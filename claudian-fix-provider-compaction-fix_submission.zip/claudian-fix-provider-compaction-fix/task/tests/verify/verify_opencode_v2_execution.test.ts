// @ts-nocheck
import { existsSync, mkdtempSync, realpathSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import * as path from 'node:path';

import { createForkTestEnvironment } from '@test/helpers/features/chat/ProviderForkTestHarness';
import { testDate } from '@test/helpers/testClock';

import { isSteerableExecutionSession, type ProviderExecutionEvent, ProviderExecutionLifecycleRegistry, type ProviderExecutionRequest, type ProviderSessionEvent } from '@/core/execution';
import { ProviderRegistry } from '@/core/providers/ProviderRegistry';
import type { ChatMessage } from '@/core/types';
import { ChatExecutionCoordinator, type ChatSteerOutcome } from '@/features/chat/execution/ChatExecutionCoordinator';
import { providerOutputEventToStreamChunk } from '@/features/chat/rendering/providerOutputChunks';
import { OpencodeExecutionBackend } from '@/providers/opencode/execution/OpencodeExecutionBackend';
import { OpencodeServerService } from '@/providers/opencode/http/OpencodeServerService';

// Native HTTP boundary, based on v2.0.12 event and route contracts.
const fixture = `#!/usr/bin/env node
const http = require('node:http');
if (process.argv.includes('--version')) { console.log('opencode v2.0.12'); return; }
if (!process.argv.includes('serve')) process.exit(3);
let onSteer, selectedAgents = [], inbox = [], lateChild, feed, permission, grandApproval, form, mcpAnswer, settleInventory = false, cancelRace = false, ownedForms = [], idle = true, waiter, messages = [], turn = 0, modelRequests = 0, releaseModel;
let activated = !process.env.ACTIVATION_DELAY_MS, activation;
const emit = (type, data) => feed.write('data: ' + JSON.stringify({ type, data: { sessionID: 'ses_test', ...data } }) + '\\n\\n');
const server = http.createServer(async (req, res) => {
  if (req.headers.authorization !== 'Basic ' + Buffer.from('opencode:' + process.env.OPENCODE_PASSWORD).toString('base64')) { res.writeHead(403).end(); return; }
  let raw = ''; for await (const c of req) raw += c;
  const body = raw ? JSON.parse(raw) : {};
  const route = new URL(req.url, 'http://localhost').pathname;
  res.setHeader('Content-Type', 'application/json');
  if (route === '/api/event') { feed = res; res.setHeader('Content-Type', 'text/event-stream'); emit('server.connected', {}); return; }
  if (route === '/api/agent') {
    const base = JSON.parse(require('node:fs').readFileSync(process.env.OPENCODE_CONFIG, 'utf8'));
    const inline = JSON.parse(process.env.OPENCODE_CONFIG_CONTENT || '{}');
    res.end(JSON.stringify({ data: [...Object.entries(inline.agent || {}).map(([id, agent]) => ({ id, system: agent.prompt })), ...Object.entries(base.agents || {}).map(([id, agent]) => ({ id, ...agent }))] })); return;
  }
  if (route === '/api/integration' || route === '/api/model') {
    activation ??= new Promise(resolve => setTimeout(() => { activated = true; resolve(); }, Number(process.env.ACTIVATION_DELAY_MS || 0)));
    if (route === '/api/integration') { await activation; res.end(JSON.stringify({ data: [] })); return; }
    res.end(JSON.stringify({ data: activated
      ? [{ id: 'chat', providerID: 'deepseek', name: 'Chat', enabled: true, variants: [], limit: { context: 1000 } }]
      : [{ id: 'builtin', providerID: 'opencode', name: 'Builtin', enabled: true, variants: [] }] })); return;
  }
  if (route === '/api/command') { res.end(JSON.stringify({ data: [{ name: 'review', description: 'Review' }] })); return; }
  if (route === '/api/form') {
    const snapshot = [...ownedForms];
    if (settleInventory) {
      emit('form.cancelled', { sessionID: 'global', id: 'frm_mcp' }); mcpAnswer = 'cancelled';
      await new Promise(resolve => setTimeout(resolve, 20));
    }
    res.end(JSON.stringify({ data: snapshot })); return;
  }
  if (route === '/api/session/global/form/frm_mcp/reply') { mcpAnswer = body.answer; emit('form.replied', { sessionID: 'global', id: 'frm_mcp' }); res.writeHead(204).end(); return; }
  if (route === '/api/session/global/form/frm_mcp' && req.method === 'DELETE') { mcpAnswer = 'cancelled'; emit('form.cancelled', { sessionID: 'global', id: 'frm_mcp' }); if (cancelRace) await new Promise(resolve => setTimeout(resolve, 30)); res.writeHead(204).end(); return; }
  if (route === '/api/mcp') { res.end(JSON.stringify({ data: [] })); return; }
  if (route === '/api/session' && process.env.EXPECT_RESUME === '1') { res.writeHead(409).end(); return; }
  if (route === '/api/session' || (route === '/api/session/ses_test' && req.method === 'GET')) { if (body.agent) selectedAgents.push(body.agent); res.end(JSON.stringify({ data: { id: 'ses_test' } })); return; }
  if (route.endsWith('/prompt') && body.delivery === 'steer') {
    if (process.env.STEER_ADMISSION === 'reject') { res.writeHead(400).end(); onSteer?.(null); return; }
    inbox.push(body.id);
    res.end(JSON.stringify({ data: { id: body.id, sessionID: 'ses_test', type: 'user', payload: { text: body.text }, delivery: 'steer' } }));
    emit('session.inbox.enqueued', { inboxID: body.id, item: { type: 'user', payload: { text: body.text }, delivery: 'steer' } });
    onSteer?.(body); return;
  }
  if (route.startsWith('/api/session/ses_test/inbox/') && req.method === 'DELETE') {
    const id = decodeURIComponent(route.slice('/api/session/ses_test/inbox/'.length));
    if (process.env.COMPACT_QUEUED_FILE && require('node:fs').existsSync(process.env.COMPACT_QUEUED_FILE) && require('node:fs').readFileSync(process.env.COMPACT_QUEUED_FILE, 'utf8') === id) {
      require('node:fs').unlinkSync(process.env.COMPACT_QUEUED_FILE); emit('session.inbox.cancelled', { inboxID: id }); res.writeHead(204).end(); return;
    }
    if (!inbox.includes(id)) { res.writeHead(409).end(JSON.stringify({ _tag: 'ConflictError' })); return; }
    inbox = inbox.filter(item => item !== id);
    emit('session.inbox.cancelled', { inboxID: id }); res.writeHead(204).end(); return;
  }
  if (route.endsWith('/interrupt')) { emit('session.execution.interrupted', { reason: 'user' }); res.end(JSON.stringify({ interrupted: true })); return; }
  if (route.endsWith('/model') && process.env.HOLD_SECOND_MODEL && ++modelRequests === 2) {
    require('node:fs').writeFileSync(process.env.HOLD_SECOND_MODEL, '');
    await new Promise(resolve => { releaseModel = resolve; setTimeout(resolve, 1000); });
  }
  if (route.endsWith('/model') || route.endsWith('/agent')) { if (body.agent) selectedAgents.push(body.agent); if (process.env.LATE_CHILD_STAGE === 'configuration') lateChild?.(); res.writeHead(204).end(); return; }
  if (route === '/api/session/ses_grand/permission/per_grand/reply') { grandApproval = body.decision; res.writeHead(204).end(); return; }
  if (route.endsWith('/permission/per_test/reply')) { permission = body.decision; res.writeHead(204).end(); return; }
  if (route.endsWith('/form/frm_test/reply')) { form = body.answer; res.writeHead(204).end(); return; }
  if (route.endsWith('/message')) { res.end(JSON.stringify({ data: messages, cursor: {} })); return; }
  if (route.endsWith('/wait')) { if (idle) res.writeHead(204).end(); else waiter = res; return; }
  if (route === '/api/session/ses_test/compact') {
    if (req.method !== 'POST' || Object.keys(body).some(key => key !== 'id')) { res.writeHead(400).end(); return; }
    if (process.env.COMPACT_OUTCOME === 'http-error') { res.writeHead(400).end(JSON.stringify({ message: 'Cannot compact this session' })); return; }
    const compactId = body.id ?? 'msg_compact';
    if (process.env.COMPACT_QUEUED_FILE) {
      require('node:fs').writeFileSync(process.env.COMPACT_QUEUED_FILE, compactId);
      await new Promise(resolve => setTimeout(resolve, Number(process.env.COMPACT_ADMISSION_DELAY || 0)));
      res.end(JSON.stringify({ data: { id: compactId, type: 'compaction' } })); return;
    }
    idle = false;
    const compact = () => {
      emit('session.execution.started', {});
      if (process.env.STALE_COMPACT_FAILURE === '1') emit('session.compaction.failed', { reason: 'manual', inputID: 'msg_old_compaction', error: { type: 'compaction.interrupted', message: 'Compaction was interrupted' } });
      emit('session.inbox.delivered', { inboxID: compactId });
      emit('session.compaction.started', { reason: 'manual', inputID: compactId });
      if (process.env.COMPACT_STARTED_FILE) { require('node:fs').writeFileSync(process.env.COMPACT_STARTED_FILE, ''); return; }
      if (process.env.COMPACT_OUTCOME === 'failed') emit('session.compaction.failed', { reason: 'manual', inputID: compactId, error: { message: 'Compaction model failed' } });
      else emit('session.compaction.ended', { reason: 'manual', text: 'Internal summary' });
      // A failed compaction settles its barrier, so the surrounding drain can still succeed.
      emit('session.execution.succeeded', {}); idle = true;
    };
    if (process.env.COMPACT_BEFORE_RESPONSE === '1') compact();
    res.end(JSON.stringify({ data: { id: compactId, type: 'compaction' } }));
    if (process.env.COMPACT_BEFORE_RESPONSE !== '1') setTimeout(compact, 50);
    return;
  }
  if (route.endsWith('/prompt') || route.endsWith('/command')) {
    releaseModel?.();
    if (body.text.includes('Old local history')) { res.writeHead(400).end(); return; }
    const assistantMessageID = 'msg_assistant_' + (++turn);
    idle = false; res.end(JSON.stringify({ data: { id: body.id ?? 'msg_user' } }));
    if (process.env.COMPACT_QUEUED_FILE && require('node:fs').existsSync(process.env.COMPACT_QUEUED_FILE)) {
      require('node:fs').unlinkSync(process.env.COMPACT_QUEUED_FILE);
      emit('session.compaction.ended', { reason: 'manual', text: 'Leaked compact' });
    }
    if (process.env.LATE_CHILD_STAGE === 'prompt') lateChild?.();
    setTimeout(async () => {
      emit('session.execution.started', {});
      // Undelivered steers left in the native inbox fold into the next execution.
      for (const inboxID of inbox.splice(0)) { emit('session.inbox.delivered', { inboxID }); emit('session.text.delta', { assistantMessageID, ordinal: 9, delta: 'Leaked steer ' }); }
      emit('session.step.started', { assistantMessageID });
      if (body.text.startsWith('steer')) {
        const deliver = steer => {
          inbox = inbox.filter(item => item !== steer.id);
          emit('session.inbox.delivered', { inboxID: steer.id });
          emit('session.step.started', { assistantMessageID: 'msg_steered' });
          emit('session.text.ended', { assistantMessageID: 'msg_steered', ordinal: 0, text: process.env.ECHO_PROMPT === '1' ? JSON.stringify(steer) : 'Saw ' + steer.text });
          emit('session.execution.succeeded', {});
        };
        onSteer = steer => {
          onSteer = undefined;
          if (!steer) { emit('session.text.ended', { assistantMessageID, ordinal: 0, text: 'Working alone' }); emit('session.execution.succeeded', {}); return; }
          if (body.text === 'steer') { emit('session.step.ended', {}); deliver(steer); }
          // The execution ended as the steer was admitted; native starts another execution for it.
          if (body.text === 'steer-late') { emit('session.execution.succeeded', {}); setTimeout(() => { emit('session.execution.started', {}); deliver(steer); }, 30); }
        };
        emit('session.text.delta', { assistantMessageID, ordinal: 0, delta: 'Working' });
        return;
      }
      if (process.env.ECHO_AGENTS === '1') {
        emit('session.text.ended', { assistantMessageID, ordinal: 0, text: JSON.stringify(selectedAgents) });
        emit('session.execution.succeeded', {}); idle = true; waiter?.writeHead(204).end();
        return;
      }
      if (process.env.ECHO_PROMPT === '1') {
        emit('session.text.ended', { assistantMessageID, ordinal: 0, text: JSON.stringify({ route, body }) });
        emit('session.execution.succeeded', {}); idle = true; waiter?.writeHead(204).end();
        return;
      }
      if (body.text.startsWith('mcp-form')) {
        const nativeForm = { id: 'frm_mcp', sessionID: 'global', title: 'probe is requesting input', metadata: { kind: 'mcp-elicitation', server: 'probe', message: 'Choose a color' }, fields: [{ key: 'q0', type: (body.text.endsWith('unsupported') || body.text.endsWith('cancel-race')) ? 'external' : 'string', title: 'Color', options: [{ label: 'Blue', value: 'blue' }], custom: false, required: true }] };
        if (body.text.endsWith('values')) nativeForm.fields[0].options = [{ value: 'Blue', label: 'Red' }, { value: 'green', label: 'Blue' }];
        if (body.text.endsWith('optional')) nativeForm.fields[0].required = false;
        if (body.text.endsWith('default')) nativeForm.fields[0].default = 'blue';
        if (body.text.endsWith('constrained')) nativeForm.fields[0].maxLength = 2;
        if (body.text.endsWith('empty-multi')) nativeForm.fields[0].type = 'multiselect';
        if (body.text === 'mcp-form-late') emit('session.execution.succeeded', {});
        cancelRace = body.text.endsWith('cancel-race');
        settleInventory = body.text === 'mcp-form-settled';
        ownedForms = [nativeForm];
        emit('form.created', { form: { ...nativeForm, id: 'frm_other_location' } });
        emit('form.created', { form: nativeForm });
        const deadline = Date.now() + 500;
        while (!mcpAnswer && Date.now() < deadline) await new Promise(r => setTimeout(r, 10));
        if (settleInventory || cancelRace) await new Promise(resolve => setTimeout(resolve, 70));
        if (!mcpAnswer) emit('session.execution.failed', { error: { message: 'MCP form never settled' } });
        else { if (body.text === 'mcp-form-late') emit('session.execution.started', {}); emit('session.text.ended', { assistantMessageID, ordinal: 0, text: body.text === 'mcp-form-late' ? 'Automatic reply' : JSON.stringify(mcpAnswer) }); emit('session.execution.succeeded', {}); }
        return;
      }
      if (body.text === 'nested') {
        for (const [owner, target, id] of [['ses_test', 'ses_worker', 'tool_worker'], ['ses_worker', 'ses_grand', 'tool_nested']]) {
          emit('session.tool.input.started', { sessionID: owner, assistantMessageID, id, name: 'subagent' });
          emit('session.tool.called', { sessionID: owner, assistantMessageID, id, input: { agent: 'worker' } });
          emit('session.tool.progress', { sessionID: owner, assistantMessageID, id, metadata: { sessionID: target, status: 'running' } });
        }
        emit('session.tool.input.started', { sessionID: 'ses_grand', assistantMessageID, id: 'tool_shell', name: 'shell' });
        emit('session.tool.called', { sessionID: 'ses_grand', assistantMessageID, id: 'tool_shell', input: { command: 'pwd' } });
        emit('permission.asked', { sessionID: 'ses_grand', id: 'per_grand', action: 'shell', resources: ['pwd'] });
        const deadline = Date.now() + 500;
        while (!grandApproval && Date.now() < deadline) await new Promise(r => setTimeout(r, 10));
        emit(grandApproval === 'once' ? 'session.execution.succeeded' : 'session.execution.failed', { error: { message: 'Nested approval was not answered' } });
        return;
      }
      if (body.text === 'cancel') { emit('session.text.delta', { assistantMessageID, ordinal: 0, delta: 'Waiting' }); return; }
      if (body.text === 'disconnect') { feed.end(); return; }
      emit('permission.asked', { id: 'per_test', action: 'shell', resources: ['echo test'] });
      if (body.text === 'question-wording') {
        emit('form.created', { form: { id: 'frm_test', sessionID: 'ses_test', title: 'Questions', metadata: { kind: 'question' }, fields: [{ key: 'q0', type: 'string', title: 'Color', description: 'Which color should the report use?', custom: true, options: [{ value: 'blue', label: 'Blue' }] }] } });
      }
      if (body.text !== 'slow' && body.text !== 'question-wording') emit('form.created', { form: { id: 'frm_test', sessionID: 'ses_test', title: 'Color', fields: [{ key: 'q0', type: 'string', title: 'Pick a color', options: [{ value: 'blue', label: 'Blue' }] }] } });
      const start = Date.now();
      while ((!permission || (!form && body.text !== 'slow')) && Date.now() - start < 1500) await new Promise(r => setTimeout(r, 10));
      if (permission !== 'once' || (body.text !== 'slow' && form?.q0 !== 'blue')) { emit('session.execution.failed', { error: { message: 'Interactions not answered' } }); return; }
      if (body.text.startsWith('background')) {
        emit('session.tool.input.started', { assistantMessageID, id: 'tool_child', name: 'subagent' });
        emit('session.tool.called', { assistantMessageID, id: 'tool_child', input: { background: true, agent: 'worker' } });
        emit('session.tool.progress', { assistantMessageID, id: 'tool_child', metadata: { sessionID: 'ses_child', status: 'running' } });
        emit('session.tool.success', { assistantMessageID, id: 'tool_child', content: [{ type: 'text', text: 'Background child launched' }], metadata: { sessionID: 'ses_child', status: 'background' } });
        emit('session.tool.input.started', { sessionID: 'ses_child', assistantMessageID: 'msg_child', id: 'tool_read', name: 'read' });
        emit('session.tool.called', { sessionID: 'ses_child', assistantMessageID: 'msg_child', id: 'tool_read', input: { path: '/workspace/notes.md' } });
        emit('session.tool.success', { sessionID: 'ses_child', assistantMessageID: 'msg_child', id: 'tool_read', content: [{ type: 'text', text: 'Child read result' }] });
        emit('session.step.ended', { sessionID: 'ses_child', assistantMessageID: 'msg_child', tokens: { input: 900, output: 200, reasoning: 100, cache: { read: 300, write: 0 } } });
        if (body.text === 'background-overlap') {
          lateChild = () => {
            lateChild = undefined;
            emit('session.tool.input.started', { sessionID: 'ses_child', assistantMessageID: 'msg_child', id: 'late_read', name: 'read' });
            emit('session.tool.called', { sessionID: 'ses_child', assistantMessageID: 'msg_child', id: 'late_read', input: { path: '/workspace/late.md' } });
            emit('session.tool.success', { sessionID: 'ses_child', assistantMessageID: 'msg_child', id: 'late_read', content: [{ type: 'text', text: 'Late child result' }] });
            emit('session.execution.succeeded', { sessionID: 'ses_child' });
          };
        } else setTimeout(async () => {
          if (body.text === 'background-approval' || body.text === 'background-nested') {
            const interactionSession = body.text === 'background-nested' ? 'ses_grand' : 'ses_child';
            if (body.text === 'background-nested') {
              emit('session.tool.input.started', { sessionID: 'ses_child', assistantMessageID: 'msg_child', id: 'nested', name: 'subagent' });
              emit('session.tool.called', { sessionID: 'ses_child', assistantMessageID: 'msg_child', id: 'nested', input: { agent: 'worker', background: true } });
              emit('session.tool.progress', { sessionID: 'ses_child', assistantMessageID: 'msg_child', id: 'nested', metadata: { sessionID: 'ses_grand', status: 'running' } });
              emit('session.text.ended', { sessionID: 'ses_child', assistantMessageID: 'msg_child', ordinal: 0, text: 'Child result' });
              emit('session.execution.succeeded', { sessionID: 'ses_child' });
            }
            permission = undefined; form = undefined;
            emit('permission.asked', { sessionID: interactionSession, id: 'per_test', action: 'shell', resources: ['echo child'] });
            emit('form.created', { form: { id: 'frm_test', sessionID: interactionSession, title: 'Child color', fields: [{ key: 'q0', type: 'string', title: 'Pick a child color', options: [{ value: 'blue', label: 'Blue' }] }] } });
            const deadline = Date.now() + 3000;
            while ((!permission || !form) && Date.now() < deadline) await new Promise(r => setTimeout(r, 10));
            if (permission !== 'once' || form?.q0 !== 'blue') return;
            if (body.text === 'background-nested') emit('session.execution.succeeded', { sessionID: 'ses_grand' });
          }
          emit('session.text.ended', { sessionID: 'ses_child', assistantMessageID: 'msg_child', ordinal: 0, text: 'Child result' });
          emit('session.execution.succeeded', { sessionID: 'ses_child' });
          emit('session.execution.started', {});
          emit('session.text.ended', { assistantMessageID: 'msg_background', ordinal: 0, text: 'Automatic reply' });
          emit('session.execution.succeeded', {});
        }, 50);
      }
      emit('session.tool.input.started', { assistantMessageID, id: 'reused_tool', name: 'read' });
      emit('session.tool.called', { assistantMessageID, id: 'reused_tool', input: { path: '/workspace/notes.md' } });
      emit('session.tool.success', { assistantMessageID, id: 'reused_tool', content: [{ type: 'text', text: 'Read result' }] });
      emit('session.text.delta', { assistantMessageID, ordinal: 0, delta: 'Finished ' });
      emit('session.text.ended', { assistantMessageID, ordinal: 0, text: 'Finished review' });
      emit('session.step.ended', { tokens: { input: 100, output: 30, reasoning: 5, cache: { read: 20, write: 10 } } });
      messages = [{ id: assistantMessageID, type: 'assistant', tokens: { input: 100, output: 30, reasoning: 5, cache: { read: 20, write: 10 } }, content: [{ type: 'text', text: 'Finished review' }] }];
      emit('session.execution.succeeded', {}); idle = true; waiter?.writeHead(204).end();
    }, 50); return;
  }
  res.writeHead(404).end();
});
server.listen(0, '127.0.0.1', () => console.log(JSON.stringify({ url: 'http://127.0.0.1:' + server.address().port })));
process.stdin.resume(); process.stdin.on('end', () => server.close());
`;

function createFixture(resume = false, approval?: (signal: AbortSignal) => Promise<void>, environmentVariables = '') {
  const root = realpathSync(mkdtempSync(path.join(tmpdir(), 'claudian-http-execution-')));
  const cliPath = path.join(root, 'opencode.cjs');
  writeFileSync(cliPath, fixture, { mode: 0o700 });
  const plugin: any = {
    settings: { model: 'opencode:deepseek/chat', providerConfigs: { opencode: { enabled: true, visibleModels: ['deepseek/chat'], discoveredModels: [{ rawId: 'deepseek/chat', label: 'DeepSeek' }], environmentVariables: [resume ? 'EXPECT_RESUME=1' : '', environmentVariables].join('\n') } } },
    getResolvedProviderCliPath: async () => cliPath,
    mutateSettings: async (fn: (settings: unknown) => void) => fn(plugin.settings),
    mutateSettingsConditionally: async (fn: (settings: unknown) => void) => fn(plugin.settings),
    notifyProviderChatOptionsChanged() {},
  };
  const approvals: unknown[] = [], questions: unknown[] = [];
  const serverService = new OpencodeServerService();
  const session = new OpencodeExecutionBackend(plugin, { serverService }).createSession({
    ...(resume ? { resumeSeed: { providerSessionId: 'ses_test', providerState: { nativeVersion: 2 } } } : {}),
    vaultWorkingDirectory: root, lifecycle: 'ephemeral', nativePersistence: 'disabled-if-supported',
    interactionPort: {
      requestApproval: async (request, signal) => { approvals.push(request); await approval?.(signal); return { interactionId: request.interactionId, decision: 'allow' }; },
      askUserQuestion: async request => { questions.push(request); const questionsInput = request.input.questions; return { interactionId: request.interactionId, answers: { q0: Array.isArray(questionsInput) ? questionsInput[0].options[0].value : '' } }; },
      dismissInteraction() {},
    },
  });
  return { plugin, session, approvals, questions, async dispose() { await session.dispose(); await serverService.dispose(); rmSync(root, { recursive: true, force: true }); } };
}

function request(text = '/review changes'): ProviderExecutionRequest {
  return {
    input: [{ type: 'text', text }],
    configuration: { model: 'opencode:deepseek/chat', permissionMode: 'normal', systemInstructions: { kind: 'explicit', instructions: 'Review changes.' } },
    toolPolicy: { kind: 'provider-default' }, signal: new AbortController().signal,
  };
}

it.each([
  { beforeResponse: false, staleFailure: false },
  { beforeResponse: true, staleFailure: false },
  { beforeResponse: false, staleFailure: true },
  { beforeResponse: true, staleFailure: true },
])('compacts through the native endpoint (events before admission: $beforeResponse, stale failure: $staleFailure)', async ({ beforeResponse, staleFailure }) => {
  const f = createFixture(true, undefined, `COMPACT_BEFORE_RESPONSE=${beforeResponse ? '1' : '0'}\nSTALE_COMPACT_FAILURE=${staleFailure ? '1' : '0'}`);
  try {
    const events: ProviderExecutionEvent[] = [];
    for await (const event of f.session.execute(request('/compact')).events) events.push(event);
    expect(events.filter(event => event.type === 'context_compacted')).toHaveLength(1);
    expect(events.at(-1)?.type).toBe('turn_completed');
    expect(events.some(event => event.type === 'text_delta' || event.type === 'user_message_started')).toBe(false);
    expect(events.find(event => event.type === 'turn_started')).not.toHaveProperty('nativeUserMessageId');
    expect(f.approvals).toEqual([]);
    expect(f.questions).toEqual([]);
  } finally { await f.dispose(); }
});

it.each([
  ['http-error', 'Cannot compact this session'],
  ['failed', 'Compaction model failed'],
])('reports native compaction failure (%s)', async (outcome, message) => {
  const f = createFixture(true, undefined, `COMPACT_OUTCOME=${outcome}`);
  try {
    const events: ProviderExecutionEvent[] = [];
    for await (const event of f.session.execute(request('/compact')).events) events.push(event);
    expect(events.at(-1)).toMatchObject({ type: 'execution_error', message: expect.stringContaining(message) });
    expect(events.some(event => event.type === 'context_compacted' || event.type === 'turn_completed')).toBe(false);
  } finally { await f.dispose(); }
});

it('rejects compact arguments unsupported by the native endpoint', async () => {
  const f = createFixture(true);
  try {
    const events: ProviderExecutionEvent[] = [];
    for await (const event of f.session.execute(request('/compact keep recent edits')).events) events.push(event);
    // Native endpoint takes a bare command; trailing args must error. Wording is the
    // solver's choice: assert an error surfaces, not any specific phrasing.
    expect(events.at(-1)).toMatchObject({ type: 'execution_error', message: expect.any(String) });
  } finally { await f.dispose(); }
});

it('cancels native compaction, declines steering, and can continue the session', async () => {
  const started = path.join(realpathSync(mkdtempSync(path.join(tmpdir(), 'claudian-http-compact-'))), 'started');
  const f = createFixture(true, undefined, `COMPACT_STARTED_FILE=${started}`);
  try {
    const run = f.session.execute(request('/compact'));
    const events: ProviderExecutionEvent[] = [];
    const consumed = (async () => { for await (const event of run.events) events.push(event); })();
    const deadline = Date.now() + 3000;
    while (!existsSync(started) && Date.now() < deadline) await new Promise(resolve => setTimeout(resolve, 10));
    expect(existsSync(started)).toBe(true);
    if (!isSteerableExecutionSession(f.session)) throw new Error('Missing steering');
    await expect(f.session.steer(request('Also check tests'))).resolves.toBe(false);
    run.cancel();
    await consumed;
    expect(events.at(-1)?.type).toBe('cancelled');
    expect(events.some(event => event.type === 'context_compacted')).toBe(false);
    const continued: ProviderExecutionEvent[] = [];
    for await (const event of f.session.execute(request('continue')).events) continued.push(event);
    expect(continued.at(-1)?.type).toBe('turn_completed');
  } finally { await f.dispose(); rmSync(path.dirname(started), { recursive: true, force: true }); }
});

describe('native steering', () => {
  it.each(['/compact', '/COMPACT'])('preserves captures and images when steering literal %j text', async text => {
    const f = createFixture(false, undefined, 'ECHO_PROMPT=1');
    try {
      const events: ProviderExecutionEvent[] = [];
      let admission: Promise<boolean> | undefined;
      for await (const event of f.session.execute(request('steer')).events) {
        events.push(event);
        if (event.type === 'text_delta' && event.text === 'Working') {
          if (!isSteerableExecutionSession(f.session)) throw new Error('Missing steering');
          admission = f.session.steer({
            ...request(text),
            input: [{ type: 'text', text }, { type: 'image', image: {
              id: 'capture', name: 'capture.png', data: 'aW1hZ2U=',
              mediaType: 'image/png', size: 5, source: 'paste',
            } }],
            context: { selections: [{ kind: 'editor', selection: { notePath: 'note.md', mode: 'selection', selectedText: 'captured note' } }] },
          });
        }
      }
      expect(await admission).toBe(true);
      expect(events.at(-1)?.type).toBe('turn_completed');
      const echoed = events.flatMap(event => event.type === 'text_delta' && event.text !== 'Working' ? [event.text] : []).join('');
      expect(JSON.parse(echoed)).toEqual({
        id: expect.any(String), delivery: 'steer',
        text: `${text}\n\n<editor_selection path="note.md">\n<![CDATA[captured note]]>\n</editor_selection>`,
        files: [{ uri: 'data:image/png;base64,aW1hZ2U=' }],
      });
      expect(events.some(event => event.type === 'context_compacted')).toBe(false);
    } finally { await f.dispose(); }
  });

  function steer(f: ReturnType<typeof createFixture>, text: string): Promise<boolean> {
    if (!isSteerableExecutionSession(f.session)) throw new Error('Missing steering');
    return f.session.steer(request(text));
  }

  async function steerDuring(f: ReturnType<typeof createFixture>, text: string) {
    const events: ProviderExecutionEvent[] = [];
    const background: ProviderSessionEvent[] = [];
    f.session.onEvent(event => background.push(event));
    const run = f.session.execute(request(text));
    let steered: Promise<boolean> | undefined;
    for await (const event of run.events) {
      events.push(event);
      if (event.type === 'text_delta' && event.text === 'Working' && !steered) {
        steered = steer(f, 'Also check tests');
        if (text === 'steer-cancel') run.cancel();
      }
    }
    return { events, background, accepted: await steered };
  }

});

it.each(['/compact', ' \t/CoMpAcT  '])('compacts %j with captured editor context', async text => {
  const f = createFixture(true);
  try {
    const events: ProviderExecutionEvent[] = [];
    for await (const event of f.session.execute({
      ...request(text),
      context: { selections: [{ kind: 'editor', selection: { notePath: 'note.md', mode: 'selection', selectedText: 'selected note text' } }] },
    }).events) events.push(event);
    expect(events.at(-1)).toMatchObject({ type: 'turn_completed' });
    expect(events.filter(event => event.type === 'context_compacted')).toHaveLength(1);
  } finally { await f.dispose(); }
});

it('requires replaying recovered context before compacting a replacement native session', async () => {
  const f = createFixture();
  try {
    const events: ProviderExecutionEvent[] = [];
    for await (const event of f.session.execute({
      ...request('/compact'),
      conversationHistory: [{ id: 'old-user', role: 'user', content: 'Earlier conversation', timestamp: testDate().getTime() }],
    }).events) events.push(event);
    // A user-facing error must surface (contract); its wording is the solver's choice.
    expect(events.at(-1)).toMatchObject({ type: 'execution_error', message: expect.any(String) });
    expect(events.some(event => event.type === 'context_compacted')).toBe(false);
  } finally { await f.dispose(); }
});

it.each([0, 150])('recalls a queued compact before continuing after cancellation (admission delay: %s)', async delay => {
  const queued = path.join(realpathSync(mkdtempSync(path.join(tmpdir(), 'claudian-queued-compact-'))), 'queued');
  const f = createFixture(true, undefined, `COMPACT_QUEUED_FILE=${queued}\nCOMPACT_ADMISSION_DELAY=${delay}`);
  try {
    const run = f.session.execute(request('/compact'));
    const events: ProviderExecutionEvent[] = [];
    const consumed = (async () => { for await (const event of run.events) events.push(event); })();
    const deadline = Date.now() + 3000;
    while (!existsSync(queued) && Date.now() < deadline) await new Promise(resolve => setTimeout(resolve, 10));
    expect(existsSync(queued)).toBe(true);
    // For the zero-delay case let the HTTP admission response arrive before cancelling.
    if (!delay) await new Promise(resolve => setTimeout(resolve, 30));
    run.cancel();
    await consumed;
    expect(events.at(-1)?.type).toBe('cancelled');
    const continued: ProviderExecutionEvent[] = [];
    for await (const event of f.session.execute(request('continue')).events) continued.push(event);
    expect(continued.at(-1)?.type).toBe('turn_completed');
    expect(continued.some(event => event.type === 'context_compacted')).toBe(false);
  } finally { await f.dispose(); rmSync(path.dirname(queued), { recursive: true, force: true }); }
});
