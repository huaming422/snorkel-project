## Task

The MCP chart tools ignore a time-grain override on saved charts that group by time.
If you fetch a saved chart's data or SQL with `extra_form_data={"time_grain_sqla": "P1M"}`, you still get the chart's saved grain back.
Row counts and timestamps match a call with no override, and nothing tells the caller the override was skipped.
For example, a chart saved at day grain over 90 days of data should come back as 3 monthly rows, and right now it still returns 90.
When a chart's data is pulled with a dashboard's filters applied, a dashboard time-grain filter gets dropped the same way, though only on some charts.
A pivot table or table chart that lists another dimension before its date column shows it.
An override should re-aggregate on both paths, whether the new grain is coarser or finer than the saved one.
Only the time column should take the new grain.
Every other column in the query should come back exactly as saved, and that includes charts with no time column at all.
