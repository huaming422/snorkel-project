# Behavioral checks for time-grain overrides on saved time-axis charts.
#
# Runs under the repo venv (see verify.toml [pytest] command) so it can import
# superset. The runner points pytest at this file alone, so the repo's
# tests/unit_tests/conftest.py is never collected. This file builds its own
# app context and runs real SQLite queries instead.
#
# Every check drives a pre-existing entry point:
#   - superset.mcp_service.chart.chart_helpers.merge_extra_form_data_filters_into_query
#     (both MCP chart tools apply extra_form_data to a saved query through it)
#   - superset.charts.data.dashboard_filter_context.apply_dashboard_filter_context
#   - superset.connectors.sqla.models.SqlaTable.adhoc_column_to_sqla / get_query_result
#   - superset.common.query_object.QueryObject
# Nothing added by a fix is imported. The grain is read back from executed
# buckets or from the compiled SQL of the time axis column.
#
# Literals that show up in expectations come from Superset's query contract:
#   - ISO-8601 grain tokens P1D / P1M / P1W (the frontend grain vocabulary)
#   - columnType "BASE_AXIS", the tag the frontend puts on a chart's time axis
#     and the one adhoc_column_to_sqla checks before truncating
#   - the SQLite truncation text "start of month", from
#     superset/db_engine_specs/sqlite.py
from __future__ import annotations

from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, timedelta
from typing import Any

import pandas as pd
import pytest
from sqlalchemy import create_engine
from sqlalchemy.pool import StaticPool

# ---------------------------------------------------------------------------
# App context (session-scoped). Same setup as the `app` and autouse
# `app_context` fixtures in tests/unit_tests/conftest.py, which pytest does not
# load here.
# ---------------------------------------------------------------------------


@pytest.fixture(scope="session")
def _app():
    from superset.app import SupersetApp
    from superset.extensions import appbuilder
    from superset.initialization import SupersetAppInitializer

    app = SupersetApp(__name__)
    app.config.from_object("superset.config")
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite://"
    app.config["WTF_CSRF_ENABLED"] = False
    app.config["PREVENT_UNSAFE_DB_CONNECTIONS"] = False
    app.config["TESTING"] = True
    app.config["RATELIMIT_ENABLED"] = False
    app.config["CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    app.config["DATA_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    app.config["TALISMAN_ENABLED"] = False
    app.config["SERVER_NAME"] = "example.com"
    app.config["APPLICATION_ROOT"] = "/"
    appbuilder.baseviews = []
    SupersetAppInitializer(app).init_app()
    return app


@pytest.fixture(autouse=True)
def app_context(_app):
    with _app.app_context():
        yield


# ---------------------------------------------------------------------------
# Dataset and query payload helpers
# ---------------------------------------------------------------------------

# 90 consecutive days starting 2024-01-01, so 90 daily buckets or 3 monthly ones.
_START = datetime(2024, 1, 1)
_DAYS = 90
_MONTHS = [
    pd.Timestamp("2024-01-01"),
    pd.Timestamp("2024-02-01"),
    pd.Timestamp("2024-03-01"),
]
_ENTRY_POINTS = ["mcp", "dashboard"]


def _events_dataset(mocker) -> Any:
    """An in-memory SQLite dataset with one row per day."""
    from superset.connectors.sqla.models import SqlaTable, TableColumn
    from superset.models.core import Database

    engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
        future=True,
    )
    connection = engine.raw_connection()
    connection.execute("CREATE TABLE events (ts TIMESTAMP, val INTEGER)")
    connection.executemany(
        "INSERT INTO events VALUES (?, 1)",
        [
            ((_START + timedelta(days=offset)).strftime("%Y-%m-%d %H:%M:%S"),)
            for offset in range(_DAYS)
        ],
    )
    connection.commit()

    database = Database(database_name="db", sqlalchemy_uri="sqlite://")

    @contextmanager
    def mock_get_sqla_engine(catalog=None, schema=None, **kwargs):  # noqa: ANN001
        yield engine

    mocker.patch.object(database, "get_sqla_engine", new=mock_get_sqla_engine)
    mocker.patch(
        "superset.connectors.sqla.models.security_manager.get_guest_rls_filters",
        return_value=[],
    )
    mocker.patch(
        "superset.connectors.sqla.models.security_manager.is_guest_user",
        return_value=False,
    )

    return SqlaTable(
        database=database,
        schema=None,
        table_name="events",
        main_dttm_col="ts",
        columns=[
            TableColumn(column_name="ts", is_dttm=True, type="TIMESTAMP"),
            TableColumn(column_name="val", type="INTEGER"),
        ],
    )


def _saved_query(time_grain: str) -> dict[str, Any]:
    """The query payload stored for a saved chart with a time x-axis."""
    base_axis: dict[str, Any] = {
        "sqlExpression": "ts",
        "label": "ts",
        "isColumnReference": True,
        "columnType": "BASE_AXIS",
        "timeGrain": time_grain,
    }
    return {
        "columns": [base_axis],
        "metrics": [
            {"expressionType": "SQL", "sqlExpression": "COUNT(*)", "label": "ct"}
        ],
        "filters": [],
        "extras": {"time_grain_sqla": time_grain},
        "row_limit": 1000,
    }


def _buckets(table: Any, query: dict[str, Any]) -> list[pd.Timestamp]:
    """Run a query payload and return its time buckets."""
    from superset.common.query_object import QueryObject

    query_object = QueryObject(
        datasource=table,
        metrics=query["metrics"],
        columns=query["columns"],
        filters=query["filters"],
        granularity=query.get("granularity"),
        is_timeseries=False,
        extras=query["extras"],
        row_limit=query["row_limit"],
    )
    return table.get_query_result(query_object).df["ts"].tolist()


def _axis_sql(column: dict[str, Any]) -> str:
    """Compile an axis column against the events table and return its SQL."""
    from superset.connectors.sqla.models import SqlaTable, TableColumn
    from superset.models.core import Database

    table = SqlaTable(
        database=Database(database_name="db", sqlalchemy_uri="sqlite://"),
        table_name="events",
        columns=[TableColumn(column_name="ts", is_dttm=True, type="TIMESTAMP")],
    )
    sql_column, _ = table.adhoc_column_to_sqla(column)
    return str(sql_column.compile(compile_kwargs={"literal_binds": True}))


@pytest.fixture
def _no_datasource_engine_lookup(mocker):
    """The MCP merge looks up the datasource engine. There is no saved datasource here."""
    mocker.patch(
        "superset.mcp_service.chart.chart_helpers.resolve_datasource_engine",
        return_value="base",
    )


def _merge_mcp(query: dict[str, Any], extra_form_data: dict[str, Any]) -> None:
    from superset.mcp_service.chart.chart_helpers import (
        merge_extra_form_data_filters_into_query,
    )

    merge_extra_form_data_filters_into_query(query, extra_form_data, 1, "table")


def _apply_override(
    entry_point: str, query: dict[str, Any], extra_form_data: dict[str, Any]
) -> dict[str, Any]:
    """Apply extra_form_data through one entry point and return the resulting query.

    The MCP merge updates the query dict in place. The dashboard path updates a
    query context, so the query is read back from it afterwards.
    """
    if entry_point == "mcp":
        _merge_mcp(query, dict(extra_form_data))
        return query

    from superset.charts.data.dashboard_filter_context import (
        apply_dashboard_filter_context,
    )

    query_context: dict[str, Any] = {"queries": [query]}
    apply_dashboard_filter_context(query_context, dict(extra_form_data))
    return query_context["queries"][0]


def _split_axis(columns: list[Any]) -> tuple[list[Any], list[Any]]:
    """Split columns by the time-axis tag, whatever order they come back in."""
    axis = [c for c in columns if c.get("columnType") == "BASE_AXIS"]
    others = [c for c in columns if c.get("columnType") != "BASE_AXIS"]
    return axis, others


# ---------------------------------------------------------------------------
# The override has to change what the query returns, in both directions.
# ---------------------------------------------------------------------------


@pytest.mark.usefixtures("_no_datasource_engine_lookup")
def test_mcp_override_reaggregates_monthly(mocker):
    """A daily chart overridden to monthly returns 3 months instead of 90 days."""
    table = _events_dataset(mocker)

    baseline = _buckets(table, _saved_query("P1D"))
    assert len(baseline) == _DAYS, baseline

    overridden = _saved_query("P1D")
    _merge_mcp(overridden, {"time_grain_sqla": "P1M"})
    monthly = _buckets(table, overridden)

    assert monthly != baseline
    assert monthly == _MONTHS, monthly


@pytest.mark.usefixtures("_no_datasource_engine_lookup")
def test_mcp_override_refines_daily(mocker):
    """A monthly chart overridden to daily returns all 90 days."""
    table = _events_dataset(mocker)

    assert len(_buckets(table, _saved_query("P1M"))) == 3

    overridden = _saved_query("P1M")
    _merge_mcp(overridden, {"time_grain_sqla": "P1D"})
    assert len(_buckets(table, overridden)) == _DAYS


def test_dashboard_path_honors_override(mocker):
    """A dashboard grain filter re-aggregates a chart whose axis is not the first column."""
    from superset.charts.data.dashboard_filter_context import (
        apply_dashboard_filter_context,
    )

    table = _events_dataset(mocker)

    saved = _saved_query("P1D")
    saved["columns"].insert(0, {"sqlExpression": "1", "label": "constant"})
    query_context = {"queries": [saved]}
    apply_dashboard_filter_context(query_context, {"time_grain_sqla": "P1M"})

    monthly = _buckets(table, query_context["queries"][0])
    assert monthly == _MONTHS, monthly


# ---------------------------------------------------------------------------
# Only the time axis takes the override, wherever it sits in the column list.
# ---------------------------------------------------------------------------


@pytest.mark.usefixtures("_no_datasource_engine_lookup")
@pytest.mark.parametrize("entry_point", _ENTRY_POINTS)
@pytest.mark.parametrize("axis_index", [0, 1])
@pytest.mark.parametrize("other_grain", [None, "P1W"])
def test_grain_follows_base_axis_any_position(entry_point, axis_index, other_grain):
    """The axis truncates by the new grain and the other column comes back unchanged."""
    other: dict[str, Any] = {
        "sqlExpression": "val",
        "label": "val",
        "isColumnReference": True,
    }
    if other_grain is not None:
        other["timeGrain"] = other_grain
    axis: dict[str, Any] = {
        "sqlExpression": "ts",
        "label": "ts",
        "isColumnReference": True,
        "columnType": "BASE_AXIS",
        "timeGrain": "P1D",
    }
    columns = [deepcopy(other)]
    columns.insert(axis_index, axis)
    query: dict[str, Any] = {
        "columns": columns,
        "filters": [],
        "extras": {"time_grain_sqla": "P1D"},
    }

    result = _apply_override(entry_point, query, {"time_grain_sqla": "P1M"})

    result_axis, result_others = _split_axis(result["columns"])
    assert len(result_axis) == 1, result["columns"]
    assert len(result_others) == 1, result["columns"]

    sql = _axis_sql(result_axis[0])
    assert "start of month" in sql, sql

    # A grain written onto a column that is not the axis would change how
    # time comparison resolves the query's grain, so it has to stay as saved.
    assert result_others[0] == other


# ---------------------------------------------------------------------------
# Behavior that has to stay the same.
# ---------------------------------------------------------------------------


@pytest.mark.usefixtures("_no_datasource_engine_lookup")
def test_no_override_preserves_saved_grain(mocker):
    """A request without a grain override leaves the saved grain alone."""
    table = _events_dataset(mocker)

    query = _saved_query("P1D")
    _merge_mcp(query, {"time_range": "No filter"})

    assert query["columns"][0]["timeGrain"] == "P1D"
    assert query["extras"]["time_grain_sqla"] == "P1D"
    assert len(_buckets(table, query)) == _DAYS


@pytest.mark.usefixtures("_no_datasource_engine_lookup")
@pytest.mark.parametrize("entry_point", _ENTRY_POINTS)
def test_no_base_axis_uses_extras(entry_point):
    """With no time axis the override stays in extras and no column picks up a grain."""
    saved_column = {"sqlExpression": "UPPER(country)", "label": "country"}
    query: dict[str, Any] = {
        "columns": [deepcopy(saved_column)],
        "filters": [],
        "extras": {},
    }

    result = _apply_override(entry_point, query, {"time_grain_sqla": "P1M"})

    assert result["extras"]["time_grain_sqla"] == "P1M"
    assert result["columns"] == [saved_column], result["columns"]
