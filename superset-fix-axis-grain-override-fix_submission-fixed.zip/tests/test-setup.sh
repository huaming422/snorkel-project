#!/usr/bin/env bash
# test-setup.sh runs once before the verifier.
#
# The repo's dependencies are already installed into /repo/superset/.venv when
# the image is built (see environment/Dockerfile), so normally this does no
# network work. It checks that the venv exists and that superset imports under
# a minimal app context. If the venv is somehow missing it reinstalls the
# pinned development requirements and says so in the log.

set -euo pipefail

REPO=/repo/superset
VENV="$REPO/.venv"
cd "$REPO"

# Use the venv from the image. Only go to the network if it is missing.
if [ ! -x "$VENV/bin/python" ]; then
    echo "[test-setup] repo venv missing, rebuilding it (online fallback)"
    /opt/tooling/uv/uv venv --managed-python --python 3.11 "$VENV"
    /opt/tooling/uv/uv pip install --python "$VENV/bin/python" \
        -r requirements/development.txt
fi

echo "[test-setup] smoke-testing superset imports under app context"
"$VENV/bin/python" - <<'PY'
from superset.app import SupersetApp
from superset.extensions import appbuilder
from superset.initialization import SupersetAppInitializer

app = SupersetApp(__name__)
app.config.from_object("superset.config")
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite://"
app.config["WTF_CSRF_ENABLED"] = False
app.config["TESTING"] = True
app.config["RATELIMIT_ENABLED"] = False
app.config["CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
app.config["DATA_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
app.config["TALISMAN_ENABLED"] = False
appbuilder.baseviews = []
SupersetAppInitializer(app).init_app()
with app.app_context():
    from superset.mcp_service.chart.chart_helpers import (
        merge_extra_form_data_filters_into_query,  # noqa: F401
    )
    from superset.charts.data.dashboard_filter_context import (
        apply_dashboard_filter_context,  # noqa: F401
    )
    print("[test-setup] imports OK")
PY

echo "[test-setup] done"
