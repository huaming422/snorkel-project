"""Story: dataset_task_redaction

Tests the 'show' command with --tasks --json on versions_app.
The dataset version's tasks list should have available/unavailable rows.
"""

import sys
import json
from unittest.mock import AsyncMock, MagicMock

sys.path.insert(0, "/repo/harbor/src")


def test_dataset_task_redaction(inputs, expected):
    import pytest
    from typer.testing import CliRunner
    from harbor.cli.versions import versions_app

    runner = CliRunner()
    env = {"COLUMNS": "1000", "TERM": "dumb"}

    case = expected["case"]

    # Build task rows directly as dicts (matching what DB returns for tasks)
    available_task_row = {
        "available": True,
        "name": "acme/visible-task",
        "content_hash": "sha256:" + "a" * 64,
    }
    unavailable_task_row = {
        "available": False,
        "opaque_id": "some-opaque-task-version-id",
    }

    def _package():
        return {"id": "pkg-id", "type": "dataset", "visibility": "private"}

    def _version():
        return {
            "id": "ver-id",
            "revision": 1,
            "content_hash": "sha256:" + "b" * 64,
            "published_at": "2026-07-20T12:00:00Z",
            "published_by": "user-id",
            "yanked_at": None,
            "yanked_by": None,
            "yanked_reason": None,
            "tags": ["latest"],
            "tasks": [available_task_row, unavailable_task_row],
        }

    with pytest.MonkeyPatch.context() as mp:
        db = MagicMock()
        db.get_package_version = AsyncMock(return_value=(_package(), _version()))
        mp.setattr("harbor.db.client.RegistryDB", MagicMock(return_value=db))

        result = runner.invoke(
            versions_app,
            ["show", "acme/demo@latest", "--tasks", "--json"],
            env=env,
        )

    if case == "available_row_full_metadata":
        # EXPECTED: exit code 0
        assert result.exit_code == expected["exit_code"], (
            f"Expected exit_code={expected['exit_code']}, got {result.exit_code}. "
            f"stdout: {result.stdout}"
        )

        payload = json.loads(result.stdout)
        tasks = payload.get("tasks", [])
        assert len(tasks) >= 1, f"Expected at least 1 task in payload, got {tasks}"

        available_row = tasks[0]

        # EXPECTED: availability indicator is truthy
        avail_key = "available"
        assert bool(available_row.get(avail_key)) == expected["available_is_available"], (
            f"Expected available_is_available={expected['available_is_available']}, "
            f"got {available_row.get(avail_key)}"
        )

        # EXPECTED: available row has full metadata - at least 1 identifying field
        # Count identifying fields: name, content_hash, etc.
        identifying_fields = [k for k in ("name", "content_hash", "digest", "path")
                              if available_row.get(k)]
        assert len(identifying_fields) >= expected["available_min_identifying_fields"], (
            f"Expected at least {expected['available_min_identifying_fields']} identifying fields "
            f"in available row, got {len(identifying_fields)}: {list(available_row.keys())}"
        )

    elif case == "unavailable_row_opaque_only":
        # EXPECTED: exit code 0
        assert result.exit_code == expected["exit_code"], (
            f"Expected exit_code={expected['exit_code']}, got {result.exit_code}. "
            f"stdout: {result.stdout}"
        )

        payload = json.loads(result.stdout)
        tasks = payload.get("tasks", [])
        assert len(tasks) >= 2, f"Expected at least 2 tasks in payload, got {tasks}"

        unavailable_row = tasks[1]

        # EXPECTED: availability indicator is falsy
        avail_key = "available"
        assert bool(unavailable_row.get(avail_key)) == expected["available_is_available"], (
            f"Expected available_is_available={expected['available_is_available']}, "
            f"got {unavailable_row.get(avail_key)}"
        )

        # EXPECTED: unavailable row has only opaque id, no identifying info
        # Collect string values in the unavailable row
        string_values = [
            str(v) for v in unavailable_row.values()
            if v is not None and not isinstance(v, bool)
        ]

        # Count leaked identifying substrings
        identifiers_to_check = ["visible-task", "acme", "aaaa", "/"]
        leaked_count = sum(
            1 for sv in string_values
            for ident in identifiers_to_check
            if ident in sv
        )
        assert leaked_count == expected["leaked_identifier_count"], (
            f"Expected leaked_identifier_count={expected['leaked_identifier_count']}, "
            f"got {leaked_count}. Row values: {string_values}"
        )

        # EXPECTED: opaque id field is present
        # Find the opaque id field
        opaque_id_keys = [k for k in unavailable_row.keys()
                         if "id" in k.lower() or "opaque" in k.lower()]
        opaque_id_count = sum(
            1 for k in unavailable_row.keys()
            if "opaque" in k.lower() or (k == "opaque_id")
        )
        # Also check generic "id" fields that hold an opaque value
        if opaque_id_count == 0:
            # Check if there's any id field with non-identifying value
            id_fields = [k for k in unavailable_row.keys() if "id" in k.lower()]
            opaque_id_count = len(id_fields)

        assert opaque_id_count == expected["opaque_id_present"], (
            f"Expected opaque_id_present={expected['opaque_id_present']}, "
            f"got {opaque_id_count}. Row keys: {list(unavailable_row.keys())}"
        )
    else:
        raise ValueError(f"Unknown case: {case}")
