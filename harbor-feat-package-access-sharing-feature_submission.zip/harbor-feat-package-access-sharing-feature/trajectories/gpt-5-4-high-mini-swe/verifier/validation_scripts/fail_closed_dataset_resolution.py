"""Story: fail_closed_dataset_resolution

Tests that dataset resolution fails closed when tasks are unavailable or dataset is empty.
"""

import sys
import os
import tempfile
from unittest.mock import AsyncMock, MagicMock
from pathlib import Path

sys.path.insert(0, "/repo/harbor/src")


def test_fail_closed_dataset_resolution(inputs, expected):
    import pytest
    from typer.testing import CliRunner
    from harbor.cli.main import app
    from harbor.cli.datasets import datasets_app

    runner = CliRunner()
    env = {"COLUMNS": "1000", "TERM": "dumb"}

    case = expected["case"]
    unavailable_count = inputs["unavailable_count"]

    if case == "run_aborts_on_unavailable_tasks":
        with tempfile.TemporaryDirectory() as tmpdir:
            jobs_dir = Path(tmpdir) / "jobs"

            with pytest.MonkeyPatch.context() as mp:
                # Mock PackageDatasetClient
                fake_client = MagicMock()
                error = PermissionError(
                    f"Dataset acme/benchmark@latest references {unavailable_count} task(s) that are out of reach for the current user."
                )
                fake_client.get_dataset_metadata = AsyncMock(side_effect=error)
                mp.setattr(
                    "harbor.registry.client.package.PackageDatasetClient",
                    MagicMock(return_value=fake_client),
                )

                # Neutralize unrelated preflights
                mp.setattr(
                    "harbor.environments.factory.EnvironmentFactory.run_preflight",
                    lambda **_: None,
                )
                mp.setattr(
                    "harbor.cli.jobs.show_registry_hint_if_first_run",
                    lambda _: None,
                )
                run_job = AsyncMock()
                mp.setattr("harbor.job.Job.run", run_job)

                result = runner.invoke(
                    app,
                    [
                        "run",
                        "--dataset", "acme/benchmark",
                        "--jobs-dir", str(jobs_dir),
                        "--yes",
                    ],
                    env=env,
                )

            # EXPECTED: non-zero exit
            assert result.exit_code == expected["exit_code"], (
                f"Expected exit_code={expected['exit_code']}, got {result.exit_code}. "
                f"stdout: {result.stdout}"
            )

            # EXPECTED: unavailable count in stdout
            assert str(unavailable_count) in result.stdout, (
                f"Expected '{unavailable_count}' in stdout. stdout: {result.stdout}"
            )

            # EXPECTED: job never ran
            assert run_job.await_count == expected["job_run_await_count"], (
                f"Expected run_job.await_count={expected['job_run_await_count']}, "
                f"got {run_job.await_count}"
            )

            # EXPECTED: jobs dir does not exist
            jobs_exist = os.path.exists(str(jobs_dir))
            leftover_count = 1 if jobs_exist else 0
            assert leftover_count == expected["leftover_dir_count"], (
                f"Expected leftover_dir_count={expected['leftover_dir_count']}, "
                f"jobs_dir exists: {jobs_exist}"
            )

    elif case == "download_aborts_on_unavailable_tasks":
        with tempfile.TemporaryDirectory() as tmpdir:
            output_dir = Path(tmpdir) / "out"

            with pytest.MonkeyPatch.context() as mp:
                # Mock PackageDatasetClient
                fake_client = MagicMock()
                error = PermissionError(
                    f"Dataset acme/benchmark@latest references {unavailable_count} task(s) that are out of reach for the current user."
                )
                fake_client.download_dataset = AsyncMock(side_effect=error)
                fake_client.get_dataset_metadata = AsyncMock(side_effect=error)
                mp.setattr(
                    "harbor.registry.client.package.PackageDatasetClient",
                    MagicMock(return_value=fake_client),
                )

                result = runner.invoke(
                    datasets_app,
                    [
                        "download", "acme/benchmark",
                        "--output-dir", str(output_dir),
                        "--export",
                    ],
                    env=env,
                )

            # EXPECTED: non-zero exit
            assert result.exit_code == expected["exit_code"], (
                f"Expected exit_code={expected['exit_code']}, got {result.exit_code}. "
                f"stdout: {result.stdout}"
            )

            # EXPECTED: unavailable count in stdout
            assert str(unavailable_count) in result.stdout, (
                f"Expected '{unavailable_count}' in stdout. stdout: {result.stdout}"
            )

            # expected["job_run_await_count"] == "__skip__" for this case - skip

            # EXPECTED: output dir empty/absent
            if output_dir.exists():
                leftover_files = list(output_dir.rglob("*"))
                leftover_count = len(leftover_files)
            else:
                leftover_count = 0
            assert leftover_count == expected["leftover_dir_count"], (
                f"Expected leftover_dir_count={expected['leftover_dir_count']}, "
                f"got {leftover_count}"
            )

    elif case == "run_aborts_on_empty_dataset":
        with tempfile.TemporaryDirectory() as tmpdir:
            jobs_dir2 = Path(tmpdir) / "jobs2"

            with pytest.MonkeyPatch.context() as mp:
                # Mock PackageDatasetClient with empty dataset error
                fake_client = MagicMock()
                error = ValueError("Dataset acme/benchmark@latest resolves to no tasks.")
                fake_client.get_dataset_metadata = AsyncMock(side_effect=error)
                mp.setattr(
                    "harbor.registry.client.package.PackageDatasetClient",
                    MagicMock(return_value=fake_client),
                )

                # Neutralize unrelated preflights
                mp.setattr(
                    "harbor.environments.factory.EnvironmentFactory.run_preflight",
                    lambda **_: None,
                )
                mp.setattr(
                    "harbor.cli.jobs.show_registry_hint_if_first_run",
                    lambda _: None,
                )
                run_job = AsyncMock()
                mp.setattr("harbor.job.Job.run", run_job)

                result = runner.invoke(
                    app,
                    [
                        "run",
                        "--dataset", "acme/benchmark",
                        "--jobs-dir", str(jobs_dir2),
                        "--yes",
                    ],
                    env=env,
                )

            # EXPECTED: non-zero exit
            assert result.exit_code == expected["exit_code"], (
                f"Expected exit_code={expected['exit_code']}, got {result.exit_code}. "
                f"stdout: {result.stdout}"
            )

            # EXPECTED: unavailable count assertion is __skip__-gated
            if unavailable_count != "__skip__":
                assert str(unavailable_count) in result.stdout, (
                    f"Expected '{unavailable_count}' in stdout. stdout: {result.stdout}"
                )

            # EXPECTED: job never ran
            assert run_job.await_count == expected["job_run_await_count"], (
                f"Expected run_job.await_count={expected['job_run_await_count']}, "
                f"got {run_job.await_count}"
            )

            # EXPECTED: jobs dir does not exist
            jobs_exist = os.path.exists(str(jobs_dir2))
            leftover_count = 1 if jobs_exist else 0
            assert leftover_count == expected["leftover_dir_count"], (
                f"Expected leftover_dir_count={expected['leftover_dir_count']}, "
                f"jobs2 dir exists: {jobs_exist}"
            )
    else:
        raise ValueError(f"Unknown case: {case}")
