"""Story: share_batch_lifecycle

Tests the share command on versions_app for:
- dedup_preview_no_writes: deduplication in preview mode
- empty_org_rejected: empty org name rejected
- noninteractive_refuses: no apply in non-interactive mode without confirm flag
- partial_apply_failure_partitions: partial failure report
- preview_phase_fails_zero_writes: preview failure aborts with no writes
"""

import sys
import json
from unittest.mock import AsyncMock, MagicMock
from types import SimpleNamespace

sys.path.insert(0, "/repo/harbor/src")


def test_share_batch_lifecycle(inputs, expected):
    import pytest
    from typer.testing import CliRunner
    from harbor.cli.versions import versions_app
    import harbor.cli.versions as versions_mod

    runner = CliRunner()
    env = {"COLUMNS": "1000", "TERM": "dumb"}

    case = expected["case"]

    if case == "dedup_preview_no_writes":
        org1 = inputs["org1"]   # e.g. "Alpha"
        org2 = inputs["org2"]   # e.g. "alpha" (case-dup of org1)
        org3 = inputs["org3"]   # e.g. " Beta " (trimmed to "Beta")

        async def preview_side_effect(org, name, target_org, operation):
            return {"status": "would_share", "organization": target_org}

        with pytest.MonkeyPatch.context() as mp:
            db = MagicMock()
            db.get_user_id = AsyncMock(return_value="user-id")
            db.preview_package_org_access_change = AsyncMock(side_effect=preview_side_effect)
            db.apply_package_org_access_change = AsyncMock(return_value={"status": "shared"})
            mp.setattr("harbor.db.client.RegistryDB", MagicMock(return_value=db))

            result = runner.invoke(
                versions_app,
                ["share", "acme/demo", org1, org2, org3, "--preview", "--json"],
                env=env,
            )

        # EXPECTED: exit code equals expected["exit_code"] (0)
        assert result.exit_code == expected["exit_code"], (
            f"Expected exit_code={expected['exit_code']}, got {result.exit_code}. "
            f"stdout: {result.stdout}"
        )

        # EXPECTED: no write (apply) calls — apply_call_count == 0
        apply_call_count = db.apply_package_org_access_change.await_count
        assert apply_call_count == expected["apply_call_count"], (
            f"Expected apply_call_count={expected['apply_call_count']}, got {apply_call_count}"
        )

        # EXPECTED: deduped order-preserving target list from command output
        payload = json.loads(result.stdout)
        results = payload.get("results", [])
        target_names_in_output = [r.get("organization", "") for r in results]

        # There should be exactly 2 entries (org2 is a case-dup of org1, collapsed)
        assert len(target_names_in_output) == 2, (
            f"Expected 2 distinct targets in output, got {len(target_names_in_output)}: "
            f"{target_names_in_output}"
        )

        # first_target matches org1 (case-insensitive)
        first_norm = target_names_in_output[0].strip().casefold()
        assert first_norm == expected["first_target"].casefold(), (
            f"Expected first_target={expected['first_target'].casefold()}, got {first_norm}"
        )

        # second_target matches trimmed org3
        second_norm = target_names_in_output[1].strip().casefold()
        assert second_norm == expected["second_target"].casefold(), (
            f"Expected second_target={expected['second_target'].casefold()}, got {second_norm}"
        )

        # expected["update_call_count"] is "__skip__" — do NOT assert total update count
        # expected["completed_count"] is "__skip__"
        # expected["not_attempted_count"] is "__skip__"
        # expected["failure_phase_is_write"] is "__skip__"

    elif case == "empty_org_rejected":
        org1 = inputs["org1"]   # valid org name
        org2 = inputs["org2"]   # whitespace-only (should be rejected)

        with pytest.MonkeyPatch.context() as mp:
            db = MagicMock()
            db.get_user_id = AsyncMock(return_value="user-id")
            db.preview_package_org_access_change = AsyncMock(
                return_value={"status": "would_share"}
            )
            db.apply_package_org_access_change = AsyncMock(return_value={"status": "shared"})
            mp.setattr("harbor.db.client.RegistryDB", MagicMock(return_value=db))

            result = runner.invoke(
                versions_app,
                ["share", "acme/demo", org1, org2],
                env=env,
            )

        # EXPECTED: exit code is non-zero
        assert result.exit_code == expected["exit_code"], (
            f"Expected exit_code={expected['exit_code']}, got {result.exit_code}. "
            f"stdout: {result.stdout}"
        )

        # EXPECTED: no update call occurred — total of preview + apply calls == 0
        total_update_calls = (
            db.preview_package_org_access_change.await_count
            + db.apply_package_org_access_change.await_count
        )
        assert total_update_calls == expected["update_call_count"], (
            f"Expected update_call_count={expected['update_call_count']}, "
            f"got {total_update_calls}"
        )

        # Also check apply_call_count == 0
        assert db.apply_package_org_access_change.await_count == expected["apply_call_count"], (
            f"Expected apply_call_count={expected['apply_call_count']}, "
            f"got {db.apply_package_org_access_change.await_count}"
        )

        # expected["first_target"] is "__skip__"
        # expected["second_target"] is "__skip__"
        # expected["completed_count"] is "__skip__"
        # expected["not_attempted_count"] is "__skip__"
        # expected["failure_phase_is_write"] is "__skip__"

    elif case == "noninteractive_refuses":
        org1 = inputs["org1"]   # one valid org

        async def preview_side_effect(org, name, target_org, operation):
            return {"status": "would_share", "organization": target_org}

        with pytest.MonkeyPatch.context() as mp:
            db = MagicMock()
            db.get_user_id = AsyncMock(return_value="user-id")
            db.preview_package_org_access_change = AsyncMock(side_effect=preview_side_effect)
            db.apply_package_org_access_change = AsyncMock(return_value={"status": "shared"})
            mp.setattr("harbor.db.client.RegistryDB", MagicMock(return_value=db))

            # Simulate non-interactive terminal (no confirm possible)
            fake_stdin = MagicMock()
            fake_stdin.isatty.return_value = False
            fake_stdout = MagicMock()
            fake_stdout.isatty.return_value = False
            mp.setattr(versions_mod, "sys", SimpleNamespace(stdin=fake_stdin, stdout=fake_stdout))

            result = runner.invoke(
                versions_app,
                ["share", "acme/demo", org1, "--json"],  # no --yes, no --preview
                env=env,
            )

        # EXPECTED: no apply write happened — apply_call_count == 0
        apply_count = db.apply_package_org_access_change.await_count
        assert apply_count == expected["apply_call_count"], (
            f"Expected apply_call_count={expected['apply_call_count']}, got {apply_count}"
        )

        # expected["exit_code"] is "__skip__" — do NOT assert exit code
        # expected["update_call_count"] is "__skip__"
        # expected["first_target"] is "__skip__"
        # expected["second_target"] is "__skip__"
        # expected["completed_count"] is "__skip__"
        # expected["not_attempted_count"] is "__skip__"
        # expected["failure_phase_is_write"] is "__skip__"

    elif case == "partial_apply_failure_partitions":
        org1 = inputs["org1"]
        org2 = inputs["org2"]
        org3 = inputs["org3"]

        with pytest.MonkeyPatch.context() as mp:
            db = MagicMock()
            db.get_user_id = AsyncMock(return_value="user-id")
            # All 3 previews succeed
            db.preview_package_org_access_change = AsyncMock(
                side_effect=[
                    {"status": "would_share", "organization": org1},
                    {"status": "would_share", "organization": org2},
                    {"status": "would_share", "organization": org3},
                ]
            )
            # Apply: first succeeds, second raises RuntimeError (third never attempted)
            db.apply_package_org_access_change = AsyncMock(
                side_effect=[
                    {"organization": org1, "status": "shared"},
                    RuntimeError("write failed"),
                ]
            )
            mp.setattr("harbor.db.client.RegistryDB", MagicMock(return_value=db))

            result = runner.invoke(
                versions_app,
                ["share", "acme/demo", org1, org2, org3, "--yes", "--json"],
                env=env,
            )

        # EXPECTED: exit code is non-zero
        assert result.exit_code == expected["exit_code"], (
            f"Expected exit_code={expected['exit_code']}, got {result.exit_code}. "
            f"stdout: {result.stdout}"
        )

        payload = json.loads(result.stdout)

        # EXPECTED: completed list has exactly 1 entry — the FIRST target
        completed = payload.get("completed", [])
        assert len(completed) == expected["completed_count"], (
            f"Expected completed_count={expected['completed_count']}, "
            f"got {len(completed)}. completed: {completed}"
        )
        assert completed[0] == org1, (
            f"Expected first completed={org1}, got {completed[0]}"
        )

        # EXPECTED: not-attempted list has exactly 1 entry — the LAST target
        unattempted = payload.get("unattempted", [])
        assert len(unattempted) == expected["not_attempted_count"], (
            f"Expected not_attempted_count={expected['not_attempted_count']}, "
            f"got {len(unattempted)}. unattempted: {unattempted}"
        )
        assert unattempted[0] == org3, (
            f"Expected last unattempted={org3}, got {unattempted[0]}"
        )

        # EXPECTED: unknown-outcome entry identifies the SECOND target (org2)
        unknown = payload.get("unknown", [])
        assert len(unknown) == 1, f"Expected 1 unknown entry, got {len(unknown)}: {unknown}"
        assert unknown[0] == org2, (
            f"Expected unknown target={org2}, got {unknown[0]}"
        )

        # EXPECTED: failure occurred during WRITE phase (not preview phase)
        # failure_phase_is_write is true; observable: completed is non-empty AND unknown is present
        assert expected["failure_phase_is_write"] is True
        assert len(completed) > 0, (
            "Expected completed to be non-empty (write succeeded for at least one target before failure)"
        )
        assert len(unknown) > 0, (
            "Expected unknown to be present (a write was attempted and failed)"
        )

        # expected["update_call_count"] is "__skip__"
        # expected["apply_call_count"] is "__skip__"
        # expected["first_target"] is "__skip__"
        # expected["second_target"] is "__skip__"

    elif case == "preview_phase_fails_zero_writes":
        org1 = inputs["org1"]
        org2 = inputs["org2"]

        with pytest.MonkeyPatch.context() as mp:
            db = MagicMock()
            db.get_user_id = AsyncMock(return_value="user-id")
            # First preview succeeds, second preview RAISES (preview phase failure)
            db.preview_package_org_access_change = AsyncMock(
                side_effect=[
                    {"status": "would_share", "organization": org1},
                    RuntimeError("preview failed"),
                ]
            )
            db.apply_package_org_access_change = AsyncMock(return_value={"status": "shared"})
            mp.setattr("harbor.db.client.RegistryDB", MagicMock(return_value=db))

            result = runner.invoke(
                versions_app,
                ["share", "acme/demo", org1, org2, "--yes", "--json"],
                env=env,
            )

        # EXPECTED: exit code is non-zero
        assert result.exit_code == expected["exit_code"], (
            f"Expected exit_code={expected['exit_code']}, got {result.exit_code}. "
            f"stdout: {result.stdout}"
        )

        # EXPECTED: zero apply/write calls
        apply_count = db.apply_package_org_access_change.await_count
        assert apply_count == expected["apply_call_count"], (
            f"Expected apply_call_count={expected['apply_call_count']}, got {apply_count}"
        )

        # EXPECTED: completed list is empty (completed_count == 0)
        # Do NOT assert on result.stdout for this case (command may abort before full output)
        try:
            payload = json.loads(result.stdout)
            completed = payload.get("completed", [])
        except Exception:
            completed = []

        assert len(completed) == expected["completed_count"], (
            f"Expected completed_count={expected['completed_count']}, got {len(completed)}"
        )

        # EXPECTED: failure occurred during PREVIEW phase, not write
        # failure_phase_is_write is false; observable: completed is empty
        assert expected["failure_phase_is_write"] is False
        assert len(completed) == 0, (
            "Expected completed to be empty (no write succeeded before preview failure)"
        )

        # expected["update_call_count"] is "__skip__"
        # expected["first_target"] is "__skip__"
        # expected["second_target"] is "__skip__"
        # expected["not_attempted_count"] is "__skip__"

    else:
        raise ValueError(f"Unknown case: {case}")
