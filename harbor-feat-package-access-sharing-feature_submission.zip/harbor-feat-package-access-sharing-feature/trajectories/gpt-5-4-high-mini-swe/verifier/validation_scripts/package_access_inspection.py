"""Story: package_access_inspection

Tests the 'access' command on versions_app for:
- manager_view: manager sees provenance fields
- non_manager_redaction: non-manager sees provenance omitted
- empty_grants_dropped: empty grant list omitted from JSON
- malformed_reference_rejected: bad ref rejected before backend call
- defunct_nested_operation: bogus token rejected
- inaccessible_is_conflated: access denied without revealing existence
"""

import sys
import json
from unittest.mock import AsyncMock, MagicMock

sys.path.insert(0, "/repo/harbor/src")


def test_package_access_inspection(inputs, expected):
    import pytest
    from typer.testing import CliRunner
    from harbor.cli.versions import versions_app

    runner = CliRunner()
    env = {"COLUMNS": "1000", "TERM": "dumb"}

    case = expected["case"]

    # Setup DB mock helper
    def make_db(mp, **methods):
        db = MagicMock()
        for name, value in methods.items():
            if isinstance(value, Exception):
                setattr(db, name, AsyncMock(side_effect=value))
            elif value is None:
                setattr(db, name, AsyncMock(return_value=None))
            else:
                setattr(db, name, AsyncMock(return_value=value))
        mp.setattr("harbor.db.client.RegistryDB", MagicMock(return_value=db))
        return db

    if case == "manager_view":
        # Mock get_package_access returning a manager view with provenance fields
        access_payload = {
            "package": "acme/demo",
            "type": "task",
            "visibility": "private",
            "viewer_can_manage": True,
            "grants": [
                {
                    "organization": "research",
                    "granted_at": "2026-07-20T13:00:00Z",
                    "granted_by": "alice",
                }
            ],
        }

        with pytest.MonkeyPatch.context() as mp:
            db = make_db(
                mp,
                get_user_id="user-id",
                get_package_access=access_payload,
            )
            result = runner.invoke(
                versions_app, ["access", "acme/demo", "--json"], env=env
            )

        assert result.exit_code == expected["exit_code"], (
            f"Expected exit_code={expected['exit_code']}, got {result.exit_code}. "
            f"Output: {result.stdout}"
        )
        payload = json.loads(result.stdout)

        # Check manager_can_manage truthiness
        assert bool(payload.get("viewer_can_manage")) == expected["manager_can_manage"], (
            f"Expected viewer_can_manage={expected['manager_can_manage']}, "
            f"got {payload.get('viewer_can_manage')}"
        )

        # Check provenance fields - manager should see grants with provenance details
        # (granted_by, granted_at are provenance fields)
        grants = payload.get("grants", [])
        provenance_keys = {"granted_by", "granted_at"}
        provenance_count = sum(
            1 for g in grants for k in g if k in provenance_keys
        )
        # Manager view should have >= manager_provenance_fields_present provenance fields
        assert provenance_count >= expected["manager_provenance_fields_present"], (
            f"Expected at least {expected['manager_provenance_fields_present']} provenance fields, "
            f"got {provenance_count}. Grants: {grants}"
        )

    elif case == "non_manager_redaction":
        # Mock get_package_access returning a non-manager view
        # Non-manager: viewer_can_manage=False, grants present but no provenance
        access_payload_non_manager = {
            "package": "acme/demo",
            "type": "dataset",
            "visibility": "private",
            "viewer_can_manage": False,
            "grants": [
                {
                    "organization": "research",
                    "granted_at": "2026-07-20T13:00:00Z",
                    "granted_by": "alice",
                }
            ],
        }

        with pytest.MonkeyPatch.context() as mp:
            db = make_db(
                mp,
                get_user_id="user-id",
                get_package_access=access_payload_non_manager,
            )
            result = runner.invoke(
                versions_app, ["access", "acme/demo", "--json"], env=env
            )

        assert result.exit_code == expected["exit_code"], (
            f"Expected exit_code={expected['exit_code']}, got {result.exit_code}. "
            f"Output: {result.stdout}"
        )
        payload = json.loads(result.stdout)

        # manage indicator is false
        assert bool(payload.get("viewer_can_manage")) == expected["manager_can_manage"], (
            f"Expected viewer_can_manage={expected['manager_can_manage']}, "
            f"got {payload.get('viewer_can_manage')}"
        )

        # Provenance fields should NOT be present in non-manager view
        provenance_keys = {"granted_by", "granted_at"}
        grants = payload.get("grants", [])
        provenance_count = sum(
            1 for g in grants for k in g if k in provenance_keys
        )
        assert provenance_count == expected["manager_provenance_fields_present"], (
            f"Expected {expected['manager_provenance_fields_present']} provenance fields in non-manager view, "
            f"got {provenance_count}. Grants: {grants}"
        )

    elif case == "empty_grants_dropped":
        # Mock returns empty grants
        access_payload_empty = {
            "package": "acme/demo",
            "type": "task",
            "visibility": "private",
            "viewer_can_manage": False,
            "grants": [],
        }

        with pytest.MonkeyPatch.context() as mp:
            db = make_db(
                mp,
                get_user_id="user-id",
                get_package_access=access_payload_empty,
            )
            result = runner.invoke(
                versions_app, ["access", "acme/demo", "--json"], env=env
            )

        assert result.exit_code == expected["exit_code"], (
            f"Expected exit_code={expected['exit_code']}, got {result.exit_code}. "
            f"Output: {result.stdout}"
        )
        payload = json.loads(result.stdout)

        # Count empty-collection keys present (grants should NOT be in payload)
        empty_key_count = sum(
            1 for k, v in payload.items()
            if isinstance(v, list) and len(v) == 0
        )
        assert empty_key_count == expected["empty_grant_keys_present"], (
            f"Expected {expected['empty_grant_keys_present']} empty collection keys, "
            f"got {empty_key_count}. Payload keys: {list(payload.keys())}"
        )

    elif case == "malformed_reference_rejected":
        bad_ref = inputs["bad_reference"]

        with pytest.MonkeyPatch.context() as mp:
            db = make_db(
                mp,
                get_user_id="user-id",
                get_package_access={
                    "package": "acme/demo",
                    "type": "task",
                    "visibility": "private",
                    "viewer_can_manage": True,
                    "grants": [],
                },
            )
            result = runner.invoke(
                versions_app, ["access", bad_ref, "--json"], env=env
            )

        # EXPECTED: exit_code is non-zero (spec says assert != 0)
        assert result.exit_code != 0, (
            f"Expected non-zero exit for bad reference '{bad_ref}', got {result.exit_code}. "
            f"Output: {result.stdout}"
        )

        # EXPECTED: get_package_access was awaited 0 times
        assert db.get_package_access.await_count == expected["read_await_count"], (
            f"Expected get_package_access.await_count={expected['read_await_count']}, "
            f"got {db.get_package_access.await_count}"
        )

    elif case == "defunct_nested_operation":
        nested_token = inputs["nested_token"]

        with pytest.MonkeyPatch.context() as mp:
            db = make_db(
                mp,
                get_user_id="user-id",
                get_package_access={
                    "package": "acme/demo",
                    "type": "task",
                    "visibility": "private",
                    "viewer_can_manage": True,
                    "grants": [],
                },
            )
            result = runner.invoke(
                versions_app, ["access", nested_token, "acme/demo"], env=env
            )

        # EXPECTED: exit_code is non-zero (spec says assert != 0)
        assert result.exit_code != 0, (
            f"Expected non-zero exit for bogus token '{nested_token}', got {result.exit_code}. "
            f"Output: {result.stdout}"
        )

        # EXPECTED: get_package_access was awaited 0 times
        assert db.get_package_access.await_count == expected["read_await_count"], (
            f"Expected get_package_access.await_count={expected['read_await_count']}, "
            f"got {db.get_package_access.await_count}"
        )

    elif case == "inaccessible_is_conflated":
        try:
            from postgrest.exceptions import APIError
            error = APIError({"message": "Package not found or permission denied", "code": "P0001"})
        except Exception:
            # Fallback: PermissionError
            error = PermissionError("Package not found or permission denied")

        with pytest.MonkeyPatch.context() as mp:
            db = MagicMock()
            db.get_user_id = AsyncMock(return_value="user-id")
            db.get_package_access = AsyncMock(side_effect=error)
            mp.setattr("harbor.db.client.RegistryDB", MagicMock(return_value=db))

            result = runner.invoke(
                versions_app, ["access", "acme/demo", "--json"], env=env
            )

        # EXPECTED: exit_code equals expected["exit_code"] (non-zero)
        assert result.exit_code == expected["exit_code"], (
            f"Expected exit_code={expected['exit_code']}, got {result.exit_code}. "
            f"Output: {result.stdout}"
        )

        # EXPECTED: no existence-distinguishing keys in the denial payload
        # Try to parse as JSON first; if not JSON, use empty dict
        try:
            payload = json.loads(result.stdout)
        except Exception:
            payload = {}

        existence_keys = {"exists", "found", "status", "code", "reason", "error_code"}
        discriminating_count = sum(
            1 for k in payload.keys()
            if k.lower() in existence_keys
        )
        assert discriminating_count == expected["denial_payload_key_count"], (
            f"Expected {expected['denial_payload_key_count']} existence-discriminating keys, "
            f"got {discriminating_count}. Payload: {payload}"
        )
    else:
        raise ValueError(f"Unknown case: {case}")
