"""Story: access_mutation_confirmation

Tests confirmation/TTY gating for share and unshare commands.

Cases:
- non_tty_without_confirm_previews_then_stops: non-interactive session previews then stops
- confirm_flag_applies: --yes flag bypasses prompt and applies the change
- preview_never_prompts: --preview mode never prompts even in interactive session
"""

import sys
import json
from unittest.mock import AsyncMock, MagicMock
from types import SimpleNamespace

sys.path.insert(0, "/repo/harbor/src")


def test_access_mutation_confirmation(inputs, expected):
    import pytest
    from typer.testing import CliRunner
    from harbor.cli.versions import versions_app
    import harbor.cli.versions as versions_mod

    runner = CliRunner()
    env = {"COLUMNS": "1000", "TERM": "dumb"}

    case = expected["case"]
    action = inputs["action"]          # "share" or "unshare"
    isatty_val = inputs["isatty"]      # True or False

    if case == "non_tty_without_confirm_previews_then_stops":
        # Non-interactive terminal, no --yes flag: command should preview then stop (no apply)
        with pytest.MonkeyPatch.context() as mp:
            db = MagicMock()
            db.get_user_id = AsyncMock(return_value="user-id")
            db.preview_package_org_access_change = AsyncMock(
                return_value={"status": "would_share", "organization": "member-org"}
            )
            db.apply_package_org_access_change = AsyncMock(
                return_value={"status": "shared", "organization": "member-org"}
            )
            mp.setattr("harbor.db.client.RegistryDB", MagicMock(return_value=db))

            # Simulate non-interactive terminal (isatty returns False)
            fake_stdin = MagicMock()
            fake_stdin.isatty.return_value = isatty_val   # False
            fake_stdout = MagicMock()
            fake_stdout.isatty.return_value = isatty_val  # False
            mp.setattr(versions_mod, "sys", SimpleNamespace(stdin=fake_stdin, stdout=fake_stdout))

            confirm_mock = MagicMock(return_value=True)
            mp.setattr(versions_mod.typer, "confirm", confirm_mock)

            result = runner.invoke(
                versions_app,
                [action, "acme/demo", "member-org"],  # no --yes, no --preview
                env=env,
            )

        # EXPECTED: confirm was NEVER called (non-TTY is never prompted)
        assert confirm_mock.call_count == expected["confirm_call_count"], (
            f"Expected confirm_call_count={expected['confirm_call_count']}, "
            f"got {confirm_mock.call_count}"
        )

        # EXPECTED: no apply write happened
        apply_count = db.apply_package_org_access_change.await_count
        assert apply_count == expected["apply_call_count"], (
            f"Expected apply_call_count={expected['apply_call_count']}, got {apply_count}"
        )

        # expected["exit_code"] is "__skip__" — do NOT assert exit code
        # expected["preview_call_count"] is "__skip__" — do NOT assert preview count

    elif case == "confirm_flag_applies":
        # Non-interactive terminal WITH --yes flag: apply should happen, confirm never called
        with pytest.MonkeyPatch.context() as mp:
            db = MagicMock()
            db.get_user_id = AsyncMock(return_value="user-id")
            db.preview_package_org_access_change = AsyncMock(
                return_value={"status": "would_share", "organization": "member-org"}
            )
            db.apply_package_org_access_change = AsyncMock(
                return_value={"status": "shared", "organization": "member-org"}
            )
            mp.setattr("harbor.db.client.RegistryDB", MagicMock(return_value=db))

            # Non-interactive terminal
            fake_stdin = MagicMock()
            fake_stdin.isatty.return_value = isatty_val   # False
            fake_stdout = MagicMock()
            fake_stdout.isatty.return_value = isatty_val  # False
            mp.setattr(versions_mod, "sys", SimpleNamespace(stdin=fake_stdin, stdout=fake_stdout))

            confirm_mock = MagicMock(return_value=True)
            mp.setattr(versions_mod.typer, "confirm", confirm_mock)

            result = runner.invoke(
                versions_app,
                [action, "acme/demo", "member-org", "--yes"],  # explicit --yes flag
                env=env,
            )

        # EXPECTED: exit code 0
        assert result.exit_code == expected["exit_code"], (
            f"Expected exit_code={expected['exit_code']}, got {result.exit_code}. "
            f"stdout: {result.stdout}"
        )

        # EXPECTED: confirm was NEVER called (--yes bypasses prompt entirely)
        assert confirm_mock.call_count == expected["confirm_call_count"], (
            f"Expected confirm_call_count={expected['confirm_call_count']}, "
            f"got {confirm_mock.call_count}"
        )

        # EXPECTED: an apply happened (1 apply call)
        apply_count = db.apply_package_org_access_change.await_count
        assert apply_count == expected["apply_call_count"], (
            f"Expected apply_call_count={expected['apply_call_count']}, got {apply_count}"
        )

        # expected["preview_call_count"] is "__skip__" — do NOT assert preview count

    elif case == "preview_never_prompts":
        # Interactive terminal WITH --preview flag: no prompt, no apply
        with pytest.MonkeyPatch.context() as mp:
            db = MagicMock()
            db.get_user_id = AsyncMock(return_value="user-id")
            db.preview_package_org_access_change = AsyncMock(
                return_value={"status": "would_share", "organization": "outside-org"}
            )
            db.apply_package_org_access_change = AsyncMock(
                return_value={"status": "shared", "organization": "outside-org"}
            )
            mp.setattr("harbor.db.client.RegistryDB", MagicMock(return_value=db))

            # Interactive terminal (isatty returns True — a prompt WOULD otherwise fire)
            fake_stdin = MagicMock()
            fake_stdin.isatty.return_value = isatty_val   # True
            fake_stdout = MagicMock()
            fake_stdout.isatty.return_value = isatty_val  # True
            mp.setattr(versions_mod, "sys", SimpleNamespace(stdin=fake_stdin, stdout=fake_stdout))

            confirm_mock = MagicMock(return_value=True)
            mp.setattr(versions_mod.typer, "confirm", confirm_mock)

            result = runner.invoke(
                versions_app,
                [action, "acme/demo", "outside-org", "--preview"],  # preview mode
                env=env,
            )

        # EXPECTED: exit code 0
        assert result.exit_code == expected["exit_code"], (
            f"Expected exit_code={expected['exit_code']}, got {result.exit_code}. "
            f"stdout: {result.stdout}"
        )

        # EXPECTED: confirm was NEVER called (preview mode never prompts)
        assert confirm_mock.call_count == expected["confirm_call_count"], (
            f"Expected confirm_call_count={expected['confirm_call_count']}, "
            f"got {confirm_mock.call_count}"
        )

        # EXPECTED: no apply write happened
        apply_count = db.apply_package_org_access_change.await_count
        assert apply_count == expected["apply_call_count"], (
            f"Expected apply_call_count={expected['apply_call_count']}, got {apply_count}"
        )

        # expected["preview_call_count"] is "__skip__" — do NOT assert preview count

    else:
        raise ValueError(f"Unknown case: {case}")
