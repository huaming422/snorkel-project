"""
Validation script for fail_closed_dataset_resolution story.

Tests that downloading/running a dataset with unavailable tasks aborts with
an error, leaves no output directory, and that empty datasets are also refused.
"""
import sys
import os
from unittest.mock import AsyncMock, MagicMock, patch

sys.path.insert(0, "/repo/harbor/src")

from typer.testing import CliRunner
from harbor.cli.datasets import datasets_app
from harbor.cli.main import app as main_app
# Pre-import so patching harbor.registry.client.package.PackageDatasetClient works.
# The run launcher imports PackageDatasetClient locally inside
# DatasetConfig._get_package_task_configs via:
#   from harbor.registry.client.package import (PackageDatasetClient, ...)
# Patching the class on its source module before invocation intercepts the
# local import correctly.
import harbor.registry.client.package
from harbor.registry.client.package import DatasetEntitlementError

runner = CliRunner()


def _make_entitlement_error(ref, unavailable_count):
    """Construct a DatasetEntitlementError for given ref and count."""
    return DatasetEntitlementError(
        f"Dataset '{ref}' references {unavailable_count} task(s) you "
        "cannot access; refusing to continue."
    )


def _make_empty_dataset_error(ref):
    """Construct a DatasetEntitlementError for an empty dataset."""
    return DatasetEntitlementError(
        f"Dataset '{ref}' resolves to no accessible tasks; refusing to continue."
    )


def test_fail_closed_dataset_resolution(inputs, expected, tmp_path):
    case = expected["case"]
    unavailable_count = inputs.get("unavailable_count")

    if case == "run_aborts_on_unavailable_tasks":
        # Mock PackageDatasetClient so get_dataset_metadata raises entitlement error.
        # Patch at the source module so the local import in _get_package_task_configs
        # picks up our mock.
        client = MagicMock()
        client.get_dataset_metadata = AsyncMock(
            side_effect=_make_entitlement_error(
                "acme/benchmark@latest",
                int(unavailable_count)
            )
        )

        run_job = AsyncMock()
        jobs_dir = str(tmp_path / "jobs")

        with patch("harbor.registry.client.package.PackageDatasetClient",
                   MagicMock(return_value=client)), \
             patch("harbor.environments.factory.EnvironmentFactory.run_preflight",
                   lambda **kw: None), \
             patch("harbor.cli.jobs.show_registry_hint_if_first_run", lambda _: None), \
             patch("harbor.job.Job.run", run_job):

            result = runner.invoke(
                main_app,
                ["run", "--dataset", "acme/benchmark", "--jobs-dir", jobs_dir, "--yes"],
                env={"COLUMNS": "1000", "TERM": "dumb"},
            )

        assert result.exit_code == expected["exit_code"], (
            f"Exit {result.exit_code}, stdout={result.stdout}, "
            f"exception={result.exception}"
        )

        # The unavailable count should appear in stdout or exception message
        count_str = str(unavailable_count)
        count_in_output = (
            count_str in result.stdout or
            (result.exception is not None and count_str in str(result.exception))
        )
        assert count_in_output, (
            f"Expected count '{count_str}' in output. "
            f"stdout={result.stdout}, exception={result.exception}"
        )

        # Job.run was never awaited (error happens in Job.create before Job.run)
        assert run_job.await_count == expected["job_run_await_count"], (
            f"Expected {expected['job_run_await_count']} job runs, "
            f"got {run_job.await_count}"
        )

        # Jobs dir does NOT exist (no partial output created)
        leftover_dirs = 1 if os.path.exists(jobs_dir) else 0
        assert leftover_dirs == expected["leftover_dir_count"], (
            f"Expected {expected['leftover_dir_count']} leftover dirs, "
            f"got {leftover_dirs} (jobs_dir={'exists' if os.path.exists(jobs_dir) else 'absent'})"
        )

    elif case == "download_aborts_on_unavailable_tasks":
        # Mock PackageDatasetClient.download_dataset to raise entitlement error.
        # In the download flow, the entitlement check is done inside download_dataset
        # via get_dataset_metadata then ensure_dataset_fully_accessible.
        client = MagicMock()
        client.download_dataset = AsyncMock(
            side_effect=_make_entitlement_error(
                "acme/benchmark@latest",
                int(unavailable_count)
            )
        )
        client.get_dataset_metadata = AsyncMock(return_value=MagicMock())

        output_dir = str(tmp_path / "out")

        with patch("harbor.registry.client.package.PackageDatasetClient",
                   MagicMock(return_value=client)):
            result = runner.invoke(
                datasets_app,
                ["download", "acme/benchmark", "--output-dir", output_dir, "--export"],
                env={"COLUMNS": "1000", "TERM": "dumb"},
            )

        assert result.exit_code == expected["exit_code"], (
            f"Exit {result.exit_code}, stdout={result.stdout}, "
            f"exception={result.exception}"
        )

        # Count should appear in stdout (download catches and prints the error)
        count_str = str(unavailable_count)
        assert count_str in result.stdout, (
            f"Expected count '{count_str}' in stdout. stdout={result.stdout}"
        )

        # Output dir should be absent or empty (no files created)
        if os.path.exists(output_dir):
            files_created = sum(len(files) for _, _, files in os.walk(output_dir))
        else:
            files_created = 0
        assert files_created == expected["leftover_dir_count"], (
            f"Expected {expected['leftover_dir_count']} files, got {files_created}"
        )

    elif case == "run_aborts_on_empty_dataset":
        # Mock PackageDatasetClient so get_dataset_metadata raises empty-dataset error
        client = MagicMock()
        client.get_dataset_metadata = AsyncMock(
            side_effect=_make_empty_dataset_error("acme/benchmark@latest")
        )

        run_job = AsyncMock()
        jobs_dir = str(tmp_path / "jobs2")

        with patch("harbor.registry.client.package.PackageDatasetClient",
                   MagicMock(return_value=client)), \
             patch("harbor.environments.factory.EnvironmentFactory.run_preflight",
                   lambda **kw: None), \
             patch("harbor.cli.jobs.show_registry_hint_if_first_run", lambda _: None), \
             patch("harbor.job.Job.run", run_job):

            result = runner.invoke(
                main_app,
                ["run", "--dataset", "acme/benchmark", "--jobs-dir", jobs_dir, "--yes"],
                env={"COLUMNS": "1000", "TERM": "dumb"},
            )

        assert result.exit_code == expected["exit_code"], (
            f"Exit {result.exit_code}, stdout={result.stdout}, "
            f"exception={result.exception}"
        )

        # unavailable_count is "__skip__" for this case - skip count assertion
        if unavailable_count != "__skip__":
            count_in_output = (
                str(unavailable_count) in result.stdout or
                (result.exception is not None and str(unavailable_count) in str(result.exception))
            )
            assert count_in_output, (
                f"Expected count '{unavailable_count}' in output. "
                f"stdout={result.stdout}"
            )

        # Job.run was never awaited (error happens in Job.create before Job.run)
        assert run_job.await_count == expected["job_run_await_count"], (
            f"Expected {expected['job_run_await_count']} job runs, "
            f"got {run_job.await_count}"
        )

        # Jobs dir does NOT exist
        leftover_dirs = 1 if os.path.exists(jobs_dir) else 0
        assert leftover_dirs == expected["leftover_dir_count"], (
            f"Expected {expected['leftover_dir_count']} leftover dirs, "
            f"got {leftover_dirs}"
        )

    else:
        raise ValueError(f"Unknown case: {case}")
