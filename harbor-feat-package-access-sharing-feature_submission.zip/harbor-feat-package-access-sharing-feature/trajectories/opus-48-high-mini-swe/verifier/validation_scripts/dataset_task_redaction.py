"""
Validation script for dataset_task_redaction story.

Tests that listing dataset version tasks marks available/unavailable rows correctly,
with unavailable rows showing only an opaque identifier.
"""
import sys
import json
from unittest.mock import AsyncMock, MagicMock

sys.path.insert(0, "/repo/harbor/src")

from typer.testing import CliRunner
from harbor.cli.versions import versions_app
import harbor.db.client

runner = CliRunner()

# Task data for tests
AVAILABLE_TASK_ROW = {
    "task_version_id": "tv-available-001",
    "task_version": {
        "content_hash": "abc123def456",
        "package": {
            "name": "visible-task",
            "org": {"name": "acme"},
        },
    },
}

UNAVAILABLE_TASK_ROW = {
    "task_version_id": "tv-unavailable-002",
    "task_version": None,
}


def _make_db_mock():
    """Create a DB mock that returns a dataset version with 2 tasks."""
    db = MagicMock()
    db.get_package_version = AsyncMock(return_value=(
        # package dict
        {"type": "dataset", "visibility": "public"},
        # version dict with tasks
        {
            "id": "ver-001",
            "content_hash": "sha256:versionhash",
            "revision": 1,
            "tags": [],
            "published_at": "2024-01-01T00:00:00Z",
            "yanked_at": None,
            "yanked_reason": None,
            "description": "Test dataset",
            "tasks": [AVAILABLE_TASK_ROW, UNAVAILABLE_TASK_ROW],
        },
    ))
    db.list_package_tags = AsyncMock(return_value=[])
    return db


def test_dataset_task_redaction(inputs, expected):
    case = expected["case"]

    # Set up DB mock and invoke show command
    orig = harbor.db.client.RegistryDB
    db = _make_db_mock()
    harbor.db.client.RegistryDB = MagicMock(return_value=db)

    try:
        result = runner.invoke(
            versions_app,
            ["show", "acme/demo@latest", "--tasks", "--json"],
            env={"COLUMNS": "1000", "TERM": "dumb"},
        )
    finally:
        harbor.db.client.RegistryDB = orig

    assert result.exit_code == expected["exit_code"], (
        f"Exit {result.exit_code}, stdout={result.stdout}, "
        f"exception={result.exception}"
    )

    payload = json.loads(result.stdout)
    tasks_list = payload.get("tasks", [])

    assert len(tasks_list) >= 2, (
        f"Expected at least 2 tasks in payload, got {len(tasks_list)}. "
        f"payload keys: {list(payload.keys())}"
    )

    available_row = tasks_list[0]   # first row: available
    unavailable_row = tasks_list[1]  # second row: unavailable

    if case == "available_row_full_metadata":
        # Row availability indicator should be truthy
        avail_indicator = available_row.get("available")
        assert bool(avail_indicator) == bool(expected["available_is_available"]), (
            f"Expected available={expected['available_is_available']}, "
            f"got {avail_indicator}. row={available_row}"
        )

        # Row carries full task-version body (at least min_identifying_fields).
        # _sanitize_tasks_for_output produces:
        #   {"available": True, "task": "acme/visible-task", "content_hash": "sha256:..."}
        # Count identifying fields: "task" (org/name) and "content_hash"
        identifying_fields = sum(
            1 for k in ["task", "content_hash", "name", "org"]
            if k in available_row and available_row[k]
        )
        assert identifying_fields >= expected["available_min_identifying_fields"], (
            f"Expected >= {expected['available_min_identifying_fields']} identifying fields, "
            f"got {identifying_fields}. row={available_row}"
        )

    elif case == "unavailable_row_opaque_only":
        # Row availability indicator should be falsy
        avail_indicator = unavailable_row.get("available")
        assert bool(avail_indicator) == bool(expected["available_is_available"]), (
            f"Expected available={expected['available_is_available']}, "
            f"got {avail_indicator}. row={unavailable_row}"
        )

        # The row exposes ONLY an opaque identifier (no name/org/digest/path).
        # Collect all string values in the row.
        def collect_string_values(obj, depth=0):
            vals = []
            if isinstance(obj, str):
                vals.append(obj)
            elif isinstance(obj, dict) and depth < 5:
                for v in obj.values():
                    vals.extend(collect_string_values(v, depth + 1))
            elif isinstance(obj, list) and depth < 5:
                for item in obj:
                    vals.extend(collect_string_values(item, depth + 1))
            return vals

        string_vals = collect_string_values(unavailable_row)

        # Check for leaked identifiers (should be 0).
        # "visible-task", "acme", full sha256 hash, or path with multiple segments
        # must not appear in any string value.
        leaked_identifiers = [
            v for v in string_vals
            if "visible-task" in v
            or "acme" in v
            or ("/" in v and v.startswith("sha256:") and len(v) > 20)  # full hash path
            or ("/" in v and not v.startswith("sha256:") and len(v.split("/")) > 2)  # path
        ]
        assert len(leaked_identifiers) == expected["leaked_identifier_count"], (
            f"Expected {expected['leaked_identifier_count']} leaked identifiers, "
            f"got {len(leaked_identifiers)}: {leaked_identifiers}. "
            f"row={unavailable_row}"
        )

        # Opaque id field IS present (count of id fields = 1)
        id_fields_present = sum(1 for k in ["id"] if k in unavailable_row and unavailable_row[k])
        assert id_fields_present == expected["opaque_id_present"], (
            f"Expected {expected['opaque_id_present']} opaque id fields, "
            f"got {id_fields_present}. row={unavailable_row}"
        )

    else:
        raise ValueError(f"Unknown case: {case}")
