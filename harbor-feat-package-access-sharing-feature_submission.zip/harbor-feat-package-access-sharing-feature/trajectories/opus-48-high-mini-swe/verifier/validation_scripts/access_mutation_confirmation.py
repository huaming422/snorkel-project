"""
Validation script for access_mutation_confirmation story.

Tests confirmation gating behavior for share/unshare commands.
"""
import sys
import types
from unittest.mock import AsyncMock, MagicMock

sys.path.insert(0, "/repo/harbor/src")

from typer.testing import CliRunner
from harbor.cli.tasks import tasks_app
import harbor.db.client
import harbor.cli.package_sharing as ps_mod

runner = CliRunner()


def _make_db():
    """Create a DB mock with can_manage=True."""
    db = MagicMock()
    db.get_package_access = AsyncMock(return_value={
        "type": "task",
        "visibility": "private",
        "can_manage": True,
        "grants": [],
    })
    db.grant_package_access = AsyncMock(return_value={})
    db.revoke_package_access = AsyncMock(return_value={})
    return db


def _patch_db(db):
    """Patch RegistryDB."""
    import contextlib

    @contextlib.contextmanager
    def _ctx():
        orig = harbor.db.client.RegistryDB
        harbor.db.client.RegistryDB = MagicMock(return_value=db)
        try:
            yield
        finally:
            harbor.db.client.RegistryDB = orig
    return _ctx()


def _count_apply_calls(db):
    """Count grant_package_access calls (= write/apply calls in this implementation)."""
    return db.grant_package_access.call_count


def test_access_mutation_confirmation(inputs, expected):
    case = expected["case"]
    action = inputs.get("action", "share")  # "share" or "unshare"
    isatty_val = inputs["isatty"]

    if case == "non_tty_without_confirm_previews_then_stops":
        # Non-interactive (isatty=False), no --yes flag
        db = _make_db()
        confirm_mock = MagicMock(return_value=True)
        orig_sys = ps_mod.sys
        orig_typer_confirm = ps_mod.typer.confirm

        fake_stdin = MagicMock()
        fake_stdin.isatty.return_value = bool(isatty_val)  # False
        ps_mod.sys = types.SimpleNamespace(stdin=fake_stdin)
        ps_mod.typer.confirm = confirm_mock

        try:
            with _patch_db(db):
                result = runner.invoke(
                    tasks_app,
                    [action, "acme/demo", "--org", "member-org"],
                    env={"COLUMNS": "1000", "TERM": "dumb"},
                )
        finally:
            ps_mod.sys = orig_sys
            ps_mod.typer.confirm = orig_typer_confirm

        # confirm was never called (non-TTY is not prompted)
        assert confirm_mock.call_count == expected["confirm_call_count"], (
            f"Expected confirm call count {expected['confirm_call_count']}, "
            f"got {confirm_mock.call_count}"
        )

        # No apply write happened
        apply_calls = _count_apply_calls(db)
        assert apply_calls == expected["apply_call_count"], (
            f"Expected {expected['apply_call_count']} apply calls, got {apply_calls}"
        )
        # Do NOT assert exit code (per procedure - __skip__)

    elif case == "confirm_flag_applies":
        # Non-interactive (isatty=False) but WITH --yes flag
        # isatty=False means non-interactive terminal; --yes bypasses confirm prompt
        db = _make_db()
        confirm_mock = MagicMock(return_value=True)
        orig_sys = ps_mod.sys
        orig_typer_confirm = ps_mod.typer.confirm

        fake_stdin = MagicMock()
        fake_stdin.isatty.return_value = bool(isatty_val)  # False
        ps_mod.sys = types.SimpleNamespace(stdin=fake_stdin)
        ps_mod.typer.confirm = confirm_mock

        try:
            with _patch_db(db):
                result = runner.invoke(
                    tasks_app,
                    [action, "acme/demo", "--org", "member-org", "--yes"],
                    env={"COLUMNS": "1000", "TERM": "dumb"},
                )
        finally:
            ps_mod.sys = orig_sys
            ps_mod.typer.confirm = orig_typer_confirm

        assert result.exit_code == expected["exit_code"], (
            f"Exit {result.exit_code}, stdout={result.stdout}"
        )

        # confirm was never called (--yes bypasses prompt)
        assert confirm_mock.call_count == expected["confirm_call_count"], (
            f"Expected confirm count {expected['confirm_call_count']}, "
            f"got {confirm_mock.call_count}"
        )

        # An apply happened (grant_package_access was called exactly apply_call_count times)
        apply_calls = _count_apply_calls(db)
        assert apply_calls == expected["apply_call_count"], (
            f"Expected {expected['apply_call_count']} apply calls, got {apply_calls}"
        )
        # Do NOT assert preview_call_count (skipped per procedure)

    elif case == "preview_never_prompts":
        # Interactive (isatty=True) but --preview mode
        db = _make_db()
        confirm_mock = MagicMock(return_value=True)
        orig_sys = ps_mod.sys
        orig_typer_confirm = ps_mod.typer.confirm

        fake_stdin = MagicMock()
        fake_stdin.isatty.return_value = bool(isatty_val)  # True
        ps_mod.sys = types.SimpleNamespace(stdin=fake_stdin)
        ps_mod.typer.confirm = confirm_mock

        try:
            with _patch_db(db):
                result = runner.invoke(
                    tasks_app,
                    [action, "acme/demo", "--org", "outside-org", "--preview"],
                    env={"COLUMNS": "1000", "TERM": "dumb"},
                )
        finally:
            ps_mod.sys = orig_sys
            ps_mod.typer.confirm = orig_typer_confirm

        assert result.exit_code == expected["exit_code"], (
            f"Exit {result.exit_code}, stdout={result.stdout}"
        )

        # confirm was never called (preview mode never prompts)
        assert confirm_mock.call_count == expected["confirm_call_count"], (
            f"Expected confirm count {expected['confirm_call_count']}, "
            f"got {confirm_mock.call_count}"
        )

        # No apply write happened (grant_package_access not called)
        apply_calls = _count_apply_calls(db)
        assert apply_calls == expected["apply_call_count"], (
            f"Expected {expected['apply_call_count']} apply calls, got {apply_calls}"
        )
        # Do NOT assert preview_call_count (skipped per procedure)

    else:
        raise ValueError(f"Unknown case: {case}")
