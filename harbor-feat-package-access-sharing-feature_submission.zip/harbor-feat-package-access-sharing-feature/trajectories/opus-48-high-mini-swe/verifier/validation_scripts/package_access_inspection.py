"""
Validation script for package_access_inspection story.

Tests the inspect command on tasks_app (and datasets_app).
Discovers implementation names from the source.
"""
import sys
import json
from unittest.mock import AsyncMock, MagicMock

sys.path.insert(0, "/repo/harbor/src")

from typer.testing import CliRunner
from harbor.cli.tasks import tasks_app
import harbor.db.client

runner = CliRunner()

# Provenance field names as used in the JSON output (from reading source)
# The inspect command includes "granted_at" and "granted_by" in grant objects for managers
PROVENANCE_KEYS = {"granted_at", "granted_by"}

# Fields that would distinguish "not found" from "permission denied" (must be absent)
DISCRIMINATOR_KEYS = {"exists", "found", "status", "code", "reason", "error_type", "http_status"}


def _mock_db(access_return=None, access_side_effect=None):
    """Create a mocked DB with the access-read method set up."""
    db = MagicMock()
    if access_side_effect is not None:
        db.get_package_access = AsyncMock(side_effect=access_side_effect)
    else:
        db.get_package_access = AsyncMock(return_value=access_return)
    return db


def _invoke_inspect(db, reference="acme/demo", extra_args=None):
    """Invoke the inspect command with mocked DB."""
    orig = harbor.db.client.RegistryDB
    harbor.db.client.RegistryDB = MagicMock(return_value=db)
    try:
        args = ["inspect", reference, "--json"]
        if extra_args:
            args.extend(extra_args)
        result = runner.invoke(tasks_app, args, env={"COLUMNS": "1000", "TERM": "dumb"})
    finally:
        harbor.db.client.RegistryDB = orig
    return result


def test_package_access_inspection(inputs, expected):
    case = expected["case"]

    if case == "manager_view":
        # Manager view: can_manage=True, grants with provenance fields
        db = _mock_db({
            "type": "task",
            "visibility": "private",
            "can_manage": True,
            "grants": [
                {"org": "trusted-org", "granted_at": "2024-01-01", "granted_by": "admin-user"}
            ],
        })
        result = _invoke_inspect(db)

        assert result.exit_code == expected["exit_code"], (
            f"Exit {result.exit_code}, stdout={result.stdout}"
        )
        payload = json.loads(result.stdout)

        # Count grants that have at least one provenance field
        grants = payload.get("grants", [])
        provenance_count = sum(
            1 for grant in grants
            if any(k in grant for k in PROVENANCE_KEYS)
        )
        assert provenance_count >= expected["manager_provenance_fields_present"], (
            f"Expected >= {expected['manager_provenance_fields_present']} grants with "
            f"provenance, got {provenance_count}. payload={payload}"
        )

        assert bool(payload.get("can_manage")) == bool(expected["manager_can_manage"]), (
            f"can_manage mismatch. payload={payload}"
        )

    elif case == "non_manager_redaction":
        # Non-manager: provenance fields omitted, grants present
        db = _mock_db({
            "type": "task",
            "visibility": "private",
            "can_manage": False,
            "grants": [{"org": "trusted-org"}],  # no provenance
        })
        result = _invoke_inspect(db)

        assert result.exit_code == expected["exit_code"], (
            f"Exit {result.exit_code}, stdout={result.stdout}"
        )
        payload = json.loads(result.stdout)

        # Provenance keys should be absent from grants
        grants = payload.get("grants", [])
        provenance_count = sum(
            1 for grant in grants
            if any(k in grant for k in PROVENANCE_KEYS)
        )
        assert provenance_count == expected["manager_provenance_fields_present"], (
            f"Expected {expected['manager_provenance_fields_present']} grants with provenance "
            f"(should be 0 for non-manager), got {provenance_count}. payload={payload}"
        )

        assert bool(payload.get("can_manage")) == bool(expected["manager_can_manage"]), (
            f"can_manage mismatch. payload={payload}"
        )

    elif case == "empty_grants_dropped":
        # Non-manager with empty grants: "grants" key absent from output
        db = _mock_db({
            "type": "task",
            "visibility": "public",
            "can_manage": False,
            "grants": [],
        })
        result = _invoke_inspect(db)

        assert result.exit_code == expected["exit_code"], (
            f"Exit {result.exit_code}, stdout={result.stdout}"
        )
        payload = json.loads(result.stdout)

        # Count keys that are empty grant collections
        empty_grant_keys = sum(
            1 for k, v in payload.items()
            if "grant" in k.lower() and isinstance(v, list) and len(v) == 0
        )
        assert empty_grant_keys == expected["empty_grant_keys_present"], (
            f"Expected {expected['empty_grant_keys_present']} empty grant keys, "
            f"got {empty_grant_keys}. payload={payload}"
        )

    elif case == "malformed_reference_rejected":
        bad_ref = inputs["bad_reference"]
        db = _mock_db({
            "type": "task", "visibility": "private", "can_manage": True, "grants": []
        })

        orig = harbor.db.client.RegistryDB
        harbor.db.client.RegistryDB = MagicMock(return_value=db)
        try:
            result = runner.invoke(
                tasks_app,
                ["inspect", bad_ref],
                env={"COLUMNS": "1000", "TERM": "dumb"},
            )
        finally:
            harbor.db.client.RegistryDB = orig

        # exit code must be non-zero (SystemExit(1) from _split_package)
        assert result.exit_code != 0, (
            f"Expected non-zero exit for bad reference '{bad_ref}', got {result.exit_code}"
        )
        # Access-read method was NOT called (rejected before backend)
        assert db.get_package_access.await_count == expected["read_await_count"], (
            f"Expected {expected['read_await_count']} backend calls, "
            f"got {db.get_package_access.await_count}. ref='{bad_ref}'"
        )

    elif case == "defunct_nested_operation":
        nested_token = inputs["nested_token"]
        db = _mock_db({
            "type": "task", "visibility": "private", "can_manage": True, "grants": []
        })

        orig = harbor.db.client.RegistryDB
        harbor.db.client.RegistryDB = MagicMock(return_value=db)
        try:
            result = runner.invoke(
                tasks_app,
                ["inspect", nested_token, "acme/demo"],
                env={"COLUMNS": "1000", "TERM": "dumb"},
            )
        finally:
            harbor.db.client.RegistryDB = orig

        # exit code must be non-zero
        assert result.exit_code != 0, (
            f"Expected non-zero exit for defunct nested op '{nested_token}', "
            f"got {result.exit_code}"
        )
        assert db.get_package_access.await_count == expected["read_await_count"], (
            f"Expected {expected['read_await_count']} backend calls, "
            f"got {db.get_package_access.await_count}"
        )

    elif case == "inaccessible_is_conflated":
        # Use APIError to simulate an inaccessible package (per spec suggestion).
        # The CLI's _get_access only catches ValueError; an APIError propagates
        # as an unhandled exception, giving exit_code != 0 with no discriminating
        # JSON payload in stdout.
        from postgrest.exceptions import APIError
        db = _mock_db(
            access_side_effect=APIError(
                {"message": "Package not found or permission denied", "code": "P0001"}
            )
        )
        result = _invoke_inspect(db)

        assert result.exit_code == expected["exit_code"], (
            f"Expected exit {expected['exit_code']}, got {result.exit_code}. "
            f"stdout={result.stdout}"
        )

        # Try to parse JSON payload
        try:
            payload = json.loads(result.stdout)
            # Count discriminating keys that reveal found-vs-forbidden
            discriminating_keys = sum(
                1 for k in payload
                if k.lower() in DISCRIMINATOR_KEYS
            )
        except (json.JSONDecodeError, TypeError, ValueError):
            # No JSON output = no discriminating JSON keys
            discriminating_keys = 0

        assert discriminating_keys == expected["denial_payload_key_count"], (
            f"Expected {expected['denial_payload_key_count']} discriminating keys, "
            f"got {discriminating_keys}. stdout={result.stdout}"
        )

    else:
        raise ValueError(f"Unknown case: {case}")
