"""
Story: access_mutation_confirmation
Tests TTY/confirm gating on share/unshare commands.

From the implementation (harbor.cli.package_access):
- _should_apply: checks sys.stdin.isatty() AND sys.stdout.isatty()
  - if either False AND yes=False AND dry_run=False → preview only (return False), exit 0
  - if yes=True → apply (return True), no confirm
  - if dry_run=True → preview only (return False), no confirm
  - if both TTYs AND yes=False AND dry_run=False → call typer.confirm
- Write methods: db.grant_package_access (share) / db.revoke_package_access (unshare)
"""
import sys
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

sys.path.insert(0, "/tests/validate")

from typer.testing import CliRunner

from harbor.cli.tasks import tasks_app
import harbor.cli.package_access as package_access_mod

runner = CliRunner(env={"COLUMNS": "1000", "TERM": "dumb"})

_PACKAGE_ROW = {"id": "p", "type": "task", "visibility": "private"}


def _patch_db(monkeypatch):
    """Patch RegistryDB with basic mocks for share/unshare."""
    db = MagicMock()
    db.get_user_id = AsyncMock(return_value="user-id")
    db.get_package = AsyncMock(return_value=_PACKAGE_ROW)
    db.grant_package_access = AsyncMock(return_value={})
    db.revoke_package_access = AsyncMock(return_value={})
    monkeypatch.setattr("harbor.db.client.RegistryDB", MagicMock(return_value=db))
    return db


def _patch_isatty(monkeypatch, isatty_value: bool):
    """
    Replace the sys object in package_access module with a SimpleNamespace
    so isatty checks use our mock value.
    """
    stdin_mock = MagicMock()
    stdin_mock.isatty.return_value = isatty_value
    stdout_mock = MagicMock()
    stdout_mock.isatty.return_value = isatty_value
    fake_sys = SimpleNamespace(stdin=stdin_mock, stdout=stdout_mock)
    monkeypatch.setattr(package_access_mod, "sys", fake_sys)
    return stdin_mock, stdout_mock


def _count_apply_calls(db) -> int:
    """Count actual write calls to grant/revoke methods."""
    return db.grant_package_access.await_count + db.revoke_package_access.await_count


def test_access_mutation_confirmation(inputs, expected, monkeypatch):
    """Test confirmation/TTY gating for share/unshare commands."""
    case = expected["case"]
    action = inputs.get("action", "share")  # "share" or "unshare"
    isatty_val = bool(inputs["isatty"])

    # Patch typer.confirm in the module
    confirm_mock = MagicMock(return_value=True)
    monkeypatch.setattr(package_access_mod.typer, "confirm", confirm_mock)

    if case == "non_tty_without_confirm_previews_then_stops":
        # Non-interactive (isatty=False), no --yes flag
        db = _patch_db(monkeypatch)
        _patch_isatty(monkeypatch, isatty_value=False)

        result = runner.invoke(tasks_app, [action, "acme/demo", "--org", "member-org"])
        # confirm was never called (non-TTY session is never prompted)
        assert confirm_mock.call_count == expected["confirm_call_count"], \
            f"Expected confirm call_count={expected['confirm_call_count']}, got {confirm_mock.call_count}"
        # No apply write happened
        apply_calls = _count_apply_calls(db)
        assert apply_calls == expected["apply_call_count"], \
            f"Expected {expected['apply_call_count']} apply calls, got {apply_calls}"
        # Do NOT assert exit code per procedure

    elif case == "confirm_flag_applies":
        # Non-interactive (isatty=False), but --yes is passed
        db = _patch_db(monkeypatch)
        _patch_isatty(monkeypatch, isatty_value=False)

        result = runner.invoke(tasks_app, [action, "acme/demo", "--org", "member-org", "--yes"])
        assert result.exit_code == expected["exit_code"], \
            f"Expected exit {expected['exit_code']}, got {result.exit_code}. stdout={result.stdout}"
        # confirm was never called (--yes bypasses prompt)
        assert confirm_mock.call_count == expected["confirm_call_count"], \
            f"Expected confirm call_count={expected['confirm_call_count']}, got {confirm_mock.call_count}"
        # An apply happened
        apply_calls = _count_apply_calls(db)
        assert apply_calls == expected["apply_call_count"], \
            f"Expected {expected['apply_call_count']} apply calls, got {apply_calls}"
        # Do NOT assert preview_call_count per procedure

    elif case == "preview_never_prompts":
        # Interactive (isatty=True), but --dry-run is passed → preview mode, never prompts
        db = _patch_db(monkeypatch)
        _patch_isatty(monkeypatch, isatty_value=True)

        result = runner.invoke(tasks_app, [action, "acme/demo", "--org", "outside-org", "--dry-run"])
        assert result.exit_code == expected["exit_code"], \
            f"Expected exit {expected['exit_code']}, got {result.exit_code}. stdout={result.stdout}"
        # confirm was never called (preview mode never prompts)
        assert confirm_mock.call_count == expected["confirm_call_count"], \
            f"Expected confirm call_count={expected['confirm_call_count']}, got {confirm_mock.call_count}"
        # No apply write happened
        apply_calls = _count_apply_calls(db)
        assert apply_calls == expected["apply_call_count"], \
            f"Expected {expected['apply_call_count']} apply calls, got {apply_calls}"
        # Do NOT assert preview_call_count per procedure

    else:
        raise ValueError(f"Unknown case: {case!r}")
