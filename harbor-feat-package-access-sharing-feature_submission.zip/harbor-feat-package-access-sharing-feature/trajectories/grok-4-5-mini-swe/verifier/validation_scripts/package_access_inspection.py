"""
Story: package_access_inspection
Tests the `access` command on tasks_app and datasets_app.

The command is named `access` on both tasks_app and datasets_app.
Machine-readable flag: --json
Access read method: db.get_package_access
Provenance field: "provenance" (one key)
Manage indicator: "can_manage"
"""
import json
import sys
from postgrest.exceptions import APIError
from unittest.mock import AsyncMock, MagicMock

sys.path.insert(0, "/tests/validate")

from typer.testing import CliRunner

from harbor.cli.tasks import tasks_app
from harbor.cli.datasets import datasets_app
import harbor.cli.package_access as package_access_mod

runner = CliRunner(env={"COLUMNS": "1000", "TERM": "dumb"})


def _patch_db(monkeypatch, get_package_access_return=None, get_package_access_side_effect=None):
    """Patch RegistryDB and return the db mock."""
    db = MagicMock()
    db.get_user_id = AsyncMock(return_value="user-id")
    if get_package_access_side_effect is not None:
        db.get_package_access = AsyncMock(side_effect=get_package_access_side_effect)
    else:
        db.get_package_access = AsyncMock(return_value=get_package_access_return)
    monkeypatch.setattr("harbor.db.client.RegistryDB", MagicMock(return_value=db))
    return db


def test_package_access_inspection(inputs, expected, monkeypatch):
    """Test the access inspection command for various scenarios."""
    case = expected["case"]

    if case == "manager_view":
        # Mock: can_manage=True, provenance present, at least one grant
        db = _patch_db(monkeypatch, get_package_access_return={
            "package": "acme/demo",
            "type": "task",
            "can_manage": True,
            "grants": [{"name": "research-org"}],
            "provenance": {"owner": "acme", "created_by": "alice"},
        })
        result = runner.invoke(tasks_app, ["access", "acme/demo", "--json"])
        assert result.exit_code == expected["exit_code"], \
            f"Expected exit {expected['exit_code']}, got {result.exit_code}. stdout={result.stdout}"
        payload = json.loads(result.stdout)
        # The implementation uses "provenance" as the single provenance field.
        # Count provenance field(s) that are present and non-null.
        provenance_keys = [k for k in payload
                           if k in {"provenance", "is_public", "public_grants"}
                           and payload[k] is not None]
        assert len(provenance_keys) >= expected["manager_provenance_fields_present"], \
            f"Expected >= {expected['manager_provenance_fields_present']} provenance keys, got {len(provenance_keys)} (keys: {list(payload.keys())})"
        # Check manage-permission indicator
        assert bool(payload.get("can_manage")) == expected["manager_can_manage"], \
            f"can_manage mismatch: expected {expected['manager_can_manage']}, got {payload.get('can_manage')}"
        # empty_grant_keys_present is "__skip__" for this case - skip
        # read_await_count is "__skip__" for this case - skip
        # denial_payload_key_count is "__skip__" for this case - skip

    elif case == "non_manager_redaction":
        # Mock: can_manage=False, provenance OMITTED, grants non-empty
        db = _patch_db(monkeypatch, get_package_access_return={
            "package": "acme/demo",
            "type": "task",
            "can_manage": False,
            "grants": [{"name": "research-org"}],
            # provenance intentionally omitted from return value
        })
        result = runner.invoke(tasks_app, ["access", "acme/demo", "--json"])
        assert result.exit_code == expected["exit_code"], \
            f"Expected exit {expected['exit_code']}, got {result.exit_code}. stdout={result.stdout}"
        payload = json.loads(result.stdout)
        # None of provenance field(s) should appear in the output
        provenance_keys_present = [k for k in payload
                                    if k in {"provenance", "is_public", "public_grants"}]
        assert len(provenance_keys_present) == expected["manager_provenance_fields_present"], \
            f"Expected {expected['manager_provenance_fields_present']} provenance keys for non-manager, got {len(provenance_keys_present)} (keys: {list(payload.keys())})"
        # Check manage-permission indicator
        assert bool(payload.get("can_manage")) == expected["manager_can_manage"], \
            f"can_manage mismatch: expected {expected['manager_can_manage']}, got {payload.get('can_manage')}"
        # empty_grant_keys_present is "__skip__" for this case - skip
        # read_await_count is "__skip__" for this case - skip
        # denial_payload_key_count is "__skip__" for this case - skip

    elif case == "empty_grants_dropped":
        # Mock: non-manager view, empty grants collection
        db = _patch_db(monkeypatch, get_package_access_return={
            "package": "acme/demo",
            "type": "task",
            "can_manage": False,
            "grants": [],  # empty - should be dropped from output
        })
        result = runner.invoke(tasks_app, ["access", "acme/demo", "--json"])
        assert result.exit_code == expected["exit_code"], \
            f"Expected exit {expected['exit_code']}, got {result.exit_code}. stdout={result.stdout}"
        payload = json.loads(result.stdout)
        # Empty grant collection should NOT appear as a key
        empty_grant_keys = [
            k for k in payload
            if k in {"grants", "org_grants", "organizations"}
            and isinstance(payload[k], list)
            and len(payload[k]) == 0
        ]
        assert len(empty_grant_keys) == expected["empty_grant_keys_present"], \
            f"Expected {expected['empty_grant_keys_present']} empty grant keys, got {len(empty_grant_keys)} (keys: {list(payload.keys())})"
        # manager_provenance_fields_present is "__skip__" - skip
        # manager_can_manage is "__skip__" - skip
        # read_await_count is "__skip__" - skip
        # denial_payload_key_count is "__skip__" - skip

    elif case == "malformed_reference_rejected":
        # Invoke with malformed reference (bare name, version-qualified, etc.)
        bad_ref = inputs["bad_reference"]
        db = _patch_db(monkeypatch, get_package_access_return={})
        result = runner.invoke(tasks_app, ["access", bad_ref, "--json"])
        # Must be non-zero
        assert result.exit_code != 0, \
            f"Expected non-zero exit for bad ref {bad_ref!r}, got {result.exit_code}. stdout={result.stdout}"
        # Backend must NOT have been called
        assert db.get_package_access.await_count == expected["read_await_count"], \
            f"Expected {expected['read_await_count']} await(s), got {db.get_package_access.await_count}"
        # manager_provenance_fields_present is "__skip__" - skip
        # manager_can_manage is "__skip__" - skip
        # empty_grant_keys_present is "__skip__" - skip
        # denial_payload_key_count is "__skip__" - skip

    elif case == "defunct_nested_operation":
        # The access command takes ONE positional argument.
        # Passing [access, <token>, "acme/demo"] gives two positional args → CLI rejects with exit 2.
        nested_token = inputs["nested_token"]
        db = _patch_db(monkeypatch, get_package_access_return={})
        # Pass [access, <token>, acme/demo] - access takes exactly one positional arg
        # The CLI will reject extra positional arguments with exit code 2
        result = runner.invoke(tasks_app, ["access", nested_token, "acme/demo"])
        # Must be non-zero
        assert result.exit_code != 0, \
            f"Expected non-zero exit for defunct_nested_operation, got {result.exit_code}. stdout={result.stdout}"
        # Backend must NOT have been called
        assert db.get_package_access.await_count == expected["read_await_count"], \
            f"Expected {expected['read_await_count']} await(s), got {db.get_package_access.await_count}"
        # manager_provenance_fields_present is "__skip__" - skip
        # manager_can_manage is "__skip__" - skip
        # empty_grant_keys_present is "__skip__" - skip
        # denial_payload_key_count is "__skip__" - skip

    elif case == "inaccessible_is_conflated":
        # Use APIError as the backend signal for "not found or permission denied".
        # The registry raises a postgrest APIError for missing/forbidden packages.
        # Construct it exactly as the repo tests do.
        api_error = APIError({"message": "Package not found or permission denied", "code": "P0001"})
        db = _patch_db(monkeypatch, get_package_access_side_effect=api_error)
        result = runner.invoke(tasks_app, ["access", "acme/missing", "--json"])
        assert result.exit_code == expected["exit_code"], \
            f"Expected exit {expected['exit_code']}, got {result.exit_code}. stdout={result.stdout}"
        # The output should NOT carry fields distinguishing "missing" from "unauthorized"
        # The implementation prints an error message (plain text via _run_access_coro),
        # so there is no JSON discriminating payload to inspect.
        stdout = result.stdout
        discriminating_keys_found = 0
        try:
            payload = json.loads(stdout)
            # If JSON is returned, check for discriminating fields
            discriminating = {"exists", "found", "status", "code", "reason", "error_type", "is_missing", "is_forbidden"}
            for k in payload:
                if k.lower() in discriminating:
                    discriminating_keys_found += 1
        except (json.JSONDecodeError, ValueError):
            # Not JSON output (expected for this implementation) — no discriminating keys
            discriminating_keys_found = 0
        assert discriminating_keys_found == expected["denial_payload_key_count"], \
            f"Expected {expected['denial_payload_key_count']} discriminating keys, got {discriminating_keys_found} in: {stdout}"
        # manager_provenance_fields_present is "__skip__" - skip
        # manager_can_manage is "__skip__" - skip
        # empty_grant_keys_present is "__skip__" - skip
        # read_await_count is "__skip__" - skip

    else:
        raise ValueError(f"Unknown case: {case!r}")
