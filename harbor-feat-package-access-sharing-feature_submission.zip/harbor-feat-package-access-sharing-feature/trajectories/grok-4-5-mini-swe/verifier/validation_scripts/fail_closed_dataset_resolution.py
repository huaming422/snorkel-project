"""
Story: fail_closed_dataset_resolution
Tests that unavailable tasks / empty datasets abort download and run.

From the implementation:
- Error class: harbor.registry.client.package.DatasetTasksUnavailableError
  - Has fields: package, unavailable, total
  - total==0 → "resolves to no tasks accessible to the current user"
  - total>0 → "has {unavailable} of {total} task(s) out of reach"
- Mock seam: harbor.registry.client.package.PackageDatasetClient
  (lazy-imported in harbor.cli.download, harbor.models.job.config)
- run command: does NOT explicitly print DatasetTasksUnavailableError to stdout
  (error propagates uncaught)
- datasets download command: DOES print DatasetTasksUnavailableError via console.print
"""
import os
import sys
from unittest.mock import AsyncMock, MagicMock

sys.path.insert(0, "/tests/validate")

from typer.testing import CliRunner

from harbor.cli.datasets import datasets_app
from harbor.cli.main import app
from harbor.registry.client.package import DatasetTasksUnavailableError

runner = CliRunner(env={"COLUMNS": "1000", "TERM": "dumb"})


def _make_unavailable_error(unavailable_count, total=5):
    """Create a DatasetTasksUnavailableError with the given counts."""
    unavail = int(unavailable_count)
    return DatasetTasksUnavailableError(
        package="acme/benchmark@latest",
        unavailable=unavail,
        total=total,
    )


def _make_empty_error():
    """Create a DatasetTasksUnavailableError for empty dataset (total=0)."""
    return DatasetTasksUnavailableError(
        package="acme/benchmark@latest",
        unavailable=0,
        total=0,
    )


def _patch_package_dataset_client(monkeypatch, client):
    """Patch PackageDatasetClient in all lazy import sites."""
    mock_cls = MagicMock(return_value=client)
    monkeypatch.setattr("harbor.registry.client.package.PackageDatasetClient", mock_cls)


def test_fail_closed_dataset_resolution(inputs, expected, monkeypatch, tmp_path):
    """Test fail-closed dataset resolution for download and run commands."""
    case = expected["case"]
    unavailable_count = inputs["unavailable_count"]

    if case == "run_aborts_on_unavailable_tasks":
        # Mock: PackageDatasetClient.get_dataset_metadata raises unavailable error
        client = MagicMock()
        error = _make_unavailable_error(unavailable_count, total=5)
        client.get_dataset_metadata = AsyncMock(side_effect=error)
        _patch_package_dataset_client(monkeypatch, client)

        # Neutralize unrelated pre-existing preflight
        monkeypatch.setattr(
            "harbor.environments.factory.EnvironmentFactory.run_preflight",
            lambda **_: None
        )
        monkeypatch.setattr(
            "harbor.cli.jobs.show_registry_hint_if_first_run",
            lambda _: None
        )
        run_job = AsyncMock()
        monkeypatch.setattr("harbor.job.Job.run", run_job)

        jobs_dir = tmp_path / "jobs"
        result = runner.invoke(app, [
            "run",
            "--dataset", "acme/benchmark",
            "--jobs-dir", str(jobs_dir),
            "--yes",
        ])
        assert result.exit_code == expected["exit_code"], \
            f"Expected exit {expected['exit_code']}, got {result.exit_code}. output={result.output}"
        # Error count should appear in output
        # NOTE: The run command does NOT explicitly print DatasetTasksUnavailableError.
        # The error propagates uncaught, so result.output may be empty.
        # This assertion tests the EXPECTED behavior (error in output); it may fail
        # if the implementation doesn't print the error.
        assert str(unavailable_count) in result.output, \
            f"Expected count {unavailable_count!r} in output (implementation should print error): {result.output}"
        # Job never ran
        assert run_job.await_count == expected["job_run_await_count"], \
            f"Expected run_job await_count={expected['job_run_await_count']}, got {run_job.await_count}"
        # Jobs dir does NOT exist
        leftover_count = 1 if jobs_dir.exists() else 0
        assert leftover_count == expected["leftover_dir_count"], \
            f"Expected leftover_dir_count={expected['leftover_dir_count']}, got {leftover_count}"

    elif case == "download_aborts_on_unavailable_tasks":
        # Mock: PackageDatasetClient.download_dataset raises unavailable error
        client = MagicMock()
        error = _make_unavailable_error(unavailable_count, total=5)
        # Set both download_dataset and get_dataset_metadata to raise
        client.download_dataset = AsyncMock(side_effect=error)
        client.get_dataset_metadata = AsyncMock(side_effect=error)
        _patch_package_dataset_client(monkeypatch, client)

        out_dir = tmp_path / "out"
        result = runner.invoke(datasets_app, [
            "download",
            "acme/benchmark",
            "--output-dir", str(out_dir),
            "--export",
        ])
        assert result.exit_code == expected["exit_code"], \
            f"Expected exit {expected['exit_code']}, got {result.exit_code}. output={result.output}"
        # Error count should appear in output
        # The download command explicitly prints the error via console.print
        assert str(unavailable_count) in result.output, \
            f"Expected count {unavailable_count!r} in output: {result.output}"
        # Output dir should not exist or should be empty
        if out_dir.exists():
            files = list(out_dir.rglob("*"))
            leftover = len(files)
        else:
            leftover = 0
        assert leftover == expected["leftover_dir_count"], \
            f"Expected leftover_dir_count={expected['leftover_dir_count']}, got {leftover}"

    elif case == "run_aborts_on_empty_dataset":
        # Mock: PackageDatasetClient.get_dataset_metadata raises empty-dataset error (total=0)
        client = MagicMock()
        error = _make_empty_error()
        client.get_dataset_metadata = AsyncMock(side_effect=error)
        _patch_package_dataset_client(monkeypatch, client)

        # Neutralize unrelated pre-existing preflight
        monkeypatch.setattr(
            "harbor.environments.factory.EnvironmentFactory.run_preflight",
            lambda **_: None
        )
        monkeypatch.setattr(
            "harbor.cli.jobs.show_registry_hint_if_first_run",
            lambda _: None
        )
        run_job = AsyncMock()
        monkeypatch.setattr("harbor.job.Job.run", run_job)

        jobs_dir = tmp_path / "jobs2"
        result = runner.invoke(app, [
            "run",
            "--dataset", "acme/benchmark",
            "--jobs-dir", str(jobs_dir),
            "--yes",
        ])
        assert result.exit_code == expected["exit_code"], \
            f"Expected exit {expected['exit_code']}, got {result.exit_code}. output={result.output}"
        # unavailable_count is "__skip__" for empty dataset - skip count check
        if unavailable_count != "__skip__":
            assert str(unavailable_count) in result.output, \
                f"Expected count {unavailable_count!r} in output: {result.output}"
        # Job never ran
        assert run_job.await_count == expected["job_run_await_count"], \
            f"Expected run_job await_count={expected['job_run_await_count']}, got {run_job.await_count}"
        # Jobs dir does NOT exist
        leftover_count = 1 if jobs_dir.exists() else 0
        assert leftover_count == expected["leftover_dir_count"], \
            f"Expected leftover_dir_count={expected['leftover_dir_count']}, got {leftover_count}"

    else:
        raise ValueError(f"Unknown case: {case!r}")
