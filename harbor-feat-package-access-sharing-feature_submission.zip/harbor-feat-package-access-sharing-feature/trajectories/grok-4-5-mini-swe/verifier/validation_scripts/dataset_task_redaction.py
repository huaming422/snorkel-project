"""
Story: dataset_task_redaction
Tests that tasks in a dataset version are marked available/unavailable
and unavailable rows show only an opaque identifier.

From the implementation:
- Command: versions_app, "show", flags "--tasks --json"
- DB mock: harbor.db.client.RegistryDB
- DB method: get_package_version(org, name, ref, include_files, include_tasks)
  returns (package_dict, version_dict)
- The version_dict has "tasks" list
- _normalize_task_row processes each row:
  - available row: returns {available: True, content_hash, name, org, package}
  - unavailable row: returns {available: False, id: opaque_id}
"""
import json
import sys
from unittest.mock import AsyncMock, MagicMock

sys.path.insert(0, "/tests/validate")

from typer.testing import CliRunner

from harbor.cli.versions import versions_app

runner = CliRunner(env={"COLUMNS": "1000", "TERM": "dumb"})


def _make_package(package_type="dataset"):
    return {
        "id": "package-id",
        "type": package_type,
        "visibility": "public",
    }


def _make_version(**overrides):
    base = {
        "id": "version-id",
        "revision": 1,
        "content_hash": "sha256:" + "a" * 64,
        "published_at": "2026-07-20T12:00:00Z",
        "published_by": "user-id",
        "yanked_at": None,
        "yanked_by": None,
        "yanked_reason": None,
        "tags": ["latest"],
        "description": "",
    }
    base.update(overrides)
    return base


def _patch_db(monkeypatch, package, version):
    """Patch RegistryDB with a version that has tasks."""
    db = MagicMock()
    db.get_package_version = AsyncMock(return_value=(package, version))
    monkeypatch.setattr("harbor.db.client.RegistryDB", MagicMock(return_value=db))
    return db


def test_dataset_task_redaction(inputs, expected, monkeypatch):
    """Test task availability marking and redaction in dataset version show."""
    case = expected["case"]

    # Build the tasks list with two rows:
    # Row 0: AVAILABLE - has a task_version body with package name and org
    # Row 1: UNAVAILABLE - has an opaque id, no package info
    available_digest = "sha256:" + "c" * 64
    unavailable_id = "opaque-hidden-id"

    available_task_row = {
        "available": True,
        "task_version": {
            "content_hash": available_digest,
            "package": {
                "name": "visible-task",
                "org": {"name": "acme"},
            },
        },
    }
    unavailable_task_row = {
        "available": False,
        "id": unavailable_id,
        "task_version": {
            "content_hash": None,
            "package": None,
        },
    }

    package = _make_package("dataset")
    version = _make_version(tasks=[available_task_row, unavailable_task_row])
    db = _patch_db(monkeypatch, package, version)

    result = runner.invoke(versions_app, ["show", "acme/demo@latest", "--tasks", "--json"])

    if case == "available_row_full_metadata":
        assert result.exit_code == expected["exit_code"], \
            f"Expected exit {expected['exit_code']}, got {result.exit_code}. stdout={result.stdout}"
        payload = json.loads(result.stdout)
        tasks = payload.get("tasks", [])
        assert len(tasks) >= 1, f"Expected at least 1 task, got {len(tasks)}"
        available_row = tasks[0]
        # Availability indicator should be truthy
        assert bool(available_row.get("available")) == expected["available_is_available"], \
            f"Expected available={expected['available_is_available']}, got {available_row.get('available')}"
        # Full task body should be present: name/org/content_hash fields
        # Count identifying fields (non-null, non-empty values beyond 'available')
        identifying_fields = [
            k for k in available_row
            if k not in {"available"}
            and available_row[k] is not None
            and available_row[k] != ""
        ]
        assert len(identifying_fields) >= expected["available_min_identifying_fields"], \
            f"Expected >= {expected['available_min_identifying_fields']} identifying fields, got {len(identifying_fields)}: {available_row}"

    elif case == "unavailable_row_opaque_only":
        assert result.exit_code == expected["exit_code"], \
            f"Expected exit {expected['exit_code']}, got {result.exit_code}. stdout={result.stdout}"
        payload = json.loads(result.stdout)
        tasks = payload.get("tasks", [])
        assert len(tasks) >= 2, f"Expected at least 2 tasks, got {len(tasks)}"
        unavailable_row = tasks[1]
        # Availability indicator should be falsy
        assert bool(unavailable_row.get("available")) == expected["available_is_available"], \
            f"Expected available={expected['available_is_available']}, got {unavailable_row.get('available')}"
        # Check for leaked identifying substrings in string values
        # The unavailable row should NOT contain: "visible-task", "acme" (org name)
        leaked = 0
        identifying_strings = ["visible-task", "acme"]
        # Collect all string values from the row
        row_string_values = [
            str(v) for v in unavailable_row.values()
            if isinstance(v, str)
        ]
        for val in row_string_values:
            for substr in identifying_strings:
                if substr in val:
                    leaked += 1
        # Also check for path separator inside string values (indicates org/name path leakage)
        for val in row_string_values:
            # Only count "/" as leaked if the value actually looks like a real org/name path
            if "/" in val and any(s in val for s in identifying_strings):
                leaked += 1
        assert leaked == expected["leaked_identifier_count"], \
            f"Expected {expected['leaked_identifier_count']} leaked identifiers, got {leaked} in row: {unavailable_row}"
        # Opaque id field should be present
        opaque_id_keys = [
            k for k in unavailable_row
            if k in {"id", "task_version_id", "opaque_id"}
            and unavailable_row[k] is not None
        ]
        assert len(opaque_id_keys) == expected["opaque_id_present"], \
            f"Expected {expected['opaque_id_present']} opaque id fields, got {len(opaque_id_keys)} in row: {unavailable_row}"

    else:
        raise ValueError(f"Unknown case: {case!r}")
