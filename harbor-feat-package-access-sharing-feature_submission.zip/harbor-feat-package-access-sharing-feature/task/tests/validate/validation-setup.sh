#!/usr/bin/env bash
# validation-setup.sh — runs once before the validation agent starts.
# Ensures harbor's uv-managed venv exists and the pre-existing package surface
# is importable, so the validation agent's pytest scripts can `import harbor...`
# and drive the CLI in-process via Typer's CliRunner. Mirrors tests/test-setup.sh
# (same repo, same package manager, same editable install). Safe to re-run.

set -euo pipefail

REPO=/repo/harbor
cd "$REPO"

export PATH="/usr/local/bin:$PATH"        # task uv (symlinked from /usr/local/uv-task)
export PATH="/root/.local/bin:$PATH"      # uv fallback location
export UV_CACHE_DIR=/opt/uv-cache         # warm cache baked at image build
export UV_OFFLINE=1                        # resolve against the warm cache first

# Rebuild/verify the venv. --frozen pins to uv.lock; the `dev` group (pytest,
# pytest-asyncio) installs by default, giving the validation scripts a pytest to
# run under. Offline-first against the warm cache; if this phase has network and
# a dep is missing from the cache, drop offline mode and fall back to an online
# sync (logged).
uv sync --frozen 2>&1 | tail -3 || { unset UV_OFFLINE; uv sync 2>&1 | tail -3; }

# Expose harbor's venv interpreter on PATH so `python`/`pytest` resolve to the
# editable install with the full dependency tree (matches [settings.pytest].python).
if [ -d "$REPO/.venv" ]; then
    export VIRTUAL_ENV="$REPO/.venv"
    export PATH="$REPO/.venv/bin:$PATH"
fi

# Smoke-import ONLY the pre-existing modules the feature extends, to fail fast if
# the env is broken. The NEW modules the solution adds (the access-command module
# and the access models) exist only after the submitted patch is applied, so they
# are intentionally NOT imported here — the validation scripts discover and import
# the solution's surface at run time.
python - <<'PY'
import harbor.cli.main        # noqa: F401  top-level Typer app
import harbor.cli.tasks       # noqa: F401  task subcommand group
import harbor.cli.datasets    # noqa: F401  dataset subcommand group
import harbor.cli.versions    # noqa: F401  version show --tasks --json
import harbor.db.client       # noqa: F401  RegistryDB (mock seam)
import harbor.registry.client.package  # noqa: F401  PackageDatasetClient (mock seam)
import typer.testing          # noqa: F401  CliRunner
print("harbor import OK")
PY
