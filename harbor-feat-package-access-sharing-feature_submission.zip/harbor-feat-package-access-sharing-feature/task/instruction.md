## Task

Harbor's CLI lets people publish and run task and dataset packages against a shared registry, but package owners have no way to see or control who else can use their packages. We want to add command-line support for owners to inspect access to a task or dataset package and to grant or revoke another organization's access to it. While we're in here, tighten how the tool handles datasets a user isn't fully entitled to, so those cases fail cleanly instead of producing partial or misleading results.

## User stories / requirements

- Inspecting a task or dataset package shows who has access and whether the viewer may manage it; a viewer who can't sees the sensitive provenance omitted, and empty grant lists are dropped from machine-readable output. Non-package references and defunct nested operations are rejected, and an inaccessible package is denied without revealing whether it exists.
- Sharing or unsharing accepts one or more target organizations, dropping case-insensitive duplicates while preserving order and rejecting empties. A preview writes nothing; an apply previews every target before any write, then writes the grants and reports a per-target result. A partial failure names which targets completed, which outcome is unknown, and which went unattempted.
- When a share or unshare is not confirmed up front and is not running against an interactive terminal, the command previews the change once and then stops instead of applying it; with an explicit confirmation it goes ahead and writes. A preview never prompts.
- Downloading or running a dataset whose referenced tasks are not all available to the user stops with an error stating how many are out of reach, and leaves no output directory and no job directory behind; a dataset that resolves to no tasks at all is refused the same way.
- Listing the tasks in a dataset version marks each one as available or not to the current user; a task the user cannot reach shows only an opaque identifier, with no name, organization, or other details exposed.
