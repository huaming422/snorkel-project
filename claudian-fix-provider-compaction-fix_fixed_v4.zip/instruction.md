## Task

`/compact` works differently on every provider and doesn't work at all on some. On its own it should compact the chat; whatever follows it is the instructions for that compaction. What testers are running into:

- With an editor selection captured or something pasted, a bare `/compact` on Pi uses that captured text as its instructions, and Claude and Grok send it along with the command. Selections, linked notes, session references and pasted images have no place in a compaction on any provider. Claude and Grok should get a plain lowercase `/compact`, followed by the trimmed instructions if there are any.
- A leading space is enough to turn it into an ordinary prompt on Pi. It should be recognized however it's cased or padded.
- Reopen a saved chat and the first `/compact` is folded into the history replay, so nothing compacts. Until the provider has that history, `/compact` should fail with an error and send nothing, and the next normal message should still bring the history along.
- OpenCode v2 posts `/compact` as a normal prompt. OpenCode has its own route for it, `POST /api/session/<id>/compact`, whose body is at most an `id` for the request. It parks the compaction in the session inbox the way steers are parked, so one cancelled before it ran is still queued afterwards and must not fire on the next message. A running compaction can't be steered, and it isn't a user message, so it shouldn't appear as one. It takes no instructions either: `/compact some text` there should fail with an error, as it already does on Codex.
- If OpenCode v2 refuses the request, or emits `session.compaction.failed` (its `inputID` says which compaction it's about, `error` says why), the turn should fail with OpenCode's message.
- The "context compacted" divider has gone missing for Grok and OpenCode, both live and after a reload, and some failed or unfinished compactions leave one behind. Each compaction that finished gets one divider and nothing else does.

What the CLIs give us to work with:

- Grok reports every compaction, manual or automatic, as an `x.ai/session/update` notification with `sessionUpdate` set to `auto_compact_started`, `auto_compact_completed`, `auto_compact_failed` or `auto_compact_cancelled`, and its session log records the same updates.
- OpenCode v1 sends nothing over ACP when a compaction finishes. It stores the summary as an assistant message with `summary: true`, which succeeded if it has `time.completed` and no `error`; the user message that started it has a `compaction` part.
- OpenCode v2 stores a row of `type: 'compaction'` whose `status` is `completed` when it worked.

After a reload, a compaction that ran mid-turn keeps its divider inside that turn, between the text either side of it. One run with `/compact` between turns isn't a turn: no user message, no new rewind point, and resuming from an earlier turn leaves it out. Nothing of the compaction's own (the message that started it, the summary text) shows in the chat, and a divider keeps the time its compaction was stored with.

Typed as a steer into a running turn, `/compact` is just text and goes out like any other steer, selection and images included.

Dividers have to come from what the CLIs already store. Leave what they write, and its format, alone.
