// @ts-nocheck
import { mkdtempSync, rmSync } from 'node:fs';
import * as os from 'node:os';
import * as path from 'node:path';
import { DatabaseSync } from 'node:sqlite';

import { testDate } from '@test/helpers/testClock';

import type * as environmentModule from '@/core/process/env';
import type { ChatMessage } from '@/core/types';
import {
  loadOpencodeSessionMessages,
  mapOpencodeMessages,
  mapOpencodeV2NativeMessages,
} from '@/providers/opencode/history/OpencodeHistoryStore';

// Exercise real SQLite subprocesses without discovering the runner's other Node installations.
jest.mock('@/core/process/env', () => ({
  ...jest.requireActual<typeof environmentModule>('@/core/process/env'),
  findNodeExecutables: () => [process.execPath],
}));

const DIVIDER = '<context compacted>';

// What the chat shows, in order: each text block (or a message's plain content) and each divider.
function visible(messages: ChatMessage[]): string[] {
  return messages.flatMap(message => (message.contentBlocks?.length
    ? message.contentBlocks.map(block => (block.type === 'context_compacted' ? DIVIDER
      : block.type === 'text' ? block.content : `<${block.type}>`))
    : [message.content])).filter(item => item !== '');
}

// A divider shown as a message of its own carries its stored record's time.
function expectDividerTime(messages: ChatMessage[], ...times: number[]): void {
  for (const message of messages) {
    if (message.contentBlocks?.length && message.contentBlocks.every(block => block.type === 'context_compacted')) {
      expect(times).toContain(message.timestamp);
    }
  }
}

// A real OpenCode database holding `rows` per table, read back the way a reload reads it. `expectUntouched` checks
// it still holds exactly those rows, in the schema it was created with.
function createStore(schema: string, rows: Record<string, unknown[][]>) {
  const root = mkdtempSync(path.join(os.tmpdir(), 'opencode-compact-history-'));
  const databasePath = path.join(root, 'opencode.db');
  const db = new DatabaseSync(databasePath);
  db.exec(schema);
  for (const [table, values] of Object.entries(rows)) {
    for (const row of values) db.prepare(`INSERT INTO ${table} VALUES(${row.map(() => '?').join(', ')})`).run(...row);
  }
  const read = () => {
    const tables = db.prepare('SELECT type, name, sql FROM sqlite_master ORDER BY name').all();
    return { tables, rows: tables.filter(table => table.type === 'table')
      .map(table => db.prepare(`SELECT * FROM ${table.name} ORDER BY rowid`).all().map(row => Object.values(row))) };
  };
  const stored = read();
  return {
    databasePath,
    expectUntouched() { expect(read()).toEqual(stored); },
    dispose() { db.close(); rmSync(root, { recursive: true, force: true }); },
  };
}

const V1_SCHEMA = `CREATE TABLE message(id TEXT, session_id TEXT, time_created INTEGER, data TEXT);
  CREATE TABLE part(id TEXT, session_id TEXT, message_id TEXT, data TEXT);`;
const V2_SCHEMA = `CREATE TABLE session_v2(id TEXT);
  CREATE TABLE session_message(id TEXT, session_id TEXT, seq INTEGER, type TEXT, time_created INTEGER, data TEXT);`;

// V1 rows as OpenCode stores them: `[id, info, parts]`, with `info.time.created` as the row time.
function v1Rows(messages: [string, Record<string, unknown>, Record<string, unknown>[]][]) {
  return {
    message: messages.map(([id, info]) => [id, 'session', info.time.created, JSON.stringify(info)]),
    part: messages.flatMap(([id, , parts]) => parts.map((part, index) => [`${id}-part-${index}`, 'session', id, JSON.stringify(part)])),
  };
}

describe('OpenCode compaction boundaries', () => {
  const created = testDate().getTime();
  it.each(['completed', 'running', 'failed'])('restores only completed V2 compaction (%s)', status => {
    const messages = mapOpencodeV2NativeMessages([
      { id: 'a1', type: 'assistant', time: { created }, content: [{ type: 'text', text: 'Before' }] },
      { id: 'compact', type: 'compaction', time: { created: created + 1 }, status, summary: 'Internal summary', recent: 'Internal context' },
      { id: 'a2', type: 'assistant', time: { created: created + 2 }, content: [{ type: 'text', text: 'After' }] },
    ]);
    expect(visible(messages)).toEqual(status === 'completed' ? ['Before', DIVIDER, 'After'] : ['Before', 'After']);
    expectDividerTime(messages, created + 1);
    expect(JSON.stringify(messages)).not.toContain('Internal');
  });

  it.each(['completed', 'running', 'failed'])('restores only successful V1 summaries (%s)', status => {
    const messages = mapOpencodeMessages([
      { info: { id: 'a1', role: 'assistant', time: { created } }, parts: [{ type: 'text', text: 'Before' }] },
      { info: { id: 'trigger', role: 'user', time: { created: created + 1 } }, parts: [{ type: 'compaction', auto: false }] },
      { info: { id: 'compact', role: 'assistant', summary: true,
        ...(status === 'failed' ? { error: { name: 'AbortedError' } } : {}),
        time: { created: created + 2, ...(status !== 'running' ? { completed: created + 3 } : {}) },
      }, parts: [{ type: 'text', text: 'Internal summary' }] },
      { info: { id: 'u2', role: 'user', time: { created: created + 4 } }, parts: [{ type: 'text', text: 'Continue' }] },
    ]);
    expect(messages.flatMap(message => message.contentBlocks ?? []).filter(block => block.type === 'context_compacted')).toHaveLength(status === 'completed' ? 1 : 0);
    expect(messages.some(message => message.id === 'trigger')).toBe(false);
    expect(JSON.stringify(messages)).not.toContain('Internal summary');
    expect(visible(messages)).toEqual(status === 'completed' ? ['Before', DIVIDER, 'Continue'] : ['Before', 'Continue']);
    expectDividerTime(messages, created + 2);
  });

  // A reload reads the summary records from OpenCode's database, not from already-parsed messages.
  it.each(['completed', 'running', 'failed'])('reloads only successful V1 summaries from the database (%s)', async status => {
    const store = createStore(V1_SCHEMA, v1Rows([
      ['u1', { role: 'user', time: { created } }, [{ type: 'text', text: 'Question' }]],
      ['a1', { role: 'assistant', time: { created: created + 1, completed: created + 2 } }, [{ type: 'text', text: 'Before' }]],
      ['trigger', { role: 'user', time: { created: created + 3 } }, [{ type: 'compaction', auto: false }]],
      ['compact', { role: 'assistant', summary: true, parentID: 'trigger',
        ...(status === 'failed' ? { error: { name: 'AbortedError' } } : {}),
        time: { created: created + 4, ...(status !== 'running' ? { completed: created + 5 } : {}) },
      }, [{ type: 'text', text: 'Internal summary' }]],
      ['u2', { role: 'user', time: { created: created + 6 } }, [{ type: 'text', text: 'Continue' }]],
    ]));
    try {
      const messages = await loadOpencodeSessionMessages('session', { databasePath: store.databasePath, nativeVersion: 1 });
      expect(visible(messages)).toEqual(status === 'completed' ? ['Question', 'Before', DIVIDER, 'Continue'] : ['Question', 'Before', 'Continue']);
      expect(JSON.stringify(messages)).not.toContain('Internal summary');
      expectDividerTime(messages, created + 4);
      store.expectUntouched();
    } finally { store.dispose(); }
  });

  it('reloads one divider per finished V1 compaction when two ran in one turn', async () => {
    const summary = (offset: number, finished: boolean) => ({ role: 'assistant', summary: true,
      time: { created: created + offset, ...(finished ? { completed: created + offset + 1 } : {}) } });
    const store = createStore(V1_SCHEMA, v1Rows([
      ['u1', { role: 'user', time: { created } }, [{ type: 'text', text: 'Question' }]],
      ['a1', { role: 'assistant', time: { created: created + 1, completed: created + 2 } }, [{ type: 'text', text: 'Before' }]],
      ['t1', { role: 'user', time: { created: created + 3 } }, [{ type: 'compaction', auto: true }]],
      ['s1', summary(4, true), [{ type: 'text', text: 'Internal summary one' }]],
      ['a2', { role: 'assistant', time: { created: created + 6, completed: created + 7 } }, [{ type: 'text', text: 'Middle' }]],
      ['t2', { role: 'user', time: { created: created + 8 } }, [{ type: 'compaction', auto: true }]],
      ['s2', summary(9, true), [{ type: 'text', text: 'Internal summary two' }]],
      ['t3', { role: 'user', time: { created: created + 11 } }, [{ type: 'compaction', auto: true }]],
      ['s3', summary(12, false), [{ type: 'text', text: 'Internal summary three' }]],
      ['a3', { role: 'assistant', time: { created: created + 14, completed: created + 15 } }, [{ type: 'text', text: 'After' }]],
    ]));
    try {
      const messages = await loadOpencodeSessionMessages('session', { databasePath: store.databasePath, nativeVersion: 1 });
      expect(visible(messages)).toEqual(['Question', 'Before', DIVIDER, 'Middle', DIVIDER, 'After']);
      expect(JSON.stringify(messages)).not.toContain('Internal summary');
      expectDividerTime(messages, created + 4, created + 9);
      store.expectUntouched();
    } finally { store.dispose(); }
  });

  it('reloads one divider per finished V2 compaction from the database, two in one turn included', async () => {
    const row = (id: string, seq: number, type: string, data: Record<string, unknown>) => (
      [id, 'session', seq, type, created + seq, JSON.stringify({ ...data, time: { created: created + seq } })]);
    const compaction = (id: string, seq: number, status: string) => row(id, seq, 'compaction',
      { status, reason: 'auto', summary: 'Internal summary', recent: 'Internal context' });
    const store = createStore(V2_SCHEMA, { session_v2: [['session']], session_message: [
      row('u1', 1, 'user', { text: 'Question' }),
      row('a1', 2, 'assistant', { content: [{ type: 'text', text: 'Before' }] }),
      compaction('c1', 3, 'completed'),
      row('a2', 4, 'assistant', { content: [{ type: 'text', text: 'Middle' }] }),
      compaction('c2', 5, 'failed'),
      compaction('c3', 6, 'completed'),
      compaction('c4', 7, 'running'),
      row('a3', 8, 'assistant', { content: [{ type: 'text', text: 'After' }] }),
    ] });
    try {
      const messages = await loadOpencodeSessionMessages('session', { databasePath: store.databasePath, nativeVersion: 2 });
      expect(visible(messages)).toEqual(['Question', 'Before', DIVIDER, 'Middle', DIVIDER, 'After']);
      expect(JSON.stringify(messages)).not.toContain('Internal');
      expectDividerTime(messages, created + 3, created + 6);
      store.expectUntouched();
    } finally { store.dispose(); }
  });
});
