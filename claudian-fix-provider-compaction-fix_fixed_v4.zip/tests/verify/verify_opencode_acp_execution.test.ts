// @ts-nocheck
import type { ChildProcessWithoutNullStreams } from 'node:child_process';
import * as fs from 'node:fs/promises';
import * as os from 'node:os';
import * as path from 'node:path';
import { DatabaseSync } from 'node:sqlite';

import { capturedSelections } from '@test/helpers/capturedSelections';
import { testDate } from '@test/helpers/testClock';
import spawn from 'cross-spawn';

jest.mock('cross-spawn', () => jest.fn());

import { createNativeRPCProcess, createNativeVersionProcess } from '@test/helpers/providers/NativeRPCTestProcess';

import type { ProviderExecutionEvent, ProviderExecutionRequest } from '@/core/execution';
import type { ProviderHost } from '@/core/providers/ProviderHost';
import { OpencodeExecutionBackend } from '@/providers/opencode/execution/OpencodeExecutionBackend';
import { OpencodeServerService } from '@/providers/opencode/http/OpencodeServerService';
import { OpencodeMetadataService } from '@/providers/opencode/metadata/OpencodeMetadataService';
import { createOpencodeModels } from '@/providers/opencode/runtime/OpencodeModels';
import { getOpencodeProviderSettings } from '@/providers/opencode/settings';

const image = { type: 'image', image: {
  id: 'capture', name: 'capture.png', data: 'aW1hZ2U=', mediaType: 'image/png', size: 5, source: 'paste',
} } as const;

// A V1 (ACP) session over a stub CLI and a real OpenCode database. `onPrompt` stands in for what the CLI does
// during session/prompt and returns its stop reason.
async function createV1Fixture(resume: boolean, onPrompt: (insert: (id: string, status: string, offset: number) => void) => string) {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'claudian-acp-compact-'));
  const cliPath = path.join(root, 'opencode');
  const databasePath = path.join(root, 'opencode.db');
  await fs.writeFile(cliPath, '', { mode: 0o700 });
  const db = new DatabaseSync(databasePath);
  db.exec(`CREATE TABLE message(id TEXT, session_id TEXT, time_created INTEGER, data TEXT);
    CREATE TABLE part(id TEXT, session_id TEXT, message_id TEXT, data TEXT);`);
  const created = testDate().getTime();
  const written: unknown[][] = [];
  const insert = (id: string, status: string, offset: number) => {
    const row = [id, 'native-session', created + offset, JSON.stringify({ role: 'assistant', summary: true,
      time: { created: created + offset, ...(status !== 'running' ? { completed: created + offset + 1 } : {}) },
      ...(status === 'failed' ? { error: { name: 'APIError' } } : {}),
    })];
    db.prepare('INSERT INTO message VALUES(?, ?, ?, ?)').run(...row);
    written.push(row);
  };
  const schema = () => db.prepare('SELECT type, name, sql FROM sqlite_master ORDER BY name').all();
  const shippedSchema = schema();
  insert('old-summary', 'completed', 0);
  const prompts: unknown[] = [];
  jest.mocked(spawn).mockImplementation((_command, args) => {
    if (args?.includes('--version')) return createNativeVersionProcess('1.2.27');
    return createNativeRPCProcess((method, params) => {
      if (method === 'initialize') return { protocolVersion: 1, agentCapabilities: {} };
      if (method === 'session/load' || method === 'session/new') return { sessionId: 'native-session' };
      if (method === 'session/set_config_option') return { configOptions: [] };
      if (method === 'session/prompt') {
        prompts.push(params.prompt);
        return { stopReason: onPrompt(insert) };
      }
      return {};
    });
  });
  const host = {
    settings: { model: 'opencode:test/model', providerConfigs: { opencode: { enabled: true,
      visibleModels: ['test/model'], discoveredModels: [{ rawId: 'test/model', label: 'Test' }],
      environmentVariables: `OPENCODE_DB=${databasePath}`,
    } } },
    getResolvedProviderCliPath: async () => cliPath,
    mutateSettings: async () => undefined,
    notifyProviderChatOptionsChanged: () => undefined,
  } as unknown as ProviderHost;
  const session = new OpencodeExecutionBackend(host, { serverService: new OpencodeServerService() }).createSession({
    lifecycle: 'persistent', nativePersistence: 'enabled', vaultWorkingDirectory: root,
    ...(resume ? { resumeSeed: { providerSessionId: 'native-session', providerState: { databasePath, nativeVersion: 1 } } } : {}),
    interactionPort: {
      requestApproval: async request => ({ interactionId: request.interactionId, decision: 'deny' }),
      askUserQuestion: async request => ({ interactionId: request.interactionId, answers: null }),
      dismissInteraction() {},
    },
  });
  const run = async (request: Partial<ProviderExecutionRequest>) => {
    const events: ProviderExecutionEvent[] = [];
    for await (const event of session.execute({
      configuration: { permissionMode: 'normal', systemInstructions: { kind: 'provider-default' } },
      input: [{ type: 'text', text: '/compact' }], toolPolicy: { kind: 'provider-default' },
      signal: new AbortController().signal, ...request,
    }).events) events.push(event);
    return events;
  };
  return {
    prompts, run,
    // The database holds exactly what the CLI wrote, in the schema it wrote it with.
    expectStoreUntouched() {
      expect(schema()).toEqual(shippedSchema);
      expect(db.prepare('SELECT * FROM message ORDER BY rowid').all().map(row => Object.values(row))).toEqual(written);
      expect(db.prepare('SELECT COUNT(*) AS count FROM part').get()).toEqual({ count: 0 });
    },
    async dispose() {
      await session.dispose();
      db.close();
      await fs.rm(root, { recursive: true, force: true });
      jest.mocked(spawn).mockReset();
    },
  };
}

it.each([
  ...['completed', 'failed', 'running', 'cancelled', 'unchanged'].map(outcome => ({ outcome, captured: false })),
  { outcome: 'completed', captured: true },
])('reports a new persisted V1 compact boundary only on success ($outcome, captured context: $captured)', async ({ outcome, captured }) => {
  const f = await createV1Fixture(true, insert => {
    if (outcome !== 'unchanged') insert('new-summary', outcome, 10);
    return outcome === 'cancelled' ? 'cancelled' : 'end_turn';
  });
  try {
    const events = await f.run(captured ? {
      input: [{ type: 'text', text: ' \t/CoMpAcT\n' }, image],
      context: { ...capturedSelections, linkedContent: { path: 'note.md' },
        sessionReferences: [{ id: 'ref', title: 'Review', providerId: 'opencode', updatedAt: 'updated', snapshotPath: '/tmp/ref.md' }],
      },
    } : {});
    // Only the command reaches OpenCode, in either casing.
    expect(f.prompts).toEqual([[{ type: 'text', text: captured ? expect.stringMatching(/^\/compact$/i) : '/compact' }]]);
    // A compaction stored as failed may end the turn normally or as an error.
    expect(outcome === 'failed' ? ['turn_completed', 'execution_error'] : [outcome === 'cancelled' ? 'cancelled' : 'turn_completed'])
      .toContain(events.at(-1)?.type);
    expect(events.filter(event => event.type === 'context_compacted')).toHaveLength(outcome === 'completed' ? 1 : 0);
    f.expectStoreUntouched();
  } finally { await f.dispose(); }
});

it('rejects V1 compact while replayed history still needs recovery, then replays it', async () => {
  const f = await createV1Fixture(false, () => 'end_turn');
  const conversationHistory = [{ id: 'prior', role: 'user' as const, content: 'Remember prior context', timestamp: testDate().getTime() }];
  try {
    const events = await f.run({ conversationHistory });
    expect(events.at(-1)).toMatchObject({ type: 'execution_error', message: expect.any(String) });
    expect(f.prompts).toEqual([]);
    await f.run({ input: [{ type: 'text', text: 'Continue' }], conversationHistory });
    expect(JSON.stringify(f.prompts[0])).toContain('Remember prior context');
    f.expectStoreUntouched();
  } finally { await f.dispose(); }
});

it.each([['completed'], ['failed'], ['running'], [], ['completed', 'completed'], ['completed', 'failed']].map(outcomes => ({ outcomes })))(
  'reports each automatic V1 compaction during an ordinary prompt only on success (stored: $outcomes)', async ({ outcomes }) => {
    // OpenCode compacts on its own while answering, possibly more than once; it stores each summary the same way
    // as for a typed /compact.
    const f = await createV1Fixture(true, insert => {
      outcomes.forEach((outcome, index) => insert(`auto-summary-${index}`, outcome, 10 + 2 * index));
      return 'end_turn';
    });
    try {
      const events = await f.run({ input: [{ type: 'text', text: 'Keep going' }] });
      expect(JSON.stringify(f.prompts)).toContain('Keep going');
      expect(outcomes.includes('failed') ? ['turn_completed', 'execution_error'] : ['turn_completed']).toContain(events.at(-1)?.type);
      expect(events.filter(event => event.type === 'context_compacted')).toHaveLength(outcomes.filter(outcome => outcome === 'completed').length);
      f.expectStoreUntouched();
    } finally { await f.dispose(); }
  },
);
