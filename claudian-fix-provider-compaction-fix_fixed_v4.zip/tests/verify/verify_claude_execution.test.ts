// @ts-nocheck
import '@/providers';

import * as fs from 'node:fs/promises';
import * as os from 'node:os';
import * as path from 'node:path';

import * as sdkModule from '@anthropic-ai/claude-agent-sdk';
import { capturedSelectionPrompt, capturedSelections } from '@test/helpers/capturedSelections';
import { claudeCatalogFixture } from '@test/helpers/claudeModels';
import { createProviderRecoveryTestHarness } from '@test/helpers/features/chat/ProviderRecoveryTestHarness';
import { testDate, testTime } from '@test/helpers/testClock';

import {
  type ProviderExecutionEvent,
  ProviderExecutionLifecycleRegistry,
  type ProviderExecutionRequest,
  type ProviderInteractionPort,
  type ProviderSessionConfig,
  type ProviderSessionEvent,
  type ProviderSessionSnapshot,
} from '@/core/execution';
import { ProviderModelUnavailableError } from '@/core/providers/models/ProviderModelUnavailableError';
import type { ProviderHost } from '@/core/providers/ProviderHost';
import type { ClaudianSettings } from '@/core/types';
type MutableTestHost = ProviderHost & { settings: ClaudianSettings };
import * as env from '@/core/process/env';
import type { Conversation } from '@/core/types';
import { createClaudeWorkspaceServices } from '@/providers/claude/app/ClaudeWorkspaceServices';
import { ClaudeExecutionBackend } from '@/providers/claude/execution/ClaudeExecutionBackend';
import { ClaudeExecutionSession } from '@/providers/claude/execution/ClaudeExecutionSession';
import { ClaudeConversationHistoryService } from '@/providers/claude/history/ClaudeConversationHistoryService';
import * as historyStore from '@/providers/claude/history/ClaudeHistoryStore';
import { assertClaudeModelAvailable } from '@/providers/claude/runtime/ClaudeModelAvailability';
import { buildClaudeSDKUserMessage } from '@/providers/claude/runtime/ClaudeUserMessageFactory';
import { getClaudeProviderSettings, updateClaudeProviderSettings } from '@/providers/claude/settings';

jest.mock('@/providers/claude/runtime/ClaudeUserMessageFactory', () => {
  const actual = jest.requireActual('@/providers/claude/runtime/ClaudeUserMessageFactory');
  return {
    ...actual,
    buildClaudeSDKUserMessage: jest.fn(actual.buildClaudeSDKUserMessage),
  };
});

const mockBuildClaudeSDKUserMessage = buildClaudeSDKUserMessage as jest.MockedFunction<
  typeof buildClaudeSDKUserMessage
>;

const sdkMock = sdkModule as unknown as {
  getLastOptions: () => sdkModule.Options | undefined;
  getLastResponse: () => {
    applyFlagSettings: jest.Mock;
    interrupt: jest.Mock;
    setModel: jest.Mock;
    setPermissionMode: jest.Mock;
    setMcpServers: jest.Mock;
    supportedCommands: jest.Mock;
    getContextUsage: jest.Mock;
  } | null;
  getQueryCallCount: () => number;
  resetMockMessages: () => void;
  setMockMessages: (
    messages: unknown[],
    options?: { appendResult?: boolean },
  ) => void;
  setMockSupportedCommands: (
    commands: Array<{
      name: string;
      description: string;
      argumentHint?: string;
    }>,
  ) => void;
  setMockSupportedModels: (models: sdkModule.ModelInfo[]) => void;
  setMockOutputStyles: (styles: string[]) => void;
  setMockContextUsage: (
    contextUsage: { rawMaxTokens: number } | null,
  ) => void;
};

function createInteractionPort(): jest.Mocked<ProviderInteractionPort> {
  return {
    requestApproval: jest.fn().mockImplementation(async (request) => ({
      interactionId: request.interactionId,
      decision: 'allow',
    })),
    askUserQuestion: jest.fn().mockImplementation(async (request) => ({
      interactionId: request.interactionId,
      answers: { choice: 'yes' },
    })),
    dismissInteraction: jest.fn(),
  };
}

function createHost(): MutableTestHost {
  return {
    app: {
      vault: {
        adapter: {
          basePath: '/vault',
        },
      },
    },
    settings: {
      providerConfigs: { claude: claudeCatalogFixture(['claude-sonnet-4-5', 'claude-opus-4-6', 'claude-haiku-4-5', 'custom-model', 'custom-model-a', 'custom-model-b'], ['low', 'medium', 'high']) },
      model: 'claude-sonnet-4-5',
      permissionMode: 'ask',
      effortLevel: 'medium',
      mediaFolder: 'media',
      systemPrompt: '',
      userName: '',
      loadUserClaudeSettings: false,
    },
    storage: {} as ProviderHost['storage'],
    getResolvedProviderCliPath: jest.fn().mockResolvedValue('/bin/claude'),
    getActiveEnvironmentVariables: jest.fn().mockReturnValue(''),
  } as unknown as MutableTestHost;
}

function createConfig(
  overrides: Partial<ProviderSessionConfig> = {},
): ProviderSessionConfig {
  return {
    lifecycle: 'persistent',
    nativePersistence: 'enabled',
    vaultWorkingDirectory: '/vault',
    interactionPort: createInteractionPort(),
    ...overrides,
  };
}

function createRequest(
  overrides: Partial<ProviderExecutionRequest> = {},
): ProviderExecutionRequest {
  return {
    input: [{ type: 'text', text: 'Hello' }],
    configuration: {
      systemInstructions: { kind: 'provider-default' },
      model: 'claude-sonnet-4-5',
      reasoning: 'medium',
      permissionMode: 'ask',
    },
    toolPolicy: { kind: 'provider-default' },
    signal: new AbortController().signal,
    ...overrides,
  };
}

async function collectEvents(
  events: AsyncIterable<ProviderExecutionEvent>,
): Promise<ProviderExecutionEvent[]> {
  const collected: ProviderExecutionEvent[] = [];
  for await (const event of events) {
    collected.push(event);
  }
  return collected;
}

function getEncodedPrompts(): string[] {
  return mockBuildClaudeSDKUserMessage.mock.calls.map(([prompt]) => prompt);
}

describe('ClaudeExecutionBackend', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    sdkMock.resetMockMessages();
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  it.each([
    ['/compact', '/compact'],
    [' \t/CoMpAcT keep recent edits\nFocus on tests  ', '/compact keep recent edits\nFocus on tests'],
  ])('compacts with only explicit instructions from %j', async (text, command) => {
    const session = new ClaudeExecutionBackend(createHost()).createSession(createConfig());
    try {
      const events = await collectEvents(session.execute(createRequest({
        input: [{ type: 'text', text }, { type: 'image', image: {
          id: 'capture', name: 'capture.png', data: 'aW1hZ2U=',
          mediaType: 'image/png', size: 5, source: 'paste',
        } }],
        context: { ...capturedSelections, linkedContent: { path: 'note.md' },
          sessionReferences: [{ id: 'ref', title: 'Review', providerId: 'claude', updatedAt: 'updated', snapshotPath: '/tmp/ref.md' }],
        },
      })).events);
      expect(mockBuildClaudeSDKUserMessage.mock.results[0]?.value.message.content).toBe(command);
      expect(events.at(-1)?.type).toBe('turn_completed');
    } finally { await session.dispose(); }
  });

  it('rejects compact without consuming history that still needs recovery', async () => {
    const session = new ClaudeExecutionBackend(createHost()).createSession(createConfig());
    const conversationHistory = [{ id: 'prior', role: 'user' as const, content: 'Remember prior context', timestamp: testDate().getTime() }];
    try {
      const events = await collectEvents(session.execute(createRequest({
        input: [{ type: 'text', text: '/compact' }], conversationHistory,
      })).events);
      // The user sees an error; its wording isn't fixed.
      expect(events.at(-1)).toMatchObject({ type: 'execution_error', message: expect.any(String) });
      expect(getEncodedPrompts()).toEqual([]);
      await collectEvents(session.execute(createRequest({ conversationHistory })).events);
      expect(getEncodedPrompts()[0]).toContain('Remember prior context');
      expect(getEncodedPrompts()[0]).toContain('Hello');
    } finally { await session.dispose(); }
  });

  it('steers literal /compact text with its captured context into the running turn', async () => {
    const steerReceived = createDeferred<sdkModule.SDKUserMessage>();
    const { session, events, done } = await startSteerableSession(async function* (nextInput, keepOpen) {
      const prompt = await nextInput();
      yield { type: 'system', subtype: 'init', session_id: 'session-1' };
      yield replayOf(prompt);
      yield assistantText('assistant-1', 'Reading the parser.');
      const steer = await nextInput();
      steerReceived.resolve(steer);
      yield replayOf(steer);
      yield assistantText('assistant-2', 'Noted.');
      yield { type: 'result', subtype: 'success', user_message_uuids: [prompt.uuid, steer.uuid], queued_turn_count: 0 };
      await keepOpen;
    });
    try {
      await waitFor(() => events.some(event => event.type === 'text_delta'));
      await expect(session.steer(createRequest({
        input: [{ type: 'text', text: '/compact' }], context: capturedSelections,
      }))).resolves.toBe(true);
      await done;
      expect(getNativePromptText(await steerReceived.promise)).toBe(`/compact\n\n${capturedSelectionPrompt}`);
      expect(events.filter(event => event.type === 'turn_completed')).toHaveLength(1);
    } finally { await session.dispose(); }
  });

});

async function startSteerableSession(
  script: (
    nextInput: () => Promise<sdkModule.SDKUserMessage>,
    keepOpen: Promise<unknown>,
  ) => AsyncGenerator<unknown>,
) {
  const keepOpen = createDeferred<unknown>();
  jest.spyOn(await import('@/providers/claude/loadClaudeAgentSDK'), 'loadClaudeAgentQuery')
    .mockResolvedValueOnce((({ prompt }: { prompt: AsyncIterable<sdkModule.SDKUserMessage> }) => (
      createInputDrivenQuery(prompt, nextInput => script(nextInput, keepOpen.promise))
    )) as never);
  const backendSession = new ClaudeExecutionBackend(createHost()).createSession(createConfig());
  const session = Object.assign(backendSession, {
    dispose: async () => {
      keepOpen.resolve(null);
      await ClaudeExecutionSession.prototype.dispose.call(backendSession);
    },
  });
  const run = session.execute(createRequest({ input: [{ type: 'text', text: 'Refactor the parser' }] }));
  const events: ProviderExecutionEvent[] = [];
  const done = (async () => {
    for await (const event of run.events) events.push(event);
  })();
  return { session, events, done };
}

function replayOf(message: sdkModule.SDKUserMessage): unknown {
  return { ...message, isReplay: true, session_id: 'session-1' };
}

function assistantText(uuid: string, text: string): unknown {
  return {
    type: 'assistant',
    uuid,
    parent_tool_use_id: null,
    message: { id: `message-${uuid}`, content: [{ type: 'text', text }] },
  };
}

function createInputDrivenQuery(
  prompt: AsyncIterable<sdkModule.SDKUserMessage>,
  script: (nextInput: () => Promise<sdkModule.SDKUserMessage>) => AsyncGenerator<unknown>,
): ScriptedQuery {
  let resolveFinished!: () => void;
  const finished = new Promise<void>((resolve) => {
    resolveFinished = resolve;
  });
  const input = prompt[Symbol.asyncIterator]();
  const nextInput = async () => {
    const next = await input.next();
    if (next.done) throw new Error('Native input closed');
    return next.value;
  };
  const query = (async function* () {
    try {
      yield* script(nextInput);
    } finally {
      resolveFinished();
    }
  })();
  return attachQueryMethods(query, finished);
}

let deferredRelease: (() => void) | null = null;

function deferredMessage(): Promise<null> {
  return new Promise((resolve) => {
    deferredRelease = () => resolve(null);
  });
}

function releaseDeferredMessage(): void {
  deferredRelease?.();
  deferredRelease = null;
}

function createDeferred<T>(): {
  promise: Promise<T>;
  resolve: (value: T) => void;
} {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>((innerResolve) => {
    resolve = innerResolve;
  });
  return { promise, resolve };
}

function applyProviderStateProjection(
  current: Readonly<Record<string, unknown>>,
  snapshot: ProviderSessionSnapshot,
): Record<string, unknown> {
  const projected: Record<string, unknown> = { ...current };
  for (const key of snapshot.providerStateDeletes ?? []) {
    delete projected[key];
  }
  Object.assign(projected, snapshot.providerState ?? {});
  return projected;
}

async function waitFor(predicate: () => boolean): Promise<void> {
  for (let attempt = 0; attempt < 100; attempt += 1) {
    if (predicate()) return;
    await new Promise<void>((resolve) => {
      setTimeout(resolve, 0);
    });
  }
  throw new Error('Timed out waiting for condition');
}

function createScriptedPersistentQuery(
  turns: Array<Array<unknown | Promise<unknown>>>,
): ScriptedQuery {
  let resolveFinished!: () => void;
  const finished = new Promise<void>((resolve) => {
    resolveFinished = resolve;
  });
  const query = (async function* () {
    try {
      for (const turn of turns) {
        for (const message of turn) {
          const resolved = await message;
          if (resolved !== null) {
            yield resolved;
          }
        }
      }
    } finally {
      resolveFinished();
    }
  })();
  return attachQueryMethods(query, finished);
}

function createFailingPersistentQuery(
  messages: Array<unknown | Promise<unknown>>,
  error: Error,
): ScriptedQuery {
  let resolveFinished!: () => void;
  const finished = new Promise<void>((resolve) => {
    resolveFinished = resolve;
  });
  const query = (async function* () {
    try {
      for (const message of messages) {
        const resolved = await message;
        if (resolved !== null) {
          yield resolved;
        }
      }
      throw error;
    } finally {
      resolveFinished();
    }
  })();
  return attachQueryMethods(query, finished);
}

function createPromptDrivenPersistentQuery(
  prompt: AsyncIterable<sdkModule.SDKUserMessage>,
  resolveTurn: (
    promptText: string,
  ) => Array<unknown | Promise<unknown>>,
): ScriptedQuery {
  let resolveFinished!: () => void;
  const finished = new Promise<void>((resolve) => {
    resolveFinished = resolve;
  });
  const query = (async function* () {
    try {
      for await (const message of prompt) {
        for (const event of resolveTurn(getNativePromptText(message))) {
          const resolved = await event;
          if (resolved !== null) {
            yield resolved;
          }
        }
      }
    } finally {
      resolveFinished();
    }
  })();
  return attachQueryMethods(query, finished);
}

function getNativePromptText(message: sdkModule.SDKUserMessage): string {
  const content = message.message.content;
  if (typeof content === 'string') return content;
  return content
    .filter((block): block is { type: 'text'; text: string } => (
      block.type === 'text'
    ))
    .map(block => block.text)
    .join('\n');
}

type ScriptedQuery = AsyncGenerator<unknown> & {
  interrupt: jest.Mock;
  setModel: jest.Mock;
  setPermissionMode: jest.Mock;
  setMcpServers: jest.Mock;
  applyFlagSettings: jest.Mock;
  supportedCommands: jest.Mock;
  rewindFiles: jest.Mock;
  finished: Promise<void>;
};

function attachQueryMethods(
  query: AsyncGenerator<unknown>,
  finished: Promise<void>,
): ScriptedQuery {
  return Object.assign(query, {
    interrupt: jest.fn().mockResolvedValue(undefined),
    setModel: jest.fn().mockResolvedValue(undefined),
    setPermissionMode: jest.fn().mockResolvedValue(undefined),
    setMcpServers: jest.fn().mockResolvedValue({ added: [], removed: [], errors: {} }),
    applyFlagSettings: jest.fn().mockResolvedValue(undefined),
    supportedCommands: jest.fn().mockResolvedValue([]),
    rewindFiles: jest.fn().mockResolvedValue({ canRewind: true, filesChanged: [] }),
    finished,
  });
}

function createThrowingPersistentQuery(error: Error): ReturnType<
  typeof createScriptedPersistentQuery
> {
  const throwing = (async function* () {
    await Promise.reject(error);
    yield undefined;
  })();
  return attachQueryMethods(throwing, Promise.resolve());
}

function createIdlePersistentQuery(): ReturnType<
  typeof createScriptedPersistentQuery
> {
  const idle = (async function* () {
    await new Promise<void>(() => undefined);
    yield undefined;
  })();
  return attachQueryMethods(
    idle,
    new Promise<void>(() => undefined),
  );
}

function consumedTaskNotification(taskId = 'task') {
  return { type: 'user', uuid: 'notification-consumed', parent_tool_use_id: null, isReplay: true, isSynthetic: true,
    message: { role: 'user', content: `<task-notification><task-id>${taskId}</task-id><status>completed</status><summary>Task finished</summary></task-notification>` } };
}
