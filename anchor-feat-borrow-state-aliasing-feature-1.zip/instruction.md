## Task

In Anchor v2, stop rejecting duplicate mutable accounts at instruction dispatch and remove the table the `Accounts` derive generates for that check. Each account should refuse a conflicting borrow itself when it lends out a reference.

`AnchorAccount::load_mut` then leaves nothing for callers to uphold, so make it a safe function. Remove `#[account(unsafe(dup))]` as well, so the derive rejects it.

Ownership checks, content validation, init-if-needed, and closes and resizes that don't conflict with a live borrow should keep working as they do now.

## User stories / requirements

- When the same data account is passed under two handles and one handle takes a mutable borrow of it, any further borrow of that account through the other handle is refused with a borrow-conflict error. Once the first borrow is dropped, the second borrow succeeds.
- When a signer, a system account, an unchecked account, or a program account is passed under two handles at once, both handles load without error.
- When an account is closed while a borrow of it is still live through another handle, the close is refused with a borrow-conflict error and the account's balance and contents are left untouched. With no other borrow live, the close succeeds and the balance moves to the destination.
- When an account is resized while a borrow of it is still live through another handle, the resize is refused with a borrow-conflict error and the account's size is unchanged, whether the resize goes through the account wrapper or directly through a raw account view. With no other borrow live, the resize succeeds.
- When an account was loaded as read-only, asking it for a writable handle to hand to a cross-program call is refused with a borrow-conflict error. An account loaded as mutable yields the writable handle.
- When a mutable load of an account is rejected because the account's contents fail validation, the account's bytes are left exactly as they were and any borrow already live on it stays live.
