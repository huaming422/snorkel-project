"""Structural verifier for anchor-feat-borrow-state-aliasing.

Confirms the accounts-derive macro no longer accepts the per-field
alias-override attribute (`#[account(unsafe(dup))]`). Before the change the
derive carried an explicit opt-out that let a field skip the whole-instruction
duplicate-mutable table; after the change enforcement is per-account at
lend time, so the opt-out is gone and the derive rejects the attribute at
macro-expansion time.

Why a compile probe (not a source grep / ast rule): the behavior under test
is "the derive refuses this attribute", which is only observable by asking the
real proc-macro to expand a struct that uses it. A grep for a removed arm would
couple to the macro crate's internal source shape; a compile probe asks the
public derive the question directly and is insensitive to how the macro is
organised internally (renamed helpers, a thinned-but-retained dispatch
pre-check, a different realloc decomposition — all expand this struct the same
way once the attribute is gone).

How the two probes split pass from fail:
  * CONTROL — a struct with the ordinary `#[account(mut)]` attribute. This must
    ALWAYS compile; it proves the probe harness, the toolchain, and the
    by-path dependency on the account layer are all wired correctly, so a
    compile failure on the real probe is attributable to the attribute and not
    to an unrelated build break.
  * PROBE — a struct whose field carries `#[account(unsafe(dup))]`. The old
    derive accepted this attribute (it compiles); the new derive has no arm for
    it, so macro expansion fails. The verifier PASSES when this probe FAILS to
    compile and FAILS when it still compiles.

The probe deliberately tests ONLY that the attribute is rejected. It does not
assert anything about internal duplicate-tracking machinery, so a solution that
reorganises or partially retains internal detection still passes as long as it
drops the public attribute — which is the stated contract.

Runs under the shared verifier interpreter (VERIFIER_PYTHON): it shells out to
cargo and imports no repository Python, so no `[pytest] command` override is
needed.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
import textwrap

# Repository root inside the task container (see image/Dockerfile).
REPO_DIR = "/repo/anchor"

# The account layer whose derive macro is under test, addressed by its on-disk
# path. This is the pre-existing crate location at the base commit; the probe
# crate depends on it by path, the way the repo's own `macro_diagnostics.rs`
# fixtures do.
ACCOUNT_LAYER_PATH = os.path.join(REPO_DIR, "lang-v2")

# A cold check of the account layer plus one tiny probe crate is a couple of
# minutes; against the image's pre-warmed target it is far less. 900s is ample
# head-room and keeps this well inside the reward stack's wall-clock budget.
CHECK_TIMEOUT_SEC = 900


def _cargo_env() -> dict:
    """Environment for cargo, honouring the image's toolchain locations."""
    env = {**os.environ}
    env.setdefault("CARGO_HOME", "/opt/cargo")
    env.setdefault("RUSTUP_HOME", "/opt/rustup")
    # Share the image's warm target dir so the account-layer dependency is a
    # cache hit rather than a cold rebuild. Falls back to a private dir if the
    # image did not set one.
    env.setdefault("CARGO_TARGET_DIR", "/opt/cache/cargo-target")
    env["PATH"] = f"{env['CARGO_HOME']}/bin:" + env.get("PATH", "")
    return env


def _cargo_check(crate_name: str, field_attr: str) -> subprocess.CompletedProcess:
    """Create a throwaway crate that derives `Accounts` on a struct whose single
    field carries ``field_attr`` and run ``cargo check`` on it.

    The crate depends on the account layer by path with the ``testing`` feature
    (matching the image's pre-warmed build so the dependency is a cache hit) and
    detaches from the surrounding workspace via an empty ``[workspace]`` table.
    """
    tmp = tempfile.mkdtemp(prefix=f"dup_probe_{crate_name}_")
    src_dir = os.path.join(tmp, "src")
    os.makedirs(src_dir, exist_ok=True)

    cargo_toml = textwrap.dedent(
        f"""\
        [package]
        name = "{crate_name}"
        version = "0.0.0"
        edition = "2021"
        publish = false

        [dependencies]
        anchor-lang = {{ path = "{ACCOUNT_LAYER_PATH}", features = ["testing"] }}

        [workspace]
        """
    )
    with open(os.path.join(tmp, "Cargo.toml"), "w") as fh:
        fh.write(cargo_toml)

    # Mirror the repo's own derive fixtures (lang-v2/tests/macro_diagnostics.rs):
    # `use prelude::*`, a `declare_id!` so the expansion's program-id references
    # resolve, and a single-field `#[derive(Accounts)]` struct. The all-ones
    # address is an arbitrary valid program id; the probe never executes.
    lib_rs = textwrap.dedent(
        f"""\
        use anchor_lang::prelude::*;

        declare_id!("11111111111111111111111111111111");

        #[derive(Accounts)]
        pub struct Probe {{
            {field_attr}
            pub a: UncheckedAccount,
        }}
        """
    )
    with open(os.path.join(src_dir, "lib.rs"), "w") as fh:
        fh.write(lib_rs)

    try:
        return subprocess.run(
            ["cargo", "check", "--offline", "--manifest-path",
             os.path.join(tmp, "Cargo.toml")],
            capture_output=True,
            text=True,
            timeout=CHECK_TIMEOUT_SEC,
            env=_cargo_env(),
            check=False,
        )
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def _tail(text: str, n: int = 120) -> str:
    return "\n".join(text.splitlines()[-n:])


def test_dup_escape_hatch_rejected_by_derive() -> None:
    """The derive must reject `#[account(unsafe(dup))]` at expansion time.

    Positive control first: a struct with the ordinary `#[account(mut)]`
    attribute must compile. If it does not, the probe harness or build
    environment is broken and any conclusion about the real probe would be
    meaningless — fail loudly rather than silently passing.
    """
    control = _cargo_check("mut_control", "#[account(mut)]")
    assert control.returncode == 0, (
        "Positive control failed to compile: a struct with the ordinary "
        "`#[account(mut)]` attribute should always build. The probe harness, "
        "toolchain, or by-path account-layer dependency is broken, so the "
        "escape-hatch probe below cannot be trusted.\n\n"
        f"--- cargo check stderr (last 120 lines) ---\n{_tail(control.stderr)}\n"
        f"--- cargo check stdout (last 120 lines) ---\n{_tail(control.stdout)}"
    )

    probe = _cargo_check("dup_probe", "#[account(unsafe(dup))]")
    assert probe.returncode != 0, (
        "The accounts derive still accepts `#[account(unsafe(dup))]`: a struct "
        "using the per-field alias-override attribute compiled successfully. "
        "The dispatch-time duplicate-mutable escape hatch must be removed — "
        "alias safety is now enforced per-account at lend time, so the derive "
        "should refuse this attribute at macro-expansion time.\n\n"
        f"--- cargo check stdout (last 120 lines) ---\n{_tail(probe.stdout)}\n"
        f"--- cargo check stderr (last 120 lines) ---\n{_tail(probe.stderr)}"
    )
