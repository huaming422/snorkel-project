#!/usr/bin/env bash
# No services to start, no data to seed: the image pre-warms the cargo
# registry cache and compiles the `anchor-lang` crate's host tests under the
# `testing` feature at the base commit, and the verifier is self-contained.
set -euo pipefail

echo "[test-setup] Rust version:    $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:   $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Workspace root:  /repo/anchor"
echo "[test-setup] Crate under test: anchor-lang (lang-v2), feature: testing"
echo "[test-setup] Setup complete."
