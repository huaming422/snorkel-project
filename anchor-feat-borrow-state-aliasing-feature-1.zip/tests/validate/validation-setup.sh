#!/usr/bin/env bash
# Validation setup for anchor-feat-borrow-state-aliasing.
#
# The cargo-test validation driver injects the validation agent's test file
# plus a generated `validation_params.rs` helper into `lang-v2/tests/`. That
# helper deserialises the immutable params file with `serde` + `serde_json`
# (`use serde::Deserialize; use serde_json::Value;`), but the account layer
# ships neither — they are not runtime dependencies of a BPF account library.
# This script makes them available as DEV-dependencies of the `lang-v2` crate
# so the injected test binary compiles, then warms the build and smoke-guards
# the environment.
#
# Both packages are already pinned in the workspace `Cargo.lock` (serde
# 1.0.229, serde_json 1.0.151, used transitively elsewhere), and the image
# baked the full registry closure via `cargo fetch --locked`, so adding these
# edges resolves entirely from the warm cache — no network required. (The
# validation phase does have network as a fallback.)
#
# Idempotent: re-running is a no-op once the dev-deps block is present.
# Fails loudly: every step is checked and a broken environment exits non-zero
# so the trial is invalidated rather than silently scored 0.
set -euo pipefail

REPO=/repo/anchor
CRATE="$REPO/lang-v2"
MANIFEST="$CRATE/Cargo.toml"
MARKER="# validation-setup: serde dev-deps for the cargo-test params helper"

# Directory this script ships in (…/tests/validate), used to locate the
# committed scaffold module shipped alongside it.
SETUP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HARNESS_SRC="$SETUP_DIR/val_harness.rs"
HARNESS_DST="$CRATE/tests/val_harness.rs"

# --- Pin the toolchain ahead of any stray version on PATH ------------------
export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
export PATH="$CARGO_HOME/bin:$PATH"

echo "validation-setup: rustc=$(rustc --version 2>&1 | head -1)"
echo "validation-setup: cargo=$(cargo --version 2>&1 | head -1)"

test -f "$MANIFEST" || {
    echo "ERROR: account-layer manifest missing at $MANIFEST" >&2
    exit 1
}

# --- Add serde + serde_json as dev-dependencies (idempotent) ---------------
# Appended as a trailing [dev-dependencies] table. The manifest has no existing
# dev-dependencies section; a trailing table after the [[test]] array entries
# is valid TOML. Version reqs are loose ("1") so cargo picks the already-locked
# 1.x releases rather than forcing a lockfile bump.
if grep -qF "$MARKER" "$MANIFEST"; then
    echo "validation-setup: dev-deps already present; skipping manifest edit"
else
    echo "validation-setup: adding serde + serde_json dev-dependencies to lang-v2"
    cat >> "$MANIFEST" <<EOF

$MARKER
[dev-dependencies]
serde = { version = "1", features = ["derive"] }
serde_json = "1"
EOF
fi

# --- Install the committed scaffold module into the crate's tests dir -------
# The per-story files pull framework plumbing in through `mod val_harness;`,
# which (because each integration-test file is a crate root) resolves to this
# sibling in `tests/`. Installed here, before the pre-validation checkpoint, so
# it is part of the baseline the integrity check compares against — it is author
# scaffold, not a validation-agent edit. Idempotent overwrite keeps re-runs
# clean.
test -f "$HARNESS_SRC" || {
    echo "ERROR: scaffold module missing at $HARNESS_SRC" >&2
    exit 1
}
mkdir -p "$CRATE/tests"
cp -f "$HARNESS_SRC" "$HARNESS_DST"
echo "validation-setup: installed scaffold module at $HARNESS_DST"

# --- Warm the library build offline-first, with a logged online fallback ---
# Build only the account-layer LIBRARY under the testing feature. This warms
# the agent's own source changes (what every per-story `cargo test --test
# <story>` recompiles) without coupling this setup's success to any unrelated
# pre-existing test file in the submission. The serde dev-deps are resolved and
# warmed by the smoke-guard probe below, which compiles a test target and so
# updates Cargo.lock with the new dev-dep edges.
echo "validation-setup: warming library build (offline-first) under the testing feature..."
if ( cd "$CRATE" && cargo build --offline -p anchor-lang --features testing --lib ) \
        > /tmp/validation-setup-build.log 2>&1; then
    echo "validation-setup: offline library build OK"
else
    echo "validation-setup: offline library build incomplete, retrying with network..." >&2
    tail -20 /tmp/validation-setup-build.log >&2 || true
    ( cd "$CRATE" && cargo build -p anchor-lang --features testing --lib ) \
        > /tmp/validation-setup-build.log 2>&1 || {
        echo "ERROR: cargo library build failed even with network; see log below" >&2
        tail -60 /tmp/validation-setup-build.log >&2
        exit 1
    }
    echo "validation-setup: networked library build OK"
fi

# --- Smoke guard -----------------------------------------------------------
# Compile a throwaway test that imports exactly what the generated params
# helper needs — `serde::Deserialize`, `serde_json::Value`, and the public
# `anchor_lang::testing` scaffold the stories build on. `--no-run` compiles but
# does not execute; a clean compile proves the dev-deps resolved, the testing
# feature is wired, and the scaffold is importable. Any failure exits non-zero.
PROBE_NAME="_vsetup_env_probe"
PROBE_FILE="$CRATE/tests/${PROBE_NAME}.rs"
cleanup() { rm -f "$PROBE_FILE"; }
trap cleanup EXIT

cat > "$PROBE_FILE" <<'EOF'
// Throwaway environment probe written by validation-setup.sh. Confirms the
// serde dev-deps and the public testing scaffold compile together, exactly as
// the generated params helper + validation test will. Removed after setup.
use serde::Deserialize;
use serde_json::Value;

#[derive(Debug, Deserialize)]
struct _Probe {
    _inputs: Value,
}

#[allow(dead_code)]
fn _touch() {
    // Reference the public testing scaffold so a missing/renamed re-export
    // surfaces here rather than mid-validation.
    let _ = anchor_lang::testing::MIN_ACCOUNT_BUF;
    let _ = core::any::type_name::<_Probe>();
}

#[test]
fn _vsetup_env_probe_compiles() {
    assert!(true);
}
EOF

echo "validation-setup: smoke-guarding the serde + testing-scaffold environment..."
if ( cd "$CRATE" && cargo test --offline --features testing \
        --test "$PROBE_NAME" --no-run ) > /tmp/validation-setup-probe.log 2>&1; then
    echo "validation-setup: smoke guard passed (offline)"
elif ( cd "$CRATE" && cargo test --features testing \
        --test "$PROBE_NAME" --no-run ) > /tmp/validation-setup-probe.log 2>&1; then
    echo "validation-setup: smoke guard passed (network fallback)"
else
    echo "ERROR: environment smoke guard failed — serde dev-deps or the" >&2
    echo "       testing scaffold did not compile. Validation cannot run." >&2
    tail -60 /tmp/validation-setup-probe.log >&2
    exit 1
fi

# --- Compile-guard the committed scaffold module ---------------------------
# `tests/val_harness.rs` is auto-discovered as its own integration-test target,
# so it is type-checked standalone here. A broken scaffold therefore fails setup
# loudly (invalidating the trial) instead of surfacing as a confusing per-story
# compile error during validation.
echo "validation-setup: compile-guarding the scaffold module..."
if ( cd "$CRATE" && cargo test --offline --features testing \
        --test val_harness --no-run ) > /tmp/validation-setup-harness.log 2>&1; then
    echo "validation-setup: scaffold compile guard passed (offline)"
elif ( cd "$CRATE" && cargo test --features testing \
        --test val_harness --no-run ) > /tmp/validation-setup-harness.log 2>&1; then
    echo "validation-setup: scaffold compile guard passed (network fallback)"
else
    echo "ERROR: scaffold module failed to compile. Validation cannot run." >&2
    tail -80 /tmp/validation-setup-harness.log >&2
    exit 1
fi

echo "validation-setup: done."
