#!/usr/bin/env python3
"""
apply_harness.py - installs the test scaffolding for turso-fix-stale-overflow-cells.

Installs the yield-injection plumbing and the regression tests into the checked
out turso_core tree, so the verifier can run those named lib tests.

Why not `git apply`: the tests live inside core/storage/btree.rs's `mod tests`
and use crate-private internals, so they cannot be an external integration test.
The scaffolding (a cfg-gated yield point, cursor fields, wiring and the test
module additions) is not part of the checkout. Code near the `impl Drop for
BTreeCursor` region sits right next to one scaffolding block (`impl
ProvidesYieldContext`), so applying it as a diff with context would fail
whenever that region changes. Each block is inserted relative to anchor lines instead, and
every edit is idempotent and checked afterwards.

All inserted code is gated behind `#[cfg(any(test, injected_yields))]`; under
`cargo test` the `test` cfg turns it on with no extra feature flag.

Exits non-zero if an anchor is missing or ambiguous, or if a block is already
present in a conflicting form, so a mis-apply can never turn into a pass.
"""
import sys
from pathlib import Path

REPO = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("/repo/turso")
BTREE = REPO / "core/storage/btree.rs"
EXECUTE = REPO / "core/vdbe/execute.rs"


def die(msg):
    print(f"[apply_harness] FATAL: {msg}", file=sys.stderr)
    sys.exit(3)


def insert_after(text, anchor, block, *, what):
    """Insert block immediately after the (unique) anchor line's end."""
    n = text.count(anchor)
    if n == 0:
        die(f"anchor for {what} not found: {anchor!r}")
    if n > 1:
        die(f"anchor for {what} is ambiguous ({n} matches): {anchor!r}")
    idx = text.index(anchor) + len(anchor)
    return text[:idx] + block + text[idx:]


def insert_before(text, anchor, block, *, what):
    n = text.count(anchor)
    if n == 0:
        die(f"anchor for {what} not found: {anchor!r}")
    if n > 1:
        die(f"anchor for {what} is ambiguous ({n} matches): {anchor!r}")
    idx = text.index(anchor)
    return text[:idx] + block + text[idx:]


def replace_once(text, old, new, *, what):
    n = text.count(old)
    if n == 0:
        die(f"replacement target for {what} not found")
    if n > 1:
        die(f"replacement target for {what} is ambiguous ({n} matches)")
    return text.replace(old, new, 1)


def already(text, marker, *, what):
    if marker in text:
        die(f"{what} already present in checkout (marker {marker!r}); the "
            f"yield-injection scaffolding is installed only by this script.")


# ---- scaffolding blocks (yield point, cursor wiring and the regression tests) ----
B_IMPORTS = "#[cfg(any(test, injected_yields))]\nuse crate::mvcc::yield_hooks::{ProvidesYieldContext, YieldContext, YieldPointMarker};\nuse crate::mvcc::yield_points::inject_io_yield;"
B_YIELDMARKER = "#[cfg(any(test, injected_yields))]\n#[derive(Debug, Clone, Copy)]\n#[repr(u8)]\npub(crate) enum BTreeWriteYieldPoint {\n    AfterInsertOverflowCellBeforeBalance,\n}\n\n#[cfg(any(test, injected_yields))]\nconst BTREE_WRITE_YIELD_FAMILY: u64 = 0x4254_5245_5752_4954;\n\n#[cfg(any(test, injected_yields))]\nimpl YieldPointMarker for BTreeWriteYieldPoint {\n    const POINT_COUNT: u8 = 1;\n\n    fn ordinal(self) -> u8 {\n        self as u8\n    }\n}"
B_STRUCTFIELDS = "    #[cfg(any(test, injected_yields))]\n    yield_injector: Option<Arc<dyn crate::mvcc::yield_points::YieldInjector>>,\n    #[cfg(any(test, injected_yields))]\n    yield_instance_id: u64,"
B_INITIALIZERS = "            #[cfg(any(test, injected_yields))]\n            yield_injector: None,\n            #[cfg(any(test, injected_yields))]\n            yield_instance_id: 0,"
B_INSTALL = "    #[cfg(any(test, injected_yields))]\n    pub(crate) fn install_yield_context(&mut self, connection: &crate::Connection) {\n        self.yield_injector = connection.yield_injector();\n        self.yield_instance_id = connection.next_yield_instance_id();\n    }"
B_INJECT = "                        inject_io_yield!(\n                            self,\n                            BTreeWriteYieldPoint::AfterInsertOverflowCellBeforeBalance\n                        );"
B_PROVIDES = "#[cfg(any(test, injected_yields))]\nimpl ProvidesYieldContext for BTreeCursor {\n    fn yield_context(&self) -> YieldContext {\n        YieldContext::new(\n            self.yield_injector.clone(),\n            None,\n            self.yield_instance_id,\n            BTREE_WRITE_YIELD_FAMILY ^ self.root_page as u64,\n        )\n    }\n}"
B_TESTUSE_MVCC = "        mvcc::{\n            yield_hooks::YieldPointMarker,\n            yield_points::{YieldInjector, YieldPoint},\n        },"
B_STDIMPORT_NEW = "    use std::{\n        mem::transmute,\n        ops::Deref,\n        sync::{\n            atomic::{AtomicBool, Ordering},\n            Arc,\n        },\n    };"
B_INJECTOR = "    #[derive(Debug)]\n    struct TargetedYieldInjector {\n        point: YieldPoint,\n        selection_key: u64,\n        fired: AtomicBool,\n    }\n\n    impl TargetedYieldInjector {\n        fn new(point: YieldPoint, selection_key: u64) -> Arc<Self> {\n            Arc::new(Self {\n                point,\n                selection_key,\n                fired: AtomicBool::new(false),\n            })\n        }\n\n        fn fired(&self) -> bool {\n            self.fired.load(Ordering::Acquire)\n        }\n    }\n\n    impl YieldInjector for TargetedYieldInjector {\n        fn should_yield(&self, _instance_id: u64, selection_key: u64, point: YieldPoint) -> bool {\n            point == self.point\n                && selection_key == self.selection_key\n                && !self.fired.swap(true, Ordering::AcqRel)\n        }\n    }\n\n    fn btree_write_selection_key(root_page: i64) -> u64 {\n        BTREE_WRITE_YIELD_FAMILY ^ root_page as u64\n    }\n\n    fn query_single_i64(conn: &Arc<Connection>, sql: &str) -> i64 {\n        let mut stmt = conn.prepare(sql).unwrap();\n        match stmt.step().unwrap() {\n            StepResult::Row => stmt.row().unwrap().get::<i64>(0).unwrap(),\n            other => panic!(\"expected a row, got {other:?}\"),\n        }\n    }\n\n    fn query_single_text(conn: &Arc<Connection>, sql: &str) -> String {\n        let mut stmt = conn.prepare(sql).unwrap();\n        match stmt.step().unwrap() {\n            StepResult::Row => stmt.row().unwrap().get::<String>(0).unwrap(),\n            other => panic!(\"expected a row, got {other:?}\"),\n        }\n    }"
B_TESTS = "    #[test]\n    fn wal_reuses_freelist_leaf_after_abandoned_overflowing_insert() {\n        #[allow(clippy::arc_with_non_send_sync)]\n        let io: Arc<dyn IO> = Arc::new(MemoryIO::new());\n        let db = Database::open_file(io, \"freelist-stale-overflow.db\").unwrap();\n        let conn = db.connect().unwrap();\n\n        conn.execute(\"PRAGMA journal_mode = WAL\").unwrap();\n        conn.execute(\n            \"CREATE TABLE red_rain_308 (\n                slow_desk_238 INTEGER NOT NULL,\n                quiet_tree_398 TEXT NOT NULL,\n                smart_dog_422 REAL UNIQUE,\n                new_hill_140 TEXT,\n                light_door_957 REAL,\n                wild_dog_803 TEXT NOT NULL,\n                new_flower_28 BLOB,\n                old_fish_931 TEXT PRIMARY KEY\n            )\",\n        )\n        .unwrap();\n        conn.execute(\n            \"CREATE TABLE full_fish_194 (\n                brave_star_722 TEXT PRIMARY KEY,\n                hot_star_957 NUMERIC,\n                empty_chair_834 REAL\n            )\",\n        )\n        .unwrap();\n\n        conn.execute(\n            \"INSERT INTO red_rain_308 (\n                slow_desk_238, quiet_tree_398, smart_dog_422, new_hill_140,\n                light_door_957, wild_dog_803, new_flower_28, old_fish_931\n            ) VALUES (\n                1, 'seed', 0.24, 'seed', 1.0, 'seed', zeroblob(3600), 'existing_unique'\n            )\",\n        )\n        .unwrap();\n        for id in 2..260 {\n            conn.execute(format!(\n                \"INSERT INTO red_rain_308 (\n                    slow_desk_238, quiet_tree_398, smart_dog_422, new_hill_140,\n                    light_door_957, wild_dog_803, new_flower_28, old_fish_931\n                ) VALUES (\n                    {id}, 'quiet_tree_{id}', {id}.0, 'new_hill_{id}',\n                    1.5, 'wild_dog_{id}', zeroblob(3600), 'seed_{id}'\n                )\"\n            ))\n            .unwrap();\n        }\n\n        conn.execute(\"BEGIN\").unwrap();\n        conn.execute(\"DELETE FROM red_rain_308 WHERE old_fish_931 = 'seed_2'\")\n            .unwrap();\n        conn.execute(\"SAVEPOINT sp_91\").unwrap();\n        conn.execute(\n            \"INSERT INTO full_fish_194 (brave_star_722, hot_star_957, empty_chair_834)\n             VALUES ('sweet_fish_597', 328, 7.71)\",\n        )\n        .unwrap();\n\n        let red_rain_root_page = query_single_i64(\n            &conn,\n            \"SELECT rootpage FROM sqlite_schema\n             WHERE type = 'table' AND name = 'red_rain_308'\",\n        );\n        let injector = TargetedYieldInjector::new(\n            BTreeWriteYieldPoint::AfterInsertOverflowCellBeforeBalance.point(),\n            btree_write_selection_key(red_rain_root_page),\n        );\n        conn.set_yield_injector(Some(injector.clone()));\n        let mut abandoned = conn\n            .prepare(\n                \"INSERT INTO red_rain_308 (\n                    slow_desk_238, quiet_tree_398, smart_dog_422, new_hill_140,\n                    light_door_957, wild_dog_803, new_flower_28, old_fish_931\n                ) VALUES (\n                    926, 'dry_hill_411', 9.24, 'blue_hill_65',\n                    7.50, 'happy_moon_474', zeroblob(7200), 'smart_rock_113'\n                )\",\n            )\n            .unwrap();\n        assert!(matches!(abandoned.step().unwrap(), StepResult::Yield));\n        assert!(injector.fired());\n        abandoned.reset().unwrap();\n        drop(abandoned);\n        conn.set_yield_injector(None);\n\n        conn.execute(\"DELETE FROM red_rain_308 WHERE slow_desk_238 BETWEEN 2 AND 240\")\n            .unwrap();\n        conn.execute(\"RELEASE sp_91\").unwrap();\n\n        assert!(conn\n            .execute(\n                \"INSERT INTO red_rain_308 (\n                    slow_desk_238, quiet_tree_398, smart_dog_422, new_hill_140,\n                    light_door_957, wild_dog_803, new_flower_28, old_fish_931\n                ) VALUES (\n                    927, 'dry_hill_412', 0.24, 'blue_hill_66',\n                    7.50, 'happy_moon_475', x'736f66745f73746f6e655f313732', 'smart_rock_114'\n                )\"\n            )\n            .is_err());\n\n        for id in 300..420 {\n            conn.execute(format!(\n                \"INSERT INTO red_rain_308 (\n                    slow_desk_238, quiet_tree_398, smart_dog_422, new_hill_140,\n                    light_door_957, wild_dog_803, new_flower_28, old_fish_931\n                ) VALUES (\n                    {id}, 'quiet_tree_{id}', {id}.0, 'new_hill_{id}',\n                    1.5, 'wild_dog_{id}', zeroblob(3600), 'reuse_{id}'\n                )\"\n            ))\n            .unwrap();\n        }\n\n        conn.execute(\"ROLLBACK\").unwrap();\n        assert_eq!(query_single_text(&conn, \"PRAGMA integrity_check\"), \"ok\");\n    }\n\n    #[test]\n    fn wal_reuses_freed_leaf_after_abandoned_insert_with_open_reader() {\n        #[allow(clippy::arc_with_non_send_sync)]\n        let io: Arc<dyn IO> = Arc::new(MemoryIO::new());\n        let db = Database::open_file(io, \"open-reader-stale-overflow.db\").unwrap();\n        let conn = db.connect().unwrap();\n\n        conn.execute(\"PRAGMA journal_mode = WAL\").unwrap();\n        conn.execute(\n            \"CREATE TABLE red_rain_308 (\n                slow_desk_238 INTEGER PRIMARY KEY,\n                quiet_tree_398 TEXT NOT NULL,\n                new_flower_28 BLOB,\n                old_fish_931 TEXT\n            )\",\n        )\n        .unwrap();\n        conn.execute(\"CREATE TABLE full_fish_194 (brave_star_722 TEXT, hot_star_957 NUMERIC)\")\n            .unwrap();\n        for i in 0..5 {\n            conn.execute(format!(\"INSERT INTO full_fish_194 VALUES ('calm_lake_{i}', {i})\"))\n                .unwrap();\n        }\n        for id in 1..260 {\n            conn.execute(format!(\n                \"INSERT INTO red_rain_308 VALUES ({id}, 'quiet_tree_{id}', zeroblob(3600), 'seed_{id}')\"\n            ))\n            .unwrap();\n        }\n\n        let mut reader = conn\n            .prepare(\"SELECT brave_star_722 FROM full_fish_194\")\n            .unwrap();\n        assert!(matches!(reader.step().unwrap(), StepResult::Row));\n\n        let red_rain_root_page = query_single_i64(\n            &conn,\n            \"SELECT rootpage FROM sqlite_schema\n             WHERE type = 'table' AND name = 'red_rain_308'\",\n        );\n        let injector = TargetedYieldInjector::new(\n            BTreeWriteYieldPoint::AfterInsertOverflowCellBeforeBalance.point(),\n            btree_write_selection_key(red_rain_root_page),\n        );\n        conn.set_yield_injector(Some(injector.clone()));\n        let mut abandoned = conn\n            .prepare(\n                \"INSERT INTO red_rain_308 VALUES (926, 'dry_hill_411', zeroblob(2000), 'smart_rock_113')\",\n            )\n            .unwrap();\n        assert!(matches!(abandoned.step().unwrap(), StepResult::Yield));\n        assert!(injector.fired());\n        abandoned.reset().unwrap();\n        drop(abandoned);\n        conn.set_yield_injector(None);\n\n        conn.execute(\"DELETE FROM red_rain_308 WHERE slow_desk_238 BETWEEN 2 AND 240\")\n            .unwrap();\n        for id in 300..420 {\n            conn.execute(format!(\n                \"INSERT INTO red_rain_308 VALUES ({id}, 'quiet_tree_{id}', zeroblob(3600), 'reuse_{id}')\"\n            ))\n            .unwrap();\n        }\n\n        let mut rows_read = 1;\n        loop {\n            match reader.step().unwrap() {\n                StepResult::Row => rows_read += 1,\n                StepResult::Done => break,\n                other => panic!(\"reader stepped to {other:?}\"),\n            }\n        }\n        drop(reader);\n        assert_eq!(rows_read, 5);\n\n        assert_eq!(query_single_text(&conn, \"PRAGMA integrity_check\"), \"ok\");\n        assert_eq!(\n            query_single_i64(&conn, \"SELECT COUNT(*) FROM red_rain_308 WHERE slow_desk_238 = 926\"),\n            0\n        );\n        assert_eq!(query_single_i64(&conn, \"SELECT COUNT(*) FROM red_rain_308\"), 140);\n    }\n\n    #[test]\n    fn wal_overflowing_insert_resumes_after_yield_before_balance() {\n        #[allow(clippy::arc_with_non_send_sync)]\n        let io: Arc<dyn IO> = Arc::new(MemoryIO::new());\n        let db = Database::open_file(io, \"resume-overflow-yield.db\").unwrap();\n        let conn = db.connect().unwrap();\n\n        conn.execute(\"PRAGMA journal_mode = WAL\").unwrap();\n        conn.execute(\n            \"CREATE TABLE red_rain_308 (\n                slow_desk_238 INTEGER NOT NULL,\n                quiet_tree_398 TEXT NOT NULL,\n                smart_dog_422 REAL UNIQUE,\n                new_hill_140 TEXT,\n                light_door_957 REAL,\n                wild_dog_803 TEXT NOT NULL,\n                new_flower_28 BLOB,\n                old_fish_931 TEXT PRIMARY KEY\n            )\",\n        )\n        .unwrap();\n\n        for id in 1..260 {\n            conn.execute(format!(\n                \"INSERT INTO red_rain_308 (\n                    slow_desk_238, quiet_tree_398, smart_dog_422, new_hill_140,\n                    light_door_957, wild_dog_803, new_flower_28, old_fish_931\n                ) VALUES (\n                    {id}, 'quiet_tree_{id}', {id}.0, 'new_hill_{id}',\n                    1.5, 'wild_dog_{id}', zeroblob(3600), 'seed_{id}'\n                )\"\n            ))\n            .unwrap();\n        }\n\n        let red_rain_root_page = query_single_i64(\n            &conn,\n            \"SELECT rootpage FROM sqlite_schema\n             WHERE type = 'table' AND name = 'red_rain_308'\",\n        );\n        let injector = TargetedYieldInjector::new(\n            BTreeWriteYieldPoint::AfterInsertOverflowCellBeforeBalance.point(),\n            btree_write_selection_key(red_rain_root_page),\n        );\n        conn.set_yield_injector(Some(injector.clone()));\n        let mut stmt = conn\n            .prepare(\n                \"INSERT INTO red_rain_308 (\n                    slow_desk_238, quiet_tree_398, smart_dog_422, new_hill_140,\n                    light_door_957, wild_dog_803, new_flower_28, old_fish_931\n                ) VALUES (\n                    926, 'dry_hill_411', 9.24, 'blue_hill_65',\n                    7.50, 'happy_moon_474', zeroblob(7200), 'smart_rock_113'\n                )\",\n            )\n            .unwrap();\n\n        assert!(matches!(stmt.step().unwrap(), StepResult::Yield));\n        assert!(injector.fired());\n        assert!(matches!(stmt.step().unwrap(), StepResult::Done));\n        drop(stmt);\n        conn.set_yield_injector(None);\n\n        assert_eq!(\n            query_single_i64(\n                &conn,\n                \"SELECT COUNT(*) FROM red_rain_308 WHERE old_fish_931 = 'smart_rock_113'\",\n            ),\n            1\n        );\n        assert_eq!(query_single_text(&conn, \"PRAGMA integrity_check\"), \"ok\");\n    }\n\n    #[test]\n    fn wal_suspended_insert_resumes_after_reads_on_same_table() {\n        #[allow(clippy::arc_with_non_send_sync)]\n        let io: Arc<dyn IO> = Arc::new(MemoryIO::new());\n        let db = Database::open_file(io, \"resume-after-reads.db\").unwrap();\n        let conn = db.connect().unwrap();\n\n        conn.execute(\"PRAGMA journal_mode = WAL\").unwrap();\n        conn.execute(\n            \"CREATE TABLE red_rain_308 (\n                slow_desk_238 INTEGER PRIMARY KEY,\n                quiet_tree_398 TEXT NOT NULL,\n                new_flower_28 BLOB,\n                old_fish_931 TEXT\n            )\",\n        )\n        .unwrap();\n        for id in 1..260 {\n            conn.execute(format!(\n                \"INSERT INTO red_rain_308 VALUES ({id}, 'quiet_tree_{id}', zeroblob(3600), 'seed_{id}')\"\n            ))\n            .unwrap();\n        }\n\n        let red_rain_root_page = query_single_i64(\n            &conn,\n            \"SELECT rootpage FROM sqlite_schema\n             WHERE type = 'table' AND name = 'red_rain_308'\",\n        );\n        let injector = TargetedYieldInjector::new(\n            BTreeWriteYieldPoint::AfterInsertOverflowCellBeforeBalance.point(),\n            btree_write_selection_key(red_rain_root_page),\n        );\n        conn.set_yield_injector(Some(injector.clone()));\n        let mut stmt = conn\n            .prepare(\n                \"INSERT INTO red_rain_308 VALUES (1000, 'dry_hill_411', zeroblob(2000), 'smart_rock_113')\",\n            )\n            .unwrap();\n        assert!(matches!(stmt.step().unwrap(), StepResult::Yield));\n        assert!(injector.fired());\n        conn.set_yield_injector(None);\n\n        for sql in [\n            \"SELECT old_fish_931 FROM red_rain_308 WHERE slow_desk_238 = 259\",\n            \"SELECT old_fish_931 FROM red_rain_308 WHERE slow_desk_238 > 250\",\n        ] {\n            let mut reader = conn.prepare(sql).unwrap();\n            loop {\n                match reader.step().unwrap() {\n                    StepResult::Row => {}\n                    StepResult::Done => break,\n                    other => panic!(\"reader stepped to {other:?}\"),\n                }\n            }\n        }\n\n        loop {\n            match stmt.step().unwrap() {\n                StepResult::Done => break,\n                other => panic!(\"resumed insert stepped to {other:?}\"),\n            }\n        }\n        drop(stmt);\n\n        assert_eq!(\n            query_single_i64(\n                &conn,\n                \"SELECT COUNT(*) FROM red_rain_308 WHERE old_fish_931 = 'smart_rock_113'\",\n            ),\n            1\n        );\n        assert_eq!(query_single_i64(&conn, \"SELECT COUNT(*) FROM red_rain_308\"), 260);\n        assert_eq!(query_single_text(&conn, \"PRAGMA integrity_check\"), \"ok\");\n    }"

B_TEST_TWO_SUSPENDED = """    fn run_two_suspended_inserts(db_file: &str, drop_earlier: bool) {
        #[allow(clippy::arc_with_non_send_sync)]
        let io: Arc<dyn IO> = Arc::new(MemoryIO::new());
        let db = Database::open_file(io, db_file).unwrap();
        let conn = db.connect().unwrap();

        conn.execute("PRAGMA journal_mode = WAL").unwrap();
        for table in ["red_rain_308", "blue_lake_512"] {
            conn.execute(format!(
                "CREATE TABLE {table} (
                    slow_desk_238 INTEGER PRIMARY KEY,
                    quiet_tree_398 TEXT NOT NULL,
                    new_flower_28 BLOB,
                    old_fish_931 TEXT
                )"
            ))
            .unwrap();
            for id in 1..260 {
                conn.execute(format!(
                    "INSERT INTO {table} VALUES ({id}, 'quiet_tree_{id}', zeroblob(3600), 'seed_{id}')"
                ))
                .unwrap();
            }
        }

        conn.execute("BEGIN").unwrap();
        let mut suspended = Vec::new();
        for table in ["red_rain_308", "blue_lake_512"] {
            let root_page = query_single_i64(
                &conn,
                &format!("SELECT rootpage FROM sqlite_schema WHERE type = 'table' AND name = '{table}'"),
            );
            let injector = TargetedYieldInjector::new(
                BTreeWriteYieldPoint::AfterInsertOverflowCellBeforeBalance.point(),
                btree_write_selection_key(root_page),
            );
            conn.set_yield_injector(Some(injector.clone()));
            let mut stmt = conn
                .prepare(&format!(
                    "INSERT INTO {table} VALUES (1000, 'dry_hill_411', zeroblob(2000), 'smart_rock_113')"
                ))
                .unwrap();
            let step = stmt.step().unwrap();
            assert!(
                matches!(step, StepResult::Yield),
                "insert on {table} stepped to {step:?} instead of pausing"
            );
            assert!(injector.fired());
            conn.set_yield_injector(None);
            suspended.push((table, stmt));
        }

        let (dropped_table, mut dropped) = suspended.remove(if drop_earlier { 0 } else { 1 });
        let (kept_table, mut kept) = suspended.remove(0);
        dropped.reset().unwrap();
        drop(dropped);
        loop {
            match kept.step().unwrap() {
                StepResult::Done => break,
                other => panic!("resumed insert stepped to {other:?}"),
            }
        }
        drop(kept);
        conn.execute("COMMIT").unwrap();

        assert_eq!(
            query_single_i64(&conn, &format!("SELECT COUNT(*) FROM {kept_table} WHERE slow_desk_238 = 1000")),
            1
        );
        assert_eq!(
            query_single_i64(&conn, &format!("SELECT COUNT(*) FROM {dropped_table} WHERE slow_desk_238 = 1000")),
            0
        );
        assert_eq!(query_single_i64(&conn, &format!("SELECT COUNT(*) FROM {kept_table}")), 260);
        assert_eq!(query_single_i64(&conn, &format!("SELECT COUNT(*) FROM {dropped_table}")), 259);
        assert_eq!(query_single_text(&conn, "PRAGMA integrity_check"), "ok");
    }

    #[test]
    fn wal_suspended_insert_resumes_after_another_insert_is_dropped() {
        run_two_suspended_inserts("two-suspended-later-dropped.db", false);
        run_two_suspended_inserts("two-suspended-earlier-dropped.db", true);
    }"""

E_HELPER = "#[inline]\nfn btree_cursor_with_yield_context(\n    cursor: Box<BTreeCursor>,\n    connection: &Arc<Connection>,\n) -> Box<BTreeCursor> {\n    #[cfg(any(test, injected_yields))]\n    {\n        let mut cursor = cursor;\n        cursor.install_yield_context(connection);\n        cursor\n    }\n    #[cfg(not(any(test, injected_yields)))]\n    {\n        let _ = connection;\n        cursor\n    }\n}"
E_STDIMPORT_OLD = "    use std::{mem::transmute, ops::Deref, sync::Arc};"
E_CALL1_OLD = "            let btree_cursor = Box::new(BTreeCursor::new_index(\n                pager,\n                maybe_transform_root_page_to_positive(mv_store.as_ref(), root_page),\n                index.as_ref(),\n                num_columns,\n            )?);"
E_CALL1_NEW = "            let btree_cursor = btree_cursor_with_yield_context(\n                Box::new(BTreeCursor::new_index(\n                    pager,\n                    maybe_transform_root_page_to_positive(mv_store.as_ref(), root_page),\n                    index.as_ref(),\n                    num_columns,\n                )?),\n                &program.connection,\n            );"
E_MATCH_OLD = "            let btree_cursor: Box<dyn CursorTrait> = match cursor_type {\n                CursorType::BTreeTable(table_rc) if !table_rc.has_rowid => {\n                    Box::new(BTreeCursor::new_without_rowid_table(\n                        pager,\n                        maybe_transform_root_page_to_positive(mv_store.as_ref(), root_page),\n                        table_rc.as_ref(),\n                        num_columns,\n                    ))\n                }\n                _ => Box::new(BTreeCursor::new_table(\n                    pager,\n                    maybe_transform_root_page_to_positive(mv_store.as_ref(), root_page),\n                    num_columns,\n                )),\n            };"
E_MATCH_NEW = "            let btree_cursor: Box<dyn CursorTrait> = match cursor_type {\n                CursorType::BTreeTable(table_rc) if !table_rc.has_rowid => {\n                    btree_cursor_with_yield_context(\n                        Box::new(BTreeCursor::new_without_rowid_table(\n                            pager,\n                            maybe_transform_root_page_to_positive(mv_store.as_ref(), root_page),\n                            table_rc.as_ref(),\n                            num_columns,\n                        )),\n                        &program.connection,\n                    )\n                }\n                _ => btree_cursor_with_yield_context(\n                    Box::new(BTreeCursor::new_table(\n                        pager,\n                        maybe_transform_root_page_to_positive(mv_store.as_ref(), root_page),\n                        num_columns,\n                    )),\n                    &program.connection,\n                ),\n            };"


def patch_btree():
    if not BTREE.is_file():
        die(f"missing {BTREE}")
    t = BTREE.read_text()

    # Guard: the scaffolding must not already be in the checkout.
    already(t, "BTreeWriteYieldPoint", what="yield-point marker")
    already(t, "install_yield_context", what="yield-context installer")
    already(t, "TargetedYieldInjector", what="test injector")
    already(t, "wal_reuses_freelist_leaf_after_abandoned_overflowing_insert",
            what="reuse regression test")

    # Site 1: imports - after the `#[cfg(test)] use crate::alloc::TursoIteratorExt;`
    a_imports = "#[cfg(test)]\nuse crate::alloc::TursoIteratorExt;"
    t = insert_after(t, a_imports, "\n" + B_IMPORTS, what="btree imports")

    # Site 2: yield-point marker - before the sibling `struct ReadPayloadOverflow {`
    a_rpo = "struct ReadPayloadOverflow {"
    t = insert_before(t, a_rpo, B_YIELDMARKER + "\n\n", what="yield-point marker")

    # Site 3: BTreeCursor struct fields - after the `did_register` field decl
    a_field = "    did_register: crate::sync::atomic::AtomicBool,"
    t = insert_after(t, a_field, "\n" + B_STRUCTFIELDS, what="cursor fields")

    # Site 4a: initializers - after the `did_register: ...::new(false),` initializer
    a_init = "            did_register: crate::sync::atomic::AtomicBool::new(false),"
    t = insert_after(t, a_init, "\n" + B_INITIALIZERS, what="cursor initializers")

    # Site 4b: install_yield_context method - before `pub fn new_table(`
    a_newtable = "    pub fn new_table(pager: Arc<Pager>, root_page: i64, num_columns: usize) -> Self {"
    t = insert_before(t, a_newtable, B_INSTALL + "\n\n", what="install_yield_context")

    # Site 5: the inject call - after the unique insert-path save_context whose
    # preceding assert says "during insert" (NOT the overwrite one).
    a_inject = ('turso_assert!(matches!(self.balance_state.sub_state, BalanceSubState::Start), '
                '"no balancing operation should be in progress during insert", '
                '{ "state": self.state, "sub_state": self.balance_state.sub_state });\n'
                '                        // If we balance, we must save the cursor position and seek to it later.\n'
                '                        self.save_context(CursorContext::seek_eq_only(bkey));')
    t = insert_after(t, a_inject, "\n" + B_INJECT, what="inject_io_yield call")

    # Site 6: ProvidesYieldContext impl - before `impl Drop for BTreeCursor {`.
    # Edits inside Drop or a new impl block leave the Drop header line in place.
    a_drop = "impl Drop for BTreeCursor {"
    t = insert_before(t, a_drop, B_PROVIDES + "\n\n", what="ProvidesYieldContext impl")

    # Site 8a: test-module mvcc use - after the `io::{Buffer, MemoryIO, OpenFlags, IO},`
    # line inside `mod tests`.
    a_testio = "        io::{Buffer, MemoryIO, OpenFlags, IO},"
    t = insert_after(t, a_testio, "\n" + B_TESTUSE_MVCC, what="test-module mvcc use")

    # Site 8b: widen std import in mod tests
    t = replace_once(t, E_STDIMPORT_OLD, B_STDIMPORT_NEW, what="test-module std import")

    # Site 8c: TargetedYieldInjector + helpers - after the test-module
    # `use super::{btree_init_page, ...};` line.
    a_supers = "    use super::{btree_init_page, defragment_page, drop_cell, insert_into_cell};"
    t = insert_after(t, a_supers, "\n\n" + B_INJECTOR, what="test injector + helpers")

    # Site 8d: the #[test] fns and their helper - before `fn ensure_cell(`
    a_ensure = "    fn ensure_cell(page: &mut PageContent, cell_idx: usize, payload: &Vec<u8>) {"
    t = insert_before(t, a_ensure, B_TESTS + "\n\n" + B_TEST_TWO_SUSPENDED + "\n\n",
                      what="regression tests")

    BTREE.write_text(t)
    print("[apply_harness] btree.rs scaffolding installed")


def patch_execute():
    if not EXECUTE.is_file():
        die(f"missing {EXECUTE}")
    t = EXECUTE.read_text()
    already(t, "btree_cursor_with_yield_context", what="execute wiring helper")

    # helper fn - after `use crate::storage::btree::{BTreeCursor, BTreeKey};`
    a_use = "use crate::storage::btree::{BTreeCursor, BTreeKey};"
    t = insert_after(t, a_use, "\n\n" + E_HELPER, what="execute helper fn")

    # call site 1 (index cursor)
    t = replace_once(t, E_CALL1_OLD, E_CALL1_NEW, what="op_open_write index cursor")
    # call sites 2+3 (table / without-rowid match)
    t = replace_once(t, E_MATCH_OLD, E_MATCH_NEW, what="op_open_write table cursors")

    EXECUTE.write_text(t)
    print("[apply_harness] execute.rs wiring installed")


def main():
    patch_btree()
    patch_execute()
    # Post-conditions: every scaffolding symbol the tests need must now be present.
    bt = BTREE.read_text()
    ex = EXECUTE.read_text()
    required = [
        (bt, "BTreeWriteYieldPoint"),
        (bt, "AfterInsertOverflowCellBeforeBalance"),
        (bt, "install_yield_context"),
        (bt, "impl ProvidesYieldContext for BTreeCursor"),
        (bt, "inject_io_yield!"),
        (bt, "struct TargetedYieldInjector"),
        (bt, "fn wal_reuses_freelist_leaf_after_abandoned_overflowing_insert"),
        (bt, "fn wal_reuses_freed_leaf_after_abandoned_insert_with_open_reader"),
        (bt, "fn wal_overflowing_insert_resumes_after_yield_before_balance"),
        (bt, "fn wal_suspended_insert_resumes_after_reads_on_same_table"),
        (bt, "fn wal_suspended_insert_resumes_after_another_insert_is_dropped"),
        (ex, "fn btree_cursor_with_yield_context"),
    ]
    for hay, needle in required:
        if needle not in hay:
            die(f"post-apply check failed: missing {needle!r}")
    print("[apply_harness] all scaffolding present; OK")


if __name__ == "__main__":
    main()
