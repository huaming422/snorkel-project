#!/usr/bin/env bash
#
# Behavioral verifier for turso-fix-stale-overflow-cells.
#
# Both regression tests must pass:
#   * wal_reuses_freelist_leaf_after_abandoned_overflowing_insert
#     WAL workload: an overflowing insert is suspended before it balances,
#     then reset and dropped; a delete frees the leaf pages it touched and
#     later inserts reuse them. Nothing may panic and the final
#     PRAGMA integrity_check must return "ok".
#   * wal_overflowing_insert_resumes_after_yield_before_balance
#     The same insert suspended at the same point and then resumed must
#     finish and persist its row, with integrity_check still "ok".
#
# Both tests live INSIDE core/storage/btree.rs's `mod tests` and use
# crate-private internals plus a cfg-gated yield-injection hook that is not part
# of the repository checkout. apply_harness.py installs that scaffolding (yield
# point, cursor wiring, the two tests) through stable anchors that sit apart
# from the code under repair.
#
# Exit 0 iff both named tests are reported `... ok` by cargo. Any panic,
# compile error, a scaffolding block already present in the checkout, or a test
# that does not run is a non-zero exit.

set -euo pipefail

REPO="${REPO_DIR:-/repo/turso}"
CRATE_DIR="$REPO/core"
HARNESS="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/apply_harness.py"

echo "[verify] repo=$REPO"
echo "[verify] rustc=$(rustc --version 2>&1 | head -1)"

# ---- 1. install the reproduction scaffolding onto the agent's solved tree ----
# apply_harness.py fails loudly (exit 3) if any anchor is missing/ambiguous, or
# if the agent already added any scaffolding symbol (which would mean the task
# leaked, not that the bug was fixed).
python3 "$HARNESS" "$REPO"

# ---- 2. run exactly the two named lib tests, single-threaded, deterministic ----
# `cargo test <name>` is a substring filter: a filter matching ZERO tests exits 0
# ("running 0 tests"), a false pass. We therefore capture output and assert each
# expected test is individually reported `ok` AND that the summary reports no
# failures and a nonzero number of tests run.
TEST_LOG="$(mktemp)"
trap 'rm -f "$TEST_LOG"' EXIT

set +e
cargo test \
  --locked \
  -p turso_core \
  --lib \
  --manifest-path "$CRATE_DIR/Cargo.toml" \
  -- \
  --test-threads=1 \
  --exact \
  storage::btree::tests::wal_reuses_freelist_leaf_after_abandoned_overflowing_insert \
  storage::btree::tests::wal_overflowing_insert_resumes_after_yield_before_balance \
  2>&1 | tee "$TEST_LOG"
CARGO_STATUS=${PIPESTATUS[0]}
set -e

echo "[verify] cargo exit status: $CARGO_STATUS"

# ---- 3. hard checks: both tests must have RUN and PASSED ----
fail() { echo "[verify] FAIL: $1" >&2; exit 1; }

[ "$CARGO_STATUS" -eq 0 ] || fail "cargo test returned non-zero ($CARGO_STATUS) (compile error, panic, or test failure)"

grep -qE 'test storage::btree::tests::wal_reuses_freelist_leaf_after_abandoned_overflowing_insert \.\.\. ok' "$TEST_LOG" \
  || fail "reuse test did not report ok (missing, panicked, or failed)"
grep -qE 'test storage::btree::tests::wal_overflowing_insert_resumes_after_yield_before_balance \.\.\. ok' "$TEST_LOG" \
  || fail "resume test did not report ok (missing, panicked, or failed)"

# Guard against a vacuous "0 tests" / "0 passed" summary and any reported failure.
grep -qE 'test result: ok\. [1-9][0-9]* passed; 0 failed' "$TEST_LOG" \
  || fail "cargo summary did not show a nonzero passed count with 0 failed"

echo "[verify] PASS: both regression tests passed"
exit 0
