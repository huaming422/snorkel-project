#!/usr/bin/env bash
#
# Behavioral verifier for turso-fix-stale-overflow-cells.
#
# All five regression tests must pass:
#   * wal_reuses_freelist_leaf_after_abandoned_overflowing_insert
#     WAL workload inside one transaction: an overflowing insert is suspended
#     before it balances, then reset and dropped; a delete frees the leaf pages
#     it touched and later inserts reuse them, and the transaction is rolled
#     back. Nothing may panic and PRAGMA integrity_check must return "ok".
#   * wal_reuses_freed_leaf_after_abandoned_insert_with_open_reader
#     The same sequence with no BEGIN, while a SELECT on another table is still
#     open on the connection. Nothing may panic, the select reads all its rows,
#     the abandoned row is absent, the row count is right and integrity_check
#     returns "ok".
#   * wal_overflowing_insert_resumes_after_yield_before_balance
#     The same insert suspended at the same point and then resumed must
#     finish and persist its row, with integrity_check still "ok".
#   * wal_suspended_insert_resumes_after_reads_on_same_table
#     An insert suspended at the same point while two SELECTs on the same table
#     run to the end; resumed afterwards, it must finish and persist its row,
#     with the row count right and integrity_check "ok".
#   * wal_suspended_insert_resumes_after_another_insert_is_dropped
#     Inside one transaction, inserts on two plain tables are both suspended at
#     that point; one is reset and dropped and the other is resumed, once with
#     the later one dropped and once with the earlier one. After COMMIT the
#     resumed row is there, the dropped one is not, both row counts are right
#     and integrity_check is "ok".
#
# The tests live inside core/storage/btree.rs's `mod tests` and use
# crate-private internals plus a cfg-gated yield-injection hook that is not part
# of the repository checkout. apply_harness.py installs that scaffolding (yield
# point, cursor wiring, the tests) through anchor lines.
#
# Exit 0 iff every named test is reported `... ok` by cargo. Any panic,
# compile error, a scaffolding block already present in the checkout, or a test
# that does not run is a non-zero exit.

set -euo pipefail

REPO="${REPO_DIR:-/repo/turso}"
CRATE_DIR="$REPO/core"
HARNESS="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/apply_harness.py"

echo "[verify] repo=$REPO"
echo "[verify] rustc=$(rustc --version 2>&1 | head -1)"

# ---- 1. install the test scaffolding into the checkout ----
# apply_harness.py exits 3 if any anchor is missing or ambiguous, or if a
# scaffolding symbol is already in the checkout.
python3 "$HARNESS" "$REPO"

# ---- 2. run exactly the named lib tests, single-threaded, deterministic ----
# `cargo test <name>` is a substring filter: a filter matching ZERO tests exits 0
# ("running 0 tests"), a false pass. We therefore capture output and assert each
# expected test is individually reported `ok` AND that the summary reports no
# failures with exactly five tests run.
TEST_LOG="$(mktemp)"
trap 'rm -f "$TEST_LOG"' EXIT

set +e
cargo test \
  --locked \
  -p turso_core \
  --lib \
  --manifest-path "$CRATE_DIR/Cargo.toml" \
  -- \
  --test-threads=1 \
  --exact \
  storage::btree::tests::wal_reuses_freelist_leaf_after_abandoned_overflowing_insert \
  storage::btree::tests::wal_reuses_freed_leaf_after_abandoned_insert_with_open_reader \
  storage::btree::tests::wal_overflowing_insert_resumes_after_yield_before_balance \
  storage::btree::tests::wal_suspended_insert_resumes_after_reads_on_same_table \
  storage::btree::tests::wal_suspended_insert_resumes_after_another_insert_is_dropped \
  2>&1 | tee "$TEST_LOG"
CARGO_STATUS=${PIPESTATUS[0]}
set -e

echo "[verify] cargo exit status: $CARGO_STATUS"

# ---- 3. hard checks: every test must have RUN and PASSED ----
fail() { echo "[verify] FAIL: $1" >&2; exit 1; }

[ "$CARGO_STATUS" -eq 0 ] || fail "cargo test returned non-zero ($CARGO_STATUS) (compile error, panic, or test failure)"

grep -qE 'test storage::btree::tests::wal_reuses_freelist_leaf_after_abandoned_overflowing_insert \.\.\. ok' "$TEST_LOG" \
  || fail "reuse test did not report ok (missing, panicked, or failed)"
grep -qE 'test storage::btree::tests::wal_reuses_freed_leaf_after_abandoned_insert_with_open_reader \.\.\. ok' "$TEST_LOG" \
  || fail "open reader test did not report ok (missing, panicked, or failed)"
grep -qE 'test storage::btree::tests::wal_overflowing_insert_resumes_after_yield_before_balance \.\.\. ok' "$TEST_LOG" \
  || fail "resume test did not report ok (missing, panicked, or failed)"
grep -qE 'test storage::btree::tests::wal_suspended_insert_resumes_after_reads_on_same_table \.\.\. ok' "$TEST_LOG" \
  || fail "resume after reads test did not report ok (missing, panicked, or failed)"
grep -qE 'test storage::btree::tests::wal_suspended_insert_resumes_after_another_insert_is_dropped \.\.\. ok' "$TEST_LOG" \
  || fail "second suspended insert test did not report ok (missing, panicked, or failed)"

# Guard against a vacuous summary and any reported failure.
grep -qE 'test result: ok\. 5 passed; 0 failed' "$TEST_LOG" \
  || fail "cargo summary did not show 5 passed with 0 failed"

echo "[verify] PASS: all five regression tests passed"
exit 0
