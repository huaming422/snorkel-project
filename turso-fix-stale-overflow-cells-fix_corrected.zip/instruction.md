## Task

On a WAL database we keep ending up with a broken table b-tree. `PRAGMA integrity_check` stops coming back `ok`, and some runs die on an internal assertion instead. It started once we began interrupting long inserts of wide rows (a few KB of blob each) and resetting them. The workload that hits it, all in one transaction: an insert like that is interrupted, reset and dropped, then most of the table is deleted and we keep inserting rows of the same shape. Can you track it down and fix it?
