## Task

Sharded pub/sub is misbehaving in a few related ways and I'd like them fixed together.

With `shardedSubscribers: true`, calling `cluster.sunsubscribe()` with no channel throws `TypeError: Cannot read properties of undefined (reading '0')`.
Redis treats a bare SUNSUBSCRIBE as "drop every shard channel on this connection", and the cluster client needs to do the same across every shard that currently holds channels and resolve with 0.
Dropped means dropped, none of those channels should come back when a slot moves later.
A shard whose subscriber connection is down or still reconnecting at that moment has to get the unsubscribe too, otherwise its channels quietly come back once it reconnects, but the call must not hang waiting on it.
If a shard refuses the unsubscribe, the call should reject rather than report success, and a retry should still reach that shard.

When one connection holds a regular channel or a pattern next to a shard channel, dropping the shard channel kills the other subscription.
Messages on it stop arriving: on RESP3 they just vanish, on RESP2 we see "Command queue state error" and the client drops out of subscriber mode even though the server still has us subscribed.
It happens the other way round too, unsubscribing the last regular channel or pattern drops a still-live shard channel.
Odd channel names get lost on one connection too.
Subscribe to Buffer 0x80 and Buffer 0x81, drop 0x80, and the client forgets 0x81 as well: after a reconnect nothing is resubscribed, and once the shard channel on that connection is gone its messages stop.
A channel called `__proto__` is lost the same way, as if we had never subscribed to it.

On a cluster, a shard channel we already unsubscribed comes back after a slot moves, as if we had resubscribed to it.
We see this with Buffer channel names, including names that only differ in bytes that are not valid UTF-8.

The empty-string channel name is legal in Redis, but after `unsubscribe("")` the client still thinks it is subscribed to it and resubscribes "" after a reconnect.

No live cluster is needed for any of this.
The existing sharded pub/sub tests run against an in-process mock server, so reproduce and check the fixes there.
The existing pub/sub tests must keep passing on both RESP2 and RESP3.
