// Behavioral checks for a no-argument shard unsubscribe on a cluster with
// sharded subscribers enabled. Everything is observed through the public
// Cluster shard subscribe/unsubscribe surface and the commands each shard's
// in-process mock server receives, never through any helper the fix
// may introduce.
//
// These files are copied into test/__ssb_verify__/ before they run, so the relative
// imports below resolve exactly as the repo's own cluster tests do.
import MockServer from "../helpers/mock_server";
import { expect } from "chai";
import { Cluster } from "../../lib";
import { Socket } from "net";

// "bar" hashes to slot 5061, "foo" to slot 12182. Splitting the keyspace at
// 8191 therefore lands one channel on each shard, so each shard ends up with
// its own sharded subscriber connection.
const SLOTS = [
  [0, 8191, ["127.0.0.1", 30001]],
  [8192, 16383, ["127.0.0.1", 30002]],
];

const SSUBSCRIBER_NAME = "ioredis-cluster(ssubscriber)";

function argvToStrings(argv: any[]): string[] {
  return argv.map((a) => String(a));
}

function zeroArgSunsubscribes(commands: string[][]): string[][] {
  return commands.filter(
    (argv) => argv[0].toLowerCase() === "sunsubscribe" && argv.length === 1
  );
}

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// Resolve `p`, but reject if it has not settled within `ms`. Used to prove that
// a call returns rather than blocking on a connection that never replies.
function withTimeout<T>(p: Promise<T>, ms: number, label: string): Promise<T> {
  return Promise.race([
    p,
    new Promise<T>((_, reject) =>
      setTimeout(() => reject(new Error(`timed out waiting for ${label}`)), ms)
    ),
  ]);
}

describe("bug_a_zero_arg_sunsubscribe", function () {
  this.timeout(15000);

  it("fans a no-argument shard unsubscribe out to every shard that holds channels", (done) => {
    const node1Commands: string[][] = [];
    const node2Commands: string[][] = [];
    // The slot table both nodes report; it is swapped for a single-owner
    // table later to simulate a reshard.
    let slots: any[] = SLOTS;

    const makeHandler = (sink: string[][]) =>
      function (argv: any[]) {
        sink.push(argvToStrings(argv));
        const name = String(argv[0]).toLowerCase();
        if (name === "cluster" && String(argv[1]).toLowerCase() === "slots") {
          return slots;
        }
        if (name === "ssubscribe") {
          return ["ssubscribe", argv[1], 1];
        }
        if (name === "sunsubscribe") {
          return ["sunsubscribe", argv[1] ?? null, 0];
        }
      };

    new MockServer(30001, makeHandler(node1Commands));
    new MockServer(30002, makeHandler(node2Commands));

    const cluster = new Cluster([{ host: "127.0.0.1", port: 30001 }], {
      shardedSubscribers: true,
    });

    const ssubscribesAfter = (commands: string[][], from: number) =>
      commands.slice(from).filter((argv) => argv[0].toLowerCase() === "ssubscribe");

    cluster.on("ready", async () => {
      try {
        await cluster.ssubscribe("bar"); // shard 1
        await cluster.ssubscribe("foo"); // shard 2

        const result = await cluster.sunsubscribe();
        expect(result).to.eql(0);

        // Each shard that held a subscription receives exactly one
        // zero-argument shard unsubscribe.
        expect(zeroArgSunsubscribes(node1Commands)).to.eql([["sunsubscribe"]]);
        expect(zeroArgSunsubscribes(node2Commands)).to.eql([["sunsubscribe"]]);

        // The channels are gone for good: when every slot moves to shard 2
        // and the client refreshes its slot cache, nothing is replayed to the
        // new owner (a client that still tracked "bar" and "foo" would
        // resubscribe them there).
        const mark1 = node1Commands.length;
        const mark2 = node2Commands.length;
        slots = [[0, 16383, ["127.0.0.1", 30002]]];
        await new Promise<void>((resolve, reject) => {
          cluster.refreshSlotsCache((err) => (err ? reject(err) : resolve()));
        });
        await delay(1000);
        expect(
          ssubscribesAfter(node2Commands, mark2),
          "no shard channel should be resubscribed after the reshard"
        ).to.eql([]);
        expect(ssubscribesAfter(node1Commands, mark1)).to.eql([]);

        cluster.disconnect();
        done();
      } catch (err) {
        cluster.disconnect();
        done(err);
      }
    });
  });
});

describe("bug_a_nonready_and_failure", function () {
  this.timeout(20000);

  it("rejects when a shard refuses and keeps its channels so a retry reaches it", (done) => {
    const node1Commands: string[][] = [];
    const node2Commands: string[][] = [];

    const node1Handler = function (argv: any[]) {
      node1Commands.push(argvToStrings(argv));
      const name = String(argv[0]).toLowerCase();
      if (name === "cluster" && String(argv[1]).toLowerCase() === "slots") {
        return SLOTS;
      }
      if (name === "ssubscribe") {
        return ["ssubscribe", argv[1], 1];
      }
      if (name === "sunsubscribe") {
        return ["sunsubscribe", argv[1] ?? null, 0];
      }
    };

    // Shard 2 is reachable and ready, but fails every shard unsubscribe.
    const node2Handler = function (argv: any[]) {
      node2Commands.push(argvToStrings(argv));
      const name = String(argv[0]).toLowerCase();
      if (name === "cluster" && String(argv[1]).toLowerCase() === "slots") {
        return SLOTS;
      }
      if (name === "ssubscribe") {
        return ["ssubscribe", argv[1], 1];
      }
      if (name === "sunsubscribe") {
        return new Error("connection lost");
      }
    };

    new MockServer(30001, node1Handler);
    new MockServer(30002, node2Handler);

    const cluster = new Cluster([{ host: "127.0.0.1", port: 30001 }], {
      shardedSubscribers: true,
    });

    cluster.on("ready", async () => {
      try {
        await cluster.ssubscribe("bar"); // shard 1 (ready, succeeds)
        await cluster.ssubscribe("foo"); // shard 2 (ready, fails on unsubscribe)

        let firstError: Error | undefined;
        try {
          await cluster.sunsubscribe();
        } catch (err) {
          firstError = err as Error;
        }
        // The call surfaces the shard failure to the caller rather than
        // silently reporting success. (The wording is the implementation's to
        // choose; only that it rejects is asserted.)
        expect(firstError, "expected the no-arg unsubscribe to reject").to.be.an(
          "error"
        );

        // Because the call rejected, the tracked channels must be left in place
        // so an idempotent retry still targets the failing shard. Prove it: a
        // second no-argument unsubscribe must reach shard 2 again.
        let secondError: Error | undefined;
        try {
          await cluster.sunsubscribe();
        } catch (err) {
          secondError = err as Error;
        }
        expect(secondError, "expected the retry to reject too").to.be.an(
          "error"
        );

        expect(
          zeroArgSunsubscribes(node2Commands).length,
          "shard 2 should receive the no-arg unsubscribe on both attempts"
        ).to.equal(2);

        cluster.disconnect();
        done();
      } catch (err) {
        cluster.disconnect();
        done(err);
      }
    });
  });

  it("reaches a shard whose connection is not yet ready without blocking on it", (done) => {
    const node1Commands: string[][] = [];
    const node2Commands: string[][] = [];

    const node1Handler = function (argv: any[]) {
      node1Commands.push(argvToStrings(argv));
      const name = String(argv[0]).toLowerCase();
      if (name === "cluster" && String(argv[1]).toLowerCase() === "slots") {
        return SLOTS;
      }
      if (name === "ssubscribe") {
        return ["ssubscribe", argv[1], 1];
      }
      if (name === "sunsubscribe") {
        return ["sunsubscribe", argv[1] ?? null, 0];
      }
    };

    // Shard 2 holds back its shard-subscriber connection: that connection's
    // handshake replies are withheld until `gateOpen` flips, so the connection
    // stays un-ready while the no-argument unsubscribe is issued. Its channel is
    // still tracked by the client, so the command must be sent to it anyway (and
    // land once the connection comes up), but the call must not wait on it.
    const subscriberSockets = new Set<Socket>();
    const deferred: Array<() => void> = [];
    let gateOpen = false;
    let node2: MockServer;

    const computeNode2Reply = (argv: any[]) => {
      const name = String(argv[0]).toLowerCase();
      if (name === "cluster" && String(argv[1]).toLowerCase() === "slots") {
        return SLOTS;
      }
      if (name === "ssubscribe") {
        return ["ssubscribe", argv[1], 1];
      }
      if (name === "sunsubscribe") {
        return ["sunsubscribe", argv[1] ?? null, 0];
      }
      return undefined; // +OK for handshake commands
    };

    const node2Handler = function (argv: any[], socket: Socket, flags: any) {
      const name = String(argv[0]).toLowerCase();
      if (
        name === "client" &&
        String(argv[1]).toLowerCase() === "setname" &&
        argv[2] === SSUBSCRIBER_NAME
      ) {
        subscriberSockets.add(socket);
      }

      const isSubscriberConn = subscriberSockets.has(socket);
      const reply = computeNode2Reply(argv);

      // Record only what the shard-subscriber connection receives.
      if (isSubscriberConn) {
        node2Commands.push(argvToStrings(argv));
      }

      if (!gateOpen && isSubscriberConn) {
        flags.hang = true;
        deferred.push(() => node2.write(socket, reply));
        return undefined;
      }
      return reply;
    };

    new MockServer(30001, node1Handler);
    node2 = new MockServer(30002, node2Handler);

    const cluster = new Cluster([{ host: "127.0.0.1", port: 30001 }], {
      shardedSubscribers: true,
    });

    const sawSubscriberHandshake = async () => {
      for (let i = 0; i < 200; i++) {
        if (subscriberSockets.size > 0) return true;
        await delay(25);
      }
      return false;
    };

    cluster.on("ready", async () => {
      try {
        await cluster.ssubscribe("bar"); // shard 1 (ready)

        // Route a subscription to shard 2 without awaiting it: this tracks the
        // channel and starts shard 2's subscriber connection, which then stalls
        // in its handshake (replies are withheld).
        cluster.ssubscribe("foo").catch(() => {});

        const started = await sawSubscriberHandshake();
        expect(started, "shard 2 subscriber should begin connecting").to.equal(
          true
        );

        // The no-argument unsubscribe must resolve promptly even though shard 2
        // is not ready - it is sent to shard 2 but not awaited.
        const result = await withTimeout(
          cluster.sunsubscribe(),
          4000,
          "no-arg shard unsubscribe while a shard is not ready"
        );
        expect(result).to.eql(0);

        // Now let shard 2's connection come up and flush its queued commands.
        gateOpen = true;
        const pending = deferred.splice(0, deferred.length);
        for (const fn of pending) fn();

        // The still-tracked channel means shard 2 must receive the no-argument
        // unsubscribe once it is reachable.
        let received = false;
        for (let i = 0; i < 200; i++) {
          if (zeroArgSunsubscribes(node2Commands).length > 0) {
            received = true;
            break;
          }
          await delay(25);
        }
        expect(
          received,
          "the not-yet-ready shard should still receive the no-arg unsubscribe"
        ).to.equal(true);

        cluster.disconnect();
        done();
      } catch (err) {
        cluster.disconnect();
        done(err);
      }
    });
  });
});
