"""Drives the repository's own TypeScript test runner (mocha over ts-node in
transpile-only mode) to check sharded pub/sub subscription bookkeeping, then
reports each behavior group and the pre-existing pub/sub regression suite as a
separate pytest case.

Why a Python entry point at all: the shared grading pipeline speaks pytest, but
the behaviors here are only observable at the TypeScript layer through the
client's public pub/sub surface and an in-process TCP server that speaks the
Redis protocol. So this module shells out to the repo's mocha and translates its
per-test results into pytest cases. It pins no implementation symbol: the spec
files alongside this one observe behavior through the pre-existing client
interfaces only.

This file imports no repository code (stdlib + subprocess only), so it runs
under the shared grading interpreter; the TypeScript run below goes through the
repository's own toolchain.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

import pytest

REPO_DIR = Path(os.environ.get("REPO_DIR", "/repo/ioredis"))
SPEC_DIR = Path(__file__).resolve().parent

# The behavior spec files are copied into a throwaway directory under the repo's
# own test tree so their relative imports ("../helpers/...", "../../lib")
# resolve exactly as the repo's cluster tests do. It is removed again afterwards
# so the working tree is left clean.
VERIFY_REL = Path("test") / "__ssb_verify__"
SPEC_FILES = [
    "spec_sharded_sunsubscribe.ts",
    "spec_subscriber_mode_groups.ts",
    "spec_channel_identity.ts",
]

# Pre-existing pub/sub + sharded-subscriber suites that must keep passing. These
# are repo-owned tests checked in at the base commit; a correct fix leaves them
# green. Functional suites drive the live Redis the image boots automatically.
REGRESSION_FILES = [
    "test/helpers/global.ts",
    "test/functional/cluster/spub_ssub.ts",
    "test/functional/spub_ssub.ts",
    "test/functional/commands/subscribe.ts",
    "test/functional/commands/unsubscribe.ts",
    "test/functional/commands/psubscribe.ts",
    "test/functional/commands/punsubscribe.ts",
    "test/functional/commands/sunsubscribe.ts",
    "test/functional/commands/pubsub.ts",
    "test/unit/DataHandler.ts",
]

MOCHA_TIMEOUT_SEC = 300


def _mocha_bin() -> list[str]:
    local = REPO_DIR / "node_modules" / ".bin" / "mocha"
    if local.exists():
        return [str(local)]
    return ["npx", "--no-install", "mocha"]


def _extract_json_report(stdout: str) -> dict | None:
    """Pull the reporter's JSON object out of stdout, tolerating stray output.

    The JSON reporter prints a single object describing the run; scan every
    opening brace and return the first decode that looks like that object.
    """
    decoder = json.JSONDecoder()
    start = 0
    while True:
        idx = stdout.find("{", start)
        if idx == -1:
            return None
        try:
            obj, _ = decoder.raw_decode(stdout[idx:])
        except json.JSONDecodeError:
            start = idx + 1
            continue
        if isinstance(obj, dict) and "stats" in obj and "tests" in obj:
            return obj
        start = idx + 1


def _run_mocha(files: list[str]) -> dict:
    """Run mocha over `files` and return {fullTitle: passed_bool, ...}.

    Raises RuntimeError on an infrastructure failure (mocha could not run or
    produced no parseable report) so the trial is invalidated rather than
    silently scored.
    """
    cmd = [
        *_mocha_bin(),
        "--no-experimental-strip-types",
        "--require",
        "ts-node/register",
        "--reporter",
        "json",
        "--exit",
        *files,
    ]
    env = {
        **os.environ,
        "TS_NODE_TRANSPILE_ONLY": "true",
        "NODE_ENV": "test",
    }
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=MOCHA_TIMEOUT_SEC,
            cwd=str(REPO_DIR),
            env=env,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(f"mocha timed out after {MOCHA_TIMEOUT_SEC}s") from exc

    report = _extract_json_report(proc.stdout or "")
    if report is None:
        tail = ((proc.stdout or "")[-2000:]) + "\n--- stderr ---\n" + ((proc.stderr or "")[-2000:])
        raise RuntimeError(
            f"mocha produced no parseable JSON report (exit {proc.returncode}).\n{tail}"
        )

    results: dict[str, bool] = {}
    for t in report.get("tests", []):
        title = t.get("fullTitle") or t.get("title") or ""
        # mocha lists a test under "failures" too; "tests" carries each test once
        # with no explicit pass flag, so treat presence of an "err" with keys as
        # failure.
        err = t.get("err") or {}
        results[title] = not bool(err)
    # Be explicit about failures in case a reporter variant omits err on the
    # tests entries.
    for t in report.get("failures", []):
        title = t.get("fullTitle") or t.get("title") or ""
        results[title] = False
    return results


# --- Run the behavior specs once and cache, so each group is reported as its own case.

_spec_results: dict[str, bool] | None = None
_spec_error: str | None = None


def _spec_run() -> dict[str, bool]:
    global _spec_results, _spec_error
    if _spec_results is not None or _spec_error is not None:
        if _spec_error is not None:
            raise RuntimeError(_spec_error)
        return _spec_results  # type: ignore[return-value]

    dest = REPO_DIR / VERIFY_REL
    try:
        dest.mkdir(parents=True, exist_ok=True)
        copied = []
        for name in SPEC_FILES:
            src = SPEC_DIR / name
            shutil.copy(src, dest / name)
            copied.append(str(VERIFY_REL / name))
        _spec_results = _run_mocha(copied)
        return _spec_results
    except Exception as exc:  # noqa: BLE001 - surface as an infrastructure failure
        _spec_error = str(exc)
        raise
    finally:
        shutil.rmtree(dest, ignore_errors=True)


def _assert_group(prefix: str) -> None:
    results = _spec_run()
    matched = {title: ok for title, ok in results.items() if prefix in title}
    assert matched, (
        f"no behavior checks matched group '{prefix}' - the spec run reported "
        f"{len(results)} tests: {sorted(results)[:8]}"
    )
    failures = [title for title, ok in matched.items() if not ok]
    assert not failures, "failing checks:\n  " + "\n  ".join(sorted(failures))


# The repaired behaviors, one case per group.

def test_bug_a_zero_arg_sunsubscribe() -> None:
    """A no-argument shard unsubscribe fans out to every shard holding channels
    and resolves with the remaining shard count (0)."""
    _assert_group("bug_a_zero_arg_sunsubscribe")


def test_bug_a_nonready_and_failure() -> None:
    """The fan-out reaches a not-yet-ready shard without blocking on it, and a
    ready-shard failure rejects while keeping tracked channels so a retry still
    reaches that shard."""
    _assert_group("bug_a_nonready_and_failure")


def test_bug_b_group_isolation() -> None:
    """Unsubscribing one channel group keeps messages flowing on the other
    group; subscriber mode is left only when every kind is empty. RESP2 and
    RESP3."""
    _assert_group("bug_b_group_isolation")


def test_bug_c_binary_safe_identity() -> None:
    """Channel bookkeeping is byte-accurate (cluster tracking and the
    connection's own set, including a channel named __proto__) and an
    unsubscribed shard channel is not replayed after a slot-topology change."""
    _assert_group("bug_c_binary_safe_identity")


def test_empty_channel_valid() -> None:
    """An empty-string channel name is a real channel: unsubscribing it drops
    exactly that channel, as the resubscribe after a reconnect shows."""
    _assert_group("empty_channel_valid")


# Pre-existing pub/sub behavior is preserved.

def test_regressions_pass() -> None:
    """The repository's pre-existing pub/sub and sharded-subscriber suites still
    pass after the fix."""
    results = _run_mocha(REGRESSION_FILES)
    assert results, "the regression suite reported no tests"
    failures = [title for title, ok in results.items() if not ok]
    assert not failures, "regressed checks:\n  " + "\n  ".join(sorted(failures))
