// Behavioral checks that channel bookkeeping is byte-accurate, on a cluster
// with sharded subscribers and on a single connection, and that an
// empty-string channel name is a real channel.
//
// Observation points, all pre-existing public surface:
//   - The Cluster shard subscribe/unsubscribe methods plus a slot-cache
//     refresh. When a slot moves, the client replays the channels it still
//     tracks to the new owner, so what the new owner receives (captured as raw
//     bytes on the wire) shows exactly which channels are still tracked.
//   - A single Redis connection's subscribe/unsubscribe methods, with the
//     in-process server pushing messages afterwards: a message on a channel
//     the client still holds must reach the listener.
//   - A forced reconnect: the client restores what it believes is subscribed,
//     so the SUBSCRIBE the new connection sends lists the tracked channels.
// No helper the fix may introduce is named.
import MockServer, { MockServerHandler, pushFrame } from "../helpers/mock_server";
import { expect } from "chai";
import { Socket } from "net";
import { Cluster } from "../../lib";
import Redis from "../../lib/Redis";

function noop() {}

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// A pub/sub frame in whichever wire shape the protocol uses, for string items.
function frame(protocol: 2 | 3, ...items: Array<string | number>) {
  return protocol === 3 ? pushFrame(...items) : items;
}

// The same frame as raw bytes, for channel names that are not valid UTF-8.
// The mock server's own writer would re-encode them, so these are written to
// the socket directly.
function rawFrame(
  protocol: 2 | 3,
  ...items: Array<string | Buffer | number>
): Buffer {
  const parts: Buffer[] = [
    Buffer.from(`${protocol === 3 ? ">" : "*"}${items.length}\r\n`),
  ];
  for (const item of items) {
    if (typeof item === "number") {
      parts.push(Buffer.from(`:${item}\r\n`));
    } else {
      const bytes = Buffer.isBuffer(item) ? item : Buffer.from(item);
      parts.push(
        Buffer.from(`$${bytes.length}\r\n`),
        bytes,
        Buffer.from("\r\n")
      );
    }
  }
  return Buffer.concat(parts);
}

// A bulk string as it appears on the wire, used to look for a channel name in
// captured bytes.
function bulk(bytes: Buffer): Buffer {
  return Buffer.concat([
    Buffer.from(`$${bytes.length}\r\n`),
    bytes,
    Buffer.from("\r\n"),
  ]);
}

// Resolve with the arguments of the next `event`, or reject if it does not
// arrive within `ms`.
function nextEvent(
  emitter: Redis,
  event: string,
  ms: number
): Promise<any[]> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      emitter.removeListener(event, onEvent);
      reject(new Error(`no "${event}" event within ${ms}ms`));
    }, ms);
    function onEvent(...args: any[]) {
      clearTimeout(timer);
      resolve(args);
    }
    emitter.once(event, onEvent);
  });
}

describe("bug_c_binary_safe_identity", function () {
  this.timeout(20000);

  // Two mock nodes that both report the slot table; `ownerPort` says which
  // one currently owns every slot. Shard subscribe/unsubscribe replies are
  // written per channel with a per-connection remaining count. Whatever the
  // second node receives on its shard-subscriber connection is recorded, as
  // strings and as raw bytes.
  function clusterPair(protocol: 2 | 3) {
    const state = {
      ownerPort: 30001,
      restored: [] as string[],
      rawOnTarget: [] as Buffer[],
    };
    const counts = new WeakMap<Socket, number>();
    const handler: MockServerHandler = (argv, socket, flags) => {
      if (argv[0] === "cluster" && argv[1] === "SLOTS") {
        return [[0, 16383, ["127.0.0.1", state.ownerPort]]];
      }
      if (argv[0] === "ssubscribe" || argv[0] === "sunsubscribe") {
        if (socket.localPort === 30002 && argv[0] === "ssubscribe") {
          state.restored.push(...argv.slice(1));
        }
        let count = counts.get(socket) ?? 0;
        for (const ch of argv.slice(1)) {
          count += argv[0] === "ssubscribe" ? 1 : -1;
          // Written as raw bytes so a channel name that is not plain ASCII
          // still gets a correct bulk-string length.
          socket.write(rawFrame(protocol, argv[0], ch, Math.max(count, 0)));
        }
        counts.set(socket, count);
        flags.hang = true;
      }
    };
    new MockServer(30001, handler);
    const target = new MockServer(30002, handler);
    target.on("connect", (socket: Socket) => {
      socket.on("data", (chunk: Buffer) => state.rawOnTarget.push(chunk));
    });
    return state;
  }

  async function moveSlotsAndWaitForReplay(
    cluster: Cluster,
    state: { ownerPort: number; restored: string[] },
    marker: string
  ) {
    state.ownerPort = 30002;
    await new Promise<void>((resolve, reject) => {
      cluster.refreshSlotsCache((err) => (err ? reject(err) : resolve()));
    });
    for (let i = 0; i < 200; i++) {
      if (state.restored.includes(marker)) return;
      await delay(25);
    }
    throw new Error(`the new owner never received ${marker}`);
  }

  for (const protocol of [2, 3] as const) {
    // An unsubscribed shard channel must not come back when the cluster
    // reshards and the still-tracked channels are replayed to the new owner,
    // whether the names were given as strings or Buffers.
    for (const [name, channel, removed] of [
      ["distinct buffers", Buffer.from("news{tag}"), Buffer.from("news{tag}")],
      ["string and buffer", "news{tag}", Buffer.from("news{tag}")],
      ["buffer and string", Buffer.from("news{tag}"), "news{tag}"],
    ] as const) {
      it(`does not replay an unsubscribed channel after moving slots (${name}, RESP${protocol})`, async () => {
        const state = clusterPair(protocol);
        const cluster = new Cluster([{ port: 30001 }], {
          shardedSubscribers: true,
          redisOptions: { protocol },
        });

        try {
          expect(await cluster.ssubscribe(channel)).to.equal(1);
          expect(await cluster.ssubscribe("control{tag}")).to.equal(2);
          expect(await cluster.sunsubscribe(removed)).to.equal(1);

          await moveSlotsAndWaitForReplay(cluster, state, "control{tag}");
          // Only the channel that is still subscribed is replayed.
          expect(state.restored).to.eql(["control{tag}"]);
        } finally {
          cluster.disconnect();
        }
      });
    }

    // Subscribing to the same shard channel twice, once as a string and once
    // as a Buffer, leaves two tracked copies. Unsubscribing it has to drop
    // every copy, or the channel comes back when the slot moves. The reply
    // counts are not checked here because the mock acknowledges the repeat
    // subscribe like any other.
    it(`drops every tracked copy of a channel subscribed more than once (RESP${protocol})`, async () => {
      const state = clusterPair(protocol);
      const cluster = new Cluster([{ port: 30001 }], {
        shardedSubscribers: true,
        redisOptions: { protocol },
      });

      try {
        await cluster.ssubscribe("news{tag}");
        await cluster.ssubscribe(Buffer.from("news{tag}"));
        await cluster.ssubscribe("control{tag}");
        await cluster.sunsubscribe(Buffer.from("news{tag}"));

        await moveSlotsAndWaitForReplay(cluster, state, "control{tag}");
        expect(state.restored).to.eql(["control{tag}"]);
      } finally {
        cluster.disconnect();
      }
    });

    // Two shard channel names that differ only in bytes that are not valid
    // UTF-8 render to the same string. Unsubscribing one must leave the other
    // tracked, so the replay after a reshard still carries it.
    it(`keeps byte-distinct shard channels apart when one is unsubscribed (RESP${protocol})`, async () => {
      const first = Buffer.concat([Buffer.from("{tag}"), Buffer.from([0xfe])]);
      const second = Buffer.concat([Buffer.from("{tag}"), Buffer.from([0xff])]);
      expect(first.toString()).to.equal(second.toString());

      const state = clusterPair(protocol);
      const cluster = new Cluster([{ port: 30001 }], {
        shardedSubscribers: true,
        redisOptions: { protocol },
      });

      try {
        await cluster.ssubscribe(first);
        await cluster.ssubscribe(second);
        await cluster.ssubscribe("control{tag}");
        // A fresh copy of the bytes, so only byte equality can match it.
        await cluster.sunsubscribe(Buffer.from(first));

        await moveSlotsAndWaitForReplay(cluster, state, "control{tag}");
        const wire = Buffer.concat(state.rawOnTarget);
        expect(
          wire.includes(bulk(second)),
          "the still-subscribed binary channel should be replayed"
        ).to.equal(true);
        expect(
          wire.includes(bulk(first)),
          "the unsubscribed binary channel should not be replayed"
        ).to.equal(false);
      } finally {
        cluster.disconnect();
      }
    });

    // A shard unsubscribe whose channels hash to different slots is refused
    // (CROSSSLOT) and must leave the tracked channels alone.
    it(`leaves the tracked channels unchanged when an unsubscribe spans slots (RESP${protocol})`, async () => {
      const state = clusterPair(protocol);
      const cluster = new Cluster([{ port: 30001 }], {
        shardedSubscribers: true,
        redisOptions: { protocol },
      });

      try {
        expect(await cluster.ssubscribe("news{tag}")).to.equal(1);
        expect(await cluster.ssubscribe("control{tag}")).to.equal(2);
        let refused: Error | undefined;
        try {
          await cluster.sunsubscribe("news{tag}", "news{other}");
        } catch (err) {
          refused = err as Error;
        }
        expect(refused, "a cross-slot unsubscribe should be refused").to.be.an(
          "error"
        );

        await moveSlotsAndWaitForReplay(cluster, state, "control{tag}");
        expect(state.restored.sort()).to.eql(["control{tag}", "news{tag}"]);
      } finally {
        cluster.disconnect();
      }
    });
  }

  // Single connection: the client's own subscription bookkeeping must keep
  // channels apart by their bytes and must cope with a channel named
  // __proto__. The visible effect of getting either wrong is the same as the
  // mixed-kind bug: unsubscribing the last channel of the other kind makes the
  // client believe nothing is subscribed, and messages on the surviving
  // channel stop arriving.
  describe("connection bookkeeping", () => {
    let server: MockServer | undefined;
    let redis: Redis | undefined;

    afterEach(() => {
      if (redis && redis.status !== "end") {
        redis.disconnect();
      }
      if (server) {
        server.disconnect();
      }
      redis = undefined;
      server = undefined;
    });

    for (const protocol of [2, 3] as const) {
      const port = 17950 + protocol;

      it(`keeps a channel named __proto__ subscribed when another kind is fully unsubscribed (RESP${protocol})`, async () => {
        let socket: Socket | undefined;
        const regular = new Set<string>();
        const shard = new Set<string>();
        const subscribes: Array<{ socket: Socket; channels: string[] }> = [];
        const mock = new MockServer(port, (argv, sock, flags) => {
          const cmd = String(argv[0]).toLowerCase();
          if (cmd === "info") {
            return "# Server\r\nredis_version:7.0.0\r\n";
          }
          if (cmd === "subscribe") {
            socket = sock;
            const channels = argv.slice(1).map(String);
            subscribes.push({ socket: sock, channels });
            // One acknowledgement per channel (a resubscribe after a
            // reconnect lists every channel in one command).
            for (const ch of channels) {
              regular.add(ch);
              mock.write(sock, frame(protocol, cmd, ch, regular.size));
            }
            flags.hang = true;
            return;
          }
          if (cmd === "ssubscribe") {
            shard.add(String(argv[1]));
            return frame(protocol, cmd, argv[1], shard.size);
          }
          if (cmd === "sunsubscribe") {
            shard.delete(String(argv[1]));
            return frame(protocol, cmd, argv[1], shard.size);
          }
          return "OK";
        });
        server = mock;

        redis = new Redis({ port, protocol });
        redis.on("error", noop);
        await redis.subscribe("__proto__");
        await redis.ssubscribe("shard{x}");
        expect(await redis.sunsubscribe("shard{x}")).to.equal(0);

        const message = nextEvent(redis, "message", 2000);
        mock.write(socket, frame(protocol, "message", "__proto__", "hello"));
        expect(await message).to.eql(["__proto__", "hello"]);

        // The channel is also part of what the client restores: drop the
        // connection from the server side and the resubscribe on the new
        // connection must name it.
        const first = subscribes[0].socket;
        first.destroy();
        let restored: string[] | undefined;
        for (let i = 0; i < 200; i++) {
          const entry = subscribes.find((s) => s.socket !== first);
          if (entry) {
            restored = entry.channels;
            break;
          }
          await delay(25);
        }
        expect(
          restored,
          "the client should resubscribe __proto__ after reconnecting"
        ).to.eql(["__proto__"]);
      });

      it(`keeps byte-distinct channel names apart (RESP${protocol})`, async () => {
        // 0x80 and 0x81 are both invalid UTF-8 and render to the same string.
        const first = Buffer.from([0x80]);
        const second = Buffer.from([0x81]);
        expect(first.toString()).to.equal(second.toString());

        // The server echoes the channel bytes the client sent, so the
        // acknowledgements are scripted in the order the test issues the
        // commands and written to the socket as raw bytes.
        let socket: Socket | undefined;
        const acks: Buffer[] = [
          rawFrame(protocol, "subscribe", first, 1),
          rawFrame(protocol, "subscribe", second, 2),
          rawFrame(protocol, "unsubscribe", first, 1),
          rawFrame(protocol, "ssubscribe", "shard{x}", 1),
          rawFrame(protocol, "sunsubscribe", "shard{x}", 0),
        ];
        // Every SUBSCRIBE, with the connection it arrived on and how many
        // channels it named, plus the raw bytes each connection sent.
        const subscribes: Array<{ socket: Socket; count: number }> = [];
        const rawBySocket = new Map<Socket, Buffer[]>();
        const mock = new MockServer(port, (argv, sock, flags) => {
          const cmd = String(argv[0]).toLowerCase();
          if (cmd === "info") {
            return "# Server\r\nredis_version:7.0.0\r\n";
          }
          if (/^s?p?(un)?subscribe$/.test(cmd)) {
            socket = sock;
            flags.hang = true;
            if (cmd === "subscribe") {
              subscribes.push({ socket: sock, count: argv.length - 1 });
            }
            if (acks.length > 0) {
              sock.write(acks.shift()!);
            } else {
              // A resubscribe after the reconnect: acknowledge each channel.
              argv.slice(1).forEach((ch: string, i: number) => {
                sock.write(rawFrame(protocol, cmd, Buffer.from(String(ch)), i + 1));
              });
            }
            return;
          }
          return "OK";
        });
        mock.on("connect", (sock: Socket) => {
          const chunks: Buffer[] = [];
          rawBySocket.set(sock, chunks);
          sock.on("data", (chunk: Buffer) => chunks.push(chunk));
        });
        server = mock;

        redis = new Redis({ port, protocol });
        redis.on("error", noop);
        await redis.subscribe(first);
        await redis.subscribe(second);
        expect(await redis.unsubscribe(first)).to.equal(1);
        await redis.ssubscribe("shard{x}");
        expect(await redis.sunsubscribe("shard{x}")).to.equal(0);

        // The second channel is still subscribed, so a message on it must
        // reach the listener with its exact bytes.
        const message = nextEvent(redis, "messageBuffer", 2000);
        socket!.write(rawFrame(protocol, "message", second, "hello"));
        const [channel, payload] = await message;
        expect(Buffer.isBuffer(channel)).to.equal(true);
        expect((channel as Buffer).equals(second)).to.equal(true);
        expect(payload.toString()).to.equal("hello");

        // The surviving channel is also part of what the client restores:
        // drop the connection from the server side and the resubscribe on
        // the new connection must name exactly one channel.
        const firstSocket = subscribes[0].socket;
        firstSocket.destroy();
        let restored: { socket: Socket; count: number } | undefined;
        for (let i = 0; i < 200; i++) {
          restored = subscribes.find((s) => s.socket !== firstSocket);
          if (restored) break;
          await delay(25);
        }
        expect(
          restored,
          "the client should resubscribe the surviving channel after reconnecting"
        ).to.not.equal(undefined);
        expect(restored!.count).to.equal(1);
        // The client restores channels by the names it reports for them, so
        // the restored name may arrive as the original bytes or as their
        // UTF-8 rendering. Either way it is one channel, and never the raw
        // bytes of the channel that was dropped.
        const wire = Buffer.concat(rawBySocket.get(restored!.socket) ?? []);
        const rendered = Buffer.from(second.toString());
        expect(
          wire.includes(bulk(second)) || wire.includes(bulk(rendered)),
          `the restore should name the surviving channel, got ${wire.toString("hex")}`
        ).to.equal(true);
        expect(wire.includes(bulk(first))).to.equal(false);
      });
    }
  });
});

describe("empty_channel_valid", function () {
  this.timeout(15000);

  // An empty-string channel is a real channel. Unsubscribing it must drop
  // exactly that channel: after a reconnect the client restores what it
  // still believes is subscribed, so the SUBSCRIBE sent on the new connection
  // shows what it kept. Under RESP2, once the last channel is gone the
  // connection must accept ordinary commands again.
  for (const protocol of [2, 3] as const) {
    it(`unsubscribing the empty-string channel removes exactly that channel (RESP${protocol})`, async () => {
      const port = 17960 + protocol;
      const regular = new Set<string>();
      const subscribes: Array<{ socket: Socket; channels: string[] }> = [];
      const server = new MockServer(port, (argv, socket, flags) => {
        const cmd = String(argv[0]).toLowerCase();
        if (cmd === "info") {
          return "# Server\r\nredis_version:7.0.0\r\n";
        }
        if (cmd === "subscribe" || cmd === "unsubscribe") {
          const channels = argv.slice(1).map(String);
          if (cmd === "subscribe") {
            subscribes.push({ socket, channels });
          }
          // One acknowledgement per channel, each with the remaining count.
          for (const ch of channels) {
            if (cmd === "subscribe") regular.add(ch);
            else regular.delete(ch);
            server.write(socket, frame(protocol, cmd, ch, regular.size));
          }
          flags.hang = true;
          return;
        }
        return "OK";
      });

      const redis = new Redis({ port, protocol });
      redis.on("error", noop);
      try {
        await redis.subscribe(""); // the empty-string channel
        await redis.subscribe("other");
        expect(await redis.unsubscribe("")).to.equal(1);

        // Drop the connection from the server side. The client reconnects and
        // resubscribes whatever it still tracks.
        const first = subscribes[0].socket;
        first.destroy();
        let restored: string[] | undefined;
        for (let i = 0; i < 200; i++) {
          const entry = subscribes.find((s) => s.socket !== first);
          if (entry) {
            restored = entry.channels;
            break;
          }
          await delay(25);
        }
        expect(restored, "the client should resubscribe after reconnecting").to.eql(
          ["other"]
        );

        if (protocol === 2) {
          // With the last channel gone the connection leaves subscriber mode
          // and ordinary commands work again.
          expect(await redis.unsubscribe("other")).to.equal(0);
          expect(await redis.get("key")).to.equal("OK");
        }
      } finally {
        if (redis.status !== "end") redis.disconnect();
        server.disconnect();
      }
    });
  }
});
