// Behavioral checks for a single connection that mixes regular channels,
// patterns and shard channels. Redis keeps one remaining count for channels
// plus patterns and a separate count for shard channels, so the count carried
// by one group's unsubscribe acknowledgement says nothing about the other
// group.
//
// Everything is driven through the public subscribe/unsubscribe methods
// against an in-process server, and observed the way a caller would notice a
// problem: messages on the surviving subscription either keep arriving or
// they do not (under RESP2 a connection that wrongly left subscriber mode
// routes the next message into the command queue and emits a "Command queue
// state error"; under RESP3 the message is silently dropped), and ordinary
// commands are refused while the connection is still subscribed under RESP2.
// `redis.condition.subscriber` and `redis.mode` are pre-existing fields and
// are only read for the final state. No helper the fix may introduce is named.
import MockServer, { pushFrame } from "../helpers/mock_server";
import { expect } from "chai";
import Redis from "../../lib/Redis";
import { Socket } from "net";

const PROTOCOLS = [2, 3] as const;

function noop() {}

// A pub/sub frame in whichever wire shape the protocol uses.
function frame(protocol: 2 | 3, ...items: Array<string | number>) {
  return protocol === 3 ? pushFrame(...items) : items;
}

// Resolve with the arguments of the next `event`, or reject if it does not
// arrive within `ms`.
function nextEvent(
  emitter: Redis,
  event: string,
  ms: number
): Promise<any[]> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      emitter.removeListener(event, onEvent);
      reject(new Error(`no "${event}" event within ${ms}ms`));
    }, ms);
    function onEvent(...args: any[]) {
      clearTimeout(timer);
      resolve(args);
    }
    emitter.once(event, onEvent);
  });
}

PROTOCOLS.forEach((protocol, index) => {
  describe(`bug_b_group_isolation (RESP${protocol})`, function () {
    this.timeout(15000);

    const port = 17940 + index;
    let server: MockServer;
    let redis: Redis;
    let socket: Socket | undefined;
    // The server-side view: one remaining count for channels plus patterns,
    // one for shard channels, exactly as Redis reports them.
    let regular: Set<string>;
    let shard: Set<string>;

    beforeEach(() => {
      regular = new Set();
      shard = new Set();
      socket = undefined;
      server = new MockServer(port, (argv, sock) => {
        const name = String(argv[0]).toLowerCase();
        if (name === "info") {
          return "# Server\r\nredis_version:7.0.0\r\n";
        }
        if (name === "subscribe" || name === "psubscribe") {
          socket = sock;
          regular.add(String(argv[1]));
          return frame(protocol, name, argv[1], regular.size);
        }
        if (name === "unsubscribe" || name === "punsubscribe") {
          regular.delete(String(argv[1]));
          return frame(protocol, name, argv[1], regular.size);
        }
        if (name === "ssubscribe") {
          socket = sock;
          shard.add(String(argv[1]));
          return frame(protocol, name, argv[1], shard.size);
        }
        if (name === "sunsubscribe") {
          shard.delete(String(argv[1]));
          return frame(protocol, name, argv[1], shard.size);
        }
        return "OK";
      });
    });

    afterEach(() => {
      if (redis && redis.status !== "end") {
        redis.disconnect();
      }
      server.disconnect();
    });

    it("keeps delivering on the regular and pattern subscriptions after the shard channel is unsubscribed", async () => {
      redis = new Redis({ port, protocol });
      redis.on("error", noop);
      await redis.subscribe("regular");
      await redis.psubscribe("pat*");
      await redis.ssubscribe("shard");
      expect(await redis.sunsubscribe("shard")).to.equal(0);

      // The regular channel and the pattern were never touched, so a message
      // published on each must still reach the listener.
      const message = nextEvent(redis, "message", 2000);
      server.write(socket, frame(protocol, "message", "regular", "hello"));
      expect(await message).to.eql(["regular", "hello"]);

      const pmessage = nextEvent(redis, "pmessage", 2000);
      server.write(
        socket,
        frame(protocol, "pmessage", "pat*", "pattern-hit", "hello")
      );
      expect(await pmessage).to.eql(["pat*", "pattern-hit", "hello"]);
    });

    it("keeps delivering on the shard channel after the last regular channel is unsubscribed", async () => {
      redis = new Redis({ port, protocol });
      redis.on("error", noop);
      await redis.ssubscribe("shard");
      await redis.subscribe("regular");
      expect(await redis.unsubscribe("regular")).to.equal(0);

      const smessage = nextEvent(redis, "smessage", 2000);
      server.write(socket, frame(protocol, "smessage", "shard", "hello"));
      expect(await smessage).to.eql(["shard", "hello"]);
    });

    it("keeps delivering on the shard channel after the last pattern is unsubscribed", async () => {
      redis = new Redis({ port, protocol });
      redis.on("error", noop);
      await redis.ssubscribe("shard");
      await redis.psubscribe("pat*");
      expect(await redis.punsubscribe("pat*")).to.equal(0);

      const smessage = nextEvent(redis, "smessage", 2000);
      server.write(socket, frame(protocol, "smessage", "shard", "hello"));
      expect(await smessage).to.eql(["shard", "hello"]);
    });

    it("leaves subscriber mode only once every kind is unsubscribed", async () => {
      redis = new Redis({ port, protocol });
      redis.on("error", noop);
      await redis.subscribe("regular");
      await redis.ssubscribe("shard");
      expect(await redis.unsubscribe("regular")).to.equal(0);

      // The shard channel is still live, so the connection is still a
      // subscriber. Under RESP2 that means ordinary commands are refused.
      if (protocol === 2) {
        let refused: Error | undefined;
        try {
          await redis.get("key");
        } catch (err) {
          refused = err as Error;
        }
        expect(refused, "an ordinary command should still be refused").to.be.an(
          "error"
        );
        expect(refused!.message).to.match(/subscriber mode/);
      }
      expect(redis.condition.subscriber).to.not.equal(false);

      expect(await redis.sunsubscribe("shard")).to.equal(0);

      // Nothing is subscribed any more: the connection is back to normal.
      expect(redis.condition.subscriber).to.equal(false);
      if (protocol === 2) {
        expect(redis.mode).to.equal("normal");
        expect(await redis.get("key")).to.equal("OK");
      }
    });
  });
});
