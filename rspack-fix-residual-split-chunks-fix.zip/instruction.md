## Task

We're seeing duplicate code in an rspack build that uses `splitChunks` with cache groups of different priorities. A module used by several chunks is extracted from some of them by the higher priority group. Its copies in the remaining chunks stay in the output instead of being gathered into a shared chunk.

A single cache group handles this module correctly. You can reproduce the failure with a small project whose chunks import the same module, then inspect which output chunks contain it. Please fix the split chunks optimization so the remaining copies are deduplicated. Keep the cases that already work, including a group that covers every importing chunk and a group that reuses an existing chunk, working as before.
