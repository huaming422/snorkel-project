// @ts-nocheck
//
// Scoped push gating through the proxy's existing entry point
// `gateGithubRequest(request, url, owner, repo, issueNumber)`, which resolves
// to null when a request is allowed and to a short reason string when it is
// refused. A receive-pack push is allowed only when every ref its commands
// update is the issue's own artifacts branch,
// `refs/heads/bot/artifacts-<issueNumber>`, as named by the command line
// itself. Reason wording is free, so refusals are checked only as a non-empty
// string.

import { describe, expect, test } from "vitest";

import { gateGithubRequest } from "../../.flue/lib/github-proxy.js";

const OWNER = "emdash-cms";
const REPO = "emdash";
const RECEIVE_PACK = "https://github.com/emdash-cms/emdash.git/git-receive-pack";

// Every command line starts with two 40-hex object ids (old, new), so a gate
// that checks oid shape still reads these as well-formed commands.
const OLD_OID = "0".repeat(40);
const NEW_OID = "1".repeat(40);

// pkt-line frame: 4-hex length prefix (counting the 4 header bytes) + payload.
// `<NUL>` marks the capability separator and becomes a single NUL byte before
// framing, as in the repo's own github-proxy.test.ts.
function pktLine(inner: string): string {
	const line = inner.replaceAll("<NUL>", String.fromCharCode(0));
	return `${(line.length + 4).toString(16).padStart(4, "0")}${line}`;
}

function receivePack(commandLines: string[], issueNumber?: number) {
	const url = new URL(RECEIVE_PACK);
	const request = new Request(url, {
		method: "POST",
		body: `${commandLines.map(pktLine).join("")}0000PACKpayload`,
	});
	return gateGithubRequest(request, url, OWNER, REPO, issueNumber);
}

function command(ref: string, capabilities = "<NUL> report-status"): string {
	return `${OLD_OID} ${NEW_OID} ${ref}${capabilities}\n`;
}

async function expectRefused(result: Promise<string | null>) {
	const reason = await result;
	expect(typeof reason).toBe("string");
	expect((reason as string).length).toBeGreaterThan(0);
}

describe("scoped push gating", () => {
	test("allows a push that targets exactly the issue's artifacts branch", async () => {
		await expect(receivePack([command("refs/heads/bot/artifacts-123")], 123)).resolves.toBeNull();
		await expect(receivePack([command("refs/heads/bot/artifacts-456")], 456)).resolves.toBeNull();
	});

	test("refuses a non-artifacts branch, including the bot fix branch", async () => {
		await expectRefused(receivePack([command("refs/heads/bot/fix-123")], 123));
		await expectRefused(receivePack([command("refs/heads/main")], 123));
	});

	test("refuses another issue's artifacts branch and a longer look-alike name", async () => {
		await expectRefused(receivePack([command("refs/heads/bot/artifacts-123")], 456));
		await expectRefused(receivePack([command("refs/heads/bot/artifacts-1234")], 123));
	});

	test("refuses a push where any one command targets another branch", async () => {
		await expectRefused(
			receivePack(
				[command("refs/heads/bot/artifacts-456"), command("refs/heads/main", "")],
				456,
			),
		);
	});

	test("decides from the command's ref, not a ref in the capability section", async () => {
		// The command targets a disallowed ref; the allowed ref string sits after
		// the NUL separator, among the capabilities.
		await expectRefused(
			receivePack([command("refs/meta/evil", "<NUL> refs/heads/bot/artifacts-123")], 123),
		);
	});

	test("refuses a receive-pack with no issue scope at all", async () => {
		await expectRefused(receivePack([command("refs/heads/bot/artifacts-123")]));
	});
});
