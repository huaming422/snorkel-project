// @ts-nocheck
//
// The authenticated GitHub proxy's existing entry point, `gateGithubRequest`,
// resolves to `null` when a request is allowed and to a short human-readable
// reason string when it is refused. Read-only traffic for the configured
// repository (repo metadata GET, clone and upload-pack, raw content, codeload,
// read-only api.github.com reads) stays allowed, and requests outside the
// repository or writing through the API stay refused.
//
// Only that null-or-string contract is checked here, through
// `gateGithubRequest(request, url, owner, repo, issueNumber)`. Receive-pack
// pushes are covered in verify_push_scope.test.ts.

import { describe, expect, test } from "vitest";

import { gateGithubRequest } from "../../.flue/lib/github-proxy.js";

const OWNER = "emdash-cms";
const REPO = "emdash";

// Drive the stable gate entry point exactly as the repo's own callers do.
function gate(url: string, init?: RequestInit) {
	const request = new Request(url, init);
	return gateGithubRequest(request, new URL(url), OWNER, REPO, 123);
}

describe("gateGithubRequest stable allow/deny contract", () => {
	test("allowed requests resolve to null (not a string)", async () => {
		// Read-only API read inside the configured repository.
		await expect(
			gate("https://api.github.com/repos/emdash-cms/emdash/issues/1"),
		).resolves.toBeNull();

		// Repository metadata GET on github.com.
		await expect(gate("https://github.com/emdash-cms/emdash")).resolves.toBeNull();

		// Clone / upload-pack fetch path on github.com.
		await expect(
			gate("https://github.com/emdash-cms/emdash.git/info/refs"),
		).resolves.toBeNull();
		await expect(
			gate("https://github.com/emdash-cms/emdash.git/git-upload-pack", { method: "POST" }),
		).resolves.toBeNull();

		// Raw content and codeload reads inside the configured repository.
		await expect(
			gate("https://raw.githubusercontent.com/emdash-cms/emdash/main/README.md"),
		).resolves.toBeNull();
		await expect(
			gate("https://codeload.github.com/emdash-cms/emdash/tar.gz/main"),
		).resolves.toBeNull();
	});

	test("rejected requests resolve to a non-empty reason string", async () => {
		// Refusals are checked as a non-empty reason string; the wording is free.

		// API read outside the configured repository.
		const outOfRepo = await gate("https://api.github.com/repos/other/private/issues/1");
		expect(typeof outOfRepo).toBe("string");
		expect((outOfRepo as string).length).toBeGreaterThan(0);

		// API writes are rejected (the API surface is read-only).
		const apiWrite = await gate("https://api.github.com/repos/emdash-cms/emdash/issues/1", {
			method: "PATCH",
		});
		expect(typeof apiWrite).toBe("string");
		expect((apiWrite as string).length).toBeGreaterThan(0);

		// A host that is not proxied at all.
		const foreignHost = await gate("https://example.com/whatever");
		expect(typeof foreignHost).toBe("string");
		expect((foreignHost as string).length).toBeGreaterThan(0);

		// Raw content outside the configured repository.
		const foreignRaw = await gate(
			"https://raw.githubusercontent.com/other/private/main/secret.txt",
		);
		expect(typeof foreignRaw).toBe("string");
		expect((foreignRaw as string).length).toBeGreaterThan(0);
	});
});
