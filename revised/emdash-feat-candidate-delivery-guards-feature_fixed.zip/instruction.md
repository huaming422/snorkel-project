## Task

Before the bot starts shipping a sandboxed agent's fixes on its own, I want three guards on the delivery path.
They don't depend on each other, so build them in any order.

Publishing: a candidate is a set of file edits and deletions on top of a base commit, plus the sha of the tree we verified for it.
The bot itself should write it to the candidate branch through GitHub's git data API and tell the caller which commit it published.

Check results: before we publish, we need to be able to trust the record that says which checks passed.
The sandbox writes those check commands, so assume someone will try to make a failing check look green.

Push gating: the sandbox pushes through the authenticated git proxy, and today the proxy lets it update more branches than it needs.
The proxy's gate keeps its current contract: it resolves to null for an allowed request and to a short reason string for a refused one.
The read-only traffic it allows today (repo metadata, clone and fetch, raw and codeload reads, read-only API calls inside the configured repo) has to keep working.

Design the interfaces for publishing and check results yourself.
All of this lives in the bot's TypeScript library code and has to be testable offline in plain Node: no Workers runtime, no network, no live GitHub.
So the publisher should take its GitHub access as an argument rather than building its own client.

## User stories / requirements

- Publishing creates or moves the branch to a commit holding the verified tree. It refuses, leaving the branch alone, if GitHub builds a different tree or the branch now points somewhere other than this run's earlier commit, and refuses if the branch doesn't show the new commit afterward. A retry returns the run's existing commit.
- Only each check's latest result counts, so a check whose last run failed isn't passing. A check whose command changed between runs, or a result from an older candidate tree, is rejected. So is a command that pipes, chains, falls back or negates (`!`) in a way that can hide a failing exit code.
- A sandboxed push through the proxy is allowed only when every ref it updates is its own issue's artifacts branch, `refs/heads/bot/artifacts-<issue number>`, read from the push commands themselves. Pushes to any other branch, another issue's branch, or with no issue scope are refused, even if an allowed-looking ref appears elsewhere in the request.
