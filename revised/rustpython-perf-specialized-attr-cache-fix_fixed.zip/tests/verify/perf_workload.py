# Steady-state attribute/method-access workload for the deterministic
# work-counter verifier.
#
# This is a plain Python program run by the built `rustpython` interpreter under
# callgrind. It builds many instances that share one attribute layout, warms the
# access sites well past the adaptive-specialization threshold, and then executes
# a long steady-state loop that reads attributes, calls a method, and does
# value-only attribute stores, all on an unchanging key set.
#
# argv[1] is the number of steady-state passes N. The verifier runs this at two
# values of N; the loop body is identical across both runs, so everything except
# the per-pass work cancels in the difference.
#
# argv[2] picks the attribute and method names ("plain" or "chained"). Both
# layouts compile the same template, so the bytecode is identical and only the
# names differ. Under PYTHONHASHSEED=0 (which the verifier sets):
#   * "plain": every attribute sits in the first slot its hash points to in the
#     instance dict's 8-slot index table, and the method name's first slot is
#     empty, so a lookup of any of them ends after one probe step;
#   * "chained": all six names hash to the same first slot, so a lookup of the
#     two attributes the loop reads walks 8 to 10 slots and a lookup of the
#     method name in the instance dict walks 11 before it ends.
# The two layouts hold the same number of keys, so the tables are the same size.
#
# Everything here is observable public Python: classes, instance attributes,
# method calls, value reassignment. Nothing about the measurement is encoded in
# the program beyond the choice of names.

import sys

# Names in order: three attributes set first, the two attributes the loop reads
# and writes, and the method.
LAYOUTS = {
    "plain": ("fjp", "ecy", "uhd", "mrh", "gnw", "cua"),
    "chained": ("r8i", "ccf", "lrx", "z_u", "ybx", "ycg"),
}

TEMPLATE = """
class Point:
    def __init__(self):
        self.{f1} = 1
        self.{f2} = 2
        self.{f3} = 3
        self.{a} = 4
        self.{b} = 5

    def {m}(self):
        return self.{a}


def build(count):
    return [Point() for _ in range(count)]


def warm(objs, rounds):
    # Run every access site far past the point where it settles, so the
    # measured loop below is entirely steady state. Includes a value-only
    # store so the store access site warms too.
    total = 0
    for _ in range(rounds):
        for o in objs:
            o.{a} = o.{a} + 1
            total += o.{a} + o.{b} + o.{f1} + o.{m}()
    return total


def measure(objs, n):
    acc = 0
    i = 0
    while i < n:
        for o in objs:
            acc += o.{a} + o.{b} + o.{m}()   # attribute reads + a method call
            o.{a} = acc & 255                # value-only store (key set unchanged)
        i += 1
    return acc
"""


def main():
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 100000
    layout = sys.argv[2] if len(sys.argv) > 2 else "plain"
    names = dict(zip(("f1", "f2", "f3", "a", "b", "m"), LAYOUTS[layout]))
    ns = {}
    exec(compile(TEMPLATE.format(**names), "<workload>", "exec"), ns)
    objs = ns["build"](64)
    warmed = ns["warm"](objs, 400)
    result = ns["measure"](objs, n)
    # Print so the work is observable and the loop cannot be optimized away.
    print(warmed + result)


main()
