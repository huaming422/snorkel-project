#!/usr/bin/env bash
# Once an object's attribute set has stopped changing, warm attribute reads,
# method calls and value stores must stop paying a per-access instance-dict hash
# and probe.
#
# Measurement is a DETERMINISTIC work count, never wall-clock. We run the built
# `rustpython` interpreter over a fixed warm attribute-access workload under
# callgrind (valgrind's call-graph simulator, reproducible across runs) and read
# two numbers from each run:
#
#   * how many times the program calls the instance dict's hash/probe routine
#     (`Dict::lookup`, the probe every keyed dict access goes through at the
#     base commit), and
#   * the total number of guest instructions executed (callgrind's Ir total).
#
# Every number used below is a SLOPE over the pass count: the same workload runs
# at N1 and N2 passes and only the difference is kept. That cancels everything
# that does not repeat per pass (start-up, imports, warm-up, one-time
# specialization), so each number describes the marginal cost of a warm pass
# over the 64 objects.
#
# Two checks, both on every run:
#
# 1. The call slope (plain layout). A warm access that still probes the instance
#    dict makes the lookup call count grow with the pass count (320 calls per
#    pass at the base commit, five accesses per object), while an access that
#    can tell the attribute set is unchanged keeps it flat. The count only means
#    something while the probe routine is visible to callgrind as a function of
#    its own. Start-up and imports alone call it tens of thousands of times, so
#    a run that shows (almost) no calls means the routine was inlined into its
#    callers or renamed; this check is then skipped and check 2 decides.
#
# 2. The layout slope. The workload runs twice more with different attribute
#    and method names: "plain" names each sit in their first index slot, while
#    "chained" names all share one first slot, so finding them in the instance
#    dict walks a long probe chain (see perf_workload.py). Both layouts run the
#    same bytecode on dicts of the same size. A warm access that still hashes
#    and probes the instance dict pays for the longer chains on every pass,
#    whatever the probing code is called or wherever it was inlined; an access
#    that skips the probe costs the same on both layouts, however much work its
#    own check takes. So the chained layout may cost at most MAX_LAYOUT_EXTRA
#    more instructions per pass than the plain one. Both numbers come from the
#    same binary in the same run, so no fixed per-pass cost is assumed.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORKLOAD="${SCRIPT_DIR}/perf_workload.py"
COUNTER="${SCRIPT_DIR}/count_calls.py"

# Fix the string-hash seed: the probe chains in the "chained" layout, and the
# probe sequence in general, depend on it. Combined with callgrind's simulated
# (noise-free) counting this makes every measured count reproducible.
export PYTHONHASHSEED=0

# Two steady-state sizes. Both are far past the adaptive-specialization warmup
# (the workload warms every access site for 400 rounds first), so every measured
# pass is steady state.
N1=2000
N2=4000
# Bound on the growth in hash/probe calls between N1 and N2 (plain layout). A
# warm access that still probes adds 64 calls per pass per access site (128,000
# over 2,000 passes); 25,000 admits any guard that only re-probes occasionally.
MAX_DELTA=25000
# Fewest lookup calls the N1 run must show for the call count to be trusted.
# Start-up and imports alone make tens of thousands of them.
MIN_VISIBLE_CALLS=1000
# Bound on the extra instructions per warm pass that the chained layout costs
# over the plain one. With 64 objects per pass, one access site that still
# probes adds well over 10,000 (the store site alone, about 200 per object);
# an access that does not probe adds nothing, whatever its guard costs.
MAX_LAYOUT_EXTRA=4000

# Locate the release interpreter built from the working tree (test-setup.sh
# built it offline-first). CARGO_TARGET_DIR is set image-wide; fall back to the
# in-repo target/ if it was overridden.
BIN=""
for cand in \
    "${CARGO_TARGET_DIR:-}/release/rustpython" \
    "/repo/RustPython/target/release/rustpython" \
    "$(pwd)/target/release/rustpython"; do
    if [[ -n "${cand}" && -x "${cand}" ]]; then BIN="${cand}"; break; fi
done
if [[ -z "${BIN}" ]]; then
    echo "FAIL: release rustpython binary not found (expected under CARGO_TARGET_DIR/release)" >&2
    exit 1
fi
echo "interpreter: ${BIN}"

command -v valgrind >/dev/null || { echo "FAIL: valgrind missing" >&2; exit 1; }

# Prime the interpreter's bytecode cache (Lib/__pycache__) with one short native
# run of the workload. Without it, whichever measured run comes first also
# compiles the standard-library modules it imports, which inflates that run
# alone and skews the slopes. A failure here is reported by the measured runs.
"${BIN}" "${WORKLOAD}" 50 plain >/dev/null 2>&1 || true

# Regex for the instance-dict lookup/probe routine. Matches every
# monomorphization of rustpython_vm::dict_inner::Dict::lookup, whether callgrind
# prints the symbol mangled (thin-LTO local symbols carry a `.llvm.<n>` suffix
# that valgrind does not demangle, giving ...dict_inner...6lookup17h...) or
# demangled (rustpython_vm::dict_inner::Dict<T>::lookup). It is used only as a
# COUNT TARGET; the behavior under test is driven entirely through the normal
# Python attribute-access path.
LOOKUP_RE='dict_inner.*(6lookup|::lookup(?![_0-9A-Za-z]))'

run_measure() {
    # $1 = N, $2 = layout ; echoes "<lookup calls> <total Ir>" for that run.
    local n="$1" layout="$2" out res
    out="$(mktemp /tmp/callgrind.XXXXXX.out)"
    res="$(mktemp /tmp/workload.XXXXXX.txt)"
    # --cache-sim/--branch-sim off: only call counts and instruction totals are
    # needed, and turning the simulators off keeps the run fast. valgrind exits
    # with the interpreter's own status, and the workload prints one integer
    # when it finishes, so a crashed or truncated run cannot be measured.
    if ! valgrind --tool=callgrind \
        --callgrind-out-file="${out}" \
        --cache-sim=no --branch-sim=no --dump-line=no \
        "${BIN}" "${WORKLOAD}" "${n}" "${layout}" >"${res}" 2>/dev/null \
        || ! grep -qE '^-?[0-9]+$' "${res}"; then
        echo "FAIL: workload did not run to completion under callgrind for N=${n} (${layout})" >&2
        head -c 2000 "${res}" >&2
        rm -f "${out}" "${res}"
        exit 1
    fi
    local c ir
    c="$(python3 "${COUNTER}" "${out}" "${LOOKUP_RE}")"
    ir="$(awk '/^(summary|totals):/ {print $2; exit}' "${out}")"
    rm -f "${out}" "${res}"
    if ! [[ "${c}" =~ ^[0-9]+$ ]]; then
        echo "FAIL: could not parse lookup count for N=${n} (${layout}) (got '${c}')" >&2
        exit 1
    fi
    if ! [[ "${ir}" =~ ^[0-9]+$ ]]; then
        echo "FAIL: could not parse instruction total for N=${n} (${layout}) (got '${ir}')" >&2
        exit 1
    fi
    echo "${c} ${ir}"
}

# Plain assignments, so a failed measurement stops the script under set -e.
P1="$(run_measure "${N1}" plain)"
P2="$(run_measure "${N2}" plain)"
K1="$(run_measure "${N1}" chained)"
K2="$(run_measure "${N2}" chained)"
read -r C1 PIR1 <<<"${P1}"
read -r C2 PIR2 <<<"${P2}"
read -r _ KIR1 <<<"${K1}"
read -r _ KIR2 <<<"${K2}"
DELTA=$(( C2 - C1 ))
PLAIN_PER_PASS=$(( (PIR2 - PIR1) / (N2 - N1) ))
CHAINED_PER_PASS=$(( (KIR2 - KIR1) / (N2 - N1) ))
LAYOUT_EXTRA=$(( CHAINED_PER_PASS - PLAIN_PER_PASS ))

echo "lookup calls (plain): N=${N1} -> ${C1} ; N=${N2} -> ${C2} ; delta=${DELTA} (bound ${MAX_DELTA})"
echo "instructions per warm pass: plain=${PLAIN_PER_PASS} chained=${CHAINED_PER_PASS} ; chained - plain=${LAYOUT_EXTRA} (bound ${MAX_LAYOUT_EXTRA})"

if (( C1 >= MIN_VISIBLE_CALLS )); then
    if (( DELTA >= MAX_DELTA )); then
        echo "FAIL: dict hash/probe calls grow with iteration count (delta ${DELTA} >= ${MAX_DELTA}); warm accesses still probe the instance dict" >&2
        exit 1
    fi
    echo "ok: steady-state attribute access does not scale dict hash/probe calls with iteration count (delta ${DELTA} < ${MAX_DELTA})"
else
    # The probe routine never showed up as a call, so the call slope cannot tell
    # a removed probe from a hidden one. The layout check below decides.
    echo "lookup routine not visible as a call (${C1} < ${MIN_VISIBLE_CALLS} calls in the N=${N1} run); skipping the call bound"
fi

if (( LAYOUT_EXTRA >= MAX_LAYOUT_EXTRA )); then
    echo "FAIL: a warm pass costs ${LAYOUT_EXTRA} more instructions when the attributes sit deeper in the instance dict's probe chains (bound ${MAX_LAYOUT_EXTRA}); warm accesses still hash and probe the dict" >&2
    exit 1
fi
echo "PASS: warm pass cost does not depend on where the attributes sit in the instance dict (chained - plain = ${LAYOUT_EXTRA} < ${MAX_LAYOUT_EXTRA})"
exit 0
