# Attribute and method resolution results that stay the same whatever the
# interpreter does to speed up warm access sites. Run by the built `rustpython`
# interpreter; every check is a plain Python assertion about observable behavior,
# and the program prints "ok" and exits 0 only if every scenario resolves the way
# the interpreter resolves it today.
#
# Each scenario warms an access site well past the specialization threshold and
# then changes something about the object: an instance attribute shadowing a
# class method or a plain class attribute, keys deleted or added (directly or
# through the dict's own methods), __dict__ replaced or cleared, dicts with
# holes, several instances sharing one access site where only one of them
# differs (it gains a name, or loses names the others still hold), an instance
# whose __dict__ is a dict subclass with overridden lookup and store methods,
# and a store whose replaced value has a finalizer that reads the same object.


class MethodHolder:
    def m(self):
        return "method"


def method_shadowed_after_specialization():
    obj = MethodHolder()
    obj.pad = 1
    for _ in range(300):
        assert obj.m() == "method"
    # Shadow the class method with an instance attribute after warmup.
    obj.m = lambda: "instance"
    assert obj.m() == "instance"
    del obj.m
    assert obj.m() == "method"
    obj.__dict__["m"] = lambda: "dict"
    assert obj.m() == "dict"
    del obj.__dict__["m"]
    assert obj.m() == "method"


def method_with_value_only_updates():
    obj = MethodHolder()
    obj.pad = 0
    for i in range(500):
        obj.pad = i  # value-only updates: the key set never changes
        assert obj.m() == "method"


class ClassAttrHolder:
    color = "class"


def class_attribute_shadowed_after_specialization():
    # A plain class attribute (no descriptor, not a method) read through an
    # instance. After the read site is warm, an instance attribute of the same
    # name must win, and removing it must bring the class attribute back.
    def read_color(obj):
        return obj.color

    obj = ClassAttrHolder()
    obj.pad = 1
    for _ in range(300):
        assert read_color(obj) == "class"
    obj.color = "instance"
    assert read_color(obj) == "instance"
    del obj.color
    assert read_color(obj) == "class"
    obj.__dict__["color"] = "dict"
    assert read_color(obj) == "dict"
    del obj.__dict__["color"]
    assert read_color(obj) == "class"

    # Value-only writes to another attribute leave the class attribute visible.
    for i in range(300):
        obj.pad = i
        assert read_color(obj) == "class"

    # Several same-layout instances share the read site and only one of them
    # gains the shadowing name.
    objs = [ClassAttrHolder() for _ in range(30)]
    for o in objs:
        o.pad = 1
    for _ in range(300):
        for o in objs:
            assert read_color(o) == "class"
    objs[7].color = "seven"
    for i, o in enumerate(objs):
        expected = "seven" if i == 7 else "class"
        assert read_color(o) == expected
    del objs[7].color
    for o in objs:
        assert read_color(o) == "class"


class Plain:
    pass


def load_hint_survives_key_churn():
    obj = Plain()
    obj.a = 1
    obj.b = 2
    obj.x = "first"
    for _ in range(300):
        assert obj.x == "first"
    del obj.a
    del obj.b
    assert obj.x == "first"
    del obj.x
    try:
        obj.x
    except AttributeError:
        pass
    else:
        raise AssertionError("expected AttributeError after deleting attribute")
    obj.x = "second"
    assert obj.x == "second"


def store_hint_survives_dict_replacement():
    obj = Plain()
    obj.v = 0
    for i in range(500):
        obj.v = i
        assert obj.v == i
    obj.__dict__ = {"v": "fresh"}
    for i in range(300):
        obj.v = i
        assert obj.v == i
    obj.__dict__.clear()
    obj.v = "back"
    assert obj.v == "back"


class ShapedCounter:
    def __init__(self):
        self.a = 1
        self.b = 2

    def m(self):
        return "method"


def shape_sharing_shadow_one_instance():
    objs = [ShapedCounter() for _ in range(30)]
    for _ in range(300):
        for o in objs:
            assert o.m() == "method"
    objs[13].m = lambda: "thirteen"
    for i, o in enumerate(objs):
        expected = "thirteen" if i == 13 else "method"
        assert o.m() == expected
    del objs[13].m
    for o in objs:
        assert o.m() == "method"


class TrackingDict(dict):
    # A dict subclass that records every lookup routed through its overridden
    # mapping protocol. Instances used as an object's __dict__ have these
    # overrides called on every attribute access today, and that stays so. The
    # call counters live in instance attributes, not dict items, so reading them
    # never re-enters the overrides.
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.getitem_calls = 0
        self.missing_calls = 0

    def __getitem__(self, key):
        self.getitem_calls += 1
        return super().__getitem__(key)

    def __missing__(self, key):
        self.missing_calls += 1
        raise KeyError(key)


def dict_subclass_resolution():
    import sys

    class Dummy:
        pass

    obj = Dummy()
    d = TrackingDict({"x": 42})
    obj.__dict__ = d
    warmup = 500
    for _ in range(warmup):
        assert obj.x == 42
    # In RustPython every attribute read on an instance whose __dict__ is a dict
    # subclass goes through that subclass's __getitem__, including after the
    # access site has specialized. Reading the raw entry storage directly would
    # still return 42 but skip the override. The check is scoped to RustPython
    # because CPython reads instance dicts without calling subclass overrides.
    if sys.implementation.name == "rustpython":
        assert d.getitem_calls >= warmup


class CountingDict(dict):
    # Counts lookups routed through its __getitem__ override. It defines no
    # __missing__, so a name it does not hold is reported absent and resolution
    # falls back to the class.
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.getitem_calls = 0

    def __getitem__(self, key):
        self.getitem_calls += 1
        return super().__getitem__(key)


class LateShadowDict(dict):
    # Answers "m" from __getitem__ once switched on. The switch is an attribute
    # of the dict object itself, so flipping it leaves the dict's keys and values
    # untouched.
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.active = False

    def __getitem__(self, key):
        if key == "m" and self.active:
            return lambda: "from-getitem"
        return super().__getitem__(key)


def dict_subclass_method_resolution():
    import sys

    class Host:
        def m(self):
            return "method"

    def call_m(obj):
        return obj.m()

    # In RustPython a method call on an instance whose __dict__ is a dict
    # subclass asks that dict for the name through its __getitem__ before
    # falling back to the class, on every call, warm or not. CPython reads the
    # instance dict directly, so these checks are RustPython-only.
    counted = Host()
    counting = CountingDict(pad=1)
    counted.__dict__ = counting
    for _ in range(300):
        assert call_m(counted) == "method"
    if sys.implementation.name == "rustpython":
        before = counting.getitem_calls
        for _ in range(100):
            assert call_m(counted) == "method"
        assert counting.getitem_calls - before >= 100

        # The override can also change the answer without any key changing.
        late = Host()
        shadow = LateShadowDict(pad=1)
        late.__dict__ = shadow
        for _ in range(300):
            assert call_m(late) == "method"
        shadow.active = True
        assert call_m(late) == "from-getitem"
        shadow.active = False
        assert call_m(late) == "method"


class RecordingDict(dict):
    # Wraps every value stored through its __setitem__ override and counts the
    # store and delete calls. Instances used as an object's __dict__ have these
    # overrides called on every attribute write today, warm or not, and that
    # stays so. The counters live in attributes of the dict object, not in its
    # items, so updating them never re-enters the overrides.
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setitem_calls = 0
        self.delitem_calls = 0

    def __setitem__(self, key, value):
        self.setitem_calls += 1
        super().__setitem__(key, ("stored", value))

    def __delitem__(self, key):
        self.delitem_calls += 1
        super().__delitem__(key)


def dict_subclass_store_resolution():
    import sys

    class Holder:
        pass

    def set_x(obj, value):
        obj.x = value

    def read_x(obj):
        return obj.x

    obj = Holder()
    d = RecordingDict()
    obj.__dict__ = d
    warmup = 500
    for i in range(warmup):
        set_x(obj, i)
        # Whatever the override put in the dict is what the attribute reads
        # back as, before and after the store site is warm.
        assert read_x(obj) == dict.__getitem__(d, "x")
    # In RustPython an attribute store on an instance whose __dict__ is a dict
    # subclass goes through that subclass's __setitem__, including after the
    # store site has specialized, so the stored value is the wrapped one. The
    # check is scoped to RustPython because CPython writes instance dicts
    # without calling subclass overrides.
    if sys.implementation.name == "rustpython":
        before = d.setitem_calls
        for i in range(100):
            set_x(obj, i)
            assert read_x(obj) == ("stored", i)
        assert d.setitem_calls - before >= 100

    del obj.x
    assert "x" not in d
    if sys.implementation.name == "rustpython":
        assert d.delitem_calls >= 1
    set_x(obj, "again")
    assert read_x(obj) == dict.__getitem__(d, "x")


class Twin:
    def m(self):
        return "method"


def same_history_different_keys():
    # Pairs of instances whose dicts went through the same number and kind of
    # changes but hold different names. Whatever one of them taught a shared
    # access site must not be applied to the other.
    def call_m(obj):
        return obj.m()

    def read_x(obj):
        return obj.x

    plain = Twin()
    plain.p = 1
    shadowing = Twin()
    shadowing.m = lambda: "instance"
    for _ in range(300):
        assert call_m(plain) == "method"
    assert call_m(shadowing) == "instance"
    for _ in range(100):
        assert call_m(plain) == "method"
        assert call_m(shadowing) == "instance"

    first = Twin()
    first.x = "first-x"
    first.y = "first-y"
    second = Twin()
    second.y = "second-y"
    second.x = "second-x"
    for _ in range(300):
        assert read_x(first) == "first-x"
    assert read_x(second) == "second-x"
    for _ in range(100):
        assert read_x(first) == "first-x"
        assert read_x(second) == "second-x"


def keys_changed_through_dict_methods():
    # After the call site is warm, the instance gains or loses the shadowing
    # name through each of the dict's own mutators and the builtins that wrap
    # them. Every change shows up on the very next call.
    class Target:
        def m(self):
            return "method"

    def call_m(obj):
        return obj.m()

    def read_v(obj):
        return obj.v

    def settle(obj, expected):
        for _ in range(100):
            assert call_m(obj) == expected

    obj = Target()
    obj.pad = 0
    obj.v = "v0"
    d = obj.__dict__
    settle(obj, "method")

    d.setdefault("m", lambda: "setdefault")
    assert call_m(obj) == "setdefault"
    settle(obj, "setdefault")
    d.pop("m")
    assert call_m(obj) == "method"
    settle(obj, "method")

    d.update(m=lambda: "update")
    assert call_m(obj) == "update"
    settle(obj, "update")
    assert d.popitem()[0] == "m"
    assert call_m(obj) == "method"
    settle(obj, "method")

    setattr(obj, "m", lambda: "setattr")
    assert call_m(obj) == "setattr"
    delattr(obj, "m")
    assert call_m(obj) == "method"
    settle(obj, "method")

    vars(obj)["m"] = lambda: "vars"
    assert call_m(obj) == "vars"
    vars(obj).clear()
    assert call_m(obj) == "method"

    # Value reads and writes on a warm site after the attribute moved to a new
    # position in the dict.
    obj.pad = 0
    obj.v = "v1"
    for i in range(300):
        obj.v = i
        assert read_v(obj) == i
    d = obj.__dict__
    d.pop("v")
    d["w"] = "w"
    d.setdefault("v", "back")
    assert read_v(obj) == "back"
    for i in range(50):
        obj.v = i
        assert read_v(obj) == i
    assert d["w"] == "w"
    assert sorted(d) == ["pad", "v", "w"]


# One class and one set of access sites per removal path, each compiled with
# its own names. {label} and {shown} are instance attributes that hide a plain
# class attribute and a class method of the same name; every instance built by
# __init__ holds the same keys in the same order.
SHARED_LAYOUT_TEMPLATE = """
class Pair:
    {label} = "class-label"

    def {shown}(self):
        return "class-shown"

    def {m}(self):
        return "method"

    def __init__(self, tag):
        self.{pad} = tag
        self.{label} = tag + "-label"
        self.{shown} = lambda: tag + "-shown"


def call_m(obj):
    return obj.{m}()


def call_shown(obj):
    return obj.{shown}()


def read_label(obj):
    return obj.{label}


def remove_with_del(obj):
    del obj.{label}
    del obj.{shown}
"""


def shared_layout_removal_from_one_instance():
    # Two instances with the same attributes share every access site. After
    # the sites are warm on both, one of them loses its attributes through one
    # of the removal paths and falls back to the class. The other keeps its
    # own attributes, at the same warm sites, for as long as it holds them.
    def remove_with_delattr(obj, names):
        delattr(obj, names["label"])
        delattr(obj, names["shown"])

    def remove_with_del_item(obj, names):
        del obj.__dict__[names["label"]]
        del obj.__dict__[names["shown"]]

    def remove_with_pop(obj, names):
        obj.__dict__.pop(names["label"])
        obj.__dict__.pop(names["shown"])

    def remove_with_popitem(obj, names):
        assert obj.__dict__.popitem()[0] == names["shown"]
        assert obj.__dict__.popitem()[0] == names["label"]

    def remove_with_clear(obj, names):
        obj.__dict__.clear()

    removals = {
        "del": None,
        "delattr": remove_with_delattr,
        "delitem": remove_with_del_item,
        "pop": remove_with_pop,
        "popitem": remove_with_popitem,
        "clear": remove_with_clear,
    }
    for path, remove in removals.items():
        names = {
            "pad": "pad_" + path,
            "label": "label_" + path,
            "shown": "shown_" + path,
            "m": "m_" + path,
        }
        ns = {}
        exec(compile(SHARED_LAYOUT_TEMPLATE.format(**names), "<" + path + ">", "exec"), ns)
        call_m, call_shown, read_label = ns["call_m"], ns["call_shown"], ns["read_label"]

        first, second = ns["Pair"]("first"), ns["Pair"]("second")
        assert list(vars(first)) == list(vars(second))
        for _ in range(300):
            for obj, tag in ((first, "first"), (second, "second")):
                assert call_m(obj) == "method"
                assert call_shown(obj) == tag + "-shown"
                assert read_label(obj) == tag + "-label"

        if remove is None:
            ns["remove_with_del"](first)
        else:
            remove(first, names)
        assert names["label"] not in vars(first)
        assert names["shown"] not in vars(first)

        # The changed instance alone first, long enough for the sites to settle
        # on it, then both instances in turn at the same sites.
        for _ in range(300):
            assert call_shown(first) == "class-shown"
            assert read_label(first) == "class-label"
            assert call_m(first) == "method"
        for _ in range(300):
            assert call_shown(second) == "second-shown", path
            assert read_label(second) == "second-label", path
            assert call_m(second) == "method"
            assert call_shown(first) == "class-shown", path
            assert read_label(first) == "class-label", path


class FinalizerOwner:
    pass


class ReadsOwnerOnDelete:
    # Reads another attribute of its owner when it is finalized, so replacing
    # it through a store into that owner runs this read while the store is
    # still in progress.
    def __init__(self, owner):
        self.owner = owner

    def __del__(self):
        self.owner.y


def store_replaces_value_with_finalizer():
    def set_x(obj, value):
        obj.x = value

    owner = FinalizerOwner()
    owner.y = "y"
    owner.x = ReadsOwnerOnDelete(owner)
    last = None
    for _ in range(300):
        last = ReadsOwnerOnDelete(owner)
        set_x(owner, last)
    assert owner.x is last
    assert owner.y == "y"


def holey_dict_falls_back():
    class Holey:
        def m(self):
            return "g"

    def call_m(obj):
        # one access site shared by both instances
        return obj.m()

    g1, g2 = Holey(), Holey()
    for o in (g1, g2):
        o.x = 1
        o.y = 2
        o.z = 3
        del o.y  # leaves a hole in the entries
    for _ in range(300):
        assert call_m(g1) == "g"
        assert call_m(g2) == "g"
    g2.m = lambda: "g2"
    assert call_m(g1) == "g"
    assert call_m(g2) == "g2"


def main():
    scenarios = [
        method_shadowed_after_specialization,
        method_with_value_only_updates,
        class_attribute_shadowed_after_specialization,
        load_hint_survives_key_churn,
        store_hint_survives_dict_replacement,
        shape_sharing_shadow_one_instance,
        dict_subclass_resolution,
        dict_subclass_method_resolution,
        dict_subclass_store_resolution,
        same_history_different_keys,
        keys_changed_through_dict_methods,
        shared_layout_removal_from_one_instance,
        store_replaces_value_with_finalizer,
        holey_dict_falls_back,
    ]
    for scenario in scenarios:
        # Name each scenario before it runs, so a failure or a hang points at it.
        print("running", scenario.__name__, flush=True)
        scenario()
    print("ok")


main()
