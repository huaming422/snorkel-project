## Task

The `event` we get in `onItemHighlighted` details on Menu, Combobox and Autocomplete is junk when the highlight moves by keyboard or mouse.
Open a menu, press ArrowDown, and log the details.
`reason` is `'keyboard'`, but `event.key` is `undefined` and `event.getModifierState('Shift')` throws.
So a handler has no way to know which key was pressed, or whether Shift was down.

The typings say a `'keyboard'` highlight comes with a `KeyboardEvent` and a `'pointer'` one with a pointer event.
What comes through is a generic placeholder event with nothing on it.

Menu arrow keys are only one case.
I see the same thing with:
- arrow keys in a Combobox or Autocomplete input
- type-to-match in a Menu
- moving the mouse onto a menu item, and moving it off again
- hovering a submenu trigger
- arrow keys in the filter input of a filterable Menu
- typing in a Combobox input after arrowing to an item, which clears the highlight

Please find out why the callback gets a placeholder, and make each of these report the native event that caused the change.
Hovering an item comes in as a `MouseEvent` and leaving it as a `PointerEvent`, and both are fine under `'pointer'`.
The reason and the event have to agree.
Don't report `'keyboard'` without a real keyboard event, or `'pointer'` without a real mouse or pointer event.

One thing should not change.
With `autoHighlight` on, the first match an Autocomplete highlights while you type is an automatic highlight, and it reports `'none'` today.
It should keep reporting `'none'`.
