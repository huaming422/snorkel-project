## Task

The `event` we get in `onItemHighlighted` details on Menu, Combobox and Autocomplete is junk when the highlight moves by keyboard or mouse.
Open a menu, press ArrowDown, and log the details.
`reason` is `'keyboard'`, but `event.key` is `undefined` and `event.getModifierState('Shift')` throws.
So a handler has no way to know which key was pressed, or whether Shift was down.

The typings say a `'keyboard'` highlight comes with a `KeyboardEvent` and a `'pointer'` one with a pointer event.
What comes through is a generic placeholder event with nothing on it.

Menu arrow keys are only one case.
I see the same thing with:
- arrow keys in a Combobox or Autocomplete input
- moving the mouse onto an item in a Combobox or Autocomplete list
- type-to-match in a Menu
- moving the mouse onto a menu item, and moving it off again
- hovering a submenu trigger
- arrow keys in the filter input of a filterable Menu
- opening a filterable submenu with ArrowRight, and closing it again with ArrowLeft or Escape
- typing in a Combobox input after arrowing to an item, which clears the highlight
- removing the highlighted item's chip, with Backspace in the empty input or with the chip's remove button
- pressing the clear control while an item is highlighted

Please find out why the callback gets a placeholder.
Then make every highlight change the user causes report the native event behind it, not just the ones listed.
Hovering an item comes in as a `MouseEvent` and leaving it as a `PointerEvent`, and both are fine under `'pointer'`.
The reason and the event have to agree.
Don't report `'keyboard'` without a real keyboard event, or `'pointer'` without a real mouse or pointer event.
Any other event, like the input event from typing, is still reported, under `'none'`.

Two moves can stay `'none'` without a real event, because the key is already gone when the highlight changes.
One is opening a filterable submenu with Enter or Space.
The other is a plain submenu handing the highlight back to a filterable menu after it closes.

One thing should not change.
With `autoHighlight` on, the first match an Autocomplete highlights while you type is an automatic highlight, and it reports `'none'` today.
It should keep reporting `'none'`.
