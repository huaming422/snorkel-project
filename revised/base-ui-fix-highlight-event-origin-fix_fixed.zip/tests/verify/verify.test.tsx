// Behavioral verifier for the item-highlight notification's originating event.
//
// Every assertion here goes through the public `onItemHighlighted(value,
// details)` callback exposed by Menu, Combobox, and Autocomplete. The callback,
// its `details.reason` string union ('keyboard' | 'pointer' | 'imperative-action'
// | 'none'), and `details.event` are the documented public contract; this file
// touches no internal store method, helper, ref, or module. Reason values are
// written as plain string literals because the public surface uses those
// strings, so the checks do not depend on how the event is carried internally.
//
// Rendering uses the repo's own `createRenderer()` harness (the same one every
// sibling *.test.tsx uses), which returns a `user` event driver and runs under
// jsdom (VITEST_ENV=jsdom, set by tests/test-setup.sh).

import { expect, vi, describe, it, onTestFinished } from 'vitest';
import * as React from 'react';
import { act, fireEvent, screen, waitFor } from '@mui/internal-test-utils';
import { createRenderer } from '#test-utils';
import { Menu } from '@base-ui/react/menu';
import { Combobox } from '@base-ui/react/combobox';
import { Autocomplete } from '@base-ui/react/autocomplete';

describe('onItemHighlighted originating event', () => {
  const { render } = createRenderer();

  // Records each event of the given types that the document receives (capture
  // phase, so non-bubbling events are seen too). A check can then compare the
  // reported event with the exact objects that were dispatched. A new event
  // built from a copied `key` is a different object and loses modifier state.
  function recordEvents(types: string[]) {
    const seen: Event[] = [];
    const listener = (event: Event) => {
      seen.push(event);
    };
    types.forEach((type) => document.addEventListener(type, listener, true));
    onTestFinished(() => {
      types.forEach((type) => document.removeEventListener(type, listener, true));
    });
    return { all: () => seen, last: () => seen[seen.length - 1] };
  }

  // A small Menu with two plain items plus a submenu trigger, covering the
  // keyboard, typeahead, item-hover, and submenu-hover entry points.
  function HighlightMenu(props: {
    onItemHighlighted: Menu.Root.Props['onItemHighlighted'];
  }) {
    return (
      <Menu.Root onItemHighlighted={props.onItemHighlighted}>
        <Menu.Trigger>Toggle</Menu.Trigger>
        <Menu.Portal>
          <Menu.Positioner>
            <Menu.Popup>
              <Menu.Item>One</Menu.Item>
              <Menu.Item>Two</Menu.Item>
              <Menu.SubmenuRoot>
                <Menu.SubmenuTrigger>Three</Menu.SubmenuTrigger>
                <Menu.Portal>
                  <Menu.Positioner>
                    <Menu.Popup>
                      <Menu.Item>Nested</Menu.Item>
                    </Menu.Popup>
                  </Menu.Positioner>
                </Menu.Portal>
              </Menu.SubmenuRoot>
            </Menu.Popup>
          </Menu.Positioner>
        </Menu.Portal>
      </Menu.Root>
    );
  }

  it('keyboard_event_real', async () => {
    const onItemHighlighted = vi.fn();
    const keydowns = recordEvents(['keydown']);
    const { user } = await render(
      <HighlightMenu onItemHighlighted={onItemHighlighted} />,
    );

    const trigger = screen.getByRole('button', { name: 'Toggle' });
    await act(async () => {
      trigger.focus();
    });
    await user.keyboard('[Enter]');
    await waitFor(() => {
      expect(screen.getByRole('menuitem', { name: 'One' })).toHaveFocus();
    });

    await user.keyboard('{ArrowDown}');
    await waitFor(() => {
      expect(screen.getByRole('menuitem', { name: 'Two' })).toHaveFocus();
    });

    const details = onItemHighlighted.mock.lastCall?.[1];
    expect(details.reason).toBe('keyboard');
    // The details carry the native keydown, with the pressed key.
    expect(details.event).toBeInstanceOf(KeyboardEvent);
    expect(details.event.key).toBe('ArrowDown');
    expect(details.event).toBe(keydowns.last());
  });

  it('typeahead_event_real', async () => {
    const onItemHighlighted = vi.fn();
    const keydowns = recordEvents(['keydown']);
    const { user } = await render(
      <HighlightMenu onItemHighlighted={onItemHighlighted} />,
    );

    const trigger = screen.getByRole('button', { name: 'Toggle' });
    await act(async () => {
      trigger.focus();
    });
    await user.keyboard('[Enter]');
    await waitFor(() => {
      expect(screen.getByRole('menuitem', { name: 'One' })).toHaveFocus();
    });

    // Type-to-match moves the highlight from the typed character's keydown.
    await user.keyboard('t');
    await waitFor(() => {
      expect(screen.getByRole('menuitem', { name: 'Two' })).toHaveFocus();
    });

    const details = onItemHighlighted.mock.lastCall?.[1];
    expect(details.reason).toBe('keyboard');
    expect(details.event).toBeInstanceOf(KeyboardEvent);
    expect(details.event.key).toBe('t');
    expect(details.event).toBe(keydowns.last());
  });

  it('pointer_event_real', async () => {
    const onItemHighlighted = vi.fn();
    await render(<HighlightMenu onItemHighlighted={onItemHighlighted} />);

    fireEvent.click(screen.getByRole('button', { name: 'Toggle' }));
    const item = await screen.findByRole('menuitem', { name: 'Two' });

    // Hovering an item reports the exact MouseEvent that was dispatched.
    const hoverEvent = new MouseEvent('mousemove', { bubbles: true });
    fireEvent(item, hoverEvent);
    await waitFor(() => {
      expect(onItemHighlighted).toHaveBeenLastCalledWith(item, expect.anything());
    });

    let details = onItemHighlighted.mock.lastCall?.[1];
    expect(details.reason).toBe('pointer');
    expect(details.event).toBeInstanceOf(MouseEvent);
    expect(details.event).toBe(hoverEvent);
    expect(details.event).not.toBeInstanceOf(PointerEvent);

    // Leaving an item reports the exact PointerEvent that was dispatched, also
    // under 'pointer'. Leaving moves the highlight off the item, so the check
    // reads the event of the latest notification rather than its value.
    const leaveEvent = new PointerEvent('pointerout', {
      bubbles: true,
      pointerType: 'mouse',
    });
    fireEvent(item, leaveEvent);
    await waitFor(() => {
      expect(onItemHighlighted.mock.lastCall?.[1]?.event).toBe(leaveEvent);
    });
    details = onItemHighlighted.mock.lastCall?.[1];
    expect(details.reason).toBe('pointer');
    expect(details.event).toBeInstanceOf(PointerEvent);
  });

  it('combobox_autocomplete_event_real', async () => {
    // Combobox and Autocomplete report arrow-key highlights with the native
    // keydown, the same as Menu.
    const keydowns = recordEvents(['keydown']);
    const comboboxHighlighted = vi.fn();
    const combobox = await render(
      <Combobox.Root items={['a', 'b', 'c']} onItemHighlighted={comboboxHighlighted}>
        <Combobox.Input data-testid="combobox-input" />
        <Combobox.Portal>
          <Combobox.Positioner>
            <Combobox.Popup>
              <Combobox.List>
                {(item: string) => (
                  <Combobox.Item key={item} value={item}>
                    {item}
                  </Combobox.Item>
                )}
              </Combobox.List>
            </Combobox.Popup>
          </Combobox.Positioner>
        </Combobox.Portal>
      </Combobox.Root>,
    );

    await combobox.user.click(screen.getByTestId('combobox-input'));
    await waitFor(() => expect(screen.getByRole('listbox')).not.toBe(null));
    await combobox.user.keyboard('{ArrowDown}');
    await waitFor(() => {
      expect(comboboxHighlighted.mock.calls.length).toBeGreaterThan(0);
    });

    const [comboboxValue, comboboxDetails] = comboboxHighlighted.mock.lastCall ?? [];
    expect(comboboxValue).toBe('a');
    expect(comboboxDetails.reason).toBe('keyboard');
    expect(comboboxDetails.event).toBeInstanceOf(KeyboardEvent);
    expect(comboboxDetails.event.key).toBe('ArrowDown');
    expect(comboboxDetails.event).toBe(keydowns.last());

    combobox.unmount();

    const autocompleteHighlighted = vi.fn();
    const autocomplete = await render(
      <Autocomplete.Root
        items={['alpha', 'beta', 'gamma']}
        onItemHighlighted={autocompleteHighlighted}
      >
        <Autocomplete.Input data-testid="autocomplete-input" />
        <Autocomplete.Portal>
          <Autocomplete.Positioner>
            <Autocomplete.Popup>
              <Autocomplete.List>
                {(item: string) => (
                  <Autocomplete.Item key={item} value={item}>
                    {item}
                  </Autocomplete.Item>
                )}
              </Autocomplete.List>
            </Autocomplete.Popup>
          </Autocomplete.Positioner>
        </Autocomplete.Portal>
      </Autocomplete.Root>,
    );

    const autocompleteInput =
      screen.getByTestId<HTMLInputElement>('autocomplete-input');
    // Focus the input, then open + navigate with ArrowDown so the highlight is
    // keyboard-driven (no pointer event involved).
    await act(async () => {
      autocompleteInput.focus();
    });
    // First ArrowDown opens the popup; a follow-up ArrowDown drives an
    // unambiguous keyboard highlight, so a highlight notification is emitted
    // and its originating event must be the real keydown.
    await autocomplete.user.keyboard('{ArrowDown}');
    await screen.findByRole('option', { name: 'alpha' });
    await autocomplete.user.keyboard('{ArrowDown}');
    await waitFor(() => {
      expect(autocompleteHighlighted.mock.calls.length).toBeGreaterThan(0);
    });

    const autocompleteDetails = autocompleteHighlighted.mock.lastCall?.[1];
    expect(autocompleteDetails.reason).toBe('keyboard');
    expect(autocompleteDetails.event).toBeInstanceOf(KeyboardEvent);
    expect(autocompleteDetails.event.key).toBe('ArrowDown');
    expect(autocompleteDetails.event).toBe(keydowns.last());
  });

  it('noninteractive_reason_none', async () => {
    // With autoHighlight, the first match highlighted while the user types is
    // an automatic highlight and reports 'none'.
    const onItemHighlighted = vi.fn();
    const { user } = await render(
      <Autocomplete.Root
        items={['alpha', 'alpine', 'beta']}
        autoHighlight
        onItemHighlighted={onItemHighlighted}
      >
        <Autocomplete.Input data-testid="input" />
        <Autocomplete.Portal>
          <Autocomplete.Positioner>
            <Autocomplete.Popup>
              <Autocomplete.List>
                {(item: string) => (
                  <Autocomplete.Item key={item} value={item}>
                    {item}
                  </Autocomplete.Item>
                )}
              </Autocomplete.List>
            </Autocomplete.Popup>
          </Autocomplete.Positioner>
        </Autocomplete.Portal>
      </Autocomplete.Root>,
    );

    const input = screen.getByTestId<HTMLInputElement>('input');
    await user.type(input, 'a');

    await screen.findByRole('option', { name: 'alpha' });
    await waitFor(() => {
      expect(onItemHighlighted.mock.calls.length).toBeGreaterThan(0);
    });

    const [value, details] = onItemHighlighted.mock.lastCall ?? [];
    expect(value).toBe('alpha');
    expect(details.reason).toBe('none');
  });

  it('filterable_menu_keyboard_event_real', async () => {
    const keydowns = recordEvents(['keydown']);
    // Arrow keys in the filter input of an open filterable menu report the
    // native keydown. Driven through the public Menu.Input.
    const onItemHighlighted = vi.fn();
    const { user } = await render(
      <Menu.FilterProvider>
        <Menu.Root open onItemHighlighted={onItemHighlighted}>
          <Menu.Portal>
            <Menu.Positioner>
              <Menu.Popup>
                <Menu.Input aria-label="Filter actions" />
                <Menu.List>
                  <Menu.Item>Rename</Menu.Item>
                  <Menu.Item>Delete</Menu.Item>
                </Menu.List>
              </Menu.Popup>
            </Menu.Positioner>
          </Menu.Portal>
        </Menu.Root>
      </Menu.FilterProvider>,
    );

    const input = screen.getByRole('searchbox', { name: 'Filter actions' });
    await act(async () => {
      input.focus();
    });
    await user.keyboard('[ArrowDown]');

    await waitFor(() => {
      expect(onItemHighlighted).toHaveBeenLastCalledWith(
        screen.getByRole('menuitem', { name: 'Rename' }),
        expect.anything(),
      );
    });

    const details = onItemHighlighted.mock.lastCall?.[1];
    expect(details.reason).toBe('keyboard');
    expect(details.event).toBeInstanceOf(KeyboardEvent);
    expect(details.event.key).toBe('ArrowDown');
    expect(details.event).toBe(keydowns.last());
  });

  // A small Combobox whose items all contain 'a', so typing 'a' after a
  // keyboard highlight clears the active item without emptying the list.
  function ClearableCombobox(props: {
    onItemHighlighted: Combobox.Root.Props<string>['onItemHighlighted'];
  }) {
    return (
      <Combobox.Root
        items={['apple', 'apricot', 'banana']}
        onItemHighlighted={props.onItemHighlighted}
      >
        <Combobox.Input data-testid="input" />
        <Combobox.Portal>
          <Combobox.Positioner>
            <Combobox.Popup>
              <Combobox.List>
                {(item: string) => (
                  <Combobox.Item key={item} value={item}>
                    {item}
                  </Combobox.Item>
                )}
              </Combobox.List>
            </Combobox.Popup>
          </Combobox.Positioner>
        </Combobox.Portal>
      </Combobox.Root>
    );
  }

  it('clear_highlight_event_not_placeholder', async () => {
    // Typing after a keyboard highlight clears the highlight. The reported
    // event is one the typing dispatched, and the reason agrees with it: the
    // exact keydown under 'keyboard', or the exact input event under 'none'.
    const onItemHighlighted = vi.fn();
    const { user } = await render(
      <ClearableCombobox onItemHighlighted={onItemHighlighted} />,
    );

    await user.click(screen.getByTestId('input'));
    await user.keyboard('{ArrowDown}');
    await waitFor(() => {
      expect(onItemHighlighted).toHaveBeenLastCalledWith('apple', expect.anything());
    });

    const typed = recordEvents(['keydown', 'input']);
    await user.keyboard('a');
    await waitFor(() => {
      expect(onItemHighlighted).toHaveBeenLastCalledWith(undefined, expect.anything());
    });

    const details = onItemHighlighted.mock.lastCall?.[1];
    if (details.reason === 'keyboard') {
      const keydown = typed.all().find((event) => event.type === 'keydown');
      expect(details.event).toBeInstanceOf(KeyboardEvent);
      expect(details.event.key).toBe('a');
      expect(details.event).toBe(keydown);
    } else {
      // Typing is not a pointer interaction, so the other accepted reason is
      // 'none', reported with the input event the typing dispatched.
      const input = typed.all().find((event) => event.type === 'input');
      expect(details.reason).toBe('none');
      expect(input).toBeDefined();
      expect(details.event).toBe(input);
    }
  });

  it('submenu_hover_pointer', async () => {
    // Hovering a submenu trigger reports 'pointer' with one of the native mouse
    // events the hover dispatched on it.
    const onItemHighlighted = vi.fn();
    await render(<HighlightMenu onItemHighlighted={onItemHighlighted} />);

    fireEvent.click(screen.getByRole('button', { name: 'Toggle' }));
    const submenuTrigger = await screen.findByRole('menuitem', { name: 'Three' });
    const mouseEvents = recordEvents(['mouseenter', 'mouseover']);
    fireEvent.mouseEnter(submenuTrigger);
    await waitFor(() => {
      expect(onItemHighlighted).toHaveBeenLastCalledWith(
        submenuTrigger,
        expect.anything(),
      );
    });

    const details = onItemHighlighted.mock.lastCall?.[1];
    expect(details.reason).toBe('pointer');
    expect(details.event).toBeInstanceOf(MouseEvent);
    // Either native event the hover dispatched is accepted.
    expect(mouseEvents.all()).toContain(details.event);
  });

  // The reported reason agrees with the reported event: 'keyboard' with a
  // KeyboardEvent, 'pointer' with a MouseEvent or PointerEvent, and any other
  // event under 'none'.
  function expectReasonAgrees(details: { reason: string; event: Event }) {
    if (details.reason === 'keyboard') {
      expect(details.event).toBeInstanceOf(KeyboardEvent);
    } else if (details.reason === 'pointer') {
      expect(details.event).toBeInstanceOf(MouseEvent);
    } else {
      expect(details.reason).toBe('none');
    }
  }

  // A multiple-selection Combobox with a chip (and its remove button) for each
  // selected value, plus a clear control.
  function ChipsCombobox(props: {
    onItemHighlighted: Combobox.Root.Props<string, true>['onItemHighlighted'];
  }) {
    return (
      <Combobox.Root
        multiple
        items={['apple', 'banana', 'cherry']}
        defaultValue={['apple', 'banana']}
        onItemHighlighted={props.onItemHighlighted}
      >
        <Combobox.Chips>
          <Combobox.Value>
            {(value: string[]) => (
              <React.Fragment>
                {value.map((item) => (
                  <Combobox.Chip key={item}>
                    {item}
                    <Combobox.ChipRemove data-testid={`remove-${item}`} />
                  </Combobox.Chip>
                ))}
                <Combobox.Input data-testid="input" />
              </React.Fragment>
            )}
          </Combobox.Value>
        </Combobox.Chips>
        <Combobox.Clear data-testid="clear" />
        <Combobox.Portal>
          <Combobox.Positioner>
            <Combobox.Popup>
              <Combobox.List>
                {(item: string) => (
                  <Combobox.Item key={item} value={item}>
                    {item}
                  </Combobox.Item>
                )}
              </Combobox.List>
            </Combobox.Popup>
          </Combobox.Positioner>
        </Combobox.Portal>
      </Combobox.Root>
    );
  }

  // Opens the chips Combobox and arrows down until 'banana', the item behind
  // the last chip, is highlighted.
  async function highlightBanana(
    user: Awaited<ReturnType<typeof render>>['user'],
    onItemHighlighted: ReturnType<typeof vi.fn>,
  ) {
    await user.click(screen.getByTestId('input'));
    await screen.findByRole('option', { name: 'banana' });
    for (let i = 0; i < 3 && onItemHighlighted.mock.lastCall?.[0] !== 'banana'; i += 1) {
      // eslint-disable-next-line no-await-in-loop
      await user.keyboard('{ArrowDown}');
    }
    expect(onItemHighlighted).toHaveBeenLastCalledWith('banana', expect.anything());
  }

  it('chip_backspace_keyboard_event', async () => {
    // Backspace in the empty input removes the last chip. Its item is the
    // highlighted one, so the highlight clears under 'keyboard' with that
    // exact keydown.
    const onItemHighlighted = vi.fn();
    const { user } = await render(<ChipsCombobox onItemHighlighted={onItemHighlighted} />);
    await highlightBanana(user, onItemHighlighted);

    const keydowns = recordEvents(['keydown']);
    await user.keyboard('{Backspace}');
    await waitFor(() => {
      expect(onItemHighlighted).toHaveBeenLastCalledWith(undefined, expect.anything());
    });
    expect(screen.queryByTestId('remove-banana')).toBe(null);

    const details = onItemHighlighted.mock.lastCall?.[1];
    expect(details.reason).toBe('keyboard');
    expect(details.event).toBeInstanceOf(KeyboardEvent);
    expect(details.event.key).toBe('Backspace');
    expect(details.event).toBe(keydowns.last());
  });

  // The native events a pointer press on a button dispatches.
  const PRESS_EVENTS = ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'];

  it('chip_remove_button_event', async () => {
    // Pressing the remove button of the highlighted item's chip clears the
    // highlight with one of the events the press dispatched, under a reason
    // that agrees with it.
    const onItemHighlighted = vi.fn();
    const { user } = await render(<ChipsCombobox onItemHighlighted={onItemHighlighted} />);
    await highlightBanana(user, onItemHighlighted);

    const removeButton = screen.getByTestId('remove-banana');
    const press = recordEvents(PRESS_EVENTS);
    await user.click(removeButton);
    await waitFor(() => {
      expect(onItemHighlighted).toHaveBeenLastCalledWith(undefined, expect.anything());
    });
    expect(screen.queryByTestId('remove-banana')).toBe(null);

    const details = onItemHighlighted.mock.lastCall?.[1];
    expect(press.all()).toContain(details.event);
    expectReasonAgrees(details);
  });

  it('clear_control_event', async () => {
    // Pressing the clear control while an item is highlighted clears the
    // highlight with one of the events the press dispatched, under a reason
    // that agrees with it.
    const onItemHighlighted = vi.fn();
    const { user } = await render(<ChipsCombobox onItemHighlighted={onItemHighlighted} />);
    await highlightBanana(user, onItemHighlighted);

    const press = recordEvents(PRESS_EVENTS);
    await user.click(screen.getByTestId('clear'));
    await waitFor(() => {
      expect(onItemHighlighted).toHaveBeenLastCalledWith(undefined, expect.anything());
    });
    expect(screen.queryByTestId('remove-apple')).toBe(null);

    const details = onItemHighlighted.mock.lastCall?.[1];
    expect(press.all()).toContain(details.event);
    expectReasonAgrees(details);
  });

  // A plain menu whose submenu is filterable.
  function FilterableSubmenuMenu(props: {
    onItemHighlighted: Menu.Root.Props['onItemHighlighted'];
  }) {
    return (
      <Menu.Root defaultOpen onItemHighlighted={props.onItemHighlighted}>
        <Menu.Trigger>Actions</Menu.Trigger>
        <Menu.Portal>
          <Menu.Positioner>
            <Menu.Popup>
              <Menu.Item>Copy</Menu.Item>
              <Menu.FilterProvider>
                <Menu.SubmenuRoot>
                  <Menu.SubmenuTrigger openOnHover={false}>More</Menu.SubmenuTrigger>
                  <Menu.Portal>
                    <Menu.Positioner>
                      <Menu.Popup data-testid="submenu">
                        <Menu.Input aria-label="Filter child actions" />
                        <Menu.List>
                          <Menu.Item>Child</Menu.Item>
                        </Menu.List>
                      </Menu.Popup>
                    </Menu.Positioner>
                  </Menu.Portal>
                </Menu.SubmenuRoot>
              </Menu.FilterProvider>
            </Menu.Popup>
          </Menu.Positioner>
        </Menu.Portal>
      </Menu.Root>
    );
  }

  it.each(['ArrowLeft', 'Escape'])(
    'filterable_submenu_keyboard_event (%s closes it)',
    async (closeKey) => {
      // Opening a filterable submenu with the keyboard moves the parent's
      // highlight off its trigger, under 'keyboard' with the exact keydown.
      // Closing it with the keyboard highlights the trigger again, with an
      // event the close dispatched: the close keydown under 'keyboard', or the
      // focus that returns to the trigger under 'none'.
      const onItemHighlighted = vi.fn();
      const { user } = await render(
        <FilterableSubmenuMenu onItemHighlighted={onItemHighlighted} />,
      );
      const trigger = screen.getByRole('menuitem', { name: 'More' });
      await act(async () => trigger.focus());

      const keydowns = recordEvents(['keydown']);
      await user.keyboard('[ArrowRight]');
      const input = await screen.findByRole('searchbox', { name: 'Filter child actions' });
      await waitFor(() => {
        expect(input).toHaveFocus();
      });
      await waitFor(() => {
        expect(onItemHighlighted).toHaveBeenLastCalledWith(undefined, expect.anything());
      });

      let details = onItemHighlighted.mock.lastCall?.[1];
      expect(details.reason).toBe('keyboard');
      expect(details.event).toBeInstanceOf(KeyboardEvent);
      expect(details.event.key).toBe('ArrowRight');
      expect(keydowns.all()).toContain(details.event);

      const closing = recordEvents(['keydown', 'focus', 'focusin']);
      await user.keyboard(`[${closeKey}]`);
      await waitFor(() => {
        expect(screen.queryByTestId('submenu')).toBe(null);
      });
      await waitFor(() => {
        expect(onItemHighlighted).toHaveBeenLastCalledWith(trigger, expect.anything());
      });

      details = onItemHighlighted.mock.lastCall?.[1];
      expect(closing.all()).toContain(details.event);
      if (details.reason === 'keyboard') {
        expect(details.event).toBeInstanceOf(KeyboardEvent);
        expect(details.event.key).toBe(closeKey);
      } else {
        expect(details.reason).toBe('none');
        expect(details.event).toBeInstanceOf(FocusEvent);
      }
    },
  );

  it.each(['combobox', 'autocomplete'])('list_hover_pointer_event (%s)', async (kind) => {
    // Moving the mouse onto a list item dispatches a pointermove and then a
    // mousemove, as a browser does. The highlight reports 'pointer' with one
    // of those exact events.
    const onItemHighlighted = vi.fn();
    const list = (Part: typeof Combobox | typeof Autocomplete) => (
      <Part.Portal>
        <Part.Positioner>
          <Part.Popup>
            <Part.List>
              {(item: string) => (
                <Part.Item key={item} value={item}>
                  {item}
                </Part.Item>
              )}
            </Part.List>
          </Part.Popup>
        </Part.Positioner>
      </Part.Portal>
    );
    const { user } = await render(
      kind === 'combobox' ? (
        <Combobox.Root items={['red', 'green', 'blue']} onItemHighlighted={onItemHighlighted}>
          <Combobox.Input data-testid="input" />
          {list(Combobox)}
        </Combobox.Root>
      ) : (
        <Autocomplete.Root items={['red', 'green', 'blue']} onItemHighlighted={onItemHighlighted}>
          <Autocomplete.Input data-testid="input" />
          {list(Autocomplete)}
        </Autocomplete.Root>
      ),
    );

    await user.click(screen.getByTestId('input'));
    if (kind === 'autocomplete') {
      await user.keyboard('{ArrowDown}');
    }
    const item = await screen.findByRole('option', { name: 'green' });

    const pointerMove = new PointerEvent('pointermove', {
      bubbles: true,
      pointerType: 'mouse',
    });
    const mouseMove = new MouseEvent('mousemove', { bubbles: true });
    fireEvent(item, pointerMove);
    fireEvent(item, mouseMove);
    await waitFor(() => {
      expect(onItemHighlighted).toHaveBeenLastCalledWith('green', expect.anything());
    });

    const details = onItemHighlighted.mock.lastCall?.[1];
    expect(details.reason).toBe('pointer');
    expect(details.event).toBeInstanceOf(MouseEvent);
    expect([pointerMove, mouseMove]).toContain(details.event);
  });
});
