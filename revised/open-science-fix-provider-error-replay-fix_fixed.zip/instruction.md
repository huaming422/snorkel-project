## Task

Our app keeps sending AI providers requests that have no chance of working.
When a provider refuses a request for a reason a retry can't fix, the app sends that same refused request back to the provider again and again instead of reporting the failure once.
In the provider logs it shows up as repeated 401s for a revoked API key, 403s when the project has no access to the model, 402s when the account has run out of balance, and 400, 404 or 422 errors when the provider won't accept the request as written.
Some OpenAI-style providers don't send a 402 when the balance runs out: they answer with a 429 whose error code is insufficient_quota, and those get re-sent the same way.

Claude Code, Codex and OpenCode sessions all do it, with any custom provider, and also when only one custom provider is set up.
One failed call turns into a burst of identical calls.
Operators have seen a single bad request repeated several times, and Claude Code send eight or more copies within a few seconds.
A provider can take a while to refuse, so many of those copies go out while the first one is still waiting for its answer.
Some gateways even send the refusal status right away and then never finish the error body, and the runtime sits there waiting on it.
That eats quota and floods provider-side rate limits and logs.

Please make the app stop re-sending a request the provider has already refused this way.
The runtime should still get the failure every time it asks, as a client error that carries the provider's error message.
A 429 with the insufficient_quota error code counts as one of these refusals.
Only that code does, though; any other 429 is a rate limit, even when its message talks about a per-minute quota.
This includes copies that arrive while the same request is still waiting on the provider.
If the provider then refuses it, none of those copies should reach the provider, and each of them gets the same error.
If the provider answers it with a success or with one of the temporary errors below, each waiting copy still goes to the provider and gets its own answer.
Sometimes the runtime drops the first connection before the provider answers.
The copies still waiting must not fail or hang because of that; the request goes out once more for them.
When the error body never finishes, the request still reaches the provider only once, and the runtime and every waiting copy get a client error within twenty seconds.
A request that differs in what goes to the provider, like another prompt or another header such as a beta flag, is a new request and has to reach the provider.
It should not have to wait for some other request that is still pending.
The same is true when the runtime resends an unchanged request but the app now sends it differently, for example after the reasoning effort was changed in the app for a Codex session on a chat-completions provider.
Once someone fixes the cause, for example by moving the session to another key or model, the next request has to go out again.
People also tend to move to another model or key while an admin grants access or adds credit, and then switch back to the first one.
After that switch back, the request has to reach the provider again and get its new answer.
That holds even when the refusal of a request sent before the switch only comes back after the session has switched back.

Rate limits (429), request timeouts (408) and server errors (5xx) can clear up on their own.
Those must keep reaching the provider on every retry and come back the way they do today: with their own status and message, and with the provider's Retry-After header wherever the runtime gets provider headers now.
Successful responses should come through the way they do today.
Switching models in the middle of a session has to keep working, with requests going to the newly picked model.
Codex sessions signed in with a ChatGPT subscription should keep connecting the way they do now.

The runtimes are third-party code, so their retry behavior can't be changed here, and the fix has to be in the app.
