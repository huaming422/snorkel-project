## Task

Our app keeps sending AI providers requests that have no chance of working.
When a provider refuses a request for a reason a retry can't fix, the app sends that same refused request back to the provider again and again instead of reporting the failure once.
In the provider logs it shows up as repeated 401s for a revoked API key, 403s when the project has no access to the model, 402s when the account has run out of balance, and 400, 404 or 422 errors when the provider won't accept the request as written.

Claude Code, Codex and OpenCode sessions all do it, with any custom provider, and also when only one custom provider is set up.
One failed call turns into a burst of identical calls.
Operators have seen a single bad request repeated several times, and Claude Code send eight or more copies within a few seconds.
That eats quota and floods provider-side rate limits and logs.

Please make the app stop re-sending a request the provider has already refused this way.
The runtime should still get the failure every time it asks, as a client error that carries the provider's error message.
A request that differs in what goes to the provider, like another prompt or another header such as a beta flag, is a new request and has to reach the provider.
Once someone fixes the cause, for example by moving the session to another key or model, the next request has to go out again.
People also tend to move to another model or key while an admin grants access or adds credit, and then switch back to the first one.
After that switch back, the request has to reach the provider again and get its new answer.

Rate limits (429), request timeouts (408) and server errors (5xx) can clear up on their own.
Those must keep reaching the provider on every retry and come back with their own status.
Successful responses should come through the way they do today.
Switching models in the middle of a session has to keep working, with requests going to the newly picked model.
Codex sessions signed in with a ChatGPT subscription should keep connecting the way they do now.

The runtimes are third-party code, so their retry behavior can't be changed here, and the fix has to be in the app.
