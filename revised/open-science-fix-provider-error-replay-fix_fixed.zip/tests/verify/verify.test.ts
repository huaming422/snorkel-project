// @ts-nocheck
//
// Behavior is exercised only through pre-existing, stable exported classes in
// src/main/settings/, each constructed with an injected fetch spy that stands in
// for the AI provider, and a loopback client that stands in for the runtime:
//   - AnthropicProviderBridge           (./anthropic-provider-bridge)
//   - OpenAiProviderBridge              (./openai-provider-bridge), chat and responses wires
//   - ResponsesBridge                   (./responses-bridge)
//   - NativeResponsesCompatibilityProxy (./native-responses-compatibility)
//   - BackendRoutePlanner + ProviderTransportOwner, which turn stored settings into the
//     endpoint a runtime is launched against
// No module that a fix might add is imported here.
//
// The main signal is the fetch spy's call count: a request the provider already
// refused with an error that cannot change must not reach the provider again, and a
// transient error must reach it every time. The client-visible status is checked as
// an envelope (a 4xx for refused requests, the provider's own status for transient
// ones), never pinned to one code.

import { afterEach, describe, expect, it, vi } from 'vitest'

// The runner copies this file into src/main/settings/ (see verify.toml
// test_parent), so these relative imports resolve against the settings
// source tree exactly as the repo's own sibling tests do.
import {
  AnthropicProviderBridge,
  type AnthropicProviderBridgeTarget
} from './anthropic-provider-bridge'
import { OpenAiProviderBridge, type OpenAiProviderBridgeTarget } from './openai-provider-bridge'
import { ResponsesBridge } from './responses-bridge'
import { NativeResponsesCompatibilityProxy } from './native-responses-compatibility'
import {
  BackendRoutePlanner,
  type BackendRouteProviderPort
} from './backend-route-planner'
import { ProviderTransportOwner } from './provider-transport-owner'
import { SETTINGS_FILE_VERSION } from '../../shared/settings'

// --- shared cleanup --------------------------------------------------------

const closers: Array<() => Promise<unknown>> = []

afterEach(async () => {
  await Promise.all(closers.splice(0).map((close) => close().catch(() => undefined)))
})

const expectClientError = (status: number): void => {
  expect(status).toBeGreaterThanOrEqual(400)
  expect(status).toBeLessThan(500)
}

const errorResponse = (status: number, message: string): Response =>
  Response.json({ error: { type: 'provider_error', message } }, { status })

// Each transport the app runs between a runtime and a custom provider. `start`
// returns a `send(prompt, headers?, signal?)` that posts the way that runtime does
// (the signal lets the runtime drop the connection), and a
// `switchTarget(to)` that moves the transport to another key, another model, or
// back to the target it started on.
type Transport = {
  name: string
  start: (fetchImpl: typeof fetch) => Promise<{
    send: (prompt: string, headers?: Record<string, string>, signal?: AbortSignal) => Promise<Response>
    switchTarget: (to: 'key' | 'model' | 'start') => void
  }>
  success: () => Response
  successText: string
}

const post = (
  url: string,
  token: string,
  body: unknown,
  headers = {},
  signal?: AbortSignal
): Promise<Response> =>
  fetch(url, {
    method: 'POST',
    headers: {
      authorization: `Bearer ${token}`,
      'content-type': 'application/json',
      ...headers
    },
    body: JSON.stringify(body),
    signal
  })

// Three targets per transport: the starting one, the same model on another key,
// and another model on the same key.
const anthropicTargets: AnthropicProviderBridgeTarget[] = [
  { id: 'provider/model-a', baseUrl: 'https://provider.example.test', key: 'key-a', model: 'model-a' },
  { id: 'provider-key-b/model-a', baseUrl: 'https://provider.example.test', key: 'key-b', model: 'model-a' },
  { id: 'provider/model-b', baseUrl: 'https://provider.example.test', key: 'key-a', model: 'model-b' }
]

const chatTargets: OpenAiProviderBridgeTarget[] = [
  {
    id: 'provider/model-a',
    wire: 'chat-completions',
    endpoint: 'https://provider.example.test/v1/chat/completions',
    key: 'key-a',
    model: 'model-a'
  },
  {
    id: 'provider-key-b/model-a',
    wire: 'chat-completions',
    endpoint: 'https://provider.example.test/v1/chat/completions',
    key: 'key-b',
    model: 'model-a'
  },
  {
    id: 'provider/model-b',
    wire: 'chat-completions',
    endpoint: 'https://provider.example.test/v1/chat/completions',
    key: 'key-a',
    model: 'model-b'
  }
]

const targetIndex = { start: 0, key: 1, model: 2 } as const

const responsesWireTargets: OpenAiProviderBridgeTarget[] = chatTargets.map((target) => ({
  ...target,
  wire: 'responses',
  endpoint: 'https://provider.example.test/v1/responses'
}))

const chatCompletion = (): Response =>
  Response.json({
    id: 'chatcmpl-1',
    object: 'chat.completion',
    model: 'model-a',
    choices: [{ index: 0, message: { role: 'assistant', content: 'pong-from-provider' } }]
  })

const transports: Transport[] = [
  {
    name: 'Anthropic bridge (Claude Code, OpenCode on Anthropic endpoints)',
    start: async (fetchImpl) => {
      const bridge = new AnthropicProviderBridge(anthropicTargets, anthropicTargets[0].id, fetchImpl)
      closers.push(() => bridge.close())
      const { baseUrl, token } = await bridge.start()
      return {
        send: (prompt, headers, signal) =>
          post(
            `${baseUrl}/v1/messages`,
            token,
            { model: 'ignored', max_tokens: 64, messages: [{ role: 'user', content: prompt }] },
            headers,
            signal
          ),
        switchTarget: (to) => {
          expect(bridge.setTarget(anthropicTargets[targetIndex[to]].id)).toBe(true)
        }
      }
    },
    success: () =>
      Response.json({ content: [{ type: 'text', text: 'pong-from-provider' }], model: 'model-a' }),
    successText: 'pong-from-provider'
  },
  {
    name: 'OpenAI chat bridge (OpenCode)',
    start: async (fetchImpl) => {
      const bridge = new OpenAiProviderBridge(chatTargets, chatTargets[0].id, fetchImpl)
      closers.push(() => bridge.close())
      const { baseUrl, token } = await bridge.start()
      return {
        send: (prompt, headers, signal) =>
          post(
            `${baseUrl}/v1/chat/completions`,
            token,
            { model: 'ignored', messages: [{ role: 'user', content: prompt }] },
            headers,
            signal
          ),
        switchTarget: (to) => {
          expect(bridge.setTarget(chatTargets[targetIndex[to]].id)).toBe(true)
        }
      }
    },
    success: chatCompletion,
    successText: 'pong-from-provider'
  },
  {
    name: 'OpenAI Responses-wire bridge (Codex on a Responses endpoint)',
    start: async (fetchImpl) => {
      const bridge = new OpenAiProviderBridge(
        responsesWireTargets,
        responsesWireTargets[0].id,
        fetchImpl
      )
      closers.push(() => bridge.close())
      const { baseUrl, token } = await bridge.start()
      return {
        send: (prompt, headers, signal) =>
          post(`${baseUrl}/v1/responses`, token, { model: 'ignored', input: prompt }, headers, signal),
        switchTarget: (to) => {
          expect(bridge.setTarget(responsesWireTargets[targetIndex[to]].id)).toBe(true)
        }
      }
    },
    success: () =>
      Response.json({
        id: 'resp-1',
        object: 'response',
        output: [{ type: 'message', content: [{ type: 'output_text', text: 'pong-from-provider' }] }]
      }),
    successText: 'pong-from-provider'
  },
  {
    name: 'Responses bridge (Codex on a chat-completions provider)',
    start: async (fetchImpl) => {
      const target = { baseUrl: 'https://vendor.example/v1', key: 'key-a', model: 'model-a' }
      const bridge = new ResponsesBridge(target, fetchImpl)
      closers.push(() => bridge.close())
      const { baseUrl, token } = await bridge.start()
      return {
        send: (prompt, headers, signal) =>
          post(
            `${baseUrl}/responses`,
            token,
            { model: 'ignored', input: prompt, stream: false },
            headers,
            signal
          ),
        switchTarget: (to) =>
          bridge.setTarget(to === 'key' ? { ...target, key: 'key-b' } : to === 'model' ? { ...target, model: 'model-b' } : target)
      }
    },
    success: chatCompletion,
    successText: 'pong-from-provider'
  },
  {
    name: 'native Responses compatibility proxy (Codex)',
    start: async (fetchImpl) => {
      const target = { baseUrl: 'https://vendor.example/v1', key: 'key-a', model: 'model-a' }
      const proxy = new NativeResponsesCompatibilityProxy(target, fetchImpl)
      closers.push(() => proxy.close())
      const { baseUrl, token } = await proxy.start()
      return {
        send: (prompt, headers, signal) =>
          post(
            `${baseUrl}/responses`,
            token,
            { model: 'ignored', input: prompt, stream: false },
            headers,
            signal
          ),
        switchTarget: (to) =>
          proxy.setTarget(to === 'key' ? { ...target, key: 'key-b' } : to === 'model' ? { ...target, model: 'model-b' } : target)
      }
    },
    success: () =>
      Response.json({
        id: 'resp-1',
        object: 'response',
        output: [{ type: 'message', content: [{ type: 'output_text', text: 'pong-from-provider' }] }]
      }),
    successText: 'pong-from-provider'
  }
]

// Errors a provider gives for a request that will fail the same way every time,
// one per kind of refusal: malformed or unsupported request, bad key, billing,
// permission, unknown model, rejected parameter value.
const refusals = [
  [400, 'Unsupported parameter: logit_bias is not supported with this model'],
  [401, 'Incorrect API key provided: sk-...wxyz'],
  [402, 'Payment required: add a payment method to continue'],
  [403, 'Project proj_29 does not have access to model model-a'],
  [404, 'The model `model-a-latest` does not exist'],
  [422, 'Invalid value for temperature: must be between 0 and 2']
] as const

// Errors that keep reaching the provider on every retry: request timeout, rate
// limit, and server errors across the 5xx range.
const transientErrors = [
  [408, 'Request timed out'],
  [429, 'Rate limit reached for requests'],
  [500, 'The server had an error while processing your request'],
  [501, 'This endpoint is not implemented on this region yet'],
  [503, 'The engine is currently overloaded'],
  [504, 'Gateway timeout while waiting for the model']
] as const

const sentBody = (call): string => String(call[1]?.body ?? '')
const sentHeader = (call, name: string): string | null =>
  new Headers(call[1]?.headers).get(name)

describe.each(transports)('$name', (transport) => {
  it.each(refusals)(
    'a request refused with %i reaches the provider once, and every retry still gets the error',
    async (status, message) => {
      const providerFetch = vi.fn(async () => errorResponse(status, message))
      const { send } = await transport.start(providerFetch)

      const replies = []
      for (let attempt = 0; attempt < 3; attempt += 1) replies.push(await send('hello there'))

      expect(providerFetch).toHaveBeenCalledTimes(1)
      for (const reply of replies) {
        expectClientError(reply.status)
        expect(await reply.text()).toContain(message)
      }
    }
  )

  it.each(transientErrors)(
    'a transient %i keeps reaching the provider on every retry with its own status',
    async (status, message) => {
      const providerFetch = vi.fn(async () => errorResponse(status, message))
      const { send } = await transport.start(providerFetch)

      const replies = []
      for (let attempt = 0; attempt < 3; attempt += 1) replies.push(await send('hello there'))

      expect(providerFetch).toHaveBeenCalledTimes(3)
      for (const reply of replies) {
        expect(reply.status).toBe(status)
        expect(await reply.text()).toContain(message)
      }
    }
  )

  it('refused requests with different prompts each reach the provider once', async () => {
    const providerFetch = vi.fn(async () => errorResponse(401, 'Incorrect API key provided'))
    const { send } = await transport.start(providerFetch)

    for (const prompt of ['first question', 'second question', 'first question', 'second question']) {
      expectClientError((await send(prompt)).status)
    }

    expect(providerFetch).toHaveBeenCalledTimes(2)
    expect(sentBody(providerFetch.mock.calls[0])).toContain('first question')
    expect(sentBody(providerFetch.mock.calls[1])).toContain('second question')
  })

  it('a request goes out again once the transport moves to another key', async () => {
    const providerFetch = vi.fn(async (_url, init) =>
      new Headers(init?.headers).get('authorization') === 'Bearer key-a'
        ? errorResponse(401, 'Incorrect API key provided')
        : transport.success()
    )
    const { send, switchTarget } = await transport.start(providerFetch)

    expectClientError((await send('hello there')).status)
    expectClientError((await send('hello there')).status)
    switchTarget('key')
    const recovered = await send('hello there')

    expect(providerFetch).toHaveBeenCalledTimes(2)
    expect(sentHeader(providerFetch.mock.calls[1], 'authorization')).toBe('Bearer key-b')
    expect(recovered.status).toBe(200)
    expect(await recovered.text()).toContain(transport.successText)
  })

  it('a request goes out again once the transport moves to another model', async () => {
    const providerFetch = vi.fn(async (_url, init) =>
      JSON.parse(String(init?.body ?? '{}')).model === 'model-a'
        ? errorResponse(404, 'The model `model-a` does not exist')
        : transport.success()
    )
    const { send, switchTarget } = await transport.start(providerFetch)

    expectClientError((await send('hello there')).status)
    expectClientError((await send('hello there')).status)
    switchTarget('model')
    const recovered = await send('hello there')

    expect(providerFetch).toHaveBeenCalledTimes(2)
    expect(JSON.parse(sentBody(providerFetch.mock.calls[1])).model).toBe('model-b')
    expect(recovered.status).toBe(200)
    expect(await recovered.text()).toContain(transport.successText)
  })

  // The provider-side cause is fixed while the session is on the other target, so
  // the first request after moving back has to reach the provider and get its answer.
  it.each([
    {
      to: 'model',
      status: 403,
      message: 'Project proj_29 does not have access to model model-a',
      refuses: (init) => JSON.parse(String(init?.body ?? '{}')).model === 'model-a'
    },
    {
      to: 'key',
      status: 402,
      message: 'Payment required: add a payment method to continue',
      refuses: (init) => new Headers(init?.headers).get('authorization') === 'Bearer key-a'
    }
  ] as const)(
    'a refusal no longer applies after the transport moves to another $to and back',
    async ({ to, status, message, refuses }) => {
      let fixedAtProvider = false
      const providerFetch = vi.fn(async (_url, init) =>
        refuses(init) && !fixedAtProvider ? errorResponse(status, message) : transport.success()
      )
      const { send, switchTarget } = await transport.start(providerFetch)

      expectClientError((await send('hello there')).status)
      expectClientError((await send('hello there')).status)
      switchTarget(to)
      expect((await send('hello there')).status).toBe(200)
      fixedAtProvider = true
      switchTarget('start')
      const recovered = await send('hello there')

      expect(providerFetch).toHaveBeenCalledTimes(3)
      expect(refuses(providerFetch.mock.calls[2][1])).toBe(true)
      expect(recovered.status).toBe(200)
      expect(await recovered.text()).toContain(transport.successText)
    }
  )

  it('a successful response comes through and is not reused for the next request', async () => {
    const providerFetch = vi.fn(async () => transport.success())
    const { send } = await transport.start(providerFetch)

    const first = await send('hello there')
    const second = await send('hello there')

    expect(first.status).toBe(200)
    expect(second.status).toBe(200)
    expect(await first.text()).toContain(transport.successText)
    expect(await second.text()).toContain(transport.successText)
    expect(providerFetch).toHaveBeenCalledTimes(2)
  })
})

// --- copies that arrive while the first request is still waiting -----------

// A provider that answers no request until `answer` is called, and every request
// at once after that. With `onlyFirst`, only the first request waits. Like a real
// fetch, a waiting request fails as soon as its signal aborts.
const slowProvider = (reply: (call: number, init) => Response, { onlyFirst = false } = {}) => {
  let answer: () => void = () => undefined
  const mayAnswer = new Promise<void>((resolve) => {
    answer = resolve
  })
  const providerFetch = vi.fn(async (_url, init) => {
    const call = providerFetch.mock.calls.length
    if (call === 1 || !onlyFirst) {
      const signal: AbortSignal | undefined = init?.signal
      await new Promise<void>((resolve, reject) => {
        if (signal?.aborted) reject(signal.reason)
        signal?.addEventListener('abort', () => reject(signal.reason), { once: true })
        mayAnswer.then(resolve)
      })
    }
    return reply(call, init)
  })
  return { providerFetch, answer }
}

// Gives copies sent over loopback time to reach the transport before the provider
// answers the first request.
const letCopiesArrive = (): Promise<void> => new Promise((resolve) => setTimeout(resolve, 400))

const COPIES = 3

// Fails when the replies are not all back within `ms`, so a request left waiting
// shows up as a failure instead of a hang.
const answeredWithin = <T,>(replies: Promise<T>, ms: number): Promise<T> =>
  Promise.race([
    replies,
    new Promise<never>((_, reject) =>
      setTimeout(() => reject(new Error(`no answer within ${ms} ms`)), ms)
    )
  ])

describe.each(transports)('$name, copies sent while the first request waits', (transport) => {
  it.each([
    [403, 'Project proj_29 does not have access to model model-a'],
    [422, 'Invalid value for temperature: must be between 0 and 2']
  ] as const)(
    'copies of a request the provider then refuses with %i never reach the provider and all get the error',
    async (status, message) => {
      const { providerFetch, answer } = slowProvider(() => errorResponse(status, message))
      const { send } = await transport.start(providerFetch)

      const first = send('hello there')
      await vi.waitFor(() => expect(providerFetch).toHaveBeenCalledTimes(1))
      const copies = Array.from({ length: COPIES }, () => send('hello there'))
      await letCopiesArrive()
      answer()
      const replies = await answeredWithin(Promise.all([first, ...copies]), 10_000)

      expect(providerFetch).toHaveBeenCalledTimes(1)
      for (const reply of replies) {
        expectClientError(reply.status)
        expect(await reply.text()).toContain(message)
      }
    }
  )

  it.each([
    [408, 'Request timed out'],
    [429, 'Rate limit reached for requests'],
    [503, 'The engine is currently overloaded']
  ] as const)(
    'copies of a request that then gets a transient %i each reach the provider with that status',
    async (status, message) => {
      const { providerFetch, answer } = slowProvider(() => errorResponse(status, message))
      const { send } = await transport.start(providerFetch)

      const first = send('hello there')
      await vi.waitFor(() => expect(providerFetch).toHaveBeenCalledTimes(1))
      const copies = Array.from({ length: COPIES }, () => send('hello there'))
      await letCopiesArrive()
      answer()
      const replies = await answeredWithin(Promise.all([first, ...copies]), 10_000)

      expect(providerFetch).toHaveBeenCalledTimes(COPIES + 1)
      for (const reply of replies) {
        expect(reply.status).toBe(status)
        expect(await reply.text()).toContain(message)
      }
    }
  )

  it('copies of a request that then succeeds each reach the provider and get its answer', async () => {
    const { providerFetch, answer } = slowProvider(() => transport.success())
    const { send } = await transport.start(providerFetch)

    const first = send('hello there')
    await vi.waitFor(() => expect(providerFetch).toHaveBeenCalledTimes(1))
    const copies = Array.from({ length: COPIES }, () => send('hello there'))
    await letCopiesArrive()
    answer()
    const replies = await answeredWithin(Promise.all([first, ...copies]), 10_000)

    expect(providerFetch).toHaveBeenCalledTimes(COPIES + 1)
    for (const reply of replies) {
      expect(reply.status).toBe(200)
      expect(await reply.text()).toContain(transport.successText)
    }
  })

  it('when the runtime drops the first request, the waiting copies go out once more and get the refusal', async () => {
    const message = 'Incorrect API key provided: sk-...wxyz'
    const { providerFetch, answer } = slowProvider(() => errorResponse(401, message))
    const { send } = await transport.start(providerFetch)

    const dropped = new AbortController()
    const first = send('hello there', undefined, dropped.signal).catch((error) => error)
    await vi.waitFor(() => expect(providerFetch).toHaveBeenCalledTimes(1))
    const copies = Array.from({ length: COPIES }, () => send('hello there'))
    await letCopiesArrive()
    dropped.abort()
    await first
    await letCopiesArrive()
    answer()
    const replies = await answeredWithin(Promise.all(copies), 10_000)

    expect(providerFetch).toHaveBeenCalledTimes(2)
    for (const reply of replies) {
      expectClientError(reply.status)
      expect(await reply.text()).toContain(message)
    }
  })

  it('a different request is not held back while another one waits on the provider', async () => {
    const { providerFetch, answer } = slowProvider(
      (call) => (call === 1 ? errorResponse(401, 'Incorrect API key provided') : transport.success()),
      { onlyFirst: true }
    )
    const { send } = await transport.start(providerFetch)

    const first = send('first question')
    await vi.waitFor(() => expect(providerFetch).toHaveBeenCalledTimes(1))
    const other = await answeredWithin(send('second question'), 5_000)

    expect(other.status).toBe(200)
    expect(await other.text()).toContain(transport.successText)
    expect(sentBody(providerFetch.mock.calls[1])).toContain('second question')
    answer()
    expectClientError((await first).status)
  })

  // The provider refused the first request before the cause was fixed, but its
  // answer only comes back after the session moved away and back.
  it.each([
    {
      to: 'model',
      status: 403,
      message: 'Project proj_29 does not have access to model model-a'
    },
    {
      to: 'key',
      status: 402,
      message: 'Payment required: add a payment method to continue'
    }
  ] as const)(
    'a refusal that comes back after a move to another $to and back does not stop the next request',
    async ({ to, status, message }) => {
      const { providerFetch, answer } = slowProvider((call) =>
        call === 1 ? errorResponse(status, message) : transport.success()
      )
      const { send, switchTarget } = await transport.start(providerFetch)

      const first = send('hello there')
      await vi.waitFor(() => expect(providerFetch).toHaveBeenCalledTimes(1))
      switchTarget(to)
      switchTarget('start')
      answer()
      const refused = await first
      expectClientError(refused.status)
      expect(await refused.text()).toContain(message)
      const recovered = await send('hello there')

      expect(providerFetch).toHaveBeenCalledTimes(2)
      expect(recovered.status).toBe(200)
      expect(await recovered.text()).toContain(transport.successText)
    }
  )
})

describe('requests that differ only in a header', () => {
  it.each([
    { name: 'Anthropic bridge', index: 0, header: 'anthropic-beta' },
    { name: 'OpenAI chat bridge', index: 1, header: 'openai-beta' },
    { name: 'OpenAI Responses-wire bridge', index: 2, header: 'openai-beta' },
    { name: 'native Responses compatibility proxy', index: 4, header: 'openai-beta' },
    { name: 'Anthropic bridge', index: 0, header: 'anthropic-version' },
    { name: 'OpenAI chat bridge', index: 1, header: 'openai-organization' },
    { name: 'OpenAI Responses-wire bridge', index: 2, header: 'openai-organization' },
    { name: 'native Responses compatibility proxy', index: 4, header: 'openai-organization' }
  ] as const)('$name sends a request with a changed $header header to the provider', async ({ index, header }) => {
    const providerFetch = vi.fn(async (_url, init) =>
      new Headers(init?.headers).get(header) === 'flag-2026-01'
        ? errorResponse(400, `Unknown ${header} value`)
        : transports[index].success()
    )
    const { send } = await transports[index].start(providerFetch)

    const refused = await send('hello there', { [header]: 'flag-2026-01' })
    const again = await send('hello there', { [header]: 'flag-2026-01' })
    const changed = await send('hello there', { [header]: 'flag-2026-02' })

    expectClientError(refused.status)
    expectClientError(again.status)
    expect(providerFetch).toHaveBeenCalledTimes(2)
    expect(sentHeader(providerFetch.mock.calls[1], header)).toBe('flag-2026-02')
    expect(changed.status).toBe(200)
  })
})

describe('Anthropic bridge edge cases', () => {
  it('a refused request with a very large declared error body still reaches the provider once', async () => {
    const providerFetch = vi.fn(
      async () =>
        new Response('oversized-error-body', {
          status: 401,
          headers: {
            'content-encoding': 'gzip',
            'content-length': String(256 * 1024 + 1),
            'content-type': 'text/event-stream'
          }
        })
    )
    const { send } = await transports[0].start(providerFetch)

    const first = await send('hello there')
    const replay = await send('hello there')

    expectClientError(first.status)
    expectClientError(replay.status)
    expect(providerFetch).toHaveBeenCalledOnce()
  })

  it('a streamed success comes through unchanged', async () => {
    const events =
      'event: message_start\ndata: {"type":"message_start"}\n\n' +
      'event: content_block_delta\ndata: {"type":"content_block_delta","delta":{"text":"streamed-ok"}}\n\n'
    const providerFetch = vi.fn(
      async () => new Response(events, { headers: { 'content-type': 'text/event-stream' } })
    )
    const { send } = await transports[0].start(providerFetch)

    const reply = await send('hello there')

    expect(reply.status).toBe(200)
    expect(reply.headers.get('content-type')).toContain('text/event-stream')
    expect(await reply.text()).toBe(events)
  })
})

// --- sessions with a single custom provider ---------------------------------

const makeStoredProvider = (overrides = {}) => ({
  id: 'provider-a',
  type: 'custom',
  name: 'Provider A',
  apiEndpoints: ['anthropic', 'openai', 'responses'],
  baseUrl: 'https://provider-a.example/v1',
  model: 'model-a',
  keyRef: 'provider-a-key-ref',
  ...overrides
})

const makeSettings = (provider = makeStoredProvider()) => ({
  version: SETTINGS_FILE_VERSION,
  providers: [provider],
  activeProviderId: provider.id,
  activeModel: provider.model,
  agentFrameworkId: 'codex',
  reasoningEffort: 'high'
})

const makeTarget = (provider, overrides = {}) => {
  const { provider: providerOverrides, ...targetOverrides } = overrides
  return {
    providerId: provider.id,
    providerType: provider.type,
    effectiveModel: provider.model,
    apiEndpoints: provider.apiEndpoints ?? ['anthropic'],
    provider: {
      type: provider.type,
      baseUrl: provider.baseUrl,
      openaiBaseUrl: provider.baseUrl,
      model: provider.model,
      key: 'plain-provider-key',
      apiEndpoints: provider.apiEndpoints,
      ...providerOverrides
    },
    reasoningEffortProfile: {
      supported: true,
      slots: ['low', 'medium', 'high', 'xhigh', 'max']
    },
    frameworkCompatible: true,
    modelBridgeSupported: true,
    needsChatResponsesBridge: false,
    needsNativeResponsesCompatibility: false,
    ...targetOverrides
  }
}

// `catalog` lists the other models the stored provider offers, so a session can
// switch between them.
const makePlanner = (catalog = []): BackendRoutePlanner => {
  const providers: BackendRouteProviderPort = {
    resolveRuntimeTarget: vi.fn(),
    resolveRuntimeModelCatalog: vi.fn(() => catalog)
  }
  return new BackendRoutePlanner({ providers })
}

const makeOwner = (providerFetch: typeof fetch): ProviderTransportOwner =>
  new ProviderTransportOwner({
    createAnthropicProviderBridge: (targets, initialTargetId) =>
      new AnthropicProviderBridge(targets, initialTargetId, providerFetch),
    createOpenAiProviderBridge: (targets, initialTargetId) =>
      new OpenAiProviderBridge(targets, initialTargetId, providerFetch),
    createResponsesBridge: (target) => new ResponsesBridge(target, providerFetch),
    createNativeResponsesProxy: (target) => new NativeResponsesCompatibilityProxy(target, providerFetch)
  })

// How each runtime calls its provider, given what the app launched it with. When
// the app hands the runtime no endpoint of its own, the runtime calls the
// provider's URL with the provider's key, which here is the same fetch spy.
// OpenCode picks the endpoint listed for the session's model in the catalog the app
// launched it with.
const runtimeCall = (frameworkId, target, generation, providerFetch, prompt: string) => {
  const provider =
    (frameworkId === 'opencode'
      ? generation.providerModelCatalog?.find(
          (entry) => entry.provider.model === target.effectiveModel
        )?.provider
      : undefined) ?? generation.provider
  const env = generation.environment ?? {}
  if (frameworkId === 'claude-code') {
    const baseUrl = env.ANTHROPIC_BASE_URL
    const body = { model: target.effectiveModel, max_tokens: 64, messages: [{ role: 'user', content: prompt }] }
    return baseUrl
      ? post(`${baseUrl}/v1/messages`, env.ANTHROPIC_AUTH_TOKEN ?? env.ANTHROPIC_API_KEY, body)
      : providerFetch(`${target.provider.baseUrl}/messages`, {
          method: 'POST',
          headers: { authorization: `Bearer ${target.provider.key}` },
          body: JSON.stringify(body)
        })
  }
  if (frameworkId === 'opencode') {
    const body = { model: target.effectiveModel, messages: [{ role: 'user', content: prompt }] }
    return provider?.openaiBaseUrl
      ? post(`${provider.openaiBaseUrl}/chat/completions`, provider.key, body)
      : providerFetch(`${target.provider.baseUrl}/chat/completions`, {
          method: 'POST',
          headers: { authorization: `Bearer ${target.provider.key}` },
          body: JSON.stringify(body)
        })
  }
  const body = { model: target.effectiveModel, input: prompt }
  const responsesBase = provider?.openaiBaseUrl ?? generation.responsesBridge?.baseUrl
  const token = provider?.key ?? generation.responsesBridge?.token
  return responsesBase
    ? post(`${responsesBase}/responses`, token, body)
    : providerFetch(`${target.provider.baseUrl}/responses`, {
        method: 'POST',
        headers: { authorization: `Bearer ${target.provider.key}` },
        body: JSON.stringify(body)
      })
}

const startSession = async (frameworkId, provider, target, providerFetch, planner = makePlanner()) => {
  const plan = planner.planBackend({
    settings: makeSettings(provider),
    frameworkId,
    target,
    effortIntent: 'high',
    conversationSkillImportEnabled: true
  })
  const generation = await makeOwner(providerFetch).acquire({ activeTarget: target, plan })
  closers.push(() => generation.release())
  return generation
}

// The session's model switch: when the change names a transport target, the running
// transport is moved to it, and a fresh connection is started when that move is
// refused or no transport is running. Without a named target the connection stays
// and only the session model changes.
const switchModel = async (frameworkId, provider, to, generation, providerFetch, planner = makePlanner()) => {
  const change = planner.projectModelChange({
    settings: makeSettings(provider),
    frameworkId,
    target: to,
    effortIntent: 'high'
  })
  expect(change).toBeDefined()
  const transportTargetId = change.anthropicBridgeTargetId ?? change.providerTransportTargetId
  if (!transportTargetId) return generation
  const lease = change.anthropicBridgeTargetId
    ? generation.anthropicBridgeLease
    : generation.providerTransportLease
  if (lease?.setTarget(transportTargetId)) return generation
  return startSession(frameworkId, provider, to, providerFetch, planner)
}

describe('sessions with a single custom provider', () => {
  it.each([
    ['claude-code', ['anthropic']],
    ['opencode', ['openai']],
    ['codex', ['responses']]
  ] as const)(
    'a %s session sends a refused request to the provider only once',
    async (frameworkId, apiEndpoints) => {
      const provider = makeStoredProvider({ apiEndpoints })
      const target = makeTarget(provider, { apiEndpoints })
      const providerFetch = vi.fn(async () => errorResponse(401, 'Incorrect API key provided'))
      const generation = await startSession(frameworkId, provider, target, providerFetch)

      const replies = []
      for (let attempt = 0; attempt < 3; attempt += 1) {
        replies.push(await runtimeCall(frameworkId, target, generation, providerFetch, 'hello there'))
      }

      expect(providerFetch).toHaveBeenCalledTimes(1)
      for (const reply of replies) expectClientError(reply.status)
    }
  )

  it.each([
    ['claude-code', ['anthropic']],
    ['opencode', ['openai']],
    ['codex', ['responses']]
  ] as const)(
    'a %s session still sends every rate-limited retry to the provider',
    async (frameworkId, apiEndpoints) => {
      const provider = makeStoredProvider({ apiEndpoints })
      const target = makeTarget(provider, { apiEndpoints })
      const providerFetch = vi.fn(async () => errorResponse(429, 'Rate limit reached for requests'))
      const generation = await startSession(frameworkId, provider, target, providerFetch)

      for (let attempt = 0; attempt < 3; attempt += 1) {
        const reply = await runtimeCall(frameworkId, target, generation, providerFetch, 'hello there')
        expect(reply.status).toBe(429)
      }

      expect(providerFetch).toHaveBeenCalledTimes(3)
    }
  )

  it.each([
    ['claude-code', ['anthropic']],
    ['opencode', ['openai']],
    ['codex', ['responses']]
  ] as const)(
    'a %s session uses the newly picked model after a model switch',
    async (frameworkId, apiEndpoints) => {
      const provider = makeStoredProvider({ apiEndpoints })
      const target = makeTarget(provider, { apiEndpoints })
      const switched = makeTarget(provider, {
        apiEndpoints,
        effectiveModel: 'model-b',
        provider: { model: 'model-b' }
      })
      const providerFetch = vi.fn(async () => errorResponse(401, 'Incorrect API key provided'))
      let generation = await startSession(frameworkId, provider, target, providerFetch)
      generation = await switchModel(frameworkId, provider, switched, generation, providerFetch)

      for (let attempt = 0; attempt < 2; attempt += 1) {
        const reply = await runtimeCall(frameworkId, switched, generation, providerFetch, 'hi')
        expectClientError(reply.status)
      }

      expect(providerFetch).toHaveBeenCalledTimes(1)
      expect(JSON.parse(sentBody(providerFetch.mock.calls[0])).model).toBe('model-b')
    }
  )

  const sessionSuccess = {
    'claude-code': () =>
      Response.json({ content: [{ type: 'text', text: 'pong-from-provider' }], model: 'model-a' }),
    opencode: chatCompletion,
    codex: () =>
      Response.json({
        id: 'resp-1',
        object: 'response',
        output: [{ type: 'message', content: [{ type: 'output_text', text: 'pong-from-provider' }] }]
      })
  }

  // The provider offers model-a and model-b. Access to model-a is granted while the
  // session is on model-b, so switching back has to reach the provider again.
  it.each([
    ['claude-code', ['anthropic']],
    ['opencode', ['openai']],
    ['codex', ['responses']]
  ] as const)(
    'a %s session that switches to another model and back sends the refused request again',
    async (frameworkId, apiEndpoints) => {
      const provider = makeStoredProvider({ apiEndpoints })
      const first = makeTarget(provider, { apiEndpoints })
      const second = makeTarget(provider, {
        apiEndpoints,
        effectiveModel: 'model-b',
        provider: { model: 'model-b' }
      })
      const planner = makePlanner([second])
      let accessGranted = false
      const providerFetch = vi.fn(async (_url, init) =>
        JSON.parse(String(init?.body ?? '{}')).model === 'model-a' && !accessGranted
          ? errorResponse(403, 'Project proj_29 does not have access to model model-a')
          : sessionSuccess[frameworkId]()
      )
      let generation = await startSession(frameworkId, provider, first, providerFetch, planner)

      for (let attempt = 0; attempt < 2; attempt += 1) {
        const reply = await runtimeCall(frameworkId, first, generation, providerFetch, 'hi')
        expectClientError(reply.status)
      }
      generation = await switchModel(frameworkId, provider, second, generation, providerFetch, planner)
      expect((await runtimeCall(frameworkId, second, generation, providerFetch, 'hi')).status).toBe(200)
      accessGranted = true
      generation = await switchModel(frameworkId, provider, first, generation, providerFetch, planner)
      const recovered = await runtimeCall(frameworkId, first, generation, providerFetch, 'hi')

      expect(providerFetch).toHaveBeenCalledTimes(3)
      expect(JSON.parse(sentBody(providerFetch.mock.calls[2])).model).toBe('model-a')
      expect(recovered.status).toBe(200)
      expect(await recovered.text()).toContain('pong-from-provider')
    }
  )

  it.each([
    ['claude-code', ['anthropic']],
    ['opencode', ['openai']],
    ['codex', ['responses']]
  ] as const)(
    'a %s session sends a refused request once even when copies go out before it is answered',
    async (frameworkId, apiEndpoints) => {
      const provider = makeStoredProvider({ apiEndpoints })
      const target = makeTarget(provider, { apiEndpoints })
      const message = 'Payment required: add a payment method to continue'
      const { providerFetch, answer } = slowProvider(() => errorResponse(402, message))
      const generation = await startSession(frameworkId, provider, target, providerFetch)

      const call = () => runtimeCall(frameworkId, target, generation, providerFetch, 'hello there')
      const first = call()
      await vi.waitFor(() => expect(providerFetch).toHaveBeenCalledTimes(1))
      const copies = Array.from({ length: COPIES }, call)
      await letCopiesArrive()
      answer()
      const replies = await answeredWithin(Promise.all([first, ...copies]), 10_000)

      expect(providerFetch).toHaveBeenCalledTimes(1)
      for (const reply of replies) {
        expectClientError(reply.status)
        expect(await reply.text()).toContain(message)
      }
    }
  )

  it('a Codex session signed in with a ChatGPT subscription keeps its direct connection', () => {
    const provider = makeStoredProvider({
      id: 'builtin-codex-subscription',
      type: 'codex-isolated',
      codexAuthMode: 'isolated',
      keyRef: undefined
    })

    const plan = makePlanner().planBackend({
      settings: makeSettings(provider),
      frameworkId: 'codex',
      target: makeTarget(provider),
      effortIntent: 'high',
      conversationSkillImportEnabled: true
    })

    expect(plan.transport).toEqual({ kind: 'direct' })
  })
})
