## Task

People running dalfox against real apps keep sending the same complaint.
dalfox flags a query parameter as a reflected `[R]` hit, they open the response to confirm it, and there is nothing in it that can run.

The pages behind these hits echo the request parameter back into their own URL, in the query string of a canonical link or a self link, and they percent-encode it on the way out.
The payloads on the hits are ones dalfox sent HTML-entity-encoded, very often the mangled `javascript:` variants it uses to get past filters (`javasscriptcript:` and friends).
A trimmed response looks like this:

```html
<link rel="canonical" href="/About.aspx?any=%26%23x006a%3B%26%23x0061%3B%26%23x0076%3B%26%23x0061%3B...">
...
<a href="/About.aspx?any=%26%23x006a%3B%26%23x0061%3B%26%23x0076%3B%26%23x0061%3B...">home</a>
```

Hand triage marks every one of these as not exploitable.
dalfox still reports them, and on ASP.NET-style sites, especially with WAF evasion turned on, there are so many that people stop trusting the output.

Work out why these echoes are dead and stop reporting them.
Real hits in links still have to be reported.
That means an encoded scheme that the page puts in as the whole link value, and a raw quote that the page writes into a link without encoding it, closing the attribute, with or without a tag after it.
This holds even when the same page also has the dead encoded echo in its canonical link.
Ordinary reflected XSS, like a raw tag in the page body, should be reported the same as it is today.
Keep dalfox's public API as it is.
