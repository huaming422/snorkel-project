//! Behavioral checks for reflections that land inside self-/canonical-link URLs.
//!
//! Each case drives the public reflection entry point
//! `dalfox::scanning::check_reflection::check_reflection_with_response` against a
//! local axum mock. The call injects one exact payload in one HTTP request,
//! classifies the reflection, applies the safe-context filtering, and returns
//! `Some(ReflectionKind)` when the reflection is reported or `None` when it is
//! not. The scan driver picks its own payloads and adds DOM verification on top,
//! so this is the layer where a given payload's reported/not-reported decision
//! can be observed directly.
//!
//! Only public API is used (`check_reflection_with_response`, `ReflectionKind`,
//! `Location`, `Param`, `parse_target`, `ScanArgs`), and the assertions read only
//! the reported/not-reported decision (`is_none()` / `is_some()`).
//!
//! Cases:
//!   1. An HTML-entity-encoded payload that the page echoes percent-encoded into
//!      the query of a canonical `<link>` and an `<a>` self-link is not reported
//!      (four payloads of different shapes).
//!   2. An entity-encoded scheme reflected at the start of an `href` value is
//!      reported (two schemes).
//!   3. A raw quote that closes a quoted `href` value is reported, with a tag
//!      after it (double-quoted) and with only an attribute (single-quoted).
//!   4. A page that echoes the payload percent-encoded into its canonical link
//!      and also has a live copy is reported: the decoded break-out unencoded
//!      inside an anchor `href`, or an encoded scheme as a whole `href` value.
//!   5. An unescaped reflection in HTML body text is reported.

use std::collections::HashMap;
use std::net::{Ipv4Addr, SocketAddr};
use std::time::Duration;

use axum::{
    Router,
    extract::Query,
    response::{Html, IntoResponse},
    routing::get,
};

use dalfox::cmd::scan::ScanArgs;
use dalfox::parameter_analysis::{Location, Param};
use dalfox::scanning::check_reflection::{ReflectionKind, check_reflection_with_response};
use dalfox::target_parser::parse_target;

// ===========================================================================
// Mock handlers, one reflection shape each
// ===========================================================================

/// Echoes the `any` param percent-encoded inside the query of both a canonical
/// `<link>` and an `<a>` self-link, the way an ASP.NET page renders its own URL
/// (`<link rel="canonical" href="/About.aspx?any={enc}">`). No byte of the value
/// appears unencoded anywhere in the page.
async fn self_link_encoded(Query(p): Query<HashMap<String, String>>) -> impl IntoResponse {
    let any = p.get("any").cloned().unwrap_or_default();
    let enc = urlencoding::encode(&any);
    Html(format!(
        r#"<!DOCTYPE html><html><head><title>About</title>
<link rel="canonical" href="/About.aspx?any={enc}"></head>
<body><a href="/About.aspx?any={enc}">home</a></body></html>"#
    ))
}

/// Echoes the `any` param verbatim as the whole `href` value. An entity-encoded
/// scheme here becomes the link's scheme in the browser.
async fn href_value_start(Query(p): Query<HashMap<String, String>>) -> impl IntoResponse {
    let any = p.get("any").cloned().unwrap_or_default();
    Html(format!(
        r#"<!DOCTYPE html><html><body><a href="{any}">go</a></body></html>"#
    ))
}

/// Echoes the `any` param verbatim inside the query of a double-quoted `href`.
/// A raw `"` closes the attribute.
async fn href_literal_breakout(Query(p): Query<HashMap<String, String>>) -> impl IntoResponse {
    let any = p.get("any").cloned().unwrap_or_default();
    Html(format!(
        r#"<!DOCTYPE html><html><body><a href="/p?x={any}">x</a></body></html>"#
    ))
}

/// Echoes the `any` param verbatim inside the query of a single-quoted `href`.
/// A raw `'` closes the attribute.
async fn href_literal_breakout_single(
    Query(p): Query<HashMap<String, String>>,
) -> impl IntoResponse {
    let any = p.get("any").cloned().unwrap_or_default();
    Html(format!(
        r#"<!DOCTYPE html><html><body><a href='/p?x={any}'>x</a></body></html>"#
    ))
}

/// Echoes the `any` param percent-encoded into the canonical link's query (an
/// inert copy), and also entity-decodes it and writes the result verbatim into
/// the query of an anchor `href` (a live copy whose raw `"` closes the
/// attribute).
async fn self_link_plus_live_breakout(
    Query(p): Query<HashMap<String, String>>,
) -> impl IntoResponse {
    let any = p.get("any").cloned().unwrap_or_default();
    let enc = urlencoding::encode(&any);
    let live = any
        .replace("&quot;", "\"")
        .replace("&lt;", "<")
        .replace("&gt;", ">");
    Html(format!(
        r#"<!DOCTYPE html><html><head>
<link rel="canonical" href="/About.aspx?any={enc}"></head>
<body><a href="/About.aspx?any={live}">home</a></body></html>"#
    ))
}

/// Echoes the `any` param percent-encoded into the canonical link's query (an
/// inert copy), and also writes it verbatim as the whole `href` value of an
/// anchor (a live copy: an entity-encoded scheme there is the link's scheme).
async fn self_link_plus_live_value_start(
    Query(p): Query<HashMap<String, String>>,
) -> impl IntoResponse {
    let any = p.get("any").cloned().unwrap_or_default();
    let enc = urlencoding::encode(&any);
    Html(format!(
        r#"<!DOCTYPE html><html><head>
<link rel="canonical" href="/About.aspx?any={enc}"></head>
<body><a href="{any}">go</a></body></html>"#
    ))
}

/// Echoes the `any` param verbatim in HTML body text with no escaping.
async fn body_raw(Query(p): Query<HashMap<String, String>>) -> impl IntoResponse {
    let any = p.get("any").cloned().unwrap_or_default();
    Html(format!(
        r#"<!DOCTYPE html><html><body><p>You searched for: {any}</p></body></html>"#
    ))
}

// ===========================================================================
// Server
// ===========================================================================

async fn start_test_server() -> SocketAddr {
    let app = Router::new()
        .route("/self-link-encoded", get(self_link_encoded))
        .route("/href-value-start", get(href_value_start))
        .route("/href-literal", get(href_literal_breakout))
        .route("/href-literal-single", get(href_literal_breakout_single))
        .route("/self-link-plus-live", get(self_link_plus_live_breakout))
        .route("/self-link-plus-value-start", get(self_link_plus_live_value_start))
        .route("/body-raw", get(body_raw));

    let listener = tokio::net::TcpListener::bind((Ipv4Addr::LOCALHOST, 0))
        .await
        .expect("bind listener");
    let addr = listener.local_addr().unwrap();

    tokio::spawn(async move {
        axum::serve(listener, app)
            .with_graceful_shutdown(async {
                tokio::time::sleep(Duration::from_secs(300)).await;
            })
            .await
            .ok();
    });

    tokio::time::sleep(Duration::from_millis(50)).await;
    addr
}

// ===========================================================================
// Reflection driver
// ===========================================================================

/// A query `Param` named `any`, seeded with the same value that appears in the
/// target URL query. Same field set as `make_param()` in the repo's
/// `src/scanning/check_reflection/tests.rs`, with this file's param name.
fn make_param() -> Param {
    Param {
        name: "any".to_string(),
        value: "test".to_string(),
        location: Location::Query,
        injection_context: None,
        valid_specials: None,
        invalid_specials: None,
        pre_encoding: None,
        pre_encoding_pipeline: None,
        wire_name: None,
        form_action_url: None,
        form_origin_url: None,
        framework_sink: None,
        escaped_specials: None,
        js_breakout: None,
    }
}

/// Full `ScanArgs`, same values as `default_scan_args()` in the repo's
/// `src/scanning/check_reflection/tests.rs`. `skip_xss_scanning` stays `false`
/// (otherwise the entry point returns `None` before injecting); the rest does
/// not affect a single `check_reflection_with_response` call.
fn default_scan_args() -> ScanArgs {
    ScanArgs {
        insecure: Some(true),
        detect_outdated_libs: false,
        input_type: "auto".to_string(),
        format: "json".to_string(),
        targets: vec![],
        param: vec![],
        data: None,
        headers: vec![],
        cookies: vec![],
        method: "GET".to_string(),
        user_agent: None,
        cookie_from_raw: None,
        include_url: vec![],
        exclude_url: vec![],
        ignore_param: vec![],
        out_of_scope: vec![],
        out_of_scope_file: None,
        mining_dict_word: None,
        skip_mining: false,
        skip_mining_dict: false,
        skip_mining_dom: false,
        only_discovery: false,
        skip_discovery: false,
        skip_reflection_header: false,
        skip_reflection_cookie: false,
        skip_reflection_path: false,
        timeout: 10,
        scan_timeout: 0,
        delay: 0,
        proxy: None,
        follow_redirects: false,
        ignore_return: vec![],
        output: None,
        include_request: false,
        include_response: false,
        include_all: false,
        no_color: false,
        silence: true,
        dry_run: false,
        stream_findings: false,
        poc_type: "plain".to_string(),
        limit: None,
        limit_result_type: "all".to_string(),
        only_poc: vec![],
        workers: 10,
        max_concurrent_targets: 10,
        max_targets_per_host: 100,
        encoders: vec!["url".to_string(), "html".to_string(), "base64".to_string()],
        custom_blind_xss_payload: None,
        blind_callback_url: None,
        oob: Default::default(),
        custom_payload: None,
        only_custom_payload: false,
        inject_marker: None,
        custom_alert_value: "1".to_string(),
        custom_alert_type: "none".to_string(),
        skip_xss_scanning: false,
        max_payloads_per_param: 0,
        deep_scan: false,
        sxss: false,
        sxss_url: None,
        sxss_method: "GET".to_string(),
        sxss_retries: 3,
        skip_ast_analysis: false,
        analyze_external_js: false,
        hpp: false,
        waf_bypass: "auto".to_string(),
        skip_waf_probe: false,
        force_waf: None,
        waf_evasion: false,
        rate_limit: 0,
        retries: 0,
        retry_delay: 1000,
        waf_min_confidence: 0.0,
        remote_payloads: vec![],
        remote_wordlists: vec![],
    }
}

/// Start the mock, inject `payload` at the `any` query param of `path`, run the
/// public reflection check, and return its decision: `Some(kind)` when the
/// reflection is reported, `None` when it is not.
async fn reflect(path: &str, payload: &str) -> Option<ReflectionKind> {
    let addr = start_test_server().await;
    let url = format!("http://{}:{}{}?any=test", addr.ip(), addr.port(), path);
    let target = parse_target(&url).expect("valid target");
    let param = make_param();
    let args = default_scan_args();

    let (kind, _body) =
        check_reflection_with_response(None, &target, &param, payload, &args).await;
    kind
}

// ===========================================================================
// Payloads
// ===========================================================================

// Hex-entity form of `javasscriptcript:a["b"]`, a keyword-doubled WAF-evasion
// mutation of a `javascript:` scheme. Its entity-decoded form carries `"`.
const ENCODED_SCHEME_WITH_QUOTE: &str =
    "&#x6a;&#x61;&#x76;&#x61;&#x73;&#x73;&#x63;&#x72;&#x69;&#x70;&#x74;&#x63;&#x72;&#x69;&#x70;&#x74;&#x3a;&#x61;&#x5b;&#x22;&#x62;&#x22;&#x5d;";
// Decimal-entity form of `vbscriptcript:a['b']`: another scheme family, another
// entity notation, and `'` instead of `"`.
const ENCODED_SCHEME_WITH_QUOTE_ALT: &str =
    "&#118;&#98;&#115;&#99;&#114;&#105;&#112;&#116;&#99;&#114;&#105;&#112;&#116;&#58;&#97;&#91;&#39;&#98;&#39;&#93;";
// Named-entity attribute break-out, `" onmouseover=alert(1) x="` once decoded.
// No scheme and no doubled keyword.
const ENCODED_ATTR_BREAKOUT: &str = "&quot; onmouseover=alert(1) x=&quot;";
// Named-entity tag, `<svg onload=alert(1)>` once decoded. Angle brackets and no
// quote.
const ENCODED_TAG: &str = "&lt;svg onload=alert(1)&gt;";
// Hex-entity form of `javascript:alert(1)`.
const ENCODED_SCHEME_EXECUTABLE: &str =
    "&#x6a;&#x61;&#x76;&#x61;&#x73;&#x63;&#x72;&#x69;&#x70;&#x74;&#x3a;&#x61;&#x6c;&#x65;&#x72;&#x74;&#x28;&#x31;&#x29;";
// Decimal-entity form of `vbscript:msgbox(1)`.
const ENCODED_SCHEME_EXECUTABLE_ALT: &str =
    "&#118;&#98;&#115;&#99;&#114;&#105;&#112;&#116;&#58;&#109;&#115;&#103;&#98;&#111;&#120;&#40;&#49;&#41;";
// Raw double-quote and tag break-out.
const LITERAL_TAG_BREAKOUT: &str = "\"><img src=x onerror=alert(1)>";
// Raw single-quote attribute break-out, no tag.
const LITERAL_SINGLE_QUOTE_BREAKOUT: &str = "' onmouseover=alert(1) x='";
// Named-entity form of `"><svg/onload=alert(1)>`.
const ENCODED_TAG_BREAKOUT: &str = "&quot;&gt;&lt;svg/onload=alert(1)&gt;";
// Ordinary reflected-XSS vector for an unescaped HTML body context.
const ORDINARY_HTML_PAYLOAD: &str = "<img src=x onerror=alert(1)>";

// ===========================================================================
// Behavioral cases
// ===========================================================================

/// Case 1: an entity-encoded payload whose only copies in the page are
/// percent-encoded inside the query of a canonical link and an anchor self-link
/// is not reported. Four payloads that differ in scheme, entity notation,
/// break-out character and shape all get the same decision.
#[tokio::test]
async fn encoded_scheme_in_self_link_query_is_not_reported() {
    for (label, payload) in [
        (
            "hex-entity keyword-doubled javascript: scheme with a double quote",
            ENCODED_SCHEME_WITH_QUOTE,
        ),
        (
            "decimal-entity keyword-doubled vbscript: scheme with a single quote",
            ENCODED_SCHEME_WITH_QUOTE_ALT,
        ),
        (
            "named-entity attribute break-out with no scheme",
            ENCODED_ATTR_BREAKOUT,
        ),
        ("named-entity tag with no quote", ENCODED_TAG),
    ] {
        let kind = reflect("/self-link-encoded", payload).await;
        assert!(
            kind.is_none(),
            "{label}, echoed only percent-encoded in a self-link query, is inert and \
             must not be reported, but it was reported as {kind:?}"
        );
    }
}

/// Case 2: an entity-encoded scheme reflected as the whole `href` value is the
/// link's scheme in the browser and stays reported.
#[tokio::test]
async fn encoded_scheme_at_href_value_start_is_reported() {
    for (label, payload) in [
        ("hex-entity javascript: scheme", ENCODED_SCHEME_EXECUTABLE),
        ("decimal-entity vbscript: scheme", ENCODED_SCHEME_EXECUTABLE_ALT),
    ] {
        let kind = reflect("/href-value-start", payload).await;
        assert!(
            kind.is_some(),
            "{label} at the href value start is executable and must stay reported, \
             but it was not reported"
        );
    }
}

/// Case 3: a raw quote that closes the surrounding quoted `href` value stays
/// reported, with a tag after it or with only an injected attribute.
#[tokio::test]
async fn literal_breakout_in_url_attribute_is_reported() {
    let kind = reflect("/href-literal", LITERAL_TAG_BREAKOUT).await;
    assert!(
        kind.is_some(),
        "a raw double-quote and tag break-out reflected inside a double-quoted href \
         must stay reported, but it was not reported"
    );

    let kind = reflect("/href-literal-single", LITERAL_SINGLE_QUOTE_BREAKOUT).await;
    assert!(
        kind.is_some(),
        "a raw single-quote attribute break-out reflected inside a single-quoted href \
         must stay reported, but it was not reported"
    );
}

/// Case 4: an inert percent-encoded copy in the canonical link does not hide a
/// live copy of the same payload elsewhere in the page, whether the live copy
/// is a raw quote break-out or an encoded scheme as the whole `href` value.
#[tokio::test]
async fn self_link_echo_does_not_hide_live_copy() {
    let kind = reflect("/self-link-plus-live", ENCODED_TAG_BREAKOUT).await;
    assert!(
        kind.is_some(),
        "the page also reflects the decoded break-out unencoded inside an anchor href, \
         so it must stay reported, but it was not reported"
    );

    let kind = reflect("/self-link-plus-value-start", ENCODED_SCHEME_EXECUTABLE).await;
    assert!(
        kind.is_some(),
        "the page also writes the encoded scheme as the whole value of an anchor href, \
         so it must stay reported, but it was not reported"
    );
}

/// Case 5: ordinary unescaped reflection in HTML body text stays reported.
#[tokio::test]
async fn ordinary_html_body_reflection_is_reported() {
    let kind = reflect("/body-raw", ORDINARY_HTML_PAYLOAD).await;
    assert!(
        kind.is_some(),
        "ordinary unescaped HTML-body reflection must still be reported, \
         but it was not reported"
    );
}
