#!/usr/bin/env bash
# Pre-warm the dalfox test build so the behavioral verifier doesn't pay the
# full cold compile. The verifier is an integration test injected under tests/
# that calls the crate's public reflection API, so the lib, its
# dev-dependencies and the existing test targets need to be compiled, not a
# fresh download.
#
# Offline-first: dependencies are baked into the image with the cargo
# registry/cache warm, so `--locked --offline` must succeed with no network.
# The verifier phase runs with network available, so if for any reason a
# dependency is missing we fall back to an online fetch and log it loudly
# rather than failing silently.
set -euo pipefail

cd /repo/dalfox

# Compile the dalfox lib + all test targets (including dev-deps) without
# running anything. The verifier injects its own test file under tests/ and
# reuses this warm target/.
if ! cargo test --locked --offline --no-run > /tmp/dalfox_test_setup.log 2>&1; then
    echo "[test-setup] offline build failed; retrying with network (logging fallback)" >&2
    tail -n 80 /tmp/dalfox_test_setup.log >&2 || true
    cargo fetch --locked
    cargo test --locked --no-run
fi

ls -la "${CARGO_TARGET_DIR:-/opt/cache/cargo-target}/debug/" | head -n 5
