#!/usr/bin/env bash
# Environment bootstrap for the verifier. Sourced (not exec'd) so env
# vars set here stay live for the verifier subprocess.
#
# The image already bakes the full dependency closure at the base commit
# (`pnpm install --frozen-lockfile`) and the package dist/ outputs (block 7b),
# so this script is defensive only. The behavioral verifier is a native
# TypeScript vitest test that imports the agents-core package from its `src/`
# via the repo's workspace aliases, so the agent's edits to `src/` are visible
# without a dist rebuild.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/openai-agents-js}"
export REPO_DIR
cd "$REPO_DIR"

# vitest must be resolvable from the workspace root. A miss means a corrupted
# node_modules (the baked offline install failed to materialize the bin); heal
# it from the warm pnpm store before the verifier fails with a confusing
# "command not found". This is the single dependency-resolving command in this
# script (offline-first: the store is warm from the image build; the online
# retry is a logged fallback, not a second independent resolve).
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest binary missing from node_modules/.bin/ — " \
         "re-materializing from the warm pnpm store." >&2
    pnpm install --frozen-lockfile --offline > /tmp/pnpm-install.log 2>&1 \
        || { pnpm install --frozen-lockfile > /tmp/pnpm-install.log 2>&1 \
               || { tail -80 /tmp/pnpm-install.log; exit 1; }; }
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR node=$(node --version 2>/dev/null || echo unknown) vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
