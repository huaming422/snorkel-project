// Behavioral checks for the serialized approval-resume path of
// `@openai/agents-core`. Everything here is driven through the package's
// existing public API plus its published deterministic model double
// (`@openai/agents-core/testing`). No private helper is imported. Most edits a
// case makes, to the loaded state or to the saved string, touch fields the
// saved format already had before this change. One block also edits whatever
// a saved string holds beyond that format, found by comparing slot names, so
// it names no field and assumes no shape. The run is fully offline:
// `ScriptedModel` produces the approval interruptions with no network.
//
// Each block checks something a caller can see: which tool output becomes the
// resumed final output, what the `Session` ends up holding, what the blocked
// state keeps, and how many times the tool mocks and the model were invoked.
// Rejection blocks check only that an error is thrown, plus that no tool ran
// and the session is untouched. The error text is not matched.

import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

import { describe, expect, it, vi } from 'vitest';
import { z } from 'zod';

import {
  Agent,
  GuardrailExecutionError,
  MemorySession,
  OutputGuardrailTripwireTriggered,
  RunState,
  ToolGuardrailFunctionOutputFactory,
  Usage,
  defineToolOutputGuardrail,
  handoff,
  run,
  tool,
  toolNamespace,
  type AgentInputItem,
  type Session,
} from '../src';
import {
  ScriptedModel,
  assistantMessage,
  functionCall,
  modelResponse,
} from '../src/testing';

type RunMode = 'non_streamed' | 'streamed';

// An append-only Session that never rewrites history, lets a test read back
// exactly what the resume path chose to persist.
class AppendOnlySession implements Session {
  readonly items: AgentInputItem[] = [];

  async getSessionId(): Promise<string> {
    return 'resume-ownership-append-only-session';
  }

  async getItems(): Promise<AgentInputItem[]> {
    return structuredClone(this.items);
  }

  async addItems(items: AgentInputItem[]): Promise<void> {
    this.items.push(...structuredClone(items));
  }

  async popItem(): Promise<AgentInputItem | undefined> {
    return this.items.pop();
  }

  async clearSession(): Promise<void> {
    this.items.length = 0;
  }
}

// Slot names the saved string uses for the paused runs in the added-data
// block below, as the saved format wrote them before this change. Array
// positions are written as `[]`. Any other slot in a saved string from those
// runs is data an implementation added to the format, whatever its name or
// shape.
const PRE_EXISTING_SAVED_SLOTS = new Set<string>([
  '$schemaVersion',
  'ambiguousToolInvocationCallIds',
  'completedToolInvocationEvidence',
  'completedToolInvocationEvidence.[].agentIdentity',
  'completedToolInvocationEvidence.[].invocations.audit-call.fingerprint',
  'completedToolInvocationEvidence.[].invocations.audit-call.items',
  'completedToolInvocationEvidence.[].invocations.audit-call.items.[].generatedItemIndex',
  'completedToolInvocationEvidence.[].invocations.guarded-call.fingerprint',
  'completedToolInvocationEvidence.[].invocations.guarded-call.items',
  'completedToolInvocationEvidence.[].invocations.guarded-call.items.[].generatedItemIndex',
  'completedToolInvocationEvidence.[].invocations.payroll-first-call.fingerprint',
  'completedToolInvocationEvidence.[].invocations.payroll-first-call.items',
  'completedToolInvocationEvidence.[].invocations.payroll-first-call.items.[].generatedItemIndex',
  'completedToolInvocationEvidence.[].invocations.payroll-first-call.items.[].item.agent.name',
  'completedToolInvocationEvidence.[].invocations.payroll-first-call.items.[].item.functionToolStateKey',
  'completedToolInvocationEvidence.[].invocations.payroll-first-call.items.[].item.rawItem.arguments',
  'completedToolInvocationEvidence.[].invocations.payroll-first-call.items.[].item.rawItem.callId',
  'completedToolInvocationEvidence.[].invocations.payroll-first-call.items.[].item.rawItem.id',
  'completedToolInvocationEvidence.[].invocations.payroll-first-call.items.[].item.rawItem.name',
  'completedToolInvocationEvidence.[].invocations.payroll-first-call.items.[].item.rawItem.namespace',
  'completedToolInvocationEvidence.[].invocations.payroll-first-call.items.[].item.rawItem.status',
  'completedToolInvocationEvidence.[].invocations.payroll-first-call.items.[].item.rawItem.type',
  'completedToolInvocationEvidence.[].invocations.payroll-first-call.items.[].item.toolName',
  'completedToolInvocationEvidence.[].invocations.payroll-first-call.items.[].item.type',
  'completedToolInvocationEvidence.[].invocations.sibling-audit-call.fingerprint',
  'completedToolInvocationEvidence.[].invocations.sibling-audit-call.items',
  'completedToolInvocationEvidence.[].invocations.sibling-audit-call.items.[].generatedItemIndex',
  'completedToolInvocations',
  'completedToolInvocations.[].agentIdentity',
  'completedToolInvocations.[].invocations.audit-call',
  'completedToolInvocations.[].invocations.guarded-call',
  'completedToolInvocations.[].invocations.payroll-first-call',
  'completedToolInvocations.[].invocations.sibling-audit-call',
  'context.approvalInvocations',
  'context.approvalInvocations.[].agentIdentity',
  'context.approvalInvocations.[].invocations.payroll-first-call',
  'context.functionApprovals',
  'context.functionApprovals.[].agentIdentity',
  'context.functionApprovals.[].approvals.["namespaced","payroll","payroll_first_approval_tool"].approved',
  'context.functionApprovals.[].approvals.["namespaced","payroll","payroll_first_approval_tool"].approved.[]',
  'context.functionApprovals.[].approvals.["namespaced","payroll","payroll_first_approval_tool"].rejected',
  'context.usage.inputTokens',
  'context.usage.inputTokensDetails',
  'context.usage.outputTokens',
  'context.usage.outputTokensDetails',
  'context.usage.requests',
  'context.usage.totalTokens',
  'currentAgent.name',
  'currentAgentSpan',
  'currentStep.data.interruptions',
  'currentStep.data.interruptions.[].agent.name',
  'currentStep.data.interruptions.[].functionToolStateKey',
  'currentStep.data.interruptions.[].rawItem.arguments',
  'currentStep.data.interruptions.[].rawItem.callId',
  'currentStep.data.interruptions.[].rawItem.id',
  'currentStep.data.interruptions.[].rawItem.name',
  'currentStep.data.interruptions.[].rawItem.namespace',
  'currentStep.data.interruptions.[].rawItem.status',
  'currentStep.data.interruptions.[].rawItem.type',
  'currentStep.data.interruptions.[].toolName',
  'currentStep.data.interruptions.[].type',
  'currentStep.type',
  'currentTurn',
  'currentTurnInProgress',
  'currentTurnPersistedItemCount',
  'currentTurnSessionInputItems',
  'currentTurnSessionInputItems.[].content',
  'currentTurnSessionInputItems.[].role',
  'currentTurnSessionInputItems.[].type',
  'generatedItems',
  'generatedItems.[].agent.name',
  'generatedItems.[].executionStatus',
  'generatedItems.[].functionToolStateKey',
  'generatedItems.[].output',
  'generatedItems.[].rawItem.arguments',
  'generatedItems.[].rawItem.callId',
  'generatedItems.[].rawItem.id',
  'generatedItems.[].rawItem.name',
  'generatedItems.[].rawItem.namespace',
  'generatedItems.[].rawItem.output.text',
  'generatedItems.[].rawItem.output.type',
  'generatedItems.[].rawItem.status',
  'generatedItems.[].rawItem.type',
  'generatedItems.[].toolName',
  'generatedItems.[].type',
  'inputGuardrailResults',
  'lastModelResponse.output',
  'lastModelResponse.output.[].arguments',
  'lastModelResponse.output.[].callId',
  'lastModelResponse.output.[].id',
  'lastModelResponse.output.[].name',
  'lastModelResponse.output.[].namespace',
  'lastModelResponse.output.[].status',
  'lastModelResponse.output.[].type',
  'lastModelResponse.responseId',
  'lastModelResponse.usage.inputTokens',
  'lastModelResponse.usage.inputTokensDetails',
  'lastModelResponse.usage.outputTokens',
  'lastModelResponse.usage.outputTokensDetails',
  'lastModelResponse.usage.requests',
  'lastModelResponse.usage.totalTokens',
  'lastProcessedResponse.applyPatchActions',
  'lastProcessedResponse.computerActions',
  'lastProcessedResponse.functionToolsNotFound',
  'lastProcessedResponse.functions',
  'lastProcessedResponse.functions.[].tool.deferLoading',
  'lastProcessedResponse.functions.[].tool.description',
  'lastProcessedResponse.functions.[].tool.inputGuardrails',
  'lastProcessedResponse.functions.[].tool.name',
  'lastProcessedResponse.functions.[].tool.outputGuardrails',
  'lastProcessedResponse.functions.[].tool.outputGuardrails.[].name',
  'lastProcessedResponse.functions.[].tool.outputGuardrails.[].type',
  'lastProcessedResponse.functions.[].tool.parameters.$schema',
  'lastProcessedResponse.functions.[].tool.parameters.additionalProperties',
  'lastProcessedResponse.functions.[].tool.parameters.required',
  'lastProcessedResponse.functions.[].tool.parameters.type',
  'lastProcessedResponse.functions.[].tool.strict',
  'lastProcessedResponse.functions.[].tool.timeoutBehavior',
  'lastProcessedResponse.functions.[].tool.type',
  'lastProcessedResponse.functions.[].toolCall.arguments',
  'lastProcessedResponse.functions.[].toolCall.callId',
  'lastProcessedResponse.functions.[].toolCall.id',
  'lastProcessedResponse.functions.[].toolCall.name',
  'lastProcessedResponse.functions.[].toolCall.namespace',
  'lastProcessedResponse.functions.[].toolCall.status',
  'lastProcessedResponse.functions.[].toolCall.type',
  'lastProcessedResponse.handoffs',
  'lastProcessedResponse.mcpApprovalRequests',
  'lastProcessedResponse.newItems',
  'lastProcessedResponse.newItems.[].agent.name',
  'lastProcessedResponse.newItems.[].rawItem.arguments',
  'lastProcessedResponse.newItems.[].rawItem.callId',
  'lastProcessedResponse.newItems.[].rawItem.id',
  'lastProcessedResponse.newItems.[].rawItem.name',
  'lastProcessedResponse.newItems.[].rawItem.namespace',
  'lastProcessedResponse.newItems.[].rawItem.status',
  'lastProcessedResponse.newItems.[].rawItem.type',
  'lastProcessedResponse.newItems.[].type',
  'lastProcessedResponse.shellActions',
  'lastProcessedResponse.toolsUsed',
  'lastProcessedResponse.toolsUsed.[]',
  'maxTurns',
  'modelResponses',
  'modelResponses.[].output',
  'modelResponses.[].output.[].arguments',
  'modelResponses.[].output.[].callId',
  'modelResponses.[].output.[].id',
  'modelResponses.[].output.[].name',
  'modelResponses.[].output.[].namespace',
  'modelResponses.[].output.[].status',
  'modelResponses.[].output.[].type',
  'modelResponses.[].responseId',
  'modelResponses.[].usage.inputTokens',
  'modelResponses.[].usage.inputTokensDetails',
  'modelResponses.[].usage.outputTokens',
  'modelResponses.[].usage.outputTokensDetails',
  'modelResponses.[].usage.requests',
  'modelResponses.[].usage.totalTokens',
  'noActiveAgentRun',
  'originalInput',
  'originalInput.[].content',
  'originalInput.[].role',
  'originalInput.[].type',
  'outputGuardrailResults',
  'toolInputGuardrailResults',
  'toolOutputGuardrailResults',
  'toolOutputGuardrailResults.[].guardrail.name',
  'toolOutputGuardrailResults.[].guardrail.type',
  'toolOutputGuardrailResults.[].output.behavior.type',
  'toolOutputGuardrailResults.[].output.outputInfo',
  'toolUseTracker.Guarded earlier result agent',
  'toolUseTracker.Guarded earlier result agent.[]',
  'toolUseTracker.Guarded sibling audit agent',
  'toolUseTracker.Guarded sibling audit agent.[]',
  'toolUseTracker.One of two approved agent',
  'toolUseTracker.One of two approved agent.[]',
  'toolUseTracker.Two pending approvals agent',
  'toolUseTracker.Two pending approvals agent.[]',
  'trace',
  'trace.group_id',
  'trace.id',
  'trace.object',
  'trace.workflow_name',
]);

type SavedSlot = {
  path: (string | number)[];
  slot: string;
  value: unknown;
};

// Every array and every primitive in a parsed saved string, with its exact
// path and its slot name.
function savedSlots(
  value: unknown,
  path: (string | number)[] = [],
  out: SavedSlot[] = [],
): SavedSlot[] {
  const slot = path
    .map((part) => (typeof part === 'number' ? '[]' : part))
    .join('.');
  if (Array.isArray(value)) {
    out.push({ path, slot, value });
    value.forEach((entry, index) => savedSlots(entry, [...path, index], out));
  } else if (value !== null && typeof value === 'object') {
    for (const [key, entry] of Object.entries(value)) {
      savedSlots(entry, [...path, key], out);
    }
  } else {
    out.push({ path, slot, value });
  }
  return out;
}

// Values that cannot describe a position or count in the paused run: a
// negative number, a fraction, a number far past every list in the run, an
// emptied list, a list with its first entry repeated, and a list in reverse
// order.
function malformedValues(value: unknown): unknown[] {
  let candidates: unknown[] = [];
  if (typeof value === 'number') {
    candidates = [-1, value + 0.5, value + 2 ** 20];
  } else if (Array.isArray(value) && value.length > 0) {
    candidates = [[], [...value, value[0]], [...value].reverse()];
  }
  return candidates.filter(
    (candidate) => JSON.stringify(candidate) !== JSON.stringify(value),
  );
}

function withValueAt(
  saved: unknown,
  path: (string | number)[],
  value: unknown,
): string {
  const edited = structuredClone(saved) as Record<string | number, any>;
  let parent = edited;
  for (const part of path.slice(0, -1)) {
    parent = parent[part];
  }
  parent[path.at(-1)!] = value;
  return JSON.stringify(edited);
}

describe('serialized approval resume preserves current-response ownership', () => {
  // An auto-executing earlier tool records one accepted result; a later
  // approval-gated tool is the one being resumed. After save-to-string,
  // restore, approve, and resume, the approved tool's own output must be the
  // final output and must be persisted, the earlier accepted output must still
  // be there, and the model must not be re-invoked a spurious extra time.
  it.each<RunMode>(['non_streamed', 'streamed'])(
    'surfaces and persists the approved output after an earlier %s result survives the round trip',
    async (mode) => {
      const historicalExecute = vi.fn(async () => 'accepted earlier result');
      const approvedExecute = vi.fn(async () => 'approved later result');
      const historicalTool = tool({
        name: 'historical_tool',
        description: 'Returns an accepted result before the approval.',
        parameters: z.object({}),
        outputGuardrails: [
          defineToolOutputGuardrail({
            name: 'accepted historical tool guardrail',
            run: async () =>
              ToolGuardrailFunctionOutputFactory.allow(
                'accepted historical guardrail metadata',
              ),
          }),
        ],
        execute: historicalExecute,
      });
      const approvalTool = tool({
        name: 'later_approval_tool',
        description: 'Requires approval after the earlier result.',
        parameters: z.object({}),
        needsApproval: true,
        execute: approvedExecute,
      });
      const model = new ScriptedModel([
        modelResponse({
          output: [
            functionCall('historical_tool', {}, { callId: 'historical-call' }),
          ],
          usage: new Usage(),
        }),
        modelResponse({
          output: [
            functionCall(
              'later_approval_tool',
              {},
              { callId: 'later-approval-call' },
            ),
          ],
          usage: new Usage(),
        }),
      ]);
      const agent = new Agent({
        name: 'Historical result before approval agent',
        model,
        tools: [historicalTool, approvalTool],
        toolUseBehavior: { stopAtToolNames: ['later_approval_tool'] },
        outputGuardrails: [
          {
            name: 'passing approval output guardrail',
            execute: async () => ({
              outputInfo: undefined,
              tripwireTriggered: false,
            }),
          },
        ],
      });
      const session = new MemorySession();
      const runOnce = async (
        input: string | RunState<unknown, typeof agent>,
        useSession = true,
      ) => {
        const options = useSession ? { session } : {};
        if (mode === 'streamed') {
          const result = await run(agent, input, { ...options, stream: true });
          await result.completed;
          return result;
        }
        return run(agent, input, options);
      };

      const first = await runOnce('Run both tools.', false);
      expect(first.interruptions).toHaveLength(1);
      expect(historicalExecute).toHaveBeenCalledTimes(1);
      expect(approvedExecute).not.toHaveBeenCalled();

      const restored = await RunState.fromString(agent, first.state.toString());
      restored.approve(restored.getInterruptions()[0]!);
      const resumed = await runOnce(restored);

      // The output that is surfaced and persisted is the APPROVED tool's own
      // result, never a stale earlier/other output.
      expect(resumed.finalOutput).toBe('approved later result');
      expect(historicalExecute).toHaveBeenCalledTimes(1);
      expect(approvedExecute).toHaveBeenCalledTimes(1);
      // The model is driven exactly twice (earlier call, then the approval
      // call), no spurious extra turn on resume.
      expect(model.calls).toHaveLength(2);

      const stored = JSON.stringify(await session.getItems());
      expect(stored).toContain('accepted earlier result');
      expect(stored).toContain('approved later result');
    },
  );

  // A handoff whose input filter clears the generated prefix means the current
  // response begins at the very start of the generated items. The resume
  // surfaces the approved tool output and executes it exactly once.
  it.each<RunMode>(['non_streamed', 'streamed'])(
    'resumes a %s approval after a handoff filter clears the generated prefix',
    async (mode) => {
      const execute = vi.fn(async () => 'handoff approval output');
      const approvalTool = tool({
        name: 'handoff_approval_tool',
        description: 'Requires approval after the handoff.',
        parameters: z.object({}),
        needsApproval: true,
        execute,
      });
      const targetModel = new ScriptedModel([
        modelResponse({
          output: [
            functionCall(
              'handoff_approval_tool',
              {},
              { callId: 'handoff-approval-call' },
            ),
          ],
          usage: new Usage(),
        }),
      ]);
      const targetAgent = new Agent({
        name: 'Filtered handoff approval target',
        model: targetModel,
        tools: [approvalTool],
        toolUseBehavior: 'stop_on_first_tool',
        outputGuardrails: [
          {
            name: 'passing handoff approval guardrail',
            execute: async () => ({
              outputInfo: undefined,
              tripwireTriggered: false,
            }),
          },
        ],
      });
      const filteredHandoff = handoff(targetAgent, {
        inputFilter: ({ runContext }) => ({
          inputHistory: [],
          preHandoffItems: [],
          newItems: [],
          runContext,
        }),
      });
      const sourceModel = new ScriptedModel([
        modelResponse({
          output: [
            functionCall(
              filteredHandoff.toolName,
              {},
              { callId: 'filtered-handoff-call' },
            ),
          ],
          usage: new Usage(),
        }),
      ]);
      const sourceAgent = new Agent({
        name: 'Filtered handoff approval source',
        model: sourceModel,
        handoffs: [filteredHandoff],
      });
      const runOnce = async (
        input: string | RunState<unknown, typeof sourceAgent>,
      ) => {
        if (mode === 'streamed') {
          const result = await run(sourceAgent, input, { stream: true });
          await result.completed;
          return result;
        }
        return run(sourceAgent, input);
      };

      const first = await runOnce('Transfer and request approval.');
      expect(first.interruptions).toHaveLength(1);

      const restored = await RunState.fromString(
        sourceAgent,
        first.state.toString(),
      );
      restored.approve(restored.getInterruptions()[0]!);
      const completed = await runOnce(restored);

      expect(completed.finalOutput).toBe('handoff approval output');
      expect(execute).toHaveBeenCalledTimes(1);
      expect(sourceModel.calls).toHaveLength(1);
      expect(targetModel.calls).toHaveLength(1);
    },
  );

  // A portable (namespaced) two-approval flow. On an unedited restore the
  // resume completes and surfaces the approved output with a Session and output
  // guardrails enabled. When the restored checkpoint is edited after loading,
  // by reordering the last response's items or by changing a call's namespace
  // so it no longer matches the generated item, the resume is refused before
  // any side effect. No further tool executes, the model is not called again,
  // and the Session is unchanged. The edits touch only fields the state already
  // had before this change.
  it.each(
    (['non_streamed', 'streamed'] as const).flatMap((mode) =>
      (['session', 'ambiguous', 'namespace_mismatch'] as const).map(
        (verdict) => ({ mode, verdict }),
      ),
    ),
  )(
    'handles a serialized $mode portable approval with a $verdict outcome',
    async ({ mode, verdict }) => {
      const firstExecute = vi.fn(async () => 'accepted first approval output');
      const secondExecute = vi.fn(
        async () => 'accepted second approval output',
      );
      const firstTool = tool({
        name: 'portable_first_approval_tool',
        description: 'Returns an output after the first approval.',
        parameters: z.object({}),
        needsApproval: true,
        execute: firstExecute,
      });
      const secondTool = tool({
        name: 'portable_second_approval_tool',
        description: 'Returns an output after the second approval.',
        parameters: z.object({}),
        needsApproval: true,
        execute: secondExecute,
      });
      const [namespacedFirstTool, namespacedSecondTool] = toolNamespace({
        name: 'crm',
        description: 'Namespaced approval tools.',
        tools: [firstTool, secondTool],
      });
      const model = new ScriptedModel([
        modelResponse({
          output: [
            functionCall(
              'portable_first_approval_tool',
              {},
              { callId: 'portable-first-call', namespace: 'crm' },
            ),
            functionCall(
              'portable_second_approval_tool',
              {},
              { callId: 'portable-second-call', namespace: 'crm' },
            ),
          ],
          usage: new Usage(),
        }),
      ]);
      const agent = new Agent({
        name: 'Portable serialized approval agent',
        model,
        tools: [namespacedFirstTool, namespacedSecondTool],
        toolUseBehavior: 'stop_on_first_tool',
        outputGuardrails: [
          {
            name: 'passing portable approval guardrail',
            execute: async () => ({
              outputInfo: undefined,
              tripwireTriggered: false,
            }),
          },
        ],
      });
      const session = new AppendOnlySession();
      const runOnce = async (
        input: string | RunState<unknown, typeof agent>,
        resumeSession?: Session,
      ) => {
        const options = resumeSession ? { session: resumeSession } : {};
        if (mode === 'streamed') {
          const result = await run(agent, input, { ...options, stream: true });
          await result.completed;
          return result;
        }
        return run(agent, input, options);
      };

      const first = await runOnce('Approve both portable tools.', session);
      first.state.approve(first.interruptions[0]!);
      const partial = await runOnce(first.state, session);
      const historicalSessionItems = await session.getItems();

      // Double round trip: the run is saved and loaded twice before the
      // second approval.
      const onceRestored = await RunState.fromString(
        agent,
        partial.state.toString(),
      );
      const restored = await RunState.fromString(
        agent,
        onceRestored.toString(),
      );
      restored.approve(restored.getInterruptions()[0]!);

      if (verdict === 'ambiguous') {
        // Reverse the order of the restored last response's calls.
        restored._lastTurnResponse?.output.reverse();
      }
      if (verdict === 'namespace_mismatch') {
        // Forge the recorded call's namespace so it disagrees with the live
        // generated item.
        const responseCall = restored._lastTurnResponse?.output[0];
        if (responseCall?.type === 'function_call') {
          responseCall.namespace = 'billing';
        }
      }

      if (verdict === 'ambiguous' || verdict === 'namespace_mismatch') {
        // The resume gets the same Session. An error is thrown (its text is
        // not checked) and nothing a caller can observe has changed.
        await expect(runOnce(restored, session)).rejects.toThrow();
        expect(secondExecute).not.toHaveBeenCalled();
        expect(model.calls).toHaveLength(1);
        expect(await session.getItems()).toEqual(historicalSessionItems);
        return;
      }

      // verdict === 'session': an unedited checkpoint with a Session and
      // output guardrails resumes and surfaces the approved output.
      const completed = await runOnce(restored, session);
      expect(completed.finalOutput).toBe('accepted second approval output');
      expect(firstExecute).toHaveBeenCalledTimes(1);
      expect(secondExecute).toHaveBeenCalledTimes(1);
      expect(model.calls).toHaveLength(1);

      const stored = await session.getItems();
      for (const callId of ['portable-first-call', 'portable-second-call']) {
        expect(
          stored
            .filter(
              (item) =>
                (item.type === 'function_call' ||
                  item.type === 'function_call_result') &&
                item.callId === callId,
            )
            .map((item) => item.type),
        ).toEqual(['function_call', 'function_call_result']);
      }
    },
  );

  // The same portable two-approval flow, but the saved string is edited
  // before it is loaded, so the current turn's data no longer agrees with
  // itself: a processed call's arguments change, the pending approval's
  // arguments change, or the pending approval item is dropped from the
  // generated items. Each edit touches only fields the saved format already
  // had. The edited checkpoint is refused, at load or at resume, before any
  // tool runs, the model is called or the Session is written. The unedited
  // string from the same run then resumes with that Session.
  it.each(
    (['non_streamed', 'streamed'] as const).flatMap((mode) =>
      (['processed_item', 'interruption', 'missing_approval'] as const).map(
        (edit) => ({ mode, edit }),
      ),
    ),
  )(
    'refuses a saved $mode portable checkpoint with an edited $edit and resumes the unedited one',
    async ({ mode, edit }) => {
      const firstExecute = vi.fn(async () => 'accepted first approval output');
      const secondExecute = vi.fn(
        async () => 'accepted second approval output',
      );
      const firstTool = tool({
        name: 'portable_first_approval_tool',
        description: 'Returns an output after the first approval.',
        parameters: z.object({}),
        needsApproval: true,
        execute: firstExecute,
      });
      const secondTool = tool({
        name: 'portable_second_approval_tool',
        description: 'Returns an output after the second approval.',
        parameters: z.object({}),
        needsApproval: true,
        execute: secondExecute,
      });
      const [namespacedFirstTool, namespacedSecondTool] = toolNamespace({
        name: 'crm',
        description: 'Namespaced approval tools.',
        tools: [firstTool, secondTool],
      });
      const model = new ScriptedModel([
        modelResponse({
          output: [
            functionCall(
              'portable_first_approval_tool',
              {},
              { callId: 'portable-first-call', namespace: 'crm' },
            ),
            functionCall(
              'portable_second_approval_tool',
              {},
              { callId: 'portable-second-call', namespace: 'crm' },
            ),
          ],
          usage: new Usage(),
        }),
      ]);
      const agent = new Agent({
        name: 'Edited saved checkpoint agent',
        model,
        tools: [namespacedFirstTool, namespacedSecondTool],
        toolUseBehavior: 'stop_on_first_tool',
        outputGuardrails: [
          {
            name: 'passing edited checkpoint guardrail',
            execute: async () => ({
              outputInfo: undefined,
              tripwireTriggered: false,
            }),
          },
        ],
      });
      const session = new AppendOnlySession();
      const runOnce = async (
        input: string | RunState<unknown, typeof agent>,
      ) => {
        if (mode === 'streamed') {
          const result = await run(agent, input, { session, stream: true });
          await result.completed;
          return result;
        }
        return run(agent, input, { session });
      };

      const first = await runOnce('Approve both portable tools.');
      first.state.approve(first.interruptions[0]!);
      const partial = await runOnce(first.state);
      const historicalSessionItems = await session.getItems();
      const saved = partial.state.toString();

      const edited = JSON.parse(saved) as Record<string, any>;
      const pending = edited.currentStep?.data?.interruptions?.[0];
      expect(pending?.rawItem?.callId).toBe('portable-second-call');
      if (edit === 'processed_item') {
        const processedCall = (
          edited.lastProcessedResponse?.newItems ?? []
        ).find((item: any) => item?.rawItem?.type === 'function_call');
        expect(processedCall).toBeDefined();
        processedCall.rawItem.arguments = JSON.stringify({
          edited: 'processed call arguments',
        });
      }
      if (edit === 'interruption') {
        pending.rawItem.arguments = JSON.stringify({
          edited: 'pending approval arguments',
        });
      }
      if (edit === 'missing_approval') {
        const generatedCount = edited.generatedItems.length;
        edited.generatedItems = edited.generatedItems.filter(
          (item: any) =>
            !(
              item?.type === 'tool_approval_item' &&
              item?.rawItem?.callId === pending.rawItem.callId
            ),
        );
        expect(edited.generatedItems.length).toBeLessThan(generatedCount);
      }

      const resumeEdited = async () => {
        const loaded = await RunState.fromString(agent, JSON.stringify(edited));
        const approval = loaded.getInterruptions()[0];
        if (approval) {
          loaded.approve(approval);
        }
        return runOnce(loaded);
      };
      await expect(resumeEdited()).rejects.toThrow();
      expect(firstExecute).toHaveBeenCalledTimes(1);
      expect(secondExecute).not.toHaveBeenCalled();
      expect(model.calls).toHaveLength(1);
      expect(await session.getItems()).toEqual(historicalSessionItems);

      const restored = await RunState.fromString(agent, saved);
      restored.approve(restored.getInterruptions()[0]!);
      const completed = await runOnce(restored);
      expect(completed.finalOutput).toBe('accepted second approval output');
      expect(firstExecute).toHaveBeenCalledTimes(1);
      expect(secondExecute).toHaveBeenCalledTimes(1);
      expect(model.calls).toHaveLength(1);
    },
  );

  // When an output guardrail throws on a resume that has a Session, the
  // failure surfaces as the public GuardrailExecutionError carrying the
  // original cause. The Session ends up holding exactly what the same failure
  // leaves when the live state is resumed, with the earlier accepted items
  // still first. Driven entirely by the guardrail behavior, with no serialized
  // field edited.
  it.each<RunMode>(['non_streamed', 'streamed'])(
    'raises GuardrailExecutionError and leaves the Session as the live path does on a %s resume',
    async (mode) => {
      const guardrailErrorRun = async (roundTrip: boolean) => {
        const firstExecute = vi.fn(
          async () => 'accepted first approval output',
        );
        const secondExecute = vi.fn(
          async () => 'accepted second approval output',
        );
        const guardrailError = new Error('serialized approval guardrail error');
        const firstTool = tool({
          name: 'portable_first_approval_tool',
          description: 'Returns an output after the first approval.',
          parameters: z.object({}),
          needsApproval: true,
          execute: firstExecute,
        });
        const secondTool = tool({
          name: 'portable_second_approval_tool',
          description: 'Returns an output after the second approval.',
          parameters: z.object({}),
          needsApproval: true,
          execute: secondExecute,
        });
        const [namespacedFirstTool, namespacedSecondTool] = toolNamespace({
          name: 'crm',
          description: 'Namespaced approval tools.',
          tools: [firstTool, secondTool],
        });
        const model = new ScriptedModel([
          modelResponse({
            output: [
              functionCall(
                'portable_first_approval_tool',
                {},
                { callId: 'portable-first-call', namespace: 'crm' },
              ),
              functionCall(
                'portable_second_approval_tool',
                {},
                { callId: 'portable-second-call', namespace: 'crm' },
              ),
            ],
            usage: new Usage(),
          }),
        ]);
        const agent = new Agent({
          name: 'Portable approval guardrail error agent',
          model,
          tools: [namespacedFirstTool, namespacedSecondTool],
          toolUseBehavior: 'stop_on_first_tool',
          outputGuardrails: [
            {
              name: 'throwing portable approval guardrail',
              execute: async () => {
                throw guardrailError;
              },
            },
          ],
        });
        const session = new AppendOnlySession();
        const runOnce = async (
          input: string | RunState<unknown, typeof agent>,
        ) => {
          if (mode === 'streamed') {
            const result = await run(agent, input, { session, stream: true });
            await result.completed;
            return result;
          }
          return run(agent, input, { session });
        };

        const first = await runOnce('Approve both portable tools.');
        first.state.approve(first.interruptions[0]!);
        const partial = await runOnce(first.state);
        const historicalSessionItems = await session.getItems();
        const state = roundTrip
          ? await RunState.fromString(
              agent,
              (
                await RunState.fromString(agent, partial.state.toString())
              ).toString(),
            )
          : partial.state;
        state.approve(state.getInterruptions()[0]!);

        let executionError: GuardrailExecutionError | undefined;
        try {
          await runOnce(state);
        } catch (error) {
          expect(error).toBeInstanceOf(GuardrailExecutionError);
          executionError = error as GuardrailExecutionError;
        }
        expect(executionError?.error).toBe(guardrailError);
        // The current approval was resolved to the current occurrence (both
        // executes ran) and the model was not called again.
        expect(firstExecute).toHaveBeenCalledTimes(1);
        expect(secondExecute).toHaveBeenCalledTimes(1);
        expect(model.calls).toHaveLength(1);
        const stored = await session.getItems();
        expect(stored.slice(0, historicalSessionItems.length)).toEqual(
          historicalSessionItems,
        );
        return stored;
      };

      const live = await guardrailErrorRun(false);
      const restored = await guardrailErrorRun(true);
      expect(restored).toEqual(live);
    },
  );

  // Tripwire variant of the historical-result case. When the output guardrail
  // trips on resume, the approved later output must be withheld from the
  // Session and surface as the public OutputGuardrailTripwireTriggered, while
  // the earlier accepted result stays persisted. The fail-closed behavior is
  // observed through public state and Session contents only.
  it.each<RunMode>(['non_streamed', 'streamed'])(
    'withholds the approved output and keeps the prefix when the %s guardrail trips',
    async (mode) => {
      const historicalExecute = vi.fn(async () => 'accepted earlier result');
      const approvedExecute = vi.fn(async () => 'approved later result');
      const historicalTool = tool({
        name: 'historical_tool',
        description: 'Returns an accepted result before the approval.',
        parameters: z.object({}),
        outputGuardrails: [
          defineToolOutputGuardrail({
            name: 'accepted historical tool guardrail',
            run: async () =>
              ToolGuardrailFunctionOutputFactory.allow(
                'accepted historical guardrail metadata',
              ),
          }),
        ],
        execute: historicalExecute,
      });
      const approvalTool = tool({
        name: 'later_approval_tool',
        description: 'Requires approval after the earlier result.',
        parameters: z.object({}),
        needsApproval: true,
        execute: approvedExecute,
      });
      const model = new ScriptedModel([
        modelResponse({
          output: [
            functionCall('historical_tool', {}, { callId: 'historical-call' }),
          ],
          usage: new Usage(),
        }),
        modelResponse({
          output: [
            functionCall(
              'later_approval_tool',
              {},
              { callId: 'later-approval-call' },
            ),
          ],
          usage: new Usage(),
        }),
      ]);
      const agent = new Agent({
        name: 'Historical result tripwire agent',
        model,
        tools: [historicalTool, approvalTool],
        toolUseBehavior: { stopAtToolNames: ['later_approval_tool'] },
        outputGuardrails: [
          {
            name: 'tripping approval output guardrail',
            execute: async () => ({
              outputInfo: undefined,
              tripwireTriggered: true,
            }),
          },
        ],
      });
      const session = new MemorySession();
      const runOnce = async (
        input: string | RunState<unknown, typeof agent>,
        useSession = true,
      ) => {
        const options = useSession ? { session } : {};
        if (mode === 'streamed') {
          const result = await run(agent, input, { ...options, stream: true });
          await result.completed;
          return result;
        }
        return run(agent, input, options);
      };

      const first = await runOnce('Run both tools.', false);
      expect(first.interruptions).toHaveLength(1);

      const restored = await RunState.fromString(agent, first.state.toString());
      restored.approve(restored.getInterruptions()[0]!);

      let tripwire: OutputGuardrailTripwireTriggered<any> | undefined;
      try {
        await runOnce(restored);
      } catch (error) {
        expect(error).toBeInstanceOf(OutputGuardrailTripwireTriggered);
        tripwire = error as OutputGuardrailTripwireTriggered<any>;
      }
      expect(tripwire).toBeDefined();
      const blockedHistory = JSON.stringify(tripwire!.state!.history);
      // The earlier accepted output stays in the blocked state's history,
      // while the just-approved output is withheld when the guardrail trips.
      expect(blockedHistory).toContain('accepted earlier result');
      expect(blockedHistory).not.toContain('approved later result');
      expect(historicalExecute).toHaveBeenCalledTimes(1);
      expect(approvedExecute).toHaveBeenCalledTimes(1);
      expect(model.calls).toHaveLength(2);
    },
  );

  // One response runs a guarded sibling tool and asks for approval of another.
  // When the run-level output guardrail trips on resume, the blocked state from
  // the saved-and-restored path must keep the same tool guardrail results and
  // history as the blocked state from the live path. The earlier turn's tool
  // guardrail metadata is kept, and the withheld turn's metadata is dropped.
  // Everything is read from the blocked state's public history and its
  // serialized form.
  it.each<RunMode>(['non_streamed', 'streamed'])(
    'keeps the same tool guardrail results as the live path when a restored %s resume trips',
    async (mode) => {
      const earlierInfo = `earlier tool guardrail metadata (${mode})`;
      const siblingInfo = `withheld sibling guardrail metadata (${mode})`;
      const blockedRun = async (roundTrip: boolean) => {
        const earlierExecute = vi.fn(async () => 'earlier lookup result');
        const siblingExecute = vi.fn(async () => 'sibling lookup result');
        const approvedExecute = vi.fn(async () => 'approved commit result');
        const allowWith = (info: string) => [
          defineToolOutputGuardrail({
            name: `allow ${info}`,
            run: async () => ToolGuardrailFunctionOutputFactory.allow(info),
          }),
        ];
        const model = new ScriptedModel([
          modelResponse({
            output: [
              functionCall('earlier_lookup', {}, { callId: 'earlier-call' }),
            ],
            usage: new Usage(),
          }),
          modelResponse({
            output: [
              functionCall('sibling_lookup', {}, { callId: 'sibling-call' }),
              functionCall('approved_commit', {}, { callId: 'commit-call' }),
            ],
            usage: new Usage(),
          }),
        ]);
        const agent = new Agent({
          name: 'Guarded sibling tripwire agent',
          model,
          tools: [
            tool({
              name: 'earlier_lookup',
              description: 'Runs before the approval turn.',
              parameters: z.object({}),
              outputGuardrails: allowWith(earlierInfo),
              execute: earlierExecute,
            }),
            tool({
              name: 'sibling_lookup',
              description: 'Runs next to the approval call.',
              parameters: z.object({}),
              outputGuardrails: allowWith(siblingInfo),
              execute: siblingExecute,
            }),
            tool({
              name: 'approved_commit',
              description: 'Requires approval.',
              parameters: z.object({}),
              needsApproval: true,
              execute: approvedExecute,
            }),
          ],
          toolUseBehavior: { stopAtToolNames: ['approved_commit'] },
          outputGuardrails: [
            {
              name: 'tripping sibling output guardrail',
              execute: async () => ({
                outputInfo: undefined,
                tripwireTriggered: true,
              }),
            },
          ],
        });
        const runOnce = async (
          input: string | RunState<unknown, typeof agent>,
        ) => {
          if (mode === 'streamed') {
            const result = await run(agent, input, { stream: true });
            await result.completed;
            return result;
          }
          return run(agent, input);
        };

        const first = await runOnce('Look things up, then commit.');
        expect(first.interruptions).toHaveLength(1);
        const state = roundTrip
          ? await RunState.fromString(agent, first.state.toString())
          : first.state;
        state.approve(state.getInterruptions()[0]!);

        let tripwire: OutputGuardrailTripwireTriggered<any> | undefined;
        try {
          await runOnce(state);
        } catch (error) {
          expect(error).toBeInstanceOf(OutputGuardrailTripwireTriggered);
          tripwire = error as OutputGuardrailTripwireTriggered<any>;
        }
        expect(tripwire).toBeDefined();
        expect(earlierExecute).toHaveBeenCalledTimes(1);
        expect(siblingExecute).toHaveBeenCalledTimes(1);
        expect(approvedExecute).toHaveBeenCalledTimes(1);
        expect(model.calls).toHaveLength(2);

        const blockedState = tripwire!.state!;
        const serialized = JSON.parse(blockedState.toString()) as {
          toolOutputGuardrailResults?: Array<{
            output?: { outputInfo?: unknown };
          }>;
        };
        return {
          guardrailInfo: (serialized.toolOutputGuardrailResults ?? []).map(
            (result) => result.output?.outputInfo ?? null,
          ),
          history: blockedState.history,
        };
      };

      const live = await blockedRun(false);
      const restored = await blockedRun(true);

      expect(JSON.stringify(restored.guardrailInfo)).toContain(earlierInfo);
      expect(JSON.stringify(restored.guardrailInfo)).not.toContain(siblingInfo);
      expect(restored.guardrailInfo).toEqual(live.guardrailInfo);
      const restoredHistory = JSON.stringify(restored.history);
      expect(restoredHistory).toContain('earlier lookup result');
      expect(restoredHistory).not.toContain('sibling lookup result');
      expect(restoredHistory).not.toContain('approved commit result');
      expect(restored.history).toEqual(live.history);
    },
  );

  // Four paused runs: two approvals still pending in one namespaced response
  // with a Session, the same response after the first approval ran with a
  // Session, an earlier guarded tool result before a later approval
  // with a Session, and a guarded sibling tool next to an approval whose resume
  // trips the output guardrail. Each saved string is compared slot by slot
  // with the saved format as it stood before this change. Every number or list
  // the string holds beyond that format is set, one at a time, to a value that
  // cannot describe this run. Each such checkpoint is refused, at load or at
  // resume, before any tool runs, the model is called or the Session is
  // written. The unedited string then resumes as the live state does. A saved
  // string that holds nothing beyond the earlier format has no added value to
  // change, and only the unedited resume is checked.
  type PausedRun = {
    saved: string;
    resume: (serialized: string) => Promise<unknown>;
    sideEffects: () => Promise<unknown>;
    resumeUnedited: () => Promise<void>;
  };

  const runInMode = async <TAgent extends Agent<any, any>>(
    mode: RunMode,
    agent: TAgent,
    input: string | RunState<unknown, TAgent>,
    session?: Session,
  ) => {
    const options = session ? { session } : {};
    if (mode === 'streamed') {
      const result = await run(agent, input, { ...options, stream: true });
      await result.completed;
      return result;
    }
    return run(agent, input, options);
  };

  const approveAllAndResume = async <TAgent extends Agent<any, any>>(
    mode: RunMode,
    agent: TAgent,
    serialized: string,
    session?: Session,
  ) => {
    const loaded = await RunState.fromString(agent, serialized);
    for (const approval of loaded.getInterruptions()) {
      loaded.approve(approval);
    }
    return runInMode(mode, agent, loaded, session);
  };

  const pausedRuns: Record<
    | 'two_pending_approvals'
    | 'one_of_two_approved'
    | 'guarded_earlier_result'
    | 'guarded_sibling_tripwire',
    (mode: RunMode) => Promise<PausedRun>
  > = {
    two_pending_approvals: async (mode) => {
      const firstExecute = vi.fn(async () => 'pending first approval output');
      const secondExecute = vi.fn(async () => 'pending second approval output');
      const [firstTool, secondTool] = toolNamespace({
        name: 'ledger',
        description: 'Namespaced approval tools.',
        tools: [
          tool({
            name: 'ledger_first_approval_tool',
            description: 'Returns an output after approval.',
            parameters: z.object({}),
            needsApproval: true,
            execute: firstExecute,
          }),
          tool({
            name: 'ledger_second_approval_tool',
            description: 'Returns an output after approval.',
            parameters: z.object({}),
            needsApproval: true,
            execute: secondExecute,
          }),
        ],
      });
      const model = new ScriptedModel([
        modelResponse({
          output: [
            functionCall(
              'ledger_first_approval_tool',
              {},
              { callId: 'ledger-first-call', namespace: 'ledger' },
            ),
            functionCall(
              'ledger_second_approval_tool',
              {},
              { callId: 'ledger-second-call', namespace: 'ledger' },
            ),
          ],
          usage: new Usage(),
        }),
      ]);
      const agent = new Agent({
        name: 'Two pending approvals agent',
        model,
        tools: [firstTool, secondTool],
        toolUseBehavior: 'stop_on_first_tool',
        outputGuardrails: [
          {
            name: 'passing two pending approvals guardrail',
            execute: async () => ({
              outputInfo: undefined,
              tripwireTriggered: false,
            }),
          },
        ],
      });
      const session = new AppendOnlySession();
      const first = await runInMode(
        mode,
        agent,
        'Approve both ledger tools.',
        session,
      );
      expect(first.interruptions).toHaveLength(2);
      return {
        saved: first.state.toString(),
        resume: (serialized) =>
          approveAllAndResume(mode, agent, serialized, session),
        sideEffects: async () => ({
          firstExecute: firstExecute.mock.calls.length,
          secondExecute: secondExecute.mock.calls.length,
          modelCalls: model.calls.length,
          session: await session.getItems(),
        }),
        resumeUnedited: async () => {
          const completed = await approveAllAndResume(
            mode,
            agent,
            first.state.toString(),
            session,
          );
          expect(completed.finalOutput).toBe('pending first approval output');
          expect(firstExecute).toHaveBeenCalledTimes(1);
          expect(secondExecute).toHaveBeenCalledTimes(1);
          expect(model.calls).toHaveLength(1);
          const stored = await session.getItems();
          for (const callId of ['ledger-first-call', 'ledger-second-call']) {
            expect(
              stored
                .filter(
                  (item) =>
                    (item.type === 'function_call' ||
                      item.type === 'function_call_result') &&
                    item.callId === callId,
                )
                .map((item) => item.type),
            ).toEqual(['function_call', 'function_call_result']);
          }
        },
      };
    },
    one_of_two_approved: async (mode) => {
      const firstExecute = vi.fn(async () => 'approved first payroll output');
      const secondExecute = vi.fn(async () => 'approved second payroll output');
      const [firstTool, secondTool] = toolNamespace({
        name: 'payroll',
        description: 'Namespaced approval tools.',
        tools: [
          tool({
            name: 'payroll_first_approval_tool',
            description: 'Returns an output after approval.',
            parameters: z.object({}),
            needsApproval: true,
            execute: firstExecute,
          }),
          tool({
            name: 'payroll_second_approval_tool',
            description: 'Returns an output after approval.',
            parameters: z.object({}),
            needsApproval: true,
            execute: secondExecute,
          }),
        ],
      });
      const model = new ScriptedModel([
        modelResponse({
          output: [
            functionCall(
              'payroll_first_approval_tool',
              {},
              { callId: 'payroll-first-call', namespace: 'payroll' },
            ),
            functionCall(
              'payroll_second_approval_tool',
              {},
              { callId: 'payroll-second-call', namespace: 'payroll' },
            ),
          ],
          usage: new Usage(),
        }),
      ]);
      const agent = new Agent({
        name: 'One of two approved agent',
        model,
        tools: [firstTool, secondTool],
        toolUseBehavior: 'stop_on_first_tool',
        outputGuardrails: [
          {
            name: 'passing one of two approved guardrail',
            execute: async () => ({
              outputInfo: undefined,
              tripwireTriggered: false,
            }),
          },
        ],
      });
      const session = new AppendOnlySession();
      const first = await runInMode(
        mode,
        agent,
        'Approve both payroll tools.',
        session,
      );
      first.state.approve(first.interruptions[0]!);
      const partial = await runInMode(mode, agent, first.state, session);
      expect(partial.interruptions).toHaveLength(1);
      const saved = partial.state.toString();
      return {
        saved,
        resume: (serialized) =>
          approveAllAndResume(mode, agent, serialized, session),
        sideEffects: async () => ({
          firstExecute: firstExecute.mock.calls.length,
          secondExecute: secondExecute.mock.calls.length,
          modelCalls: model.calls.length,
          session: await session.getItems(),
        }),
        resumeUnedited: async () => {
          const completed = await approveAllAndResume(
            mode,
            agent,
            saved,
            session,
          );
          expect(completed.finalOutput).toBe('approved second payroll output');
          expect(firstExecute).toHaveBeenCalledTimes(1);
          expect(secondExecute).toHaveBeenCalledTimes(1);
          expect(model.calls).toHaveLength(1);
          const stored = await session.getItems();
          for (const callId of ['payroll-first-call', 'payroll-second-call']) {
            expect(
              stored
                .filter(
                  (item) =>
                    (item.type === 'function_call' ||
                      item.type === 'function_call_result') &&
                    item.callId === callId,
                )
                .map((item) => item.type),
            ).toEqual(['function_call', 'function_call_result']);
          }
        },
      };
    },
    guarded_earlier_result: async (mode) => {
      const earlierExecute = vi.fn(async () => 'guarded earlier result');
      const approvedExecute = vi.fn(async () => 'approved after guarded result');
      const model = new ScriptedModel([
        modelResponse({
          output: [
            functionCall('guarded_earlier_tool', {}, { callId: 'guarded-call' }),
          ],
          usage: new Usage(),
        }),
        modelResponse({
          output: [
            functionCall(
              'approval_after_guarded_tool',
              {},
              { callId: 'approval-after-guarded-call' },
            ),
          ],
          usage: new Usage(),
        }),
      ]);
      const agent = new Agent({
        name: 'Guarded earlier result agent',
        model,
        tools: [
          tool({
            name: 'guarded_earlier_tool',
            description: 'Returns a guarded result before the approval.',
            parameters: z.object({}),
            outputGuardrails: [
              defineToolOutputGuardrail({
                name: 'allow guarded earlier result',
                run: async () =>
                  ToolGuardrailFunctionOutputFactory.allow(
                    'guarded earlier metadata',
                  ),
              }),
            ],
            execute: earlierExecute,
          }),
          tool({
            name: 'approval_after_guarded_tool',
            description: 'Requires approval after the guarded result.',
            parameters: z.object({}),
            needsApproval: true,
            execute: approvedExecute,
          }),
        ],
        toolUseBehavior: { stopAtToolNames: ['approval_after_guarded_tool'] },
        outputGuardrails: [
          {
            name: 'passing guarded earlier result guardrail',
            execute: async () => ({
              outputInfo: undefined,
              tripwireTriggered: false,
            }),
          },
        ],
      });
      const session = new AppendOnlySession();
      const first = await runInMode(
        mode,
        agent,
        'Run the guarded tool, then ask.',
        session,
      );
      expect(first.interruptions).toHaveLength(1);
      return {
        saved: first.state.toString(),
        resume: (serialized) =>
          approveAllAndResume(mode, agent, serialized, session),
        sideEffects: async () => ({
          earlierExecute: earlierExecute.mock.calls.length,
          approvedExecute: approvedExecute.mock.calls.length,
          modelCalls: model.calls.length,
          session: await session.getItems(),
        }),
        resumeUnedited: async () => {
          const completed = await approveAllAndResume(
            mode,
            agent,
            first.state.toString(),
            session,
          );
          expect(completed.finalOutput).toBe('approved after guarded result');
          expect(earlierExecute).toHaveBeenCalledTimes(1);
          expect(approvedExecute).toHaveBeenCalledTimes(1);
          expect(model.calls).toHaveLength(2);
          const stored = JSON.stringify(await session.getItems());
          expect(stored).toContain('guarded earlier result');
          expect(stored).toContain('approved after guarded result');
        },
      };
    },
    guarded_sibling_tripwire: async (mode) => {
      const earlierInfo = `kept earlier guardrail metadata (${mode})`;
      const siblingInfo = `dropped sibling guardrail metadata (${mode})`;
      const earlierExecute = vi.fn(async () => 'earlier audit result');
      const siblingExecute = vi.fn(async () => 'sibling audit result');
      const approvedExecute = vi.fn(async () => 'approved transfer result');
      const allowWith = (info: string) => [
        defineToolOutputGuardrail({
          name: `allow ${info}`,
          run: async () => ToolGuardrailFunctionOutputFactory.allow(info),
        }),
      ];
      const model = new ScriptedModel([
        modelResponse({
          output: [functionCall('earlier_audit', {}, { callId: 'audit-call' })],
          usage: new Usage(),
        }),
        modelResponse({
          output: [
            functionCall('sibling_audit', {}, { callId: 'sibling-audit-call' }),
            functionCall('approved_transfer', {}, { callId: 'transfer-call' }),
          ],
          usage: new Usage(),
        }),
      ]);
      const agent = new Agent({
        name: 'Guarded sibling audit agent',
        model,
        tools: [
          tool({
            name: 'earlier_audit',
            description: 'Runs before the approval turn.',
            parameters: z.object({}),
            outputGuardrails: allowWith(earlierInfo),
            execute: earlierExecute,
          }),
          tool({
            name: 'sibling_audit',
            description: 'Runs next to the approval call.',
            parameters: z.object({}),
            outputGuardrails: allowWith(siblingInfo),
            execute: siblingExecute,
          }),
          tool({
            name: 'approved_transfer',
            description: 'Requires approval.',
            parameters: z.object({}),
            needsApproval: true,
            execute: approvedExecute,
          }),
        ],
        toolUseBehavior: { stopAtToolNames: ['approved_transfer'] },
        outputGuardrails: [
          {
            name: 'tripping sibling audit guardrail',
            execute: async () => ({
              outputInfo: undefined,
              tripwireTriggered: true,
            }),
          },
        ],
      });
      const first = await runInMode(mode, agent, 'Audit, then transfer.');
      expect(first.interruptions).toHaveLength(1);
      return {
        saved: first.state.toString(),
        resume: (serialized) => approveAllAndResume(mode, agent, serialized),
        sideEffects: async () => ({
          earlierExecute: earlierExecute.mock.calls.length,
          siblingExecute: siblingExecute.mock.calls.length,
          approvedExecute: approvedExecute.mock.calls.length,
          modelCalls: model.calls.length,
        }),
        resumeUnedited: async () => {
          let tripwire: OutputGuardrailTripwireTriggered<any> | undefined;
          try {
            await approveAllAndResume(mode, agent, first.state.toString());
          } catch (error) {
            expect(error).toBeInstanceOf(OutputGuardrailTripwireTriggered);
            tripwire = error as OutputGuardrailTripwireTriggered<any>;
          }
          expect(tripwire).toBeDefined();
          expect(approvedExecute).toHaveBeenCalledTimes(1);
          expect(model.calls).toHaveLength(2);
          const blocked = JSON.parse(tripwire!.state!.toString()) as {
            toolOutputGuardrailResults?: Array<{
              output?: { outputInfo?: unknown };
            }>;
          };
          const guardrailInfo = JSON.stringify(
            (blocked.toolOutputGuardrailResults ?? []).map(
              (result) => result.output?.outputInfo ?? null,
            ),
          );
          expect(guardrailInfo).toContain(earlierInfo);
          expect(guardrailInfo).not.toContain(siblingInfo);
          const history = JSON.stringify(tripwire!.state!.history);
          expect(history).toContain('earlier audit result');
          expect(history).not.toContain('sibling audit result');
          expect(history).not.toContain('approved transfer result');
        },
      };
    },
  };

  it.each(
    (['non_streamed', 'streamed'] as const).flatMap((mode) =>
      (
        [
          'two_pending_approvals',
          'one_of_two_approved',
          'guarded_earlier_result',
          'guarded_sibling_tripwire',
        ] as const
      ).map((paused) => ({ mode, paused })),
    ),
  )(
    'refuses a saved $mode $paused checkpoint whose added values are malformed and resumes the unedited one',
    async ({ mode, paused }) => {
      const pausedRun = await pausedRuns[paused](mode);
      const before = await pausedRun.sideEffects();
      const saved = JSON.parse(pausedRun.saved) as unknown;
      const added = savedSlots(saved).filter(
        ({ slot }) => !PRE_EXISTING_SAVED_SLOTS.has(slot),
      );

      for (const { path, slot, value } of added) {
        for (const malformed of malformedValues(value)) {
          const label = `${slot} set to ${JSON.stringify(malformed)}`;
          await expect(
            pausedRun.resume(withValueAt(saved, path, malformed)),
            label,
          ).rejects.toThrow();
          expect(await pausedRun.sideEffects(), label).toEqual(before);
        }
      }

      await pausedRun.resumeUnedited();
    },
  );

  // A paused approval run written by a released SDK on an older schema
  // version, read unchanged from the repo's own historical fixture corpus,
  // still loads, approves and resumes. The file's SHA-256 is the one the
  // corpus manifest records for it, so the snapshot is the released writer's
  // own output and carries no field added later.
  it.each<RunMode>(['non_streamed', 'streamed'])(
    'still loads and resumes a released older-schema %s approval snapshot',
    async (mode) => {
      const fixture = readFileSync(
        join(
          dirname(fileURLToPath(import.meta.url)),
          'fixtures/run-state/historical/v1.2-nested-approval.json',
        ),
        'utf8',
      );
      expect(createHash('sha256').update(fixture).digest('hex')).toBe(
        '8364cae7dee515fe5ca8da870b5e52e138e85de9adf085af3bceead8acde5f4c',
      );
      expect(JSON.parse(fixture).$schemaVersion).toBe('1.2');

      const approvedExecute = vi.fn(
        async ({ text }: { text: string }) => `approved:${text}`,
      );
      const secureTool = tool({
        name: 'secure_tool',
        description: 'Requires approval.',
        parameters: z.object({ text: z.string() }),
        needsApproval: true,
        execute: approvedExecute,
      });
      const nestedModel = new ScriptedModel([
        modelResponse({
          output: [assistantMessage('Nested done')],
          usage: new Usage(),
        }),
      ]);
      const nestedAgent = new Agent({
        name: 'NestedAgent',
        model: nestedModel,
        tools: [secureTool],
        modelSettings: { toolChoice: 'required' },
      });
      const outerModel = new ScriptedModel([
        modelResponse({
          output: [assistantMessage('Outer done')],
          usage: new Usage(),
        }),
      ]);
      const outerAgent = new Agent({
        name: 'OuterAgent',
        model: outerModel,
        tools: [
          nestedAgent.asTool({
            toolName: 'nested_tool',
            toolDescription: 'Nested agent tool.',
            runOptions: { context: { nested: true } },
          }),
        ],
        modelSettings: { toolChoice: 'required' },
      });

      const restored = await RunState.fromString(outerAgent, fixture);
      const approval = restored.getInterruptions()[0];
      expect(approval?.agent.name).toBe('NestedAgent');
      restored.approve(approval!);

      let finalOutput: unknown;
      if (mode === 'streamed') {
        const result = await run(outerAgent, restored, { stream: true });
        await result.completed;
        finalOutput = result.finalOutput;
      } else {
        finalOutput = (await run(outerAgent, restored)).finalOutput;
      }

      expect(finalOutput).toBe('Outer done');
      expect(approvedExecute).toHaveBeenCalledTimes(1);
      expect(nestedModel.calls).toHaveLength(1);
      expect(outerModel.calls).toHaveLength(1);
    },
  );

  // Approving and resuming the live RunState directly, never going through the
  // string form: the approved output surfaces and persists, and the earlier
  // accepted output is kept.
  it.each<RunMode>(['non_streamed', 'streamed'])(
    'resumes the in-memory %s approval with no round trip unchanged',
    async (mode) => {
      const historicalExecute = vi.fn(async () => 'accepted earlier result');
      const approvedExecute = vi.fn(async () => 'approved later result');
      const historicalTool = tool({
        name: 'historical_tool',
        description: 'Returns an accepted result before the approval.',
        parameters: z.object({}),
        execute: historicalExecute,
      });
      const approvalTool = tool({
        name: 'later_approval_tool',
        description: 'Requires approval after the earlier result.',
        parameters: z.object({}),
        needsApproval: true,
        execute: approvedExecute,
      });
      const model = new ScriptedModel([
        modelResponse({
          output: [
            functionCall('historical_tool', {}, { callId: 'historical-call' }),
          ],
          usage: new Usage(),
        }),
        modelResponse({
          output: [
            functionCall(
              'later_approval_tool',
              {},
              { callId: 'later-approval-call' },
            ),
          ],
          usage: new Usage(),
        }),
      ]);
      const agent = new Agent({
        name: 'In-memory resume agent',
        model,
        tools: [historicalTool, approvalTool],
        toolUseBehavior: { stopAtToolNames: ['later_approval_tool'] },
        outputGuardrails: [
          {
            name: 'passing in-memory output guardrail',
            execute: async () => ({
              outputInfo: undefined,
              tripwireTriggered: false,
            }),
          },
        ],
      });
      const session = new MemorySession();
      const runOnce = async (
        input: string | RunState<unknown, typeof agent>,
        useSession = true,
      ) => {
        const options = useSession ? { session } : {};
        if (mode === 'streamed') {
          const result = await run(agent, input, { ...options, stream: true });
          await result.completed;
          return result;
        }
        return run(agent, input, options);
      };

      const first = await runOnce('Run both tools.', false);
      expect(first.interruptions).toHaveLength(1);

      // Approve and resume the SAME live state, no toString/fromString.
      first.state.approve(first.interruptions[0]!);
      const resumed = await runOnce(first.state);

      expect(resumed.finalOutput).toBe('approved later result');
      expect(historicalExecute).toHaveBeenCalledTimes(1);
      expect(approvedExecute).toHaveBeenCalledTimes(1);
      const stored = JSON.stringify(await session.getItems());
      expect(stored).toContain('accepted earlier result');
      expect(stored).toContain('approved later result');
    },
  );
});
