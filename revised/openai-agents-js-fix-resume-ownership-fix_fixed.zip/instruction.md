## Task

a run can stop and wait for someone to approve a tool call.
you can save the paused run with `toString()`, load it back later with `RunState.fromString()`, approve, and keep going.

after that round trip the resume doesn't act like it does on the live state, streamed or not.
some resumes that work fine live just throw after a restore, mostly once a session or guardrails are set up.
and when an output guardrail blocks the resumed turn, the blocked run we get back still carries bits of that turn that the live path drops.

the refusals we have today are worth keeping, though.
when someone edits a loaded run so it no longer matches the turn it came from, it gets refused before any tool or model call runs or the session is touched, and that should stay.
people also still load snapshots from older SDK versions, and those resume fine right now.
