## Task

a run can stop and wait for someone to approve a tool call.
you can save the paused run with `toString()`, load it back later with `RunState.fromString()`, approve, and keep going.

after that round trip the resume doesn't act like it does on the live state, streamed or not.
some resumes that work fine live just throw after a restore, mostly once a session or guardrails are set up.
reasoning models hit it a lot too: if the paused turn has a reasoning item or a short assistant message next to its tool calls, the restored resume throws where the live one goes through.
this is what we get back:

```
UserError: Cannot resume this serialized output-bearing approval checkpoint because current-response provenance was not preserved. Start a new run from safe input.
```

and when an output guardrail blocks the resumed turn, the blocked run we get back should look like the live one, with whatever earlier turns already accepted still in its history.
right now it still carries bits of the blocked turn that the live path drops.

the refusals we have today are worth keeping, though.
when someone edits a saved string or a loaded run so it no longer matches the turn it came from, it gets refused before any tool or model call runs or the session is touched, and that should stay.
people also still load snapshots from older SDK versions, and those resume fine right now.
