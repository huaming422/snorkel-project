## Task

a run can stop and wait for someone to approve a tool call.
you can save the paused run with `toString()`, load it back later with `RunState.fromString()`, approve, and keep going.

after that round trip the resume doesn't act like it does on the live state.
some resumes that work fine live just throw after a restore, mostly once a session or guardrails are set up.
and when an output guardrail blocks the resumed turn, the blocked run we get back still carries bits of that turn that the live path drops.

a restored run should resume the same way the live one would, streamed or not, with or without a session.
if a loaded run gets edited so it no longer matches the turn it came from, it should still be refused before any tool or model call runs or the session is touched.
snapshots written by older SDK versions still need to load and resume.
please keep the public API signatures as they are.
