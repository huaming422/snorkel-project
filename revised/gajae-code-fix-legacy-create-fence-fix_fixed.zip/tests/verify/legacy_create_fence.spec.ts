// Behavioral spec for how the in-process SDK broker answers lifecycle requests
// when the ledger still holds rows written by an older build.
//
// Everything is driven through `Broker.handleRequest(operation, input,
// idempotencyKey)`, plus the public `LifecycleLedger` calls used to seed row
// state. The checks read only the response the caller gets and whether a
// launch was attempted.
//
// Admitted and refused requests are told apart with an injected lifecycle
// command resolver that points at a missing binary and counts each launch
// attempt. An admitted create runs the resolver and then fails with
// `spawn_failed`. A refused request never runs it and gets an
// `idempotency_conflict` back. No real child process is needed.
//
// Each test uses its own temp agent dir and broker, and a short key as its
// title so the runner can select it by name.
//
// This file is copied into the package test tree at run time so the relative
// imports below resolve. It is not part of the repository's own suite.

import { expect, it } from "bun:test";
import { createHash } from "node:crypto";
import * as fs from "node:fs/promises";
import path from "node:path";

import { Broker, lifecycleTargetForTest, normalizeBrokerInput } from "../src/sdk/broker/broker";
import { deriveLegacyIdentity, deriveLegacyTargetIdentity } from "../src/sdk/broker/identity";
import { setLifecycleCommandResolverForTest } from "../src/sdk/broker/lifecycle";
import { LifecycleLedger } from "../src/sdk/broker/lifecycle-ledger";

const AMBIGUOUS_TARGET_CONFLICT = {
	ok: false,
	error: { code: "idempotency_conflict", message: "legacy lifecycle request has an ambiguous target" },
} as const;

const REUSED_KEY_CONFLICT = {
	ok: false,
	error: { code: "idempotency_conflict", message: "idempotency key was used with a different request" },
} as const;

async function makeAgentDir(prefix: string): Promise<{ root: string; agentDir: string }> {
	const root = await fs.mkdtemp(path.join(process.env.TMPDIR ?? "/tmp", prefix));
	return { root, agentDir: path.join(root, "agent") };
}

// Seed a finished row the way an older build wrote it, with no operation/key
// metadata.
async function seedTerminalLegacyRow(
	ledger: LifecycleLedger,
	identity: string,
	state: "terminal_ok" | "terminal_error",
): Promise<void> {
	await ledger.begin(identity, `legacy-request-${identity}`);
	await ledger.transition(identity, state, {
		response:
			state === "terminal_ok"
				? { ok: true, result: { sessionId: identity } }
				: { ok: false, error: { code: "fixture_error", message: "legacy operation completed" } },
	});
	expect(ledger.get(identity)?.operationKey).toBeUndefined();
}

interface BrokerHandle {
	broker: Broker;
	launchAttempts: () => number;
}

async function startBrokerWithCountingResolver(agentDir: string, missingBinaryDir: string): Promise<BrokerHandle> {
	const broker = new Broker({ agentDir });
	let launchAttempts = 0;
	setLifecycleCommandResolverForTest(broker, () => {
		launchAttempts += 1;
		return { file: path.join(missingBinaryDir, "missing-gjc"), args: [] };
	});
	await broker.start();
	return { broker, launchAttempts: () => launchAttempts };
}

it("fresh_create_past_terminal_legacy", async () => {
	const { root, agentDir } = await makeAgentDir("gjc-fence-fresh-");
	const ledger = await new LifecycleLedger(agentDir).open();
	await seedTerminalLegacyRow(ledger, "legacy-terminal-ok", "terminal_ok");
	await seedTerminalLegacyRow(ledger, "legacy-terminal-error", "terminal_error");

	const handle = await startBrokerWithCountingResolver(agentDir, root);
	try {
		// A create whose key matches no existing row is admitted while only
		// finished old rows (one ok, one error) are present, and reaches launch,
		// which then fails to spawn the missing binary.
		await expect(
			handle.broker.handleRequest("session.create", { cwd: root }, "fresh-after-upgrade"),
		).resolves.toMatchObject({ ok: false, error: { code: "spawn_failed" } });
		expect(handle.launchAttempts()).toBe(1);
	} finally {
		setLifecycleCommandResolverForTest(handle.broker, undefined);
		await handle.broker.stop();
		await fs.rm(root, { recursive: true, force: true });
	}
});

it("nonterminal_legacy_still_fences", async () => {
	const { root, agentDir } = await makeAgentDir("gjc-fence-live-");
	const ledger = await new LifecycleLedger(agentDir).open();
	await seedTerminalLegacyRow(ledger, "legacy-terminal-ok", "terminal_ok");

	let handle = await startBrokerWithCountingResolver(agentDir, root);
	let broker = handle.broker;
	try {
		// With only a finished old row present, a fresh create reaches launch.
		await expect(
			broker.handleRequest("session.create", { cwd: root }, "fresh-after-upgrade"),
		).resolves.toMatchObject({ ok: false, error: { code: "spawn_failed" } });
		expect(handle.launchAttempts()).toBe(1);

		// An old row that has not finished keeps every fresh create refused with
		// the ambiguous-target conflict. Walk it through each in-flight state and
		// check that nothing launches.
		const liveIdentity = "legacy-in-flight";
		await broker.ledger.begin(liveIdentity, "legacy-request-in-flight");

		// "Fenced" means the request was rejected without a new launch. Snapshot
		// the current attempt count and assert it is unchanged across the call so
		// the check stays valid after the broker restart below (a fresh broker
		// starts a fresh counter at zero).
		const assertFenced = async (key: string): Promise<void> => {
			const before = handle.launchAttempts();
			await expect(broker.handleRequest("session.create", { cwd: root }, key)).resolves.toEqual(
				AMBIGUOUS_TARGET_CONFLICT,
			);
			expect(handle.launchAttempts()).toBe(before);
		};

		await assertFenced("fresh-with-accepted-legacy");
		await broker.ledger.transition(liveIdentity, "effect_started");
		await assertFenced("fresh-with-effect-started-legacy");
		await broker.ledger.transition(liveIdentity, "awaiting_ready");
		await assertFenced("fresh-with-awaiting-ready-legacy");

		// Restarting the broker over an in-flight old row records its outcome as
		// unknown. A fresh create is still refused after the restart.
		setLifecycleCommandResolverForTest(broker, undefined);
		await broker.stop();
		handle = await startBrokerWithCountingResolver(agentDir, root);
		broker = handle.broker;
		expect(broker.ledger.get(liveIdentity)?.state).toBe("terminal_uncertain");
		expect(broker.ledger.get(liveIdentity)?.operationKey).toBeUndefined();
		await assertFenced("fresh-with-recovered-uncertain-legacy");
	} finally {
		setLifecycleCommandResolverForTest(broker, undefined);
		await broker.stop();
		await fs.rm(root, { recursive: true, force: true });
	}
});

// Fresh-keyed requests for every other lifecycle operation that reaches
// idempotency admission. Each input passes normalization unchanged.
const NON_CREATE_REQUESTS: ReadonlyArray<readonly [string, (root: string) => Record<string, unknown>]> = [
	["session.delete", root => ({ sessionId: "unrelated-session", sessionPath: path.join(root, "missing.json") })],
	["session.close", () => ({ sessionId: "unrelated-close-session" })],
	["session.resume", () => ({ sessionId: "unrelated-resume-session" })],
	["session.fork", root => ({ cwd: root, sourceSessionId: "unrelated-fork-source" })],
	["session.reconcile_uncertain", () => ({ sessionId: "unrelated-reconcile-session" })],
];

it("relaxation_is_create_only", async () => {
	const { root, agentDir } = await makeAgentDir("gjc-fence-create-only-");
	const ledger = await new LifecycleLedger(agentDir).open();
	await seedTerminalLegacyRow(ledger, "legacy-terminal-ok", "terminal_ok");

	const handle = await startBrokerWithCountingResolver(agentDir, root);
	const broker = handle.broker;
	try {
		// With only a finished old row present, every non-create operation under
		// a fresh key is still refused with the ambiguous-target conflict.
		for (const [operation, input] of NON_CREATE_REQUESTS) {
			await expect(
				broker.handleRequest(operation, input(root), `fresh-${operation}-after-upgrade`),
			).resolves.toEqual(AMBIGUOUS_TARGET_CONFLICT);
		}
		expect(handle.launchAttempts()).toBe(0);

		// In the same ledger state, a fresh create is admitted and launches.
		await expect(
			broker.handleRequest("session.create", { cwd: root }, "fresh-create-after-upgrade"),
		).resolves.toMatchObject({ ok: false, error: { code: "spawn_failed" } });
		expect(handle.launchAttempts()).toBe(1);
	} finally {
		setLifecycleCommandResolverForTest(broker, undefined);
		await broker.stop();
		await fs.rm(root, { recursive: true, force: true });
	}
});

it("exact_key_reuse_still_conflicts", async () => {
	const { root, agentDir } = await makeAgentDir("gjc-fence-exact-key-");
	const ledger = await new LifecycleLedger(agentDir).open();

	// Two finished old creates. One was recorded under its caller key alone,
	// the other under its caller key plus the create target. A later create
	// with either key and a different request gets the key-reuse conflict and
	// does not launch.
	const reusedKey = "reused-terminal-create-key";
	const reusedIdentity = await deriveLegacyIdentity(agentDir, "session.create", reusedKey);
	await seedTerminalLegacyRow(ledger, reusedIdentity, "terminal_error");

	const reusedTargetKey = "reused-target-bound-create-key";
	const normalized = normalizeBrokerInput("session.create", { cwd: root });
	if (!("input" in normalized)) throw new Error("Expected valid create input");
	const targetHash = createHash("sha256")
		.update(JSON.stringify(lifecycleTargetForTest("session.create", normalized.input)))
		.digest("hex");
	const reusedTargetIdentity = await deriveLegacyTargetIdentity(
		agentDir,
		"session.create",
		reusedTargetKey,
		targetHash,
	);
	await seedTerminalLegacyRow(ledger, reusedTargetIdentity, "terminal_ok");

	const handle = await startBrokerWithCountingResolver(agentDir, root);
	const broker = handle.broker;
	try {
		await expect(broker.handleRequest("session.create", { cwd: root }, reusedKey)).resolves.toEqual(
			REUSED_KEY_CONFLICT,
		);
		await expect(broker.handleRequest("session.create", { cwd: root }, reusedTargetKey)).resolves.toEqual(
			REUSED_KEY_CONFLICT,
		);
		expect(handle.launchAttempts()).toBe(0);
	} finally {
		setLifecycleCommandResolverForTest(broker, undefined);
		await broker.stop();
		await fs.rm(root, { recursive: true, force: true });
	}
});
