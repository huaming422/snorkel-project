#!/usr/bin/env bash
# test-setup.sh: environment bootstrap for the verifier.
#
# Sourced (not exec'd) by tests/test.sh under `set -euo pipefail`, so exports
# here stay live for the verifier subprocess. The image runs offline and
# already baked the full dependency closure at the pinned commit:
#   - the Bun workspace node_modules (bun install --frozen-lockfile)
#   - the compiled pi-natives napi addon at packages/natives/native/
#     (pi_natives.linux-<arch>.node, loaded in workspace-dev mode)
# So this script does NOT lazily install the project. It only brings the baked
# closure online offline-first, with a logged online fallback for a stale bake.
#
# The focused suite is a Bun test that loads the native addon; there is no Rust
# recompile and there are no background services to start or data to seed.

cd /repo/gajae-code

# Never write back to the lockfile and keep the online cache warm against the
# one the image bake populated, so the stale-bake fallback below is fast.
export BUN_CONFIG_NO_SAVE=1
export BUN_INSTALL_CACHE_DIR=/opt/cache/bun

# Dependencies: the image already baked the full workspace closure at the
# pinned commit (node_modules/, gitignored so the checkout reset never disturbs
# it), so `bun test` reuses it without any install. We do NOT
# re-run the install here: bun's offline resolver cannot re-derive the
# workspace `catalog:` protocol from the per-user cache and aborts
# ("<pkg>@catalog: is not in the catalog") before any verifier runs, even
# though the bake's online frozen install succeeded. The only reason to touch
# the registry is a stale image whose closure is missing; cover that
# with a single logged online fallback.
if [ -d node_modules ] && [ -n "$(ls -A node_modules 2>/dev/null)" ]; then
    echo "[test-setup] using baked workspace closure (no install needed)"
elif bun install --frozen-lockfile --ignore-scripts > /tmp/test-setup-install.log 2>&1; then
    echo "[test-setup] deps installed online (image bake was missing)"
else
    tail -40 /tmp/test-setup-install.log >&2; exit 1
fi

# The native addon is baked at build time (workspace-dev load path). If it is
# somehow absent, rebuild it from the baked Rust toolchain + cargo cache; this
# needs no network. A missing addon is a corrupt image, so bail loudly if the
# rebuild also fails.
if ! ls packages/natives/native/pi_natives.linux-*.node >/dev/null 2>&1; then
    echo "[test-setup] native addon missing from image, rebuilding offline" >&2
    variant_env=""
    if [ "$(dpkg --print-architecture)" = "amd64" ]; then variant_env="TARGET_VARIANT=baseline"; fi
    if ! env ${variant_env} CARGO_NET_OFFLINE=true bun --cwd=packages/natives run build \
            > /tmp/test-setup-native.log 2>&1; then
        tail -60 /tmp/test-setup-native.log >&2; exit 1
    fi
fi

echo "[test-setup] ready. bun=$(bun --version 2>/dev/null || echo unknown) addon=$(ls packages/natives/native/pi_natives.linux-*.node 2>/dev/null | head -1)"
