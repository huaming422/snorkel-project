## Task

Since we upgraded the coding agent from 0.17.2, the coordinator's MCP integration can't start sessions.
Every `gjc_coordinator_start_session` call fails, even for a brand-new session with a key we've never used.
The coordinator only gives a vague cleanup error, but the broker itself turns down the session create with this:

```
idempotency_conflict: legacy lifecycle request has an ambiguous target
```

Going back to the previous version fixes it, and so does a clean install with no history, so it seems to come from records the old version left behind.
On the machines we looked at, those old records are all for session starts and other calls that finished weeks ago.

New session starts need to go through again on upgraded machines.
That conflict exists so nothing gets started twice while an older request might still be running, or when nobody knows how it ended, so in that case a new start should still be refused.
A few machines were upgraded while the old version was partway through a session start.
When the caller retries that same start with the same key and folder, it should get this back every time, and nothing should launch:

```
terminal_uncertain: prior lifecycle operation outcome is uncertain
```

Once a stuck start has been retried like that, it stops holding up new starts, but any other stuck start still blocks them.
Other session calls such as resume, fork, close and delete should keep getting the same conflict while old records are around, as they do now.
When the old records do show that a key was already used for a different start, a start with that key should keep failing with `idempotency key was used with a different request`.
