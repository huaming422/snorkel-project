## Task

Codex CLI users going through the proxy keep getting `exceeded retry limit, last status: 429` once traffic picks up.
Upstream, an account answers for a moment with a 429 whose body is only "Rate limit exceeded", and a few seconds later the same account works fine again.
The proxy doesn't ride that out.
Its next request goes straight back to the account that just rejected, and the user sees the failure.
Multi-turn conversations, which can't move off the account that served their earlier turns, are hit worst and fail almost right away.
Restarting the proxy only helps until the next busy stretch.

Please make the proxy absorb these short bursts:

- A request that can only run on one account should wait and try that account again, and go through if the burst clears.
- Keep that bounded: no more than 5 retries, no single wait longer than 10 seconds, and never a wait shorter than the Retry-After the upstream sent.
- If that account is still rejecting once those retries are used up, the client should get the 429 back with the upstream error body and a Retry-After header (the upstream value when there was one).
- While an account is in one of these bursts, new conversations should start on another account if one is free.
  Once the burst is over, which takes seconds rather than minutes, the account should take new conversations again.
- A burst like this shouldn't get the account marked as rate-limited.
