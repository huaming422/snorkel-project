## Task

Codex CLI users going through the proxy keep getting `exceeded retry limit, last status: 429` once traffic picks up.
Upstream, an account answers for a moment with a 429 whose body is only "Rate limit exceeded", and a few seconds later the same account works fine again.
The proxy doesn't ride that out.
Its next request goes straight back to the account that just rejected, and the user sees the failure.
Multi-turn conversations, which can't move off the account that served their earlier turns, are hit worst and fail almost right away.
Restarting the proxy only helps until the next busy stretch.

Please make the proxy absorb these short bursts:

- Some requests can only run on one account.
  That covers a turn that replays reasoning items from that account, names an earlier response with `previous_response_id`, or sends back the `x-codex-turn-state` header.
  It also covers a request that refers to a file uploaded through that account, and any request while routing is set to a single account.
  When one of these gets a burst 429, the proxy should wait and try the same account again, and the request should go through if the burst clears.
- Keep that bounded: no more than 5 retries and no single wait longer than 10 seconds.
  No wait should be shorter than the Retry-After the upstream sent, unless it asks for more than 10 seconds.
  In that case the 10-second cap wins, and each wait is 10 seconds.
- If that account is still rejecting once those retries are used up, the client should get the 429 back with the upstream error body and a Retry-After header (the upstream value when there was one).
- A request that could run on any account isn't held for retries.
  It should move to another account, and when there is no other account, as in a pool with only one, the client gets the 429 back right away.
- While an account is in one of these bursts, new conversations should start on another account if one is free.
  Once the burst is over, which takes seconds rather than minutes, the account should take new conversations again.
- A burst like this shouldn't get the account marked as rate-limited.
- 429s that carry a `usage_limit_reached` or `rate_limit_exceeded` error code should keep working as they do today: the request moves to another account and that account is marked rate-limited.
