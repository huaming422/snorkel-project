#!/bin/bash
# Setup for the codex-lb-fix-burst-429-backoff checks.
#
# The image already bakes the full dependency closure at the base commit
# into /opt/venv (UV_PROJECT_ENVIRONMENT), so `uv sync` is offline-first
# and normally a no-op. The working tree may have changed pyproject.toml,
# so the sync below runs again before the checks.
#
# SQLite is the default test database (async aiosqlite); no PostgreSQL or
# Redis service is needed.

set -euo pipefail

REPO_DIR="/repo/codex-lb"

cd "$REPO_DIR"

# Refresh the dev dependency group. The full closure is baked into /opt/venv
# at the base commit with a warm uv store, so --frozen resolves from the local
# store without a network round-trip in the common case.
# tests/conftest.py sets every CODEX_LB_* test env var it needs at import time
# (SQLite DB URL, disabled schedulers, upstream base URL), so no extra runtime
# configuration is required here.
# Single offline sync of the third-party dependency closure only.
#
# The full closure (dev group included) is baked into the image's uv store at the
# base commit, and the application package is already importable from the mounted
# source. Three flags keep this hermetic on the egress-controlled test sandbox:
#   --offline  : resolve every package from the local cache, never open a socket.
#                A plain sync on the sandbox attempts a pypi index fetch and the
#                sandbox RESETS that connection (Connection reset by peer) rather
#                than falling back to cache, aborting setup before any check
#                runs. --offline keeps uv on the cache it already has.
#   --no-install-project : do not rebuild/reinstall the local `codex-lb` wheel.
#                A changed source tree would otherwise trigger a wheel rebuild
#                that needs the build backend (hatchling) at install time, which
#                the runtime cache does not carry. The checks need the
#                dependencies; the app itself is imported from the source tree.
#   --frozen   : pin to the committed lock.
# One sync command keeps a single dependency-resolving invocation for this
# ecosystem.
uv sync --frozen --offline --no-install-project --group dev --quiet 2>&1 | tail -5

export REPO_NAME=codex-lb
export PYTHONUNBUFFERED=1
