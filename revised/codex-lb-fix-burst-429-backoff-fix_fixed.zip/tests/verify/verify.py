"""Behavioral checks for short upstream 429 bursts on the Codex responses route.

Every case drives the real FastAPI application through
``POST /backend-api/codex/responses`` (the route the Codex CLI uses) and asserts
on what a client or operator can observe: the streamed events, the final HTTP
status, headers and body, which upstream account each attempt went to, the
account status read back from the database, and the waits taken between
attempts, recorded at the scheduler the proxy code uses for its timed waits.

Upstream is simulated by replacing ``proxy_module.core_stream_responses`` with a
fake async generator, the same seam the repository's own integration suite
uses. The fixtures (``async_client`` and the per-test database reset) come from
the repository's test support module, loaded as a plugin in ``conftest.py``.

Cases:
  * a conversation pinned to one account (reasoning replay, previous_response_id
    or turn-state) gets one "Rate limit exceeded" 429, then succeeds on the
    same account after a wait, and the account stays ACTIVE
  * the same 429 on every attempt ends in an HTTP 429 with the upstream body
    and a Retry-After header, after a bounded number of same-account retries,
    also when the waits take real time
  * waits stay within 10 seconds each, at most 5 of them, and never shorter
    than an upstream Retry-After (3 or 6 seconds)
  * new conversations avoid accounts that just answered with that 429, the
    accounts stay ACTIVE, and they take new conversations again two minutes on
  * a 429 carrying usage_limit_reached or rate_limit_exceeded still moves the
    request to another account and marks the first one RATE_LIMITED
  * ``failover_decision`` called with its three original arguments returns
    the same results as before
"""

from __future__ import annotations

import asyncio
import base64
import json

import pytest

import app.modules.proxy.service as proxy_module
from app.core.auth import generate_unique_account_id
from app.core.clients.proxy import ProxyResponseError
from app.core.clock import RealClock, RealScheduler
from app.core.errors import openai_error
from app.db.models import Account, AccountStatus
from app.db.session import SessionLocal

pytestmark = pytest.mark.asyncio


# ---------------------------------------------------------------------------
# Account import + payload/SSE helpers (ported from the repository's own
# integration suite so the checks drive the real import + stream path).
# ---------------------------------------------------------------------------


def _encode_jwt(payload: dict) -> str:
    raw = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    body = base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")
    return f"header.{body}.sig"


def _make_auth_json(account_id: str, email: str) -> dict:
    payload = {
        "email": email,
        "chatgpt_account_id": account_id,
        "https://api.openai.com/auth": {"chatgpt_plan_type": "plus"},
    }
    return {
        "tokens": {
            "idToken": _encode_jwt(payload),
            "accessToken": "access-token",
            "refreshToken": "refresh-token",
            "accountId": account_id,
        },
    }


async def _import_account(async_client, account_id: str, email: str) -> str:
    auth_json = _make_auth_json(account_id, email)
    files = {"auth_json": ("auth.json", json.dumps(auth_json), "application/json")}
    response = await async_client.post("/api/accounts/import", files=files)
    assert response.status_code == 200, response.text
    return generate_unique_account_id(account_id, email)


async def _force_usage_weighted_routing(async_client) -> None:
    current = await async_client.get("/api/settings")
    assert current.status_code == 200
    payload = current.json()
    payload["routingStrategy"] = "usage_weighted"
    response = await async_client.put("/api/settings", json=payload)
    assert response.status_code == 200


async def _account_status(account_db_id: str) -> AccountStatus:
    async with SessionLocal() as session:
        account = await session.get(Account, account_db_id)
        assert account is not None
        return account.status


def _sse_event(payload: dict) -> str:
    return f"data: {json.dumps(payload)}\n\n"


def _success_sse_event(response_id: str = "resp_ok") -> str:
    return _sse_event(
        {
            "type": "response.completed",
            "response": {
                "id": response_id,
                "usage": {"input_tokens": 1, "output_tokens": 1},
            },
        }
    )


def _extract_events(lines: list[str]) -> list[dict]:
    events: list[dict] = []
    for line in lines:
        if line.startswith("data: "):
            data = line[6:]
            if data == "[DONE]":
                continue
            events.append(json.loads(data))
    return events


def _record_waits(monkeypatch) -> list[float]:
    """Record every timed wait taken through the proxy's scheduler.

    Proxy request handling takes its timed waits through ``RealScheduler.sleep``
    (the repository's timing-seam check keeps raw ``asyncio.sleep`` out of
    those modules), so patching that method sees each wait. Patching the
    process-wide ``asyncio.sleep`` instead would also catch the lifespan
    event-loop-lag monitor's own one-second loop. The replacement still yields
    once so the awaiting coroutine keeps turning, but returns at once.
    """
    slept: list[float] = []
    real_sleep = asyncio.sleep

    def fake_sleep(self, delay, result=None):
        if delay and delay > 0:
            slept.append(float(delay))
        return real_sleep(0, result)

    monkeypatch.setattr(RealScheduler, "sleep", fake_sleep)
    return slept


def _burst_429(retry_after: int | None = None) -> ProxyResponseError:
    if retry_after is None:
        return ProxyResponseError(429, dict(_BURST_429_BODY), failure_phase="status")
    return ProxyResponseError(
        429,
        dict(_BURST_429_BODY),
        failure_phase="status",
        retry_after_seconds=retry_after,
        retry_after_header=str(retry_after),
    )


_NATIVE_CODEX_HEADERS = {"originator": "codex_cli_rs"}
_BURST_429_BODY = {"error": {"message": "Rate limit exceeded"}}
_PIN_KINDS = ["reasoning_replay", "previous_response", "turn_state"]


def _plain_payload(prompt_cache_key: str | None = None) -> dict:
    # No account-bound input: the request may go to any account. A
    # ``prompt_cache_key`` names a sticky session; a new key is a new session
    # whose account the proxy picks.
    payload: dict = {"model": "gpt-5.1", "instructions": "hi", "input": [], "stream": True}
    if prompt_cache_key is not None:
        payload["prompt_cache_key"] = prompt_cache_key
    return payload


class _Upstream:
    """Fake upstream. Set-up turns complete normally; case turns follow ``script``.

    ``script(n)`` gets the 1-based attempt number of the case turn and returns
    the exception to raise for it, or ``None`` to complete normally.
    """

    def __init__(self, script):
        self.script = script
        self.setting_up = False
        self.setup_calls: list[str | None] = []
        self.calls: list[str | None] = []

    async def stream(self, payload, headers, access_token, account_id, base_url=None, raise_for_status=False):
        if self.setting_up:
            self.setup_calls.append(account_id)
            yield _success_sse_event(f"resp_setup_{len(self.setup_calls)}")
            return
        self.calls.append(account_id)
        exc = self.script(len(self.calls))
        if exc is not None:
            raise exc
        yield _success_sse_event("resp_after_burst")


async def _pinned_request(async_client, monkeypatch, upstream: _Upstream, kind: str, tag: str):
    """Set up a conversation that can only run on one account.

    Two healthy accounts exist, so a request that wrongly moved would have
    somewhere to go. Returns (owner upstream id, owner db id, payload, headers).
    """
    owner_upstream_id = f"acc_pin_{tag}_a"
    owner_db_id = await _import_account(async_client, owner_upstream_id, f"pin_{tag}_a@example.com")
    other_db_id = await _import_account(async_client, f"acc_pin_{tag}_b", f"pin_{tag}_b@example.com")
    await _force_usage_weighted_routing(async_client)
    monkeypatch.setattr(proxy_module, "core_stream_responses", upstream.stream)
    headers = dict(_NATIVE_CODEX_HEADERS)

    if kind == "reasoning_replay":
        # A replayed reasoning item belongs to the account that produced it.
        payload = _plain_payload()
        payload["input"] = [{"type": "reasoning", "id": f"rs_{tag}", "encrypted_content": "owner-bound"}]
        return owner_upstream_id, owner_db_id, payload, headers

    if kind == "previous_response":
        # A real first turn; the follow-up names its response id.
        upstream.setting_up = True
        async with async_client.stream(
            "POST", "/backend-api/codex/responses", json=_plain_payload(), headers=headers
        ) as resp:
            assert resp.status_code == 200
            [line async for line in resp.aiter_lines() if line]
        upstream.setting_up = False
        assert len(upstream.setup_calls) == 1, upstream.setup_calls
        owner_upstream_id = upstream.setup_calls[0]
        owner_db_id = owner_db_id if owner_upstream_id == f"acc_pin_{tag}_a" else other_db_id
        payload = _plain_payload()
        payload["previous_response_id"] = "resp_setup_1"
        return owner_upstream_id, owner_db_id, payload, headers

    assert kind == "turn_state"

    # The turn-state owner lookup is answered the way the repository's own
    # integration tests answer it, so the follow-up is tied to account A.
    async def turn_state_owner(self, *, turn_state, api_key, fail_on_missing):
        del self, turn_state, api_key, fail_on_missing
        return owner_db_id

    monkeypatch.setattr(proxy_module.ProxyService, "_resolve_compact_turn_state_owner", turn_state_owner)
    headers["x-codex-turn-state"] = f"turn-state-{tag}"
    return owner_upstream_id, owner_db_id, _plain_payload(), headers


# ===========================================================================
# A pinned conversation gets one burst 429, then succeeds on the same account.
# ===========================================================================


@pytest.mark.parametrize("kind", _PIN_KINDS)
async def test_pinned_burst_429_retries_same_account_then_succeeds(async_client, monkeypatch, kind):
    slept = _record_waits(monkeypatch)
    upstream = _Upstream(lambda n: _burst_429() if n == 1 else None)
    owner, owner_db_id, payload, headers = await _pinned_request(
        async_client, monkeypatch, upstream, kind, f"ok_{kind}"
    )

    async with async_client.stream("POST", "/backend-api/codex/responses", json=payload, headers=headers) as resp:
        assert resp.status_code == 200
        lines = [line async for line in resp.aiter_lines() if line]

    events = _extract_events(lines)
    completed = [e for e in events if e.get("type") == "response.completed"]
    failed = [e for e in events if e.get("type") == "response.failed"]
    assert len(completed) == 1, f"expected a success stream, got events={events}"
    assert not failed, f"request must not surface a failure, got events={events}"

    assert upstream.calls == [owner, owner], upstream.calls
    assert slept, "expected a wait before trying the same account again"
    assert await _account_status(owner_db_id) == AccountStatus.ACTIVE


# ===========================================================================
# The same 429 on every attempt: bounded same-account retries, then a real
# HTTP 429 with the upstream body and a Retry-After header.
# ===========================================================================


@pytest.mark.parametrize("kind", _PIN_KINDS)
async def test_pinned_burst_429_exhaustion_surfaces_http_429_with_retry_after(async_client, monkeypatch, kind):
    slept = _record_waits(monkeypatch)
    upstream = _Upstream(lambda n: _burst_429())
    owner, owner_db_id, payload, headers = await _pinned_request(
        async_client, monkeypatch, upstream, kind, f"ex_{kind}"
    )

    async with async_client.stream("POST", "/backend-api/codex/responses", json=payload, headers=headers) as resp:
        body = json.loads(await resp.aread())
        assert resp.status_code == 429, f"an exhausted burst must surface a real 429, got {resp.status_code}"
        assert "Retry-After" in resp.headers, dict(resp.headers)
        retry_after = int(resp.headers["Retry-After"])
        assert retry_after >= 1, retry_after

    assert body == _BURST_429_BODY, body

    assert len(upstream.calls) >= 2, "expected at least one retry before the 429 is returned"
    assert set(upstream.calls) == {owner}, f"a pinned request must stay on its account: {upstream.calls}"
    assert len(upstream.calls) <= 6, f"the first try plus at most 5 retries: {upstream.calls}"
    assert slept, "expected waits before the 429 is returned"
    assert len(slept) <= 5, f"at most 5 retries: {slept}"
    assert all(w <= 10.0 for w in slept), f"no single wait above 10 seconds: {slept}"
    assert await _account_status(owner_db_id) == AccountStatus.ACTIVE


async def test_pinned_burst_429_exhaustion_after_real_waits_is_still_http_429(async_client, monkeypatch):
    # Same as above, but the waits really elapse (a few seconds in total), as
    # they do for a user. The client must still get the HTTP 429 status and
    # header, not a 200 stream that only reports the failure inside it.
    upstream = _Upstream(lambda n: _burst_429())
    owner, _, payload, headers = await _pinned_request(
        async_client, monkeypatch, upstream, "reasoning_replay", "realtime"
    )

    async with async_client.stream("POST", "/backend-api/codex/responses", json=payload, headers=headers) as resp:
        raw = await resp.aread()
        assert resp.status_code == 429, f"expected an HTTP 429 after real waits, got {resp.status_code}: {raw[:200]!r}"
        assert int(resp.headers.get("Retry-After", "0")) >= 1, dict(resp.headers)

    assert json.loads(raw) == _BURST_429_BODY, raw
    assert len(upstream.calls) >= 2, "expected at least one retry before the 429 is returned"
    assert set(upstream.calls) == {owner}, upstream.calls


# ===========================================================================
# Waits: bounded with no upstream Retry-After, never shorter than one.
# ===========================================================================


async def test_pinned_burst_429_waits_are_bounded(async_client, monkeypatch):
    slept = _record_waits(monkeypatch)
    upstream = _Upstream(lambda n: _burst_429())
    _, _, payload, headers = await _pinned_request(
        async_client, monkeypatch, upstream, "reasoning_replay", "bounded"
    )

    async with async_client.stream("POST", "/backend-api/codex/responses", json=payload, headers=headers) as resp:
        await resp.aread()
        assert resp.status_code == 429

    assert len(upstream.calls) <= 6, f"the first try plus at most 5 retries: {upstream.calls}"
    assert slept, "expected waits before the 429 is returned"
    assert len(slept) <= 5, f"at most 5 retries: {slept}"
    assert all(0 < w <= 10.0 for w in slept), f"each wait within 10 seconds: {slept}"


@pytest.mark.parametrize("retry_after", [3, 6])
async def test_pinned_burst_429_never_retries_before_upstream_retry_after(async_client, monkeypatch, retry_after):
    slept = _record_waits(monkeypatch)
    upstream = _Upstream(lambda n: _burst_429(retry_after))
    _, _, payload, headers = await _pinned_request(
        async_client, monkeypatch, upstream, "previous_response", f"floor_{retry_after}"
    )

    async with async_client.stream("POST", "/backend-api/codex/responses", json=payload, headers=headers) as resp:
        await resp.aread()
        assert resp.status_code == 429
        assert resp.headers.get("Retry-After") == str(retry_after), dict(resp.headers)

    assert len(upstream.calls) <= 6, f"the first try plus at most 5 retries: {upstream.calls}"
    assert slept, "expected waits before the 429 is returned"
    assert len(slept) <= 5, f"at most 5 retries: {slept}"
    assert all(w >= retry_after for w in slept), f"each wait at least Retry-After={retry_after}: {slept}"
    assert all(w <= 10.0 for w in slept), f"no single wait above 10 seconds: {slept}"


# ===========================================================================
# New conversations avoid accounts that just answered with a burst 429, and
# take them again once the burst has passed.
# ===========================================================================


async def test_burst_429_steers_new_sessions_away_until_it_passes(async_client, monkeypatch):
    names = ["acc_steer_a", "acc_steer_b", "acc_steer_c"]
    db_ids = {
        name: await _import_account(async_client, name, f"{name}@example.com") for name in names
    }
    await _force_usage_weighted_routing(async_client)

    seen: list[str | None] = []
    rejected: list[str | None] = []

    async def fake_stream(payload, headers, access_token, account_id, base_url=None, raise_for_status=False):
        seen.append(account_id)
        # The first two distinct accounts the proxy tries each answer once with
        # the burst 429; everything after that succeeds.
        if len(rejected) < 2 and account_id not in rejected:
            rejected.append(account_id)
            raise _burst_429()
        yield _success_sse_event("resp_steer_ok")

    monkeypatch.setattr(proxy_module, "core_stream_responses", fake_stream)

    async def new_session(key: str | None) -> str | None:
        start = len(seen)
        async with async_client.stream(
            "POST", "/backend-api/codex/responses", json=_plain_payload(key)
        ) as resp:
            assert resp.status_code == 200
            lines = [line async for line in resp.aiter_lines() if line]
        events = _extract_events(lines)
        assert any(e.get("type") == "response.completed" for e in events), events
        return seen[start]

    # First session: two accounts reject in turn, the third serves it.
    await new_session("steer-session-one")
    assert len(rejected) == 2, f"expected two rejecting accounts: {seen}"
    healthy = next(name for name in names if name not in rejected)

    # Right after the bursts, a new session starts on the account that is not
    # in one, not on either account that just rejected.
    second = await new_session("steer-session-two")
    assert second == healthy, (
        f"a new session must avoid accounts that just answered with a burst 429 {rejected}, "
        f"but started on {second}: {seen}"
    )

    # A request with no session key at all is placed the same way.
    unkeyed = await new_session(None)
    assert unkeyed == healthy, (
        f"a request with no session key must avoid accounts that just answered with a burst 429 "
        f"{rejected}, but went to {unkeyed}: {seen}"
    )

    for name in rejected:
        assert await _account_status(db_ids[name]) == AccountStatus.ACTIVE

    # Two minutes later the burst is long over: the next new session starts on
    # one of the accounts that rejected before, as it would with no burst.
    real_time, real_monotonic = RealClock.time, RealClock.monotonic
    monkeypatch.setattr(RealClock, "time", lambda self: real_time(self) + 120.0)
    monkeypatch.setattr(RealClock, "monotonic", lambda self: real_monotonic(self) + 120.0)
    third = await new_session("steer-session-three")
    assert third in rejected, (
        f"once the burst has passed, the accounts that rejected must take new sessions again, "
        f"but the session started on {third}: {seen}"
    )


# ===========================================================================
# A 429 with a usage or rate-limit code still moves to another account and
# marks the first one RATE_LIMITED.
# ===========================================================================


@pytest.mark.parametrize(
    ("code", "message"),
    [
        ("usage_limit_reached", "usage limit reached"),
        ("rate_limit_exceeded", "Rate limit reached for requests"),
    ],
)
async def test_coded_429_still_fails_over_and_persists_rate_limited(async_client, monkeypatch, code, message):
    tag = code.replace("_", "")[:10]
    account_a_id = await _import_account(async_client, f"acc_coded_{tag}_a", f"coded_{tag}_a@example.com")
    await _import_account(async_client, f"acc_coded_{tag}_b", f"coded_{tag}_b@example.com")
    await _force_usage_weighted_routing(async_client)

    seen_account_ids: list[str | None] = []

    async def fake_stream(payload, headers, access_token, account_id, base_url=None, raise_for_status=False):
        seen_account_ids.append(account_id)
        if account_id == f"acc_coded_{tag}_a":
            raise ProxyResponseError(429, openai_error(code, message), failure_phase="status")
        yield _success_sse_event("resp_coded_ok")

    monkeypatch.setattr(proxy_module, "core_stream_responses", fake_stream)

    async with async_client.stream("POST", "/backend-api/codex/responses", json=_plain_payload()) as resp:
        assert resp.status_code == 200
        lines = [line async for line in resp.aiter_lines() if line]

    events = _extract_events(lines)
    assert len([e for e in events if e.get("type") == "response.completed"]) == 1, events
    assert seen_account_ids[:2] == [f"acc_coded_{tag}_a", f"acc_coded_{tag}_b"], seen_account_ids
    assert await _account_status(account_a_id) == AccountStatus.RATE_LIMITED


# ===========================================================================
# failover_decision with its three original arguments keeps its results (the
# repository's tests/unit/test_failover_foundation.py pins the same table).
# ===========================================================================


async def test_failover_decision_three_arg_truth_table_unchanged():
    from app.core.balancer.logic import failover_decision

    assert (
        failover_decision(failure_class="retryable_transient", downstream_visible=False, candidates_remaining=1)
        == "failover_next"
    )
    assert (
        failover_decision(failure_class="rate_limit", downstream_visible=False, candidates_remaining=2)
        == "failover_next"
    )
    assert (
        failover_decision(failure_class="quota", downstream_visible=False, candidates_remaining=2)
        == "failover_next"
    )
    assert (
        failover_decision(failure_class="retryable_transient", downstream_visible=True, candidates_remaining=5)
        == "surface"
    )
    assert (
        failover_decision(failure_class="retryable_transient", downstream_visible=False, candidates_remaining=0)
        == "surface"
    )
    assert (
        failover_decision(failure_class="non_retryable", downstream_visible=False, candidates_remaining=3)
        == "surface"
    )
