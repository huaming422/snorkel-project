"""Verifier conftest — bridges the repository's own pytest fixtures.

The verifier drives the real FastAPI application through its HTTP endpoint,
exactly as the repository's own integration suite does. That requires the
repository's test fixtures: the in-process ASGI client, the per-test database
reset, and the ~dozen autouse fixtures that neutralise schedulers / leader
election so the app lifespan is safe to run under test.

Rather than re-implement that heavyweight setup (which would drift from the
repository's real wiring), this conftest loads the repository's own test
support module as a pytest plugin, so every fixture the integration suite
relies on becomes available here unchanged. This file is the rootdir conftest
for the verifier run (the verifier file is collected in isolation, outside the
repository tree), so declaring ``pytest_plugins`` here is permitted.

The repository root is taken from ``REPO_NAME`` (exported by test-setup.sh),
defaulting to the conventional mount point. It is the project root, not any
implementation-specific file — the application package and the test support
module both live under it.
"""

from __future__ import annotations

import os
import sys

_REPO_NAME = os.environ.get("REPO_NAME", "codex-lb")
_REPO_ROOT = os.environ.get("REPO_DIR", f"/repo/{_REPO_NAME}")

# ``uv run pytest`` launches the console script rather than ``python -m pytest``,
# so the working directory is not placed on ``sys.path`` automatically. Put the
# project root first so ``app`` and the repository's ``tests`` support package
# both import before the plugin below is loaded.
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

# Load the repository's own test fixtures (in-process ``async_client``, the
# database reset, and the autouse scheduler/leader-election neutralisers).
pytest_plugins = ["tests.conftest"]
