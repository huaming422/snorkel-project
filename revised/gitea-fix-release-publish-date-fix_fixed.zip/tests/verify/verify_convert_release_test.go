// Copyright 2026 The Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

package convert

import (
	"encoding/json"
	"testing"

	repo_model "gitea.dev/models/repo"
	"gitea.dev/models/unittest"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// publishedAtRaw serializes a release through ToAPIRelease and returns the raw
// JSON of its `published_at` field as an API client reads it. An explicit null
// and a missing key both mean "no publication date", so a missing key is
// returned as "null".
func publishedAtRaw(t *testing.T, repo *repo_model.Repository, rel *repo_model.Release) string {
	t.Helper()
	api := ToAPIRelease(t.Context(), repo, rel)
	require.NotNil(t, api)
	blob, err := json.Marshal(api)
	require.NoError(t, err)
	var fields map[string]json.RawMessage
	require.NoError(t, json.Unmarshal(blob, &fields))
	raw, ok := fields["published_at"]
	if !ok {
		return "null"
	}
	return string(raw)
}

// A draft release reports no publication date in the API, while it still
// reports a creation date. Fixture release 4 is a draft in repo 1.
func TestVerify_PublishedAtNullableForDrafts(t *testing.T) {
	require.NoError(t, unittest.PrepareTestDatabase())

	repo1 := unittest.AssertExistsAndLoadBean(t, &repo_model.Repository{ID: 1})
	rel := unittest.AssertExistsAndLoadBean(t, &repo_model.Release{ID: 4})
	require.NoError(t, rel.LoadAttributes(t.Context()))
	require.True(t, rel.IsDraft, "fixture precondition: release 4 is a draft")

	// published_at is null or left out of the payload.
	draft := publishedAtRaw(t, repo1, rel)
	assert.Equal(t, "null", draft,
		"an unpublished release has no publication date")

	createdAt := func() string {
		blob, err := json.Marshal(ToAPIRelease(t.Context(), repo1, rel))
		require.NoError(t, err)
		var fields map[string]json.RawMessage
		require.NoError(t, json.Unmarshal(blob, &fields))
		return string(fields["created_at"])
	}()
	assert.NotEqual(t, "null", createdAt,
		"the draft still carries a creation date, so absence is specific to publication")
}
