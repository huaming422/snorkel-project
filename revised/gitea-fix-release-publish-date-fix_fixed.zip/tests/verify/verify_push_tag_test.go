// Copyright 2026 The Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

package repository

import (
	"testing"
	"time"

	"gitea.dev/models/db"
	repo_model "gitea.dev/models/repo"
	"gitea.dev/models/unittest"
	user_model "gitea.dev/models/user"
	"gitea.dev/modules/git"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// Tags pushed from the command line date their releases by the committer date
// of the commit each one points at. An annotated tag written now at an old
// fixture commit carries a tagger time of roughly now, so the two dates are
// years apart. A lightweight tag at a different commit is pushed in the same
// update, and so is a tag for a draft release that already exists. The tags go
// through PushUpdateAddDeleteTags, the entry point the push handler calls.
func TestVerify_PushedTagDatedByCommit(t *testing.T) {
	require.NoError(t, unittest.PrepareTestDatabase())

	pusher := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 2})
	repo := unittest.AssertExistsAndLoadBean(t, &repo_model.Repository{ID: 1})

	gitRepo, err := git.OpenRepository(t.Context(), repo)
	require.NoError(t, err)
	defer gitRepo.Close()

	// An old commit on the fixture repo; its committer date is the expected value.
	commit, err := gitRepo.GetBranchCommit(t.Context(), "master")
	require.NoError(t, err)
	commitWhen := commit.Committer.When.Unix()

	// The commit is at least two years old, so its date can never be taken for
	// the moment the tag is written below.
	require.Lessf(t, commitWhen, time.Now().Unix()-(2*365*24*3600),
		"fixture precondition: master points at a commit at least two years old (got %d)", commitWhen)

	otherCommit, err := gitRepo.GetBranchCommit(t.Context(), "DefaultBranch")
	require.NoError(t, err)
	// Either of the commit's own dates counts as "the commit's date".
	otherDates := []int64{otherCommit.Committer.When.Unix(), otherCommit.Author.When.Unix()}
	require.NotContains(t, otherDates, commitWhen, "fixture precondition: the two commits have different dates")

	// Write an annotated tag now at the old commit and a lightweight tag at the
	// other one, then push both.
	const annotatedTag = "v9.9-pushprobe"
	const lightweightTag = "v9.9-pushprobe-light"
	require.NoError(t, gitRepo.CreateAnnotatedTag(t.Context(), annotatedTag, "probe for pushed tag commit date", commit.ID.String()))
	require.NoError(t, gitRepo.CreateTag(t.Context(), lightweightTag, otherCommit.ID.String()))

	// A draft release whose tag does not exist yet; pushing the tag publishes it.
	const draftTag = "v9.9-pushdraft"
	require.NoError(t, db.Insert(t.Context(), &repo_model.Release{
		RepoID: repo.ID, PublisherID: pusher.ID, TagName: draftTag, LowerTagName: draftTag,
		Target: "master", Title: "pushed draft", IsDraft: true, CreatedUnix: 1,
	}))
	require.NoError(t, gitRepo.CreateAnnotatedTag(t.Context(), draftTag, "probe for a pushed draft tag", commit.ID.String()))

	require.NoError(t, PushUpdateAddDeleteTags(t.Context(), repo, gitRepo, pusher, []string{annotatedTag, lightweightTag, draftTag}, nil))

	rel, err := repo_model.GetRelease(t.Context(), repo.ID, annotatedTag)
	require.NoError(t, err)
	assert.Equal(t, commitWhen, int64(rel.CreatedUnix),
		"a pushed annotated tag's release is dated by the commit it points at, not by when the tag was written")

	rel, err = repo_model.GetRelease(t.Context(), repo.ID, lightweightTag)
	require.NoError(t, err)
	assert.Contains(t, otherDates, int64(rel.CreatedUnix),
		"a pushed lightweight tag's release is dated by the commit it points at")

	rel, err = repo_model.GetRelease(t.Context(), repo.ID, draftTag)
	require.NoError(t, err)
	assert.Equal(t, commitWhen, int64(rel.CreatedUnix),
		"an existing release whose tag is pushed is dated by the commit the tag points at")
}
