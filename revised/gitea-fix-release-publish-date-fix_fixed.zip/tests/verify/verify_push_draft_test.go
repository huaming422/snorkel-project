// Copyright 2026 The Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

package repository_test

import (
	"encoding/json"
	"testing"
	"time"

	repo_model "gitea.dev/models/repo"
	"gitea.dev/models/unittest"
	user_model "gitea.dev/models/user"
	"gitea.dev/modules/git"
	"gitea.dev/services/convert"
	release_service "gitea.dev/services/release"
	repo_service "gitea.dev/services/repository"

	_ "gitea.dev/models/actions"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// verifyPublishedAt returns the `published_at` value of a release as an API
// client reads it; null or a missing key comes back as nil.
func verifyPublishedAt(t *testing.T, repo *repo_model.Repository, id int64) *time.Time {
	t.Helper()
	rel, err := repo_model.GetReleaseByID(t.Context(), id)
	require.NoError(t, err)
	rel.Repo = repo
	require.NoError(t, rel.LoadAttributes(t.Context()))
	blob, err := json.Marshal(convert.ToAPIRelease(t.Context(), repo, rel))
	require.NoError(t, err)
	var fields struct {
		PublishedAt *time.Time `json:"published_at"`
	}
	require.NoError(t, json.Unmarshal(blob, &fields))
	return fields.PublishedAt
}

// When a push deletes the tag of a published release, the release turns into
// a draft and the API reports no publication date for it. The deletion goes
// through PushUpdateAddDeleteTags, the entry point the push handler calls.
func TestVerify_TagDeletionClearsPublication(t *testing.T) {
	require.NoError(t, unittest.PrepareTestDatabase())

	user := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 2})
	repo := unittest.AssertExistsAndLoadBean(t, &repo_model.Repository{ID: 1})

	gitRepo, err := git.OpenRepository(t.Context(), repo)
	require.NoError(t, err)
	defer gitRepo.Close()

	rel := &repo_model.Release{
		RepoID: repo.ID, Repo: repo, PublisherID: user.ID, Publisher: user,
		TagName: "v9.5-tag-deleted", Target: "master", Title: "v9.5 tag deleted",
	}
	require.NoError(t, release_service.CreateRelease(t.Context(), gitRepo, rel, nil, ""))
	require.NotNil(t, verifyPublishedAt(t, repo, rel.ID), "the published release has a publication date")

	require.NoError(t, repo_service.PushUpdateAddDeleteTags(t.Context(), repo, gitRepo, user, nil, []string{rel.TagName}))

	reloaded, err := repo_model.GetReleaseByID(t.Context(), rel.ID)
	require.NoError(t, err)
	require.True(t, reloaded.IsDraft, "a release whose tag was deleted becomes a draft")
	assert.Nil(t, verifyPublishedAt(t, repo, rel.ID),
		"a release turned into a draft by deleting its tag has no publication date")
}
