// Copyright 2026 The Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

package v28_test

import (
	"strconv"
	"testing"

	"gitea.dev/modelmigration"
	"gitea.dev/modelmigration/migrationtest"
	repo_model "gitea.dev/models/repo"

	"github.com/stretchr/testify/require"
)

// toInt64 reads one raw SQL cell, delivered as decimal ASCII bytes, as an
// integer. A NULL cell reads as zero, which means no publication time.
func toInt64(b []byte) int64 {
	if len(b) == 0 {
		return 0
	}
	n, err := strconv.ParseInt(string(b), 10, 64)
	if err != nil {
		return -1 // a non-integer cell never matches
	}
	return n
}

// After the upgrade, a published release has a publication time equal to its
// creation time and a draft has none. The release table is seeded in its
// shape from before the change, next to the repository table, and the
// migration sequence runs through the public Migrate entry point from the
// schema version the last existing step records (350).
//
// The publication time is found by value rather than by column name: exactly
// one column holds the published release's creation time while the draft's
// cell is zero or NULL. The creation column does not match, because its draft
// cell holds the draft's own creation time. The bare tag row is accepted at
// its creation time or at zero, since a bare tag is neither a published
// release nor a draft.
func TestVerify_MigrationBackfillsNonDrafts(t *testing.T) {
	type Release struct {
		ID               int64  `xorm:"pk autoincr"`
		RepoID           int64  `xorm:"INDEX UNIQUE(n)"`
		PublisherID      int64  `xorm:"INDEX"`
		TagName          string `xorm:"INDEX UNIQUE(n)"`
		OriginalAuthor   string
		OriginalAuthorID int64 `xorm:"index"`
		LowerTagName     string
		Target           string
		Title            string
		Sha1             string `xorm:"INDEX VARCHAR(64)"`
		NumCommits       int64
		Note             string `xorm:"TEXT"`
		IsDraft          bool   `xorm:"NOT NULL DEFAULT false"`
		IsPrerelease     bool   `xorm:"NOT NULL DEFAULT false"`
		IsTag            bool   `xorm:"NOT NULL DEFAULT false"`
		CreatedUnix      int64  `xorm:"INDEX"`
	}

	x, deferable := migrationtest.PrepareTestEnv(t, 0, new(Release), new(repo_model.Repository))
	defer deferable()
	if x == nil || t.Failed() {
		return
	}

	_, err := x.Insert(
		&Release{RepoID: 1, TagName: "v1.0", LowerTagName: "v1.0", Title: "v1.0", CreatedUnix: 1000000},
		&Release{RepoID: 1, TagName: "v1.1", LowerTagName: "v1.1", Title: "v1.1", IsDraft: true, CreatedUnix: 2000000},
		&Release{RepoID: 1, TagName: "v1.2", LowerTagName: "v1.2", IsTag: true, CreatedUnix: 3000000},
	)
	require.NoError(t, err)

	require.NoError(t, x.Sync(new(modelmigration.Version)))
	_, err = x.Insert(&modelmigration.Version{ID: 1, Version: 350})
	require.NoError(t, err)

	require.NoError(t, modelmigration.Migrate(t.Context(), x))

	rows, err := x.Query("SELECT * FROM `release` ORDER BY id")
	require.NoError(t, err)
	require.Len(t, rows, 3, "the three seeded rows survive the migration")

	matched := ""
	for col := range rows[0] {
		published := toInt64(rows[0][col])
		draft := toInt64(rows[1][col])
		tag := toInt64(rows[2][col])
		if published == 1000000 && draft == 0 && (tag == 3000000 || tag == 0) {
			matched = col
			break
		}
	}
	require.NotEmptyf(t, matched,
		"no column holds the publication time (the published release's creation "+
			"time, nothing for the draft); got rows %v", rows)
}
