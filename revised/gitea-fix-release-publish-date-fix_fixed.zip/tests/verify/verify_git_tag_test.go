// Copyright 2026 The Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

package repository

import (
	"testing"
	"time"

	"gitea.dev/models/db"
	repo_model "gitea.dev/models/repo"
	"gitea.dev/models/unittest"
	"gitea.dev/modules/git"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// Syncing tags into releases, as a pull mirror does, dates each release by
// the commit its tag points at, both for a new tag and for a known tag that now
// points at another commit. An annotated tag written now at an old fixture
// commit carries a tagger time of roughly now, so the two dates are years
// apart.
func TestVerify_TagCommitDateResolved(t *testing.T) {
	require.NoError(t, unittest.PrepareTestDatabase())

	repo := unittest.AssertExistsAndLoadBean(t, &repo_model.Repository{ID: 1})

	gitRepo, err := git.OpenRepository(t.Context(), repo)
	require.NoError(t, err)
	defer gitRepo.Close()

	// An old commit on the fixture repo; its committer date is the expected value.
	commit, err := gitRepo.GetBranchCommit(t.Context(), "master")
	require.NoError(t, err)
	commitWhen := commit.Committer.When.Unix()

	// The commit is at least two years old, so its date can never be taken for
	// the moment the tag is written below.
	require.Lessf(t, commitWhen, time.Now().Unix()-(2*365*24*3600),
		"fixture precondition: master points at a commit at least two years old (got %d)", commitWhen)

	// Write an annotated tag now at that old commit.
	const tagName = "v9.9-syncprobe"
	require.NoError(t, gitRepo.CreateAnnotatedTag(t.Context(), tagName, "probe for tag commit date", commit.ID.String()))

	_, err = SyncReleasesWithTags(t.Context(), repo, gitRepo)
	require.NoError(t, err)

	rel, err := repo_model.GetRelease(t.Context(), repo.ID, tagName)
	require.NoError(t, err)

	assert.Equal(t, commitWhen, int64(rel.CreatedUnix),
		"a synced tag's release is dated by the commit it points at, not by when the tag was written")

	// A tag already known from an earlier sync now points at another commit.
	otherCommit, err := gitRepo.GetBranchCommit(t.Context(), "DefaultBranch")
	require.NoError(t, err)
	// Either of the commit's own dates counts as "the commit's date".
	otherDates := []int64{otherCommit.Committer.When.Unix(), otherCommit.Author.When.Unix()}
	require.NotContains(t, otherDates, commitWhen, "fixture precondition: the two commits have different dates")

	const movedTag = "v9.9-syncmoved"
	require.NoError(t, db.Insert(t.Context(), &repo_model.Release{
		RepoID: repo.ID, TagName: movedTag, LowerTagName: movedTag,
		Sha1: commit.ID.String(), NumCommits: -1, IsTag: true, CreatedUnix: 1,
	}))
	require.NoError(t, gitRepo.CreateAnnotatedTag(t.Context(), movedTag, "probe for a moved tag", otherCommit.ID.String()))

	_, err = SyncReleasesWithTags(t.Context(), repo, gitRepo)
	require.NoError(t, err)

	moved, err := repo_model.GetRelease(t.Context(), repo.ID, movedTag)
	require.NoError(t, err)
	assert.Contains(t, otherDates, int64(moved.CreatedUnix),
		"a tag that moved to another commit is dated by its new commit after the sync")
}
