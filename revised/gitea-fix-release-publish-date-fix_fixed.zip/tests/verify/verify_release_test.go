// Copyright 2026 The Gitea Authors. All rights reserved.
// SPDX-License-Identifier: MIT

package release

import (
	"encoding/json"
	"testing"
	"time"

	repo_model "gitea.dev/models/repo"
	"gitea.dev/models/unittest"
	user_model "gitea.dev/models/user"
	"gitea.dev/modules/git"
	"gitea.dev/modules/timeutil"
	"gitea.dev/services/convert"

	_ "gitea.dev/models/actions"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// verifyAPIReleaseDates serializes a release through ToAPIRelease and returns
// its `created_at` and `published_at` values as an API client reads them. A
// `published_at` that is null or left out of the payload comes back as nil.
func verifyAPIReleaseDates(t *testing.T, repo *repo_model.Repository, rel *repo_model.Release) (time.Time, *time.Time) {
	t.Helper()
	require.NoError(t, rel.LoadAttributes(t.Context()))
	api := convert.ToAPIRelease(t.Context(), repo, rel)
	require.NotNil(t, api)
	blob, err := json.Marshal(api)
	require.NoError(t, err)
	var fields struct {
		CreatedAt   *time.Time `json:"created_at"`
		PublishedAt *time.Time `json:"published_at"`
	}
	require.NoError(t, json.Unmarshal(blob, &fields))
	require.NotNilf(t, fields.CreatedAt, "serialized release carries created_at; got %s", blob)
	return *fields.CreatedAt, fields.PublishedAt
}

// verifyReloadRelease reads a release back from the database.
func verifyReloadRelease(t *testing.T, repo *repo_model.Repository, id int64) *repo_model.Release {
	t.Helper()
	rel, err := repo_model.GetReleaseByID(t.Context(), id)
	require.NoError(t, err)
	rel.Repo = repo
	return rel
}

// verifyPublishedNow checks that a publication date is the moment of the
// action: either the mocked clock's value (when mocked is set) or a real-clock
// time between since and the moment of the check.
func verifyPublishedNow(t *testing.T, published *time.Time, mocked, since time.Time, msg string) {
	t.Helper()
	if !assert.NotNil(t, published, msg) {
		return
	}
	got := published.Unix()
	if !mocked.IsZero() && got == mocked.Unix() {
		return
	}
	assert.Truef(t, got >= since.Unix()-1 && got <= time.Now().Unix()+1,
		"%s: got %s, expected the moment of publication", msg, published.UTC().Format(time.RFC3339))
}

// A release created on an old commit reports that commit's committer date as
// `created_at` and the moment it was created as `published_at`. The
// publication date stays the same when the release is read again later.
func TestVerify_CreatedAtIsCommitDate(t *testing.T) {
	require.NoError(t, unittest.PrepareTestDatabase())

	user := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 2})
	repo := unittest.AssertExistsAndLoadBean(t, &repo_model.Repository{ID: 1})

	gitRepo, err := git.OpenRepository(t.Context(), repo)
	require.NoError(t, err)
	defer gitRepo.Close()

	commit, err := gitRepo.GetBranchCommit(t.Context(), "master")
	require.NoError(t, err)

	start := time.Now()
	rel := &repo_model.Release{
		RepoID: repo.ID, Repo: repo, PublisherID: user.ID, Publisher: user,
		TagName: "v9.9-dated", Target: "master", Title: "v9.9-dated",
	}
	require.NoError(t, CreateRelease(t.Context(), gitRepo, rel, nil, ""))

	createdAt, publishedAt := verifyAPIReleaseDates(t, repo, verifyReloadRelease(t, repo, rel.ID))
	assert.Equal(t, commit.Committer.When.Unix(), createdAt.Unix(),
		"created_at is the committer date of the commit the release points at")
	verifyPublishedNow(t, publishedAt, time.Time{}, start,
		"published_at is the moment the release was published")

	// Read it again after the clock has moved past the next second.
	time.Sleep(1100 * time.Millisecond)
	_, again := verifyAPIReleaseDates(t, repo, verifyReloadRelease(t, repo, rel.ID))
	if assert.NotNil(t, again, "a published release keeps its publication date") && publishedAt != nil {
		assert.Equal(t, publishedAt.Unix(), again.Unix(),
			"published_at stays at the moment of publication when read later")
	}
}

// A tag created in the web UI is dated by its commit. Publishing a release
// from that existing tag later reports the commit's date as `created_at` and
// the moment of publishing as `published_at`.
func TestVerify_PublishFromExistingTag(t *testing.T) {
	require.NoError(t, unittest.PrepareTestDatabase())

	user := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 2})
	repo := unittest.AssertExistsAndLoadBean(t, &repo_model.Repository{ID: 1})

	gitRepo, err := git.OpenRepository(t.Context(), repo)
	require.NoError(t, err)
	defer gitRepo.Close()

	commit, err := gitRepo.GetBranchCommit(t.Context(), "master")
	require.NoError(t, err)
	commitWhen := commit.Committer.When.Unix()

	fakeNow := time.Date(2025, 3, 1, 12, 0, 0, 0, time.UTC)
	defer timeutil.MockSet(fakeNow)()
	start := time.Now()

	const tagName = "v9.7-ui-tag"
	require.NoError(t, CreateNewTag(t.Context(), user, repo, "master", tagName, "tagged from the web UI"))

	tagRel, err := repo_model.GetRelease(t.Context(), repo.ID, tagName)
	require.NoError(t, err)
	require.True(t, tagRel.IsTag, "the web UI tag is stored as a tag")
	tagRel.Repo = repo
	tagCreatedAt, _ := verifyAPIReleaseDates(t, repo, tagRel)
	assert.Equal(t, commitWhen, tagCreatedAt.Unix(), "a tag made in the web UI is dated by its commit")

	// Two days later, a release is published from the existing tag.
	fakeNow = fakeNow.Add(48 * time.Hour)
	timeutil.MockSet(fakeNow)
	tagRel.Publisher = user
	tagRel.IsTag = false
	tagRel.Title = "v9.7 from an existing tag"
	tagRel.Note = "published from an existing tag"
	require.NoError(t, UpdateRelease(t.Context(), user, gitRepo, tagRel, nil, nil, nil))

	createdAt, publishedAt := verifyAPIReleaseDates(t, repo, verifyReloadRelease(t, repo, tagRel.ID))
	assert.Equal(t, commitWhen, createdAt.Unix(),
		"a release published from an existing tag is dated by the tag's commit")
	verifyPublishedNow(t, publishedAt, fakeNow, start,
		"a release published from an existing tag reports when it was published")
}

// The latest release is the one pointing at the newest commit, whichever order
// the releases were published in, and also when the release on the older
// commit is published from an existing tag.
func TestVerify_LatestReleaseByCommitDate(t *testing.T) {
	require.NoError(t, unittest.PrepareTestDatabase())

	user := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 2})
	repo := unittest.AssertExistsAndLoadBean(t, &repo_model.Repository{ID: 1})

	gitRepo, err := git.OpenRepository(t.Context(), repo)
	require.NoError(t, err)
	defer gitRepo.Close()

	// DefaultBranch points at a newer commit than master.
	recentCommit, err := gitRepo.GetBranchCommit(t.Context(), "DefaultBranch")
	require.NoError(t, err)
	oldCommit, err := gitRepo.GetBranchCommit(t.Context(), "master")
	require.NoError(t, err)
	require.Greater(t, recentCommit.Committer.When.Unix(), oldCommit.Committer.When.Unix(),
		"fixture precondition: DefaultBranch points at a newer commit than master")

	newRelease := func(t *testing.T, tagName, target string) *repo_model.Release {
		rel := &repo_model.Release{
			RepoID: repo.ID, Repo: repo, PublisherID: user.ID, Publisher: user,
			TagName: tagName, Target: target, Title: tagName,
		}
		require.NoError(t, CreateRelease(t.Context(), gitRepo, rel, nil, ""))
		return rel
	}
	latestID := func(t *testing.T) int64 {
		latest, err := repo_model.GetLatestReleaseByRepoID(t.Context(), repo.ID)
		require.NoError(t, err)
		return latest.ID
	}

	t.Run("older commit published last", func(t *testing.T) {
		require.NoError(t, unittest.PrepareTestDatabase())
		recent := newRelease(t, "v9.9-recent", "DefaultBranch")
		newRelease(t, "v9.9-old", "master")
		assert.Equal(t, recent.ID, latestID(t), "the latest release is the one pointing at the newest commit")
	})

	t.Run("newer commit published last", func(t *testing.T) {
		require.NoError(t, unittest.PrepareTestDatabase())
		newRelease(t, "v9.8-old", "master")
		recent := newRelease(t, "v9.8-recent", "DefaultBranch")
		assert.Equal(t, recent.ID, latestID(t), "the latest release is the one pointing at the newest commit")
	})

	t.Run("older commit published from an existing tag", func(t *testing.T) {
		require.NoError(t, unittest.PrepareTestDatabase())
		recent := newRelease(t, "v9.6-recent", "DefaultBranch")

		const tagName = "v9.6-old-tag"
		require.NoError(t, CreateNewTag(t.Context(), user, repo, "master", tagName, ""))
		tagRel, err := repo_model.GetRelease(t.Context(), repo.ID, tagName)
		require.NoError(t, err)
		tagRel.Repo, tagRel.Publisher = repo, user
		tagRel.IsTag = false
		tagRel.Title = "v9.6 from an existing tag"
		require.NoError(t, UpdateRelease(t.Context(), user, gitRepo, tagRel, nil, nil, nil))

		assert.Equal(t, recent.ID, latestID(t), "the latest release is the one pointing at the newest commit")
	})
}

// The publication date follows the draft lifecycle through UpdateRelease:
// editing a published release does not move it, publishing a draft sets it to
// the moment of publishing, withdrawing back to a draft clears it, and
// publishing again sets a new one.
func TestVerify_DraftPublishToggle(t *testing.T) {
	require.NoError(t, unittest.PrepareTestDatabase())

	user := unittest.AssertExistsAndLoadBean(t, &user_model.User{ID: 2})
	repo := unittest.AssertExistsAndLoadBean(t, &repo_model.Repository{ID: 1})

	gitRepo, err := git.OpenRepository(t.Context(), repo)
	require.NoError(t, err)
	defer gitRepo.Close()

	// The mocked clock moves an hour between steps, so a publication date set
	// at the wrong step shows up as a different value.
	fakeNow := time.Date(2024, 1, 1, 0, 0, 0, 0, time.UTC)
	defer timeutil.MockSet(fakeNow)()
	advance := func() { fakeNow = fakeNow.Add(time.Hour); timeutil.MockSet(fakeNow) }
	start := time.Now()

	publishedAt := func(id int64) *time.Time {
		_, p := verifyAPIReleaseDates(t, repo, verifyReloadRelease(t, repo, id))
		return p
	}
	update := func(id int64, change func(rel *repo_model.Release)) {
		rel := verifyReloadRelease(t, repo, id)
		rel.Publisher = user
		change(rel)
		require.NoError(t, UpdateRelease(t.Context(), user, gitRepo, rel, nil, nil, nil))
	}

	// A published release has a publication date.
	published := &repo_model.Release{
		RepoID: repo.ID, Repo: repo, PublisherID: user.ID, Publisher: user,
		TagName: "v8.1-published", Target: "master", Title: "v8.1 published",
		Note: "published", IsDraft: false,
	}
	require.NoError(t, CreateRelease(t.Context(), gitRepo, published, nil, ""))
	at0 := publishedAt(published.ID)
	verifyPublishedNow(t, at0, fakeNow, start, "a published release has a publication date")

	// Editing a published release leaves its publication date where it was,
	// after both the mocked and the real clock have moved on.
	advance()
	time.Sleep(1100 * time.Millisecond)
	update(published.ID, func(rel *repo_model.Release) { rel.Note = "Changed note" })
	if at1 := publishedAt(published.ID); assert.NotNil(t, at1, "an edited release keeps its publication date") && at0 != nil {
		assert.Equal(t, at0.Unix(), at1.Unix(), "editing a published release does not move its publication date")
	}

	// A newly created draft has no publication date.
	draft := &repo_model.Release{
		RepoID: repo.ID, Repo: repo, PublisherID: user.ID, Publisher: user,
		TagName: "v8.2-draft", Target: "master", Title: "v8.2 draft",
		Note: "draft", IsDraft: true,
	}
	require.NoError(t, CreateRelease(t.Context(), gitRepo, draft, nil, ""))
	assert.Nil(t, publishedAt(draft.ID), "a draft has no publication date")

	// Publishing the draft sets the publication date to that moment.
	advance()
	update(draft.ID, func(rel *repo_model.Release) { rel.IsDraft = false })
	verifyPublishedNow(t, publishedAt(draft.ID), fakeNow, start, "publishing a draft sets its publication date")

	// Withdrawing it back to a draft clears the publication date again.
	advance()
	update(draft.ID, func(rel *repo_model.Release) { rel.IsDraft = true })
	assert.Nil(t, publishedAt(draft.ID), "withdrawing a release clears its publication date")

	// Publishing it again sets a new publication date.
	advance()
	update(draft.ID, func(rel *repo_model.Release) { rel.IsDraft = false })
	verifyPublishedNow(t, publishedAt(draft.ID), fakeNow, start, "publishing again sets a new publication date")
}
