## Task

Release dates on our Gitea instance are off in a few related ways.

If someone publishes a release from a tag that already exists, the API's `published_at` shows the tag's old date instead of the time the release went out.
So a release we put out today from an old tag looks like it shipped months ago.
Creating a release on an older commit gets the other half wrong, because its `created_at` shows the moment it was made rather than when the commit was made.
Those are two different dates, and the API should report both.
The `created_at` field should be the date of the commit the release points at, and `published_at` should be when the release was published.

Drafts are wrong the other way around.
A draft that was never published still shows a `published_at`, but it should come back as null.
Turning a published release back into a draft should also make it null, and publishing it again should give it a new publication time.
A release that turns into a draft because its tag was deleted should come back as null as well.
Editing a release that's already out shouldn't change its `published_at`.

The "latest release" gets picked wrong too.
It should be the release on the newest commit, but if someone publishes a release on an older commit, that one takes the spot from a release on a newer commit.

Tags don't agree on dates either.
A tag created in the web UI ends up with a different date than the same tag pushed from the command line, and annotated tags pulled in by a mirror sync get the date the tag was written.
In all of these cases the release for the tag should be dated by the commit it points at.

After the upgrade, releases that were already published should keep their current date as their publication date, and existing drafts should have none.
