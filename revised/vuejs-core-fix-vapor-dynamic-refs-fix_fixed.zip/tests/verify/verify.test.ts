// @ts-nocheck
//
// Vitest behavior tests for template refs on Vapor dynamic and async
// components.
//
// Each test drives entry points that already exist in runtime-vapor
// (re-exported from `../../src`):
//   - createTemplateRefSetter()      the ref-apply closure
//   - createDynamicComponent()       `<component :is>` in Vapor
//   - defineVaporComponent()         Vapor child components
//   - defineVaporAsyncComponent()    async wrapper
//   - vaporInteropPlugin (via makeInteropRender) for vdom interop
// plus `useTemplateRef` / `watchEffect` / `ref` from `@vue/runtime-dom`.
// Nothing internal to the ref implementation is imported. These are the
// same interfaces the package's own specs use.
//
// The JS runner copies this file into packages/runtime-vapor/__tests__/dom/,
// so the relative imports below resolve the same way they do for
// dom/templateRef.spec.ts.
//
// Assertions look only at ref.value identity, function-ref call arguments,
// rendered html and dev warnings.

import {
  createComponent,
  createDynamicComponent,
  createTemplateRefSetter,
  defineVaporComponent,
  insert,
  renderEffect,
  template,
} from '../../src'
import { makeInteropRender, makeRender } from '../_utils'
import {
  type ShallowRef,
  defineComponent,
  h,
  nextTick,
  ref,
  shallowRef,
  useTemplateRef,
  watchEffect,
} from '@vue/runtime-dom'
import { defineVaporAsyncComponent } from '../../src/apiDefineAsyncComponent'
import type { VaporComponent } from '../../src/component'

const define = makeRender()
const defineInterop = makeInteropRender()
const timeout = (n = 0) => new Promise(r => setTimeout(r, n))

describe('vapor dynamic/async template refs', () => {
  // ── Criterion 1 ──────────────────────────────────────────────────
  // Switching the inner component of a dynamic component moves the bound
  // ref to the new child's exposed value, so calling through the ref runs
  // the new child's method.
  test('dynamic component ref updates to the new child on switch', async () => {
    const msg = ref('')
    const Child1 = defineVaporComponent({
      setup(_, { expose }) {
        expose({ setMsg: () => (msg.value = 'one') })
        return template(`<div>1`)()
      },
    })
    const Child2 = defineVaporComponent({
      setup(_, { expose }) {
        expose({ setMsg: () => (msg.value = 'two') })
        return template(`<div>2`)()
      },
    })

    const view = shallowRef(Child1)
    const refKey = ref<any>(null)

    const { html } = define({
      setup() {
        const setRef = createTemplateRefSetter()
        const n0 = createDynamicComponent(() => view.value) as any
        setRef(n0, refKey)
        return n0
      },
    }).render()

    expect(refKey.value).toBeDefined()
    expect(html()).toBe('<div>1</div><!--dynamic-component-->')
    refKey.value.setMsg()
    expect(msg.value).toBe('one')

    view.value = Child2
    await nextTick()
    expect(html()).toBe('<div>2</div><!--dynamic-component-->')
    refKey.value.setMsg()
    expect(msg.value).toBe('two')
  })

  // ── Criterion 2 ──────────────────────────────────────────────────
  // A useTemplateRef-bound ref follows each dynamic switch, seen through a
  // watchEffect, including the switch back to the first child.
  test('useTemplateRef reflects each dynamic-component switch', async () => {
    const One = defineVaporComponent({
      setup(_, { expose }) {
        expose({ name: 'one' })
        return template('<div>one</div>')()
      },
    })
    const Two = defineVaporComponent({
      setup(_, { expose }) {
        expose({ name: 'two' })
        return template('<div>two</div>')()
      },
    })

    const views: VaporComponent[] = [One, Two]
    const view = ref(0)
    const refNames: string[] = []
    let compRef: ShallowRef

    const { html } = define({
      setup() {
        compRef = useTemplateRef('compRef')
        watchEffect(() => {
          const value = compRef.value as { name?: string } | null
          if (value?.name) refNames.push(value.name)
        })
        const setRef = createTemplateRefSetter()
        const n0 = createDynamicComponent(() => views[view.value]) as any
        setRef(n0, compRef, false, 'compRef')
        return n0
      },
    }).render()

    await nextTick()
    const one = compRef!.value
    expect(one).toMatchObject({ name: 'one' })
    expect(html()).toBe('<div>one</div><!--dynamic-component-->')

    view.value = 1
    await nextTick()
    const two = compRef!.value
    expect(two).toMatchObject({ name: 'two' })
    expect(two).not.toBe(one)
    expect(html()).toBe('<div>two</div><!--dynamic-component-->')

    view.value = 0
    await nextTick()
    expect(compRef!.value).toMatchObject({ name: 'one' })
    expect(compRef!.value).not.toBe(two)
    expect(refNames).toContain('two')
  })

  // ── Criterion 3 ──────────────────────────────────────────────────
  // The same function ref is bound from a renderEffect that re-runs three
  // times without a child switch, then the child switches once. That switch
  // calls the function ref a small, fixed number of times (the null cleanup
  // plus the new child), however many re-runs came before it.
  test('dynamic component registers exactly one re-apply handler', async () => {
    const One = defineVaporComponent({
      setup: () => template('<div>one</div>')(),
    })
    const Two = defineVaporComponent({
      setup: () => template('<div>two</div>')(),
    })

    const views: VaporComponent[] = [One, Two]
    const view = ref(0)
    const bump = ref(0)
    const fnRef = vi.fn()
    let frag: any

    define({
      setup() {
        const setRef = createTemplateRefSetter()
        frag = createDynamicComponent(() => views[view.value]) as any
        renderEffect(() => {
          // Track `bump` (not `view`) so the re-runs come from here and the
          // child switch below does not re-run this effect.
          bump.value
          setRef(frag, fnRef as any)
        })
        return frag
      },
    }).render()

    // Re-run the renderEffect several times with the same bound ref.
    bump.value++
    await nextTick()
    bump.value++
    await nextTick()
    bump.value++
    await nextTick()
    const beforeSwitch = fnRef.mock.calls.length

    // One child switch.
    view.value = 1
    await nextTick()
    const switchCalls = fnRef.mock.calls.length - beforeSwitch

    // The switch has to reach the function ref so it tracks the new child,
    // but the count must not grow with the earlier re-runs. Null cleanup plus
    // the new value is 2 calls, and 3 leaves room for one extra call. A count
    // that grows with the three re-runs reaches 4 or more here.
    expect(switchCalls).toBeGreaterThan(0)
    expect(switchCalls).toBeLessThanOrEqual(3)
  })

  // ── Criterion 4 ──────────────────────────────────────────────────
  // When the bound ref object itself changes (refA -> refB), refA is set to
  // null and only refB holds the value. A later child switch then updates
  // refB, and refA stays null.
  test('rebinding the ref object transfers tracking to the new ref', async () => {
    const One = defineVaporComponent({
      setup(_, { expose }) {
        expose({ name: 'one' })
        return template('<div>one</div>')()
      },
    })
    const Two = defineVaporComponent({
      setup(_, { expose }) {
        expose({ name: 'two' })
        return template('<div>two</div>')()
      },
    })

    const views: VaporComponent[] = [One, Two]
    const view = ref(0)
    const useA = ref(true)
    const refA = ref<any>(null)
    const refB = ref<any>(null)

    define({
      setup() {
        const setRef = createTemplateRefSetter()
        const n0 = createDynamicComponent(() => views[view.value]) as any
        renderEffect(() => {
          setRef(n0, useA.value ? refA : refB)
        })
        return n0
      },
    }).render()

    await nextTick()
    expect(refA.value).toMatchObject({ name: 'one' })
    expect(refB.value).toBe(null)

    // Rebind the ref object refA -> refB (child still One): the old ref is
    // nulled and the active ref holds the current value.
    useA.value = false
    await nextTick()
    expect(refA.value).toBe(null)
    expect(refB.value).toMatchObject({ name: 'one' })

    // A later child switch must re-apply to the now-active refB; the detached
    // refA must stay null.
    view.value = 1
    await nextTick()
    expect(refA.value).toBe(null)
    expect(refB.value).toMatchObject({ name: 'two' })
  })

  // ── Criterion 5 ──────────────────────────────────────────────────
  // A function ref on a dynamic component is called with `null` for the old
  // child before it gets the new child.
  test('dynamic component function ref cleans up with null on switch', async () => {
    const One = defineVaporComponent({
      setup(_, { expose }) {
        expose({ name: 'one' })
        return template('<div>one</div>')()
      },
    })
    const Two = defineVaporComponent({
      setup(_, { expose }) {
        expose({ name: 'two' })
        return template('<div>two</div>')()
      },
    })

    const views: VaporComponent[] = [One, Two]
    const view = ref(0)
    const fnRef = vi.fn()

    define({
      setup() {
        const setRef = createTemplateRefSetter()
        const n0 = createDynamicComponent(() => views[view.value]) as any
        setRef(n0, fnRef as any)
        return n0
      },
    }).render()

    expect(fnRef).toHaveBeenCalledTimes(1)
    expect(fnRef.mock.calls[0][0]).toMatchObject({ name: 'one' })

    view.value = 1
    await nextTick()

    const callArgs = fnRef.mock.calls.map(args => args[0])
    expect(callArgs).toContain(null)
    expect(fnRef.mock.calls[fnRef.mock.calls.length - 1][0]).toMatchObject({
      name: 'two',
    })
  })

  // ── Criterion 6 ──────────────────────────────────────────────────
  // Swapping the bound function ref (fnA -> fnB) on a dynamic component calls
  // fnA with `null`, and fnB gets the current child.
  test('dynamic component function ref cleans up previous callback when the ref changes', async () => {
    const One = defineVaporComponent({
      setup(_, { expose }) {
        expose({ name: 'one' })
        return template('<div>one</div>')()
      },
    })

    const useA = ref(true)
    const fnA = vi.fn()
    const fnB = vi.fn()

    define({
      setup() {
        const setRef = createTemplateRefSetter()
        const n0 = createDynamicComponent(() => One) as any
        renderEffect(() => {
          setRef(n0, useA.value ? (fnA as any) : (fnB as any))
        })
        return n0
      },
    }).render()

    expect(fnA.mock.calls[fnA.mock.calls.length - 1][0]).toMatchObject({
      name: 'one',
    })
    expect(fnB).toHaveBeenCalledTimes(0)

    useA.value = false
    await nextTick()

    const fnAArgs = fnA.mock.calls.map(args => args[0])
    expect(fnAArgs).toContain(null)
    expect(fnB.mock.calls[fnB.mock.calls.length - 1][0]).toMatchObject({
      name: 'one',
    })
  })

  // ── Criterion 7: ref_for keeps sibling entries ───────────────────
  // Two dynamic components share one ref_for array ref. Switching one of them
  // replaces only its own entry, and the sibling's entry stays in the array.
  test('dynamic ref_for keeps sibling refs when one branch updates', async () => {
    const One = defineVaporComponent({
      setup(_, { expose }) {
        expose({ name: 'one' })
        return template('<div>one</div>')()
      },
    })
    const Two = defineVaporComponent({
      setup(_, { expose }) {
        expose({ name: 'two' })
        return template('<div>two</div>')()
      },
    })

    const views: VaporComponent[] = [One, Two]
    const view = ref(0)
    const listRef = ref<any[]>([])

    define({
      setup() {
        return { listRef }
      },
      render() {
        const n0 = template('<div></div>')() as Element
        const setRef = createTemplateRefSetter()
        const n1 = createDynamicComponent(() => views[view.value]) as any
        const n2 = createDynamicComponent(() => One) as any
        setRef(n1, listRef as any, true)
        setRef(n2, listRef as any, true)
        insert(n1, n0 as ParentNode)
        insert(n2, n0 as ParentNode)
        return n0
      },
    }).render()

    await nextTick()
    expect(listRef.value).toHaveLength(2)
    expect(listRef.value.filter(i => i?.name === 'one')).toHaveLength(2)

    view.value = 1
    await nextTick()
    expect(listRef.value).toHaveLength(2)
    expect(listRef.value.filter(i => i?.name === 'one')).toHaveLength(1)
    expect(listRef.value.some(i => i?.name === 'two')).toBe(true)
  })

  // ── Criterion 8: vdom interop child ──────────────────────────────
  // A dynamic component that renders a vdom (interop) child resolves the ref
  // to that child's exposed value.
  test('dynamic component resolves a vdom interop child ref', async () => {
    const vdomRef = ref<any>(null)
    const VdomChild = defineComponent({
      setup(_, { expose }) {
        expose({ name: 'vdomChild' })
        return () => h('div', 'vdom child')
      },
    })

    const VaporChild = defineVaporComponent({
      setup() {
        return { vdomRef }
      },
      render() {
        const setRef = createTemplateRefSetter()
        const n0 = createDynamicComponent(() => VdomChild)
        setRef(n0, vdomRef, false, 'vdomRef')
        return n0
      },
    })

    defineInterop({
      setup() {
        return () => h(VaporChild as any)
      },
    }).render()

    await nextTick()
    expect(vdomRef.value).toBeDefined()
    expect(vdomRef.value.name).toBe('vdomChild')
  })

  // ── Criterion 9: vdom interop ref change ─────────────────────────
  // With a vdom child inside the dynamic component, changing the bound ref
  // (refA -> refB) sets refA to null and refB to the child's exposed value.
  test('dynamic vdom interop child ref cleans up the old ref on switch', async () => {
    const VdomChild = defineComponent({
      setup(_, { expose }) {
        expose({ name: 'vdomChild' })
        return () => h('div', 'vdom child')
      },
    })

    const useA = ref(true)
    const refA = ref<any>(null)
    const refB = ref<any>(null)

    const VaporChild = defineVaporComponent({
      setup() {
        const setRef = createTemplateRefSetter()
        const n0 = createDynamicComponent(() => VdomChild)
        renderEffect(() => {
          setRef(n0, useA.value ? refA : refB, false, 'vdomRef')
        })
        return n0
      },
    })

    defineInterop({
      setup() {
        return () => h(VaporChild as any)
      },
    }).render()

    await nextTick()
    expect(refA.value).toBeDefined()
    expect(refA.value.name).toBe('vdomChild')
    expect(refB.value).toBe(null)

    useA.value = false
    await nextTick()
    expect(refA.value).toBe(null)
    expect(refB.value).toBeDefined()
    expect(refB.value.name).toBe('vdomChild')
  })

  // ── Criterion 10: null/undefined key on an element, no warning ───
  // A dynamic ref on a plain element whose key becomes null or undefined
  // clears the old ref value and does not emit the "Invalid template ref
  // type:" dev warning. Setting a valid key again binds the ref again.
  // setup-vitest.ts also throws on any warning a test does not assert.
  test('null/undefined dynamic ref key clears without warning', async () => {
    const t0 = template('<div></div>')
    const el = ref(null)
    const refKey = ref<any>('foo')

    const { render } = define({
      setup() {
        return { foo: el }
      },
      render() {
        const n0 = t0()
        const setRef = createTemplateRefSetter()
        renderEffect(() => {
          setRef(n0 as Element, refKey.value)
        })
        return n0
      },
    })

    const { host } = render()
    expect(el.value).toBe(host.children[0])

    refKey.value = null
    await nextTick()
    expect(el.value).toBe(null)
    expect('Invalid template ref type:').not.toHaveBeenWarned()

    refKey.value = 'foo'
    await nextTick()
    expect(el.value).toBe(host.children[0])

    refKey.value = undefined
    await nextTick()
    expect(el.value).toBe(null)
    expect('Invalid template ref type:').not.toHaveBeenWarned()
  })

  // ── Criterion 11: null/undefined key on components, no warning ──
  // The same rule on a Vapor component and on a dynamic component. Each ref
  // first holds its child's exposed value. A null or undefined key clears it
  // with no "Invalid template ref type:" dev warning, and a valid key binds
  // it again.
  test('null/undefined dynamic ref key on a component clears without warning', async () => {
    const Child = defineVaporComponent({
      setup(_, { expose }) {
        expose({ name: 'child' })
        return template('<div>child</div>')()
      },
    })

    const compRef = ref<any>(null)
    const dynRef = ref<any>(null)
    const compKey = ref<any>('compRef')
    const dynKey = ref<any>('dynRef')

    define({
      setup() {
        return { compRef, dynRef }
      },
      render() {
        const n0 = template('<div></div>')() as Element
        const setRef = createTemplateRefSetter()
        const n1 = createComponent(Child)
        const n2 = createDynamicComponent(() => Child) as any
        renderEffect(() => {
          setRef(n1 as any, compKey.value)
        })
        renderEffect(() => {
          setRef(n2, dynKey.value)
        })
        insert(n1, n0 as ParentNode)
        insert(n2, n0 as ParentNode)
        return n0
      },
    }).render()

    await nextTick()
    expect(compRef.value).toMatchObject({ name: 'child' })
    expect(dynRef.value).toMatchObject({ name: 'child' })

    compKey.value = null
    dynKey.value = null
    await nextTick()
    expect(compRef.value).toBe(null)
    expect(dynRef.value).toBe(null)
    expect('Invalid template ref type:').not.toHaveBeenWarned()

    compKey.value = 'compRef'
    dynKey.value = 'dynRef'
    await nextTick()
    expect(compRef.value).toMatchObject({ name: 'child' })
    expect(dynRef.value).toMatchObject({ name: 'child' })

    compKey.value = undefined
    dynKey.value = undefined
    await nextTick()
    expect(compRef.value).toBe(null)
    expect(dynRef.value).toBe(null)
    expect('Invalid template ref type:').not.toHaveBeenWarned()
  })

  // ── Criterion 12: async wrapper ref ──────────────────────────────
  // A ref on an async component points at the inner instance once it
  // resolves. If the bound ref changes after that, the old ref is cleared
  // and the new one gets the inner instance.
  test('async wrapper ref forwarding drops stale callbacks after resolve', async () => {
    let resolve: (comp: VaporComponent) => void
    const Foo = defineVaporAsyncComponent(
      () =>
        new Promise(r => {
          resolve = r as any
        }),
    )

    const refA = ref<any>(null)
    const refB = ref<any>(null)
    const useA = ref(true)
    const root = document.createElement('div')

    const { mount } = define({
      setup() {
        return { refA, refB, useA }
      },
      render() {
        const setTemplateRef = createTemplateRefSetter()
        const n0 = createComponent(Foo, null, null, true)
        renderEffect(() => {
          setTemplateRef(n0, useA.value ? 'refA' : 'refB')
        })
        return n0
      },
    }).create()

    mount(root)
    expect(refA.value).toBe(null)
    expect(refB.value).toBe(null)

    resolve!({
      setup: (props, { expose }) => {
        expose({ id: 'foo' })
        return template('resolved')()
      },
    })
    await timeout()

    expect(root.innerHTML).toBe('resolved<!--async component-->')
    expect(refA.value.id).toBe('foo')
    expect(refB.value).toBe(null)

    useA.value = false
    await nextTick()
    expect(refA.value).toBe(null)
    expect(refB.value.id).toBe('foo')
  })

  // ── Criterion 13: static refs still work ─────────────────────────
  // Plain element and component template refs still resolve to the element
  // and the exposed value.
  test('plain element and component refs still resolve (regression guard)', async () => {
    const elRef = ref<any>(null)
    const childRef = ref<any>(null)

    const Child = defineVaporComponent({
      setup(_, { expose }) {
        expose({ name: 'child' })
        return template('<span>child</span>')()
      },
    })

    const { host } = define({
      setup() {
        return { elRef, childRef }
      },
      render() {
        const setRef = createTemplateRefSetter()
        const n0 = template('<div></div>')() as Element
        const n1 = createComponent(Child)
        setRef(n0, elRef, false, 'elRef')
        setRef(n1 as any, childRef, false, 'childRef')
        insert(n1, n0 as ParentNode)
        return n0
      },
    }).render()

    await nextTick()
    expect(elRef.value).toBe(host.children[0])
    expect(childRef.value).toMatchObject({ name: 'child' })
  })
})
