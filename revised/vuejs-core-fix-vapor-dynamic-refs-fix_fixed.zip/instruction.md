## Task

In Vapor mode, template refs on a `<component :is="...">` don't follow the component when it changes.
Bind a `ref()` object, a string ref, a `useTemplateRef` ref or a function ref, switch `is` to another component, and the ref still holds the first child's exposed value.
If the dynamic component renders a regular non-Vapor component, the ref comes back `undefined` instead of that component's exposed value.
Async components hit the same problems, including when the bound ref changes after the component has loaded.

On a child switch, a ref object or string ref should just end up holding the new child's value.
A function ref is different: it should get called with `null` for the old child, then with the new one.
One switch should give a function ref only that cleanup call and the new child, no matter how many times the parent re-rendered before it.
For refs inside `v-for`, only the entry for the component that switched should change, and the other entries stay put.

When the bound ref itself changes, the old one has to be let go before the new one picks up the current child.
An old ref object or string ref goes back to `null`, and an old function ref gets called with `null`.

A dynamic `:ref` whose value turns `null` or `undefined` logs an "Invalid template ref type" warning in dev today.
It shouldn't warn at all, it should just clear whatever that ref pointed at before.
That goes for plain elements, regular components and dynamic components alike.

Static refs work fine today and need to keep working, and the way refs are declared in templates stays the same.
