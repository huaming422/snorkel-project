## Task

We run our own Dolt server for bd and point bd at it through the workspace metadata, `BEADS_DOLT_SERVER_HOST`, `dolt.host` in the config file, or the `bd init` server flags.
With an IPv4 address or a DNS name that works fine.
With an IPv6 address it doesn't.
`bd list`, serving the workspace (proxied-server mode too) and `bd doctor --perf` / `bd doctor --server` all fail with address or port errors, even though the server is up and listening.

Writing the address bare (`::1`) or in brackets (`[::1]`) doesn't help, it only changes which commands break.
`bd doctor` and the everyday commands don't even agree on which spelling works.
With the bracketed form, the error bd prints names the server as `[[::1]]:3307`.

It also goes wrong when our server at `::1` is down.
`bd list` tries to start bd's own Dolt server in its place and then tells us to run `bd dolt start`.
On a workspace that doesn't pin the port, `bd doctor` even passes the Dolt connection check with "Skipped (no server running; will auto-start on next bd command)".
bd's own server only ever listens on `127.0.0.1`, so it can never be the one answering at `[::1]`.

What we need:
- Any IPv6 address works written either way, and both spellings reach the same server.
- When bd can't reach an IPv6 server, the error and the hint it prints name the server in brackets once, like `[::1]:3307`.
- Saved passwords keep working, and our credentials files have IPv6 sections written both ways, `[::1:3307]` and `[[::1]:3307]`.
- Either section is found whichever way the host is written, while a section for another port still doesn't match.
- The warning bd prints when other users can read the credentials file still shows up just once, as it does today.
- A server at `::1`, in either spelling, is never treated as bd's own: when it's down, bd doesn't try to start its own server instead, doesn't suggest `bd dolt start`, and `bd doctor` reports the failed connection rather than skipping it.
- IPv4 addresses and DNS names behave exactly as they do now.

bd's own server keeps listening on `127.0.0.1` only, so don't change where it listens.
Host values that already carry a port, like `127.0.0.1:3307`, are a separate problem; leave them as they are.
