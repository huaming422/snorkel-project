## Task

We run our own Dolt server for bd and point bd at it through the workspace metadata, `BEADS_DOLT_SERVER_HOST`, `dolt.host` in the config file, or the `bd init` server flags.
With an IPv4 address or a DNS name that works fine.
With an IPv6 address it doesn't.
`bd list`, serving the workspace (proxied-server mode too) and `bd doctor --perf` / `bd doctor --server` all fail with address or port errors, even though the server is up and listening.

Writing the address bare (`::1`) or in brackets (`[::1]`) doesn't help, it only changes which commands break.
`bd doctor` and the everyday commands don't even agree on which spelling works.
With the bracketed form, the error bd prints names the server as `[[::1]]:3307`.

What we need:
- Any IPv6 address works written either way, and both spellings reach the same server.
- When bd can't reach an IPv6 server, the error and the hint it prints name the server in brackets once, like `[::1]:3307`.
- Saved passwords keep working, and our credentials files have IPv6 sections written both ways, `[::1:3307]` and `[[::1]:3307]`.
- Either section is found whichever way the host is written, while a section for another port still doesn't match.
- The warning bd prints when other users can read the credentials file still shows up just once, as it does today.
- IPv4 addresses and DNS names behave exactly as they do now.

Leave alone the server bd launches for itself (it only listens on `127.0.0.1`) and host values that already carry a port, like `127.0.0.1:3307`.
