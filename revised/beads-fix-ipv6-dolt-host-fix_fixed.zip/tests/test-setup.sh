#!/usr/bin/env bash
# All dependencies are baked into the image at the base commit. Nothing to
# do at verifier time.
set -euo pipefail
echo "[test-setup] no-op for beads-fix-ipv6-dolt-host"
