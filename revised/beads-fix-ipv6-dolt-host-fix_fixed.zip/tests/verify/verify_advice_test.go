package doltserver_test

import (
	"fmt"
	"path/filepath"
	"strings"
	"testing"

	"github.com/steveyegge/beads/internal/config"
	"github.com/steveyegge/beads/internal/configfile"
	"github.com/steveyegge/beads/internal/doltserver"
)

// TestUnreachableEndpointAdvice_IPv6SingleBracket checks that the advice bd
// prints for an unreachable IPv6 Dolt server names the endpoint as
// [host]:port, never with doubled brackets ([[host]]:port) and never joined
// without brackets (host:port). Each host is given bare and bracketed, for the
// loopback and for a non-loopback address; both spellings of one server are
// named the same way.
func TestUnreachableEndpointAdvice_IPv6SingleBracket(t *testing.T) {
	const port = 3309
	for _, tc := range []struct{ host, addr string }{
		{"::1", "::1"},
		{"[::1]", "::1"},
		{"2001:db8::1", "2001:db8::1"},
		{"[2001:db8::1]", "2001:db8::1"},
	} {
		t.Run(tc.host, func(t *testing.T) {
			resetServerClassificationEnv(t)
			dir := newExternalPortWorkspace(t, port)

			msg := doltserver.UnreachableEndpointAdvice(dir, tc.host, port, doltserver.PortSourceMetadataJSON)
			if msg == "" {
				t.Fatalf("UnreachableEndpointAdvice(%q, %d) returned no advice", tc.host, port)
			}
			endpoint := fmt.Sprintf("[%s]:%d", tc.addr, port)
			if !strings.Contains(msg, endpoint) {
				t.Errorf("advice for host %q should name the endpoint %s; got: %s", tc.host, endpoint, msg)
			}
			if strings.Contains(msg, "[["+tc.addr+"]]") {
				t.Errorf("advice for host %q double-brackets the endpoint; got: %s", tc.host, msg)
			}
			if strings.Contains(msg, fmt.Sprintf(" %s:%d", tc.addr, port)) {
				t.Errorf("advice for host %q names the endpoint unbracketed; got: %s", tc.host, msg)
			}
		})
	}
}

// resetServerClassificationEnv clears every setting that classifies a
// workspace's Dolt server, so a case names exactly the one it configures.
// Mirrors the package's own test-env reset through the exported config API.
func resetServerClassificationEnv(t *testing.T) {
	t.Helper()
	home := t.TempDir()
	t.Setenv("HOME", home)
	t.Setenv("USERPROFILE", home)
	t.Setenv("BEADS_SHARED_SERVER_DIR", filepath.Join(home, "shared-server"))
	for _, name := range []string{
		"BEADS_DOLT_SERVER_MODE", "BEADS_DOLT_SHARED_SERVER", "BEADS_DOLT_SERVER_HOST",
		"BEADS_DOLT_SERVER_PORT", "BEADS_DOLT_PORT", "BEADS_DOLT_AUTO_START",
	} {
		t.Setenv(name, "")
	}
	config.ResetForTesting()
	t.Cleanup(config.ResetForTesting)
}

// newExternalPortWorkspace writes a .beads workspace whose persisted
// server-mode metadata names metadataPort, so the workspace's Dolt server is
// classified as externally managed on that port, the state in which the
// unreachable-server advice names the endpoint.
func newExternalPortWorkspace(t *testing.T, metadataPort int) string {
	t.Helper()
	dir := t.TempDir()
	cfg := configfile.DefaultConfig()
	cfg.Backend = configfile.BackendDolt
	cfg.DoltMode = configfile.DoltModeServer
	cfg.DoltServerPort = metadataPort
	if err := cfg.Save(dir); err != nil {
		t.Fatal(err)
	}
	return dir
}
