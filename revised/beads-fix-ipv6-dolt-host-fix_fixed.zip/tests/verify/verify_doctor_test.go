package doctor

import (
	"fmt"
	"net"
	"os"
	"path/filepath"
	"strings"
	"sync/atomic"
	"testing"

	"github.com/steveyegge/beads/internal/config"
	"github.com/steveyegge/beads/internal/configfile"
	"github.com/steveyegge/beads/internal/doltserver"
)

// ipv6DoctorHosts are spellings of one IPv6 loopback server: bare, bracketed,
// and the bare long form of the same address.
var ipv6DoctorHosts = []string{"::1", "[::1]", "0:0:0:0:0:0:0:1"}

// ipv6DoctorProbe listens on an ephemeral port of the IPv6 loopback [::1],
// accepting and closing every connection until the test ends, and returns the
// port plus a count of the connections it has accepted. The IPv6 loopback is
// part of the test environment, so a host that cannot bind it fails the test
// rather than skipping it.
func ipv6DoctorProbe(t *testing.T) (port int, accepted func() int64) {
	t.Helper()
	ln, err := net.Listen("tcp", "[::1]:0")
	if err != nil {
		t.Fatalf("IPv6 loopback not available: %v", err)
	}
	t.Cleanup(func() { _ = ln.Close() })
	var n atomic.Int64
	go func() {
		for {
			conn, err := ln.Accept()
			if err != nil {
				return
			}
			n.Add(1)
			_ = conn.Close()
		}
	}()
	return ln.Addr().(*net.TCPAddr).Port, n.Load
}

// ipv6DoctorWorkspace writes a server-mode metadata.json naming host and port,
// with no Dolt server variable set, and returns the project directory.
func ipv6DoctorWorkspace(t *testing.T, host string, port int) string {
	t.Helper()
	for _, name := range []string{"BEADS_DOLT_SHARED_SERVER", "BEADS_DOLT_SERVER_MODE", "BEADS_DOLT_SERVER_PORT",
		"BEADS_DOLT_PORT", "BEADS_DOLT_SERVER_HOST", "BEADS_DOLT_SERVER_SOCKET"} {
		t.Setenv(name, "")
	}
	config.ResetForTesting()
	t.Cleanup(config.ResetForTesting)
	tmpDir := t.TempDir()
	beadsDir := filepath.Join(tmpDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0o750); err != nil {
		t.Fatal(err)
	}
	cfg := configfile.DefaultConfig()
	cfg.Backend = configfile.BackendDolt
	cfg.DoltMode = configfile.DoltModeServer
	cfg.DoltServerHost = host
	cfg.DoltServerPort = port
	if err := cfg.Save(beadsDir); err != nil {
		t.Fatalf("save config: %v", err)
	}
	return tmpDir
}

// TestDoctorPerf_IPv6HostReportsServerRunning checks that `bd doctor --perf`
// (RunDoltPerformanceDiagnostics) reports an IPv6 Dolt server it can reach as
// running, for each spelling of the host. The workspace names a plain IPv6
// loopback listener that speaks no MySQL, so the later diagnostics fail; what
// is asserted is the reported server status, that the error does not say the
// server is not running, and that the listener saw the connection.
func TestDoctorPerf_IPv6HostReportsServerRunning(t *testing.T) {
	for _, host := range ipv6DoctorHosts {
		t.Run(host, func(t *testing.T) {
			port, accepted := ipv6DoctorProbe(t)
			dir := ipv6DoctorWorkspace(t, host, port)

			metrics, err := RunDoltPerformanceDiagnostics(dir, false)
			if metrics == nil {
				t.Fatalf("RunDoltPerformanceDiagnostics returned no metrics for IPv6 host %q: %v", host, err)
			}
			if metrics.ServerStatus != "running" {
				t.Errorf("bd doctor --perf reported the IPv6 server at %q as %q, want running (err: %v)",
					host, metrics.ServerStatus, err)
			}
			if err != nil && strings.Contains(err.Error(), "not running") {
				t.Errorf("bd doctor --perf says the IPv6 server at %q is not running: %v", host, err)
			}
			if accepted() == 0 {
				t.Errorf("bd doctor --perf for IPv6 host %q never reached the server", host)
			}
		})
	}
}

// TestDoctorServer_IPv6HostReachable checks that `bd doctor --server`
// (RunServerHealthChecks) reports an IPv6 Dolt server it can reach as
// reachable, for each spelling of the host. The later checks need a real Dolt
// server and fail against the plain listener, so only the reachability check
// is asserted, together with the listener seeing the connection.
func TestDoctorServer_IPv6HostReachable(t *testing.T) {
	for _, host := range ipv6DoctorHosts {
		t.Run(host, func(t *testing.T) {
			port, accepted := ipv6DoctorProbe(t)
			dir := ipv6DoctorWorkspace(t, host, port)

			result := RunServerHealthChecks(dir)
			var reach *DoctorCheck
			for i := range result.Checks {
				if result.Checks[i].Name == "Server Reachable" {
					reach = &result.Checks[i]
				}
			}
			if reach == nil {
				t.Fatalf("bd doctor --server ran no reachability check for IPv6 host %q: %+v", host, result.Checks)
			}
			if reach.Status != StatusOK {
				t.Errorf("bd doctor --server reported the IPv6 server at %q unreachable: %s (%s)",
					host, reach.Message, reach.Detail)
			}
			if accepted() == 0 {
				t.Errorf("bd doctor --server for IPv6 host %q never reached the server", host)
			}
		})
	}
}

// TestDoctorPerf_IPv6UnreachableErrorBracketsOnce checks the error `bd doctor
// --perf` (RunDoltPerformanceDiagnostics) returns when nothing listens at the
// IPv6 host's port. It must name the server as [address]:port: never with
// doubled brackets and never as the bare address joined to the port.
func TestDoctorPerf_IPv6UnreachableErrorBracketsOnce(t *testing.T) {
	for _, tc := range []struct{ host, addr string }{
		{"::1", "::1"},
		{"[::1]", "::1"},
		{"0:0:0:0:0:0:0:1", "0:0:0:0:0:0:0:1"},
	} {
		t.Run(tc.host, func(t *testing.T) {
			ln, err := net.Listen("tcp", "[::1]:0")
			if err != nil {
				t.Fatalf("IPv6 loopback not available: %v", err)
			}
			port := ln.Addr().(*net.TCPAddr).Port
			_ = ln.Close()
			dir := ipv6DoctorWorkspace(t, tc.host, port)

			_, err = RunDoltPerformanceDiagnostics(dir, false)
			if err == nil {
				t.Fatalf("bd doctor --perf succeeded with nothing at IPv6 host %q port %d", tc.host, port)
			}
			msg := err.Error()
			if !strings.Contains(msg, fmt.Sprintf("]:%d", port)) {
				t.Errorf("error for IPv6 host %q does not name the server as [address]:%d:\n%s", tc.host, port, msg)
			}
			if strings.Contains(msg, "[[") {
				t.Errorf("error for IPv6 host %q double-brackets the server:\n%s", tc.host, msg)
			}
			if strings.Contains(msg, fmt.Sprintf("%s:%d", tc.addr, port)) {
				t.Errorf("error for IPv6 host %q names the server without brackets:\n%s", tc.host, msg)
			}
		})
	}
}

// TestDoctorDolt_IPv6LoopbackDownReportedNotSkipped checks `bd doctor`'s Dolt
// checks (RunDoltHealthChecks) on a server-mode workspace whose metadata
// names the IPv6 loopback and no port: either none at all, or a workspace
// where bd ran its own server before and its port file is still there. No bd
// command starts a server at [::1] (bd's own listens on 127.0.0.1 only), so
// the Dolt connection must be reported as failed, not skipped as a server the
// next bd command will auto-start, and its fix must not be `bd dolt start`.
// The same workspace at 127.0.0.1 is the control: bd does start that server,
// so doctor still skips the connection checks there.
func TestDoctorDolt_IPv6LoopbackDownReportedNotSkipped(t *testing.T) {
	for _, tc := range []struct {
		name, host string
		portFile   bool
	}{
		{"no port/::1", "::1", false},
		{"no port/[::1]", "[::1]", false},
		{"bd port file/::1", "::1", true},
		{"bd port file/[::1]", "[::1]", true},
		{"no port/127.0.0.1", "127.0.0.1", false},
	} {
		t.Run(tc.name, func(t *testing.T) {
			dir := ipv6DoctorWorkspace(t, tc.host, 0)
			if tc.portFile {
				ln, err := net.Listen("tcp", "127.0.0.1:0")
				if err != nil {
					t.Fatal(err)
				}
				port := ln.Addr().(*net.TCPAddr).Port
				_ = ln.Close()
				beadsDir := filepath.Join(dir, ".beads")
				if err := doltserver.EnsurePortFile(doltserver.ResolveServerDir(beadsDir), port); err != nil {
					t.Fatalf("write bd's port file: %v", err)
				}
			}

			var conn *DoctorCheck
			checks := RunDoltHealthChecks(dir)
			for i := range checks {
				if checks[i].Name == "Dolt Connection" {
					conn = &checks[i]
				}
			}
			if conn == nil {
				t.Fatalf("bd doctor ran no Dolt Connection check for host %q: %+v", tc.host, checks)
			}
			if tc.host == "127.0.0.1" {
				if conn.Status != StatusOK || !strings.Contains(conn.Message, "auto-start") {
					t.Errorf("bd doctor no longer skips a stopped 127.0.0.1 server bd starts itself: %s (%s)",
						conn.Status, conn.Message)
				}
				return
			}
			if conn.Status != StatusError {
				t.Errorf("bd doctor reported the down IPv6 server at %q as %s: %s", tc.host, conn.Status, conn.Message)
			}
			if strings.Contains(conn.Fix, "bd dolt start") {
				t.Errorf("bd doctor's fix for the IPv6 server at %q is bd dolt start: %s", tc.host, conn.Fix)
			}
		})
	}
}
