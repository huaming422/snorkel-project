package dolt

import (
	"context"
	"fmt"
	"net"
	"strings"
	"sync/atomic"
	"testing"
)

// ipv6LoopbackProbe listens on an ephemeral port of the IPv6 loopback [::1],
// accepting and closing every connection until the test ends, and returns the
// port plus a count of the connections it has accepted. The count tells an
// address that was dialed from one that failed to parse before any
// dial happened. The IPv6 loopback is part of the test environment, so a host
// that cannot bind it fails the test rather than skipping it.
func ipv6LoopbackProbe(t *testing.T) (port int, accepted func() int64) {
	t.Helper()
	ln, err := net.Listen("tcp", "[::1]:0")
	if err != nil {
		t.Fatalf("IPv6 loopback not available: %v", err)
	}
	t.Cleanup(func() { _ = ln.Close() })
	var n atomic.Int64
	go func() {
		for {
			conn, err := ln.Accept()
			if err != nil {
				return
			}
			n.Add(1)
			_ = conn.Close()
		}
	}()
	return ln.Addr().(*net.TCPAddr).Port, n.Load
}

// TestServerMode_IPv6HostDialReachesServer checks that opening a server-mode
// store whose host is an IPv6 address reaches the server at that address. The
// host is given bare ("::1"), bracketed ("[::1]"), and as a bracketed long
// form of the same loopback ("[0:0:0:0:0:0:0:1]"); each names the plain IPv6
// loopback listener the test owns, and the listener must see the connection.
// The open still ends in an error (the listener speaks no MySQL), so only the
// accepted-connection count is asserted.
func TestServerMode_IPv6HostDialReachesServer(t *testing.T) {
	for _, host := range []string{"::1", "[::1]", "[0:0:0:0:0:0:0:1]"} {
		t.Run(host, func(t *testing.T) {
			port, accepted := ipv6LoopbackProbe(t)

			cfg := &Config{
				Path:             t.TempDir(),
				BeadsDir:         t.TempDir(),
				Database:         "testdb_ipv6probe",
				ServerMode:       true,
				ServerHost:       host,
				ServerPort:       port,
				DisableAutoStart: true,
			}

			// The probe is not a real Dolt server, so the open's error is not
			// asserted on. What is asserted is that the configured IPv6 host
			// was dialed.
			if store, err := New(context.Background(), cfg); err == nil && store != nil {
				_ = store.Close()
			}

			if accepted() == 0 {
				t.Errorf("opening a store at IPv6 host %q never reached the server", host)
			}
		})
	}
}

// closedIPv6LoopbackPort returns a port on the IPv6 loopback that nothing
// listens on, by binding an ephemeral port and releasing it.
func closedIPv6LoopbackPort(t *testing.T) int {
	t.Helper()
	ln, err := net.Listen("tcp", "[::1]:0")
	if err != nil {
		t.Fatalf("IPv6 loopback not available: %v", err)
	}
	port := ln.Addr().(*net.TCPAddr).Port
	_ = ln.Close()
	return port
}

// TestServerMode_IPv6UnreachableErrorBracketsOnce checks the error a
// server-mode open returns when nothing listens at the IPv6 host's port, the
// error `bd list` prints. It must name the server as [address]:port: never
// with doubled brackets and never as the bare address joined to the port.
func TestServerMode_IPv6UnreachableErrorBracketsOnce(t *testing.T) {
	for _, tc := range []struct{ host, addr string }{
		{"::1", "::1"},
		{"[::1]", "::1"},
		{"[0:0:0:0:0:0:0:1]", "0:0:0:0:0:0:0:1"},
	} {
		t.Run(tc.host, func(t *testing.T) {
			port := closedIPv6LoopbackPort(t)
			cfg := &Config{
				Path:             t.TempDir(),
				BeadsDir:         t.TempDir(),
				Database:         "testdb_ipv6probe",
				ServerMode:       true,
				ServerHost:       tc.host,
				ServerPort:       port,
				DisableAutoStart: true,
			}

			store, err := New(context.Background(), cfg)
			if err == nil {
				if store != nil {
					_ = store.Close()
				}
				t.Fatalf("opening a store at IPv6 host %q with nothing on port %d succeeded", tc.host, port)
			}
			msg := err.Error()
			if !strings.Contains(msg, fmt.Sprintf("]:%d", port)) {
				t.Errorf("error for IPv6 host %q does not name the server as [address]:%d:\n%s", tc.host, port, msg)
			}
			if strings.Contains(msg, "[[") {
				t.Errorf("error for IPv6 host %q double-brackets the server:\n%s", tc.host, msg)
			}
			if strings.Contains(msg, fmt.Sprintf("%s:%d", tc.addr, port)) {
				t.Errorf("error for IPv6 host %q names the server without brackets:\n%s", tc.host, msg)
			}
		})
	}
}
