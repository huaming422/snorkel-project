package util

import (
	"testing"

	mysql "github.com/go-sql-driver/mysql"
)

// TestDoltServerDSN_IPv6CanonicalAddress checks that the proxied-server DSN
// builder dials the same canonical bracketed address [host]:port for an IPv6
// host in either spelling, matching the plain Dolt-server DSN builder. A
// colon-free IPv4 host joins to plain host:port.
func TestDoltServerDSN_IPv6CanonicalAddress(t *testing.T) {
	for _, tc := range []struct{ host, want string }{
		{"::1", "[::1]:3306"},
		{"[::1]", "[::1]:3306"},
		{"2001:db8::1", "[2001:db8::1]:3306"},
		{"127.0.0.1", "127.0.0.1:3306"},
	} {
		t.Run(tc.host, func(t *testing.T) {
			dsn := DoltServerDSN{Host: tc.host, Port: 3306, User: "root"}.String()
			cfg, err := mysql.ParseDSN(dsn)
			if err != nil {
				t.Fatalf("ParseDSN(%q) failed: %v", dsn, err)
			}
			if cfg.Net != "tcp" {
				t.Errorf("host %q: DSN %q uses network %q, want tcp", tc.host, dsn, cfg.Net)
			}
			if cfg.Addr != tc.want {
				t.Errorf("host %q: DSN %q dials %q, want %q", tc.host, dsn, cfg.Addr, tc.want)
			}
		})
	}
}
