package server

import (
	"context"
	"net"
	"sync/atomic"
	"testing"
	"time"

	"github.com/steveyegge/beads/internal/configfile"
)

// ipv6DialProbe listens on an ephemeral port of the IPv6 loopback [::1],
// accepting and closing every connection until the test ends, and returns the
// port plus a count of the connections it has accepted. The IPv6 loopback is
// part of the test environment, so a host that cannot bind it fails the test
// rather than skipping it.
func ipv6DialProbe(t *testing.T) (port int, accepted func() int64) {
	t.Helper()
	ln, err := net.Listen("tcp", "[::1]:0")
	if err != nil {
		t.Fatalf("IPv6 loopback not available: %v", err)
	}
	t.Cleanup(func() { _ = ln.Close() })
	var n atomic.Int64
	go func() {
		for {
			conn, err := ln.Accept()
			if err != nil {
				return
			}
			n.Add(1)
			_ = conn.Close()
		}
	}()
	return ln.Addr().(*net.TCPAddr).Port, n.Load
}

// TestExternalDoltServer_IPv6HostDialReachesServer checks that the proxied
// external-server path connects to an IPv6 Dolt server. The external server is
// built through the public NewExternalDoltServer entry from an
// ExternalDoltConfig, the struct the proxied-server config carries, and Dial
// runs against a plain IPv6 loopback listener. The host is given bare
// ("::1"), bracketed ("[::1]"), and as a bracketed long form of the same
// loopback ("[0:0:0:0:0:0:0:1]"). The dial must succeed, land on the probe's
// port, and be seen by the listener; the listener speaks no MySQL, so a
// completed TCP dial is the observable result.
func TestExternalDoltServer_IPv6HostDialReachesServer(t *testing.T) {
	for _, host := range []string{"::1", "[::1]", "[0:0:0:0:0:0:0:1]"} {
		t.Run(host, func(t *testing.T) {
			port, accepted := ipv6DialProbe(t)

			s, err := NewExternalDoltServer(configfile.ExternalDoltConfig{Host: host, Port: port})
			if err != nil {
				t.Fatalf("NewExternalDoltServer(host=%q): %v", host, err)
			}
			if err := s.Start(context.Background()); err != nil {
				t.Fatalf("Start: %v", err)
			}
			t.Cleanup(func() { _ = s.Stop(context.Background()) })

			conn, err := s.Dial(context.Background())
			if err != nil {
				t.Fatalf("proxied external-server dial to IPv6 host %q failed: %v", host, err)
			}
			remote := conn.RemoteAddr().(*net.TCPAddr)
			_ = conn.Close()

			if remote.Port != port {
				t.Errorf("proxied external-server dial to IPv6 host %q reached port %d, "+
					"not the configured server at [::1]:%d", host, remote.Port, port)
			}

			// Confirm the listener observed the connection (userspace Accept
			// trails the kernel handshake, so poll briefly rather than read once).
			if !waitAccepted(accepted) {
				t.Errorf("proxied external-server dial to IPv6 host %q never reached the server", host)
			}
		})
	}
}

// waitAccepted reports whether the probe accepted at least one connection,
// polling briefly because userspace Accept runs after the client's dial returns.
func waitAccepted(accepted func() int64) bool {
	deadline := time.Now().Add(2 * time.Second)
	for time.Now().Before(deadline) {
		if accepted() > 0 {
			return true
		}
		time.Sleep(10 * time.Millisecond)
	}
	return accepted() > 0
}
