package doltutil

import (
	"testing"

	mysql "github.com/go-sql-driver/mysql"
)

// TestServerDSN_IPv6CanonicalAddress checks that a MySQL DSN built for an IPv6
// Dolt server host dials the canonical bracketed TCP address [host]:port, no
// matter whether the host was written bare ("::1") or already bracketed
// ("[::1]"), and for a non-loopback literal as well as the loopback. The DSN
// is parsed back with the driver's own parser and its dialed address is
// asserted, rather than matching DSN text, so the check reflects exactly what
// the driver would connect to.
func TestServerDSN_IPv6CanonicalAddress(t *testing.T) {
	for _, tc := range []struct{ host, want string }{
		{"::1", "[::1]:3307"},
		{"[::1]", "[::1]:3307"},
		{"2001:db8::1", "[2001:db8::1]:3307"},
		{"[2001:db8::1]", "[2001:db8::1]:3307"},
	} {
		t.Run(tc.host, func(t *testing.T) {
			dsn := ServerDSN{Host: tc.host, Port: 3307, User: "root"}.String()
			cfg, err := mysql.ParseDSN(dsn)
			if err != nil {
				t.Fatalf("ParseDSN(%q) failed: %v", dsn, err)
			}
			if cfg.Net != "tcp" {
				t.Errorf("host %q: DSN %q uses network %q, want tcp", tc.host, dsn, cfg.Net)
			}
			if cfg.Addr != tc.want {
				t.Errorf("host %q: DSN %q dials %q, want %q", tc.host, dsn, cfg.Addr, tc.want)
			}
		})
	}
}

// TestServerDSN_IPv4AndHostnameUnchanged checks that a colon-free host, an
// IPv4 address or a DNS hostname, joins to plain host:port with no brackets.
func TestServerDSN_IPv4AndHostnameUnchanged(t *testing.T) {
	for _, tc := range []struct{ host, want string }{
		{"127.0.0.1", "127.0.0.1:3307"},
		{"dolt.example.com", "dolt.example.com:3307"},
	} {
		t.Run(tc.host, func(t *testing.T) {
			dsn := ServerDSN{Host: tc.host, Port: 3307, User: "root"}.String()
			cfg, err := mysql.ParseDSN(dsn)
			if err != nil {
				t.Fatalf("ParseDSN(%q) failed: %v", dsn, err)
			}
			if cfg.Addr != tc.want {
				t.Errorf("host %q: DSN %q dials %q, want %q", tc.host, dsn, cfg.Addr, tc.want)
			}
		})
	}
}
