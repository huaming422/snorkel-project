## Task

Stacked time-series bar charts with "Show Total" or "Only Total" are printing a total on each bar that's bigger than the bar itself.
It happens when the chart has no dimensions and "Sort by" is set to a metric that isn't one of the plotted metrics.
Sort by one of the plotted metrics, or turn sorting off, and the totals are right again.
Can you track this down and fix it?
