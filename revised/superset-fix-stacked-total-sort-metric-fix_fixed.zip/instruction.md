## Task

Stacked time-series bar charts with "Show Total" or "Only Total" are printing a total on each bar that's bigger than the bar itself.
It happens when the chart has no dimensions and "Sort by" uses a metric that isn't one of the plotted metrics, e.g. a helper metric we use to order bucketed x-axis values like 1-3d, 4-6d.
Sorting by one of the plotted metrics, or turning sorting off, gives the right totals.
We see the same thing when the sort metric has a verbose name set on the dataset.

Each bar should only show the metrics we picked to plot, and the total on top should be the sum of those, whether or not the sort metric has a verbose name.
