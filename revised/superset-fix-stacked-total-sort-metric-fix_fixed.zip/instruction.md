## Task

Stacked time-series bar charts with "Show Total" or "Only Total" are printing a total on each bar that's bigger than the bar itself.
We see it when the chart has no dimensions and "Sort by" uses a metric that isn't one of the metrics being plotted, e.g. a helper metric that orders bucketed x-axis values like 1-3d, 4-6d.
If you sort by one of the plotted metrics or turn sorting off, the totals are correct again.
It also happens when the sort metric has a verbose name set on the dataset, and in that case the sort metric also shows up as an extra segment in the bars.

Please fix it so a sort-only metric is never stacked or counted, with or without a verbose name, and the total on every bar equals the sum of the segments drawn in it.
Legend toggling should keep working the way it does now: a series you hide in the legend still drops out of the total.
