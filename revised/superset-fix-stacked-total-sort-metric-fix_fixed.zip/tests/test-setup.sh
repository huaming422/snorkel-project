#!/usr/bin/env bash
# test-setup.sh — sourced by tests/test.sh once before the verifier
# (set -euo pipefail inherited).
#
# This task exercises ONLY the React/TypeScript frontend (the
# plugin-chart-echarts Timeseries transform) via jest. There is no backend,
# database, or service to bring up. This script only makes the frontend
# node_modules available so the jest verifier can run, plus the small stubs the
# repo's jest setup expects.
#
# The image bakes node_modules + the npm cache at the base commit (§1.5), so the
# install below is offline-first: it must succeed with the network cut (the
# smoke gate's offline fold sources this script inside `docker run
# --network none`). The online branch is a logged fallback for a stale bake.

# Modal sandbox uses bash -c (non-login); bake in the full standard PATH so
# npm (/usr/local/bin/npm) and npx are always reachable regardless of how the
# parent process's PATH was initialised.
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin${PATH:+:$PATH}"

REPO=/repo/superset
FE="$REPO/superset-frontend"
cd "$FE"

# Make a cache miss fail fast instead of retrying against a dead network.
export npm_config_offline=true
export npm_config_cache=/opt/npm-cache

echo "[test-setup] $(date) — ensuring frontend dependencies (npm, offline-first)"
# --legacy-peer-deps mirrors the repo's own CI install and avoids peer-dep
# resolution failures across the workspace plugins/packages. Check each attempt's
# exit status directly (never `| tail`, which masks the exit code).
if [ -x "$FE/node_modules/.bin/jest" ]; then
    echo "[offline-first] node_modules already present from image bake"
elif npm_config_offline=true npm install --no-audit --no-fund --legacy-peer-deps \
        > /tmp/test-setup-install.log 2>&1; then
    echo "[offline-first] deps satisfied from image cache"
elif npm_config_offline=false npm install --no-audit --no-fund --legacy-peer-deps \
        >> /tmp/test-setup-install.log 2>&1; then
    echo "[test-setup] deps installed online (image bake was stale)"
else
    tail -60 /tmp/test-setup-install.log >&2; exit 1
fi

# npm install may rewrite package-lock.json as an infrastructure side effect.
# Mark it assume-unchanged so repo-integrity checks don't flag it as a dirty
# tree contamination from the agent.
git -C "$REPO" update-index --assume-unchanged superset-frontend/package-lock.json 2>/dev/null || true

# ace-builds stubs: the repo's jest setup (spec/helpers/setup.ts) mocks a few
# ace-builds submodules; npm install can wipe hand-created stubs, so (re)create
# them AFTER install. Harmless if unused by this transform's test.
mkdir -p node_modules/ace-builds/src-min-noconflict
echo 'module.exports = {};' > node_modules/ace-builds/src-min-noconflict/mode-handlebars.js

echo "[test-setup] verifying jest is runnable"
npx jest --version 2>&1 || echo "[test-setup] WARNING: npx jest not runnable from superset-frontend/"

echo "[test-setup] $(date) — done"
