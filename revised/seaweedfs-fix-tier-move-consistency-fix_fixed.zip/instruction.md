## Task

Some volumes we tier out to S3 from our busy volume servers aren't right afterwards.
Reads from them come back stale or missing, and once in a while a volume's metadata points at a remote object that doesn't match what the volume holds.
It's intermittent, and so far it has only shown up on volumes that the space-reclaiming vacuum was working on while the tier-up was still running.

These hosts run the Rust volume server, the `seaweed-volume` crate, so please fix it there and leave the Go volume server alone.
Find out why a tier-up can leave a volume out of step with the data it serves, and fix it.

Whatever order a tier-up and a vacuum end up running in on the same volume, the volume has to keep serving the data it really holds, and any remote reference it records has to match that data.
Here's what we expect once it's fixed:

- A tier-up that records its remote reference reports success.
- A tier-up that gets abandoned after its upload went through reports an error and deletes the object it uploaded, since we pay for every orphan left in that bucket.
- A tier-up asked for while a vacuum is already running on that volume is refused with an error right away, before anything is uploaded.
- A vacuum on a volume that's already on remote storage can still do its copy, but committing it must fail with an error while the volume keeps serving the same data.
- A vacuum on a volume that stays on local disk still commits the way it does today.
- Big uploads take minutes, so the volume being tiered still has to answer reads while its upload is running.
