//! External integration coverage for the interaction between a
//! tier-move-to-remote and a concurrent compaction on the same volume.
//!
//! The volume server is built from the public API exactly the way
//! `seaweed-volume/tests/http_integration.rs` builds it, and every scenario is
//! driven through the public `VolumeServer` gRPC surface (tier move, compact,
//! commit). A configurable in-process S3 endpoint lets each scenario order the
//! upload, the compaction and the metadata update deterministically, so none of
//! these assertions depend on a timing race.

use std::sync::Arc;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::time::Duration;

use seaweed_volume::pb::volume_server_pb;
use seaweed_volume::pb::volume_server_pb::volume_server_server::VolumeServer;
use seaweed_volume::remote_storage::s3_tier::{
    S3TierBackend, S3TierConfig, global_s3_tier_registry,
};
use seaweed_volume::security::{Guard, SigningKey};
use seaweed_volume::server::grpc_server::VolumeGrpcService;
use seaweed_volume::server::volume_server::{RuntimeMetricsConfig, VolumeServerState};
use seaweed_volume::storage::needle::Needle;
use seaweed_volume::storage::needle_map::NeedleMapKind;
use seaweed_volume::storage::store::Store;
use seaweed_volume::storage::types::{Cookie, DiskType, NeedleId, VolumeId};
use seaweed_volume::storage::volume::{VolumeError, VolumeSpec};

use std::sync::RwLock;
use tempfile::TempDir;
use tokio_stream::StreamExt;
use tonic::{Code, Request, Status};

// ---------------------------------------------------------------------------
// Service construction (public API only)
// ---------------------------------------------------------------------------

/// Build a volume server backed by a temp directory with a single empty
/// volume (id 1), returning the service, the temp dir and its path. Mirrors
/// the construction recipe in `tests/http_integration.rs`.
fn build_service() -> (VolumeGrpcService, TempDir, String) {
    let tmp = TempDir::new().expect("temp dir");
    let dir = tmp.path().to_str().unwrap().to_string();

    let mut store = Store::new(NeedleMapKind::InMemory);
    store
        .add_location(
            &dir,
            &dir,
            10,
            DiskType::HardDrive,
            seaweed_volume::config::MinFreeSpace::Percent(1.0),
            Vec::new(),
        )
        .expect("add location");
    store
        .add_volume(
            VolumeId(1),
            DiskType::HardDrive,
            &VolumeSpec {
                ..Default::default()
            },
        )
        .expect("add volume");

    let guard = Guard::new(&[], SigningKey(vec![]), 0, SigningKey(vec![]), 0);
    let state = Arc::new(VolumeServerState {
        store: RwLock::new(store),
        guard: RwLock::new(guard),
        is_stopping: RwLock::new(false),
        maintenance: std::sync::atomic::AtomicBool::new(false),
        state_version: std::sync::atomic::AtomicU32::new(0),
        concurrent_upload_limit: 0,
        concurrent_download_limit: 0,
        inflight_upload_data_timeout: std::time::Duration::from_secs(60),
        inflight_download_data_timeout: std::time::Duration::from_secs(60),
        inflight_upload_bytes: std::sync::atomic::AtomicI64::new(0),
        inflight_download_bytes: std::sync::atomic::AtomicI64::new(0),
        upload_notify: tokio::sync::Notify::new(),
        download_notify: tokio::sync::Notify::new(),
        data_center: String::new(),
        rack: String::new(),
        file_size_limit_bytes: 0,
        maintenance_byte_per_second: 0,
        is_heartbeating: std::sync::atomic::AtomicBool::new(true),
        has_master: false,
        pre_stop_seconds: 0,
        volume_state_notify: tokio::sync::Notify::new(),
        write_queue: std::sync::OnceLock::new(),
        read_mode: seaweed_volume::config::ReadMode::Local,
        allow_untrusted_remote_endpoints: true,
        master_url: String::new(),
        master_urls: Vec::new(),
        seed_master_set: std::collections::HashSet::new(),
        current_master_url: tokio::sync::RwLock::new(String::new()),
        self_url: String::new(),
        http_client: reqwest::Client::new(),
        outgoing_http_scheme: "http".to_string(),
        outgoing_grpc_tls: None,
        metrics_runtime: std::sync::RwLock::new(RuntimeMetricsConfig::default()),
        metrics_notify: tokio::sync::Notify::new(),
        fix_jpg_orientation: false,
        has_slow_read: false,
        read_buffer_size_bytes: 1024 * 1024,
        security_file: String::new(),
        cli_white_list: vec![],
        state_file_path: String::new(),
    });

    (VolumeGrpcService { state }, tmp, dir)
}

/// Write needles 1 and 2 and delete needle 1, leaving one live needle so a
/// compaction has something to rewrite and the result can be read back.
fn seed_volume(service: &VolumeGrpcService) {
    let mut store = service.state.store.write().unwrap();
    for id in [1u64, 2] {
        let data = format!("needle-{id}").into_bytes();
        let mut n = Needle {
            id: NeedleId(id),
            cookie: Cookie(id as u32),
            data_size: data.len() as u32,
            data,
            ..Needle::default()
        };
        store.write_volume_needle(VolumeId(1), &mut n, true).unwrap();
    }
    let mut dead = Needle {
        id: NeedleId(1),
        cookie: Cookie(1),
        ..Needle::default()
    };
    store.delete_volume_needle(VolumeId(1), &mut dead).unwrap();
}

/// The volume's current compaction revision.
fn compaction_revision(service: &VolumeGrpcService) -> u16 {
    let store = service.state.store.read().unwrap();
    store
        .find_volume(VolumeId(1))
        .unwrap()
        .1
        .super_block
        .compaction_revision
}

/// Read the single surviving needle (id 2) through the public store API.
fn read_surviving_needle(service: &VolumeGrpcService) -> Result<Vec<u8>, VolumeError> {
    let mut n = Needle {
        id: NeedleId(2),
        cookie: Cookie(2),
        ..Needle::default()
    };
    let store = service.state.store.read().unwrap();
    store.read_volume_needle(VolumeId(1), &mut n)?;
    Ok(n.data)
}

// ---------------------------------------------------------------------------
// Tier-move helpers
// ---------------------------------------------------------------------------

fn tier_up_request(
    backend: &str,
    keep_local_dat_file: bool,
) -> Request<volume_server_pb::VolumeTierMoveDatToRemoteRequest> {
    Request::new(volume_server_pb::VolumeTierMoveDatToRemoteRequest {
        volume_id: 1,
        collection: String::new(),
        destination_backend_name: backend.to_string(),
        keep_local_dat_file,
    })
}

fn register_backend(name: &str, endpoint: String) {
    global_s3_tier_registry().write().unwrap().register(
        name.to_string(),
        S3TierBackend::new(&S3TierConfig {
            access_key: "access".to_string(),
            secret_key: "secret".to_string(),
            region: "us-east-1".to_string(),
            bucket: "bucket-a".to_string(),
            endpoint,
            storage_class: "STANDARD".to_string(),
            force_path_style: true,
        }),
    );
}

fn unregister_backend(name: &str) {
    global_s3_tier_registry().write().unwrap().remove(name);
}

/// Drain a tier-move response stream and return its terminal error, if any.
async fn drain_tier_move<S>(mut stream: S) -> Option<Status>
where
    S: tokio_stream::Stream<
            Item = Result<volume_server_pb::VolumeTierMoveDatToRemoteResponse, Status>,
        > + Unpin,
{
    let mut terminal = None;
    while let Some(message) = stream.next().await {
        if let Err(e) = message {
            terminal = Some(e);
        }
    }
    terminal
}

/// Attempt a tier move and reduce both refusal shapes to a single error: the
/// call itself may reject synchronously, or the spawned transfer may report a
/// terminal error on the stream. Returns the error if the move did not record
/// its destination.
async fn attempt_tier_move(
    service: &VolumeGrpcService,
    backend: &str,
    keep_local: bool,
) -> Option<Status> {
    match service
        .volume_tier_move_dat_to_remote(tier_up_request(backend, keep_local))
        .await
    {
        Err(status) => Some(status),
        Ok(response) => drain_tier_move(response.into_inner()).await,
    }
}

/// Run a full tier-move to completion against a backend that answers every
/// request, leaving the volume backed by the remote object. Returns the
/// terminal error if the move did not succeed.
async fn tier_to_remote(service: &VolumeGrpcService, backend: &str) -> Option<Status> {
    attempt_tier_move(service, backend, true).await
}

// ---------------------------------------------------------------------------
// Compaction helpers (driven through the gRPC surface)
// ---------------------------------------------------------------------------

/// Run a compaction to completion through the RPC, draining its progress
/// stream. Returns the error it reported, whether the call itself was refused
/// or the stream ended with an error.
async fn compact_outcome(service: &VolumeGrpcService) -> Option<Status> {
    let mut stream = match service
        .vacuum_volume_compact(Request::new(volume_server_pb::VacuumVolumeCompactRequest {
            volume_id: 1,
            preallocate: 0,
        }))
        .await
    {
        Err(status) => return Some(status),
        Ok(response) => response.into_inner(),
    };
    let mut terminal = None;
    while let Some(message) = stream.next().await {
        if let Err(e) = message {
            terminal = Some(e);
        }
    }
    terminal
}

/// Run a compaction to completion through the RPC; it must not report an error.
async fn compact(service: &VolumeGrpcService) {
    if let Some(e) = compact_outcome(service).await {
        panic!("the compaction must run without error: {e:?}");
    }
}

/// Commit a compaction through the RPC. Returns the terminal error if the
/// commit was refused.
async fn commit_compaction(service: &VolumeGrpcService) -> Option<Status> {
    service
        .vacuum_volume_commit(Request::new(volume_server_pb::VacuumVolumeCommitRequest {
            volume_id: 1,
        }))
        .await
        .err()
}

// ---------------------------------------------------------------------------
// Configurable in-process S3 endpoint
// ---------------------------------------------------------------------------

/// An S3-compatible endpoint that can hold multipart part uploads and/or
/// range reads until the test releases them, so an upload or a remote read can
/// be interleaved with other operations deterministically.
struct FakeS3 {
    endpoint: String,
    shutdown: tokio::sync::oneshot::Sender<()>,
    /// Signals the arrival of each multipart part before it is answered.
    put_parked: tokio::sync::mpsc::UnboundedReceiver<()>,
    /// Signals the arrival of each range read before it is answered.
    get_parked: tokio::sync::mpsc::UnboundedReceiver<()>,
    /// One permit releases one held part.
    put_gate: Arc<tokio::sync::Semaphore>,
    /// One permit releases one held range read.
    get_gate: Arc<tokio::sync::Semaphore>,
    delete_count: Arc<AtomicUsize>,
}

/// `put_permits`/`get_permits` set how many of each request pass without being
/// held; use a large number to never hold that verb, or 0 to hold it until the
/// test adds permits. `body` is what range reads return.
fn spawn_fake_s3(body: Vec<u8>, put_permits: usize, get_permits: usize) -> FakeS3 {
    use axum::Router;
    use axum::http::{Method, StatusCode, Uri, header};
    use axum::response::{IntoResponse, Response};
    use axum::routing::any;

    let body = Arc::new(body);
    let listener = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
    let addr = listener.local_addr().unwrap();
    listener.set_nonblocking(true).unwrap();

    let (shutdown, shutdown_rx) = tokio::sync::oneshot::channel::<()>();
    let (put_parked_tx, put_parked) = tokio::sync::mpsc::unbounded_channel();
    let (get_parked_tx, get_parked) = tokio::sync::mpsc::unbounded_channel();
    let put_gate = Arc::new(tokio::sync::Semaphore::new(put_permits));
    let get_gate = Arc::new(tokio::sync::Semaphore::new(get_permits));
    let delete_count = Arc::new(AtomicUsize::new(0));
    let (ready_tx, ready_rx) = std::sync::mpsc::channel::<()>();

    let h_put_gate = put_gate.clone();
    let h_get_gate = get_gate.clone();
    let h_deletes = delete_count.clone();

    std::thread::spawn(move || {
        let runtime = tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .unwrap();
        runtime.block_on(async move {
            let app = Router::new().fallback(any(
                move |method: Method, uri: Uri, headers: axum::http::HeaderMap| {
                    let body = body.clone();
                    let put_parked_tx = put_parked_tx.clone();
                    let get_parked_tx = get_parked_tx.clone();
                    let put_gate = h_put_gate.clone();
                    let get_gate = h_get_gate.clone();
                    let deletes = h_deletes.clone();
                    async move {
                        let query = uri.query().unwrap_or_default().to_string();
                        let etag = [(header::ETAG, "\"etag\"")];
                        match method {
                            Method::DELETE => {
                                deletes.fetch_add(1, Ordering::SeqCst);
                                (StatusCode::NO_CONTENT, etag, String::new()).into_response()
                            }
                            Method::POST if query.contains("uploads") => (
                                StatusCode::OK,
                                etag,
                                "<InitiateMultipartUploadResult><Bucket>bucket-a</Bucket>\
                                 <Key>k</Key><UploadId>upload-1</UploadId>\
                                 </InitiateMultipartUploadResult>"
                                    .to_string(),
                            )
                                .into_response(),
                            Method::PUT if query.contains("partNumber") => {
                                let _ = put_parked_tx.send(());
                                put_gate.acquire().await.unwrap().forget();
                                (StatusCode::OK, etag, String::new()).into_response()
                            }
                            Method::POST => (
                                StatusCode::OK,
                                etag,
                                "<CompleteMultipartUploadResult><Bucket>bucket-a</Bucket>\
                                 <Key>k</Key><ETag>\"etag\"</ETag>\
                                 </CompleteMultipartUploadResult>"
                                    .to_string(),
                            )
                                .into_response(),
                            Method::GET => {
                                let _ = get_parked_tx.send(());
                                get_gate.acquire().await.unwrap().forget();
                                let bytes = body.as_ref();
                                if let Some(range) = headers
                                    .get(header::RANGE)
                                    .and_then(|v| v.to_str().ok())
                                    .and_then(|v| v.strip_prefix("bytes="))
                                {
                                    let mut parts = range.splitn(2, '-');
                                    let start = parts
                                        .next()
                                        .and_then(|v| v.parse::<usize>().ok())
                                        .unwrap_or(0)
                                        .min(bytes.len());
                                    let end = parts
                                        .next()
                                        .and_then(|v| v.parse::<usize>().ok())
                                        .unwrap_or_else(|| bytes.len().saturating_sub(1))
                                        .min(bytes.len().saturating_sub(1));
                                    let payload = if start > end || start >= bytes.len() {
                                        Vec::new()
                                    } else {
                                        bytes[start..=end].to_vec()
                                    };
                                    let mut rh = axum::http::HeaderMap::new();
                                    rh.insert(
                                        header::CONTENT_RANGE,
                                        axum::http::HeaderValue::from_str(&format!(
                                            "bytes {}-{}/{}",
                                            start,
                                            end,
                                            bytes.len()
                                        ))
                                        .unwrap(),
                                    );
                                    (StatusCode::PARTIAL_CONTENT, rh, payload).into_response()
                                } else {
                                    (StatusCode::OK, bytes.to_vec()).into_response()
                                }
                            }
                            _ => (StatusCode::NOT_FOUND, etag, String::new()).into_response(),
                        }
                    }
                },
            ));
            let listener = tokio::net::TcpListener::from_std(listener).unwrap();
            let _ = ready_tx.send(());
            let _ = axum::serve(listener, app)
                .with_graceful_shutdown(async move {
                    let _ = shutdown_rx.await;
                })
                .await;
        });
    });
    ready_rx.recv().unwrap();

    FakeS3 {
        endpoint: format!("http://{}", addr),
        shutdown,
        put_parked,
        get_parked,
        put_gate,
        get_gate,
        delete_count,
    }
}

// ===========================================================================
// 1. A tier-move that finishes while a compaction replaced the volume's files
//    must not publish a remote reference that disagrees with the live volume.
// ===========================================================================
#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn tier_move_compaction_consistency() {
    let (service, _tmp, dir) = build_service();
    seed_volume(&service);

    // The compaction revision before the move starts. A move may only publish a
    // remote reference if the concurrent compaction did not take effect; once a
    // compaction commits, the revision advances and the uploaded bytes no longer
    // describe the live volume.
    let rev_before = compaction_revision(&service);

    // Serve the real pre-operation .dat bytes on range reads so a design that
    // serializes the move against the compaction (recording a consistent remote
    // reference and reading it back) resolves to the correct data, rather than
    // being rejected for reading an empty object.
    let dat_bytes = std::fs::read(format!("{dir}/1.dat")).expect("read dat");

    // Hold the single part upload so a compaction can land before the move
    // records its result.
    let mut s3 = spawn_fake_s3(dat_bytes, 0, usize::MAX >> 4);
    register_backend("s3.consistency", s3.endpoint.clone());

    let stream = service
        .volume_tier_move_dat_to_remote(tier_up_request("s3.consistency", true))
        .await
        .expect("tier move must start")
        .into_inner();
    s3.put_parked.recv().await.expect("the upload must reach its part");

    // The store stays available while the upload is in flight: the volume being
    // moved still answers reads.
    assert!(
        service.state.store.try_read().is_ok(),
        "the store must not stay locked while the upload is in flight"
    );
    assert_eq!(
        read_surviving_needle(&service).expect("the volume must answer reads mid-upload"),
        b"needle-2"
    );

    // Compact and commit the same volume while the upload is held. The server
    // may run both (rewriting the files and advancing the revision underneath
    // the move), turn either one away, or skip it while the move is in flight.
    // If the vacuum waits for the move to finish instead, the upload is released
    // after a grace period so the two complete in whatever order the server
    // allows.
    let vacuum_service = VolumeGrpcService {
        state: service.state.clone(),
    };
    let mut vacuum = tokio::spawn(async move {
        compact_outcome(&vacuum_service).await;
        commit_compaction(&vacuum_service).await;
    });
    let vacuum_finished = tokio::time::timeout(Duration::from_secs(10), &mut vacuum).await;

    s3.put_gate.add_permits(1);
    let terminal = drain_tier_move(stream).await;
    match vacuum_finished {
        Ok(joined) => joined.expect("the vacuum task must not panic"),
        Err(_) => vacuum.await.expect("the vacuum task must not panic"),
    }

    unregister_backend("s3.consistency");

    // The invariant is consistency, not a particular resolution strategy. Two
    // outcomes keep the volume and its remote reference in agreement:
    //
    //  * Abort: the move records no remote reference, deletes the object it
    //    uploaded, and reports a terminal error.
    //  * Serialize: the compaction does not take effect while the move is in
    //    flight (it is refused, skipped or held back), so the move records a
    //    remote reference that still matches what the volume serves.
    //
    // A recorded reference is only consistent with the live volume if the
    // compaction did not take effect, so the revision must be unchanged.
    let recorded;
    let rev_after;
    {
        let store = service.state.store.read().unwrap();
        let (_, vol) = store.find_volume(VolumeId(1)).unwrap();
        recorded = vol.has_remote_file();
        rev_after = vol.super_block.compaction_revision;
        assert_eq!(
            recorded,
            !vol.volume_info().files.is_empty(),
            "has_remote_file() must agree with the recorded remote file list"
        );
    }

    if recorded {
        // Serialize path: a remote reference was published, so the move must have
        // completed without error, and the compaction must not have taken effect.
        assert!(
            terminal.is_none(),
            "a move that published a remote reference must not also report failure"
        );
        assert_eq!(
            rev_after, rev_before,
            "a remote reference may only be published when the move serialized \
             against the compaction (the compaction did not take effect); a \
             reference recorded across a committed compaction is stale"
        );
    } else {
        // Abort path: nothing was published, so the orphaned upload must have been
        // cleaned up and the move must have reported that it did not complete.
        assert!(
            s3.delete_count.load(Ordering::SeqCst) >= 1,
            "the uploaded object must be removed when the move is abandoned"
        );
        assert!(
            terminal.is_some(),
            "the move must report that it did not complete"
        );
    }

    // In either resolution, the live volume must still serve the surviving needle
    // correctly.
    assert_eq!(read_surviving_needle(&service).unwrap(), b"needle-2");

    let _ = s3.shutdown.send(());
}

// ===========================================================================
// 2. A compaction still runs on a volume already tiered to remote storage, but
//    committing it is refused and the volume keeps serving the same data.
// ===========================================================================
#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn commit_refused_when_tiered() {
    let (service, _tmp, dir) = build_service();
    seed_volume(&service);

    // The endpoint serves the real data bytes so a compaction reading the
    // remote object rebuilds valid needles.
    let dat_bytes = std::fs::read(format!("{dir}/1.dat")).expect("read dat");
    let s3 = spawn_fake_s3(dat_bytes, usize::MAX >> 4, usize::MAX >> 4);
    register_backend("s3.tiered_commit", s3.endpoint.clone());

    // Move the volume to remote storage (keeping the local file), so the volume
    // is now served from the remote object.
    assert!(
        tier_to_remote(&service, "s3.tiered_commit").await.is_none(),
        "the initial tier move must succeed"
    );
    {
        let store = service.state.store.read().unwrap();
        assert!(store.find_volume(VolumeId(1)).unwrap().1.has_remote_file());
    }

    // Compact the now-remote volume, then attempt to commit through the RPC.
    compact(&service).await;
    let commit_error = commit_compaction(&service).await;

    let read = read_surviving_needle(&service);

    unregister_backend("s3.tiered_commit");
    let _ = s3.shutdown.send(());

    assert!(
        commit_error.is_some(),
        "a tiered volume must not accept a compaction commit"
    );
    assert_eq!(
        read.expect("the surviving needle must still be readable"),
        b"needle-2",
        "reads must remain consistent after the refused commit"
    );
}

// ===========================================================================
// 3. A tier-move started while the volume is already compacting is refused
//    with an error, uploads nothing and records nothing.
// ===========================================================================
#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn tier_move_refused_while_compacting() {
    let (service, _tmp, dir) = build_service();
    seed_volume(&service);

    // Serve the data bytes on reads, but hold reads so the compaction copy
    // parks in progress (and keeps the volume marked compacting). Uploads are
    // never held.
    let dat_bytes = std::fs::read(format!("{dir}/1.dat")).expect("read dat");
    let mut s3 = spawn_fake_s3(dat_bytes, usize::MAX >> 4, 0);
    register_backend("s3.compacting_first", s3.endpoint.clone());
    register_backend("s3.compacting_second", s3.endpoint.clone());

    // Tier the volume so its data lives remote; the compaction below then reads
    // the remote object, which we hold mid-copy.
    assert!(
        tier_to_remote(&service, "s3.compacting_first")
            .await
            .is_none(),
        "the initial tier move must succeed"
    );

    // Start a compaction through the RPC: the copy runs off the store lock, so
    // the volume reports compacting while this read is held.
    let _compact_stream = service
        .vacuum_volume_compact(Request::new(volume_server_pb::VacuumVolumeCompactRequest {
            volume_id: 1,
            preallocate: 0,
        }))
        .await
        .expect("compaction must start")
        .into_inner();
    tokio::time::timeout(Duration::from_secs(60), s3.get_parked.recv())
        .await
        .expect("the compaction must reach a remote read")
        .expect("the endpoint must still be running");
    {
        let store = service.state.store.read().unwrap();
        assert!(
            store.find_volume(VolumeId(1)).unwrap().1.is_compacting(),
            "the volume must be compacting before the move is attempted"
        );
    }

    // Forget the parts the first move uploaded, so any part seen from here on
    // belongs to the second move.
    while s3.put_parked.try_recv().is_ok() {}

    // A move to a different destination, while the volume is compacting.
    let terminal = attempt_tier_move(&service, "s3.compacting_second", true).await;
    assert!(
        s3.put_parked.try_recv().is_err(),
        "a move attempted during compaction must not upload anything"
    );

    // The move must have been refused and must not have recorded a second
    // remote reference.
    {
        let store = service.state.store.read().unwrap();
        let (_, vol) = store.find_volume(VolumeId(1)).unwrap();
        assert_eq!(
            vol.volume_info().files.len(),
            1,
            "a move attempted during compaction must not record anything"
        );
        let (_, second_id) =
            seaweed_volume::remote_storage::s3_tier::backend_name_to_type_id("s3.compacting_second");
        assert!(
            !vol.volume_info()
                .files
                .iter()
                .any(|f| f.backend_id == second_id),
            "the second destination must not appear in the volume's remote files"
        );
    }
    assert!(
        terminal.is_some(),
        "a move during compaction must report a failure"
    );
    if let Some(status) = &terminal {
        assert_ne!(
            status.code(),
            Code::Ok,
            "the move must not report success while compacting"
        );
    }

    // Let the held compaction finish and clean up.
    s3.get_gate.add_permits(1024);
    unregister_backend("s3.compacting_first");
    unregister_backend("s3.compacting_second");
    let _ = s3.shutdown.send(());
}

// ===========================================================================
// 4. A compaction on a volume that stays on local disk still commits.
// ===========================================================================
#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn local_compaction_still_commits() {
    let (service, _tmp, _dir) = build_service();
    seed_volume(&service);
    let rev_before = compaction_revision(&service);

    compact(&service).await;
    commit_compaction(&service)
        .await
        .map_or((), |e| panic!("the compaction commit must succeed: {e:?}"));

    assert_eq!(
        compaction_revision(&service),
        rev_before + 1,
        "a committed compaction advances the volume's revision"
    );
    assert_eq!(
        read_surviving_needle(&service).expect("the surviving needle must be readable"),
        b"needle-2"
    );
}
