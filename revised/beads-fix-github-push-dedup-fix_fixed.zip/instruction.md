## Task

Our GitHub sync keeps burning the shared API rate limit on routine runs.
Running `bd github sync --push-only` twice in a row with nothing changed locally writes every linked issue back to GitHub on the second run and again says it pushed all of them, even though GitHub already has exactly that content.
`bd github push <id>` does the same for a single bead and reports it as updated every time.
Please work out why repeated pushes keep re-sending issues GitHub already has, and fix it for both commands.
After the fix, re-pushing beads I haven't touched shouldn't make any request for them on GitHub.
GitHub hands labels back in its own order, so the same labels in a different order are not a change.
Neither command should report them as pushed or updated, and `bd github push` should count them as skipped in its summary.
A real local edit, like a new title, still has to go out on the next push.
We also relink beads now and then and switch github.owner or github.repo between our main and staging repos, and the first push after either of those should still go to GitHub for the issues involved.
