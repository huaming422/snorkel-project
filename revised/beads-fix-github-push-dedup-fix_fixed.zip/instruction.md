## Task

Our GitHub sync keeps eating the shared API rate limit on routine runs.
If I run `bd github sync --push-only` and then run it again straight away with nothing changed locally, the second run still writes every linked issue back to GitHub.
`bd github push <id>` behaves the same way for one issue, and pushing it a second time reports it as updated again.
Please work out why repeated pushes keep re-sending unchanged issues and make a no-op re-push cheap on both commands.

What I expect after the fix:

- An issue that hasn't changed locally since its last push should not be fetched or written on GitHub when I push again, and the summary should count it as skipped, not updated.
- A real local edit, like a new title, still goes out as an update on the next push.
- If I relink an issue to a different GitHub issue, or point the config at another owner or repo, the next push should check that issue on GitHub again instead of assuming it is already in sync.
- When bd does compare against GitHub, it should only write if the title, body, open or closed state, or the set of labels is different.
- GitHub doesn't keep label order, so the same labels coming back in another order is not a change.
