#!/usr/bin/env bash
# Everything the checks need is baked into the image at build time: the Go
# toolchain, libicu-dev, build-essential, the warmed Go module and build cache
# under /opt/cache, and the compiled test tree. Nothing is installed at test
# time, so this stays a no-op that runs fine with the network cut.
set -euo pipefail
echo "[test-setup] no-op for beads-fix-github-push-dedup (deps baked into image)"
