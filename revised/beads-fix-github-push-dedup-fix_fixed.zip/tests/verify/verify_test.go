// Black-box checks for `bd github push` and `bd github sync --push-only`.
//
// These checks drive the real `bd` command-line tool end to end against an
// in-process stand-in for the GitHub REST API. They observe only what an
// operator can observe:
//
//   - the REST traffic the stand-in receives (how many issue fetches / writes),
//   - the machine-readable sync summary `bd --json github push` prints
//     (created / updated / skipped counts).
//
// Only the command-line interface and the GitHub REST contract are used. No
// source identifier, struct field, file path or internal symbol is read.
//
// The stand-in reports a fixed `updated_at` in the past for every issue, so the
// remote copy never looks newer than the local one. An issue that has not
// changed locally since its last push is expected to cause no fetch and no
// write on the next push.
//
// This file owns TestMain, so the shared test runner compiles it in isolation
// from the package's other test files. It builds `bd` once, then each check
// runs in its own throwaway home + project directory with its own stand-in
// server.

package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"testing"
)

// bdBin is the path to the `bd` executable built once in TestMain.
var bdBin string

func TestMain(m *testing.M) {
	dir, err := os.MkdirTemp("", "bd-build-")
	if err != nil {
		fmt.Fprintf(os.Stderr, "setup: mkdir temp: %v\n", err)
		os.Exit(1)
	}
	bin := filepath.Join(dir, "bd")

	// Build the CLI from the package under test. Working directory for a Go
	// test is the package's own source directory (cmd/bd), so "." is the
	// command's main package. The embedded on-disk store needs cgo; the build
	// tag and CGO setting come from the runner environment and are inherited.
	build := exec.Command("go", "build", "-tags", "gms_pure_go", "-o", bin, ".")
	build.Env = os.Environ()
	if out, err := build.CombinedOutput(); err != nil {
		fmt.Fprintf(os.Stderr, "setup: build bd failed: %v\n%s\n", err, out)
		os.Exit(1)
	}
	bdBin = bin

	code := m.Run()
	_ = os.RemoveAll(dir)
	os.Exit(code)
}

// ----------------------------------------------------------------------------
// GitHub REST stand-in
// ----------------------------------------------------------------------------

// remoteIssue is the stand-in's stored view of one remote issue. It mirrors the
// shape the GitHub REST contract returns so the real client can parse it; the
// field values are whatever the command sent on create/update, so this file
// never hardcodes label text or titles.
type remoteIssue struct {
	number int
	title  string
	body   string
	state  string
	labels []string
}

// ghStub is an in-process stand-in for the GitHub REST endpoints the push path
// uses: create issue (POST), fetch issue by number (GET), update issue (PATCH).
// It counts each kind of call so a check can assert how much remote traffic a
// push produced.
type ghStub struct {
	mu      sync.Mutex
	posts   int
	gets    int
	patches int

	nextNumber int
	issues     map[int]*remoteIssue

	// getTransform, when set, rewrites the issue a fetch returns. It models a
	// remote whose stored representation differs from the local one (for
	// example labels in a different order, or a different field value) so a
	// check can observe whether the command treats the push as a no-op or a
	// real change. It does not mutate stored state.
	getTransform func(in remoteIssue) remoteIssue

	server *httptest.Server
}

func newGHStub() *ghStub {
	s := &ghStub{nextNumber: 0, issues: map[int]*remoteIssue{}}
	s.server = httptest.NewServer(http.HandlerFunc(s.handle))
	return s
}

func (s *ghStub) close() { s.server.Close() }

func (s *ghStub) url() string { return s.server.URL }

// counts returns and resets the per-call counters. Call it immediately before a
// push to measure only that push's traffic.
func (s *ghStub) resetCounts() {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.posts, s.gets, s.patches = 0, 0, 0
}

func (s *ghStub) snapshot() (posts, gets, patches int) {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.posts, s.gets, s.patches
}

// lastCreated returns the number of the most recently created remote issue.
func (s *ghStub) lastCreated() int {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.nextNumber
}

func (s *ghStub) setGetTransform(f func(in remoteIssue) remoteIssue) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.getTransform = f
}

// issueNumberFromPath extracts the trailing numeric id from a
// .../issues/<n> path, or -1 if the path does not end in a number.
func issueNumberFromPath(p string) int {
	p = strings.SplitN(p, "?", 2)[0]
	p = strings.TrimRight(p, "/")
	idx := strings.LastIndex(p, "/")
	if idx < 0 {
		return -1
	}
	n, err := strconv.Atoi(p[idx+1:])
	if err != nil {
		return -1
	}
	return n
}

func (s *ghStub) handle(w http.ResponseWriter, r *http.Request) {
	body, _ := readBody(r)
	path := strings.SplitN(r.URL.Path, "?", 2)[0]

	s.mu.Lock()
	defer s.mu.Unlock()

	switch {
	case r.Method == http.MethodPost && strings.HasSuffix(path, "/issues"):
		s.posts++
		s.nextNumber++
		n := s.nextNumber
		iss := &remoteIssue{
			number: n,
			title:  jsonString(body, "title"),
			body:   jsonString(body, "body"),
			state:  "open",
			labels: jsonStringSlice(body, "labels"),
		}
		s.issues[n] = iss
		writeIssue(w, http.StatusCreated, *iss)

	case r.Method == http.MethodGet && strings.Contains(path, "/issues/"):
		n := issueNumberFromPath(path)
		if n < 0 {
			// Not an issue fetch; return something harmless and do not count it.
			writeJSON(w, http.StatusOK, map[string]any{})
			return
		}
		s.gets++
		iss := s.issues[n]
		if iss == nil {
			iss = &remoteIssue{number: n, state: "open"}
		}
		out := *iss
		if s.getTransform != nil {
			out = s.getTransform(*iss)
		}
		writeIssue(w, http.StatusOK, out)

	case r.Method == http.MethodPatch && strings.Contains(path, "/issues/"):
		n := issueNumberFromPath(path)
		s.patches++
		if n >= 0 {
			cur := s.issues[n]
			if cur == nil {
				cur = &remoteIssue{number: n}
				s.issues[n] = cur
			}
			if v := jsonString(body, "title"); v != "" {
				cur.title = v
			}
			if v := jsonString(body, "body"); v != "" {
				cur.body = v
			}
			if v := jsonString(body, "state"); v != "" {
				cur.state = v
			}
			if v := jsonStringSlice(body, "labels"); v != nil {
				cur.labels = v
			}
			writeIssue(w, http.StatusOK, *cur)
			return
		}
		writeJSON(w, http.StatusOK, map[string]any{})

	default:
		writeJSON(w, http.StatusOK, map[string]any{})
	}
}

func readBody(r *http.Request) (map[string]any, error) {
	if r.Body == nil {
		return map[string]any{}, nil
	}
	var buf bytes.Buffer
	if _, err := buf.ReadFrom(r.Body); err != nil {
		return map[string]any{}, err
	}
	m := map[string]any{}
	if buf.Len() == 0 {
		return m, nil
	}
	_ = json.Unmarshal(buf.Bytes(), &m)
	return m, nil
}

func jsonString(m map[string]any, key string) string {
	if v, ok := m[key].(string); ok {
		return v
	}
	return ""
}

func jsonStringSlice(m map[string]any, key string) []string {
	raw, ok := m[key].([]any)
	if !ok {
		return nil
	}
	out := make([]string, 0, len(raw))
	for _, e := range raw {
		if s, ok := e.(string); ok {
			out = append(out, s)
		}
	}
	return out
}

// writeIssue serializes a remoteIssue in the GitHub REST shape the client
// parses. html_url is omitted on purpose: with no URL the client stores the
// "github:<n>" shorthand reference, which the fetch/update path recognizes, and
// this sidesteps the real-URL recognition rule. Both remote timestamps are
// fixed in the past.
func writeIssue(w http.ResponseWriter, status int, iss remoteIssue) {
	labels := make([]map[string]any, 0, len(iss.labels))
	for i, name := range iss.labels {
		labels = append(labels, map[string]any{"id": 1000 + i, "name": name})
	}
	state := iss.state
	if state == "" {
		state = "open"
	}
	writeJSON(w, status, map[string]any{
		"id":         1000 + iss.number,
		"number":     iss.number,
		"title":      iss.title,
		"body":       iss.body,
		"state":      state,
		"labels":     labels,
		"created_at": "2000-01-01T00:00:00Z",
		"updated_at": "2000-01-01T00:00:00Z",
		"closed_at":  nil,
	})
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	b, _ := json.Marshal(v)
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_, _ = w.Write(b)
}

// ----------------------------------------------------------------------------
// bd command-line driver
// ----------------------------------------------------------------------------

// world is one isolated bd project: a fresh home + working directory with its
// own on-disk store, pointed at one stand-in server. The configured repository
// is mutable so a check can change the remote target between pushes.
type world struct {
	t     *testing.T
	dir   string
	stub  *ghStub
	owner string
	repo  string
}

func newWorld(t *testing.T, stub *ghStub) *world {
	t.Helper()
	dir := t.TempDir()
	w := &world{t: t, dir: dir, stub: stub, owner: "acme", repo: "widgets"}
	w.run("init project", bdBin, "init", "--quiet")
	return w
}

// env builds a clean environment: the real repository/credential settings are
// supplied here (not through any on-disk config), the home and project are the
// throwaway directory, and the embedded store runs in-process with no daemon.
func (w *world) env() []string {
	var out []string
	for _, kv := range os.Environ() {
		key := kv
		if i := strings.IndexByte(kv, '='); i >= 0 {
			key = kv[:i]
		}
		switch {
		case strings.HasPrefix(key, "BEADS_"),
			strings.HasPrefix(key, "GITHUB_"),
			strings.HasPrefix(key, "GH_"),
			key == "HOME":
			continue
		}
		out = append(out, kv)
	}
	out = append(out,
		"HOME="+w.dir,
		"BEADS_DOLT_AUTO_START=0",
		"BEADS_NO_DAEMON=1",
		"BD_DISABLE_METRICS=1",
		"BD_DISABLE_EVENT_FLUSH=1",
		"GITHUB_TOKEN=stub-token",
		"GITHUB_OWNER="+w.owner,
		"GITHUB_REPO="+w.repo,
		"GITHUB_API_URL="+w.stub.url(),
	)
	return out
}

// run executes a bd command, failing the check on a non-zero exit. Returns
// trimmed stdout.
func (w *world) run(what string, name string, args ...string) string {
	w.t.Helper()
	cmd := exec.Command(name, args...)
	cmd.Dir = w.dir
	cmd.Env = w.env()
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr
	if err := cmd.Run(); err != nil {
		w.t.Fatalf("%s: `%s %s` failed: %v\nstdout:\n%s\nstderr:\n%s",
			what, name, strings.Join(args, " "), err, stdout.String(), stderr.String())
	}
	return strings.TrimSpace(stdout.String())
}

// createIssue creates a local issue and returns its id.
func (w *world) createIssue(title, body string) string {
	w.t.Helper()
	id := w.run("create issue", bdBin, "create", title, "-d", body, "--silent")
	id = lastLine(id)
	if id == "" {
		w.t.Fatalf("create issue: empty id returned")
	}
	return id
}

func lastLine(s string) string {
	lines := strings.Split(strings.TrimSpace(s), "\n")
	for i := len(lines) - 1; i >= 0; i-- {
		if t := strings.TrimSpace(lines[i]); t != "" {
			return t
		}
	}
	return ""
}

// pushStats is the summary printed by `bd --json github push`.
type pushStats struct {
	Created int
	Updated int
	Skipped int
}

type syncResult struct {
	Stats struct {
		Created int `json:"created"`
		Updated int `json:"updated"`
		Skipped int `json:"skipped"`
		Pushed  int `json:"pushed"`
	} `json:"stats"`
}

// push runs a machine-readable push of a single issue and returns its summary.
func (w *world) push(id string) pushStats {
	w.t.Helper()
	cmd := exec.Command(bdBin, "--json", "github", "push", id)
	cmd.Dir = w.dir
	cmd.Env = w.env()
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr
	if err := cmd.Run(); err != nil {
		w.t.Fatalf("push %s failed: %v\nstdout:\n%s\nstderr:\n%s",
			id, err, stdout.String(), stderr.String())
	}
	res := parseSyncResult(w.t, stdout.String())
	return pushStats{Created: res.Stats.Created, Updated: res.Stats.Updated, Skipped: res.Stats.Skipped}
}

func parseSyncResult(t *testing.T, out string) syncResult {
	t.Helper()
	start := strings.IndexByte(out, '{')
	end := strings.LastIndexByte(out, '}')
	if start < 0 || end < start {
		t.Fatalf("push output is not JSON:\n%s", out)
	}
	var res syncResult
	if err := json.Unmarshal([]byte(out[start:end+1]), &res); err != nil {
		t.Fatalf("decode push output: %v\n%s", err, out)
	}
	return res
}

// syncPushOnly runs a push-only sync over every local issue. This is a separate
// command from the single-issue push above and prints only human-readable text,
// so callers observe its effect through the stand-in's REST counters rather than
// a parsed summary.
func (w *world) syncPushOnly() {
	w.t.Helper()
	w.run("push-only sync", bdBin, "github", "sync", "--push-only")
}

// pushCommand is one of the two commands that push local issues to GitHub.
// The checks for local edits, relinks, target changes and content comparison
// run under both.
type pushCommand struct {
	name string
	// hasSummary is true when the command prints a parsed created / updated /
	// skipped summary. The push-only sync prints only text, so under it a
	// check relies on the REST counters alone.
	hasSummary bool
}

var pushCommands = []pushCommand{
	{name: "github_push", hasSummary: true},
	{name: "sync_push_only", hasSummary: false},
}

// traffic is the REST traffic one push produced.
type traffic struct {
	posts, gets, patches int
}

// pushWith pushes the issue through the given command and returns the summary
// (all zero when the command prints none) and the traffic that push produced.
func (w *world) pushWith(c pushCommand, id string) (pushStats, traffic) {
	w.t.Helper()
	w.stub.resetCounts()
	var st pushStats
	if c.hasSummary {
		st = w.push(id)
	} else {
		w.syncPushOnly()
	}
	posts, gets, patches := w.stub.snapshot()
	return st, traffic{posts: posts, gets: gets, patches: patches}
}

// firstPushWith pushes a not yet linked issue and stops the check unless the
// push created it on the remote.
func (w *world) firstPushWith(c pushCommand, id string) {
	w.t.Helper()
	st, tr := w.pushWith(c, id)
	if tr.posts < 1 || (c.hasSummary && st.Created < 1) {
		w.t.Fatalf("first push: expected the issue to be created on the remote, got creates=%d summary=%+v", tr.posts, st)
	}
}

// expectNoop fails the check unless the push made no fetch and no write and,
// when the command prints a summary, counted the issue as skipped.
func expectNoop(t *testing.T, c pushCommand, what string, st pushStats, tr traffic) {
	t.Helper()
	if tr.gets != 0 || tr.patches != 0 {
		t.Errorf("%s: made %d fetch(es) and %d write(s), want 0 and 0", what, tr.gets, tr.patches)
	}
	if c.hasSummary && (st.Skipped < 1 || st.Updated != 0) {
		t.Errorf("%s: reported skipped=%d updated=%d, want skipped>=1 updated=0", what, st.Skipped, st.Updated)
	}
}

// expectUpdate fails the check unless the push wrote to the remote and, when
// the command prints a summary, counted the issue as updated.
func expectUpdate(t *testing.T, c pushCommand, what string, st pushStats, tr traffic) {
	t.Helper()
	if tr.patches < 1 {
		t.Errorf("%s: made %d remote write(s), want >= 1", what, tr.patches)
	}
	if c.hasSummary && st.Updated < 1 {
		t.Errorf("%s: reported updated=%d, want >= 1", what, st.Updated)
	}
}

// reverseStrings returns a copy of in with its order reversed.
func reverseStrings(in []string) []string {
	out := make([]string, len(in))
	for i, v := range in {
		out[len(in)-1-i] = v
	}
	return out
}

// ----------------------------------------------------------------------------
// Checks
// ----------------------------------------------------------------------------

// TestPushUnchangedReportsSkipped covers: after an issue is pushed once,
// pushing the same unchanged issue again reports it as skipped (not updated)
// and issues no remote write for it.
func TestPushUnchangedReportsSkipped(t *testing.T) {
	stub := newGHStub()
	defer stub.close()
	w := newWorld(t, stub)

	id := w.createIssue("Rate limit audit", "look into push volume")

	stub.resetCounts()
	first := w.push(id)
	if first.Created < 1 {
		t.Fatalf("first push: expected the issue to be created on the remote, got %+v", first)
	}

	stub.resetCounts()
	second := w.push(id)
	_, _, patches := stub.snapshot()

	if second.Updated != 0 {
		t.Errorf("unchanged re-push reported %d updated, want 0", second.Updated)
	}
	if second.Skipped < 1 {
		t.Errorf("unchanged re-push reported %d skipped, want >= 1", second.Skipped)
	}
	if patches != 0 {
		t.Errorf("unchanged re-push issued %d remote write(s), want 0", patches)
	}
}

// TestNoopPushMakesZeroFetches covers: re-pushing an issue that is unchanged
// since its last push makes zero per-issue remote fetches.
func TestNoopPushMakesZeroFetches(t *testing.T) {
	stub := newGHStub()
	defer stub.close()
	w := newWorld(t, stub)

	id := w.createIssue("Quiet sync", "a no-op re-sync should be cheap")

	stub.resetCounts()
	if first := w.push(id); first.Created < 1 {
		t.Fatalf("first push: expected create, got %+v", first)
	}

	stub.resetCounts()
	second := w.push(id)
	_, gets, _ := stub.snapshot()

	if gets != 0 {
		t.Errorf("unchanged re-push performed %d remote fetch(es), want 0", gets)
	}
	if second.Skipped < 1 {
		t.Errorf("unchanged re-push reported %d skipped, want >= 1", second.Skipped)
	}
}

// TestSyncPushOnlyUnchangedMakesZeroCalls covers the same property on
// `bd github sync --push-only`, which is a separate entry point from the
// single-issue push exercised above.
//
// The push-only sync prints only human-readable text, so this check observes the
// remote traffic directly: the first sync creates the issue on the remote; an
// immediate second sync with nothing changed locally must make no per-issue fetch
// and no remote write.
func TestSyncPushOnlyUnchangedMakesZeroCalls(t *testing.T) {
	stub := newGHStub()
	defer stub.close()
	w := newWorld(t, stub)

	w.createIssue("Quiet push-only sync", "re-running an unchanged sync should be cheap")

	stub.resetCounts()
	w.syncPushOnly()
	posts, _, _ := stub.snapshot()
	if posts < 1 {
		t.Fatalf("first push-only sync: expected the issue to be created on the remote, got %d creates", posts)
	}

	stub.resetCounts()
	w.syncPushOnly()
	_, gets, patches := stub.snapshot()

	if gets != 0 {
		t.Errorf("unchanged push-only re-sync performed %d remote fetch(es), want 0", gets)
	}
	if patches != 0 {
		t.Errorf("unchanged push-only re-sync issued %d remote write(s), want 0", patches)
	}
}

// TestChangedIssueStillUpdated covers: a local edit to any pushed field made
// after a push goes out as an update, with a remote write, on the next push.
// A third push with nothing changed since that update is a no-op again: no
// fetch, no write, and the issue counted as skipped.
//
// Each case edits one field. The title, description and label cases change
// what is sent directly. Moving the status to in progress changes the pushed
// labels, and closing the issue changes the remote state.
func TestChangedIssueStillUpdated(t *testing.T) {
	edits := []struct {
		name string
		args func(id string) []string
	}{
		{name: "title", args: func(id string) []string { return []string{"update", id, "--title", "Corrected title"} }},
		{name: "description", args: func(id string) []string { return []string{"update", id, "--description", "rewritten body"} }},
		{name: "status_in_progress", args: func(id string) []string { return []string{"update", id, "--status", "in_progress"} }},
		{name: "status_closed", args: func(id string) []string { return []string{"close", id} }},
		{name: "label_added", args: func(id string) []string { return []string{"update", id, "--add-label", "needs-triage"} }},
	}

	for _, c := range pushCommands {
		for _, ed := range edits {
			t.Run(c.name+"/"+ed.name, func(t *testing.T) {
				stub := newGHStub()
				defer stub.close()
				w := newWorld(t, stub)

				id := w.createIssue("Initial title", "initial body")
				w.firstPushWith(c, id)

				w.run("edit "+ed.name, bdBin, ed.args(id)...)

				st, tr := w.pushWith(c, id)
				expectUpdate(t, c, "push after a local "+ed.name+" edit", st, tr)

				st, tr = w.pushWith(c, id)
				expectNoop(t, c, "unchanged push after the update", st, tr)
			})
		}
	}
}

// TestCacheInvalidatedByRelink covers: the no-op shortcut is bound to the
// remote reference. After an issue is relinked to a new remote reference, the
// next push must send at least one request (a fetch or a write) for it rather
// than silently reuse the previous no-op decision.
//
// The check first confirms that an unchanged re-push is a no-op. It then
// relinks the issue and expects the next push to reach the remote.
func TestCacheInvalidatedByRelink(t *testing.T) {
	for _, c := range pushCommands {
		t.Run(c.name, func(t *testing.T) {
			stub := newGHStub()
			defer stub.close()
			w := newWorld(t, stub)

			id := w.createIssue("Linked item", "body")
			w.firstPushWith(c, id)

			st, tr := w.pushWith(c, id)
			expectNoop(t, c, "precondition: unchanged re-push", st, tr)
			if t.Failed() {
				t.FailNow()
			}

			// Relink the issue to a different remote reference.
			w.run("relink", bdBin, "update", id, "--external-ref", "github:2")

			_, tr = w.pushWith(c, id)
			if tr.gets+tr.patches < 1 {
				t.Errorf("push after relink made no remote request for the issue (fetches=%d writes=%d), want >= 1 (the no-op decision must not carry over to a new target)", tr.gets, tr.patches)
			}
		})
	}
}

// TestCacheInvalidatedByTargetScope covers: the no-op shortcut is bound to the
// configured remote namespace. After the configured owner or repository
// changes, the next push must send at least one request (a fetch or a write)
// for the issue, because a shorthand reference such as github:1 names neither.
//
// Here the per-issue reference stays the same and only one part of the
// configured target changes per case.
func TestCacheInvalidatedByTargetScope(t *testing.T) {
	changes := []struct {
		name   string
		what   string
		change func(w *world)
	}{
		{
			name:   "repository_change",
			what:   "repository",
			change: func(w *world) { w.repo = "widgets-staging" },
		},
		{
			name:   "owner_change",
			what:   "owner",
			change: func(w *world) { w.owner = "acme-labs" },
		},
	}

	for _, c := range pushCommands {
		for _, tc := range changes {
			t.Run(c.name+"/"+tc.name, func(t *testing.T) {
				stub := newGHStub()
				defer stub.close()
				w := newWorld(t, stub)

				id := w.createIssue("Scoped item", "body")
				w.firstPushWith(c, id)

				st, tr := w.pushWith(c, id)
				expectNoop(t, c, "precondition: unchanged re-push", st, tr)
				if t.Failed() {
					t.FailNow()
				}

				tc.change(w)

				_, tr = w.pushWith(c, id)
				if tr.gets+tr.patches < 1 {
					t.Errorf("push after a %s change made no remote request for the issue (fetches=%d writes=%d), want >= 1 (the no-op decision must not carry over to a different %s)", tc.what, tr.gets, tr.patches, tc.what)
				}
			})
		}
	}
}

// TestPushComparisonFieldsAndLabelOrder covers: pushing a linked issue that
// the remote already holds with the same content writes nothing, and the
// remote is treated as holding the same content when it returns the same
// labels in a different order. A difference in the title, body, state or
// label set must still produce an update. When the remote already matched,
// the push after that makes no fetch either.
//
// Each case first pushes the issue from a seed project so the stand-in holds a
// remote copy. A second, fresh project then creates an identical issue, links
// it to that remote issue and pushes it. The fresh project has no record of
// the seed push, so the outcome depends only on how its push compares with the
// remote. The stand-in returns a remote copy that differs only as described
// per case.
func TestPushComparisonFieldsAndLabelOrder(t *testing.T) {
	cases := []struct {
		name      string
		transform func(in remoteIssue) remoteIssue
		// wantUpdate is true when the remote copy differs in a pushed field,
		// so the push must write, and false when it is equivalent, so the
		// push must skip.
		wantUpdate bool
	}{
		{
			name: "labels_reordered_same_set_is_equal",
			transform: func(in remoteIssue) remoteIssue {
				in.labels = reverseStrings(in.labels)
				return in
			},
			wantUpdate: false,
		},
		{
			name: "different_title_updates",
			transform: func(in remoteIssue) remoteIssue {
				in.title = in.title + " (remote drift)"
				return in
			},
			wantUpdate: true,
		},
		{
			name: "different_body_updates",
			transform: func(in remoteIssue) remoteIssue {
				in.body = in.body + " (remote drift)"
				return in
			},
			wantUpdate: true,
		},
		{
			name: "different_state_updates",
			transform: func(in remoteIssue) remoteIssue {
				in.state = "closed"
				return in
			},
			wantUpdate: true,
		},
		{
			name: "different_label_set_updates",
			transform: func(in remoteIssue) remoteIssue {
				in.labels = append(append([]string(nil), in.labels...), "extra-remote-label")
				return in
			},
			wantUpdate: true,
		},
		{
			// Same number of labels, one of them renamed.
			name: "renamed_label_same_count_updates",
			transform: func(in remoteIssue) remoteIssue {
				labels := append([]string(nil), in.labels...)
				if len(labels) > 0 {
					labels[0] = labels[0] + "-renamed"
				}
				in.labels = labels
				return in
			},
			wantUpdate: true,
		},
	}

	for _, c := range pushCommands {
		for _, tc := range cases {
			t.Run(c.name+"/"+tc.name, func(t *testing.T) {
				stub := newGHStub()
				defer stub.close()

				seed := newWorld(t, stub)
				seedID := seed.createIssue("Equality probe", "equality body")
				if first := seed.push(seedID); first.Created < 1 {
					t.Fatalf("seed push: expected create, got %+v", first)
				}
				num := stub.lastCreated()
				stub.mu.Lock()
				seeded := len(stub.issues[num].labels)
				stub.mu.Unlock()
				if seeded == 0 {
					t.Fatalf("seed push: remote issue has no labels to compare")
				}
				ref := fmt.Sprintf("github:%d", num)

				w := newWorld(t, stub)
				id := w.createIssue("Equality probe", "equality body")
				w.run("link to seeded remote issue", bdBin, "update", id, "--external-ref", ref)

				stub.setGetTransform(tc.transform)
				st, tr := w.pushWith(c, id)

				if tc.wantUpdate {
					expectUpdate(t, c, "push against a remote with a real content difference", st, tr)
					return
				}
				if tr.patches != 0 || (c.hasSummary && st.Skipped < 1) {
					t.Errorf("an equivalent remote (label order only) should be a no-op: skipped=%d writes=%d, want skipped>=1 writes=0", st.Skipped, tr.patches)
				}
				st, tr = w.pushWith(c, id)
				expectNoop(t, c, "push after the remote was found already in sync", st, tr)
			})
		}
	}
}
