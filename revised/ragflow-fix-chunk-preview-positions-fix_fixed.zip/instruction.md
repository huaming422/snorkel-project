## Task

We parse PDFs through the ingestion pipeline with the title chunker, in both hierarchy and group mode, and a chunk token cap set.
When a passage runs past the cap it gets cut into several pieces, and only the first piece shows a page thumbnail in the chunk list.
The pieces after it have no thumbnail, and clicking one doesn't jump to or highlight anything in the source document.
The token chunker does the same thing when a single paragraph is bigger than the chunk size.
We see it on both the Go ingestion service and the Python pipeline.
Apart from its text, every later piece should carry the same source details as the first piece, so it previews and highlights the whole passage it was cut from.
The chunk text and the points where pieces are split should stay exactly as they are now.
