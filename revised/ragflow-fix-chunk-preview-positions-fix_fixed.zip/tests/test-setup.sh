#!/usr/bin/env bash
# Verifier-time setup. Everything both verifiers need is already baked into the
# image:
#   - Go: toolchain (1.26.4), warm module + build cache, and the cl100k_base
#     BPE table under ragflow_deps/ (the token hard-cap tests count tokens
#     through the real tokenizer, which loads that table from disk).
#   - Python: the canonical verifier venv at /opt/tooling/venv (VERIFIER_PYTHON),
#     with pytest. The Python verifier module stubs all heavy repo imports, so
#     no ragflow dependency closure is required.
# Nothing to install at verifier time.
set -euo pipefail
echo "[test-setup] no-op for ragflow-fix-chunk-preview-positions (deps baked into image)"
