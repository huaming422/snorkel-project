package chunker

// Behavioral verifier for the Go title-cap splitter cap-split path.
//
// Drives enforceTitleTokenCap (the pre-existing, stable in-package entry
// point) on an oversized text chunk carrying a known page-region matrix and
// asserts that EVERY resulting sub-chunk carries the whole matrix, so each one
// stays eligible for the on-demand page-region crop and the in-document
// highlight. Self-contained: it swaps the package token-count seam vars for a
// deterministic rune counter inline (never calling the repo test-file helpers)
// and builds its own fixtures. Test names use a unique prefix so they do not
// collide with the package's existing Test functions.

import (
	"encoding/json"
	"reflect"
	"strings"
	"testing"
	"unicode/utf8"
)

// vtcInstallRuneSeam swaps the package token seam (numTokens / trimToTokenLimit)
// for a deterministic 1-token-per-rune counter and returns a restore func. This
// makes the cap a plain rune ceiling without loading the real BPE tokenizer.
func vtcInstallRuneSeam() func() {
	savedNum := numTokens
	savedTrim := trimToTokenLimit
	numTokens = func(s string) int {
		if s == "" {
			return 0
		}
		return utf8.RuneCountInString(s)
	}
	trimToTokenLimit = func(s string, limit int) string {
		if limit < 0 {
			limit = 0
		}
		if utf8.RuneCountInString(s) <= limit {
			return s
		}
		return runePrefix(s, limit)
	}
	return func() {
		numTokens = savedNum
		trimToTokenLimit = savedTrim
	}
}

// vtcBody builds n sentences of the form "S00。S01。..." - each a 4-rune
// sentence ending on a "。" boundary, so the greedy cap splitter produces
// several sub-chunks.
func vtcBody(n int) string {
	var b strings.Builder
	for i := 0; i < n; i++ {
		b.WriteString("S")
		b.WriteByte(byte('0' + (i/10)%10))
		b.WriteByte(byte('0' + i%10))
		b.WriteString("。")
	}
	return b.String()
}

// TestVerifyTitleCap_EverySubChunkKeepsPositions asserts that when an oversized
// text chunk is re-split by the title cap, every sub-chunk (not just the first)
// carries the whole source page-region matrix.
func TestVerifyTitleCap_EverySubChunkKeepsPositions(t *testing.T) {
	restore := vtcInstallRuneSeam()
	defer restore()

	pos := [][]float64{{1, 10, 200, 50, 80}, {2, 15, 190, 60, 90}}
	body := vtcBody(12) // 48 runes; cap 20 -> several sub-chunks
	chunks := []map[string]any{
		{"text": body, "positions": pos},
	}

	got := enforceTitleTokenCap(chunks, 20)
	if len(got) <= 1 {
		t.Fatalf("expected the oversized chunk to split into >1 sub-chunk, got %d", len(got))
	}
	for i := range got {
		v, ok := got[i]["positions"].([][]float64)
		if !ok || !reflect.DeepEqual(v, pos) {
			t.Errorf("sub-chunk %d positions = %#v, want the source matrix %v", i, got[i]["positions"], pos)
		}
	}
}

// TestVerifyTitleCap_RawJSONPositionsCarriedToEverySubChunk asserts that a
// position matrix held as json.RawMessage (the encoded form the chunk maps
// also carry) reaches every sub-chunk unchanged, not only the first one.
func TestVerifyTitleCap_RawJSONPositionsCarriedToEverySubChunk(t *testing.T) {
	restore := vtcInstallRuneSeam()
	defer restore()

	raw := json.RawMessage(`[[1,10,200,50,80],[2,15,190,60,90]]`)
	body := vtcBody(12)
	chunks := []map[string]any{
		{"text": body, "positions": raw},
	}

	got := enforceTitleTokenCap(chunks, 20)
	if len(got) <= 1 {
		t.Fatalf("expected the oversized chunk to split into >1 sub-chunk, got %d", len(got))
	}
	for i := range got {
		v, ok := got[i]["positions"].(json.RawMessage)
		if !ok || string(v) != string(raw) {
			t.Errorf("sub-chunk %d positions = %#v, want the source matrix %s", i, got[i]["positions"], raw)
		}
	}
}

// TestVerifyTitleCap_PdfPositionsKeyKeptOnEverySubChunk mirrors the primary
// case for the `_pdf_positions` map key (the production merged-matrix key),
// guarding both coordinate keys the title cap manages.
func TestVerifyTitleCap_PdfPositionsKeyKeptOnEverySubChunk(t *testing.T) {
	restore := vtcInstallRuneSeam()
	defer restore()

	pos := [][]float64{{1, 10, 200, 50, 80}, {2, 15, 190, 60, 90}}
	body := vtcBody(12)
	chunks := []map[string]any{
		{"text": body, "_pdf_positions": pos},
	}

	got := enforceTitleTokenCap(chunks, 20)
	if len(got) <= 1 {
		t.Fatalf("expected the oversized chunk to split into >1 sub-chunk, got %d", len(got))
	}
	for i := range got {
		v, ok := got[i]["_pdf_positions"].([][]float64)
		if !ok || !reflect.DeepEqual(v, pos) {
			t.Errorf("sub-chunk %d _pdf_positions = %#v, want the source matrix %v", i, got[i]["_pdf_positions"], pos)
		}
	}
}
