## Task

We build a lot of `RangeSelection`s in code (toolbar actions, plugins, scripted edits), and the selection APIs stop agreeing with each other as soon as one end is written as an element point instead of a text point.
Both forms can name the same spot.
Take a paragraph holding the text nodes `abcd`, `efgh` (italic) and `ijkl` (bold): "just after `efgh`" is offset 4 in `efgh` as a text point, and child index 2 of the paragraph as an element point.

What we run into with selections like that:

- From `b` to just after `efgh`, `getTextContent()` gives `bcdefgh` with the text-point end but only `bcd` with the element-point end.
- When both ends name the same spot, one as the end of `abcd` and one as child index 1, `getTextContent()` still returns `abcd`.
- Copying a selection whose ends both sit at the start of a link's text, one written on the text node and one on the link, still copies the link's text.
- A caret with nothing selected, next to a block that has slot content, returns the slot's text.
- `extract()` from `b` to the element point after `efgh` leaves out `efgh`.
- `formatText('bold')` on a selection we built, while the user has a different one active, bolds the right characters, but afterwards our selection no longer covers them.
- `$patchStyleText(selection, patch)` styles whatever the user has selected, or nothing at all if there is no selection, instead of the selection we pass in.

What we need:

- `getTextContent()`, `extract()`, `formatText()`, `$patchStyleText()`, `$sliceSelectedTextNodeContent()` and copying treat an element point and the matching text point the same way, at either end and in both directions.
- The slice has to be right both in place and in the `'clone'` mode that copy and HTML export use, and the clone mode leaves the document's nodes alone.
- When both ends name the same spot, nothing is selected: the text is empty, nothing gets copied, `extract()` returns nothing and leaves the document alone, and a slice comes back empty.
- A collapsed selection gives empty text too, even right next to a block with slot content (that block still shows up in the selection's nodes, it just adds no text).
- `extract()` splits nodes without changing the document's text, and like `formatText()` it keeps the selection's direction.
- After `extract()`, `formatText()` or `$patchStyleText()`, the selection we called it on covers exactly the text that was pulled out, formatted or styled, so styling it again keeps working and a second format toggle puts the text back.
- `$patchStyleText()` styles the selection it is given, whether that is a range, a caret (which only gets the pending style) or a node selection, and whether the user has another range selected, only a caret, or nothing.
- When the selection we pass is not the user's active selection, none of these calls should move the active selection or touch its text.
- Selections that use only text points, or cover whole nodes, keep working the way they do now.
