#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
# No services, DB, or browser: the verifier is a jsdom vitest unit test that
# exercises the lexical / @lexical/selection public API directly.
cd /repo/lexical

# Offline switch: a cache miss must fail fast instead of reaching a registry.
export npm_config_offline=true
export CI=true

# Dependencies: offline-first against the image bake, logged online fallback.
# The image baked node_modules + the pnpm store at the base commit, so the
# offline install is normally a no-op; the online branch only fires if the
# bake was somehow stale (and the smoke gate's offline fold never takes it).
if pnpm install --offline --frozen-lockfile --ignore-scripts > /tmp/test-setup-install.log 2>&1; then
    echo "[offline-first] deps satisfied from image"
elif env -u npm_config_offline pnpm install --frozen-lockfile --ignore-scripts >> /tmp/test-setup-install.log 2>&1; then
    echo "[test-setup] deps installed online (image bake was stale)"
else
    tail -40 /tmp/test-setup-install.log >&2; exit 1
fi

# vitest must be resolvable from the workspace root; a miss means a corrupted
# node_modules from a partial bake. Surface it loudly.
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest binary missing from node_modules/.bin/ (the image bake is incomplete)." >&2
    exit 1
fi

# verify.toml ([jest] runner = "vitest") is parsed by js.py under VERIFIER_PYTHON
# (/opt/tooling/venv, Python 3.12), whose stdlib has tomllib, so no tomli install
# needed here. tests/test.sh routes all verifier infrastructure through
# VERIFIER_PYTHON, so the config is honored rather than silently dropped.

echo "test-setup.sh: ready. vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
