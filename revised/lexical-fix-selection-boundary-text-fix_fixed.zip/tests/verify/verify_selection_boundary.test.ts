/**
 * Selection boundary checks for the `lexical` and `@lexical/selection`
 * packages.
 *
 * Every test uses public API only:
 *   - RangeSelection.getTextContent() / .extract() / .formatText() / .getNodes()
 *   - $patchStyleText(selection, patch) on range, caret and node selections
 *   - $sliceSelectedTextNodeContent(selection, node, mutates), both modes
 * A RangeSelection is built directly by creating nodes and setting its anchor
 * and focus Points (text point: (key, offset, 'text'); element point:
 * (parentKey, childIndex, 'element')). No internal helper or implementation
 * file is imported, and selection positions are compared by the text they
 * cover rather than by how a point is written.
 *
 * Runner: vitest (jsdom), single file, via ssb_lib/runners/js.py.
 */
import {$generateJSONFromSelectedNodes} from '@lexical/clipboard';
import {$createLinkNode, LinkNode} from '@lexical/link';
import {$patchStyleText, $sliceSelectedTextNodeContent} from '@lexical/selection';
import {buildEditorFromExtensions} from '@lexical/extension';
import {
  $createNodeSelection,
  $createParagraphNode,
  $createRangeSelection,
  $createTextNode,
  $getNodeByKey,
  $getRoot,
  $getSelection,
  $isRangeSelection,
  $isTextNode,
  $setSelection,
  $setSlot,
  IS_BOLD,
  IS_ITALIC,
  type ElementNode,
  type LexicalNode,
  type PointType,
  type RangeSelection,
  type TextNode,
} from 'lexical';
import {expect, test} from 'vitest';

function textChildren(node: LexicalNode): TextNode[] {
  if (!('getChildren' in node)) {
    return [];
  }
  // @ts-expect-error - node is an ElementNode in every call site below.
  return node.getChildren().filter($isTextNode) as TextNode[];
}

// True when the point sits at the very end of `block`, written either as an
// element point after its last child or as a text point at the end of its
// last text child.
function isAtEndOf(point: PointType, block: ElementNode): boolean {
  if (point.type === 'element') {
    return (
      point.key === block.getKey() && point.offset === block.getChildrenSize()
    );
  }
  const last = block.getLastChild();
  return (
    $isTextNode(last) &&
    point.key === last.getKey() &&
    point.offset === last.getTextContentSize()
  );
}

// Snapshot of the active selection, so a later check can tell whether it
// moved, changed or had its text styled.
function $snapshotActive(other: TextNode) {
  const active = $getSelection();
  const original = $isRangeSelection(active) ? active.clone() : null;
  return function $expectActiveUnchanged() {
    expect(other.getParentOrThrow().getChildren()).toEqual([other]);
    expect(other.getStyle()).toBe('');
    const current = $getSelection();
    if (original === null) {
      expect(current).toBe(null);
    } else {
      expect($isRangeSelection(current) && current.is(original)).toBe(true);
    }
  };
}

// ---------------------------------------------------------------------------
// getTextContent()
// ---------------------------------------------------------------------------

test('gettextcontent_boundary_equiv', () => {
  using editor = buildEditorFromExtensions({name: 'v-gettextcontent'});
  for (const backward of [false, true]) {
    editor.update(
      () => {
        const first = $createTextNode('abcd');
        const second = $createTextNode('efgh').setFormat('italic');
        const third = $createTextNode('ijkl').setFormat('bold');
        const paragraph = $createParagraphNode().append(first, second, third);
        $getRoot().clear().append(paragraph);
        const selection = $createRangeSelection();
        const [start, end] = backward
          ? [selection.focus, selection.anchor]
          : [selection.anchor, selection.focus];

        // End of the range: text point at the end of `second`, then the
        // equivalent element point (child index after `second`).
        start.set(first.getKey(), 1, 'text');
        end.set(second.getKey(), 4, 'text');
        expect(selection.getTextContent()).toBe('bcdefgh');
        end.set(paragraph.getKey(), 2, 'element');
        expect(selection.getTextContent()).toBe('bcdefgh');

        // Start of the range: text point at the end of `first`, then the
        // equivalent element point (child index of `second`).
        start.set(first.getKey(), 4, 'text');
        end.set(third.getKey(), 2, 'text');
        expect(selection.getTextContent()).toBe('efghij');
        start.set(paragraph.getKey(), 1, 'element');
        expect(selection.getTextContent()).toBe('efghij');

        // Reading the text does not change the document.
        expect(paragraph.getTextContent()).toBe('abcdefghijkl');
      },
      {discrete: true},
    );
  }
});

test('empty_mixed_range_empty', () => {
  using editor = buildEditorFromExtensions({name: 'v-emptymixed'});
  for (const backward of [false, true]) {
    editor.update(
      () => {
        const first = $createTextNode('abcd');
        const paragraph = $createParagraphNode().append(
          first,
          $createTextNode('efgh').setFormat('italic'),
        );
        $getRoot().clear().append(paragraph);
        const selection = $createRangeSelection();
        const [start, end] = backward
          ? [selection.focus, selection.anchor]
          : [selection.anchor, selection.focus];
        // Text point at end of `first` == element point just after `first`.
        start.set(first.getKey(), 4, 'text');
        end.set(paragraph.getKey(), 1, 'element');
        expect(selection.getTextContent()).toBe('');
        expect(paragraph.getTextContent()).toBe('abcdefgh');
      },
      {discrete: true},
    );
  }
});

test('collapsed_returns_empty', () => {
  using editor = buildEditorFromExtensions({name: 'v-collapsed'});
  for (const offset of [0, 1]) {
    editor.update(
      () => {
        const root = $getRoot();
        const host = $createParagraphNode();
        root.clear().append(host);
        $setSlot(
          host,
          'title',
          $createParagraphNode().append($createTextNode('Title')),
        );
        const selection = $createRangeSelection();
        selection.anchor.set(root.getKey(), offset, 'element');
        selection.focus.set(root.getKey(), offset, 'element');
        // The slot-bearing host still appears in the collapsed selection's
        // nodes and keeps its own text, but the collapsed range itself is empty.
        expect(selection.getNodes()).toEqual([host]);
        expect(selection.getTextContent()).toBe('');
        expect(host.getTextContent()).toBe('Title');
      },
      {discrete: true},
    );
  }
});

// ---------------------------------------------------------------------------
// extract()
// ---------------------------------------------------------------------------

function extractTextContents(selection: RangeSelection): string[] {
  return selection
    .extract()
    .filter($isTextNode)
    .map((node) => node.getTextContent());
}

test('extract_isolates_fragment', () => {
  using editor = buildEditorFromExtensions({name: 'v-extract'});

  // (a) Single partially-selected TextNode: extract returns the isolated
  //     fragment and the selection then covers exactly that fragment.
  for (const backward of [false, true]) {
    editor.update(
      () => {
        const text = $createTextNode('abcde');
        const paragraph = $createParagraphNode().append(text);
        $getRoot().clear().append(paragraph);
        const selection = $createRangeSelection();
        const [start, end] = backward
          ? [selection.focus, selection.anchor]
          : [selection.anchor, selection.focus];
        start.set(text.getKey(), 1, 'text');
        end.set(text.getKey(), 4, 'text');
        const extracted = selection.extract();
        expect(extracted.map((node) => node.getTextContent())).toEqual(['bcd']);
        expect(selection.getTextContent()).toBe('bcd');
        expect(selection.getNodes()).toEqual(extracted);
        expect(paragraph.getTextContent()).toBe('abcde');
      },
      {discrete: true},
    );
  }

  // (b) Range whose end is an ELEMENT point between children: extract splits
  //     and isolates the selected fragments across both TextNodes.
  for (const backward of [false, true]) {
    editor.update(
      () => {
        const first = $createTextNode('abcd');
        const second = $createTextNode('efgh').setFormat('italic');
        const third = $createTextNode('ijkl').setFormat('bold');
        const paragraph = $createParagraphNode().append(first, second, third);
        $getRoot().clear().append(paragraph);
        const selection = $createRangeSelection();
        const [start, end] = backward
          ? [selection.focus, selection.anchor]
          : [selection.anchor, selection.focus];
        start.set(first.getKey(), 1, 'text');
        end.set(paragraph.getKey(), 2, 'element');
        expect(extractTextContents(selection)).toEqual(['bcd', 'efgh']);
        // The remaining document is intact.
        expect(paragraph.getTextContent()).toBe('abcdefghijkl');
        expect(selection.isBackward()).toBe(backward);
      },
      {discrete: true},
    );
  }

  // (b2) Range whose start is an ELEMENT point between children.
  for (const backward of [false, true]) {
    editor.update(
      () => {
        const first = $createTextNode('abcd');
        const second = $createTextNode('efgh').setFormat('italic');
        const third = $createTextNode('ijkl').setFormat('bold');
        const paragraph = $createParagraphNode().append(first, second, third);
        $getRoot().clear().append(paragraph);
        const selection = $createRangeSelection();
        const [start, end] = backward
          ? [selection.focus, selection.anchor]
          : [selection.anchor, selection.focus];
        start.set(paragraph.getKey(), 1, 'element');
        end.set(third.getKey(), 2, 'text');
        expect(extractTextContents(selection)).toEqual(['efgh', 'ij']);
        expect(selection.getTextContent()).toBe('efghij');
        expect(paragraph.getTextContent()).toBe('abcdefghijkl');
        expect(selection.isBackward()).toBe(backward);
      },
      {discrete: true},
    );
  }

  // (c) Empty mixed-point range extracts nothing and leaves the tree untouched,
  //     with the element point written first or second.
  for (const backward of [false, true]) {
    editor.update(
      () => {
        const text = $createTextNode('abcd');
        const following = $createTextNode('efgh').setFormat('italic');
        const paragraph = $createParagraphNode().append(text, following);
        $getRoot().clear().append(paragraph);
        const selection = $createRangeSelection();
        const [elementPoint, textPoint] = backward
          ? [selection.focus, selection.anchor]
          : [selection.anchor, selection.focus];
        elementPoint.set(paragraph.getKey(), 1, 'element');
        textPoint.set(text.getKey(), 4, 'text');
        expect(selection.extract()).toEqual([]);
        expect(paragraph.getChildren()).toEqual([text, following]);
        expect(text.getTextContent()).toBe('abcd');
      },
      {discrete: true},
    );
  }

  // (d) A selection that is not the active one keeps covering the extracted
  //     text through an element end, and the active selection stays put.
  editor.update(
    () => {
      const first = $createTextNode('abc');
      const second = $createTextNode('def').setFormat('italic');
      const paragraph = $createParagraphNode().append(first, second);
      const other = $createTextNode('other');
      $getRoot()
        .clear()
        .append(paragraph, $createParagraphNode().append(other));
      const active = other.select(2, 2);
      const selection = $createRangeSelection();
      selection.anchor.set(first.getKey(), 1, 'text');
      selection.focus.set(paragraph.getKey(), 2, 'element');

      expect(extractTextContents(selection)).toEqual(['bc', 'def']);
      expect(selection.getTextContent()).toBe('bcdef');
      expect(paragraph.getTextContent()).toBe('abcdef');
      expect($getSelection()).toBe(active);
      expect(active.anchor.key).toBe(other.getKey());
      expect(active.anchor.offset).toBe(2);
    },
    {discrete: true},
  );
});

// ---------------------------------------------------------------------------
// extract() and formatText() on a selection that is not the active one, while
// the active caret sits at the end of the same paragraph.
// ---------------------------------------------------------------------------

test('detached_edit_keeps_active_caret', () => {
  using editor = buildEditorFromExtensions({name: 'v-detached-active'});
  for (const operation of ['format', 'extract'] as const) {
    editor.update(
      () => {
        const text = $createTextNode('abcde');
        const following = $createTextNode('after').setFormat('italic');
        const paragraph = $createParagraphNode().append(text, following);
        $getRoot().clear().append(paragraph);
        const active = paragraph.select(2, 2);
        const selection = $createRangeSelection();
        selection.anchor.set(text.getKey(), 1, 'text');
        selection.focus.set(text.getKey(), 4, 'text');

        if (operation === 'format') {
          selection.formatText('bold');
        } else {
          selection.extract();
        }

        expect(selection.getTextContent()).toBe('bcd');
        expect(paragraph.getTextContent()).toBe('abcdeafter');
        expect($getSelection()).toBe(active);
        expect(active.isCollapsed()).toBe(true);
        expect(isAtEndOf(active.anchor, paragraph)).toBe(true);
      },
      {discrete: true},
    );
  }
});

// ---------------------------------------------------------------------------
// formatText()
// ---------------------------------------------------------------------------

test('formattext_partial_fragment', () => {
  using editor = buildEditorFromExtensions({name: 'v-formattext'});
  for (const operationBackward of [false, true]) {
    editor.update(
      () => {
        const first = $createTextNode('abc');
        const second = $createTextNode('def').setFormat('italic');
        const paragraph = $createParagraphNode().append(first, second);
        const other = $createTextNode('other');
        $getRoot()
          .clear()
          .append(paragraph, $createParagraphNode().append(other));
        // An unrelated active selection: formatting a different selection
        // must not disturb it.
        const active = other.select(2, 2);
        const selection = $createRangeSelection();
        const [start, end] = operationBackward
          ? [selection.focus, selection.anchor]
          : [selection.anchor, selection.focus];
        // Spans part of `first` through an element point past `second`.
        start.set(first.getKey(), 1, 'text');
        end.set(paragraph.getKey(), 2, 'element');

        selection.formatText('bold');

        // Exactly the selected fragment ('bcdef') is bold; the unselected
        // prefix 'a' is untouched.
        const bolded = textChildren(paragraph)
          .filter((node) => (node.getFormat() & IS_BOLD) !== 0)
          .map((node) => node.getTextContent())
          .join('');
        expect(bolded).toBe('bcdef');
        const unbolded = textChildren(paragraph)
          .filter((node) => (node.getFormat() & IS_BOLD) === 0)
          .map((node) => node.getTextContent())
          .join('');
        expect(unbolded).toBe('a');
        // The selection still covers the formatted fragment.
        expect(selection.getTextContent()).toBe('bcdef');
        // The unrelated active selection is unchanged.
        expect($getSelection()).toBe(active);
        expect(active.anchor.key).toBe(other.getKey());
        expect(active.anchor.offset).toBe(2);
      },
      {discrete: true},
    );
  }

  // A backward selection inside one TextNode, not the active one.
  editor.update(
    () => {
      const text = $createTextNode('abcde');
      const other = $createTextNode('other');
      const paragraph = $createParagraphNode().append(text);
      $getRoot()
        .clear()
        .append(paragraph, $createParagraphNode().append(other));
      const active = other.select(2, 2);
      const selection = $createRangeSelection();
      selection.anchor.set(text.getKey(), 4, 'text');
      selection.focus.set(text.getKey(), 1, 'text');

      selection.formatText('bold');
      expect(
        paragraph
          .getChildren()
          .map((node) => [
            node.getTextContent(),
            $isTextNode(node) && node.getFormat(),
          ]),
      ).toEqual([
        ['a', 0],
        ['bcd', IS_BOLD],
        ['e', 0],
      ]);
      expect(selection.getTextContent()).toBe('bcd');
      expect($getSelection()).toBe(active);
      expect(active.anchor.key).toBe(other.getKey());
      expect(active.anchor.offset).toBe(2);
    },
    {discrete: true},
  );
});

test('formattext_element_start', () => {
  using editor = buildEditorFromExtensions({name: 'v-formattext-start'});
  for (const backward of [false, true]) {
    for (const active of [false, true]) {
      for (const preceding of [false, true]) {
        for (const endOffset of [1, 3]) {
          editor.update(
            () => {
              const text = $createTextNode('abc');
              const paragraph = $createParagraphNode();
              if (preceding) {
                paragraph.append($createTextNode('before').setFormat('italic'));
              }
              paragraph.append(text, $createTextNode('def'));
              const other = $createTextNode('other');
              $getRoot()
                .clear()
                .append(paragraph, $createParagraphNode().append(other));
              const unrelated = other.select(2, 2);
              const selection = $createRangeSelection();
              const [start, end] = backward
                ? [selection.focus, selection.anchor]
                : [selection.anchor, selection.focus];
              // Element point just before `text`, text point inside or at the
              // end of `text`.
              start.set(paragraph.getKey(), preceding ? 1 : 0, 'element');
              end.set(text.getKey(), endOffset, 'text');
              if (active) {
                $setSelection(selection);
              }
              const expectedText = 'abc'.slice(0, endOffset);
              expect(selection.getTextContent()).toBe(expectedText);

              // Toggling twice formats, then restores, exactly the selected run.
              for (const expectedFormat of [IS_BOLD, 0]) {
                selection.formatText('bold');
                const formatted = paragraph.getChildAtIndex(preceding ? 1 : 0);
                expect($isTextNode(formatted) && formatted.getFormat()).toBe(
                  expectedFormat,
                );
                expect(formatted?.getTextContent()).toBe(expectedText);
                expect(selection.getTextContent()).toBe(expectedText);
                expect(selection.isBackward()).toBe(backward);
                if (preceding) {
                  const before = paragraph.getFirstChildOrThrow<TextNode>();
                  expect(before.getTextContent()).toBe('before');
                  expect(before.getFormat()).toBe(IS_ITALIC);
                }
                expect(paragraph.getTextContent()).toBe(
                  (preceding ? 'before' : '') + 'abcdef',
                );
                if (!active) {
                  expect($getSelection()).toBe(unrelated);
                  expect(unrelated.anchor.key).toBe(other.getKey());
                  expect(unrelated.anchor.offset).toBe(2);
                }
              }
            },
            {discrete: true},
          );
        }
      }
    }
  }
});

// ---------------------------------------------------------------------------
// $patchStyleText()
// ---------------------------------------------------------------------------

const ACTIVE_SELECTIONS = ['none', 'caret', 'range'] as const;

// Paragraph 'abcdef' to style, plus a second paragraph 'xyz' that holds the
// active selection (nothing, a caret, or a range over 'xy').
function $createStyleFixture(active: (typeof ACTIVE_SELECTIONS)[number]) {
  const text = $createTextNode('abcdef');
  const paragraph = $createParagraphNode().append(text);
  const other = $createTextNode('xyz');
  $getRoot().clear().append(paragraph, $createParagraphNode().append(other));
  $setSelection(
    active === 'none' ? null : other.select(0, active === 'range' ? 2 : 0),
  );
  return {$expectActiveUnchanged: $snapshotActive(other), paragraph, text};
}

test('patchstyle_supplied_selection', () => {
  using editor = buildEditorFromExtensions({name: 'v-patchstyle-supplied'});
  for (const active of ACTIVE_SELECTIONS) {
    for (const backward of [false, true]) {
      for (const partial of [false, true]) {
        editor.update(
          () => {
            const {text, paragraph, $expectActiveUnchanged} =
              $createStyleFixture(active);
            const selection = $createRangeSelection();
            const [start, end] = backward
              ? [selection.focus, selection.anchor]
              : [selection.anchor, selection.focus];
            start.set(text.getKey(), partial ? 2 : 0, 'text');
            end.set(text.getKey(), partial ? 4 : 6, 'text');
            const expectedText = partial ? 'cd' : 'abcdef';

            $patchStyleText(selection, {color: 'red'});

            // Only the supplied selection's text got styled.
            const styled = textChildren(paragraph).filter(
              (node) => node.getStyle() !== '',
            );
            expect(styled.map((node) => node.getTextContent())).toEqual([
              expectedText,
            ]);
            expect(styled[0].getStyle()).toBe('color: red;');
            expect(selection.getTextContent()).toBe(expectedText);
            expect(selection.getNodes()).toEqual(styled);

            // A second call on the same selection styles the same run again.
            $patchStyleText(selection, {'font-size': '20px'});
            expect(styled[0].getStyle()).toBe('color: red;font-size: 20px;');
            expect(selection.getTextContent()).toBe(expectedText);
            expect(paragraph.getTextContent()).toBe('abcdef');
            $expectActiveUnchanged();
          },
          {discrete: true},
        );
      }
    }
  }
});

test('patchstyle_endpoints_survive', () => {
  using editor = buildEditorFromExtensions({name: 'v-patchstyle-repeat'});
  editor.update(
    () => {
      const text = $createTextNode('abcdef');
      const paragraph = $createParagraphNode().append(text);
      const other = $createTextNode('xyz');
      $getRoot().clear().append(paragraph, $createParagraphNode().append(other));
      // No active selection at all.
      $setSelection(null);

      const selection = $createRangeSelection();
      selection.anchor.set(text.getKey(), 2, 'text');
      selection.focus.set(text.getKey(), 4, 'text');

      $patchStyleText(selection, {color: 'red'});
      const styled = textChildren(paragraph).find(
        (node) => node.getStyle().includes('color: red'),
      );
      expect(styled?.getTextContent()).toBe('cd');
      // After the first call the endpoints resolve exactly to the styled run.
      expect(selection.getNodes()).toEqual([styled]);
      expect(selection.getTextContent()).toBe('cd');

      // A second call keeps valid endpoints and accumulates the style.
      $patchStyleText(selection, {'font-size': '20px'});
      expect(styled?.getStyle()).toBe('color: red;font-size: 20px;');
      expect(selection.getTextContent()).toBe('cd');
      expect(paragraph.getTextContent()).toBe('abcdef');
      // No active selection was created as a side effect.
      expect($getSelection()).toBe(null);
    },
    {discrete: true},
  );
});

test('patchstyle_caret_and_node_selection', () => {
  using editor = buildEditorFromExtensions({name: 'v-patchstyle-kinds'});
  for (const active of ACTIVE_SELECTIONS) {
    // A supplied caret gets the pending style; no text is styled.
    editor.update(
      () => {
        const {text, $expectActiveUnchanged} = $createStyleFixture(active);
        const selection = $createRangeSelection();
        selection.anchor.set(text.getKey(), 2, 'text');
        selection.focus.set(text.getKey(), 2, 'text');
        $patchStyleText(selection, {color: 'red'});
        expect(selection.style).toBe('color: red;');
        expect(text.getStyle()).toBe('');
        $expectActiveUnchanged();
      },
      {discrete: true},
    );

    // A supplied node selection styles the node it holds.
    editor.update(
      () => {
        const {text, $expectActiveUnchanged} = $createStyleFixture(active);
        const selection = $createNodeSelection();
        selection.add(text.getKey());
        $patchStyleText(selection, {color: 'red'});
        expect(text.getStyle()).toBe('color: red;');
        $expectActiveUnchanged();
      },
      {discrete: true},
    );
  }
});

test('patchstyle_element_boundary', () => {
  using editor = buildEditorFromExtensions({name: 'v-patchstyle-element'});
  for (const backward of [false, true]) {
    for (const active of [false, true]) {
      editor.update(
        () => {
          const text = $createTextNode('abc');
          const paragraph = $createParagraphNode().append(text);
          const other = $createTextNode('other');
          $getRoot()
            .clear()
            .append(paragraph, $createParagraphNode().append(other));
          const unrelated = other.select(2, 2);
          const selection = $createRangeSelection();
          const [start, end] = backward
            ? [selection.focus, selection.anchor]
            : [selection.anchor, selection.focus];
          // Element point at the start of the paragraph, text point after 'a'.
          start.set(paragraph.getKey(), 0, 'element');
          end.set(text.getKey(), 1, 'text');
          if (active) {
            $setSelection(selection);
          }

          $patchStyleText(selection, {color: 'red'});
          expect(selection.getTextContent()).toBe('a');
          $patchStyleText(selection, {color: 'blue'});
          expect(selection.getTextContent()).toBe('a');

          const first = paragraph.getFirstChildOrThrow<TextNode>();
          const last = paragraph.getLastChildOrThrow<TextNode>();
          expect(paragraph.getChildrenSize()).toBe(2);
          expect(first.getTextContent()).toBe('a');
          expect(first.getStyle()).toBe('color: blue;');
          expect(last.getTextContent()).toBe('bc');
          expect(last.getStyle()).toBe('');
          if (!active) {
            expect($getSelection()).toBe(unrelated);
            expect(unrelated.anchor.key).toBe(other.getKey());
            expect(unrelated.anchor.offset).toBe(2);
            expect(other.getStyle()).toBe('');
          }
        },
        {discrete: true},
      );
    }
  }

  // Element point at the END of the range (child index after `def`), on a
  // selection that is not the active one.
  for (const backward of [false, true]) {
    editor.update(
      () => {
        const first = $createTextNode('abc');
        const second = $createTextNode('def').setFormat('italic');
        const paragraph = $createParagraphNode().append(first, second);
        const other = $createTextNode('other');
        $getRoot()
          .clear()
          .append(paragraph, $createParagraphNode().append(other));
        const unrelated = other.select(2, 2);
        const selection = $createRangeSelection();
        const [start, end] = backward
          ? [selection.focus, selection.anchor]
          : [selection.anchor, selection.focus];
        start.set(first.getKey(), 1, 'text');
        end.set(paragraph.getKey(), 2, 'element');

        $patchStyleText(selection, {color: 'green'});

        const styled = textChildren(paragraph)
          .filter((node) => node.getStyle() === 'color: green;')
          .map((node) => node.getTextContent())
          .join('');
        expect(styled).toBe('bcdef');
        const unstyled = textChildren(paragraph)
          .filter((node) => node.getStyle() === '')
          .map((node) => node.getTextContent())
          .join('');
        expect(unstyled).toBe('a');
        expect(selection.getTextContent()).toBe('bcdef');
        expect($getSelection()).toBe(unrelated);
        expect(unrelated.anchor.key).toBe(other.getKey());
        expect(unrelated.anchor.offset).toBe(2);
        expect(other.getStyle()).toBe('');
      },
      {discrete: true},
    );
  }
});

// ---------------------------------------------------------------------------
// $sliceSelectedTextNodeContent()
// ---------------------------------------------------------------------------

test('slice_element_endpoints', () => {
  using editor = buildEditorFromExtensions({
    name: 'v-slice',
    nodes: [LinkNode],
  });

  // (a) Equivalent mixed text/element endpoints produce an empty slice, in
  //     both directions, with the element point on the link or the paragraph,
  //     and for the in-place and the clone mode.
  for (const offset of [0, 2]) {
    for (const backward of [false, true]) {
      for (const outer of [false, true]) {
        for (const mutates of ['clone', 'self'] as const) {
          editor.update(
            () => {
              const text = $createTextNode('jh');
              const link = $createLinkNode('https://example.com').append(text);
              const paragraph = $createParagraphNode().append(link);
              $getRoot().clear().append(paragraph);
              const selection = $createRangeSelection();
              const [textPoint, elementPoint] = backward
                ? [selection.focus, selection.anchor]
                : [selection.anchor, selection.focus];
              textPoint.set(text.getKey(), offset, 'text');
              elementPoint.set(
                (outer ? paragraph : link).getKey(),
                offset === 0 ? 0 : 1,
                'element',
              );
              const slice = $sliceSelectedTextNodeContent(
                selection,
                text,
                mutates,
              );
              expect(slice.__text).toBe('');
              if (mutates === 'clone') {
                expect(slice).not.toBe(text);
                expect(text.__text).toBe('jh');
                expect($getNodeByKey(text.getKey())).toBe(text);
              } else {
                expect(slice).toBe(text);
              }
            },
            {discrete: true},
          );
        }
      }
    }
  }

  // (b) A non-empty range ending on an element point slices each node to its
  //     selected part; the clone mode leaves the document's nodes alone.
  for (const backward of [false, true]) {
    for (const mutates of ['clone', 'self'] as const) {
      editor.update(
        () => {
          const first = $createTextNode('abcd');
          const second = $createTextNode('efgh').setFormat('italic');
          const third = $createTextNode('ijkl').setFormat('bold');
          const paragraph = $createParagraphNode().append(first, second, third);
          $getRoot().clear().append(paragraph);
          const selection = $createRangeSelection();
          const [start, end] = backward
            ? [selection.focus, selection.anchor]
            : [selection.anchor, selection.focus];
          start.set(first.getKey(), 1, 'text');
          end.set(paragraph.getKey(), 2, 'element');
          const slices = [first, second, third].map(
            (node) =>
              $sliceSelectedTextNodeContent(selection, node, mutates).__text,
          );
          expect(slices).toEqual(['bcd', 'efgh', 'ijkl']);
          if (mutates === 'clone') {
            expect(paragraph.getTextContent()).toBe('abcdefghijkl');
          }
        },
        {discrete: true},
      );
    }
  }

  // (b2) The same with the ELEMENT point at the start of the range.
  for (const backward of [false, true]) {
    for (const mutates of ['clone', 'self'] as const) {
      editor.update(
        () => {
          const first = $createTextNode('abcd');
          const second = $createTextNode('efgh').setFormat('italic');
          const third = $createTextNode('ijkl').setFormat('bold');
          const paragraph = $createParagraphNode().append(first, second, third);
          $getRoot().clear().append(paragraph);
          const selection = $createRangeSelection();
          const [start, end] = backward
            ? [selection.focus, selection.anchor]
            : [selection.anchor, selection.focus];
          start.set(paragraph.getKey(), 1, 'element');
          end.set(third.getKey(), 2, 'text');
          const slices = [second, third].map(
            (node) =>
              $sliceSelectedTextNodeContent(selection, node, mutates).__text,
          );
          expect(slices).toEqual(['efgh', 'ij']);
          if (mutates === 'clone') {
            expect(paragraph.getTextContent()).toBe('abcdefghijkl');
          }
        },
        {discrete: true},
      );
    }
  }

  // (c) Text-only fast path still returns the correct substring.
  for (const mutates of ['clone', 'self'] as const) {
    editor.update(
      () => {
        const text = $createTextNode('hello');
        const paragraph = $createParagraphNode().append(text);
        $getRoot().clear().append(paragraph);
        const selection = $createRangeSelection();
        selection.anchor.set(text.getKey(), 1, 'text');
        selection.focus.set(text.getKey(), 3, 'text');
        const slice = $sliceSelectedTextNodeContent(selection, text, mutates);
        expect(slice.__text).toBe('el');
      },
      {discrete: true},
    );
  }
});

// ---------------------------------------------------------------------------
// Copy: the clipboard JSON built from a selection
// ---------------------------------------------------------------------------

function copiedText(json: {nodes: unknown[]}): string {
  let out = '';
  const walk = (node: unknown) => {
    const serialized = node as {children?: unknown[]; text?: unknown};
    if (typeof serialized.text === 'string') {
      out += serialized.text;
    }
    (serialized.children ?? []).forEach(walk);
  };
  json.nodes.forEach(walk);
  return out;
}

test('copy_boundary_text', () => {
  using editor = buildEditorFromExtensions({
    name: 'v-copy',
    nodes: [LinkNode],
  });

  // (a) Both ends at the start of a link's text, one as a text point and one
  //     as an element point on the link: nothing is copied.
  for (const backward of [false, true]) {
    editor.update(
      () => {
        const text = $createTextNode('jh');
        const link = $createLinkNode('https://example.com').append(text);
        $getRoot().clear().append($createParagraphNode().append(link));
        const selection = $createRangeSelection();
        const [textPoint, elementPoint] = backward
          ? [selection.focus, selection.anchor]
          : [selection.anchor, selection.focus];
        textPoint.set(text.getKey(), 0, 'text');
        elementPoint.set(link.getKey(), 0, 'element');
        expect(copiedText($generateJSONFromSelectedNodes(editor, selection))).toBe(
          '',
        );
        expect(text.getTextContent()).toBe('jh');
      },
      {discrete: true},
    );
  }

  // (b) A range ending on a text point and the same range ending on the
  //     equivalent element point copy the same text.
  for (const backward of [false, true]) {
    editor.update(
      () => {
        const first = $createTextNode('abcd');
        const second = $createTextNode('efgh').setFormat('italic');
        const paragraph = $createParagraphNode().append(
          first,
          second,
          $createTextNode('ijkl').setFormat('bold'),
        );
        $getRoot().clear().append(paragraph);
        const selection = $createRangeSelection();
        const [start, end] = backward
          ? [selection.focus, selection.anchor]
          : [selection.anchor, selection.focus];
        start.set(first.getKey(), 1, 'text');
        end.set(second.getKey(), 4, 'text');
        expect(copiedText($generateJSONFromSelectedNodes(editor, selection))).toBe(
          'bcdefgh',
        );
        end.set(paragraph.getKey(), 2, 'element');
        expect(copiedText($generateJSONFromSelectedNodes(editor, selection))).toBe(
          'bcdefgh',
        );
        expect(paragraph.getTextContent()).toBe('abcdefghijkl');
      },
      {discrete: true},
    );
  }
});

// ---------------------------------------------------------------------------
// Baseline selection/caret behaviors with text points only or whole nodes,
// asserted inline because the runner executes this file alone.
// ---------------------------------------------------------------------------

test('no_regression_selection_caret', () => {
  using editor = buildEditorFromExtensions({name: 'v-regression'});
  editor.update(
    () => {
      const a = $createTextNode('Hello');
      const b = $createTextNode(' World').setFormat('italic');
      const paragraph = $createParagraphNode().append(a, b);
      $getRoot().clear().append(paragraph);

      // Full multi-node selection returns the complete text and both nodes.
      const full = $createRangeSelection();
      full.anchor.set(a.getKey(), 0, 'text');
      full.focus.set(b.getKey(), b.getTextContentSize(), 'text');
      expect(full.getTextContent()).toBe('Hello World');
      expect(full.getNodes().filter($isTextNode).map((n) => n.getTextContent())).toEqual([
        'Hello',
        ' World',
      ]);

      // A collapsed text selection is empty.
      const collapsed = $createRangeSelection();
      collapsed.anchor.set(a.getKey(), 2, 'text');
      collapsed.focus.set(a.getKey(), 2, 'text');
      expect(collapsed.getTextContent()).toBe('');

      // Extracting a whole-node multi-node selection returns the nodes as-is.
      const extractSel = $createRangeSelection();
      extractSel.anchor.set(a.getKey(), 0, 'text');
      extractSel.focus.set(b.getKey(), b.getTextContentSize(), 'text');
      expect(
        extractSel.extract().filter($isTextNode).map((n) => n.getTextContent()),
      ).toEqual(['Hello', ' World']);

      // The italic format on `b` survived untouched.
      expect((b.getFormat() & IS_ITALIC) !== 0).toBe(true);
    },
    {discrete: true},
  );
});
