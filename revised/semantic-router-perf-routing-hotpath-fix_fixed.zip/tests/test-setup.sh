#!/usr/bin/env bash
# Offline-first Go dependency bring-up for the semantic-router src/semantic-router
# module. The image bakes GOMODCACHE + GOCACHE warm at the base commit (see
# environment/Dockerfile), so `go mod download` is satisfied entirely from the image
# with no network. The online fallback exists only to self-heal a stale bake;
# under the smoke gate's offline fold (`docker run --network none`) the
# offline-first path must succeed without ever reaching it.
set -euo pipefail

cd /repo/semantic-router/src/semantic-router

# Use the baked module cache; never hit the network on the happy path.
# GOSUMDB=off disables the checksum-database (sum.golang.org) lookup that
# `go mod download all` otherwise makes for a warm-but-sumless cache entry;
# without it the offline attempt fails on sum.golang.org and falls back to
# GOPROXY=direct, defeating the whole offline-first path under the network cut.
export GOFLAGS="-mod=mod"
export GOTOOLCHAIN=local
export GOPROXY=off
export GOSUMDB=off

if go mod download all >/tmp/go-mod-download.log 2>&1; then
  echo "[offline-first] go module closure satisfied from the image cache"
else
  echo "[test-setup] WARNING: offline go mod download failed - image bake is stale"
  tail -40 /tmp/go-mod-download.log || true
  echo "[test-setup] falling back to network (GOPROXY=direct)"
  export GOPROXY=direct
  go mod download all >/tmp/go-mod-download-online.log 2>&1 || {
    tail -80 /tmp/go-mod-download-online.log
    exit 1
  }
fi

echo "[test-setup] go dependency closure ready"
