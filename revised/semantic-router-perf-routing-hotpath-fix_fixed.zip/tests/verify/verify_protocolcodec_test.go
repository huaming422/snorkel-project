// Behavioral checks for request decoding, exercised only through the package's
// exported API (NewBuiltinEngine, (*Engine).DecodeRequest) under the default
// policy, which rejects unknown fields. The assertions observe an allocation
// count and decode results only.
package protocolcodec_test

import (
	"fmt"
	"testing"

	"github.com/vllm-project/semantic-router/src/semantic-router/pkg/llmprotocol"
	protocolcodec "github.com/vllm-project/semantic-router/src/semantic-router/pkg/protocolcodec"
)

// sinks keep the measured calls from being optimised away.
var (
	sinkRequest  llmprotocol.Request
	sinkEnvelope llmprotocol.Envelope
)

// maxDecodeRequestAllocs bounds the allocations one DecodeRequest call may make
// for a small, valid OpenAI-chat body under the default policy. Decoding parses
// the body and builds the neutral request, so the bound is a large constant
// rather than zero.
const maxDecodeRequestAllocs = 190

// A fixed, valid OpenAI-chat request body.
var openAIChatBody = []byte(`{"model":"gpt-4","messages":[{"role":"user","content":"hello world"}],"temperature":0.7,"max_tokens":128}`)

// distinctChatBodies returns n valid OpenAI-chat bodies of the same shape and
// size whose content differs, so no two calls decode the same bytes.
func distinctChatBodies(n int) [][]byte {
	bodies := make([][]byte, n)
	for i := range bodies {
		bodies[i] = []byte(fmt.Sprintf(
			`{"model":"gpt-4","messages":[{"role":"user","content":"hello %05d"}],"temperature":0.7,"max_tokens":%d}`,
			i, 100+i%900))
	}
	return bodies
}

// Decoding small chat requests stays within the allocation budget. Every
// measured call decodes a different body, so the count reflects the cost of
// a new request rather than a repeat of one already seen.
func TestDecodeRequestStaysWithinAllocationBudget(t *testing.T) {
	engine := protocolcodec.NewBuiltinEngine()

	// Prime once outside the measured region so any first-call state is settled.
	var err error
	sinkRequest, sinkEnvelope, _, err = engine.DecodeRequest(llmprotocol.OpenAIChatV1, openAIChatBody)
	if err != nil {
		t.Fatalf("DecodeRequest: %v", err)
	}

	const runs = 100
	bodies := distinctChatBodies(runs + 1) // AllocsPerRun makes one extra warm-up call
	next := 0
	allocs := testing.AllocsPerRun(runs, func() {
		sinkRequest, sinkEnvelope, _, _ = engine.DecodeRequest(llmprotocol.OpenAIChatV1, bodies[next])
		next++
	})
	if next != runs+1 {
		t.Fatalf("measured %d calls, want %d", next, runs+1)
	}
	if allocs > maxDecodeRequestAllocs {
		t.Errorf("DecodeRequest allocates %v times per call, want <= %d", allocs, maxDecodeRequestAllocs)
	}
	for i, body := range bodies[:3] {
		request, _, _, err := engine.DecodeRequest(llmprotocol.OpenAIChatV1, body)
		if err != nil {
			t.Fatalf("DecodeRequest(body %d): %v", i, err)
		}
		if request.Model != "gpt-4" || len(request.Messages) != 1 {
			t.Errorf("DecodeRequest(body %d) = model %q with %d messages, want gpt-4 with 1", i, request.Model, len(request.Messages))
		}
	}
}

// Decoding behavior is preserved: a valid OpenAI-chat body decodes without error
// into the expected model and message, and under the default policy a body is
// rejected when it carries an unknown field or a field name that differs from
// the wire name only in case, at the top level or inside a message.
func TestDecodeRequestBehaviorPreserved(t *testing.T) {
	engine := protocolcodec.NewBuiltinEngine()

	request, _, _, err := engine.DecodeRequest(llmprotocol.OpenAIChatV1, openAIChatBody)
	if err != nil {
		t.Fatalf("DecodeRequest(valid body) error: %v", err)
	}
	if request.Model != "gpt-4" {
		t.Errorf("decoded model = %q, want %q", request.Model, "gpt-4")
	}
	if len(request.Messages) != 1 {
		t.Fatalf("decoded %d messages, want 1", len(request.Messages))
	}

	rejected := []struct {
		name string
		body string
	}{
		{"unknown top-level field", `{"model":"gpt-4","messages":[{"role":"user","content":"hi"}],"not_a_real_field":true}`},
		{"top-level name differs in case", `{"model":"gpt-4","Messages":[{"role":"user","content":"hi"}]}`},
		{"unknown message field", `{"model":"gpt-4","messages":[{"role":"user","content":"hi","not_a_real_field":1}]}`},
		{"message name differs in case", `{"model":"gpt-4","messages":[{"ROLE":"user","content":"hi"}]}`},
	}
	for _, tc := range rejected {
		if _, _, _, err := engine.DecodeRequest(llmprotocol.OpenAIChatV1, []byte(tc.body)); err == nil {
			t.Errorf("DecodeRequest(%s) = nil error, want an error under the default policy", tc.name)
		}
	}
}
