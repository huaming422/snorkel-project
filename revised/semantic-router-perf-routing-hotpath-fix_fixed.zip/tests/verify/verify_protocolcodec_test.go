// Behavioral checks for request decoding, exercised only through the package's
// exported API (NewBuiltinEngine, (*Engine).DecodeRequest) under the default
// policy, which rejects unknown fields. The assertions observe an allocation
// count and decode results only.
package protocolcodec_test

import (
	"testing"

	"github.com/vllm-project/semantic-router/src/semantic-router/pkg/llmprotocol"
	protocolcodec "github.com/vllm-project/semantic-router/src/semantic-router/pkg/protocolcodec"
)

// sinks keep the measured calls from being optimised away.
var (
	sinkRequest  llmprotocol.Request
	sinkEnvelope llmprotocol.Envelope
)

// maxDecodeRequestAllocs bounds the allocations one DecodeRequest call may make
// for a fixed, valid OpenAI-chat body under the default policy. Decoding parses
// the body and builds the neutral request, so the bound is a large constant
// rather than zero.
const maxDecodeRequestAllocs = 190

// A fixed, valid OpenAI-chat request body.
var openAIChatBody = []byte(`{"model":"gpt-4","messages":[{"role":"user","content":"hello world"}],"temperature":0.7,"max_tokens":128}`)

// Decoding a small chat request stays within the allocation budget.
func TestDecodeRequestStaysWithinAllocationBudget(t *testing.T) {
	engine := protocolcodec.NewBuiltinEngine()

	// Prime once outside the measured region so any first-call state is settled.
	var err error
	sinkRequest, sinkEnvelope, _, err = engine.DecodeRequest(llmprotocol.OpenAIChatV1, openAIChatBody)
	if err != nil {
		t.Fatalf("DecodeRequest: %v", err)
	}

	allocs := testing.AllocsPerRun(100, func() {
		sinkRequest, sinkEnvelope, _, _ = engine.DecodeRequest(llmprotocol.OpenAIChatV1, openAIChatBody)
	})
	if allocs > maxDecodeRequestAllocs {
		t.Errorf("DecodeRequest allocates %v times per call, want <= %d", allocs, maxDecodeRequestAllocs)
	}
}

// Decoding behavior is preserved: a valid OpenAI-chat body decodes without error
// into the expected model and message, and under the default policy a body is
// rejected when it carries an unknown field or a field name that differs from
// the wire name only in case, at the top level or inside a message.
func TestDecodeRequestBehaviorPreserved(t *testing.T) {
	engine := protocolcodec.NewBuiltinEngine()

	request, _, _, err := engine.DecodeRequest(llmprotocol.OpenAIChatV1, openAIChatBody)
	if err != nil {
		t.Fatalf("DecodeRequest(valid body) error: %v", err)
	}
	if request.Model != "gpt-4" {
		t.Errorf("decoded model = %q, want %q", request.Model, "gpt-4")
	}
	if len(request.Messages) != 1 {
		t.Fatalf("decoded %d messages, want 1", len(request.Messages))
	}

	rejected := []struct {
		name string
		body string
	}{
		{"unknown top-level field", `{"model":"gpt-4","messages":[{"role":"user","content":"hi"}],"not_a_real_field":true}`},
		{"top-level name differs in case", `{"model":"gpt-4","Messages":[{"role":"user","content":"hi"}]}`},
		{"unknown message field", `{"model":"gpt-4","messages":[{"role":"user","content":"hi","not_a_real_field":1}]}`},
		{"message name differs in case", `{"model":"gpt-4","messages":[{"ROLE":"user","content":"hi"}]}`},
	}
	for _, tc := range rejected {
		if _, _, _, err := engine.DecodeRequest(llmprotocol.OpenAIChatV1, []byte(tc.body)); err == nil {
			t.Errorf("DecodeRequest(%s) = nil error, want an error under the default policy", tc.name)
		}
	}
}
