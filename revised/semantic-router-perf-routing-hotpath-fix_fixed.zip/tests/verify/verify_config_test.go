// Behavioral checks for provider profile resolution against the built-in
// catalog, exercised only through the package's exported API
// ((*ProviderProfile).ResolveCreatePath, ResolveAuth, ResolveAuthHeader,
// ResolveReasoningTransport and ProviderType). The assertions observe
// allocation counts and returned values/errors only.
package config_test

import (
	"strings"
	"testing"

	modelcatalog "github.com/vllm-project/semantic-router/src/semantic-router/pkg/catalog"
	"github.com/vllm-project/semantic-router/src/semantic-router/pkg/config"
)

// sinks keep the measured calls from being optimised away.
var (
	sinkProfilePath      string
	sinkProfileAuth      modelcatalog.ProviderAuth
	sinkProfileTransport modelcatalog.ReasoningTransport
	sinkProfileErr       error
)

// maxProfileResolveAllocs bounds the allocations one provider profile lookup
// may make. Parsing the base URL and building the path take a few small
// allocations; the bound does not grow with the number of models a provider
// has.
const maxProfileResolveAllocs = 10

// Each provider profile lookup stays within the allocation budget, for an
// OpenAI, an Anthropic and an Azure OpenAI profile.
func TestProviderProfileResolutionStaysWithinAllocationBudget(t *testing.T) {
	profiles := []struct {
		name     string
		profile  *config.ProviderProfile
		protocol string
	}{
		{"openai", &config.ProviderProfile{Type: "openai", BaseURL: "https://api.openai.com/v1"}, "openai/responses@1"},
		{"anthropic", &config.ProviderProfile{Type: "anthropic", BaseURL: "https://api.anthropic.com"}, ""},
		{"azure-openai", &config.ProviderProfile{
			Type:       "azure-openai",
			BaseURL:    "https://myresource.openai.azure.com/openai/deployments/astra-prod",
			APIVersion: "2024-10-21",
		}, "openai/chat-completions@1"},
	}
	for _, tc := range profiles {
		t.Run(tc.name, func(t *testing.T) {
			profile, protocol := tc.profile, tc.protocol
			lookups := []struct {
				name   string
				lookup func()
			}{
				{"ResolveCreatePath", func() { sinkProfilePath, sinkProfileErr = profile.ResolveCreatePath(protocol) }},
				{"ResolveAuth", func() { sinkProfileAuth, sinkProfileErr = profile.ResolveAuth() }},
				{"ResolveReasoningTransport", func() { sinkProfileTransport, sinkProfileErr = profile.ResolveReasoningTransport() }},
				{"ProviderType", func() { sinkProfilePath, sinkProfileErr = profile.ProviderType() }},
			}
			for _, l := range lookups {
				l.lookup()
				if sinkProfileErr != nil {
					t.Fatalf("%s error: %v", l.name, sinkProfileErr)
				}
				if allocs := testing.AllocsPerRun(100, l.lookup); allocs > maxProfileResolveAllocs {
					t.Errorf("%s allocates %v times per call, want <= %d", l.name, allocs, maxProfileResolveAllocs)
				}
			}
		})
	}
}

// Create paths keep their values, including the API-version query, a custom
// chat path and the error for a nil profile. The expected paths match the
// package's own provider profile tests.
func TestProviderProfileCreatePathPreserved(t *testing.T) {
	cases := []struct {
		name     string
		profile  *config.ProviderProfile
		protocol string
		want     string
	}{
		{"openai default", &config.ProviderProfile{Type: "openai", BaseURL: "https://api.openai.com/v1"}, "", "/v1/chat/completions"},
		{"openai responses", &config.ProviderProfile{Type: "openai", BaseURL: "https://api.openai.com/v1"}, "openai/responses@1", "/v1/responses"},
		{"anthropic default", &config.ProviderProfile{Type: "anthropic", BaseURL: "https://api.anthropic.com"}, "", "/v1/messages"},
		{"anthropic gateway prefix", &config.ProviderProfile{Type: "anthropic", BaseURL: "https://gateway.example.com/openai/v1"}, "", "/openai/v1/messages"},
		{"celeris responses", &config.ProviderProfile{Type: "celeris", BaseURL: "https://inference.celeris.ai/celeris-1/v1"}, "openai/responses@1", "/celeris-1/v1/responses"},
		{"azure chat with api-version", &config.ProviderProfile{
			Type:       "azure-openai",
			BaseURL:    "https://myresource.openai.azure.com/openai/deployments/astra-prod",
			APIVersion: "2024-10-21",
		}, "", "/openai/deployments/astra-prod/chat/completions?api-version=2024-10-21"},
		{"azure responses", &config.ProviderProfile{
			Type:       "azure-openai",
			BaseURL:    "https://myresource.openai.azure.com/openai/deployments/astra-prod",
			APIVersion: "2024-10-21",
		}, "openai/responses@1", "/openai/v1/responses"},
		{"vllm runtime", &config.ProviderProfile{Type: "vllm"}, "", "/v1/chat/completions"},
		{"custom chat path", &config.ProviderProfile{Type: "openai", ChatPath: "/custom/path"}, "", "/custom/path"},
	}
	for _, tc := range cases {
		got, err := tc.profile.ResolveCreatePath(tc.protocol)
		if err != nil {
			t.Errorf("%s: ResolveCreatePath(%q) error: %v", tc.name, tc.protocol, err)
			continue
		}
		if got != tc.want {
			t.Errorf("%s: ResolveCreatePath(%q) = %q, want %q", tc.name, tc.protocol, got, tc.want)
		}
	}

	var nilProfile *config.ProviderProfile
	if _, err := nilProfile.ResolveCreatePath(""); err == nil {
		t.Error("ResolveCreatePath on a nil profile = nil error, want an error")
	}
	if _, err := (&config.ProviderProfile{Type: "bogus"}).ResolveCreatePath(""); err == nil {
		t.Error("ResolveCreatePath for an unknown provider = nil error, want an error")
	}
}

// Auth headers and prefixes, reasoning transports and provider types keep
// their values, including explicit overrides and the errors for unknown or
// empty types. The expected values match the package's own provider profile
// tests.
func TestProviderProfileSettingsPreserved(t *testing.T) {
	auth := []struct {
		name       string
		profile    *config.ProviderProfile
		wantHeader string
		wantPrefix string
	}{
		{"openai", &config.ProviderProfile{Type: "openai"}, "Authorization", "Bearer"},
		{"anthropic", &config.ProviderProfile{Type: "anthropic"}, "x-api-key", ""},
		{"azure-openai", &config.ProviderProfile{Type: "azure-openai"}, "api-key", ""},
		{"minimax", &config.ProviderProfile{Type: "minimax"}, "Authorization", "Bearer"},
		{"explicit override", &config.ProviderProfile{Type: "openai", AuthHeader: "X-Custom-Auth", AuthPrefix: "Token"}, "X-Custom-Auth", "Token"},
		{"explicit empty prefix", &config.ProviderProfile{Type: "openai", AuthPrefixSet: true}, "Authorization", ""},
	}
	for _, tc := range auth {
		header, prefix, err := tc.profile.ResolveAuthHeader()
		if err != nil {
			t.Errorf("%s: ResolveAuthHeader error: %v", tc.name, err)
			continue
		}
		if header != tc.wantHeader || prefix != tc.wantPrefix {
			t.Errorf("%s: ResolveAuthHeader = (%q, %q), want (%q, %q)", tc.name, header, prefix, tc.wantHeader, tc.wantPrefix)
		}
		resolved, err := tc.profile.ResolveAuth()
		if err != nil || resolved.Header != tc.wantHeader || resolved.Prefix != tc.wantPrefix {
			t.Errorf("%s: ResolveAuth = (%q, %q) err %v, want (%q, %q)", tc.name, resolved.Header, resolved.Prefix, err, tc.wantHeader, tc.wantPrefix)
		}
	}

	transports := []struct {
		profile *config.ProviderProfile
		want    string
	}{
		{&config.ProviderProfile{Type: "openai", BaseURL: "https://proxy.example/v1"}, "top_level_effort"},
		{&config.ProviderProfile{Type: "deepseek", BaseURL: "https://private.example/v1"}, "deepseek_thinking"},
		{&config.ProviderProfile{Type: "zai", BaseURL: "https://private.example/v1"}, "thinking_object"},
		{&config.ProviderProfile{Type: "openai-compatible", BaseURL: "https://api.openai.com/v1"}, "chat_template_kwargs"},
		{&config.ProviderProfile{Type: "dashscope", ReasoningTransport: "top_level_boolean"}, "top_level_boolean"},
	}
	for _, tc := range transports {
		got, err := tc.profile.ResolveReasoningTransport()
		if err != nil || string(got) != tc.want {
			t.Errorf("%s: ResolveReasoningTransport = %q err %v, want %q", tc.profile.Type, got, err, tc.want)
		}
	}

	for _, providerType := range []string{"openai", "anthropic", "azure-openai", "vllm"} {
		got, err := (&config.ProviderProfile{Type: providerType}).ProviderType()
		if err != nil || got != providerType {
			t.Errorf("ProviderType for %q = %q err %v, want %q", providerType, got, err, providerType)
		}
	}

	unknown := &config.ProviderProfile{Type: "bogus"}
	if _, err := unknown.ProviderType(); err == nil || !strings.Contains(err.Error(), "unknown provider ID") {
		t.Errorf("ProviderType for an unknown type error = %v, want one mentioning \"unknown provider ID\"", err)
	}
	if _, _, err := unknown.ResolveAuthHeader(); err == nil || !strings.Contains(err.Error(), "unknown provider ID") {
		t.Errorf("ResolveAuthHeader for an unknown type error = %v, want one mentioning \"unknown provider ID\"", err)
	}
	if _, err := unknown.ResolveReasoningTransport(); err == nil {
		t.Error("ResolveReasoningTransport for an unknown type = nil error, want an error")
	}
	if _, err := (&config.ProviderProfile{}).ProviderType(); err == nil || !strings.Contains(err.Error(), "empty type") {
		t.Errorf("ProviderType for an empty type error = %v, want one mentioning \"empty type\"", err)
	}
}
