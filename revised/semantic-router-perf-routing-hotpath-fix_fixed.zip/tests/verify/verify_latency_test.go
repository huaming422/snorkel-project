// Behavioral checks for the per-model latency history, exercised only through
// the package's exported API (ResetTTFT/ResetTPOT, UpdateTTFT/UpdateTPOT,
// GetTTFT, GetTTFTPercentile/GetTPOTPercentile, GetTTFTLastUpdated and
// EstimateCacheProbability). The assertions observe allocation counts and
// returned values only, so any storage that keeps each model's last
// MaxTTFTHistorySize/MaxTPOTHistorySize observations satisfies them.
package latency_test

import (
	"math"
	"math/rand/v2"
	"slices"
	"sort"
	"testing"
	"time"

	latency "github.com/vllm-project/semantic-router/src/semantic-router/pkg/latency"
)

// sinks keep the measured calls from being optimised away.
var (
	sinkFloat float64
	sinkBool  bool
)

// sameFloats compares two values treating any NaN as equal to any NaN, so the
// expected and observed percentiles agree on the ordering of non-finite inputs.
func sameFloats(a, b float64) bool {
	return a == b || (math.IsNaN(a) && math.IsNaN(b))
}

// expectedPercentile reads the pct percentile from an ascending slice with
// linear interpolation: index = pct*(n-1), lerp between the two neighbouring
// samples.
func expectedPercentile(sorted []float64, pct float64) float64 {
	n := len(sorted)
	if n == 0 {
		return 0
	}
	index := pct * float64(n-1)
	lower := int(index)
	upper := lower + 1
	if upper >= n {
		return sorted[n-1]
	}
	weight := index - float64(lower)
	return sorted[lower]*(1-weight) + sorted[upper]*weight
}

// lastWindow returns the last size values of history in ascending order.
func lastWindow(history []float64, size int) []float64 {
	start := len(history) - size
	if start < 0 {
		start = 0
	}
	window := slices.Clone(history[start:])
	sort.Float64s(window)
	return window
}

// sampleLatency draws one positive observation; with nonFinite set, about one
// in 25 draws is NaN or +Inf instead.
func sampleLatency(rng *rand.Rand, nonFinite bool) float64 {
	value := 0.05 + rng.Float64()
	if nonFinite {
		switch rng.IntN(50) {
		case 0:
			value = math.NaN()
		case 1:
			value = math.Inf(1)
		}
	}
	return value
}

// Reading a percentile or the cache-warmth estimate does not allocate, with two
// observations, part way to a full history and after it is full.
func TestLatencyPercentileReadDoesNotAllocate(t *testing.T) {
	const model = "m-alloc"
	latency.ResetTTFT()
	latency.ResetTPOT()
	rng := rand.New(rand.NewPCG(1, 2))

	recorded := 0
	for _, total := range []int{2, 500, 2*latency.MaxTTFTHistorySize + 17} {
		for ; recorded < total; recorded++ {
			latency.UpdateTTFT(model, sampleLatency(rng, false))
			latency.UpdateTPOT(model, sampleLatency(rng, false))
		}
		input := latency.CacheEstimationInput{Model: model, TTFTSeconds: 0.4, Now: time.Now().Add(30 * time.Second)}

		reads := []struct {
			name string
			read func()
		}{
			{"GetTTFTPercentile", func() { sinkFloat, sinkBool = latency.GetTTFTPercentile(model, 95) }},
			{"GetTPOTPercentile", func() { sinkFloat, sinkBool = latency.GetTPOTPercentile(model, 95) }},
			{"EstimateCacheProbability", func() { sinkFloat = latency.EstimateCacheProbability(input) }},
		}
		for _, r := range reads {
			r.read()
			if allocs := testing.AllocsPerRun(100, r.read); allocs != 0 {
				t.Errorf("%s with %d observations allocates %v times per call, want 0", r.name, total, allocs)
			}
		}
	}
}

// Percentile values match a freshly sorted copy of each history's last N
// observations. Two models are fed in turn, and TTFT and TPOT get different
// values, so each history must stay separate. The values are checked at the
// one- and two-observation fallback (the model's current TTFT/TPOT), at the
// first interpolated read, part way to full, exactly full, one past full and
// well past full, with NaN and +Inf mixed in.
func TestLatencyPercentileEqualsSortedWindow(t *testing.T) {
	latency.ResetTTFT()
	latency.ResetTPOT()
	rng := rand.New(rand.NewPCG(3, 4))

	models := []string{"m-values-a", "m-values-b"}
	ttftHistory := map[string][]float64{}
	tpotHistory := map[string][]float64{}

	stages := []int{
		1, 2, latency.MinObservationsForPercentile, 500,
		latency.MaxTTFTHistorySize, latency.MaxTTFTHistorySize + 1, 2*latency.MaxTTFTHistorySize + 41,
	}
	for _, total := range stages {
		for len(ttftHistory[models[0]]) < total {
			for _, model := range models {
				// UpdateTTFT/UpdateTPOT record every value that is not <= 0, so
				// the positive, NaN and +Inf values drawn here are all kept.
				ttft := sampleLatency(rng, true)
				tpot := sampleLatency(rng, true)
				ttftHistory[model] = append(ttftHistory[model], ttft)
				tpotHistory[model] = append(tpotHistory[model], tpot)
				latency.UpdateTTFT(model, ttft)
				latency.UpdateTPOT(model, tpot)
			}
		}

		for _, model := range models {
			ttftWindow := lastWindow(ttftHistory[model], latency.MaxTTFTHistorySize)
			tpotWindow := lastWindow(tpotHistory[model], latency.MaxTPOTHistorySize)
			ttftCurrent, _ := latency.GetTTFT(model)
			tpotCurrent, _ := latency.GetTPOT(model)

			for _, percentile := range []int{1, 10, 20, 50, 80, 95, 100} {
				wantTTFT, wantTPOT := ttftCurrent, tpotCurrent
				if total >= latency.MinObservationsForPercentile {
					wantTTFT = expectedPercentile(ttftWindow, float64(percentile)/100)
					wantTPOT = expectedPercentile(tpotWindow, float64(percentile)/100)
				}

				got, ok := latency.GetTTFTPercentile(model, percentile)
				if !ok || !sameFloats(got, wantTTFT) {
					t.Errorf("%s after %d observations: GetTTFTPercentile p%d = %v (ok=%v), want %v",
						model, total, percentile, got, ok, wantTTFT)
				}
				got, ok = latency.GetTPOTPercentile(model, percentile)
				if !ok || !sameFloats(got, wantTPOT) {
					t.Errorf("%s after %d observations: GetTPOTPercentile p%d = %v (ok=%v), want %v",
						model, total, percentile, got, ok, wantTPOT)
				}
			}
		}
	}
}

// expectedWarmth recomputes the cache-warmth estimate from the TTFT history's
// 20th, 50th and 80th percentiles, its observation count and its age, using
// the package's exported tuning constants.
func expectedWarmth(observed, warm, ref, cold float64, count int, ageSeconds float64) float64 {
	clamp := func(v, lo, hi float64) float64 { return math.Max(lo, math.Min(v, hi)) }
	spread := cold - warm
	scale := math.Max(spread, ref*latency.MinRelativeScaleFloor)
	raw := clamp((cold-observed)/scale, 0, 1)
	countReliability := clamp(
		float64(count-latency.CountReliabilityStart)/
			float64(latency.CountReliabilityFull-latency.CountReliabilityStart),
		0, 1,
	)
	spreadReliability := clamp((spread/ref)/latency.TargetRelativeSpread, 0, 1)
	freshness := math.Exp(-math.Ln2 * ageSeconds / latency.FreshnessHalfLifeSeconds)
	reliability := countReliability * spreadReliability * freshness
	return clamp(reliability*raw+(1.0-reliability)*latency.CacheWarmthPrior, 0, 1)
}

// The cache-warmth estimate keeps its value: for a history part way to full
// and one past full, and for observed TTFTs below, inside and above the
// warm-cold range, it equals the value recomputed from the history's
// percentiles, observation count and age.
func TestCacheWarmthEstimateMatchesHistory(t *testing.T) {
	const model = "m-warmth"
	latency.ResetTTFT()
	rng := rand.New(rand.NewPCG(5, 6))

	recorded := 0
	for _, total := range []int{20, latency.MaxTTFTHistorySize + 250} {
		for ; recorded < total; recorded++ {
			latency.UpdateTTFT(model, 0.2+rng.Float64())
		}
		warm, _ := latency.GetTTFTPercentile(model, 20)
		ref, _ := latency.GetTTFTPercentile(model, 50)
		cold, _ := latency.GetTTFTPercentile(model, 80)
		updated, ok := latency.GetTTFTLastUpdated(model)
		if !ok {
			t.Fatalf("GetTTFTLastUpdated(%q) found no history", model)
		}
		const ageSeconds = 30
		now := updated.Add(ageSeconds * time.Second)

		for _, observed := range []float64{warm - 0.05, (warm + cold) / 2, ref, cold + 0.05} {
			got := latency.EstimateCacheProbability(latency.CacheEstimationInput{Model: model, TTFTSeconds: observed, Now: now})
			want := expectedWarmth(observed, warm, ref, cold, total, ageSeconds)
			if math.Abs(got-want) > 1e-12 {
				t.Errorf("after %d observations, EstimateCacheProbability(observed=%v) = %v, want %v",
					total, observed, got, want)
			}
		}
	}
}
