// Behavioral checks for the event logging helpers, exercised only through the
// package's exported API (LogEvent, DebugEvent, WarnEvent, ErrorEvent and their
// Component* forms) and zap's public test observer. The assertions observe
// allocation counts, emitted fields, levels, messages and sampler keep/drop
// counts only.
package logging_test

import (
	"testing"
	"time"

	logging "github.com/vllm-project/semantic-router/src/semantic-router/pkg/observability/logging"
	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"
	"go.uber.org/zap/zaptest/observer"
)

// observeGlobal routes the global logger to an in-memory observer at Info level
// behind a sampler that keeps the first two entries of each message within a
// long tick and drops the rest. It returns the observed-log handle and restores
// the previous global logger on cleanup.
func observeGlobal(t *testing.T) *observer.ObservedLogs {
	t.Helper()
	return observeGlobalAt(t, zapcore.InfoLevel)
}

// observeGlobalAt is observeGlobal with the observer at the given level.
func observeGlobalAt(t *testing.T, level zapcore.Level) *observer.ObservedLogs {
	t.Helper()
	core, logs := observer.New(level)
	sampled := zapcore.NewSamplerWithOptions(core, time.Hour, 2, 0)
	restore := zap.ReplaceGlobals(zap.New(sampled))
	t.Cleanup(restore)
	return logs
}

// An event the logger does not write costs no allocation: an info, warn or
// error event repeated past the sampler's keep count, a debug event while the
// logger is at Info level, and an info event while it is at Warn level, with
// and without a component.
func TestDroppedEventDoesNotAllocate(t *testing.T) {
	fields := map[string]interface{}{"path": "/v1/chat/completions", "response_code": 200}

	events := []struct {
		name  string
		level zapcore.Level
		emit  func()
	}{
		{"ComponentEvent", zapcore.InfoLevel, func() { logging.ComponentEvent("gateway", "access", fields) }},
		{"ComponentWarnEvent", zapcore.InfoLevel, func() { logging.ComponentWarnEvent("proxy", "slow_backend", fields) }},
		{"ComponentErrorEvent", zapcore.InfoLevel, func() { logging.ComponentErrorEvent("proxy", "backend_failed", fields) }},
		{"ComponentDebugEvent", zapcore.InfoLevel, func() { logging.ComponentDebugEvent("router", "route_trace", fields) }},
		{"LogEvent", zapcore.InfoLevel, func() { logging.LogEvent("routed", fields) }},
		{"WarnEvent", zapcore.InfoLevel, func() { logging.WarnEvent("retrying", fields) }},
		{"ErrorEvent", zapcore.InfoLevel, func() { logging.ErrorEvent("request_failed", fields) }},
		{"DebugEvent", zapcore.InfoLevel, func() { logging.DebugEvent("decision_trace", fields) }},
		{"ComponentEvent below Warn", zapcore.WarnLevel, func() { logging.ComponentEvent("gateway", "access_quiet", fields) }},
		{"LogEvent below Warn", zapcore.WarnLevel, func() { logging.LogEvent("routed_quiet", fields) }},
	}
	for _, ev := range events {
		t.Run(ev.name, func(t *testing.T) {
			observeGlobalAt(t, ev.level)
			// Two calls use up the sampler's keep count for this message, so
			// every measured call is dropped by the sampler or the level.
			ev.emit()
			ev.emit()
			if allocs := testing.AllocsPerRun(100, ev.emit); allocs != 0 {
				t.Errorf("a dropped %s allocates %v times, want 0", ev.name, allocs)
			}
		})
	}
}

// Field content and precedence are preserved: the component helpers add the
// event name and component when the caller omits them, the caller's own
// event/component values win when supplied, the plain helpers add only the
// event name, and each entry is written at its helper's level with the event
// name as its message. The logger is at Debug level here, so debug entries are
// written too.
func TestComponentEventFieldsAndPrecedence(t *testing.T) {
	logs := observeGlobalAt(t, zapcore.DebugLevel)

	logging.ComponentEvent("gateway", "access", map[string]interface{}{"response_code": 200, "path": "/v1/models"})
	logging.ComponentEvent("gateway", "custom", map[string]interface{}{"event": "own", "component": "own-component"})
	logging.LogEvent("plain", map[string]interface{}{"n": int64(3)})
	logging.ComponentWarnEvent("proxy", "slow_backend", map[string]interface{}{"ms": int64(950)})
	logging.WarnEvent("retrying", map[string]interface{}{"attempt": int64(2), "event": "retry_own"})
	logging.ComponentErrorEvent("proxy", "backend_failed", map[string]interface{}{"component": "pool", "status": int64(502)})
	logging.ErrorEvent("request_failed", map[string]interface{}{"reason": "timeout"})
	logging.DebugEvent("decision_trace", map[string]interface{}{"step": int64(1)})
	logging.ComponentDebugEvent("router", "route_trace", map[string]interface{}{"route": "default"})

	entries := logs.All()
	want := []struct {
		level   zapcore.Level
		message string
		fields  map[string]interface{}
	}{
		{zapcore.InfoLevel, "access", map[string]interface{}{"response_code": int64(200), "path": "/v1/models", "event": "access", "component": "gateway"}},
		{zapcore.InfoLevel, "custom", map[string]interface{}{"event": "own", "component": "own-component"}},
		{zapcore.InfoLevel, "plain", map[string]interface{}{"n": int64(3), "event": "plain"}},
		{zapcore.WarnLevel, "slow_backend", map[string]interface{}{"ms": int64(950), "event": "slow_backend", "component": "proxy"}},
		{zapcore.WarnLevel, "retrying", map[string]interface{}{"attempt": int64(2), "event": "retry_own"}},
		{zapcore.ErrorLevel, "backend_failed", map[string]interface{}{"component": "pool", "status": int64(502), "event": "backend_failed"}},
		{zapcore.ErrorLevel, "request_failed", map[string]interface{}{"reason": "timeout", "event": "request_failed"}},
		{zapcore.DebugLevel, "decision_trace", map[string]interface{}{"step": int64(1), "event": "decision_trace"}},
		{zapcore.DebugLevel, "route_trace", map[string]interface{}{"route": "default", "event": "route_trace", "component": "router"}},
	}
	if len(entries) != len(want) {
		t.Fatalf("got %d entries, want %d", len(entries), len(want))
	}
	for i, entry := range entries {
		if entry.Level != want[i].level || entry.Message != want[i].message {
			t.Errorf("entry %d = %s %q, want %s %q", i, entry.Level, entry.Message, want[i].level, want[i].message)
		}
		got := entry.ContextMap()
		if len(got) != len(want[i].fields) {
			t.Errorf("entry %d fields = %v, want %v", i, got, want[i].fields)
			continue
		}
		for key, value := range want[i].fields {
			if got[key] != value {
				t.Errorf("entry %d field %s = %v, want %v", i, key, got[key], value)
			}
		}
	}
}

// Sampler keep/drop decisions are preserved and happen independent of field
// construction: the first two of a repeated message pass and the rest drop, a
// warn event passes the same way, and a debug event at Info level is dropped.
func TestSamplerDecisionsPreserved(t *testing.T) {
	logs := observeGlobal(t)

	for i := 0; i < 5; i++ {
		logging.ComponentEvent("gateway", "access", map[string]interface{}{"i": i})
		logging.WarnEvent("warned", nil)
	}
	logging.DebugEvent("disabled", map[string]interface{}{"i": 1})

	if got := logs.FilterMessage("access").Len(); got != 2 {
		t.Errorf("access entries = %d, want 2", got)
	}
	if got := logs.FilterMessage("warned").Len(); got != 2 {
		t.Errorf("warned entries = %d, want 2", got)
	}
	if got := logs.FilterMessage("disabled").Len(); got != 0 {
		t.Errorf("debug entries = %d, want 0", got)
	}
}
