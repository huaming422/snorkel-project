// Behavioral checks for provider-operation resolution, exercised only through
// the package's exported API (BuiltIn, (*Registry).ResolveOperation,
// (*Registry).ResolveOperationPath, (*Registry).Provider). The assertions
// observe allocation counts and returned paths/errors only.
package catalog_test

import (
	"encoding/json"
	"testing"

	modelcatalog "github.com/vllm-project/semantic-router/src/semantic-router/pkg/catalog"
)

var sinkResolved modelcatalog.ResolvedOperation

// maxResolveOperationAllocs bounds the allocations one ResolveOperation call
// may make. Building the result and its path takes a few small allocations;
// the bound does not grow with the number of models a provider has.
const maxResolveOperationAllocs = 10

// Resolving a provider operation stays within a small allocation budget, for
// OpenAI with a base path and for Anthropic with its default protocol.
func TestResolveOperationStaysWithinAllocationBudget(t *testing.T) {
	registry, err := modelcatalog.BuiltIn()
	if err != nil {
		t.Fatalf("BuiltIn: %v", err)
	}

	cases := []struct {
		provider, protocol, operation, basePath string
	}{
		{"openai", "openai/responses@1", "create", "/v1"},
		{"anthropic", "", "create", ""},
	}
	for _, tc := range cases {
		resolve := func() {
			sinkResolved, _ = registry.ResolveOperation(tc.provider, tc.protocol, tc.operation, tc.basePath)
		}
		if _, err := registry.ResolveOperation(tc.provider, tc.protocol, tc.operation, tc.basePath); err != nil {
			t.Fatalf("ResolveOperation(%q,%q,%q,%q) error: %v", tc.provider, tc.protocol, tc.operation, tc.basePath, err)
		}
		if allocs := testing.AllocsPerRun(100, resolve); allocs > maxResolveOperationAllocs {
			t.Errorf("ResolveOperation for %s allocates %v times per call, want <= %d", tc.provider, allocs, maxResolveOperationAllocs)
		}
	}
}

// Resolution results and error cases are preserved. The happy-path tuples and
// their expected paths match the catalog's own resolution tests; the error
// cases cover an unknown provider, an unknown protocol and an unsupported
// operation.
func TestResolveOperationBehaviorPreserved(t *testing.T) {
	registry, err := modelcatalog.BuiltIn()
	if err != nil {
		t.Fatalf("BuiltIn: %v", err)
	}

	resolved := []struct {
		name                   string
		provider               string
		protocol               string
		operation              string
		basePath               string
		wantPath               string
		wantUseAPIVersionQuery bool
	}{
		{"OpenAI Responses", "openai", "openai/responses@1", "create", "/v1", "/v1/responses", false},
		{"custom API root", "openai", "openai/chat-completions@1", "create", "/v1beta/openai", "/v1beta/openai/chat/completions", false},
		{"Anthropic inventory", "anthropic", "", "list_models", "", "/v1/models", false},
		{"Azure default Chat", "azure-openai", "", "create", "/openai/deployments/astra-prod", "/openai/deployments/astra-prod/chat/completions", true},
		{"Azure Responses", "azure-openai", "openai/responses@1", "create", "/openai/deployments/astra-prod", "/openai/v1/responses", false},
	}
	for _, tc := range resolved {
		t.Run(tc.name, func(t *testing.T) {
			got, err := registry.ResolveOperation(tc.provider, tc.protocol, tc.operation, tc.basePath)
			if err != nil {
				t.Fatalf("ResolveOperation(%q,%q,%q,%q) error: %v",
					tc.provider, tc.protocol, tc.operation, tc.basePath, err)
			}
			if got.Path != tc.wantPath {
				t.Errorf("path = %q, want %q", got.Path, tc.wantPath)
			}
			if got.UseAPIVersionQuery != tc.wantUseAPIVersionQuery {
				t.Errorf("UseAPIVersionQuery = %t, want %t", got.UseAPIVersionQuery, tc.wantUseAPIVersionQuery)
			}
			// ResolveOperationPath is the thin wrapper over ResolveOperation.
			path, err := registry.ResolveOperationPath(tc.provider, tc.protocol, tc.operation, tc.basePath)
			if err != nil || path != tc.wantPath {
				t.Errorf("ResolveOperationPath = %q (err %v), want %q", path, err, tc.wantPath)
			}
		})
	}

	errorCases := []struct {
		name      string
		provider  string
		protocol  string
		operation string
		basePath  string
	}{
		{"unknown provider", "no-such-provider", "", "create", ""},
		{"unknown protocol", "openai", "anthropic/messages@1", "create", ""},
		{"unsupported operation", "openai", "", "delete_model", ""},
		{"operation off provider", "azure-openai", "", "list_models", ""},
	}
	for _, tc := range errorCases {
		t.Run(tc.name, func(t *testing.T) {
			if _, err := registry.ResolveOperationPath(tc.provider, tc.protocol, tc.operation, tc.basePath); err == nil {
				t.Errorf("ResolveOperationPath(%q,%q,%q,%q) = nil error, want an error",
					tc.provider, tc.protocol, tc.operation, tc.basePath)
			}
		})
	}
}

// mutateProvider changes every collection a caller can reach on a returned
// provider definition, including each model binding's own collections, and
// reports which kinds of collection it found.
func mutateProvider(p *modelcatalog.ProviderDefinition, seen map[string]bool) {
	for i := range p.Protocols {
		p.Protocols[i] = "mutated"
		seen["Protocols"] = true
	}
	for i := range p.SupportedOperations {
		p.SupportedOperations[i] = "mutated"
		seen["SupportedOperations"] = true
	}
	for k := range p.PathOverrides {
		p.PathOverrides[k] = "mutated"
		seen["PathOverrides"] = true
	}
	for k, v := range p.OperationOverrides {
		v.Path = "mutated"
		p.OperationOverrides[k] = v
		seen["OperationOverrides"] = true
	}
	for k := range p.DefaultHeaders {
		p.DefaultHeaders[k] = "mutated"
		seen["DefaultHeaders"] = true
	}
	for i := range p.Models {
		model := &p.Models[i]
		model.ID = "mutated"
		seen["Models"] = true
		for j := range model.Protocols {
			model.Protocols[j] = "mutated"
			seen["Models.Protocols"] = true
		}
		for j := range model.ReasoningModes {
			model.ReasoningModes[j] = "mutated"
			seen["Models.ReasoningModes"] = true
		}
		for j := range model.ReasoningEfforts {
			model.ReasoningEfforts[j] = "mutated"
			seen["Models.ReasoningEfforts"] = true
		}
		for _, efforts := range model.ReasoningEffortsByProtocol {
			for j := range efforts {
				efforts[j] = "mutated"
				seen["Models.ReasoningEffortsByProtocol"] = true
			}
		}
		for k := range model.Restrictions {
			model.Restrictions[k] = "mutated"
			seen["Models.Restrictions"] = true
		}
		if model.Pricing.CacheWritePer1M != nil {
			*model.Pricing.CacheWritePer1M = -1
			seen["Models.Pricing.CacheWritePer1M"] = true
		}
	}
	// Adding keys must not reach the catalog either.
	if p.PathOverrides != nil {
		p.PathOverrides["mutated"] = "mutated"
	}
	if p.DefaultHeaders != nil {
		p.DefaultHeaders["mutated"] = "mutated"
	}
}

// Provider(id) returns a copy the caller can change: for every built-in
// provider, mutating every collection of one returned value, model bindings
// included, leaves a later call identical to what was returned before.
func TestProviderReturnsMutationSafeCopy(t *testing.T) {
	registry, err := modelcatalog.BuiltIn()
	if err != nil {
		t.Fatalf("BuiltIn: %v", err)
	}

	seen := map[string]bool{}
	for _, id := range registry.ProviderIDs() {
		before, ok := registry.Provider(id)
		if !ok {
			t.Fatalf("Provider(%q) not found", id)
		}
		want, err := json.Marshal(before)
		if err != nil {
			t.Fatalf("marshal Provider(%q): %v", id, err)
		}

		first, _ := registry.Provider(id)
		mutateProvider(&first, seen)

		second, _ := registry.Provider(id)
		got, err := json.Marshal(second)
		if err != nil {
			t.Fatalf("marshal Provider(%q): %v", id, err)
		}
		if string(got) != string(want) {
			t.Errorf("Provider(%q) changed after a caller mutated an earlier copy", id)
		}
	}

	// The built-in catalog must give the probe something to change in each of
	// these collections, or the check above proves nothing for them.
	for _, kind := range []string{
		"Protocols", "SupportedOperations", "PathOverrides", "OperationOverrides",
		"DefaultHeaders", "Models", "Models.Protocols",
	} {
		if !seen[kind] {
			t.Errorf("no built-in provider has a non-empty %s to probe", kind)
		}
	}
}
