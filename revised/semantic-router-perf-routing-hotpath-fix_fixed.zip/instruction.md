## Task

Standalone serving mode stops scaling once load ramps up.
Past roughly 32 concurrent clients its throughput flattens out 5 to 10% short of envoy mode when both get the same cores, and giving it more cores hardly helps.
At 64 clients only about 14 of the container's 24 cores are busy, and a scheduler trace shows idle Ps with empty run queues.
So requests are mostly waiting, and the allocation and block profiles from those runs are full of garbage and blocked goroutines.

Please find what each request allocates that it doesn't need and take it out.
When you're done, a read of state the router keeps between requests should allocate only what its answer needs, and nothing when the answer is a plain number.
A structured log event, an event name with its fields, that is dropped because it is sampled out or below the level should cost no allocation once it has been handed to the logging code.
A request also shouldn't allocate again for setup work that comes out the same on every request of its kind.
For the same inputs, nothing the router returns, accepts, rejects or logs may change, and there should be no new config.
