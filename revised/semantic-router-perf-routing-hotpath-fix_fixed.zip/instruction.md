## Task

Standalone serving mode stops scaling once load ramps up.
From about 32 concurrent clients its throughput levels off 5 to 10% below envoy mode on the same core budget, and adding cores barely moves that ceiling.
At 64 clients only about 14 of the container's 24 cores are busy, and a scheduler trace shows idle Ps with empty run queues.
So requests spend their time waiting, not computing, and the allocation and block profiles put most of the garbage and the waiting on work that every request repeats.

I measured allocations per call on one goroutine after warm-up:

- Looking up a model's TTFT or TPOT percentile for latency-aware routing costs 2 allocations per lookup, and the cache-warmth estimate built on the same history allocates too.
- Resolving one provider operation's wire path from the built-in catalog costs 34 for OpenAI and more for providers with more models, and getting a provider profile's create path, auth, reasoning transport or type costs about as much or more.
- A component log event costs 7 even when the sampler drops it, and an event whose level is turned off isn't free either.
- Decoding a small OpenAI chat completion request with unknown fields rejected, which is the default, costs about 220.

Please get those per-request costs down:

- Percentile lookups and the cache-warmth estimate shouldn't allocate at all, whether or not the model's history is full yet.
- Each of those catalog and provider profile lookups should take at most 10 allocations, whatever the provider.
- Handing the event logging helpers a debug, info, warn or error event that the sampler drops, or whose level is off, shouldn't allocate, with or without a component.
- Decoding that chat request should take fewer than 190.

None of the results may change.
Percentiles still come from each model's last 1,000 observations, TTFT and TPOT tracked separately, and the cache-warmth estimate gives the same number for the same history.
Resolved paths, auth settings, reasoning transports, provider types and their errors stay the same.
Log entries keep their message, level and fields, the caller's own `event` or `component` value still wins, and the sampler keeps and drops the same entries.
Request bodies that are accepted or rejected today stay that way, including fields whose name differs only in case.
Code that asks the catalog for a provider's full definition still gets its own copy that it can change freely.
