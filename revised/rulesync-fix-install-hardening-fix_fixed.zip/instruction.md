## Task

We've had a batch of install and lockfile reports that all come down to rulesync trusting the lockfiles and the checkout too much.

With a committed `rulesync-apm.lock.yaml` in the repo, `rulesync install --mode apm` can delete in-project files that apm never installed.
In one report, that cleanup wiped files inside `.git/`.
Stale cleanup should only remove files from the directories apm deploys into.

When a stale entry is itself a symlink, apm and gh project installs just warn and leave the link behind, run after run.
The link itself should be removed, and whatever it points to must stay untouched.
A stale path that goes through a symlinked directory should still be refused.

Ref resolution for Git sources is loose.
Asking for the tag `v1` can return the commit of an unrelated branch such as `feature/v1`, and an annotated tag comes back as the tag object rather than its commit.
Only an exact branch or tag name should match.
If a branch and a tag share the name but point at different commits, refuse the ref as ambiguous instead of picking one.

Pinned commits are trusted blindly, too.
After someone changes a ref in the manifest, `install` keeps reusing the commit locked for the old ref, and `--frozen` doesn't notice.
This applies to apm dependencies and to Git/GitHub sources in `rulesync.lock`.
For an apm dependency that names no ref, the ref is the repo's current default branch, so a lock pinned to a previous default branch is drift as well.
Older lock entries that never recorded the requested ref, and sources that don't declare a ref, should keep their pinned commit.
The declared ref gets recorded the next time such an entry is written.

apm also never checks that a locked commit is on the ref it was locked for.
gh mode already checks its pins against GitHub's compare API.
apm should do the same and fail the dependency when the commit isn't in the ref's history, or fail the whole run under `--frozen`.

Under `--frozen`, an apm run that fails on one dependency (bad content hash, symlinked target) can leave other dependencies' files already written.
A failed frozen run should not write anything.

Two things are not part of this work.
One is catching a lockfile that someone edited to roll a version back.
The other is how `rulesync fetch` treats symlinks sitting at the project root.
The exported install and resolve functions should keep their current signatures.
