## Task

We keep getting install and lockfile reports, and they all come down to rulesync believing whatever the lockfiles and the checkout tell it.

A repo with a committed `rulesync-apm.lock.yaml` can lose files when someone runs `rulesync install --mode apm`, even files apm never put there.
In one report, that cleanup wiped files inside `.git/`.
I'd expect cleanup to leave everything outside `.github/instructions/` and `.github/skills/` alone and warn about what it skipped.
Look-alike folders such as `.github/instructions-old/` aren't apm's either.

Stale symlinks have the opposite problem.
If a file that apm or a gh project install used to manage is now a symlink, every run warns about it and leaves it where it is.
That link should disappear like any other stale file, and the file it points at should stay as it is.
When a folder on the way to a stale file is a symlink, nothing behind that folder should get deleted.

Git sources sometimes install the wrong commit.
Asking for the tag `v1` has given us the commit of a branch called `feature/v1`.
An annotated tag has come back as the tag object instead of the commit it points to.
If the repo has no `v1` at all, only `feature/v1`, I'd rather get a not-found error.
When a branch and a tag are both named `v1` but sit on different commits, please fail with an error that calls the ref ambiguous rather than guessing.
If both point at the same commit, that's fine.

Changing a ref in the manifest doesn't stick either.
Someone switched a dependency to a new ref, ran `install`, and still got the old commit, and `--frozen` passed without a word.
We see this with apm dependencies and with Git/GitHub sources in `rulesync.lock`.
It also happens to an apm dependency with no ref after its repo moved its default branch, say from `main` to `trunk`.
Some of our older `rulesync.lock` files were written before the lock recorded which ref was asked for, and some sources don't set a ref at all.
Those should keep installing their locked commit instead of re-resolving.
It would help if the old entries picked up the ref the next time the lock is written.

Nothing checks that an apm lock's commit really belongs to its ref, either.
Someone could edit the lock to pin a commit that only exists in a fork, and apm would install it.
gh mode already turns such pins down.
For apm, that dependency should fail and keep its old lock entry, and a `--frozen` run should fail outright.

Last, a `--frozen` apm run that fails on one dependency, for example on a content hash or a symlinked target folder, has still left other dependencies' files on disk.
When a frozen run fails, the project should look the way it did before the run.

Please leave two things for later: spotting a lockfile edited to roll a version back, and what `rulesync fetch` does with symlinks in the project root.
Other code calls the install and resolve functions, so keep their signatures as they are.
