// @ts-nocheck
//
// Behavioral checks for ref resolution through the exported, pre-existing
// `resolveRefToSha(url, ref)` in src/lib/git-client.ts. The signature stays the
// same. The promisified `execFile` is mocked the same way the repo's own
// git-client.test.ts mocks it, so no real `git` or network is touched.
//
// Only the returned SHA and whether the call throws are asserted. The
// `ls-remote` argv, the number of calls, their order and any stdout parser are
// left open: one multi-ref query, several single-ref queries, `--heads --tags`
// filtering, or a pattern query matched exactly on the client side all fit.
// The contract checked here:
//   * a branch whose name only ends with the requested ref does not match it,
//   * an annotated tag resolves to its peeled commit, not the tag object,
//   * a branch and a tag of the same name at different commits are refused as
//     ambiguous, and at the same commit they are accepted.

import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const { mockExecFileAsync } = vi.hoisted(() => ({ mockExecFileAsync: vi.fn() }));

vi.mock("node:child_process", () => ({ execFile: vi.fn() }));
vi.mock("node:util", () => ({ promisify: () => mockExecFileAsync }));

import { GitClientError, resetGitCheck, resolveRefToSha } from "./git-client.js";

const SHA = "a".repeat(40);
const URL = "https://example.com/repo.git";

describe("resolveRefToSha", () => {
  beforeEach(() => {
    // `checkGitAvailable()` runs `git --version` through the same mocked
    // execFile; a resolved value keeps the availability probe happy.
    mockExecFileAsync.mockResolvedValue({ stdout: "git version 2.43.0\n" });
  });

  afterEach(() => {
    vi.clearAllMocks();
    resetGitCheck();
  });

  it("ignores a same-suffix branch and returns the peeled commit of an annotated tag", async () => {
    const branchSha = "b".repeat(40);
    const tagObjectSha = "c".repeat(40);
    const tagCommitSha = "d".repeat(40);
    // A branch `feature/v1` shares the suffix `v1` with the requested tag. The
    // tag is annotated, so its own object SHA differs from the commit it points
    // at (the `^{}` peeled line). The result is the peeled commit, never the
    // branch that comes first in the output.
    mockExecFileAsync.mockResolvedValue({
      stdout: [
        `${branchSha}\trefs/heads/feature/v1`,
        `${tagObjectSha}\trefs/tags/v1`,
        `${tagCommitSha}\trefs/tags/v1^{}`,
        "",
      ].join("\n"),
    });

    expect(await resolveRefToSha(URL, "v1")).toBe(tagCommitSha);
  });

  it("does not resolve a ref that only matches by suffix", async () => {
    // Only a branch whose name ends with the requested ref is present; there is
    // no exact `refs/heads/v1` or `refs/tags/v1`, so the ref is not found. The
    // error wording is not pinned.
    mockExecFileAsync.mockResolvedValue({ stdout: `${SHA}\trefs/heads/feature/v1\n` });

    await expect(resolveRefToSha(URL, "v1")).rejects.toThrow();
  });

  it("refuses a branch and a tag of the same name pointing at different commits", async () => {
    mockExecFileAsync.mockResolvedValue({
      stdout: `${"b".repeat(40)}\trefs/heads/v1\n${"c".repeat(40)}\trefs/tags/v1\n`,
    });

    // The message only has to say the ref is ambiguous ("ambiguous",
    // "ambiguity", any casing).
    await expect(resolveRefToSha(URL, "v1")).rejects.toThrow(/ambigu/i);
  });

  it("accepts a branch and a tag of the same name pointing at the same commit", async () => {
    // A branch and a tag that agree on the commit are not ambiguous, so the
    // SHA comes back.
    mockExecFileAsync.mockResolvedValue({
      stdout: `${SHA}\trefs/heads/v1\n${SHA}\trefs/tags/v1\n`,
    });

    expect(await resolveRefToSha(URL, "v1")).toBe(SHA);
  });

  it("returns the resolved commit for an ordinary branch", async () => {
    // Common case: an exact branch match resolves to its commit.
    mockExecFileAsync.mockResolvedValue({ stdout: `${SHA}\trefs/heads/main\n` });

    expect(await resolveRefToSha(URL, "main")).toBe(SHA);
  });
});

// Keep the import referenced so an unused-import lint cannot trip the suite.
void GitClientError;
