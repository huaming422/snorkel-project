// @ts-nocheck
//
// Behavioral checks for the apm install/lock path through the exported,
// pre-existing `installApm({ projectRoot, logger, options })` in
// src/lib/apm/apm-install.ts. The signature stays the same. The GitHubClient is
// mocked the same way the repo's own apm-install.test.ts mocks it, with
// `compareCommits` added to the mock surface (the real client already exposes
// it and gh mode already uses it), and each case runs in a real temp project.
//
// Asserted: files on disk after install, thrown errors,
// `failedDependencyCount`, the written lockfile, and that a warning was logged.
// No internal helper is imported, so helpers can be inlined, renamed or split
// in any way.

import { mkdir, readdir, symlink } from "node:fs/promises";
import { join } from "node:path";

import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { createMockLogger } from "../../test-utils/mock-logger.js";
import { setupTestDirectory } from "../../test-utils/test-directories.js";
import { fileExists, readFileContent, writeFileContent } from "../../utils/file.js";
import { installApm } from "./apm-install.js";
import { getApmLockPath, readApmLock } from "./apm-lock.js";
import { getApmManifestPath } from "./apm-manifest.js";

let mockClientInstance: any;

vi.mock("../github-client.js", () => ({
  GitHubClient: class MockGitHubClient {
    static resolveToken = vi.fn().mockReturnValue(undefined);

    getDefaultBranch(...args: any[]) {
      return mockClientInstance.getDefaultBranch(...args);
    }
    resolveRefToSha(...args: any[]) {
      return mockClientInstance.resolveRefToSha(...args);
    }
    listDirectory(...args: any[]) {
      return mockClientInstance.listDirectory(...args);
    }
    getFileContent(...args: any[]) {
      return mockClientInstance.getFileContent(...args);
    }
    compareCommits(...args: any[]) {
      return mockClientInstance.compareCommits(...args);
    }
  },
  GitHubClientError: class GitHubClientError extends Error {
    statusCode?: number;
    constructor(message: string, statusCode?: number) {
      super(message);
      this.statusCode = statusCode;
    }
  },
  logGitHubAuthHints: vi.fn(),
}));

const VALID_SHA = "a".repeat(40);
const SECOND_SHA = "b".repeat(40);

describe("installApm", () => {
  let testDir: string;
  let cleanup: () => Promise<void>;
  const logger = createMockLogger();

  beforeEach(async () => {
    ({ testDir, cleanup } = await setupTestDirectory());

    mockClientInstance = {
      getDefaultBranch: vi.fn().mockResolvedValue("main"),
      resolveRefToSha: vi.fn().mockResolvedValue(VALID_SHA),
      listDirectory: vi.fn(),
      getFileContent: vi.fn(),
      compareCommits: vi.fn().mockResolvedValue("identical"),
    };
  });

  afterEach(async () => {
    await cleanup();
    vi.clearAllMocks();
  });

  async function writeManifest(content: string): Promise<void> {
    await writeFileContent(getApmManifestPath(testDir), content);
  }

  // A committed lockfile naming `deployedFiles` as stale. No content_hash is
  // written, so the integrity check is skipped and the run reaches stale
  // removal / re-resolution directly.
  function staleLockYaml(deployedFiles: string[]): string {
    return `lockfile_version: "1"
generated_at: "2026-04-20T00:00:00Z"
apm_version: "0.7.7"
dependencies:
  - repo_url: https://github.com/acme/security
    resolved_commit: ${VALID_SHA}
    resolved_ref: v1.0.0
    depth: 1
    package_type: apm_package
    deployed_files:
${deployedFiles.map((file) => `      - ${file}`).join("\n")}
`;
  }

  // ── Stale-removal confinement to the apm deploy directories ──────────────

  it("refuses to remove stale files outside the apm deploy directories", async () => {
    // A committed lockfile names paths all over the checkout: a .git file, an
    // untracked file, and two look-alike prefixes (`instructions-evil`,
    // `skills-extra`) that a bare `startsWith(deployDir)` check would match,
    // plus one genuine stale file inside `.github/instructions/`. Only the
    // genuine one may be removed.
    await writeFileContent(join(testDir, ".git", "HEAD"), "ref: refs/heads/main\n");
    await writeFileContent(join(testDir, "notes.txt"), "untracked");
    await writeFileContent(join(testDir, ".github/instructions-evil/x.md"), "lookalike");
    await writeFileContent(join(testDir, ".github/skills-extra/y.md"), "lookalike");
    await writeFileContent(join(testDir, ".github/instructions/old.instructions.md"), "stale");
    await writeFileContent(
      getApmLockPath(testDir),
      staleLockYaml([
        ".git/HEAD",
        "notes.txt",
        ".github/instructions-evil/x.md",
        ".github/skills-extra/y.md",
        ".github/instructions/old.instructions.md",
      ]),
    );
    await writeManifest(`dependencies:
  apm:
    - acme/security#v1.0.0
`);
    mockClientInstance.listDirectory.mockResolvedValue([]);

    const localLogger = createMockLogger();
    await installApm({ projectRoot: testDir, logger: localLogger, options: { update: true } });

    expect(await fileExists(join(testDir, ".git", "HEAD"))).toBe(true);
    expect(await fileExists(join(testDir, "notes.txt"))).toBe(true);
    expect(await fileExists(join(testDir, ".github/instructions-evil/x.md"))).toBe(true);
    expect(await fileExists(join(testDir, ".github/skills-extra/y.md"))).toBe(true);
    expect(await fileExists(join(testDir, ".github/instructions/old.instructions.md"))).toBe(false);
    // The four kept files and the one removed file carry the contract and do
    // not depend on any message text. Skipping the outside paths must also not
    // be silent: at least one warning is logged, with the wording left open.
    expect(localLogger.warn.mock.calls.length).toBeGreaterThan(0);
  });

  // ── Symlink-safe stale removal (the stale entry is itself a link) ─────────

  it.skipIf(process.platform === "win32")(
    "unlinks a stale file that is itself a symbolic link without touching its target",
    async () => {
      // The stale entry under `.github/instructions/` is a symlink to a kept
      // file one level up. Cleanup removes the link itself and leaves its target
      // untouched; a link that is warned about and left on disk does not meet
      // the contract. Both the removed link and the intact target are asserted.
      await writeFileContent(join(testDir, "kept.md"), "link target");
      await mkdir(join(testDir, ".github", "instructions"), { recursive: true });
      await symlink(
        join("..", "..", "kept.md"),
        join(testDir, ".github", "instructions", "old.instructions.md"),
      );
      await writeFileContent(
        getApmLockPath(testDir),
        staleLockYaml([".github/instructions/old.instructions.md"]),
      );
      await writeManifest(`dependencies:
  apm:
    - acme/security#v1.0.0
`);
      mockClientInstance.listDirectory.mockResolvedValue([]);

      await installApm({ projectRoot: testDir, logger, options: { update: true } });

      // The link is gone (directory is empty) but the target survives unchanged.
      expect(await readdir(join(testDir, ".github", "instructions"))).toEqual([]);
      expect(await readFileContent(join(testDir, "kept.md"))).toBe("link target");
    },
  );

  // ── apm lock-pin ref-history check via compareCommits ────────────────────

  it("refuses a locked commit that is not in the declared ref's history", async () => {
    // First install populates the lock with the resolved commit. Then the
    // client reports the locked commit has `diverged` from the declared ref:
    // a normal install refuses the pin and counts the dependency as failed
    // (leaving the lock unchanged), and a --frozen install rejects.
    await writeManifest(`dependencies:
  apm:
    - acme/security#v1.0.0
`);
    mockClientInstance.listDirectory.mockResolvedValue([]);
    await installApm({ projectRoot: testDir, logger });
    const lockBefore = await readApmLock(testDir);

    mockClientInstance.compareCommits.mockResolvedValue("diverged");
    const result = await installApm({ projectRoot: testDir, logger });

    // The ref-history check relates the locked commit (VALID_SHA) to the
    // declared ref (v1.0.0) through compareCommits, the same compare call gh
    // mode makes. Either base/head orientation is accepted: base=commit/head=ref
    // (identical|ahead) and base=ref/head=commit (identical|behind) ask the same
    // question. owner/repo are the existing method's own parameter names. The
    // accepted status set and the call count are not asserted.
    const compareArgs = mockClientInstance.compareCommits.mock.calls.map((c) => c[0]);
    expect(
      compareArgs.some(
        (a) =>
          a?.owner === "acme" &&
          a?.repo === "security" &&
          [a?.base, a?.head].includes(VALID_SHA) &&
          [a?.base, a?.head].includes("v1.0.0"),
      ),
    ).toBe(true);
    expect(result.failedDependencyCount).toBe(1);
    expect((await readApmLock(testDir))?.dependencies).toEqual(lockBefore?.dependencies);

    // --frozen rejects the diverged pin. Manifest and lock still agree here, so
    // nothing else in this run is expected to throw; the message is not pinned.
    await expect(
      installApm({ projectRoot: testDir, logger, options: { frozen: true } }),
    ).rejects.toThrow();
  });

  it("--frozen refuses a locked default branch that is no longer the default branch", async () => {
    // The dependency declares no ref, so the lock pins the then-default branch
    // `main`. The default branch later moves to `trunk`; under --frozen the
    // install rejects because the declared ref (the new default) no longer
    // matches the locked ref.
    await writeManifest(`dependencies:
  apm:
    - acme/security
`);
    mockClientInstance.listDirectory.mockResolvedValue([]);
    await installApm({ projectRoot: testDir, logger });

    mockClientInstance.getDefaultBranch.mockResolvedValue("trunk");
    // Only the rejection is asserted. Whether the new default is resolved
    // before refusing, and the message text, are left open.
    await expect(
      installApm({ projectRoot: testDir, logger, options: { frozen: true } }),
    ).rejects.toThrow();
  });

  it("re-resolves a dependency whose declared ref no longer matches the lock", async () => {
    // Install at v1.0.0, then edit the manifest to v2.0.0. The next install
    // re-resolves against the new ref and rewrites the lock instead of reusing
    // the commit resolved for the old ref.
    await writeManifest(`dependencies:
  apm:
    - acme/security#v1.0.0
`);
    mockClientInstance.listDirectory.mockResolvedValue([]);
    await installApm({ projectRoot: testDir, logger });

    await writeManifest(`dependencies:
  apm:
    - acme/security#v2.0.0
`);
    mockClientInstance.resolveRefToSha.mockResolvedValue(SECOND_SHA);
    await installApm({ projectRoot: testDir, logger });

    expect(mockClientInstance.resolveRefToSha).toHaveBeenLastCalledWith(
      "acme",
      "security",
      "v2.0.0",
    );
    const lock = await readApmLock(testDir);
    expect(lock?.dependencies[0]).toMatchObject({
      resolved_commit: SECOND_SHA,
      resolved_ref: "v2.0.0",
    });
  });

  // ── --frozen cross-dependency write barrier ──────────────────────────────

  it.skipIf(process.platform === "win32")(
    "--frozen checks every dependency's targets before writing any dependency",
    async () => {
      // Two dependencies, installed concurrently. Only the second deploys
      // skills, and its skills directory is a symlink pointing outside the
      // project, so the second dependency fails. Under --frozen the run fails
      // without the first dependency's file being written.
      //
      // Writing each dependency as soon as it is processed puts the first file
      // on disk before the second dependency fails; checking every target
      // first writes nothing. The second dependency's listings are delayed so
      // that order is fixed instead of left to scheduling. The delay only
      // orders the two dependencies and cannot cause a write by itself.
      const projectRoot = join(testDir, "project");
      const outsideDir = join(testDir, "outside");
      await mkdir(join(projectRoot, ".github"), { recursive: true });
      await mkdir(outsideDir, { recursive: true });
      await symlink(outsideDir, join(projectRoot, ".github", "skills"));
      const lockEntry = (repo: string, deployed: string): string =>
        `  - repo_url: https://github.com/acme/${repo}
    resolved_commit: ${VALID_SHA}
    resolved_ref: v1.0.0
    depth: 1
    package_type: apm_package
    content_hash: "sha256:legacy"
    deployed_files:
      - ${deployed}
`;
      await writeFileContent(
        getApmLockPath(projectRoot),
        `lockfile_version: "1"
generated_at: "2026-04-20T00:00:00Z"
apm_version: "0.7.7"
dependencies:
${lockEntry("first", ".github/instructions/a.instructions.md")}${lockEntry("second", ".github/skills/s/SKILL.md")}`,
      );
      await writeFileContent(
        getApmManifestPath(projectRoot),
        `dependencies:
  apm:
    - acme/first#v1.0.0
    - acme/second#v1.0.0
`,
      );
      // The second dependency's directory listings are delayed so the first
      // dependency always finishes first. The delay never changes which
      // dependency fails.
      const delay = (ms: number): Promise<void> =>
        new Promise((resolve) => {
          setTimeout(resolve, ms);
        });
      mockClientInstance.listDirectory.mockImplementation(
        async (_owner: string, repo: string, path: string) => {
          if (repo === "first" && path === ".apm/instructions") {
            return [
              {
                name: "a.instructions.md",
                path: ".apm/instructions/a.instructions.md",
                type: "file",
                size: 10,
              },
            ];
          }
          if (repo === "second") {
            await delay(80);
          }
          if (repo === "second" && path === ".apm/skills") {
            return [{ name: "s", path: ".apm/skills/s", type: "dir", size: 0 }];
          }
          if (repo === "second" && path === ".apm/skills/s") {
            return [{ name: "SKILL.md", path: ".apm/skills/s/SKILL.md", type: "file", size: 10 }];
          }
          return [];
        },
      );
      mockClientInstance.getFileContent.mockResolvedValue("content");

      // The symlinked target is rejected either way, so the throw and its
      // wording carry little here. The contract is checked below: the first
      // dependency's file is absent after the failed run.
      await expect(
        installApm({ projectRoot, logger, options: { frozen: true } }),
      ).rejects.toThrow();

      // The symlinked skills directory was never written through, and the first
      // dependency's instruction file was never written to disk.
      expect(await readdir(outsideDir)).toEqual([]);
      expect(await fileExists(join(projectRoot, ".github/instructions/a.instructions.md"))).toBe(
        false,
      );
    },
  );
});
