// @ts-nocheck
//
// Behavioral check for gh project-scope stale removal through the exported,
// pre-existing `installGh(...)` in src/lib/gh/gh-install.ts. The signature
// stays the same. Set up the same way as the repo's own gh-install.test.ts:
// the GitHubClient is mocked and the install runs in a real temp dir.
//
// Asserted: files on disk after install. No internal helper is imported.

import { lstat, symlink } from "node:fs/promises";
import { join } from "node:path";

import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import type { SourceEntry } from "../../config/config.js";
import { createMockLogger } from "../../test-utils/mock-logger.js";
import { setupTestDirectory } from "../../test-utils/test-directories.js";
import { readFileContent, writeFileContent } from "../../utils/file.js";
import { installGh } from "./gh-install.js";
import { getGhLockPath, readGhLock, writeGhLock } from "./gh-lock.js";

let mockClientInstance: any;

vi.mock("../github-client.js", () => ({
  GitHubClient: class MockGitHubClient {
    static resolveToken = vi.fn().mockReturnValue(undefined);

    getDefaultBranch(...args: any[]) {
      return mockClientInstance.getDefaultBranch(...args);
    }
    getLatestRelease(...args: any[]) {
      return mockClientInstance.getLatestRelease(...args);
    }
    resolveRefToSha(...args: any[]) {
      return mockClientInstance.resolveRefToSha(...args);
    }
    listDirectory(...args: any[]) {
      return mockClientInstance.listDirectory(...args);
    }
    getFileContent(...args: any[]) {
      return mockClientInstance.getFileContent(...args);
    }
    getFileInfo(...args: any[]) {
      return mockClientInstance.getFileInfo(...args);
    }
    compareCommits(...args: any[]) {
      return mockClientInstance.compareCommits(...args);
    }
    getReleaseByTag(...args: any[]) {
      return mockClientInstance.getReleaseByTag(...args);
    }
  },
  GitHubClientError: class GitHubClientError extends Error {
    statusCode?: number;
    constructor(message: string, statusCode?: number) {
      super(message);
      this.statusCode = statusCode;
    }
  },
  logGitHubAuthHints: vi.fn(),
}));

const VALID_SHA = "a".repeat(40);

function makeNotFound(): Error & { statusCode: number } {
  const err = new Error("Not found") as Error & { statusCode: number };
  err.statusCode = 404;
  return err;
}

function source(overrides: Partial<SourceEntry> & { source: string }): SourceEntry {
  return overrides;
}

describe("installGh", () => {
  let testDir: string;
  let cleanup: () => Promise<void>;
  const logger = createMockLogger();

  beforeEach(async () => {
    ({ testDir, cleanup } = await setupTestDirectory());

    mockClientInstance = {
      getDefaultBranch: vi.fn().mockResolvedValue("main"),
      getLatestRelease: vi.fn().mockResolvedValue({
        tag_name: "v1.0.0",
        name: "v1.0.0",
        prerelease: false,
        draft: false,
        assets: [],
      }),
      resolveRefToSha: vi.fn().mockResolvedValue(VALID_SHA),
      listDirectory: vi.fn(),
      getFileContent: vi.fn(),
      getFileInfo: vi.fn(),
      compareCommits: vi.fn().mockResolvedValue("identical"),
      getReleaseByTag: vi.fn().mockResolvedValue({
        tag_name: "v1.0.0",
        name: "v1.0.0",
        prerelease: false,
        draft: false,
        assets: [],
      }),
    };
  });

  afterEach(async () => {
    await cleanup();
    vi.clearAllMocks();
  });

  // Install a single skill `s`, then append `extraDeployedFiles` to the lock's
  // deployed_files so the next install treats them as stale. Mirrors the repo's
  // own gh-install.test.ts helper.
  function setupSingleSkill(skillName: string): void {
    mockClientInstance.listDirectory.mockImplementation(
      async (_owner: string, _repo: string, path: string) => {
        if (path === "skills") {
          return [{ name: skillName, path: `skills/${skillName}`, type: "dir", size: 0 }];
        }
        if (path === `skills/${skillName}`) {
          return [
            { name: "SKILL.md", path: `skills/${skillName}/SKILL.md`, type: "file", size: 50 },
          ];
        }
        throw makeNotFound();
      },
    );
    mockClientInstance.getFileInfo.mockImplementation(async (_o: string, _r: string, p: string) => {
      if (p === `skills/${skillName}/SKILL.md`) {
        return { name: "SKILL.md", path: p, type: "file", size: 50 };
      }
      return null;
    });
    mockClientInstance.getFileContent.mockImplementation(
      async (_o: string, _r: string, p: string) => `# ${skillName}\n\nbody for ${p}\n`,
    );
  }

  async function installWithExtraLockedFiles(extraDeployedFiles: string[]): Promise<void> {
    setupSingleSkill("s");
    await installGh({ projectRoot: testDir, sources: [source({ source: "owner/repo" })], logger });
    const lock = await readGhLock(testDir);
    const installation = lock?.installations[0];
    if (!lock || !installation) {
      throw new Error("expected a lock entry after the first install");
    }
    installation.deployed_files.push(...extraDeployedFiles);
    await writeGhLock({ projectRoot: testDir, lock });
  }

  it.skipIf(process.platform === "win32")(
    "unlinks a stale file that is itself a symbolic link without touching its target",
    async () => {
      // A stale project-scope entry is a symlink pointing at a kept file.
      // Cleanup removes the link itself and leaves its target intact; a link
      // that is warned about and left on disk does not meet the contract. Both
      // the removed link and the intact target are asserted.
      await writeFileContent(join(testDir, "victim.md"), "victim\n");
      await installWithExtraLockedFiles([".agents/skills/s/old.md"]);
      const linkPath = join(testDir, ".agents/skills/s/old.md");
      await symlink("../../../victim.md", linkPath);

      await installGh({
        projectRoot: testDir,
        sources: [source({ source: "owner/repo" })],
        options: { update: true },
        logger,
      });

      await expect(lstat(linkPath)).rejects.toThrow(/ENOENT/);
      expect(await readFileContent(join(testDir, "victim.md"))).toBe("victim\n");
    },
  );
});

// Keep the path import referenced.
void getGhLockPath;
