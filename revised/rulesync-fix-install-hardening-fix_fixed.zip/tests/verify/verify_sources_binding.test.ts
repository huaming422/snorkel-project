// @ts-nocheck
//
// Behavioral checks for source ref binding through the exported, pre-existing
// `resolveAndFetchSources(...)` in src/lib/sources.ts. The signature stays the
// same. Set up the same way as the repo's own sources.test.ts: the GitHub
// client, the git client, the sources lockfile I/O and the file utils are all
// mocked, which shows which client calls are made (re-resolve or reuse), the
// errors thrown under --frozen, and the lock written back.
//
// No internal predicate or helper is imported, so the ref check can be inlined,
// renamed, or shared across the four call sites. Covered: re-resolve vs reuse
// on the GitHub and git-transport paths, plus the two edge rules (an entry
// with no requestedRef and a dropped declared ref both keep the locked commit).

import { relative, sep } from "node:path";

import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { createMockLogger } from "../test-utils/mock-logger.js";
import { setupTestDirectory } from "../test-utils/test-directories.js";
import {
  directoryExists,
  fileExists,
  listFilePathsRecursively,
  listSubdirectoryNames,
  readFileContent,
  removeDirectoryStrict as removeDirectory,
  removeFileStrict as removeFile,
  writeFileContent,
} from "../utils/file.js";
import { computeRuleIntegrity } from "./sources-lock.js";
import { resolveAndFetchSources } from "./sources.js";

let mockClientInstance: any;

vi.mock("./github-client.js", () => ({
  GitHubClient: class MockGitHubClient {
    static resolveToken = vi.fn().mockReturnValue(undefined);

    getDefaultBranch(...args: any[]) {
      return mockClientInstance.getDefaultBranch(...args);
    }
    listDirectory(...args: any[]) {
      return mockClientInstance.listDirectory(...args);
    }
    getFileContent(...args: any[]) {
      return mockClientInstance.getFileContent(...args);
    }
    resolveRefToSha(...args: any[]) {
      return mockClientInstance.resolveRefToSha(...args);
    }
    listExecutablePaths(...args: any[]) {
      return mockClientInstance.listExecutablePaths(...args);
    }
  },
  GitHubClientError: class GitHubClientError extends Error {
    statusCode?: number;
    constructor(message: string, statusCode?: number) {
      super(message);
      this.statusCode = statusCode;
    }
  },
  logGitHubAuthHints: vi.fn(),
}));

vi.mock("../utils/file.js", async (importOriginal) => {
  const actual = await importOriginal<typeof import("../utils/file.js")>();
  const directoryExistsMock = vi.fn();
  return {
    ...actual,
    applyFileMode: vi.fn(),
    directoryExists: directoryExistsMock,
    directoryExistsStrict: directoryExistsMock,
    fileExists: vi.fn(),
    listFilePathsRecursively: vi.fn(),
    listSubdirectoryNames: vi.fn(),
    readFileContent: vi.fn(),
    removeDirectoryStrict: vi.fn(),
    removeFileStrict: vi.fn(),
    writeFileContent: vi.fn(),
    assertDirectoryIfExists: vi.fn(),
    assertTreeContainsNoSymlinks: vi.fn(),
    assertWritablePathInsideRoot: vi.fn(),
  };
});

const logger = createMockLogger();

const writtenFiles = new Map<string, string>();

vi.mock("./git-client.js", () => ({
  GitClientError: class GitClientError extends Error {
    constructor(message: string, cause?: unknown) {
      super(message);
      this.name = "GitClientError";
      this.cause = cause;
    }
  },
  validateGitUrl: vi.fn(),
  validateRef: vi.fn(),
  checkGitAvailable: vi.fn(),
  resetGitCheck: vi.fn(),
  resolveDefaultRef: vi.fn(),
  resolveRefToSha: vi.fn(),
  fetchSkillFiles: vi.fn(),
}));

vi.mock("./npm-client.js", async (importOriginal) => {
  const actual = await importOriginal<typeof import("./npm-client.js")>();
  return {
    ...actual,
    fetchPackument: vi.fn(),
    fetchTarball: vi.fn(),
    getPackumentVersionDist: vi.fn(),
    resolveNpmToken: vi.fn(),
    resolvePackumentVersion: vi.fn(),
    verifyTarballIntegrity: vi.fn(),
  };
});

vi.mock("./npm-tar.js", async (importOriginal) => {
  const actual = await importOriginal<typeof import("./npm-tar.js")>();
  return {
    ...actual,
    extractPackageTarball: vi.fn(),
  };
});

vi.mock("./sources-lock.js", async (importOriginal) => {
  const actual = await importOriginal<typeof import("./sources-lock.js")>();
  return {
    ...actual,
    readLockFile: vi.fn().mockResolvedValue({ lockfileVersion: 1, sources: {} }),
    writeLockFile: vi.fn().mockResolvedValue(undefined),
  };
});

vi.mock("./npm-sources-lock.js", async (importOriginal) => {
  const actual = await importOriginal<typeof import("./npm-sources-lock.js")>();
  return {
    ...actual,
    readNpmLockFile: vi.fn().mockResolvedValue({ lockfileVersion: 1, sources: {} }),
    writeNpmLockFile: vi.fn().mockResolvedValue(undefined),
  };
});

describe("resolveAndFetchSources ref binding", () => {
  let testDir: string;
  let cleanup: () => Promise<void>;

  beforeEach(async () => {
    ({ testDir, cleanup } = await setupTestDirectory());
    vi.spyOn(process, "cwd").mockReturnValue(testDir);

    mockClientInstance = {
      getDefaultBranch: vi.fn().mockResolvedValue("main"),
      resolveRefToSha: vi.fn().mockResolvedValue("abc123def456"),
      listDirectory: vi.fn().mockResolvedValue([]),
      getFileContent: vi.fn().mockResolvedValue("file content"),
      listExecutablePaths: vi.fn().mockResolvedValue({ paths: new Set(), truncated: false }),
    };

    vi.mocked(directoryExists).mockResolvedValue(false);
    vi.mocked(fileExists).mockResolvedValue(false);
    vi.mocked(listSubdirectoryNames).mockResolvedValue([]);
    writtenFiles.clear();
    vi.mocked(readFileContent).mockImplementation(
      async (path: string) => writtenFiles.get(path) ?? "",
    );
    // The in-memory files join the real ones on disk, mirroring the repo's own
    // sources.test.ts so a curated skill written by one install is read back by
    // the next.
    const actualFile = await vi.importActual<typeof import("../utils/file.js")>("../utils/file.js");
    vi.mocked(listFilePathsRecursively).mockImplementation(async (dirPath, options) => {
      const inMemory = [...writtenFiles.keys()]
        .filter((path) => path.startsWith(`${dirPath}${sep}`))
        .map((path) => relative(dirPath, path));
      const onDisk = await actualFile.listFilePathsRecursively(dirPath, options);
      return [...new Set([...onDisk, ...inMemory])].toSorted();
    });
    vi.mocked(removeDirectory).mockResolvedValue(undefined);
    vi.mocked(removeFile).mockResolvedValue(undefined);
    vi.mocked(writeFileContent).mockImplementation(async (path: string, content: string) => {
      writtenFiles.set(path, content);
    });
  });

  afterEach(async () => {
    await cleanup();
    vi.clearAllMocks();
  });

  // ── GitHub transport ─────────────────────────────────────────────────────

  it("re-resolves a GitHub source whose declared ref differs from the locked requestedRef", async () => {
    const { readLockFile } = await import("./sources-lock.js");
    vi.mocked(readLockFile).mockResolvedValue({
      lockfileVersion: 1,
      sources: {
        "org/repo": {
          resolvedRef: "locked-sha-123",
          requestedRef: "main",
          skills: { "my-skill": { integrity: "sha256-old-hash" } },
        },
      },
    });
    mockClientInstance.resolveRefToSha.mockResolvedValue("new-sha-456");
    mockClientInstance.listDirectory.mockResolvedValue([]);

    await resolveAndFetchSources({
      logger,
      sources: [{ source: "org/repo", ref: "v2" }],
      projectRoot: testDir,
    });

    // The declared ref v2 differs from the locked main, so v2 is resolved
    // again and the locked commit is not reused.
    expect(mockClientInstance.resolveRefToSha).toHaveBeenCalledWith("org", "repo", "v2");
    expect(mockClientInstance.listDirectory).not.toHaveBeenCalledWith(
      "org",
      "repo",
      expect.anything(),
      "locked-sha-123",
    );
  });

  it("refuses under --frozen when the declared ref differs from the locked requestedRef", async () => {
    const { readLockFile } = await import("./sources-lock.js");
    vi.mocked(readLockFile).mockResolvedValue({
      lockfileVersion: 1,
      sources: {
        "org/repo": {
          resolvedRef: "locked-sha-123",
          requestedRef: "main",
          skills: { "my-skill": { integrity: "sha256-old-hash" } },
        },
      },
    });

    // --frozen fails on the ref drift instead of reusing the locked commit.
    // Only the rejection is asserted; whether the new ref is resolved before
    // refusing, and the message format, are left open.
    await expect(
      resolveAndFetchSources({
        logger,
        sources: [{ source: "org/repo", ref: "v2" }],
        projectRoot: testDir,
        options: { frozen: true },
      }),
    ).rejects.toThrow();
  });

  it("keeps the locked commit of an entry that records no requestedRef", async () => {
    const { readLockFile, writeLockFile } = await import("./sources-lock.js");
    vi.mocked(readLockFile).mockResolvedValue({
      lockfileVersion: 1,
      sources: {
        "org/repo": {
          resolvedRef: "locked-sha-123",
          skills: { "my-skill": { integrity: "sha256-old-hash" } },
        },
      },
    });
    // Curated skill missing on disk, so it is fetched again at the locked commit
    // and the entry rewritten with the now-declared ref.
    vi.mocked(directoryExists).mockResolvedValue(false);
    mockClientInstance.listDirectory.mockImplementation(
      async (_owner: string, _repo: string, path: string) => {
        if (path === "skills") {
          return [{ name: "my-skill", path: "skills/my-skill", type: "dir" }];
        }
        if (path === "skills/my-skill") {
          return [{ name: "SKILL.md", path: "skills/my-skill/SKILL.md", type: "file", size: 100 }];
        }
        return [];
      },
    );
    mockClientInstance.getFileContent.mockResolvedValue("skill content");

    await resolveAndFetchSources({
      logger,
      sources: [{ source: "org/repo", ref: "v2" }],
      projectRoot: testDir,
    });
    // A legacy entry with no requestedRef still matches and reuses the locked
    // commit instead of being resolved again.
    expect(mockClientInstance.listDirectory).toHaveBeenCalledWith(
      "org",
      "repo",
      "skills",
      "locked-sha-123",
    );
    const writtenLock = vi.mocked(writeLockFile).mock.calls.at(-1)?.[0].lock;
    expect(writtenLock?.sources["org/repo"]).toMatchObject({
      resolvedRef: "locked-sha-123",
      requestedRef: "v2",
    });

    // A second --frozen run against the same legacy lock (no requestedRef)
    // still matches the declared ref, so nothing is resolved again here
    // either.
    await resolveAndFetchSources({
      logger,
      sources: [{ source: "org/repo", ref: "v2" }],
      projectRoot: testDir,
      options: { frozen: true },
    });
    expect(mockClientInstance.resolveRefToSha).not.toHaveBeenCalled();
  });

  it("keeps the locked commit when the declared ref is dropped", async () => {
    // With no declared ref the locked requestedRef is the default branch it
    // resolved to, which offline looks the same as a dropped ref, so it still
    // matches under --frozen without being resolved again.
    const { readLockFile } = await import("./sources-lock.js");
    vi.mocked(readLockFile).mockResolvedValue({
      lockfileVersion: 1,
      sources: {
        "org/repo": {
          resolvedRef: "locked-sha-123",
          requestedRef: "v1",
          skills: { "my-skill": { integrity: "sha256-old-hash" } },
        },
      },
    });
    mockClientInstance.listDirectory.mockResolvedValue([]);

    await resolveAndFetchSources({
      logger,
      sources: [{ source: "org/repo" }],
      projectRoot: testDir,
      options: { frozen: true },
    });

    expect(mockClientInstance.resolveRefToSha).not.toHaveBeenCalled();
  });

  // ── git transport (sources path and rules path) ──────────────────────────

  it("re-resolves a git source whose declared ref differs from the locked requestedRef", async () => {
    const { fetchSkillFiles, resolveRefToSha } = await import("./git-client.js");
    const { readLockFile } = await import("./sources-lock.js");
    const source = "https://example.com/team/assets.git";
    const newSha = "a".repeat(40);
    vi.mocked(readLockFile).mockResolvedValue({
      lockfileVersion: 1,
      sources: {
        [source]: {
          requestedRef: "main",
          resolvedRef: "b".repeat(40),
          skills: { shared: { integrity: "sha256-old-skill" } },
        },
      },
    });
    vi.mocked(resolveRefToSha).mockResolvedValue(newSha);
    vi.mocked(fetchSkillFiles).mockResolvedValue([]);

    await resolveAndFetchSources({
      logger,
      sources: [{ source, transport: "git", ref: "release" }],
      projectRoot: testDir,
    });

    expect(resolveRefToSha).toHaveBeenCalledWith(source, "release");
    expect(fetchSkillFiles).toHaveBeenCalledWith(
      expect.objectContaining({ url: source, ref: "release", resolvedRef: newSha }),
    );
  });

  it("refuses under --frozen when a git source's declared ref differs from the locked requestedRef", async () => {
    const { readLockFile } = await import("./sources-lock.js");
    const source = "https://example.com/team/assets.git";
    vi.mocked(readLockFile).mockResolvedValue({
      lockfileVersion: 1,
      sources: {
        [source]: {
          requestedRef: "main",
          resolvedRef: "b".repeat(40),
          skills: { shared: { integrity: "sha256-old-skill" } },
        },
      },
    });

    // --frozen fails the whole run on the ref drift instead of reusing the
    // commit locked for main. Only the rejection is asserted.
    await expect(
      resolveAndFetchSources({
        logger,
        sources: [{ source, transport: "git", ref: "release" }],
        projectRoot: testDir,
        options: { frozen: true },
      }),
    ).rejects.toThrow();
  });

  it("re-resolves git-transport rules whose declared ref differs from the locked requestedRef", async () => {
    const { fetchSkillFiles, resolveRefToSha } = await import("./git-client.js");
    const { readLockFile } = await import("./sources-lock.js");
    const source = "https://example.com/team/rules.git";
    const newSha = "a".repeat(40);
    vi.mocked(readLockFile).mockResolvedValue({
      lockfileVersion: 1,
      sources: {
        [source]: {
          requestedRef: "main",
          resolvedRef: "b".repeat(40),
          skills: {},
          rules: { "testing-guidelines": { integrity: computeRuleIntegrity("old rule") } },
          ruleSelection: ["testing-guidelines"],
          rulesPath: "exports/rules",
          resolvedRuleNames: ["testing-guidelines"],
        },
      },
    });
    vi.mocked(resolveRefToSha).mockResolvedValue(newSha);
    vi.mocked(fetchSkillFiles).mockResolvedValue([
      {
        relativePath: "testing-guidelines.md",
        content: "---\ntargets: ['*']\n---\nUse Vitest.",
        size: 50,
      },
    ]);

    await resolveAndFetchSources({
      logger,
      sources: [
        {
          source,
          transport: "git",
          ref: "release",
          rules: ["testing-guidelines"],
          rulesPath: "exports/rules",
        },
      ],
      projectRoot: testDir,
    });

    // The git-rules path must also honor the declared ref.
    expect(resolveRefToSha).toHaveBeenCalledWith(source, "release");
    expect(fetchSkillFiles).toHaveBeenCalledWith(
      expect.objectContaining({ url: source, ref: "release", resolvedRef: newSha }),
    );
  });
});
