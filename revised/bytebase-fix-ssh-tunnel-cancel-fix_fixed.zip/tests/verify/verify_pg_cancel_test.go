package pg

// This file is injected into backend/plugin/db/pg at test time and runs on its
// own (sibling verify files are not injected alongside it), so every helper it
// needs is defined here with a vtssh/vtpg prefix to avoid colliding with the
// package's own test symbols.

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"database/sql"
	"encoding/pem"
	"io"
	"net"
	"strconv"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/pkg/errors"
	"github.com/stretchr/testify/require"
	"golang.org/x/crypto/ssh"

	storepb "github.com/bytebase/bytebase/backend/generated-go/store"
	v1pb "github.com/bytebase/bytebase/backend/generated-go/v1"
	"github.com/bytebase/bytebase/backend/plugin/db"
)

// TestVerifyQueryConnStopsServerQueryWhenContextEnds runs a query against the
// baked PostgreSQL, directly and over an in-process SSH tunnel. A query whose
// context is canceled or runs out must return with an error, stop running on
// the server, and leave no session behind, and the driver must connect again
// for the next call. A query that ends inside its deadline must return its row.
func TestVerifyQueryConnStopsServerQueryWhenContextEnds(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name      string
		sshTunnel bool
		// timeout is the context deadline; zero cancels the context instead.
		timeout time.Duration
		// finishes runs a query that ends well inside its deadline but outlasts
		// the 10s a stopped query gets to return.
		finishes bool
	}{
		{name: "direct_canceled"},
		{name: "direct_deadline", timeout: 2 * time.Second},
		{name: "direct_finishes", timeout: 60 * time.Second, finishes: true},
		{name: "ssh_tunnel_canceled", sshTunnel: true},
		{name: "ssh_tunnel_deadline", sshTunnel: true, timeout: 2 * time.Second},
		{name: "ssh_tunnel_finishes", sshTunnel: true, timeout: 60 * time.Second, finishes: true},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			dbName, rawDB := vtpgNewDatabase(t)
			dataSource := &storepb.DataSource{
				Host:     "127.0.0.1",
				Port:     "5432",
				Username: "postgres",
			}
			if tc.sshTunnel {
				sshServer := vtsshNewServer(t, 0)
				dataSource.SshHost = sshServer.host
				dataSource.SshPort = sshServer.port
				dataSource.SshUser = sshServer.user
				dataSource.SshPrivateKey = sshServer.privateKey
			}

			background := context.Background()
			driver, err := (&Driver{}).Open(background, storepb.Engine_POSTGRES, db.ConnectionConfig{
				DataSource:        dataSource,
				Password:          "root-password",
				ConnectionContext: db.ConnectionContext{DatabaseName: dbName},
			})
			require.NoError(t, err)
			t.Cleanup(func() { _ = driver.Close(background) })

			conn, err := driver.GetDB().Conn(background)
			require.NoError(t, err)
			t.Cleanup(func() { _ = conn.Close() })
			// Runs first, so a query that outlived its context cannot hold up the closes above.
			t.Cleanup(func() {
				_, _ = rawDB.Exec(`SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = $1 AND pid <> pg_backend_pid()`, dbName)
			})

			ctx, cancel := context.WithCancel(background)
			if tc.timeout > 0 {
				ctx, cancel = context.WithTimeout(background, tc.timeout)
			}
			defer cancel()

			statement := "SELECT pg_sleep(30);"
			if tc.finishes {
				statement = "SELECT 1 AS done FROM (SELECT pg_sleep(12)) AS s;"
			}
			done := make(chan []*v1pb.QueryResult, 1)
			go func() {
				results, err := driver.QueryConn(ctx, conn, statement, db.QueryContext{MaximumSQLResultSize: 1 << 30})
				if err != nil {
					results = []*v1pb.QueryResult{{Error: err.Error()}}
				}
				done <- results
			}()

			const runningQueries = `state = 'active' AND query LIKE '%pg_sleep%'`
			require.Eventually(t, func() bool { return vtpgCountSessions(t, rawDB, dbName, runningQueries) == 1 }, 10*time.Second, 20*time.Millisecond,
				"the query never started on the server")
			if tc.finishes {
				select {
				case results := <-done:
					require.Len(t, results, 1)
					require.Empty(t, results[0].Error, "a query that ended inside its deadline must not fail")
					require.Len(t, results[0].Rows, 1, "a query that ended inside its deadline must return its row")
				case <-time.After(30 * time.Second):
					require.FailNow(t, "QueryConn was still blocked 30s after a 12s query started")
				}
				require.NoError(t, driver.Ping(background), "the driver must keep serving after a query that finished")
				return
			}
			if tc.timeout == 0 {
				cancel()
			}

			select {
			case results := <-done:
				require.Len(t, results, 1)
				require.NotEmpty(t, results[0].Error, "a query whose context ended must return an error")
			case <-time.After(10 * time.Second):
				require.FailNow(t, "QueryConn was still blocked 10s after the query started")
			}
			require.Eventually(t, func() bool { return vtpgCountSessions(t, rawDB, dbName, runningQueries) == 0 }, 10*time.Second, 20*time.Millisecond,
				"the query kept running on the server after its context ended")
			require.Eventually(t, func() bool { return vtpgCountSessions(t, rawDB, dbName, `application_name = 'bytebase'`) == 0 }, 10*time.Second, 20*time.Millisecond,
				"the canceled connection stayed open on the server")

			require.NoError(t, driver.Ping(background), "the driver must reconnect once the canceled connection is discarded")
		})
	}
}

// vtsshSlowOpen and vtsshSlowerOpen are how long the slow bastions take to open
// each forwarded connection, as a bastion far from the server does.
const (
	vtsshSlowOpen   = 1500 * time.Millisecond
	vtsshSlowerOpen = 6 * time.Second
)

// TestVerifyQueryStopsWhenRequestClosesDriver runs a query as one query
// request does: it opens the driver, takes a connection, runs the query, and
// closes the connection and then the driver as soon as the query returns. Over
// the tunnel, the bastion takes openDelay to open each forwarded connection. A
// query whose context is canceled or runs out must still stop running on the
// server and leave no session behind after the driver is closed, and the
// bastion connection must close once that is done. A query that ends inside its
// deadline must return its row, and closing the driver after it must neither
// wait for the slow bastion nor leave the bastion connection open for more
// than a second.
func TestVerifyQueryStopsWhenRequestClosesDriver(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name string
		// openDelay is how long the bastion takes to open each forwarded
		// connection; zero connects directly.
		openDelay time.Duration
		// timeout is the context deadline; zero cancels the context instead.
		timeout  time.Duration
		finishes bool
	}{
		{name: "direct_canceled"},
		{name: "direct_deadline", timeout: 2 * time.Second},
		{name: "ssh_tunnel_canceled", openDelay: vtsshSlowOpen},
		{name: "ssh_tunnel_deadline", openDelay: vtsshSlowOpen, timeout: 2 * time.Second},
		{name: "ssh_tunnel_finishes", openDelay: vtsshSlowOpen, timeout: 60 * time.Second, finishes: true},
		{name: "slower_bastion_canceled", openDelay: vtsshSlowerOpen},
		{name: "slower_bastion_deadline", openDelay: vtsshSlowerOpen, timeout: 2 * time.Second},
		{name: "slower_bastion_finishes", openDelay: vtsshSlowerOpen, timeout: 60 * time.Second, finishes: true},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			dbName, rawDB := vtpgNewDatabase(t)
			dataSource := &storepb.DataSource{
				Host:     "127.0.0.1",
				Port:     "5432",
				Username: "postgres",
			}
			var sshServer *vtsshServer
			if tc.openDelay > 0 {
				sshServer = vtsshNewServer(t, tc.openDelay)
				dataSource.SshHost = sshServer.host
				dataSource.SshPort = sshServer.port
				dataSource.SshUser = sshServer.user
				dataSource.SshPrivateKey = sshServer.privateKey
			}
			// Runs before the bastion stops and the database is dropped, so a query that
			// outlived its request cannot hold them up.
			t.Cleanup(func() {
				_, _ = rawDB.Exec(`SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = $1 AND pid <> pg_backend_pid()`, dbName)
			})

			background := context.Background()
			driver, err := (&Driver{}).Open(background, storepb.Engine_POSTGRES, db.ConnectionConfig{
				DataSource:        dataSource,
				Password:          "root-password",
				ConnectionContext: db.ConnectionContext{DatabaseName: dbName},
			})
			require.NoError(t, err)
			conn, err := driver.GetDB().Conn(background)
			require.NoError(t, err)

			ctx, cancel := context.WithCancel(background)
			if tc.timeout > 0 {
				ctx, cancel = context.WithTimeout(background, tc.timeout)
			}
			defer cancel()

			// The stopped query outlasts the wait for the closes below, so the
			// call returns in time only if the query is stopped.
			statement := "SELECT pg_sleep(60);"
			if tc.finishes {
				statement = "SELECT 1 AS done FROM (SELECT pg_sleep(1)) AS s;"
			}
			// closed reports the query's results once the connection and the
			// driver are closed, and how long closing them took.
			type outcome struct {
				results []*v1pb.QueryResult
				closing time.Duration
			}
			closed := make(chan outcome, 1)
			go func() {
				results, err := driver.QueryConn(ctx, conn, statement, db.QueryContext{MaximumSQLResultSize: 1 << 30})
				if err != nil {
					results = []*v1pb.QueryResult{{Error: err.Error()}}
				}
				// The request's own context ends when it is dropped, but not when
				// only the query's time limit passes.
				requestCtx := ctx
				if tc.timeout > 0 {
					requestCtx = background
				}
				start := time.Now()
				_ = conn.Close()
				_ = driver.Close(requestCtx)
				closed <- outcome{results: results, closing: time.Since(start)}
			}()

			const runningQueries = `state = 'active' AND query LIKE '%pg_sleep%'`
			if !tc.finishes {
				require.Eventually(t, func() bool { return vtpgCountSessions(t, rawDB, dbName, runningQueries) == 1 }, 10*time.Second, 20*time.Millisecond,
					"the query never started on the server")
				if tc.timeout == 0 {
					cancel()
				}
			}

			// A stopped query's cleanup may have to wait for the bastion to open
			// one more forwarded connection.
			wait := 10*time.Second + tc.openDelay
			var got outcome
			select {
			case got = <-closed:
			case <-time.After(30*time.Second + tc.openDelay):
				require.FailNow(t, "the query, or closing the driver after it, was still blocked")
			}
			require.Len(t, got.results, 1)
			if tc.finishes {
				require.Empty(t, got.results[0].Error, "a query that ended inside its deadline must not fail")
				require.Len(t, got.results[0].Rows, 1, "a query that ended inside its deadline must return its row")
				require.Less(t, got.closing, time.Second, "closing the driver after a query that finished must not wait for the bastion")
				vtsshRequireBastionClosed(t, sshServer, time.Second)
				return
			}
			require.NotEmpty(t, got.results[0].Error, "a query whose context ended must return an error")
			require.Less(t, got.closing, wait, "closing the driver after a stopped query must not hang")
			require.Eventually(t, func() bool { return vtpgCountSessions(t, rawDB, dbName, runningQueries) == 0 }, wait, 20*time.Millisecond,
				"the query kept running on the server after its request closed the driver")
			require.Eventually(t, func() bool { return vtpgCountSessions(t, rawDB, dbName, `application_name = 'bytebase'`) == 0 }, wait, 20*time.Millisecond,
				"the stopped query's connection stayed open on the server")
			vtsshRequireBastionClosed(t, sshServer, wait)
		})
	}
}

// vtsshRequireBastionClosed requires that a closed driver no longer holds an
// SSH connection to the bastion within window, if it used one.
func vtsshRequireBastionClosed(t *testing.T, sshServer *vtsshServer, window time.Duration) {
	t.Helper()
	if sshServer == nil {
		return
	}
	require.Eventually(t, func() bool { return sshServer.open.Load() == 0 }, window, 20*time.Millisecond,
		"the closed driver kept its SSH connection to the bastion open")
}

// vtpgDBSeq keeps database names unique across parallel subtests in this binary.
var vtpgDBSeq atomic.Int64

// vtpgNewDatabase creates an isolated database on the baked PostgreSQL and
// returns its name with a superuser handle to it.
func vtpgNewDatabase(t *testing.T) (string, *sql.DB) {
	t.Helper()
	admin, err := sql.Open("pgx", "host=127.0.0.1 port=5432 user=postgres password=root-password database=postgres")
	require.NoError(t, err)
	defer func() { _ = admin.Close() }()
	name := "vtpg_" + strconv.FormatInt(time.Now().UnixNano(), 36) + "_" + strconv.FormatInt(vtpgDBSeq.Add(1), 36)
	_, err = admin.Exec("CREATE DATABASE " + name)
	require.NoError(t, err)
	t.Cleanup(func() {
		cleanup, err := sql.Open("pgx", "host=127.0.0.1 port=5432 user=postgres password=root-password database=postgres")
		if err != nil {
			return
		}
		defer func() { _ = cleanup.Close() }()
		_, _ = cleanup.Exec("DROP DATABASE IF EXISTS " + name + " WITH (FORCE)")
	})
	conn, err := sql.Open("pgx", "host=127.0.0.1 port=5432 user=postgres password=root-password database="+name)
	require.NoError(t, err)
	t.Cleanup(func() { _ = conn.Close() })
	return name, conn
}

// vtpgCountSessions counts the sessions in the database, other than the one
// asking, that match the pg_stat_activity condition.
func vtpgCountSessions(t *testing.T, rawDB *sql.DB, dbName, condition string) int {
	t.Helper()
	var count int
	err := rawDB.QueryRow(`SELECT count(*) FROM pg_stat_activity WHERE datname = $1 AND pid <> pg_backend_pid() AND `+condition, dbName).Scan(&count)
	require.NoError(t, err)
	return count
}

// --- in-process SSH bastion + forwarding TCP server (test-only infrastructure) ---

type vtsshServer struct {
	host       string
	port       string
	user       string
	privateKey string
	// open counts the SSH connections the bastion has logged in and not yet seen closed.
	open atomic.Int64
}

// vtsshNewServer starts an SSH server that forwards TCP connections and stops it
// when the test ends. It takes openDelay to open each forwarded connection. It
// runs in the test binary, so the addresses it forwards to are ones the test
// can dial.
func vtsshNewServer(t *testing.T, openDelay time.Duration) *vtsshServer {
	t.Helper()

	_, hostKey, err := ed25519.GenerateKey(rand.Reader)
	require.NoError(t, err)
	hostSigner, err := ssh.NewSignerFromKey(hostKey)
	require.NoError(t, err)

	clientPublicKey, clientKey, err := ed25519.GenerateKey(rand.Reader)
	require.NoError(t, err)
	authorizedKey, err := ssh.NewPublicKey(clientPublicKey)
	require.NoError(t, err)
	clientKeyPEM, err := ssh.MarshalPrivateKey(clientKey, "")
	require.NoError(t, err)

	config := &ssh.ServerConfig{
		PublicKeyCallback: func(_ ssh.ConnMetadata, key ssh.PublicKey) (*ssh.Permissions, error) {
			if !bytes.Equal(key.Marshal(), authorizedKey.Marshal()) {
				return nil, errors.New("unknown public key")
			}
			return nil, nil
		},
	}
	config.AddHostKey(hostSigner)

	server := &vtsshServer{user: "bytebase", privateKey: string(pem.EncodeToMemory(clientKeyPEM))}
	server.host, server.port = vtsshNewTCPServer(t, func(conn net.Conn) { vtsshServeConn(conn, config, openDelay, &server.open) })
	return server
}

// vtsshNewTCPServer listens on a loopback port and runs handle on each
// connection it accepts. A handle that does nothing is a server that never
// answers.
func vtsshNewTCPServer(t *testing.T, handle func(net.Conn)) (host, port string) {
	t.Helper()

	listener, err := net.Listen("tcp", "127.0.0.1:0")
	require.NoError(t, err)
	host, port, err = net.SplitHostPort(listener.Addr().String())
	require.NoError(t, err)

	var mu sync.Mutex
	var conns []net.Conn
	t.Cleanup(func() {
		_ = listener.Close()
		mu.Lock()
		defer mu.Unlock()
		for _, conn := range conns {
			_ = conn.Close()
		}
	})

	go func() {
		for {
			conn, err := listener.Accept()
			if err != nil {
				return
			}
			mu.Lock()
			conns = append(conns, conn)
			mu.Unlock()
			go handle(conn)
		}
	}()
	return host, port
}

func vtsshServeConn(conn net.Conn, config *ssh.ServerConfig, openDelay time.Duration, open *atomic.Int64) {
	_, channels, requests, err := ssh.NewServerConn(conn, config)
	if err != nil {
		return
	}
	open.Add(1)
	defer open.Add(-1)
	go ssh.DiscardRequests(requests)
	for newChannel := range channels {
		if newChannel.ChannelType() != "direct-tcpip" {
			_ = newChannel.Reject(ssh.UnknownChannelType, "only direct-tcpip is supported")
			continue
		}
		go vtsshForwardChannel(newChannel, openDelay)
	}
}

// vtsshForwardChannel serves one direct-tcpip channel as sshd does: after
// openDelay it dials the requested address and closes both sides once either
// one ends.
func vtsshForwardChannel(newChannel ssh.NewChannel, openDelay time.Duration) {
	time.Sleep(openDelay)
	// RFC 4254 section 7.2.
	var request struct {
		DestAddr   string
		DestPort   uint32
		OriginAddr string
		OriginPort uint32
	}
	if err := ssh.Unmarshal(newChannel.ExtraData(), &request); err != nil {
		_ = newChannel.Reject(ssh.ConnectionFailed, err.Error())
		return
	}
	target, err := net.Dial("tcp", net.JoinHostPort(request.DestAddr, strconv.FormatUint(uint64(request.DestPort), 10)))
	if err != nil {
		_ = newChannel.Reject(ssh.ConnectionFailed, err.Error())
		return
	}
	defer target.Close()

	channel, requests, err := newChannel.Accept()
	if err != nil {
		return
	}
	defer channel.Close()
	go ssh.DiscardRequests(requests)

	done := make(chan struct{}, 2)
	go func() {
		_, _ = io.Copy(channel, target)
		done <- struct{}{}
	}()
	go func() {
		_, _ = io.Copy(target, channel)
		done <- struct{}{}
	}()
	<-done
}
