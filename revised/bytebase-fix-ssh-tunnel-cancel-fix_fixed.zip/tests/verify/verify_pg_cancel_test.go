package pg

// This file is injected into backend/plugin/db/pg at test time and runs on its
// own (sibling verify files are not injected alongside it), so every helper it
// needs is defined here with a vtssh/vtpg prefix to avoid colliding with the
// package's own test symbols.

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"database/sql"
	"encoding/pem"
	"io"
	"net"
	"strconv"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/pkg/errors"
	"github.com/stretchr/testify/require"
	"golang.org/x/crypto/ssh"

	storepb "github.com/bytebase/bytebase/backend/generated-go/store"
	v1pb "github.com/bytebase/bytebase/backend/generated-go/v1"
	"github.com/bytebase/bytebase/backend/plugin/db"
)

// TestVerifyQueryConnStopsServerQueryWhenContextEnds runs a query against the
// baked PostgreSQL, directly and over an in-process SSH tunnel. A query whose
// context is canceled or runs out must return with an error, stop running on
// the server, and leave no session behind, and the driver must connect again
// for the next call. A query that ends inside its deadline must return its row.
func TestVerifyQueryConnStopsServerQueryWhenContextEnds(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name      string
		sshTunnel bool
		// timeout is the context deadline; zero cancels the context instead.
		timeout time.Duration
		// finishes runs a query that ends well inside its deadline but outlasts
		// the 10s a stopped query gets to return.
		finishes bool
	}{
		{name: "direct_canceled"},
		{name: "direct_deadline", timeout: 2 * time.Second},
		{name: "direct_finishes", timeout: 60 * time.Second, finishes: true},
		{name: "ssh_tunnel_canceled", sshTunnel: true},
		{name: "ssh_tunnel_deadline", sshTunnel: true, timeout: 2 * time.Second},
		{name: "ssh_tunnel_finishes", sshTunnel: true, timeout: 60 * time.Second, finishes: true},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			dbName, rawDB := vtpgNewDatabase(t)
			dataSource := &storepb.DataSource{
				Host:     "127.0.0.1",
				Port:     "5432",
				Username: "postgres",
			}
			if tc.sshTunnel {
				sshServer := vtsshNewServer(t)
				dataSource.SshHost = sshServer.host
				dataSource.SshPort = sshServer.port
				dataSource.SshUser = sshServer.user
				dataSource.SshPrivateKey = sshServer.privateKey
			}

			background := context.Background()
			driver, err := (&Driver{}).Open(background, storepb.Engine_POSTGRES, db.ConnectionConfig{
				DataSource:        dataSource,
				Password:          "root-password",
				ConnectionContext: db.ConnectionContext{DatabaseName: dbName},
			})
			require.NoError(t, err)
			t.Cleanup(func() { _ = driver.Close(background) })

			conn, err := driver.GetDB().Conn(background)
			require.NoError(t, err)
			t.Cleanup(func() { _ = conn.Close() })
			// Runs first, so a query that outlived its context cannot hold up the closes above.
			t.Cleanup(func() {
				_, _ = rawDB.Exec(`SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = $1 AND pid <> pg_backend_pid()`, dbName)
			})

			ctx, cancel := context.WithCancel(background)
			if tc.timeout > 0 {
				ctx, cancel = context.WithTimeout(background, tc.timeout)
			}
			defer cancel()

			statement := "SELECT pg_sleep(30);"
			if tc.finishes {
				statement = "SELECT 1 AS done FROM (SELECT pg_sleep(12)) AS s;"
			}
			done := make(chan []*v1pb.QueryResult, 1)
			go func() {
				results, err := driver.QueryConn(ctx, conn, statement, db.QueryContext{MaximumSQLResultSize: 1 << 30})
				if err != nil {
					results = []*v1pb.QueryResult{{Error: err.Error()}}
				}
				done <- results
			}()

			const runningQueries = `state = 'active' AND query LIKE '%pg_sleep%'`
			require.Eventually(t, func() bool { return vtpgCountSessions(t, rawDB, dbName, runningQueries) == 1 }, 10*time.Second, 20*time.Millisecond,
				"the query never started on the server")
			if tc.finishes {
				select {
				case results := <-done:
					require.Len(t, results, 1)
					require.Empty(t, results[0].Error, "a query that ended inside its deadline must not fail")
					require.Len(t, results[0].Rows, 1, "a query that ended inside its deadline must return its row")
				case <-time.After(30 * time.Second):
					require.FailNow(t, "QueryConn was still blocked 30s after a 12s query started")
				}
				require.NoError(t, driver.Ping(background), "the driver must keep serving after a query that finished")
				return
			}
			if tc.timeout == 0 {
				cancel()
			}

			select {
			case results := <-done:
				require.Len(t, results, 1)
				require.NotEmpty(t, results[0].Error, "a query whose context ended must return an error")
			case <-time.After(10 * time.Second):
				require.FailNow(t, "QueryConn was still blocked 10s after the query started")
			}
			require.Eventually(t, func() bool { return vtpgCountSessions(t, rawDB, dbName, runningQueries) == 0 }, 10*time.Second, 20*time.Millisecond,
				"the query kept running on the server after its context ended")
			require.Eventually(t, func() bool { return vtpgCountSessions(t, rawDB, dbName, `application_name = 'bytebase'`) == 0 }, 10*time.Second, 20*time.Millisecond,
				"the canceled connection stayed open on the server")

			require.NoError(t, driver.Ping(background), "the driver must reconnect once the canceled connection is discarded")
		})
	}
}

// vtpgDBSeq keeps database names unique across parallel subtests in this binary.
var vtpgDBSeq atomic.Int64

// vtpgNewDatabase creates an isolated database on the baked PostgreSQL and
// returns its name with a superuser handle to it.
func vtpgNewDatabase(t *testing.T) (string, *sql.DB) {
	t.Helper()
	admin, err := sql.Open("pgx", "host=127.0.0.1 port=5432 user=postgres password=root-password database=postgres")
	require.NoError(t, err)
	defer func() { _ = admin.Close() }()
	name := "vtpg_" + strconv.FormatInt(time.Now().UnixNano(), 36) + "_" + strconv.FormatInt(vtpgDBSeq.Add(1), 36)
	_, err = admin.Exec("CREATE DATABASE " + name)
	require.NoError(t, err)
	t.Cleanup(func() {
		cleanup, err := sql.Open("pgx", "host=127.0.0.1 port=5432 user=postgres password=root-password database=postgres")
		if err != nil {
			return
		}
		defer func() { _ = cleanup.Close() }()
		_, _ = cleanup.Exec("DROP DATABASE IF EXISTS " + name + " WITH (FORCE)")
	})
	conn, err := sql.Open("pgx", "host=127.0.0.1 port=5432 user=postgres password=root-password database="+name)
	require.NoError(t, err)
	t.Cleanup(func() { _ = conn.Close() })
	return name, conn
}

// vtpgCountSessions counts the sessions in the database, other than the one
// asking, that match the pg_stat_activity condition.
func vtpgCountSessions(t *testing.T, rawDB *sql.DB, dbName, condition string) int {
	t.Helper()
	var count int
	err := rawDB.QueryRow(`SELECT count(*) FROM pg_stat_activity WHERE datname = $1 AND pid <> pg_backend_pid() AND `+condition, dbName).Scan(&count)
	require.NoError(t, err)
	return count
}

// --- in-process SSH bastion + forwarding TCP server (test-only infrastructure) ---

type vtsshServer struct {
	host       string
	port       string
	user       string
	privateKey string
}

// vtsshNewServer starts an SSH server that forwards TCP connections and stops it
// when the test ends. It runs in the test binary, so the addresses it forwards
// to are ones the test can dial.
func vtsshNewServer(t *testing.T) *vtsshServer {
	t.Helper()

	_, hostKey, err := ed25519.GenerateKey(rand.Reader)
	require.NoError(t, err)
	hostSigner, err := ssh.NewSignerFromKey(hostKey)
	require.NoError(t, err)

	clientPublicKey, clientKey, err := ed25519.GenerateKey(rand.Reader)
	require.NoError(t, err)
	authorizedKey, err := ssh.NewPublicKey(clientPublicKey)
	require.NoError(t, err)
	clientKeyPEM, err := ssh.MarshalPrivateKey(clientKey, "")
	require.NoError(t, err)

	config := &ssh.ServerConfig{
		PublicKeyCallback: func(_ ssh.ConnMetadata, key ssh.PublicKey) (*ssh.Permissions, error) {
			if !bytes.Equal(key.Marshal(), authorizedKey.Marshal()) {
				return nil, errors.New("unknown public key")
			}
			return nil, nil
		},
	}
	config.AddHostKey(hostSigner)

	host, port := vtsshNewTCPServer(t, func(conn net.Conn) { vtsshServeConn(conn, config) })
	return &vtsshServer{host: host, port: port, user: "bytebase", privateKey: string(pem.EncodeToMemory(clientKeyPEM))}
}

// vtsshNewTCPServer listens on a loopback port and runs handle on each
// connection it accepts. A handle that does nothing is a server that never
// answers.
func vtsshNewTCPServer(t *testing.T, handle func(net.Conn)) (host, port string) {
	t.Helper()

	listener, err := net.Listen("tcp", "127.0.0.1:0")
	require.NoError(t, err)
	host, port, err = net.SplitHostPort(listener.Addr().String())
	require.NoError(t, err)

	var mu sync.Mutex
	var conns []net.Conn
	t.Cleanup(func() {
		_ = listener.Close()
		mu.Lock()
		defer mu.Unlock()
		for _, conn := range conns {
			_ = conn.Close()
		}
	})

	go func() {
		for {
			conn, err := listener.Accept()
			if err != nil {
				return
			}
			mu.Lock()
			conns = append(conns, conn)
			mu.Unlock()
			go handle(conn)
		}
	}()
	return host, port
}

func vtsshServeConn(conn net.Conn, config *ssh.ServerConfig) {
	_, channels, requests, err := ssh.NewServerConn(conn, config)
	if err != nil {
		return
	}
	go ssh.DiscardRequests(requests)
	for newChannel := range channels {
		if newChannel.ChannelType() != "direct-tcpip" {
			_ = newChannel.Reject(ssh.UnknownChannelType, "only direct-tcpip is supported")
			continue
		}
		go vtsshForwardChannel(newChannel)
	}
}

// vtsshForwardChannel serves one direct-tcpip channel as sshd does: it dials the
// requested address and closes both sides once either one ends.
func vtsshForwardChannel(newChannel ssh.NewChannel) {
	// RFC 4254 section 7.2.
	var request struct {
		DestAddr   string
		DestPort   uint32
		OriginAddr string
		OriginPort uint32
	}
	if err := ssh.Unmarshal(newChannel.ExtraData(), &request); err != nil {
		_ = newChannel.Reject(ssh.ConnectionFailed, err.Error())
		return
	}
	target, err := net.Dial("tcp", net.JoinHostPort(request.DestAddr, strconv.FormatUint(uint64(request.DestPort), 10)))
	if err != nil {
		_ = newChannel.Reject(ssh.ConnectionFailed, err.Error())
		return
	}
	defer target.Close()

	channel, requests, err := newChannel.Accept()
	if err != nil {
		return
	}
	defer channel.Close()
	go ssh.DiscardRequests(requests)

	done := make(chan struct{}, 2)
	go func() {
		_, _ = io.Copy(channel, target)
		done <- struct{}{}
	}()
	go func() {
		_, _ = io.Copy(target, channel)
		done <- struct{}{}
	}()
	<-done
}
