package cockroachdb

// This file is injected into backend/plugin/db/cockroachdb at test time and runs on
// its own (sibling verify files are not injected alongside it), so every helper
// it needs is defined here with a vtssh prefix to avoid colliding with the
// package's own test symbols.

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"encoding/pem"
	"io"
	"net"
	"strconv"
	"sync"
	"testing"
	"time"

	"github.com/pkg/errors"
	"github.com/stretchr/testify/require"
	"golang.org/x/crypto/ssh"

	storepb "github.com/bytebase/bytebase/backend/generated-go/store"
	"github.com/bytebase/bytebase/backend/plugin/db"
)

// TestVerifyPingThroughSSHTunnelReturnsWhenContextEnds opens the driver through
// an in-process SSH tunnel that forwards to a TCP server which accepts the
// connection and never answers, then calls Ping with a short-deadline context.
// Ping must give up with an error soon after that deadline instead of staying
// blocked until the watchdog.
func TestVerifyPingThroughSSHTunnelReturnsWhenContextEnds(t *testing.T) {
	t.Parallel()
	sshServer := vtsshNewServer(t)
	// The server accepts the connection and never answers the startup message.
	host, port := vtsshNewTCPServer(t, func(net.Conn) {})

	background := context.Background()
	driver, err := (&Driver{}).Open(background, storepb.Engine_COCKROACHDB, db.ConnectionConfig{
		DataSource: &storepb.DataSource{
			Host:          host,
			Port:          port,
			Username:      "bytebase",
			SshHost:       sshServer.host,
			SshPort:       sshServer.port,
			SshUser:       sshServer.user,
			SshPrivateKey: sshServer.privateKey,
		},
	})
	require.NoError(t, err)
	t.Cleanup(func() { _ = driver.Close(background) })

	ctx, cancel := context.WithTimeout(background, 500*time.Millisecond)
	defer cancel()
	pinged := make(chan error, 1)
	go func() { pinged <- driver.Ping(ctx) }()

	select {
	case err := <-pinged:
		require.Error(t, err, "Ping must report that it gave up")
	case <-time.After(10 * time.Second):
		require.FailNow(t, "Ping was still blocked long after its context ended")
	}
}

// --- in-process SSH bastion + forwarding TCP server (test-only infrastructure) ---

type vtsshServer struct {
	host       string
	port       string
	user       string
	privateKey string
}

// vtsshNewServer starts an SSH server that forwards TCP connections and stops it
// when the test ends. It runs in the test binary, so the addresses it forwards
// to are ones the test can dial.
func vtsshNewServer(t *testing.T) *vtsshServer {
	t.Helper()

	_, hostKey, err := ed25519.GenerateKey(rand.Reader)
	require.NoError(t, err)
	hostSigner, err := ssh.NewSignerFromKey(hostKey)
	require.NoError(t, err)

	clientPublicKey, clientKey, err := ed25519.GenerateKey(rand.Reader)
	require.NoError(t, err)
	authorizedKey, err := ssh.NewPublicKey(clientPublicKey)
	require.NoError(t, err)
	clientKeyPEM, err := ssh.MarshalPrivateKey(clientKey, "")
	require.NoError(t, err)

	config := &ssh.ServerConfig{
		PublicKeyCallback: func(_ ssh.ConnMetadata, key ssh.PublicKey) (*ssh.Permissions, error) {
			if !bytes.Equal(key.Marshal(), authorizedKey.Marshal()) {
				return nil, errors.New("unknown public key")
			}
			return nil, nil
		},
	}
	config.AddHostKey(hostSigner)

	host, port := vtsshNewTCPServer(t, func(conn net.Conn) { vtsshServeConn(conn, config) })
	return &vtsshServer{host: host, port: port, user: "bytebase", privateKey: string(pem.EncodeToMemory(clientKeyPEM))}
}

// vtsshNewTCPServer listens on a loopback port and runs handle on each
// connection it accepts. A handle that does nothing is a server that never
// answers.
func vtsshNewTCPServer(t *testing.T, handle func(net.Conn)) (host, port string) {
	t.Helper()

	listener, err := net.Listen("tcp", "127.0.0.1:0")
	require.NoError(t, err)
	host, port, err = net.SplitHostPort(listener.Addr().String())
	require.NoError(t, err)

	var mu sync.Mutex
	var conns []net.Conn
	t.Cleanup(func() {
		_ = listener.Close()
		mu.Lock()
		defer mu.Unlock()
		for _, conn := range conns {
			_ = conn.Close()
		}
	})

	go func() {
		for {
			conn, err := listener.Accept()
			if err != nil {
				return
			}
			mu.Lock()
			conns = append(conns, conn)
			mu.Unlock()
			go handle(conn)
		}
	}()
	return host, port
}

func vtsshServeConn(conn net.Conn, config *ssh.ServerConfig) {
	_, channels, requests, err := ssh.NewServerConn(conn, config)
	if err != nil {
		return
	}
	go ssh.DiscardRequests(requests)
	for newChannel := range channels {
		if newChannel.ChannelType() != "direct-tcpip" {
			_ = newChannel.Reject(ssh.UnknownChannelType, "only direct-tcpip is supported")
			continue
		}
		go vtsshForwardChannel(newChannel)
	}
}

// vtsshForwardChannel serves one direct-tcpip channel as sshd does: it dials the
// requested address and closes both sides once either one ends.
func vtsshForwardChannel(newChannel ssh.NewChannel) {
	// RFC 4254 section 7.2.
	var request struct {
		DestAddr   string
		DestPort   uint32
		OriginAddr string
		OriginPort uint32
	}
	if err := ssh.Unmarshal(newChannel.ExtraData(), &request); err != nil {
		_ = newChannel.Reject(ssh.ConnectionFailed, err.Error())
		return
	}
	target, err := net.Dial("tcp", net.JoinHostPort(request.DestAddr, strconv.FormatUint(uint64(request.DestPort), 10)))
	if err != nil {
		_ = newChannel.Reject(ssh.ConnectionFailed, err.Error())
		return
	}
	defer target.Close()

	channel, requests, err := newChannel.Accept()
	if err != nil {
		return
	}
	defer channel.Close()
	go ssh.DiscardRequests(requests)

	done := make(chan struct{}, 2)
	go func() {
		_, _ = io.Copy(channel, target)
		done <- struct{}{}
	}()
	go func() {
		_, _ = io.Copy(target, channel)
		done <- struct{}{}
	}()
	<-done
}
