package redshift

// This file is injected into backend/plugin/db/redshift at test time and runs on
// its own (sibling verify files are not injected alongside it), so every helper
// it needs is defined here with a vtssh prefix to avoid colliding with the
// package's own test symbols.

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"encoding/pem"
	"io"
	"net"
	"strconv"
	"sync"
	"testing"
	"time"

	"github.com/pkg/errors"
	"github.com/stretchr/testify/require"
	"golang.org/x/crypto/ssh"

	storepb "github.com/bytebase/bytebase/backend/generated-go/store"
	"github.com/bytebase/bytebase/backend/plugin/db"
)

// vtsshStage is the step of a connection check through an SSH tunnel that is
// held up.
type vtsshStage string

const (
	// The bastion takes the TCP connection and does not start the SSH handshake.
	vtsshStageBastion vtsshStage = "bastion"
	// The bastion logs the client in and does not answer its request to open the
	// forwarded connection to the database.
	vtsshStageForward vtsshStage = "forward"
	// The database takes the forwarded connection and does not answer the
	// startup message.
	vtsshStageDatabase vtsshStage = "database"
)

// vtsshSlowAnswer is how long a slow stage waits before it answers. It is
// longer than the 3s a check whose context ended gets to return.
const vtsshSlowAnswer = 5 * time.Second

// TestVerifyPingThroughSSHTunnelReturnsWhenContextEnds runs a connection check
// (Open, then Ping, with one context) through an in-process SSH tunnel where
// one stage never answers, and ends the context, once by canceling it and once
// by letting a short deadline pass. The check must give up with an error soon
// after, whichever stage it is waiting on.
func TestVerifyPingThroughSSHTunnelReturnsWhenContextEnds(t *testing.T) {
	t.Parallel()

	for _, stage := range []vtsshStage{vtsshStageBastion, vtsshStageForward, vtsshStageDatabase} {
		for _, tc := range []struct {
			name string
			// timeout is the context deadline; zero cancels the context instead.
			timeout time.Duration
		}{
			{name: "canceled"},
			{name: "deadline", timeout: 500 * time.Millisecond},
		} {
			t.Run(string(stage)+"_"+tc.name, func(t *testing.T) {
				t.Parallel()
				dataSource := vtsshNewDataSource(t, stage, -1)

				background := context.Background()
				ctx, cancel := context.WithCancel(background)
				if tc.timeout > 0 {
					ctx, cancel = context.WithTimeout(background, tc.timeout)
				}
				defer cancel()
				checked := make(chan error, 1)
				go func() { checked <- vtsshCheckConnection(ctx, dataSource) }()
				if tc.timeout == 0 {
					time.Sleep(500 * time.Millisecond)
					cancel()
				}

				select {
				case err := <-checked:
					require.Error(t, err, "a connection check that gave up must report an error")
				case <-time.After(500*time.Millisecond + 3*time.Second):
					require.FailNow(t, "the connection check was still blocked 3s after its context ended", "stage %s", stage)
				}
			})
		}
	}
}

// TestVerifyPingThroughSSHTunnelWaitsForSlowAnswer runs a connection check
// through an in-process SSH tunnel where one stage answers only after a delay
// that is well inside the check's deadline. The check must succeed.
func TestVerifyPingThroughSSHTunnelWaitsForSlowAnswer(t *testing.T) {
	t.Parallel()

	for _, stage := range []vtsshStage{vtsshStageBastion, vtsshStageForward, vtsshStageDatabase} {
		t.Run(string(stage), func(t *testing.T) {
			t.Parallel()
			dataSource := vtsshNewDataSource(t, stage, vtsshSlowAnswer)

			ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
			defer cancel()
			checked := make(chan error, 1)
			go func() { checked <- vtsshCheckConnection(ctx, dataSource) }()

			select {
			case err := <-checked:
				require.NoError(t, err, "a connection check whose tunnel answers inside the deadline must succeed")
			case <-time.After(45 * time.Second):
				require.FailNow(t, "the connection check was still blocked 45s after it started", "stage %s", stage)
			}
		})
	}
}

// vtsshCheckConnection opens the driver and pings it with ctx, as a connection
// check does, then closes the driver.
func vtsshCheckConnection(ctx context.Context, dataSource *storepb.DataSource) error {
	driver, err := (&Driver{}).Open(ctx, storepb.Engine_REDSHIFT, db.ConnectionConfig{
		DataSource: dataSource,
		Password:   "root-password",
	})
	if err != nil {
		return err
	}
	defer func() { _ = driver.Close(context.Background()) }()
	return driver.Ping(ctx)
}

// vtsshNewDataSource starts an SSH bastion and a database behind it, holds up
// the given stage for delay (for the whole test when delay is negative), and
// returns a data source that reaches the database through the bastion. The
// database is the baked PostgreSQL behind a forwarding proxy, except when the
// database stage never answers.
func vtsshNewDataSource(t *testing.T, stage vtsshStage, delay time.Duration) *storepb.DataSource {
	t.Helper()

	var bastionDelay, forwardDelay, databaseDelay time.Duration
	switch stage {
	case vtsshStageBastion:
		bastionDelay = delay
	case vtsshStageForward:
		forwardDelay = delay
	case vtsshStageDatabase:
		databaseDelay = delay
	}

	host, port := vtsshNewTCPServer(t, func(conn net.Conn, done <-chan struct{}) {
		if !vtsshWait(done, databaseDelay) {
			return
		}
		target, err := net.Dial("tcp", "127.0.0.1:5432")
		if err != nil {
			return
		}
		defer target.Close()
		vtsshPipe(conn, target)
	})
	sshServer := vtsshNewServer(t, bastionDelay, forwardDelay)
	return &storepb.DataSource{
		Host:          host,
		Port:          port,
		Username:      "postgres",
		Database:      "postgres",
		SshHost:       sshServer.host,
		SshPort:       sshServer.port,
		SshUser:       sshServer.user,
		SshPrivateKey: sshServer.privateKey,
	}
}

// vtsshWait waits for delay, or until the test ends when delay is negative,
// and reports whether the test is still running.
func vtsshWait(done <-chan struct{}, delay time.Duration) bool {
	if delay < 0 {
		<-done
		return false
	}
	select {
	case <-time.After(delay):
		return true
	case <-done:
		return false
	}
}

// vtsshPipe copies both ways between a and b until either side ends.
func vtsshPipe(a, b io.ReadWriter) {
	copied := make(chan struct{}, 2)
	go func() {
		_, _ = io.Copy(a, b)
		copied <- struct{}{}
	}()
	go func() {
		_, _ = io.Copy(b, a)
		copied <- struct{}{}
	}()
	<-copied
}

// --- in-process SSH bastion + forwarding TCP server (test-only infrastructure) ---

type vtsshServer struct {
	host       string
	port       string
	user       string
	privateKey string
}

// vtsshNewServer starts an SSH server that forwards TCP connections and stops it
// when the test ends. It starts each handshake after bastionDelay and answers
// each request to open a forwarded connection after forwardDelay; a negative
// delay never answers. It runs in the test binary, so the addresses it forwards
// to are ones the test can dial.
func vtsshNewServer(t *testing.T, bastionDelay, forwardDelay time.Duration) *vtsshServer {
	t.Helper()

	_, hostKey, err := ed25519.GenerateKey(rand.Reader)
	require.NoError(t, err)
	hostSigner, err := ssh.NewSignerFromKey(hostKey)
	require.NoError(t, err)

	clientPublicKey, clientKey, err := ed25519.GenerateKey(rand.Reader)
	require.NoError(t, err)
	authorizedKey, err := ssh.NewPublicKey(clientPublicKey)
	require.NoError(t, err)
	clientKeyPEM, err := ssh.MarshalPrivateKey(clientKey, "")
	require.NoError(t, err)

	config := &ssh.ServerConfig{
		PublicKeyCallback: func(_ ssh.ConnMetadata, key ssh.PublicKey) (*ssh.Permissions, error) {
			if !bytes.Equal(key.Marshal(), authorizedKey.Marshal()) {
				return nil, errors.New("unknown public key")
			}
			return nil, nil
		},
	}
	config.AddHostKey(hostSigner)

	host, port := vtsshNewTCPServer(t, func(conn net.Conn, done <-chan struct{}) {
		if !vtsshWait(done, bastionDelay) {
			return
		}
		vtsshServeConn(conn, config, forwardDelay, done)
	})
	return &vtsshServer{host: host, port: port, user: "bytebase", privateKey: string(pem.EncodeToMemory(clientKeyPEM))}
}

// vtsshNewTCPServer listens on a loopback port and runs handle on each
// connection it accepts. done is closed when the test ends, and every accepted
// connection is closed then too.
func vtsshNewTCPServer(t *testing.T, handle func(conn net.Conn, done <-chan struct{})) (host, port string) {
	t.Helper()

	listener, err := net.Listen("tcp", "127.0.0.1:0")
	require.NoError(t, err)
	host, port, err = net.SplitHostPort(listener.Addr().String())
	require.NoError(t, err)

	done := make(chan struct{})
	var mu sync.Mutex
	var conns []net.Conn
	t.Cleanup(func() {
		close(done)
		_ = listener.Close()
		mu.Lock()
		defer mu.Unlock()
		for _, conn := range conns {
			_ = conn.Close()
		}
	})

	go func() {
		for {
			conn, err := listener.Accept()
			if err != nil {
				return
			}
			mu.Lock()
			conns = append(conns, conn)
			mu.Unlock()
			go handle(conn, done)
		}
	}()
	return host, port
}

func vtsshServeConn(conn net.Conn, config *ssh.ServerConfig, forwardDelay time.Duration, done <-chan struct{}) {
	_, channels, requests, err := ssh.NewServerConn(conn, config)
	if err != nil {
		return
	}
	go ssh.DiscardRequests(requests)
	for newChannel := range channels {
		if newChannel.ChannelType() != "direct-tcpip" {
			_ = newChannel.Reject(ssh.UnknownChannelType, "only direct-tcpip is supported")
			continue
		}
		go vtsshForwardChannel(newChannel, forwardDelay, done)
	}
}

// vtsshForwardChannel serves one direct-tcpip channel as sshd does: after
// delay it dials the requested address and closes both sides once either one
// ends.
func vtsshForwardChannel(newChannel ssh.NewChannel, delay time.Duration, done <-chan struct{}) {
	if !vtsshWait(done, delay) {
		return
	}
	// RFC 4254 section 7.2.
	var request struct {
		DestAddr   string
		DestPort   uint32
		OriginAddr string
		OriginPort uint32
	}
	if err := ssh.Unmarshal(newChannel.ExtraData(), &request); err != nil {
		_ = newChannel.Reject(ssh.ConnectionFailed, err.Error())
		return
	}
	target, err := net.Dial("tcp", net.JoinHostPort(request.DestAddr, strconv.FormatUint(uint64(request.DestPort), 10)))
	if err != nil {
		_ = newChannel.Reject(ssh.ConnectionFailed, err.Error())
		return
	}
	defer target.Close()

	channel, requests, err := newChannel.Accept()
	if err != nil {
		return
	}
	defer channel.Close()
	go ssh.DiscardRequests(requests)
	vtsshPipe(channel, target)
}
