## Task

Some of our database instances can only be reached through an SSH tunnel, and on those we have no way to stop a query once it is running.
We first saw it on PostgreSQL.
Our CockroachDB and Redshift instances behind tunnels act the same way.

- Canceling a running query, with Cancel in SQL Editor or by dropping the request, does nothing.
- The request stays stuck until the query finishes by itself, and the database keeps running it the whole time.
- A query that goes past the workspace maximum query time isn't stopped either.
- Connection checks hang too, and they keep waiting after their request is dropped or their deadline has passed.

We've caught connection checks stuck in three places:

- The bastion host takes the TCP connection but never answers the SSH login.
- The bastion logs us in, but its connection on to the database never goes through, like when a firewall drops it.
- The database accepts the forwarded connection but never replies.

Instances we connect to directly don't have any of these problems.

On a tunneled PostgreSQL, CockroachDB or Redshift instance, a query that is canceled or runs out of time should come back right away with an error.
Shortly after, the query should no longer be running on the database and its session should be gone.
The next query on that instance should work.
A connection check whose request is dropped or whose deadline passes should give up with an error right away, wherever it is waiting.
Direct connections, tunneled queries that finish inside the limit, and connection checks through a tunnel that answers should keep working as they do now.
That includes a slow bastion, a slow forwarded connection or a slow database that takes several seconds to answer but still answers before the deadline.

Can you find out why canceling, the time limit and dropped connection checks don't stop anything on tunneled instances, and fix it?
