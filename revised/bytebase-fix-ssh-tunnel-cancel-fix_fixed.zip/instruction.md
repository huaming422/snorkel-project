## Task

Some of our database instances can only be reached through an SSH tunnel, and on those we have no way to stop a query once it is running.
We first saw it on PostgreSQL.
Our CockroachDB and Redshift instances behind tunnels act the same way.

- Canceling a running query, with Cancel in SQL Editor or by dropping the request, does nothing.
- The request stays stuck until the query finishes by itself, and the database keeps running it the whole time.
- A query that goes past the workspace maximum query time isn't stopped either.
- A connection check gets stuck as well when the database behind the tunnel accepts the connection but never replies, and it keeps waiting after the time it was given has run out.

Instances we connect to directly don't have any of these problems.

On a tunneled PostgreSQL, CockroachDB or Redshift instance, a query that is canceled or runs out of time should come back right away with an error.
Shortly after, the query should no longer be running on the database and its session should be gone.
The next query on that instance should work.
A connection check that runs out of time should give up with an error instead of hanging.
Everything else should keep working as it does now, including direct connections, tunneled queries that finish inside the limit, and connection checks against a database that answers.

Can you find out why canceling and the time limit don't stop queries on tunneled instances, and fix it?
