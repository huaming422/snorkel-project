//go:build cgo

// Behavioral checks for the paste-ready remedy commands cmd/bd prints when it
// refuses a target.
//
// Every assertion goes through two package entry points whose signatures stay
// fixed, never through the helpers behind them:
//
//   - refuseUninitializableTarget(beadsDir string) error
//     Reached by `bd create --repo` / `bd migrate-personal`. For a target
//     with no metadata.json whose own config.yaml selects Dolt server mode,
//     it prints a `bd init ... --server-host <host> ...` remedy whose host
//     comes from the target's config, rendered for runtime.GOOS.
//
//   - repoSyncMirrorRefusal(issue *types.Issue, planningPath, goos string) error
//     The phase-0 `bd repo sync` mirror refusal. It prints
//     `bd repo remove <path>` / `bd repo add <path>` remedies whose path is
//     the recorded source_repo, rendered for the goos it is given.
//
// On a Linux host refuseUninitializableTarget only renders the POSIX form, so
// the Windows rules are checked through repoSyncMirrorRefusal(..., "windows").
// serverInitRemedy and the quoting helpers are not called here, so their
// names, signatures and layout are free to change.
//
// This file owns TestMain so the shared Go runner runs it as the only test
// file in the package. Other cmd/bd test files that call quoting helpers by
// name are then not compiled with it.
package main

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"unicode/utf8"

	"github.com/steveyegge/beads/internal/types"
)

func TestMain(m *testing.M) {
	os.Exit(m.Run())
}

// writeTarget builds a .beads directory holding only a config.yaml and returns
// its path. refuseUninitializableTarget reads the target's dolt.mode and
// dolt.host from that file.
func writeTarget(t *testing.T, configYAML string) string {
	t.Helper()
	beadsDir := filepath.Join(t.TempDir(), ".beads")
	if err := os.MkdirAll(beadsDir, 0o755); err != nil {
		t.Fatal(err)
	}
	if configYAML != "" {
		if err := os.WriteFile(filepath.Join(beadsDir, "config.yaml"), []byte(configYAML), 0o644); err != nil {
			t.Fatal(err)
		}
	}
	return beadsDir
}

// serverModeByHost yields a config.yaml that selects Dolt server mode by a
// non-local dolt.host, which leads refuseUninitializableTarget to its host
// remedy.
func serverModeByHost(host string) string {
	return "dolt:\n  host: " + host + "\n  port: 3307\n"
}

// vrTerminalActive reports whether s holds a raw character that, printed into a
// terminal line beside or inside a paste-ready command, can redraw, reorder or
// split it: a carriage return, a line feed, an ESC that starts a control
// sequence, the U+202E bidi override, the U+2028/U+2029 separators, or a byte
// that is not valid UTF-8, such as 0x9b, which some terminals read as a control
// sequence start.
func vrTerminalActive(s string) bool {
	if !utf8.ValidString(s) {
		return true
	}
	for _, r := range []rune{'\r', '\n', '\x1b', '\u202e', '\u2028', '\u2029'} {
		if strings.ContainsRune(s, r) {
			return true
		}
	}
	return false
}

// vrOutsideDoubleQuotes returns s with every double-quoted run removed, where a
// backslash inside a run escapes the next character. sh, bash, zsh, fish and
// PowerShell all keep ' ‘ ’ ‚ ‛ ; and # literal inside double quotes, so a
// payload made of only those characters matters only outside such a run. $( )
// and backticks stay live inside double quotes, so payloads holding them are
// searched in the whole message.
func vrOutsideDoubleQuotes(s string) string {
	var b strings.Builder
	inQuotes := false
	for i := 0; i < len(s); i++ {
		switch c := s[i]; {
		case inQuotes && c == '\\':
			i++
		case c == '"':
			inQuotes = !inQuotes
		case !inQuotes:
			b.WriteByte(c)
		}
	}
	return b.String()
}

// vrRemedyArg returns the single argument the printed command passes after
// anchor (e.g. "bd repo remove "), reading up to the next occurrence of stop.
// It lets a round-trip test paste exactly what the operator would copy.
func vrRemedyArg(msg, anchor, stop string) string {
	i := strings.Index(msg, anchor)
	if i < 0 {
		return ""
	}
	rest := msg[i+len(anchor):]
	if j := strings.Index(rest, stop); j >= 0 {
		return rest[:j]
	}
	return rest
}

// vrShellPrintf runs `printf %s <arg>` in the shell that stands for goos (sh
// for POSIX, bash for Windows as Git Bash runs it) and returns what the
// program received on standard output.
func vrShellPrintf(goos, arg string) (string, error) {
	shell := "sh"
	if goos == "windows" {
		shell = "bash"
	}
	out, err := exec.Command(shell, "-c", "printf %s "+arg).Output()
	return string(out), err
}

// vrCheckPrintedArg checks the argument a printed command passes for a crafted
// value. It is either a placeholder that carries no part of the value (it
// starts with < and does not hold fragment), or a form the target shell hands
// to the program as exactly value, with nothing dropped or added.
func vrCheckPrintedArg(t *testing.T, label, goos, arg, value, fragment string) {
	t.Helper()
	if arg == "" {
		t.Errorf("[%s] no argument found in the printed command", label)
		return
	}
	if strings.HasPrefix(arg, "<") && !strings.Contains(arg, fragment) {
		return
	}
	got, err := vrShellPrintf(goos, arg)
	if err != nil || got != value {
		t.Errorf("[%s] printed argument %q is neither a placeholder nor the recorded value when pasted:\n got %q (err %v)\n want %q", label, arg, got, err, value)
	}
}

// An ordinary host or path prints the same whole refusal message as before:
// the host or path quoted for the platform inside the command (single quotes
// on POSIX with the configured port, plain double quotes on Windows), and the
// same text around it.
func TestBenignRemedyUnchanged(t *testing.T) {
	const hostTail = "; not initializing it as an embedded workspace, which would hide its server data. Run `%s` there, naming the server database it uses (\"beads\" unless BEADS_DOLT_SERVER_DATABASE names another), then rerun"
	for _, tc := range []struct{ name, config, want string }{
		{
			"server mode by dolt.host",
			serverModeByHost("db.example.com"),
			"%s has no metadata.json and its own config selects Dolt server mode (dolt.host: \"db.example.com\")" +
				fmt.Sprintf(hostTail, "bd init --server --server-host 'db.example.com' --server-port 3307 --database <name>"),
		},
		{
			"server mode by dolt.mode",
			"dolt:\n  mode: server\n  host: dolt-02.corp.example\n  port: 4406\n",
			"%s has no metadata.json and its own config selects Dolt server mode (dolt.mode: server)" +
				fmt.Sprintf(hostTail, "bd init --server-host 'dolt-02.corp.example' --server-port 4406 --database <name>"),
		},
	} {
		beadsDir := writeTarget(t, tc.config)
		err := refuseUninitializableTarget(beadsDir)
		if err == nil {
			t.Fatalf("[%s] refuseUninitializableTarget: expected a refusal, got nil", tc.name)
		}
		want := fmt.Sprintf(tc.want, filepath.Dir(beadsDir))
		if err.Error() != want {
			t.Errorf("[%s] benign host refusal changed:\n got  %q\n want %q", tc.name, err.Error(), want)
		}
	}

	const repoSyncMsg = "issue mps-1 already exists in the planning repo /plan/path; the project copy was imported from %s by `bd repo sync` (remove those copies with `bd repo remove %s`, then rerun, and run `bd repo add %s` again if you want them hydrated); nothing was moved"
	for _, tc := range []struct{ goos, path, quoted string }{
		{"linux", "/home/me/proj", "'/home/me/proj'"},
		{"linux", "/srv/repos/alpha", "'/srv/repos/alpha'"},
		{"windows", `C:\Users\me\proj`, `"C:\Users\me\proj"`},
		{"windows", "/home/me/proj", `"/home/me/proj"`},
	} {
		issue := &types.Issue{ID: "mps-1", SourceRepo: tc.path}
		msg := repoSyncMirrorRefusal(issue, "/plan/path", tc.goos).Error()
		want := fmt.Sprintf(repoSyncMsg, tc.path, tc.quoted, tc.quoted)
		if msg != want {
			t.Errorf("[%s %s] benign source_repo refusal changed:\n got  %q\n want %q", tc.goos, tc.path, msg, want)
		}
	}
}

// A dolt.host crafted to run a command or to redraw the terminal leaves no live
// payload and no raw terminal-active character in the printed refusal, while
// the recognizable part of the host is still named. The --server-host argument
// is a placeholder or pastes back as exactly the configured host. Any rendering
// that meets that passes: a placeholder, an escaped form or a different
// quoting.
func TestCraftedHostNeutralized(t *testing.T) {
	for _, tc := range []struct {
		name, host, fragment, dangerRaw string
		// inertInDoubleQuotes marks a dangerRaw that sh, bash, zsh, fish and
		// PowerShell keep literal inside double quotes, so only the text
		// outside them is searched.
		inertInDoubleQuotes bool
	}{
		// The tail ends a single-quoted argument and runs `id`.
		{"single-quote break-out", "myhost'; id #", "myhost", "'; id", true},
		// A ' needs a placeholder; the $( ) or backtick after it runs inside
		// double quotes too, so it must not appear raw anywhere.
		{"quote then command substitution", "hostR'$(id)", "hostR", "$(id)", false},
		{"quote then backtick", "hostS'`id`", "hostS", "`id`", false},
	} {
		yamlHost := `"` + strings.ReplaceAll(tc.host, `"`, `\"`) + `"`
		err := refuseUninitializableTarget(writeTarget(t, serverModeByHost(yamlHost)))
		if err == nil {
			t.Fatalf("[%s] refuseUninitializableTarget: expected a refusal for a crafted dolt.host, got nil", tc.name)
		}
		msg := err.Error()
		searched := msg
		if tc.inertInDoubleQuotes {
			searched = vrOutsideDoubleQuotes(msg)
		}
		if strings.Contains(searched, tc.dangerRaw) {
			t.Errorf("[%s] the crafted host's payload %q is printed live in the refusal, got %q", tc.name, tc.dangerRaw, msg)
		}
		if !strings.Contains(msg, tc.fragment) {
			t.Errorf("[%s] the recorded host value is not named at all, got %q", tc.name, msg)
		}
		vrCheckPrintedArg(t, "host "+tc.name, "linux", vrRemedyArg(msg, "--server-host ", " --server-port"), tc.host, tc.fragment)
	}

	// A carriage return, a line feed, an ESC sequence, the U+202E override and
	// the U+2028/U+2029 separators each change how the printed line shows.
	// U+202E and U+2028 sit above U+00A0, so dropping C0/C1 control bytes alone
	// leaves them in place.
	for _, esc := range []string{`\r`, `\n`, `\u001b[2K`, `\u202E`, `\u2028`, `\u2029`} {
		termErr := refuseUninitializableTarget(writeTarget(t, serverModeByHost(`"db`+esc+`x"`)))
		if termErr == nil {
			t.Fatalf("refuseUninitializableTarget: expected a refusal for a dolt.host holding %s, got nil", esc)
		}
		if vrTerminalActive(termErr.Error()) {
			t.Errorf("host holding %s: a raw terminal-active character reached the printed line, got %q", esc, termErr.Error())
		}
	}

	// The refusal also names the target path (filepath.Dir of its .beads)
	// ahead of the bd init remedy. Here the host is ordinary and only the path
	// holds the terminal-active character.
	for _, c := range []string{"\r", "\n", "\u202e"} {
		ctrlBeads := filepath.Join(t.TempDir(), "we"+c+"ird", ".beads")
		if err := os.MkdirAll(ctrlBeads, 0o755); err != nil {
			t.Fatalf("mkdir target with %q in its path: %v", c, err)
		}
		if err := os.WriteFile(filepath.Join(ctrlBeads, "config.yaml"), []byte(serverModeByHost("db.example.com")), 0o644); err != nil {
			t.Fatal(err)
		}
		pathErr := refuseUninitializableTarget(ctrlBeads)
		if pathErr == nil {
			t.Fatalf("refuseUninitializableTarget: expected a refusal for a target path holding %q, got nil", c)
		}
		if vrTerminalActive(pathErr.Error()) {
			t.Errorf("target path holding %q: a raw terminal-active character reached the printed line, got %q", c, pathErr.Error())
		}
	}
}

// A source_repo that some target shell would expand, break out of, split or
// alter is rendered so the dangerous part does not appear raw anywhere in the
// refusal, while the recorded path is still recognizably named. The path in
// `bd repo remove` is a placeholder or pastes back as exactly the recorded
// source_repo. The issue ID and planning path it names carry no raw
// terminal-active character. Both platforms are driven through
// repoSyncMirrorRefusal's goos parameter.
func TestRepoSyncRefusalNeutralized(t *testing.T) {
	for _, tc := range []struct {
		name, goos, sourceRepo string
		fidelity               string // a benign fragment of the value that must still be named
		dangerRaw              string // the dangerous substring that must not appear raw
		// inertInDoubleQuotes marks a dangerRaw that every target shell on goos
		// keeps literal inside double quotes, so only the text outside them is
		// searched.
		inertInDoubleQuotes bool
	}{
		// POSIX: a ' ends single quotes in PowerShell, which also runs on Linux
		// and macOS, so the `; id` tail would run there.
		{"posix single-quote break-out", "linux", "repoA'; id #", "repoA", "'; id", true},
		// POSIX: PowerShell also ends single quotes at each curly single quote.
		{"posix left curly-quote break-out", "linux", "/home/repoQ\u2018; id #", "repoQ", "\u2018; id", true},
		{"posix right curly-quote break-out", "linux", "/home/repoR\u2019; id #", "repoR", "\u2019; id", true},
		{"posix low curly-quote break-out", "linux", "/home/repoS\u201a; id #", "repoS", "\u201a; id", true},
		{"posix reversed curly-quote break-out", "linux", "/home/repoT\u201b; id #", "repoT", "\u201b; id", true},
		// POSIX: a ' needs a placeholder, and the $( ) or backtick after it
		// runs inside double quotes as well.
		{"posix quote then command substitution", "linux", "/home/repoU'$(id)", "repoU", "$(id)", false},
		{"posix quote then backtick", "linux", "/home/repoV'`id`", "repoV", "`id`", false},
		// POSIX: fish reads \\ inside single quotes as one backslash.
		{"posix double backslash pair", "linux", `/home/repoP\\x`, "repoP", `repoP\\x`, false},
		// POSIX: fish reads a trailing \ inside single quotes as escaping the
		// closing quote.
		{"posix trailing backslash", "linux", `/home/repoW\`, "repoW", `repoW\'`, false},
		// Windows: PowerShell and bash expand $( ) inside double quotes.
		{"windows dollar expansion", "windows", `C:\repoB$(id)`, "repoB", "$(id)", false},
		// Windows: Git Bash runs `...` inside double quotes.
		{"windows backtick substitution", "windows", "C:\\repoM`calc`", "repoM", "`calc`", false},
		// Windows: cmd.exe expands %NAME% inside double quotes.
		{"windows percent expansion", "windows", `C:\repoN%PATH%`, "repoN", "%PATH%", false},
		// Windows: cmd.exe delayed expansion and bash history expand !x!.
		{"windows bang expansion", "windows", `C:\repoO!x!`, "repoO", "!x!", false},
		// Windows: Go's argument parsing reads a trailing backslash as escaping
		// the closing double quote, so the quoted path ending in \" is itself
		// the hazard.
		{"windows trailing backslash", "windows", `C:\repoC\`, "repoC", `C:\repoC\`, false},
		// Windows: a " ends the double quotes in every Windows shell.
		{"windows double quote", "windows", `C:\repoD"x`, "repoD", `repoD"x`, false},
		// Windows: PowerShell also ends double quotes at a curly double quote.
		{"windows left curly double quote", "windows", "C:\\repoX\u201cx", "repoX", "\u201cx", false},
		{"windows right curly double quote", "windows", "C:\\repoY\u201dx", "repoY", "\u201dx", false},
		{"windows low curly double quote", "windows", "C:\\repoZ\u201ex", "repoZ", "\u201ex", false},
		// Windows: cmd.exe reads ; , = as separating a .cmd shim's arguments.
		{"windows semicolon shim split", "windows", `C:\repoE;calc`, "repoE", ";calc", false},
		{"windows comma shim split", "windows", `C:\repoF,calc`, "repoF", ",calc", false},
		{"windows equals shim split", "windows", `C:\repoG=calc`, "repoG", "=calc", false},
		// Windows: cmd.exe acts on & | < > ^ in an argument PowerShell hands a
		// .cmd shim unquoted.
		{"windows ampersand", "windows", `C:\repoH2&calc`, "repoH2", "&calc", false},
		{"windows pipe", "windows", `C:\repoH|calc`, "repoH", "|calc", false},
		{"windows redirect in", "windows", `C:\repoI<calc`, "repoI", "<calc", false},
		{"windows redirect out", "windows", `C:\repoJ>calc`, "repoJ", ">calc", false},
		{"windows caret", "windows", `C:\repoK^calc`, "repoK", "^calc", false},
		// Windows: bash/Git Bash reads \\ inside double quotes as one backslash.
		{"windows double backslash pair", "windows", `C:\repoL\\x`, "repoL", `repoL\\x`, false},
	} {
		issue := &types.Issue{ID: "mps-1", SourceRepo: tc.sourceRepo}
		msg := repoSyncMirrorRefusal(issue, "/plan/path", tc.goos).Error()
		searched := msg
		if tc.inertInDoubleQuotes {
			searched = vrOutsideDoubleQuotes(msg)
		}
		if strings.Contains(searched, tc.dangerRaw) {
			t.Errorf("[%s] the crafted path's dangerous substring %q appears raw, got %q", tc.name, tc.dangerRaw, msg)
		}
		if !strings.Contains(msg, tc.fidelity) {
			t.Errorf("[%s] the recorded path is not recognizably named, got %q", tc.name, msg)
		}
		vrCheckPrintedArg(t, tc.name, tc.goos, vrRemedyArg(msg, "bd repo remove ", "`, then rerun"), tc.sourceRepo, tc.fidelity)
	}

	// The source_repo, issue ID and planning path named beside the commands
	// carry no raw terminal-active character either, on either platform.
	for _, goos := range []string{"linux", "windows"} {
		for _, c := range []string{"\r", "\n", "\x1b[2K", "\u202e", "\u2028", "\u2029", "\x9b"} {
			ctrlIssue := &types.Issue{ID: "mps" + c + "1", SourceRepo: "/home/db" + c + "x"}
			ctrlMsg := repoSyncMirrorRefusal(ctrlIssue, "/plan"+c+"path", goos).Error()
			if vrTerminalActive(ctrlMsg) {
				t.Errorf("[%s %q] repo sync refusal: a raw terminal-active character reached the printed line, got %q", goos, c, ctrlMsg)
			}
		}
	}
}

// A printed argument that is quotable, run through the real target shell, hands
// the program the value unchanged. An argument derived from an injecting value
// does not run the injection when pasted.
func TestPrintedFormRoundTripsThroughShell(t *testing.T) {
	// POSIX forms go through sh; Windows forms through bash, as Git Bash runs
	// them.
	for _, tc := range []struct{ goos, value string }{
		{"linux", "/home/me/proj"},
		{"linux", "/tmp/$HOME/`id`"},
		{"windows", `C:\Users\Jane Doe\Proj (x86)`},
	} {
		issue := &types.Issue{ID: "mps-1", SourceRepo: tc.value}
		msg := repoSyncMirrorRefusal(issue, "/plan/path", tc.goos).Error()
		arg := vrRemedyArg(msg, "bd repo remove ", "`, then rerun")
		if arg == "" || strings.Contains(arg, "<path>") {
			t.Fatalf("[%s %q] expected a quotable path printed in the command, got arg %q from %q", tc.goos, tc.value, arg, msg)
		}
		out, err := vrShellPrintf(tc.goos, arg)
		if err != nil {
			t.Fatalf("[%s %q] printf %%s %s: %v", tc.goos, tc.value, arg, err)
		}
		if out != tc.value {
			t.Errorf("[%s %q] printed form did not round-trip through the shell:\n got %q\n want %q", tc.goos, tc.value, out, tc.value)
		}
	}

	// The marker would reach standard output only if $(echo PWNED) ran. Standard
	// error is not read, since bash echoes an unparsable line back there as text.
	inject := &types.Issue{ID: "mps-1", SourceRepo: "x$(echo PWNED)y"}
	injMsg := repoSyncMirrorRefusal(inject, "/plan/path", "windows").Error()
	injArg := vrRemedyArg(injMsg, "bd repo remove ", "`, then rerun")
	injOut, _ := vrShellPrintf("windows", injArg)
	if strings.Contains(injOut, "PWNED") {
		t.Errorf("injecting value executed when pasted: arg %q produced %q", injArg, injOut)
	}
}

// Whether bd refuses a target (server-mode detection, the local-host
// exemption, a missing config) does not depend on how values are rendered.
func TestRefusalConditionsUnchanged(t *testing.T) {
	for _, tc := range []struct {
		name, config string
		wantRefused  bool
	}{
		{"non-local host selects server mode", serverModeByHost("db.example.com"), true},
		{"dolt.mode server selects server mode", "dolt:\n  mode: server\n", true},
		{"local host is exempt", serverModeByHost("127.0.0.1"), false},
		{"no config is not refused", "", false},
	} {
		beadsDir := writeTarget(t, tc.config)
		err := refuseUninitializableTarget(beadsDir)
		if (err != nil) != tc.wantRefused {
			t.Errorf("[%s] refused=%v, want refused=%v (err=%v)", tc.name, err != nil, tc.wantRefused, err)
		}
	}
}
