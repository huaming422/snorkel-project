//go:build cgo

// Behavioral checks for the paste-ready remedy commands cmd/bd prints when it
// refuses a target.
//
// Every assertion goes through two package entry points whose signatures stay
// fixed, never through the helpers behind them:
//
//   - refuseUninitializableTarget(beadsDir string) error
//     Reached by `bd create --repo` / `bd migrate-personal`. For a target
//     with no metadata.json whose own config.yaml selects Dolt server mode,
//     it prints a `bd init ... --server-host <host> ...` remedy whose host
//     comes from the target's config, rendered for runtime.GOOS.
//
//   - repoSyncMirrorRefusal(issue *types.Issue, planningPath, goos string) error
//     The phase-0 `bd repo sync` mirror refusal. It prints
//     `bd repo remove <path>` / `bd repo add <path>` remedies whose path is
//     the recorded source_repo, rendered for the goos it is given.
//
// On a Linux host refuseUninitializableTarget only renders the POSIX form, so
// the Windows rules are checked through repoSyncMirrorRefusal(..., "windows").
// serverInitRemedy and the quoting helpers are not called here, so their
// names, signatures and layout are free to change.
//
// This file owns TestMain so the shared Go runner runs it as the only test
// file in the package. Other cmd/bd test files that call quoting helpers by
// name are then not compiled with it.
package main

import (
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"

	"github.com/steveyegge/beads/internal/types"
)

func TestMain(m *testing.M) {
	os.Exit(m.Run())
}

// writeTarget builds a .beads directory holding only a config.yaml and returns
// its path. refuseUninitializableTarget reads the target's dolt.mode and
// dolt.host from that file.
func writeTarget(t *testing.T, configYAML string) string {
	t.Helper()
	beadsDir := filepath.Join(t.TempDir(), ".beads")
	if err := os.MkdirAll(beadsDir, 0o755); err != nil {
		t.Fatal(err)
	}
	if configYAML != "" {
		if err := os.WriteFile(filepath.Join(beadsDir, "config.yaml"), []byte(configYAML), 0o644); err != nil {
			t.Fatal(err)
		}
	}
	return beadsDir
}

// serverModeByHost yields a config.yaml that selects Dolt server mode by a
// non-local dolt.host, which leads refuseUninitializableTarget to its host
// remedy.
func serverModeByHost(host string) string {
	return "dolt:\n  host: " + host + "\n  port: 3307\n"
}

// vrTerminalActive reports whether s holds a raw character that, printed into a
// terminal line beside or inside a paste-ready command, can redraw, reorder or
// split it: a carriage return, an ESC that starts a control sequence, the
// U+202E bidi override, or the U+2028/U+2029 separators.
func vrTerminalActive(s string) bool {
	for _, r := range []rune{'\r', '\x1b', '\u202e', '\u2028', '\u2029'} {
		if strings.ContainsRune(s, r) {
			return true
		}
	}
	return false
}

// vrOutsideDoubleQuotes returns s with every double-quoted run removed, where a
// backslash inside a run escapes the next character. sh, bash, zsh, fish and
// PowerShell all keep ' ‘ ’ ; and # literal inside double quotes, so a payload
// made of those characters only matters outside such a run.
func vrOutsideDoubleQuotes(s string) string {
	var b strings.Builder
	inQuotes := false
	for i := 0; i < len(s); i++ {
		switch c := s[i]; {
		case inQuotes && c == '\\':
			i++
		case c == '"':
			inQuotes = !inQuotes
		case !inQuotes:
			b.WriteByte(c)
		}
	}
	return b.String()
}

// vrRemedyArg returns the single argument the printed command passes after
// anchor (e.g. "bd repo remove "), reading up to the next occurrence of stop.
// It lets a round-trip test paste exactly what the operator would copy.
func vrRemedyArg(msg, anchor, stop string) string {
	i := strings.Index(msg, anchor)
	if i < 0 {
		return ""
	}
	rest := msg[i+len(anchor):]
	if j := strings.Index(rest, stop); j >= 0 {
		return rest[:j]
	}
	return rest
}

// An ordinary host or path is printed inside the command, quoted for the
// platform, in the same form as before: single quotes on POSIX with the
// configured port, plain double quotes on Windows.
func TestBenignRemedyUnchanged(t *testing.T) {
	beadsDir := writeTarget(t, serverModeByHost("db.example.com"))
	err := refuseUninitializableTarget(beadsDir)
	if err == nil {
		t.Fatalf("refuseUninitializableTarget: expected a refusal for a non-local dolt.host, got nil")
	}
	const wantInit = "--server-host 'db.example.com' --server-port 3307 --database <name>"
	if !strings.Contains(err.Error(), wantInit) {
		t.Errorf("benign host remedy:\n got %q\n want substring %q", err.Error(), wantInit)
	}

	issue := &types.Issue{ID: "mps-1", SourceRepo: "/home/me/proj"}
	for _, tc := range []struct{ goos, want string }{
		{"linux", "bd repo remove '/home/me/proj'"},
		{"windows", `bd repo remove "/home/me/proj"`},
	} {
		msg := repoSyncMirrorRefusal(issue, "/plan/path", tc.goos).Error()
		if !strings.Contains(msg, tc.want) {
			t.Errorf("[%s] benign source_repo remedy:\n got %q\n want substring %q", tc.goos, msg, tc.want)
		}
	}
}

// A dolt.host crafted to run a command or to redraw the terminal leaves no live
// payload and no raw terminal-active character in the printed refusal, while
// the recognizable part of the host is still named. Any rendering that meets
// that passes: a placeholder, an escaped form or a different quoting.
func TestCraftedHostNeutralized(t *testing.T) {
	// The tail ends a single-quoted argument and runs `id`. Outside double
	// quotes, the `'; id` sequence must not appear anywhere in the refusal.
	injErr := refuseUninitializableTarget(writeTarget(t, serverModeByHost(`"myhost'; id #"`)))
	if injErr == nil {
		t.Fatalf("refuseUninitializableTarget: expected a refusal for a crafted dolt.host, got nil")
	}
	injMsg := injErr.Error()
	if strings.Contains(vrOutsideDoubleQuotes(injMsg), "'; id") {
		t.Errorf("crafted host: the injected shell tail is printed live in the refusal, got %q", injMsg)
	}
	if !strings.Contains(injMsg, "myhost") {
		t.Errorf("crafted host: the recorded host value is not named at all, got %q", injMsg)
	}

	// A carriage return, an ESC sequence, the U+202E override and the U+2028
	// separator each change how the printed line shows. U+202E and U+2028 sit
	// above U+00A0, so dropping C0/C1 control bytes alone leaves them in place.
	termErr := refuseUninitializableTarget(writeTarget(t, serverModeByHost("\"db\\r\\u001b[2K\\u202E\\u2028x\"")))
	if termErr == nil {
		t.Fatalf("refuseUninitializableTarget: expected a refusal for a control-char dolt.host, got nil")
	}
	if vrTerminalActive(termErr.Error()) {
		t.Errorf("control-char host: a raw terminal-active character reached the printed line, got %q", termErr.Error())
	}

	// The refusal also names the target path (filepath.Dir of its .beads)
	// ahead of the bd init remedy. Here the host is ordinary and only the path
	// holds a carriage return.
	ctrlBeads := filepath.Join(t.TempDir(), "we\rird", ".beads")
	if err := os.MkdirAll(ctrlBeads, 0o755); err != nil {
		t.Fatalf("mkdir target with a control character in its path: %v", err)
	}
	if err := os.WriteFile(filepath.Join(ctrlBeads, "config.yaml"), []byte(serverModeByHost("db.example.com")), 0o644); err != nil {
		t.Fatal(err)
	}
	pathErr := refuseUninitializableTarget(ctrlBeads)
	if pathErr == nil {
		t.Fatalf("refuseUninitializableTarget: expected a refusal for a control-char target path, got nil")
	}
	if vrTerminalActive(pathErr.Error()) {
		t.Errorf("control-char target path: a raw terminal-active character reached the printed line, got %q", pathErr.Error())
	}
}

// A source_repo that some target shell would expand, break out of, split or
// alter is rendered so the dangerous part does not appear raw anywhere in the
// refusal, while the recorded path is still recognizably named. The issue ID
// and planning path it names carry no raw terminal-active character. Both
// platforms are driven through repoSyncMirrorRefusal's goos parameter.
func TestRepoSyncRefusalNeutralized(t *testing.T) {
	for _, tc := range []struct {
		name, goos, sourceRepo string
		fidelity               string // a benign fragment of the value that must still be named
		dangerRaw              string // the dangerous substring that must not appear raw
		// inertInDoubleQuotes marks a dangerRaw that every target shell on goos
		// keeps literal inside double quotes, so only the text outside them is
		// searched.
		inertInDoubleQuotes bool
	}{
		// POSIX: a ' ends single quotes in PowerShell, which also runs on Linux
		// and macOS, so the `; id` tail would run there.
		{"posix single-quote break-out", "linux", "repoA'; id #", "repoA", "'; id", true},
		// POSIX: PowerShell also ends single quotes at a curly quote.
		{"posix curly-quote break-out", "linux", "/home/repoQ\u2019; id #", "repoQ", "\u2019; id", true},
		// POSIX: fish reads \\ inside single quotes as one backslash.
		{"posix double backslash pair", "linux", `/home/repoP\\x`, "repoP", `repoP\\x`, false},
		// Windows: PowerShell and bash expand $( ) inside double quotes.
		{"windows dollar expansion", "windows", `C:\repoB$(id)`, "repoB", "$(id)", false},
		// Windows: Git Bash runs `...` inside double quotes.
		{"windows backtick substitution", "windows", "C:\\repoM`calc`", "repoM", "`calc`", false},
		// Windows: cmd.exe expands %NAME% inside double quotes.
		{"windows percent expansion", "windows", `C:\repoN%PATH%`, "repoN", "%PATH%", false},
		// Windows: cmd.exe delayed expansion and bash history expand !x!.
		{"windows bang expansion", "windows", `C:\repoO!x!`, "repoO", "!x!", false},
		// Windows: Go's argument parsing reads a trailing backslash as escaping
		// the closing double quote, so the quoted path ending in \" is itself
		// the hazard.
		{"windows trailing backslash", "windows", `C:\repoC\`, "repoC", `C:\repoC\`, false},
		// Windows: a " ends cmd.exe's quotes so the rest runs; & chains a command.
		{"windows quote-ampersand breakout", "windows", `C:\repoD" & calc & "x`, "repoD", `" & calc`, false},
		// Windows: cmd.exe reads ; , = as separating a .cmd shim's arguments.
		{"windows semicolon shim split", "windows", `C:\repoE;calc`, "repoE", ";calc", false},
		{"windows comma shim split", "windows", `C:\repoF,calc`, "repoF", ",calc", false},
		{"windows equals shim split", "windows", `C:\repoG=calc`, "repoG", "=calc", false},
		// Windows: cmd.exe acts on | < > ^ in an argument PowerShell hands a .cmd
		// shim unquoted.
		{"windows pipe", "windows", `C:\repoH|calc`, "repoH", "|calc", false},
		{"windows redirect in", "windows", `C:\repoI<calc`, "repoI", "<calc", false},
		{"windows redirect out", "windows", `C:\repoJ>calc`, "repoJ", ">calc", false},
		{"windows caret", "windows", `C:\repoK^calc`, "repoK", "^calc", false},
		// Windows: bash/Git Bash reads \\ inside double quotes as one backslash.
		{"windows double backslash pair", "windows", `C:\repoL\\x`, "repoL", `repoL\\x`, false},
	} {
		issue := &types.Issue{ID: "mps-1", SourceRepo: tc.sourceRepo}
		msg := repoSyncMirrorRefusal(issue, "/plan/path", tc.goos).Error()
		searched := msg
		if tc.inertInDoubleQuotes {
			searched = vrOutsideDoubleQuotes(msg)
		}
		if strings.Contains(searched, tc.dangerRaw) {
			t.Errorf("[%s] the crafted path's dangerous substring %q appears raw, got %q", tc.name, tc.dangerRaw, msg)
		}
		if !strings.Contains(msg, tc.fidelity) {
			t.Errorf("[%s] the recorded path is not recognizably named, got %q", tc.name, msg)
		}
	}

	// The source_repo, issue ID and planning path named beside the commands
	// carry no raw terminal-active character either, U+202E included.
	ctrlIssue := &types.Issue{ID: "mps\r1", SourceRepo: "db\x1b[2K\u202e\u2028x"}
	ctrlMsg := repoSyncMirrorRefusal(ctrlIssue, "/plan\rpath", "linux").Error()
	if vrTerminalActive(ctrlMsg) {
		t.Errorf("control-char repo sync refusal: a raw terminal-active character reached the printed line, got %q", ctrlMsg)
	}
}

// A printed argument that is quotable, run through the real target shell, hands
// the program the value unchanged. An argument derived from an injecting value
// does not run the injection when pasted.
func TestPrintedFormRoundTripsThroughShell(t *testing.T) {
	// POSIX forms go through sh; Windows forms through bash, as Git Bash runs
	// them.
	for _, tc := range []struct{ goos, shell, value string }{
		{"linux", "sh", "/home/me/proj"},
		{"linux", "sh", "/tmp/$HOME/`id`"},
		{"windows", "bash", `C:\Users\Jane Doe\Proj (x86)`},
	} {
		issue := &types.Issue{ID: "mps-1", SourceRepo: tc.value}
		msg := repoSyncMirrorRefusal(issue, "/plan/path", tc.goos).Error()
		arg := vrRemedyArg(msg, "bd repo remove ", "`, then rerun")
		if arg == "" || strings.Contains(arg, "<path>") {
			t.Fatalf("[%s %q] expected a quotable path printed in the command, got arg %q from %q", tc.goos, tc.value, arg, msg)
		}
		out, err := exec.Command(tc.shell, "-c", "printf %s "+arg).Output()
		if err != nil {
			t.Fatalf("[%s %q] %s -c \"printf %%s %s\": %v", tc.goos, tc.value, tc.shell, arg, err)
		}
		if string(out) != tc.value {
			t.Errorf("[%s %q] printed form did not round-trip through %s:\n got %q\n want %q", tc.goos, tc.value, tc.shell, string(out), tc.value)
		}
	}

	// The marker would reach standard output only if $(echo PWNED) ran. Standard
	// error is not read, since bash echoes an unparsable line back there as text.
	inject := &types.Issue{ID: "mps-1", SourceRepo: "x$(echo PWNED)y"}
	injMsg := repoSyncMirrorRefusal(inject, "/plan/path", "windows").Error()
	injArg := vrRemedyArg(injMsg, "bd repo remove ", "`, then rerun")
	injOut, _ := exec.Command("bash", "-c", "printf %s "+injArg).Output()
	if strings.Contains(string(injOut), "PWNED") {
		t.Errorf("injecting value executed when pasted: arg %q produced %q", injArg, string(injOut))
	}
}

// Whether bd refuses a target (server-mode detection, the local-host
// exemption, a missing config) does not depend on how values are rendered.
func TestRefusalConditionsUnchanged(t *testing.T) {
	for _, tc := range []struct {
		name, config string
		wantRefused  bool
	}{
		{"non-local host selects server mode", serverModeByHost("db.example.com"), true},
		{"dolt.mode server selects server mode", "dolt:\n  mode: server\n", true},
		{"local host is exempt", serverModeByHost("127.0.0.1"), false},
		{"no config is not refused", "", false},
	} {
		beadsDir := writeTarget(t, tc.config)
		err := refuseUninitializableTarget(beadsDir)
		if (err != nil) != tc.wantRefused {
			t.Errorf("[%s] refused=%v, want refused=%v (err=%v)", tc.name, err != nil, tc.wantRefused, err)
		}
	}
}
