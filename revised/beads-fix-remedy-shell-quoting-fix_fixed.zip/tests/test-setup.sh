#!/usr/bin/env bash
# Verifier test-setup for beads-fix-remedy-shell-quoting.
#
# The task runs offline. The image already carries the full dependency closure
# for the pinned source (Go module and build caches warmed in
# environment/Dockerfile blocks 5 and 7), and the reference change adds only
# stdlib imports, so no new module is needed.
# The Go verifier compiles and runs entirely from what is already baked, so there
# is nothing to install here. The behavioral verifier also pipes printed commands
# through sh/bash, both present in the base image.
#
# Kept as an explicit no-op (rather than absent) so the contract is visible and a
# future dependency can be added offline-first with a logged online fallback.
set -euo pipefail

echo "test-setup: no additional setup required (dependency closure baked at base commit)"
