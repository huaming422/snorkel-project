## Task

Heads up, I think this one is a security problem.
When `bd` won't set up or migrate a repo because that repo's own config points its database at a remote host, it prints a `bd init` command for the operator to paste.
It does the same thing when it explains how to undo a `bd repo sync` copy, with `bd repo remove` and `bd repo add` commands.
Those commands and the text around them carry values from the repo, such as the host or the recorded source path.
A repo's config may have been written by someone else, and a hostile one can choose values so that pasting the command runs something nobody typed.
Other values redraw the terminal line, so the text you copy is not the text on screen.
Sometimes the paste just hands `bd` a different value or an extra argument.
Windows gets the worst of it, but Linux and macOS are affected as well.

On Windows people paste these into cmd.exe, PowerShell or Git Bash, and many run `bd` through the npm `bd.cmd` shim.
On Linux and macOS they use sh, bash, zsh, fish, and sometimes PowerShell.

Please make these refusals safe in all of those shells, whatever the config holds.
When someone pastes one of the commands, `bd` should get exactly the value the repo recorded, nothing more and nothing changed.
The rest of the message, like the host or path it names next to the command, should be just as safe to copy and shouldn't be able to mess with the terminal line.
It should still show which host or path it is talking about.
Ordinary hosts and paths should keep printing exactly the way they do today.
When and why `bd` refuses is right already, so leave that part alone.

## User stories / requirements

- When `bd` turns down a repo whose config points at a remote database host, the `bd init` command it prints for Windows is safe to paste into cmd.exe, PowerShell or Git Bash, or to run through `bd.cmd`.
  A host holding characters any of those shells would act on never shows up raw in the command or next to it.
  The message still says which host it means.
