## Task

Heads up, I think this one is a security problem.
Sometimes `bd` won't set up or migrate a repo because the config inside that repo selects a remote Dolt server, and then it prints a `bd init` command for the operator to paste.
It does the same thing when it explains how to take back what `bd repo sync` copied, with `bd repo remove` and `bd repo add` commands.
Those commands and the text around them carry values from the repo, such as the host or the recorded source path.
A repo's config may have been written by someone else, and a hostile one can choose values so that pasting the command runs something nobody typed.
Other values redraw the terminal line, so the text you copy is not the text on screen.
Sometimes the paste just hands `bd` a different value or an extra argument.
Windows gets the worst of it, but Linux and macOS are affected as well.

On Windows people paste these into cmd.exe, PowerShell or Git Bash, and many run `bd` through the npm `bd.cmd` shim.
On Linux and macOS they use sh, bash, zsh, fish, and sometimes PowerShell.

Please make these refusals safe in all of those shells, whatever the config holds.
When a value is written into one of the commands, pasting it should hand `bd` exactly what the repo recorded, nothing more and nothing changed.
If a value can't be written so that every one of those shells passes it through untouched, leave it out and put a placeholder in angle brackets there instead, like the `<name>` that `bd init` already shows.
The rest of the message, like the host or path it names next to the command, should be just as safe to copy and shouldn't be able to mess with the terminal line.
It still has to name that host or path in full.
When a value can't be shown as it is, write it as a double-quoted string with backslash escapes, the way the message already shows `dolt.host: "db.example.com"`, so that reading the escapes back gives exactly the recorded value.
Ordinary hosts and paths should keep printing exactly the way they do today.
When and why `bd` refuses is right already, so leave that part alone.
