#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
# Dependencies are baked into the image's module cache, so this runs with the
# network cut and must resolve everything from that cache.
cd /repo/ragflow

# Offline switches: make a cache miss fail fast instead of retrying against a
# dead network. GOFLAGS=-mod=mod lets `go mod download` reconcile go.mod and
# go.sum against the cache without a network-backed proxy; GOPROXY=off forbids
# any network fetch; GOTOOLCHAIN=local forbids a toolchain download.
export GOFLAGS=-mod=mod
export GOPROXY=off
export GOTOOLCHAIN=local
export CGO_ENABLED=0

# Dependencies: offline-first against the image bake, logged online fallback.
if GOPROXY=off go mod download > /tmp/test-setup-godl.log 2>&1; then
    echo "[offline-first] go modules satisfied from image cache"
elif GOFLAGS=-mod=mod GOPROXY='https://proxy.golang.org,direct' go mod download >> /tmp/test-setup-godl.log 2>&1; then
    echo "[test-setup] go modules downloaded online (image bake was stale)"
else
    tail -40 /tmp/test-setup-godl.log >&2; exit 1
fi
