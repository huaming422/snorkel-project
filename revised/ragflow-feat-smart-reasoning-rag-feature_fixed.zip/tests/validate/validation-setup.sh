#!/usr/bin/env bash
# Validation-phase setup for the smart-reasoning task.
#
# Runs AFTER the implementation change has been applied to /repo/ragflow and
# BEFORE the generated story _test.go files are compiled and run by the go-test
# driver. Dependencies are baked into the image's module cache, so this runs
# with the network cut and must resolve everything from that cache;
# `go mod download` only reconciles go.mod/go.sum against it.

set -euo pipefail

cd /repo/ragflow

# Offline switches (mirror tests/test-setup.sh): a cache miss fails fast instead
# of hanging on a dead network. GOFLAGS=-mod=mod lets `go mod download` work
# from the current go.mod; GOPROXY=off forbids any network fetch;
# GOTOOLCHAIN=local forbids a toolchain download; pure Go, no cgo.
export GOFLAGS=-mod=mod
export GOPROXY=off
export GOTOOLCHAIN=local
export CGO_ENABLED=0
export GOCACHE="${GOCACHE:-/root/.cache/go-build}"
export GOMODCACHE="${GOMODCACHE:-/root/go/pkg/mod}"
mkdir -p "$GOCACHE" "$GOMODCACHE"

# Resolve modules offline-first against the image bake, with a logged online
# fallback only if the bake was stale (for example a dependency that is in the
# lockfile transitively but not yet materialized).
if GOPROXY=off go mod download > /tmp/validation-setup-godl.log 2>&1; then
    echo "[offline-first] go modules satisfied from image cache"
elif GOFLAGS=-mod=mod GOPROXY='https://proxy.golang.org,direct' go mod download >> /tmp/validation-setup-godl.log 2>&1; then
    echo "[validation-setup] go modules downloaded online (image bake was stale)"
else
    tail -40 /tmp/validation-setup-godl.log >&2
    exit 1
fi

# Loud smoke guard: the stories inject an external `package runtime_test` file
# into internal/agent/runtime. Confirm the whole module builds, so a build
# error stops here with a clear message rather than as an opaque per-case
# build_error later.
if ! go build ./... > /tmp/validation-setup-build.log 2>&1; then
    echo "[validation-setup] changed tree failed to build:" >&2
    tail -60 /tmp/validation-setup-build.log >&2
    exit 1
fi

echo "[validation-setup] ragflow builds offline; validation environment ready"
