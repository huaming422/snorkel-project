## Task

We want to add a "smart-reasoning" conversation mode to the knowledge-base assistant.
Instead of the fixed retrieve-then-answer flow, the model works through the knowledge base on its own and decides which search and reasoning tools it needs before replying.
RAGFlow already depends on cloudwego/eino, and the eino ADK's chat-model agent runs exactly this kind of reason-act loop, so please build on it instead of writing a new loop.

For now we only need the backend piece: a new self-contained Go package that builds the agent's tools and system prompt, plus an exported entry point that sets the agent up for a turn.
Hooking it up to the chat endpoints and the UI will come later.

The system prompt should be evidence-first.
It should push the model to find the relevant documents and read them through, then answer from what it read rather than from what it already knows.

The machine is offline, and everything the package needs is already installed, including a JavaScript engine.
run_javascript should run snippets in-process with that engine rather than sending them to the code executor sandbox.

## User stories / requirements

- The agent exposes exactly six tools the chat model can call: think, todo_write, grep_chunks, search_chunks, list_chunks and run_javascript. Its system prompt names all six, mentions no other tool (like web_search, web_fetch, get_document_info or query_knowledge_graph) and has no unrendered {{ }} placeholders. Setting the agent up without a chat model fails.
- run_javascript runs a self-contained ES5.1 snippet and returns what it prints with console.log, such as the sum of an array. Snippets that use the module system (import, require, module.exports) get an error. So does a multi-megabyte source, and so does a snippet still running when the caller cancels or its deadline passes.
- grep_chunks searches chunk text with a case-insensitive regular expression and returns the text that matched. An empty pattern, or one that is not a valid regular expression, gets an error.
- list_chunks reads one document, addressed only by its document id, and returns its chunks in reading order one page at a time: the caller sets the page size and can ask for the next page. A request without a document id gets an error.
- search_chunks takes one to five semantic queries, runs every one of them and returns the content of the chunks it finds. Zero queries or more than five get an error.
- Retrieval never leaves the caller's tenant: grep_chunks, search_chunks and list_chunks only search the tenant the tools were built for. When the model doesn't name datasets, grep_chunks and search_chunks search the datasets bound to the conversation.
