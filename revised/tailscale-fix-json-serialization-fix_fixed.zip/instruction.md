## Task

We moved our builds to Go 1.27 and tailscaled broke on every node whose tailnet has Tailscale SSH rules.
The netmap from control no longer decodes on those nodes, so each poll fails and the client just keeps retrying.
The same tree built with Go 1.26 works fine.

CI went red with the bump too.
`go test ./...` now fails in types/logger, types/opt, types/prefs and logtail, which all passed on Go 1.26.
The types/logger one is TestAsJSON failing with `allocs = 3; want max 2`.

Can you find out what the new toolchain changed for us and fix it?
The netmap has to decode again, and the tests that went red have to pass as they are, so please don't delete, skip or loosen them (the allocation limit included).

The JSON we send and receive can't change at all.
Some of our nodes and control servers are still built with Go 1.26, and go.mod still says 1.26.5, so the code has to keep building on Go 1.26, write byte-for-byte the same JSON and read it the same way, whichever toolchain built it.
Going back to the old toolchain isn't a fix, and neither is dropping a field or a feature that's affected.
