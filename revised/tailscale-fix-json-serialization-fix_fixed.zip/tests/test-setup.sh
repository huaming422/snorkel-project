#!/usr/bin/env bash
#
# Sourced (not exec'd) by tests/test.sh before every verifier, under
# `set -euo pipefail`. Sets the Go build environment again in case the working
# tree or a layer changed it, and checks that the baked module cache covers the
# module graph without the network.
#
# A plain Go library task: no services to start, no data to seed, no
# assertion logic here.

REPO_DIR="${REPO_DIR:-/repo/tailscale}"
cd "$REPO_DIR"

# Run against the toolchain baked in the image (go.mod declares an older
# language version with no `toolchain` directive, so `local` keeps the installed
# compiler). Dependencies are baked into the image, so the network stays off
# and a cache miss fails fast.
export GOTOOLCHAIN=local
export GOFLAGS=-mod=mod
export GOPROXY=off
export CGO_ENABLED=1

# Make `go` reachable even if the harness scrubbed PATH.
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:/root/go/bin:$PATH ;;
esac

# Dependencies: offline first against the image cache, with a logged online
# fallback. Offline is the expected path; the fallback only matters if the
# cache was stale, and it only reaches the network when the run has one.
if go mod download > /tmp/test-setup-godl.log 2>&1; then
    echo "[offline-first] go modules satisfied from image cache"
elif GOPROXY=https://proxy.golang.org,direct GOFLAGS=-mod=mod go mod download >> /tmp/test-setup-godl.log 2>&1; then
    echo "[test-setup] go modules downloaded online (image bake was stale)"
else
    tail -40 /tmp/test-setup-godl.log >&2
    exit 1
fi

echo "test-setup.sh: ready (GOTOOLCHAIN=local, GOFLAGS=$GOFLAGS, GOPROXY=$GOPROXY, CGO_ENABLED=$CGO_ENABLED)"
