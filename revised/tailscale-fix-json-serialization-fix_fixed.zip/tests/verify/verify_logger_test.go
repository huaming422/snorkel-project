// Copyright (c) Tailscale Inc & contributors
// SPDX-License-Identifier: BSD-3-Clause

// types/logger.AsJSON prints a value's JSON through fmt, reports a marshal
// error inline, and stays within the package's limit of 2 allocations per
// print (the limit the repo's TestAsJSON sets).
//
// The test uses only logger.AsJSON through fmt.
package logger

import (
	"bytes"
	"fmt"
	"testing"
)

// TestVerifyAsJSONOutputAndAllocs checks AsJSON's output for a struct and for
// an unsupported value, and its allocations per print. verify.toml runs it
// without the race detector.
func TestVerifyAsJSONOutputAndAllocs(t *testing.T) {
	// A small struct prints as compact JSON in field order.
	got := fmt.Sprintf("got %v", AsJSON(struct {
		Foo string
		Bar int
	}{"hi", 123}))
	const want = `got {"Foo":"hi","Bar":123}`
	if got != want {
		t.Fatalf("AsJSON output changed\n got: %#q\nwant: %#q", got, want)
	}

	// A marshal error is printed inline.
	gotErr := fmt.Sprintf("got %v", AsJSON(func() {}))
	const wantErr = `got %!JSON-ERROR:json: unsupported type: func()`
	if gotErr != wantErr {
		t.Fatalf("AsJSON marshal-error output changed\n got: %#q\nwant: %#q", gotErr, wantErr)
	}

	// At most 2 allocations per print.
	var buf bytes.Buffer
	n := int(testing.AllocsPerRun(1000, func() {
		buf.Reset()
		fmt.Fprintf(&buf, "got %v", AsJSON("hi"))
	}))
	if n > 2 {
		t.Fatalf("AsJSON allocs = %d; want max 2", n)
	}
}
