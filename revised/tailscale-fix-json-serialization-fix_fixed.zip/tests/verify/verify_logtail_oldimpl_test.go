// Copyright (c) Tailscale Inc & contributors
// SPDX-License-Identifier: BSD-3-Clause

// logtail.LogEntry[T] gives the same bytes when encoded by the JSON
// implementation a Go 1.26 build uses: the value's fields at the top level of
// the object, next to the reserved "logtail" member.
//
// verify.toml runs this file with GOEXPERIMENT=nojsonv2. With that setting the
// go-json-experiment module that go.mod names compiles its own encoder, as it
// does on Go 1.26, instead of forwarding to the standard library. The test
// encodes through that module's Marshal, which is what logtail uploads use,
// and compares exact bytes with the Go 1.27 output in verify_logtail_test.go.
// The logtail package has its own TestMain, so this file declares none.
package logtail

import (
	"testing"

	oldjson "github.com/go-json-experiment/json"
)

// verifyOldImplPayload is a small struct used as the LogEntry value.
type verifyOldImplPayload struct {
	Text  string `json:"text"`
	Level int    `json:"level"`
}

// TestVerifyLogEntryInlinesValueFieldsOldImpl checks that a LogEntry encoded by
// the Go 1.26 implementation has its payload fields at the top level.
func TestVerifyLogEntryInlinesValueFieldsOldImpl(t *testing.T) {
	in := LogEntry[verifyOldImplPayload]{
		Value: verifyOldImplPayload{Text: "hello", Level: 3},
	}

	got, err := oldjson.Marshal(in)
	if err != nil {
		t.Fatalf("old-impl Marshal(LogEntry) returned error: %v", err)
	}

	// "text" and "level" at the top level, not under a "Value" key; the zero
	// Logtail metadata is omitted.
	const want = `{"text":"hello","level":3}`
	if string(got) != want {
		t.Fatalf("Go 1.26 encoding of LogEntry\n got: %s\nwant: %s\n"+
			"(the value's fields belong at the top level)", got, want)
	}

	// With metadata set, "logtail" comes first and the payload fields follow
	// at the same level.
	in2 := LogEntry[verifyOldImplPayload]{
		Logtail: Logtail{ProcID: 7, ProcSeq: 42},
		Value:   verifyOldImplPayload{Text: "second", Level: 1},
	}
	got2, err := oldjson.Marshal(in2)
	if err != nil {
		t.Fatalf("old-impl Marshal(LogEntry with metadata) returned error: %v", err)
	}
	const want2 = `{"logtail":{"proc_id":7,"proc_seq":42},"text":"second","level":1}`
	if string(got2) != want2 {
		t.Fatalf("Go 1.26 encoding of LogEntry with metadata\n got: %s\nwant: %s", got2, want2)
	}
}
