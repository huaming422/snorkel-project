// Copyright (c) Tailscale Inc & contributors
// SPDX-License-Identifier: BSD-3-Clause

// tailcfg.SSHAction and a MapResponse carrying an SSH policy encode and decode
// through the standard library encoding/json, with SSHAction.SessionDuration
// on the wire as an int64 count of nanoseconds.
//
// The session duration is set and read through reflection, so these tests
// build with any integer-backed type for that field. They use only
// pre-existing exported types and json.Marshal / json.Unmarshal.
package tailcfg

import (
	"encoding/json"
	"reflect"
	"testing"
	"time"
)

// verifySessionDurationField returns a's SessionDuration field and stops the
// test if it is not an integer kind.
func verifySessionDurationField(t *testing.T, a *SSHAction) reflect.Value {
	t.Helper()
	f := reflect.ValueOf(a).Elem().FieldByName("SessionDuration")
	if !f.IsValid() || !f.CanInt() {
		t.Fatalf("SSHAction.SessionDuration is %v; want an integer count of nanoseconds", f.Kind())
	}
	return f
}

func verifySetSessionDuration(t *testing.T, a *SSHAction, d time.Duration) {
	t.Helper()
	verifySessionDurationField(t, a).SetInt(int64(d))
}

func verifyGetSessionDuration(t *testing.T, a *SSHAction) time.Duration {
	t.Helper()
	return time.Duration(verifySessionDurationField(t, a).Int())
}

// TestVerifySSHActionSessionDurationRoundTrip checks the exact bytes of an
// SSHAction for several session durations (including none) and that each
// decodes back to an equal value.
func TestVerifySSHActionSessionDurationRoundTrip(t *testing.T) {
	cases := []struct {
		name string
		base SSHAction
		dur  time.Duration
		want string
	}{
		{"accept_90m", SSHAction{Accept: true}, 90 * time.Minute, `{"accept":true,"sessionDuration":5400000000000}`},
		{"only_5s", SSHAction{}, 5 * time.Second, `{"sessionDuration":5000000000}`},
		{"message_1500ms", SSHAction{Message: "hi", Accept: true}, 1500 * time.Millisecond, `{"message":"hi","accept":true,"sessionDuration":1500000000}`},
		{"reject_no_duration", SSHAction{Reject: true}, 0, `{"reject":true}`},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			in := tc.base
			verifySetSessionDuration(t, &in, tc.dur)

			got, err := json.Marshal(in)
			if err != nil {
				t.Fatalf("json.Marshal(SSHAction) error: %v", err)
			}
			if string(got) != tc.want {
				t.Fatalf("json.Marshal(SSHAction)\n got: %s\nwant: %s", got, tc.want)
			}

			var back SSHAction
			if err := json.Unmarshal(got, &back); err != nil {
				t.Fatalf("json.Unmarshal(SSHAction) error: %v", err)
			}
			if !reflect.DeepEqual(back, in) {
				t.Fatalf("SSHAction round trip\n got: %+v\nwant: %+v", back, in)
			}
			if d := verifyGetSessionDuration(t, &back); d != tc.dur {
				t.Fatalf("decoded SessionDuration = %v; want %v", d, tc.dur)
			}
		})
	}
}

// TestVerifyNetmapSSHPolicyDecode decodes a MapResponse whose SSH policy has
// rules with and without a session duration, the way a netmap poll reads it.
// The last rule spells its members in another case, which encoding/json
// matches on Go 1.26.
func TestVerifyNetmapSSHPolicyDecode(t *testing.T) {
	const netmap = `{"SSHPolicy":{"rules":[` +
		`{"action":{"accept":true,"sessionDuration":5400000000000}},` +
		`{"action":{"message":"later","accept":true,"sessionDuration":5000000000}},` +
		`{"action":{"reject":true}},` +
		`{"action":{"Accept":true,"SessionDuration":250000000}}` +
		`]}}`

	var mr MapResponse
	if err := json.Unmarshal([]byte(netmap), &mr); err != nil {
		t.Fatalf("json.Unmarshal(MapResponse) error: %v", err)
	}
	if mr.SSHPolicy == nil || len(mr.SSHPolicy.Rules) != 4 {
		t.Fatalf("decoded SSHPolicy = %+v; want 4 rules", mr.SSHPolicy)
	}
	want := []struct {
		accept, reject bool
		message        string
		dur            time.Duration
	}{
		{true, false, "", 90 * time.Minute},
		{true, false, "later", 5 * time.Second},
		{false, true, "", 0},
		{true, false, "", 250 * time.Millisecond},
	}
	for i, w := range want {
		a := mr.SSHPolicy.Rules[i].Action
		if a == nil {
			t.Fatalf("rule %d: nil action", i)
		}
		if a.Accept != w.accept || a.Reject != w.reject || a.Message != w.message {
			t.Errorf("rule %d: action = %+v; want accept=%v reject=%v message=%q", i, *a, w.accept, w.reject, w.message)
		}
		if d := verifyGetSessionDuration(t, a); d != w.dur {
			t.Errorf("rule %d: SessionDuration = %v; want %v", i, d, w.dur)
		}
	}
}
