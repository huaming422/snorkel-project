#!/usr/bin/env bash
#
# The whole module still builds (`go build ./...`) and the tests of util/set, a
# package with no JSON in it, still pass. Runs from the repo root.
set -uo pipefail

REPO_DIR="${REPO_DIR:-/repo/tailscale}"
cd "$REPO_DIR" || { echo "cannot cd to $REPO_DIR" >&2; exit 1; }

# Use the image's toolchain and the baked module cache only.
export GOTOOLCHAIN=local
export GOFLAGS=-mod=mod
export GOPROXY=off
export CGO_ENABLED=1
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:/root/go/bin:$PATH ;;
esac

echo "[verify_build] go build ./..."
if ! go build ./... > /tmp/verify-build.log 2>&1; then
    echo "[verify_build] go build ./... FAILED: the module no longer compiles" >&2
    tail -60 /tmp/verify-build.log >&2
    exit 1
fi
echo "[verify_build] go build ./... ok"

# util/set has no JSON code and its tests pass at the pinned commit.
STABLE_PKG="./util/set/..."
echo "[verify_build] go test ${STABLE_PKG}"
if ! go test -count=1 "${STABLE_PKG}" > /tmp/verify-build-test.log 2>&1; then
    echo "[verify_build] go test ${STABLE_PKG} FAILED" >&2
    tail -60 /tmp/verify-build-test.log >&2
    exit 1
fi
echo "[verify_build] go test ${STABLE_PKG} ok"

echo "[verify_build] PASS"
exit 0
