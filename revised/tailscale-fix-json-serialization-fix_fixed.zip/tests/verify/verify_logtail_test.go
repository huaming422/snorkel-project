// Copyright (c) Tailscale Inc & contributors
// SPDX-License-Identifier: BSD-3-Clause

// logtail.LogEntry[T] puts the fields of its value at the top level of the
// JSON object, next to the reserved "logtail" member, through the standard
// library encoding/json.
//
// The test uses only the pre-existing exported type and compares exact bytes.
// The logtail package has its own TestMain, so this file declares none.
package logtail

import (
	"encoding/json"
	"reflect"
	"testing"
)

// verifyPayload is a small struct used as the LogEntry value.
type verifyPayload struct {
	Text  string `json:"text"`
	Level int    `json:"level"`
}

// TestVerifyLogEntryInlinesValueFields checks that a LogEntry marshals to an
// object whose payload fields sit at the top level, and decodes back to an
// equal value.
func TestVerifyLogEntryInlinesValueFields(t *testing.T) {
	in := LogEntry[verifyPayload]{
		Value: verifyPayload{Text: "hello", Level: 3},
	}

	got, err := json.Marshal(in)
	if err != nil {
		t.Fatalf("json.Marshal(LogEntry) returned error: %v", err)
	}

	// "text" and "level" at the top level, not under a "Value" key; the zero
	// Logtail metadata is omitted.
	const want = `{"text":"hello","level":3}`
	if string(got) != want {
		t.Fatalf("json.Marshal(LogEntry)\n got: %s\nwant: %s\n"+
			"(the value's fields belong at the top level)", got, want)
	}

	var back LogEntry[verifyPayload]
	if err := json.Unmarshal(got, &back); err != nil {
		t.Fatalf("json.Unmarshal(LogEntry) returned error: %v", err)
	}
	if !reflect.DeepEqual(back, in) {
		t.Fatalf("LogEntry round trip\n got: %+v\nwant: %+v", back, in)
	}

	// With metadata set, "logtail" comes first and the payload fields follow
	// at the same level.
	in2 := LogEntry[verifyPayload]{
		Logtail: Logtail{ProcID: 7, ProcSeq: 42},
		Value:   verifyPayload{Text: "second", Level: 1},
	}
	got2, err := json.Marshal(in2)
	if err != nil {
		t.Fatalf("json.Marshal(LogEntry with metadata) returned error: %v", err)
	}
	const want2 = `{"logtail":{"proc_id":7,"proc_seq":42},"text":"second","level":1}`
	if string(got2) != want2 {
		t.Fatalf("json.Marshal(LogEntry with metadata)\n got: %s\nwant: %s", got2, want2)
	}
	var back2 LogEntry[verifyPayload]
	if err := json.Unmarshal(got2, &back2); err != nil {
		t.Fatalf("json.Unmarshal(LogEntry with metadata) returned error: %v", err)
	}
	if !reflect.DeepEqual(back2, in2) {
		t.Fatalf("LogEntry with metadata round trip\n got: %+v\nwant: %+v", back2, in2)
	}
}
