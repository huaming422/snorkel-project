// Copyright (c) Tailscale Inc & contributors
// SPDX-License-Identifier: BSD-3-Clause

// types/opt.Value[T] keeps its JSON encoding and decoding through the standard
// library encoding/json: a set Value holding a nil slice encodes as [], one
// holding a nil map as {}, an unset Value as null, and decoding a held struct
// matches member names exactly.
//
// The test uses only the pre-existing exported type and json.Marshal /
// json.Unmarshal, and compares exact bytes.
package opt

import (
	"encoding/json"
	"reflect"
	"testing"
)

// TestVerifyValueNilSliceMapWireFormat checks that a Value holding a nil slice
// marshals to [] and one holding a nil map to {}, that both decode back to set,
// empty containers, that set and unset values keep their encoding, and that
// decoding matches member names exactly.
func TestVerifyValueNilSliceMapWireFormat(t *testing.T) {
	in := struct {
		Slice Value[[]int]
		Map   Value[map[string]int]
	}{
		Slice: ValueOf[[]int](nil),
		Map:   ValueOf[map[string]int](nil),
	}

	got, err := json.Marshal(in)
	if err != nil {
		t.Fatalf("json.Marshal returned error: %v", err)
	}

	const want = `{"Slice":[],"Map":{}}`
	if string(got) != want {
		t.Fatalf("json.Marshal(opt.Value)\n got: %s\nwant: %s\n(a nil slice encodes as [] and a nil map as {})", got, want)
	}

	// The empty containers decode back as set, empty (non-nil) values.
	wantBack := struct {
		Slice Value[[]int]
		Map   Value[map[string]int]
	}{ValueOf([]int{}), ValueOf(map[string]int{})}
	var back struct {
		Slice Value[[]int]
		Map   Value[map[string]int]
	}
	if err := json.Unmarshal(got, &back); err != nil {
		t.Fatalf("json.Unmarshal returned error: %v", err)
	}
	if !reflect.DeepEqual(back, wantBack) {
		t.Fatalf("opt.Value did not round-trip\n got: %+v\nwant: %+v", back, wantBack)
	}

	// A non-empty slice and an unset Value.
	in2 := struct {
		Set   Value[[]int]
		Unset Value[[]int]
	}{
		Set: ValueOf([]int{1, 2, 3}),
	}
	got2, err := json.Marshal(in2)
	if err != nil {
		t.Fatalf("json.Marshal (set/unset) returned error: %v", err)
	}
	const want2 = `{"Set":[1,2,3],"Unset":null}`
	if string(got2) != want2 {
		t.Fatalf("json.Marshal(set and unset opt.Value)\n got: %s\nwant: %s", got2, want2)
	}

	// Decoding matches member names exactly, as on Go 1.26: "name" does not
	// fill the field Name, and the Value is still set.
	type verifyNamed struct {
		Name string
	}
	var named struct{ V Value[verifyNamed] }
	if err := json.Unmarshal([]byte(`{"V":{"name":"lower"}}`), &named); err != nil {
		t.Fatalf("json.Unmarshal(opt.Value of struct) error: %v", err)
	}
	if v, ok := named.V.GetOk(); !ok || v.Name != "" {
		t.Fatalf("decoded opt.Value = %+v (set=%v); want set with Name \"\" (member names match exactly)", v, ok)
	}
}
