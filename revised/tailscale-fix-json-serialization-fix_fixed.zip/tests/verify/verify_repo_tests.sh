#!/usr/bin/env bash
#
# The repository's own TestAsJSON (types/logger), TestValue (types/opt),
# TestMarshalUnmarshal (types/prefs) and TestUploadLogs (logtail) keep the
# source they have at the pinned commit, and each one runs and passes.
#
# Each function's source, from its `func TestName(` line to the closing `}` at
# column 0, is hashed and compared with the hash of the same function at the
# pinned commit. Other tests in those files may change or be added.
set -uo pipefail

REPO_DIR="${REPO_DIR:-/repo/tailscale}"
cd "$REPO_DIR" || { echo "cannot cd to $REPO_DIR" >&2; exit 1; }

export GOTOOLCHAIN=local
export GOFLAGS=-mod=mod
export GOPROXY=off
export CGO_ENABLED=1
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:/root/go/bin:$PATH ;;
esac

# package dir | test file | test function | sha256 of the function at the pinned commit
CHECKS="
types/logger|logger_test.go|TestAsJSON|d9292487f7300735d57f6905922992032bf0f475b0115779db01047952fc07bb
types/opt|value_test.go|TestValue|98c522ec64b628437de0dc4346ebc9408bc6e457e4e9bcbb65802634a65b215b
types/prefs|prefs_test.go|TestMarshalUnmarshal|d88ac4983309a2570c84fd6c3b3712688c8d11b538b07ded88287d556a0d3ed7
logtail|logtail_test.go|TestUploadLogs|d27596a7046de10e9ce6b69dbf7f672ec57242ebb5cc889f45228cc01794fa3f
"

status=0
for line in $CHECKS; do
    IFS='|' read -r pkg file func want <<< "$line"

    src="$pkg/$file"
    got=""
    if [ -f "$src" ]; then
        got=$(awk -v start="func ${func}(" 'index($0, start) == 1 { p = 1 } p { print } p && $0 == "}" { exit }' "$src" | sha256sum | cut -d' ' -f1)
    fi
    if [ "$got" != "$want" ]; then
        echo "[verify_repo_tests] $src: ${func} is missing or differs from the pinned commit" >&2
        status=1
        continue
    fi

    log="/tmp/verify-repo-tests-${func}.log"
    go test -count=1 -v -run "^${func}\$" "./$pkg" > "$log" 2>&1
    rc=$?
    if [ $rc -ne 0 ] || ! grep -q -- "^--- PASS: ${func} (" "$log"; then
        echo "[verify_repo_tests] go test -run ^${func}\$ ./$pkg did not pass (exit $rc)" >&2
        grep -E -- '^(=== RUN|--- (FAIL|SKIP)|FAIL|ok)|_test\.go:[0-9]+:' "$log" | tail -40 >&2
        status=1
        continue
    fi
    echo "[verify_repo_tests] ${func} (./$pkg) ok"
done

[ $status -eq 0 ] && echo "[verify_repo_tests] PASS"
exit $status
