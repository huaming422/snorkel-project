// Copyright (c) Tailscale Inc & contributors
// SPDX-License-Identifier: BSD-3-Clause

// types/prefs preference types give the same bytes when encoded by the JSON
// implementation a Go 1.26 build uses: the managed and read-only flags at the
// top level of the preference object next to "Value", not under their own key.
//
// verify.toml runs this file with GOEXPERIMENT=nojsonv2. With that setting the
// go-json-experiment module that go.mod names compiles its own encoder, as it
// does on Go 1.26, instead of forwarding to the standard library. The test
// encodes through that module's Marshal and compares exact bytes with the
// Go 1.27 output in verify_prefs_test.go. Preferences are built with the
// package's exported constructors and options.
package prefs

import (
	"testing"

	oldjson "github.com/go-json-experiment/json"
)

// verifyOldImplPrefs is a minimal preferences bundle built only from the
// package's public preference types. Its JSON shape is governed by the same
// serializable layout as every real preferences struct.
type verifyOldImplPrefs struct {
	StringItem Item[string]
	IntSlice   List[int]
}

// TestVerifyPrefsMetadataInlineOldImpl checks the bytes of a preferences bundle
// encoded by the Go 1.26 implementation.
func TestVerifyPrefsMetadataInlineOldImpl(t *testing.T) {
	// A managed string item plus an empty-slice list.
	in := &verifyOldImplPrefs{
		StringItem: ItemOf("v1", Managed),
		IntSlice:   ListOf([]int{}),
	}

	got, err := oldjson.Marshal(in)
	if err != nil {
		t.Fatalf("old-impl Marshal(prefs) returned error: %v", err)
	}

	const want = `{"StringItem":{"Value":"v1","Managed":true},"IntSlice":{"Value":[]}}`
	if string(got) != want {
		t.Fatalf("Go 1.26 encoding of prefs\n got: %s\nwant: %s\n"+
			"(the flags belong at the top level of each preference)", got, want)
	}

	// A read-only, unconfigured item: no "Value" key, flag at the top level.
	in2 := &verifyOldImplPrefs{StringItem: ItemWithOpts[string](ReadOnly)}
	got2, err := oldjson.Marshal(in2)
	if err != nil {
		t.Fatalf("old-impl Marshal(prefs readonly) returned error: %v", err)
	}
	const want2 = `{"StringItem":{"ReadOnly":true},"IntSlice":{}}`
	if string(got2) != want2 {
		t.Fatalf("Go 1.26 encoding of read-only prefs\n got: %s\nwant: %s", got2, want2)
	}
}
