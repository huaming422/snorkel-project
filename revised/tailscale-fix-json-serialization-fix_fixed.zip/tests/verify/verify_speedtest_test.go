// Copyright (c) Tailscale Inc & contributors
// SPDX-License-Identifier: BSD-3-Clause

// The net/speedtest handshake config encodes and decodes through the standard
// library encoding/json, with its duration on the wire as an int64 count of
// nanoseconds under the "time" key.
//
// The config type is unexported and no exported API returns its JSON, so this
// test lives in package speedtest. The duration is set and read through
// reflection, so it builds with any integer-backed type for that field.
package speedtest

import (
	"encoding/json"
	"reflect"
	"testing"
	"time"
)

func verifyTestDurationField(t *testing.T, c *config) reflect.Value {
	t.Helper()
	f := reflect.ValueOf(c).Elem().FieldByName("TestDuration")
	if !f.IsValid() || !f.CanInt() {
		t.Fatalf("config.TestDuration is %v; want an integer count of nanoseconds", f.Kind())
	}
	return f
}

// TestVerifySpeedtestConfigDurationRoundTrip checks the exact bytes of the
// config for several durations and both directions, that each decodes back to
// an equal value, and that capitalized keys decode too.
func TestVerifySpeedtestConfigDurationRoundTrip(t *testing.T) {
	cases := []struct {
		name string
		dir  Direction
		dur  time.Duration
		want string
	}{
		{"download_5s", Download, 5 * time.Second, `{"version":2,"time":5000000000,"direction":0}`},
		{"upload_90m", Upload, 90 * time.Minute, `{"version":2,"time":5400000000000,"direction":1}`},
		{"upload_250ms", Upload, 250 * time.Millisecond, `{"version":2,"time":250000000,"direction":1}`},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			in := config{Version: version, Direction: tc.dir}
			verifyTestDurationField(t, &in).SetInt(int64(tc.dur))

			got, err := json.Marshal(in)
			if err != nil {
				t.Fatalf("json.Marshal(config) error: %v", err)
			}
			if string(got) != tc.want {
				t.Fatalf("json.Marshal(config)\n got: %s\nwant: %s", got, tc.want)
			}

			var back config
			if err := json.Unmarshal(got, &back); err != nil {
				t.Fatalf("json.Unmarshal(config) error: %v", err)
			}
			if !reflect.DeepEqual(back, in) {
				t.Fatalf("config round trip\n got: %+v\nwant: %+v", back, in)
			}
			if d := time.Duration(verifyTestDurationField(t, &back).Int()); d != tc.dur {
				t.Fatalf("decoded TestDuration = %v; want %v", d, tc.dur)
			}
		})
	}

	// encoding/json matches member names in any case on Go 1.26, so a config
	// with capitalized keys decodes the same way.
	var upper config
	if err := json.Unmarshal([]byte(`{"Version":2,"Time":5000000000,"Direction":1}`), &upper); err != nil {
		t.Fatalf("json.Unmarshal(config with capitalized keys) error: %v", err)
	}
	if d := time.Duration(verifyTestDurationField(t, &upper).Int()); upper.Version != 2 || upper.Direction != Upload || d != 5*time.Second {
		t.Fatalf("decoded config = %+v (duration %v); want version 2, Upload, 5s", upper, d)
	}
}
