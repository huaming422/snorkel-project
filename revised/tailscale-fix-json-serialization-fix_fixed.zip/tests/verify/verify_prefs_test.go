// Copyright (c) Tailscale Inc & contributors
// SPDX-License-Identifier: BSD-3-Clause

// types/prefs preference types keep their JSON encoding through the standard
// library encoding/json:
//
//   - per-preference metadata (the managed and read-only flags) sits at the top
//     level of the preference object next to "Value", not under its own key;
//   - a preference holding an empty slice encodes its value as [], and a nil
//     slice inside a default value as [];
//   - decoding matches member names exactly.
//
// Preferences are built with the package's exported constructors and options
// (ItemOf, ListOf, ItemWithOpts, Managed, ReadOnly), and the test compares
// exact bytes.
package prefs

import (
	"encoding/json"
	"testing"
)

// verifyPrefs is a minimal preferences bundle built only from the package's
// public preference types. Its JSON shape is governed by the same serializable
// layout as every real preferences struct.
type verifyPrefs struct {
	StringItem Item[string]
	IntSlice   List[int]
}

// verifyPrefsDefault is a struct default value with a slice that stays nil.
type verifyPrefsDefault struct {
	Tags []string
	N    int
}

// TestVerifyPrefsMetadataInlineAndSliceSemantics checks the bytes of a
// preferences bundle from json.Marshal and that json.Unmarshal restores it.
func TestVerifyPrefsMetadataInlineAndSliceSemantics(t *testing.T) {
	// A managed string item plus an empty-slice list.
	in := &verifyPrefs{
		StringItem: ItemOf("v1", Managed),
		IntSlice:   ListOf([]int{}),
	}

	got, err := json.Marshal(in)
	if err != nil {
		t.Fatalf("json.Marshal(prefs) returned error: %v", err)
	}

	const want = `{"StringItem":{"Value":"v1","Managed":true},"IntSlice":{"Value":[]}}`
	if string(got) != want {
		t.Fatalf("json.Marshal(prefs)\n got: %s\nwant: %s", got, want)
	}

	// Decoding restores the managed flag and the configured values.
	var back verifyPrefs
	if err := json.Unmarshal(got, &back); err != nil {
		t.Fatalf("json.Unmarshal(prefs) returned error: %v", err)
	}
	if v, ok := back.StringItem.ValueOk(); !ok || v != "v1" {
		t.Fatalf("StringItem round-trip value = %q (set=%v); want \"v1\" (set=true)", v, ok)
	}
	if !back.StringItem.IsManaged() {
		t.Fatalf("StringItem lost its managed flag on round trip")
	}
	if v, ok := back.IntSlice.ValueOk(); !ok || len(v) != 0 || v == nil {
		t.Fatalf("IntSlice round-trip value = %#v (set=%v); want an empty non-nil slice (set=true)", v, ok)
	}

	// A read-only, unconfigured item: no "Value" key, flag at the top level.
	in2 := &verifyPrefs{StringItem: ItemWithOpts[string](ReadOnly)}
	got2, err := json.Marshal(in2)
	if err != nil {
		t.Fatalf("json.Marshal(prefs readonly) returned error: %v", err)
	}
	const want2 = `{"StringItem":{"ReadOnly":true},"IntSlice":{}}`
	if string(got2) != want2 {
		t.Fatalf("json.Marshal(read-only prefs)\n got: %s\nwant: %s", got2, want2)
	}

	// A default value is written the same way as on Go 1.26: a nil slice
	// inside it encodes as [].
	var withDefault struct{ D Item[verifyPrefsDefault] }
	withDefault.D.SetDefaultValue(verifyPrefsDefault{N: 1})
	got3, err := json.Marshal(withDefault)
	if err != nil {
		t.Fatalf("json.Marshal(prefs with default) error: %v", err)
	}
	const want3 = `{"D":{"Default":{"Tags":[],"N":1}}}`
	if string(got3) != want3 {
		t.Fatalf("json.Marshal(prefs with default)\n got: %s\nwant: %s", got3, want3)
	}

	// Decoding matches member names exactly, as on Go 1.26: lower-case
	// "value" and "managed" fill nothing.
	var lower verifyPrefs
	if err := json.Unmarshal([]byte(`{"StringItem":{"value":"lower","managed":true}}`), &lower); err != nil {
		t.Fatalf("json.Unmarshal(prefs with lower-case members) error: %v", err)
	}
	if v, ok := lower.StringItem.ValueOk(); ok || lower.StringItem.IsManaged() {
		t.Fatalf("decoded StringItem = %q (set=%v, managed=%v); want unset and not managed (member names match exactly)",
			v, ok, lower.StringItem.IsManaged())
	}
}
