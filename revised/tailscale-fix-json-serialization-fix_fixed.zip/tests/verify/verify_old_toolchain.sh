#!/usr/bin/env bash
#
# The tree still targets Go 1.26 and gives the same JSON when built with the
# JSON implementation Go 1.26 uses:
#
#   - go.mod declares a Go 1.26 language version and no newer toolchain line;
#   - with GOEXPERIMENT=nojsonv2, every package with a .go file that differs
#     from the pinned commit still builds;
#   - with that same setting (encoding/json and the go-json-experiment
#     module then use their own pre-1.27 encoders, as on Go 1.26), the tailcfg,
#     net/speedtest, types/opt, types/prefs and types/logger checks in this
#     directory pass unchanged. They expect the same bytes as under Go 1.27.
#
# The logtail and types/prefs checks through the go-json-experiment module run
# with the same setting from verify.toml.
set -uo pipefail

REPO_DIR="${REPO_DIR:-/repo/tailscale}"
cd "$REPO_DIR" || { echo "cannot cd to $REPO_DIR" >&2; exit 1; }
VERIFY_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

export GOTOOLCHAIN=local
export GOFLAGS=-mod=mod
export GOPROXY=off
export CGO_ENABLED=1
export GOEXPERIMENT=nojsonv2
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:/root/go/bin:$PATH ;;
esac

go_line=$(awk '$1 == "go" { print $2; exit }' go.mod)
case "$go_line" in
    1.26|1.26.*) ;;
    *) echo "[verify_old_toolchain] go.mod declares go ${go_line:-<none>}; want a 1.26 version" >&2; exit 1 ;;
esac
toolchain_line=$(awk '$1 == "toolchain" { print $2; exit }' go.mod)
case "$toolchain_line" in
    ""|go1.26|go1.26.*) ;;
    *) echo "[verify_old_toolchain] go.mod names toolchain $toolchain_line; want none newer than go1.26" >&2; exit 1 ;;
esac
echo "[verify_old_toolchain] go.mod: go $go_line${toolchain_line:+, toolchain $toolchain_line}"

# Every directory with a .go file that differs from the pinned commit (added,
# changed or deleted) still builds with GOEXPERIMENT=nojsonv2, for the packages
# in it that build on this platform.
BASE_REF_FILE="${BASE_REF_FILE:-/var/lib/devcontainer_base_ref}"
base=$(tr -d '[:space:]' < "$BASE_REF_FILE" 2>/dev/null || true)
if [ -n "$base" ] && git rev-parse -q --verify "${base}^{commit}" > /dev/null 2>&1; then
    dirs=$( { git diff --name-only "$base" -- '*.go'; git ls-files --others --exclude-standard -- '*.go'; } \
        | xargs -r -n1 dirname | sort -u )
    pkgs=""
    for d in $dirs; do
        [ -d "$d" ] && pkgs="$pkgs ./$d"
    done
    if [ -n "$pkgs" ]; then
        # shellcheck disable=SC2086
        buildable=$(go list -e -f '{{if .GoFiles}}{{.Dir}}{{end}}' $pkgs 2>/dev/null | sed "s|^$PWD|.|")
        if [ -n "$buildable" ]; then
            # shellcheck disable=SC2086
            if ! go build -o /dev/null $buildable > /tmp/verify-old-toolchain-build.log 2>&1; then
                echo "[verify_old_toolchain] changed packages do not build with GOEXPERIMENT=nojsonv2" >&2
                tail -40 /tmp/verify-old-toolchain-build.log >&2
                exit 1
            fi
            echo "[verify_old_toolchain] changed packages build:" $buildable
        fi
    fi
else
    echo "[verify_old_toolchain] no pinned base commit in this checkout; skipping the changed-package build"
fi

injected=""
trap 'if [ -n "$injected" ]; then rm -f "$injected"; fi' EXIT

# verifier file | package dir
CHECKS="
verify_tailcfg_test.go|tailcfg
verify_speedtest_test.go|net/speedtest
verify_opt_test.go|types/opt
verify_prefs_test.go|types/prefs
verify_logger_test.go|types/logger
"

status=0
for line in $CHECKS; do
    IFS='|' read -r file pkg <<< "$line"
    funcs=$(grep -oE '^func TestVerify[A-Za-z0-9_]+' "$VERIFY_DIR/$file" | awk '{ print $2 }')
    if [ -z "$funcs" ]; then
        echo "[verify_old_toolchain] no TestVerify functions in $file" >&2
        status=1
        continue
    fi

    injected="$pkg/$file"
    cp "$VERIFY_DIR/$file" "$injected"
    log="/tmp/verify-old-toolchain-${file%.go}.log"
    go test -count=1 -v -run "^($(echo $funcs | tr ' ' '|'))\$" "./$pkg" > "$log" 2>&1
    rc=$?
    rm -f "$injected"
    injected=""

    ok=1
    [ $rc -eq 0 ] || ok=0
    for f in $funcs; do
        grep -q -- "^--- PASS: ${f} (" "$log" || ok=0
    done
    if [ $ok -ne 1 ]; then
        echo "[verify_old_toolchain] $file in ./$pkg did not pass with GOEXPERIMENT=nojsonv2 (exit $rc)" >&2
        tail -40 "$log" >&2
        status=1
        continue
    fi
    echo "[verify_old_toolchain] $file (./$pkg) ok"
done

[ $status -eq 0 ] && echo "[verify_old_toolchain] PASS"
exit $status
