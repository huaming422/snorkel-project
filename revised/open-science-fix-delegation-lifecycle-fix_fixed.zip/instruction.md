## Task

Delegated work gets its state wrong and leaks capacity when several things happen to one session at the same time.
These are the cases we've run into so far.

A batch of delegated children is running, and one child that already finished gets a follow-up message and starts new work before the others are done.
What the batch hands back then depends on where the follow-up is.
If it's still running, the whole batch fails as if it never reached a final state.
If it has finished, that child's entry carries the follow-up's response.
If it stopped on a question, the batch reports that child as waiting on the user.
Each time, the result that child produced for the batch is lost, and the batch should return it.
The same goes when the child asked a question during the batch, the user confirmed it, and the continuation has started.

A child that is paused on a question for the user shows up in `collect` as finished, while `children` lists it as `awaiting_user`.
`collect` should report `awaiting_user` too, with or without a timeout and whether it waits for all children or any, and so should a delegate call with a timeout that runs out while the child waits.
Once the user has answered, `collect` on that same attempt should show it finished again, with its own response.
Whatever `collect` returns also has to validate against the result schema the collect tool publishes to agents, waiting children included.

Stopping a session, or just its active branch, can miss children that were still starting when Stop ran, and they go on running afterwards.
A request that was still getting ready when Stop ran, before it got to saving its child, should fail with a `conflict` error, the same code a request gets while a session stop is in progress.
Nothing from it should be saved or started, and whatever it had reserved should be given back.
If it had already reached the point of saving its child, it can be turned away the same way or end up stopped, but it must not run.
Anything delegated after Stop has returned should be accepted and run as usual.

Sending a child a message, or confirming its question, starts a continuation of that child.
If handing the continuation to the runtime fails after it was saved, the child shows as running although nothing runs, and it keeps its capacity slot, so after a while nothing new can start.
In that case the call that sent the message or confirmed the question should still fail with the error it hit.
The new attempt should end with status `error` and give its capacity slot back.
A message that started it should be marked failed, and an answer the user already confirmed should stay confirmed.
Recovering interrupted work later shouldn't start it again.
Two related failures already work this way, and they need to stay that way.
If saving the continuation fails, nothing new is recorded, a question being answered stays open, and the slot is freed.
If the runtime refuses to start a saved continuation, its attempt ends in `error`, the slot is freed and a confirmed answer stays confirmed.

When a child needs several inputs resolved at once and one of them fails, the inputs that did resolve are never released, including ones that finish just after the failure.
Preparing the child should still fail with that input's error, but every input that was acquired should be released exactly once.
The same goes for a failure while copying the inputs into place.

Please keep the public delegation methods as they are.
