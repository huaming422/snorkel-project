#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
#
# The delegation subsystem under test is pure in-memory TypeScript with no
# external services, databases, or credentials. The image baked the full
# dependency closure at the base commit (npm ci in the clone RUN), and `ajv`,
# the only library the schema check needs beyond the app itself, is already a
# project dependency. So this script's job is only to make sure
# node_modules is present without reaching the network, and to fail loudly if
# the bake was somehow incomplete.
set -euo pipefail

cd /repo/open-science

# Cut npm off from any registry: a cache miss must fail fast here rather than
# silently fetch, so the smoke gate's `docker run --network none` fold stays
# honest. (Set here, not in image ENV.)
export npm_config_offline=true
export npm_config_update_notifier=false
export npm_config_fund=false
export npm_config_audit=false

# Dependencies: offline-first against the image bake, logged online fallback.
if [ -d node_modules ] && node -e "require.resolve('vitest'); require.resolve('ajv')" >/dev/null 2>&1; then
    echo "[offline-first] deps satisfied from image bake"
elif npm ci --prefer-offline --no-audit --no-fund > /tmp/test-setup-install.log 2>&1; then
    echo "[offline-first] deps restored from warm npm cache"
elif { unset npm_config_offline; npm ci --no-audit --no-fund >> /tmp/test-setup-install.log 2>&1; }; then
    echo "[test-setup] deps installed online (image bake was stale)"
else
    tail -40 /tmp/test-setup-install.log >&2
    echo "[test-setup] FAILED to satisfy node dependencies" >&2
    exit 1
fi

# Vitest thread caps (also set in image ENV / /etc/environment; re-export in
# case the verifier runs under a clean env).
export VITEST_MAX_THREADS="${VITEST_MAX_THREADS:-2}"
export VITEST_MIN_THREADS="${VITEST_MIN_THREADS:-1}"

# Sanity: the test runner and the contract-schema library must both resolve.
node -e "require.resolve('vitest'); require.resolve('ajv/dist/2020.js'); console.log('open-science delegation test env ready')"
