// @ts-nocheck
//
// Behavioral checks for the in-memory delegation engine under controlled
// concurrency. Every check drives public surfaces that already exist in the
// repository:
//
//   createTestDurableDelegatedWork({ execution, records, ... })
//       builds the DurableDelegatedWork facade with a fixture model resolver
//       (durable-delegated-work-test-fixture.ts).
//   createInMemoryDelegatedWorkRecords({ session, rootFrameId, originMessageId })
//       the in-memory record store (re-exported from durable-delegated-work.ts).
//   createDeterministicDelegateExecution(capacity?)
//       the controlled async execution harness (deterministic-execution.ts).
//       A check holds an Attempt mid-flight through its control() handles and
//       the reserve()/releasedFrames()/controls() observers, with no real
//       services or timers.
//   createProductionFrameWorkspace({ root, resolveInput })
//       the parallel input-resolution surface (frame-workspace.ts).
//   COLLECT_AGENT_CONTRACT (host-sdk/delegate-contract.ts) + Ajv2020
//       the published JSON schema for a collect result.
//
// Signals read:
//   - the identity and response of the result returned by delegate/collect,
//   - the status field reported by collect(...) and children(...),
//   - the stored Attempt status and message-receipt status after a failure,
//   - whether capacity can be reserved again (reserve() succeeds),
//   - whether a resolved input lease's close() ran,
//   - whether a waiting-on-user collect result validates against the
//     published collect schema.

import { afterEach, describe, expect, it, vi } from 'vitest'
import { mkdtemp, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import Ajv2020 from 'ajv/dist/2020.js'

import {
  createDeterministicDelegateExecution,
  type ExecutionControl
} from './deterministic-execution'
import {
  createInMemoryDelegatedWorkRecords,
  type AuthenticatedDelegateCaller
} from './durable-delegated-work'
import {
  TEST_EXECUTION_MODEL,
  createTestDurableDelegatedWork as createDurableDelegatedWork
} from './durable-delegated-work-test-fixture'
import { createProductionFrameWorkspace } from './frame-workspace'
import { COLLECT_AGENT_CONTRACT } from '../host-sdk/delegate-contract'

const caller: AuthenticatedDelegateCaller = {
  session: { projectId: 'project-1', sessionId: 'session-1' },
  frameId: 'root-frame',
  role: 'main',
  originMessageId: 'origin-message',
  toolInvocationId: 'tool-call-1'
}

// A manually-resolved promise used to pin an Attempt mid-flight and sequence a
// race deterministically.
const gate = (): { promise: Promise<void>; release(): void } => {
  let release!: () => void
  const promise = new Promise<void>((resolve) => {
    release = resolve
  })
  return { promise, release }
}

const fixture = (
  capacity = 3
): {
  execution: ReturnType<typeof createDeterministicDelegateExecution>
  records: ReturnType<typeof createInMemoryDelegatedWorkRecords>
} => {
  const execution = createDeterministicDelegateExecution(capacity)
  const records = createInMemoryDelegatedWorkRecords({
    session: caller.session,
    rootFrameId: caller.frameId,
    originMessageId: caller.originMessageId
  })
  return { execution, records }
}

// The two ends a Stop may give a request it caught while saving: refused with
// a conflict and nothing saved, or accepted with its child stopped unrun.
const stopOutcomes = [
  { refused: 'conflict', saved: [] },
  { accepted: 'receipts', saved: ['cancelled'] }
]
const stopOutcome = (
  result: { value?: { kind: string }; error?: { code?: string } },
  snapshot: Awaited<ReturnType<ReturnType<typeof createInMemoryDelegatedWorkRecords>['snapshot']>>
): Record<string, unknown> => {
  const saved = snapshot.records.map((child) => child.attempts.at(-1)?.status)
  return 'error' in result
    ? { refused: result.error?.code, saved }
    : { accepted: result.value?.kind, saved }
}

// Drive a child to the waiting-on-user state through the public question flow.
const ask = async (
  work: ReturnType<typeof createDurableDelegatedWork>,
  control: ExecutionControl,
  requestId = 'reported-question'
): Promise<void> => {
  await work.requestUserInput(
    {
      ...caller,
      role: 'delegate',
      frameId: control.input.frameId,
      attemptId: control.input.attemptId,
      originMessageId: control.input.turn!.promptMessageId,
      toolInvocationId: 'ask-choice'
    },
    {
      sessionId: caller.session.sessionId,
      questions: [
        { question: 'Which cohort?', options: [{ label: 'Strict' }, { label: 'Broad' }] }
      ]
    },
    requestId
  )
}

describe('delegation result identity under a concurrent continuation', () => {
  it.each(['running', 'completed', 'awaiting_user'] as const)(
    'returns the originally admitted batch results even when one child is continued (%s) before the other finishes',
    async (followupStatus) => {
      const { execution, records } = fixture()
      const work = createDurableDelegatedWork({ execution, records })
      const outcome = work
        .delegate(caller, [
          { task: 'Original A', name: 'A' },
          { task: 'Original B', name: 'B' }
        ])
        .then(
          (value) => ({ value }),
          (error) => ({ error })
        )
      await expect.poll(() => execution.controls()).toHaveLength(2)
      const [a1, b1] = execution.controls()
      a1.complete('ORIGINAL RESULT A1')
      await expect.poll(() => execution.releasedFrames()).toContain(a1.input.frameId)
      await work.sendMessage(
        { ...caller, toolInvocationId: 'followup-a' },
        a1.input.frameId,
        'Unrelated follow-up'
      )
      await expect.poll(() => execution.controls()).toHaveLength(3)
      const a2 = execution.controls()[2]
      a2.accept()
      if (followupStatus === 'awaiting_user') await ask(work, a2)
      if (followupStatus !== 'running') {
        a2.complete('UNRELATED FOLLOW-UP RESULT A2')
        await expect
          .poll(async () => (await records.snapshot()).records[0].attempts[1].status)
          .toBe('completed')
      }
      b1.complete('ORIGINAL RESULT B1')
      const result = await outcome
      await work.stopSession(caller.session)
      // A's entry in the batch result is A1's own outcome, never the later
      // follow-up Attempt A2.
      expect(
        result,
        JSON.stringify(result, (_key, value) => (value instanceof Error ? value.message : value))
      ).toMatchObject({
        value: {
          kind: 'results',
          children: [
            {
              frameId: a1.input.frameId,
              attemptId: a1.input.attemptId,
              status: 'completed',
              response: 'ORIGINAL RESULT A1'
            },
            {
              frameId: b1.input.frameId,
              attemptId: b1.input.attemptId,
              status: 'completed',
              response: 'ORIGINAL RESULT B1'
            }
          ]
        }
      })
    }
  )

  it('keeps the first child result after its question is confirmed and a continuation has started', async () => {
    const { execution, records } = fixture()
    const work = createDurableDelegatedWork({ execution, records })
    const outcome = work
      .delegate(caller, [
        { task: 'A', name: 'A' },
        { task: 'B', name: 'B' }
      ])
      .then(
        (value) => ({ value }),
        (error) => ({ error })
      )
    await expect.poll(() => execution.controls()).toHaveLength(2)
    const [a1, b1] = execution.controls()
    await ask(work, a1)
    a1.complete('ORIGINAL QUESTION A1')
    await expect.poll(() => execution.releasedFrames()).toHaveLength(1)
    await work.confirmQuestion(caller.session, {
      requestId: 'reported-question',
      answers: [{ questionIndex: 0, value: 'Strict' }]
    })
    await expect.poll(() => execution.controls()).toHaveLength(3)
    b1.complete('ORIGINAL RESULT B1')
    const result = await outcome
    // Once the question is answered, collect on the first Attempt reads it as finished.
    const answered = await work.collect(
      caller,
      [{ frameId: a1.input.frameId, attemptId: a1.input.attemptId }],
      { timeoutSeconds: 0 }
    )
    await work.stopSession(caller.session)
    expect(answered).toMatchObject([
      { attemptId: a1.input.attemptId, status: 'completed', response: 'ORIGINAL QUESTION A1' }
    ])
    expect(result).toMatchObject({
      value: {
        kind: 'results',
        children: [
          { attemptId: a1.input.attemptId, response: 'ORIGINAL QUESTION A1' },
          { attemptId: b1.input.attemptId, response: 'ORIGINAL RESULT B1' }
        ]
      }
    })
  })
})

describe('waiting-on-user state is reported consistently', () => {
  it.each([
    ['all', 0],
    ['any', 0],
    ['all', 1],
    ['any', 1]
  ] as const)(
    'collect (return_when=%s, timeout=%s) agrees with children for a child blocked on a question',
    async (returnWhen, timeoutSeconds) => {
      const { execution, records } = fixture()
      const work = createDurableDelegatedWork({ execution, records })
      const admitted = await work.delegate(
        caller,
        { task: 'Ask a question', name: 'Question' },
        { wait: false }
      )
      await expect.poll(() => execution.controls()).toHaveLength(1)
      await ask(work, execution.controls()[0])
      execution.controls()[0].complete('Waiting for your answer')
      await expect.poll(() => execution.releasedFrames()).toHaveLength(1)
      await expect(work.children(caller)).resolves.toMatchObject([{ status: 'awaiting_user' }])
      const observed = await work.collect(caller, [admitted.children[0]], {
        timeoutSeconds,
        returnWhen
      })
      await work.stopSession(caller.session)
      expect(observed).toMatchObject([
        { attemptId: admitted.children[0].attemptId, status: 'awaiting_user' }
      ])
    }
  )

  it('reports the pending question when a timed delegate reaches its deadline', async () => {
    const { execution, records } = fixture()
    let expired = false
    const work = createDurableDelegatedWork({
      execution,
      records,
      collectMonotonicNow: () => (expired ? 1001 : 0)
    })
    const outcome = work.delegate(caller, { task: 'Ask', name: 'Question' }, { timeoutSeconds: 1 })
    await expect.poll(() => execution.controls()).toHaveLength(1)
    await ask(work, execution.controls()[0])
    execution.controls()[0].complete('Waiting for your answer')
    await expect.poll(() => execution.releasedFrames()).toHaveLength(1)
    expired = true
    await expect(outcome).resolves.toMatchObject({
      kind: 'observations',
      children: [{ status: 'awaiting_user' }]
    })
    await work.stopSession(caller.session)
  })

  it('advertises the waiting-on-user result in the host collect contract', async () => {
    const { execution, records } = fixture()
    const work = createDurableDelegatedWork({ execution, records })
    const receipt = await work.delegate(caller, { task: 'Ask', name: 'Question' }, { wait: false })
    await expect.poll(() => execution.controls()).toHaveLength(1)
    await ask(work, execution.controls()[0])
    execution.controls()[0].complete('Waiting for your answer')
    await expect.poll(() => execution.releasedFrames()).toHaveLength(1)
    const observation = await work.collect(caller, [receipt.children[0]], { timeoutSeconds: 0 })
    await work.stopSession(caller.session)
    expect(observation[0].status).toBe('awaiting_user')
    // The published collect schema accepts the waiting-on-user result the
    // facade just produced. The contract object carries descriptive annotation
    // keys that JSON Schema does not define, so compile in non-strict mode.
    const validate = new Ajv2020({ strict: false }).compile(COLLECT_AGENT_CONTRACT.returns)
    expect(validate(observation), JSON.stringify(validate.errors)).toBe(true)
  })

  it('keeps running and finished collect results valid against the host collect contract', async () => {
    const { execution, records } = fixture()
    const work = createDurableDelegatedWork({ execution, records })
    const receipt = await work.delegate(
      caller,
      [
        { task: 'Finish', name: 'Finished' },
        { task: 'Keep going', name: 'Running' }
      ],
      { wait: false }
    )
    await expect.poll(() => execution.controls()).toHaveLength(2)
    execution.controls()[0].complete('Finished result')
    await expect.poll(() => execution.releasedFrames()).toHaveLength(1)
    const observation = await work.collect(caller, [...receipt.children], { timeoutSeconds: 0 })
    await work.stopSession(caller.session)
    expect(observation).toMatchObject([
      { status: 'completed', response: 'Finished result' },
      { status: 'running' }
    ])
    const validate = new Ajv2020({ strict: false }).compile(COLLECT_AGENT_CONTRACT.returns)
    expect(validate(observation), JSON.stringify(validate.errors)).toBe(true)
  })
})

describe('Stop fences in-flight admission while still admitting new work', () => {
  it.each([
    ['stopSession', 'model'],
    ['stopActiveBranch', 'model'],
    ['stopSession', 'reservation'],
    ['stopActiveBranch', 'reservation']
  ] as const)('%s invalidates a request paused in %s, then a later request still runs', async (stop, boundary) => {
    const { execution, records } = fixture(1)
    const release = vi.fn(async () => undefined)
    const claim = vi.fn()
    const entered = gate()
    const resume = gate()
    const pause = async (): Promise<void> => {
      entered.release()
      await resume.promise
    }
    const work = createDurableDelegatedWork({
      execution: {
        ...execution,
        async reserve(count) {
          const reservation = await execution.reserve(count)
          if (boundary === 'reservation') await pause()
          return reservation
        }
      },
      records,
      resolveExecutionModel: async () => {
        if (boundary === 'model') await pause()
        return { snapshot: TEST_EXECUTION_MODEL, backendLease: { claim, release } }
      }
    })
    const admission = work
      .delegate(caller, { task: 'Late task', name: 'Late' }, { wait: false })
      .then(
        (value) => ({ value }),
        (error) => ({ error })
      )
    await entered.promise
    expect(await work[stop](caller.session)).toEqual([])
    resume.release()
    const result = await admission
    if ('value' in result) await expect.poll(() => execution.controls()).toHaveLength(1)
    const executionCount = execution.controls().length
    const admitted = (await records.snapshot()).records
    await work.stopSession(caller.session)
    expect.soft(result).toMatchObject({ error: { code: 'conflict' } })
    expect.soft(admitted).toHaveLength(0)
    expect.soft(executionCount, 'execution must not start after Stop returns').toBe(0)
    expect(release).toHaveBeenCalledOnce()
    expect(claim).not.toHaveBeenCalled()
    // A request issued after Stop has returned is still admitted normally.
    const next = await work.delegate(
      { ...caller, toolInvocationId: 'after-stop' },
      { task: 'New task', name: 'New' },
      { wait: false }
    )
    expect(next.kind).toBe('receipts')
    await expect.poll(() => execution.controls().length).toBe(executionCount + 1)
    expect(execution.controls().at(-1)!.input.frameId).toBe(next.children[0].frameId)
    await work.stopSession(caller.session)
  })

  it('refuses a request made while a session stop is still in progress', async () => {
    const { execution, records } = fixture()
    const cleanup = gate()
    const work = createDurableDelegatedWork({
      execution,
      records,
      settleAttemptCleanup: async () => cleanup.promise
    })
    const running = await work.delegate(
      caller,
      { task: 'Running task', name: 'Running' },
      { wait: false }
    )
    await expect.poll(() => execution.controls()).toHaveLength(1)
    const stopping = work.stopSession(caller.session)
    const during = work
      .delegate(
        { ...caller, toolInvocationId: 'during-stop' },
        { task: 'Too late', name: 'Too late' },
        { wait: false }
      )
      .then(
        (value) => ({ value }),
        (error) => ({ error })
      )
    cleanup.release()
    await expect(stopping).resolves.toEqual([
      { frameId: running.children[0].frameId, status: 'cancelled' }
    ])
    expect(await during).toMatchObject({ error: { code: 'conflict' } })
    expect((await records.snapshot()).records).toHaveLength(1)
    expect(execution.controls()).toHaveLength(1)
  })

  it.each(['stopSession', 'stopActiveBranch'] as const)(
    '%s refuses or stops a request paused at its last check before saving its child',
    async (stop) => {
      const { execution, records } = fixture(1)
      const entered = gate()
      const resume = gate()
      let checks = 0
      const work = createDurableDelegatedWork({
        execution,
        records,
        async assertTurnOpen() {
          if (++checks === 2) {
            entered.release()
            await resume.promise
          }
        }
      })
      const admission = work
        .delegate(caller, { task: 'Late', name: 'Late' }, { wait: false })
        .then(
          (value) => ({ value }),
          (error) => ({ error })
        )
      await entered.promise
      const stopping = work[stop](caller.session)
      resume.release()
      await stopping
      const result = await admission
      const stopped = await records.snapshot()
      const controls = execution.controls().length
      await work.stopSession(caller.session)
      expect(controls, 'execution must not start after Stop returns').toBe(0)
      expect(stopOutcomes).toContainEqual(stopOutcome(result, stopped))
      const reservation = await execution.reserve(1)
      await reservation.releaseAll()
    }
  )

  it.each(['stopSession', 'stopActiveBranch'] as const)(
    '%s stops a request that is saving its new child when Stop starts',
    async (stop) => {
      const { execution, records } = fixture(1)
      const entered = gate()
      const resume = gate()
      // Record reads that start while the save is held, so the save can wait for them.
      const readsDuringSave: Promise<unknown>[] = []
      let saving = false
      const work = createDurableDelegatedWork({
        execution,
        records: {
          ...records,
          snapshot() {
            const read = records.snapshot()
            if (saving) readsDuringSave.push(read)
            return read
          },
          async admitChildren(input: Parameters<typeof records.admitChildren>[0]) {
            saving = true
            entered.release()
            await resume.promise
            saving = false
            return records.admitChildren(input)
          }
        }
      })
      const admission = work
        .delegate(caller, { task: 'Saving task', name: 'Saving' }, { wait: false })
        .then(
          (value) => ({ value }),
          (error) => ({ error })
        )
      await entered.promise
      const stopping = work[stop](caller.session)
      // Any read Stop has already started finishes before the save does.
      await Promise.all(readsDuringSave)
      resume.release()
      await stopping
      const result = await admission
      const stopped = await records.snapshot()
      const controls = execution.controls().length
      await work.stopSession(caller.session)
      expect(controls, 'execution must not start after Stop returns').toBe(0)
      expect(stopOutcomes).toContainEqual(stopOutcome(result, stopped))
      const reservation = await execution.reserve(1)
      await reservation.releaseAll()
    }
  )
})

describe('failed continuation handoff cleans up fully', () => {
  it.each(['question', 'message', 'message-delivery'] as const)(
    'releases capacity and terminalizes a %s continuation after a post-commit read failure',
    async (path) => {
      const { execution, records } = fixture(1)
      let snapshotsUntilFailure = 0
      const snapshot = records.snapshot.bind(records)
      const faultyRecords = {
        ...records,
        async snapshot() {
          if (snapshotsUntilFailure > 0 && --snapshotsUntilFailure === 0) {
            throw new Error('post-commit snapshot unavailable')
          }
          return snapshot()
        },
        async confirmQuestion(input: Parameters<typeof records.confirmQuestion>[0]) {
          const result = await records.confirmQuestion(input)
          snapshotsUntilFailure = path === 'message-delivery' ? 2 : 1
          return result
        },
        async continueChild(input: Parameters<typeof records.continueChild>[0]) {
          const result = await records.continueChild(input)
          snapshotsUntilFailure = path === 'message-delivery' ? 2 : 1
          return result
        }
      }
      const work = createDurableDelegatedWork({ execution, records: faultyRecords })
      await work.delegate(caller, { task: 'Original task', name: 'Original' }, { wait: false })
      await expect.poll(() => execution.controls()).toHaveLength(1)
      if (path === 'question') await ask(work, execution.controls()[0])
      execution.controls()[0].complete('Waiting for your answer')
      await expect.poll(() => execution.releasedFrames()).toHaveLength(1)
      const result = await (
        path === 'question'
          ? work.confirmQuestion(caller.session, {
              requestId: 'reported-question',
              answers: [{ questionIndex: 0, value: 'Strict' }]
            })
          : work.sendMessage(
              { ...caller, toolInvocationId: 'continue-message' },
              execution.controls()[0].input.frameId,
              'Strict'
            )
      ).then(
        (value) => ({ value }),
        (error) => ({ error })
      )
      expect(result).toMatchObject({ error: { message: 'post-commit snapshot unavailable' } })
      const saved = await records.snapshot()
      // A continuation Attempt was recorded; it must not linger as 'running'.
      expect(saved.records[0].attempts).toHaveLength(2)
      expect(execution.controls()).toHaveLength(1)
      if (path === 'question')
        // An already-confirmed answer survives the failed handoff intact.
        expect(saved.questionRequests[0]).toMatchObject({
          status: 'confirmed',
          answers: [{ questionIndex: 0, value: 'Strict' }]
        })
      expect.soft(saved.records[0].attempts[1].status).toBe('error')
      if (path !== 'question')
        expect.soft(saved.messageCommands[0].receipt).toMatchObject({ status: 'failed' })
      // The reserved capacity slot was released: a fresh reservation succeeds.
      const reserved = await execution.reserve(1).then(
        async (reservation) => {
          await reservation.releaseAll()
          return true
        },
        () => false
      )
      expect.soft(reserved, 'the unlaunched continuation must release its capacity').toBe(true)
      await work.recoverInterrupted()
      await work.recoverInterrupted()
      expect(execution.controls()).toHaveLength(1)
    }
  )

  it.each(['question', 'message'] as const)(
    '%s continuation releases capacity on both commit and runtime-start failures',
    async (path) => {
      const { execution, records } = fixture(1)
      let failCommit = true
      let failRun = false
      const work = createDurableDelegatedWork({
        execution: {
          ...execution,
          run(input, slotId) {
            if (failRun) throw new Error('runtime start failed')
            return execution.run(input, slotId)
          }
        },
        records: {
          ...records,
          async confirmQuestion(input) {
            if (failCommit) throw new Error('commit failed')
            return records.confirmQuestion(input)
          },
          async continueChild(input) {
            if (failCommit) throw new Error('commit failed')
            return records.continueChild(input)
          }
        }
      })
      await work.delegate(caller, { task: 'Source', name: 'Source' }, { wait: false })
      await expect.poll(() => execution.controls()).toHaveLength(1)
      if (path === 'question') await ask(work, execution.controls()[0])
      execution.controls()[0].complete('Source response')
      await expect.poll(() => execution.releasedFrames()).toHaveLength(1)
      const continueWork = (): Promise<unknown> =>
        path === 'question'
          ? work.confirmQuestion(caller.session, {
              requestId: 'reported-question',
              answers: [{ questionIndex: 0, value: 'Strict' }]
            })
          : work.sendMessage(
              { ...caller, toolInvocationId: 'fault-continuation' },
              execution.controls()[0].input.frameId,
              'Strict'
            )
      // Commit itself fails: nothing new is recorded, the question stays open, the slot frees.
      const beforeCommit = await records.snapshot()
      await expect(continueWork()).rejects.toThrow()
      const afterCommit = await records.snapshot()
      expect(afterCommit.records[0].attempts).toHaveLength(1)
      expect(afterCommit.messageCommands).toHaveLength(beforeCommit.messageCommands.length)
      expect(afterCommit.messages).toHaveLength(beforeCommit.messages.length)
      if (path === 'question') expect(afterCommit.questionRequests[0].status).toBe('pending')
      const reservation = await execution.reserve(1)
      await reservation.releaseAll()
      // Commit succeeds but the runtime start throws: the recorded Attempt is
      // terminalized to error and the slot is released; the answer survives.
      // The call itself may resolve or reject here.
      failCommit = false
      failRun = true
      await continueWork().catch(() => undefined)
      await expect
        .poll(async () => (await records.snapshot()).records[0].attempts[1].status)
        .toBe('error')
      await expect
        .poll(async () =>
          execution.reserve(1).then(
            async (slot) => {
              await slot.releaseAll()
              return true
            },
            () => false
          )
        )
        .toBe(true)
      if (path === 'question')
        expect((await records.snapshot()).questionRequests[0]).toMatchObject({
          status: 'confirmed',
          answers: [{ questionIndex: 0, value: 'Strict' }]
        })
      await work.recoverInterrupted()
      await work.recoverInterrupted()
      expect(execution.controls()).toHaveLength(1)
    }
  )
})

describe('partial failure during parallel input resolution leaks no lease', () => {
  let root: string | undefined
  afterEach(async () => {
    if (root) await rm(root, { recursive: true, force: true })
    root = undefined
  })

  it.each(['before failure', 'after failure'] as const)(
    'closes a lease resolved %s when another input fails',
    async (timing) => {
      root = await mkdtemp(join(tmpdir(), 'delegated-workspace-lease-'))
      const input = join(root, 'input.csv')
      await writeFile(input, 'value\n1\n')
      const close = vi.fn(async () => undefined)
      let release!: () => void
      const delayed = new Promise<void>((resolve) => {
        release = resolve
      })
      let rejected!: () => void
      const rejection = new Promise<void>((resolve) => {
        rejected = resolve
      })
      const workspace = createProductionFrameWorkspace({
        root: join(root, 'workspaces'),
        async resolveInput(identity) {
          if (identity === 'upload-version:broken') {
            rejected()
            throw new Error('input resolution failed')
          }
          if (timing === 'after failure') await delayed
          return { path: input, close }
        }
      })
      const preparation = workspace
        .prepare({ projectId: 'project-1', sessionId: 'session-1' }, 'frame-1', [
          'upload-version:valid',
          'upload-version:broken'
        ])
        .then(
          (value) => ({ value }),
          (error) => ({ error })
        )
      await rejection
      // Let the immediate rejection surface before the sibling resolver finishes.
      await new Promise<void>((resolve) => setImmediate(resolve))
      release()
      expect(await preparation).toMatchObject({ error: { message: 'input resolution failed' } })
      // Even the lease that resolved after the rejection is closed.
      expect(close).toHaveBeenCalledOnce()
    }
  )

  it('closes each lease that resolves before or after a failing sibling', async () => {
    root = await mkdtemp(join(tmpdir(), 'delegated-workspace-mixed-'))
    const input = join(root, 'input.csv')
    await writeFile(input, 'value\n1\n')
    const closes = { early: vi.fn(async () => undefined), late: vi.fn(async () => undefined) }
    let release!: () => void
    const delayed = new Promise<void>((resolve) => {
      release = resolve
    })
    let rejected!: () => void
    const rejection = new Promise<void>((resolve) => {
      rejected = resolve
    })
    const workspace = createProductionFrameWorkspace({
      root: join(root, 'workspaces'),
      async resolveInput(identity) {
        if (identity === 'upload-version:broken') {
          await Promise.resolve()
          rejected()
          throw new Error('input resolution failed')
        }
        if (identity === 'upload-version:late') {
          await delayed
          return { path: input, close: closes.late }
        }
        return { path: input, close: closes.early }
      }
    })
    const preparation = workspace
      .prepare({ projectId: 'project-1', sessionId: 'session-1' }, 'frame-1', [
        'upload-version:early',
        'upload-version:broken',
        'upload-version:late'
      ])
      .then(
        (value) => ({ value }),
        (error) => ({ error })
      )
    await rejection
    await new Promise<void>((resolve) => setImmediate(resolve))
    release()
    expect(await preparation).toMatchObject({ error: { message: 'input resolution failed' } })
    expect(closes.early).toHaveBeenCalledOnce()
    expect(closes.late).toHaveBeenCalledOnce()
  })

  it('closes every resolved lease exactly once when staging fails', async () => {
    root = await mkdtemp(join(tmpdir(), 'delegated-workspace-copy-'))
    const closes = [vi.fn(async () => undefined), vi.fn(async () => undefined)]
    const workspace = createProductionFrameWorkspace({
      root: join(root, 'workspaces'),
      async resolveInput(identity) {
        return {
          path: join(root!, 'input.csv'),
          close: closes[identity === 'upload-version:first' ? 0 : 1],
          copyTo: async () => {
            throw new Error('copy failed')
          }
        }
      }
    })
    await expect(
      workspace.prepare({ projectId: 'project-1', sessionId: 'session-1' }, 'frame-1', [
        'upload-version:first',
        'upload-version:second'
      ])
    ).rejects.toThrow('copy failed')
    for (const close of closes) expect(close).toHaveBeenCalledOnce()
  })
})
