#!/usr/bin/env bash
# test-setup.sh - runs (sourced) once before the verifier.
#
# The verifier runs jest files under jsdom in superset-frontend. Node 24, the
# frontend node_modules and the jest binary are baked into the image, so this
# script only checks that the frontend workspace is intact and reinstalls if
# node_modules got corrupted.
#
# The solve phase is offline, and the test phase can reach only the model
# gateway. Nothing here needs the public network on a healthy image.

set -e
set -o pipefail

FE=/repo/superset/superset-frontend
cd "$FE"

# The jest binary must resolve from the frontend workspace root. A miss means
# node_modules is corrupt - reinstall now rather than failing later with a
# confusing "command not found". npm ci installs the exact locked versions, so
# this is deterministic even on a network-free container (the cache is warm).
if ! [ -x node_modules/.bin/jest ]; then
    echo "test-setup.sh: jest binary missing from node_modules/.bin/. " \
         "Image node_modules looks corrupt - reinstalling (offline-first)." >&2
    # Offline-first: the image bakes the npm cache warm, so prefer a cache-only
    # install and only fall back to an online fetch (logged) if the cache is cold.
    if ! npm ci --no-audit --no-fund --offline; then
        echo "test-setup.sh: offline npm ci failed (cache cold?) - " \
             "falling back to an online npm ci." >&2
        npm ci --no-audit --no-fund
    fi
fi

echo "test-setup.sh: ready. FE=$FE node=$(node -v) jest=$(node_modules/.bin/jest --version 2>/dev/null || echo unknown)"
