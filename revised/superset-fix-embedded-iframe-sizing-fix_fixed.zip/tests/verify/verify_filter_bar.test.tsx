// @ts-nocheck
/**
 * Behavioral checks for the vertical filter bar's own layout.
 *
 * The bar is the existing VerticalFilterBar component. These render it with
 * the dashboard's embed check (isEmbedded) stubbed true and false and read the
 * style rules it emits through @emotion/jest's toHaveStyleRule. Outside an
 * embed the bar fills its column as it does today. Inside an embed it does not
 * stretch to fill its column, so the Apply and Clear buttons can sit right
 * under the filter list. The heavy filter children are mocked so the render
 * stays on the bar's own styling.
 */
import { render } from 'spec/helpers/testing-library';

// isEmbedded is the dashboard's existing check for running inside a frame;
// stubbing it picks the embedded or the standalone layout for each render.
jest.mock('src/dashboard/util/isEmbedded', () => ({
  isEmbedded: jest.fn(() => false),
}));

// Keep the render focused on the bar's own container styling: the filter list,
// header, and cross/url filter subtrees are unrelated to the layout contract and
// pull in large dependency graphs.
jest.mock(
  'src/dashboard/components/nativeFilters/FilterBar/Header',
  () => ({
    __esModule: true,
    default: () => null,
  }),
);
jest.mock(
  'src/dashboard/components/nativeFilters/FilterBar/FilterControls/FilterControls',
  () => ({
    __esModule: true,
    default: () => <div data-test="mock-filter-controls" />,
  }),
);
jest.mock(
  'src/dashboard/components/nativeFilters/FilterBar/CrossFilters/Vertical',
  () => ({
    __esModule: true,
    default: () => null,
  }),
);
jest.mock(
  'src/dashboard/components/nativeFilters/FilterBar/UrlFilters/Vertical',
  () => ({
    __esModule: true,
    default: () => null,
  }),
);

// eslint-disable-next-line import/first
import { stateWithoutNativeFilters } from 'spec/fixtures/mockStore';
// eslint-disable-next-line import/first
import { isEmbedded } from 'src/dashboard/util/isEmbedded';
// eslint-disable-next-line import/first
import VerticalFilterBar from 'src/dashboard/components/nativeFilters/FilterBar/Vertical';

// The complete dashboard fixture the repo's own FilterBar tests use. It carries
// the redux-undo { past, present, future } layout and the slice, datasource
// and dataMask state the store reducers expect, so a live store built from it
// renders cleanly.
const initialState = stateWithoutNativeFilters;

const baseProps = {
  actions: null,
  canEdit: true,
  dataMaskSelected: {},
  filtersOpen: true,
  // One native filter so the initialized bar renders its filter-list wrapper.
  filterValues: [{ id: 'f1', name: 'Filter 1' }],
  chartCustomizationValues: [],
  height: 900,
  isInitialized: true,
  offset: 0,
  onSelectionChange: jest.fn(),
  onPendingCustomizationDataMaskChange: jest.fn(),
  toggleFiltersBar: jest.fn(),
  width: 320,
  mobileMode: false,
};

const renderBar = (overrides = {}) =>
  render(<VerticalFilterBar {...baseProps} {...overrides} />, {
    useRedux: true,
    useRouter: true,
    useTheme: true,
    initialState,
  });

// The open bar is the `.open` descendant of the wrapper that carries
// data-test="filter-bar". It is found by structure, not by any embed-only
// class name.
const openBar = (container: HTMLElement) =>
  container.querySelector('[data-test="filter-bar"] .open');

afterEach(() => {
  (isEmbedded as jest.Mock).mockReturnValue(false);
  jest.clearAllMocks();
});

describe('vertical filter bar layout', () => {
  // Outside an embed the open bar still fills its column.
  test('standalone bar keeps its full-height sizing', () => {
    (isEmbedded as jest.Mock).mockReturnValue(false);

    const { container } = renderBar();
    const bar = openBar(container);

    expect(bar).toBeTruthy();
    expect(bar).toHaveStyleRule('min-height', '100%');
  });

  // Inside an embed the open bar does not stretch to fill its column, so it
  // ends where its content ends.
  test('embedded bar does not stretch to fill its column', () => {
    (isEmbedded as jest.Mock).mockReturnValue(true);

    const { container } = renderBar();
    const bar = openBar(container);

    expect(bar).toBeTruthy();
    expect(bar).not.toHaveStyleRule('min-height', '100%');
  });
});
