// @ts-nocheck
/**
 * Behavioral checks for the vertical filter bar's own layout.
 *
 * The bar is the existing VerticalFilterBar component. These render it with
 * the dashboard's embed check (isEmbedded) stubbed true and false and read the
 * styles its elements end up with through jsdom's getComputedStyle, which
 * applies inline styles and every stylesheet on the page, emotion's included.
 * Outside an embed the bar fills its column as it does today. Inside an embed
 * neither the bar nor anything around the Apply and Clear buttons holds a
 * height of its own, so the buttons follow the filter list. The list height
 * the builder passes is checked with the builder in verify_builder.test.tsx.
 * The heavy filter children are mocked so the render stays on the bar's own
 * styling.
 */
import { render } from 'spec/helpers/testing-library';

// The app build compiles JSX with emotion's runtime, so a `css` prop on a plain
// element becomes a style rule. Jest's babel config uses React's runtime, which
// would leave it as a dead attribute. Route JSX through emotion's jsx here so
// the page renders with the styles the app would give it.
jest.mock('react/jsx-runtime', () => {
  const runtime = jest.requireActual('react/jsx-runtime');
  const { jsx: emotionJsx } = jest.requireActual('@emotion/react');
  const withCss = (type, props, key) => {
    if (!props || props.css === undefined) return runtime.jsx(type, props, key);
    const { children, ...rest } = props;
    const childList =
      children === undefined ? [] : [].concat(children);
    return emotionJsx(
      type,
      key === undefined ? rest : { ...rest, key },
      ...childList,
    );
  };
  return { ...runtime, jsx: withCss, jsxs: withCss };
});

// isEmbedded is the dashboard's existing check for running inside a frame;
// stubbing it picks the embedded or the standalone layout for each render.
jest.mock('src/dashboard/util/isEmbedded', () => ({
  isEmbedded: jest.fn(() => false),
}));

// Keep the render focused on the bar's own container styling: the filter list,
// header, and cross/url filter subtrees are unrelated to the layout contract and
// pull in large dependency graphs.
jest.mock(
  'src/dashboard/components/nativeFilters/FilterBar/Header',
  () => ({
    __esModule: true,
    default: () => null,
  }),
);
jest.mock(
  'src/dashboard/components/nativeFilters/FilterBar/FilterControls/FilterControls',
  () => ({
    __esModule: true,
    default: () => <div data-test="mock-filter-controls" />,
  }),
);
jest.mock(
  'src/dashboard/components/nativeFilters/FilterBar/CrossFilters/Vertical',
  () => ({
    __esModule: true,
    default: () => null,
  }),
);
jest.mock(
  'src/dashboard/components/nativeFilters/FilterBar/UrlFilters/Vertical',
  () => ({
    __esModule: true,
    default: () => null,
  }),
);

// eslint-disable-next-line import/first
import { stateWithoutNativeFilters } from 'spec/fixtures/mockStore';
// eslint-disable-next-line import/first
import { isEmbedded } from 'src/dashboard/util/isEmbedded';
// eslint-disable-next-line import/first
import VerticalFilterBar from 'src/dashboard/components/nativeFilters/FilterBar/Vertical';

// The complete dashboard fixture the repo's own FilterBar tests use. It carries
// the redux-undo { past, present, future } layout and the slice, datasource
// and dataMask state the store reducers expect, so a live store built from it
// renders cleanly.
const initialState = stateWithoutNativeFilters;

const baseProps = {
  actions: <div data-test="mock-filter-actions" />,
  canEdit: true,
  dataMaskSelected: {},
  filtersOpen: true,
  // One native filter so the initialized bar renders its filter-list wrapper.
  filterValues: [{ id: 'f1', name: 'Filter 1' }],
  chartCustomizationValues: [],
  height: 900,
  isInitialized: true,
  offset: 0,
  onSelectionChange: jest.fn(),
  onPendingCustomizationDataMaskChange: jest.fn(),
  toggleFiltersBar: jest.fn(),
  width: 320,
  mobileMode: false,
};

const renderBar = (overrides = {}) =>
  render(<VerticalFilterBar {...baseProps} {...overrides} />, {
    useRedux: true,
    useRouter: true,
    useTheme: true,
    initialState,
  });

const styleOf = (el: Element, property: string) =>
  window.getComputedStyle(el).getPropertyValue(property).trim();

// Values that leave an element's height to its content.
const CONTENT_SIZED = [
  '',
  'auto',
  'none',
  '0',
  '0px',
  'initial',
  'unset',
  'fit-content',
  'max-content',
  'min-content',
];

// A height or min-height of its own: a length, a percentage or a viewport
// unit, any of which can hold the element taller than what it contains.
const holdsAHeight = (el: Element) =>
  !CONTENT_SIZED.includes(styleOf(el, 'height')) ||
  !CONTENT_SIZED.includes(styleOf(el, 'min-height'));

// The bar wrapper and every element between it and the Apply and Clear
// buttons.
const barAroundButtons = (container: HTMLElement) => {
  const bar = container.querySelector('[data-test="filter-bar"]');
  const buttons = container.querySelector('[data-test="mock-filter-actions"]');
  expect(bar).toBeTruthy();
  expect(buttons).toBeTruthy();
  const out: Element[] = [];
  for (let node = buttons.parentElement; node; node = node.parentElement) {
    out.push(node);
    if (node === bar) break;
  }
  return out;
};

afterEach(() => {
  (isEmbedded as jest.Mock).mockReturnValue(false);
  jest.clearAllMocks();
});

describe('vertical filter bar layout', () => {
  // Outside an embed the open bar still fills its column.
  test('standalone bar keeps its full-height sizing', () => {
    (isEmbedded as jest.Mock).mockReturnValue(false);

    const { container } = renderBar();

    expect(barAroundButtons(container).some(holdsAHeight)).toBe(true);
  });

  // Inside an embed the open bar does not stretch to fill its column or take
  // a fixed height, so it ends where its content ends.
  test('embedded bar does not stretch to fill its column', () => {
    (isEmbedded as jest.Mock).mockReturnValue(true);

    const { container } = renderBar();
    const held = barAroundButtons(container).filter(holdsAHeight);

    expect(
      held.map(el => `${styleOf(el, 'height')} / ${styleOf(el, 'min-height')}`),
    ).toEqual([]);
  });
});
