// @ts-nocheck
/**
 * Behavioral checks for the dashboard page layout inside and outside an embed.
 *
 * These render the existing DashboardBuilder and read the style rules its
 * pieces emit through @emotion/jest's toHaveStyleRule, the same interface the
 * repo's own DashboardBuilder.test.tsx uses for the header width.
 *
 *  - The header (data-test="dashboard-header-wrapper") is not capped by a
 *    viewport width and still stays inside its column.
 *  - The vertical filter bar is checked with the layout the builder hands it:
 *    the filter bar entry point is mocked as a recorder, and the real bar is
 *    then rendered with the props the builder passed. In an embed nothing in
 *    the open bar takes its height from the viewport, loaded or still loading.
 *    Outside an embed the filter list keeps its viewport-based height.
 *  - With version history turned on, none of the page's top-level columns
 *    takes its height from the viewport in an embed.
 *
 * isEmbedded, the dashboard's existing check for running inside a frame, is
 * stubbed true, and false for the standalone case. jsdom's window is never
 * inside a frame, so the real check would always say no.
 */
import { mockAntdWithDesktopBreakpoint } from 'spec/helpers/mobileTestUtils';
import fetchMock from 'fetch-mock';
import { render } from 'spec/helpers/testing-library';

fetchMock.get('glob:*/csstemplateasyncmodelview/api/read', {});
fetchMock.put('glob:*/api/v1/dashboard/*', {});
fetchMock.post('glob:*/log/?*', {});

// Keep the breakpoint desktop so the header renders in its normal (non-mobile)
// form, matching the repo's own DashboardBuilder tests.
jest.mock('antd', () => mockAntdWithDesktopBreakpoint());

jest.mock('src/dashboard/util/isEmbedded', () => ({
  isEmbedded: jest.fn(() => true),
}));

jest.mock('src/dashboard/actions/dashboardState', () => ({
  ...jest.requireActual('src/dashboard/actions/dashboardState'),
  fetchFaveStar: jest.fn(),
  setActiveTab: jest.fn(),
  setDirectPathToChild: jest.fn(),
}));
jest.mock('src/components/ResizableSidebar/useStoredSidebarWidth');

// Mock the dependent subtrees the page does not need, matching the repo's own
// DashboardBuilder test, so the render stays focused and free of prop warnings.
jest.mock('@superset-ui/core/components/Select/Select', () => {
  const MockSelect = () => <div data-test="mock-select" />;
  MockSelect.displayName = 'MockSelect';
  return MockSelect;
});
jest.mock('@superset-ui/core/components/Select/AsyncSelect', () => {
  const MockAsyncSelect = () => <div data-test="mock-async-select" />;
  MockAsyncSelect.displayName = 'MockAsyncSelect';
  return MockAsyncSelect;
});
jest.mock('@superset-ui/core/components/PageHeaderWithActions', () => {
  const MockPageHeaderWithActions = () => (
    <div data-test="mock-page-header-with-actions" />
  );
  MockPageHeaderWithActions.displayName = 'MockPageHeaderWithActions';
  return {
    PageHeaderWithActions: MockPageHeaderWithActions,
  };
});
jest.mock(
  'src/dashboard/components/nativeFilters/FiltersConfigModal/FiltersConfigModal',
  () => {
    const MockFiltersConfigModal = () => (
      <div data-test="mock-filters-config-modal" />
    );
    MockFiltersConfigModal.displayName = 'MockFiltersConfigModal';
    return MockFiltersConfigModal;
  },
);
jest.mock('src/dashboard/components/BuilderComponentPane', () => {
  const MockBuilderComponentPane = () => (
    <div data-test="mock-builder-component-pane" />
  );
  MockBuilderComponentPane.displayName = 'MockBuilderComponentPane';
  return MockBuilderComponentPane;
});
// The filter bar entry point records the props the builder passes, so the
// real bar can be rendered with them.
jest.mock('src/dashboard/components/nativeFilters/FilterBar', () => {
  const MockFilterBar = jest.fn(() => <div data-test="mock-filter-bar" />);
  MockFilterBar.displayName = 'MockFilterBar';
  return MockFilterBar;
});
jest.mock('src/dashboard/containers/DashboardGrid', () => {
  const MockDashboardGrid = () => <div data-test="mock-dashboard-grid" />;
  MockDashboardGrid.displayName = 'MockDashboardGrid';
  return MockDashboardGrid;
});
jest.mock('src/dashboard/components/Header/HeadlessAutoRefresh', () => {
  const MockHeadlessAutoRefresh = () => (
    <div data-test="mock-headless-auto-refresh" />
  );
  MockHeadlessAutoRefresh.displayName = 'MockHeadlessAutoRefresh';
  return MockHeadlessAutoRefresh;
});
jest.mock('src/hooks/useIsMobile', () => ({
  ...jest.requireActual('src/hooks/useIsMobile'),
  useIsMobile: jest.fn().mockReturnValue(false),
}));
// Lazy-loaded behind the VersionHistory flag. Visible stand-ins keep the
// render free of their fetches.
jest.mock('src/features/versionHistory/DashboardVersionHistory', () => {
  const MockDashboardVersionHistory = () => (
    <div data-test="mock-dashboard-version-history" />
  );
  MockDashboardVersionHistory.displayName = 'MockDashboardVersionHistory';
  return { __esModule: true, default: MockDashboardVersionHistory };
});
jest.mock('src/features/versionHistory/PreviewBanner', () => {
  const MockPreviewBanner = () => null;
  MockPreviewBanner.displayName = 'MockPreviewBanner';
  return { __esModule: true, default: MockPreviewBanner };
});
// The bar's own heavy children, mocked as in the repo's FilterBar tests so the
// real bar renders on its own styling.
jest.mock(
  'src/dashboard/components/nativeFilters/FilterBar/Header',
  () => ({
    __esModule: true,
    default: () => null,
  }),
);
jest.mock(
  'src/dashboard/components/nativeFilters/FilterBar/FilterControls/FilterControls',
  () => ({
    __esModule: true,
    default: () => <div data-test="mock-filter-controls" />,
  }),
);
jest.mock(
  'src/dashboard/components/nativeFilters/FilterBar/CrossFilters/Vertical',
  () => ({
    __esModule: true,
    default: () => null,
  }),
);
jest.mock(
  'src/dashboard/components/nativeFilters/FilterBar/UrlFilters/Vertical',
  () => ({
    __esModule: true,
    default: () => null,
  }),
);

// eslint-disable-next-line import/first
import { FeatureFlag } from '@superset-ui/core';
// eslint-disable-next-line import/first
import DashboardBuilder from 'src/dashboard/components/DashboardBuilder/DashboardBuilder';
// eslint-disable-next-line import/first
import VerticalFilterBar from 'src/dashboard/components/nativeFilters/FilterBar/Vertical';
// eslint-disable-next-line import/first
import useStoredSidebarWidth from 'src/components/ResizableSidebar/useStoredSidebarWidth';
// eslint-disable-next-line import/first
import {
  fetchFaveStar,
  setActiveTab,
} from 'src/dashboard/actions/dashboardState';
// eslint-disable-next-line import/first
import { isEmbedded } from 'src/dashboard/util/isEmbedded';
// eslint-disable-next-line import/first
import { dashboardLayout as undoableDashboardLayout } from 'spec/fixtures/mockDashboardLayout';
// eslint-disable-next-line import/first
import {
  storeWithState,
  stateWithoutNativeFilters,
} from 'spec/fixtures/mockStore';
// eslint-disable-next-line import/first
import mockState from 'spec/fixtures/mockState';
// eslint-disable-next-line import/first
import * as useNativeFiltersModule from 'src/dashboard/components/DashboardBuilder/state';

const FilterBarMock = jest.requireMock(
  'src/dashboard/components/nativeFilters/FilterBar',
);

let nativeFiltersSpy;

beforeAll(() => {
  (fetchFaveStar as jest.Mock).mockReturnValue({ type: 'mock-action' });
  (setActiveTab as jest.Mock).mockReturnValue({ type: 'mock-action' });
  (useStoredSidebarWidth as jest.Mock).mockImplementation(() => [100, jest.fn()]);
});

afterEach(() => {
  nativeFiltersSpy?.mockRestore();
  nativeFiltersSpy = undefined;
  (isEmbedded as jest.Mock).mockReturnValue(true);
  FilterBarMock.mockClear();
  window.featureFlags = {};
});

afterAll(() => {
  (fetchFaveStar as jest.Mock).mockReset();
  (setActiveTab as jest.Mock).mockReset();
  (useStoredSidebarWidth as jest.Mock).mockReset();
});

// Render with the vertical filter bar open, the configuration the overflow
// and the button problem were reported in. The spy stays in place until the
// test ends, so later renders see the same filter state.
const renderBuilder = () => {
  nativeFiltersSpy = jest
    .spyOn(useNativeFiltersModule, 'useNativeFilters')
    .mockReturnValue({
      showDashboard: true,
      missingInitialFilters: [],
      dashboardFiltersOpen: true,
      toggleDashboardFiltersOpen: jest.fn(),
      nativeFiltersEnabled: true,
      hasFilters: true,
    });
  const result = render(<DashboardBuilder />, {
    useRedux: true,
    store: storeWithState({
      ...mockState,
      dashboardLayout: undoableDashboardLayout,
    }),
    useDnd: true,
    useRouter: true,
    useTheme: true,
  });
  return result;
};

// The vertical layout the builder passed to the filter bar on its last render.
const verticalConfigFromBuilder = () => {
  const calls = FilterBarMock.mock.calls.filter(
    ([props]) => props?.verticalConfig,
  );
  return calls.length ? calls[calls.length - 1][0].verticalConfig : undefined;
};

// The real bar with the builder's vertical layout, passed on prop for prop the
// way the filter bar entry point passes it.
const renderBarAsBuilderSetsIt = (
  verticalConfig,
  { isInitialized }: { isInitialized: boolean },
) =>
  render(
    <VerticalFilterBar
      actions={<div data-test="mock-filter-actions" />}
      canEdit
      dataMaskSelected={{}}
      filterValues={[{ id: 'f1', name: 'Filter 1' }]}
      chartCustomizationValues={[]}
      isInitialized={isInitialized}
      onSelectionChange={jest.fn()}
      onPendingCustomizationDataMaskChange={jest.fn()}
      filtersOpen={verticalConfig.filtersOpen}
      toggleFiltersBar={verticalConfig.toggleFiltersBar}
      width={verticalConfig.width}
      height={verticalConfig.height}
      offset={verticalConfig.offset}
      mobileMode={Boolean(verticalConfig.mobileMode)}
    />,
    {
      useRedux: true,
      useRouter: true,
      useTheme: true,
      initialState: stateWithoutNativeFilters,
    },
  );

// Only HTML elements with a class or a style attribute can carry a height.
const styledElementsIn = (els: Element[]) =>
  els.filter(
    el =>
      el instanceof HTMLElement &&
      (el.getAttribute('class') || el.getAttribute('style')),
  );

const styledElementsUnder = (rootEl: Element) =>
  styledElementsIn([rootEl, ...Array.from(rootEl.querySelectorAll('*'))]);

const hasStyleRule = (el: Element, property: string, value: RegExp) => {
  try {
    expect(el).toHaveStyleRule(property, value);
    return true;
  } catch (e) {
    return false;
  }
};

// A height or min-height in viewport units, from an emotion rule or an inline
// style.
const takesViewportHeight = (el: HTMLElement) =>
  /vh/.test(el.style.height) ||
  /vh/.test(el.style.minHeight) ||
  hasStyleRule(el, 'height', /vh/) ||
  hasStyleRule(el, 'min-height', /vh/);

const describeElement = (el: HTMLElement) =>
  `<${el.tagName.toLowerCase()} class="${el.getAttribute('class') ?? ''}">`;

const expectNoViewportHeight = (els: HTMLElement[]) => {
  expect(els.filter(takesViewportHeight).map(describeElement)).toEqual([]);
};

const builtBar = ({ isInitialized }: { isInitialized: boolean }) => {
  renderBuilder();
  const verticalConfig = verticalConfigFromBuilder();
  expect(verticalConfig).toBeDefined();

  const { container } = renderBarAsBuilderSetsIt(verticalConfig, {
    isInitialized,
  });
  const bar = container.querySelector('[data-test="filter-bar"]');
  expect(bar).toBeTruthy();
  return bar;
};

describe('embedded dashboard page layout', () => {
  // The header's width cap is not a viewport width, and the header still stays
  // inside its column, with a cap of its own or a zero minimum width.
  test('header is not capped by a viewport-unit width in an embed', () => {
    const { getByTestId } = renderBuilder();

    const header = getByTestId('dashboard-header-wrapper');

    expect(header).not.toHaveStyleRule('max-width', /vw/);
    expect(
      hasStyleRule(header, 'max-width', /\S/) ||
        hasStyleRule(header, 'min-width', /^0(px)?$/),
    ).toBe(true);
  });

  // Nothing in the open bar takes its height from the viewport, and the filter
  // list and the Apply and Clear buttons are both still in it.
  test('open filter bar takes no height from the viewport in an embed', () => {
    const bar = builtBar({ isInitialized: true });

    expectNoViewportHeight(styledElementsUnder(bar));
    expect(bar.querySelector('[data-test="mock-filter-controls"]')).toBeTruthy();
    expect(bar.querySelector('[data-test="mock-filter-actions"]')).toBeTruthy();
  });

  test('filter bar still loading takes no height from the viewport in an embed', () => {
    const bar = builtBar({ isInitialized: false });

    expectNoViewportHeight(styledElementsUnder(bar));
    expect(bar.querySelector('[data-test="mock-filter-actions"]')).toBeTruthy();
  });

  // The standalone filter list keeps the viewport-based height it has today.
  test('open filter bar keeps its viewport-based list height outside an embed', () => {
    (isEmbedded as jest.Mock).mockReturnValue(false);

    const bar = builtBar({ isInitialized: true });

    expect(styledElementsUnder(bar).some(takesViewportHeight)).toBe(true);
  });

  // With version history on, none of the page's top-level columns takes its
  // height from the viewport.
  test('no top-level column takes its height from the viewport in an embed with version history on', () => {
    window.featureFlags = { [FeatureFlag.VersionHistory]: true };

    const { getByTestId } = renderBuilder();
    const page = getByTestId('dashboard-header-wrapper').parentElement;

    expect(page).toBeTruthy();
    expectNoViewportHeight(styledElementsIn(Array.from(page.children)));
  });
});
