// @ts-nocheck
/**
 * Behavioral checks for the dashboard page layout inside and outside an embed.
 *
 * These render the existing DashboardBuilder with its real filter bar entry
 * point and read the styles each element ends up with through jsdom's
 * getComputedStyle, which applies inline styles and every stylesheet on the
 * page, emotion's included.
 *
 *  - The header (data-test="dashboard-header-wrapper") is not capped by a
 *    viewport width and still has a real bound inside its column.
 *  - In an embed, nothing that stacks above the Apply and Clear buttons in the
 *    open vertical filter bar keeps a height of its own (a fixed length, a
 *    percentage, a viewport unit), whether the bar is still loading or has
 *    loaded its filters. The bar and its filter list end with their content.
 *  - Outside an embed the open bar still fills its column and its filter list
 *    still has a height bound, as it does today.
 *
 * isEmbedded, the dashboard's existing check for running inside a frame, is
 * stubbed true, and false for the standalone case. jsdom's window is never
 * inside a frame, so the real check would always say no.
 */
import { mockAntdWithDesktopBreakpoint } from 'spec/helpers/mobileTestUtils';
import fetchMock from 'fetch-mock';
import { render, waitFor } from 'spec/helpers/testing-library';

fetchMock.get('glob:*/csstemplateasyncmodelview/api/read', {});
fetchMock.put('glob:*/api/v1/dashboard/*', {});
fetchMock.post('glob:*/log/?*', {});

// The app build compiles JSX with emotion's runtime, so a `css` prop on a plain
// element becomes a style rule. Jest's babel config uses React's runtime, which
// would leave it as a dead attribute. Route JSX through emotion's jsx here so
// the page renders with the styles the app would give it.
jest.mock('react/jsx-runtime', () => {
  const runtime = jest.requireActual('react/jsx-runtime');
  const { jsx: emotionJsx } = jest.requireActual('@emotion/react');
  const withCss = (type, props, key) => {
    if (!props || props.css === undefined) return runtime.jsx(type, props, key);
    const { children, ...rest } = props;
    const childList =
      children === undefined ? [] : [].concat(children);
    return emotionJsx(
      type,
      key === undefined ? rest : { ...rest, key },
      ...childList,
    );
  };
  return { ...runtime, jsx: withCss, jsxs: withCss };
});

// Keep the breakpoint desktop so the header renders in its normal (non-mobile)
// form, matching the repo's own DashboardBuilder tests.
jest.mock('antd', () => mockAntdWithDesktopBreakpoint());

jest.mock('src/dashboard/util/isEmbedded', () => ({
  isEmbedded: jest.fn(() => true),
}));

jest.mock('src/dashboard/actions/dashboardState', () => ({
  ...jest.requireActual('src/dashboard/actions/dashboardState'),
  fetchFaveStar: jest.fn(),
  setActiveTab: jest.fn(),
  setDirectPathToChild: jest.fn(),
}));
jest.mock('src/components/ResizableSidebar/useStoredSidebarWidth');

// Mock the dependent subtrees the page does not need, matching the repo's own
// DashboardBuilder test, so the render stays focused and free of prop warnings.
jest.mock('@superset-ui/core/components/Select/Select', () => {
  const MockSelect = () => <div data-test="mock-select" />;
  MockSelect.displayName = 'MockSelect';
  return MockSelect;
});
jest.mock('@superset-ui/core/components/Select/AsyncSelect', () => {
  const MockAsyncSelect = () => <div data-test="mock-async-select" />;
  MockAsyncSelect.displayName = 'MockAsyncSelect';
  return MockAsyncSelect;
});
jest.mock('@superset-ui/core/components/PageHeaderWithActions', () => {
  const MockPageHeaderWithActions = () => (
    <div data-test="mock-page-header-with-actions" />
  );
  MockPageHeaderWithActions.displayName = 'MockPageHeaderWithActions';
  return {
    PageHeaderWithActions: MockPageHeaderWithActions,
  };
});
jest.mock(
  'src/dashboard/components/nativeFilters/FiltersConfigModal/FiltersConfigModal',
  () => {
    const MockFiltersConfigModal = () => (
      <div data-test="mock-filters-config-modal" />
    );
    MockFiltersConfigModal.displayName = 'MockFiltersConfigModal';
    return MockFiltersConfigModal;
  },
);
jest.mock('src/dashboard/components/BuilderComponentPane', () => {
  const MockBuilderComponentPane = () => (
    <div data-test="mock-builder-component-pane" />
  );
  MockBuilderComponentPane.displayName = 'MockBuilderComponentPane';
  return MockBuilderComponentPane;
});
jest.mock('src/dashboard/containers/DashboardGrid', () => {
  const MockDashboardGrid = () => <div data-test="mock-dashboard-grid" />;
  MockDashboardGrid.displayName = 'MockDashboardGrid';
  return MockDashboardGrid;
});
jest.mock('src/dashboard/components/Header/HeadlessAutoRefresh', () => {
  const MockHeadlessAutoRefresh = () => (
    <div data-test="mock-headless-auto-refresh" />
  );
  MockHeadlessAutoRefresh.displayName = 'MockHeadlessAutoRefresh';
  return MockHeadlessAutoRefresh;
});
jest.mock('src/hooks/useIsMobile', () => ({
  ...jest.requireActual('src/hooks/useIsMobile'),
  useIsMobile: jest.fn().mockReturnValue(false),
}));
// The bar's own heavy children, mocked as in the repo's FilterBar tests so the
// real bar renders on its own styling.
jest.mock(
  'src/dashboard/components/nativeFilters/FilterBar/Header',
  () => ({
    __esModule: true,
    default: () => null,
  }),
);
jest.mock(
  'src/dashboard/components/nativeFilters/FilterBar/FilterControls/FilterControls',
  () => ({
    __esModule: true,
    default: () => <div data-test="mock-filter-controls" />,
  }),
);
jest.mock(
  'src/dashboard/components/nativeFilters/FilterBar/CrossFilters/Vertical',
  () => ({
    __esModule: true,
    default: () => null,
  }),
);
jest.mock(
  'src/dashboard/components/nativeFilters/FilterBar/UrlFilters/Vertical',
  () => ({
    __esModule: true,
    default: () => null,
  }),
);


// eslint-disable-next-line import/first
import DashboardBuilder from 'src/dashboard/components/DashboardBuilder/DashboardBuilder';
// eslint-disable-next-line import/first
import useStoredSidebarWidth from 'src/components/ResizableSidebar/useStoredSidebarWidth';
// eslint-disable-next-line import/first
import {
  fetchFaveStar,
  setActiveTab,
} from 'src/dashboard/actions/dashboardState';
// eslint-disable-next-line import/first
import { isEmbedded } from 'src/dashboard/util/isEmbedded';
// eslint-disable-next-line import/first
import { dashboardLayout as undoableDashboardLayout } from 'spec/fixtures/mockDashboardLayout';
// eslint-disable-next-line import/first
import { storeWithState } from 'spec/fixtures/mockStore';
// eslint-disable-next-line import/first
import mockState from 'spec/fixtures/mockState';
// eslint-disable-next-line import/first
import * as useNativeFiltersModule from 'src/dashboard/components/DashboardBuilder/state';

let nativeFiltersSpy;

beforeAll(() => {
  (fetchFaveStar as jest.Mock).mockReturnValue({ type: 'mock-action' });
  (setActiveTab as jest.Mock).mockReturnValue({ type: 'mock-action' });
  (useStoredSidebarWidth as jest.Mock).mockImplementation(() => [100, jest.fn()]);
});

afterEach(() => {
  nativeFiltersSpy?.mockRestore();
  nativeFiltersSpy = undefined;
  (isEmbedded as jest.Mock).mockReturnValue(true);
});

afterAll(() => {
  (fetchFaveStar as jest.Mock).mockReset();
  (setActiveTab as jest.Mock).mockReset();
  (useStoredSidebarWidth as jest.Mock).mockReset();
});

// Render with the vertical filter bar open, the configuration the overflow
// and the button problem were reported in. The spy stays in place until the
// test ends, so later renders see the same filter state.
const renderBuilder = () => {
  nativeFiltersSpy = jest
    .spyOn(useNativeFiltersModule, 'useNativeFilters')
    .mockReturnValue({
      showDashboard: true,
      missingInitialFilters: [],
      dashboardFiltersOpen: true,
      toggleDashboardFiltersOpen: jest.fn(),
      nativeFiltersEnabled: true,
      hasFilters: true,
    });
  return render(<DashboardBuilder />, {
    useRedux: true,
    store: storeWithState({
      ...mockState,
      dashboardLayout: undoableDashboardLayout,
    }),
    useDnd: true,
    useRouter: true,
    useTheme: true,
  });
};

const styleOf = (el: Element, property: string) =>
  window.getComputedStyle(el).getPropertyValue(property).trim();

// Values that leave an element's height to its content.
const CONTENT_SIZED = [
  '',
  'auto',
  'none',
  '0',
  '0px',
  'initial',
  'unset',
  'fit-content',
  'max-content',
  'min-content',
];

const isHidden = (el: Element) => styleOf(el, 'display') === 'none';

// A height or min-height of its own: a length, a percentage or a viewport
// unit, any of which can hold the element taller than what it contains.
const holdsAHeight = (el: Element) =>
  !CONTENT_SIZED.includes(styleOf(el, 'height')) ||
  !CONTENT_SIZED.includes(styleOf(el, 'min-height'));

// A height or max-height that stops the element growing with its content.
const hasAHeightBound = (el: Element) =>
  !CONTENT_SIZED.includes(styleOf(el, 'height')) ||
  !CONTENT_SIZED.includes(styleOf(el, 'max-height'));

// The ancestors of `el`, up to and including `top`.
const ancestorsWithin = (el: Element, top: Element) => {
  const out: Element[] = [];
  for (let node = el.parentElement; node; node = node.parentElement) {
    out.push(node);
    if (node === top) break;
  }
  return out;
};

// Everything that stacks above `el` inside `top`: each of its ancestors, and
// at every level the siblings rendered before the branch that holds it.
const stackedAbove = (el: Element, top: Element) => {
  const out: Element[] = [];
  let branch = el;
  ancestorsWithin(el, top).forEach(parent => {
    out.push(parent);
    for (const sibling of Array.from(parent.children)) {
      if (sibling === branch) break;
      out.push(sibling);
    }
    branch = parent;
  });
  return out;
};

const describeElement = (el: Element) =>
  `<${el.tagName.toLowerCase()} class="${el.getAttribute('class') ?? ''}" ` +
  `height="${styleOf(el, 'height')}" min-height="${styleOf(el, 'min-height')}">`;

const expectNoneHoldAHeight = (els: Element[]) => {
  const visible = Array.from(new Set(els)).filter(el => !isHidden(el));
  expect(visible.filter(holdsAHeight).map(describeElement)).toEqual([]);
};

const filterBarParts = (container: HTMLElement) => {
  const bar = container.querySelector('[data-test="filter-bar"]');
  expect(bar).toBeTruthy();
  const buttons = bar.querySelector('[data-test="filterbar-action-buttons"]');
  expect(buttons).toBeTruthy();
  return { bar, buttons };
};

const loadedFilterList = async (bar: Element) => {
  let list;
  await waitFor(
    () => {
      list = bar.querySelector('[data-test="mock-filter-controls"]');
      expect(list).toBeTruthy();
    },
    { timeout: 5000 },
  );
  return list;
};

// A real bound that is not a viewport width: a length, a percentage, or a
// calc(), min() or clamp() built from those.
const BOUNDED_WIDTH =
  /^(?!.*v(w|h|min|max)\b)(\d+(\.\d+)?(%|px|r?em)|(calc|min|clamp)\(.+\))$/;

describe('embedded dashboard page layout', () => {
  // The header takes no width from the viewport and is still held inside its
  // column, by a cap of its own or a zero minimum width.
  test('header is not capped by a viewport-unit width in an embed', () => {
    const { getByTestId } = renderBuilder();

    const header = getByTestId('dashboard-header-wrapper');
    ['width', 'min-width', 'max-width'].forEach(property => {
      expect(styleOf(header, property)).not.toMatch(/vw/);
    });
    expect(
      BOUNDED_WIDTH.test(styleOf(header, 'max-width')) ||
        /^0(px)?$/.test(styleOf(header, 'min-width')),
    ).toBe(true);
  });

  // While the bar is still loading, nothing above the Apply and Clear buttons
  // holds a height of its own.
  test('filter bar still loading ends with its content in an embed', () => {
    const { container } = renderBuilder();
    const { bar, buttons } = filterBarParts(container);

    expect(bar.querySelector('[data-test="mock-filter-controls"]')).toBeNull();
    expectNoneHoldAHeight(stackedAbove(buttons, bar));
  });

  // Once the filters have loaded, nothing above the buttons holds a height of
  // its own, the filter list and everything around it included.
  test('open filter bar ends with its content in an embed', async () => {
    const { container } = renderBuilder();
    const { bar, buttons } = filterBarParts(container);
    const list = await loadedFilterList(bar);

    expectNoneHoldAHeight([
      ...stackedAbove(buttons, bar),
      ...ancestorsWithin(list, bar),
    ]);
  });

  // Outside an embed the open bar still fills its column, and its filter list
  // still has a height bound so it scrolls inside the bar.
  test('open filter bar keeps its full-height layout outside an embed', async () => {
    (isEmbedded as jest.Mock).mockReturnValue(false);

    const { container } = renderBuilder();
    const { bar, buttons } = filterBarParts(container);
    const list = await loadedFilterList(bar);

    expect(ancestorsWithin(buttons, bar).some(holdsAHeight)).toBe(true);
    expect(ancestorsWithin(list, bar).some(hasAHeightBound)).toBe(true);
  });
});
