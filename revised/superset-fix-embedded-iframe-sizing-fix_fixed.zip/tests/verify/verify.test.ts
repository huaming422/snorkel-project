// @ts-nocheck
/**
 * Behavioral checks for the height the embedded dashboard reports to its host.
 *
 * These call the existing `embeddedApi.getScrollSize()` export, the call a
 * host uses to size an auto-sizing iframe, and look at what it returns. They
 * import nothing the starting code lacks. jsdom does no layout, so every
 * height a browser would compute is stubbed with Object.defineProperty, and
 * the grid markup is the class names DashboardGrid already renders.
 *
 * The page is modeled the way a browser lays out an app that fills its frame:
 *
 *  - The root, body and #app get their fill rules from a stylesheet, as the
 *    app does, in place before the API module loads. While those rules are in force, the body and #app scroll
 *    heights read as the frame height.
 *  - Once the computed height and min-height of all three are free again, by
 *    whatever means (inline styles, another stylesheet, a class), the body
 *    and #app read as their content: the dashboard's height when the
 *    dashboard is laid out, or a little loading chrome when it is not.
 *  - The root's scrollHeight is never below the frame, as with a browser's
 *    documentElement. Its clientHeight and window.innerHeight are the frame.
 */

// Mock factories build their own jest.fn()s: jest.mock is hoisted above these
// declarations, so a factory closing over a const would read it uninitialized.
jest.mock('@apache-superset/core/utils', () => ({
  logging: { debug: jest.fn(), warn: jest.fn(), error: jest.fn() },
}));

jest.mock('../views/store', () => ({
  store: { dispatch: jest.fn(), getState: jest.fn(), subscribe: jest.fn() },
}));

// The app's fill-the-frame rules, put on the page once before the API module
// loads, the way the app's own styles are in place before any script runs.
// jsdom cascades stylesheets in the order they were added, so any sheet a
// module adds when it loads, or later, comes after these rules.
const FILL_RULES = 'html, body, #app { height: 100%; min-height: 100vh; }';
const fillRules = document.createElement('style');
fillRules.textContent = FILL_RULES;
document.head.appendChild(fillRules);

const { embeddedApi } = require('./api');

const { store: mockStore } = jest.requireMock('../views/store');
const mockGetState = mockStore.getState;

const LOADING_CHROME = 120;

const root = () => document.documentElement;
const body = () => document.body;
const appEl = () => document.getElementById('app') as HTMLElement;

// The grid div and its content div, by the class names DashboardGrid renders.
function mountDom({ gridMounted }: { gridMounted: boolean }) {
  document.body.innerHTML = `
    <div id="app">
      <div class="dashboard">
        ${
          gridMounted
            ? '<div class="dashboard-grid"><div class="grid-content"></div></div>'
            : ''
        }
      </div>
    </div>`;
}

// Computed values that no longer hold an element to its frame.
const FREE_HEIGHTS = [
  '',
  'auto',
  'initial',
  'unset',
  'fit-content',
  'max-content',
  'min-content',
];
const FREE_MIN_HEIGHTS = ['', '0', '0px', 'auto', 'initial', 'unset'];

function fillRulesOff(els: HTMLElement[]) {
  return els.every(el => {
    const computed = window.getComputedStyle(el);
    return (
      FREE_HEIGHTS.includes(computed.height) &&
      FREE_MIN_HEIGHTS.includes(computed.minHeight)
    );
  });
}

/**
 * Lay out the page. `frameRef.value` is the frame height the host has set and
 * `contentRef.value` is what the body and #app hold once the fill rules are
 * off. Both can change between reads.
 */
function layOut({
  hydrated = true,
  gridMounted = true,
  frameRef,
  contentRef,
}: {
  hydrated?: boolean;
  gridMounted?: boolean;
  frameRef: { value: number };
  contentRef: { value: number };
}) {
  mockGetState.mockReturnValue(hydrated ? { dashboardInfo: { id: 1 } } : {});
  mountDom({ gridMounted });

  const fillEls = [root(), body(), appEl()];
  const bodyHeight = () =>
    fillRulesOff(fillEls) ? contentRef.value : frameRef.value;
  [body(), appEl()].forEach(el => {
    Object.defineProperty(el, 'scrollHeight', {
      configurable: true,
      get: bodyHeight,
    });
  });
  Object.defineProperty(root(), 'scrollHeight', {
    configurable: true,
    get: () => Math.max(frameRef.value, bodyHeight()),
  });
  Object.defineProperty(root(), 'clientHeight', {
    configurable: true,
    get: () => frameRef.value,
  });
  Object.defineProperty(window, 'innerHeight', {
    configurable: true,
    get: () => frameRef.value,
  });
  Object.defineProperty(body(), 'scrollWidth', {
    configurable: true,
    get: () => 1000,
  });
}

// Everything on the page a call could change: each element's attributes and
// inline declarations, every stylesheet rule, and the computed heights of the
// root, body and #app. An emptied style or class attribute reads the same as
// none.
function pageState() {
  const elements = Array.from(document.querySelectorAll('*')).map(el => {
    const attrs = Array.from(el.attributes)
      .filter(attr => attr.name !== 'style')
      .filter(attr => !(attr.name === 'class' && attr.value.trim() === ''))
      .map(attr => `${attr.name}=${attr.value}`)
      .sort();
    const inline = el instanceof HTMLElement ? el.style.cssText : '';
    return `${el.tagName} ${attrs.join(' ')} {${inline}}`;
  });
  const sheets = Array.from(document.styleSheets).map(sheet =>
    Array.from(sheet.cssRules)
      .map(rule => rule.cssText)
      .join('\n'),
  );
  const computed = [root(), body(), appEl()].map(el => {
    const style = window.getComputedStyle(el);
    return [style.height, style.minHeight, style.maxHeight].join('|');
  });
  return { elements, sheets, computed };
}

// <head> keeps the fill rules and anything a module added when it loaded.
afterEach(() => {
  document.body.innerHTML = '';
  Array.from(root().attributes).forEach(attr =>
    root().removeAttribute(attr.name),
  );
  Array.from(body().attributes).forEach(attr =>
    body().removeAttribute(attr.name),
  );
  jest.clearAllMocks();
});

describe('embeddedApi.getScrollSize reports the dashboard content height', () => {
  // The host sets the frame to each answer and asks again, so every answer has
  // to be the content height, whatever height the frame has right now.
  test('getScrollSize reports the content height whatever the frame height is', () => {
    const frameRef = { value: 800 };
    const contentRef = { value: 1600 };
    layOut({ frameRef, contentRef });

    const first = embeddedApi.getScrollSize().height;
    frameRef.value = first;
    const second = embeddedApi.getScrollSize().height;
    frameRef.value = 2400;
    const third = embeddedApi.getScrollSize().height;

    expect(first).toBe(1600);
    expect(second).toBe(1600);
    expect(third).toBe(1600);
  });

  // A tab switch or a filter change makes the content taller or shorter, and
  // the next answer has to follow it in both directions.
  test('getScrollSize follows the content when it gets taller or shorter', () => {
    const frameRef = { value: 1600 };
    const contentRef = { value: 2100 };
    layOut({ frameRef, contentRef });

    expect(embeddedApi.getScrollSize().height).toBe(2100);

    frameRef.value = 2100;
    contentRef.value = 900;
    expect(embeddedApi.getScrollSize().height).toBe(900);
  });

  // While the store has not hydrated, the page holds only loading chrome, and
  // each answer is the frame's height at the time of the call.
  test('getScrollSize reports the frame height before the dashboard hydrates', () => {
    const frameRef = { value: 650 };
    layOut({
      hydrated: false,
      frameRef,
      contentRef: { value: LOADING_CHROME },
    });

    expect(embeddedApi.getScrollSize().height).toBe(650);

    frameRef.value = 910;
    expect(embeddedApi.getScrollSize().height).toBe(910);
  });

  // A hydrated store with no grid on the page yet is still loading, so each
  // answer is the frame's height at the time of the call here too.
  test('getScrollSize reports the frame height until the grid is on the page', () => {
    const frameRef = { value: 720 };
    layOut({
      gridMounted: false,
      frameRef,
      contentRef: { value: LOADING_CHROME },
    });

    expect(embeddedApi.getScrollSize().height).toBe(720);

    frameRef.value = 480;
    expect(embeddedApi.getScrollSize().height).toBe(480);
  });

  // The page starts with inline styles and classes of its own. After the
  // answer, every element, stylesheet and computed height is as it was.
  test('getScrollSize leaves the page as it found it', () => {
    layOut({ frameRef: { value: 800 }, contentRef: { value: 1600 } });

    root().classList.add('theme-light');
    root().style.color = 'black';
    body().style.overflowX = 'hidden';
    appEl().style.paddingTop = '4px';
    appEl().classList.add('app-ready');

    const before = pageState();
    const { height } = embeddedApi.getScrollSize();

    expect(height).toBe(1600);
    expect(pageState()).toEqual(before);
  });
});
