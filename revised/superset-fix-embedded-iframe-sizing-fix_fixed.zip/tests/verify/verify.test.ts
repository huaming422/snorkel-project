// @ts-nocheck
/**
 * Behavioral checks for the height the embedded dashboard reports to its host.
 *
 * These call the existing `embeddedApi.getScrollSize()` export, the call a
 * host uses to size an auto-sizing iframe, and look at what it returns. They
 * import nothing the starting code lacks. jsdom does no layout, so every
 * height a browser would compute is stubbed with Object.defineProperty, and
 * the grid markup is the class names DashboardGrid already renders.
 *
 * The page is modeled the way a browser lays out an app that fills its frame:
 *
 *  - While the root, body and #app still carry their fill rules, the body and
 *    #app scroll heights read as the frame height.
 *  - Once those rules are switched off through inline styles, the body and
 *    #app read as their content: the dashboard's height when the dashboard is
 *    laid out, or a little loading chrome when it is not.
 *  - The root's scrollHeight is never below the frame, as with a browser's
 *    documentElement. Its clientHeight and window.innerHeight are the frame.
 */

// Mock factories build their own jest.fn()s: jest.mock is hoisted above these
// declarations, so a factory closing over a const would read it uninitialized.
jest.mock('@apache-superset/core/utils', () => ({
  logging: { debug: jest.fn(), warn: jest.fn(), error: jest.fn() },
}));

jest.mock('../views/store', () => ({
  store: { dispatch: jest.fn(), getState: jest.fn(), subscribe: jest.fn() },
}));

// eslint-disable-next-line import/first
import { embeddedApi } from './api';

const { store: mockStore } = jest.requireMock('../views/store');
const mockGetState = mockStore.getState;

const LOADING_CHROME = 120;

const root = () => document.documentElement;
const body = () => document.body;
const appEl = () => document.getElementById('app') as HTMLElement;

// The grid div and its content div, by the class names DashboardGrid renders.
function mountDom({ gridMounted }: { gridMounted: boolean }) {
  document.body.innerHTML = `
    <div id="app">
      <div class="dashboard">
        ${
          gridMounted
            ? '<div class="dashboard-grid"><div class="grid-content"></div></div>'
            : ''
        }
      </div>
    </div>`;
}

// Inline values that no longer hold an element to its frame.
const FREE_HEIGHTS = [
  '',
  'auto',
  'initial',
  'unset',
  'fit-content',
  'max-content',
  'min-content',
];
const FREE_MIN_HEIGHTS = ['', '0', '0px', 'auto', 'initial', 'unset'];

function fillRulesOff(els: HTMLElement[]) {
  return els.every(
    el =>
      FREE_HEIGHTS.includes(el.style.height) &&
      FREE_MIN_HEIGHTS.includes(el.style.minHeight),
  );
}

/**
 * Lay out the page. `frameRef.value` is the frame height the host has set and
 * `contentRef.value` is what the body and #app hold once the fill rules are
 * off. Both can change between reads.
 */
function layOut({
  hydrated = true,
  gridMounted = true,
  frameRef,
  contentRef,
}: {
  hydrated?: boolean;
  gridMounted?: boolean;
  frameRef: { value: number };
  contentRef: { value: number };
}) {
  mockGetState.mockReturnValue(hydrated ? { dashboardInfo: { id: 1 } } : {});
  mountDom({ gridMounted });

  const fillEls = [root(), body(), appEl()];
  fillEls.forEach(el => {
    el.style.minHeight = '100vh';
  });

  const bodyHeight = () =>
    fillRulesOff(fillEls) ? contentRef.value : frameRef.value;
  [body(), appEl()].forEach(el => {
    Object.defineProperty(el, 'scrollHeight', {
      configurable: true,
      get: bodyHeight,
    });
  });
  Object.defineProperty(root(), 'scrollHeight', {
    configurable: true,
    get: () => Math.max(frameRef.value, bodyHeight()),
  });
  Object.defineProperty(root(), 'clientHeight', {
    configurable: true,
    get: () => frameRef.value,
  });
  Object.defineProperty(window, 'innerHeight', {
    configurable: true,
    get: () => frameRef.value,
  });
  Object.defineProperty(body(), 'scrollWidth', {
    configurable: true,
    get: () => 1000,
  });
}

afterEach(() => {
  document.body.innerHTML = '';
  document.documentElement.removeAttribute('style');
  document.body.removeAttribute('style');
  jest.clearAllMocks();
});

describe('embeddedApi.getScrollSize reports the dashboard content height', () => {
  // The host sets the frame to each answer and asks again, so every answer has
  // to be the content height, whatever height the frame has right now.
  test('getScrollSize reports the content height whatever the frame height is', () => {
    const frameRef = { value: 800 };
    const contentRef = { value: 1600 };
    layOut({ frameRef, contentRef });

    const first = embeddedApi.getScrollSize().height;
    frameRef.value = first;
    const second = embeddedApi.getScrollSize().height;
    frameRef.value = 2400;
    const third = embeddedApi.getScrollSize().height;

    expect(first).toBe(1600);
    expect(second).toBe(1600);
    expect(third).toBe(1600);
  });

  // A tab switch or a filter change makes the content taller or shorter, and
  // the next answer has to follow it in both directions.
  test('getScrollSize follows the content when it gets taller or shorter', () => {
    const frameRef = { value: 1600 };
    const contentRef = { value: 2100 };
    layOut({ frameRef, contentRef });

    expect(embeddedApi.getScrollSize().height).toBe(2100);

    frameRef.value = 2100;
    contentRef.value = 900;
    expect(embeddedApi.getScrollSize().height).toBe(900);
  });

  // While the store has not hydrated, the page holds only loading chrome, and
  // the answer is the frame's current height.
  test('getScrollSize reports the frame height before the dashboard hydrates', () => {
    const frameRef = { value: 650 };
    layOut({
      hydrated: false,
      frameRef,
      contentRef: { value: LOADING_CHROME },
    });

    expect(embeddedApi.getScrollSize().height).toBe(650);
  });

  // A hydrated store with no grid on the page yet is still loading, so the
  // answer is the frame's current height here too.
  test('getScrollSize reports the frame height until the grid is on the page', () => {
    const frameRef = { value: 650 };
    layOut({
      gridMounted: false,
      frameRef,
      contentRef: { value: LOADING_CHROME },
    });

    expect(embeddedApi.getScrollSize().height).toBe(650);
  });

  // Each fill element starts with its own inline values, and after the answer
  // every one of them is back to what it was.
  test('getScrollSize leaves every inline style as it found it', () => {
    layOut({ frameRef: { value: 800 }, contentRef: { value: 1600 } });

    root().style.height = '100%';
    root().style.minHeight = '100vh';
    body().style.height = '';
    body().style.minHeight = '90vh';
    appEl().style.height = '640px';
    appEl().style.minHeight = '50vh';

    const { height } = embeddedApi.getScrollSize();

    expect(height).toBe(1600);
    expect(root().style.height).toBe('100%');
    expect(root().style.minHeight).toBe('100vh');
    expect(body().style.height).toBe('');
    expect(body().style.minHeight).toBe('90vh');
    expect(appEl().style.height).toBe('640px');
    expect(appEl().style.minHeight).toBe('50vh');
  });
});
