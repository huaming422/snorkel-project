## Task

A customer has one of our dashboards embedded in an iframe that sizes itself to its content, and the frame keeps getting taller on its own.
Their page calls the embedded SDK's getScrollSize() to ask how tall the dashboard is, then sets the iframe to that height.
Every answer comes back bigger than the last one, so the frame never settles.

They see two more problems on the same embedded dashboards:
- With the vertical filter bar, the Apply and Clear buttons end up far below the last filter, past the visible part of the frame, so nobody can click them.
- With the filter bar open at narrower widths, a horizontal scrollbar shows up and the page scrolls sideways by a few pixels.

What we need:
- Once the dashboard is on the page, the height it reports should depend only on its content, not on how tall the frame is right now.
- When the content changes later, for example after a tab switch, the next answer should follow it.
- While the dashboard is still loading, it should report the frame's current height, so an early check doesn't shrink the frame before the charts show up.
- Answering shouldn't leave anything on the page changed.
- The Apply and Clear buttons should sit right under the filter list.
- The stray horizontal scrollbar should go away.

By embedded I mean the dashboard is running inside any frame, the same way the rest of the dashboard code already decides that.
On standalone dashboards the filter bar looks fine today and should stay as it is.
