## Task

We're retiring the `role` search facet.
It's just specialization (category) crossed with seniority, and only about 1.6% of searches use it.
People can pick those two instead.
Don't build a replacement, and don't change what category and seniority mean.

Take it out of the whole backend, not only the query parameters:

- Indexed job documents stop carrying role data, and the index settings stop declaring it filterable.
- The AI search assistant never hands back a role anymore, while category and seniority still resolve as before.
- Search suggestions stop offering roles, and role is no longer a suggestion kind at all, while every specialization is still offered.
- The generated front-end contracts stop shipping the role labels but still carry the shorthand terms people type to find a specialization or seniority, like "data engineer".
- Nothing uses the role dictionary after that, so delete it and take it out of the architecture layering list.

## User stories / requirements

- A search or facet-count request that still has `role`, `role_exclude` or `role_mode` (a stale saved search or shared link) still succeeds. Those parameters filter nothing and come back reported as ignored, with no did-you-mean pointing at another parameter, and a live filter sent next to them keeps working.
- The similarly-named people-management filter (whether a posting manages people) and its exclude and mode variants are a different facet and stay. On both kinds of request it keeps filtering and is never reported as ignored, even when the retired role parameters ride along.
