## Task

We're retiring the `role` search facet.
It's just specialization (category) crossed with seniority, and only about 1.6% of searches use it.
People can pick those two instead.
Don't build a replacement, and don't change what category and seniority mean.

Take it out of the whole backend, not only the query parameters:

- Indexed job documents stop carrying role data, and the index settings stop declaring it filterable.
- The AI search assistant never hands back a role anymore, while category and seniority still resolve as before.
- Search suggestions stop offering roles, and role is no longer a suggestion kind at all, while every specialization is still offered.
- The generated front-end contracts stop shipping the role labels but still carry the shorthand terms people type to find a specialization or seniority, like "data engineer".
- Nothing uses the role dictionary after that, so delete it and take it out of the architecture layering list.

Saved-search alerts need care too.
They re-run their stored query on every pass, and some of those queries were saved with `role` in them.
If `role` or `role_exclude` was the only thing narrowing an alert, the alert stops picking up new postings instead of sending out the whole catalogue.
That holds even when the saved query also keeps settings that don't filter, like a sort order.
An alert that still has something else narrowing it (another facet, a salary bound or search text) keeps matching on that, the same way a fresh search without the role parameters would.
An alert saved with no filter at all always meant "everything", and it keeps matching everything.

## User stories / requirements

- A search or facet-count request that still has `role`, `role_exclude` or `role_mode` (a stale saved search or shared link) still succeeds. Those parameters filter nothing and come back reported as ignored, with no did-you-mean pointing at another parameter. A live filter sent with them narrows the results exactly as it does alone.
- The similarly-named people-management filter (whether a posting manages people) and its exclude and mode variants are a different facet and stay. On both kinds of request it keeps filtering and is never reported as ignored, even when the retired role parameters ride along.
