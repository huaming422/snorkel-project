## Task

We're retiring the `role` search facet.
It's just specialization (category) crossed with seniority, and only about 1.6% of searches use it.
People can pick those two instead, so nothing needs to take its place, and category and seniority keep meaning what they mean today.

Take it out of the whole backend, not just the query parameters.
Once this lands, the backend shouldn't show role to anyone, hand it to the front end or accept it as a filter, and the search index shouldn't keep storing it or filtering on it.
Some things stay as they are: the AI search assistant still works out category and seniority, every specialization is still offered in search suggestions, and the generated front-end contracts keep the shorthand terms people type to find a specialization or seniority, like "data engineer".
The repo's own build and architecture checks have to keep passing.

The suggestion list is only rebuilt once a day, so until that runs it still has the old role entries in it.
The search box shouldn't offer any of them, and when someone types out a role's full name it shouldn't be read back to them as a role.
Everything else in the list keeps being offered and recognized the way it is today, including a specialization that happens to share its name with an old role.
The next rebuild has to go through against the index as it is after this change, and leave role out.

Saved-search alerts need care too.
They re-run their stored query on every pass, and some of those queries were saved with `role` in them.
If `role` or `role_exclude` was the only thing narrowing an alert, the alert stops picking up new postings instead of sending out the whole catalogue.
That holds even when the saved query also keeps settings that don't filter, like a sort order.
An alert that still has something else narrowing it (another facet, a salary bound or search text) keeps matching on that, the same way a fresh search without the role parameters would.
An alert saved with no filter at all always meant "everything", and it keeps matching everything.

## User stories / requirements

- A search or facet-count request that still has `role`, `role_exclude` or `role_mode` (a stale saved search or shared link) still succeeds. Those parameters filter nothing and come back reported as ignored, with no did-you-mean pointing at another parameter. A live filter sent with them narrows the results exactly as it does alone.
- The similarly-named people-management filter (whether a posting manages people) and its exclude and mode variants are a different facet and stay. On both kinds of request it keeps filtering and is never reported as ignored, even when the retired role parameters ride along.
