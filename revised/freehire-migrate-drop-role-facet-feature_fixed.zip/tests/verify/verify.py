"""Structural and coherence checks for this migration.

The behavioral contract (filter builder, param reporter, settings, document
shape, intent layer, suggestions, generated contracts) is checked by the Go
verifier files in this directory, each of which owns its own ``TestMain`` and
compiles against production symbols only.

This file adds the whole-module checks:

1. ``test_repo_architecture_checks_pass``: the repository's own architecture
   tests in ``internal/platform/arch/layering`` pass. They hold the block table
   against the packages on disk in both directions and check every import
   against the layering. The test files are taken from the base commit for the
   run, so the rules are the repository's, not an edited copy.

2. ``test_module_builds_clean``: ``go build ./...`` succeeds across the whole
   module.

Runs under VERIFIER_PYTHON: it inspects text/filesystem and shells out to the
toolchain, never importing repository code, so it needs no project interpreter.
"""

from __future__ import annotations

import os
import subprocess
from pathlib import Path

import pytest


REPO_DIR = Path(f"/repo/{os.environ.get('REPO_NAME', 'freehire')}")

LAYERING_DIR = REPO_DIR / "internal" / "platform" / "arch" / "layering"
BASE_REF_FILE = Path("/var/lib/devcontainer_base_ref")


def _go_env() -> dict[str, str]:
    env = dict(os.environ)
    env["GOFLAGS"] = "-mod=mod"
    env.setdefault("GOPROXY", "off")
    env.setdefault("CGO_ENABLED", "1")
    env.setdefault("GOTOOLCHAIN", "local")
    return env


def _git(*args: str) -> str:
    return subprocess.run(
        ["git", "-c", "safe.directory=*", "-C", str(REPO_DIR), *args],
        capture_output=True, text=True, check=True,
    ).stdout


def test_repo_architecture_checks_pass() -> None:
    """The repository's layering tests, as of the base commit, pass on the tree."""
    base = BASE_REF_FILE.read_text().strip() if BASE_REF_FILE.exists() else "HEAD"
    rel = LAYERING_DIR.relative_to(REPO_DIR).as_posix()
    names = [n for n in _git("ls-tree", "--name-only", base, rel + "/").split() if n.endswith("_test.go")]
    assert names, f"no layering tests at {base}:{rel}"
    saved = {p: p.read_bytes() for p in LAYERING_DIR.glob("*_test.go")}
    try:
        for p in saved:
            p.unlink()
        for name in names:
            (REPO_DIR / name).write_text(_git("show", f"{base}:{name}"))
        proc = subprocess.run(
            ["go", "test", "-count=1", "./" + rel + "/"],
            capture_output=True, text=True, timeout=900,
            cwd=str(REPO_DIR), check=False, env=_go_env(),
        )
    finally:
        for p in LAYERING_DIR.glob("*_test.go"):
            p.unlink()
        for p, data in saved.items():
            p.write_bytes(data)
    assert proc.returncode == 0, (
        f"the repository's architecture tests failed.\n"
        f"--- output tail ---\n{proc.stdout[-2500:]}\n{proc.stderr[-1500:]}"
    )


def test_module_builds_clean() -> None:
    """`go build ./...` succeeds against the whole module."""
    proc = subprocess.run(
        ["go", "build", "./..."],
        capture_output=True,
        text=True,
        timeout=900,
        cwd=str(REPO_DIR),
        check=False,
        env=_go_env(),
    )
    assert proc.returncode == 0, (
        f"`go build ./...` exited with {proc.returncode}.\n"
        f"--- stderr tail ---\n{proc.stderr[-2500:]}\n"
        f"--- stdout tail ---\n{proc.stdout[-1500:]}"
    )


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v", "--tb=short"]))
