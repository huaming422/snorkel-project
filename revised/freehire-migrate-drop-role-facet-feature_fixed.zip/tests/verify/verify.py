"""Structural and coherence checks for this migration.

The behavioral contract (filter builder, param reporter, settings, document
shape, intent layer, suggestions, generated contracts) is checked by the Go
verifier files in this directory, each of which owns its own ``TestMain`` and
compiles against production symbols only.

This file adds the checks that are filesystem/text facts or whole-module
coherence, not single-package behavior:

1. ``test_orphan_dictionary_package_deleted``: the role dictionary package
   directory is gone from the tree.

2. ``test_layering_block_drops_orphan_package``: the architecture layering
   definition's ``dict`` block list no longer names that package, so the
   block list and the on-disk tree agree.

3. ``test_module_builds_clean``: ``go build ./...`` succeeds across the whole
   module.

Runs under VERIFIER_PYTHON: it inspects text/filesystem and shells out to the
toolchain, never importing repository code, so it needs no project interpreter.
"""

from __future__ import annotations

import os
import re
import subprocess
from pathlib import Path

import pytest


REPO_DIR = Path(f"/repo/{os.environ.get('REPO_NAME', 'freehire')}")

# The role dictionary package, as a repo-relative directory and as the token the
# layering block lists it under.
ORPHAN_PACKAGE_DIR = REPO_DIR / "internal" / "dict" / "roletag"
ORPHAN_BLOCK_TOKEN = "roletag"

LAYERING_BLOCKS = REPO_DIR / "internal" / "platform" / "arch" / "layering" / "blocks.go"


def _dict_block_body(source: str) -> str:
    """Return the text inside the ``"dict": { ... }`` block of blocks.go.

    Matches from the block's opening brace to its closing brace. Scoping the
    search to this block keeps the assertion about the dictionary layer alone,
    not about any other mention elsewhere in the file.
    """
    start = re.search(r'"dict"\s*:\s*\{', source)
    assert start is not None, "could not find the dict block in the layering definition"
    i = start.end()
    depth = 1
    while i < len(source) and depth > 0:
        if source[i] == "{":
            depth += 1
        elif source[i] == "}":
            depth -= 1
        i += 1
    return source[start.end() : i - 1]


def test_orphan_dictionary_package_deleted() -> None:
    assert not ORPHAN_PACKAGE_DIR.exists(), (
        f"the role dictionary package still exists at {ORPHAN_PACKAGE_DIR}"
    )


def test_layering_block_drops_orphan_package() -> None:
    assert LAYERING_BLOCKS.exists(), f"layering definition not found at {LAYERING_BLOCKS}"
    body = _dict_block_body(LAYERING_BLOCKS.read_text())
    listed = set(re.findall(r'"([^"]+)"', body))
    assert ORPHAN_BLOCK_TOKEN not in listed, (
        f"the dict block still lists {ORPHAN_BLOCK_TOKEN!r}; the block list must "
        "match the packages actually on disk."
    )


def test_module_builds_clean() -> None:
    """`go build ./...` succeeds against the whole module."""
    env = dict(os.environ)
    env["GOFLAGS"] = "-mod=mod"
    env.setdefault("GOPROXY", "off")
    env.setdefault("CGO_ENABLED", "1")
    env.setdefault("GOTOOLCHAIN", "local")
    proc = subprocess.run(
        ["go", "build", "./..."],
        capture_output=True,
        text=True,
        timeout=900,
        cwd=str(REPO_DIR),
        check=False,
        env=env,
    )
    assert proc.returncode == 0, (
        f"`go build ./...` exited with {proc.returncode}.\n"
        f"--- stderr tail ---\n{proc.stderr[-2500:]}\n"
        f"--- stdout tail ---\n{proc.stdout[-1500:]}"
    )


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v", "--tb=short"]))
