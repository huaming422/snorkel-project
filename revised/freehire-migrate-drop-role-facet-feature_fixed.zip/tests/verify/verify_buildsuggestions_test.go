package main

// Behavioral check on the suggestions CLI: the facet distributions it requests are
// sourced from the shared facet table, the discontinued name is not in that table,
// and a build against an index that no longer filters on the discontinued
// attribute completes and offers every specialization and no role.
//
// This file owns TestMain so it is the only test compiled into this command's test
// binary. The build check runs the command's own gather step against a database
// layer with no rows and a stand-in jobs index, then the public Build, the same two
// steps the command runs before writing the dictionary.

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"sort"
	"strings"
	"testing"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"

	"github.com/strelov1/freehire/internal/platform/config"
	"github.com/strelov1/freehire/internal/platform/db"
	"github.com/strelov1/freehire/internal/search/search"
	"github.com/strelov1/freehire/internal/search/suggest"
)

func TestMain(m *testing.M) {
	os.Exit(m.Run())
}

// The surviving facet names the builder asks for are keys of the shared table.
func TestRequestedFacetsComeFromSharedTable(t *testing.T) {
	for _, param := range []string{"skills", "category"} {
		attr, ok := search.StringFacets[param]
		if !ok {
			t.Errorf("%q is not in the shared facet table the builder reads from", param)
			continue
		}
		if attr == "" {
			t.Errorf("%q maps to an empty attribute", param)
		}
	}
}

// The discontinued facet is not in the shared table, so it cannot come back by
// being re-added there: the builder has no kind for it and would fetch a
// distribution only to throw it away.
func TestDiscontinuedFacetAbsentFromSharedTable(t *testing.T) {
	if _, ok := search.StringFacets["role"]; ok {
		t.Errorf("the discontinued facet is in the shared table again")
	}
}

// noRows is a database layer whose every query returns no rows: no mined titles,
// no suggestible companies and no recorded searches.
type noRows struct{}

func (noRows) Exec(context.Context, string, ...interface{}) (pgconn.CommandTag, error) {
	return pgconn.CommandTag{}, nil
}
func (noRows) Query(context.Context, string, ...interface{}) (pgx.Rows, error) {
	return &emptyRows{}, nil
}
func (noRows) QueryRow(context.Context, string, ...interface{}) pgx.Row { return emptyRow{} }
func (noRows) SendBatch(context.Context, *pgx.Batch) pgx.BatchResults   { return nil }

type emptyRow struct{}

func (emptyRow) Scan(...any) error { return pgx.ErrNoRows }

type emptyRows struct{}

func (*emptyRows) Close()                                       {}
func (*emptyRows) Err() error                                   { return nil }
func (*emptyRows) CommandTag() pgconn.CommandTag                { return pgconn.CommandTag{} }
func (*emptyRows) FieldDescriptions() []pgconn.FieldDescription { return nil }
func (*emptyRows) Next() bool                                   { return false }
func (*emptyRows) Scan(...any) error                            { return pgx.ErrNoRows }
func (*emptyRows) Values() ([]any, error)                       { return nil, nil }
func (*emptyRows) RawValues() [][]byte                          { return nil }
func (*emptyRows) Conn() *pgx.Conn                              { return nil }

// jobsIndex stands in for the live jobs index after the change: a facet search
// answers the distribution of each requested attribute. The index filters on the
// attributes the shared facet table names, except the discontinued `roles`, which it
// no longer filters on. Asking for any other is the 400 the engine gives for a facet
// that is not filterable.
func jobsIndex(t *testing.T, dist map[string]map[string]int) *httptest.Server {
	t.Helper()
	filterable := map[string]bool{}
	for _, attr := range search.StringFacets {
		filterable[attr] = attr != "" && attr != "roles"
	}
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		if r.Method != http.MethodPost || r.URL.Path != "/indexes/jobs/search" {
			w.WriteHeader(http.StatusNotFound)
			_, _ = io.WriteString(w, `{"message":"not found","code":"not_found","type":"invalid_request","link":""}`)
			return
		}
		var req struct {
			Facets []string `json:"facets"`
		}
		_ = json.NewDecoder(r.Body).Decode(&req)
		out := map[string]map[string]int{}
		for _, f := range req.Facets {
			if !filterable[f] {
				w.WriteHeader(http.StatusBadRequest)
				fmt.Fprintf(w, `{"message":"Invalid facet distribution, attribute %s is not filterable.","code":"invalid_search_facets","type":"invalid_request","link":""}`, "`"+f+"`")
				return
			}
			out[f] = dist[f]
		}
		_ = json.NewEncoder(w).Encode(map[string]any{
			"hits": []any{}, "query": "", "processingTimeMs": 0, "limit": 0, "offset": 0,
			"estimatedTotalHits": 100, "facetDistribution": out,
		})
	}))
	t.Cleanup(srv.Close)
	return srv
}

// A build against the index as it stands after the change completes, offers every
// specialization and skill the index counts, including specializations named like
// a former role, and offers nothing of the discontinued kind.
func TestBuildAgainstIndexWithoutDiscontinuedAttribute(t *testing.T) {
	cases := []struct {
		categories map[string]int
		skills     map[string]int
	}{
		{
			categories: map[string]int{"backend": 40769, "frontend": 12000, "data_engineering": 900},
			skills:     map[string]int{"go": 120, "kubernetes": 80},
		},
		{
			categories: map[string]int{"qa": 3100, "mobile": 2500, "devops": 4100, "product": 9000},
			skills:     map[string]int{"swift": 60},
		},
	}
	for _, tc := range cases {
		srv := jobsIndex(t, map[string]map[string]int{
			search.StringFacets["category"]: tc.categories,
			search.StringFacets["skills"]:   tc.skills,
		})
		client := search.NewClient(srv.URL, "verify-key")
		in, err := gather(context.Background(), db.New(noRows{}), client, config.Suggest{TitleFloor: 25, CompanyFloor: 5})
		if err != nil {
			t.Fatalf("gathering against the index failed: %v", err)
		}
		got := map[string][]string{}
		for _, d := range suggest.Build(in) {
			got[string(d.Kind)] = append(got[string(d.Kind)], d.Slug)
		}
		for k := range got {
			sort.Strings(got[k])
		}
		want := map[string][]string{"category": keys(tc.categories), "skill": keys(tc.skills)}
		for kind, slugs := range got {
			if kind != "category" && kind != "skill" {
				t.Errorf("the build offers %s suggestions %v, want only categories and skills", kind, slugs)
			}
		}
		for kind, slugs := range want {
			if strings.Join(got[kind], ",") != strings.Join(slugs, ",") {
				t.Errorf("%s suggestions = %v, want %v", kind, got[kind], slugs)
			}
		}
	}
}

func keys(m map[string]int) []string {
	out := make([]string, 0, len(m))
	for k := range m {
		out = append(out, k)
	}
	sort.Strings(out)
	return out
}
