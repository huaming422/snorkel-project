package main

// Behavioral check on the suggestions CLI: the facet distributions it requests are
// sourced from the shared facet table, and the discontinued name is not in that
// table (so it cannot be requested).
//
// This file owns TestMain so it is the only test compiled into this command's test
// binary. It asserts on the shared table the builder reads, never on a private
// literal inside the builder.

import (
	"os"
	"testing"

	"github.com/strelov1/freehire/internal/search/search"
)

func TestMain(m *testing.M) {
	os.Exit(m.Run())
}

// The surviving facet names the builder asks for are keys of the shared table.
func TestRequestedFacetsComeFromSharedTable(t *testing.T) {
	for _, param := range []string{"skills", "category"} {
		attr, ok := search.StringFacets[param]
		if !ok {
			t.Errorf("%q is not in the shared facet table the builder reads from", param)
			continue
		}
		if attr == "" {
			t.Errorf("%q maps to an empty attribute", param)
		}
	}
}

// The discontinued facet is not in the shared table, so it cannot come back by
// being re-added there: the builder has no kind for it and would fetch a
// distribution only to throw it away.
func TestDiscontinuedFacetAbsentFromSharedTable(t *testing.T) {
	if _, ok := search.StringFacets["role"]; ok {
		t.Errorf("the discontinued facet is in the shared table again")
	}
}
