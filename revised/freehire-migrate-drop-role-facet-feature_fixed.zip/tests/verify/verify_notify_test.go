package notify

// Behavioral checks on the alert matcher: a pass over the active subscriptions
// re-runs each stored query and records the postings each subscription picks up.
//
// This file owns TestMain so it is the only test compiled into the package. It
// leans only on production symbols and inlines its own fakes, so it never clashes
// with a sibling test file's helper names.

import (
	"context"
	"net/url"
	"os"
	"reflect"
	"sort"
	"strings"
	"testing"
	"time"

	"github.com/jackc/pgx/v5/pgtype"

	"github.com/strelov1/freehire/internal/platform/db"
	"github.com/strelov1/freehire/internal/search/search"
)

func TestMain(m *testing.M) {
	os.Exit(m.Run())
}

var alertStart = time.Date(2026, 3, 2, 9, 0, 0, 0, time.UTC)

// alertSearcher answers every search with the same two fresh postings and keeps
// the parameters it was asked with.
type alertSearcher struct {
	calls []search.SearchParams
}

func (s *alertSearcher) Search(_ context.Context, p search.SearchParams) (search.SearchResult, error) {
	s.calls = append(s.calls, p)
	return search.SearchResult{Hits: []search.JobDocument{
		alertHit(7001, alertStart.Add(time.Hour)),
		alertHit(7002, alertStart.Add(2*time.Hour)),
	}}, nil
}

func alertHit(id int64, created time.Time) search.JobDocument {
	s := created.Format(time.RFC3339)
	d := search.JobDocument{ID: id}
	d.CreatedAt = &s
	return d
}

// alertStore serves the subscriptions and records the matches a pass writes. The
// embedded Store is left nil: delivery finds nothing claimed, so no other method
// is reached.
type alertStore struct {
	Store
	active   []db.ListActiveSubscriptionsRow
	recorded map[int64][]int64
}

func (s *alertStore) ListActiveSubscriptions(context.Context) ([]db.ListActiveSubscriptionsRow, error) {
	return s.active, nil
}

func (s *alertStore) ListUserProfilesExcludedSkills(context.Context, []int64) ([]db.ListUserProfilesExcludedSkillsRow, error) {
	return nil, nil
}

func (s *alertStore) RecordSubscriptionMatches(_ context.Context, a db.RecordSubscriptionMatchesParams) (int64, error) {
	if s.recorded == nil {
		s.recorded = map[int64][]int64{}
	}
	for i := range a.SubscriptionIds {
		s.recorded[a.SubscriptionIds[i]] = append(s.recorded[a.SubscriptionIds[i]], a.JobIds[i])
	}
	return int64(len(a.SubscriptionIds)), nil
}

func (s *alertStore) ClaimSubscriptionMatches(context.Context, db.ClaimSubscriptionMatchesParams) ([]db.ClaimSubscriptionMatchesRow, error) {
	return nil, nil
}

func subscription(id, user int64, query string) db.ListActiveSubscriptionsRow {
	return db.ListActiveSubscriptionsRow{
		ID:      id,
		UserID:  user,
		Query:   query,
		StartAt: pgtype.Timestamptz{Time: alertStart, Valid: true},
	}
}

// runPass runs one matching pass over subs and fails the test if it errors.
func runPass(t *testing.T, subs ...db.ListActiveSubscriptionsRow) (*alertStore, *alertSearcher) {
	t.Helper()
	store := &alertStore{active: subs}
	searcher := &alertSearcher{}
	if _, err := New(store, searcher, nil, DefaultConfig()).Run(context.Background()); err != nil {
		t.Fatalf("pass failed: %v", err)
	}
	return store, searcher
}

func picked(store *alertStore, sub int64) []int64 {
	got := append([]int64(nil), store.recorded[sub]...)
	sort.Slice(got, func(i, j int) bool { return got[i] < got[j] })
	return got
}

var bothHits = []int64{7001, 7002}

// withoutRole parses q and drops the role params, giving the request a caller
// would send today for the same saved search.
func withoutRole(t *testing.T, q string) url.Values {
	t.Helper()
	v, err := url.ParseQuery(q)
	if err != nil {
		t.Fatal(err)
	}
	for _, k := range []string{"role", "role_exclude", "role_mode"} {
		v.Del(k)
	}
	return v
}

// unorderedFilter puts a group-form filter into a fixed order, so two filters
// that differ only in the order their facets were walked compare equal.
func unorderedFilter(t *testing.T, f any) [][]string {
	t.Helper()
	if f == nil {
		return nil
	}
	gs, ok := f.([][]string)
	if !ok {
		t.Fatalf("filter has unexpected shape %#v", f)
	}
	out := make([][]string, 0, len(gs))
	for _, g := range gs {
		c := append([]string(nil), g...)
		sort.Strings(c)
		out = append(out, c)
	}
	sort.Slice(out, func(i, j int) bool {
		return strings.Join(out[i], "\x00") < strings.Join(out[j], "\x00")
	})
	return out
}

// An alert whose saved query narrowed only through the retired role params picks
// up nothing, for every subscriber on that query, while an ordinary alert in the
// same pass keeps matching.
func TestAlertLeftWithOnlyRetiredFilterStopsMatching(t *testing.T) {
	stale := []string{
		"role=senior_backend",
		"role=lead_frontend,staff_data_engineering&role_mode=and",
		"role_exclude=intern",
		"role=principal_ml_ai&sort=posted_at",
	}
	for _, q := range stale {
		t.Run(q, func(t *testing.T) {
			store, _ := runPass(t,
				subscription(11, 501, q),
				subscription(12, 502, q),
				subscription(13, 503, "seniority=senior"),
			)
			for _, id := range []int64{11, 12} {
				if got := picked(store, id); len(got) != 0 {
					t.Errorf("alert %d on %q picked up %v, want nothing", id, q, got)
				}
			}
			if got := picked(store, 13); !reflect.DeepEqual(got, bothHits) {
				t.Errorf("ordinary alert in the same pass picked up %v, want %v", got, bothHits)
			}
		})
	}
}

// An alert that still has something else narrowing it keeps matching, and runs
// the same search a fresh request without the role params would.
func TestAlertWithLiveFilterKeepsMatching(t *testing.T) {
	cases := []string{
		"role=senior_backend&category=backend",
		"role=lead_frontend&role_type=people_manager",
		"role_exclude=intern&role_type_exclude=people_manager",
		"role_exclude=intern&salary_min=120000",
		"role=senior_backend&q=golang",
		"role=staff_sre&q=kubernetes&sort=posted_at",
	}
	for _, q := range cases {
		t.Run(q, func(t *testing.T) {
			store, searcher := runPass(t, subscription(21, 601, q))
			if got := picked(store, 21); !reflect.DeepEqual(got, bothHits) {
				t.Fatalf("alert on %q picked up %v, want %v", q, got, bothHits)
			}
			if len(searcher.calls) != 1 {
				t.Fatalf("searches run = %d, want 1", len(searcher.calls))
			}
			want := withoutRole(t, q)
			call := searcher.calls[0]
			if call.Query != want.Get("q") {
				t.Errorf("search text = %q, want %q", call.Query, want.Get("q"))
			}
			if g, w := unorderedFilter(t, call.Filter), unorderedFilter(t, search.FilterFromValues(want)); !reflect.DeepEqual(g, w) {
				t.Errorf("filter = %v, want %v (the same request without the role params)", g, w)
			}
		})
	}
}

// An alert saved with no filter at all asked for everything, and still gets it.
func TestUnfilteredAlertStillMatchesEverything(t *testing.T) {
	for _, q := range []string{"", "sort=posted_at"} {
		t.Run("query="+q, func(t *testing.T) {
			store, searcher := runPass(t, subscription(31, 701, q), subscription(32, 702, q))
			for _, id := range []int64{31, 32} {
				if got := picked(store, id); !reflect.DeepEqual(got, bothHits) {
					t.Errorf("alert %d on %q picked up %v, want %v", id, q, got, bothHits)
				}
			}
			if len(searcher.calls) != 1 {
				t.Fatalf("searches run = %d, want 1", len(searcher.calls))
			}
			if searcher.calls[0].Filter != nil || searcher.calls[0].Query != "" {
				t.Errorf("search = %+v, want no filter and no text", searcher.calls[0])
			}
		})
	}
}
