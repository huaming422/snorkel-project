package handler

// Behavioral check at the public search and facets HTTP endpoints: a request still
// carrying the discontinued params answers 200 and gets them surfaced under
// meta.ignored_params with no did-you-mean, while the people-management params are
// never reported.
//
// This file owns TestMain so it is the only test compiled into the package; it
// drives the real handlers through an in-memory fiber app and inlines its own
// doubles and request helper, depending on no sibling test file.

import (
	"context"
	"encoding/json"
	"io"
	"net/http/httptest"
	"os"
	"testing"

	"github.com/gofiber/fiber/v2"

	"github.com/strelov1/freehire/internal/search/search"
)

func TestMain(m *testing.M) {
	os.Exit(m.Run())
}

// stubCounter is a do-nothing facet backend: the endpoint still answers 200 and
// still reports ignored params without any live index behind it.
type stubCounter struct{}

func (stubCounter) FacetCounts(context.Context, search.FacetParams) (search.FacetResult, error) {
	return search.FacetResult{}, nil
}

func (stubCounter) DisjunctiveFacetCounts(context.Context, string, []search.FacetReq, any) (search.FacetResult, error) {
	return search.FacetResult{}, nil
}

// stubSearcher is a do-nothing search backend for the same purpose.
type stubSearcher struct{}

func (stubSearcher) Search(context.Context, search.SearchParams) (search.SearchResult, error) {
	return search.SearchResult{}, nil
}

// endpoints wires each real handler onto an in-memory app at its public route.
func endpoints() map[string]*fiber.App {
	facets := fiber.New(fiber.Config{ErrorHandler: RenderError})
	facets.Get("/jobs/facets", (&searchHandlers{facets: stubCounter{}}).JobFacets)
	jobs := fiber.New(fiber.Config{ErrorHandler: RenderError})
	jobs.Get("/jobs/search", (&searchHandlers{search: stubSearcher{}}).SearchJobs)
	return map[string]*fiber.App{"/jobs/facets": facets, "/jobs/search": jobs}
}

// getJSON performs the request, requires a 200, and decodes the JSON body.
func getJSON(t *testing.T, app *fiber.App, target string) map[string]any {
	t.Helper()
	resp, err := app.Test(httptest.NewRequestWithContext(context.Background(), fiber.MethodGet, target, nil))
	if err != nil {
		t.Fatalf("request: %v", err)
	}
	defer resp.Body.Close()
	raw, err := io.ReadAll(resp.Body)
	if err != nil {
		t.Fatalf("read body: %v", err)
	}
	if resp.StatusCode != fiber.StatusOK {
		t.Errorf("%s answered %d, want 200: %s", target, resp.StatusCode, raw)
	}
	var body map[string]any
	if err := json.Unmarshal(raw, &body); err != nil {
		t.Fatalf("decode %s: %v", raw, err)
	}
	return body
}

// ignored maps each param reported under meta.ignored_params to its did-you-mean
// text ("" when the entry carries none).
func ignored(body map[string]any) map[string]string {
	meta, _ := body["meta"].(map[string]any)
	entries, _ := meta["ignored_params"].([]any)
	out := map[string]string{}
	for _, e := range entries {
		if m, ok := e.(map[string]any); ok {
			if p, ok := m["param"].(string); ok {
				hint, _ := m["did_you_mean"].(string)
				out[p] = hint
			}
		}
	}
	return out
}

// Both endpoints answer 200 and list the discontinued params under
// meta.ignored_params, none of them pointed at another param.
func TestEndpointsReportDiscontinuedParams(t *testing.T) {
	for path, app := range endpoints() {
		body := getJSON(t, app, path+"?role=senior_backend&role_exclude=lead&role_mode=and")
		got := ignored(body)
		for _, name := range []string{"role", "role_exclude", "role_mode"} {
			hint, seen := got[name]
			if !seen {
				t.Errorf("%s: meta.ignored_params = %v, missing %q", path, got, name)
				continue
			}
			if hint != "" {
				t.Errorf("%s: %q carried did_you_mean %q, want none", path, name, hint)
			}
		}
	}
}

// The people-management params and their modifiers are never reported as ignored
// on either endpoint, also when the discontinued params ride along.
func TestEndpointsKeepPeopleManagementParams(t *testing.T) {
	for path, app := range endpoints() {
		for _, q := range []string{
			"role_type=people_manager&role_type_mode=and&role=senior_backend",
			"role_type_exclude=people_manager&role_mode=and",
		} {
			got := ignored(getJSON(t, app, path+"?"+q))
			for _, name := range []string{"role_type", "role_type_exclude", "role_type_mode"} {
				if _, seen := got[name]; seen {
					t.Errorf("%s?%s: %q wrongly reported as ignored: %v", path, q, name, got)
				}
			}
			if len(got) != 1 {
				t.Errorf("%s?%s: meta.ignored_params = %v, want only the discontinued param", path, q, got)
			}
		}
	}
}
