package handler

// Behavioral check at the public search and facets HTTP endpoints: a request still
// carrying the discontinued params answers 200 and gets them surfaced under
// meta.ignored_params with no did-you-mean, while the people-management params are
// never reported. The suggest endpoint, served by the real service and engine client
// over a dictionary that still holds rows of the discontinued kind, offers none of
// them and reads no typed phrase as one.
//
// This file owns TestMain so it is the only test compiled into the package; it
// drives the real handlers through an in-memory fiber app and inlines its own
// doubles and request helper, depending on no sibling test file.

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"sort"
	"strings"
	"sync"
	"testing"
	"unicode"

	"github.com/gofiber/fiber/v2"

	"github.com/strelov1/freehire/internal/search/search"
	"github.com/strelov1/freehire/internal/search/suggest"
)

func TestMain(m *testing.M) {
	os.Exit(m.Run())
}

// stubCounter is a do-nothing facet backend: the endpoint still answers 200 and
// still reports ignored params without any live index behind it.
type stubCounter struct{}

func (stubCounter) FacetCounts(context.Context, search.FacetParams) (search.FacetResult, error) {
	return search.FacetResult{}, nil
}

func (stubCounter) DisjunctiveFacetCounts(context.Context, string, []search.FacetReq, any) (search.FacetResult, error) {
	return search.FacetResult{}, nil
}

// stubSearcher is a do-nothing search backend for the same purpose.
type stubSearcher struct{}

func (stubSearcher) Search(context.Context, search.SearchParams) (search.SearchResult, error) {
	return search.SearchResult{}, nil
}

// endpoints wires each real handler onto an in-memory app at its public route.
func endpoints() map[string]*fiber.App {
	facets := fiber.New(fiber.Config{ErrorHandler: RenderError})
	facets.Get("/jobs/facets", (&searchHandlers{facets: stubCounter{}}).JobFacets)
	jobs := fiber.New(fiber.Config{ErrorHandler: RenderError})
	jobs.Get("/jobs/search", (&searchHandlers{search: stubSearcher{}}).SearchJobs)
	return map[string]*fiber.App{"/jobs/facets": facets, "/jobs/search": jobs}
}

// getJSON performs the request, requires a 200, and decodes the JSON body.
func getJSON(t *testing.T, app *fiber.App, target string) map[string]any {
	t.Helper()
	resp, err := app.Test(httptest.NewRequestWithContext(context.Background(), fiber.MethodGet, target, nil))
	if err != nil {
		t.Fatalf("request: %v", err)
	}
	defer resp.Body.Close()
	raw, err := io.ReadAll(resp.Body)
	if err != nil {
		t.Fatalf("read body: %v", err)
	}
	if resp.StatusCode != fiber.StatusOK {
		t.Errorf("%s answered %d, want 200: %s", target, resp.StatusCode, raw)
	}
	var body map[string]any
	if err := json.Unmarshal(raw, &body); err != nil {
		t.Fatalf("decode %s: %v", raw, err)
	}
	return body
}

// ignored maps each param reported under meta.ignored_params to its did-you-mean
// text ("" when the entry carries none).
func ignored(body map[string]any) map[string]string {
	meta, _ := body["meta"].(map[string]any)
	entries, _ := meta["ignored_params"].([]any)
	out := map[string]string{}
	for _, e := range entries {
		if m, ok := e.(map[string]any); ok {
			if p, ok := m["param"].(string); ok {
				hint, _ := m["did_you_mean"].(string)
				out[p] = hint
			}
		}
	}
	return out
}

// Both endpoints answer 200 and list the discontinued params under
// meta.ignored_params, none of them pointed at another param.
func TestEndpointsReportDiscontinuedParams(t *testing.T) {
	for path, app := range endpoints() {
		body := getJSON(t, app, path+"?role=senior_backend&role_exclude=lead&role_mode=and")
		got := ignored(body)
		for _, name := range []string{"role", "role_exclude", "role_mode"} {
			hint, seen := got[name]
			if !seen {
				t.Errorf("%s: meta.ignored_params = %v, missing %q", path, got, name)
				continue
			}
			if hint != "" {
				t.Errorf("%s: %q carried did_you_mean %q, want none", path, name, hint)
			}
		}
	}
}

// The people-management params and their modifiers are never reported as ignored
// on either endpoint, also when the discontinued params ride along.
func TestEndpointsKeepPeopleManagementParams(t *testing.T) {
	for path, app := range endpoints() {
		for _, q := range []string{
			"role_type=people_manager&role_type_mode=and&role=senior_backend",
			"role_type_exclude=people_manager&role_mode=and",
		} {
			got := ignored(getJSON(t, app, path+"?"+q))
			for _, name := range []string{"role_type", "role_type_exclude", "role_type_mode"} {
				if _, seen := got[name]; seen {
					t.Errorf("%s?%s: %q wrongly reported as ignored: %v", path, q, name, got)
				}
			}
			if len(got) != 1 {
				t.Errorf("%s?%s: meta.ignored_params = %v, want only the discontinued param", path, q, got)
			}
		}
	}
}

// dictRow is one row of the suggestion dictionary as the engine stores it.
type dictRow struct {
	ID       string `json:"id"`
	Text     string `json:"text"`
	Kind     string `json:"kind"`
	Slug     string `json:"slug,omitempty"`
	Jobs     int    `json:"jobs"`
	Searches int    `json:"searches"`
}

func dictEntry(kind, slug, text string, jobs, searches int) dictRow {
	id := slug
	if id == "" {
		id = strings.ToLower(text)
	}
	return dictRow{ID: kind + ":" + id, Text: text, Kind: kind, Slug: slug, Jobs: jobs, Searches: searches}
}

// dictionaryServer stands in for the engine's `suggestions` index and holds its
// rows. The search route matches when every query word starts some word of the
// row's text (an empty query matches every row) and ranks by searches, then jobs.
// The document routes fetch rows and delete them by filter or by id, each delete
// a task that the task route reports as finished. Every filter is read in the
// engine's syntax, as a string or as nested arrays, on the two attributes the index
// declares filterable, kind and slug. A filter it cannot read, or one on another
// attribute, is a 400 as the engine answers it, and any other route is a 404.
func dictionaryServer(t *testing.T, rows []dictRow) *httptest.Server {
	t.Helper()
	var mu sync.Mutex
	live := append([]dictRow(nil), rows...)
	tasks := 0
	fail := func(w http.ResponseWriter, status int, code, msg string) {
		w.WriteHeader(status)
		m, _ := json.Marshal(msg)
		fmt.Fprintf(w, `{"message":%s,"code":%q,"type":"invalid_request","link":""}`, m, code)
	}
	enqueued := func(w http.ResponseWriter, kind string) {
		tasks++
		w.WriteHeader(http.StatusAccepted)
		fmt.Fprintf(w, `{"taskUid":%d,"indexUid":"suggestions","status":"enqueued","type":%q,"enqueuedAt":"2026-01-01T00:00:00Z"}`, tasks, kind)
	}
	remove := func(drop func(dictRow) bool) {
		kept := live[:0]
		for _, row := range live {
			if !drop(row) {
				kept = append(kept, row)
			}
		}
		live = kept
	}
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		mu.Lock()
		defer mu.Unlock()
		w.Header().Set("Content-Type", "application/json")
		const docs = "/indexes/suggestions/documents"
		var body struct {
			Q      string `json:"q"`
			Limit  int    `json:"limit"`
			Offset int    `json:"offset"`
			Filter any    `json:"filter"`
		}
		switch {
		case r.Method == http.MethodGet && strings.HasPrefix(r.URL.Path, "/tasks/"):
			uid := strings.TrimPrefix(r.URL.Path, "/tasks/")
			fmt.Fprintf(w, `{"uid":%s,"indexUid":"suggestions","status":"succeeded","type":"documentDeletion","enqueuedAt":"2026-01-01T00:00:00Z","startedAt":"2026-01-01T00:00:00Z","finishedAt":"2026-01-01T00:00:00Z"}`, uid)
		case r.Method == http.MethodPost && r.URL.Path == docs+"/delete-batch":
			var ids []any
			if err := json.NewDecoder(r.Body).Decode(&ids); err != nil {
				fail(w, http.StatusBadRequest, "bad_request", "bad body")
				return
			}
			gone := map[string]bool{}
			for _, id := range ids {
				gone[fmt.Sprint(id)] = true
			}
			remove(func(row dictRow) bool { return gone[row.ID] })
			enqueued(w, "documentDeletion")
		case r.Method == http.MethodDelete && strings.HasPrefix(r.URL.Path, docs+"/"):
			id := strings.TrimPrefix(r.URL.Path, docs+"/")
			if unescaped, err := url.PathUnescape(id); err == nil {
				id = unescaped
			}
			remove(func(row dictRow) bool { return row.ID == id })
			enqueued(w, "documentDeletion")
		case r.Method == http.MethodPost && (r.URL.Path == docs+"/delete" || r.URL.Path == docs+"/fetch" || r.URL.Path == "/indexes/suggestions/search"):
			if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
				fail(w, http.StatusBadRequest, "bad_request", "bad body")
				return
			}
			keep, err := dictFilter(body.Filter)
			if err != nil {
				fail(w, http.StatusBadRequest, "invalid_search_filter", err.Error())
				return
			}
			if r.URL.Path == docs+"/delete" {
				if body.Filter == nil {
					fail(w, http.StatusBadRequest, "missing_document_filter", "a filter is required")
					return
				}
				remove(keep)
				enqueued(w, "documentDeletion")
				return
			}
			words := dictWords(body.Q)
			var hits []dictRow
			for _, row := range live {
				if keep(row) && dictMatches(words, dictWords(row.Text)) {
					hits = append(hits, row)
				}
			}
			sort.SliceStable(hits, func(i, j int) bool {
				if hits[i].Searches != hits[j].Searches {
					return hits[i].Searches > hits[j].Searches
				}
				if hits[i].Jobs != hits[j].Jobs {
					return hits[i].Jobs > hits[j].Jobs
				}
				return hits[i].ID < hits[j].ID
			})
			total := len(hits)
			if body.Offset > len(hits) {
				body.Offset = len(hits)
			}
			hits = hits[body.Offset:]
			if body.Limit == 0 {
				body.Limit = 20
			}
			if len(hits) > body.Limit {
				hits = hits[:body.Limit]
			}
			if hits == nil {
				hits = []dictRow{}
			}
			if r.URL.Path == docs+"/fetch" {
				_ = json.NewEncoder(w).Encode(map[string]any{
					"results": hits, "offset": body.Offset, "limit": body.Limit, "total": total,
				})
				return
			}
			_ = json.NewEncoder(w).Encode(map[string]any{
				"hits": hits, "query": body.Q, "processingTimeMs": 0,
				"limit": body.Limit, "offset": body.Offset, "estimatedTotalHits": total,
			})
		default:
			fail(w, http.StatusNotFound, "not_found", "not found")
		}
	}))
	t.Cleanup(srv.Close)
	return srv
}

func dictWords(s string) []string {
	return strings.FieldsFunc(strings.ToLower(s), func(r rune) bool {
		return !unicode.IsLetter(r) && !unicode.IsDigit(r)
	})
}

func dictMatches(query, text []string) bool {
	for _, q := range query {
		found := false
		for _, w := range text {
			if strings.HasPrefix(w, q) {
				found = true
				break
			}
		}
		if !found {
			return false
		}
	}
	return true
}

// dictFilter reads a filter as the engine does: a string expression, or an array
// whose entries all hold, each entry a string or an array of strings any one of
// which holds.
func dictFilter(f any) (func(dictRow) bool, error) {
	switch v := f.(type) {
	case nil:
		return func(dictRow) bool { return true }, nil
	case string:
		if strings.TrimSpace(v) == "" {
			return func(dictRow) bool { return true }, nil
		}
		p := &filterParser{toks: filterTokens(v)}
		pred, err := p.or()
		if err != nil {
			return nil, err
		}
		if p.pos != len(p.toks) {
			return nil, fmt.Errorf("unexpected %q in filter %q", p.toks[p.pos].text, v)
		}
		return pred, nil
	case []any:
		var all []func(dictRow) bool
		for _, entry := range v {
			if inner, ok := entry.([]any); ok {
				var oneOf []func(dictRow) bool
				for _, e := range inner {
					pred, err := dictFilter(e)
					if err != nil {
						return nil, err
					}
					oneOf = append(oneOf, pred)
				}
				all = append(all, func(r dictRow) bool {
					for _, p := range oneOf {
						if p(r) {
							return true
						}
					}
					return false
				})
				continue
			}
			pred, err := dictFilter(entry)
			if err != nil {
				return nil, err
			}
			all = append(all, pred)
		}
		return func(r dictRow) bool {
			for _, p := range all {
				if !p(r) {
					return false
				}
			}
			return true
		}, nil
	}
	return nil, fmt.Errorf("filter of type %T", f)
}

type filterToken struct {
	text   string
	quoted bool
}

func filterTokens(s string) []filterToken {
	var out []filterToken
	for i := 0; i < len(s); {
		c := s[i]
		switch {
		case c == ' ' || c == '\t' || c == '\n':
			i++
		case c == '"' || c == '\'':
			j := i + 1
			var b strings.Builder
			for j < len(s) && s[j] != c {
				if s[j] == '\\' && j+1 < len(s) {
					j++
				}
				b.WriteByte(s[j])
				j++
			}
			out = append(out, filterToken{text: b.String(), quoted: true})
			i = j + 1
		case strings.ContainsRune("()[],", rune(c)):
			out = append(out, filterToken{text: string(c)})
			i++
		case c == '!' && i+1 < len(s) && s[i+1] == '=':
			out = append(out, filterToken{text: "!="})
			i += 2
		case c == '>' || c == '<':
			if i+1 < len(s) && s[i+1] == '=' {
				out = append(out, filterToken{text: s[i : i+2]})
				i += 2
			} else {
				out = append(out, filterToken{text: string(c)})
				i++
			}
		case c == '=':
			out = append(out, filterToken{text: "="})
			i++
		default:
			j := i
			for j < len(s) && !strings.ContainsRune(" \t\n()[],=!<>\"'", rune(s[j])) {
				j++
			}
			out = append(out, filterToken{text: s[i:j]})
			i = j
		}
	}
	return out
}

type filterParser struct {
	toks []filterToken
	pos  int
}

func (p *filterParser) keyword(word string) bool {
	if p.pos < len(p.toks) && !p.toks[p.pos].quoted && strings.EqualFold(p.toks[p.pos].text, word) {
		p.pos++
		return true
	}
	return false
}

func (p *filterParser) next() (filterToken, error) {
	if p.pos >= len(p.toks) {
		return filterToken{}, fmt.Errorf("filter ends early")
	}
	p.pos++
	return p.toks[p.pos-1], nil
}

func (p *filterParser) or() (func(dictRow) bool, error) {
	left, err := p.and()
	if err != nil {
		return nil, err
	}
	for p.keyword("OR") {
		right, err := p.and()
		if err != nil {
			return nil, err
		}
		l := left
		left = func(r dictRow) bool { return l(r) || right(r) }
	}
	return left, nil
}

func (p *filterParser) and() (func(dictRow) bool, error) {
	left, err := p.not()
	if err != nil {
		return nil, err
	}
	for p.keyword("AND") {
		right, err := p.not()
		if err != nil {
			return nil, err
		}
		l := left
		left = func(r dictRow) bool { return l(r) && right(r) }
	}
	return left, nil
}

func (p *filterParser) not() (func(dictRow) bool, error) {
	if p.keyword("NOT") {
		inner, err := p.not()
		if err != nil {
			return nil, err
		}
		return func(r dictRow) bool { return !inner(r) }, nil
	}
	if p.pos < len(p.toks) && !p.toks[p.pos].quoted && p.toks[p.pos].text == "(" {
		p.pos++
		inner, err := p.or()
		if err != nil {
			return nil, err
		}
		if tok, err := p.next(); err != nil || tok.text != ")" {
			return nil, fmt.Errorf("unclosed parenthesis")
		}
		return inner, nil
	}
	return p.condition()
}

func (p *filterParser) condition() (func(dictRow) bool, error) {
	attr, err := p.next()
	if err != nil {
		return nil, err
	}
	var field func(dictRow) (string, bool)
	switch attr.text {
	case "kind":
		field = func(r dictRow) (string, bool) { return r.Kind, r.Kind != "" }
	case "slug":
		field = func(r dictRow) (string, bool) { return r.Slug, r.Slug != "" }
	default:
		return nil, fmt.Errorf("attribute `%s` is not filterable", attr.text)
	}
	eq := func(r dictRow, want string) bool {
		got, ok := field(r)
		return ok && strings.EqualFold(got, want)
	}
	negate := p.keyword("NOT")
	var pred func(dictRow) bool
	switch {
	case p.keyword("IN"):
		list, err := p.list()
		if err != nil {
			return nil, err
		}
		pred = func(r dictRow) bool {
			for _, v := range list {
				if eq(r, v) {
					return true
				}
			}
			return false
		}
	case p.keyword("EXISTS"):
		pred = func(r dictRow) bool { _, ok := field(r); return ok }
	case !negate && p.keyword("IS"):
		negate = p.keyword("NOT")
		if !p.keyword("NULL") && !p.keyword("EMPTY") {
			return nil, fmt.Errorf("IS must be followed by NULL or EMPTY")
		}
		pred = func(r dictRow) bool { _, ok := field(r); return !ok }
	case !negate:
		op, err := p.next()
		if err != nil {
			return nil, err
		}
		val, err := p.next()
		if err != nil {
			return nil, err
		}
		switch op.text {
		case "=":
			pred = func(r dictRow) bool { return eq(r, val.text) }
		case "!=":
			pred = func(r dictRow) bool { return !eq(r, val.text) }
		default:
			return nil, fmt.Errorf("operator %q needs a number", op.text)
		}
	default:
		return nil, fmt.Errorf("NOT must be followed by IN or EXISTS")
	}
	if negate {
		inner := pred
		pred = func(r dictRow) bool { return !inner(r) }
	}
	return pred, nil
}

func (p *filterParser) list() ([]string, error) {
	if tok, err := p.next(); err != nil || tok.text != "[" {
		return nil, fmt.Errorf("IN needs a [list]")
	}
	var out []string
	for {
		tok, err := p.next()
		if err != nil {
			return nil, err
		}
		if !tok.quoted && tok.text == "]" {
			return out, nil
		}
		if !tok.quoted && tok.text == "," {
			continue
		}
		out = append(out, tok.text)
	}
}

// suggestApp serves the real suggest handler from the real service, which reads the
// dictionary through the real engine client, and loads its phrases first the way
// the server does at boot.
func suggestApp(t *testing.T, rows []dictRow) *fiber.App {
	t.Helper()
	srv := dictionaryServer(t, rows)
	svc := suggest.New(suggest.NewIndex(search.NewClient(srv.URL, "verify-key")))
	if err := svc.Refresh(context.Background()); err != nil {
		t.Fatalf("loading the dictionary's phrases: %v", err)
	}
	app := fiber.New(fiber.Config{ErrorHandler: RenderError})
	app.Get("/suggest", (&suggestHandlers{suggest: svc}).Suggest)
	return app
}

// offered lists each returned row as its parts, "kind:slug" joined by "+".
func offered(t *testing.T, body map[string]any) []string {
	t.Helper()
	data, ok := body["data"].([]any)
	if !ok {
		t.Fatalf("data = %v, want a list", body["data"])
	}
	out := []string{}
	for _, item := range data {
		m, _ := item.(map[string]any)
		parts, _ := m["parts"].([]any)
		var names []string
		for _, part := range parts {
			pm, _ := part.(map[string]any)
			kind, _ := pm["kind"].(string)
			slug, _ := pm["slug"].(string)
			names = append(names, kind+":"+slug)
		}
		out = append(out, strings.Join(names, "+"))
	}
	sort.Strings(out)
	return out
}

// The dictionary is rebuilt on its own schedule, so for a while after the change it
// still holds rows of the discontinued kind. The endpoint offers none of them, as a
// completion or as a phrase it recognized in what was typed, and still offers and
// recognizes everything else.
func TestSuggestPassesOverLeftoverDiscontinuedRows(t *testing.T) {
	cases := []struct {
		name  string
		rows  []dictRow
		query string
		want  []string
	}{
		{
			name: "completions skip leftover rows",
			rows: []dictRow{
				dictEntry("role", "senior_data_engineer", "Senior Data Engineer", 900, 500),
				dictEntry("role", "data_engineer", "Data Engineer", 1200, 400),
				dictEntry("category", "data_engineering", "Data Engineering", 800, 60),
				dictEntry("title", "", "Data Engineer Intern", 70, 30),
				dictEntry("skill", "dbt", "dbt", 50, 5),
			},
			query: "data eng",
			want:  []string{"category:data_engineering", "title:"},
		},
		{
			name: "a typed name of a leftover row is not read as one",
			rows: []dictRow{
				dictEntry("role", "backend_developer", "Backend Developer", 2000, 700),
				dictEntry("title", "", "Golang Backend Developer", 90, 40),
				dictEntry("skill", "golang", "Golang", 300, 20),
			},
			query: "backend developer gol",
			want:  []string{"title:"},
		},
		{
			name: "a live phrase that shares its text with a leftover row is still recognized",
			rows: []dictRow{
				dictEntry("role", "frontend", "Frontend Engineer", 1500, 600),
				dictEntry("category", "frontend", "Frontend Engineer", 700, 90),
				dictEntry("skill", "react", "React", 400, 50),
				dictEntry("company", "reactor_labs", "Reactor Labs", 30, 2),
			},
			query: "frontend engineer rea",
			want:  []string{"category:frontend+company:reactor_labs", "category:frontend+skill:react"},
		},
		{
			name: "only leftover rows match",
			rows: []dictRow{
				dictEntry("role", "product_owner", "Product Owner", 800, 300),
				dictEntry("category", "product", "Product Management", 900, 100),
			},
			query: "product own",
			want:  []string{},
		},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			app := suggestApp(t, tc.rows)
			body := getJSON(t, app, "/suggest?limit=10&q="+url.QueryEscape(tc.query))
			got := offered(t, body)
			if strings.Join(got, " | ") != strings.Join(tc.want, " | ") {
				t.Errorf("/suggest?q=%s offered %v, want %v", tc.query, got, tc.want)
			}
		})
	}
}
