package search

// Behavioral checks on the core search package: the query-filter builder, the
// unknown-param reporter, the index settings, and the indexed document shape.
//
// This file owns TestMain so it is the only test compiled into the package: it
// leans only on production symbols and inlines every helper it needs, so it is
// self-contained and never clashes with a sibling test file's helper names.

import (
	"encoding/json"
	"net/url"
	"os"
	"reflect"
	"testing"

	"github.com/strelov1/freehire/internal/platform/db"
)

func TestMain(m *testing.M) {
	os.Exit(m.Run())
}

// vals parses a raw query string the way an HTTP request would.
func vals(q string) url.Values {
	v, err := url.ParseQuery(q)
	if err != nil {
		panic(err)
	}
	return v
}

// groups coerces a built filter to its group form. A nil filter (nothing to
// constrain) comes back as an empty slice.
func groups(t *testing.T, f any) [][]string {
	t.Helper()
	if f == nil {
		return nil
	}
	g, ok := f.([][]string)
	if !ok {
		t.Fatalf("filter has unexpected shape %#v", f)
	}
	return g
}

// hasFragment reports whether any group carries the exact fragment.
func hasFragment(gs [][]string, frag string) bool {
	for _, g := range gs {
		for _, f := range g {
			if f == frag {
				return true
			}
		}
	}
	return false
}

// paramReported reports whether name appears in the ignored-param report, and
// the did-you-mean string it carried.
func paramReported(rep []UnknownParam, name string) (bool, string) {
	for _, p := range rep {
		if p.Param == name {
			return true, p.DidYouMean
		}
	}
	return false, ""
}

// A request carrying the discontinued filter builds exactly the filter the same
// request builds without it: nothing on its own, and only the live filter when
// one rides along. No roles constraint, and no stand-in constraint either.
func TestDiscontinuedFilterBuildsNoGroup(t *testing.T) {
	for _, c := range []struct{ withRole, without string }{
		{"role=senior_backend", ""},
		{"role_exclude=senior_backend", ""},
		{"role=staff_data_engineering&role_mode=and", ""},
	} {
		got, want := FilterFromValues(vals(c.withRole)), FilterFromValues(vals(c.without))
		if !reflect.DeepEqual(got, want) {
			t.Errorf("%q built %#v, want the same filter as %q: %#v", c.withRole, got, c.without, want)
		}
	}
}

// The discontinued filter sent beside a live one does not take the live one
// down with it and adds nothing of its own.
func TestDiscontinuedFilterLeavesLiveFacetStanding(t *testing.T) {
	for _, c := range []struct {
		withRole, without string
		live              []string
	}{
		{"role=senior_backend&regions=eu", "regions=eu", []string{`regions = "eu"`}},
		{"role=lead_devops&role_exclude=junior_qa&regions=latam", "regions=latam", []string{`regions = "latam"`}},
		{
			"role=senior_backend&category=backend&seniority=senior", "category=backend&seniority=senior",
			[]string{`enrichment.category = "backend"`, `enrichment.seniority = "senior"`},
		},
	} {
		got := FilterFromValues(vals(c.withRole))
		if want := FilterFromValues(vals(c.without)); !reflect.DeepEqual(got, want) {
			t.Errorf("%q built %#v, want the same filter as %q: %#v", c.withRole, got, c.without, want)
		}
		for _, live := range c.live {
			if !hasFragment(groups(t, got), live) {
				t.Errorf("%q lost the live group %s: %#v", c.withRole, live, got)
			}
		}
	}
}

// The discontinued params are surfaced as ignored, with no near-miss guess, so a
// stale saved search can see the filter went away rather than be quietly widened.
func TestDiscontinuedParamsReportedIgnored(t *testing.T) {
	rep := UnknownParams(vals("role=senior_backend&role_exclude=x&role_mode=and"), nil)
	for _, name := range []string{"role", "role_exclude", "role_mode"} {
		seen, didYouMean := paramReported(rep, name)
		if !seen {
			t.Errorf("%q was not reported as ignored: %#v", name, rep)
			continue
		}
		if didYouMean != "" {
			t.Errorf("%q carried a did-you-mean %q, want none", name, didYouMean)
		}
	}
}

// The separate people-management filter and its modifiers are a different facet
// and survive untouched: none of them is reported as ignored.
func TestPeopleManagementParamsSurvive(t *testing.T) {
	rep := UnknownParams(vals("role_type=people_manager&role_type_exclude=x&role_type_mode=and"), nil)
	for _, name := range []string{"role_type", "role_type_exclude", "role_type_mode"} {
		if seen, _ := paramReported(rep, name); seen {
			t.Errorf("%q was wrongly reported as ignored: %#v", name, rep)
		}
	}
}

// The index attribute behind the discontinued facet is no longer declared
// filterable, while the people-management attribute still is.
func TestSettingsDropFilterableAttribute(t *testing.T) {
	attrs := facetSettings().FilterableAttributes
	for _, a := range attrs {
		if a == "roles" {
			t.Errorf("settings still declare roles filterable: %v", attrs)
		}
	}
	survived := false
	for _, a := range attrs {
		if a == "role_type" {
			survived = true
		}
	}
	if !survived {
		t.Errorf("people-management attribute lost its filterable declaration: %v", attrs)
	}
}

// A built document no longer carries the derived top-level roles array, so a
// reindex drops it from live documents; the axes it decomposed into stay.
func TestDocumentDropsDerivedArray(t *testing.T) {
	doc, err := FromJob(db.Job{ID: 1, PublicSlug: "s", Seniority: "senior", Category: "backend", Title: "Senior Backend Engineer"})
	if err != nil {
		t.Fatalf("FromJob: %v", err)
	}
	raw, err := json.Marshal(doc)
	if err != nil {
		t.Fatalf("marshal: %v", err)
	}
	var full map[string]json.RawMessage
	if err := json.Unmarshal(raw, &full); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}
	if _, ok := full["roles"]; ok {
		t.Errorf("document still carries a top-level roles field: %s", raw)
	}
	if _, ok := full["enrichment"]; !ok {
		t.Errorf("document lost enrichment, where the replacing axes live: %s", raw)
	}
}
