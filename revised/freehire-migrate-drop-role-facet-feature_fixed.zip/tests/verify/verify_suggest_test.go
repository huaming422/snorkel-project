package suggest

// Behavioral check on the suggestions builder: it still offers the
// specialization kind for every category it is given a count for.
//
// This file owns TestMain so it is the only test compiled into the package. It
// drives the stable Build interface only.

import (
	"os"
	"testing"
)

func TestMain(m *testing.M) {
	os.Exit(m.Run())
}

// The builder offers every specialization it is given a count for.
func TestBuilderOffersSpecializations(t *testing.T) {
	docs := Build(Input{
		Categories: map[string]int{"backend": 40769, "data_engineering": 900},
		Skills:     map[string]int{"go": 120},
	})
	var specializations []string
	for _, d := range docs {
		if d.Kind == KindCategory {
			specializations = append(specializations, d.Slug)
		}
	}
	if len(specializations) != 2 {
		t.Errorf("specializations offered = %v, want both", specializations)
	}
}
