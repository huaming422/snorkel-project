package searchintent

// Behavioral check on the AI-intent layer: an intent that names the discontinued
// facet never resolves to a role value, while the two surviving axes still
// resolve to their values.
//
// This file owns TestMain so it is the only test compiled into the package. It
// drives resolve() through the package's intent value, and through a model reply
// decoded the way the interpreter decodes one, and asserts only on returned
// errors and values.

import (
	"encoding/json"
	"os"
	"testing"
)

func TestMain(m *testing.M) {
	os.Exit(m.Run())
}

// An intent that names the discontinued facet next to a surviving one either is
// refused with an error or resolves with no role value; when it resolves, the
// surviving facet keeps its value.
func TestResolveNeverServesDiscontinuedFacet(t *testing.T) {
	for _, value := range []string{"senior_backend", "staff_data_engineering"} {
		res, err := intent{Facets: map[string][]string{
			"role":     {value},
			"category": {"frontend"},
		}}.resolve()
		if err != nil {
			continue
		}
		if got := res.Facets["role"]; len(got) != 0 {
			t.Errorf("role %q resolved to %v, want no role value", value, got)
		}
		if got := res.Facets["category"]; len(got) != 1 || got[0] != "frontend" {
			t.Errorf("category beside role %q resolved to %v, want [frontend]", value, got)
		}
	}
}

// The two surviving axes still resolve to their canonical values.
func TestResolveKeepsSurvivingAxes(t *testing.T) {
	res, err := intent{Facets: map[string][]string{
		"category":  {"backend"},
		"seniority": {"senior"},
	}}.resolve()
	if err != nil {
		t.Fatalf("resolve rejected the surviving axes: %v", err)
	}
	if got := res.Facets["category"]; len(got) != 1 || got[0] != "backend" {
		t.Errorf("category resolved to %v, want [backend]", got)
	}
	if got := res.Facets["seniority"]; len(got) != 1 || got[0] != "senior" {
		t.Errorf("seniority resolved to %v, want [senior]", got)
	}
}

// A model reply is decoded and resolved the way the interpreter does it. A plain
// reply naming the two surviving axes resolves to them; a reply that still
// carries a role field is either refused or resolves with no role value.
func TestModelReplyResolvesWithoutRole(t *testing.T) {
	var plain proposal
	if err := json.Unmarshal([]byte(`{"summary":"s","category":["data_engineering"],"seniority":["staff"]}`), &plain); err != nil {
		t.Fatalf("decode plain reply: %v", err)
	}
	res, err := plain.intent().resolve()
	if err != nil {
		t.Fatalf("a reply naming only category and seniority was refused: %v", err)
	}
	if got := res.Facets["category"]; len(got) != 1 || got[0] != "data_engineering" {
		t.Errorf("category resolved to %v, want [data_engineering]", got)
	}
	if got := res.Facets["seniority"]; len(got) != 1 || got[0] != "staff" {
		t.Errorf("seniority resolved to %v, want [staff]", got)
	}

	var stale proposal
	if err := json.Unmarshal([]byte(`{"summary":"s","category":["backend"],"role":["senior_backend"]}`), &stale); err != nil {
		t.Fatalf("decode reply with role: %v", err)
	}
	if res, err := stale.intent().resolve(); err == nil {
		if got := res.Facets["role"]; len(got) != 0 {
			t.Errorf("a reply carrying role resolved to role %v, want none", got)
		}
	}
}
