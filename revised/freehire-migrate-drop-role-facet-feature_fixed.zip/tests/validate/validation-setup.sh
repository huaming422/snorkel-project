#!/usr/bin/env bash
#
# Validation environment setup. Runs after tests/test-setup.sh and layers on
# what the go-test validation driver needs. The stories drive the facets handler
# entirely in-memory (an in-process app plus a do-nothing counts double), so no
# server, database, or search engine has to come up. This only has to make the
# Go toolchain deterministic and offline, in case an earlier step wiped the
# image-time environment. IDEMPOTENT: may be sourced multiple times.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/freehire}"
cd "$REPO_DIR"

# Deterministic, offline-first Go environment. The image warmed the module cache
# and compiled the test binaries at the base commit; the driver builds and runs
# the focused package test with the network cut.
export GOFLAGS="-mod=mod"
export GOPROXY="${GOPROXY:-off}"
export CGO_ENABLED="1"
export GOTOOLCHAIN="local"
export GOMODCACHE="${GOMODCACHE:-/opt/cache/go}"
export GOCACHE="${GOCACHE:-/home/dev/.cache/go-build}"
mkdir -p "$GOCACHE"

# Thread caps (mirror the image ENV in case the shell didn't inherit them).
export GOMAXPROCS="${GOMAXPROCS:-4}"
export OMP_THREAD_LIMIT="${OMP_THREAD_LIMIT:-4}"

# Make `go` resolvable even if the harness scrubbed PATH.
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:$PATH ;;
esac

# Belt-and-suspenders module check against the warm cache; GOPROXY=off keeps it
# offline-first (a no-op on the image's warm cache). Harmless (returns success)
# if anything is missing; the focused package build is what actually gates.
GOPROXY=off GOFLAGS=-mod=mod go mod download 2>/dev/null || true

echo "validation-setup.sh: ready (go $(go version 2>/dev/null | awk '{print $3}'), GOPROXY=$GOPROXY, GOMODCACHE=$GOMODCACHE)"
