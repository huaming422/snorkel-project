## Task

Since we moved to a newer DataFusion main build, several of our custom functions plan with the wrong output type.
They pick their output type from constant arguments, the way `round(x, 2)` uses the `2`.
One of them declares that its second argument is coerced to Int16, and when we call `my_udf(x, 2)` it now acts as if the `2` were a column, or as if it were still an Int64 that it doesn't accept.
`my_udf(x, NULL)` gets the same treatment.

Our lambda-taking functions broke the same way.
`my_fold(arr, x -> x * 1.5, 0)` asks for its fallback value to be coerced to whatever the lambda returns, and it no longer sees the `0` as the Float64 0.0 it expects.

A couple of weeks ago this all worked.
Whenever the planner asked one of these functions for its output type, it saw a literal as the value the caller wrote, already in the type its signature asked for, and NULL as a null of that type.
Columns and lambdas were never treated as constants, and that part still looks fine.
We'd like the old behavior back for any function with a coercing signature, not only ours.

One thing should stay exactly as it is.
`select my_udf(2147483648)` against an Int32 argument plans fine today, so EXPLAIN works, and it only errors when the query runs.
