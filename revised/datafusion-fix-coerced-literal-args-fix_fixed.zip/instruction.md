## Task

Since we moved to a newer DataFusion main build, several of our custom functions plan with the wrong output type.
They size their result from a constant argument, the way `round(x, 2)` uses the `2`.
One of them declares that its second argument is coerced to Int16, and `my_udf(x, 2)` now plans as if it couldn't read the `2` at all.
`my_udf(x, NULL)` has the same problem.

Our lambda-taking functions broke too.
`my_fold(arr, x -> x * 1.5, 0)` coerces its fallback value to whatever the lambda returns, and it can no longer make sense of the `0`.

This worked a couple of weeks ago, and it seems to hit any function with a coercing signature, not just ours.
Please get these calls planning correctly again, without changing what other queries return or which ones fail.
