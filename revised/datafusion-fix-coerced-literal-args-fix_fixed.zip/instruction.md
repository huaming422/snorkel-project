## Task

After we moved to a newer DataFusion main build, some of our UDFs plan with the wrong result type.
`select my_round(price, 2) from sales` used to give a Decimal128(10, 2) column.
It now gives Decimal128(38, 10), which is what `my_round` returns when it has no scale to work with.

Our `my_fold` function broke at the same time.
`select my_fold(prices, p -> p * 1.5, 0) from sales` used to plan as Float64.
Now planning fails with our own "fallback does not match the lambda result" error.

Both queries worked a couple of weeks ago, and nothing changed on our side.
