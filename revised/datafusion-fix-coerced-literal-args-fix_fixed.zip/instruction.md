## Task

After we moved to a newer DataFusion main build, some of our UDFs plan with the wrong result type.
`select my_round(price, 2) from sales` used to give a Decimal128(10, 2) column.
It now gives Decimal128(38, 10), which is what `my_round` returns when it has no scale to work with.

Our `my_fold` function broke at the same time.
`select my_fold(prices, p -> p * 1.5, 0) from sales` used to plan as Float64.
Now planning fails with our own "fallback does not match the lambda result" error.

Both functions decide their return type in `return_field_from_args`, from the argument fields and the constant arguments they are handed there.
This is what our code depends on, and it all held before the upgrade:

- A literal argument comes through as a constant of the type our signature asks for, the same type as that argument's field.
- The constant keeps the value the caller wrote, so `my_round`'s scale `2` should be an Int32 2.
- Negative numbers and values at the very ends of the type's range keep their exact value too.
- A `NULL` literal comes through as a null of the signature's type, not as a missing constant.
- A column, or anything else that isn't a literal, is never reported as a constant, even when the same call also has literal arguments.
- Lambda functions like `my_fold` get the same treatment for their value arguments.
- `my_fold` wants its fallback in whatever type the lambda returns, so the `0` above should arrive as a Float64 0.0.
- This applies wherever the call sits, including a UDF called inside a lambda body.

One thing must not change.
A literal that can't fit the type the signature asks for, like 2147483648 for an Int32 argument, still has to make the query fail.
We don't care whether that error shows up while planning or when the query runs, but quietly turning it into some value that fits is not OK.

Both queries worked a couple of weeks ago, and nothing changed on our side.
