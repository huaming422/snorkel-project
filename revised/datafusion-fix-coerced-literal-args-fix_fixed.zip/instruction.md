## Task

Our custom scalar functions on DataFusion have started getting bad constant-argument information when they resolve a call's return type.
Take a function whose signature coerces a numeric argument down to Int16 and call it with a plain literal, for example `my_udf(1)` or `my_udf(x, 2)`.
Inside `return_field_from_args` we expect an Int16 constant for that argument, since that is what we declared, and we used to get one.
Now the slot is either empty, as if we had passed a column, or it holds something our Int16 match arm rejects.
Passing NULL in that position comes back as missing too.
Anything that sizes its output from a constant, the way `round(x, 2)` reads the `2`, is guessing now.

Our higher-order functions, the ones that take a lambda next to ordinary arguments, show the same thing.
One of them takes a fallback value after the lambda, as in `my_fold(arr, x -> x * 1.5, 0)`, and asks for that value to be coerced to whatever the lambda returns.
Its hook should see the `0` as a Float64 constant, but it gets the same bad slot.
This worked on the main build we were on a couple of weeks ago, and it seems to hit any function with a coercing signature, not just ours.

At minimum, a plain literal, NULL included, needs to reach the function as a constant of the type the argument was coerced to, still holding the value the caller wrote, every time the planner asks for the return field.
Columns and lambdas stay non-constant, and a literal that can't fit the narrower type, say 2147483648 for an Int32 argument, must not stop the query from planning.
It should keep failing when the query runs, as it does today.
Otherwise, these calls should plan, run, and fail the same way they do now.
