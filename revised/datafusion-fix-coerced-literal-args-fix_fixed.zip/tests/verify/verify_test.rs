// Integration test for datafusion-fix-coerced-literal-args.
//
// The rust runner copies this file into datafusion/core/tests/ and runs
//   cargo test --test verify_test --manifest-path=datafusion/core/Cargo.toml
// (package name `datafusion`). Every test plans and runs a query through a real
// SessionContext, so the type coercion analyzer pass runs, and reads the
// per-argument constant metadata from inside a custom ScalarUDFImpl's or
// HigherOrderUDFImpl's return-field hook.
//
// Only public API that exists at the base commit is used. The tests look at the
// values handed to the return-field hook and at the SQL-level outcome. They do
// not care where in the planning pipeline those values were produced.

use std::sync::Arc;

use arrow::array::{Array, Int16Array, ListArray, RecordBatch};
use arrow::datatypes::{DataType, Field, FieldRef, Int32Type, Schema};

use datafusion::prelude::{SessionConfig, SessionContext, col, lit};

use datafusion_common::types::{NativeType, logical_int16, logical_int32};
use datafusion_common::{Result, ScalarValue, assert_contains};
use datafusion_expr::{
    ColumnarValue, HigherOrderFunctionArgs, HigherOrderReturnFieldArgs,
    HigherOrderSignature, HigherOrderUDF, HigherOrderUDFImpl, LambdaParametersProgress,
    ReturnFieldArgs, ScalarFunctionArgs, ScalarUDF, ScalarUDFImpl, Signature,
    TypeSignatureClass, ValueOrLambda, Volatility,
};
use datafusion_expr_common::signature::Coercion;

/// What the custom function expects of one constant-argument slot each time
/// its return field is resolved.
#[derive(Debug, PartialEq, Eq, Hash)]
enum ConstantExpectation {
    /// The slot holds exactly this value (value and nullness), and the
    /// resolved field has the value's type.
    TypedConstant(ScalarValue),
    /// The slot is empty because the argument is not a constant.
    Absent,
    /// No claim about the slot. Used where the slot legitimately differs
    /// between planning stages, such as a literal whose value cannot take the
    /// coerced type and is therefore carried as an expression.
    Unchecked,
}

/// A custom scalar function with a coercible signature. Its return-field hook
/// compares every constant-argument slot with the matching resolved field and
/// panics on a mismatch, which fails the planning call and with it the test.
#[derive(Debug, PartialEq, Eq, Hash)]
struct ContractUdf {
    name: &'static str,
    expectations: Vec<ConstantExpectation>,
    signature: Signature,
}

impl ContractUdf {
    fn new(name: &'static str, args: Vec<(Coercion, ConstantExpectation)>) -> Self {
        let (coercions, expectations): (Vec<_>, Vec<_>) = args.into_iter().unzip();
        Self {
            name,
            expectations,
            signature: Signature::coercible(coercions, Volatility::Immutable),
        }
    }

    /// Any numeric input is coerced to Int16.
    fn narrow_to_int16() -> Coercion {
        Coercion::new_implicit(
            TypeSignatureClass::Native(logical_int16()),
            vec![TypeSignatureClass::Numeric],
            NativeType::Int16,
        )
    }

    /// Any numeric input is coerced to Int32.
    fn narrow_to_int32() -> Coercion {
        Coercion::new_implicit(
            TypeSignatureClass::Native(logical_int32()),
            vec![TypeSignatureClass::Numeric],
            NativeType::Int32,
        )
    }
}

impl ScalarUDFImpl for ContractUdf {
    fn name(&self) -> &str {
        self.name
    }

    fn signature(&self) -> &Signature {
        &self.signature
    }

    fn return_type(&self, _arg_types: &[DataType]) -> Result<DataType> {
        // return_field_from_args is implemented, so this path is never taken.
        unreachable!("return_field_from_args is implemented for {}", self.name)
    }

    fn return_field_from_args(&self, args: ReturnFieldArgs) -> Result<FieldRef> {
        assert_eq!(
            args.arg_fields.len(),
            self.expectations.len(),
            "{}: unexpected number of argument fields",
            self.name
        );
        assert_eq!(
            args.scalar_arguments.len(),
            self.expectations.len(),
            "{}: unexpected number of constant-argument slots",
            self.name
        );

        for (i, expectation) in self.expectations.iter().enumerate() {
            let field_type = args.arg_fields[i].data_type();
            match expectation {
                ConstantExpectation::TypedConstant(expected) => {
                    assert_eq!(
                        field_type,
                        &expected.data_type(),
                        "{}: argument {i} resolved to an unexpected field type",
                        self.name
                    );
                    let scalar = args.scalar_arguments[i].unwrap_or_else(|| {
                        panic!(
                            "{}: argument {i} is a plain literal but was reported as \
                             not a constant",
                            self.name
                        )
                    });
                    assert_eq!(
                        &scalar.data_type(),
                        field_type,
                        "{}: the constant for argument {i} does not have the resolved \
                         field type",
                        self.name
                    );
                    assert_eq!(
                        scalar, expected,
                        "{}: the constant for argument {i} does not hold the value the \
                         caller wrote",
                        self.name
                    );
                }
                ConstantExpectation::Absent => {
                    assert!(
                        args.scalar_arguments[i].is_none(),
                        "{}: argument {i} is not a literal but was reported as a \
                         constant",
                        self.name
                    );
                }
                ConstantExpectation::Unchecked => {}
            }
        }

        Ok(Field::new(self.name, args.arg_fields[0].data_type().clone(), true).into())
    }

    fn invoke_with_args(&self, args: ScalarFunctionArgs) -> Result<ColumnarValue> {
        Ok(args.args[0].clone())
    }
}

/// Registers a one-argument function with the given coercion and expectation
/// on a fresh context, then plans and runs `sql`.
async fn plan_and_collect_single(
    name: &'static str,
    coercion: Coercion,
    expectation: ConstantExpectation,
    sql: &str,
) -> Result<()> {
    let ctx = SessionContext::new();
    let udf: ScalarUDF = ContractUdf::new(name, vec![(coercion, expectation)]).into();
    ctx.register_udf(udf);

    ctx.sql(sql).await?.collect().await?;

    Ok(())
}

/// A plain integer literal passed where the signature coerces that argument to
/// a narrower integer type arrives at the return-field hook as a present
/// constant of the coerced field type (Int16 here) holding the value the caller
/// wrote, at every point in planning where the hook runs.
#[tokio::test]
async fn literal_matches_coerced_field() -> Result<()> {
    plan_and_collect_single(
        "literal_match_udf",
        ContractUdf::narrow_to_int16(),
        ConstantExpectation::TypedConstant(ScalarValue::Int16(Some(1))),
        "select literal_match_udf(1)",
    )
    .await?;

    plan_and_collect_single(
        "zero_literal_udf",
        ContractUdf::narrow_to_int16(),
        ConstantExpectation::TypedConstant(ScalarValue::Int16(Some(0))),
        "select zero_literal_udf(0)",
    )
    .await
}

/// Negative literals and literals at the edges of the coerced type's range keep
/// their exact value. No truncation, wrapping or placeholder value is accepted.
#[tokio::test]
async fn negative_and_boundary_literals_keep_their_value() -> Result<()> {
    let cases = [
        (
            "negative_literal_udf",
            ContractUdf::narrow_to_int16(),
            ScalarValue::Int16(Some(-5)),
            "select negative_literal_udf(-5)",
        ),
        (
            "int16_max_literal_udf",
            ContractUdf::narrow_to_int16(),
            ScalarValue::Int16(Some(i16::MAX)),
            "select int16_max_literal_udf(32767)",
        ),
        (
            "int16_min_literal_udf",
            ContractUdf::narrow_to_int16(),
            ScalarValue::Int16(Some(i16::MIN)),
            "select int16_min_literal_udf(-32768)",
        ),
        (
            "int32_max_literal_udf",
            ContractUdf::narrow_to_int32(),
            ScalarValue::Int32(Some(i32::MAX)),
            "select int32_max_literal_udf(2147483647)",
        ),
    ];

    for (name, coercion, expected, sql) in cases {
        plan_and_collect_single(
            name,
            coercion,
            ConstantExpectation::TypedConstant(expected),
            sql,
        )
        .await?;
    }

    Ok(())
}

/// A NULL literal passed to a coercing argument arrives as a present null of
/// the coerced type. An untyped null, a non-null value or an empty slot is a
/// failure.
#[tokio::test]
async fn typed_null_matches_coerced_field() -> Result<()> {
    plan_and_collect_single(
        "typed_null_udf",
        ContractUdf::narrow_to_int16(),
        ConstantExpectation::TypedConstant(ScalarValue::Int16(None)),
        "select typed_null_udf(NULL)",
    )
    .await
}

/// A call that mixes a column with a literal keeps each slot matched to its
/// argument position. The column slot stays empty. The literal slot holds a
/// constant of the coerced type (Int32 here) with the literal's value.
///
/// The call is built with the DataFrame API, and `lit(2_i64)` starts out as an
/// Int64 value, like a SQL integer literal does.
#[tokio::test]
async fn mixed_column_and_literal_arguments() -> Result<()> {
    let ctx = SessionContext::new();
    let udf: ScalarUDF = ContractUdf::new(
        "mixed_args_udf",
        vec![
            (
                Coercion::new_exact(TypeSignatureClass::Numeric),
                ConstantExpectation::Absent,
            ),
            (
                ContractUdf::narrow_to_int32(),
                ConstantExpectation::TypedConstant(ScalarValue::Int32(Some(2))),
            ),
        ],
    )
    .into();
    let udf_clone = udf.clone();
    ctx.register_udf(udf);

    let batch = RecordBatch::try_new(
        Arc::new(Schema::new(vec![Field::new("a", DataType::Int16, false)])),
        vec![Arc::new(Int16Array::from(vec![1_i16, 2, 3]))],
    )?;
    ctx.read_batch(batch)?
        .select(vec![udf_clone.call(vec![col("a"), lit(2_i64)])])?
        .collect()
        .await?;

    Ok(())
}

/// Regression guard for an existing function that depends on the constant
/// slots. arrow_cast reads its type argument from the constant slot, and a type
/// argument written as a cast expression instead of a string literal is
/// rejected with an error naming the "second argument". That has to stay the
/// case, whether the error comes from building the logical plan or later.
#[tokio::test]
async fn arrow_cast_requires_literal_type_arg() -> Result<()> {
    let ctx = SessionContext::new();

    let planned = ctx
        .sql("select arrow_cast(1, cast('Utf8' as varchar))")
        .await;
    let outcome = match planned {
        Err(e) => Err(e),
        Ok(df) => df.collect().await,
    };

    let err = outcome.expect_err(
        "a cast type argument to arrow_cast must not be accepted as a constant",
    );
    assert_contains!(err.to_string(), "second argument");

    Ok(())
}

/// A literal whose value cannot take the coerced type (2147483648 where the
/// signature wants Int32) still makes the query fail. The error may come from
/// planning or from running the query, but the value must not be folded into
/// something that lets the query succeed.
#[tokio::test]
async fn invalid_literal_value_preserved() -> Result<()> {
    let ctx = SessionContext::new();
    let udf: ScalarUDF = ContractUdf::new(
        "overflow_literal_udf",
        vec![(
            ContractUdf::narrow_to_int32(),
            ConstantExpectation::Unchecked,
        )],
    )
    .into();
    ctx.register_udf(udf);

    // 2147483648 == i32::MAX + 1: a valid Int64 literal that cannot take Int32.
    let outcome = match ctx.sql("select overflow_literal_udf(2147483648)").await {
        Err(e) => Err(e),
        Ok(df) => df.collect().await,
    };

    assert!(
        outcome.is_err(),
        "an out-of-range literal must still make the query fail, not be folded to a \
         value that fits"
    );

    Ok(())
}

/// Where a higher-order function wants its trailing value argument coerced.
#[derive(Debug, PartialEq, Eq, Hash, Clone, Copy)]
enum FallbackTarget {
    /// Always Int16, decided from the value argument types alone.
    Int16,
    /// Whatever type the lambda returns, decided once the lambda's output
    /// field is known.
    LambdaOutput,
}

/// A custom higher-order function shaped like `f(list, x -> ..., fallback)`.
/// Its return-field hook checks the constant slot of the fallback value the
/// same way ContractUdf does, and expects the list and lambda slots to be
/// empty.
#[derive(Debug, PartialEq, Eq, Hash)]
struct ContractHof {
    name: &'static str,
    fallback: ConstantExpectation,
    target: FallbackTarget,
    signature: HigherOrderSignature,
}

impl ContractHof {
    fn new(
        name: &'static str,
        target: FallbackTarget,
        fallback: ConstantExpectation,
    ) -> Self {
        Self {
            name,
            fallback,
            target,
            signature: HigherOrderSignature::exact(
                vec![
                    ValueOrLambda::Value(()),
                    ValueOrLambda::Lambda(()),
                    ValueOrLambda::Value(()),
                ],
                Volatility::Immutable,
            ),
        }
    }
}

impl HigherOrderUDFImpl for ContractHof {
    fn name(&self) -> &str {
        self.name
    }

    fn signature(&self) -> &HigherOrderSignature {
        &self.signature
    }

    fn lambda_parameters(
        &self,
        _step: usize,
        fields: &[ValueOrLambda<FieldRef, Option<FieldRef>>],
    ) -> Result<LambdaParametersProgress> {
        let ValueOrLambda::Value(list) = &fields[0] else {
            panic!("{}: the first argument must be a value", self.name)
        };
        let DataType::List(item) = list.data_type() else {
            panic!("{}: the first argument must be a list", self.name)
        };
        Ok(LambdaParametersProgress::Complete(vec![vec![Arc::clone(
            item,
        )]]))
    }

    fn coerce_value_types(&self, arg_types: &[DataType]) -> Result<Vec<DataType>> {
        let fallback = match self.target {
            FallbackTarget::Int16 => DataType::Int16,
            // Settled later by coerce_values_for_lambdas.
            FallbackTarget::LambdaOutput => arg_types[1].clone(),
        };
        Ok(vec![arg_types[0].clone(), fallback])
    }

    fn coerce_values_for_lambdas(
        &self,
        fields: &[ValueOrLambda<DataType, DataType>],
    ) -> Result<Option<Vec<DataType>>> {
        match (self.target, &fields[0], &fields[1]) {
            (FallbackTarget::Int16, _, _) => Ok(None),
            (
                FallbackTarget::LambdaOutput,
                ValueOrLambda::Value(list),
                ValueOrLambda::Lambda(lambda_output),
            ) => Ok(Some(vec![list.clone(), lambda_output.clone()])),
            _ => panic!("{}: unexpected argument kinds", self.name),
        }
    }

    fn return_field_from_args(
        &self,
        args: HigherOrderReturnFieldArgs,
    ) -> Result<FieldRef> {
        assert_eq!(
            args.arg_fields.len(),
            3,
            "{}: unexpected number of argument fields",
            self.name
        );
        assert_eq!(
            args.scalar_arguments.len(),
            3,
            "{}: unexpected number of constant-argument slots",
            self.name
        );
        assert!(
            args.scalar_arguments[0].is_none(),
            "{}: the list column was reported as a constant",
            self.name
        );
        assert!(
            args.scalar_arguments[1].is_none(),
            "{}: the lambda was reported as a constant",
            self.name
        );

        let ValueOrLambda::Value(fallback_field) = &args.arg_fields[2] else {
            panic!("{}: argument 2 resolved to a lambda field", self.name)
        };
        match &self.fallback {
            ConstantExpectation::TypedConstant(expected) => {
                assert_eq!(
                    fallback_field.data_type(),
                    &expected.data_type(),
                    "{}: argument 2 resolved to an unexpected field type",
                    self.name
                );
                let scalar = args.scalar_arguments[2].unwrap_or_else(|| {
                    panic!(
                        "{}: argument 2 is a plain literal but was reported as not a \
                         constant",
                        self.name
                    )
                });
                assert_eq!(
                    &scalar.data_type(),
                    fallback_field.data_type(),
                    "{}: the constant for argument 2 does not have the resolved field \
                     type",
                    self.name
                );
                assert_eq!(
                    scalar, expected,
                    "{}: the constant for argument 2 does not hold the value the caller \
                     wrote",
                    self.name
                );
            }
            ConstantExpectation::Absent => assert!(
                args.scalar_arguments[2].is_none(),
                "{}: argument 2 is not a literal but was reported as a constant",
                self.name
            ),
            ConstantExpectation::Unchecked => {}
        }

        let ValueOrLambda::Value(list) = &args.arg_fields[0] else {
            panic!("{}: argument 0 resolved to a lambda field", self.name)
        };
        Ok(Arc::clone(list))
    }

    fn invoke_with_args(&self, args: HigherOrderFunctionArgs) -> Result<ColumnarValue> {
        let ValueOrLambda::Value(list) = &args.args[0] else {
            panic!("{}: argument 0 evaluated to a lambda", self.name)
        };
        Ok(list.clone())
    }
}

/// A context that parses `x -> ...` as a lambda and has a table `t` with a
/// single `List<Int32>` column named `arr`.
fn lambda_context() -> Result<SessionContext> {
    let config =
        SessionConfig::new().set_str("datafusion.sql_parser.dialect", "databricks");
    let ctx = SessionContext::new_with_config(config);

    let arr = ListArray::from_iter_primitive::<Int32Type, _, _>(vec![
        Some(vec![Some(1), Some(2)]),
        Some(vec![Some(3)]),
    ]);
    let batch = RecordBatch::try_new(
        Arc::new(Schema::new(vec![Field::new(
            "arr",
            arr.data_type().clone(),
            true,
        )])),
        vec![Arc::new(arr)],
    )?;
    ctx.register_batch("t", batch)?;

    Ok(ctx)
}

/// Registers a ContractHof on a fresh lambda context, then plans and runs
/// `sql`.
async fn plan_and_collect_higher_order(
    name: &'static str,
    target: FallbackTarget,
    fallback: ConstantExpectation,
    sql: &str,
) -> Result<()> {
    let ctx = lambda_context()?;
    ctx.register_higher_order_function(Arc::new(HigherOrderUDF::new_from_impl(
        ContractHof::new(name, target, fallback),
    )));

    ctx.sql(sql).await?.collect().await?;

    Ok(())
}

/// A higher-order function gets the same guarantee as a scalar function. A
/// literal value argument that its signature coerces to Int16 arrives as an
/// Int16 constant holding the caller's value, while the list column and the
/// lambda slots stay empty.
#[tokio::test]
async fn higher_order_literal_matches_coerced_field() -> Result<()> {
    plan_and_collect_higher_order(
        "hof_int16_udf",
        FallbackTarget::Int16,
        ConstantExpectation::TypedConstant(ScalarValue::Int16(Some(2))),
        "select hof_int16_udf(arr, x -> x + 1, 2) from t",
    )
    .await?;

    plan_and_collect_higher_order(
        "hof_negative_udf",
        FallbackTarget::Int16,
        ConstantExpectation::TypedConstant(ScalarValue::Int16(Some(-7))),
        "select hof_negative_udf(arr, x -> x, -7) from t",
    )
    .await
}

/// When a higher-order function coerces a value argument to the type its
/// lambda returns, the constant follows that type. `x * 1.5` returns Float64,
/// so `0` must arrive as Float64 0.0 and NULL as a Float64 null. `x` alone
/// returns Int32, so `5` must arrive as Int32 5.
#[tokio::test]
async fn higher_order_literal_follows_lambda_output() -> Result<()> {
    let cases = [
        (
            "hof_float_udf",
            ScalarValue::Float64(Some(0.0)),
            "select hof_float_udf(arr, x -> x * 1.5, 0) from t",
        ),
        (
            "hof_null_udf",
            ScalarValue::Float64(None),
            "select hof_null_udf(arr, x -> x * 1.5, NULL) from t",
        ),
        (
            "hof_int32_udf",
            ScalarValue::Int32(Some(5)),
            "select hof_int32_udf(arr, x -> x, 5) from t",
        ),
    ];

    for (name, expected, sql) in cases {
        plan_and_collect_higher_order(
            name,
            FallbackTarget::LambdaOutput,
            ConstantExpectation::TypedConstant(expected),
            sql,
        )
        .await?;
    }

    Ok(())
}

/// A scalar function called inside a lambda body keeps the scalar guarantee.
/// Its literal argument arrives as a constant of the coerced type and the
/// lambda variable stays non-constant.
#[tokio::test]
async fn scalar_literal_inside_lambda_body() -> Result<()> {
    let ctx = lambda_context()?;
    ctx.register_higher_order_function(Arc::new(HigherOrderUDF::new_from_impl(
        ContractHof::new(
            "hof_outer_udf",
            FallbackTarget::Int16,
            ConstantExpectation::Unchecked,
        ),
    )));
    let udf: ScalarUDF = ContractUdf::new(
        "lambda_body_udf",
        vec![
            (
                Coercion::new_exact(TypeSignatureClass::Numeric),
                ConstantExpectation::Absent,
            ),
            (
                ContractUdf::narrow_to_int16(),
                ConstantExpectation::TypedConstant(ScalarValue::Int16(Some(3))),
            ),
        ],
    )
    .into();
    ctx.register_udf(udf);

    ctx.sql("select hof_outer_udf(arr, x -> lambda_body_udf(x, 3), 1) from t")
        .await?
        .collect()
        .await?;

    Ok(())
}

/// The out-of-range rule also holds for a higher-order function. 40000 cannot
/// take Int16, so the query still fails, during planning or when it runs.
#[tokio::test]
async fn higher_order_invalid_literal_value_preserved() -> Result<()> {
    let ctx = lambda_context()?;
    ctx.register_higher_order_function(Arc::new(HigherOrderUDF::new_from_impl(
        ContractHof::new(
            "hof_overflow_udf",
            FallbackTarget::Int16,
            ConstantExpectation::Unchecked,
        ),
    )));

    let outcome = match ctx
        .sql("select hof_overflow_udf(arr, x -> x, 40000) from t")
        .await
    {
        Err(e) => Err(e),
        Ok(df) => df.collect().await,
    };

    assert!(
        outcome.is_err(),
        "an out-of-range literal must still make the query fail, not be folded to a \
         value that fits"
    );

    Ok(())
}
