// Integration test for datafusion-fix-coerced-literal-args.
//
// The rust runner copies this file into datafusion/core/tests/ and runs
//   cargo test --test verify_test --manifest-path=datafusion/core/Cargo.toml
// (package name `datafusion`). Every test plans and runs a query through a real
// SessionContext, so the type coercion analyzer pass runs, and reads the
// per-argument constant metadata from inside a custom ScalarUDFImpl's
// return-field hook.
//
// Only public API that exists at the base commit is used. The tests look at the
// values handed to the return-field hook and at the SQL-level outcome. They do
// not care where in the planning pipeline those values were produced.

use std::sync::Arc;

use arrow::array::{Int16Array, RecordBatch};
use arrow::datatypes::{DataType, Field, FieldRef, Schema};

use datafusion::prelude::{SessionContext, col, lit};

use datafusion_common::types::{NativeType, logical_int16, logical_int32};
use datafusion_common::{Result, ScalarValue, assert_contains};
use datafusion_expr::{
    ColumnarValue, ReturnFieldArgs, ScalarFunctionArgs, ScalarUDF, ScalarUDFImpl,
    Signature, TypeSignatureClass, Volatility,
};
use datafusion_expr_common::signature::Coercion;

/// What the custom function expects of one constant-argument slot each time
/// its return field is resolved.
#[derive(Debug, PartialEq, Eq, Hash)]
enum ConstantExpectation {
    /// The slot holds exactly this value (value and nullness), and the
    /// resolved field has the value's type.
    TypedConstant(ScalarValue),
    /// The slot is empty because the argument is not a constant.
    Absent,
    /// No claim about the slot. Used where the slot legitimately differs
    /// between planning stages, such as a literal whose value cannot take the
    /// coerced type and is therefore carried as an expression.
    Unchecked,
}

/// A custom scalar function with a coercible signature. Its return-field hook
/// compares every constant-argument slot with the matching resolved field and
/// panics on a mismatch, which fails the planning call and with it the test.
#[derive(Debug, PartialEq, Eq, Hash)]
struct ContractUdf {
    name: &'static str,
    expectations: Vec<ConstantExpectation>,
    signature: Signature,
}

impl ContractUdf {
    fn new(name: &'static str, args: Vec<(Coercion, ConstantExpectation)>) -> Self {
        let (coercions, expectations): (Vec<_>, Vec<_>) = args.into_iter().unzip();
        Self {
            name,
            expectations,
            signature: Signature::coercible(coercions, Volatility::Immutable),
        }
    }

    /// Any numeric input is coerced to Int16.
    fn narrow_to_int16() -> Coercion {
        Coercion::new_implicit(
            TypeSignatureClass::Native(logical_int16()),
            vec![TypeSignatureClass::Numeric],
            NativeType::Int16,
        )
    }

    /// Any numeric input is coerced to Int32.
    fn narrow_to_int32() -> Coercion {
        Coercion::new_implicit(
            TypeSignatureClass::Native(logical_int32()),
            vec![TypeSignatureClass::Numeric],
            NativeType::Int32,
        )
    }
}

impl ScalarUDFImpl for ContractUdf {
    fn name(&self) -> &str {
        self.name
    }

    fn signature(&self) -> &Signature {
        &self.signature
    }

    fn return_type(&self, _arg_types: &[DataType]) -> Result<DataType> {
        // return_field_from_args is implemented, so this path is never taken.
        unreachable!("return_field_from_args is implemented for {}", self.name)
    }

    fn return_field_from_args(&self, args: ReturnFieldArgs) -> Result<FieldRef> {
        assert_eq!(
            args.arg_fields.len(),
            self.expectations.len(),
            "{}: unexpected number of argument fields",
            self.name
        );
        assert_eq!(
            args.scalar_arguments.len(),
            self.expectations.len(),
            "{}: unexpected number of constant-argument slots",
            self.name
        );

        for (i, expectation) in self.expectations.iter().enumerate() {
            let field_type = args.arg_fields[i].data_type();
            match expectation {
                ConstantExpectation::TypedConstant(expected) => {
                    assert_eq!(
                        field_type,
                        &expected.data_type(),
                        "{}: argument {i} resolved to an unexpected field type",
                        self.name
                    );
                    let scalar = args.scalar_arguments[i].unwrap_or_else(|| {
                        panic!(
                            "{}: argument {i} is a plain literal but was reported as \
                             not a constant",
                            self.name
                        )
                    });
                    assert_eq!(
                        &scalar.data_type(),
                        field_type,
                        "{}: the constant for argument {i} does not have the resolved \
                         field type",
                        self.name
                    );
                    assert_eq!(
                        scalar, expected,
                        "{}: the constant for argument {i} does not hold the value the \
                         caller wrote",
                        self.name
                    );
                }
                ConstantExpectation::Absent => {
                    assert!(
                        args.scalar_arguments[i].is_none(),
                        "{}: argument {i} is not a literal but was reported as a \
                         constant",
                        self.name
                    );
                }
                ConstantExpectation::Unchecked => {}
            }
        }

        Ok(Field::new(self.name, args.arg_fields[0].data_type().clone(), true).into())
    }

    fn invoke_with_args(&self, args: ScalarFunctionArgs) -> Result<ColumnarValue> {
        Ok(args.args[0].clone())
    }
}

/// Registers a one-argument function with the given coercion and expectation
/// on a fresh context, then plans and runs `sql`.
async fn plan_and_collect_single(
    name: &'static str,
    coercion: Coercion,
    expectation: ConstantExpectation,
    sql: &str,
) -> Result<()> {
    let ctx = SessionContext::new();
    let udf: ScalarUDF = ContractUdf::new(name, vec![(coercion, expectation)]).into();
    ctx.register_udf(udf);

    ctx.sql(sql).await?.collect().await?;

    Ok(())
}

/// A plain integer literal passed where the signature coerces that argument to
/// a narrower integer type arrives at the return-field hook as a present
/// constant of the coerced field type (Int16 here) holding the value the caller
/// wrote, at every point in planning where the hook runs.
#[tokio::test]
async fn literal_matches_coerced_field() -> Result<()> {
    plan_and_collect_single(
        "literal_match_udf",
        ContractUdf::narrow_to_int16(),
        ConstantExpectation::TypedConstant(ScalarValue::Int16(Some(1))),
        "select literal_match_udf(1)",
    )
    .await?;

    plan_and_collect_single(
        "zero_literal_udf",
        ContractUdf::narrow_to_int16(),
        ConstantExpectation::TypedConstant(ScalarValue::Int16(Some(0))),
        "select zero_literal_udf(0)",
    )
    .await
}

/// Negative literals and literals at the edges of the coerced type's range keep
/// their exact value. No truncation, wrapping or placeholder value is accepted.
#[tokio::test]
async fn negative_and_boundary_literals_keep_their_value() -> Result<()> {
    let cases = [
        (
            "negative_literal_udf",
            ContractUdf::narrow_to_int16(),
            ScalarValue::Int16(Some(-5)),
            "select negative_literal_udf(-5)",
        ),
        (
            "int16_max_literal_udf",
            ContractUdf::narrow_to_int16(),
            ScalarValue::Int16(Some(i16::MAX)),
            "select int16_max_literal_udf(32767)",
        ),
        (
            "int16_min_literal_udf",
            ContractUdf::narrow_to_int16(),
            ScalarValue::Int16(Some(i16::MIN)),
            "select int16_min_literal_udf(-32768)",
        ),
        (
            "int32_max_literal_udf",
            ContractUdf::narrow_to_int32(),
            ScalarValue::Int32(Some(i32::MAX)),
            "select int32_max_literal_udf(2147483647)",
        ),
    ];

    for (name, coercion, expected, sql) in cases {
        plan_and_collect_single(
            name,
            coercion,
            ConstantExpectation::TypedConstant(expected),
            sql,
        )
        .await?;
    }

    Ok(())
}

/// A NULL literal passed to a coercing argument arrives as a present null of
/// the coerced type. An untyped null, a non-null value or an empty slot is a
/// failure.
#[tokio::test]
async fn typed_null_matches_coerced_field() -> Result<()> {
    plan_and_collect_single(
        "typed_null_udf",
        ContractUdf::narrow_to_int16(),
        ConstantExpectation::TypedConstant(ScalarValue::Int16(None)),
        "select typed_null_udf(NULL)",
    )
    .await
}

/// A call that mixes a column with a literal keeps each slot matched to its
/// argument position. The column slot stays empty and the literal slot holds a
/// constant of the coerced type (Int32 here) with the literal's value. This goes through the DataFrame
/// API so the literal starts out as an Int64 value, the same as a SQL integer
/// literal.
#[tokio::test]
async fn mixed_column_and_literal_arguments() -> Result<()> {
    let ctx = SessionContext::new();
    let udf: ScalarUDF = ContractUdf::new(
        "mixed_args_udf",
        vec![
            (
                Coercion::new_exact(TypeSignatureClass::Numeric),
                ConstantExpectation::Absent,
            ),
            (
                ContractUdf::narrow_to_int32(),
                ConstantExpectation::TypedConstant(ScalarValue::Int32(Some(2))),
            ),
        ],
    )
    .into();
    let udf_clone = udf.clone();
    ctx.register_udf(udf);

    let batch = RecordBatch::try_new(
        Arc::new(Schema::new(vec![Field::new("a", DataType::Int16, false)])),
        vec![Arc::new(Int16Array::from(vec![1_i16, 2, 3]))],
    )?;
    ctx.read_batch(batch)?
        .select(vec![udf_clone.call(vec![col("a"), lit(2_i64)])])?
        .collect()
        .await?;

    Ok(())
}

/// Regression guard for an existing function that depends on the constant
/// slots. arrow_cast reads its type argument from the constant slot, and a type
/// argument written as a cast expression instead of a string literal is
/// rejected with an error naming the "second argument". That has to stay the
/// case, whether the error comes from building the logical plan or later.
#[tokio::test]
async fn arrow_cast_requires_literal_type_arg() -> Result<()> {
    let ctx = SessionContext::new();

    let planned = ctx.sql("select arrow_cast(1, cast('Utf8' as varchar))").await;
    let outcome = match planned {
        Err(e) => Err(e),
        Ok(df) => df.collect().await,
    };

    let err = outcome
        .expect_err("a cast type argument to arrow_cast must not be accepted as a constant");
    assert_contains!(err.to_string(), "second argument");

    Ok(())
}

/// A literal whose value cannot take the coerced type (2147483648 where the
/// signature wants Int32) keeps its current behavior. Building the logical plan
/// succeeds and running the query returns an error. Return-type resolution must
/// not turn the value problem into an early error, and the value must not be
/// folded into something that lets the query succeed.
#[tokio::test]
async fn invalid_literal_value_preserved() -> Result<()> {
    let ctx = SessionContext::new();
    let udf: ScalarUDF = ContractUdf::new(
        "overflow_literal_udf",
        vec![(
            ContractUdf::narrow_to_int32(),
            ConstantExpectation::Unchecked,
        )],
    )
    .into();
    ctx.register_udf(udf);

    // 2147483648 == i32::MAX + 1: a valid Int64 literal that cannot take Int32.
    let planned = ctx.sql("select overflow_literal_udf(2147483648)").await;
    let df = planned.expect("building the logical plan must not fail on the literal's value");

    assert!(
        df.collect().await.is_err(),
        "an out-of-range literal must still make the query fail when it runs, not be \
         folded to a value that fits"
    );

    Ok(())
}
