#!/usr/bin/env bash
# Test-setup for datafusion-fix-coerced-literal-args. The image already baked
# the full workspace dependency closure (`cargo fetch --locked`) and pre-warmed
# the cargo cache for the crates the verifier exercises (datafusion-core's
# `user_defined_integration` test target, datafusion-expr lib, datafusion-optimizer
# lib). No services to start, no data to seed. Offline-first: the verifier's
# integration-test compile resolves entirely from the baked cache.

set -euo pipefail

cd /repo/datafusion

# Fail fast on a cache miss rather than silently reaching for the network: the
# dependency closure is supposed to be complete at the pre-fix commit.
export CARGO_NET_OFFLINE=true

echo "[test-setup] Rust version:    $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:   $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Workspace root:  /repo/datafusion"
echo "[test-setup] CARGO_NET_OFFLINE=${CARGO_NET_OFFLINE}"
echo "[test-setup] Setup complete."
