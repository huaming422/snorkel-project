// Structural check: the wire contract stays internally consistent.
//
// internal/httpapi welds the issue-detail body (types.IssueDetails) to its
// OpenAPI schema with x-go-type, so the generator emits a type alias and the
// compiler never sees the spec's property list. The package's own
// TestWireTagBijection is the guard that, for each schema it pins, every
// serialized struct field has a schema property and every property is a field.
//
// This file re-runs that test. It pins no field name: a new `--json` field
// under any name passes when openapi.v0.yaml documents it too, and a change
// that adds no serialized field leaves the bijection as it was.
//
// TestWireTagBijection and its helpers (loadSpec, mapAt, resolveRef,
// pinnedSchemas, jsonTagNames, schemaProperties, diff) live in the httpapi test
// package and compile alongside this injected file. No build tag:
// internal/httpapi is pure Go.

package httpapi

import "testing"

func TestVerifyWireTagBijection(t *testing.T) {
	// The package's own bijection guard drives one t.Run subtest per pinned
	// schema; calling it here runs the full two-way (Go-tag set ==
	// spec-property set) check under this file's -run filter.
	TestWireTagBijection(t)
}
