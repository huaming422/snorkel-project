//go:build cgo

// Behavioral checks for `bd show` on the embedded store (the default backend,
// usesProxiedServer() is false), for issues whose dependency targets have no
// issue row in this database: an explicit `external:` reference or a bare id
// with another repo's prefix.
//
// For each case it builds three issues that differ only in their edges:
//   - hidden: some edges point at targets with no local row (plus, in the
//     mixed case, one local edge);
//   - twin: the same number of edges, of the same types, all to local issues;
//   - nodep: no edges at all (the stderr baseline).
//
// It asserts:
//   - `--json`: dependency_count still counts every stored edge, the
//     dependencies list holds exactly the local issues, and some field reports
//     how many edges were not listed. That field may have any name and may be
//     a number, a numeric string or a list of the unlisted edges; it must be
//     absent or zero/empty on the twin.
//   - text, direct and watch (`bd show -w`): stderr gains lines over the
//     no-dependency baseline for the hidden issue and none for the twin, those
//     lines never appear on stdout, and stdout still renders the issue and its
//     local dependency.
//   - `bd dep list <id> <id>` still prints every stored target.
//
// This file is injected into cmd/bd/ by the Go runner and compiles as
// `package main` against the package's committed test helpers
// (buildEmbeddedBD, bdInit, bdCreate, bdDep, bdShowDetails, bdEnv,
// runCommandBuffers).

package main

import (
	"bytes"
	"context"
	"os/exec"
	"strconv"
	"strings"
	"testing"
	"time"
)

// vudEdge is one dependency edge of the hidden issue. An empty target means a
// local issue created for the case.
type vudEdge struct {
	target string
	depTyp string
}

type vudCase struct {
	name  string
	edges []vudEdge
}

// vudCases cover both target shapes alone and together, and a mixed issue
// where the listing is short but not empty, so the reported number (2) differs
// from both the edge count (3) and the listing length (1).
var vudCases = []vudCase{
	{"external_reference", []vudEdge{{"external:liveop:liveop-kmf", "tracks"}}},
	{"cross_repo_prefix", []vudEdge{{"liveop-kmf", "blocks"}}},
	{"two_hidden_one_local", []vudEdge{
		{"external:liveop:liveop-q7x", "tracks"},
		{"liveop-r2d", "blocks"},
		{"", "blocks"},
	}},
}

func (c vudCase) hiddenCount() int {
	n := 0
	for _, e := range c.edges {
		if e.target != "" {
			n++
		}
	}
	return n
}

func TestVerifyUnresolvableDepsEmbedded(t *testing.T) {
	bd := buildEmbeddedBD(t)
	dir, _, _ := bdInit(t, bd, "--prefix", "ud")

	for _, tc := range vudCases {
		tc := tc
		t.Run(tc.name, func(t *testing.T) {
			hidden := bdCreate(t, bd, dir, "Subject "+tc.name, "--type", "task")
			twin := bdCreate(t, bd, dir, "Local twin "+tc.name, "--type", "task")
			var hiddenLocal []string
			var twinLocal []string
			for i, e := range tc.edges {
				target := e.target
				if target == "" {
					blocker := bdCreate(t, bd, dir, "Local blocker "+tc.name+" "+strconv.Itoa(i), "--type", "task")
					target = blocker.ID
					hiddenLocal = append(hiddenLocal, target)
				}
				bdDep(t, bd, dir, "add", hidden.ID, target, "--type", e.depTyp)

				twinBlocker := bdCreate(t, bd, dir, "Twin blocker "+tc.name+" "+strconv.Itoa(i), "--type", "task")
				bdDep(t, bd, dir, "add", twin.ID, twinBlocker.ID, "--type", e.depTyp)
				twinLocal = append(twinLocal, twinBlocker.ID)
			}
			nodep := bdCreate(t, bd, dir, "No-dependency subject "+tc.name, "--type", "task")

			hiddenJSON := bdShowDetails(t, bd, dir, hidden.ID)
			twinJSON := bdShowDetails(t, bd, dir, twin.ID)
			vudAssertJSON(t, "bd show --json", tc, hiddenJSON, twinJSON, hiddenLocal, twinLocal)

			// Direct text render.
			hOut, hErr := vudRunShow(t, bd, dir, hidden.ID)
			lOut, lErr := vudRunShow(t, bd, dir, twin.ID)
			_, nErr := vudRunShow(t, bd, dir, nodep.ID)
			vudAssertTextNotice(t, "direct bd show", tc.name,
				hErr, hOut, hidden.ID,
				lErr, twin.ID,
				nErr, nodep.ID)
			vudAssertRendered(t, "direct bd show", hOut, hidden.ID, hiddenLocal)
			vudAssertRendered(t, "direct bd show", lOut, twin.ID, twinLocal)

			// Watch text render: `bd show -w` renders once, then polls until
			// killed. The watch banner is in every capture, so the
			// no-dependency baseline subtracts it.
			hwOut, hwErr := vudRunWatch(t, bd, dir, hidden.ID)
			_, lwErr := vudRunWatch(t, bd, dir, twin.ID)
			_, nwErr := vudRunWatch(t, bd, dir, nodep.ID)
			if !strings.Contains(hwOut, hidden.ID) {
				t.Fatalf("watch (`bd show -w`) never rendered issue %s:\nstdout:\n%s", hidden.ID, hwOut)
			}
			vudAssertTextNotice(t, "watch bd show -w", tc.name,
				hwErr, hwOut, hidden.ID,
				lwErr, twin.ID,
				nwErr, nodep.ID)

			// The stored edges stay readable through the raw edge listing.
			rawList := bdDep(t, bd, dir, "list", hidden.ID, hidden.ID)
			for _, e := range tc.edges {
				if e.target == "" {
					continue
				}
				want := strings.TrimPrefix(e.target, "external:liveop:")
				if !strings.Contains(rawList, want) {
					t.Errorf("`bd dep list %s %s` did not print the stored target %s:\n%s",
						hidden.ID, hidden.ID, e.target, rawList)
				}
			}
		})
	}
}

// vudAssertJSON checks one route's `--json` detail for the hidden issue
// against its all-local twin.
func vudAssertJSON(t *testing.T, route string, tc vudCase,
	hiddenJSON, twinJSON map[string]interface{}, hiddenLocal, twinLocal []string) {
	t.Helper()
	total := float64(len(tc.edges))
	if n, ok := hiddenJSON["dependency_count"].(float64); !ok || n != total {
		t.Errorf("[%s/%s] dependency_count = %v, want %v (every stored edge is counted)",
			route, tc.name, hiddenJSON["dependency_count"], total)
	}
	if got := vudListedIDs(hiddenJSON["dependencies"]); !vudSameSet(got, hiddenLocal) {
		t.Errorf("[%s/%s] dependencies listed %v, want exactly the local issues %v",
			route, tc.name, got, hiddenLocal)
	}
	if got := vudListedIDs(twinJSON["dependencies"]); !vudSameSet(got, twinLocal) {
		t.Errorf("[%s/%s] twin dependencies listed %v, want %v", route, tc.name, got, twinLocal)
	}

	want := tc.hiddenCount()
	if keys := vudReportingKeys(hiddenJSON, twinJSON, want); len(keys) == 0 {
		t.Errorf("[%s/%s] no field reports the %d dependency edge(s) that are counted but not listed\n"+
			"(it must be absent or zero on an issue whose edges are all local).\nhidden: %v\ntwin:   %v",
			route, tc.name, want, hiddenJSON, twinJSON)
	}
}

// vudAssertTextNotice compares ID-normalized stderr line sets for one text
// render: the hidden issue adds lines over the no-dependency baseline, the
// all-local twin adds none, and none of the hidden issue's extra lines appear
// on its stdout.
func vudAssertTextNotice(
	t *testing.T, render, caseName string,
	hiddenErr, hiddenOut, hiddenID string,
	localErr, localID string,
	baseErr, baseID string,
) {
	t.Helper()
	base := vudStderrLineSet(baseErr, baseID)
	hiddenExtra := vudStderrDelta(vudStderrLineSet(hiddenErr, hiddenID), base)
	localExtra := vudStderrDelta(vudStderrLineSet(localErr, localID), base)

	if len(hiddenExtra) == 0 {
		t.Errorf("[%s/%s] printed nothing on stderr about the unlisted edge(s) beyond the\n"+
			"no-dependency baseline.\nhidden stderr:\n%s\nbaseline stderr:\n%s",
			render, caseName, hiddenErr, baseErr)
	}
	if len(localExtra) != 0 {
		t.Errorf("[%s/%s] printed stderr lines for an issue whose edges are all local: %v\nlocal stderr:\n%s",
			render, caseName, localExtra, localErr)
	}
	outNorm := strings.ReplaceAll(hiddenOut, hiddenID, "ISSUE")
	for _, line := range hiddenExtra {
		if strings.Contains(outNorm, line) {
			t.Errorf("[%s/%s] the stderr line %q also appeared on stdout:\n%s",
				render, caseName, line, hiddenOut)
		}
	}
}

// vudAssertRendered checks that stdout still shows the issue and each of its
// local dependencies.
func vudAssertRendered(t *testing.T, render, stdout, id string, localDeps []string) {
	t.Helper()
	if !strings.Contains(stdout, id) {
		t.Errorf("[%s] stdout did not render issue %s:\n%s", render, id, stdout)
	}
	for _, dep := range localDeps {
		if !strings.Contains(stdout, dep) {
			t.Errorf("[%s] stdout for %s did not show its local dependency %s:\n%s", render, id, dep, stdout)
		}
	}
}

// vudListedIDs returns the ids of a decoded `dependencies` value, which may be
// absent, nil or a list of objects.
func vudListedIDs(v interface{}) []string {
	list, ok := v.([]interface{})
	if !ok {
		return nil
	}
	ids := make([]string, 0, len(list))
	for _, item := range list {
		obj, _ := item.(map[string]interface{})
		id, _ := obj["id"].(string)
		ids = append(ids, id)
	}
	return ids
}

func vudSameSet(got, want []string) bool {
	if len(got) != len(want) {
		return false
	}
	seen := map[string]int{}
	for _, s := range want {
		seen[s]++
	}
	for _, s := range got {
		if seen[s] == 0 {
			return false
		}
		seen[s]--
	}
	return true
}

// vudReportingKeys returns the fields (top level, or one level inside an
// object) whose value on the hidden issue reports want, and which are absent
// or empty on the twin.
func vudReportingKeys(hidden, twin map[string]interface{}, want int) []string {
	h, tw := vudFlatten(hidden), vudFlatten(twin)
	var out []string
	for k, v := range h {
		if vudReports(v, want) && !vudNonEmpty(tw[k]) {
			out = append(out, k)
		}
	}
	return out
}

func vudFlatten(m map[string]interface{}) map[string]interface{} {
	out := map[string]interface{}{}
	for k, v := range m {
		out[k] = v
		if obj, ok := v.(map[string]interface{}); ok {
			for sk, sv := range obj {
				out[k+"."+sk] = sv
			}
		}
	}
	return out
}

// vudReports reports whether a decoded JSON value states the number want: a
// number, a numeric string, or a list with that many entries.
func vudReports(v interface{}, want int) bool {
	switch x := v.(type) {
	case float64:
		return x == float64(want)
	case string:
		return strings.TrimSpace(x) == strconv.Itoa(want)
	case []interface{}:
		return len(x) == want
	default:
		return false
	}
}

// vudNonEmpty reports whether a decoded JSON value claims something: a
// non-zero number, true, a non-empty string other than "0"/"false", or a
// non-empty list or object.
func vudNonEmpty(v interface{}) bool {
	switch x := v.(type) {
	case nil:
		return false
	case float64:
		return x != 0
	case bool:
		return x
	case string:
		s := strings.TrimSpace(x)
		return s != "" && s != "0" && s != "false"
	case []interface{}:
		return len(x) > 0
	case map[string]interface{}:
		return len(x) > 0
	default:
		return true
	}
}

// vudStderrLineSet turns a stderr capture into a set of non-empty trimmed
// lines with the subject issue id replaced by a constant token, so captures of
// different issues differ only where their content differs.
func vudStderrLineSet(raw, id string) map[string]bool {
	norm := strings.ReplaceAll(raw, id, "ISSUE")
	set := map[string]bool{}
	for _, line := range strings.Split(norm, "\n") {
		if l := strings.TrimSpace(line); l != "" {
			set[l] = true
		}
	}
	return set
}

func vudStderrDelta(sub, base map[string]bool) []string {
	var out []string
	for l := range sub {
		if !base[l] {
			out = append(out, l)
		}
	}
	return out
}

// vudRunShow runs `bd show <id>` with stdout and stderr kept apart.
func vudRunShow(t *testing.T, bd, dir, id string) (stdout, stderr string) {
	t.Helper()
	cmd := exec.Command(bd, "show", id)
	cmd.Dir = dir
	cmd.Env = bdEnv(dir)
	outBuf, errBuf, err := runCommandBuffers(t, cmd)
	if err != nil {
		t.Fatalf("bd show %s failed: %v\nstdout:\n%s\nstderr:\n%s", id, err, outBuf.String(), errBuf.String())
	}
	return outBuf.String(), errBuf.String()
}

// vudRunWatch runs `bd show <id> -w`, which renders once and then polls until
// killed, and returns what reached stdout/stderr before the deadline. The
// error from the kill is expected and not asserted.
func vudRunWatch(t *testing.T, bd, dir, id string) (stdout, stderr string) {
	t.Helper()
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, bd, "show", id, "-w")
	cmd.Dir = dir
	cmd.Env = bdEnv(dir)
	var out, errOut bytes.Buffer
	cmd.Stdout = &out
	cmd.Stderr = &errOut
	_ = cmd.Run()
	return out.String(), errOut.String()
}
