//go:build cgo

// Behavioral checks for `bd show` on the proxied-server backend (a repo whose
// bd talks to a Dolt SQL server; usesProxiedServer() is true), for issues
// whose dependency targets have no issue row in this database.
//
// Same cases and assertions as the embedded file, run through the three
// proxied routes: the plain text render, the watch render (`bd show -w`) and
// `bd show --json`.
//
// The server comes from the pinned local `dolt` CLI
// (BEADS_TEST_DOLT_SERVER=local, see internal/testutil/localdoltserver.go),
// and BEADS_TEST_REQUIRE_DOLT_CONTAINER=1 turns an unavailable server into a
// failure instead of a skip. verify.toml sets those, plus
// BEADS_TEST_PROXIED_SERVER=1, in this file's per-file env.
//
// Compiles as `package main` against the package's committed proxied test
// helpers (requireSharedProxiedServer, newSharedProxiedProject,
// bdProxiedCreate, bdProxiedDep, bdProxiedRunBuffers, bdProxiedEnv,
// buildEmbeddedBD).

package main

import (
	"bytes"
	"context"
	"encoding/json"
	"os/exec"
	"strconv"
	"strings"
	"testing"
	"time"
)

// vudPxEdge is one dependency edge of the hidden issue. An empty target means
// a local issue created for the case.
type vudPxEdge struct {
	target string
	depTyp string
}

type vudPxCase struct {
	name  string
	edges []vudPxEdge
}

// vudPxCases cover both target shapes alone and together, and a mixed issue
// where the listing is short but not empty, so the reported number (2) differs
// from both the edge count (3) and the listing length (1).
var vudPxCases = []vudPxCase{
	{"external_reference", []vudPxEdge{{"external:liveop:liveop-kmf", "tracks"}}},
	{"cross_repo_prefix", []vudPxEdge{{"liveop-kmf", "blocks"}}},
	{"two_hidden_one_local", []vudPxEdge{
		{"external:liveop:liveop-q7x", "tracks"},
		{"liveop-r2d", "blocks"},
		{"", "blocks"},
	}},
}

func (c vudPxCase) hiddenCount() int {
	n := 0
	for _, e := range c.edges {
		if e.target != "" {
			n++
		}
	}
	return n
}

func TestVerifyUnresolvableDepsProxied(t *testing.T) {
	requireSharedProxiedServer(t)
	bd := buildEmbeddedBD(t)

	// One project for every case, so all issues share one server-backed
	// database.
	p := newSharedProxiedProject(t, bd, "vud")

	for _, tc := range vudPxCases {
		tc := tc
		t.Run(tc.name, func(t *testing.T) {
			hidden := bdProxiedCreate(t, bd, p.dir, "Proxied subject "+tc.name, "--type", "task")
			twin := bdProxiedCreate(t, bd, p.dir, "Proxied local twin "+tc.name, "--type", "task")
			var hiddenLocal []string
			var twinLocal []string
			for i, e := range tc.edges {
				target := e.target
				if target == "" {
					blocker := bdProxiedCreate(t, bd, p.dir, "Proxied local blocker "+tc.name+" "+strconv.Itoa(i), "--type", "task")
					target = blocker.ID
					hiddenLocal = append(hiddenLocal, target)
				}
				bdProxiedDep(t, bd, p.dir, "add", hidden.ID, target, "--type", e.depTyp)

				twinBlocker := bdProxiedCreate(t, bd, p.dir, "Proxied twin blocker "+tc.name+" "+strconv.Itoa(i), "--type", "task")
				bdProxiedDep(t, bd, p.dir, "add", twin.ID, twinBlocker.ID, "--type", e.depTyp)
				twinLocal = append(twinLocal, twinBlocker.ID)
			}
			nodep := bdProxiedCreate(t, bd, p.dir, "Proxied no-dependency subject "+tc.name, "--type", "task")

			// --json
			hiddenJSON := vudPxShowJSON(t, bd, p.dir, hidden.ID)
			twinJSON := vudPxShowJSON(t, bd, p.dir, twin.ID)
			vudPxAssertJSON(t, tc, hiddenJSON, twinJSON, hiddenLocal, twinLocal)

			// Plain text render.
			hOut, hErr := vudProxiedShow(t, bd, p.dir, hidden.ID)
			lOut, lErr := vudProxiedShow(t, bd, p.dir, twin.ID)
			_, nErr := vudProxiedShow(t, bd, p.dir, nodep.ID)
			vudPxAssertTextNotice(t, "proxied bd show", tc.name,
				hErr, hOut, hidden.ID,
				lErr, twin.ID,
				nErr, nodep.ID)
			vudPxAssertRendered(t, "proxied bd show", hOut, hidden.ID, hiddenLocal)
			vudPxAssertRendered(t, "proxied bd show", lOut, twin.ID, twinLocal)

			// Watch render: renders once, then polls until killed. The watch
			// banner is in every capture, so the no-dependency baseline
			// subtracts it.
			hwOut, hwErr := vudPxRunWatch(t, bd, p.dir, hidden.ID)
			_, lwErr := vudPxRunWatch(t, bd, p.dir, twin.ID)
			_, nwErr := vudPxRunWatch(t, bd, p.dir, nodep.ID)
			if !strings.Contains(hwOut, hidden.ID) {
				t.Fatalf("proxied watch (`bd show -w`) never rendered issue %s:\nstdout:\n%s", hidden.ID, hwOut)
			}
			vudPxAssertTextNotice(t, "proxied bd show -w", tc.name,
				hwErr, hwOut, hidden.ID,
				lwErr, twin.ID,
				nwErr, nodep.ID)
		})
	}
}

// vudPxAssertJSON checks the proxied `--json` detail for the hidden issue
// against its all-local twin: every stored edge counted, exactly the local
// issues listed, and some field reporting how many edges were not listed
// (absent or zero/empty on the twin).
func vudPxAssertJSON(t *testing.T, tc vudPxCase,
	hiddenJSON, twinJSON map[string]interface{}, hiddenLocal, twinLocal []string) {
	t.Helper()
	total := float64(len(tc.edges))
	if n, ok := hiddenJSON["dependency_count"].(float64); !ok || n != total {
		t.Errorf("[proxied bd show --json/%s] dependency_count = %v, want %v (every stored edge is counted)",
			tc.name, hiddenJSON["dependency_count"], total)
	}
	if got := vudPxListedIDs(hiddenJSON["dependencies"]); !vudPxSameSet(got, hiddenLocal) {
		t.Errorf("[proxied bd show --json/%s] dependencies listed %v, want exactly the local issues %v",
			tc.name, got, hiddenLocal)
	}
	if got := vudPxListedIDs(twinJSON["dependencies"]); !vudPxSameSet(got, twinLocal) {
		t.Errorf("[proxied bd show --json/%s] twin dependencies listed %v, want %v", tc.name, got, twinLocal)
	}

	want := tc.hiddenCount()
	if keys := vudPxReportingKeys(hiddenJSON, twinJSON, want); len(keys) == 0 {
		t.Errorf("[proxied bd show --json/%s] no field reports the %d dependency edge(s) that are counted but not listed\n"+
			"(it must be absent or zero on an issue whose edges are all local).\nhidden: %v\ntwin:   %v",
			tc.name, want, hiddenJSON, twinJSON)
	}
}

// vudPxAssertTextNotice compares ID-normalized stderr line sets for one text
// render: the hidden issue adds lines over the no-dependency baseline, the
// all-local twin adds none, and none of the hidden issue's extra lines appear
// on its stdout.
func vudPxAssertTextNotice(
	t *testing.T, render, caseName string,
	hiddenErr, hiddenOut, hiddenID string,
	localErr, localID string,
	baseErr, baseID string,
) {
	t.Helper()
	base := vudPxStderrLineSet(baseErr, baseID)
	hiddenExtra := vudPxStderrDelta(vudPxStderrLineSet(hiddenErr, hiddenID), base)
	localExtra := vudPxStderrDelta(vudPxStderrLineSet(localErr, localID), base)

	if len(hiddenExtra) == 0 {
		t.Errorf("[%s/%s] printed nothing on stderr about the unlisted edge(s) beyond the\n"+
			"no-dependency baseline.\nhidden stderr:\n%s\nbaseline stderr:\n%s",
			render, caseName, hiddenErr, baseErr)
	}
	if len(localExtra) != 0 {
		t.Errorf("[%s/%s] printed stderr lines for an issue whose edges are all local: %v\nlocal stderr:\n%s",
			render, caseName, localExtra, localErr)
	}
	outNorm := strings.ReplaceAll(hiddenOut, hiddenID, "ISSUE")
	for _, line := range hiddenExtra {
		if strings.Contains(outNorm, line) {
			t.Errorf("[%s/%s] the stderr line %q also appeared on stdout:\n%s",
				render, caseName, line, hiddenOut)
		}
	}
}

// vudPxAssertRendered checks that stdout still shows the issue and each of
// its local dependencies.
func vudPxAssertRendered(t *testing.T, render, stdout, id string, localDeps []string) {
	t.Helper()
	if !strings.Contains(stdout, id) {
		t.Errorf("[%s] stdout did not render issue %s:\n%s", render, id, stdout)
	}
	for _, dep := range localDeps {
		if !strings.Contains(stdout, dep) {
			t.Errorf("[%s] stdout for %s did not show its local dependency %s:\n%s", render, id, dep, stdout)
		}
	}
}

// vudProxiedShow runs a proxied `bd show <id>` with stdout and stderr kept
// apart and fails on a command error.
func vudProxiedShow(t *testing.T, bd, dir, id string) (stdout, stderr string) {
	t.Helper()
	out, errOut, err := bdProxiedRunBuffers(t, bd, dir, "show", id)
	if err != nil {
		t.Fatalf("proxied bd show %s failed: %v\nstdout:\n%s\nstderr:\n%s", id, err, out, errOut)
	}
	return out, errOut
}

// vudPxShowJSON runs a proxied `bd show <id> --json` and decodes stdout (an
// object, or an array whose first element is the issue).
func vudPxShowJSON(t *testing.T, bd, dir, id string) map[string]interface{} {
	t.Helper()
	out, errOut, err := bdProxiedRunBuffers(t, bd, dir, "show", id, "--json")
	if err != nil {
		t.Fatalf("proxied bd show %s --json failed: %v\nstdout:\n%s\nstderr:\n%s", id, err, out, errOut)
	}
	s := strings.TrimSpace(out)
	start := strings.IndexAny(s, "[{")
	if start < 0 {
		t.Fatalf("no JSON in proxied show output:\n%s", out)
	}
	s = s[start:]
	if strings.HasPrefix(s, "[") {
		var arr []map[string]interface{}
		if err := json.Unmarshal([]byte(s), &arr); err != nil {
			t.Fatalf("parse proxied show JSON array: %v\n%s", err, s)
		}
		if len(arr) == 0 {
			t.Fatalf("empty JSON array from proxied show %s", id)
		}
		return arr[0]
	}
	var m map[string]interface{}
	if err := json.Unmarshal([]byte(s), &m); err != nil {
		t.Fatalf("parse proxied show JSON: %v\n%s", err, s)
	}
	return m
}

// vudPxRunWatch runs a proxied `bd show <id> -w` and returns what reached
// stdout/stderr before the deadline. The error from the kill is expected and
// not asserted.
func vudPxRunWatch(t *testing.T, bd, dir, id string) (stdout, stderr string) {
	t.Helper()
	ctx, cancel := context.WithTimeout(context.Background(), 8*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, bd, "show", id, "-w")
	cmd.Dir = dir
	cmd.Env = bdProxiedEnv(dir)
	var out, errOut bytes.Buffer
	cmd.Stdout = &out
	cmd.Stderr = &errOut
	_ = cmd.Run()
	return out.String(), errOut.String()
}

// The helpers below mirror the embedded file's. The Go runner injects and
// runs each verify*_test.go on its own, so this file cannot use that file's
// helpers, and two files in one package cannot share top-level names.

func vudPxListedIDs(v interface{}) []string {
	list, ok := v.([]interface{})
	if !ok {
		return nil
	}
	ids := make([]string, 0, len(list))
	for _, item := range list {
		obj, _ := item.(map[string]interface{})
		id, _ := obj["id"].(string)
		ids = append(ids, id)
	}
	return ids
}

func vudPxSameSet(got, want []string) bool {
	if len(got) != len(want) {
		return false
	}
	seen := map[string]int{}
	for _, s := range want {
		seen[s]++
	}
	for _, s := range got {
		if seen[s] == 0 {
			return false
		}
		seen[s]--
	}
	return true
}

func vudPxReportingKeys(hidden, twin map[string]interface{}, want int) []string {
	h, tw := vudPxFlatten(hidden), vudPxFlatten(twin)
	var out []string
	for k, v := range h {
		if vudPxReports(v, want) && !vudPxNonEmpty(tw[k]) {
			out = append(out, k)
		}
	}
	return out
}

func vudPxFlatten(m map[string]interface{}) map[string]interface{} {
	out := map[string]interface{}{}
	for k, v := range m {
		out[k] = v
		if obj, ok := v.(map[string]interface{}); ok {
			for sk, sv := range obj {
				out[k+"."+sk] = sv
			}
		}
	}
	return out
}

func vudPxReports(v interface{}, want int) bool {
	switch x := v.(type) {
	case float64:
		return x == float64(want)
	case string:
		return strings.TrimSpace(x) == strconv.Itoa(want)
	case []interface{}:
		return len(x) == want
	default:
		return false
	}
}

func vudPxNonEmpty(v interface{}) bool {
	switch x := v.(type) {
	case nil:
		return false
	case float64:
		return x != 0
	case bool:
		return x
	case string:
		s := strings.TrimSpace(x)
		return s != "" && s != "0" && s != "false"
	case []interface{}:
		return len(x) > 0
	case map[string]interface{}:
		return len(x) > 0
	default:
		return true
	}
}

func vudPxStderrLineSet(raw, id string) map[string]bool {
	norm := strings.ReplaceAll(raw, id, "ISSUE")
	set := map[string]bool{}
	for _, line := range strings.Split(norm, "\n") {
		if l := strings.TrimSpace(line); l != "" {
			set[l] = true
		}
	}
	return set
}

func vudPxStderrDelta(sub, base map[string]bool) []string {
	var out []string
	for l := range sub {
		if !base[l] {
			out = append(out, l)
		}
	}
	return out
}
