## Task

A teammate used `bd dep add` to make one of our issues depend on work that lives in another repo.
The target was either a bare id with that repo's prefix (like `liveop-kmf`) or an `external:` reference, and `bd dep add` reported the dependency as added.
After that, `bd show` on the issue doesn't add up.
The normal output has no dependency section at all, as if nothing had been added.
With `--json`, `dependency_count` is 1 but there's no `dependencies` list.
Watch mode (`bd show -w`) looks the same, and so does `bd show` on our clones that were set up with `bd init --proxied-server`.

From `bd show` alone we can't tell whether the edge was saved or the count is wrong.
Please find out what's going on and make `bd show` give a straight answer about these dependencies.

What we rely on:

- `dependency_count` keeps counting every dependency the issue really has, and the stored edges stay as they are.
- Our scripts treat every entry in the `--json` `dependencies` list as an issue in this database, so that list should keep holding only those, local dependencies included.
- The JSON should also say how many of the counted dependencies it couldn't list.
  For an issue whose dependencies are all local, it shouldn't claim any.
- In the normal output, the warning about dependencies it can't show goes to stderr, because we pipe stdout into other tools.
  An issue whose dependencies are all local gets no warning, and local dependencies still show up in the output.
