## Task

freehire has a browser extension with a side panel.
While a candidate reads a job ad on a careers site or a job board, the panel calls `GET /api/v1/jobs/find?url=<page>` to ask whether freehire has that vacancy, and links to freehire's page for it when it does.

On about one job page in five, the panel says "freehire doesn't have this posting" for a vacancy freehire plainly has.
For those pages the endpoint answers `{"data": null}`.
The match card for the same role shows on the page behind the panel, and a search on freehire finds it too.
Every reported page belongs to a posting freehire folded into another one: the role went out on more than one channel, and freehire keeps one posting to represent the vacancy so it is listed once.

Find out why these pages come back empty and fix it.
For a page whose posting was folded into another, the panel should link to the posting that represents the vacancy.
If that representative has since closed while the posting on the page is still open, link to the folded posting's own freehire page instead.

These must keep working as they do now:
- A page whose posting has closed comes back as not carried, folded or not, and so does a page freehire never stored.
- Links that differ only by scheme, a leading `www.`, a tracking query, a fragment or a trailing slash match the same posting.
- When two separate open postings store the same page, the one seen most recently wins.
- The lookup stays an index lookup, since it runs for every job page a candidate opens against a jobs table of a few million rows.

An earlier version of this endpoint scanned that table and timed out in production.
Pages the panel already recognizes are not part of this report.
The repo's integration suite (`-tags=integration`) runs against a local PostgreSQL in this environment, so the problem can be reproduced there.
