#!/usr/bin/env bash
# Test setup for freehire-fix-duplicate-job-lookup.
#
# Runs once before the verifier, with the repo already rewound and the user
# changes applied to the working tree. It must succeed under `docker run
# --network none`: every dependency the focused tests compile against is already
# baked into the image (go module cache warmed at the base commit in the image
# build), so `go mod download` is an offline no-op here. The online fallback
# exists only for the smoke gate's networked run; the checks themselves run offline.
#
# Responsibilities, in order:
#   1. cd into the repo and export the offline Go switches.
#   2. Put the baked PostgreSQL 18 binaries on PATH.
#   3. Start the baked, dev-owned PostgreSQL cluster (the integration suite's
#      internal/testdb also auto-starts it, but doing it here fails fast with a
#      clear message if the cluster cannot come up).
#   4. Warm the module cache offline-first, with a logged online fallback.
# No assertion logic lives here; the verifier owns it.
set -euo pipefail

cd /repo/freehire

# Offline Go: resolve only from the warmed module cache, never the network.
# -mod=mod lets `go test` touch go.sum entries already present without a vendor
# dir; GOPROXY=off forbids any download.
export GOFLAGS="${GOFLAGS:--mod=mod}"
export GOPROXY="${GOPROXY:-off}"

# The baked Postgres 18 binaries (pg_ctl, psql, pg_isready, initdb) live here.
export PATH="/usr/local/go/bin:/usr/lib/postgresql/18/bin:${PATH}"

# Start the baked dev-owned cluster. The helper is idempotent and concurrency
# safe; it initialises the data dir on first use and is a no-op when already up.
echo "[test-setup] starting baked PostgreSQL cluster"
/usr/local/bin/freehire-pg start

# Warm the module cache. Offline first (the image already carries the closure);
# fall back to an online fetch only when a network is present (smoke gate).
echo "[test-setup] priming Go module cache (offline-first)"
if GOFLAGS=-mod=mod GOPROXY=off go mod download; then
    echo "[test-setup] module cache satisfied offline"
else
    echo "[test-setup] offline module cache incomplete; falling back to network" >&2
    go mod download
fi

echo "[test-setup] setup complete"
