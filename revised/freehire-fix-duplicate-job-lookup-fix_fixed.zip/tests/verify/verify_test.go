//go:build integration

// Behavioral checks for GET /api/v1/jobs/find, the endpoint the browser extension's side
// panel asks "is the page I am on a posting freehire carries?". Every case drives the
// real handler over HTTP (as the repo's own find_job integration test does) against the
// baked PostgreSQL via testdb.Pool, and reads the JSON answer the panel reads:
// {"data":{"public_slug":...}} for a carried page, {"data":null} otherwise.
//
// The page URLs are on hosts whose links carry no identity the URL parser reads, so each
// lookup is answered by matching the page against the URL every posting stored. A
// self-prefixed (vrfy*) set of helpers keeps this file independent of the package's own
// test fixtures, which compile alongside it.
//
// Run with: go test -tags=integration ./internal/handler/
package handler

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"sync"
	"testing"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/strelov1/freehire/internal/db"
	"github.com/strelov1/freehire/internal/testdb"
)

// vrfyStatement is one SQL statement the endpoint sent, with the arguments it bound.
type vrfyStatement struct {
	sql  string
	args []any
}

// vrfyRecorder sits between the endpoint's queries and the pool and keeps every statement
// sent through it, so the plan of each one can be inspected afterwards.
type vrfyRecorder struct {
	pool *pgxpool.Pool

	mu    sync.Mutex
	stmts []vrfyStatement
}

func (r *vrfyRecorder) record(sql string, args []any) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.stmts = append(r.stmts, vrfyStatement{sql: sql, args: append([]any(nil), args...)})
}

func (r *vrfyRecorder) reset() {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.stmts = nil
}

func (r *vrfyRecorder) statements() []vrfyStatement {
	r.mu.Lock()
	defer r.mu.Unlock()
	return append([]vrfyStatement(nil), r.stmts...)
}

func (r *vrfyRecorder) Exec(ctx context.Context, sql string, args ...interface{}) (pgconn.CommandTag, error) {
	r.record(sql, args)
	return r.pool.Exec(ctx, sql, args...)
}

func (r *vrfyRecorder) Query(ctx context.Context, sql string, args ...interface{}) (pgx.Rows, error) {
	r.record(sql, args)
	return r.pool.Query(ctx, sql, args...)
}

func (r *vrfyRecorder) QueryRow(ctx context.Context, sql string, args ...interface{}) pgx.Row {
	r.record(sql, args)
	return r.pool.QueryRow(ctx, sql, args...)
}

func (r *vrfyRecorder) SendBatch(ctx context.Context, b *pgx.Batch) pgx.BatchResults {
	for _, qq := range b.QueuedQueries {
		r.record(qq.SQL, qq.Arguments)
	}
	return r.pool.SendBatch(ctx, b)
}

func (r *vrfyRecorder) CopyFrom(ctx context.Context, table pgx.Identifier, columns []string, src pgx.CopyFromSource) (int64, error) {
	return r.pool.CopyFrom(ctx, table, columns, src)
}

// vrfyEnv is one test's database plus the find endpoint mounted on a fiber app.
type vrfyEnv struct {
	pool *pgxpool.Pool
	rec  *vrfyRecorder
	app  *fiber.App
}

func vrfyNewEnv(t *testing.T) *vrfyEnv {
	t.Helper()
	pool := testdb.Pool(t)
	rec := &vrfyRecorder{pool: pool}
	h := &jobsHandlers{queries: db.New(rec)}
	app := fiber.New(fiber.Config{ErrorHandler: RenderError})
	app.Get("/api/v1/jobs/find", h.FindJob)
	return &vrfyEnv{pool: pool, rec: rec, app: app}
}

// insert creates one open posting (not folded into another, last seen now) storing the
// given page URL and slug, and returns its id.
func (e *vrfyEnv) insert(t *testing.T, extID, pageURL, slug string) int64 {
	t.Helper()
	var id int64
	if err := e.pool.QueryRow(context.Background(),
		`INSERT INTO jobs (source, external_id, url, title, public_slug)
		 VALUES ('vrfy', $1, $2, 'A Role', $3) RETURNING id`,
		extID, pageURL, slug).Scan(&id); err != nil {
		t.Fatalf("seed posting %s: %v", extID, err)
	}
	return id
}

// fold records dupID as a duplicate of the posting representativeID.
func (e *vrfyEnv) fold(t *testing.T, dupID, representativeID int64) {
	t.Helper()
	if _, err := e.pool.Exec(context.Background(),
		"UPDATE jobs SET duplicate_of = $1 WHERE id = $2", representativeID, dupID); err != nil {
		t.Fatalf("fold %d into %d: %v", dupID, representativeID, err)
	}
}

// close stamps closed_at, so the posting is no longer open.
func (e *vrfyEnv) close(t *testing.T, id int64) {
	t.Helper()
	if _, err := e.pool.Exec(context.Background(),
		"UPDATE jobs SET closed_at = now() WHERE id = $1", id); err != nil {
		t.Fatalf("close %d: %v", id, err)
	}
}

// age moves a posting's last_seen_at back by the given interval.
func (e *vrfyEnv) age(t *testing.T, id int64, interval string) {
	t.Helper()
	if _, err := e.pool.Exec(context.Background(),
		"UPDATE jobs SET last_seen_at = now() - $1::interval WHERE id = $2", interval, id); err != nil {
		t.Fatalf("age %d: %v", id, err)
	}
}

// find asks the endpoint about a page. It returns the slug and true for
// {"data":{"public_slug":...}}, and "" and false for {"data":null}; any other answer
// fails the test.
func (e *vrfyEnv) find(t *testing.T, pageURL string) (string, bool) {
	t.Helper()
	req := httptest.NewRequest(fiber.MethodGet, "/api/v1/jobs/find?url="+url.QueryEscape(pageURL), nil)
	resp, err := e.app.Test(req, -1)
	if err != nil {
		t.Fatalf("GET find?url=%s: %v", pageURL, err)
	}
	defer resp.Body.Close()
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		t.Fatalf("read body for %s: %v", pageURL, err)
	}
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("GET find?url=%s: status %d, want 200 (body %s)", pageURL, resp.StatusCode, body)
	}
	var top map[string]json.RawMessage
	if err := json.Unmarshal(body, &top); err != nil {
		t.Fatalf("decode %s: %v", body, err)
	}
	data, ok := top["data"]
	if !ok {
		t.Fatalf("answer for %s has no data field: %s", pageURL, body)
	}
	if strings.TrimSpace(string(data)) == "null" {
		return "", false
	}
	var posting struct {
		PublicSlug string `json:"public_slug"`
	}
	if err := json.Unmarshal(data, &posting); err != nil || posting.PublicSlug == "" {
		t.Fatalf("answer for %s is neither null nor a posting with a slug: %s", pageURL, body)
	}
	return posting.PublicSlug, true
}

func (e *vrfyEnv) wantCarried(t *testing.T, pageURL, wantSlug string) {
	t.Helper()
	slug, carried := e.find(t, pageURL)
	if !carried {
		t.Errorf("page %s answered not carried, want %q", pageURL, wantSlug)
		return
	}
	if slug != wantSlug {
		t.Errorf("page %s answered %q, want %q", pageURL, slug, wantSlug)
	}
}

func (e *vrfyEnv) wantNotCarried(t *testing.T, pageURL string) {
	t.Helper()
	if slug, carried := e.find(t, pageURL); carried {
		t.Errorf("page %s answered %q, want not carried", pageURL, slug)
	}
}

// A page that belongs to a posting folded into another answers with the posting that
// represents the vacancy. Two groups share the database, so each folded page has to
// land on its own representative; a representative's own page keeps answering with
// itself, and a tracking-tagged link to the folded page answers the same way.
func TestVerifyFoldedPageLinksToRepresentative(t *testing.T) {
	e := vrfyNewEnv(t)

	ashbyRep := e.insert(t, "truelogic:rep", "https://jobs.ashbyhq.com/truelogic/9b1e44f0", "senior-go-truelogic")
	ashbyDup := e.insert(t, "truelogic:dup", "https://jobs.ashbyhq.com/truelogic/c6d2719d", "senior-go-truelogic-2")
	e.fold(t, ashbyDup, ashbyRep)

	northwindRep := e.insert(t, "northwind:rep", "https://himalayas.app/companies/northwind/jobs/data-engineer", "data-engineer-northwind")
	northwindDup := e.insert(t, "northwind:dup", "https://jobs.lever.co/northwind/5f0c2a71", "data-engineer-northwind-lever")
	e.fold(t, northwindDup, northwindRep)

	e.wantCarried(t, "https://jobs.ashbyhq.com/truelogic/c6d2719d", "senior-go-truelogic")
	e.wantCarried(t, "https://jobs.lever.co/northwind/5f0c2a71", "data-engineer-northwind")
	e.wantCarried(t, "https://jobs.lever.co/northwind/5f0c2a71?utm_source=freehire.me", "data-engineer-northwind")
	e.wantCarried(t, "https://jobs.ashbyhq.com/truelogic/9b1e44f0", "senior-go-truelogic")
	e.wantCarried(t, "https://himalayas.app/companies/northwind/jobs/data-engineer", "data-engineer-northwind")
}

// When the representative has closed and the folded posting on the page is still open,
// the page answers with the folded posting's own slug. A second group whose
// representative is still open sits beside it and keeps answering with that
// representative.
func TestVerifyClosedRepresentativeFallsBackToOwnPosting(t *testing.T) {
	e := vrfyNewEnv(t)

	goneRep := e.insert(t, "acme:rep", "https://jobs.ashbyhq.com/acme/0d3f6b52", "platform-engineer-acme")
	liveDup := e.insert(t, "acme:dup", "https://jobs.ashbyhq.com/acme/77aa1c90", "platform-engineer-acme-2")
	e.fold(t, liveDup, goneRep)
	e.close(t, goneRep)

	openRep := e.insert(t, "globex:rep", "https://himalayas.app/companies/globex/jobs/sre", "sre-globex")
	openDup := e.insert(t, "globex:dup", "https://jobs.lever.co/globex/3e9d8b14", "sre-globex-lever")
	e.fold(t, openDup, openRep)

	e.wantCarried(t, "https://jobs.ashbyhq.com/acme/77aa1c90", "platform-engineer-acme-2")
	e.wantCarried(t, "https://jobs.lever.co/globex/3e9d8b14", "sre-globex")
	e.wantNotCarried(t, "https://jobs.ashbyhq.com/acme/0d3f6b52")
}

// A posting that has closed answers not carried whether or not it was folded into
// another (with the representative open or closed), and a page freehire never stored
// answers not carried.
func TestVerifyClosedAndUnknownPagesNotCarried(t *testing.T) {
	e := vrfyNewEnv(t)

	plain := e.insert(t, "initech:plain", "https://jobs.ashbyhq.com/initech/41c0e7aa", "qa-initech")
	e.close(t, plain)

	rep := e.insert(t, "hooli:rep", "https://himalayas.app/companies/hooli/jobs/designer", "designer-hooli")
	closedDup := e.insert(t, "hooli:dup", "https://jobs.lever.co/hooli/a81f3c02", "designer-hooli-lever")
	e.fold(t, closedDup, rep)
	e.close(t, closedDup)

	goneRep := e.insert(t, "umbrella:rep", "https://himalayas.app/companies/umbrella/jobs/analyst", "analyst-umbrella")
	goneDup := e.insert(t, "umbrella:dup", "https://jobs.ashbyhq.com/umbrella/6b2d90fe", "analyst-umbrella-2")
	e.fold(t, goneDup, goneRep)
	e.close(t, goneRep)
	e.close(t, goneDup)

	e.wantNotCarried(t, "https://jobs.ashbyhq.com/initech/41c0e7aa")
	e.wantNotCarried(t, "https://jobs.lever.co/hooli/a81f3c02")
	e.wantNotCarried(t, "https://jobs.ashbyhq.com/umbrella/6b2d90fe")
	e.wantNotCarried(t, "https://example.test/careers/unheard-of")

	// The open representative of the closed duplicate still answers on its own page.
	e.wantCarried(t, "https://himalayas.app/companies/hooli/jobs/designer", "designer-hooli")
}

// Links that differ only by scheme, www., tracking query, fragment or trailing slash
// answer with the same posting. When two separate open postings store the same page,
// the one seen most recently wins, in either insert order.
func TestVerifyCosmeticVariantsAndRecency(t *testing.T) {
	e := vrfyNewEnv(t)

	t.Run("cosmetic variants", func(t *testing.T) {
		e.insert(t, "stark:noise", "https://jobs.ashbyhq.com/stark/2c4e6a80", "backend-stark")
		for _, requested := range []string{
			"https://jobs.ashbyhq.com/stark/2c4e6a80",
			"https://jobs.ashbyhq.com/stark/2c4e6a80?utm_source=freehire.me",
			"http://jobs.ashbyhq.com/stark/2c4e6a80",
			"https://www.jobs.ashbyhq.com/stark/2c4e6a80/",
			"https://jobs.ashbyhq.com/stark/2c4e6a80#apply",
		} {
			e.wantCarried(t, requested, "backend-stark")
		}
	})

	t.Run("most recently seen wins when the stale posting came first", func(t *testing.T) {
		stale := e.insert(t, "wayne:stale", "https://himalayas.app/companies/wayne/jobs/ml-engineer", "ml-engineer-wayne-old")
		e.insert(t, "wayne:fresh", "https://himalayas.app/companies/wayne/jobs/ml-engineer", "ml-engineer-wayne")
		e.age(t, stale, "10 days")
		e.wantCarried(t, "https://himalayas.app/companies/wayne/jobs/ml-engineer", "ml-engineer-wayne")
	})

	t.Run("most recently seen wins when the stale posting came second", func(t *testing.T) {
		e.insert(t, "tyrell:fresh", "https://jobs.lever.co/tyrell/90be1d37", "android-tyrell")
		stale := e.insert(t, "tyrell:stale", "https://jobs.lever.co/tyrell/90be1d37", "android-tyrell-old")
		e.age(t, stale, "10 days")
		e.wantCarried(t, "https://jobs.lever.co/tyrell/90be1d37", "android-tyrell")
	})
}

// The lookup stays on an index. The endpoint answers one folded page while every
// statement it sends is recorded; each is then EXPLAINed with its own arguments and
// sequential scans switched off. No plan may scan the jobs table sequentially, and a
// statement that matches the page through normalize_job_url must use an index built on
// that expression, whatever the query shape, layer or number of statements.
func TestVerifyLookupStaysOnIndex(t *testing.T) {
	e := vrfyNewEnv(t)
	ctx := context.Background()

	// Enough open postings that a scan of the whole table, or of an index unrelated to
	// the page URL, costs clearly more than a lookup on the URL itself.
	if _, err := e.pool.Exec(ctx,
		`INSERT INTO jobs (source, external_id, url, title, public_slug)
		 SELECT 'vrfy', 'filler:' || g, 'https://jobs.ashbyhq.com/filler/' || g, 'A Role', 'filler-' || g
		 FROM generate_series(1, 2000) AS g`); err != nil {
		t.Fatalf("seed filler postings: %v", err)
	}
	rep := e.insert(t, "cyberdyne:rep", "https://himalayas.app/companies/cyberdyne/jobs/firmware", "firmware-cyberdyne")
	dup := e.insert(t, "cyberdyne:dup", "https://jobs.ashbyhq.com/cyberdyne/e3a7c519", "firmware-cyberdyne-2")
	e.fold(t, dup, rep)
	if _, err := e.pool.Exec(ctx, "ANALYZE jobs"); err != nil {
		t.Fatalf("analyze jobs: %v", err)
	}

	e.rec.reset()
	e.wantCarried(t, "https://jobs.ashbyhq.com/cyberdyne/e3a7c519", "firmware-cyberdyne")
	stmts := e.rec.statements()
	if len(stmts) == 0 {
		t.Fatal("the endpoint sent no statement through its queries")
	}

	// One pooled session: the planner setting and the EXPLAINs must share a connection.
	conn, err := e.pool.Acquire(ctx)
	if err != nil {
		t.Fatalf("acquire connection: %v", err)
	}
	defer conn.Release()
	if _, err := conn.Exec(ctx, "SET enable_seqscan = off"); err != nil {
		t.Fatalf("disable seqscan: %v", err)
	}

	for _, st := range stmts {
		var planJSON []byte
		if err := conn.QueryRow(ctx, "EXPLAIN (FORMAT JSON) "+st.sql, st.args...).Scan(&planJSON); err != nil {
			t.Fatalf("explain %q: %v", st.sql, err)
		}
		var plan []map[string]any
		if err := json.Unmarshal(planJSON, &plan); err != nil {
			t.Fatalf("parse plan JSON: %v", err)
		}

		for _, entry := range plan {
			if vrfyHasSeqScanOnJobs(entry) {
				t.Errorf("with enable_seqscan=off this statement still scans jobs sequentially:\n%s\nplan:\n%s", st.sql, planJSON)
			}
		}

		if !strings.Contains(st.sql, "normalize_job_url") {
			continue
		}
		used := map[string]bool{}
		for _, entry := range plan {
			vrfyCollectIndexNames(entry, used)
		}
		if !vrfyAnyNormalizedURLIndex(t, conn, used) {
			names := make([]string, 0, len(used))
			for name := range used {
				names = append(names, name)
			}
			t.Errorf("statement matching on normalize_job_url uses no index on that expression (indexes used: %v):\n%s\nplan:\n%s",
				names, st.sql, planJSON)
		}
	}
}

// vrfyAnyNormalizedURLIndex reports whether any of the named indexes is defined over
// normalize_job_url.
func vrfyAnyNormalizedURLIndex(t *testing.T, conn *pgxpool.Conn, names map[string]bool) bool {
	t.Helper()
	for name := range names {
		var def string
		err := conn.QueryRow(context.Background(),
			"SELECT indexdef FROM pg_indexes WHERE schemaname = 'public' AND indexname = $1", name).Scan(&def)
		if errors.Is(err, pgx.ErrNoRows) {
			continue
		}
		if err != nil {
			t.Fatalf("read definition of index %q: %v", name, err)
		}
		if strings.Contains(def, "normalize_job_url") {
			return true
		}
	}
	return false
}

// vrfyHasSeqScanOnJobs reports whether any node in an EXPLAIN (FORMAT JSON) plan tree
// is a sequential scan over the jobs table, at any depth.
func vrfyHasSeqScanOnJobs(node any) bool {
	switch n := node.(type) {
	case map[string]any:
		if nt, _ := n["Node Type"].(string); nt == "Seq Scan" {
			if rel, _ := n["Relation Name"].(string); rel == "jobs" {
				return true
			}
		}
		for _, v := range n {
			if vrfyHasSeqScanOnJobs(v) {
				return true
			}
		}
	case []any:
		for _, v := range n {
			if vrfyHasSeqScanOnJobs(v) {
				return true
			}
		}
	}
	return false
}

// vrfyCollectIndexNames walks an EXPLAIN (FORMAT JSON) plan tree collecting every
// "Index Name" the planner reports, at any depth.
func vrfyCollectIndexNames(node any, out map[string]bool) {
	switch n := node.(type) {
	case map[string]any:
		if name, ok := n["Index Name"].(string); ok && name != "" {
			out[name] = true
		}
		for _, v := range n {
			vrfyCollectIndexNames(v, out)
		}
	case []any:
		for _, v := range n {
			vrfyCollectIndexNames(v, out)
		}
	}
}
