## Task

We hand read-only .NET collections to scripts, with `Interop.AllowWrite = true` and `Interop.ArrayConversion = ArrayConversionMode.LiveView` set on the engine.
When a script tries to change one of them, `engine.Evaluate(...)` throws a raw `System.NotSupportedException`.
The script's own `try`/`catch` never sees it, and neither does the `catch (JavaScriptException)` we keep around `Evaluate`.

Smallest repro:

```csharp
var engine = new Engine(o =>
{
    o.Interop.AllowWrite = true;
    o.Interop.ArrayConversion = ArrayConversionMode.LiveView;
});
engine.SetValue("x", new ReadOnlyCollection<int>(new List<int> { 1, 2, 3 }));
engine.Evaluate("try { x.push(4); } catch (e) { 'caught'; }"); // NotSupportedException escapes
```

We've hit it with `ReadOnlyCollection<int>`, with our own class that implements only `IReadOnlyList<int>`, and with `ArrayList.ReadOnly(...)`.
Depending on the type, it comes from `push`, `pop`, `splice`, `x[0] = 9`, `delete x[0]` or an assignment to `x.length`.

A plain `int[]` exposed the same way can't grow either, and it behaves fine.
Element writes go through, and `x.push(4)` throws a `TypeError` the script can catch.

For those three read-only types we want what a frozen array (`Object.freeze([1, 2, 3])`) does:

- `push`, `pop` and `splice` throw a `TypeError`, in sloppy and in strict mode.
- `x[0] = 9`, `delete x[0]` and `x.length = n` (growing or shrinking) throw a `TypeError` in strict mode, and quietly do nothing in sloppy mode.
- A refused call leaves the collection exactly as it was, read back from the script or from .NET.
- Reading the collection, for example with `x.join(',')`, still works.
- If the script doesn't catch the `TypeError`, it reaches the host as a `JavaScriptException`.

Watch out for `ArraySegment<int>`.
It is a fixed-size window over an array, not a read-only collection.
`seg[0] = 9` must keep writing into the underlying array in both modes, while `push` and `pop` on it throw a `TypeError` and leave it unchanged.

A growable `List<int>` should keep growing on `push` and keep taking element writes.
It also throws `ArgumentOutOfRangeException` on a write past its end, but that's a separate issue, so leave it alone.

The code is in `/repo/jint`.
The .NET 10 SDK is on PATH and the NuGet cache is already filled, so builds work without network.
Everything above can be reproduced from the public API (`Engine`, `Options`, `SetValue`, `Evaluate`), the same way an embedding app would.
