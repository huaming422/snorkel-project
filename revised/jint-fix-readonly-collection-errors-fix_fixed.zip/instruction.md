## Task

We hand read-only .NET collections to scripts, with `Interop.AllowWrite = true` and `Interop.ArrayConversion = ArrayConversionMode.LiveView` set on the engine.
When a script tries to change one of them, `engine.Evaluate(...)` throws a raw `System.NotSupportedException`.
The script's own `try`/`catch` never sees it, and neither does the `catch (JavaScriptException)` we keep around `Evaluate`.

Smallest repro:

```csharp
var engine = new Engine(o =>
{
    o.Interop.AllowWrite = true;
    o.Interop.ArrayConversion = ArrayConversionMode.LiveView;
});
engine.SetValue("x", new ReadOnlyCollection<int>(new List<int> { 1, 2, 3 }));
engine.Evaluate("try { x.push(4); } catch (e) { 'caught'; }"); // NotSupportedException escapes
```

We've hit it with six types: `ReadOnlyCollection<int>`, `ImmutableList<int>`, `ImmutableArray<int>`, `ArrayList.ReadOnly(...)`, our own `IList<int>` whose `IsReadOnly` returns `true` and whose setters throw, and our own class that implements only `IReadOnlyList<int>`.
Depending on the type, it comes from `push`, `pop`, `splice`, `sort`, `reverse`, `x[0] = 9`, a write past the end like `x[3] = 9`, `delete x[0]` or an assignment to `x.length`.
We call `sort` and `reverse` as `Array.prototype.sort.call(x, compare)` and `Array.prototype.reverse.call(x)`, since `x.sort` on the immutable types picks up their own .NET methods.

A plain `int[]` exposed the same way can't grow either, and it behaves fine.
Element writes go through, and `x.push(4)` throws a `TypeError` the script can catch.

For those six types, the operations above should do what they do on a frozen array (`Object.freeze([1, 2, 3])`):

- `push`, `pop`, `splice`, `sort` and `reverse` throw a `TypeError`, in sloppy and in strict mode.
- `x[0] = 9`, `x[3] = 9`, `delete x[0]` and `x.length = n` (growing or shrinking) throw a `TypeError` in strict mode, and quietly do nothing in sloppy mode.
- A refused call leaves the collection exactly as it was, read back from the script or from .NET.
- Reading the collection, for example with `x.join(',')`, still works.
- If the script doesn't catch the `TypeError`, it reaches the host as a `JavaScriptException`.

`ArraySegment<int>` throws the same raw exception on `push` and `pop`, and `pop` clears its last element before it fails.
Its element writes work today and have to keep working, so `seg[0] = 9` and `Array.prototype.reverse.call(seg)` still write into the underlying array in both modes.
`push` and `pop` on it should throw a `TypeError` and leave it unchanged.

A growable `List<int>` should keep changing on `push`, element writes, `reverse` and growing `x.length`.
It also throws `ArgumentOutOfRangeException` on a write past its end, but that's a separate issue, so leave it alone.

The code is in `/repo/jint`.
The .NET 10 SDK is on PATH and the NuGet cache is already filled, so builds work without network.
Everything above can be reproduced from the public API (`Engine`, `Options`, `SetValue`, `Evaluate`), the same way an embedding app would.
