#!/usr/bin/env bash
# test-setup.sh - sourced before the verifier runs.
#
# Rebuilds the edited Jint engine (Release, net10.0) from the NuGet closure
# baked into the image, so the verifier's standalone C# probe can reference a
# fresh Jint.dll. Dependencies are baked into the image and a Release net10.0
# build of Jint is already warm, so this rebuild is incremental: only changed
# source files recompile, typically in tens of seconds. Runs offline-first with
# a logged online fallback.
set -euo pipefail

cd /repo/jint

# --- .NET / NuGet offline switches (scoped to THIS task's tooling only) -------
# These make a cache miss fail fast against the warm store instead of hanging
# on a cut network. They are exported here (not baked as image ENV) so they
# never reach the trial-prep `uv tool install` that harbor runs while the
# network is still up.
export DOTNET_CLI_TELEMETRY_OPTOUT=1
export DOTNET_NOLOGO=1
export DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1
export DOTNET_GENERATE_ASPNET_CERTIFICATE=false
# The global-packages folder the image warmed during its restore layer.
export NUGET_PACKAGES="${NUGET_PACKAGES:-/opt/nuget/packages}"
export DOTNET_ROOT="${DOTNET_ROOT:-/usr/local/dotnet}"
export PATH="${DOTNET_ROOT}:${PATH}"

echo "test-setup: dotnet $(dotnet --version 2>/dev/null || echo '??') | NUGET_PACKAGES=${NUGET_PACKAGES}"

# --- Rebuild the edited Jint, offline-first ----------------------------------
# --no-restore uses the packages the image already placed in NUGET_PACKAGES.
# If the offline build fails (for example on a package the cache does not
# hold), we fall back to an online restore so the verifier can still run; a
# restore fetch is logged, not silently swallowed.
echo "test-setup: rebuilding Jint (Release, net10.0) offline..."
if dotnet build Jint/Jint.csproj -c Release -f net10.0 --no-restore \
        > /tmp/test-setup-build.log 2>&1; then
    echo "test-setup: offline rebuild OK."
else
    echo "test-setup: offline rebuild failed; tail of log:" >&2
    tail -60 /tmp/test-setup-build.log >&2
    echo "test-setup: attempting online restore + rebuild as a logged fallback..." >&2
    dotnet restore Jint/Jint.csproj > /tmp/test-setup-restore.log 2>&1 \
        || { echo "test-setup: online restore failed"; tail -60 /tmp/test-setup-restore.log >&2; exit 1; }
    dotnet build Jint/Jint.csproj -c Release -f net10.0 --no-restore \
        > /tmp/test-setup-build2.log 2>&1 \
        || { echo "test-setup: rebuild after online restore failed"; tail -60 /tmp/test-setup-build2.log >&2; exit 1; }
    echo "test-setup: rebuild OK after online restore."
fi

# Surface the built Jint.dll location for the verifier probe. The Release
# net10.0 output lands under artifacts/bin/Jint/ (ArtifactsPath layout);
# glob for it rather than hardcoding the exact folder name.
JINT_DLL="$(find /repo/jint/artifacts/bin/Jint -type f -name Jint.dll -path '*net10.0*' 2>/dev/null | head -1 || true)"
if [ -z "${JINT_DLL}" ]; then
    # Fallback to the classic bin/ layout if ArtifactsPath is not in effect.
    JINT_DLL="$(find /repo/jint/Jint/bin -type f -name Jint.dll -path '*net10.0*' 2>/dev/null | head -1 || true)"
fi
if [ -z "${JINT_DLL}" ]; then
    echo "test-setup: WARNING - could not locate built Jint.dll under artifacts/ or Jint/bin" >&2
else
    echo "test-setup: Jint.dll at ${JINT_DLL}"
    export JINT_DLL
fi

echo "test-setup: ready."
