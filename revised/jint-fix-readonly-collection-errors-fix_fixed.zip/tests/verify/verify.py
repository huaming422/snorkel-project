"""Behavioral verifier for how script writes to read-only host collections are refused.

The behavior lives in the embedding engine's .NET assembly, so it is observed the
way a .NET host sees it: a small standalone program references the rebuilt engine
project and drives it through the public embedding surface (the engine object, its
options, the value binder and the evaluate entry point), with no access to engine
internals.

`test-setup.sh` rebuilds the engine. This module writes a throwaway console
program and project file under a temp directory (outside the repository tree, so
it inherits none of the repo's build settings), builds it once, then runs it once
per behavioral group.

Each case runs on a fresh engine and reports one line of the form
`<outcome>|<contents seen by script>|<contents of the .NET backing store>`:

- `TypeError` / `no-throw`: what the script's own try/catch saw.
- `host:TypeError`: the uncaught error reached the host as the engine's script
  error type and is a TypeError.
- `clr:<type>`: some other .NET exception came out of the evaluate call.

The contents are read back after the operation, from script with `join` and from
.NET by enumerating the backing store, so a refusal that still changed the
collection, or a fix that stops script from reading it, shows up in the outcome.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# The standalone embedder program. One argument selects a group; it prints one
# JSON line of {case -> outcome} and exits 0.
# ---------------------------------------------------------------------------
PROBE_SOURCE = r"""
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using Jint;
using Jint.Native;
using Jint.Runtime;

internal static class Probe
{
    private static readonly string[] ReadOnlyShapes = { "readonly_collection", "readonly_list_only", "arraylist_readonly" };
    private static readonly string[] LengthChangingOps = { "host.push(42)", "host.pop()", "host.splice(0, 1)" };
    private static readonly string[] PlainWriteOps = { "host[0] = 42", "delete host[0]", "host.length = 5", "host.length = 1" };

    // A host type that offers reads only and no writing member of any kind.
    private sealed class HostReadOnlySequence : IReadOnlyList<int>
    {
        private readonly List<int> _items;
        public HostReadOnlySequence(List<int> items) => _items = items;
        public int Count => _items.Count;
        public int this[int index] => _items[index];
        public IEnumerator<int> GetEnumerator() => _items.GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
    }

    private sealed class Subject
    {
        public Subject(object host, IEnumerable backing)
        {
            Host = host;
            Backing = backing;
        }

        public object Host { get; }

        public IEnumerable Backing { get; }
    }

    // Every shape gets its own contents, so an outcome can only match when the
    // values really came from that collection.
    private static Subject Make(string shape)
    {
        switch (shape)
        {
            case "readonly_collection":
            {
                var items = new List<int> { 4, 7, 2 };
                return new Subject(new ReadOnlyCollection<int>(items), items);
            }
            case "readonly_list_only":
            {
                var items = new List<int> { 5, 8, 6 };
                return new Subject(new HostReadOnlySequence(items), items);
            }
            case "arraylist_readonly":
            {
                var items = new ArrayList { 3, 9, 1 };
                return new Subject(ArrayList.ReadOnly(items), items);
            }
            case "array_segment":
            {
                var items = new[] { 0, 6, 2, 5, 0 };
                return new Subject(new ArraySegment<int>(items, 1, 3), items);
            }
            case "growable_list":
            {
                var items = new List<int> { 1, 2, 3 };
                return new Subject(items, items);
            }
            case "live_array":
            {
                var items = new[] { 8, 3, 5 };
                return new Subject(items, items);
            }
        }

        throw new ArgumentException("unknown shape: " + shape);
    }

    private static Engine CreateEngine(object host, bool strict)
    {
        var engine = new Engine(options =>
        {
            options.Strict = strict;
            options.Interop.AllowWrite = true;
            options.Interop.ArrayConversion = ArrayConversionMode.LiveView;
        });
        engine.SetValue("host", host);
        return engine;
    }

    private static string Join(IEnumerable items)
    {
        var sb = new StringBuilder();
        foreach (var item in items)
        {
            if (sb.Length > 0)
            {
                sb.Append(',');
            }
            sb.Append(item);
        }
        return sb.ToString();
    }

    // scriptCatch: the operation runs inside the script's own try/catch.
    // Otherwise it runs bare and the host's catch around Evaluate sees what escapes.
    private static string Run(string shape, string op, bool strict, bool scriptCatch)
    {
        var subject = Make(shape);
        var engine = CreateEngine(subject.Host, strict);
        var prologue = strict ? "'use strict';\n" : "";
        string outcome;
        try
        {
            if (scriptCatch)
            {
                outcome = engine.Evaluate(prologue
                    + "(function () { var r; try { " + op + "; r = 'no-throw'; } "
                    + "catch (e) { r = e instanceof TypeError ? 'TypeError' : 'other:' + e; } "
                    + "return r + '|' + host.join(','); })()").AsString();
            }
            else
            {
                engine.Evaluate(prologue + op + ";");
                outcome = "no-throw|" + engine.Evaluate("host.join(',')").AsString();
            }
        }
        catch (JavaScriptException ex)
        {
            engine.SetValue("__error", ex.Error);
            var isTypeError = engine.Evaluate("__error instanceof TypeError").AsBoolean();
            outcome = (isTypeError ? "host:TypeError" : "host:other:" + ex.Message)
                + "|" + engine.Evaluate("host.join(',')").AsString();
        }
        catch (Exception ex)
        {
            // any other exception out of Evaluate is reported by its type
            return "clr:" + ex.GetType().FullName + "|?|" + Join(subject.Backing);
        }

        return outcome + "|" + Join(subject.Backing);
    }

    private static void Add(Dictionary<string, string> r, string shape, string op, bool strict, bool scriptCatch)
    {
        var key = shape + " / " + op + " / " + (strict ? "strict" : "sloppy") + " / " + (scriptCatch ? "script-catch" : "host-catch");
        r[key] = Run(shape, op, strict, scriptCatch);
    }

    public static int Main(string[] args)
    {
        var which = args.Length > 0 ? args[0] : "";
        var r = new Dictionary<string, string>();
        var modes = new[] { false, true };

        switch (which)
        {
            case "length_changing":
                foreach (var shape in ReadOnlyShapes)
                    foreach (var op in LengthChangingOps)
                        foreach (var strict in modes)
                            Add(r, shape, op, strict, scriptCatch: true);
                break;

            case "plain_writes":
                foreach (var shape in ReadOnlyShapes)
                    foreach (var op in PlainWriteOps)
                        foreach (var strict in modes)
                            Add(r, shape, op, strict, scriptCatch: true);
                break;

            case "uncaught":
                foreach (var shape in ReadOnlyShapes)
                {
                    foreach (var op in LengthChangingOps)
                        foreach (var strict in modes)
                            Add(r, shape, op, strict, scriptCatch: false);
                    foreach (var op in PlainWriteOps)
                        foreach (var strict in modes)
                            Add(r, shape, op, strict, scriptCatch: false);
                }
                break;

            case "segment":
                foreach (var op in new[] { "host[0] = 42", "host.push(42)", "host.pop()" })
                    foreach (var strict in modes)
                        Add(r, "array_segment", op, strict, scriptCatch: true);
                break;

            case "writable":
                foreach (var strict in modes)
                {
                    Add(r, "growable_list", "host.push(42)", strict, scriptCatch: true);
                    Add(r, "growable_list", "host[0] = 42", strict, scriptCatch: true);
                    Add(r, "live_array", "host[0] = 42", strict, scriptCatch: true);
                    Add(r, "live_array", "host.push(42)", strict, scriptCatch: true);
                }
                break;

            default:
                Console.Error.WriteLine("unknown group: " + which);
                return 2;
        }

        Console.WriteLine(ToJson(r));
        return 0;
    }

    private static string ToJson(Dictionary<string, string> d)
    {
        var sb = new StringBuilder();
        sb.Append('{');
        var first = true;
        foreach (var kv in d)
        {
            if (!first)
            {
                sb.Append(',');
            }
            first = false;
            sb.Append('"').Append(Escape(kv.Key)).Append("\":\"").Append(Escape(kv.Value)).Append('"');
        }
        sb.Append('}');
        return sb.ToString();
    }

    private static string Escape(string s) =>
        s.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\r", "").Replace("\n", "\\n");
}
"""

PROBE_TIMEOUT = 300

# Contents each read-only shape starts with (script view and .NET backing store agree).
READ_ONLY_SHAPES = {
    "readonly_collection": "4,7,2",
    "readonly_list_only": "5,8,6",
    "arraylist_readonly": "3,9,1",
}
LENGTH_CHANGING_OPS = ("host.push(42)", "host.pop()", "host.splice(0, 1)")
PLAIN_WRITE_OPS = ("host[0] = 42", "delete host[0]", "host.length = 5", "host.length = 1")
MODES = ("sloppy", "strict")


def _dotnet() -> str:
    exe = shutil.which("dotnet")
    if exe:
        return exe
    for candidate in ("/usr/local/dotnet/dotnet", "/usr/share/dotnet/dotnet"):
        if Path(candidate).is_file():
            return candidate
    raise RuntimeError("dotnet CLI not found on PATH or in the usual locations")


def _engine_project() -> Path:
    """Locate the engine's own project file. The probe references the project, the
    way the repo's own public-surface suite does, so all transitive dependencies
    resolve into the probe's output."""
    env = os.environ.get("JINT_CSPROJ")
    if env and Path(env).is_file():
        return Path(env)
    for candidate in (
        "/repo/jint/Jint/Jint.csproj",
        "/repo/jint/jint/Jint.csproj",
    ):
        if Path(candidate).is_file():
            return Path(candidate)
    hits = sorted(Path("/repo/jint").rglob("Jint.csproj"))
    hits = [h for h in hits if h.parent.name.lower() == "jint"]
    if hits:
        return hits[0]
    raise RuntimeError("could not locate the engine project file (Jint.csproj) under /repo/jint")


def _write_project(work: Path) -> None:
    engine_csproj = _engine_project()
    csproj = f"""<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <OutputType>Exe</OutputType>
    <TargetFramework>net10.0</TargetFramework>
    <Nullable>disable</Nullable>
    <ImplicitUsings>disable</ImplicitUsings>
    <TreatWarningsAsErrors>false</TreatWarningsAsErrors>
    <AssemblyName>collectionprobe</AssemblyName>
    <EnableDefaultCompileItems>true</EnableDefaultCompileItems>
    <RestorePackagesWithLockFile>false</RestorePackagesWithLockFile>
  </PropertyGroup>
  <ItemGroup>
    <ProjectReference Include="{engine_csproj}" />
  </ItemGroup>
</Project>
"""
    (work / "collectionprobe.csproj").write_text(csproj)
    (work / "Program.cs").write_text(PROBE_SOURCE)


@pytest.fixture(scope="session")
def probe_exe() -> Path:
    """Build the standalone embedder program once and return its built assembly."""
    work = Path(tempfile.mkdtemp(prefix="collection-probe-"))
    _write_project(work)

    env = {**os.environ}
    env.setdefault("DOTNET_CLI_TELEMETRY_OPTOUT", "1")
    env.setdefault("DOTNET_NOLOGO", "1")
    env.setdefault("DOTNET_SKIP_FIRST_TIME_EXPERIENCE", "1")
    env.setdefault("NUGET_PACKAGES", "/opt/nuget/packages")

    # The restore runs offline from the warm package cache. The package
    # vulnerability audit needs nuget.org, and the repo treats warnings as
    # errors, so it is switched off for every project in the restore graph.
    proc = subprocess.run(
        [_dotnet(), "build", "-c", "Release", "-v", "quiet", "--nologo", "-p:NuGetAudit=false"],
        cwd=str(work),
        capture_output=True,
        text=True,
        timeout=PROBE_TIMEOUT,
        env=env,
        check=False,
    )
    if proc.returncode != 0:
        raise RuntimeError(
            "probe build failed (exit "
            f"{proc.returncode})\nSTDOUT:\n{proc.stdout[-4000:]}\nSTDERR:\n{proc.stderr[-4000:]}"
        )

    built = work / "bin" / "Release" / "net10.0" / "collectionprobe.dll"
    if not built.is_file():
        raise RuntimeError(f"probe build reported success but {built} is missing")
    return built


def _run_group(probe_exe: Path, group: str) -> dict:
    env = {**os.environ}
    env.setdefault("NUGET_PACKAGES", "/opt/nuget/packages")
    proc = subprocess.run(
        [_dotnet(), str(probe_exe), group],
        capture_output=True,
        text=True,
        timeout=PROBE_TIMEOUT,
        env=env,
        check=False,
    )
    assert proc.returncode == 0, (
        f"the embedder program exited {proc.returncode} running group '{group}'.\n"
        f"STDERR:\n{proc.stderr[-2000:]}"
    )
    for candidate in reversed(proc.stdout.strip().splitlines()):
        candidate = candidate.strip()
        if candidate.startswith("{"):
            return json.loads(candidate)
    raise AssertionError(f"group '{group}' produced no JSON.\nSTDOUT:\n{proc.stdout[-2000:]}")


def _key(shape: str, op: str, mode: str, catch: str) -> str:
    return f"{shape} / {op} / {mode} / {catch}"


def _assert_outcomes(actual: dict, expected: dict) -> None:
    wrong = {k: {"expected": v, "actual": actual.get(k)} for k, v in expected.items() if actual.get(k) != v}
    assert not wrong, json.dumps(wrong, indent=1)


def test_length_changing_calls_on_read_only_collections_throw_type_error(probe_exe):
    """push, pop and splice on each read-only shape throw a TypeError the script
    catches, in sloppy and strict mode, and leave the contents unchanged."""
    expected = {
        _key(shape, op, mode, "script-catch"): f"TypeError|{contents}|{contents}"
        for shape, contents in READ_ONLY_SHAPES.items()
        for op in LENGTH_CHANGING_OPS
        for mode in MODES
    }
    _assert_outcomes(_run_group(probe_exe, "length_changing"), expected)


def test_plain_writes_on_read_only_collections_follow_frozen_array_rules(probe_exe):
    """An element write, a delete, and growing or shrinking length throw a
    TypeError in strict mode and do nothing in sloppy mode; either way the
    contents stay the same."""
    expected = {
        _key(shape, op, mode, "script-catch"): f"{'TypeError' if mode == 'strict' else 'no-throw'}|{contents}|{contents}"
        for shape, contents in READ_ONLY_SHAPES.items()
        for op in PLAIN_WRITE_OPS
        for mode in MODES
    }
    _assert_outcomes(_run_group(probe_exe, "plain_writes"), expected)


def test_uncaught_refusal_reaches_host_as_script_type_error(probe_exe):
    """With no script try/catch, every refusal that throws reaches the host's
    catch around Evaluate as a script error that is a TypeError."""
    expected = {}
    for shape, contents in READ_ONLY_SHAPES.items():
        for mode in MODES:
            for op in LENGTH_CHANGING_OPS:
                expected[_key(shape, op, mode, "host-catch")] = f"host:TypeError|{contents}|{contents}"
            for op in PLAIN_WRITE_OPS:
                seen = "host:TypeError" if mode == "strict" else "no-throw"
                expected[_key(shape, op, mode, "host-catch")] = f"{seen}|{contents}|{contents}"
    _assert_outcomes(_run_group(probe_exe, "uncaught"), expected)


def test_array_segment_keeps_element_writes_and_refuses_growth(probe_exe):
    """An ArraySegment<int> over the middle of an array takes element writes into
    the underlying array in both modes; push and pop throw a TypeError and leave
    it unchanged."""
    expected = {}
    for mode in MODES:
        expected[_key("array_segment", "host[0] = 42", mode, "script-catch")] = "no-throw|42,2,5|0,42,2,5,0"
        expected[_key("array_segment", "host.push(42)", mode, "script-catch")] = "TypeError|6,2,5|0,6,2,5,0"
        expected[_key("array_segment", "host.pop()", mode, "script-catch")] = "TypeError|6,2,5|0,6,2,5,0"
    _assert_outcomes(_run_group(probe_exe, "segment"), expected)


def test_writable_hosts_keep_working(probe_exe):
    """A growable List<int> still grows and takes element writes; a live int[]
    still takes element writes and refuses push with a TypeError."""
    expected = {}
    for mode in MODES:
        expected[_key("growable_list", "host.push(42)", mode, "script-catch")] = "no-throw|1,2,3,42|1,2,3,42"
        expected[_key("growable_list", "host[0] = 42", mode, "script-catch")] = "no-throw|42,2,3|42,2,3"
        expected[_key("live_array", "host[0] = 42", mode, "script-catch")] = "no-throw|42,3,5|42,3,5"
        expected[_key("live_array", "host.push(42)", mode, "script-catch")] = "TypeError|8,3,5|8,3,5"
    _assert_outcomes(_run_group(probe_exe, "writable"), expected)
