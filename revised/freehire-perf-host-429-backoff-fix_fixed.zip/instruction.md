## Task

Two crawler problems keep showing up in the production journal, and both eat the run's request budget.

The first one is workable.
A run goes fine for about half an hour, then workable starts answering 429 Too Many Requests.
The other board workers keep sending requests to workable anyway and get refused as well.
Within two or three minutes around 1,500 workable boards are written down as failed.

When a host answers 429, every request the crawler sends to that host after that should wait before it goes out, not just the request that was refused, whether it is an API call or a page fetch.
Requests to other hosts shouldn't slow down at all.
The refused request itself still gets retried the way it is today, just after the wait.
A retry that goes out through the proxy fallback comes from a different address, so it doesn't need to wait.
The first wait can be anything from a tenth of a second to five seconds; around a second is fine.
If the host refuses again after a wait has run out, the next wait should be about twice as long.
Refusals that come back together while a wait is already running (several workers had requests in flight) count as one refusal, not one each.
Once the host serves a request successfully, its next refusal starts over from the first wait.
When the 429 carries `Retry-After: <seconds>`, the whole host waits at least that long, including requests that never saw the header.
Each host keeps its own count, so a host that has refused over and over doesn't make another host's first wait any longer, and a success on one host doesn't reset another host's count.

The second one is SmartRecruiters.
The board health dashboard lists about 1,300 SmartRecruiters boards whose last error is a 429, but all of them last failed in mid-September.
The journal has no SmartRecruiters 429s in the last two days, so those rows are old history and not current rate limiting.
The real problem is coverage.
A 50-minute run reaches only about 230 of its 7,988 boards, roughly half the runs end on the timeout, and close to 2,900 live boards have never been crawled.
Every run reads each posting's full details again, including postings we stored on earlier runs.

A SmartRecruiters crawl should only fetch details for postings we don't have yet.
A posting we already have should still come back from the crawl as present, with the title from the listing (trimmed) and the board's company, but without a detail request.
If the board listing itself fails, the crawl of that board should still fail instead of coming back with nothing.

Pasting a single SmartRecruiters posting link to import it has to work with this.
Those links put the posting id at the front of the last path part, followed by a dash and the title, like `https://jobs.smartrecruiters.com/Acme/744000022222222-senior-go`.
The link should bring in that posting with its full details, without fetching details for the board's other postings.
That includes an old link whose title part no longer matches because the posting was renamed since.
A posting with no id should never be matched by a link this way.
