#!/usr/bin/env bash
#
# Sourced (not exec'd) before the verifier's `go test`, so env we set persists
# for the runner. The Dockerfile already baked the Go toolchain, the module
# cache and the build cache at the pinned source; this re-asserts them in case
# the implementation changes or a wiped layer disturbed the environment.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/freehire}"
cd "$REPO_DIR"

# Make `go` reachable even if the harness scrubbed PATH.
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:/root/go/bin:$PATH ;;
esac

# The ingest unit tests are pure Go (httptest loopback, in-memory doubles); no
# cgo, no services, no datastore. Keep the toolchain pinned and local.
export CGO_ENABLED=0
export GOTOOLCHAIN=local

# Offline-first: the coding phase has no network, and dependencies are baked
# into the image. Fail fast on a cache miss instead of hanging against a dead
# proxy. (These are task-local exports, not image ENV.)
export GOFLAGS=-mod=mod
export GOPROXY=off

# Module check: a warm cache makes this a no-op, and a wiped layer recovers from
# the module cache without the network. One offline attempt only, since the
# coding phase has no network.
go mod download 2>/dev/null || true

echo "test-setup.sh: ready (CGO_ENABLED=$CGO_ENABLED, GOFLAGS=$GOFLAGS, GOPROXY=$GOPROXY)"
