#!/usr/bin/env bash
# Runs the repo's own unit suites for internal/ingest/sources and
# internal/ingest/linksource: URL normalization, every other provider adapter,
# the retry and refusal flow, and the existing link-resolution cases. They are
# run by package path only, so no name an implementation introduces is used.
#
# The Go verify files are a separate runner with their own -run filter, and the
# harness runs each runner on its own, so the two do not interfere.
#
# Env mirrors tests/test-setup.sh: offline, cgo off, local toolchain. The ingest
# tests are pure Go (httptest loopback and in-memory doubles) and need no
# services or datastore.
set -euo pipefail

export GOFLAGS="${GOFLAGS:--mod=mod}"
export CGO_ENABLED="${CGO_ENABLED:-0}"
export GOTOOLCHAIN="${GOTOOLCHAIN:-local}"
export GOPROXY="${GOPROXY:-off}"

REPO_DIR="${REPO_DIR:-/repo/freehire}"
cd "$REPO_DIR"

# Make `go` reachable even if the harness scrubbed PATH.
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:/root/go/bin:$PATH ;;
esac

go test -count=1 ./internal/ingest/sources/... ./internal/ingest/linksource/...

echo "verify_regression.sh: internal/ingest/sources + internal/ingest/linksource unit suites pass."
