// White-box checks for host-wide 429 pacing in the shared HTTP client and for
// SmartRecruiters' seen-posting crawl. The file sits in `package sources` for the
// same reason the repo's own http_test.go does: wiring an httptest loopback
// server into a *Client means setting its unexported transport field.
//
// Only names that already exist in the package are used: NewClient, the
// httpClient, refusalClient, maxRetries and retryDelay fields, GetJSON, GetHTML,
// NewSmartRecruiters and the HydratingSource interface. Pacing is observed as the wall-clock time at
// which each request reaches a stub server, so any internal layout, escalation
// formula or naming works.
//
// The length of the first wait is the implementation's choice, anywhere from a
// tenth of a second to five seconds. The checks therefore compare waits with
// each other (a later wait is about twice an earlier one, a wait after a success
// is back near the first one, a burst stays near one step) and use only a small
// absolute floor (50ms) to tell "a wait happened" from the 1ms retry delay these
// clients are given. The measured first wait is also checked against the
// tenth-of-a-second floor and the five-second ceiling.
package sources

import (
	"context"
	"encoding/json"
	"fmt"
	"math"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strconv"
	"strings"
	"sync"
	"testing"
	"time"
)

// vrRecorder records the wall-clock time of each request a stub server receives,
// under a caller-chosen label. All fields are guarded by mu.
type vrRecorder struct {
	mu   sync.Mutex
	hits map[string][]time.Time
}

func newVRRecorder() *vrRecorder { return &vrRecorder{hits: map[string][]time.Time{}} }

func (r *vrRecorder) record(tag string) {
	r.mu.Lock()
	r.hits[tag] = append(r.hits[tag], time.Now())
	r.mu.Unlock()
}

func (r *vrRecorder) times(tag string) []time.Time {
	r.mu.Lock()
	defer r.mu.Unlock()
	out := make([]time.Time, len(r.hits[tag]))
	copy(out, r.hits[tag])
	return out
}

func (r *vrRecorder) count(tag string) int {
	r.mu.Lock()
	defer r.mu.Unlock()
	return len(r.hits[tag])
}

// vrClient builds the production client, then swaps in the loopback transport and
// sets the retry budget. NewClient leaves the proxy fallback unset, so every
// attempt goes out on the direct egress. retryDelay is 1ms, so a retry that only
// waits for retryDelay comes back almost at once.
func vrClient(t *testing.T, transport *http.Client, maxRetries int) *Client {
	t.Helper()
	c := NewClient()
	c.httpClient = transport
	c.maxRetries = maxRetries
	c.retryDelay = time.Millisecond
	return c
}

// vrLocalhostURL gives an httptest server's URL with the host name "localhost"
// instead of "127.0.0.1", so two stub servers differ by host name as well as by
// port. A wait keyed by host name alone then still tells them apart.
func vrLocalhostURL(srv *httptest.Server) string {
	return strings.Replace(srv.URL, "127.0.0.1", "localhost", 1)
}

// gapFloor is the smallest gap counted as a wait. The 1ms retry delay stays far
// below it, and a first wait of a tenth of a second or more is above it.
const gapFloor = 50 * time.Millisecond

// firstWaitFloor and firstWaitCeiling bound the first wait (a tenth of a second
// to five seconds), with room for scheduler jitter.
const (
	firstWaitFloor   = 90 * time.Millisecond
	firstWaitCeiling = 5*time.Second + 250*time.Millisecond
)

// vrOneStep measures the first wait after a single 429 on a fresh client: one
// request to an always-429 host with one retry, timed between its two attempts.
func vrOneStep(t *testing.T) time.Duration {
	t.Helper()
	rec := newVRRecorder()
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		rec.record("h")
		w.WriteHeader(http.StatusTooManyRequests)
	}))
	defer srv.Close()
	c := vrClient(t, srv.Client(), 1)
	var out any
	_ = c.GetJSON(context.Background(), srv.URL+"/p", &out)
	hits := rec.times("h")
	if len(hits) < 2 {
		t.Fatalf("always-429 host saw %d attempts, want 2", len(hits))
	}
	step := hits[1].Sub(hits[0])
	if step < firstWaitFloor {
		t.Fatalf("the retry after a 429 went out %v later, want a first wait of at least a tenth of a second", step)
	}
	if step > firstWaitCeiling {
		t.Fatalf("the first wait after a 429 was %v, want at most five seconds", step)
	}
	return step
}

// After one request to a host draws a 429, a later request to that same host
// waits before it goes out, while a request to a different host goes out at once.
//
// The wait is set up first by a lone request with no retries (it fires once, gets
// the 429 and returns). Only then are the two probe requests started, so the wait
// is already in place when they go out.
func TestVRHostWide429HoldsLaterRequestsToTheSameHost(t *testing.T) {
	rec := newVRRecorder()
	refusing := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		rec.record("refusing")
		w.WriteHeader(http.StatusTooManyRequests)
	}))
	defer refusing.Close()
	healthy := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		rec.record("healthy")
		_, _ = w.Write([]byte(`{"ok":true}`))
	}))
	defer healthy.Close()

	c := vrClient(t, refusing.Client(), 0)
	var out struct {
		OK bool `json:"ok"`
	}

	_ = c.GetJSON(context.Background(), refusing.URL+"/arm", &out)
	if rec.count("refusing") != 1 {
		t.Fatalf("first request made %d hits, want 1", rec.count("refusing"))
	}

	launch := time.Now()
	var sameHit, otherHit time.Time
	var otherErr error
	var wg sync.WaitGroup
	wg.Add(2)
	go func() {
		defer wg.Done()
		var o struct {
			OK bool `json:"ok"`
		}
		_ = c.GetJSON(context.Background(), refusing.URL+"/probe", &o)
		hits := rec.times("refusing")
		sameHit = hits[len(hits)-1]
	}()
	go func() {
		defer wg.Done()
		var o struct {
			OK bool `json:"ok"`
		}
		otherErr = c.GetJSON(context.Background(), vrLocalhostURL(healthy)+"/probe", &o)
		if hits := rec.times("healthy"); len(hits) > 0 {
			otherHit = hits[0]
		}
	}()
	wg.Wait()

	if held := sameHit.Sub(launch); held < gapFloor {
		t.Errorf("a later request to the host that answered 429 went out %v after it started, want a wait of at least %v", held, gapFloor)
	}
	if otherErr != nil || otherHit.IsZero() {
		t.Fatalf("request to the other host: err %v, reached server %v; want a served request", otherErr, !otherHit.IsZero())
	}
	if delayed := otherHit.Sub(launch); delayed >= gapFloor {
		t.Errorf("a request to a different host went out %v after it started, want under %v", delayed, gapFloor)
	}
}

// The wait covers page fetches as well as API calls to the host. A 429 drawn by
// a JSON request holds a later HTML page request to the same host, and a 429
// drawn by an HTML page request holds a later JSON request.
func TestVRHostWide429HoldCoversJSONAndHTMLRequests(t *testing.T) {
	cases := []struct {
		name       string
		arm, probe func(c *Client, url string)
	}{
		{
			name:  "json_then_html",
			arm:   func(c *Client, url string) { var o any; _ = c.GetJSON(context.Background(), url, &o) },
			probe: func(c *Client, url string) { _, _ = c.GetHTML(context.Background(), url) },
		},
		{
			name:  "html_then_json",
			arm:   func(c *Client, url string) { _, _ = c.GetHTML(context.Background(), url) },
			probe: func(c *Client, url string) { var o any; _ = c.GetJSON(context.Background(), url, &o) },
		},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			rec := newVRRecorder()
			var mu sync.Mutex
			served := 0
			srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				rec.record("h")
				mu.Lock()
				n := served
				served++
				mu.Unlock()
				if n == 0 {
					w.WriteHeader(http.StatusTooManyRequests)
					return
				}
				if strings.HasSuffix(r.URL.Path, "/page") {
					w.Header().Set("Content-Type", "text/html; charset=utf-8")
					_, _ = w.Write([]byte(`<html><body><p>ok</p></body></html>`))
					return
				}
				_, _ = w.Write([]byte(`{"ok":true}`))
			}))
			defer srv.Close()

			c := vrClient(t, srv.Client(), 0)
			armURL, probeURL := srv.URL+"/api", srv.URL+"/page"
			if tc.name == "html_then_json" {
				armURL, probeURL = srv.URL+"/page", srv.URL+"/api"
			}
			tc.arm(c, armURL)
			if rec.count("h") != 1 {
				t.Fatalf("first request made %d hits, want 1", rec.count("h"))
			}
			launch := time.Now()
			tc.probe(c, probeURL)
			hits := rec.times("h")
			if len(hits) < 2 {
				t.Fatalf("the later request never reached the host (%d hits)", len(hits))
			}
			if held := hits[1].Sub(launch); held < gapFloor {
				t.Errorf("a later request to the host that answered 429 went out %v after it started, want a wait of at least %v", held, gapFloor)
			}
		})
	}
}

// A refusal that arrives after the previous wait ran out makes the next wait
// about twice as long. One request to an always-429 host with two retries
// gives two gaps between attempts, and those gaps are the two waits.
func TestVRHost429HoldEscalatesOnConsecutiveRefusals(t *testing.T) {
	rec := newVRRecorder()
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		rec.record("h")
		w.WriteHeader(http.StatusTooManyRequests)
	}))
	defer srv.Close()

	c := vrClient(t, srv.Client(), 2)
	var out any
	_ = c.GetJSON(context.Background(), srv.URL+"/p", &out)

	hits := rec.times("h")
	if len(hits) < 3 {
		t.Fatalf("host saw %d attempts, want 3 (first try and two retries)", len(hits))
	}
	gap1 := hits[1].Sub(hits[0])
	gap2 := hits[2].Sub(hits[1])
	if gap1 < gapFloor {
		t.Fatalf("first retry came %v after the 429, want a wait of at least %v", gap1, gapFloor)
	}
	// 1.4x to 3x leaves room for jitter around a doubling, while a wait that does
	// not grow stays near 1.0x and a much steeper jump goes past 3x.
	if gap2 < gap1*7/5 {
		t.Errorf("second wait %v is not clearly longer than the first %v (want at least 1.4x)", gap2, gap1)
	}
	if gap2 > gap1*3 {
		t.Errorf("second wait %v is more than 3x the first %v, want about twice", gap2, gap1)
	}
}

// After a 2xx from the host, its next refusal waits about as long as the first
// wait again. The warm-up request draws two refusals (first wait, then a longer
// one) and is then served. The probe request draws one refusal and is served; its
// wait has to be near the first wait, not the next step up from the second.
func TestVRHost429HoldResetsAfterASuccess(t *testing.T) {
	var mu sync.Mutex
	refusalsLeft := map[string]int{"/warm": 2, "/probe": 1}
	rec := newVRRecorder()
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		rec.record(r.URL.Path)
		mu.Lock()
		left := refusalsLeft[r.URL.Path]
		if left > 0 {
			refusalsLeft[r.URL.Path] = left - 1
		}
		mu.Unlock()
		if left > 0 {
			w.WriteHeader(http.StatusTooManyRequests)
			return
		}
		_, _ = w.Write([]byte(`{"ok":true}`))
	}))
	defer srv.Close()

	c := vrClient(t, srv.Client(), 3)
	var out any
	if err := c.GetJSON(context.Background(), srv.URL+"/warm", &out); err != nil {
		t.Fatalf("warm-up request was not served in the end: %v", err)
	}
	warm := rec.times("/warm")
	if len(warm) < 3 {
		t.Fatalf("warm-up path saw %d attempts, want 3 (two refusals, then served)", len(warm))
	}
	firstHold := warm[1].Sub(warm[0])
	secondHold := warm[2].Sub(warm[1])
	if firstHold < gapFloor {
		t.Fatalf("first wait %v is under %v", firstHold, gapFloor)
	}

	// Let any wait left over from the warm-up run out, so the probe's refusal
	// arrives after it and is not part of the same burst.
	time.Sleep(secondHold + gapFloor)

	if err := c.GetJSON(context.Background(), srv.URL+"/probe", &out); err != nil {
		t.Fatalf("probe request was not served in the end: %v", err)
	}
	probe := rec.times("/probe")
	if len(probe) < 2 {
		t.Fatalf("probe path saw %d attempts, want 2 (one refusal, then served)", len(probe))
	}
	probeHold := probe[1].Sub(probe[0])
	// Half to twice the first wait leaves room for jitter. Carrying on from the
	// warm-up count would give about four times the first wait, and no wait at
	// all would come in under half.
	if probeHold > 2*firstHold || probeHold < firstHold/2 {
		t.Errorf("after a served request the next refusal waited %v, want about the first wait %v (the warm-up's second wait was %v)",
			probeHold, firstHold, secondHold)
	}
}

// Refusals that all arrive while one wait is running count as one refusal. A
// server-side barrier holds eight concurrent first attempts until all eight have
// arrived and then refuses them together. Their retries go out after the wait the
// burst set, and that wait has to be about one step: not cut short, and within a
// small multiple of one step.
func TestVRHost429BurstCountsAsOneStep(t *testing.T) {
	oneStep := vrOneStep(t)

	const workers = 8
	recB := newVRRecorder()
	var bmu sync.Mutex
	arrived := 0
	gate := make(chan struct{})
	burstSrv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		recB.record("h")
		bmu.Lock()
		arrived++
		cur := arrived
		bmu.Unlock()
		if cur <= workers {
			if cur == workers {
				close(gate)
			}
			<-gate
		}
		w.WriteHeader(http.StatusTooManyRequests)
	}))
	defer burstSrv.Close()
	cB := vrClient(t, burstSrv.Client(), 1)
	var wg sync.WaitGroup
	for range workers {
		wg.Add(1)
		go func() {
			defer wg.Done()
			var o any
			_ = cB.GetJSON(context.Background(), burstSrv.URL+"/p", &o)
		}()
	}
	wg.Wait()

	hits := recB.times("h")
	if len(hits) != workers*2 {
		t.Fatalf("host saw %d attempts, want %d (8 requests x 2 attempts)", len(hits), workers*2)
	}
	// In arrival order the first eight hits are the first attempts and the next
	// eight are the retries. The wait the burst set is the gap between them.
	roundGap := hits[workers].Sub(hits[workers-1])
	// Half a step to 3x allows jitter and at most one extra doubling. The retries
	// still have to wait out the step the burst set.
	if roundGap > oneStep*3 {
		t.Errorf("after %d refusals that arrived together the wait was %v, more than 3x one step (%v)", workers, roundGap, oneStep)
	}
	if roundGap < oneStep/2 {
		t.Errorf("after %d refusals that arrived together the retries went out %v later, want about one step (%v)", workers, roundGap, oneStep)
	}
}

// Each host keeps its own escalation. Host A refuses twice in a row, so its next
// wait is past the first step. A request to host B on the same client then goes
// out without waiting for A, B's first refusal waits about one first step, and B
// is then served. Host A's next refusal still continues A's own count: B's
// success does not reset it.
func TestVRHost429EscalationIsPerHost(t *testing.T) {
	rec := newVRRecorder()
	srvA := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		rec.record("a")
		w.WriteHeader(http.StatusTooManyRequests)
	}))
	defer srvA.Close()
	var mu sync.Mutex
	servedB := 0
	srvB := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		rec.record("b")
		mu.Lock()
		n := servedB
		servedB++
		mu.Unlock()
		if n == 0 {
			w.WriteHeader(http.StatusTooManyRequests)
			return
		}
		_, _ = w.Write([]byte(`{"ok":true}`))
	}))
	defer srvB.Close()

	c := vrClient(t, srvA.Client(), 1)
	var out any
	_ = c.GetJSON(context.Background(), srvA.URL+"/p", &out)
	hitsA := rec.times("a")
	if len(hitsA) != 2 {
		t.Fatalf("host A saw %d attempts, want 2", len(hitsA))
	}
	firstA := hitsA[1].Sub(hitsA[0])
	if firstA < gapFloor {
		t.Fatalf("host A's first wait %v is under %v", firstA, gapFloor)
	}

	launch := time.Now()
	if err := c.GetJSON(context.Background(), vrLocalhostURL(srvB)+"/p", &out); err != nil {
		t.Fatalf("request to host B was not served in the end: %v", err)
	}
	hitsB := rec.times("b")
	if len(hitsB) < 2 {
		t.Fatalf("host B saw %d attempts, want 2 (one refusal, then served)", len(hitsB))
	}
	if first := hitsB[0].Sub(launch); first >= gapFloor {
		t.Errorf("host B's first request went out %v after it started; host A's wait must not hold it (want under %v)", first, gapFloor)
	}
	if holdB := hitsB[1].Sub(hitsB[0]); holdB > 2*firstA || holdB < firstA/2 {
		t.Errorf("host B's first refusal waited %v, want about one first step (host A's first wait was %v)", holdB, firstA)
	}

	// Host A again: its first attempt waits out what is left of A's wait, draws
	// A's third refusal, and the retry after it shows A's next step.
	_ = c.GetJSON(context.Background(), srvA.URL+"/p", &out)
	hitsA = rec.times("a")
	if len(hitsA) != 4 {
		t.Fatalf("host A saw %d attempts in total, want 4", len(hitsA))
	}
	// Two growth steps of at least 1.4x each give at least 1.96x the first wait;
	// a count reset by host B's success would give about 1x.
	if thirdA := hitsA[3].Sub(hitsA[2]); thirdA < firstA*3/2 {
		t.Errorf("host A's wait after its third refusal was %v, want its count to carry on past the first wait %v; a success on another host must not reset it",
			thirdA, firstA)
	}
}

// A 429 that names a Retry-After makes the whole host wait at least that long,
// including a later request that never saw the header. The header value is set to at least three times the measured first
// step, so a host that waits only its own first step comes in well under it.
//
// The wait is set up by a lone request with no retries, which gets the header and
// returns at once. The probe then runs on the same client while that wait is on.
func TestVRHost429RetryAfterFeedsTheHostWideHold(t *testing.T) {
	oneStep := vrOneStep(t)
	retryAfterSecs := int(math.Ceil((3 * oneStep).Seconds()))
	if retryAfterSecs < 3 {
		retryAfterSecs = 3
	}
	retryAfter := time.Duration(retryAfterSecs) * time.Second

	rec := newVRRecorder()
	var mu sync.Mutex
	served := 0
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		rec.record("h")
		mu.Lock()
		n := served
		served++
		mu.Unlock()
		if n == 0 {
			w.Header().Set("Retry-After", strconv.Itoa(retryAfterSecs))
			w.WriteHeader(http.StatusTooManyRequests)
			return
		}
		_, _ = w.Write([]byte(`{"ok":true}`))
	}))
	defer srv.Close()

	var out any
	c := vrClient(t, srv.Client(), 0)
	_ = c.GetJSON(context.Background(), srv.URL+"/arm", &out)
	if rec.count("h") != 1 {
		t.Fatalf("first request made %d hits, want 1", rec.count("h"))
	}

	c.maxRetries = 2
	launch := time.Now()
	if err := c.GetJSON(context.Background(), srv.URL+"/probe", &out); err != nil {
		t.Fatalf("probe request was not served in the end: %v", err)
	}
	all := rec.times("h")
	held := all[1].Sub(launch)
	if held < retryAfter*4/5 {
		t.Errorf("a later request went out %v after a 429 with Retry-After: %d (one first step is %v), want at least %v",
			held, retryAfterSecs, oneStep, retryAfter*4/5)
	}
}

// ---- Proxy fallback egress (refusalClient) ----

// vrRewriteTransport sends every request to base whatever URL was asked for, so a
// request for a made-up host name lands on a stub server. Two of these stand in
// for the direct egress and the proxy fallback.
type vrRewriteTransport struct{ base *url.URL }

func (t vrRewriteTransport) RoundTrip(r *http.Request) (*http.Response, error) {
	r = r.Clone(r.Context())
	r.URL.Scheme, r.URL.Host = t.base.Scheme, t.base.Host
	return http.DefaultTransport.RoundTrip(r)
}

// vrTwoWayClient builds the production client with its direct egress pointed at
// direct and its proxy fallback (the existing refusalClient field) pointed at
// fallback. One retry is enough for the fallback to get its turn.
func vrTwoWayClient(t *testing.T, direct, fallback *httptest.Server) *Client {
	t.Helper()
	du, err := url.Parse(direct.URL)
	if err != nil {
		t.Fatalf("parse direct: %v", err)
	}
	fu, err := url.Parse(fallback.URL)
	if err != nil {
		t.Fatalf("parse fallback: %v", err)
	}
	c := vrClient(t, &http.Client{Transport: vrRewriteTransport{du}, Timeout: 30 * time.Second}, 1)
	c.refusalClient = &http.Client{Transport: vrRewriteTransport{fu}, Timeout: 30 * time.Second}
	return c
}

// A 429 on the direct egress sends the retry through the proxy fallback, and that
// retry goes out at once: it comes from another address, so the host's wait does
// not apply to it. The same 429 still holds the next direct request to the host.
func TestVRFallbackRetryIsNotHeldByTheHostWait(t *testing.T) {
	rec := newVRRecorder()
	direct := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		rec.record("direct")
		w.WriteHeader(http.StatusTooManyRequests)
	}))
	defer direct.Close()
	fallback := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		rec.record("fallback")
		_, _ = w.Write([]byte(`{"ok":true}`))
	}))
	defer fallback.Close()

	c := vrTwoWayClient(t, direct, fallback)
	var out struct {
		OK bool `json:"ok"`
	}
	if err := c.GetJSON(context.Background(), "http://board.example/first", &out); err != nil || !out.OK {
		t.Fatalf("first request: err %v, ok %v; want it served by the fallback", err, out.OK)
	}
	d, f := rec.times("direct"), rec.times("fallback")
	if len(d) != 1 || len(f) != 1 {
		t.Fatalf("first request made %d direct and %d fallback hits, want 1 and 1", len(d), len(f))
	}
	if gap := f[0].Sub(d[0]); gap >= gapFloor {
		t.Errorf("the fallback retry went out %v after the direct 429, want under %v; the host's wait does not cover the fallback", gap, gapFloor)
	}

	launch := time.Now()
	out.OK = false
	if err := c.GetJSON(context.Background(), "http://board.example/second", &out); err != nil || !out.OK {
		t.Fatalf("second request: err %v, ok %v; want it served by the fallback", err, out.OK)
	}
	d, f = rec.times("direct"), rec.times("fallback")
	if len(d) != 2 || len(f) != 2 {
		t.Fatalf("after two requests there were %d direct and %d fallback hits, want 2 and 2", len(d), len(f))
	}
	if held := d[1].Sub(launch); held < gapFloor {
		t.Errorf("a later direct request to the host that answered 429 went out %v after it started, want a wait of at least %v", held, gapFloor)
	}
	if gap := f[1].Sub(d[1]); gap >= gapFloor {
		t.Errorf("the second fallback retry went out %v after its direct 429, want under %v", gap, gapFloor)
	}
}

// A response that comes back over the proxy fallback says nothing about the direct
// address, so it neither starts the host's wait nor makes a running one longer.
// The fallback answers 429 with a Retry-After well past the first step in both
// cases, so counting it would show up as a long wait on the next direct request.
func TestVRFallbackResponseDoesNotStartOrLengthenTheHostWait(t *testing.T) {
	oneStep := vrOneStep(t)
	retryAfterSecs := int(math.Ceil((2 * oneStep).Seconds())) + 2

	newFallback := func(rec *vrRecorder) *httptest.Server {
		return httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			rec.record("fallback")
			w.Header().Set("Retry-After", strconv.Itoa(retryAfterSecs))
			w.WriteHeader(http.StatusTooManyRequests)
		}))
	}

	t.Run("does_not_start", func(t *testing.T) {
		// A direct 403 goes to the fallback too, and starts no wait of its own.
		rec := newVRRecorder()
		direct := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			rec.record("direct")
			w.WriteHeader(http.StatusForbidden)
		}))
		defer direct.Close()
		fallback := newFallback(rec)
		defer fallback.Close()

		c := vrTwoWayClient(t, direct, fallback)
		var out any
		_ = c.GetJSON(context.Background(), "http://start.example/first", &out)
		if rec.count("direct") != 1 || rec.count("fallback") != 1 {
			t.Fatalf("first request made %d direct and %d fallback hits, want 1 and 1", rec.count("direct"), rec.count("fallback"))
		}

		launch := time.Now()
		_ = c.GetJSON(context.Background(), "http://start.example/second", &out)
		d := rec.times("direct")
		if len(d) != 2 {
			t.Fatalf("the second request made %d direct hits in total, want 2", len(d))
		}
		if delayed := d[1].Sub(launch); delayed >= gapFloor {
			t.Errorf("after a 429 that came only over the fallback, a direct request went out %v after it started, want under %v", delayed, gapFloor)
		}
	})

	t.Run("does_not_lengthen", func(t *testing.T) {
		// A direct 429 starts the wait, then the fallback's 429 with its
		// Retry-After arrives while that wait is running.
		rec := newVRRecorder()
		direct := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			rec.record("direct")
			w.WriteHeader(http.StatusTooManyRequests)
		}))
		defer direct.Close()
		fallback := newFallback(rec)
		defer fallback.Close()

		c := vrTwoWayClient(t, direct, fallback)
		var out any
		_ = c.GetJSON(context.Background(), "http://grow.example/first", &out)
		if rec.count("direct") != 1 || rec.count("fallback") != 1 {
			t.Fatalf("first request made %d direct and %d fallback hits, want 1 and 1", rec.count("direct"), rec.count("fallback"))
		}

		_ = c.GetJSON(context.Background(), "http://grow.example/second", &out)
		d := rec.times("direct")
		if len(d) != 2 {
			t.Fatalf("the second request made %d direct hits in total, want 2", len(d))
		}
		// The direct 429 alone gives about one step. Half to twice that allows
		// jitter, while a wait stretched to the fallback's Retry-After is at least
		// two steps plus two seconds.
		held := d[1].Sub(d[0])
		if held < oneStep/2 {
			t.Errorf("the next direct request went out %v after the direct 429, want about one step (%v)", held, oneStep)
		}
		if held > 2*oneStep {
			t.Errorf("the next direct request went out %v after the direct 429, more than twice one step (%v); the fallback's Retry-After of %ds must not lengthen the wait",
				held, oneStep, retryAfterSecs)
		}
	})
}

// ---- SmartRecruiters seen-posting crawl (HydratingSource.FetchNew) ----

// vrJSONGetter is a self-contained JSONGetter stub. It answers each request with
// the canned JSON body whose key is a substring of the URL, and records every URL
// it was asked for.
type vrJSONGetter struct {
	routes map[string]string
	err    error

	mu   sync.Mutex
	urls []string
}

func (g *vrJSONGetter) GetJSON(_ context.Context, url string, v any) error {
	g.mu.Lock()
	g.urls = append(g.urls, url)
	g.mu.Unlock()
	if g.err != nil {
		return g.err
	}
	for sub, body := range g.routes {
		if strings.Contains(url, sub) {
			return json.Unmarshal([]byte(body), v)
		}
	}
	return fmt.Errorf("vrJSONGetter: no route for %s", url)
}

func (g *vrJSONGetter) requested(sub string) int {
	g.mu.Lock()
	defer g.mu.Unlock()
	n := 0
	for _, u := range g.urls {
		if strings.Contains(u, sub) {
			n++
		}
	}
	return n
}

// Through the HydratingSource interface, a posting the seen predicate reports as
// stored comes back as a liveness refresh with the listing's trimmed title and
// the board's company, and no detail request is sent for it. A new posting is
// read in full from its detail. Two stored postings with different titles and two
// boards with different companies are used.
func TestVRSmartRecruitersFetchNewSkipsDetailForSeenPostings(t *testing.T) {
	listing := `{"totalFound":3,"content":[` +
		`{"id":"P1","name":"  Backend Engineer  ","releasedDate":"2024-06-11T15:19:46.134Z","location":{"city":"Berlin","country":"de"}},` +
		`{"id":"P2","name":"Frontend Engineer","releasedDate":"2024-06-11T15:19:46.134Z","location":{"city":"Paris","country":"fr"}},` +
		`{"id":"P3","name":"Data Engineer ","releasedDate":"2024-06-12T09:00:00.000Z","location":{"city":"Madrid","country":"es"}}` +
		`]}`
	detail := func(id, text string) string {
		return `{"postingUrl":"https://jobs.smartrecruiters.com/Acme/` + id + `","jobAd":{"sections":{"jobDescription":{"text":"<p>` + text + `</p>"}}}}`
	}
	wantTitles := map[string]string{"P1": "Backend Engineer", "P3": "Data Engineer"}
	stored := func(id string) bool { return id == "P1" || id == "P3" }

	for _, e := range []CompanyEntry{
		{Company: "Acme", Provider: "smartrecruiters", Board: "Acme"},
		{Company: "Globex GmbH", Provider: "smartrecruiters", Board: "globex"},
	} {
		t.Run(e.Board, func(t *testing.T) {
			fake := &vrJSONGetter{routes: map[string]string{
				"postings?":    listing,
				"/postings/P1": detail("P1", "stored body one"),
				"/postings/P2": detail("P2", "do the job."),
				"/postings/P3": detail("P3", "stored body three"),
			}}

			src, ok := NewSmartRecruiters(fake).(HydratingSource)
			if !ok {
				t.Fatal("the SmartRecruiters source does not implement HydratingSource")
			}
			jobs, err := src.FetchNew(context.Background(), e, stored)
			if err != nil {
				t.Fatalf("FetchNew: %v", err)
			}
			byID := map[string]Job{}
			for _, j := range jobs {
				byID[j.ExternalID] = j
			}
			if len(byID) != 3 {
				t.Fatalf("got %d postings, want 3: %+v", len(byID), jobs)
			}

			for id, title := range wantTitles {
				if n := fake.requested("/postings/" + id); n != 0 {
					t.Errorf("stored posting %s: %d detail requests, want none", id, n)
				}
				j := byID[id]
				if !j.SeenRefresh || j.Unreadable {
					t.Errorf("stored posting %s = %+v, want a liveness refresh", id, j)
				}
				if j.Title != title {
					t.Errorf("stored posting %s title = %q, want the listing's trimmed name %q", id, j.Title, title)
				}
				if j.Company != e.Company {
					t.Errorf("stored posting %s company = %q, want the board's company %q", id, j.Company, e.Company)
				}
			}

			if n := fake.requested("/postings/P2"); n != 1 {
				t.Errorf("new posting P2: %d detail requests, want 1", n)
			}
			fresh := byID["P2"]
			if fresh.SeenRefresh || fresh.Unreadable {
				t.Fatalf("new posting P2 = %+v, want a fully read posting", fresh)
			}
			if !strings.Contains(fresh.Description, "do the job.") {
				t.Errorf("new posting Description = %q, want the detail body", fresh.Description)
			}
			if fresh.URL != "https://jobs.smartrecruiters.com/Acme/P2" {
				t.Errorf("new posting URL = %q, want the detail's postingUrl", fresh.URL)
			}
		})
	}
}

// A failed board listing makes FetchNew return an error, the same as Fetch.
func TestVRSmartRecruitersFetchNewPropagatesAListingError(t *testing.T) {
	fake := &vrJSONGetter{err: fmt.Errorf("listing boom")}
	src, ok := NewSmartRecruiters(fake).(HydratingSource)
	if !ok {
		t.Fatal("the SmartRecruiters source does not implement HydratingSource")
	}
	if _, err := src.FetchNew(context.Background(), CompanyEntry{Board: "acme"}, func(string) bool { return false }); err == nil {
		t.Fatal("FetchNew returned no error although the board listing failed")
	}
}
