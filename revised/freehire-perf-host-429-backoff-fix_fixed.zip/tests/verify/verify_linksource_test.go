// White-box checks for importing a pasted SmartRecruiters posting link, driven
// through the exported linksource.ResolveOnBoard. A SmartRecruiters link puts the
// posting id at the front of its last path part, followed by a dash and a title
// slug (".../<company>/<id>-<title-slug>"). The checks cover a link to one
// posting among several, a link whose slug no longer matches the stored
// posting's, and a posting with no id.
//
// Only ResolveOnBoard and the sources types are named here, so the matching can
// be written in any form.
//
// ResolveOnBoard namespaces the returned ExternalID by board, so the assertions
// look at Title, SeenRefresh and which postings the board was asked to read in
// full, never at the raw id.
package linksource

import (
	"context"
	"slices"
	"testing"

	"github.com/strelov1/freehire/internal/ingest/sources"
)

// vrHydratingBoard is a self-contained HydratingSource double. For each posting
// its seen predicate reports as stored it returns a liveness-only refresh with no
// URL or description. Every other posting is returned in full and its id is added
// to `hydrated`, the list of postings it was asked to read in full.
type vrHydratingBoard struct {
	provider string
	jobs     []sources.Job
	hydrated []string
}

func (f *vrHydratingBoard) Provider() string { return f.provider }

func (f *vrHydratingBoard) Fetch(_ context.Context, _ sources.CompanyEntry) ([]sources.Job, error) {
	return f.jobs, nil
}

func (f *vrHydratingBoard) FetchNew(_ context.Context, _ sources.CompanyEntry, seen func(externalID string) bool) ([]sources.Job, error) {
	out := make([]sources.Job, 0, len(f.jobs))
	for _, j := range f.jobs {
		if seen(j.ExternalID) {
			out = append(out, sources.Job{ExternalID: j.ExternalID, Title: j.Title, SeenRefresh: true})
			continue
		}
		f.hydrated = append(f.hydrated, j.ExternalID)
		out = append(out, j)
	}
	return out, nil
}

// A pasted "<id>-<title-slug>" link resolves to that posting, read in full, and
// only that posting is read in full. The board also holds a posting whose id is
// the linked id minus its last digit, so the id has to end where the dash is.
func TestVRResolveOnBoardResolvesAnIDPrefixedSlugSegment(t *testing.T) {
	board := &vrHydratingBoard{
		provider: "smartrecruiters",
		jobs: []sources.Job{
			{ExternalID: "74400002222222", URL: "https://jobs.smartrecruiters.com/Acme/74400002222222-go-intern", Title: "Go Intern"},
			{ExternalID: "744000011111111", URL: "https://jobs.smartrecruiters.com/Acme/744000011111111-junior-go", Title: "Junior Go"},
			{ExternalID: "744000022222222", URL: "https://jobs.smartrecruiters.com/Acme/744000022222222-senior-go", Title: "Senior Go"},
		},
	}
	reg := map[string]sources.Source{"smartrecruiters": board}

	raw := "https://jobs.smartrecruiters.com/Acme/744000022222222-senior-go"
	job, ok, err := ResolveOnBoard(context.Background(), reg, "smartrecruiters", "Acme", raw)
	if err != nil || !ok {
		t.Fatalf("ResolveOnBoard = (ok %v, err %v), want the linked posting", ok, err)
	}
	if job.SeenRefresh {
		t.Errorf("resolved posting is a liveness refresh, want the posting read in full")
	}
	if job.Title != "Senior Go" {
		t.Errorf("resolved Title = %q, want %q", job.Title, "Senior Go")
	}
	if want := []string{"744000022222222"}; !slices.Equal(board.hydrated, want) {
		t.Errorf("board read %v in full, want only the linked posting %v", board.hydrated, want)
	}
}

// A slug follows the posting's title, so a link copied before a rename carries an
// old slug after the right id. The id still picks the posting.
func TestVRResolveOnBoardMatchesAnIDPrefixedSegmentWithAStaleSlug(t *testing.T) {
	board := &vrHydratingBoard{
		provider: "smartrecruiters",
		jobs: []sources.Job{
			{ExternalID: "744000022222222", URL: "https://jobs.smartrecruiters.com/Acme/744000022222222-staff-go", Title: "Staff Go"},
		},
	}
	reg := map[string]sources.Source{"smartrecruiters": board}

	// The link's slug is "senior-go"; the stored posting's is "staff-go".
	raw := "https://jobs.smartrecruiters.com/Acme/744000022222222-senior-go"
	job, ok, err := ResolveOnBoard(context.Background(), reg, "smartrecruiters", "Acme", raw)
	if err != nil || !ok {
		t.Fatalf("ResolveOnBoard = (ok %v, err %v), want the posting picked by the id in front of the old slug", ok, err)
	}
	if job.Title != "Staff Go" {
		t.Errorf("resolved Title = %q, want %q", job.Title, "Staff Go")
	}
	if job.SeenRefresh {
		t.Errorf("resolved posting is a liveness refresh, want the posting read in full")
	}
}

// A posting with an empty id is never picked by a link. The only stored posting
// has no id and a URL that differs from each link, so nothing resolves. The
// second link's last part starts with a dash, where an empty id would sit in
// front of it.
func TestVRResolveOnBoardDoesNotMatchAnEmptyIDAgainstASlugSegment(t *testing.T) {
	for _, raw := range []string{
		"https://jobs.smartrecruiters.com/Acme/744000022222222-senior-go",
		"https://jobs.smartrecruiters.com/Acme/-senior-go",
	} {
		board := &vrHydratingBoard{
			provider: "smartrecruiters",
			jobs: []sources.Job{
				{ExternalID: "", URL: "https://jobs.smartrecruiters.com/Acme/other-posting", Title: "No ID"},
			},
		}
		reg := map[string]sources.Source{"smartrecruiters": board}

		_, ok, err := ResolveOnBoard(context.Background(), reg, "smartrecruiters", "Acme", raw)
		if err != nil {
			t.Fatalf("ResolveOnBoard(%s) error: %v", raw, err)
		}
		if ok {
			t.Errorf("ResolveOnBoard(%s) picked a posting that has no id", raw)
		}
	}
}
