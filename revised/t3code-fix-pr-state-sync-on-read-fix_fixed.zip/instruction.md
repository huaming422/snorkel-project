## Task

When a PR gets merged, its details panel shows merged right away, but the thread's PR badge in the sidebar still says open and the thread won't settle.
It sorts itself out after about a minute.
You only see it if you have the PR open around the time it merges, and for that minute the panel and the badge disagree.
Our PR watch hits the same thing: it reads the PR, sees it merged or closed and stops watching, while the badge keeps saying open.

Whenever the server reads a PR's details and finds something the thread's link hasn't caught up with, the link should catch up right away instead of waiting for the next sync pass.
That goes for the first read of a PR after the server starts and for every state change after it: closed, reopened, merged.
It should still catch up when some other request already fetched the new state first.
The panel re-reads on focus and on a timer, so a read that finds nothing new can't cost an extra host request.
One extra host request per state change is fine.
Reads can also come back out of order, and an answer older than one we already have must not flip a merged PR back to open.
The regular sync pass should keep working as it does today.
