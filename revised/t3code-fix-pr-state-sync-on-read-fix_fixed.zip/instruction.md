## Task

The PR badge in the sidebar falls behind the PR details panel.
Merge a PR while its panel is open and the panel shows merged right away, but the thread's badge still says open and the thread won't settle for up to about a minute.
Closing or reopening a PR lags the same way.
After a server restart, the first time someone opens a PR, the thread's link keeps its older copy instead of what the panel just showed.
The PR watch has it too.
A watch pass sees the PR merged or closed and stops watching, and the badge keeps saying open.

Once the server has seen a PR in a newer state, the badge and the thread should follow straight away, not on the next sync pass.
The sync pass itself should keep running as it does now.

Cases we've hit while poking at this:

- The panel's repeat reads are often answered from the copy the server already holds, with the host asked again behind that answer.
  When that later host answer is the one that shows the merge, the badge should follow it without waiting for another read.
- A summary lookup can pick up the new state before the panel does, and the badge still has to follow once the panel shows it.
- The panel re-reads on focus and on a timer, so a read with nothing new can't cost an extra host request.
  One extra request per real state change is fine.
- Host answers can come back out of order.
  Once a PR is merged, an older answer that still says open must not move the badge back to open.
