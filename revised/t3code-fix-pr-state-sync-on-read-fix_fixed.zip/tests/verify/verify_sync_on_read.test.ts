// @ts-nocheck
// Hand-authored integration suite: it stands the production PullRequestService,
// PullRequestSyncReactor and PullRequestWatchReactor up together over one shared dependency
// context and drives them only through their public surface. The service reads pull request state from a
// test-controlled provider; the reactor writes thread-link snapshots by dispatching
// `thread.pull-request-link.sync` commands. Everything is observed at that dispatch
// boundary (a Ref the Orchestrator mock records into) plus the provider's read counters.
// The suite never references any member the two layers use to talk to each other; it only
// arranges reads and watches the link snapshots settle. Because every layer reads the very
// same service instance (one memoized layer, provided once), the catch-up path between them
// is the production one, not a stand-in.
import * as NodeServices from "@effect/platform-node/NodeServices";
import * as KeyValueStore from "effect/persistence/KeyValueStore";
import { assert, describe, it } from "@effect/vitest";
import * as Crypto from "effect/Crypto";
import * as DateTime from "effect/DateTime";
import * as Deferred from "effect/Deferred";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Option from "effect/Option";
import * as Queue from "effect/Queue";
import * as Ref from "effect/Ref";
import * as Stream from "effect/Stream";
import { ProjectId, ThreadId } from "@t3tools/contracts";
import { DEFAULT_SERVER_SETTINGS } from "@t3tools/contracts/settings";

import * as ServerSettingsService from "../serverSettings.ts";
import * as ProjectService from "../project/ProjectService.ts";
import * as RepositoryIdentityResolver from "../project/RepositoryIdentityResolver.ts";
import * as SqlitePersistence from "../persistence/Sqlite.ts";
import * as PullRequestFilesViewed from "../persistence/PullRequestFilesViewed.ts";
import * as SourceControlProviderRegistry from "../sourceControl/SourceControlProviderRegistry.ts";
import * as SourceControlRateLimit from "../sourceControl/SourceControlRateLimit.ts";
import * as PullRequestProviderRegistry from "../pullRequest/PullRequestProviderRegistry.ts";
import * as PullRequestReadCache from "../pullRequest/PullRequestReadCache.ts";
import * as PullRequestService from "../pullRequest/PullRequestService.ts";
import * as Orchestrator from "./Orchestrator.ts";
import * as ProjectionStore from "./ProjectionStore.ts";
import * as PullRequestSyncReactor from "./PullRequestSyncReactor.ts";
import * as PullRequestWatchReactor from "./PullRequestWatchReactor.ts";
import * as ServerActivation from "../serverActivation.ts";

const PROJECT_ID = ProjectId.make("sync-on-read");
const THREAD_ID = ThreadId.make("thread");
const HOST = "github.com";
const REPOSITORY = "owner/repository";
// Seeded links carry a timestamp older than any read below, so the first read a client makes
// of a link always differs from the seeded snapshot and settles it, independent of state.
const SEED_UPDATED_AT = "2026-06-01T00:00:00.000Z";
// Generous enough to absorb a cold Vite transform + sqlite/git setup on the first read, yet
// short enough that a link that never settles is reported promptly as a timeout rather than
// after the whole-suite deadline.
const AWAIT = "10 seconds";

const testCrypto = Crypto.make({
  randomBytes: (size) => new Uint8Array(size).fill(1),
  digest: (_algorithm, data) => Effect.succeed(data),
});

/** The single workspace project both the service and its provider answer for. */
function project() {
  return {
    id: PROJECT_ID,
    title: "web",
    workspaceRoot: "/workspace/project",
    repositoryIdentity: {
      canonicalKey: `${HOST}/${REPOSITORY}`,
      locator: {
        source: "git-remote",
        remoteName: "origin",
        remoteUrl: `https://${HOST}/${REPOSITORY}.git`,
      },
      provider: "github",
      displayName: REPOSITORY,
    },
    defaultModelSelection: null,
    scripts: [],
    createdAt: "2026-07-01T00:00:00Z",
    updatedAt: "2026-07-01T00:00:00Z",
  };
}

/** A host payload for a given number/state/updatedAt, shaped like a real detail read. */
function hostedChangeRequest(number, state, updatedAt) {
  return {
    number,
    title: "Pull request",
    url: `https://${HOST}/${REPOSITORY}/pull/${number}`,
    author: { login: "octocat", name: null, avatarUrl: null },
    headBranch: "feature",
    baseBranch: "main",
    state,
    isDraft: false,
    mergeability: "mergeable",
    additions: 1,
    deletions: 0,
    createdAt: "2026-07-01T00:00:00Z",
    updatedAt,
    reviewRequestLogins: [],
    labels: [],
    body: "body",
    changedFiles: 2,
    mergedAt: state === "merged" ? updatedAt : null,
    closedAt: state === "closed" ? updatedAt : null,
    reviewers: [],
    checks: [],
    mergeCapabilities: { merge: true, squash: true, rebase: true },
    viewerPermissions: {
      actions: ["merge"],
      comment: true,
      resolve: true,
      verdicts: ["comment", "approve", "request-changes"],
      requestReviewers: true,
    },
  };
}

/** A thread-link snapshot for the fake projection store. `null` leaves the link unsynced. */
function link(number, snapshot, options = {}) {
  return {
    host: HOST,
    repository: REPOSITORY,
    number,
    url: `https://${HOST}/${REPOSITORY}/pull/${number}`,
    source: "manual",
    linkedAt: "2026-05-10T00:00:00.000Z",
    snapshot:
      snapshot === null
        ? null
        : {
            state: "open",
            title: "Pull request",
            headBranch: "feature",
            baseBranch: "main",
            isDraft: false,
            updatedAt: SEED_UPDATED_AT,
            syncedAt: SEED_UPDATED_AT,
            ...snapshot,
          },
    stack: null,
    ...(options.watched ? { watch: watching() } : {}),
  };
}

/** A pull request watch that has not taken its first look yet. */
function watching() {
  return {
    startedAt: "2026-06-15T00:00:00.000Z",
    headSha: null,
    failedChecks: [],
    passed: false,
    passedChecks: [],
    remarksThrough: "2026-06-15T00:00:00.000Z",
    remarkIds: [],
    conflicting: false,
    wakes: 0,
  };
}

function ref(number) {
  return { projectId: PROJECT_ID, host: HOST, repository: REPOSITORY, number };
}

/**
 * Builds a world holding one thread with the given links, a provider whose per-number
 * detail/summary answers the test moves at will, and a projection+orchestrator pair wired to
 * the real service and reactor. Each dispatched link sync lands in `syncCommands` and is also
 * folded back into the served link, so the store reflects what the reactor has settled: a
 * later read sees the reactor's own writes, as production persistence would show it.
 */
const makeWorld = Effect.fn("makeSyncOnReadWorld")(function* (options) {
  const activation = yield* Deferred.make();
  const snapshotReads = yield* Queue.unbounded();
  const domainEvents = yield* Queue.unbounded();
  const syncCommands = yield* Ref.make([]);
  const watchCommands = yield* Ref.make([]);
  const summaryReadCount = yield* Ref.make(0);
  // Per-number host state for detail reads and for summary reads, held apart so a test can let
  // a summary see a state a detail has not read yet.
  const detailState = yield* Ref.make(options.detail ?? {});
  const summaryState = yield* Ref.make(options.summary ?? options.detail ?? {});
  const threads = yield* Ref.make(options.links);

  const readFrom = (store, number) =>
    Ref.get(store).pipe(
      Effect.map(
        (byNumber) => byNumber[number] ?? { state: "open", updatedAt: "2026-07-01T00:00:00Z" },
      ),
    );

  const provider = {
    kind: "github",
    capabilities: {
      diff: true,
      comment: true,
      actions: ["merge", "ready", "draft", "close", "reopen"],
      mergeMethods: ["merge"],
      search: true,
      reactions: true,
      review: { approve: true, requestChanges: true, comment: true },
      reviewers: { request: true, listCandidates: true },
      edit: { changeRequest: true, comment: true },
    },
    getViewer: () => Effect.succeed("octocat"),
    getViewerPermissions: () =>
      Effect.succeed({
        actions: ["merge", "ready", "draft", "close", "reopen"],
        comment: true,
        resolve: true,
        verdicts: ["comment", "approve", "request-changes"],
        requestReviewers: true,
      }),
    listChangeRequests: () => Effect.succeed({ items: [], truncated: false, continues: true }),
    getChangeRequest: (input) =>
      readFrom(detailState, input.number).pipe(
        Effect.map((current) => hostedChangeRequest(input.number, current.state, current.updatedAt)),
      ),
    getChangeRequestSummary: (input) =>
      Ref.update(summaryReadCount, (count) => count + 1).pipe(
        Effect.andThen(readFrom(summaryState, input.number)),
        Effect.map((current) => hostedChangeRequest(input.number, current.state, current.updatedAt)),
      ),
    getChangeRequestActivity: () =>
      Effect.succeed({
        comments: [],
        commentCount: 0,
        commentsTruncated: false,
        reviewThreads: [],
        commits: [],
      }),
    getDiff: () => Effect.die("unused"),
    runAction: () => Effect.void,
    updateChangeRequest: () => Effect.void,
    comment: () => Effect.void,
    updateComment: () => Effect.void,
    submitReview: () => Effect.void,
    replyToThread: () => Effect.void,
    setThreadResolution: () => Effect.void,
    setReaction: () => Effect.void,
    listReviewerCandidates: () => Effect.succeed({ candidates: [], truncated: false }),
    setReviewerRequest: () => Effect.void,
  };

  const serviceDeps = Layer.mergeAll(
    Layer.mock(ServerSettingsService.ServerSettingsService)({
      getSettings: Effect.succeed(DEFAULT_SERVER_SETTINGS),
    }),
    Layer.succeed(
      PullRequestProviderRegistry.PullRequestProviderRegistry,
      PullRequestProviderRegistry.fromProviders([provider]),
    ),
    Layer.mock(SourceControlProviderRegistry.SourceControlProviderRegistry)({
      resolveLink: () => undefined,
      resolveHandle: () => Effect.die("unused"),
    }),
    Layer.mock(ProjectService.ProjectService)({
      listShells: (opts) =>
        Effect.succeed([project()].filter((p) => opts?.projectIds?.includes(p.id) ?? true)),
      getShell: (projectId) =>
        Effect.succeed(Option.fromNullishOr([project()].find((p) => p.id === projectId))),
    }),
    Layer.mock(RepositoryIdentityResolver.RepositoryIdentityResolver)({
      resolve: () => Effect.succeed(null),
    }),
    SourceControlRateLimit.layer,
    PullRequestFilesViewed.layer.pipe(Layer.provide(SqlitePersistence.layerMemory)),
    Layer.effect(PullRequestReadCache.PullRequestReadCache, PullRequestReadCache.make).pipe(
      Layer.provide(KeyValueStore.layerMemory),
      Layer.provide(NodeServices.layer),
    ),
  );

  // One shared service layer: the reactor and the test both read it, so the production path the
  // service uses to tell the reactor about a read is exercised end to end.
  const serviceLayer = PullRequestService.layer.pipe(Layer.provide(serviceDeps));

  const applyToLink = (command) => (held) =>
    held.number === command.number
      ? { ...held, snapshot: command.snapshot, stack: command.stack }
      : held;

  const dispatch = (command) => {
    if (command.type === "thread.pull-request-link.sync") {
      return Ref.update(syncCommands, (recorded) => [...recorded, command]).pipe(
        Effect.andThen(Ref.update(threads, (links) => links.map(applyToLink(command)))),
        Effect.as({ sequence: 1, storedEvents: [] }),
      );
    }
    if (command.type === "thread.pull-request.link") {
      return Effect.succeed({ sequence: 1, storedEvents: [] });
    }
    if (command.type === "thread.pull-request-watch.sync") {
      return Ref.update(watchCommands, (recorded) => [...recorded, command]).pipe(
        Effect.as({ sequence: 1, storedEvents: [] }),
      );
    }
    return Effect.die(new Error(`Unexpected command: ${command.type}`));
  };

  // The reactors' non-service dependencies. The service is provided separately, through
  // provideMerge, so exactly one service instance is built and the reactors and the test body
  // all read it - the only way the production catch-up path is exercised rather than faked.
  const reactorInfra = Layer.mergeAll(
    Layer.mock(ProjectionStore.ProjectionStoreV2)({
      getThreadsWithPullRequests: () =>
        Queue.offer(snapshotReads, undefined).pipe(
          Effect.andThen(Ref.get(threads)),
          Effect.map((links) => [
            {
              id: THREAD_ID,
              projectId: PROJECT_ID,
              lineage: {
                parentThreadId: null,
                relationshipToParent: null,
                rootThreadId: THREAD_ID,
              },
              settledOverride: options.settled ? "settled" : null,
              settledAt: options.settled ? DateTime.makeUnsafe("2026-05-20T00:00:00.000Z") : null,
              pullRequests: links,
            },
          ]),
        ),
    }),
    Layer.mock(Orchestrator.OrchestratorV2)({
      getShellSnapshot: () => Effect.die(new Error("pull request sync must not read the shell")),
      dispatch,
      streamDomainEvents: Stream.fromQueue(domainEvents),
    }),
    Layer.succeed(ServerActivation.ServerActivation, Deferred.await(activation)),
    Layer.succeed(Crypto.Crypto, testCrypto),
  );

  const appLayer = Layer.mergeAll(PullRequestSyncReactor.layer, PullRequestWatchReactor.layer).pipe(
    Layer.provide(reactorInfra),
    // Supplies the one service to both reactors and keeps it in the output, so the test reads the
    // same instance the sync reactor subscribed to and the watch reads through.
    Layer.provideMerge(serviceLayer),
  );

  const setDetail = (number, state, updatedAt) =>
    Ref.update(detailState, (byNumber) => ({ ...byNumber, [number]: { state, updatedAt } }));
  const setSummary = (number, state, updatedAt) =>
    Ref.update(summaryState, (byNumber) => ({ ...byNumber, [number]: { state, updatedAt } }));
  // Move both views in lockstep: a reader sees a new state through the detail panel, and the
  // reactor's own confirming read sees the same.
  const observe = (number, state, updatedAt) =>
    setDetail(number, state, updatedAt).pipe(Effect.andThen(setSummary(number, state, updatedAt)));

  return {
    appLayer,
    snapshotReads,
    syncCommands,
    watchCommands,
    summaryReadCount,
    activation,
    setDetail,
    setSummary,
    observe,
  };
});

/** Starts the reactor and lets its first periodic pass run to completion. */
const start = Effect.fn("startSyncOnReadWorld")(function* (world) {
  const reactor = yield* PullRequestSyncReactor.PullRequestSyncReactor;
  const service = yield* PullRequestService.PullRequestService;
  yield* reactor.start();
  yield* Deferred.succeed(world.activation, undefined);
  // Drain the startup pass so anything it settles is accounted for before the reads begin.
  yield* Queue.take(world.snapshotReads);
  yield* reactor.drain;
  return { reactor, service };
});

/** Reads a pull request detail the way a client viewing the panel would, fresh each time. */
const readDetail = (service, number) =>
  service.invalidate({ reference: ref(number) }).pipe(Effect.andThen(service.detail(ref(number))));

const statesFor = (commands, number) =>
  commands.filter((command) => command.number === number).map((command) => command.snapshot.state);

/**
 * Drains sync passes until the recorded commands satisfy `predicate`, bounded by AWAIT. A read
 * reaches the reactor through a forked subscription on the live clock, so the number of passes a
 * settle takes is not fixed; draining until the expected command appears is order-independent.
 * A predicate that already holds needs no further pass. If no pass ever makes the predicate hold
 * (a read driving nothing), the wait for the next pass blocks and the bound trips it as a failure
 * instead of hanging the suite.
 */
const drainUntil = (world, reactor, predicate) =>
  Effect.gen(function* () {
    yield* reactor.drain;
    while (!predicate(yield* Ref.get(world.syncCommands))) {
      yield* Queue.take(world.snapshotReads);
      yield* reactor.drain;
    }
  }).pipe(Effect.timeout(AWAIT));

describe("PullRequestSyncReactor state-change catch-up", () => {
  // A detail read that sees a pull request for the first time, or in a newly changed state,
  // settles its link once per transition. open, closed, reopened, merged yields exactly those
  // four snapshots in order, and no more.
  it.live("settles a link once for each new state a reader sees it reach", () =>
    Effect.scoped(
      Effect.gen(function* () {
        const world = yield* makeWorld({
          settled: true,
          links: [link(7, { state: "open" })],
          detail: { 7: { state: "open", updatedAt: SEED_UPDATED_AT } },
          summary: { 7: { state: "open", updatedAt: SEED_UPDATED_AT } },
        });
        yield* Effect.gen(function* () {
          const { reactor, service } = yield* start(world);

          yield* world.observe(7, "open", "2026-07-02T00:00:00Z");
          yield* readDetail(service, 7);
          yield* drainUntil(world, reactor, (c) => statesFor(c, 7).length >= 1);

          yield* world.observe(7, "closed", "2026-07-03T00:00:00Z");
          yield* readDetail(service, 7);
          yield* drainUntil(world, reactor, (c) => statesFor(c, 7).length >= 2);

          yield* world.observe(7, "open", "2026-07-04T00:00:00Z");
          yield* readDetail(service, 7);
          yield* drainUntil(world, reactor, (c) => statesFor(c, 7).length >= 3);

          yield* world.observe(7, "merged", "2026-07-05T00:00:00Z");
          yield* readDetail(service, 7);
          yield* drainUntil(world, reactor, (c) => statesFor(c, 7).length >= 4);

          // One settle per transition the reader saw, in order, nothing extra.
          assert.deepStrictEqual(statesFor(yield* Ref.get(world.syncCommands), 7), [
            "open",
            "closed",
            "open",
            "merged",
          ]);
          // At most one extra host read per state the reader saw.
          assert.isAtMost(yield* Ref.get(world.summaryReadCount), 4);
        }).pipe(Effect.provide(world.appLayer));
      }),
    ),
  );

  // A repeated read of a state already seen, even a fresh invalidated one, settles nothing
  // further and costs no extra host read: at most one per state a reader sees.
  it.live("does not settle again when a reader re-reads a state it already saw", () =>
    Effect.scoped(
      Effect.gen(function* () {
        const world = yield* makeWorld({
          settled: true,
          links: [link(7, { state: "open" }), link(8, { state: "open" })],
          detail: {
            7: { state: "open", updatedAt: SEED_UPDATED_AT },
            8: { state: "open", updatedAt: SEED_UPDATED_AT },
          },
          summary: {
            7: { state: "open", updatedAt: SEED_UPDATED_AT },
            8: { state: "open", updatedAt: SEED_UPDATED_AT },
          },
        });
        yield* Effect.gen(function* () {
          const { reactor, service } = yield* start(world);

          // A reader sees #7 close: one settle, at most one extra host read.
          yield* world.observe(7, "closed", "2026-07-03T00:00:00Z");
          yield* readDetail(service, 7);
          yield* drainUntil(world, reactor, (c) => statesFor(c, 7).length >= 1);
          assert.deepStrictEqual(statesFor(yield* Ref.get(world.syncCommands), 7), ["closed"]);
          assert.isAtMost(yield* Ref.get(world.summaryReadCount), 1);

          // Re-reading that same closed state, even freshly, adds nothing.
          yield* readDetail(service, 7);
          yield* readDetail(service, 7);

          // A read of a different pull request flushes the pipeline: by the time #8 settles, any
          // stray work the repeat reads queued (they are published before #8) is already recorded.
          yield* world.observe(8, "merged", "2026-07-04T00:00:00Z");
          yield* readDetail(service, 8);
          yield* drainUntil(world, reactor, (c) => statesFor(c, 8).length >= 1);

          const commands = yield* Ref.get(world.syncCommands);
          assert.deepStrictEqual(statesFor(commands, 7), ["closed"]);
          assert.deepStrictEqual(statesFor(commands, 8), ["merged"]);
          // At most one extra host read per state change a reader saw: #7 closed,
          // #8 merged. The two repeat reads of #7 add none.
          assert.isAtMost(yield* Ref.get(world.summaryReadCount), 2);
        }).pipe(Effect.provide(world.appLayer));
      }),
    ),
  );

  // A summary read that sees the new state first does not swallow the later detail read's
  // catch-up.
  it.live("leaves the link to the detail read when a summary sees the change first", () =>
    Effect.scoped(
      Effect.gen(function* () {
        const world = yield* makeWorld({
          settled: true,
          links: [link(7, { state: "open" }), link(8, { state: "open" })],
          detail: {
            7: { state: "open", updatedAt: SEED_UPDATED_AT },
            8: { state: "open", updatedAt: SEED_UPDATED_AT },
          },
          summary: {
            7: { state: "open", updatedAt: SEED_UPDATED_AT },
            8: { state: "open", updatedAt: SEED_UPDATED_AT },
          },
        });
        yield* Effect.gen(function* () {
          const { reactor, service } = yield* start(world);

          // The summary observes the merge first.
          yield* world.setSummary(7, "merged", "2026-07-04T00:00:00Z");
          yield* service.summary(ref(7), { recoverTransientFailure: false });

          // An unrelated pull request still settles on its own read.
          yield* world.observe(8, "merged", "2026-07-04T00:00:00Z");
          yield* readDetail(service, 8);
          yield* drainUntil(world, reactor, (c) => statesFor(c, 8).length >= 1);
          assert.deepStrictEqual(statesFor(yield* Ref.get(world.syncCommands), 8), ["merged"]);

          // The detail read that follows still leaves #7 settled merged; the earlier summary did
          // not hide the change from it.
          yield* world.setDetail(7, "merged", "2026-07-04T00:00:00Z");
          yield* readDetail(service, 7);
          yield* drainUntil(world, reactor, (c) => statesFor(c, 7).includes("merged"));
          assert.deepStrictEqual(statesFor(yield* Ref.get(world.syncCommands), 7), ["merged"]);
        }).pipe(Effect.provide(world.appLayer));
      }),
    ),
  );

  // Merged is final. After a reader settled a link merged, a later read that is actually older
  // and still shows it open must not drag the link back open.
  it.live("keeps a merged link merged when a late stale read still shows it open", () =>
    Effect.scoped(
      Effect.gen(function* () {
        const world = yield* makeWorld({
          settled: true,
          links: [link(7, { state: "open" }), link(8, { state: "open" })],
          detail: {
            7: { state: "open", updatedAt: SEED_UPDATED_AT },
            8: { state: "open", updatedAt: SEED_UPDATED_AT },
          },
          summary: {
            7: { state: "open", updatedAt: SEED_UPDATED_AT },
            8: { state: "open", updatedAt: SEED_UPDATED_AT },
          },
        });
        yield* Effect.gen(function* () {
          const { reactor, service } = yield* start(world);

          // A reader sees #7 merge at a fresh timestamp: it settles merged.
          yield* world.observe(7, "merged", "2026-07-04T00:00:00Z");
          yield* readDetail(service, 7);
          yield* drainUntil(world, reactor, (c) => statesFor(c, 7).length >= 1);
          assert.deepStrictEqual(statesFor(yield* Ref.get(world.syncCommands), 7), ["merged"]);

          // A later read that is actually older (a lower updatedAt) still shows open. It must not
          // reopen the link. The store now holds merged, so a spurious reopen would show up here.
          yield* world.observe(7, "open", "2026-07-03T00:00:00Z");
          yield* readDetail(service, 7);

          // Flush with #8 and confirm #7 gained no reopen behind it.
          yield* world.observe(8, "merged", "2026-07-04T00:00:00Z");
          yield* readDetail(service, 8);
          yield* drainUntil(world, reactor, (c) => statesFor(c, 8).length >= 1);
          const commands = yield* Ref.get(world.syncCommands);
          assert.deepStrictEqual(statesFor(commands, 7), ["merged"]);
          assert.deepStrictEqual(statesFor(commands, 8), ["merged"]);
        }).pipe(Effect.provide(world.appLayer));
      }),
    ),
  );

  // A reader's observation settles the link straight away, without a periodic pass advancing.
  it.live("settles the link the moment a reader sees the merge, before any sweep is due", () =>
    Effect.scoped(
      Effect.gen(function* () {
        const world = yield* makeWorld({
          settled: true,
          links: [link(7, { state: "open" })],
          detail: { 7: { state: "open", updatedAt: SEED_UPDATED_AT } },
          summary: { 7: { state: "open", updatedAt: SEED_UPDATED_AT } },
        });
        yield* Effect.gen(function* () {
          const { reactor, service } = yield* start(world);

          // The host now reports the pull request merged; a client reads the detail panel and
          // sees it. No periodic pass is due; the next is a minute out on the live clock.
          yield* world.observe(7, "merged", "2026-07-04T00:00:00Z");
          yield* readDetail(service, 7);
          yield* drainUntil(world, reactor, (c) => statesFor(c, 7).length >= 1);

          // The link settled to merged off the read alone, for at most one extra host read.
          assert.deepStrictEqual(statesFor(yield* Ref.get(world.syncCommands), 7), ["merged"]);
          assert.isAtMost(yield* Ref.get(world.summaryReadCount), 1);
        }).pipe(Effect.provide(world.appLayer));
      }),
    ),
  );

  // A pull request watch is a reader too. When its pass finds one watched pull request merged and
  // another closed, it stops watching both, and both links settle before any sweep is due.
  it.live("settles watched links the moment a watch sees them merge or close", () =>
    Effect.scoped(
      Effect.gen(function* () {
        const world = yield* makeWorld({
          settled: false,
          links: [
            link(7, { state: "open" }, { watched: true }),
            link(8, { state: "open" }, { watched: true }),
          ],
          detail: {
            7: { state: "open", updatedAt: SEED_UPDATED_AT },
            8: { state: "open", updatedAt: SEED_UPDATED_AT },
          },
          summary: {
            7: { state: "open", updatedAt: SEED_UPDATED_AT },
            8: { state: "open", updatedAt: SEED_UPDATED_AT },
          },
        });
        yield* Effect.gen(function* () {
          const { reactor } = yield* start(world);
          const watch = yield* PullRequestWatchReactor.PullRequestWatchReactor;
          // The startup pass synced both open links; the next periodic pass is a minute out.
          const before = yield* Ref.get(world.syncCommands);

          yield* world.observe(7, "merged", "2026-07-04T00:00:00Z");
          yield* world.observe(8, "closed", "2026-07-03T00:00:00Z");
          yield* watch.sweep;
          yield* drainUntil(
            world,
            reactor,
            (c) => statesFor(c, 7).includes("merged") && statesFor(c, 8).includes("closed"),
          );

          // The watch itself saw both and stopped watching them.
          const stopped = (yield* Ref.get(world.watchCommands))
            .filter((command) => command.watch === null)
            .map((command) => command.number)
            .toSorted();
          assert.deepStrictEqual(stopped, [7, 8]);
          const after = (yield* Ref.get(world.syncCommands)).slice(before.length);
          assert.deepStrictEqual(statesFor(after, 7), ["merged"]);
          assert.deepStrictEqual(statesFor(after, 8), ["closed"]);
        }).pipe(Effect.provide(world.appLayer));
      }),
    ),
  );

  // The periodic pass still settles links on its own, with no reader driving it. The catch-up
  // path is additive; it does not replace the periodic sweep.
  it.live("still settles links on the periodic sweep when no reader has seen a change", () =>
    Effect.scoped(
      Effect.gen(function* () {
        // An unsettled thread with a freshly linked (unsynced) pull request: the periodic pass
        // alone must read the host and settle it, with no read driving the catch-up.
        const world = yield* makeWorld({
          settled: false,
          links: [link(7, null)],
          detail: { 7: { state: "merged", updatedAt: "2026-07-04T00:00:00Z" } },
          summary: { 7: { state: "merged", updatedAt: "2026-07-04T00:00:00Z" } },
        });
        yield* Effect.gen(function* () {
          const reactor = yield* PullRequestSyncReactor.PullRequestSyncReactor;
          yield* reactor.start();
          yield* Deferred.succeed(world.activation, undefined);
          yield* Queue.take(world.snapshotReads);
          yield* reactor.drain;

          // The sweep settled the link on its own, independent of any reader.
          assert.deepStrictEqual(statesFor(yield* Ref.get(world.syncCommands), 7), ["merged"]);
        }).pipe(Effect.provide(world.appLayer));
      }),
    ),
  );
});
