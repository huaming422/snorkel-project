#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
# No assertion logic here - only bring baked deps online and prepare the suite.
#
# This task's verifiers are in-process Effect-TS tests (vite-plus/vitest); they use
# sqlite + git set up by apps/server's own setupFiles, so there are no background
# services to start or data to seed.
cd /repo/t3code

# Fail fast on a cache miss instead of silently reaching a registry. Dependencies are
# baked into the image's pnpm store.
export npm_config_offline=true
export HUSKY=0
export PNPM_HOME=/opt/pnpm
export PNPM_STORE_DIR=/opt/pnpm/store
export PATH="/repo/t3code/node_modules/.bin:${PNPM_HOME}:${PATH}"

# Dependencies: offline-first against the image bake, logged online fallback. Check each
# exit status directly - never `… | tail`, which masks the code so the fallback never fires.
if pnpm install --offline --frozen-lockfile > /tmp/test-setup-install.log 2>&1; then
    echo "[offline-first] deps satisfied from image"
elif pnpm install --frozen-lockfile >> /tmp/test-setup-install.log 2>&1; then
    echo "[test-setup] deps installed online (image bake was stale)"
else
    tail -40 /tmp/test-setup-install.log >&2; exit 1
fi

# The test runner invokes `vitest run <file> --reporter=json --outputFile=…
# --testTimeout=…` to execute the suite. This workspace does not expose a
# standalone `vitest` binary - the test runner is driven through `vp test`, which
# forwards the same arguments on to Vitest and emits the identical JSON report.
# Bridge the two by linking a thin `vitest` entry on PATH that delegates to
# `vp test`, so the invocation resolves without changing how the suite runs.
# Written after install so the dependency step cannot clobber it.
VITEST_SHIM=/repo/t3code/node_modules/.bin/vitest
cat > "${VITEST_SHIM}" <<'SHIM'
#!/usr/bin/env bash
# `vitest --version` is a presence probe that must resolve without executing the
# suite; `vp test` has no --version passthrough and would run every file, so answer
# it here and exit before delegating.
if [ "${1:-}" = "--version" ]; then
  echo "vitest/vp-bridge"
  exit 0
fi
# The test runner reads the machine report from the --outputFile path, never
# from stdout, so merging the runner's diagnostic stream into stdout keeps report
# parsing intact while making any load-time collection error legible in the
# persisted stdout log instead of a discarded stderr.
exec vp test "$@" 2>&1
SHIM
chmod +x "${VITEST_SHIM}"
command -v vitest >/dev/null 2>&1 || { echo "[test-setup] vitest bridge not on PATH" >&2; exit 1; }
