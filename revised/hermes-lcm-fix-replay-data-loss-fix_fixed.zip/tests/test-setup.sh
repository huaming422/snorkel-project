#!/usr/bin/env bash
# Verifier-side setup for hermes-lcm-fix-replay-data-loss.
#
# The task image already bakes everything the verifier needs at build time:
#   - the repo venv at /opt/venv (with test deps surfaced from /opt/testdeps via .pth)
#   - pytest / numpy / coverage in /opt/testdeps
#   - the agent.context_engine stub in /opt/testdeps
# verify.py imports hermes_lcm and adds no dependencies of its own, so this script
# installs nothing. It performs an offline import sanity check and logs clearly.
set -euo pipefail

LOG=/tmp/test-setup.log
: > "$LOG"

echo "[test-setup] hermes-lcm-fix-replay-data-loss: no package installation required" | tee -a "$LOG"

# Offline-first sanity: confirm the repo modules import under the repo interpreter.
# The repo uses a flat layout (/repo/hermes-lcm/*.py) with a top-level __init__.py.
# Python cannot import a directory named with a hyphen as a package directly, so
# this check uses importlib.util to register it under the canonical hermes_lcm name,
# matching the shim in verify.py.
if VIRTUAL_ENV=/opt/venv UV_PROJECT_ENVIRONMENT=/opt/venv UV_OFFLINE=1 \
     /opt/venv/bin/python - >>"$LOG" 2>&1 <<'PY'
import importlib.util, sys
from pathlib import Path
repo_root = Path("/repo/hermes-lcm")
spec = importlib.util.spec_from_file_location(
    "hermes_lcm",
    str(repo_root / "__init__.py"),
    submodule_search_locations=[str(repo_root)],
)
mod = importlib.util.module_from_spec(spec)
mod.__path__ = [str(repo_root)]
mod.__package__ = "hermes_lcm"
sys.modules["hermes_lcm"] = mod
import hermes_lcm.engine, hermes_lcm.config, hermes_lcm.store
PY
then
  echo "[test-setup] hermes_lcm import OK (offline)" | tee -a "$LOG"
else
  echo "[test-setup] WARNING: offline import check failed; see $LOG" | tee -a "$LOG"
  tail -40 "$LOG" >&2 || true
  exit 1
fi

echo "[test-setup] done" | tee -a "$LOG"
