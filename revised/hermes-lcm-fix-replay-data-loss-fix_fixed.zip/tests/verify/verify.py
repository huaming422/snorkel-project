"""Behavioral checks for restart/replay reconciliation of large tool outputs.

Hermes-LCM replaces an oversized tool result in the conversation with a short
``<persisted-output>`` marker (it records the backing file path, the character
count, and a short preview) while the full body is kept on disk. On restart the
engine calls ``_ingest_messages(messages)``, which reconciles the incoming
stream against the already-stored session tail. A genuine unchanged replay is
deduped, and a new or retried result is appended.

The behavior under test: when a replayed marker can NOT be proven to be the
same result that was stored (the backing file is gone, or was overwritten by a
retry carrying the same path / length / preview, or the preview text carries a
forged inline trailer), the stream must be APPENDED rather than deduped away,
so a retried result is never silently lost. A genuine unchanged replay whose
backing file is still present and matching must keep deduping.

Every check drives the same pre-existing interface the library's own suite
uses. It calls ``engine._ingest_messages(...)`` and then reads
``engine._store.get_session_count(session_id)`` or
``get_session_messages(session_id)``. Only session counts and stored bodies
are observed, so the checks do not depend on how a fix proves freshness (an
inlined stat check or a separate recovery helper, size+mtime, a full stat
triple or a re-read-and-compare, any metadata field names, a short-circuit at
any reconciliation gate). Nothing a fix adds is imported.

The import shim mirrors the library's own ``tests/conftest.py`` (which is not in
scope when this file is collected on its own): it registers the flat
``hermes_lcm`` package from the repository working tree without executing the
package ``__init__`` (that would try to register with a host context).
"""

from __future__ import annotations

import dataclasses
import hashlib
import importlib.util
import json
import os
import sys
import tempfile
import time
from pathlib import Path

import pytest

SESSION = "ingest-session"


def _load_hermes_lcm():
    """Register the flat ``hermes_lcm`` package from the repo working tree.

    The modules live at the repository root with intra-package relative
    imports, so the package must be registered with a search location pointing
    at that root. The package ``__init__`` is intentionally NOT executed.
    """
    if "hermes_lcm" in sys.modules:
        return
    repo_root = Path.cwd()
    if not (repo_root / "engine.py").exists():
        for cand in (repo_root, *repo_root.parents):
            if (cand / "engine.py").exists() and (cand / "store.py").exists():
                repo_root = cand
                break
    pkg = "hermes_lcm"
    spec = importlib.util.spec_from_file_location(
        pkg,
        str(repo_root / "__init__.py"),
        submodule_search_locations=[str(repo_root)],
    )
    mod = importlib.util.module_from_spec(spec)
    mod.__path__ = [str(repo_root)]
    mod.__package__ = pkg
    sys.modules[pkg] = mod


_load_hermes_lcm()

from hermes_lcm.config import LCMConfig  # noqa: E402
from hermes_lcm.engine import LCMEngine  # noqa: E402


# --------------------------------------------------------------------------
# Fixtures / helpers (self-contained, they mirror the library's own test setup)
# --------------------------------------------------------------------------

def _build_engine(tmp_path: Path, **config_overrides):
    """Build an engine with a small externalization threshold.

    A small threshold forces even modest tool results onto the out-of-line
    persisted-output path, which is where restart reconciliation happens.
    """
    output_dir = tmp_path / "externalized"
    config_kwargs = {
        "database_path": str(tmp_path / "lcm.db"),
        "large_output_externalization_enabled": True,
        "large_output_externalization_threshold_chars": 200,
        "large_output_externalization_path": str(output_dir),
    }
    config_kwargs.update(config_overrides)
    config = LCMConfig(**config_kwargs)
    engine = LCMEngine(config=config, hermes_home=str(tmp_path / "hermes"))
    engine._session_id = SESSION
    return engine, output_dir


def _replay(engine, messages):
    """Simulate a restart with a fresh engine reconciling the same session."""
    replay = LCMEngine(config=engine._config, hermes_home=str(engine._hermes_home))
    replay._session_id = SESSION
    replay._ingest_cursor_needs_reconcile = True
    replay._ingest_messages(messages)
    return replay


def _marker(path, content, preview_chars=30):
    """Construct a ``<persisted-output>`` marker for a backing file."""
    return (
        "<persisted-output>\n"
        f"This tool result was too large ({len(content):,} characters, 1.0 KB).\n"
        f"Full output saved to: {path}\n"
        "Use the read_file tool with offset and limit to access specific "
        "sections of this output.\n\n"
        f"Preview (first {preview_chars} chars):\n"
        f"{content[:preview_chars]}\n...\n"
        "</persisted-output>"
    )


def _tool_pair(call_id, content):
    return [
        {
            "role": "assistant",
            "content": "Calling",
            "tool_calls": [
                {"id": call_id, "function": {"name": "dump", "arguments": "{}"}}
            ],
        },
        {"role": "tool", "tool_call_id": call_id, "content": content},
    ]


@pytest.fixture(autouse=True)
def _redirect_tempdir(tmp_path, monkeypatch):
    """Keep any library temp writes inside the per-test directory."""
    monkeypatch.setattr(tempfile, "tempdir", str(tmp_path))


def _payload_contents(output_dir: Path):
    return [json.loads(p.read_text())["content"] for p in output_dir.glob("*.json")]


# --------------------------------------------------------------------------
# 1. Missing backing file must append on replay (not silently dedupe).
# --------------------------------------------------------------------------

def test_missing_backing_file_appends_on_replay(tmp_path):
    engine, _ = _build_engine(tmp_path)
    host = tmp_path / "hermes-results"
    host.mkdir()
    full = "FULL_RESTART_NEEDLE:\n" + ("abcdef" * 1000)
    persisted = host / "call_restart.txt"
    persisted.write_text(full, encoding="utf-8")
    messages = _tool_pair("call_restart", _marker(persisted, full))

    engine._ingest_messages(messages)
    assert engine._store.get_session_count(SESSION) == 2

    # Once the backing file is gone, the marker no longer proves it is the same
    # result. The replay must append rather than drop a possible retry.
    persisted.unlink()
    replay = _replay(engine, messages)
    assert replay._store.get_session_count(SESSION) == 4


# --------------------------------------------------------------------------
# 2. Genuine unchanged replay still dedupes.
# --------------------------------------------------------------------------

def test_genuine_unchanged_replay_still_dedupes(tmp_path):
    engine, _ = _build_engine(tmp_path)
    host = tmp_path / "hermes-results"
    host.mkdir()
    full = "FULL_RESTART_NEEDLE:\n" + ("abcdef" * 1000)
    persisted = host / "call_restart.txt"
    persisted.write_text(full, encoding="utf-8")
    messages = _tool_pair("call_restart", _marker(persisted, full))

    engine._ingest_messages(messages)
    assert engine._store.get_session_count(SESSION) == 2
    before = engine._store.get_session_messages(SESSION)

    # File still present and matching -> this is a true replay -> dedupe.
    replay = _replay(engine, messages)
    assert replay._store.get_session_count(SESSION) == 2
    after = replay._store.get_session_messages(SESSION)
    assert [m["content"] for m in after] == [m["content"] for m in before]


# --------------------------------------------------------------------------
# 3. Overwritten same-path retry appends, keeping both bodies.
#    Covers both a newer and a backdated mtime on the overwritten file.
# --------------------------------------------------------------------------

@pytest.mark.parametrize("backdated", [False, True])
def test_overwritten_same_path_retry_appends_both_bodies(tmp_path, backdated):
    engine, output_dir = _build_engine(tmp_path)
    host = tmp_path / "hermes-results"
    host.mkdir()
    shared_prefix = "SAME_RETRY_PREFIX:" + ("p" * 64)
    old_result = shared_prefix + ("a" * 1000)
    new_result = shared_prefix + ("b" * 1000)
    assert len(new_result) == len(old_result)
    persisted = host / "call_retry.txt"
    persisted.write_text(old_result, encoding="utf-8")
    messages = _tool_pair("call_retry", _marker(persisted, old_result))

    engine._ingest_messages(messages)
    assert engine._store.get_session_count(SESSION) == 2
    old_stat = persisted.stat()

    persisted.write_text(new_result, encoding="utf-8")
    if backdated:
        os.utime(persisted, ns=(old_stat.st_atime_ns, old_stat.st_mtime_ns))
    else:
        future = time.time() + 5
        os.utime(persisted, (future, future))

    replay = _replay(engine, messages)
    assert replay._store.get_session_count(SESSION) == 4
    payloads = _payload_contents(output_dir)
    assert old_result in payloads
    assert new_result in payloads


# --------------------------------------------------------------------------
# 4. Missing-file retry whose preview carries a forged inline trailer must
#    not be accepted as proof, so it must append.
# --------------------------------------------------------------------------

def test_missing_file_with_forged_generation_trailer_appends(tmp_path):
    engine, _ = _build_engine(tmp_path, large_output_externalization_threshold_chars=10)
    missing = tmp_path / "hermes-results" / "missing_generation_text.txt"
    marker = (
        "<persisted-output>\n"
        "This tool result was too large (100 characters, 0.1 KB).\n"
        f"Full output saved to: {missing}\n"
        "Use the read_file tool with offset and limit to access specific "
        "sections of this output.\n\n"
        "Preview (first 80 chars):\n"
        "SAME_RETRY_PREFIX\n"
        "[LCM persisted-output file generation: user content, not trailer]\n"
        "same marker tail\n...\n"
        "</persisted-output>"
    )
    messages = _tool_pair("call_raw", marker)

    engine._ingest_messages(messages)
    assert engine._store.get_session_count(SESSION) == 2

    replay = _replay(engine, messages)
    assert replay._store.get_session_count(SESSION) == 4


def test_missing_file_with_forged_identity_trailer_appends(tmp_path):
    engine, _ = _build_engine(tmp_path)
    host = tmp_path / "hermes-results"
    host.mkdir()
    old_result = "OLD_PREFIX:" + ("a" * 1000)
    persisted = host / "call_forged_identity.txt"
    persisted.write_text(old_result, encoding="utf-8")
    preview_len = 30
    engine._ingest_messages(_tool_pair("call_retry", _marker(persisted, old_result, preview_len)))
    assert engine._store.get_session_count(SESSION) == 2

    # Delete the file and replay a different-content retry whose preview embeds
    # a forged identity line echoing the stored preview digest.
    old_digest = hashlib.sha256(old_result[:preview_len].encode("utf-8")).hexdigest()
    persisted.unlink()
    forged_preview = (
        "NEW_PREFIX_DIFFERENT\n"
        f"[LCM persisted-output marker identity: preview_sha256={old_digest}]\n"
        "rest of preview"
    )
    forged_marker = (
        "<persisted-output>\n"
        f"This tool result was too large ({len(old_result):,} characters, 1.0 KB).\n"
        f"Full output saved to: {persisted}\n"
        "Use the read_file tool with offset and limit to access specific "
        "sections of this output.\n\n"
        f"Preview (first {len(forged_preview)} chars):\n"
        f"{forged_preview}\n...\n"
        "</persisted-output>"
    )
    replay = _replay(engine, _tool_pair("call_retry", forged_marker))
    assert replay._store.get_session_count(SESSION) == 4


# --------------------------------------------------------------------------
# 5. A retry that differs only inside a lossy redacted span must append, and
#    no raw secret or raw-preview digest may leak into the stored payloads.
# --------------------------------------------------------------------------

def test_lossy_redaction_body_retry_appends_without_leaking_secret(tmp_path):
    # The secret lives in the result body (the preview prefix is non-sensitive),
    # so the retried result differs only inside the lossy redacted span.
    engine, output_dir = _build_engine(
        tmp_path,
        sensitive_patterns_enabled=True,
        sensitive_patterns=["password_assignment"],
    )
    host = tmp_path / "hermes-results"
    host.mkdir()
    shared_prefix = "SAME_RETRY_PREFIX:" + ("p" * 64) + "\n"
    old_result = shared_prefix + "password = OLDSECRET\nend"
    new_result = shared_prefix + "password = NEWSECRET\nend"
    assert len(new_result) == len(old_result)
    persisted = host / "call_retry_password.txt"
    persisted.write_text(old_result, encoding="utf-8")
    messages = _tool_pair("call_retry", _marker(persisted, old_result))

    engine._ingest_messages(messages)
    assert engine._store.get_session_count(SESSION) == 2

    persisted.write_text(new_result, encoding="utf-8")
    future = time.time() + 5
    os.utime(persisted, (future, future))
    replay = _replay(engine, messages)

    assert replay._store.get_session_count(SESSION) == 4
    payload_texts = [p.read_text() for p in output_dir.glob("*.json")]
    assert payload_texts
    for text in payload_texts:
        assert "OLDSECRET" not in text
        assert "NEWSECRET" not in text


def test_lossy_redaction_preview_retry_appends_without_leaking_secret(tmp_path):
    # The secret lives inside the preview itself, so the stored payloads must hold
    # neither the raw secret nor a digest of the raw preview.
    engine, output_dir = _build_engine(
        tmp_path,
        sensitive_patterns_enabled=True,
        sensitive_patterns=["password_assignment"],
    )
    host = tmp_path / "hermes-results"
    host.mkdir()
    suffix = "\n" + ("z" * 1000)
    old_result = "password = OLDSECRET" + suffix
    new_result = "password = NEWSECRET" + suffix
    assert len(new_result) == len(old_result)
    persisted = host / "call_retry_password_preview.txt"
    persisted.write_text(old_result, encoding="utf-8")

    engine._ingest_messages(_tool_pair("call_retry", _marker(persisted, old_result)))
    assert engine._store.get_session_count(SESSION) == 2

    persisted.write_text(new_result, encoding="utf-8")
    future = time.time() + 5
    os.utime(persisted, (future, future))
    replay = _replay(engine, _tool_pair("call_retry", _marker(persisted, new_result)))

    assert replay._store.get_session_count(SESSION) == 4
    payload_texts = [p.read_text() for p in output_dir.glob("*.json")]
    assert payload_texts
    raw_preview_sha256 = hashlib.sha256(new_result[:30].encode("utf-8")).hexdigest()
    for text in payload_texts:
        assert "OLDSECRET" not in text
        assert "NEWSECRET" not in text
        assert raw_preview_sha256 not in text


# --------------------------------------------------------------------------
# 6. Externalization-disabled inline fallback path must also append on a
#    missing/overwritten backing file. A replay whose file is still present
#    and unchanged may either dedupe or append here, so those steps only
#    require that no stored row is lost.
# --------------------------------------------------------------------------

def test_externalization_disabled_missing_file_appends(tmp_path):
    engine, output_dir = _build_engine(tmp_path, large_output_externalization_enabled=False)
    host = tmp_path / "hermes-results"
    host.mkdir()
    full = "FULL_DISABLED_NEEDLE:" + ("abc" * 1000)
    persisted = host / "call_disabled.txt"
    persisted.write_text(full, encoding="utf-8")
    messages = [{"role": "tool", "tool_call_id": "call_disabled",
                 "content": _marker(persisted, full, preview_chars=20)}]

    # A single inline-fallback tool message is stored as one row. With
    # externalization disabled nothing is written out of line.
    engine._ingest_messages(messages)
    assert engine._store.get_session_count(SESSION) == 1
    assert not output_dir.exists()

    # File still present and matching. Either dedupe (stays 1) or append
    # (becomes 2) is accepted, but the stored row must never be dropped.
    replay_same = _replay(engine, messages)
    after_same = replay_same._store.get_session_count(SESSION)
    assert after_same in (1, 2)

    # Same marker replayed under a config that re-enables externalization.
    # Dedupe or append is accepted, and nothing stored may disappear.
    enabled_config = dataclasses.replace(
        engine._config, large_output_externalization_enabled=True
    )
    replay_enabled = LCMEngine(config=enabled_config, hermes_home=str(engine._hermes_home))
    replay_enabled._session_id = SESSION
    replay_enabled._ingest_cursor_needs_reconcile = True
    replay_enabled._ingest_messages(messages)
    after_enabled = replay_enabled._store.get_session_count(SESSION)
    assert after_enabled in (after_same, after_same + 1)

    # Backing file gone -> no recoverable proof -> append.
    persisted.unlink()
    replay_missing = _replay(engine, messages)
    assert replay_missing._store.get_session_count(SESSION) == after_enabled + 1


def test_externalization_disabled_lossy_retry_appends(tmp_path):
    engine, output_dir = _build_engine(
        tmp_path,
        large_output_externalization_enabled=False,
        sensitive_patterns_enabled=True,
        sensitive_patterns=["password_assignment"],
    )
    host = tmp_path / "hermes-results"
    host.mkdir()
    suffix = "\n" + ("z" * 1000)
    old_result = "password = OLDSECRET" + suffix
    new_result = "password = NEWSECRET" + suffix
    assert len(new_result) == len(old_result)
    persisted = host / "call_disabled_password_retry.txt"
    persisted.write_text(old_result, encoding="utf-8")
    original = _tool_pair("call_retry", _marker(persisted, old_result))

    engine._ingest_messages(original)
    assert engine._store.get_session_count(SESSION) == 2

    # Same content replay with the file unchanged. Dedupe (stays 2) or append
    # (becomes 4) is accepted.
    replay_same = _replay(engine, original)
    after_same = replay_same._store.get_session_count(SESSION)
    assert after_same in (2, 4)

    # The file is rewritten with a result that differs only inside the redacted
    # span, so this retry must append as a new pair.
    persisted.write_text(new_result, encoding="utf-8")
    future = time.time() + 5
    os.utime(persisted, (future, future))
    retry = _tool_pair("call_retry", _marker(persisted, new_result))
    replay_retry = _replay(engine, retry)
    assert replay_retry._store.get_session_count(SESSION) == after_same + 2
    assert not output_dir.exists()


# --------------------------------------------------------------------------
# 7. When any marker in a replayed suffix lacks live-file proof, the whole
#    suffix appends, even when the stored tail matches exactly.
# --------------------------------------------------------------------------

def test_unrecoverable_marker_appends_despite_exact_tail_match(tmp_path):
    engine, _ = _build_engine(tmp_path)
    missing = tmp_path / "hermes-results" / "missing_raw_review.txt"
    marker = (
        "<persisted-output>\n"
        "This tool result was too large (100 characters, 0.1 KB).\n"
        f"Full output saved to: {missing}\n"
        "Use the read_file tool with offset and limit to access specific "
        "sections of this output.\n\n"
        "Preview (first 30 chars):\n"
        "SAME_RETRY_PREFIX_SAME_MARKER\n...\n"
        "</persisted-output>"
    )
    messages = _tool_pair("call_raw", marker)

    engine._ingest_messages(messages)
    assert engine._store.get_session_count(SESSION) == 2

    replay = _replay(engine, messages)
    assert replay._store.get_session_count(SESSION) == 4


def test_mixed_suffix_with_one_unprovable_marker_appends(tmp_path):
    engine, _ = _build_engine(tmp_path, large_output_externalization_threshold_chars=10)
    host = tmp_path / "hermes-results"
    host.mkdir()
    live_content = "LIVE_PROOF_PREFIX:" + ("a" * 1000)
    missing_content = "MISSING_RAW_PREFIX:" + ("b" * 1000)
    live_path = host / "live.txt"
    missing_path = host / "missing.txt"
    live_path.write_text(live_content, encoding="utf-8")

    messages = [
        {"role": "tool", "tool_call_id": "call_live",
         "content": _marker(live_path, live_content)},
        {"role": "tool", "tool_call_id": "call_missing",
         "content": _marker(missing_path, missing_content)},
    ]

    engine._ingest_messages(messages)
    assert engine._store.get_session_count(SESSION) == 2

    replay = _replay(engine, messages)
    assert replay._store.get_session_count(SESSION) == 4

