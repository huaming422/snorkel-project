"""Behavioral checks for restart/replay reconciliation of large tool outputs.

Hermes-LCM replaces an oversized tool result in the conversation with a short
``<persisted-output>`` marker (it records the backing file path, the character
count, and a short preview) while the full body is kept on disk. On restart the
engine calls ``_ingest_messages(messages)``, which reconciles the incoming
stream against the already-stored session tail. A genuine unchanged replay is
deduped, and a new or retried result is appended.

The behavior under test: when a replayed marker's backing file is gone, can't
be read, or now holds a different result with the same path, length and
preview, the replay is APPENDED, even when its text matches the stored row, so
a retried result is never silently lost. A replay whose backing file is still
present and unchanged keeps deduping. No raw secret shows up in any file the
engine writes.

Every check drives the same pre-existing interface the library's own suite
uses. It calls ``engine._ingest_messages(...)`` and then reads
``engine._store.get_session_count(session_id)``,
``get_session_messages(session_id)`` or the files the engine wrote. Nothing a
fix adds is imported.

The import shim mirrors the library's own ``tests/conftest.py`` (which is not in
scope when this file is collected on its own): it registers the flat
``hermes_lcm`` package from the repository working tree without executing the
package ``__init__`` (that would try to register with a host context).
"""

from __future__ import annotations

import dataclasses
import hashlib
import importlib.util
import json
import os
import sys
import tempfile
import time
from pathlib import Path

import pytest

SESSION = "ingest-session"


def _load_hermes_lcm():
    """Register the flat ``hermes_lcm`` package from the repo working tree.

    The modules live at the repository root with intra-package relative
    imports, so the package must be registered with a search location pointing
    at that root. The package ``__init__`` is intentionally NOT executed.
    """
    if "hermes_lcm" in sys.modules:
        return
    repo_root = Path.cwd()
    if not (repo_root / "engine.py").exists():
        for cand in (repo_root, *repo_root.parents):
            if (cand / "engine.py").exists() and (cand / "store.py").exists():
                repo_root = cand
                break
    pkg = "hermes_lcm"
    spec = importlib.util.spec_from_file_location(
        pkg,
        str(repo_root / "__init__.py"),
        submodule_search_locations=[str(repo_root)],
    )
    mod = importlib.util.module_from_spec(spec)
    mod.__path__ = [str(repo_root)]
    mod.__package__ = pkg
    sys.modules[pkg] = mod


_load_hermes_lcm()

from hermes_lcm.config import LCMConfig  # noqa: E402
from hermes_lcm.engine import LCMEngine  # noqa: E402


# --------------------------------------------------------------------------
# Fixtures / helpers (self-contained, they mirror the library's own test setup)
# --------------------------------------------------------------------------

def _build_engine(tmp_path: Path, **config_overrides):
    """Build an engine with a small externalization threshold.

    A small threshold forces even modest tool results onto the out-of-line
    persisted-output path, which is where restart reconciliation happens.
    """
    output_dir = tmp_path / "externalized"
    config_kwargs = {
        "database_path": str(tmp_path / "lcm.db"),
        "large_output_externalization_enabled": True,
        "large_output_externalization_threshold_chars": 200,
        "large_output_externalization_path": str(output_dir),
    }
    config_kwargs.update(config_overrides)
    config = LCMConfig(**config_kwargs)
    engine = LCMEngine(config=config, hermes_home=str(tmp_path / "hermes"))
    engine._session_id = SESSION
    return engine, output_dir


def _replay(engine, messages):
    """Simulate a restart with a fresh engine reconciling the same session."""
    replay = LCMEngine(config=engine._config, hermes_home=str(engine._hermes_home))
    replay._session_id = SESSION
    replay._ingest_cursor_needs_reconcile = True
    replay._ingest_messages(messages)
    return replay


def _marker(path, content, preview_chars=30):
    """Construct a ``<persisted-output>`` marker for a backing file."""
    return (
        "<persisted-output>\n"
        f"This tool result was too large ({len(content):,} characters, 1.0 KB).\n"
        f"Full output saved to: {path}\n"
        "Use the read_file tool with offset and limit to access specific "
        "sections of this output.\n\n"
        f"Preview (first {preview_chars} chars):\n"
        f"{content[:preview_chars]}\n...\n"
        "</persisted-output>"
    )


def _tool_pair(call_id, content):
    return [
        {
            "role": "assistant",
            "content": "Calling",
            "tool_calls": [
                {"id": call_id, "function": {"name": "dump", "arguments": "{}"}}
            ],
        },
        {"role": "tool", "tool_call_id": call_id, "content": content},
    ]


@pytest.fixture(autouse=True)
def _redirect_tempdir(tmp_path, monkeypatch):
    """Keep any library temp writes inside the per-test directory."""
    monkeypatch.setattr(tempfile, "tempdir", str(tmp_path))


def _payload_contents(output_dir: Path):
    return [json.loads(p.read_text())["content"] for p in output_dir.glob("*.json")]


def _assert_secrets_not_stored(tmp_path: Path, *secrets):
    """Check every file the engine wrote (database, WAL, payloads) for raw secrets.

    The tool's own saved results under ``hermes-results`` are the input, not
    something the engine stores, so they are skipped.
    """
    host = tmp_path / "hermes-results"
    stored = [p for p in tmp_path.rglob("*") if p.is_file() and host not in p.parents]
    assert stored
    for path in stored:
        data = path.read_bytes()
        for secret in secrets:
            assert secret.encode() not in data, f"raw {secret!r} stored in {path.name}"


# --------------------------------------------------------------------------
# 1. Missing backing file must append on replay (not silently dedupe).
# --------------------------------------------------------------------------

def test_missing_backing_file_appends_on_replay(tmp_path):
    engine, _ = _build_engine(tmp_path)
    host = tmp_path / "hermes-results"
    host.mkdir()
    full = "FULL_RESTART_NEEDLE:\n" + ("abcdef" * 1000)
    persisted = host / "call_restart.txt"
    persisted.write_text(full, encoding="utf-8")
    messages = _tool_pair("call_restart", _marker(persisted, full))

    engine._ingest_messages(messages)
    assert engine._store.get_session_count(SESSION) == 2

    # The backing file is gone, so the replay could be a retry. It must append.
    persisted.unlink()
    replay = _replay(engine, messages)
    assert replay._store.get_session_count(SESSION) == 4


# A backing file that can't be read counts like a missing one. In the first two
# cases the file is unreadable from the first ingest on and never changes.
@pytest.mark.parametrize("externalize", [True, False], ids=["externalized", "inline"])
@pytest.mark.parametrize("kind", ["directory", "not_utf8", "turned_not_utf8"])
def test_unreadable_backing_file_appends_on_replay(tmp_path, kind, externalize):
    engine, _ = _build_engine(tmp_path, large_output_externalization_enabled=externalize)
    host = tmp_path / "hermes-results"
    host.mkdir()
    full = "UNREADABLE_NEEDLE:" + ("u" * 1000)
    # Same byte length as ``full``, with one byte that is not valid UTF-8.
    garbled = full.encode("utf-8")[:-5] + b"\xff" + full.encode("utf-8")[-4:]
    persisted = host / "call_unreadable.txt"
    if kind == "directory":
        persisted.mkdir()
    elif kind == "not_utf8":
        persisted.write_bytes(garbled)
    else:
        persisted.write_text(full, encoding="utf-8")
    messages = _tool_pair("call_unreadable", _marker(persisted, full))

    engine._ingest_messages(messages)
    assert engine._store.get_session_count(SESSION) == 2

    if kind == "turned_not_utf8":
        # Garbled in place, keeping the old size and mtime.
        old_stat = persisted.stat()
        persisted.write_bytes(garbled)
        os.utime(persisted, ns=(old_stat.st_atime_ns, old_stat.st_mtime_ns))

    replay = _replay(engine, messages)
    assert replay._store.get_session_count(SESSION) == 4


# --------------------------------------------------------------------------
# 2. Genuine unchanged replay still dedupes.
# --------------------------------------------------------------------------

def test_genuine_unchanged_replay_still_dedupes(tmp_path):
    engine, _ = _build_engine(tmp_path)
    host = tmp_path / "hermes-results"
    host.mkdir()
    full = "FULL_RESTART_NEEDLE:\n" + ("abcdef" * 1000)
    persisted = host / "call_restart.txt"
    persisted.write_text(full, encoding="utf-8")
    messages = _tool_pair("call_restart", _marker(persisted, full))

    engine._ingest_messages(messages)
    assert engine._store.get_session_count(SESSION) == 2
    before = engine._store.get_session_messages(SESSION)

    # File still present and matching -> this is a true replay -> dedupe.
    replay = _replay(engine, messages)
    assert replay._store.get_session_count(SESSION) == 2
    after = replay._store.get_session_messages(SESSION)
    assert [m["content"] for m in after] == [m["content"] for m in before]


# A genuine replay of a result with a masked secret also dedupes, and the raw
# secret is never stored. The secret sits in the body or, for an api_key, in the
# preview.
@pytest.mark.parametrize(
    "old_result,secret",
    [
        ("SAME_REPLAY_PREFIX:" + ("p" * 64) + "\npassword = KEEPSECRET1\nend" + ("y" * 400),
         "KEEPSECRET1"),
        ("OTHER_REPLAY_PREFIX:" + ("q" * 64) + "\napi_key=KEEPTOKENVALUE0042\n" + ("x" * 600),
         "KEEPTOKENVALUE0042"),
        ("api_key=PREVIEWTOKEN0077XYZ done\n" + ("w" * 900), "PREVIEWTOKEN0077XYZ"),
    ],
    ids=["password_in_body", "api_key_in_body", "api_key_in_preview"],
)
def test_genuine_unchanged_redacted_replay_still_dedupes(tmp_path, old_result, secret):
    engine, _ = _build_engine(
        tmp_path,
        sensitive_patterns_enabled=True,
        sensitive_patterns=["password_assignment", "api_key"],
    )
    host = tmp_path / "hermes-results"
    host.mkdir()
    persisted = host / "call_redacted_replay.txt"
    persisted.write_text(old_result, encoding="utf-8")
    messages = _tool_pair("call_redacted_replay", _marker(persisted, old_result, preview_chars=40))

    engine._ingest_messages(messages)
    assert engine._store.get_session_count(SESSION) == 2
    before = engine._store.get_session_messages(SESSION)

    replay = _replay(engine, messages)
    assert replay._store.get_session_count(SESSION) == 2
    after = replay._store.get_session_messages(SESSION)
    assert [m["content"] for m in after] == [m["content"] for m in before]
    _assert_secrets_not_stored(tmp_path, secret)


# With a masked password in the preview, an unchanged replay may be stored again
# or deduped. Either way the first rows stay as they were and the password is
# never stored raw.
def test_unchanged_replay_with_masked_password_in_preview_loses_nothing(tmp_path):
    engine, _ = _build_engine(
        tmp_path,
        sensitive_patterns_enabled=True,
        sensitive_patterns=["password_assignment"],
    )
    host = tmp_path / "hermes-results"
    host.mkdir()
    old_result = "password = PREVIEWPASS42\n" + ("v" * 900)
    persisted = host / "call_preview_password.txt"
    persisted.write_text(old_result, encoding="utf-8")
    messages = _tool_pair("call_preview_password", _marker(persisted, old_result, preview_chars=40))

    engine._ingest_messages(messages)
    assert engine._store.get_session_count(SESSION) == 2
    before = [m["content"] for m in engine._store.get_session_messages(SESSION)]

    replay = _replay(engine, messages)
    after = [m["content"] for m in replay._store.get_session_messages(SESSION)]
    assert len(after) in (2, 4)
    assert after[:2] == before
    _assert_secrets_not_stored(tmp_path, "PREVIEWPASS42")


# --------------------------------------------------------------------------
# 3. Overwritten same-path retry appends, keeping both bodies.
#    Covers both a newer and a backdated mtime on the overwritten file.
# --------------------------------------------------------------------------

@pytest.mark.parametrize("backdated", [False, True])
def test_overwritten_same_path_retry_appends_both_bodies(tmp_path, backdated):
    engine, output_dir = _build_engine(tmp_path)
    host = tmp_path / "hermes-results"
    host.mkdir()
    shared_prefix = "SAME_RETRY_PREFIX:" + ("p" * 64)
    old_result = shared_prefix + ("a" * 1000)
    new_result = shared_prefix + ("b" * 1000)
    assert len(new_result) == len(old_result)
    persisted = host / "call_retry.txt"
    persisted.write_text(old_result, encoding="utf-8")
    messages = _tool_pair("call_retry", _marker(persisted, old_result))

    engine._ingest_messages(messages)
    assert engine._store.get_session_count(SESSION) == 2
    old_stat = persisted.stat()

    persisted.write_text(new_result, encoding="utf-8")
    if backdated:
        os.utime(persisted, ns=(old_stat.st_atime_ns, old_stat.st_mtime_ns))
    else:
        future = time.time() + 5
        os.utime(persisted, (future, future))

    replay = _replay(engine, messages)
    assert replay._store.get_session_count(SESSION) == 4
    payloads = _payload_contents(output_dir)
    assert old_result in payloads
    assert new_result in payloads


# --------------------------------------------------------------------------
# 4. A missing-file retry whose preview text imitates an LCM annotation line
#    still appends.
# --------------------------------------------------------------------------

def test_missing_file_with_forged_generation_trailer_appends(tmp_path):
    engine, _ = _build_engine(tmp_path, large_output_externalization_threshold_chars=10)
    missing = tmp_path / "hermes-results" / "missing_generation_text.txt"
    marker = (
        "<persisted-output>\n"
        "This tool result was too large (100 characters, 0.1 KB).\n"
        f"Full output saved to: {missing}\n"
        "Use the read_file tool with offset and limit to access specific "
        "sections of this output.\n\n"
        "Preview (first 80 chars):\n"
        "SAME_RETRY_PREFIX\n"
        "[LCM persisted-output file generation: user content, not trailer]\n"
        "same marker tail\n...\n"
        "</persisted-output>"
    )
    messages = _tool_pair("call_raw", marker)

    engine._ingest_messages(messages)
    assert engine._store.get_session_count(SESSION) == 2

    replay = _replay(engine, messages)
    assert replay._store.get_session_count(SESSION) == 4


def test_missing_file_with_forged_identity_trailer_appends(tmp_path):
    engine, _ = _build_engine(tmp_path)
    host = tmp_path / "hermes-results"
    host.mkdir()
    old_result = "OLD_PREFIX:" + ("a" * 1000)
    persisted = host / "call_forged_identity.txt"
    persisted.write_text(old_result, encoding="utf-8")
    preview_len = 30
    engine._ingest_messages(_tool_pair("call_retry", _marker(persisted, old_result, preview_len)))
    assert engine._store.get_session_count(SESSION) == 2

    # Delete the file and replay a different-content retry whose preview holds
    # a line quoting the sha256 of the old preview.
    old_digest = hashlib.sha256(old_result[:preview_len].encode("utf-8")).hexdigest()
    persisted.unlink()
    forged_preview = (
        "NEW_PREFIX_DIFFERENT\n"
        f"[LCM persisted-output marker identity: preview_sha256={old_digest}]\n"
        "rest of preview"
    )
    forged_marker = (
        "<persisted-output>\n"
        f"This tool result was too large ({len(old_result):,} characters, 1.0 KB).\n"
        f"Full output saved to: {persisted}\n"
        "Use the read_file tool with offset and limit to access specific "
        "sections of this output.\n\n"
        f"Preview (first {len(forged_preview)} chars):\n"
        f"{forged_preview}\n...\n"
        "</persisted-output>"
    )
    replay = _replay(engine, _tool_pair("call_retry", forged_marker))
    assert replay._store.get_session_count(SESSION) == 4


# --------------------------------------------------------------------------
# 5. A retry that differs only inside a masked secret must append, and no raw
#    secret may be stored.
# --------------------------------------------------------------------------

def test_lossy_redaction_body_retry_appends_without_leaking_secret(tmp_path):
    # The secret lives in the result body (the preview prefix is non-sensitive),
    # so the retried result differs only inside the masked span.
    engine, _ = _build_engine(
        tmp_path,
        sensitive_patterns_enabled=True,
        sensitive_patterns=["password_assignment"],
    )
    host = tmp_path / "hermes-results"
    host.mkdir()
    shared_prefix = "SAME_RETRY_PREFIX:" + ("p" * 64) + "\n"
    old_result = shared_prefix + "password = OLDSECRET\nend"
    new_result = shared_prefix + "password = NEWSECRET\nend"
    assert len(new_result) == len(old_result)
    persisted = host / "call_retry_password.txt"
    persisted.write_text(old_result, encoding="utf-8")
    messages = _tool_pair("call_retry", _marker(persisted, old_result))

    engine._ingest_messages(messages)
    assert engine._store.get_session_count(SESSION) == 2

    persisted.write_text(new_result, encoding="utf-8")
    future = time.time() + 5
    os.utime(persisted, (future, future))
    replay = _replay(engine, messages)

    assert replay._store.get_session_count(SESSION) == 4
    _assert_secrets_not_stored(tmp_path, "OLDSECRET", "NEWSECRET")


def test_lossy_redaction_preview_retry_appends_without_leaking_secret(tmp_path):
    # The secret lives inside the preview itself.
    engine, _ = _build_engine(
        tmp_path,
        sensitive_patterns_enabled=True,
        sensitive_patterns=["password_assignment"],
    )
    host = tmp_path / "hermes-results"
    host.mkdir()
    suffix = "\n" + ("z" * 1000)
    old_result = "password = OLDSECRET" + suffix
    new_result = "password = NEWSECRET" + suffix
    assert len(new_result) == len(old_result)
    persisted = host / "call_retry_password_preview.txt"
    persisted.write_text(old_result, encoding="utf-8")

    engine._ingest_messages(_tool_pair("call_retry", _marker(persisted, old_result)))
    assert engine._store.get_session_count(SESSION) == 2

    persisted.write_text(new_result, encoding="utf-8")
    future = time.time() + 5
    os.utime(persisted, (future, future))
    replay = _replay(engine, _tool_pair("call_retry", _marker(persisted, new_result)))

    assert replay._store.get_session_count(SESSION) == 4
    _assert_secrets_not_stored(tmp_path, "OLDSECRET", "NEWSECRET")


# An api_key retry with a new token, in the preview or in the body, appends and
# stores neither token raw, with externalization on or off.
@pytest.mark.parametrize("externalize", [True, False], ids=["externalized", "inline"])
@pytest.mark.parametrize("position", ["preview", "body"])
def test_api_key_retry_appends_without_storing_raw_token(tmp_path, position, externalize):
    engine, _ = _build_engine(
        tmp_path,
        large_output_externalization_enabled=externalize,
        sensitive_patterns_enabled=True,
        sensitive_patterns=["api_key"],
    )
    host = tmp_path / "hermes-results"
    host.mkdir()
    prefix = "" if position == "preview" else "API_RETRY_PREFIX:" + ("k" * 64) + "\n"
    old_result = prefix + "api_key=OLDTOKENVALUE0451 done\n" + ("t" * 900)
    new_result = prefix + "api_key=NEWTOKENVALUE0872 done\n" + ("t" * 900)
    assert len(new_result) == len(old_result)
    persisted = host / "call_retry_api_key.txt"
    persisted.write_text(old_result, encoding="utf-8")

    engine._ingest_messages(_tool_pair("call_retry", _marker(persisted, old_result)))
    assert engine._store.get_session_count(SESSION) == 2

    persisted.write_text(new_result, encoding="utf-8")
    future = time.time() + 5
    os.utime(persisted, (future, future))
    replay = _replay(engine, _tool_pair("call_retry", _marker(persisted, new_result)))

    assert replay._store.get_session_count(SESSION) == 4
    _assert_secrets_not_stored(tmp_path, "OLDTOKENVALUE0451", "NEWTOKENVALUE0872")


# --------------------------------------------------------------------------
# 6. With externalization disabled, a missing or rewritten backing file must
#    still append. A replay whose file is still present and unchanged may
#    either dedupe or append here, so those steps only require that no stored
#    row is lost.
# --------------------------------------------------------------------------

def test_externalization_disabled_missing_file_appends(tmp_path):
    engine, output_dir = _build_engine(tmp_path, large_output_externalization_enabled=False)
    host = tmp_path / "hermes-results"
    host.mkdir()
    full = "FULL_DISABLED_NEEDLE:" + ("abc" * 1000)
    persisted = host / "call_disabled.txt"
    persisted.write_text(full, encoding="utf-8")
    messages = [{"role": "tool", "tool_call_id": "call_disabled",
                 "content": _marker(persisted, full, preview_chars=20)}]

    # A single inline-fallback tool message is stored as one row. With
    # externalization disabled nothing is written out of line.
    engine._ingest_messages(messages)
    assert engine._store.get_session_count(SESSION) == 1
    assert not output_dir.exists()

    # File still present and matching. Either dedupe (stays 1) or append
    # (becomes 2) is accepted, but the stored row must never be dropped.
    replay_same = _replay(engine, messages)
    after_same = replay_same._store.get_session_count(SESSION)
    assert after_same in (1, 2)

    # Same marker replayed under a config that re-enables externalization.
    # Dedupe or append is accepted, and nothing stored may disappear.
    enabled_config = dataclasses.replace(
        engine._config, large_output_externalization_enabled=True
    )
    replay_enabled = LCMEngine(config=enabled_config, hermes_home=str(engine._hermes_home))
    replay_enabled._session_id = SESSION
    replay_enabled._ingest_cursor_needs_reconcile = True
    replay_enabled._ingest_messages(messages)
    after_enabled = replay_enabled._store.get_session_count(SESSION)
    assert after_enabled in (after_same, after_same + 1)

    # Backing file gone -> append.
    persisted.unlink()
    replay_missing = _replay(engine, messages)
    assert replay_missing._store.get_session_count(SESSION) == after_enabled + 1


def test_externalization_disabled_lossy_retry_appends(tmp_path):
    engine, output_dir = _build_engine(
        tmp_path,
        large_output_externalization_enabled=False,
        sensitive_patterns_enabled=True,
        sensitive_patterns=["password_assignment"],
    )
    host = tmp_path / "hermes-results"
    host.mkdir()
    suffix = "\n" + ("z" * 1000)
    old_result = "password = OLDSECRET" + suffix
    new_result = "password = NEWSECRET" + suffix
    assert len(new_result) == len(old_result)
    persisted = host / "call_disabled_password_retry.txt"
    persisted.write_text(old_result, encoding="utf-8")
    original = _tool_pair("call_retry", _marker(persisted, old_result))

    engine._ingest_messages(original)
    assert engine._store.get_session_count(SESSION) == 2

    # Same content replay with the file unchanged. Dedupe (stays 2) or append
    # (becomes 4) is accepted.
    replay_same = _replay(engine, original)
    after_same = replay_same._store.get_session_count(SESSION)
    assert after_same in (2, 4)

    # The file is rewritten with a result that differs only inside the redacted
    # span, so this retry must append as a new pair.
    persisted.write_text(new_result, encoding="utf-8")
    future = time.time() + 5
    os.utime(persisted, (future, future))
    retry = _tool_pair("call_retry", _marker(persisted, new_result))
    replay_retry = _replay(engine, retry)
    assert replay_retry._store.get_session_count(SESSION) == after_same + 2
    assert not output_dir.exists()
    _assert_secrets_not_stored(tmp_path, "OLDSECRET", "NEWSECRET")


# --------------------------------------------------------------------------
# 7. A marker whose backing file was never there appends, and when one result
#    in a replayed batch has a missing file, the whole batch appends, even
#    when the stored tail matches exactly.
# --------------------------------------------------------------------------

def test_never_written_file_appends_despite_exact_tail_match(tmp_path):
    engine, _ = _build_engine(tmp_path)
    missing = tmp_path / "hermes-results" / "missing_raw_review.txt"
    marker = (
        "<persisted-output>\n"
        "This tool result was too large (100 characters, 0.1 KB).\n"
        f"Full output saved to: {missing}\n"
        "Use the read_file tool with offset and limit to access specific "
        "sections of this output.\n\n"
        "Preview (first 30 chars):\n"
        "SAME_RETRY_PREFIX_SAME_MARKER\n...\n"
        "</persisted-output>"
    )
    messages = _tool_pair("call_raw", marker)

    engine._ingest_messages(messages)
    assert engine._store.get_session_count(SESSION) == 2

    replay = _replay(engine, messages)
    assert replay._store.get_session_count(SESSION) == 4


@pytest.mark.parametrize("externalize", [True, False], ids=["externalized", "inline"])
def test_mixed_batch_with_one_missing_file_appends(tmp_path, externalize):
    engine, _ = _build_engine(
        tmp_path,
        large_output_externalization_enabled=externalize,
        large_output_externalization_threshold_chars=10,
    )
    host = tmp_path / "hermes-results"
    host.mkdir()
    live_content = "PRESENT_FILE_PREFIX:" + ("a" * 1000)
    missing_content = "MISSING_RAW_PREFIX:" + ("b" * 1000)
    live_path = host / "live.txt"
    missing_path = host / "missing.txt"
    live_path.write_text(live_content, encoding="utf-8")

    messages = [
        {"role": "tool", "tool_call_id": "call_live",
         "content": _marker(live_path, live_content)},
        {"role": "tool", "tool_call_id": "call_missing",
         "content": _marker(missing_path, missing_content)},
    ]

    engine._ingest_messages(messages)
    assert engine._store.get_session_count(SESSION) == 2

    replay = _replay(engine, messages)
    assert replay._store.get_session_count(SESSION) == 4

