## Task

we're losing tool output after restarts.
it shows up when an agent runs a tool again, gets a new large result back as a `<persisted-output>` note pointing at a saved file, and the session's saved history is replayed later.
the newer output never shows up in the stored session.
there's no error, it's just missing.
can you track this down and fix it?

here's how replay should behave once it's fixed:
- if the saved file is still there and still holds the same result, nothing new gets stored, including when redaction masks a secret in that result.
- if the saved file is gone, can't be read, or now holds something else, keep the replayed result as a new entry, even when its text looks exactly like what's already stored.
- a masked password inside the preview text means the replay can't be matched, so treat it like a changed result.
- if any large result in a replayed batch can't be matched this way, keep the whole batch.
- with `LCM_LARGE_OUTPUT_EXTERNALIZATION_ENABLED` off, storing an unchanged replay a second time is fine, but a replay whose file is gone or changed still has to be kept.
- raw secrets must not end up in anything we store.

a duplicate is better than lost output.
no config or schema changes should be needed.
