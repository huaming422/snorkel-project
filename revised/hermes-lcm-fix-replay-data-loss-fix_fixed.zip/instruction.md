## Task

we're quietly losing tool output after a restart.
an agent re-runs a tool that returns a big result, the session later replays its saved history, and the retried result gets matched to an older one we already have.
it never makes it into the store.

here's how replay should treat those big outputs that point at a file on disk:
- if the file is still there and hasn't changed since we stored it, it's the same result, so don't store it twice.
- if the file is gone or can't be read, there's no way to tell a replay from a retry, so keep the incoming one, even when the marker text matches the stored one byte for byte.
- if a retry wrote over the same file, that's a new result even when the path, size and preview all match, and even if the file's timestamp was set back to an older value.
  we should end up with both bodies.
- with secret masking on, a retry whose only difference sits inside a masked value is still new, and nothing we store may hold the raw secret or a hash of the unmasked preview.
- the preview inside the marker is just tool output, so nothing written there counts as proof.
- if even one big output in a replayed batch can't be confirmed, don't treat that batch as already stored.
- with large-output externalization turned off, a missing or rewritten file still means we keep the incoming result.
  there's no stored copy of the body in that mode, so an extra row on an unchanged replay is fine there, but a lost one isn't.

a few existing tests still expect the old dedupe once the file is gone, so update them to match.
leave compaction, summarization, config and the database schema alone for this.
