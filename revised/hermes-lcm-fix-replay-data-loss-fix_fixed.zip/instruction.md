## Task

we're losing tool output after restarts.
it shows up when an agent runs a tool again, gets a new large result, and the session's saved history is replayed later.
the newer output never shows up in the stored session.
there's no error, it's just missing.
can you track this down and fix it?
some existing replay tests may need updating along the way.
no config or schema changes should be needed.
