## Task

we're losing tool output after a restart.
an agent re-runs a tool that returns a large result, and later the session replays its saved history.
the retried result gets matched to an older one we already have, so the new one is never stored.
nothing errors, the output is just gone.
in the saved history, a retry can look exactly like the result it replaced.
when replay can't tell whether a large result is one we already have, keep it.
i'd rather see an extra row than lose output.
replaying a session that hasn't changed still shouldn't pile up duplicates, though.
a few existing replay tests were written around the current behavior, so it's fine to update those.
please leave compaction, summarization, config and the db schema out of this.
