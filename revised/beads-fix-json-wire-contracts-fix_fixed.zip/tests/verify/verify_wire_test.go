// Pure-Go checks on the JSON wire contract that a client sees: metadata scalar
// typing, the revision token's wire spelling in the issue detail view, and the
// agreement between the generated Go request/response structs and the published
// OpenAPI document. Everything here runs through the packages' exported surface
// (storage.MetadataEditValue / storage.ApplyMetadataEdits, types.NewIssueDetails,
// the apigen structs, the embedded spec bytes). No internal symbol is named.
package storage_test

import (
	"encoding/json"
	"fmt"
	"reflect"
	"strconv"
	"strings"
	"testing"

	"gopkg.in/yaml.v3"

	"github.com/steveyegge/beads/internal/httpapi/apigen"
	"github.com/steveyegge/beads/internal/httpapi/spec"
	"github.com/steveyegge/beads/internal/storage"
	"github.com/steveyegge/beads/internal/types"
)

// A --set-metadata value is stored and echoed as JSON whose scalar type is
// inferred from the value's spelling: the canonical JSON scalars keep their
// type, while a spelling that is not valid JSON on its own stays a quoted
// string even when it scans as a float. The leading-zero / unary-plus / NaN /
// dotted rows scan as floats but are not JSON numbers as written, and the text
// rows keep plain strings as strings for map[string]string readers.
func TestVerifyMetadataScalarTyping(t *testing.T) {
	cases := []struct {
		name  string
		input string
		want  string
	}{
		{"integer", "5", `5`},
		{"negative integer", "-2", `-2`},
		{"trailing zero float", "0.50", `0.50`},
		{"exponent", "1e3", `1e3`},
		{"zero", "0", `0`},
		{"true", "true", `true`},
		{"false", "false", `false`},
		{"null", "null", `null`},
		{"leading zero stays text", "05", `"05"`},
		{"unary plus stays text", "+5", `"+5"`},
		{"not-a-number stays text", "NaN", `"NaN"`},
		{"dotted triple stays text", "1.2.3", `"1.2.3"`},
		{"empty stays text", "", `""`},
		{"word stays text", "abc", `"abc"`},
		{"sentence stays text", "hello world", `"hello world"`},
	}
	for _, c := range cases {
		c := c
		t.Run(c.name, func(t *testing.T) {
			got := string(storage.MetadataEditValue(c.input))
			if got != c.want {
				t.Errorf("MetadataEditValue(%q) = %s, want %s", c.input, got, c.want)
			}
			if !json.Valid([]byte(got)) {
				t.Errorf("MetadataEditValue(%q) = %s, which is not valid JSON", c.input, got)
			}
		})
	}
}

// The inference must reach the merged blob every edit path writes, not just the
// single-value helper. A set of edits is applied over an existing blob and the
// resulting JSON is decoded back: canonical scalars arrive as numbers / bools /
// null, text arrives as a string, and pre-existing keys survive untouched.
func TestVerifyApplyMetadataEditsTyping(t *testing.T) {
	merged, err := storage.ApplyMetadataEdits(
		json.RawMessage(`{"existing":"yes"}`),
		[]string{"score=99", "ratio=0.5", "done=true", "cleared=null", "tier=gold"},
		nil,
	)
	if err != nil {
		t.Fatalf("ApplyMetadataEdits: %v", err)
	}
	var got map[string]any
	if err := json.Unmarshal(merged, &got); err != nil {
		t.Fatalf("unmarshal %s: %v", merged, err)
	}
	if got["score"] != float64(99) {
		t.Errorf("metadata[score] = %#v, want the JSON number 99", got["score"])
	}
	if got["ratio"] != 0.5 {
		t.Errorf("metadata[ratio] = %#v, want the JSON number 0.5", got["ratio"])
	}
	if got["done"] != true {
		t.Errorf("metadata[done] = %#v, want the JSON boolean true", got["done"])
	}
	if v, present := got["cleared"]; !present || v != nil {
		t.Errorf("metadata[cleared] = %#v (present=%v), want JSON null", v, present)
	}
	if got["tier"] != "gold" {
		t.Errorf("metadata[tier] = %#v, want %q", got["tier"], "gold")
	}
	if got["existing"] != "yes" {
		t.Errorf("metadata[existing] = %#v, want %q: pre-existing keys must survive", got["existing"], "yes")
	}
}

// revisionTokens spans the int64 range the token is drawn from: the legacy
// zero, small values, values just past 2^53 on both sides of zero, and both
// int64 extremes. A float64 reader changes every value past 2^53, so each one
// has to come back as the exact decimal spelling.
var revisionTokens = []int64{
	0,
	7,
	9007199254740993,  // 2^53 + 1
	-9007199254740995, // -(2^53 + 3)
	4611686018427387905,
	9223372036854775807,
	-9223372036854775808,
}

// The detail view publishes the row's optimistic-concurrency token under the
// `revision` key. On the wire it is a JSON string holding the token's decimal
// spelling, so a JavaScript consumer reads back exactly the value it must echo
// on a guarded write.
func TestVerifyRevisionDetailsWireString(t *testing.T) {
	for _, rowVersion := range revisionTokens {
		rowVersion := rowVersion
		want := strconv.FormatInt(rowVersion, 10)
		t.Run(want, func(t *testing.T) {
			details := types.NewIssueDetails(types.Issue{RowVersion: rowVersion})

			blob, err := json.Marshal(details)
			if err != nil {
				t.Fatalf("marshal issue details: %v", err)
			}
			var fields map[string]json.RawMessage
			if err := json.Unmarshal(blob, &fields); err != nil {
				t.Fatalf("unmarshal issue details %s: %v", blob, err)
			}
			raw, ok := fields["revision"]
			if !ok {
				t.Fatalf("issue details carry no `revision` member: %s", blob)
			}
			// A JSON string literal begins with a double quote; a JSON number does not.
			if len(raw) == 0 || raw[0] != '"' {
				t.Fatalf("`revision` = %s, want a JSON string (a number loses precision past 2^53)", raw)
			}
			var token string
			if err := json.Unmarshal(raw, &token); err != nil {
				t.Fatalf("`revision` %s does not decode as a JSON string: %v", raw, err)
			}
			if token != want {
				t.Errorf("`revision` = %q, want the decimal spelling %q", token, want)
			}
		})
	}
}

// Every revision / expected-version / actual-version member is published as a
// JSON string, in the OpenAPI document and in the Go structs generated from it.
//
// The generated struct has to be what the document generates. A property that
// is a plain `type: string` generates a Go string. A property pinned with
// `x-go-type` (directly or through a `$ref` to a pinned component) generates
// that named Go type, which can be any type that spells the token as a string.
// Whatever the Go type, the struct reads a quoted decimal token and writes the
// same quoted token back, across the whole int64 range.
func TestVerifyGeneratedSpecTypeAgreement(t *testing.T) {
	var doc map[string]any
	if err := yaml.Unmarshal(spec.OpenAPIV0(), &doc); err != nil {
		t.Fatalf("parse embedded OpenAPI document: %v", err)
	}

	// schema/prop name the OpenAPI member; goType/field name the generated Go
	// struct member it must agree with.
	checks := []struct {
		schema string
		prop   string
		goType reflect.Type
		field  string
	}{
		{"UpdateIssueResponse", "revision", reflect.TypeOf(apigen.UpdateIssueResponse{}), "Revision"},
		{"CloseIssueResponse", "revision", reflect.TypeOf(apigen.CloseIssueResponse{}), "Revision"},
		{"ReleaseIssueResponse", "revision", reflect.TypeOf(apigen.ReleaseIssueResponse{}), "Revision"},
		{"ReopenIssueResponse", "revision", reflect.TypeOf(apigen.ReopenIssueResponse{}), "Revision"},
		{"ApplyItemResult", "revision", reflect.TypeOf(apigen.ApplyItemResult{}), "Revision"},
		{"UpdateIssueRequest", "expected_version", reflect.TypeOf(apigen.UpdateIssueRequest{}), "ExpectedVersion"},
		{"CloseIssueRequest", "expected_version", reflect.TypeOf(apigen.CloseIssueRequest{}), "ExpectedVersion"},
		{"ReopenIssueRequest", "expected_version", reflect.TypeOf(apigen.ReopenIssueRequest{}), "ExpectedVersion"},
		{"DeleteIssuesRequest", "expected_version", reflect.TypeOf(apigen.DeleteIssuesRequest{}), "ExpectedVersion"},
		{"ApplyUpdateItem", "expected_version", reflect.TypeOf(apigen.ApplyUpdateItem{}), "ExpectedVersion"},
		{"ApplyCloseItem", "expected_version", reflect.TypeOf(apigen.ApplyCloseItem{}), "ExpectedVersion"},
		{"Problem", "expected_version", reflect.TypeOf(apigen.Problem{}), "ExpectedVersion"},
		{"Problem", "actual_version", reflect.TypeOf(apigen.Problem{}), "ActualVersion"},
	}

	for _, c := range checks {
		c := c
		t.Run(c.schema+"."+c.prop, func(t *testing.T) {
			prop := specProperty(t, doc, c.schema, c.prop)
			if typ, _ := prop["type"].(string); typ != "string" {
				t.Errorf("OpenAPI %s.%s has type %q, want \"string\": revision and expected_version are JSON strings on the wire",
					c.schema, c.prop, typ)
			}

			goType := generatedFieldType(t, c.goType, c.field)
			if pin, pinned := prop["x-go-type"].(string); pinned {
				if pin != goType.Name() && !strings.HasSuffix(pin, "."+goType.Name()) {
					t.Errorf("%s.%s: OpenAPI pins x-go-type %q but the generated field is %s, so the generated file does not match the document",
						c.schema, c.prop, pin, goType)
				}
			} else if goType.Kind() != reflect.String {
				t.Errorf("%s.%s: generated field is %s, but a `type: string` property with no x-go-type generates a Go string, so the generated file does not match the document",
					c.schema, c.prop, goType)
			}

			for _, v := range revisionTokens {
				assertTokenRoundTrip(t, c.goType, c.prop, strconv.FormatInt(v, 10))
			}
		})
	}
}

// generatedFieldType returns the Go type of a generated struct member, with a
// pointer followed to its element.
func generatedFieldType(t *testing.T, st reflect.Type, field string) reflect.Type {
	t.Helper()
	f, ok := st.FieldByName(field)
	if !ok {
		t.Fatalf("%s has no field %q", st.Name(), field)
	}
	ft := f.Type
	if ft.Kind() == reflect.Pointer {
		ft = ft.Elem()
	}
	return ft
}

// assertTokenRoundTrip decodes {"<prop>":"<token>"} into a fresh value of the
// generated struct, encodes it again, and checks that the member comes back as
// the same quoted decimal string.
func assertTokenRoundTrip(t *testing.T, st reflect.Type, prop, token string) {
	t.Helper()
	in := fmt.Sprintf(`{%q:%q}`, prop, token)
	ptr := reflect.New(st)
	if err := json.Unmarshal([]byte(in), ptr.Interface()); err != nil {
		t.Errorf("%s: decode %s: %v; the member must accept the token as a JSON string", st.Name(), in, err)
		return
	}
	out, err := json.Marshal(ptr.Interface())
	if err != nil {
		t.Errorf("%s: encode after decoding %s: %v", st.Name(), in, err)
		return
	}
	var fields map[string]json.RawMessage
	if err := json.Unmarshal(out, &fields); err != nil {
		t.Errorf("%s: encoded value %s is not a JSON object: %v", st.Name(), out, err)
		return
	}
	if got, want := string(fields[prop]), strconv.Quote(token); got != want {
		t.Errorf("%s.%s: decoded %s and encoded it back as %s, want %s", st.Name(), prop, in, got, want)
	}
}

// specProperty returns components.schemas.<schema>.properties.<prop> from the
// parsed OpenAPI document. A property that is a `$ref` to another component is
// replaced by that component, which is what the generator reads for it.
func specProperty(t *testing.T, doc map[string]any, schema, prop string) map[string]any {
	t.Helper()
	components := childMap(t, doc, "components")
	schemas := childMap(t, components, "schemas")
	s := childMap(t, schemas, schema)
	props := childMap(t, s, "properties")
	p := childMap(t, props, prop)
	if ref, ok := p["$ref"].(string); ok {
		const prefix = "#/components/schemas/"
		if !strings.HasPrefix(ref, prefix) {
			t.Fatalf("components.schemas.%s.properties.%s refers to %q, outside components.schemas", schema, prop, ref)
		}
		p = childMap(t, schemas, strings.TrimPrefix(ref, prefix))
	}
	return p
}

func childMap(t *testing.T, parent map[string]any, key string) map[string]any {
	t.Helper()
	v, ok := parent[key]
	if !ok {
		t.Fatalf("missing key %q", key)
	}
	m, ok := v.(map[string]any)
	if !ok {
		t.Fatalf("key %q is %T, want a mapping", key, v)
	}
	return m
}
