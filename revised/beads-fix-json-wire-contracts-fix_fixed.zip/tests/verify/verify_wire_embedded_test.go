//go:build cgo

// Checks that exercise the JSON wire contract end to end over a REAL embedded
// store: the create echo's sub-second timestamps on the executor path (single
// and batch), and, through a live in-process HTTP server bound to that same
// store, the create echo over the wire, the revision token's string spelling
// on a guarded-write response, and the symmetric guard rule (a string guard is
// accepted, a bare-number guard is a 400 naming the member).
//
// The suite reuses the package's existing embedded-store scaffolding
// (newTestEnv, the conformance fixture builders, requireEmbeddedDolt) and the
// top-level issueops / httpapi packages' exported surface. Every symbol it
// names already exists in the repository.
package embeddeddolt_test

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"testing"
	"time"

	"github.com/steveyegge/beads/backend/conformance"
	"github.com/steveyegge/beads/internal/httpapi"
	"github.com/steveyegge/beads/internal/storage"
	"github.com/steveyegge/beads/internal/types"
	publicops "github.com/steveyegge/beads/issueops"
	"github.com/steveyegge/beads/memoryops"
)

// A create RESULT carries back the exact create/update instant the caller
// supplied, down to the nanosecond. The single-lifecycle create and every entry
// of a batch create are both covered, since each is its own create entry point.
func TestVerifyEmbeddedCreateEchoesSubSecondTimestamps(t *testing.T) {
	requireEmbeddedDolt(t)
	te := newTestEnv(t, "cesl")
	ctx := t.Context()

	t.Run("Lifecycle", func(t *testing.T) {
		fixture := newEmbeddedLifecycleCreateFixture(t, te, "cesl")
		verifyLifecycleCreateEchoesSubSecond(t, ctx, fixture)
	})
	t.Run("Batch", func(t *testing.T) {
		fixture := newEmbeddedBatchCreatorFixture(t, te, "cesb")
		verifyBatchCreateEchoesSubSecond(t, ctx, fixture)
	})
}

// verifyLifecycleCreateEchoesSubSecond stages a create whose caller-supplied
// CreatedAt/UpdatedAt carry different nanosecond fractions and asserts the create
// result echoes both back to the nanosecond. The echo is the caller's record of
// the instant the row was written, and it is what orders same-second creates.
func verifyLifecycleCreateEchoesSubSecond(t *testing.T, ctx context.Context, fixture conformance.LifecycleCreateFixture) {
	t.Helper()
	id := fixture.IssuePrefix + "-nanoecho"
	createdAt := time.Date(2019, 3, 4, 5, 6, 7, 123456789, time.UTC)
	updatedAt := time.Date(2019, 3, 4, 5, 6, 8, 987654321, time.UTC)
	created, err := fixture.Lifecycle.Create(ctx, publicops.CreateRequest{
		Actor:         "writer",
		ForceIDPrefix: true,
		Issue: &types.Issue{
			ID:        id,
			Title:     "sub-second echo",
			Status:    types.StatusOpen,
			Priority:  2,
			IssueType: types.TypeTask,
			CreatedAt: createdAt,
			UpdatedAt: updatedAt,
		},
	})
	if err != nil {
		t.Fatalf("create %s with sub-second timestamps: %v", id, err)
	}
	if created.Issue == nil {
		t.Fatalf("create %s returned no issue", id)
	}
	if !created.Issue.CreatedAt.Equal(createdAt) {
		t.Errorf("%s create result created_at = %v, want %v exactly (the echo is the caller's record of when the row was written)",
			id, created.Issue.CreatedAt.UTC(), createdAt)
	}
	if !created.Issue.UpdatedAt.Equal(updatedAt) {
		t.Errorf("%s create result updated_at = %v, want %v exactly", id, created.Issue.UpdatedAt.UTC(), updatedAt)
	}
}

// verifyBatchCreateEchoesSubSecond runs the same assertion across a batch, item
// by item. Each item carries a distinct fraction and the ids are generated, the
// way the batch role mints them. The fractions sit both below and above half a
// second, so the echo has to match whichever way a whole-second value would
// round.
func verifyBatchCreateEchoesSubSecond(t *testing.T, ctx context.Context, fixture conformance.BatchCreatorFixture) {
	t.Helper()
	first := time.Date(2019, 3, 4, 5, 6, 7, 123456789, time.UTC)
	second := time.Date(2020, 4, 5, 6, 7, 8, 246813579, time.UTC)
	third := time.Date(2021, 5, 6, 7, 8, 9, 876543210, time.UTC)
	want := []time.Time{first, second, third}
	items := []publicops.BatchCreateItem{
		{Issue: &types.Issue{Title: "nano first", Priority: 2, IssueType: types.TypeTask, CreatedAt: first, UpdatedAt: first}},
		{Issue: &types.Issue{Title: "nano second", Priority: 2, IssueType: types.TypeTask, CreatedAt: second, UpdatedAt: second}},
		{Issue: &types.Issue{Title: "nano third", Priority: 2, IssueType: types.TypeTask, CreatedAt: third, UpdatedAt: third}},
	}
	result, err := fixture.BatchCreator.CreateBatch(ctx, publicops.CreateBatchRequest{
		Actor: "batch-writer",
		Items: items,
	})
	if err != nil {
		t.Fatalf("CreateBatch with sub-second timestamps: %v", err)
	}
	if len(result.Issues) != len(want) {
		t.Fatalf("CreateBatch returned %d issues for %d items", len(result.Issues), len(want))
	}
	for i, issue := range result.Issues {
		if issue == nil {
			t.Fatalf("CreateBatch result issue %d is nil", i)
		}
		if !issue.CreatedAt.Equal(want[i]) {
			t.Errorf("result issue %d created_at = %v, want %v exactly (each batch item echoes its own sub-second instant)",
				i, issue.CreatedAt.UTC(), want[i])
		}
		if !issue.UpdatedAt.Equal(want[i]) {
			t.Errorf("result issue %d updated_at = %v, want %v exactly", i, issue.UpdatedAt.UTC(), want[i])
		}
	}
}

// Over a live HTTP server bound to the real backend, a created issue's echoed
// create/update timestamp carries the sub-second part of the instant it was
// created at. A clock reading lands on an exact second about once in a billion,
// and two creates make an all-zero fraction across both vanishingly unlikely.
func TestVerifyHTTPCreateEchoesSubSecondTimestamps(t *testing.T) {
	requireEmbeddedDolt(t)
	srv := newEmbeddedHTTPServer(t, "hce")

	fractional := false
	for i := 0; i < 2; i++ {
		body := fmt.Sprintf(`{"actor":"verifier","issue_type":"task","title":"http create echo %d"}`, i)
		resp := srv.post(t, "/v0/beads/issues", body)
		if resp.status != http.StatusOK {
			t.Fatalf("create %d: status = %d, want 200: %s", i, resp.status, resp.body)
		}
		obj := resp.object(t)
		for _, member := range []string{"created_at", "updated_at"} {
			text, ok := obj[member].(string)
			if !ok {
				t.Fatalf("create %d: %s = %v, want an RFC3339 string", i, member, obj[member])
			}
			at, err := time.Parse(time.RFC3339Nano, text)
			if err != nil {
				t.Fatalf("create %d: %s = %q does not parse as RFC3339Nano: %v", i, member, text, err)
			}
			if at.Nanosecond() != 0 {
				fractional = true
			}
		}
	}
	if !fractional {
		t.Error("no create echoed a timestamp with a sub-second part across two creates; the create echo has to keep the sub-second part so same-second creates stay ordered")
	}
}

// On a guarded-write RESPONSE the revision token must be a JSON string. The
// server is driven to create an issue, then PATCH it; the update response's
// `revision` member must be a quoted string, and a number would round past 2^53
// in a JavaScript consumer. The GET detail view's `revision` is checked the same
// way, since it is the read that sources a guard.
func TestVerifyHTTPRevisionIsWireString(t *testing.T) {
	requireEmbeddedDolt(t)
	srv := newEmbeddedHTTPServer(t, "rws")

	id := srv.createIssue(t, "revision wire string")

	// The detail read that publishes the token a client must echo.
	detail := srv.get(t, "/v0/beads/issues/"+id)
	if detail.status != http.StatusOK {
		t.Fatalf("get issue: status = %d, want 200: %s", detail.status, detail.body)
	}
	assertRevisionString(t, "GET /v0/beads/issues/{id}", detail)

	// The write response that carries the post-write token.
	update := srv.patch(t, "/v0/beads/issues/"+id, `{"actor":"verifier","patch":{"title":"renamed"}}`)
	if update.status != http.StatusOK {
		t.Fatalf("update issue: status = %d, want 200: %s", update.status, update.body)
	}
	assertRevisionString(t, "PATCH /v0/beads/issues/{id}", update)
}

// The guard is symmetric: a client echoes the revision token a response carried,
// as a STRING, and that write is accepted. A client that sends the guard as a
// bare JSON number is refused with a 400 whose problem body names the offending
// member, so a client still sending numbers learns about it on its first write.
func TestVerifyHTTPGuardStringAcceptedNumberRejected(t *testing.T) {
	requireEmbeddedDolt(t)
	srv := newEmbeddedHTTPServer(t, "grd")

	id := srv.createIssue(t, "guard symmetry")
	token := srv.revisionToken(t, id)

	t.Run("StringGuardAccepted", func(t *testing.T) {
		body := fmt.Sprintf(`{"actor":"verifier","patch":{"title":"guarded rename"},"expected_version":%q}`, token)
		resp := srv.patch(t, "/v0/beads/issues/"+id, body)
		if resp.status != http.StatusOK {
			t.Fatalf("string guard matching the current revision: status = %d, want 200: %s", resp.status, resp.body)
		}
	})

	t.Run("NumberGuardRejected", func(t *testing.T) {
		// A fresh issue so the earlier accepted write cannot interfere.
		other := srv.createIssue(t, "guard numeric rejection")
		numeric := srv.revisionToken(t, other) // decimal digits, sent unquoted
		body := fmt.Sprintf(`{"actor":"verifier","patch":{"title":"numeric guard"},"expected_version":%s}`, numeric)
		resp := srv.patch(t, "/v0/beads/issues/"+other, body)
		if resp.status != http.StatusBadRequest {
			t.Fatalf("bare-number guard: status = %d, want 400 (a numeric token is a value the client already rounded): %s", resp.status, resp.body)
		}
		if !bytes.Contains([]byte(resp.body), []byte("expected_version")) {
			t.Errorf("400 problem body does not name the offending member `expected_version`: %s", resp.body)
		}
	})
}

// assertRevisionString pulls `revision` out of a JSON response and asserts it is
// a quoted string holding decimal digits.
func assertRevisionString(t *testing.T, where string, resp httpResult) {
	t.Helper()
	var fields map[string]json.RawMessage
	if err := json.Unmarshal([]byte(resp.body), &fields); err != nil {
		t.Fatalf("%s: response is not a JSON object: %v (%s)", where, err, resp.body)
	}
	raw, ok := fields["revision"]
	if !ok {
		t.Fatalf("%s: response carries no `revision` member: %s", where, resp.body)
	}
	if len(raw) == 0 || raw[0] != '"' {
		t.Fatalf("%s: `revision` = %s, want a JSON string (a number loses precision past 2^53)", where, raw)
	}
	var token string
	if err := json.Unmarshal(raw, &token); err != nil {
		t.Fatalf("%s: `revision` %s does not decode as a JSON string: %v", where, raw, err)
	}
	if token == "" {
		t.Errorf("%s: `revision` is the empty string; the legacy value is \"0\", never \"\"", where)
	}
}

// --- live server over the real embedded store ---------------------------------

// embeddedHTTPServer is a live httpapi server bound to a real embedded store on
// an ephemeral loopback port, plus a client that speaks to it.
type embeddedHTTPServer struct {
	baseURL string
	client  *http.Client
}

// newEmbeddedHTTPServer stands up the server the way cmd/bd's serve path does:
// it binds every role to the store's own capability accessor, beneath the hook
// layer (the raw embedded store fires no hooks, but the peel matches the
// production wiring), and serves on 127.0.0.1:0. The journal is left off, so the
// conditional events-journal role is not required.
func newEmbeddedHTTPServer(t *testing.T, prefix string) *embeddedHTTPServer {
	t.Helper()
	te := newTestEnv(t, prefix)
	cfg := httpapi.Config{Addr: "127.0.0.1:0"}
	bindRoles(t, te.store, &cfg)

	srv, err := httpapi.Listen(cfg)
	if err != nil {
		t.Fatalf("httpapi.Listen: %v", err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan struct{})
	go func() {
		defer close(done)
		if err := srv.Serve(ctx); err != nil {
			t.Logf("server stopped: %v", err)
		}
	}()
	t.Cleanup(func() {
		cancel()
		<-done
	})

	return &embeddedHTTPServer{
		baseURL: "http://" + srv.Addr(),
		client:  &http.Client{Timeout: 30 * time.Second},
	}
}

// bindRoles fills every role field of cfg from the store's accessors. The peel
// below the hook layer mirrors cmd/bd's serveIssueRoles, which httpapi.Listen
// refuses any configuration that skips.
func bindRoles(t *testing.T, store storage.DoltStorage, cfg *httpapi.Config) {
	t.Helper()
	var src storage.DoltStorage = store
	if hooked, ok := src.(*storage.HookFiringStore); ok {
		src = hooked.Unwrap()
	}

	must := func(name string, err error) {
		if err != nil {
			t.Fatalf("bind %s: %v", name, err)
		}
	}
	var err error
	cfg.Reader, err = src.IssueReader()
	must("reader", err)
	cfg.Claimer, err = src.IssueClaimer()
	must("claimer", err)
	cfg.BatchCloser, err = src.BatchCloser()
	must("batch closer", err)
	cfg.ReadyClaimer, err = src.ReadyClaimer()
	must("ready claimer", err)
	cfg.Releaser, err = src.Releaser()
	must("releaser", err)
	cfg.Lifecycle, err = src.IssueLifecycle()
	must("lifecycle", err)
	cfg.Settings, err = src.WorkspaceConfig()
	must("settings", err)
	cfg.Stats, err = src.StatsReporter()
	must("stats", err)
	cfg.CycleDetector, err = src.CycleDetector()
	must("cycle detector", err)
	cfg.EdgeReader, err = src.EdgeReader()
	must("edge reader", err)
	cfg.GraphCounter, err = src.GraphCounter()
	must("graph counter", err)
	cfg.Relations, err = src.IssueRelations()
	must("relations", err)
	cfg.Commenter, err = src.Commenter()
	must("commenter", err)
	cfg.BlockingAnnotator, err = src.BlockingAnnotator()
	must("blocking annotator", err)
	cfg.TreeWalker, err = src.TreeWalker()
	must("tree walker", err)
	cfg.ReadyCounter, err = src.ReadyCounter()
	must("ready counter", err)
	cfg.Counter, err = src.Counter()
	must("counter", err)
	cfg.Querier, err = src.Querier()
	must("querier", err)
	cfg.Sweeper, err = src.Sweeper()
	must("sweeper", err)
	cfg.Deleter, err = src.Deleter()
	must("deleter", err)
	cfg.BatchCreator, err = src.BatchCreator()
	must("batch creator", err)
	cfg.DependencyEditor, err = src.DependencyEditor()
	must("dependency editor", err)
	cfg.MetadataCAS, err = src.MetadataCAS()
	must("metadata cas", err)
	cfg.BatchApplier, err = src.BatchApplier()
	must("batch applier", err)
	var memories memoryops.Memories
	memories, err = src.Memories()
	must("memories", err)
	cfg.Memories = memories
}

// createIssue posts a minimal valid create and returns the minted id.
func (s *embeddedHTTPServer) createIssue(t *testing.T, title string) string {
	t.Helper()
	resp := s.post(t, "/v0/beads/issues", fmt.Sprintf(`{"actor":"verifier","issue_type":"task","title":%q}`, title))
	if resp.status != http.StatusOK {
		t.Fatalf("create issue: status = %d, want 200: %s", resp.status, resp.body)
	}
	obj := resp.object(t)
	id, ok := obj["id"].(string)
	if !ok || id == "" {
		t.Fatalf("create issue: response carries no string `id`: %s", resp.body)
	}
	return id
}

// revisionToken reads the current revision token for an issue off its detail
// view, as the decimal string the wire carries.
func (s *embeddedHTTPServer) revisionToken(t *testing.T, id string) string {
	t.Helper()
	resp := s.get(t, "/v0/beads/issues/"+id)
	if resp.status != http.StatusOK {
		t.Fatalf("get issue %s: status = %d, want 200: %s", id, resp.status, resp.body)
	}
	var fields map[string]json.RawMessage
	if err := json.Unmarshal([]byte(resp.body), &fields); err != nil {
		t.Fatalf("get issue %s: response is not a JSON object: %v", id, err)
	}
	raw, ok := fields["revision"]
	if !ok {
		t.Fatalf("get issue %s: no `revision` member: %s", id, resp.body)
	}
	var token string
	if err := json.Unmarshal(raw, &token); err != nil {
		t.Fatalf("get issue %s: `revision` %s is not a JSON string: %v", id, raw, err)
	}
	return token
}

type httpResult struct {
	status int
	body   string
}

func (r httpResult) object(t *testing.T) map[string]any {
	t.Helper()
	var obj map[string]any
	if err := json.Unmarshal([]byte(r.body), &obj); err != nil {
		t.Fatalf("response is not a JSON object: %v (%s)", err, r.body)
	}
	return obj
}

func (s *embeddedHTTPServer) do(t *testing.T, method, path, body string) httpResult {
	t.Helper()
	var reader io.Reader
	if body != "" {
		reader = bytes.NewReader([]byte(body))
	}
	req, err := http.NewRequest(method, s.baseURL+path, reader)
	if err != nil {
		t.Fatalf("new request %s %s: %v", method, path, err)
	}
	if body != "" {
		req.Header.Set("Content-Type", "application/json")
	}
	resp, err := s.client.Do(req)
	if err != nil {
		t.Fatalf("%s %s: %v", method, path, err)
	}
	defer func() { _ = resp.Body.Close() }()
	raw, err := io.ReadAll(resp.Body)
	if err != nil {
		t.Fatalf("%s %s: read body: %v", method, path, err)
	}
	return httpResult{status: resp.StatusCode, body: string(raw)}
}

func (s *embeddedHTTPServer) post(t *testing.T, path, body string) httpResult {
	return s.do(t, http.MethodPost, path, body)
}

func (s *embeddedHTTPServer) patch(t *testing.T, path, body string) httpResult {
	return s.do(t, http.MethodPatch, path, body)
}

func (s *embeddedHTTPServer) get(t *testing.T, path string) httpResult {
	return s.do(t, http.MethodGet, path, "")
}
