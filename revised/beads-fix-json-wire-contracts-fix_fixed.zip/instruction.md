## Task

We're close to cutting 1.3.0, and that release locks in the JSON shapes clients get back from bd.
A check against what 1.2.2 returned turned up three places that no longer match, and a couple of integrations already trip over them.
I'd like all three sorted before the release goes out.

Metadata first.
In 1.2.2, `bd update <id> --set-metadata score=5` stored a real number, so reading the issue back gave `"score": 5`, and `true`, `false` and `null` kept their types too.
Now every value comes back quoted, like `"score": "5"`, and clients that read a typed score or flag break on it.
A value should keep its JSON type only when it's written exactly the way JSON writes it, so `5`, `-2`, `0`, `0.50`, `1e3`, `true`, `false` and `null` come back typed.
Everything else stays a string, including look-alikes such as `05`, `+5`, `NaN` and `1.2.3`, an empty value, and plain text.
Setting new keys shouldn't change keys the issue already has.

Second, timestamps on create.
If a caller creates an issue and passes its own `created_at` and `updated_at`, the issue handed back has both rounded to the whole second.
That happens for a single create and for every issue in a batch create.
Over the HTTP API it's the same story, since a freshly created issue never shows a fraction of a second.
Both timestamps on the returned issue should match what the caller passed, down to the nanosecond.
When the caller passes nothing and bd picks the time itself, the returned issue should carry that exact time, fraction included.
That way issues made in the same second still sort in order.
Please don't change the database schema or add a migration for this one.

Third, the revision token for guarded writes.
Some clients get version-conflict errors on issues nobody else has touched.
The token is a 64-bit integer that we send as a JSON number, and clients that parse numbers as float64 round anything past 2^53, so they echo back a guard that no longer matches.
In 1.3.0 the token should be a JSON string holding its decimal digits everywhere it shows up in the API:

- `revision` on the issue detail view
- `revision` on the update, close, release, reopen and batch-apply responses
- `expected_version` on every request that sends a guard
- `expected_version` and `actual_version` in the error body of a version conflict

A string guard that matches the current revision should go through as before.
A guard sent as a bare JSON number should get a 400, and the error should name `expected_version`, so a client still sending numbers finds out on its first write.
The published OpenAPI document should list all of these members as strings, and the Go types generated from it have to match it.
Go code that reads an issue's row version directly shouldn't see any change.

Existing tests that pin the old shapes can be updated to match.
