## Task

Right now the CLI only mentions a newer release through the upgrade banner, and that banner only prints in an interactive terminal.
Scripts, piped runs and agents that call the CLI never see it, so they have no way to tell they're behind.
Please add an explicit status query that answers "is there a newer stable release, and which one?" in a form a script can parse.
The command or flag and the field names are your call.
This is an addition next to the banner, not a rework of it.

## User stories / requirements

- Running the status query prints a single JSON object on stdout and exits with code 0. The object always carries the installed version, matching what plain `version` prints, and an overall status, and a script can tell from it whether an update is available. Human-readable hints, if any, go to stderr.
- If the CLI knows about a stable release newer than the installed one, the output reports that an update is available and includes that release's version.
- If the release list has a pre-release that sorts above every stable release, the output still points at the newest stable release as the update. A pre-release is never offered as the version to upgrade to.
- If the lookup fails and there is no cached stable release to fall back on (no cache, or only an unusable value), the status says it is unknown and gives no latest version. That status must differ from the update-available one and from the one shown after a successful lookup that finds nothing newer.
- If an earlier successful lookup already found a newer stable release, the output still reports that update, with its version, even when the current lookup attempt fails.
- The existing upgrade banner works as before. When a stable release newer than the installed one is cached, running plain `version` in an interactive terminal still shows the banner with that release's version, and the banner stays hidden when nothing newer is cached or when the output is piped.
