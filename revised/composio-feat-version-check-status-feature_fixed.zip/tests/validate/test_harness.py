"""Test harness for composio-feat-version-check-status validation.

Exposes two things the stories need and nothing implementation-specific:

  1. ``run_cli(argv, cache=..., serve_latest=...)`` - run the CLI from source
     with a private ``$HOME`` (so a seeded ``~/.composio/update-check.json``
     cache is the only one it sees), optionally with a mock-success release
     lookup served at the pre-existing releases host.
  2. ``mock_releases_up(latest_stable)`` - a context manager that stands up a
     local HTTPS endpoint at the pre-existing releases host
     (``api.github.com``, which ``validation-setup.sh`` has pinned to
     loopback) returning a single stable release whose version is
     ``latest_stable``. While it is up, ANY design's release lookup SUCCEEDS;
     while it is down, every lookup FAILS (connection refused).

Nothing here imports a task-introduced symbol. The CLI is driven only as a
subprocess over its public argv surface, the release payload uses only the
pre-existing GitHub releases JSON shape (``tag_name`` / ``prerelease`` /
``draft`` / ``assets[].name``) that the pre-existing
``parseLatestVersionFromReleases`` already consumes, and the cache file shape
(``{lastChecked, latestVersion}``) is the pre-existing on-disk convention.

Why a mock-success endpoint (and not just a seeded cache) is needed to capture
a design-agnostic "up to date" reference:

  Offline, the two valid designs DIVERGE on a non-newer cached release - a
  throttle-respecting design trusts the fresh cache and reports "up to date",
  while a force-refresh design re-attempts the (failing) live lookup and
  reports "unknown". So NO seeded cache yields "up to date" for every design.
  A genuine successful lookup of a non-newer stable release, by contrast,
  makes BOTH design families report "up to date" - it is the only
  design-agnostic way to observe the "up to date" state, and it drives only
  pre-existing surfaces (the releases host + payload shape).
"""

from __future__ import annotations

import contextlib
import http.server
import json
import os
import ssl
import subprocess
import tempfile
import threading
import time
from collections.abc import Iterator, Sequence

# The CLI runs from source here.
REPO = "/repo/composio"

# The pre-existing releases host (api.github.com) is pinned to loopback by
# validation-setup.sh, so binding :443 locally intercepts every live lookup.
_MOCK_HOST = "127.0.0.1"
_MOCK_PORT = 443

# Self-signed cert for api.github.com, generated once by validation-setup.sh
# (or lazily here as a fallback). Trusted by the CLI's runtime via
# NODE_EXTRA_CA_CERTS so a successful TLS fetch is possible without disabling
# certificate verification.
_CERT = "/tmp/gh-releases-mock/cert.pem"
_KEY = "/tmp/gh-releases-mock/key.pem"

# The platform binary asset names the release fetch looks for. Providing all
# four (linux/darwin x x64/aarch64) keeps the mock payload valid on any Modal
# host architecture without the harness having to detect the current platform.
_ASSET_NAMES = (
    "composio-linux-x64.zip",
    "composio-linux-aarch64.zip",
    "composio-darwin-x64.zip",
    "composio-darwin-aarch64.zip",
)


def _ensure_cert() -> None:
    """Make sure the self-signed cert/key for api.github.com exist.

    validation-setup.sh normally creates these; regenerate here if missing so
    the harness is self-contained when run directly.
    """
    if os.path.exists(_CERT) and os.path.exists(_KEY):
        return
    os.makedirs(os.path.dirname(_CERT), exist_ok=True)
    subprocess.run(
        [
            "openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes",
            "-keyout", _KEY, "-out", _CERT, "-days", "2",
            "-subj", "/CN=api.github.com",
            "-addext", "subjectAltName=DNS:api.github.com",
        ],
        check=True,
        capture_output=True,
        text=True,
    )


def release_entry(version: str, *, prerelease: bool = False, draft: bool = False) -> dict:
    """Build one GitHub-releases JSON entry for ``@composio/cli@<version>``.

    Uses only the pre-existing releases payload shape (``tag_name`` /
    ``prerelease`` / ``draft`` / ``assets[].name``) the pre-existing
    ``parseLatestVersionFromReleases`` already consumes. Carries the platform
    binary asset for every host arch so the entry is considered on any Modal box.
    """
    return {
        "tag_name": f"@composio/cli@{version}",
        "prerelease": prerelease,
        "draft": draft,
        "assets": [{"name": name} for name in _ASSET_NAMES],
    }


@contextlib.contextmanager
def mock_releases_feed(releases: Sequence[dict]) -> Iterator[None]:
    """Serve an arbitrary mock-success release feed for the ``with`` block.

    ``releases`` is a list of entries from ``release_entry(...)``. While active,
    any implementation's live release lookup succeeds and sees exactly this feed.
    Use this to observe how the latest-stable selection treats a feed that mixes
    stable and pre-release entries.
    """
    _ensure_cert()
    body = json.dumps(list(releases)).encode()

    class _Handler(http.server.BaseHTTPRequestHandler):
        def do_GET(self) -> None:  # noqa: N802 - http.server API
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *args: object) -> None:  # silence access log
            return

    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(_CERT, _KEY)
    httpd = http.server.HTTPServer((_MOCK_HOST, _MOCK_PORT), _Handler)
    httpd.socket = ctx.wrap_socket(httpd.socket, server_side=True)
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    try:
        yield
    finally:
        httpd.shutdown()
        httpd.server_close()
        # Give the OS a beat to release :443 before the next scenario binds it.
        time.sleep(0.2)


@contextlib.contextmanager
def mock_releases_up(latest_stable: str) -> Iterator[None]:
    """Serve a mock-success release lookup naming ``latest_stable`` as the only
    stable release, for the duration of the ``with`` block.

    While active, any implementation's live release lookup succeeds and sees a
    single stable release ``@composio/cli@<latest_stable>`` carrying the
    platform binary asset. Use a NON-newer ``latest_stable`` (e.g. the installed
    version) to observe the design-agnostic "up to date" state.
    """
    _ensure_cert()
    releases = [
        {
            "tag_name": f"@composio/cli@{latest_stable}",
            "prerelease": False,
            "draft": False,
            "assets": [{"name": name} for name in _ASSET_NAMES],
        }
    ]
    body = json.dumps(releases).encode()

    class _Handler(http.server.BaseHTTPRequestHandler):
        def do_GET(self) -> None:  # noqa: N802 - http.server API
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *args: object) -> None:  # silence access log
            return

    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(_CERT, _KEY)
    httpd = http.server.HTTPServer((_MOCK_HOST, _MOCK_PORT), _Handler)
    httpd.socket = ctx.wrap_socket(httpd.socket, server_side=True)
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    try:
        yield
    finally:
        httpd.shutdown()
        httpd.server_close()
        # Give the OS a beat to release :443 before the next scenario binds it.
        time.sleep(0.2)


def run_cli(
    argv: Sequence[str],
    *,
    cache: dict | None = None,
    serve_latest: str | None = None,
    serve_feed: Sequence[dict] | None = None,
    timeout: int = 180,
) -> subprocess.CompletedProcess:
    """Run ``pnpm --filter @composio/cli cli -- <argv>`` in a private $HOME.

    - ``cache`` - when provided, written to ``$HOME/.composio/update-check.json``
      before the run; when None, no cache file exists.
    - ``serve_latest`` - when provided, a mock-success release lookup naming
      this single stable version is served for the run (the live lookup
      SUCCEEDS).
    - ``serve_feed`` - when provided, a mock-success lookup returning this exact
      feed (list of ``release_entry(...)`` dicts) is served for the run. Use for
      mixed stable/pre-release feeds. Mutually exclusive with ``serve_latest``.
    - when neither ``serve_*`` is given, no server runs, so any live lookup FAILS
      (connection refused on the loopback-pinned host).
    """
    if serve_latest is not None and serve_feed is not None:
        raise ValueError("pass at most one of serve_latest / serve_feed")

    home = tempfile.mkdtemp()
    if cache is not None:
        os.makedirs(os.path.join(home, ".composio"), exist_ok=True)
        with open(os.path.join(home, ".composio", "update-check.json"), "w") as fh:
            json.dump(cache, fh)
    env = {**os.environ, "HOME": home, "NODE_EXTRA_CA_CERTS": _CERT}
    cmd = ["pnpm", "--filter", "@composio/cli", "cli", "--", *argv]

    def _run() -> subprocess.CompletedProcess:
        return subprocess.run(
            cmd, cwd=REPO, capture_output=True, text=True,
            timeout=timeout, env=env, check=False,
        )

    if serve_feed is not None:
        with mock_releases_feed(serve_feed):
            return _run()
    if serve_latest is not None:
        with mock_releases_up(serve_latest):
            return _run()
    return _run()


def installed_version() -> str:
    """Return the installed CLI version string (what plain ``version`` prints)."""
    result = run_cli(["version"])
    return result.stdout.strip().splitlines()[-1].strip()
