#!/usr/bin/env bash
# Validation setup: runs after the implementation change is applied, before the stories.
# Three jobs:
#   1. Make sure the monorepo's dependencies are present (offline no-op on the
#      warm image store) so the CLI runs from source.
#   2. Make the public releases host unreachable, so any on-demand release
#      lookup fails deterministically while the stories run. The stories that exercise
#      the degraded path depend on this; the stories that seed a fresh cache
#      never reach the network at all.
#   3. Boot-probe the CLI so a broken build surfaces here with a clear message
#      instead of as an opaque failure inside every story.
# Idempotent: re-running is safe.
set -euo pipefail

REPO=/repo/composio
CLI_PKG="@composio/cli"

cd "$REPO"

echo "validation-setup: node=$(node --version 2>&1 | head -1)"
echo "validation-setup: pnpm=$(pnpm --version 2>&1 | head -1)"
echo "validation-setup: bun=$(bun --version 2>&1 | head -1)"

# Step 1: dependencies present (offline; warm store makes this a no-op).
echo "validation-setup: ensuring dependencies (offline)..."
export npm_config_offline=true
export COMPOSIO_DISABLE_TELEMETRY=1
export DO_NOT_TRACK=1
if ! pnpm install --frozen-lockfile --offline --store-dir /root/.pnpm-store > /tmp/vsetup-install.log 2>&1; then
    echo "validation-setup: offline install reported issues (continuing; deps are baked):"
    tail -20 /tmp/vsetup-install.log || true
fi

# Step 2: neutralize the releases host so a live lookup fails fast and
# identically regardless of how the implementation performs it. Pointing the
# host at the loopback address makes the HTTPS connection refuse immediately.
# The host is a pre-existing constant of the update pipeline, not a solution
# choice.
RELEASE_HOST="api.github.com"
if ! grep -qE "^[0-9.]+[[:space:]]+${RELEASE_HOST}\$" /etc/hosts 2>/dev/null; then
    if printf '127.0.0.1 %s\n::1 %s\n' "$RELEASE_HOST" "$RELEASE_HOST" >> /etc/hosts 2>/dev/null; then
        echo "validation-setup: pinned ${RELEASE_HOST} to loopback (lookups will fail)"
    else
        echo "validation-setup: WARNING could not edit /etc/hosts to block ${RELEASE_HOST}" >&2
        echo "validation-setup: degraded-path stories may be non-deterministic" >&2
    fi
else
    echo "validation-setup: ${RELEASE_HOST} already pinned to loopback"
fi

# Step 2b: a self-signed cert for the releases host so a story can stand up a
# MOCK-SUCCESS release lookup (served on loopback :443, trusted via
# NODE_EXTRA_CA_CERTS) and observe the design-agnostic "up to date" state.
# Offline, no seeded cache yields "up to date" for every valid design - a
# throttle-respecting design trusts a non-newer cache ("up to date") while a
# force-refresh design re-attempts the failing lookup ("unknown"). Only a
# genuine successful lookup of a non-newer stable makes BOTH report "up to
# date", so the honest-degradation story needs this reference. The cert names
# only the pre-existing releases host; it grants no newer release and changes
# no behavior on its own - a scenario is "up" only while test_harness.py is
# actively serving.
MOCK_CERT_DIR=/tmp/gh-releases-mock
MOCK_CERT="${MOCK_CERT_DIR}/cert.pem"
MOCK_KEY="${MOCK_CERT_DIR}/key.pem"
if [ ! -s "$MOCK_CERT" ] || [ ! -s "$MOCK_KEY" ]; then
    mkdir -p "$MOCK_CERT_DIR"
    if openssl req -x509 -newkey rsa:2048 -nodes \
            -keyout "$MOCK_KEY" -out "$MOCK_CERT" -days 2 \
            -subj "/CN=${RELEASE_HOST}" \
            -addext "subjectAltName=DNS:${RELEASE_HOST}" >/tmp/vsetup-cert.log 2>&1; then
        chmod 0644 "$MOCK_CERT" "$MOCK_KEY"
        echo "validation-setup: mock releases cert ready at ${MOCK_CERT}"
    else
        echo "validation-setup: WARNING could not generate mock releases cert" >&2
        tail -20 /tmp/vsetup-cert.log >&2 || true
    fi
else
    echo "validation-setup: mock releases cert already present"
fi

# Step 3: boot-probe. The plain version command must print a non-empty version
# string; if the CLI cannot even start, every story would fail with the same
# opaque error, so surface it here instead.
echo "validation-setup: probing CLI boot (plain version)..."
PROBE_HOME="$(mktemp -d)"
if ! PROBE_OUT="$(HOME="$PROBE_HOME" pnpm --filter "$CLI_PKG" cli -- version 2>/tmp/vsetup-probe.err)"; then
    echo "ERROR: CLI failed to run 'version' from source. stderr tail:" >&2
    tail -40 /tmp/vsetup-probe.err >&2 || true
    exit 1
fi
PROBE_VERSION="$(printf '%s' "$PROBE_OUT" | tail -1 | tr -d '[:space:]')"
if [ -z "$PROBE_VERSION" ]; then
    echo "ERROR: 'version' produced no version string on stdout." >&2
    exit 1
fi
echo "validation-setup: CLI boots; installed version string = '${PROBE_VERSION}'"

echo "validation-setup: done. Stories may now run the CLI through 'pnpm --filter ${CLI_PKG} cli -- <args>'."
