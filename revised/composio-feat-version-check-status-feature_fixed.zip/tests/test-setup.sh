#!/usr/bin/env bash
# Prepare the Composio CLI package so it runs from source and the behavioral
# stories can drive the CLI.
#
# This script is `source`d by the runner, so traps and background PIDs would
# persist into the verifier process; none are added here.
#
# The image already baked the full dependency closure at the base commit
# (pnpm store + node_modules warm). The run is offline, so everything below is
# offline-first; the install is a no-op on the hot store.
set -euo pipefail

cd /repo/composio

# Make a cache miss fail fast instead of retrying against the (absent) network.
export npm_config_offline=true
export CI=1

# Re-link in case the user changes touched a manifest or added a workspace module.
# No-op on the warm store; offline so it never reaches the network.
pnpm install --frozen-lockfile --offline --ignore-scripts --store-dir /root/.pnpm-store >/tmp/setup-install.log 2>&1 || true

# Toolchain sanity - all three runtimes the CLI/tests need must be present.
node --version
bun --version
pnpm --version

# Smoke-check that the CLI boots from source and prints a version string.
pnpm --filter @composio/cli cli -- version >/tmp/cli-version.log 2>&1 \
    || { echo "CLI failed to boot from source:"; tail -40 /tmp/cli-version.log; exit 1; }

cd /repo/composio
