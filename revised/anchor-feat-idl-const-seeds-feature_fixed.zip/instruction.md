## Task

PDA seeds that come from a named constant get lost in the IDL that Anchor v2's `#[derive(Accounts)]` generates.
Say an account has `seeds = [MY_SEED]` where `MY_SEED` is a `const` byte value.
The IDL lists that seed as a const seed with an empty `value` array, so a client reading the IDL can't derive the address.
Program markers have the same problem: a marker type a program defines for itself comes out empty, and only the few markers that ship with the framework get their real id.
Please make these seeds show their actual bytes in the IDL, whatever byte-like type the constant has.
Any seed that already comes out right today has to produce exactly the same IDL as before.

## User stories / requirements

- A PDA seed that uses a constant byte value appears in the generated IDL as a const seed holding that constant's real bytes, not an empty array. This covers byte slices, byte arrays, strings and addresses, a constant named through a module path, and a constant whose value is computed rather than written out.
- When a program defines its own marker type, the IDL carries that marker's real 32-byte program id, both when it is the `seeds::program = Marker::id()` override and when `Marker::id()` sits in the seed list itself.
