#!/usr/bin/env bash
#
# Build check for anchor-feat-idl-const-seeds.
#
# The IDL code that `#[derive(Accounts)]` generates is only compiled under
# `--features idl-build`, so a mismatch between the derive crate and the
# lang crate it expands against shows up only in a feature-enabled build.
#
# This script confirms both halves build:
#   * the accounts derive proc-macro crate compiles on its own, and
#   * the `constraints` fixture crate compiles with `--features idl-build`,
#     which expands every `__idl_accounts()` body in a real program.
#
# The image pre-builds both targets, so a warm run is under 30 seconds.
# The runner cwd is {repo_dir} (/repo/anchor), which is the cargo
# workspace root.
#
# Exit codes:
#   0 - both build cleanly
#   non-zero - propagates the cargo failure

set -euo pipefail

cd /repo/anchor

# 1. The derive proc-macro crate builds in isolation.
cargo build -p anchor-derive-accounts-v2

# 2. An idl-build-enabled fixture compiles, which expands the generated
#    IDL code for every Accounts struct in the crate.
cargo build -p constraints --features idl-build
