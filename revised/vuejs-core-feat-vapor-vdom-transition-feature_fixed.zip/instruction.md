## Task

We mix vapor and vdom components in one app, and transitions break where the two meet.
We hit it in two setups.
In one, a vapor component passes slot content to a vdom component whose template wraps its `<slot/>` in a `<Transition>`.
There the passed content never animates: it just pops in or out, and none of its JS hooks (`@before-leave`, `@leave`, `@after-enter` and the rest) get called.
In the other, a vapor component sits directly inside a vdom `<Transition>`.
There it only half works: the element the component rendered first can play its leave, but an element it renders later, such as its root coming back, just appears with no enter.
In both setups, with `mode="out-in"`, switching away from vapor content that is hidden at that moment never shows the next content at all.

Please make the vdom `<Transition>` animate this vapor content in both setups.
In each case below, its hooks should fire in the same order, and at the same points, as they do when the same `<Transition>` wraps plain vdom elements.
Nothing else should change in either runtime: what already works today, with or without the interop layer, should keep working as it does now.

## User stories / requirements

- In the slot setup, hiding the passed content plays its leave and keeps it on the page until the leave ends. Showing it again plays its enter, and with `appear` the first render plays the appear hooks. When content and the slot's fallback replace each other without a mode, one enters while the other leaves.
- With `mode="out-in"`, swapping the passed content waits for the old content to finish leaving and be removed before the new content starts its enter. That goes for `v-if`/`v-else` branches and for a single `<component :is>` element whose tag changes.
- With `mode="in-out"`, new passed content enters first and the old starts leaving only after that enter is done, for `v-if`/`v-else` branches and a `<component :is>` tag change. Switching from the slot to a sibling and back before that keeps one copy of the slot content and removes the copy waiting to leave.
- A vapor component placed directly inside the vdom `<Transition>` animates when a `v-if` on it shows and hides it and when it toggles its own root. Under `out-in` or `in-out`, swapping it with a sibling follows the mode, and swapping its root for another element ends the old root's leave as the new root enters.
- A vapor component whose root starts hidden mounts with no hooks and enters once the root shows up. Under `out-in`, a hidden vapor child, whether a component swapped by `v-if` or a slot, plays no hooks: switching to it runs only the old content's leave, and switching away enters the next content right away.
- A `<Transition>` compiled in vapor mode around vapor content keeps working as it does now: enter and leave hooks fire, leaving content stays until its leave is done, and `out-in` still finishes the leave before the next content enters.
