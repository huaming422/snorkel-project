## Task

We mix vapor and vdom components in one app, and transitions stop working where the two meet.
When a vdom `<Transition>` has vapor-rendered content as its child, nothing animates.
The content just pops in or out, and none of the JS hooks (`@before-leave`, `@leave`, `@after-enter` and the rest) get called.
We hit it in two setups.
In one, a vapor component passes slot content to a vdom component whose template wraps its `<slot/>` in a `<Transition>`.
In the other, a vapor component sits directly inside a vdom `<Transition>`.

Please make the vdom `<Transition>` animate that content the way it already animates vdom content.
The hooks should fire in the same order, and at the same points, as they do when the same `<Transition>` wraps plain vdom elements.

## User stories / requirements

- In the slot setup, hiding the passed content plays its leave and keeps it on the page until the leave is done. Showing it again plays its enter, and with `appear` the first render plays the appear hooks. When the slot falls back to its own content, that fallback enters while the old content leaves.
- With `mode="out-in"`, swapping the slot content waits for the old content to finish leaving and be removed before the new content starts its enter. That goes for `v-if`/`v-else` branches and for a single `<component :is>` element whose tag changes.
- With `mode="in-out"`, the new slot content enters first and the old content starts leaving only after that enter is done. If the `<Transition>` switches from the slot to a sibling element and back before that, one copy of the slot content stays on the page and the copy waiting to leave is removed.
- A vapor component placed directly inside the vdom `<Transition>` animates too, both when a `v-if` on the component shows and hides it and when the component shows and hides its own root element while it stays mounted.
- A vapor component whose root starts hidden mounts with no hooks and enters once the root shows up. With `out-in`, switching to a slot whose vapor content is hidden runs only the old content's leave, and switching away again enters the next content right away.
- A `<Transition>` compiled in vapor mode around vapor content keeps working as it does now: enter and leave hooks fire, leaving content stays until its leave is done, and `out-in` still finishes the leave before the next content enters.
