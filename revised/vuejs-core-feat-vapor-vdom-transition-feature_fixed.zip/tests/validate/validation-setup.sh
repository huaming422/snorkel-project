#!/usr/bin/env bash
# Environment bootstrap for the story scripts.
#
# All dependencies (Node toolchain, pnpm with a warm store, the
# frozen-lockfile workspace install, the jsdom test environment, and the
# prebuilt dev bundle) are baked into the image, so this is normally a fast
# no-op. It restores node_modules if earlier changes erased it, and
# smoke-checks that the vitest jsdom project loads and that the shared
# cross-runtime test helper is importable before any story is written.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/${REPO_NAME:-vuejs-core}}"
cd "$REPO_DIR"

# Sanity: Node + pnpm are reachable at their pinned versions.
node --version
pnpm --version

# Restore deps if a previous phase wiped them (offline replay against the
# pre-fetched pnpm store baked into the image).
if [ ! -d "node_modules/.pnpm" ]; then
    echo "[validation-setup] node_modules missing, restoring from frozen lockfile..."
    pnpm install --frozen-lockfile --offline
fi

# Smoke: the test runner is reachable.
pnpm exec vitest --version

# Smoke-run a tiny spec through the SAME project + path layout the driver uses:
# a file under packages/runtime-vapor/__tests__/__validation__/ run by the
# unit-jsdom project. This confirms the jsdom environment, the project include
# glob, the setup file, and the pre-existing shared helper import (../_utils)
# all resolve before the stories are written. It mounts vapor slot content
# inside a vdom Transition and toggles it, and only checks that mounting and
# toggling run without throwing.
SMOKE_DIR="$REPO_DIR/packages/runtime-vapor/__tests__/__validation__"
mkdir -p "$SMOKE_DIR"
cat > "$SMOKE_DIR/__setup_smoke__.spec.ts" <<'TS'
// @ts-nocheck
import { nextTick, ref } from '@vue/runtime-dom'
import { compile, makeInteropRender } from '../_utils'

const define = makeInteropRender()

const sfc = (vapor, data, template, components = {}) =>
  compile(
    `<script setup${vapor ? ' vapor' : ''}>` +
      `const data = _data; const components = _components</script>` +
      `<template>${template}</template>`,
    data,
    components,
    { vapor },
  )

describe('__setup_smoke__', () => {
  it('mounts a vapor slot inside a vdom Transition', async () => {
    const log = []
    const data = ref({
      show: true,
      onBeforeLeave: el => log.push(`beforeLeave:${el.textContent}`),
      onLeave: () => {},
    })
    const makeApp = d =>
      sfc(true, d, `<components.Wrapper><div v-if="data.show">x</div></components.Wrapper>`, {
        Wrapper: sfc(
          false,
          d,
          `<Transition :css="false" @before-leave="data.onBeforeLeave" @leave="data.onLeave"><slot/></Transition>`,
        ),
      })
    const { host, html } = define(makeApp(data)).render()
    document.body.appendChild(host)
    await nextTick()
    expect(html().replace(/<!--[^]*?-->/g, '')).toContain('x')
    data.value.show = false
    await nextTick()
    // whether or not the cross-runtime animation is wired up, mounting and
    // toggling must not throw and the helper import must resolve.
    expect(Array.isArray(log)).toBe(true)
    host.remove()
  })
})
TS

cleanup() { rm -f "$SMOKE_DIR/__setup_smoke__.spec.ts"; rmdir "$SMOKE_DIR" 2>/dev/null || true; }
trap cleanup EXIT

if pnpm exec vitest run --project unit-jsdom --reporter=verbose \
      packages/runtime-vapor/__tests__/__validation__/__setup_smoke__.spec.ts 2>&1 \
      | tee /tmp/validation_setup_smoke.log | tail -20 | grep -Eq "1 passed|Tests  1 passed"; then
    echo "[validation-setup] smoke test passed"
else
    echo "[validation-setup] ERROR: smoke test did not pass: the jsdom project or the shared helper import is broken; validation stories will fail." >&2
    tail -60 /tmp/validation_setup_smoke.log >&2 || true
    exit 1
fi
