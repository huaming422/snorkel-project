#!/usr/bin/env bash
# All dependencies are baked into the image: the Node toolchain, pnpm with a
# warm store (/opt/cache/pnpm), the full workspace
# `pnpm install --frozen-lockfile`, the puppeteer/playwright browsers, and
# the prebuilt global dev bundle. Nothing to do at verifier time.
set -euo pipefail
echo "[test-setup] no-op for vuejs-core-feat-vapor-vdom-transition"
