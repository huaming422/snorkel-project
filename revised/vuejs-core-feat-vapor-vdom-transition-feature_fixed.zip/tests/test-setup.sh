#!/usr/bin/env bash
# All dependencies are baked into the image: the Node toolchain, pnpm with a
# warm store (/opt/cache/pnpm), the full workspace
# `pnpm install --frozen-lockfile`, the puppeteer/playwright browsers, and
# the prebuilt global dev bundle.
#
# The suites that tests/verify imports, and the shared helpers they use, are
# put back to their text at the pinned revision, so those checks run the
# repo's own tests even when the implementation change edited them.
set -euo pipefail

REPO_DIR="/repo/${REPO_NAME:-vuejs-core}"
BASE_REF_FILE=/var/lib/devcontainer_base_ref
RESTORED_SUITES=(
    packages/runtime-vapor/__tests__/components/Transition.spec.ts
    packages/runtime-vapor/__tests__/components/TransitionGroup.spec.ts
    packages/runtime-vapor/__tests__/components/KeepAlive.spec.ts
    packages/runtime-vapor/__tests__/vdomInterop.spec.ts
    packages/runtime-vapor/__tests__/vdomInteropSlotOutlet.spec.ts
    packages/runtime-vapor/__tests__/hydration/transition.spec.ts
    packages/runtime-vapor/__tests__/hydration/interopSlots.spec.ts
    packages/runtime-vapor/__tests__/hydration/_helpers.ts
    packages/runtime-vapor/__tests__/_utils.ts
    packages/runtime-core/__tests__/components/BaseTransition.spec.ts
    packages/runtime-core/__tests__/components/KeepAlive.spec.ts
)
if [ -f "$BASE_REF_FILE" ]; then
    git -C "$REPO_DIR" checkout "$(tr -d '[:space:]' < "$BASE_REF_FILE")" -- "${RESTORED_SUITES[@]}"
    echo "[test-setup] restored ${#RESTORED_SUITES[@]} suite files"
else
    echo "[test-setup] no base ref recorded, suite files left as they are" >&2
fi
