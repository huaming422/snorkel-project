// @vitest-environment jsdom
// The repo's interop slot hydration suite, run as it is at the pinned revision
// (the setup script restores it). Every test in it must keep passing.
import '../../../runtime-vapor/__tests__/hydration/interopSlots.spec'
