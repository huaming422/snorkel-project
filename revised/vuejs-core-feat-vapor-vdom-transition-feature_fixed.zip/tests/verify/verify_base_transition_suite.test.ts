// The repo's BaseTransition suite on the runtime-test renderer, run as it is at
// the pinned revision (the setup script restores it). Every test in it must
// keep passing.
import '../components/BaseTransition.spec'
