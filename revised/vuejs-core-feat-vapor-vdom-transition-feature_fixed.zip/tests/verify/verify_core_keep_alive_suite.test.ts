// The repo's vdom `<KeepAlive>` suite on the runtime-test renderer, run as it
// is at the pinned revision (the setup script restores it). Every test in it
// must keep passing.
import '../components/KeepAlive.spec'
