## Task

open-science is an Electron desktop app, and its notebooks run user code in long-lived interpreter subprocesses we call kernels.
With the protected network sandbox turned on, every kernel is started inside a process sandbox.

People keep telling us their notebook kernel dies right after it starts, and all they get is this one line:

```
Notebook kernel process exited.
```

It doesn't give the exit code or show anything the interpreter printed before it died.
When the sandbox blocked something on the way down, the error doesn't mention that either.
We need that error to be enough to tell a crash from a missing interpreter from the sandbox stopping it.

Kernels still have to stay sandboxed for as long as they run, and the sandbox cleanup we already do on restarts, shutdowns, interpreter switches, idle reclaim, timeout kills and failed starts has to keep working.
