## Task

open-science is an Electron desktop app, and its notebooks run user code in long-lived interpreter subprocesses we call kernels.
With the protected network sandbox turned on, every kernel is started inside a process sandbox.

People keep telling us their notebook kernel dies right after it starts.
It happens most with the sandbox on and the notebook's working folder on a drive that isn't the system drive.
All they get is this one line:

```
Notebook kernel process exited.
```

There's no exit code and nothing the interpreter printed to stderr, so we can't tell a crash from a missing interpreter from the sandbox blocking it.

We'll chase the drive problem on its own later.
What we need first is a failure we can read.
When a kernel dies before it answers, the error for that run should include the exit code and what the interpreter wrote to stderr, not just that line.
If the sandbox blocked something for that kernel, the error should say so too, the same way a finished cell's output already does.
The kernel's sandbox still has to be released once the kernel is gone.

Everything else should behave as it does today.
Normal cells report the same as before, and a run that hits its timeout still comes back as a timeout, even if the kernel dies from the interrupt.
A dead kernel still settles its run as a failure right away, even when a process it started is still running and holding its output open.
