## Task

open-science is an Electron desktop app, and its notebooks run user code in long-lived interpreter subprocesses we call kernels.
With the protected network sandbox turned on, every kernel is started inside a process sandbox.

People keep telling us their notebook kernel dies right after it starts, and all they get is this one line:

```
Notebook kernel process exited.
```

It doesn't give the exit code or show anything the interpreter printed before it died.
From that we can't tell a crash from a missing interpreter from the sandbox stopping it.
Can you make that failure tell us what happened?

Kernels have to stay sandboxed while they run, and the sandbox teardown we already do whenever a kernel goes away or fails to start has to keep working.
