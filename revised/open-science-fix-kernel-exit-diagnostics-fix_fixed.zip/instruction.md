## Task

open-science is an Electron desktop app, and its notebooks run user code in long-lived interpreter subprocesses we call kernels.
With the protected network sandbox turned on, every kernel is started inside a process sandbox.

People keep telling us their notebook kernel dies right after it starts, and all they get is this one line:

```
Notebook kernel process exited.
```

It doesn't give the exit code or show anything the interpreter printed before it died.
From that we can't tell a crash from a missing interpreter from the sandbox stopping it.
Can you make that failure tell us what happened?

Most of these reports come from Windows machines that have the protected (AppContainer) sandbox installed and keep the notebook folder on a drive other than the system drive, like D:\ or an external disk.
On one of them we got the process output, and before Python even starts, PowerShell gives up with:

```
Attempting to perform the InitializeDefaultDrives operation on the 'FileSystem' provider failed.
```

Please fix that too.
On protected Windows, Python kernels and the JavaScript control kernel have to start, still inside the sandbox, whatever drive their folder is on.
Each kernel's interpreter, the interpreter's own arguments, its loop script and its working folder have to reach it exactly as given, even with spaces, quotes, & or % in them.

Kernels have to stay sandboxed while they run, and the sandbox teardown we already do whenever a kernel goes away or fails to start has to keep working.
