## Task

open-science is an Electron desktop app, and its notebooks run user code in long-lived interpreter subprocesses we call kernels.
With the protected network sandbox turned on, every kernel is started inside a process sandbox.

People keep telling us their notebook kernel dies right after it starts, and all they get is this one line:

```
Notebook kernel process exited.
```

From that we can't tell a crash from a missing interpreter from the sandbox stopping it.
We'd want to see the exit code, whatever the interpreter wrote to stderr, and any sandbox violations in that error.

Today a kernel's sandbox gets released when the kernel is restarted or shut down, when a run switches it to a different interpreter, when it's reclaimed after sitting idle, and when it's killed because a run ignored the timeout interrupt.
An interpreter that fails to start gives its sandbox back too.
Keep all of that working, and don't release a sandbox while its kernel is still running.
