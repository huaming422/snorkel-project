## Task

open-science is an Electron desktop app, and its notebooks run user code in long-lived interpreter subprocesses we call kernels.
With the protected network sandbox turned on, every kernel is started inside a process sandbox.

People keep telling us their notebook kernel dies right after it starts.
It happens most with the sandbox on and the notebook's working folder on a drive that isn't the system drive.
All they get is this one line:

```
Notebook kernel process exited.
```

There's no exit code and nothing the interpreter printed to stderr, and when the sandbox blocked something, the error doesn't mention that either.
So we can't tell a crash from a missing interpreter from the sandbox stopping it.

When a kernel dies before it answers, the error for that run should carry its exit code, what the interpreter wrote to stderr, and anything the sandbox reported blocking.
Normal runs and timeouts should keep behaving exactly as they do today.
