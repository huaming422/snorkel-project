#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier (set -euo pipefail inherited).
# Brings the baked dependency closure online-first and sanity-checks the two
# things every verifier for this task needs: the vitest binary and a system
# python3 (the kernel-executor suite drives a real python3 interpreter).

REPO_DIR="${REPO_DIR:-/repo/open-science}"
export REPO_DIR
cd "$REPO_DIR"

# node_modules is baked at the base commit (npm ci in the image). Satisfy
# everything from that offline bake first; only reach the network if the tree
# is somehow incomplete. Check the exit status directly so the fallback
# actually fires (never pipe into `| tail`, which masks it).
if [ -x node_modules/.bin/vitest ]; then
    echo "[offline-first] node_modules satisfied from image bake"
else
    echo "[offline-first] vitest missing from node_modules; running npm ci" >&2
    npm ci
fi

# The kernel-executor driver tests resolve a system python3 and skip entirely
# if none is present. Fail loud here rather than silently skipping the richest
# behavioral checks. python3 is baked into the image (apt, block 5).
if ! command -v python3 >/dev/null 2>&1; then
    echo "test-setup.sh: python3 not found on PATH; kernel-executor tests cannot run" >&2
    exit 1
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR" \
     "vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)" \
     "python3=$(command -v python3)"
