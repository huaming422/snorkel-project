// @ts-nocheck
//
// Behavioral checks for notebook kernels that die before answering. Every case
// drives the public `NotebookKernelExecutor.execute()` end to end against a real
// system python3 and reads only the returned NotebookExecutionResult (status,
// stderr), how long it takes to settle, and the calls made on an injected
// process sandbox.

import { existsSync } from 'node:fs'
import { mkdtemp, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, describe, expect, it, vi } from 'vitest'

import { NotebookKernelExecutor } from './kernel-executor'
import type { NotebookProcessSandbox } from './process-sandbox'

const FIXTURE = join(__dirname, '../../../test/fixtures/fake_loop.py')

// First on-disk python3 wins; mirrors the repo's own driver-suite resolver.
const resolvePython3 = (): string | undefined =>
  [
    process.env.OPEN_SCIENCE_TEST_PY_ENV,
    '/opt/homebrew/bin/python3',
    '/usr/local/bin/python3',
    '/usr/bin/python3'
  ].find((candidate): candidate is string => typeof candidate === 'string' && existsSync(candidate))

const python3 = resolvePython3()
// The image bakes python3 and test-setup.sh fails loud when it is missing, so a
// skip here would hide an environment regression rather than a real pass.
const gate = python3 ? describe : describe.skip

const baseRequest = (
  cwd: string
): {
  cwd: string
  notebookSessionRoot: string
  inputRoot: string
  dataRoot: string
  runtimeRoot: string
} => ({
  cwd,
  notebookSessionRoot: join(cwd, 'nb'),
  inputRoot: join(cwd, 'inputs'),
  dataRoot: join(cwd, 'nb', 'data'),
  runtimeRoot: join(cwd, 'runtime')
})

let cwdDir: string | undefined

afterEach(async () => {
  if (cwdDir) {
    const { rm } = await import('node:fs/promises')
    await rm(cwdDir, { recursive: true, force: true })
    cwdDir = undefined
  }
})

gate('NotebookKernelExecutor startup-failure diagnostics', () => {
  it('surfaces the exit code and the interpreter stderr when a kernel exits before replying', async () => {
    cwdDir = await mkdtemp(join(tmpdir(), 'os-kernel-startup-exit-'))
    const crashingLoop = join(cwdDir, 'crashing_loop.py')
    await writeFile(
      crashingLoop,
      [
        'import sys',
        'sys.stderr.write("PowerShell FileSystem provider initialization failed.\\n")',
        'sys.stderr.flush()',
        'raise SystemExit(23)'
      ].join('\n')
    )
    const executor = new NotebookKernelExecutor({ pythonLoopPath: crashingLoop })

    try {
      const result = await executor.execute({
        ...baseRequest(cwdDir),
        code: 'import numpy',
        resolvedInterpreter: { command: python3 as string }
      })

      expect(result).toMatchObject({ status: 'failed' })
      // The run's stderr carries the exit code and the interpreter's own stderr
      // line. The wording around the code is not fixed ("exit code 23",
      // "exited with code 23" and "status 23" all match).
      expect(result.stderr).toMatch(/\b23\b/)
      expect(result.stderr).toContain('PowerShell FileSystem provider initialization failed.')
    } finally {
      await executor.shutdown()
    }
  })

  it('settles the run promptly when a dead kernel leaves a descendant holding its stdio pipes', async () => {
    cwdDir = await mkdtemp(join(tmpdir(), 'os-kernel-descendant-stdio-'))
    const releaseFile = join(cwdDir, 'release-descendant')
    const finishedFile = join(cwdDir, 'descendant-finished')
    // The descendant inherits the kernel's stdout/stderr and blocks until a
    // release file appears, holding those pipes open after the kernel is gone.
    const descendantCode = [
      'import os, time',
      `release_file = ${JSON.stringify(releaseFile)}`,
      `finished_file = ${JSON.stringify(finishedFile)}`,
      'while not os.path.exists(release_file): time.sleep(0.01)',
      `os.chdir(${JSON.stringify(tmpdir())})`,
      'with open(finished_file, "w", encoding="utf-8") as marker: marker.write("done")'
    ].join('\n')
    const crashingLoop = join(cwdDir, 'crashing_loop_with_descendant.py')
    await writeFile(
      crashingLoop,
      [
        'import subprocess, sys',
        `subprocess.Popen([sys.executable, "-c", ${JSON.stringify(descendantCode)}], stdout=sys.stdout, stderr=sys.stderr, close_fds=False)`,
        'raise SystemExit(24)'
      ].join('\n')
    )
    const executor = new NotebookKernelExecutor({ pythonLoopPath: crashingLoop })
    const execution = executor.execute({
      ...baseRequest(cwdDir),
      code: 'kernel exits',
      resolvedInterpreter: { command: python3 as string }
    })

    try {
      // The run has to settle well before the descendant is released.
      const settledBeforeDescendant = await Promise.race([
        execution.then(() => true),
        new Promise<false>((resolve) => setTimeout(() => resolve(false), 1_500))
      ])

      expect(settledBeforeDescendant).toBe(true)
      await expect(execution).resolves.toMatchObject({ status: 'failed' })
    } finally {
      await writeFile(releaseFile, 'release')
      await execution
      await executor.shutdown()
      for (let attempt = 0; attempt < 200 && !existsSync(finishedFile); attempt += 1) {
        await new Promise((resolve) => setTimeout(resolve, 10))
      }
    }
  })

  it('keeps the sandbox violation note in a sandboxed kernel crash error', async () => {
    cwdDir = await mkdtemp(join(tmpdir(), 'os-kernel-startup-sandbox-exit-'))
    const crashingLoop = join(cwdDir, 'crashing_sandbox_loop.py')
    await writeFile(
      crashingLoop,
      [
        'import sys',
        'sys.stderr.write("Permission denied: C:/hidden/credentials.txt\\n")',
        'sys.stderr.flush()',
        'raise SystemExit(25)'
      ].join('\n')
    )
    // Like the real sandbox, this one keeps its violation records only until
    // cleanup: after that, annotateStderr returns the stderr unchanged. The
    // sandbox still has to be cleaned up for the crashed kernel.
    let cleaned = false
    const cleanup = vi.fn(() => {
      cleaned = true
    })
    const annotateStderr = vi.fn((stderr: string) =>
      cleaned ? stderr : `${stderr}<sandbox_violations>hidden path</sandbox_violations>`
    )
    const processSandbox: NotebookProcessSandbox = {
      wrap: vi.fn(async (invocation) => ({
        executable: invocation.executable,
        args: invocation.args,
        env: invocation.env,
        beginExecution: () => () => undefined,
        annotateStderr,
        cleanup
      }))
    }
    const executor = new NotebookKernelExecutor({
      pythonLoopPath: crashingLoop,
      processSandbox
    })

    try {
      const result = await executor.execute({
        ...baseRequest(cwdDir),
        code: 'kernel exits in sandbox',
        sessionId: 'session-1',
        projectId: 'project-1',
        resolvedInterpreter: { command: python3 as string }
      })

      expect(result).toMatchObject({ status: 'failed' })
      expect(result.stderr).toMatch(/\b25\b/)
      expect(result.stderr).toContain('<sandbox_violations>hidden path</sandbox_violations>')
      expect(annotateStderr).toHaveBeenCalled()
    } finally {
      await executor.shutdown()
    }
    expect(cleanup).toHaveBeenCalled()
  })

  it('leaves the healthy execute and the timeout branch unchanged', async () => {
    cwdDir = await mkdtemp(join(tmpdir(), 'os-kernel-happy-timeout-'))
    const executor = new NotebookKernelExecutor({ pythonLoopPath: FIXTURE })

    try {
      // Healthy request returns its result.
      const healthy = await executor.execute({
        ...baseRequest(cwdDir),
        code: 'hello',
        resolvedInterpreter: { command: python3 as string }
      })
      expect(healthy.status).toBe('completed')
      expect(healthy.stdout).toBe('hello')

      // Warm the loop, then a soft-timed-out run still surfaces the timeout,
      // never an exit-code termination message.
      const timed = await executor.execute({
        ...baseRequest(cwdDir),
        code: '__SLEEP__',
        resolvedInterpreter: { command: python3 as string },
        timeoutMs: 100
      })
      expect(timed.status).toBe('timeout')
      expect(timed.stderr ?? '').not.toContain('exit code')
    } finally {
      await executor.shutdown()
    }
  }, 15_000)

  it('still reports a timeout when the kernel dies from the timeout interrupt', async () => {
    cwdDir = await mkdtemp(join(tmpdir(), 'os-kernel-timeout-exit-'))
    // Reads the request, then sleeps without handling SIGINT, so the soft
    // timeout interrupt ends the process instead of getting a reply.
    const interruptedLoop = join(cwdDir, 'interrupted_loop.py')
    await writeFile(
      interruptedLoop,
      ['import sys, time', 'sys.stdin.readline()', 'time.sleep(30)'].join('\n')
    )
    const executor = new NotebookKernelExecutor({ pythonLoopPath: interruptedLoop })

    try {
      const result = await executor.execute({
        ...baseRequest(cwdDir),
        code: 'kernel sleeps',
        resolvedInterpreter: { command: python3 as string },
        timeoutMs: 100
      })
      expect(result.status).toBe('timeout')
    } finally {
      await executor.shutdown()
    }
  }, 15_000)
})
