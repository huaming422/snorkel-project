// @ts-nocheck
//
// Behavioral checks for notebook kernels that die before answering, for when a
// kernel's process sandbox is released, and for kernels started on a protected
// Windows sandbox. Every case drives the public `NotebookKernelExecutor` methods
// (execute, restart, shutdown, terminate) end to end against a real system
// python3 (or Node for the control kernel) and reads only the returned
// NotebookExecutionResult (status, stdout, stderr), how long it takes to settle,
// the calls made on an injected process sandbox, and the launch specifications
// a stand-in AppContainer host received.

import { existsSync } from 'node:fs'
import { chmod, mkdir, mkdtemp, readFile, realpath, rm, symlink, writeFile } from 'node:fs/promises'
import { createServer } from 'node:net'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterAll, afterEach, beforeAll, describe, expect, it, vi } from 'vitest'

import { DEFAULT_NOTEBOOK_NETWORK_SETTINGS } from '../../shared/notebook-network'
import { NOTEBOOK_PROTOCOL_LINE_LIMIT_BYTES } from './content-limits'
import { NotebookKernelExecutor } from './kernel-executor'
import { NotebookNetworkSandboxOwner } from './network-sandbox-owner'
import type { NotebookProcessSandbox } from './process-sandbox'
import { DEFAULT_PY_ENV } from './runtime-paths'

const FIXTURE = join(__dirname, '../../../test/fixtures/fake_loop.py')

// First on-disk python3 wins; mirrors the repo's own driver-suite resolver.
const resolvePython3 = (): string | undefined =>
  [
    process.env.OPEN_SCIENCE_TEST_PY_ENV,
    '/opt/homebrew/bin/python3',
    '/usr/local/bin/python3',
    '/usr/bin/python3'
  ].find((candidate): candidate is string => typeof candidate === 'string' && existsSync(candidate))

const python3 = resolvePython3()
// The image bakes python3 and test-setup.sh fails loud when it is missing, so a
// skip here would hide an environment regression rather than a real pass.
const gate = python3 ? describe : describe.skip

const baseRequest = (
  cwd: string
): {
  cwd: string
  notebookSessionRoot: string
  inputRoot: string
  dataRoot: string
  runtimeRoot: string
} => ({
  cwd,
  notebookSessionRoot: join(cwd, 'nb'),
  inputRoot: join(cwd, 'inputs'),
  dataRoot: join(cwd, 'nb', 'data'),
  runtimeRoot: join(cwd, 'runtime')
})

// A process sandbox that runs the invocation unchanged and records, per wrapped
// kernel, whether its cleanup has run. Each wrap gets its own cleanup so a check
// can tell which kernel's sandbox was released.
const recordingSandbox = (): {
  processSandbox: NotebookProcessSandbox
  kernels: Array<{ cleanup: ReturnType<typeof vi.fn> }>
} => {
  const kernels: Array<{ cleanup: ReturnType<typeof vi.fn> }> = []
  const processSandbox: NotebookProcessSandbox = {
    wrap: vi.fn(async (invocation) => {
      const kernel = { cleanup: vi.fn() }
      kernels.push(kernel)
      return {
        executable: invocation.executable,
        args: invocation.args,
        env: invocation.env,
        beginExecution: () => () => undefined,
        annotateStderr: (stderr: string) => stderr,
        cleanup: kernel.cleanup
      }
    })
  }
  return { processSandbox, kernels }
}

const sandboxContext = { sessionId: 'session-1', projectId: 'project-1' }

const released = async (cleanup: ReturnType<typeof vi.fn>): Promise<void> => {
  await vi.waitFor(() => expect(cleanup).toHaveBeenCalled(), { timeout: 5_000, interval: 20 })
}

let cwdDir: string | undefined

afterEach(async () => {
  if (cwdDir) {
    await rm(cwdDir, { recursive: true, force: true })
    cwdDir = undefined
  }
})

gate('NotebookKernelExecutor startup-failure diagnostics', () => {
  it('surfaces the exit code and the interpreter stderr when a kernel exits before replying', async () => {
    cwdDir = await mkdtemp(join(tmpdir(), 'os-kernel-startup-exit-'))
    const crashingLoop = join(cwdDir, 'crashing_loop.py')
    await writeFile(
      crashingLoop,
      [
        'import sys',
        'sys.stderr.write("PowerShell FileSystem provider initialization failed.\\n")',
        'sys.stderr.flush()',
        'raise SystemExit(23)'
      ].join('\n')
    )
    const executor = new NotebookKernelExecutor({ pythonLoopPath: crashingLoop })

    try {
      const result = await executor.execute({
        ...baseRequest(cwdDir),
        code: 'import numpy',
        resolvedInterpreter: { command: python3 as string }
      })

      expect(result).toMatchObject({ status: 'failed' })
      // The run's stderr carries the exit code and the interpreter's own stderr
      // line. The wording around the code is not fixed ("exit code 23",
      // "exited with code 23" and "status 23" all match).
      expect(result.stderr).toMatch(/\b23\b/)
      expect(result.stderr).toContain('PowerShell FileSystem provider initialization failed.')
    } finally {
      await executor.shutdown()
    }
  })

  it('settles the run promptly when a dead kernel leaves a descendant holding its stdio pipes', async () => {
    cwdDir = await mkdtemp(join(tmpdir(), 'os-kernel-descendant-stdio-'))
    const releaseFile = join(cwdDir, 'release-descendant')
    const finishedFile = join(cwdDir, 'descendant-finished')
    // The descendant inherits the kernel's stdout/stderr and blocks until a
    // release file appears, holding those pipes open after the kernel is gone.
    const descendantCode = [
      'import os, time',
      `release_file = ${JSON.stringify(releaseFile)}`,
      `finished_file = ${JSON.stringify(finishedFile)}`,
      'while not os.path.exists(release_file): time.sleep(0.01)',
      `os.chdir(${JSON.stringify(tmpdir())})`,
      'with open(finished_file, "w", encoding="utf-8") as marker: marker.write("done")'
    ].join('\n')
    const crashingLoop = join(cwdDir, 'crashing_loop_with_descendant.py')
    await writeFile(
      crashingLoop,
      [
        'import subprocess, sys',
        `subprocess.Popen([sys.executable, "-c", ${JSON.stringify(descendantCode)}], stdout=sys.stdout, stderr=sys.stderr, close_fds=False)`,
        'raise SystemExit(24)'
      ].join('\n')
    )
    const executor = new NotebookKernelExecutor({ pythonLoopPath: crashingLoop })
    const execution = executor.execute({
      ...baseRequest(cwdDir),
      code: 'kernel exits',
      resolvedInterpreter: { command: python3 as string }
    })

    try {
      // The run has to settle well before the descendant is released.
      const settledBeforeDescendant = await Promise.race([
        execution.then(() => true),
        new Promise<false>((resolve) => setTimeout(() => resolve(false), 1_500))
      ])

      expect(settledBeforeDescendant).toBe(true)
      await expect(execution).resolves.toMatchObject({ status: 'failed' })
    } finally {
      await writeFile(releaseFile, 'release')
      await execution
      await executor.shutdown()
      for (let attempt = 0; attempt < 200 && !existsSync(finishedFile); attempt += 1) {
        await new Promise((resolve) => setTimeout(resolve, 10))
      }
    }
  })

  it('keeps the sandbox violation note in a sandboxed kernel crash error', async () => {
    cwdDir = await mkdtemp(join(tmpdir(), 'os-kernel-startup-sandbox-exit-'))
    const crashingLoop = join(cwdDir, 'crashing_sandbox_loop.py')
    await writeFile(
      crashingLoop,
      [
        'import sys',
        'sys.stderr.write("Permission denied: C:/hidden/credentials.txt\\n")',
        'sys.stderr.flush()',
        'raise SystemExit(25)'
      ].join('\n')
    )
    // Like the real sandbox, this one keeps its violation records only until
    // cleanup: after that, annotateStderr returns the stderr unchanged. The
    // sandbox still has to be cleaned up for the crashed kernel.
    let cleaned = false
    const cleanup = vi.fn(() => {
      cleaned = true
    })
    const annotateStderr = vi.fn((stderr: string) =>
      cleaned ? stderr : `${stderr}<sandbox_violations>hidden path</sandbox_violations>`
    )
    const processSandbox: NotebookProcessSandbox = {
      wrap: vi.fn(async (invocation) => ({
        executable: invocation.executable,
        args: invocation.args,
        env: invocation.env,
        beginExecution: () => () => undefined,
        annotateStderr,
        cleanup
      }))
    }
    const executor = new NotebookKernelExecutor({
      pythonLoopPath: crashingLoop,
      processSandbox
    })

    try {
      const result = await executor.execute({
        ...baseRequest(cwdDir),
        code: 'kernel exits in sandbox',
        sessionId: 'session-1',
        projectId: 'project-1',
        resolvedInterpreter: { command: python3 as string }
      })

      expect(result).toMatchObject({ status: 'failed' })
      expect(result.stderr).toMatch(/\b25\b/)
      expect(result.stderr).toContain('<sandbox_violations>hidden path</sandbox_violations>')
      expect(annotateStderr).toHaveBeenCalled()
    } finally {
      await executor.shutdown()
    }
    expect(cleanup).toHaveBeenCalled()
  })

  it('leaves the healthy execute and the timeout branch unchanged', async () => {
    cwdDir = await mkdtemp(join(tmpdir(), 'os-kernel-happy-timeout-'))
    const executor = new NotebookKernelExecutor({ pythonLoopPath: FIXTURE })

    try {
      // Healthy request returns its result.
      const healthy = await executor.execute({
        ...baseRequest(cwdDir),
        code: 'hello',
        resolvedInterpreter: { command: python3 as string }
      })
      expect(healthy.status).toBe('completed')
      expect(healthy.stdout).toBe('hello')

      // Warm the loop, then a soft-timed-out run still surfaces the timeout,
      // never an exit-code termination message.
      const timed = await executor.execute({
        ...baseRequest(cwdDir),
        code: '__SLEEP__',
        resolvedInterpreter: { command: python3 as string },
        timeoutMs: 100
      })
      expect(timed.status).toBe('timeout')
      expect(timed.stderr ?? '').not.toContain('exit code')
    } finally {
      await executor.shutdown()
    }
  }, 15_000)

  it('still reports a timeout when the kernel dies from the timeout interrupt', async () => {
    cwdDir = await mkdtemp(join(tmpdir(), 'os-kernel-timeout-exit-'))
    // Reads the request, then sleeps without handling SIGINT, so the soft
    // timeout interrupt ends the process instead of getting a reply.
    const interruptedLoop = join(cwdDir, 'interrupted_loop.py')
    await writeFile(
      interruptedLoop,
      ['import sys, time', 'sys.stdin.readline()', 'time.sleep(30)'].join('\n')
    )
    const executor = new NotebookKernelExecutor({ pythonLoopPath: interruptedLoop })

    try {
      const result = await executor.execute({
        ...baseRequest(cwdDir),
        code: 'kernel sleeps',
        resolvedInterpreter: { command: python3 as string },
        timeoutMs: 100
      })
      expect(result.status).toBe('timeout')
    } finally {
      await executor.shutdown()
    }
  }, 15_000)
})

gate('NotebookKernelExecutor sandbox release across the kernel lifecycle', () => {
  it('keeps a running kernel sandboxed and releases it on restart and on shutdown', async () => {
    cwdDir = await mkdtemp(join(tmpdir(), 'os-kernel-sandbox-restart-'))
    const { processSandbox, kernels } = recordingSandbox()
    const executor = new NotebookKernelExecutor({ pythonLoopPath: FIXTURE, processSandbox })
    const run = (code: string) =>
      executor.execute({
        ...baseRequest(cwdDir as string),
        ...sandboxContext,
        code,
        resolvedInterpreter: { command: python3 as string }
      })

    try {
      const first = await run('first kernel')
      expect(first).toMatchObject({ status: 'completed', stdout: 'first kernel' })
      expect(kernels).toHaveLength(1)
      expect(kernels[0].cleanup).not.toHaveBeenCalled()

      await executor.restart()
      await released(kernels[0].cleanup)

      const second = await run('second kernel')
      expect(second).toMatchObject({ status: 'completed', stdout: 'second kernel' })
      expect(kernels).toHaveLength(2)
      expect(kernels[1].cleanup).not.toHaveBeenCalled()
    } finally {
      await executor.shutdown()
    }
    await released(kernels[1].cleanup)
  }, 20_000)

  it('releases the old kernel sandbox, and only that one, when a run switches interpreters', async () => {
    cwdDir = await mkdtemp(join(tmpdir(), 'os-kernel-sandbox-switch-'))
    const { processSandbox, kernels } = recordingSandbox()
    const executor = new NotebookKernelExecutor({ pythonLoopPath: FIXTURE, processSandbox })

    try {
      const managed = await executor.execute({
        ...baseRequest(cwdDir),
        ...sandboxContext,
        code: 'on the first interpreter',
        resolvedInterpreter: { command: python3 as string }
      })
      expect(managed).toMatchObject({ status: 'completed' })

      const switched = await executor.execute({
        ...baseRequest(cwdDir),
        ...sandboxContext,
        code: 'on the second interpreter',
        resolvedInterpreter: { command: python3 as string, args: ['-u'] }
      })
      expect(switched).toMatchObject({ status: 'completed', stdout: 'on the second interpreter' })
      expect(kernels).toHaveLength(2)
      await released(kernels[0].cleanup)
      expect(kernels[1].cleanup).not.toHaveBeenCalled()
    } finally {
      await executor.shutdown()
    }
    await released(kernels[1].cleanup)
  }, 20_000)

  it('releases the sandbox of a kernel reclaimed after sitting idle', async () => {
    cwdDir = await mkdtemp(join(tmpdir(), 'os-kernel-sandbox-idle-'))
    const { processSandbox, kernels } = recordingSandbox()
    const onIdleShutdown = vi.fn()
    const executor = new NotebookKernelExecutor({
      pythonLoopPath: FIXTURE,
      processSandbox,
      idleTimeoutMs: 150,
      onIdleShutdown
    })

    try {
      const result = await executor.execute({
        ...baseRequest(cwdDir),
        ...sandboxContext,
        code: 'then idle',
        resolvedInterpreter: { command: python3 as string }
      })
      expect(result).toMatchObject({ status: 'completed' })
      await vi.waitFor(() => expect(onIdleShutdown).toHaveBeenCalled(), {
        timeout: 5_000,
        interval: 20
      })
      await released(kernels[0].cleanup)
    } finally {
      await executor.shutdown()
    }
  }, 20_000)

  it('releases the sandbox of a kernel killed after its run ignored the timeout interrupt', async () => {
    cwdDir = await mkdtemp(join(tmpdir(), 'os-kernel-sandbox-hard-timeout-'))
    const { processSandbox, kernels } = recordingSandbox()
    const executor = new NotebookKernelExecutor({ pythonLoopPath: FIXTURE, processSandbox })

    try {
      // The fixture ignores SIGINT for this code, so the run is only ended by the hard kill.
      const result = await executor.execute({
        ...baseRequest(cwdDir),
        ...sandboxContext,
        code: '__IGNORE_SIGINT__',
        resolvedInterpreter: { command: python3 as string },
        timeoutMs: 100
      })
      expect(result.status).toBe('timeout')
      await released(kernels[0].cleanup)
    } finally {
      await executor.shutdown()
    }
  }, 20_000)

  it('releases the sandbox of a kernel torn down for a runtime switch', async () => {
    cwdDir = await mkdtemp(join(tmpdir(), 'os-kernel-sandbox-terminate-'))
    const { processSandbox, kernels } = recordingSandbox()
    const executor = new NotebookKernelExecutor({ pythonLoopPath: FIXTURE, processSandbox })

    try {
      const result = await executor.execute({
        ...baseRequest(cwdDir),
        ...sandboxContext,
        code: 'before the switch',
        resolvedInterpreter: { command: python3 as string }
      })
      expect(result).toMatchObject({ status: 'completed' })
      expect(kernels[0].cleanup).not.toHaveBeenCalled()

      await executor.terminate('python', DEFAULT_PY_ENV)
      await released(kernels[0].cleanup)
    } finally {
      await executor.shutdown()
    }
  }, 20_000)

  it('releases the sandbox of a kernel dropped after a cancelled run ignored the interrupt', async () => {
    cwdDir = await mkdtemp(join(tmpdir(), 'os-kernel-sandbox-cancel-'))
    const { processSandbox, kernels } = recordingSandbox()
    const executor = new NotebookKernelExecutor({
      pythonLoopPath: FIXTURE,
      processSandbox,
      platform: 'linux',
      cancellationGraceMs: 50
    })

    try {
      const warm = await executor.execute({
        ...baseRequest(cwdDir),
        ...sandboxContext,
        code: 'warm',
        resolvedInterpreter: { command: python3 as string }
      })
      expect(warm).toMatchObject({ status: 'completed' })

      // The fixture ignores SIGINT for this code, so the cancelled kernel is
      // dropped once the cancellation grace runs out.
      const cancellation = new AbortController()
      const run = executor.execute({
        ...baseRequest(cwdDir),
        ...sandboxContext,
        code: '__IGNORE_SIGINT__',
        resolvedInterpreter: { command: python3 as string },
        signal: cancellation.signal
      })
      await new Promise((resolve) => setTimeout(resolve, 500))
      cancellation.abort()

      await expect(run).resolves.toMatchObject({ status: 'cancelled' })
      await released(kernels[0].cleanup)
    } finally {
      await executor.shutdown()
    }
  }, 20_000)

  it('releases the sandbox of a kernel dropped for an oversized output line', async () => {
    cwdDir = await mkdtemp(join(tmpdir(), 'os-kernel-sandbox-overflow-'))
    const { processSandbox, kernels } = recordingSandbox()
    const executor = new NotebookKernelExecutor({ pythonLoopPath: FIXTURE, processSandbox })

    try {
      const result = await executor.execute({
        ...baseRequest(cwdDir),
        ...sandboxContext,
        code: `__OVERSIZED_LINE__:${NOTEBOOK_PROTOCOL_LINE_LIMIT_BYTES + 1}`,
        resolvedInterpreter: { command: python3 as string }
      })
      expect(result.status).toBe('failed')
      await released(kernels[0].cleanup)
    } finally {
      await executor.shutdown()
    }
  }, 20_000)

  it('releases the sandbox when the interpreter cannot be started', async () => {
    cwdDir = await mkdtemp(join(tmpdir(), 'os-kernel-sandbox-missing-'))
    const { processSandbox, kernels } = recordingSandbox()
    const missingInterpreter = join(cwdDir, 'missing-env', 'bin', 'python3')
    const executor = new NotebookKernelExecutor({ pythonLoopPath: FIXTURE, processSandbox })

    try {
      const result = await executor.execute({
        ...baseRequest(cwdDir),
        ...sandboxContext,
        code: 'never runs',
        resolvedInterpreter: { command: missingInterpreter }
      })
      expect(result.status).toBe('failed')
      expect(result.stderr).toContain(missingInterpreter)
      expect(kernels).toHaveLength(1)
      await released(kernels[0].cleanup)
    } finally {
      await executor.shutdown()
    }
  }, 20_000)
})

// A stand-in for the native AppContainer host. It answers the status and network
// fence probes the sandbox runs on start-up, and for a launch it reads the
// launch specification and runs the named executable with the named arguments
// in the named working directory, sharing its own stdio, the way the real host
// hands its pipes to the process it starts. Every working directory in this
// block stands for a folder on a non-system drive, where PowerShell cannot
// start inside the AppContainer, so a PowerShell launch fails with PowerShell's
// own error.
const writeAppContainerHost = async (
  resourceRoot: string,
  gatewayPort: number,
  launchLog: string
): Promise<void> => {
  const arch = process.arch === 'arm64' ? 'arm64' : 'x64'
  const hostDir = join(resourceRoot, 'windows', arch)
  await mkdir(hostDir, { recursive: true })
  const hostPath = join(hostDir, 'notebook-appcontainer-host.exe')
  await writeFile(
    hostPath,
    [
      `#!${process.execPath}`,
      "const { spawn } = require('node:child_process')",
      "const { appendFileSync } = require('node:fs')",
      `const gatewayPort = ${gatewayPort}`,
      `const launchLog = ${JSON.stringify(launchLog)}`,
      'const [command, , , encoded] = process.argv.slice(2)',
      "if (command === 'status') {",
      '  process.stdout.write(JSON.stringify({ profileExists: true, loopbackAllowed: true,',
      "    networkFenceReady: true, owned: true, ownershipState: 'owned', gatewayPort }))",
      '  process.exit(0)',
      '}',
      "if (command !== 'launch') process.exit(0)",
      "const spec = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8'))",
      "const commandLine = spec.arguments.join(' ')",
      "const probe = /ConnectAsync\\('127\\.0\\.0\\.1', (\\d+)\\)/.exec(commandLine)",
      'if (probe) process.exit(Number(probe[1]) === gatewayPort ? 0 : 33)',
      "appendFileSync(launchLog, JSON.stringify(spec) + '\\n')",
      'if (/(^|[\\\\/])(powershell|pwsh)(\\.exe)?$/i.test(spec.executable)) {',
      '  process.stderr.write("Attempting to perform the InitializeDefaultDrives operation on the \'FileSystem\' provider failed.\\n")',
      '  process.exit(1)',
      '}',
      "const child = spawn(spec.executable, spec.arguments, { cwd: spec.cwd, stdio: 'inherit' })",
      "child.on('error', (error) => { process.stderr.write(error.message + '\\n'); process.exit(1) })",
      "child.on('exit', (code, signal) => process.exit(code ?? (signal ? 1 : 0)))"
    ].join('\n')
  )
  await chmod(hostPath, 0o755)
}

const freePort = (): Promise<number> =>
  new Promise((resolve, reject) => {
    const server = createServer()
    server.once('error', reject)
    server.listen(0, '127.0.0.1', () => {
      const address = server.address()
      server.close(() =>
        typeof address === 'object' && address ? resolve(address.port) : reject(new Error('no port'))
      )
    })
  })

// The sandbox package reads process.platform while it starts up and while it
// prepares each launch. Only those calls see win32; the executor and the
// process-tree teardown keep running on the real platform.
const asWindows = async <T>(run: () => Promise<T>): Promise<T> => {
  const original = Object.getOwnPropertyDescriptor(process, 'platform') as PropertyDescriptor
  Object.defineProperty(process, 'platform', { ...original, value: 'win32' })
  try {
    return await run()
  } finally {
    Object.defineProperty(process, 'platform', original)
  }
}

const quietLogger = { debug: () => undefined, info: () => undefined, warn: () => undefined, error: () => undefined }

// Replies to every request with what the interpreter was started with: its
// argument vector, its working directory and the interpreter options the cases
// pass. The interpreter's own path is checked by the kernel starting at all.
const PYTHON_LAUNCH_REPORT_LOOP = [
  'import json, os, sys',
  'for line in sys.stdin:',
  '    line = line.strip()',
  '    if not line:',
  '        continue',
  '    request = json.loads(line)',
  '    report = {"argv": sys.argv, "cwd": os.getcwd(),',
  '              "optimize": sys.flags.optimize, "no_bytecode": sys.flags.dont_write_bytecode,',
  '              "pycache_prefix": sys.pycache_prefix}',
  '    sys.stdout.write(json.dumps({"req_id": request["req_id"], "stdout": json.dumps(report),',
  '        "stderr": "", "error": None, "interrupt_ack": False, "result": None,',
  '        "cwd": os.getcwd(), "figures": []}) + "\\n")',
  '    sys.stdout.flush()'
].join('\n')

const REPL_LAUNCH_REPORT_LOOP = [
  "const { createInterface } = require('node:readline')",
  "createInterface({ input: process.stdin }).on('line', (line) => {",
  '  if (!line.trim()) return',
  '  const request = JSON.parse(line)',
  '  const report = { argv: process.argv.slice(1), cwd: process.cwd() }',
  "  process.stdout.write(JSON.stringify({ req_id: request.req_id, stdout: JSON.stringify(report), stderr: '',",
  "    error: null, interrupt_ack: false, result: null, cwd: process.cwd(), figures: [] }) + '\\n')",
  '})'
].join('\n')

gate('NotebookKernelExecutor on a protected Windows sandbox', () => {
  let root: string
  let launchLog: string
  let owner: NotebookNetworkSandboxOwner

  beforeAll(async () => {
    root = await realpath(await mkdtemp(join(tmpdir(), 'os-kernel-appcontainer-')))
    launchLog = join(root, 'launches.jsonl')
    await writeFile(launchLog, '')
    await writeAppContainerHost(join(root, 'resources'), await freePort(), launchLog)
    owner = new NotebookNetworkSandboxOwner({
      resourceRoot: join(root, 'resources'),
      getSettings: async () => DEFAULT_NOTEBOOK_NETWORK_SETTINGS,
      persistAlwaysAllow: vi.fn(),
      requestDecision: vi.fn().mockResolvedValue('deny'),
      platform: 'win32',
      logger: quietLogger
    })
    await asWindows(() => owner.initialize())
  }, 30_000)

  afterAll(async () => {
    await asWindows(() => owner.dispose())
    await rm(root, { recursive: true, force: true })
  })

  const windowsSandbox = (): NotebookProcessSandbox => ({
    wrap: (invocation) => asWindows(() => owner.wrap(invocation))
  })

  const launchesIn = async (cwd: string): Promise<Array<{ cwd: string }>> =>
    (await readFile(launchLog, 'utf8'))
      .split('\n')
      .filter(Boolean)
      .map((line) => JSON.parse(line))
      .filter((spec) => spec.cwd === cwd)

  it('starts Python kernels on a non-system drive with their interpreter, arguments and folder unchanged', async () => {
    const notebookDir = join(root, 'D drive', "Q3 results & notes (Bob's copy) 100%")
    const loopDir = join(root, 'kernel loops 100%', "O'Brien")
    const interpreterDir = join(root, "Python 3 (Ana's & Raj's) 50%")
    const pycacheDir = join(root, `py cache & 'tmp' "v2" 7%`)
    await mkdir(notebookDir, { recursive: true })
    await mkdir(loopDir, { recursive: true })
    await mkdir(interpreterDir, { recursive: true })
    const loopPath = join(loopDir, 'launch report loop.py')
    await writeFile(loopPath, PYTHON_LAUNCH_REPORT_LOOP)
    const interpreter = join(interpreterDir, 'python3')
    await symlink(python3 as string, interpreter)
    const executor = new NotebookKernelExecutor({
      pythonLoopPath: loopPath,
      processSandbox: windowsSandbox()
    })
    const run = (args: string[]) =>
      executor.execute({
        ...baseRequest(notebookDir),
        ...sandboxContext,
        code: 'report',
        resolvedInterpreter: { command: interpreter, args }
      })

    try {
      const first = await run(['-O', '-X', `pycache_prefix=${pycacheDir}`])
      expect(first).toMatchObject({ status: 'completed' })
      expect(JSON.parse(first.stdout)).toEqual({
        argv: [loopPath],
        cwd: notebookDir,
        optimize: 1,
        no_bytecode: 0,
        pycache_prefix: pycacheDir
      })

      // Other interpreter arguments are another interpreter identity, so the
      // kernel is started again with them.
      const second = await run(['-B'])
      expect(second).toMatchObject({ status: 'completed' })
      expect(JSON.parse(second.stdout)).toEqual({
        argv: [loopPath],
        cwd: notebookDir,
        optimize: 0,
        no_bytecode: 1,
        pycache_prefix: null
      })
      // Both kernels were started by the AppContainer host, not outside it.
      expect((await launchesIn(notebookDir)).length).toBeGreaterThanOrEqual(2)
    } finally {
      await executor.shutdown()
    }
  }, 30_000)

  it('starts the JavaScript control kernel on a non-system drive with its loop path and folder unchanged', async () => {
    const notebookDir = join(root, 'E drive', "control & Ana's tools 20%")
    const loopDir = join(root, 'repl loops & 25%', "it's here")
    await mkdir(notebookDir, { recursive: true })
    await mkdir(loopDir, { recursive: true })
    const loopPath = join(loopDir, 'launch report loop.js')
    await writeFile(loopPath, REPL_LAUNCH_REPORT_LOOP)
    const executor = new NotebookKernelExecutor({
      replLoopPath: loopPath,
      processSandbox: windowsSandbox()
    })

    try {
      const result = await executor.execute({
        ...baseRequest(notebookDir),
        ...sandboxContext,
        kind: 'repl',
        code: 'report'
      })
      expect(result).toMatchObject({ status: 'completed' })
      expect(JSON.parse(result.stdout)).toEqual({ argv: [loopPath], cwd: notebookDir })
      expect((await launchesIn(notebookDir)).length).toBeGreaterThanOrEqual(1)
    } finally {
      await executor.shutdown()
    }
  }, 30_000)

  it('surfaces the exit code and stderr of a kernel that dies on a protected Windows sandbox', async () => {
    const notebookDir = join(root, 'F drive', 'crash')
    await mkdir(notebookDir, { recursive: true })
    const crashingLoop = join(notebookDir, 'crashing loop.py')
    await writeFile(
      crashingLoop,
      [
        'import sys',
        'sys.stderr.write("ImportError: DLL load failed while importing _multiarray_umath\\n")',
        'sys.stderr.flush()',
        'raise SystemExit(26)'
      ].join('\n')
    )
    const executor = new NotebookKernelExecutor({
      pythonLoopPath: crashingLoop,
      processSandbox: windowsSandbox()
    })

    try {
      const result = await executor.execute({
        ...baseRequest(notebookDir),
        ...sandboxContext,
        code: 'import numpy',
        resolvedInterpreter: { command: python3 as string }
      })
      expect(result).toMatchObject({ status: 'failed' })
      expect(result.stderr).toMatch(/\b26\b/)
      expect(result.stderr).toContain(
        'ImportError: DLL load failed while importing _multiarray_umath'
      )
    } finally {
      await executor.shutdown()
    }
  }, 30_000)
})
