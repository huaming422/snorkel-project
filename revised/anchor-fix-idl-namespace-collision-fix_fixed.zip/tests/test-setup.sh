#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier (set -euo pipefail inherited).
# Rust-only task: no services to start, no data to seed. This script only brings
# the baked dependency closure online for the offline grade-time phase.
cd /repo/anchor

# Fail fast on a cache miss instead of retrying against a dead network: the
# smoke gate's offline fold sources this inside `docker run --network none`.
export CARGO_NET_OFFLINE=true

# Dependencies: offline-first against the image bake, logged online fallback.
# The image warmed the root workspace (cargo fetch --locked) at the base commit.
if cargo fetch --locked --offline > /tmp/test-setup-fetch.log 2>&1; then
    echo "[offline-first] root workspace deps satisfied from image"
elif cargo fetch --locked >> /tmp/test-setup-fetch.log 2>&1; then
    echo "[test-setup] root workspace deps fetched online (image bake was stale)"
else
    tail -40 /tmp/test-setup-fetch.log >&2; exit 1
fi

# The program-interface macro harness lives in a nested, excluded workspace with
# no checked-in lockfile; the image warmed its registry entries. Resolve it
# against that warm cache (unlocked, since there is no Cargo.lock to honor).
if cargo fetch --offline --manifest-path tests/declare-program/Cargo.toml \
        > /tmp/test-setup-fetch-declare.log 2>&1; then
    echo "[offline-first] declare-program harness deps satisfied from image"
elif cargo fetch --manifest-path tests/declare-program/Cargo.toml \
        >> /tmp/test-setup-fetch-declare.log 2>&1; then
    echo "[test-setup] declare-program harness deps fetched online (image bake was stale)"
else
    tail -40 /tmp/test-setup-fetch-declare.log >&2; exit 1
fi
