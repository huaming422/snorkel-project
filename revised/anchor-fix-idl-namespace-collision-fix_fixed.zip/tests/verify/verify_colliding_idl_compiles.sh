#!/usr/bin/env bash
#
# Behavioral check (fail_to_pass): when an interface description defines
# names that match framework items, the bindings the program-interface macro
# generates from it must still compile.
#
# The fixture is written here and does not come from the task repo. It is a
# hand-written foreign interface description with one matching name in each
# vocabulary the generated scope re-exports:
#   - a `types` enum named `Space` (same name as a framework item), used as an
#     instruction argument so the bindings name it in type position;
#   - an `accounts` entry named `Key` (same name as a framework item), which
#     the generated account parser names in type position;
#   - an `events` entry named `Owner` (same name as a framework item), which
#     the generated event parser names in type position.
# A throwaway consumer crate loads that description through the macro and is
# compiled.
#
# Spreading the matches over all three vocabularies means the bindings only
# compile when every IDL-defined name is resolved apart from the framework
# names. Renaming one type, handling a single name, or separating only one
# vocabulary leaves at least one of these references ambiguous.
#
# With the shared scope, a bare reference resolves to the framework item and
# the build fails. With the names kept apart, it builds. Only the cargo exit
# code is used; generated symbol names are never read.

set -euo pipefail

WS=/repo/anchor/tests/declare-program
IDL_NAME=collision_probe_space
CRATE=collision_probe_space_verify
CRATE_DIR="${WS}/programs/${CRATE}"
IDL_FILE="${WS}/idls/${IDL_NAME}.json"

cleanup() {
    rm -rf "${CRATE_DIR}" "${IDL_FILE}"
}
trap cleanup EXIT

mkdir -p "${CRATE_DIR}/src"

# The fixture described in the header above.
cat > "${IDL_FILE}" <<'JSON'
{
  "address": "11111111111111111111111111111111",
  "metadata": {
    "name": "collision_probe_space",
    "version": "0.1.0",
    "spec": "0.1.0",
    "description": "Hand-authored fixture: a foreign interface whose defined type, account, and event names each coincide with a framework-provided item. No source program in this repo."
  },
  "instructions": [
    {
      "name": "probe",
      "discriminator": [0, 0, 0, 0, 0, 0, 0, 0],
      "accounts": [],
      "args": [
        {
          "name": "value",
          "type": {
            "defined": {
              "name": "Space"
            }
          }
        }
      ]
    }
  ],
  "accounts": [
    {
      "name": "Key",
      "discriminator": [0, 0, 0, 0, 0, 0, 0, 0]
    }
  ],
  "events": [
    {
      "name": "Owner",
      "discriminator": [0, 0, 0, 0, 0, 0, 0, 0]
    }
  ],
  "types": [
    {
      "name": "Space",
      "type": {
        "kind": "enum",
        "variants": [
          { "name": "Small" },
          { "name": "Large" }
        ]
      }
    },
    {
      "name": "Key",
      "type": {
        "kind": "struct",
        "fields": [
          { "name": "value", "type": "u64" }
        ]
      }
    },
    {
      "name": "Owner",
      "type": {
        "kind": "struct",
        "fields": [
          { "name": "value", "type": "u64" }
        ]
      }
    }
  ]
}
JSON

cat > "${CRATE_DIR}/Cargo.toml" <<'TOML'
[package]
name = "collision_probe_space_verify"
version = "0.0.0"
edition = "2021"
publish = false

[lib]
name = "collision_probe_space_verify"
path = "src/lib.rs"

[dependencies]
anchor-lang = { path = "../../../../lang" }
TOML

cat > "${CRATE_DIR}/src/lib.rs" <<'RUST'
use anchor_lang::prelude::*;

declare_program!(collision_probe_space);
RUST

cd "${WS}"
cargo build -p "${CRATE}"
