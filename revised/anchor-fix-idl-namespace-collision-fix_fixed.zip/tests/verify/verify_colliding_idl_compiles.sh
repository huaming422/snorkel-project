#!/usr/bin/env bash
#
# Behavioral check: when a foreign interface description defines types whose
# names match framework items, the bindings the program-interface macro
# generates from it must still compile.
#
# The fixture is written here and does not come from the task repo. It uses
# twelve trait names that the framework prelude exports, all of them in one
# description:
#   - six `types` entries, each passed as an instruction argument so the
#     bindings name it in type position. Three are enums, and each of the other
#     three is a struct whose field type is one of those enums;
#   - three `accounts` entries, which the generated account parser names in
#     type position;
#   - three `events` entries, which the generated event parser names in type
#     position.
# A shuffle with a fixed seed decides which name goes into which slot, so the
# layout is mixed but every run builds the same fixture. A throwaway consumer
# crate loads the description through the macro and is compiled.
#
# The build only passes when every defined type, account and event can share
# its name with a framework trait. Handling a few of the names, or only one of
# accounts, events and types, leaves the other names failing.
#
# When a name in the bindings resolves to the framework trait instead of the
# defined type, the build fails with an ambiguity or "expected a type, found a
# trait" error. Only the cargo exit code is used; generated symbol names are
# never read.

set -euo pipefail

WS=/repo/anchor/tests/declare-program
IDL_NAME=foreign_probe
CRATE=foreign_probe_verify
CRATE_DIR="${WS}/programs/${CRATE}"
IDL_FILE="${WS}/idls/${IDL_NAME}.json"

# Traits from `anchor_lang::prelude`. The generated accounts, events and types
# modules never name any of them bare.
FRAMEWORK_NAMES=(
    Key Owner Owners Space Id Lamports
    ToAccountInfo ToAccountInfos ToAccountMetas
    AccountsExit AccountsClose DuplicateMutableAccountKeys
)
mapfile -t N < <(printf '%s\n' "${FRAMEWORK_NAMES[@]}" \
    | shuf --random-source=<(yes anchor-foreign-probe))
# N[0..5] are types (0-2 enums, 3-5 structs), N[6..8] accounts, N[9..11] events.

echo "fixture types: ${N[*]:0:6}; accounts: ${N[*]:6:3}; events: ${N[*]:9:3}" >&2

cleanup() {
    rm -rf "${CRATE_DIR}" "${IDL_FILE}"
}
trap cleanup EXIT

mkdir -p "${CRATE_DIR}/src"

defined() { printf '{ "defined": { "name": "%s" } }' "$1"; }

args=()
for i in 0 1 2 3 4 5; do
    args+=("$(printf '{ "name": "arg%d", "type": %s }' "$i" "$(defined "${N[$i]}")")")
done

accounts=()
for i in 6 7 8; do
    accounts+=("$(printf '{ "name": "%s", "discriminator": [%d, 0, 0, 0, 0, 0, 0, 0] }' "${N[$i]}" "$i")")
done

events=()
for i in 9 10 11; do
    events+=("$(printf '{ "name": "%s", "discriminator": [%d, 0, 0, 0, 0, 0, 0, 0] }' "${N[$i]}" "$i")")
done

types=()
for i in 0 1 2; do
    types+=("$(printf '{ "name": "%s", "type": { "kind": "enum", "variants": [{ "name": "Small" }, { "name": "Large" }] } }' "${N[$i]}")")
done
for i in 3 4 5; do
    types+=("$(printf '{ "name": "%s", "type": { "kind": "struct", "fields": [{ "name": "inner", "type": %s }] } }' "${N[$i]}" "$(defined "${N[$((i - 3))]}")")")
done
for i in 6 7 8 9 10 11; do
    types+=("$(printf '{ "name": "%s", "type": { "kind": "struct", "fields": [{ "name": "value", "type": "u64" }] } }' "${N[$i]}")")
done

join() { local IFS=,; echo "$*"; }

# The fixture described in the header above.
cat > "${IDL_FILE}" <<JSON
{
  "address": "11111111111111111111111111111111",
  "metadata": {
    "name": "${IDL_NAME}",
    "version": "0.1.0",
    "spec": "0.1.0",
    "description": "Hand-written foreign interface whose defined type, account and event names each match a framework trait. No source program in this repo."
  },
  "instructions": [
    {
      "name": "probe",
      "discriminator": [0, 0, 0, 0, 0, 0, 0, 0],
      "accounts": [],
      "args": [$(join "${args[@]}")]
    }
  ],
  "accounts": [$(join "${accounts[@]}")],
  "events": [$(join "${events[@]}")],
  "types": [$(join "${types[@]}")]
}
JSON

cat > "${CRATE_DIR}/Cargo.toml" <<'TOML'
[package]
name = "foreign_probe_verify"
version = "0.0.0"
edition = "2021"
publish = false

[lib]
name = "foreign_probe_verify"
path = "src/lib.rs"

[dependencies]
anchor-lang = { path = "../../../../lang" }
TOML

cat > "${CRATE_DIR}/src/lib.rs" <<'RUST'
use anchor_lang::prelude::*;

declare_program!(foreign_probe);
RUST

cd "${WS}"
cargo build -p "${CRATE}"
