#!/usr/bin/env bash
#
# Behavioral check: interface descriptions whose names do not
# match any framework item must keep generating bindings that compile and work.
#
# This builds the repo's existing consumer crate and runs its four test files
# (parsers, generics, error, client_to_account_metas), named one by one so
# test files added next to them are not part of this check. The crate loads a
# current-format description, a legacy-format one, and a large third-party one
# through the program-interface macro, and it uses the generated
# cross-program-call bindings. Its own tests use the generated
# `parsers` module (`Account`, `Event` and `Instruction` parse real bytes), the
# generated client argument and account structs, the generated error enum and
# a generic defined type. A change that breaks general binding generation,
# drops or empties a generated module, or makes a parser stop decoding, makes
# this build or one of these tests fail.
#
# Only the cargo exit code is used.

set -euo pipefail

cd /repo/anchor/tests/declare-program
cargo test -p declare-program \
    --test parsers --test generics --test error --test client_to_account_metas
