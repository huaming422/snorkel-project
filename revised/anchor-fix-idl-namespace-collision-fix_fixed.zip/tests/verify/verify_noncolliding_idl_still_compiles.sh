#!/usr/bin/env bash
#
# Behavioral check: interface descriptions whose names do not
# match any framework item must keep generating bindings that compile.
#
# This builds the repo's existing consumer crate. It loads a current-format
# description, a legacy-format one, and a large third-party one through the
# program-interface macro, and it uses the generated cross-program-call
# bindings. A change that breaks general binding generation, or that only
# patches one emission site, makes this build fail.
#
# Only the cargo exit code is used.

set -euo pipefail

cd /repo/anchor/tests/declare-program
cargo build -p declare-program
