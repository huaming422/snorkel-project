## Task

Our Anchor program stopped building after we added the IDL of a program we CPI into and loaded it with `declare_program!`.
That IDL embeds mpl-core's types, and the compile error lands in the generated code where it uses mpl-core's `Key` enum.
Bindings for our other IDLs still build, and none of our own code changed.
Looks like something in how Anchor generates bindings is off.
Can you track it down and fix it there?
I doubt this is specific to `Key`, so a one-off workaround for this IDL won't cut it.
Code that already uses the generated bindings should keep compiling as it does today.
