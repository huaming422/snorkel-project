## Task

Our Anchor program stopped compiling after we added the IDL of a program we CPI into and loaded it with `declare_program!`.
That IDL pulls in mpl-core's types, including the `Key` enum mpl-core uses as its account discriminator.
The error comes from the generated bindings and not from our own code.
rustc reports E0782 on that `Key` type and suggests adding `dyn`.
Bindings for our other IDLs still build, and nothing else in the project changed.

Find out why the bindings for this IDL don't compile and fix it in Anchor.
The fix should hold for any IDL, not just one that has a type called `Key`.
Don't change the public paths of the generated accounts, events or types.
