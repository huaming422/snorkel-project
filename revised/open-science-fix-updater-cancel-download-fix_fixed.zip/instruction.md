## Task

People keep telling us the updater's Cancel button doesn't cancel anything.
If an update is downloading and you hit Cancel, or close the dialog some other way (the X, a click on the overlay, Escape), the dialog closes while the download carries on in the background.
Reopen the updater later on and the progress has moved past the point where you stopped it.
It happens even if you hit Cancel right after clicking Download, before any progress shows up.

Others run into trouble when they cancel and then start the download again right away.
The retry doesn't start over cleanly, or the installer file it saves ends up missing or corrupt.

Cancel should really stop the download on both of our update paths.
Starting a download again right after a cancel, or after an attempt that failed, should work like a fresh download.
Only one download should run at a time.
A second click on Download while one is running shouldn't disturb it, and it shouldn't start another download either, right away or once the first one stops.
Closing the dialog after a download has finished shouldn't throw that download away.
Please don't add any new third-party dependency for this.
