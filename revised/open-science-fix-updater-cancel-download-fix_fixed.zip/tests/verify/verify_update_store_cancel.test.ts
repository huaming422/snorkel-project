// @vitest-environment jsdom
import { beforeEach, describe, expect, it, vi } from 'vitest'

import { useUpdateStore } from './update-store'

// Electron stubs for the bridge test below, which loads the real `src/preload/index.ts` and the real
// `registerUpdateIpcHandlers` from `src/main/update/ipc.ts`. `contextBridge.exposeInMainWorld` is
// captured so the test can read the bridge object the preload exposes, `ipcRenderer.invoke` is a spy
// so the test sees which channel a bridge method calls, and `ipcMain.handle` records each channel the
// IPC registration wires up. electron-updater is stubbed because the IPC module's strategy imports it
// at load. The store tests touch none of these modules.
const PRELOAD_MOCKS = vi.hoisted(() => ({
  exposeMock: vi.fn(),
  invokeMock: vi.fn((..._args: unknown[]) =>
    Promise.resolve({ state: 'available', current: '0.2.0' })
  ),
  registeredHandlers: new Map<string, (...args: unknown[]) => unknown>()
}))

vi.mock('electron', () => ({
  contextBridge: { exposeInMainWorld: PRELOAD_MOCKS.exposeMock },
  ipcRenderer: {
    invoke: PRELOAD_MOCKS.invokeMock,
    on: vi.fn(),
    off: vi.fn(),
    send: vi.fn(),
    removeListener: vi.fn()
  },
  ipcMain: {
    handle: (channel: string, listener: (...args: unknown[]) => unknown) => {
      PRELOAD_MOCKS.registeredHandlers.set(channel, listener)
    }
  },
  app: { getVersion: () => '0.0.0', getPath: () => '/tmp', isPackaged: false },
  BrowserWindow: { getFocusedWindow: () => null, getAllWindows: () => [] },
  dialog: { showSaveDialog: async () => ({ canceled: true, filePath: undefined }) },
  shell: { openPath: async () => '', openExternal: async () => undefined }
}))

vi.mock('electron-updater', () => ({
  autoUpdater: {},
  CancellationToken: class {
    cancelled = false
    cancel(): void {
      this.cancelled = true
    }
    dispose(): void {}
  }
}))

// Update channels other than the cancel command. The cancel command is the one update:* channel
// outside this list, whatever it is called.
const BASELINE_UPDATE_CHANNELS = new Set([
  'update:get-app-info',
  'update:get-status',
  'update:check',
  'update:download',
  'update:apply'
])

const resetStore = (): void =>
  useUpdateStore.setState({
    appInfo: null,
    status: { state: 'idle', current: '' },
    isDialogOpen: false
  })

// Update bridge methods other than cancel. The cancel method is any other method name on
// window.api.update, so its name is not fixed here: the recording bridge below answers every other
// name with a spy, and a test reads which of those the close path called.
const BASELINE_BRIDGE_METHODS = new Set([
  'getAppInfo',
  'getStatus',
  'check',
  'download',
  'apply',
  'onStatus',
  'onProgress'
])

type BridgeCall = { method: string; result: unknown }

// Installs window.api.update as a recording bridge. The listed methods are inert spies (onStatus and
// onProgress return a no-op unsubscribe; the commands resolve a plain status). Any other method the
// store reads is created on first access as a spy that records the call in `calls` and resolves
// `cancelResult`.
const installRecordingBridge = (cancelResult: unknown): { calls: BridgeCall[] } => {
  const calls: BridgeCall[] = []
  const spies = new Map<string, (...args: unknown[]) => unknown>()
  const base: Record<string, unknown> = {
    getAppInfo: vi.fn(() => Promise.resolve({ name: 'app', version: '0.2.0', copyright: '' })),
    getStatus: vi.fn(() => Promise.resolve({ state: 'idle', current: '0.2.0' })),
    check: vi.fn(() => Promise.resolve({ state: 'available', current: '0.2.0' })),
    download: vi.fn(() => Promise.resolve({ state: 'downloading', current: '0.2.0' })),
    apply: vi.fn(() => Promise.resolve({ state: 'ready', current: '0.2.0' })),
    onStatus: vi.fn(() => () => undefined),
    onProgress: vi.fn(() => () => undefined)
  }
  const update = new Proxy(base, {
    get(target, prop: string) {
      if (prop in target) return target[prop]
      // Any other method name: the cancel method.
      if (!spies.has(prop)) {
        spies.set(
          prop,
          vi.fn((..._args: unknown[]) => {
            calls.push({ method: prop, result: cancelResult })
            return Promise.resolve(cancelResult)
          })
        )
      }
      return spies.get(prop)
    }
  })
  ;(window as unknown as { api: unknown }).api = { update }
  return { calls }
}

describe('useUpdateStore close-dialog cancels the download', () => {
  beforeEach(() => {
    resetStore()
    vi.restoreAllMocks()
  })

  // store_closeDialog_cancels_downloading: closing the dialog while a download is running asks the
  // main process to cancel it. The store's close action (which the dialog's Cancel button, X, overlay
  // and Escape all call) calls the cancel bridge method exactly once, and the dialog closes. The status
  // the renderer shows afterwards comes from main's broadcast and is checked on the main-process side.
  it('store_closeDialog_cancels_downloading: closeDialog aborts an in-flight download', async () => {
    const { calls } = installRecordingBridge({ state: 'available', current: '0.2.0', latest: '0.3.0' })
    useUpdateStore.setState({
      status: { state: 'downloading', current: '0.2.0', latest: '0.3.0', progress: 40 },
      isDialogOpen: true
    })

    useUpdateStore.getState().closeDialog()
    await Promise.resolve()
    await Promise.resolve()

    expect(calls.filter((c) => !BASELINE_BRIDGE_METHODS.has(c.method))).toHaveLength(1)
    expect(useUpdateStore.getState().isDialogOpen).toBe(false)
  })

  // store_closeDialog_cancels_unconditional: Cancel can be hit right after Download, before the
  // renderer has heard that a download started, so its status still reads 'available'. Closing the
  // dialog in that state still calls the cancel bridge method exactly once, and the dialog closes.
  it('store_closeDialog_cancels_unconditional: closeDialog cancels even before the downloading state arrives', async () => {
    const { calls } = installRecordingBridge({ state: 'available', current: '0.2.0' })
    useUpdateStore.setState({
      status: { state: 'available', current: '0.2.0', latest: '0.3.0' },
      isDialogOpen: true
    })

    useUpdateStore.getState().closeDialog()
    await Promise.resolve()
    await Promise.resolve()

    expect(calls.filter((c) => !BASELINE_BRIDGE_METHODS.has(c.method))).toHaveLength(1)
    expect(useUpdateStore.getState().isDialogOpen).toBe(false)
  })
})

describe('preload bridge forwards cancel to the main-process cancel channel', () => {
  // bridge_cancel_forwards_to_main: the cancel method the real preload bridge exposes on
  // window.api.update sends an IPC invoke on the channel the real main-process registration handles
  // for cancel. Neither name is fixed: the bridge method is the one update method outside the list
  // above, and the channel is the one update:* channel outside BASELINE_UPDATE_CHANNELS.
  it('bridge_cancel_forwards_to_main: the preload cancel bridge method invokes the cancel IPC channel', async () => {
    // Load the real IPC registration and preload bridge against the stubbed electron. With context
    // isolation on, the preload exposes its api through exposeInMainWorld, which the stub captures.
    Object.defineProperty(process, 'contextIsolated', { value: true, configurable: true })
    const { registerUpdateIpcHandlers } = await import('../../../main/update/ipc')
    await import('../../../preload/index')

    // The bridge object the preload exposed, and its one update method outside the list above.
    const exposed = PRELOAD_MOCKS.exposeMock.mock.calls.find((call) => call[0] === 'api')?.[1] as
      | { update?: Record<string, unknown> }
      | undefined
    if (!exposed?.update) throw new Error('preload did not expose an "api.update" bridge')
    const newBridgeMethods = Object.keys(exposed.update).filter(
      (method) => !BASELINE_BRIDGE_METHODS.has(method)
    )
    expect(newBridgeMethods).toHaveLength(1)
    const cancelMethod = exposed.update[newBridgeMethods[0]] as () => Promise<unknown>

    // The cancel channel: register the real handlers against the stubbed ipcMain and take the one
    // update:* channel outside BASELINE_UPDATE_CHANNELS.
    PRELOAD_MOCKS.registeredHandlers.clear()
    ;(registerUpdateIpcHandlers as (strategy: unknown) => unknown)({})
    const newChannels = [...PRELOAD_MOCKS.registeredHandlers.keys()].filter(
      (channel) => channel.startsWith('update:') && !BASELINE_UPDATE_CHANNELS.has(channel)
    )
    expect(newChannels).toHaveLength(1)
    const cancelChannel = newChannels[0]

    // Calling the bridge method sends exactly one invoke, on the cancel channel.
    PRELOAD_MOCKS.invokeMock.mockClear()
    await cancelMethod()
    expect(PRELOAD_MOCKS.invokeMock).toHaveBeenCalledTimes(1)
    expect(PRELOAD_MOCKS.invokeMock.mock.calls[0]?.[0]).toBe(cancelChannel)
  })
})
