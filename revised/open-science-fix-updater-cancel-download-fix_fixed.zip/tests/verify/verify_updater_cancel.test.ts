import { createHash } from 'node:crypto'
import { EventEmitter } from 'node:events'
import { existsSync } from 'node:fs'
import { mkdtemp, readFile, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import { afterEach, describe, expect, it, vi } from 'vitest'

// Every case here settles well under a second once the download stops. A per-case cap of a few
// seconds turns a download that never stops into a prompt failure instead of a run-level timeout.
vi.setConfig({ testTimeout: 20000, hookTimeout: 20000 })

// electron is imported transitively (service.ts pulls app/BrowserWindow/dialog/shell; ipc.ts pulls
// ipcMain). Every case injects its own fakes, so the module is stubbed to keep a real Electron runtime
// out of the test process. The ipcMain stub records each channel `registerUpdateIpcHandlers` wires up
// into REGISTERED_HANDLERS, so cancelVia below can call the cancel command by its channel.
const REGISTERED_HANDLERS = vi.hoisted(() => new Map<string, (...args: unknown[]) => unknown>())
vi.mock('electron', () => ({
  app: { getVersion: () => '0.0.0', getPath: () => tmpdir(), isPackaged: false },
  BrowserWindow: { getFocusedWindow: () => null, getAllWindows: () => [] },
  dialog: { showSaveDialog: async () => ({ canceled: true, filePath: undefined }) },
  shell: { openPath: async () => '', openExternal: async () => undefined },
  ipcMain: {
    handle: (channel: string, listener: (...args: unknown[]) => unknown) => {
      REGISTERED_HANDLERS.set(channel, listener)
    }
  }
}))

import type { UpdateManifest } from '../../shared/update'
import { ElectronUpdaterStrategy } from './electron-updater-strategy'
import { registerUpdateIpcHandlers } from './ipc'
import { UpdateService } from './service'

// The in-place strategy imports electron-updater at module load, so the module is stubbed. Its
// CancellationToken stand-in keeps the parts of the library class a strategy uses: an EventEmitter
// with a readable `cancelled` flag that emits 'cancel' when cancelled, and a dispose() that drops
// its listeners. A strategy that injects its own token factory and one that constructs
// `new CancellationToken()` both end up with this class.
vi.mock('electron-updater', () => ({
  autoUpdater: {},
  CancellationToken: class extends EventEmitter {
    cancelled = false
    cancel(): void {
      this.cancelled = true
      this.emit('cancel')
    }
    dispose(): void {
      this.removeAllListeners()
    }
  }
}))

type FakeToken = EventEmitter & { cancelled: boolean; cancel(): void }

// A rejection shaped like electron-updater's cancellation error (name 'CancellationError').
const cancellationError = (): Error => {
  const err = new Error('cancelled')
  err.name = 'CancellationError'
  return err
}

// How long the fake in-place download takes to wind down after its token is cancelled. A real
// cancelled transfer also rejects some time after cancel() returns, not in the same tick.
const CANCEL_TEARDOWN_MS = 20

// An installer body that sends a few bytes and then stalls. It never completes on its own and
// errors a short while after its request signal fires, the way an aborted transfer winds down.
const SLOW_TEARDOWN_MS = 50
const stallingBody = (signal?: AbortSignal): ReadableStream<Uint8Array> =>
  new ReadableStream({
    start(controller) {
      controller.enqueue(new Uint8Array([1, 2, 3]))
      signal?.addEventListener('abort', () =>
        setTimeout(
          () => controller.error(new DOMException('The user aborted a request.', 'AbortError')),
          SLOW_TEARDOWN_MS
        )
      )
    }
  })

// A download in progress: it never completes on its own and rejects with a cancellation error a
// short while after its token is cancelled.
const hangUntilCancelled = (token?: FakeToken): Promise<void> =>
  new Promise<void>((_resolve, reject) => {
    const rejectSoon = (): void => {
      setTimeout(() => reject(cancellationError()), CANCEL_TEARDOWN_MS)
    }
    if (token?.cancelled) return rejectSoon()
    token?.once('cancel', rejectSoon)
  })

// Polls `predicate` every few milliseconds until it holds or the budget runs out, then returns the
// last answer.
const settleWithin = async (predicate: () => boolean, budgetMs = 500): Promise<boolean> => {
  const deadline = Date.now() + budgetMs
  while (Date.now() < deadline) {
    if (predicate()) return true
    await new Promise((resolve) => setTimeout(resolve, 5))
  }
  return predicate()
}

type StatusSource = { getStatus(): { state: string; localPath?: string } }
type BroadcastSpy = ReturnType<typeof vi.fn>

// The state carried by the most recent 'update:status' broadcast, which is what the renderer mirrors.
const lastBroadcastState = (broadcast: BroadcastSpy): string | undefined => {
  const statusCalls = broadcast.mock.calls.filter((call) => call[0] === 'update:status')
  const last = statusCalls[statusCalls.length - 1]
  return (last?.[1] as { state?: string } | undefined)?.state
}

// True once the strategy reports `state` both from getStatus() and in its latest status broadcast.
const settlesTo = (source: StatusSource, broadcast: BroadcastSpy, state: string): Promise<boolean> =>
  settleWithin(() => source.getStatus().state === state && lastBroadcastState(broadcast) === state)

// --- Cancel through the IPC command ---------------------------------------------------------------
// The cancel operation is reached the way the renderer reaches it: through the update command
// channels that `registerUpdateIpcHandlers(strategy)` registers. The cancel command is the one
// update:* channel outside the list below, whatever it is called, so neither the strategy method name
// nor the channel name is fixed here.
const NON_CANCEL_UPDATE_CHANNELS = new Set([
  'update:get-app-info',
  'update:get-status',
  'update:check',
  'update:download',
  'update:apply'
])

// Registers the strategy's IPC handlers against the stubbed ipcMain, finds the cancel command channel
// and invokes it. Throws when there is not exactly one such channel.
const cancelVia = async (strategy: unknown): Promise<unknown> => {
  REGISTERED_HANDLERS.clear()
  ;(registerUpdateIpcHandlers as (s: unknown) => unknown)(strategy)
  const cancelChannels = [...REGISTERED_HANDLERS.keys()].filter(
    (ch) => ch.startsWith('update:') && !NON_CANCEL_UPDATE_CHANNELS.has(ch)
  )
  if (cancelChannels.length !== 1) {
    throw new Error(
      `expected exactly one update:* command channel for cancel, found ${JSON.stringify(cancelChannels)}`
    )
  }
  const handler = REGISTERED_HANDLERS.get(cancelChannels[0])!
  return handler()
}

// Minimal manifest body returned over the fake fetch for the manifest URL.
const jsonResponse = (body: unknown): Response =>
  ({ ok: true, status: 200, json: () => Promise.resolve(body) }) as unknown as Response

// A manifest that advertises a newer version with a single mac-arm64 installer on the same host as
// the manifest URL used below, so the manual-download path accepts it.
const downloadManifest = (size: number, sha256: string): UpdateManifest => ({
  version: '0.3.0',
  releaseDate: '',
  notes: '',
  downloads: {
    'mac-arm64': { url: 'https://statics.aipoch.com/releases/0.3.0/installer.dmg', size, sha256 }
  }
})

// A fetch that always fails, so the in-place strategy's release-notes lookup never reaches a network.
const offlineFetch = (): typeof fetch =>
  vi.fn(async () => {
    throw new Error('no network in test')
  }) as unknown as typeof fetch

// Stand-in for electron-updater's autoUpdater. Like the library's AppUpdater, a downloadUpdate call
// made while a download is still live returns that same live promise and ignores the token it was
// given; the promise clears only once the live download has settled. A cancelled download rejects
// with a cancellation error and fires 'update-cancelled'. The default body completes at once.
class FakeUpdater extends EventEmitter {
  autoDownload = true
  autoInstallOnAppQuit = true
  // Number of downloads that started (calls that returned the live promise don't count).
  starts = 0
  // The body each started download runs. Cases override it to hang until cancelled, to capture the
  // token, to fail, or to behave differently on a later start.
  runDownload: (token?: FakeToken) => Promise<void> = async () => {
    this.emit('download-progress', { percent: 42 })
    this.emit('update-downloaded', { version: '0.3.0' })
  }
  private downloadPromise: Promise<void> | null = null
  checkForUpdates = vi.fn(async () => {
    this.emit('checking-for-update')
    this.emit('update-available', { version: '0.3.0', releaseNotes: 'notes' })
  })
  downloadUpdate = vi.fn((token?: FakeToken): Promise<void> => {
    if (this.downloadPromise != null) return this.downloadPromise
    this.starts += 1
    token?.once('cancel', () => this.emit('update-cancelled'))
    this.downloadPromise = this.runDownload(token).finally(() => {
      this.downloadPromise = null
    })
    return this.downloadPromise
  })
  quitAndInstall = vi.fn()
}

describe('UpdateService cancel/retry (manual-download path)', () => {
  let dir = ''
  afterEach(async () => {
    if (dir) await rm(dir, { recursive: true, force: true })
    dir = ''
  })

  // svc_cancel_aborts: cancelling a running manual download stops the transfer (the hanging fetch only
  // ends when its request signal fires), the status goes back to 'available' with no error, both in
  // getStatus() and in the status broadcast, and no partial installer is left on disk.
  it('svc_cancel_aborts: cancel aborts the in-flight download, resets to available, leaves no partial file', async () => {
    dir = await mkdtemp(join(tmpdir(), 'svc-'))
    const target = join(dir, 'installer.dmg')
    const manifestForCheck = downloadManifest(100, 'irrelevant')
    let onInstallerFetch: (() => void) | undefined
    const fetched = new Promise<void>((resolve) => (onInstallerFetch = resolve))
    const fetchImpl = ((input: unknown, init?: { signal?: AbortSignal }) => {
      if (String(input).endsWith('version.json')) {
        return Promise.resolve(jsonResponse(manifestForCheck))
      }
      const body = new ReadableStream({
        start(controller) {
          controller.enqueue(new Uint8Array([1, 2, 3]))
          init?.signal?.addEventListener('abort', () =>
            controller.error(new DOMException('The user aborted a request.', 'AbortError'))
          )
        }
      })
      onInstallerFetch?.()
      return Promise.resolve(new Response(body, { status: 200 }))
    }) as unknown as typeof fetch
    const broadcast = vi.fn()
    const service = new UpdateService({
      fetchImpl,
      platform: 'darwin',
      arch: 'arm64',
      currentVersion: '0.2.0',
      manifestUrl: 'https://statics.aipoch.com/version.json',
      broadcast,
      promptSavePath: () => Promise.resolve(target)
    })

    await service.check()
    const downloading = service.download()
    await fetched
    await cancelVia(service)
    expect(await settlesTo(service, broadcast, 'available')).toBe(true)

    const final = await downloading
    expect(final.state).toBe('available')
    expect(final.error).toBeUndefined()
    // The partial file may be removed a tick after the download settles, so give it a short window.
    expect(await settleWithin(() => !existsSync(target))).toBe(true)
  })

  // single_download (service): a second download() while one is running starts no second transfer,
  // neither right away nor once the first one is cancelled. After the cancel, exactly one installer
  // request has gone out and the status is 'available'. The second call's own result is not awaited,
  // since returning the current status and sharing the running download's promise are both fine.
  it('single_download (service): a second download() neither starts nor queues a second transfer', async () => {
    dir = await mkdtemp(join(tmpdir(), 'svc-'))
    const target = join(dir, 'installer.dmg')
    const manifestForCheck = downloadManifest(100, 'irrelevant')
    let installerFetches = 0
    let onInstallerFetch: (() => void) | undefined
    const fetched = new Promise<void>((resolve) => (onInstallerFetch = resolve))
    const fetchImpl = ((input: unknown, init?: { signal?: AbortSignal }) => {
      if (String(input).endsWith('version.json')) {
        return Promise.resolve(jsonResponse(manifestForCheck))
      }
      installerFetches += 1
      const body = new ReadableStream({
        start(controller) {
          controller.enqueue(new Uint8Array([1, 2, 3]))
          init?.signal?.addEventListener('abort', () =>
            controller.error(new DOMException('The user aborted a request.', 'AbortError'))
          )
        }
      })
      onInstallerFetch?.()
      return Promise.resolve(new Response(body, { status: 200 }))
    }) as unknown as typeof fetch
    const broadcast = vi.fn()
    const service = new UpdateService({
      fetchImpl,
      platform: 'darwin',
      arch: 'arm64',
      currentVersion: '0.2.0',
      manifestUrl: 'https://statics.aipoch.com/version.json',
      broadcast,
      promptSavePath: () => Promise.resolve(target)
    })

    await service.check()
    const first = service.download()
    await fetched
    void service.download()
    await new Promise((resolve) => setTimeout(resolve, 0))
    expect(installerFetches).toBe(1)

    await cancelVia(service)
    await first
    // Nothing else may start after the cancel.
    await settleWithin(() => installerFetches > 1, 300)
    expect(installerFetches).toBe(1)
    expect(await settlesTo(service, broadcast, 'available')).toBe(true)
  })

  // single_download_after_finish (service): a second download() while one is running does not disturb
  // it and starts nothing once it finishes. The first download completes to 'ready' with its installer
  // on disk, exactly one installer request goes out, and the status stays 'ready'.
  it('single_download_after_finish (service): a second download() during a download starts nothing after it finishes', async () => {
    dir = await mkdtemp(join(tmpdir(), 'svc-'))
    const target = join(dir, 'installer.dmg')
    const body = Buffer.from('installer-bytes')
    const manifestForCheck = downloadManifest(
      body.byteLength,
      createHash('sha256').update(body).digest('hex')
    )
    let installerFetches = 0
    let finishFirstStream: (() => void) | undefined
    let onFirstFetch: (() => void) | undefined
    const firstFetched = new Promise<void>((resolve) => (onFirstFetch = resolve))
    const fetchImpl = ((input: unknown, init?: { signal?: AbortSignal }) => {
      if (String(input).endsWith('version.json')) {
        return Promise.resolve(jsonResponse(manifestForCheck))
      }
      installerFetches += 1
      if (installerFetches === 1) {
        const slow = new ReadableStream({
          start(controller) {
            controller.enqueue(new Uint8Array(body))
            finishFirstStream = () => {
              // The stream may already have ended if the first download was aborted.
              try {
                controller.close()
              } catch {
                // already closed or errored
              }
            }
            init?.signal?.addEventListener('abort', () =>
              controller.error(new DOMException('The user aborted a request.', 'AbortError'))
            )
          }
        })
        onFirstFetch?.()
        return Promise.resolve(new Response(slow, { status: 200 }))
      }
      return Promise.resolve(new Response(body, { status: 200 }))
    }) as unknown as typeof fetch
    const broadcast = vi.fn()
    const service = new UpdateService({
      fetchImpl,
      platform: 'darwin',
      arch: 'arm64',
      currentVersion: '0.2.0',
      manifestUrl: 'https://statics.aipoch.com/version.json',
      broadcast,
      promptSavePath: () => Promise.resolve(target)
    })

    await service.check()
    const first = service.download()
    await firstFetched
    void service.download()
    await new Promise((resolve) => setTimeout(resolve, 50))
    finishFirstStream?.()

    const done = await first
    expect(done.state).toBe('ready')
    // Nothing else may start after the first download finishes.
    await settleWithin(() => installerFetches > 1, 300)
    expect(installerFetches).toBe(1)
    expect(await settlesTo(service, broadcast, 'ready')).toBe(true)
    expect(await readFile(target)).toEqual(body)
  })

  // svc_same_path_retry: a retry to the same destination, started right after a cancel while the
  // cancelled transfer is still winding down, completes to 'ready' and leaves its installer on disk with
  // the right bytes. The cancelled stream ends 50 ms after its abort, so when the retry starts at once
  // the cancelled download's partial-file cleanup overlaps the retry's write.
  it('svc_same_path_retry: a same-path retry survives the cancelled download’s cleanup with correct bytes', async () => {
    dir = await mkdtemp(join(tmpdir(), 'svc-'))
    const target = join(dir, 'installer.dmg')
    const body = Buffer.from('installer-bytes')
    const manifestForCheck = downloadManifest(
      body.byteLength,
      createHash('sha256').update(body).digest('hex')
    )
    let installerFetches = 0
    let onFirstFetch: (() => void) | undefined
    const firstFetched = new Promise<void>((resolve) => (onFirstFetch = resolve))
    const fetchImpl = ((input: unknown, init?: { signal?: AbortSignal }) => {
      if (String(input).endsWith('version.json')) {
        return Promise.resolve(jsonResponse(manifestForCheck))
      }
      installerFetches += 1
      if (installerFetches === 1) {
        onFirstFetch?.()
        return Promise.resolve(new Response(stallingBody(init?.signal), { status: 200 }))
      }
      return Promise.resolve(new Response(body, { status: 200 }))
    }) as unknown as typeof fetch
    const broadcast = vi.fn()
    const service = new UpdateService({
      fetchImpl,
      platform: 'darwin',
      arch: 'arm64',
      currentVersion: '0.2.0',
      manifestUrl: 'https://statics.aipoch.com/version.json',
      broadcast,
      promptSavePath: () => Promise.resolve(target)
    })

    await service.check()
    const first = service.download()
    await firstFetched
    await cancelVia(service)
    expect(await settlesTo(service, broadcast, 'available')).toBe(true)

    const status = await service.download()
    const firstFinal = await first

    expect(installerFetches).toBe(2)
    expect(status.state).toBe('ready')
    expect(existsSync(target)).toBe(true)
    expect(await readFile(target)).toEqual(body)
    expect(firstFinal.error).toBeUndefined()
  })

  // svc_repeated_cancel_retry: cancel and retry twice in a row to the same destination, each retry
  // started right away. Each cancelled stream ends 50 ms after its abort, so its partial-file cleanup
  // overlaps the next download. The third download still completes to 'ready' with the right bytes.
  // The middle download really starts before it is cancelled.
  it('svc_repeated_cancel_retry: a second cancel-and-retry cycle to the same path keeps the final installer', async () => {
    dir = await mkdtemp(join(tmpdir(), 'svc-'))
    const target = join(dir, 'installer.dmg')
    const body = Buffer.from('third-installer-bytes')
    const manifestForCheck = downloadManifest(
      body.byteLength,
      createHash('sha256').update(body).digest('hex')
    )
    let installerFetches = 0
    const fetchImpl = ((input: unknown, init?: { signal?: AbortSignal }) => {
      if (String(input).endsWith('version.json')) {
        return Promise.resolve(jsonResponse(manifestForCheck))
      }
      installerFetches += 1
      if (installerFetches <= 2) {
        return Promise.resolve(new Response(stallingBody(init?.signal), { status: 200 }))
      }
      return Promise.resolve(new Response(body, { status: 200 }))
    }) as unknown as typeof fetch
    const broadcast = vi.fn()
    const service = new UpdateService({
      fetchImpl,
      platform: 'darwin',
      arch: 'arm64',
      currentVersion: '0.2.0',
      manifestUrl: 'https://statics.aipoch.com/version.json',
      broadcast,
      promptSavePath: () => Promise.resolve(target)
    })

    await service.check()
    const first = service.download()
    expect(await settleWithin(() => installerFetches === 1)).toBe(true)
    await cancelVia(service)
    expect(await settlesTo(service, broadcast, 'available')).toBe(true)

    const second = service.download()
    expect(await settleWithin(() => installerFetches === 2)).toBe(true)
    await cancelVia(service)
    expect(await settlesTo(service, broadcast, 'available')).toBe(true)

    const status = await service.download()
    await first
    await second

    expect(installerFetches).toBe(3)
    expect(status.state).toBe('ready')
    expect(await readFile(target)).toEqual(body)
  })

  // svc_second_cancel_stops_retry: cancel, start a retry, then cancel again right away. The second
  // cancel stops the retry: it ends 'available', never 'ready', and no installer is left on disk. Every
  // installer stream here only ends when its own request signal fires, so a retry the second cancel did
  // not reach never settles. How many requests the retry made before it was stopped is not checked.
  it('svc_second_cancel_stops_retry: a cancel right after a retry stops it, no download completes', async () => {
    dir = await mkdtemp(join(tmpdir(), 'svc-'))
    const target = join(dir, 'installer.dmg')
    const manifestForCheck = downloadManifest(100, 'irrelevant')
    let onFirstFetch: (() => void) | undefined
    const firstFetched = new Promise<void>((resolve) => (onFirstFetch = resolve))
    const fetchImpl = ((input: unknown, init?: { signal?: AbortSignal }) => {
      if (String(input).endsWith('version.json')) {
        return Promise.resolve(jsonResponse(manifestForCheck))
      }
      const hanging = new ReadableStream({
        start(controller) {
          controller.enqueue(new Uint8Array([1, 2, 3]))
          init?.signal?.addEventListener('abort', () =>
            controller.error(new DOMException('The user aborted a request.', 'AbortError'))
          )
        }
      })
      onFirstFetch?.()
      return Promise.resolve(new Response(hanging, { status: 200 }))
    }) as unknown as typeof fetch
    const broadcast = vi.fn()
    const service = new UpdateService({
      fetchImpl,
      platform: 'darwin',
      arch: 'arm64',
      currentVersion: '0.2.0',
      manifestUrl: 'https://statics.aipoch.com/version.json',
      broadcast,
      promptSavePath: () => Promise.resolve(target)
    })

    await service.check()
    const first = service.download()
    await firstFetched
    await cancelVia(service)
    expect(await settlesTo(service, broadcast, 'available')).toBe(true)

    const retry = service.download()
    await new Promise((resolve) => setTimeout(resolve, 0))
    await cancelVia(service)
    expect(await settlesTo(service, broadcast, 'available')).toBe(true)

    const status = await retry
    await first
    expect(status.state).toBe('available')
    expect(existsSync(target)).toBe(false)
  })

  // svc_retry_after_failure: when the save-location prompt throws, that attempt doesn't report a
  // download (download() may reject or settle on a non-success status) and the status is not left at
  // 'downloading'. A later download() then reopens the prompt and completes normally.
  it('svc_retry_after_failure: a later download() works after the save prompt throws', async () => {
    dir = await mkdtemp(join(tmpdir(), 'svc-'))
    const target = join(dir, 'installer.dmg')
    const body = Buffer.from('installer-bytes')
    const manifestForCheck = downloadManifest(
      body.byteLength,
      createHash('sha256').update(body).digest('hex')
    )
    const fetchImpl = ((input: unknown) =>
      String(input).endsWith('version.json')
        ? Promise.resolve(jsonResponse(manifestForCheck))
        : Promise.resolve(new Response(body, { status: 200 }))) as unknown as typeof fetch
    let saveCall = 0
    const service = new UpdateService({
      fetchImpl,
      platform: 'darwin',
      arch: 'arm64',
      currentVersion: '0.2.0',
      manifestUrl: 'https://statics.aipoch.com/version.json',
      broadcast: vi.fn(),
      promptSavePath: () =>
        saveCall++ === 0 ? Promise.reject(new Error('dialog failed')) : Promise.resolve(target)
    })

    await service.check()
    let failedState: string | undefined
    let rejected = false
    try {
      failedState = (await service.download()).state
    } catch {
      rejected = true
    }
    if (!rejected) expect(['ready', 'downloading']).not.toContain(failedState)
    expect(service.getStatus().state).not.toBe('downloading')

    const retry = await service.download()
    expect(saveCall).toBe(2)
    expect(retry.state).toBe('ready')
    expect(retry.localPath).toBe(target)
    expect(existsSync(target)).toBe(true)
  })

  // svc_cancel_keeps_finished: a cancel after the download has finished leaves it alone. The status
  // stays 'ready' with the same local path, and the installer stays on disk.
  it('svc_cancel_keeps_finished: cancel after a finished download keeps it ready', async () => {
    dir = await mkdtemp(join(tmpdir(), 'svc-'))
    const target = join(dir, 'installer.dmg')
    const body = Buffer.from('finished-installer')
    const manifestForCheck = downloadManifest(
      body.byteLength,
      createHash('sha256').update(body).digest('hex')
    )
    const fetchImpl = ((input: unknown) =>
      String(input).endsWith('version.json')
        ? Promise.resolve(jsonResponse(manifestForCheck))
        : Promise.resolve(new Response(body, { status: 200 }))) as unknown as typeof fetch
    const broadcast = vi.fn()
    const service = new UpdateService({
      fetchImpl,
      platform: 'darwin',
      arch: 'arm64',
      currentVersion: '0.2.0',
      manifestUrl: 'https://statics.aipoch.com/version.json',
      broadcast,
      promptSavePath: () => Promise.resolve(target)
    })

    await service.check()
    const done = await service.download()
    expect(done.state).toBe('ready')

    await cancelVia(service)
    await settleWithin(() => service.getStatus().state !== 'ready', 200)
    expect(service.getStatus().state).toBe('ready')
    expect(service.getStatus().localPath).toBe(target)
    expect(lastBroadcastState(broadcast)).toBe('ready')
    expect(await readFile(target)).toEqual(body)
  })

  // cancel_noop_when_idle (service): a cancel when nothing is downloading leaves 'available' as is.
  it('cancel_noop_when_idle (service): cancel is a no-op when nothing is downloading', async () => {
    const manifestForCheck = downloadManifest(5, 'h')
    const fetchImpl = (() =>
      Promise.resolve(jsonResponse(manifestForCheck))) as unknown as typeof fetch
    const broadcast = vi.fn()
    const service = new UpdateService({
      fetchImpl,
      platform: 'darwin',
      arch: 'arm64',
      currentVersion: '0.2.0',
      manifestUrl: 'https://statics.aipoch.com/version.json',
      broadcast,
      promptSavePath: () => Promise.resolve(null)
    })

    await service.check()
    await cancelVia(service)
    expect(await settlesTo(service, broadcast, 'available')).toBe(true)
  })
})

describe('ElectronUpdaterStrategy cancel/retry (in-place path)', () => {
  // electron_cancel_resets: cancelling a running in-place download cancels the token the strategy
  // handed to the updater, the status goes back to 'available' (getStatus() and the broadcast), and the
  // cancelled download's rejection does not turn it into an error.
  it('electron_cancel_resets: cancel aborts the in-flight download and resets to available', async () => {
    const updater = new FakeUpdater()
    let seenToken: FakeToken | undefined
    updater.runDownload = (token) => {
      seenToken = token
      return hangUntilCancelled(token)
    }
    const broadcast = vi.fn()
    const strategy = new ElectronUpdaterStrategy({
      updater,
      currentVersion: '0.2.0',
      broadcast,
      fetchImpl: offlineFetch()
    })
    await strategy.check()

    const downloading = strategy.download()
    await cancelVia(strategy)
    expect(seenToken?.cancelled).toBe(true)
    expect(await settlesTo(strategy, broadcast, 'available')).toBe(true)

    const final = await downloading
    expect(final.state).toBe('available')
    expect(final.error).toBeUndefined()
  })

  // single_download (electron): a second download() while one is running keeps the first download
  // cancellable and starts no second download, neither right away nor after the cancel. One cancel
  // settles the first download() call, the status returns to 'available', and the updater has started
  // exactly one download.
  it('single_download (electron): a second download() neither starts nor queues a second download', async () => {
    const updater = new FakeUpdater()
    updater.runDownload = (token) => hangUntilCancelled(token)
    const broadcast = vi.fn()
    const strategy = new ElectronUpdaterStrategy({
      updater,
      currentVersion: '0.2.0',
      broadcast,
      fetchImpl: offlineFetch()
    })
    await strategy.check()

    let settled = false
    const first = strategy.download().finally(() => {
      settled = true
    })
    void strategy.download()
    expect(updater.starts).toBe(1)

    void cancelVia(strategy)
    expect(await settleWithin(() => settled)).toBe(true)
    await first.catch(() => undefined)
    // Nothing else may start after the cancel.
    await settleWithin(() => updater.starts > 1, 300)
    expect(updater.starts).toBe(1)
    expect(await settlesTo(strategy, broadcast, 'available')).toBe(true)
  })

  // single_download_after_finish (electron): a second download() while one is running does not
  // disturb it and starts nothing once it finishes. The first download() settles 'ready', the updater
  // has started exactly one download, and the status stays 'ready'. The running download honors its
  // token, so cancelling it from the second call would show up as a failed first download.
  it('single_download_after_finish (electron): a second download() during a download starts nothing after it finishes', async () => {
    const updater = new FakeUpdater()
    let finishFirst: (() => void) | undefined
    updater.runDownload = (token) =>
      new Promise<void>((resolve, reject) => {
        finishFirst = () => {
          updater.emit('download-progress', { percent: 100 })
          updater.emit('update-downloaded', { version: '0.3.0' })
          resolve()
        }
        token?.once('cancel', () =>
          setTimeout(() => reject(cancellationError()), CANCEL_TEARDOWN_MS)
        )
      })
    const broadcast = vi.fn()
    const strategy = new ElectronUpdaterStrategy({
      updater,
      currentVersion: '0.2.0',
      broadcast,
      fetchImpl: offlineFetch()
    })
    await strategy.check()

    const first = strategy.download()
    void strategy.download()
    expect(updater.starts).toBe(1)
    await new Promise((resolve) => setTimeout(resolve, 50))
    finishFirst?.()

    const done = await first
    expect(done.state).toBe('ready')
    // Nothing else may start after the first download finishes.
    await settleWithin(() => updater.starts > 1, 300)
    expect(updater.starts).toBe(1)
    expect(await settlesTo(strategy, broadcast, 'ready')).toBe(true)
  })

  // electron_retry_starts_fresh: a download started right after a cancel, once the status reads
  // 'available', is a new download that reaches 'ready'. The cancelled download is still winding down
  // at that point, and a call that lands on it would get its cancellation instead.
  it('electron_retry_starts_fresh: cancel then immediate retry starts a genuine second download', async () => {
    const updater = new FakeUpdater()
    updater.runDownload = (token) => {
      if (updater.starts === 1) return hangUntilCancelled(token)
      updater.emit('download-progress', { percent: 55 })
      updater.emit('update-downloaded', { version: '0.3.0' })
      return Promise.resolve()
    }
    const broadcast = vi.fn()
    const strategy = new ElectronUpdaterStrategy({
      updater,
      currentVersion: '0.2.0',
      broadcast,
      fetchImpl: offlineFetch()
    })
    await strategy.check()

    const first = strategy.download()
    await cancelVia(strategy)
    expect(await settlesTo(strategy, broadcast, 'available')).toBe(true)

    const retry = await strategy.download()
    expect(retry.state).toBe('ready')
    expect(updater.starts).toBe(2)

    const firstFinal = await first
    expect(firstFinal.error).toBeUndefined()
  })

  // electron_repeated_cancel_retry: cancel and retry twice in a row. The second download really
  // starts, gets cancelled, and a third download started right after that is a new download that
  // reaches 'ready', even though the second one is still winding down when it is requested.
  it('electron_repeated_cancel_retry: a second cancel-and-retry cycle also starts a genuine new download', async () => {
    const updater = new FakeUpdater()
    updater.runDownload = (token) => {
      if (updater.starts < 3) return hangUntilCancelled(token)
      updater.emit('download-progress', { percent: 60 })
      updater.emit('update-downloaded', { version: '0.3.0' })
      return Promise.resolve()
    }
    const broadcast = vi.fn()
    const strategy = new ElectronUpdaterStrategy({
      updater,
      currentVersion: '0.2.0',
      broadcast,
      fetchImpl: offlineFetch()
    })
    await strategy.check()

    const first = strategy.download()
    await cancelVia(strategy)
    expect(await settlesTo(strategy, broadcast, 'available')).toBe(true)

    const second = strategy.download()
    expect(await settleWithin(() => updater.starts === 2)).toBe(true)
    await cancelVia(strategy)
    expect(await settlesTo(strategy, broadcast, 'available')).toBe(true)

    const third = await strategy.download()
    expect(third.state).toBe('ready')
    expect(updater.starts).toBe(3)

    await first
    await second
  })

  // electron_second_cancel_stops_retry: cancel, start a retry, then cancel again right away. The second
  // cancel stops the retry, which ends 'available' and never 'ready'.
  it('electron_second_cancel_stops_retry: a cancel right after a retry stops it, no download completes', async () => {
    const updater = new FakeUpdater()
    updater.runDownload = (token) => hangUntilCancelled(token)
    const broadcast = vi.fn()
    const strategy = new ElectronUpdaterStrategy({
      updater,
      currentVersion: '0.2.0',
      broadcast,
      fetchImpl: offlineFetch()
    })
    await strategy.check()

    const first = strategy.download()
    await cancelVia(strategy)
    expect(await settlesTo(strategy, broadcast, 'available')).toBe(true)

    const retry = strategy.download()
    await new Promise((resolve) => setTimeout(resolve, 0))
    await cancelVia(strategy)
    expect(await settlesTo(strategy, broadcast, 'available')).toBe(true)

    const status = await retry
    expect(status.state).toBe('available')
    await first
  })

  // electron_retry_after_failure: when a download fails with a real error, that attempt doesn't report
  // a download, and a later download() starts a new one that reaches 'ready'.
  it('electron_retry_after_failure: a later download() works after a failed download', async () => {
    const updater = new FakeUpdater()
    updater.runDownload = () => {
      if (updater.starts === 1) return Promise.reject(new Error('network down'))
      updater.emit('download-progress', { percent: 70 })
      updater.emit('update-downloaded', { version: '0.3.0' })
      return Promise.resolve()
    }
    const strategy = new ElectronUpdaterStrategy({
      updater,
      currentVersion: '0.2.0',
      broadcast: vi.fn(),
      fetchImpl: offlineFetch()
    })
    await strategy.check()

    const failed = await strategy.download()
    expect(['ready', 'downloading']).not.toContain(failed.state)

    const retry = await strategy.download()
    expect(retry.state).toBe('ready')
    expect(updater.starts).toBe(2)
  })

  // electron_cancel_keeps_finished: a cancel after the download has finished leaves the status at
  // 'ready', so the update can still be installed.
  it('electron_cancel_keeps_finished: cancel after a finished download keeps it ready', async () => {
    const updater = new FakeUpdater()
    const broadcast = vi.fn()
    const strategy = new ElectronUpdaterStrategy({
      updater,
      currentVersion: '0.2.0',
      broadcast,
      fetchImpl: offlineFetch()
    })
    await strategy.check()

    const done = await strategy.download()
    expect(done.state).toBe('ready')

    await cancelVia(strategy)
    await settleWithin(() => strategy.getStatus().state !== 'ready', 200)
    expect(strategy.getStatus().state).toBe('ready')
    expect(lastBroadcastState(broadcast)).toBe('ready')
  })

  // cancel_noop_when_idle (electron): a cancel when nothing is downloading leaves 'available' as is.
  it('cancel_noop_when_idle (electron): cancel is a no-op when nothing is downloading', async () => {
    const updater = new FakeUpdater()
    const broadcast = vi.fn()
    const strategy = new ElectronUpdaterStrategy({
      updater,
      currentVersion: '0.2.0',
      broadcast,
      fetchImpl: offlineFetch()
    })
    await strategy.check()
    await cancelVia(strategy)
    expect(await settlesTo(strategy, broadcast, 'available')).toBe(true)
  })
})
