#!/usr/bin/env bash
# Environment bootstrap for the verifier (runs with network available).
#
# Sourced (not exec'd) by the harbor runner so env vars set here stay live for
# the verifier subprocess.
#
# The vitest suite runs TypeScript sources directly (no dist/ build step for the
# update subsystem under test). node_modules is already baked into the image at
# the pinned commit via `npm ci` (image Dockerfile block 10), so this script
# installs nothing in the normal case. The coding phase runs offline, and everything the
# verifier needs is present. The canonical verifier interpreter is Python 3.12
# (VERIFIER_PYTHON), whose stdlib includes tomllib, so verify.toml parsing needs
# no extra package here.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/open-science}"
export REPO_DIR
cd "$REPO_DIR"

# Sanity check: vitest must be resolvable from the repo root. It is baked into
# node_modules at the base commit, so this is only a safety net for a corrupted
# store. Reinstall offline-first (npm's cache is warm from the image build);
# fall back to an online install with the output logged. This is the verifier
# phase, which has network; the coding phase never runs this script.
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest missing from node_modules/.bin/; reinstalling from lockfile." >&2
    npm ci --offline > /tmp/npm-ci.log 2>&1 \
        || npm ci > /tmp/npm-ci.log 2>&1 \
        || { echo "test-setup.sh: npm ci failed:" >&2; tail -80 /tmp/npm-ci.log >&2; exit 1; }
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
