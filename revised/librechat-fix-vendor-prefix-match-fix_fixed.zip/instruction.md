## Task

We run models through OpenAI-compatible and OpenRouter-style gateways, and two problems show up only when a model is named by its vendor-prefixed id (`vendor/model`).
Our case is `moonshotai/kimi-k2` on an endpoint with no token config of its own, so LibreChat's built-in windows and prices apply.
The Groq and Together spellings, `moonshotai/kimi-k2-instruct` and `moonshotai/Kimi-K2-Instruct`, hit the same thing.
Naming the model by its bare id (`kimi-k2`), or by a dot-separated id like `moonshot.kimi-k2` or `us.anthropic.claude-3-5-sonnet-20241022-v2:0`, works fine.

The first problem is lost context.
In a long chat with big tool results, the assistant suddenly replies as if the history were gone and only the latest system message reached it.
This starts at about half of the model's real window, long before the chat should need trimming.
With the bare id the history holds up to the expected point.

The second problem is billing.
The prefixed id is charged more per token than the bare id, for prompt and completion alike, and its cache reads and writes are not priced the way the bare id's are.
The two problems move together: whatever window the prefixed id ends up with, its price comes from the same place.

What we expect after the fix:

- A `vendor/model` id whose part after the slash is a model LibreChat knows gets that model's built-in context window and prices, the same as the bare id.
- The window works the same way when it comes from an endpoint's token config, so `acme/nova` gets the window of the `nova` entry, not of an `acme` entry.
- When the part after the slash is not a model LibreChat knows by itself, as with `moonshot/v1-8k`, the id keeps the context window it gets today instead of ending up with none.
- When an endpoint's token config has an entry under the full `vendor/model` id, as a model list fetched from OpenRouter does, that entry keeps setting the context window for that id and for longer ids that start with it, like a `-latest` build, even if the config also has an entry for the bare model name.
- Bare ids and dot-separated ids keep the windows and prices they get now.

Fix the cause, and keep the way callers ask for a model's window or price as it is.
