## Task

We run models through OpenAI-compatible and OpenRouter-style gateways, some of them behind a proxy that adds its own prefix, and two problems show up only when a model is named by a vendor-prefixed id.
Our case is `moonshotai/kimi-k2` on an endpoint with no token config of its own, so LibreChat's built-in windows and prices apply.
The Groq and Together spellings, `moonshotai/kimi-k2-instruct` and `moonshotai/Kimi-K2-Instruct`, hit the same thing, and so does the id our proxy sends on, `openrouter/moonshotai/kimi-k2`.
Naming the model by its bare id (`kimi-k2`), or by a dot-separated id like `moonshot.kimi-k2` or `us.anthropic.claude-3-5-sonnet-20241022-v2:0`, works fine.

The first problem is lost context.
In a long chat with big tool results, the assistant suddenly replies as if the history were gone and only the latest system message reached it.
This starts at about half of the model's real window, long before the chat should need trimming.
With the bare id the history holds up to the expected point.

The second problem is billing.
The prefixed id is charged more per token than the bare id, for prompt and completion alike, and its cache reads and writes are not priced the way the bare id's are.
The two problems move together: whatever window the prefixed id ends up with, its price comes from the same place.

What we expect after the fix:

- The model a prefixed id names is the part after its last slash, however many prefixes come before it.
- With no token config in play, a prefixed id whose model part gets a built-in window as a bare id gets that same window and the bare id's prices.
- An endpoint's token config is still read before the built-in tables, and the same rule holds inside it: `acme/nova` takes the window of the `nova` entry, not of an `acme` entry.
- When the model part matches nothing on its own in the table being read, the id keeps the window it gets now.
- Any id that picks up a token config entry listed under a full `vendor/model` id today, the way a model list fetched from OpenRouter is keyed, keeps getting it, even when the same config also lists the bare model name.
- Bare and dot-separated ids keep the windows and prices they get now.

Fix the cause, and keep the way callers ask for a model's window or price as it is.
