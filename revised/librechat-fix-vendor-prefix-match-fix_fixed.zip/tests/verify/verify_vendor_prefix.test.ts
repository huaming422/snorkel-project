/**
 * Behavioral checks for vendor-prefixed (`vendor/model`) model-id resolution.
 *
 * Everything is asserted through the library's public entry points:
 *   - `getModelMaxTokens(modelName, endpoint, endpointTokenConfig?)` from
 *     `@librechat/api` for the context window, and
 *   - `getMultiplier` / `getCacheMultiplier` built by
 *     `createTxMethods(...)` from `@librechat/data-schemas`, wired with the
 *     model-lookup functions the app passes in (api/models), for pricing, and
 *   - `buildTokenConfigMap`, which resolves the window and rates the server
 *     sends to the client for every configured model.
 *
 * No signature changes; only the resolved windows and rates are compared.
 */
import { EModelEndpoint } from 'librechat-data-provider';
import { createTxMethods } from '@librechat/data-schemas';
import type { EndpointTokenConfig } from '~/types';
import { matchModelName, findMatchingPattern, getModelMaxTokens } from './tokens';
import { buildTokenConfigMap } from '../endpoints/pricing';

/**
 * Pricing methods built with the same lookup functions the app injects in
 * api/models. These lookups never touch the mongoose connection.
 */
const { getValueKey, getMultiplier, getCacheMultiplier } = createTxMethods(
  {} as typeof import('mongoose'),
  {
    matchModelName: (model: string, endpoint?: string) =>
      matchModelName(model, endpoint as EModelEndpoint),
    findMatchingPattern: (model: string, values) =>
      findMatchingPattern(model, values as Record<string, number>) ?? undefined,
  },
);

const ENDPOINTS = [EModelEndpoint.openAI, EModelEndpoint.custom, EModelEndpoint.agents];

/** Every rate a request is billed with: prompt, completion, cache write, cache read. */
function rates(model: string) {
  return {
    prompt: getMultiplier({ model, tokenType: 'prompt' }),
    completion: getMultiplier({ model, tokenType: 'completion' }),
    cacheWrite: getCacheMultiplier({ model, cacheType: 'write' }),
    cacheRead: getCacheMultiplier({ model, cacheType: 'read' }),
  };
}

const KIMI_K2_RATES = { prompt: 0.6, completion: 2.5, cacheWrite: 0.6, cacheRead: 0.15 };
const MOONSHOT_RATES = { prompt: 2.0, completion: 5.0, cacheWrite: null, cacheRead: null };

/**
 * Prefixed spellings of Kimi K2 as gateways list it (OpenRouter, Groq, Together),
 * and as a proxy in front of those gateways passes them on, with its own prefix.
 */
const PREFIXED_KIMI_K2 = [
  'moonshotai/kimi-k2',
  'moonshot/kimi-k2',
  'moonshotai/Kimi-K2-Instruct',
  'moonshotai/kimi-k2-instruct-0905',
  'openrouter/moonshotai/kimi-k2',
  'groq/moonshotai/kimi-k2-instruct',
  'together_ai/moonshotai/Kimi-K2-Instruct',
];

describe('vendor-prefixed model resolution', () => {
  it('context window of a prefixed id is the window of its model part', () => {
    for (const endpoint of ENDPOINTS) {
      for (const id of PREFIXED_KIMI_K2) {
        expect([id, endpoint, getModelMaxTokens(id, endpoint)]).toEqual([id, endpoint, 262144]);
      }
    }
    expect(getModelMaxTokens('moonshotai/kimi-k2')).toBe(262144);
  });

  it('prices of a prefixed id are the prices of its model part', () => {
    for (const id of PREFIXED_KIMI_K2) {
      expect([id, rates(id)]).toEqual([id, KIMI_K2_RATES]);
    }
  });

  it('prefixed ids resolve by their model part in an endpoint token config too', () => {
    const config = {
      northwind: { prompt: 1, completion: 2, context: 16000 },
      gale: { prompt: 3, completion: 4, context: 400000 },
      'sundial-labs': { prompt: 5, completion: 6, context: 32000 },
      'ember-2': { prompt: 7, completion: 8, context: 640000 },
    } as EndpointTokenConfig;
    expect(getModelMaxTokens('northwind/gale', EModelEndpoint.custom, config)).toBe(400000);
    expect(getModelMaxTokens('sundial-labs/ember-2', EModelEndpoint.custom, config)).toBe(640000);
    expect(getModelMaxTokens('sundial-labs/ember-2-preview', EModelEndpoint.custom, config)).toBe(
      640000,
    );
    // The same ids passed on by a proxy that adds its own prefix.
    expect(getModelMaxTokens('relay/northwind/gale', EModelEndpoint.custom, config)).toBe(400000);
    expect(
      getModelMaxTokens('relay/sundial-labs/ember-2-preview', EModelEndpoint.custom, config),
    ).toBe(640000);
    // An unknown model part keeps the vendor entry it resolves to today.
    expect(getModelMaxTokens('northwind/breeze', EModelEndpoint.custom, config)).toBe(16000);
    expect(getModelMaxTokens('relay/northwind/breeze', EModelEndpoint.custom, config)).toBe(16000);
    // Bare ids in the same config keep their own entries.
    expect(getModelMaxTokens('northwind', EModelEndpoint.custom, config)).toBe(16000);
    expect(getModelMaxTokens('gale', EModelEndpoint.custom, config)).toBe(400000);
  });

  it('a prefixed id whose model part is not a known model keeps its current window', () => {
    for (const endpoint of ENDPOINTS) {
      for (const id of ['moonshot/v1-8k', 'openrouter/moonshot/v1-8k']) {
        expect([id, endpoint, getModelMaxTokens(id, endpoint)]).toEqual([id, endpoint, 131072]);
      }
    }
  });

  it('an id that picks up a full vendor/model token config entry today keeps it', () => {
    const openrouter = {
      'openrouter/foo': { prompt: 1, completion: 2, context: 900000, output: 1 },
      foo: { prompt: 1, completion: 2, context: 1000, output: 1 },
    } as EndpointTokenConfig;
    expect(getModelMaxTokens('openrouter/foo', EModelEndpoint.custom, openrouter)).toBe(900000);
    expect(getModelMaxTokens('openrouter/foo-latest', EModelEndpoint.custom, openrouter)).toBe(
      900000,
    );
    // Another vendor has no full-id entry, so the bare key applies.
    expect(getModelMaxTokens('other/foo-latest', EModelEndpoint.custom, openrouter)).toBe(1000);

    const acme = {
      'acme/orion': { prompt: 1, completion: 2, context: 777000 },
      orion: { prompt: 1, completion: 2, context: 2000 },
    } as EndpointTokenConfig;
    expect(getModelMaxTokens('acme/orion-2025-01', EModelEndpoint.custom, acme)).toBe(777000);
    expect(getModelMaxTokens('beta/orion-2025-01', EModelEndpoint.custom, acme)).toBe(2000);

    // A bare entry for one dated build sits next to the full-id entry.
    const acmeDated = {
      'acme/orion': { prompt: 1, completion: 2, context: 777000 },
      'orion-2025-01': { prompt: 1, completion: 2, context: 64000 },
    } as EndpointTokenConfig;
    expect(getModelMaxTokens('acme/orion-2025-01', EModelEndpoint.custom, acmeDated)).toBe(64000);
    expect(getModelMaxTokens('acme/orion-2025-02', EModelEndpoint.custom, acmeDated)).toBe(777000);

    // A model list keyed only by full ids, as fetched from OpenRouter.
    const fetched = {
      'moonshotai/kimi-k2': { prompt: 0.5, completion: 2.2, context: 100000 },
      'qwen/qwen3-coder': { prompt: 0.3, completion: 1.2, context: 300000 },
    } as EndpointTokenConfig;
    expect(getModelMaxTokens('moonshotai/kimi-k2-0905', EModelEndpoint.custom, fetched)).toBe(
      100000,
    );
    expect(getModelMaxTokens('qwen/qwen3-coder-latest', EModelEndpoint.custom, fetched)).toBe(
      300000,
    );

    // The same entries reached through a proxy prefix or in another letter case.
    expect(
      getModelMaxTokens('openrouter/moonshotai/kimi-k2-0905', EModelEndpoint.custom, fetched),
    ).toBe(100000);
    expect(getModelMaxTokens('MoonshotAI/Kimi-K2-0905', EModelEndpoint.custom, fetched)).toBe(
      100000,
    );
    expect(getModelMaxTokens('relay/acme/orion-2025-01', EModelEndpoint.custom, acme)).toBe(
      777000,
    );
    expect(
      getModelMaxTokens('relay/openrouter/foo-latest', EModelEndpoint.custom, openrouter),
    ).toBe(900000);
  });

  it('the server-built token config map shows the model part window and prices', () => {
    const map = buildTokenConfigMap(
      {
        modelsConfig: {
          [EModelEndpoint.openAI]: ['moonshotai/kimi-k2', 'kimi-k2', 'moonshot', 'moonshot/v1-8k'],
          Gateway: [
            'moonshotai/Kimi-K2-Instruct',
            'moonshotai/kimi-k2-instruct-0905',
            'moonshot.kimi-k2',
            'openrouter/moonshotai/kimi-k2',
            'openrouter/moonshot/v1-8k',
          ],
        },
        includePricing: true,
      },
      { getValueKey, getMultiplier, getCacheMultiplier },
    );
    const kimi = { context: 262144, ...KIMI_K2_RATES };
    expect(map[EModelEndpoint.openAI]['moonshotai/kimi-k2']).toEqual(kimi);
    expect(map[EModelEndpoint.openAI]['kimi-k2']).toEqual(kimi);
    expect(map.Gateway['moonshotai/Kimi-K2-Instruct']).toEqual(kimi);
    expect(map.Gateway['moonshotai/kimi-k2-instruct-0905']).toEqual(kimi);
    expect(map.Gateway['openrouter/moonshotai/kimi-k2']).toEqual(kimi);
    expect(map.Gateway['openrouter/moonshot/v1-8k'].context).toBe(131072);
    expect(map[EModelEndpoint.openAI].moonshot).toEqual({ context: 131072, prompt: 2.0, completion: 5.0 });
    expect(map[EModelEndpoint.openAI]['moonshot/v1-8k'].context).toBe(131072);
    expect(map.Gateway['moonshot.kimi-k2']).toEqual({ context: 262144, prompt: 0.6, completion: 2.5 });
  });

  it('dot-separated and unprefixed ids are unchanged', () => {
    expect(getModelMaxTokens('moonshot.kimi-k2-thinking', EModelEndpoint.bedrock)).toBe(262144);
    expect(getModelMaxTokens('moonshot.kimi-k2', EModelEndpoint.bedrock)).toBe(262144);
    expect(getModelMaxTokens('us.anthropic.claude-3-5-sonnet-20241022-v2:0')).toBe(200000);
    expect(getModelMaxTokens('kimi-k2', EModelEndpoint.openAI)).toBe(262144);
    expect(getModelMaxTokens('moonshot', EModelEndpoint.openAI)).toBe(131072);
    expect(rates('kimi-k2')).toEqual(KIMI_K2_RATES);
    expect(rates('moonshot')).toEqual(MOONSHOT_RATES);
    expect(rates('moonshot.kimi-k2')).toEqual({
      prompt: 0.6,
      completion: 2.5,
      cacheWrite: null,
      cacheRead: null,
    });
    expect(rates('moonshot.kimi-k2-thinking')).toEqual({
      prompt: 0.6,
      completion: 2.5,
      cacheWrite: null,
      cacheRead: null,
    });
    expect(rates('us.anthropic.claude-3-5-sonnet-20241022-v2:0')).toEqual({
      prompt: 3,
      completion: 15,
      cacheWrite: 3.75,
      cacheRead: 0.3,
    });
  });
});
