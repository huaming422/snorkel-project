/**
 * Behavioral checks for vendor-prefixed (`vendor/model`) model-id resolution.
 *
 * Everything is asserted through the library's public entry points:
 *   - `getModelMaxTokens(modelName, endpoint, endpointTokenConfig?)` from
 *     `@librechat/api` for the context window, and
 *   - `getMultiplier` / `getCacheMultiplier` built by
 *     `createTxMethods(...)` from `@librechat/data-schemas`, wired with the
 *     model-lookup functions the app passes in (api/models), for pricing.
 *
 * No signature changes; only the resolved windows and rates are compared.
 */
import { EModelEndpoint } from 'librechat-data-provider';
import { createTxMethods } from '@librechat/data-schemas';
import type { EndpointTokenConfig } from '~/types';
import { matchModelName, findMatchingPattern, getModelMaxTokens } from './tokens';

/**
 * Pricing methods built with the same lookup functions the app injects in
 * api/models. These lookups never touch the mongoose connection.
 */
const { getMultiplier, getCacheMultiplier } = createTxMethods(
  {} as typeof import('mongoose'),
  {
    matchModelName: (model: string, endpoint?: string) =>
      matchModelName(model, endpoint as EModelEndpoint),
    findMatchingPattern: (model: string, values) =>
      findMatchingPattern(model, values as Record<string, number>) ?? undefined,
  },
);

const ENDPOINTS = [EModelEndpoint.openAI, EModelEndpoint.custom, EModelEndpoint.agents];

/** Every rate a request is billed with: prompt, completion, cache write, cache read. */
function rates(model: string) {
  return {
    prompt: getMultiplier({ model, tokenType: 'prompt' }),
    completion: getMultiplier({ model, tokenType: 'completion' }),
    cacheWrite: getCacheMultiplier({ model, cacheType: 'write' }),
    cacheRead: getCacheMultiplier({ model, cacheType: 'read' }),
  };
}

const KIMI_K2_RATES = { prompt: 0.6, completion: 2.5, cacheWrite: 0.6, cacheRead: 0.15 };
const MOONSHOT_RATES = { prompt: 2.0, completion: 5.0, cacheWrite: null, cacheRead: null };

/** Prefixed spellings of Kimi K2 as gateways list it (OpenRouter, Groq, Together). */
const PREFIXED_KIMI_K2 = [
  'moonshotai/kimi-k2',
  'moonshot/kimi-k2',
  'moonshotai/Kimi-K2-Instruct',
  'moonshotai/kimi-k2-instruct-0905',
];

describe('vendor-prefixed model resolution', () => {
  it('context window of a prefixed id is the window of its model part', () => {
    for (const endpoint of ENDPOINTS) {
      for (const id of PREFIXED_KIMI_K2) {
        expect([id, endpoint, getModelMaxTokens(id, endpoint)]).toEqual([id, endpoint, 262144]);
      }
    }
    expect(getModelMaxTokens('moonshotai/kimi-k2')).toBe(262144);
  });

  it('prices of a prefixed id are the prices of its model part', () => {
    for (const id of PREFIXED_KIMI_K2) {
      expect([id, rates(id)]).toEqual([id, KIMI_K2_RATES]);
    }
  });

  it('prefixed ids resolve by their model part in an endpoint token config too', () => {
    const config = {
      northwind: { prompt: 1, completion: 2, context: 16000 },
      gale: { prompt: 3, completion: 4, context: 400000 },
      'sundial-labs': { prompt: 5, completion: 6, context: 32000 },
      'ember-2': { prompt: 7, completion: 8, context: 640000 },
    } as EndpointTokenConfig;
    expect(getModelMaxTokens('northwind/gale', EModelEndpoint.custom, config)).toBe(400000);
    expect(getModelMaxTokens('sundial-labs/ember-2', EModelEndpoint.custom, config)).toBe(640000);
    expect(getModelMaxTokens('sundial-labs/ember-2-preview', EModelEndpoint.custom, config)).toBe(
      640000,
    );
    // An unknown model part keeps the vendor entry it resolves to today.
    expect(getModelMaxTokens('northwind/breeze', EModelEndpoint.custom, config)).toBe(16000);
    // Bare ids in the same config keep their own entries.
    expect(getModelMaxTokens('northwind', EModelEndpoint.custom, config)).toBe(16000);
    expect(getModelMaxTokens('gale', EModelEndpoint.custom, config)).toBe(400000);
  });

  it('a prefixed id whose model part is not a known model keeps its current window', () => {
    for (const endpoint of ENDPOINTS) {
      expect([endpoint, getModelMaxTokens('moonshot/v1-8k', endpoint)]).toEqual([endpoint, 131072]);
    }
  });

  it('a token config entry keyed by the full vendor/model id wins over a bare key', () => {
    const openrouter = {
      'openrouter/foo': { prompt: 1, completion: 2, context: 900000, output: 1 },
      foo: { prompt: 1, completion: 2, context: 1000, output: 1 },
    } as EndpointTokenConfig;
    expect(getModelMaxTokens('openrouter/foo', EModelEndpoint.custom, openrouter)).toBe(900000);
    expect(getModelMaxTokens('openrouter/foo-latest', EModelEndpoint.custom, openrouter)).toBe(
      900000,
    );
    // Another vendor has no full-id entry, so the bare key applies.
    expect(getModelMaxTokens('other/foo-latest', EModelEndpoint.custom, openrouter)).toBe(1000);

    const acme = {
      'acme/orion': { prompt: 1, completion: 2, context: 777000 },
      orion: { prompt: 1, completion: 2, context: 2000 },
    } as EndpointTokenConfig;
    expect(getModelMaxTokens('acme/orion-2025-01', EModelEndpoint.custom, acme)).toBe(777000);
    expect(getModelMaxTokens('beta/orion-2025-01', EModelEndpoint.custom, acme)).toBe(2000);

    // A model list keyed only by full ids, as fetched from OpenRouter.
    const fetched = {
      'moonshotai/kimi-k2': { prompt: 0.5, completion: 2.2, context: 100000 },
      'qwen/qwen3-coder': { prompt: 0.3, completion: 1.2, context: 300000 },
    } as EndpointTokenConfig;
    expect(getModelMaxTokens('moonshotai/kimi-k2-0905', EModelEndpoint.custom, fetched)).toBe(
      100000,
    );
    expect(getModelMaxTokens('qwen/qwen3-coder-latest', EModelEndpoint.custom, fetched)).toBe(
      300000,
    );
  });

  it('dot-separated and unprefixed ids are unchanged', () => {
    expect(getModelMaxTokens('moonshot.kimi-k2-thinking', EModelEndpoint.bedrock)).toBe(262144);
    expect(getModelMaxTokens('moonshot.kimi-k2', EModelEndpoint.bedrock)).toBe(262144);
    expect(getModelMaxTokens('us.anthropic.claude-3-5-sonnet-20241022-v2:0')).toBe(200000);
    expect(getModelMaxTokens('kimi-k2', EModelEndpoint.openAI)).toBe(262144);
    expect(getModelMaxTokens('moonshot', EModelEndpoint.openAI)).toBe(131072);
    expect(rates('kimi-k2')).toEqual(KIMI_K2_RATES);
    expect(rates('moonshot')).toEqual(MOONSHOT_RATES);
    expect(rates('moonshot.kimi-k2')).toEqual({
      prompt: 0.6,
      completion: 2.5,
      cacheWrite: null,
      cacheRead: null,
    });
    expect(rates('moonshot.kimi-k2-thinking')).toEqual({
      prompt: 0.6,
      completion: 2.5,
      cacheWrite: null,
      cacheRead: null,
    });
    expect(rates('us.anthropic.claude-3-5-sonnet-20241022-v2:0')).toEqual({
      prompt: 3,
      completion: 15,
      cacheWrite: 3.75,
      cacheRead: 0.3,
    });
  });
});
