# LICENSE HEADER MANAGED BY add-license-header
#
# Copyright 2018 Kornia Team
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
"""Verifier for the augmentation parameter-generation contract.

What is checked, on CPU and on the ``meta`` device:

* Tracing a parameter generator, an augmentation's parameter step, or an
  augmentation's forward call with ``make_fx`` records no
  ``aten.lift_fresh_copy`` node. Affine centers and perspective corners also
  reach the graph output without a ``get_attr`` node.
* Outputs keep their values. Each generator returns the same set of keys, the
  constant part of its output (box corners, centers, control points, size and
  padding tables) matches the geometry the input shape dictates, the random
  part (crop and mosaic origins, control-point noise, angles) stays inside its
  configured range, and the augmentation-level constants keep their value,
  dtype and shape.
* NumPy array and tensor ranges give the same parameters as tuples, eager and
  under ``torch.compile``.
* Moves follow ``nn.Module.to`` semantics. A dtype-only move keeps the device,
  a device-only move keeps the dtype, and a container move or a ``.double()``
  call reaches a generator used on its own. Placement is read from the
  parameters that come back.
* After a container move or a ``.double()`` call, an affine augmentation and an
  affine generator draw every random number in the moved dtype.
* Shear ranges in scalar, 2-element and 4-element form sample inside their
  range after a move, and every draw behind them runs on the moved device and
  dtype.
* Mix augmentations return mixed labels in the dtype of the input, float32 or
  float64.
* Illumination generators return their gradient on the moved device and dtype
  and draw every random number on that device.
* Empty-batch 3D center-crop parameters match the batched path's dtype and
  device, on CPU and on ``meta``.

Everything goes through public ``kornia.augmentation`` modules and
``kornia.augmentation.random_generator`` constructors plus ``make_fx``,
``torch.compile`` and ``nn.Module.to``. No helper added by a fix is imported
by name.

This file is collected from ``/tests/verify/``, outside the repo tree, so the
repo's ``tests/conftest.py`` fixtures and ``testing.base.BaseTester`` are not
in scope. Execution is CPU-only, so the fixtures below are CPU/float32 and
``torch.testing.assert_close`` is used directly.
"""

from __future__ import annotations

from functools import partial
from typing import Callable, Dict, List

import numpy as np
import pytest
import torch
from torch.fx.experimental.proxy_tensor import make_fx
from torch.utils._python_dispatch import TorchDispatchMode

import kornia.augmentation as K
from kornia.augmentation import random_generator as rg


# --------------------------------------------------------------------------- #
# Local fixtures. The repo conftest is out of scope and execution is CPU-only.
# --------------------------------------------------------------------------- #
@pytest.fixture
def device() -> torch.device:
    return torch.device("cpu")


@pytest.fixture
def dtype() -> torch.dtype:
    return torch.float32


def assert_close(actual, expected, *, rtol=None, atol=None) -> None:
    if rtol is None and atol is None:
        torch.testing.assert_close(actual, expected)
    else:
        torch.testing.assert_close(actual, expected, rtol=rtol, atol=atol)


def _lift_nodes(graph) -> list:
    return [n for n in graph.nodes if n.target == torch.ops.aten.lift_fresh_copy.default]


# --------------------------------------------------------------------------- #
# Generator roster, built through public constructors only. The shapes are
# (B, C, H, W) or (B, C, D, H, W); the functional generators take the dims
# unpacked.
# --------------------------------------------------------------------------- #
GENERATORS = [
    pytest.param(lambda: rg.AffineGenerator(30.0), (4, 3, 16, 19), id="affine"),
    pytest.param(lambda: rg.PerspectiveGenerator(0.5), (4, 3, 16, 19), id="perspective"),
    pytest.param(lambda: rg.ShearGenerator((-10.0, 10.0)), (4, 3, 16, 19), id="shear"),
    pytest.param(
        lambda: rg.RectangleEraseGenerator((0.1, 0.2), (0.8, 1.2), 0.5), (4, 3, 16, 19), id="erasing"
    ),
    pytest.param(lambda: rg.CropGenerator((8, 9)), (4, 3, 16, 19), id="crop"),
    pytest.param(lambda: rg.CropGenerator((8, 9), resize_to=(6, 7)), (4, 3, 16, 19), id="crop-resize"),
    pytest.param(
        lambda: rg.ResizedCropGenerator((8, 9), (0.5, 1.0), (0.8, 1.2)), (4, 3, 16, 19), id="resized-crop"
    ),
    pytest.param(lambda: partial(rg.center_crop_generator, size=(8, 9)), (4, 16, 19), id="center-crop"),
    pytest.param(lambda: rg.ResizeGenerator((8, 9)), (4, 3, 16, 19), id="resize"),
    pytest.param(lambda: rg.AffineGenerator3D(30.0), (4, 3, 12, 16, 19), id="affine3d"),
    pytest.param(lambda: rg.PerspectiveGenerator3D(0.5), (4, 3, 12, 16, 19), id="perspective3d"),
    pytest.param(lambda: rg.CropGenerator3D((6, 8, 9)), (4, 3, 12, 16, 19), id="crop3d"),
    pytest.param(
        lambda: rg.CropGenerator3D((6, 8, 9), resize_to=(4, 6, 7)), (4, 3, 12, 16, 19), id="crop3d-resize"
    ),
    pytest.param(
        lambda: partial(rg.center_crop_generator3d, size=(6, 8, 9)), (4, 12, 16, 19), id="center-crop3d"
    ),
    pytest.param(lambda: K.RandomThinPlateSpline(p=1.0).generate_parameters, (4, 3, 16, 19), id="tps"),
    pytest.param(lambda: rg.MosaicGenerator((8, 9)), (4, 3, 16, 19), id="mosaic"),
    pytest.param(rg.CutmixGenerator, (4, 3, 16, 19), id="cutmix"),
    pytest.param(
        lambda: rg.LinearIlluminationGenerator((0.1, 0.2), (0.1, 0.2)), (4, 3, 16, 19), id="linear"
    ),
    pytest.param(
        lambda: rg.LinearCornerIlluminationGenerator((0.1, 0.2), (0.1, 0.2)), (4, 3, 16, 19), id="linear-corner"
    ),
    pytest.param(
        lambda: rg.GaussianIlluminationGenerator((0.1, 0.2), (0.1, 0.2), (0.1, 0.2), (0.1, 0.2)),
        (4, 3, 16, 19),
        id="gaussian",
    ),
]


def _generate(generator, shape):
    """Call a roster entry. ``partial`` factories take unpacked dims, modules take the shape."""
    return generator(*shape) if isinstance(generator, partial) else generator(shape)


# =========================================================================== #
# No lifted constants anywhere in the generator family.
# =========================================================================== #
@pytest.mark.parametrize("make_generator,shape", GENERATORS)
def test_no_lifted_constants(make_generator, shape):
    generator = make_generator()
    # make_fx records every op the call runs, so any tensor constant copied
    # into the graph shows up as a lift_fresh_copy node.
    graph = make_fx(lambda: _generate(generator, shape), _error_on_data_dependent_ops=False)().graph
    lifted = _lift_nodes(graph)
    assert not lifted, f"Forward lifted fresh tensor constants: {lifted}"


# =========================================================================== #
# The affine ``center`` and perspective ``start_points`` reach the graph output
# without passing through a ``get_attr`` node, i.e. they are computed in the
# graph rather than stored as a frozen attribute.
# =========================================================================== #
@pytest.mark.parametrize(
    "make_generator,key",
    [
        pytest.param(lambda: rg.AffineGenerator(30.0, (0.1, 0.1), (0.8, 1.2)), "center", id="affine"),
        pytest.param(lambda: rg.PerspectiveGenerator(0.5), "start_points", id="perspective"),
        pytest.param(
            lambda: rg.PerspectiveGenerator(0.5, sampling_method="area_preserving"),
            "start_points",
            id="perspective-area-preserving",
        ),
    ],
)
def test_geometry_constants_constructed_in_graph(make_generator, key):
    generator = make_generator()
    graph = make_fx(lambda: generator((4, 3, 16, 19))[key].to(torch.float64))().graph
    assert not _lift_nodes(graph)
    output = next(n for n in graph.nodes if n.op == "output")
    pending = list(output.all_input_nodes)
    visited = set()
    while pending:
        node = pending.pop()
        if node in visited:
            continue
        visited.add(node)
        assert node.op != "get_attr", f"Lifted geometry constant: {node.target}"
        pending.extend(node.all_input_nodes)


# =========================================================================== #
# Output values are unchanged.
#
# Every roster entry has a checker that pins the constant part of its output to
# the geometry the input shape dictates (B=4, H=16, W=19, D=12) and bounds the
# random part. The expectations are plain geometry read from the input shape
# and the constructor arguments.
# =========================================================================== #
def _corners2d(width: int, height: int) -> List[List[int]]:
    # top-left, top-right, bottom-right, bottom-left, inclusive far corner
    return [[0, 0], [width - 1, 0], [width - 1, height - 1], [0, height - 1]]


def _corners3d(width: int, height: int, depth: int) -> List[List[int]]:
    front = [[0, 0, 0], [width - 1, 0, 0], [width - 1, height - 1, 0], [0, height - 1, 0]]
    back = [[x, y, depth - 1] for x, y, _ in front]
    return front + back


def _expect(actual: torch.Tensor, rows, *, dtype=torch.float32, batch: int = 4) -> None:
    expected = torch.tensor(rows, dtype=dtype).expand(batch, *torch.tensor(rows).shape)
    assert actual.dtype == dtype, f"{actual.dtype} != {dtype}"
    assert actual.shape == expected.shape, f"{tuple(actual.shape)} != {tuple(expected.shape)}"
    assert_close(actual, expected, rtol=0, atol=0)


def _expect_rows(actual: torch.Tensor, row, *, dtype=torch.long, batch: int = 4) -> None:
    _expect(actual, row, dtype=dtype, batch=batch)


def _expect_keys(params, *names: str) -> None:
    assert set(params) == set(names), f"keys {sorted(params)}, expected {sorted(names)}"


def _expect_box(actual: torch.Tensor, corners, bounds, *, integral: bool, atol: float = 0.0) -> None:
    """A float32 box per sample: ``corners`` shifted by its first vertex, which lies inside ``bounds``.

    ``bounds`` holds one inclusive ``(low, high)`` pair per axis. Integral boxes
    come from floored crop offsets, so their origin has no fractional part.
    """
    offsets = torch.tensor(corners, dtype=torch.float32)
    assert actual.dtype == torch.float32, f"{actual.dtype} != torch.float32"
    assert actual.shape == (4, *offsets.shape), f"{tuple(actual.shape)} != {(4, *offsets.shape)}"
    origin = actual[:, 0]
    assert_close(actual, origin[:, None, :] + offsets, rtol=0, atol=atol)
    for axis, (low, high) in enumerate(bounds):
        assert bool((origin[:, axis] >= low).all()) and bool((origin[:, axis] <= high).all()), f"axis {axis}"
    if integral:
        assert_close(origin, origin.floor(), rtol=0, atol=0)


def _expect_offsets_follow_corner_signs(params, pts_norm, factor) -> None:
    """Perspective end points move each corner inward by at most ``factor`` per axis."""
    offset = params["end_points"] - params["start_points"]
    signs = torch.tensor(pts_norm, dtype=offset.dtype)
    assert bool((offset * signs >= -1e-6).all()), "corner displacement has the wrong sign"
    assert bool((offset.abs() <= torch.tensor(factor, dtype=offset.dtype) + 1e-5).all())


def _check_affine(params) -> None:
    _expect_keys(params, "translations", "center", "scale", "angle", "shear_x", "shear_y")
    _expect(params["center"], [9.0, 7.5])
    _expect(params["translations"], [0.0, 0.0])
    _expect(params["scale"], [1.0, 1.0])
    _expect(params["shear_x"], 0.0)
    _expect(params["shear_y"], 0.0)
    assert bool((params["angle"].abs() <= 30.0).all())


def _check_perspective(params) -> None:
    _expect_keys(params, "start_points", "end_points")
    _expect(params["start_points"], _corners2d(19, 16))
    _expect_offsets_follow_corner_signs(params, [[1, 1], [-1, 1], [-1, -1], [1, -1]], [19 / 4, 16 / 4])


def _check_shear(params) -> None:
    _expect_keys(params, "center", "shear_x", "shear_y")
    _expect(params["center"], [9.0, 7.5])
    assert bool((params["shear_x"].abs() <= 10.0).all())
    _expect(params["shear_y"], 0.0)


def _check_erasing(params) -> None:
    _expect_keys(params, "widths", "heights", "xs", "ys", "values")
    _expect(params["values"], 0.5)
    assert bool((params["widths"] >= 1).all()) and bool((params["widths"] <= 19).all())
    assert bool((params["heights"] >= 1).all()) and bool((params["heights"] <= 16).all())
    assert bool((params["xs"] >= 0).all()) and bool((params["ys"] >= 0).all())


# An 8x9 crop of a 16x19 image starts at a whole-pixel x in [0, 10] and y in [0, 8].
_CROP_SRC_BOUNDS = [(0, 19 - 9), (0, 16 - 8)]


def _check_crop(params) -> None:
    _expect_keys(params, "src", "dst", "input_size", "output_size")
    _expect_box(params["src"], _corners2d(9, 8), _CROP_SRC_BOUNDS, integral=True)
    _expect(params["dst"], _corners2d(9, 8))
    _expect_rows(params["input_size"], [16, 19])
    _expect_rows(params["output_size"], [8, 9])


def _check_crop_resize(params) -> None:
    # resize_to changes only the destination box and output size; the source crop is still 8x9.
    _expect_keys(params, "src", "dst", "input_size", "output_size")
    _expect_box(params["src"], _corners2d(9, 8), _CROP_SRC_BOUNDS, integral=True)
    _expect(params["dst"], _corners2d(7, 6))
    _expect_rows(params["input_size"], [16, 19])
    _expect_rows(params["output_size"], [6, 7])


def _check_resized_crop(params) -> None:
    _expect_keys(params, "src", "dst", "input_size", "output_size")
    _expect(params["dst"], _corners2d(9, 8))
    _expect_rows(params["input_size"], [16, 19])
    _expect_rows(params["output_size"], [8, 9])
    src = params["src"]
    assert bool((src[..., 0] >= 0).all()) and bool((src[..., 0] <= 18).all())
    assert bool((src[..., 1] >= 0).all()) and bool((src[..., 1] <= 15).all())


def _check_center_crop(params) -> None:
    _expect_keys(params, "src", "dst", "input_size", "output_size")
    _expect(params["src"], [[5, 4], [13, 4], [13, 11], [5, 11]], dtype=torch.long)
    _expect(params["dst"], _corners2d(9, 8), dtype=torch.long)
    _expect_rows(params["input_size"], [16, 19])
    _expect_rows(params["output_size"], [8, 9])


def _check_resize(params) -> None:
    _expect_keys(params, "src", "dst", "input_size", "output_size")
    _expect(params["src"], _corners2d(19, 16))
    _expect(params["dst"], _corners2d(9, 8))
    _expect_rows(params["input_size"], [16, 19])
    _expect_rows(params["output_size"], [8, 9])


def _check_affine3d(params) -> None:
    # Only degrees are configured, so translation is zero and scale is one on every axis.
    _expect_keys(params, "translations", "center", "scale", "angles", "sxy", "sxz", "syx", "syz", "szx", "szy")
    _expect(params["translations"], [0.0, 0.0, 0.0])
    _expect(params["scale"], [1.0, 1.0, 1.0])
    _expect(params["center"], [9.0, 7.5, 5.5])
    assert params["angles"].dtype == torch.float32 and params["angles"].shape == (4, 3)
    for name in ("sxy", "sxz", "syx", "syz", "szx", "szy"):
        _expect(params[name], 0.0)
    assert bool((params["angles"].abs() <= 30.0).all())


def _check_perspective3d(params) -> None:
    _expect_keys(params, "start_points", "end_points")
    _expect(params["start_points"], _corners3d(19, 16, 12))
    pts_norm = [[1, 1, 1], [-1, 1, 1], [-1, -1, 1], [1, -1, 1], [1, 1, -1], [-1, 1, -1], [-1, -1, -1], [1, -1, -1]]
    _expect_offsets_follow_corner_signs(params, pts_norm, [19 / 4, 16 / 4, 12 / 4])


# A 6x8x9 crop of a 12x16x19 volume starts at a whole voxel with x in [0, 10],
# y in [0, 8] and z in [0, 6]. The 3D crop generator reports no input or output
# size, so src and dst are its whole output.
_CROP3D_SRC_BOUNDS = [(0, 19 - 9), (0, 16 - 8), (0, 12 - 6)]


def _check_crop3d(params) -> None:
    _expect_keys(params, "src", "dst")
    _expect_box(params["src"], _corners3d(9, 8, 6), _CROP3D_SRC_BOUNDS, integral=True)
    _expect(params["dst"], _corners3d(9, 8, 6))


def _check_crop3d_resize(params) -> None:
    _expect_keys(params, "src", "dst")
    _expect_box(params["src"], _corners3d(9, 8, 6), _CROP3D_SRC_BOUNDS, integral=True)
    _expect(params["dst"], _corners3d(7, 6, 4))


def _check_center_crop3d(params) -> None:
    _expect_keys(params, "src", "dst")
    # center_crop_generator3d(4, 12, 16, 19, (6, 8, 9)):
    # start=(x=5, y=4, z=3), end=(x=13, y=11, z=8); dst box 9x8x6 -> (8, 7, 5).
    src = [[5, 4, 3], [13, 4, 3], [13, 11, 3], [5, 11, 3], [5, 4, 8], [13, 4, 8], [13, 11, 8], [5, 11, 8]]
    _expect(params["src"], src, dtype=torch.long)
    _expect(params["dst"], _corners3d(9, 8, 6), dtype=torch.long)


def _check_tps(params) -> None:
    _expect_keys(params, "src", "dst")
    control_points = [[-1.0, -1.0], [-1.0, 1.0], [1.0, -1.0], [1.0, 1.0], [0.0, 0.0]]
    _expect(params["src"], control_points)
    # The default scale of 0.2 moves each control point by at most 0.2 per axis.
    dst = params["dst"]
    assert dst.dtype == torch.float32 and dst.shape == (4, 5, 2)
    noise = dst - torch.tensor(control_points)
    assert bool((noise.abs() <= 0.2 + 1e-6).all()), "control point moved more than the scale"
    assert bool((noise != 0).any()), "control points were not moved"


def _check_mosaic(params) -> None:
    _expect_keys(params, "permutation", "src", "dst", "batch_shapes")
    # The crop window is a full 16x19 image whose top-left corner sits at
    # 0.3 to 0.7 of the width and height, give or take float32 rounding.
    bounds = [(0.3 * side - 1e-4, 0.7 * side + 1e-4) for side in (19, 16)]
    _expect_box(params["src"], _corners2d(19, 16), bounds, integral=False, atol=1e-5)
    _expect(params["dst"], _corners2d(19, 16))
    _expect_rows(params["batch_shapes"], [3, 16, 19])
    # A 2x2 mosaic picks four batch indices per output image, and across the
    # batch every image fills the same number of tiles (4 images x 4 tiles).
    permutation = params["permutation"]
    assert permutation.shape == (4, 4) and permutation.dtype == torch.long
    assert bool((permutation >= 0).all()) and bool((permutation < 4).all())
    counts = torch.bincount(permutation.flatten(), minlength=4)
    assert counts.tolist() == [4, 4, 4, 4], f"tile counts per image: {counts.tolist()}"


def _check_cutmix(params) -> None:
    _expect_keys(params, "crop_src", "mix_pairs", "image_shape")
    assert_close(params["image_shape"], torch.tensor([16.0, 19.0]), rtol=0, atol=0)
    assert params["mix_pairs"].shape == (1, 4)
    assert_close(params["mix_pairs"][0].sort().values, torch.arange(4), rtol=0, atol=0)
    src = params["crop_src"]
    assert src.shape == (1, 4, 4, 2)
    assert bool((src[..., 0] >= 0).all()) and bool((src[..., 0] <= 18).all())
    assert bool((src[..., 1] >= 0).all()) and bool((src[..., 1] <= 15).all())


def _check_illumination(params) -> None:
    _expect_keys(params, "gradient")
    # Sign range (0.1, 0.2) is strictly positive and the pattern is normalized to [0, 1],
    # so each sample spans exactly [0, gain] with gain drawn from (0.1, 0.2).
    gradient = params["gradient"]
    assert gradient.shape == (4, 3, 16, 19)
    per_sample = gradient.flatten(1)
    assert_close(per_sample.amin(dim=1), torch.zeros(4), rtol=0, atol=1e-6)
    peak = per_sample.amax(dim=1)
    assert bool((peak >= 0.1 - 1e-5).all()) and bool((peak <= 0.2 + 1e-5).all())


_VALUE_CHECKS: Dict[str, Callable[[dict], None]] = {
    "affine": _check_affine,
    "perspective": _check_perspective,
    "shear": _check_shear,
    "erasing": _check_erasing,
    "crop": _check_crop,
    "crop-resize": _check_crop_resize,
    "resized-crop": _check_resized_crop,
    "center-crop": _check_center_crop,
    "resize": _check_resize,
    "affine3d": _check_affine3d,
    "perspective3d": _check_perspective3d,
    "crop3d": _check_crop3d,
    "crop3d-resize": _check_crop3d_resize,
    "center-crop3d": _check_center_crop3d,
    "tps": _check_tps,
    "mosaic": _check_mosaic,
    "cutmix": _check_cutmix,
    "linear": _check_illumination,
    "linear-corner": _check_illumination,
    "gaussian": _check_illumination,
}


@pytest.mark.parametrize("make_generator,shape", GENERATORS)
def test_generator_values_match_geometry(make_generator, shape, request):
    check = _VALUE_CHECKS[request.node.callspec.id]
    torch.manual_seed(0)
    params = _generate(make_generator(), shape)
    for value in params.values():
        assert value.device == torch.device("cpu")
    check(params)


def test_centercrop3d_values_on_requested_device(device):
    params = rg.center_crop_generator3d(2, 12, 16, 19, (6, 8, 9), device=device)
    assert params["src"].device == device and params["dst"].device == device
    _check_center_crop3d({name: value[:1].expand(4, -1, -1) for name, value in params.items()})


# =========================================================================== #
# Augmentation-level constants. The padding table of a padded random crop, the
# recorded input shape, the empty-batch motion-blur index, the mix dtype tag,
# and the default per-sample gate filled in when a caller passes a parameter
# dict without one, all build in-graph and keep their eager value.
# =========================================================================== #
def test_random_crop_padding_builds_in_graph_and_keeps_values():
    aug = K.RandomCrop((8, 9), padding=(1, 2), p=1.0)
    shape = torch.Size([4, 3, 16, 19])
    graph = make_fx(lambda: aug.forward_parameters(shape), _error_on_data_dependent_ops=False)().graph
    assert not _lift_nodes(graph), "RandomCrop parameters lifted a constant"
    torch.manual_seed(0)
    params = aug.forward_parameters(shape)
    # (1, 2) pads one column on the left and right and two rows on the top and bottom.
    _expect_rows(params["padding_size"], [1, 1, 2, 2])
    _expect_rows(params["input_size"], [20, 21])
    _expect_rows(params["output_size"], [8, 9])
    _expect(params["dst"], _corners2d(9, 8))


@pytest.mark.parametrize(
    "make_aug",
    [
        pytest.param(lambda: K.RandomAffine(degrees=(-30.0, 30.0), p=1.0), id="affine"),
        pytest.param(lambda: K.RandomPerspective(0.5, p=1.0), id="perspective"),
    ],
)
def test_forward_parameters_input_shape_keeps_value(make_aug):
    aug = make_aug()
    shape = torch.Size([2, 3, 64, 64])
    graph = make_fx(
        lambda: aug.forward_parameters(shape)["forward_input_shape"],
        _error_on_data_dependent_ops=False,
    )().graph
    assert not _lift_nodes(graph), "forward_parameters lifted the forward_input_shape constant"
    recorded = aug.forward_parameters(shape)["forward_input_shape"]
    assert recorded.dtype == torch.long
    assert_close(recorded, torch.tensor([2, 3, 64, 64]), rtol=0, atol=0)


def test_motion_blur_empty_batch_index_keeps_value():
    aug = K.RandomMotionBlur(3, 35.0, 0.5, p=1.0)
    shape = torch.Size([0, 3, 64, 64])
    graph = make_fx(
        lambda: aug.generate_parameters(shape)["idx"],
        _error_on_data_dependent_ops=False,
    )().graph
    assert not _lift_nodes(graph), "RandomMotionBlur lifted the idx constant"
    idx = aug.generate_parameters(shape)["idx"]
    assert idx.dtype == torch.long and idx.shape == (1,)
    assert int(idx[0]) == 0


@pytest.mark.parametrize("input_dtype", [torch.float32, torch.float64], ids=["float32", "float64"])
@pytest.mark.parametrize(
    "make_aug",
    [
        pytest.param(lambda: K.RandomMixUpV2(p=1.0), id="mixup"),
        pytest.param(lambda: K.RandomCutMixV2(p=1.0), id="cutmix"),
    ],
)
def test_mix_dtype_tag_keeps_value(make_aug, input_dtype):
    aug = make_aug()
    x = torch.rand(2, 3, 16, 16, dtype=input_dtype)
    graph = make_fx(lambda x: aug(x), _error_on_data_dependent_ops=False)(x).graph
    assert not _lift_nodes(graph), "mix augmentation lifted the dtype constant"
    # Mixed labels come back in the dtype the input was recorded with.
    labels = torch.tensor([0, 1])
    _, mixed = aug(x, labels, data_keys=["input", "class"])
    assert mixed.dtype == input_dtype, f"labels in {mixed.dtype}, expected {input_dtype}"
    assert_close(mixed[..., 0], labels.to(input_dtype).expand_as(mixed[..., 0]), rtol=0, atol=0)


# The full forward call is traced here, so these are augmentations whose
# transform step has no constants of its own and only the parameter path is
# under test.
CALLER_PARAM_AUGMENTATIONS = [
    pytest.param(lambda: K.RandomHorizontalFlip(p=1.0), id="horizontal-flip"),
    pytest.param(lambda: K.Resize((8, 9)), id="resize"),
]


@pytest.mark.parametrize("make_aug", CALLER_PARAM_AUGMENTATIONS)
def test_forward_with_caller_params_builds_in_graph(make_aug):
    aug = make_aug()
    x = torch.rand(2, 3, 16, 19)

    def run(x):
        params = aug.forward_parameters(x.shape)
        params.pop("batch_prob")
        return aug(x, params=params)

    graph = make_fx(run, _error_on_data_dependent_ops=False)(x).graph
    assert not _lift_nodes(graph), "forward with caller parameters lifted a constant"
    torch.manual_seed(0)
    params = aug.forward_parameters(x.shape)
    expected = aug(x, params=dict(params))
    params.pop("batch_prob")
    actual = aug(x, params=params)
    assert_close(actual, expected, rtol=0, atol=0)


# =========================================================================== #
# NumPy array and tensor ranges keep giving the same parameters as tuples, eager
# and under torch.compile. The eager backend keeps the compile check cheap while
# still running the Dynamo tracer that torch.compile uses.
# =========================================================================== #
RANGE_KINDS = [
    pytest.param(np.array, id="numpy"),
    pytest.param(torch.tensor, id="tensor"),
]


@pytest.mark.parametrize("as_range", RANGE_KINDS)
def test_resized_crop_array_scale_matches_tuple(device, dtype, as_range):
    tuple_gen = rg.ResizedCropGenerator((8, 9), (0.5, 1.0), (0.8, 1.2)).to(device=device, dtype=dtype)
    array_gen = rg.ResizedCropGenerator((8, 9), as_range([0.5, 1.0]), (0.8, 1.2)).to(device=device, dtype=dtype)
    torch.manual_seed(0)
    expected = tuple_gen((4, 3, 16, 19))
    torch.manual_seed(0)
    actual = array_gen((4, 3, 16, 19))
    assert set(actual) == set(expected)
    for name, value in expected.items():
        assert actual[name].dtype == value.dtype, name
        assert_close(actual[name], value, rtol=0, atol=0)


@pytest.mark.parametrize("as_range", RANGE_KINDS)
def test_affine_array_ranges_match_tuple(as_range):
    tuple_gen = rg.AffineGenerator((-30.0, 30.0), (0.1, 0.1), (0.8, 1.2), (-10.0, 10.0))
    array_gen = rg.AffineGenerator(
        as_range([-30.0, 30.0]), as_range([0.1, 0.1]), as_range([0.8, 1.2]), as_range([-10.0, 10.0])
    )
    torch.manual_seed(0)
    expected = tuple_gen((4, 3, 16, 19))
    torch.manual_seed(0)
    actual = array_gen((4, 3, 16, 19))
    assert set(actual) == set(expected)
    for name, value in expected.items():
        assert_close(actual[name], value.to(actual[name].dtype), rtol=1e-6, atol=1e-6)


@pytest.mark.parametrize("as_range", RANGE_KINDS)
def test_resized_crop_array_scale_compiles(device, dtype, as_range):
    generator = rg.ResizedCropGenerator((8, 9), as_range([0.5, 1.0]), (0.8, 1.2)).to(device=device, dtype=dtype)

    def sample():
        return generator((4, 3, 16, 19))

    torch._dynamo.reset()
    compiled = torch.compile(sample, backend="eager")
    torch.manual_seed(0)
    expected = sample()
    torch.manual_seed(0)
    actual = compiled()
    assert set(actual) == set(expected)
    for name, value in expected.items():
        assert actual[name].dtype == value.dtype, name
        assert actual[name].device == value.device, name
        assert_close(actual[name], value, rtol=0, atol=0)


# =========================================================================== #
# Moves follow nn.Module.to semantics. Resize returns its boxes on the device
# and dtype it was moved to, so its parameters show where a move landed. The
# augmentation and the bare generator both take dtype-only and device-only
# moves; container moves and .double() are checked on both as well.
# =========================================================================== #
_RESIZE_SHAPE = (4, 3, 16, 19)

MOVABLE = [
    pytest.param(lambda: K.Resize((8, 9)), id="augmentation"),
    pytest.param(lambda: rg.ResizeGenerator((8, 9)), id="generator"),
]


def _resize_boxes(module) -> torch.Tensor:
    if hasattr(module, "forward_parameters"):
        return module.forward_parameters(torch.Size(_RESIZE_SHAPE))["src"]
    return module(_RESIZE_SHAPE)["src"]


def _assert_boxes_on(module, device_type: str, dtype: torch.dtype) -> None:
    boxes = _resize_boxes(module)
    assert boxes.shape == (4, 4, 2)
    assert boxes.device.type == device_type, f"boxes on {boxes.device}, expected {device_type}"
    assert boxes.dtype == dtype, f"boxes in {boxes.dtype}, expected {dtype}"


@pytest.mark.parametrize("make_module", MOVABLE)
def test_dtype_only_move_keeps_device(make_module):
    module = make_module()
    module.to(device="meta")
    module.to(dtype=torch.float64)
    _assert_boxes_on(module, "meta", torch.float64)


@pytest.mark.parametrize("make_module", MOVABLE)
def test_device_only_move_keeps_dtype(make_module):
    module = make_module()
    module.to(dtype=torch.float64)
    module.to(device="meta")
    _assert_boxes_on(module, "meta", torch.float64)


@pytest.mark.parametrize("make_module", MOVABLE)
def test_container_move_reaches_parameters(make_module):
    module = make_module()
    torch.nn.Sequential(module).to(device="meta", dtype=torch.float64)
    _assert_boxes_on(module, "meta", torch.float64)


@pytest.mark.parametrize("make_module", MOVABLE)
def test_double_after_device_move(make_module):
    module = make_module()
    module.to(device="meta")
    module.double()
    _assert_boxes_on(module, "meta", torch.float64)


# =========================================================================== #
# Samplers follow moves. Affine draws its angle, translation, scale and shear
# from distributions, so the dtype of every floating random draw shows where
# those distributions sit after a move.
# =========================================================================== #
_RANDOM_OPS = frozenset(
    {
        "rand",
        "rand_like",
        "randn",
        "randn_like",
        "randint",
        "randint_like",
        "randperm",
        "uniform",
        "uniform_",
        "normal",
        "normal_",
        "bernoulli",
        "bernoulli_",
        "random_",
        "exponential_",
        "multinomial",
    }
)


class _RandomDrawLog(TorchDispatchMode):
    """Record the device and dtype of every random-number op that runs while active."""

    def __init__(self) -> None:
        super().__init__()
        self.draws: List[tuple] = []

    def __torch_dispatch__(self, func, types, args=(), kwargs=None):
        out = func(*args, **(kwargs or {}))
        if func.overloadpacket.__name__ in _RANDOM_OPS:
            for tensor in out if isinstance(out, (tuple, list)) else (out,):
                if isinstance(tensor, torch.Tensor):
                    self.draws.append((tensor.device.type, tensor.dtype))
        return out

    def devices(self) -> set:
        return {device for device, _ in self.draws}

    def float_dtypes(self) -> set:
        return {dtype for _, dtype in self.draws if dtype.is_floating_point}


SAMPLED = [
    pytest.param(
        lambda: K.RandomAffine(30.0, translate=(0.1, 0.1), scale=(0.8, 1.2), shear=(-10.0, 10.0), p=1.0),
        id="augmentation",
    ),
    pytest.param(
        lambda: rg.AffineGenerator(30.0, (0.1, 0.1), (0.8, 1.2), (-10.0, 10.0, -5.0, 5.0)), id="generator"
    ),
]


def _assert_draws_in(module, dtype: torch.dtype) -> None:
    with _RandomDrawLog() as log:
        if hasattr(module, "forward_parameters"):
            module.forward_parameters(torch.Size(_RESIZE_SHAPE))
        else:
            module(_RESIZE_SHAPE)
    assert log.float_dtypes() == {dtype}, f"random draws in {sorted(map(str, log.float_dtypes()))}, expected {dtype}"


@pytest.mark.parametrize("make_module", SAMPLED)
def test_container_move_reaches_samplers(make_module):
    module = make_module()
    torch.nn.Sequential(module).to(dtype=torch.float64)
    _assert_draws_in(module, torch.float64)


@pytest.mark.parametrize("make_module", SAMPLED)
def test_double_reaches_samplers(make_module):
    module = make_module()
    module.double()
    _assert_draws_in(module, torch.float64)


# =========================================================================== #
# Shear ranges sample inside their range after a float64 move, and every shear
# draw runs in float64. The range check is data dependent, so this runs on CPU.
# =========================================================================== #
@pytest.mark.parametrize("make_generator", [rg.ShearGenerator, partial(rg.AffineGenerator, 30.0)])
@pytest.mark.parametrize(
    "shear,x_bound,y_bound",
    [
        pytest.param(10.0, 10.0, 0.0, id="scalar"),
        pytest.param((-10.0, 10.0), 10.0, 0.0, id="pair"),
        pytest.param((-10.0, 10.0, -5.0, 5.0), 10.0, 5.0, id="quad"),
    ],
)
def test_shear_after_move(make_generator, shear, x_bound, y_bound):
    gen = make_generator(shear=shear).to(device=torch.device("cpu"), dtype=torch.float64)
    torch.manual_seed(0)
    with _RandomDrawLog() as log:
        params = gen((4, 3, 16, 19))
    assert params["shear_x"].shape == (4,) and params["shear_y"].shape == (4,)
    assert bool((params["shear_x"].abs() <= x_bound).all())
    assert bool((params["shear_y"].abs() <= y_bound).all())
    assert log.devices() == {"cpu"}
    assert log.float_dtypes() == {torch.float64}, f"random draws in {sorted(map(str, log.float_dtypes()))}"


# =========================================================================== #
# Illumination generators return their gradient on the device and dtype they
# were moved to, and every random number behind it is drawn on that device.
# =========================================================================== #
ILLUMINATION_GENERATORS = [
    pytest.param(lambda: rg.LinearIlluminationGenerator((0.1, 0.2), (-1.0, 1.0)), id="linear"),
    pytest.param(lambda: rg.LinearCornerIlluminationGenerator((0.1, 0.2), (-1.0, 1.0)), id="linear-corner"),
    pytest.param(
        lambda: rg.GaussianIlluminationGenerator((0.1, 0.2), (0.1, 0.2), (0.1, 0.2), (-1.0, 1.0)), id="gaussian"
    ),
]


@pytest.mark.parametrize("make_generator", ILLUMINATION_GENERATORS)
def test_illumination_gradient_follows_move(make_generator):
    gen = make_generator().to(device=torch.device("cpu"), dtype=torch.float64)
    params = gen((4, 3, 16, 19))
    assert params["gradient"].device == torch.device("cpu")
    assert params["gradient"].dtype == torch.float64


@pytest.mark.parametrize("make_generator", ILLUMINATION_GENERATORS[:2])
def test_illumination_draws_on_target_device(make_generator):
    gen = make_generator().to(device="meta", dtype=torch.float64)
    with _RandomDrawLog() as log:
        params = gen((4, 3, 16, 19))
    assert log.draws, "no random draw was recorded"
    assert log.devices() == {"meta"}, f"random draws ran on {sorted(log.devices())}"
    assert params["gradient"].device.type == "meta"
    assert params["gradient"].dtype == torch.float64


# =========================================================================== #
# Empty-batch 3D center-crop parameters match the batched path's dtype (long)
# and device.
# =========================================================================== #
@pytest.mark.parametrize("device_name", ["cpu", "meta"])
def test_centercrop3d_empty_batch_matches_batched(device_name):
    requested = torch.device(device_name)
    empty = rg.center_crop_generator3d(0, 12, 16, 19, (6, 8, 9), device=requested)
    batched = rg.center_crop_generator3d(1, 12, 16, 19, (6, 8, 9), device=requested)
    assert set(empty) == set(batched)
    for name, value in batched.items():
        assert value.device.type == device_name, name
        assert empty[name].shape == (0, *value.shape[1:]), name
        assert empty[name].device == value.device, name
        assert empty[name].dtype == value.dtype, name
