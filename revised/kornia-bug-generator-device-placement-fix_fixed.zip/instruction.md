## Task

Augmentation pipelines wrapped in `torch.compile` crash at runtime on our GPU machines.
It started with `RandomAffine` and `RandomPerspective`, but most of the parameter generators seem to be affected.

Augmentations also do not reliably end up where you put them.
After a pipeline is moved to another device or dtype, some of them throw device-mismatch errors on the next call, and others return parameters on the wrong device or with the wrong dtype, which silently changes the precision people get and adds a transfer per call.

Can you work out why and sort it out wherever it shows up?
However a pipeline gets moved, the augmentations and generators in it should do their sampling on the device and in the dtype the pipeline ended up with.
Eager results must not change, and existing callers have to keep working whether they hand in ranges as NumPy arrays, tensors or plain tuples, compiled or not.
A lot of our users have no GPU and check shapes on the `meta` device without real data, so all of this has to hold there too.
