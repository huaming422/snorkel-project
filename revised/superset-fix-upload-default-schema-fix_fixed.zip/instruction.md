## Task

Uploading a CSV to one of our Postgres databases fails if I leave the Schema field empty.
This is what comes back:

```
schema "undefined" does not exist
```

On databases where a schema-less upload does get through, I end up with a second dataset for a table that already had one.
Leaving Schema empty used to mean "put it in the database's default schema", and I'd like that back.
The rows should land in the default schema and the dataset should be listed under it.
If that table already has a dataset there, the upload should use it rather than add another.

There's a second case on a database that only accepts uploads into a few schemas.
Its default schema is on that list, yet a blank Schema gets refused as not allowed.
That upload should go through too.
I don't want a blank Schema to become a way around the list, though, and schemas people pick should be checked against it the same way they are now.
Picking a schema by hand works today and needs to keep working.

A lot of people have the upload page open or cached, so this has to work for them without a reload.
