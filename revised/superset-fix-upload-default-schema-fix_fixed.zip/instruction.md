## Task

Uploading a CSV to a Postgres database fails if I leave the Schema field empty.
The error is:

```
schema "undefined" does not exist
```

In the browser's network tab, the upload request has `schema=undefined` in it.
On databases where a schema-less upload does get through, I end up with a second dataset for a table that already had one.
Choosing a schema by hand works.
An empty Schema field used to mean "use the database's default schema", and that's what I want back.

What should hold once this is fixed:

- An empty Schema field, whether never touched, cleared with its x, or reset after switching databases, puts the data in the database's default schema, and the dataset it creates is listed under that schema.
- If a dataset for that table already exists under the default schema, a blank-schema upload reuses it instead of creating another one.
- The upload form doesn't send `undefined` for an empty Schema field.
- Some people will keep sending `schema=undefined` from the old page for a while, and the server should treat that the same as an empty schema.
- On an Excel upload where no sheet ends up selected (say the sheet list failed to load), the request asks for a sheet called `undefined`, and the form should leave the sheet name out instead, since the server already falls back to the first sheet then.
- A schema I pick is still the one the data goes into.
- On a database that only allows uploads into certain schemas, a picked schema still has to match one of the allowed names exactly, letter case included.
- On such a database, an empty Schema field is accepted when the default schema is on the list, and refused when the list doesn't have it at all.
