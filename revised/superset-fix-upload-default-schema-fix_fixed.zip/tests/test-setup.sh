#!/usr/bin/env bash
# test-setup.sh - runs once before the verifiers.
#
# The full dependency closure (backend requirements/development.txt incl.
# editable superset, and the frontend node_modules via `npm ci`) is already
# baked into the image at build time, so this script does NO network installs.
# It only (1) exports offline switches so any accidental resolve fails fast
# instead of hanging on a dead network, and (2) smoke-tests that the backend
# import chain boots inside a minimal Flask app context, the canonical way to
# make app-context-bound Superset modules importable for the verifier.
#
# The backend verifier (pytest over superset.*) relies on what is baked, and
# node_modules stays baked for frontend work; nothing here reaches the network,
# so the smoke gate's offline fold passes.

set -euo pipefail

REPO=/repo/superset
cd "$REPO"

# Offline switches scoped to this task's own tooling (NOT image-wide ENV, which
# would break harbor's `uv tool install` of the run harness at trial prep).
export UV_OFFLINE=1
export PIP_NO_INDEX=1

echo "[test-setup] verifying baked backend deps are importable"
python3 - <<'PY'
import sys
sys.path.insert(0, "/repo/superset")

from superset.app import SupersetApp
from superset.extensions import appbuilder
from superset.initialization import SupersetAppInitializer

app = SupersetApp(__name__)
app.config.from_object("superset.config")
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite://"
app.config["WTF_CSRF_ENABLED"] = False
app.config["TESTING"] = True
app.config["RATELIMIT_ENABLED"] = False
app.config["CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
app.config["DATA_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
app.config["FILTER_STATE_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
app.config["EXPLORE_FORM_DATA_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
app.config["GLOBAL_ASYNC_QUERIES_REDIS_CONFIG"] = None
app.config["TALISMAN_ENABLED"] = False
app.config["PREVENT_UNSAFE_DB_CONNECTIONS"] = False

appbuilder.baseviews = []
SupersetAppInitializer(app).init_app()
with app.app_context():
    # The REST API module the backend verifier posts to.
    from superset.databases.api import DatabaseRestApi  # noqa: F401
    print("[test-setup] backend imports OK")
PY

echo "[test-setup] verifying baked frontend node_modules is present"
if [ ! -d "$REPO/superset-frontend/node_modules/.bin" ]; then
    echo "[test-setup] ERROR: frontend node_modules missing (should be baked)" >&2
    exit 1
fi
echo "[test-setup] frontend node_modules OK"

echo "[test-setup] done"
