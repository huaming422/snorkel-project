/**
 * Upload modal: the multipart body it sends when optional fields are empty.
 *
 * - CSV upload with the Schema field never touched: the body carries no
 *   schema value other than an empty one (never the text "undefined").
 * - CSV upload whose schema was reset by switching databases: same.
 * - CSV upload whose picked schema was removed with the clear icon: same.
 * - Excel upload with no sheet selected: the body has no sheet_name entry.
 *
 * The checks render <UploadDataModal> and read the request body it sends
 * (intercepted via fetch-mock); no internal helper of the component is used.
 *
 * Self-contained: the runner copies just this file into the component
 * directory, so the mocks/props/fillForm helper from the repo's own
 * UploadDataModal.test.tsx are reproduced here.
 */
// @ts-nocheck
import fetchMock from 'fetch-mock';
import UploadDataModal from 'src/features/databases/UploadDataModel';
import {
  render,
  screen,
  waitFor,
  userEvent,
  fireEvent,
  within,
} from 'spec/helpers/testing-library';

const csvProps = {
  show: true,
  onHide: () => {},
  allowedExtensions: ['csv', 'tsv'],
  type: 'csv',
};

const excelProps = {
  show: true,
  onHide: () => {},
  allowedExtensions: ['xls', 'xlsx'],
  type: 'excel',
};

const setupMocks = () => {
  fetchMock.post('glob:*api/v1/database/1/upload/', {});
  fetchMock.post('glob:*api/v1/database/csv_metadata/', {});
  fetchMock.post('glob:*api/v1/database/excel_metadata/', {});
  fetchMock.post('glob:*api/v1/database/columnar_metadata/', {});
  fetchMock.post('glob:*api/v1/database/upload_metadata/', {});

  fetchMock.get(
    'glob:*api/v1/database/?q=(filters:!((col:allow_file_upload,opr:eq,value:!t)),page:0,page_size:100)',
    {
      result: [
        { id: 1, database_name: 'database1' },
        { id: 2, database_name: 'database2' },
      ],
    },
  );

  fetchMock.get('glob:*api/v1/database/*/catalogs/', { result: [] });

  fetchMock.get('glob:*api/v1/database/1/schemas/?q=(upload_allowed:!t)', {
    result: ['information_schema', 'public'],
  });

  fetchMock.get('glob:*api/v1/database/2/schemas/?q=(upload_allowed:!t)', {
    result: ['schema1', 'schema2'],
  });
};

jest.setTimeout(60000);

beforeEach(() => {
  setupMocks();
});

afterEach(() => {
  fetchMock.clearHistory().removeRoutes();
});

// eslint-disable-next-line no-restricted-globals -- scoped suite
describe('UploadDataModal form data for empty optional fields', () => {
  // Fill and submit the form. When omitSchema is true the schema combobox is
  // left untouched. When switchFromDatabase2 is true, database2 and one of its
  // schemas are picked first, then the database is switched to database1,
  // which resets the Schema field. When clearSchema is true, 'public' is
  // picked and then removed with the field's clear icon.
  const fillForm = async (
    fileName: string,
    mimeType = 'text/csv',
    { omitSchema = false, switchFromDatabase2 = false, clearSchema = false } = {},
  ) => {
    const selectButton = screen.getByRole('button', { name: 'Select' });
    await userEvent.click(selectButton);

    const file = new File(['test'], fileName, { type: mimeType });
    const inputElement = screen.getByTestId('model-file-input');
    fireEvent.change(inputElement, { target: { files: [file] } });

    const selectDatabase = screen.getByRole('combobox', {
      name: /select a database/i,
    });
    if (switchFromDatabase2) {
      await userEvent.click(selectDatabase);
      await waitFor(() => screen.getByText('database2'));
      await userEvent.click(screen.getByText('database2'));
      const schemaCombobox = screen.getByRole('combobox', { name: /schema/i });
      await userEvent.click(schemaCombobox);
      await waitFor(() => screen.getAllByText('schema1'));
      await userEvent.click(screen.getAllByText('schema1')[1]);
    }
    await userEvent.click(selectDatabase);
    await waitFor(() => screen.getByText('database1'));
    await userEvent.click(screen.getByText('database1'));

    if (!omitSchema) {
      const schemaCombobox = screen.getByRole('combobox', { name: /schema/i });
      await userEvent.click(schemaCombobox);
      await waitFor(() => screen.getAllByText('public'));
      await userEvent.click(screen.getAllByText('public')[1]);
      if (clearSchema) {
        const schemaSelect = schemaCombobox.closest('.ant-select') as HTMLElement;
        await userEvent.hover(schemaSelect);
        await userEvent.click(within(schemaSelect).getByLabelText('close-circle'));
      }
    }

    const inputTableName = screen.getByRole('textbox', {
      name: /table name/i,
    });
    await userEvent.type(inputTableName, 'table1');

    const uploadButton = screen.getByRole('button', { name: 'Upload' });
    await userEvent.click(uploadButton);

    await waitFor(
      () => fetchMock.callHistory.called('glob:*api/v1/database/1/upload/'),
      { timeout: 10000 },
    );
    return fetchMock.callHistory.calls('glob:*api/v1/database/1/upload/')[0];
  };

  test('CSV submission with the schema field never touched sends no schema value', async () => {
    render(<UploadDataModal {...csvProps} />, { useRedux: true });

    const { options } = await fillForm('test.csv', 'text/csv', {
      omitSchema: true,
    });
    const formData = options?.body as FormData;

    expect(formData.get('type')).toBe('csv');
    expect(formData.get('table_name')).toBe('table1');
    expect((formData.get('file') as File).name).toBe('test.csv');
    // Absent (null) or empty; never a stringified unset value.
    expect([null, '']).toContain(formData.get('schema'));
  }, 60000);

  test('CSV submission after switching databases resets schema and sends no schema value', async () => {
    render(<UploadDataModal {...csvProps} />, { useRedux: true });

    const { options } = await fillForm('test.csv', 'text/csv', {
      omitSchema: true,
      switchFromDatabase2: true,
    });
    const formData = options?.body as FormData;

    expect(formData.get('type')).toBe('csv');
    expect(formData.get('table_name')).toBe('table1');
    expect([null, '']).toContain(formData.get('schema'));
  }, 60000);

  test('CSV submission after clearing the picked schema sends no schema value', async () => {
    render(<UploadDataModal {...csvProps} />, { useRedux: true });

    const { options } = await fillForm('test.csv', 'text/csv', {
      clearSchema: true,
    });
    const formData = options?.body as FormData;

    expect(formData.get('type')).toBe('csv');
    expect(formData.get('table_name')).toBe('table1');
    expect([null, '']).toContain(formData.get('schema'));
  }, 60000);

  test('Excel submission with no sheet selected sends no sheet_name entry', async () => {
    render(<UploadDataModal {...excelProps} />, { useRedux: true });

    const { options } = await fillForm('test.xls', 'text', { omitSchema: false });
    const formData = options?.body as FormData;

    expect(formData.get('type')).toBe('excel');
    expect(formData.get('table_name')).toBe('table1');
    expect(formData.get('schema')).toBe('public');
    // No sheet is selected, so no sheet_name entry is sent at all.
    expect(formData.has('sheet_name')).toBe(false);
  }, 60000);
});
