"""Backend checks for file uploads that leave the schema empty.

Behaviors covered:
  - an empty schema (omitted or "") is written to the database's default
    schema, and a new dataset is registered under that schema
  - an existing dataset under the default schema is reused, not duplicated
  - "undefined" sent on the request path is handled like an empty schema,
    while a real schema name reaches the write unchanged
  - an explicitly chosen schema is written as given
  - with an upload allow-list, a chosen schema must match an entry exactly,
    and an empty schema is accepted only when the default schema is listed

Every check drives existing entry points only:
  * superset.commands.database.uploaders.base.UploadCommand.run()
  * superset.databases.schemas.UploadPostSchema().load(..., partial=True)

The schema the command writes is read where the command hands it to the
reader, and the dataset outcome is read from the dataset lookup and the
SqlaTable construction, so the checks hold wherever the schema is resolved.
"""

from __future__ import annotations

import io
import sys

import pytest
from werkzeug.datastructures import FileStorage

# The repo is editable-installed; keep the explicit path insert so the checks
# import superset.* even if invoked from outside the source root.
sys.path.insert(0, "/repo/superset")


# --------------------------------------------------------------------------- #
# App context: UploadCommand and the marshmallow schema need a live Superset
# application context (flask config + flask_babel lazy_gettext on the exception
# classes). Build the minimal app once per session, mirroring the repo's own
# unit-test harness (tests/unit_tests/conftest.py). The pytest runner executes
# this file by path, so the repo conftest is not auto-loaded and the fixtures
# live here.
# --------------------------------------------------------------------------- #
@pytest.fixture(scope="session")
def _superset_app():
    from superset.app import SupersetApp
    from superset.extensions import appbuilder
    from superset.initialization import SupersetAppInitializer

    app = SupersetApp(__name__)
    app.config.from_object("superset.config")
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite://"
    app.config["WTF_CSRF_ENABLED"] = False
    app.config["TESTING"] = True
    app.config["RATELIMIT_ENABLED"] = False
    app.config["CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    app.config["DATA_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    app.config["FILTER_STATE_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    app.config["EXPLORE_FORM_DATA_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    app.config["GLOBAL_ASYNC_QUERIES_REDIS_CONFIG"] = None
    app.config["TALISMAN_ENABLED"] = False
    app.config["PREVENT_UNSAFE_DB_CONNECTIONS"] = False

    appbuilder.baseviews = []
    SupersetAppInitializer(app).init_app()
    return app


@pytest.fixture
def app_context(_superset_app):
    with _superset_app.app_context():
        yield


def _file(contents: bytes = b"col\n1\n") -> FileStorage:
    return FileStorage(stream=io.BytesIO(contents), filename="data.csv")


class _Upload:
    """What one UploadCommand.run() call did."""

    def __init__(self, reader, sqla_cls, existing):
        self.reader = reader
        self.sqla_cls = sqla_cls
        self.existing = existing

    @property
    def written_schema(self):
        """The schema handed to reader.read(file, model, table, schema)."""
        return self.reader.read.call_args[0][3]

    @property
    def created_dataset_schema(self):
        """The schema of the dataset the command created, if it created one."""
        assert self.sqla_cls.call_count == 1, "expected one new dataset"
        return self.sqla_cls.call_args.kwargs.get("schema")


def _drive_run(
    mocker,
    *,
    schema,
    default_schema,
    existing_schema=None,
    allowed=None,
    table="t",
    reader=None,
):
    """Run UploadCommand.run() against a mocked database.

    - default_schema: what the database reports as its default schema, through
      both Database.get_default_schema and the engine spec's classmethod.
    - existing_schema: when set, a dataset for `table` already exists under
      this schema, and the dataset lookup returns it for that schema only.
    - allowed: None means the database has no upload allow-list and file
      uploads are permitted; a set is the database's upload allow-list, read
      through the repo's own upload permission check.
    """
    from superset.commands.database.uploaders.base import UploadCommand

    model = mocker.MagicMock()
    model.allow_file_upload = True
    model.db_engine_spec.supports_file_upload = True
    model.db_engine_spec.supports_schemas = True
    model.get_default_catalog.return_value = None
    model.db_engine_spec.get_default_catalog.return_value = None
    model.get_default_schema.return_value = default_schema
    model.db_engine_spec.get_default_schema.return_value = default_schema
    model.db_engine_spec.normalize_table_name_for_upload.side_effect = (
        lambda table_name, schema_name: (table_name, schema_name)
    )
    if allowed is None:
        # No allow-list: the upload permission check is stubbed to allow, so
        # these cases look only at where the schema ends up.
        model.get_schema_access_for_file_upload.return_value = set()
        mocker.patch(
            "superset.commands.database.uploaders.base.schema_allows_file_upload",
            return_value=True,
        )
    else:
        model.get_schema_access_for_file_upload.return_value = set(allowed)
        model.get_extra.return_value = {
            "schemas_allowed_for_file_upload": sorted(allowed)
        }
    mocker.patch(
        "superset.commands.database.uploaders.base.DatabaseDAO.find_by_id",
        return_value=model,
    )
    mocker.patch.dict(
        "superset.commands.database.uploaders.base.current_app.config",
        {"UPLOAD_MAX_FILE_SIZE_BYTES": 1024},
    )

    existing = mocker.MagicMock(name="existing_dataset") if existing_schema else None

    def _filter_by(**kwargs):
        found = (
            existing
            if existing is not None
            and kwargs.get("table_name", table) == table
            and kwargs.get("schema") == existing_schema
            else None
        )
        result = mocker.MagicMock()
        result.one_or_none.return_value = found
        result.first.return_value = found
        result.filter.return_value.all.return_value = []
        return result

    db_mock = mocker.patch("superset.commands.database.uploaders.base.db")
    db_mock.session.query.return_value.filter_by.side_effect = _filter_by
    mocker.patch(
        "superset.daos.dataset.DatasetDAO.find_soft_deleted_logical_duplicate",
        return_value=None,
    )
    sqla_cls = mocker.patch("superset.commands.database.uploaders.base.SqlaTable")
    mocker.patch(
        "superset.commands.database.uploaders.base.get_user",
        return_value=None,
    )

    reader = reader if reader is not None else mocker.MagicMock()
    UploadCommand(1, table, _file(), schema, reader).run()
    return _Upload(reader, sqla_cls, existing)


DEFAULT_SCHEMAS = ["public", "analytics", "dbo"]


# --------------------------------------------------------------------------- #
# An empty schema, omitted or "", is written to the database's default schema,
# and the new dataset is registered under that schema.
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("default_schema", DEFAULT_SCHEMAS)
@pytest.mark.parametrize("schema_in", [None, ""], ids=["omitted", "empty"])
def test_empty_schema_is_written_to_database_default(
    app_context, mocker, schema_in, default_schema
):
    upload = _drive_run(mocker, schema=schema_in, default_schema=default_schema)

    assert upload.written_schema == default_schema
    assert upload.created_dataset_schema == default_schema


# --------------------------------------------------------------------------- #
# A dataset for the table already exists under the default schema: an upload
# with an empty schema writes there and reuses that dataset.
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("default_schema", ["public", "analytics"])
@pytest.mark.parametrize("schema_in", [None, ""], ids=["omitted", "empty"])
def test_empty_schema_reuses_dataset_under_default(
    app_context, mocker, schema_in, default_schema
):
    upload = _drive_run(
        mocker,
        schema=schema_in,
        default_schema=default_schema,
        existing_schema=default_schema,
    )

    assert upload.written_schema == default_schema
    upload.sqla_cls.assert_not_called()
    upload.existing.fetch_metadata.assert_called_once()


# --------------------------------------------------------------------------- #
# An explicitly chosen schema is written as given, and a new dataset is
# registered under it, even when the database's default differs.
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("schema_in", ["sales", "other"])
def test_explicit_schema_is_written_as_given(app_context, mocker, schema_in):
    upload = _drive_run(mocker, schema=schema_in, default_schema="public")

    assert upload.written_schema == schema_in
    assert upload.created_dataset_schema == schema_in


# --------------------------------------------------------------------------- #
# The request path, upload-form load followed by the command: "undefined" and
# "" end up written to the database default, while a real schema name passes
# through unchanged.
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize(
    "schema_in,default_schema,expected",
    [
        ("undefined", "public", "public"),
        ("undefined", "analytics", "analytics"),
        ("", "dbo", "dbo"),
        ("myschema", "public", "myschema"),
        ("sales", "analytics", "sales"),
    ],
)
def test_request_path_handles_undefined_like_empty_schema(
    app_context, mocker, schema_in, default_schema, expected
):
    from superset.databases.schemas import UploadPostSchema

    loaded = UploadPostSchema().load({"schema": schema_in}, partial=True)
    upload = _drive_run(
        mocker, schema=loaded.get("schema"), default_schema=default_schema
    )

    assert upload.written_schema == expected
    assert upload.created_dataset_schema == expected


# --------------------------------------------------------------------------- #
# Upload allow-list, chosen schema: it must match an allow-list entry exactly,
# letter case included. A match is written as given; anything else is refused
# with DatabaseSchemaUploadNotAllowed and nothing is written.
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize(
    "schema_in,allowed,accepted",
    [
        ("public", {"public"}, True),
        ("sales", {"sales", "public"}, True),
        ("PUBLIC", {"public"}, False),
        ("public", {"PUBLIC"}, False),
        ("Sales", {"sales", "public"}, False),
        ("other", {"public"}, False),
    ],
)
def test_allowlist_chosen_schema_must_match_exactly(
    app_context, mocker, schema_in, allowed, accepted
):
    from superset.commands.database.exceptions import (
        DatabaseSchemaUploadNotAllowed,
    )

    if accepted:
        upload = _drive_run(
            mocker, schema=schema_in, default_schema="public", allowed=allowed
        )
        assert upload.written_schema == schema_in
    else:
        reader = mocker.MagicMock()
        with pytest.raises(DatabaseSchemaUploadNotAllowed):
            _drive_run(
                mocker,
                schema=schema_in,
                default_schema="public",
                allowed=allowed,
                reader=reader,
            )
        reader.read.assert_not_called()


# --------------------------------------------------------------------------- #
# Upload allow-list, empty schema: accepted and written to the default schema
# when the default is on the allow-list, refused when it is not.
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize(
    "schema_in,default_schema,allowed,accepted",
    [
        (None, "public", {"public"}, True),
        ("", "analytics", {"analytics", "sales"}, True),
        (None, "public", {"sales"}, False),
        ("", "analytics", {"public"}, False),
    ],
)
def test_allowlist_empty_schema_follows_default(
    app_context, mocker, schema_in, default_schema, allowed, accepted
):
    from superset.commands.database.exceptions import (
        DatabaseSchemaUploadNotAllowed,
    )

    if accepted:
        upload = _drive_run(
            mocker, schema=schema_in, default_schema=default_schema, allowed=allowed
        )
        assert upload.written_schema == default_schema
        assert upload.created_dataset_schema == default_schema
    else:
        reader = mocker.MagicMock()
        with pytest.raises(DatabaseSchemaUploadNotAllowed):
            _drive_run(
                mocker,
                schema=schema_in,
                default_schema=default_schema,
                allowed=allowed,
                reader=reader,
            )
        reader.read.assert_not_called()
