"""Backend checks for file uploads that leave the schema empty.

Behaviors covered:
  - an upload with an empty schema (field left out, "", or the text
    "undefined" the upload page sends) writes its rows into the database's
    default schema and registers the dataset under that schema
  - an existing dataset under the default schema is reused, not duplicated
  - a schema the user picks is where the rows and the dataset go
  - with an upload allow-list, a picked schema must match an entry exactly,
    and an empty schema is accepted when the default schema is on the list
    and refused when it is not

Every case posts a multipart form to the upload endpoint
(POST /api/v1/database/<pk>/upload/) of a real Superset app, against a real
Database row in the metadata database. The target database is a SQLite file
with one attached SQLite file per schema, so the upload really writes rows
and the new dataset really reads the table back. What the target database
reports as its default schema is set at the SQLAlchemy dialect, so it is the
same whichever Superset or SQLAlchemy call asks for it. The outcome is read
from the target files (which schema holds the table and its rows) and from
the dataset rows in the metadata database.
"""

from __future__ import annotations

import io
import json
import sqlite3
import sys
from pathlib import Path

import pytest
from sqlalchemy import event
from sqlalchemy.dialects.sqlite.base import SQLiteDialect
from sqlalchemy.engine import Engine

# The repo is editable-installed; keep the explicit path insert so the checks
# import superset.* even if invoked from outside the source root.
sys.path.insert(0, "/repo/superset")

# Schemas the target database has, each an attached SQLite file.
SCHEMAS = ["public", "analytics", "dbo", "sales", "other"]


# --------------------------------------------------------------------------- #
# App: built once, the way the repo's unit-test conftest builds it. The pytest
# runner executes this file by path, so the repo conftest is not loaded and the
# fixtures live here. The metadata database is a SQLite file.
# --------------------------------------------------------------------------- #
@pytest.fixture(scope="session")
def superset_app(tmp_path_factory):
    from superset.app import SupersetApp
    from superset.extensions import appbuilder
    from superset.initialization import SupersetAppInitializer

    app = SupersetApp(__name__)
    app.config.from_object("superset.config")
    app.config["SQLALCHEMY_DATABASE_URI"] = (
        f"sqlite:///{tmp_path_factory.mktemp('metadata') / 'superset.db'}"
    )
    app.config["WTF_CSRF_ENABLED"] = False
    app.config["TESTING"] = True
    app.config["RATELIMIT_ENABLED"] = False
    app.config["CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    app.config["DATA_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    app.config["FILTER_STATE_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    app.config["EXPLORE_FORM_DATA_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    app.config["GLOBAL_ASYNC_QUERIES_REDIS_CONFIG"] = None
    app.config["TALISMAN_ENABLED"] = False
    app.config["PREVENT_UNSAFE_DB_CONNECTIONS"] = False
    app.config["UPLOAD_MAX_FILE_SIZE_BYTES"] = None

    appbuilder.baseviews = []
    SupersetAppInitializer(app).init_app()

    from superset import db
    from superset.models.core import Database

    with app.app_context():
        Database.metadata.create_all(db.engine)
    return app


def _clear_metadata():
    from superset import db
    from superset.models.core import Database

    db.session.rollback()
    db.session.remove()
    # A plain DBAPI connection: the versioning hooks on SQLAlchemy connections
    # expect an ORM unit of work around every statement.
    conn = db.engine.raw_connection()
    try:
        cur = conn.cursor()
        for table in reversed(Database.metadata.sorted_tables):
            cur.execute(f'DELETE FROM "{table.name}"')
        conn.commit()
    finally:
        conn.close()


@pytest.fixture
def api(superset_app, mocker):
    """A test client with full API access and empty metadata tables."""
    from superset import security_manager

    mocker.patch(
        "flask_appbuilder.security.decorators.verify_jwt_in_request",
        return_value=True,
    )
    mocker.patch.object(security_manager, "is_item_public", return_value=True)
    mocker.patch.object(security_manager, "has_access", return_value=True)
    mocker.patch.object(security_manager, "can_access_all_databases", return_value=True)
    # The test client is anonymous; the upload records no editor for it.
    mocker.patch(
        "superset.commands.database.uploaders.base.get_user", return_value=None
    )

    with superset_app.app_context():
        _clear_metadata()
        with superset_app.test_client() as client:
            yield client
        _clear_metadata()


class Target:
    """The SQLite target database: main file plus one file per schema."""

    def __init__(self, root: Path):
        self.root = root
        self.main = root / "main.db"
        self.files = {name: root / f"{name}.db" for name in SCHEMAS}
        for path in [self.main, *self.files.values()]:
            sqlite3.connect(path).close()

    @property
    def uri(self) -> str:
        return f"sqlite:///{self.main}"

    def tables(self, schema: str | None) -> set[str]:
        """Tables in a schema; None is the target's own main file."""
        path = self.main if schema is None else self.files[schema]
        with sqlite3.connect(path) as conn:
            rows = conn.execute(
                "SELECT name FROM sqlite_master WHERE type = 'table'"
            ).fetchall()
        return {row[0] for row in rows}

    def where(self, table: str) -> list[str | None]:
        """Every schema (None for main) that holds the table."""
        return [
            schema for schema in [None, *SCHEMAS] if table in self.tables(schema)
        ]

    def rows(self, schema: str, table: str) -> list[tuple]:
        with sqlite3.connect(self.files[schema]) as conn:
            return conn.execute(f'SELECT * FROM "{table}" ORDER BY 1').fetchall()


@pytest.fixture
def target(tmp_path, mocker):
    """Attach the schema files on every connection to the target database,
    and let the test choose what the target reports as its default schema."""
    from superset.models import core as models_core

    tgt = Target(tmp_path)
    state = {"default": None}

    def _attach(dbapi_conn, _record):
        cur = dbapi_conn.cursor()
        try:
            files = {row[2] for row in cur.execute("PRAGMA database_list")}
            if str(tgt.main) in files:
                for name, path in tgt.files.items():
                    cur.execute(f"ATTACH DATABASE '{path}' AS \"{name}\"")
        finally:
            cur.close()

    event.listen(Engine, "connect", _attach)

    real_default = SQLiteDialect._get_default_schema_name

    def _default_schema_name(self, connection):
        if str(connection.engine.url.database) == str(tgt.main):
            return state["default"]
        return real_default(self, connection)

    mocker.patch.object(SQLiteDialect, "_get_default_schema_name", _default_schema_name)
    tgt.state = state
    yield tgt
    event.remove(Engine, "connect", _attach)
    cache = getattr(models_core, "_ENGINE_CACHE", None)
    if cache is not None:
        for engine in list(cache.values()):
            engine.dispose()
        cache.clear()


def _add_database(*, uri: str, allowed=None) -> int:
    from superset import db
    from superset.models.core import Database

    extra = {}
    if allowed is not None:
        extra["schemas_allowed_for_file_upload"] = sorted(allowed)
    database = Database(
        database_name="uploads",
        sqlalchemy_uri=uri,
        allow_file_upload=True,
        extra=json.dumps(extra),
    )
    db.session.add(database)
    db.session.commit()
    return database.id


def _add_dataset(database_id: int, table: str, schema: str) -> int:
    from superset import db
    from superset.connectors.sqla.models import SqlaTable

    dataset = SqlaTable(table_name=table, schema=schema, database_id=database_id)
    db.session.add(dataset)
    db.session.commit()
    return dataset.id


def _datasets(table: str) -> list[tuple[int, str | None]]:
    from superset import db
    from superset.connectors.sqla.models import SqlaTable

    db.session.expire_all()
    found = db.session.query(SqlaTable).filter_by(table_name=table).all()
    return sorted(((d.id, d.schema) for d in found), key=lambda item: item[0])


OMITTED = object()


def _upload(client, database_id: int, table: str, schema, rows: list[int]):
    body = "num\n" + "".join(f"{value}\n" for value in rows)
    data = {
        "type": "csv",
        "table_name": table,
        "file": (io.BytesIO(body.encode()), f"{table}.csv"),
        "already_exists": "fail",
    }
    if schema is not OMITTED:
        data["schema"] = schema
    return client.post(
        f"/api/v1/database/{database_id}/upload/",
        data=data,
        content_type="multipart/form-data",
    )


EMPTY_SCHEMAS = [OMITTED, "", "undefined"]
EMPTY_IDS = ["left-out", "empty", "undefined"]


def _accepted(response, target, table, schema, rows):
    assert response.status_code == 201, response.get_data(as_text=True)
    assert target.where(table) == [schema]
    assert target.rows(schema, table) == [(value,) for value in rows]


def _refused(response, target, table):
    from superset.commands.database.exceptions import (
        DatabaseSchemaUploadNotAllowed,
    )

    assert response.status_code == DatabaseSchemaUploadNotAllowed.status, (
        response.get_data(as_text=True)
    )
    assert "not allowed" in response.get_data(as_text=True)
    assert target.where(table) == []
    assert _datasets(table) == []


# --------------------------------------------------------------------------- #
# An empty schema writes the rows into the database's default schema, and the
# new dataset is registered under that schema.
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("default_schema", ["public", "analytics", "dbo"])
@pytest.mark.parametrize("schema_in", EMPTY_SCHEMAS, ids=EMPTY_IDS)
def test_empty_schema_goes_to_database_default(api, target, schema_in, default_schema):
    target.state["default"] = default_schema
    database_id = _add_database(uri=target.uri)
    table = f"orders_{default_schema}"
    rows = [3, 1, len(default_schema)]

    response = _upload(api, database_id, table, schema_in, rows)

    _accepted(response, target, table, default_schema, sorted(rows))
    datasets = _datasets(table)
    assert [schema for _, schema in datasets] == [default_schema]


# --------------------------------------------------------------------------- #
# A dataset for the table already exists under the default schema: an upload
# with an empty schema writes there and keeps that one dataset.
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("default_schema", ["public", "analytics"])
@pytest.mark.parametrize("schema_in", EMPTY_SCHEMAS, ids=EMPTY_IDS)
def test_empty_schema_reuses_dataset_under_default(api, target, schema_in, default_schema):
    target.state["default"] = default_schema
    database_id = _add_database(uri=target.uri)
    table = f"events_{default_schema}"
    existing_id = _add_dataset(database_id, table, default_schema)

    response = _upload(api, database_id, table, schema_in, [7, 8])

    _accepted(response, target, table, default_schema, [7, 8])
    assert _datasets(table) == [(existing_id, default_schema)]


# --------------------------------------------------------------------------- #
# A picked schema is where the rows go and where the dataset is registered,
# whatever the database's default is.
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize(
    "schema_in,default_schema",
    [("sales", "public"), ("other", "public"), ("public", "analytics")],
)
def test_picked_schema_is_used(api, target, schema_in, default_schema):
    target.state["default"] = default_schema
    database_id = _add_database(uri=target.uri)
    table = f"picked_{schema_in}"

    response = _upload(api, database_id, table, schema_in, [5, 6])

    _accepted(response, target, table, schema_in, [5, 6])
    assert [schema for _, schema in _datasets(table)] == [schema_in]


# --------------------------------------------------------------------------- #
# Upload allow-list, picked schema: it must match an allow-list entry exactly,
# letter case included. A match is written as given; anything else is refused
# as not allowed and nothing is written.
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize(
    "schema_in,allowed,accepted",
    [
        ("public", {"public"}, True),
        ("sales", {"sales", "public"}, True),
        ("PUBLIC", {"public"}, False),
        ("public", {"PUBLIC"}, False),
        ("Sales", {"sales", "public"}, False),
        ("other", {"public"}, False),
    ],
)
def test_allowlist_picked_schema_must_match_exactly(
    api, target, schema_in, allowed, accepted
):
    target.state["default"] = "public"
    database_id = _add_database(uri=target.uri, allowed=allowed)
    table = f"listed_{schema_in.lower()}"

    response = _upload(api, database_id, table, schema_in, [1, 2])

    if accepted:
        _accepted(response, target, table, schema_in, [1, 2])
    else:
        _refused(response, target, table)


# --------------------------------------------------------------------------- #
# Upload allow-list, empty schema: accepted and written to the default schema
# when the default is on the allow-list, refused when it is not.
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize(
    "schema_in,default_schema,allowed,accepted",
    [
        (OMITTED, "public", {"public"}, True),
        ("", "analytics", {"analytics", "sales"}, True),
        ("undefined", "dbo", {"dbo", "public"}, True),
        (OMITTED, "public", {"sales"}, False),
        ("", "analytics", {"public"}, False),
        ("undefined", "dbo", {"sales", "other"}, False),
    ],
    ids=[
        "left-out-listed",
        "empty-listed",
        "undefined-listed",
        "left-out-unlisted",
        "empty-unlisted",
        "undefined-unlisted",
    ],
)
def test_allowlist_empty_schema_follows_default(
    api, target, schema_in, default_schema, allowed, accepted
):
    target.state["default"] = default_schema
    database_id = _add_database(uri=target.uri, allowed=allowed)
    table = f"blank_{default_schema}"

    response = _upload(api, database_id, table, schema_in, [4, 9])

    if accepted:
        _accepted(response, target, table, default_schema, [4, 9])
        assert [schema for _, schema in _datasets(table)] == [default_schema]
    else:
        _refused(response, target, table)
