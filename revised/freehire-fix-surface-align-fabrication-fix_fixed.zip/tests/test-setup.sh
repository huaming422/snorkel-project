#!/usr/bin/env bash
# Environment bootstrap for the verifier.
#
# Dependencies are baked into the image, with the Go module and build caches
# warm. There is nothing to fetch or install here.
#
# We force Go offline so a verifier run can never silently reach the network:
# GOPROXY=off makes any attempted module download a hard, visible error instead
# of a hang, and GOFLAGS=-mod=mod keeps builds working against the warm cache.
set -euo pipefail

export GOPROXY=off
export GOFLAGS=-mod=mod
export GOTOOLCHAIN=local

echo "[test-setup] freehire-fix-surface-align-fabrication: deps baked; Go set to offline (GOPROXY=off)"
