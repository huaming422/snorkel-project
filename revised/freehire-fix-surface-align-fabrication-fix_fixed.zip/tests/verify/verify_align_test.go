// Internal-package (cv) test. Every test drives the two public entry points of
// the wording-alignment step that tailoring runs:
//
//   skilltag.PreferredFromText(text) map[string]string
//   cv.Align(doc, preferred)           -> the rewritten CV document
//
// The tests read only what these two return: the rewritten document, and the
// spellings resolved from a vacancy. They never name or import anything
// beneath them. cv.Align may return the document alone or the document plus a
// "changed" flag, so it is called reflectively and only the document is read.
// Repeat runs are compared by the document itself, not by any flag.
//
// Inputs are built the way the in-tree tests build them (cv.Document with skill
// groups, experience stacks, summaries and bullets), and vacancy text always
// goes through PreferredFromText, so the preferred map comes from the code
// under test rather than being assembled by hand.

package cv

import (
	"reflect"
	"strings"
	"testing"

	"github.com/strelov1/freehire/internal/skilltag"
)

// alignDoc calls cv.Align reflectively and returns only the rewritten document.
// Align may be func(Document, map[string]string) Document or
// func(Document, map[string]string) (Document, bool); a second result, if any,
// is ignored.
func alignDoc(t *testing.T, doc Document, preferred map[string]string) Document {
	t.Helper()
	fn := reflect.ValueOf(Align)
	out := fn.Call([]reflect.Value{reflect.ValueOf(doc), reflect.ValueOf(preferred)})
	if len(out) == 0 {
		t.Fatalf("Align returned no values")
	}
	d, ok := out[0].Interface().(Document)
	if !ok {
		t.Fatalf("Align's first result is %T, want cv.Document", out[0].Interface())
	}
	return d
}

// firstChip is a tiny accessor so a malformed result fails loudly instead of
// panicking with an index error.
func firstChip(t *testing.T, doc Document) string {
	t.Helper()
	if len(doc.Skills) == 0 || len(doc.Skills[0].Items) == 0 {
		t.Fatalf("expected at least one skill chip, got %#v", doc.Skills)
	}
	return doc.Skills[0].Items[0]
}

// spellingFor resolves a vacancy sentence that names exactly one skill and
// returns the spelling PreferredFromText chose for it, so a test can expect
// that skill's own spelling without naming a canonical key or hardcoding it.
func spellingFor(t *testing.T, text string) string {
	t.Helper()
	preferred := skilltag.PreferredFromText(text)
	if len(preferred) != 1 {
		t.Fatalf("vacancy %q resolved %#v, want exactly one skill", text, preferred)
	}
	for _, v := range preferred {
		if v == "" {
			t.Fatalf("vacancy %q resolved an empty spelling: %#v", text, preferred)
		}
		return v
	}
	return ""
}

// TestVerifyNarrowerTermDoesNotFabricateSkill: when a vacancy names a different
// (narrower, broader, versioned or related) technology than the one the
// candidate listed, the candidate's skill stays as written everywhere it
// appears: the skill chip, the experience stack, and experience and project
// bullets. Alignment may change how a skill is spelled, never which skill it is.
//
// Some vacancy terms contain the candidate's word ("Ruby on Rails" and "Ruby")
// and some do not ("continuous delivery" and "CI/CD", "GA4" and "Google
// Analytics").
func TestVerifyNarrowerTermDoesNotFabricateSkill(t *testing.T) {
	cases := []struct {
		name string
		chip string
		jd   string
	}{
		{"rails_is_not_ruby", "Ruby", "We are a Ruby on Rails shop."},
		{"spring_boot_is_not_spring", "Spring", "Java 17 with Spring Boot microservices."},
		{"c_developer_is_not_c", "C", "Looking for a C developer."},
		{"restful_is_not_rest", "REST", "You will design RESTful APIs."},
		{"html5_is_not_html", "HTML", "Frontend with HTML5 and CSS3."},
		{"continuous_delivery_is_not_cicd", "CI/CD", "We practice continuous delivery on every service."},
		{"object_oriented_design_is_not_oop", "OOP", "Strong object oriented design skills."},
		{"ga4_is_not_google_analytics", "Google Analytics", "Track funnels in GA4 and Looker."},
		{"shell_is_not_bash", "Bash", "Shell scripting on Linux servers with Docker."},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			preferred := skilltag.PreferredFromText(tc.jd)
			bullet := "Built services with " + tc.chip + " for years."
			doc := Document{
				Skills: []SkillGroup{{Items: []string{tc.chip}}},
				Experience: []ExperienceItem{{
					Stack:   []string{tc.chip},
					Bullets: []string{bullet},
				}},
				Projects: []Project{{Bullets: []string{bullet}}},
			}
			got := alignDoc(t, doc, preferred)
			if c := firstChip(t, got); c != tc.chip {
				t.Fatalf("chip changed from %q to %q for vacancy %q; another technology must not replace the candidate's skill",
					tc.chip, c, tc.jd)
			}
			if s := got.Experience[0].Stack; len(s) != 1 || s[0] != tc.chip {
				t.Fatalf("experience stack changed from [%q] to %#v for vacancy %q", tc.chip, s, tc.jd)
			}
			if b := got.Experience[0].Bullets[0]; b != bullet {
				t.Fatalf("bullet changed from %q to %q for vacancy %q", bullet, b, tc.jd)
			}
			if b := got.Projects[0].Bullets[0]; b != bullet {
				t.Fatalf("project bullet changed from %q to %q for vacancy %q", bullet, b, tc.jd)
			}
		})
	}
}

// TestVerifyInterchangeableSpellingStillAligns: when a vacancy writes another
// spelling of the same skill the candidate wrote (an acronym and its expansion),
// the chip, the experience stack entry, and experience and project bullets are
// all rewritten to the vacancy's spelling.
//
// The vacancy spells two skills out in full and the candidate wrote the
// acronyms. Each acronym must become its own skill's spelling: the expected
// spelling for each skill is what PreferredFromText gives for a sentence that
// names that skill alone, never a hardcoded spelling or canonical key.
func TestVerifyInterchangeableSpellingStillAligns(t *testing.T) {
	jd := "We run Kubernetes clusters and practice infrastructure as code throughout."
	preferred := skilltag.PreferredFromText(jd)
	if len(preferred) < 2 {
		t.Fatalf("vacancy did not resolve two skills: preferred=%#v", preferred)
	}
	kube := spellingFor(t, "We run Kubernetes clusters.")
	iac := spellingFor(t, "We practice infrastructure as code throughout.")

	inChips := []string{"IaC", "k8s"}
	wantChips := []string{iac, kube}
	doc := Document{
		Skills: []SkillGroup{{Items: append([]string(nil), inChips...)}},
		Experience: []ExperienceItem{{
			Stack:   []string{"k8s"},
			Bullets: []string{"Ran k8s clusters for the platform team."},
		}},
		Projects: []Project{{Bullets: []string{"Moved the build farm to k8s."}}},
	}
	got := alignDoc(t, doc, preferred)

	chips := got.Skills[0].Items
	if len(chips) != len(inChips) {
		t.Fatalf("chip count changed: got %#v, want %d chips", chips, len(inChips))
	}
	for i, c := range chips {
		if c != wantChips[i] {
			t.Fatalf("chip %q became %q, want %q; result %#v", inChips[i], c, wantChips[i], chips)
		}
	}
	if stack := got.Experience[0].Stack; len(stack) != 1 || stack[0] != kube {
		t.Fatalf("experience stack = %#v, want [%q]", stack, kube)
	}
	wantBullet := strings.Replace(doc.Experience[0].Bullets[0], "k8s", kube, 1)
	if b := got.Experience[0].Bullets[0]; b != wantBullet {
		t.Fatalf("bullet = %q, want %q", b, wantBullet)
	}
	wantProject := strings.Replace(doc.Projects[0].Bullets[0], "k8s", kube, 1)
	if b := got.Projects[0].Bullets[0]; b != wantProject {
		t.Fatalf("project bullet = %q, want %q", b, wantProject)
	}
}

// TestVerifyNonAsciiVacancyIsSafe: vacancy text and CV text with non-English
// letters (such as İ, Ⱥ, ẞ and Cyrillic) neither panic nor change what
// alignment does.
//
//   - A vacancy that carries such letters before its skills resolves to the
//     same spellings, and aligns a CV to the same result, as the same vacancy
//     without them.
//   - A CV summary that names a non-English place next to a skill still gets
//     that skill aligned, and the place name comes through intact.
func TestVerifyNonAsciiVacancyIsSafe(t *testing.T) {
	const skills = "We run Kubernetes and infrastructure as code."
	cvDoc := func() Document {
		return Document{
			Summary: "Ran k8s clusters and IaC pipelines.",
			Skills:  []SkillGroup{{Items: []string{"IaC", "k8s"}}},
		}
	}

	t.Run("non_ascii_description_resolves_like_plain_text", func(t *testing.T) {
		plain := skilltag.PreferredFromText(skills)
		if len(plain) < 2 {
			t.Fatalf("plain vacancy did not resolve both skills: %#v", plain)
		}
		want := alignDoc(t, cvDoc(), plain)
		for _, prefix := range []string{
			strings.Repeat("Ⱥ", 200) + " ",
			strings.Repeat("İ", 40) + " ",
			"İstanbul office, Ⱥrhus team. ",
		} {
			func() {
				defer func() {
					if r := recover(); r != nil {
						t.Fatalf("vacancy starting %q panicked: %v", prefix[:8], r)
					}
				}()
				got := skilltag.PreferredFromText(prefix + skills)
				if !reflect.DeepEqual(got, plain) {
					t.Fatalf("vacancy starting %q resolved %#v, the same text without it resolved %#v", prefix[:8], got, plain)
				}
				if doc := alignDoc(t, cvDoc(), got); !reflect.DeepEqual(doc, want) {
					t.Fatalf("vacancy starting %q aligned the CV to %#v, want %#v", prefix[:8], doc, want)
				}
			}()
		}
	})

	t.Run("skill_aligns_around_non_ascii_text", func(t *testing.T) {
		preferred := skilltag.PreferredFromText(skills)
		if len(preferred) == 0 {
			t.Fatalf("vacancy resolved no skills: %#v", preferred)
		}
		kube := spellingFor(t, "We run Kubernetes clusters.")
		for _, name := range []string{"İstanbul", "Ⱥrhus", "Straẞe", "Кёльн"} {
			doc := Document{Summary: "Led the " + name + " team that ran k8s in production."}
			got := alignDoc(t, doc, preferred).Summary
			if want := "Led the " + name + " team that ran " + kube + " in production."; got != want {
				t.Fatalf("summary with %q not aligned around the non-ASCII text: got %q, want %q", name, got, want)
			}
		}
	})
}

// TestVerifyAlignmentIsIdempotent: running alignment again over its own output
// changes nothing, for the summary and for bullets. Each case has a vacancy
// spelling that ends in a word another spelling also uses ("REST APIs",
// "Vue.js", "Google Cloud Platform"). Stability is checked by comparing whole
// documents across runs, never through a change flag. A third run rules out a
// two-step cycle.
func TestVerifyAlignmentIsIdempotent(t *testing.T) {
	cases := []struct {
		name    string
		jd      string
		summary string
		bullet  string
	}{
		{"rest_apis", "You will design REST APIs for the platform.",
			"Built REST APIs for scale.", "Owned the REST APIs powering checkout."},
		{"vue_js", "Frontend work in Vue.js and TypeScript.",
			"Built VueJS dashboards and Vue.js widgets.", "Moved the admin UI to Vue.js."},
		{"google_cloud_platform", "We deploy everything on Google Cloud Platform.",
			"Ran GCP projects and Google Cloud Platform billing.", "Cut Google Cloud Platform spend by a third."},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			preferred := skilltag.PreferredFromText(tc.jd)
			doc := Document{
				Summary: tc.summary,
				Experience: []ExperienceItem{{
					Stack:   []string{"k8s"},
					Bullets: []string{tc.bullet},
				}},
			}
			first := alignDoc(t, doc, preferred)
			second := alignDoc(t, first, preferred)
			if !reflect.DeepEqual(first, second) {
				t.Fatalf("second alignment changed the document:\n first  = %#v\n second = %#v", first, second)
			}
			third := alignDoc(t, second, preferred)
			if !reflect.DeepEqual(second, third) {
				t.Fatalf("third alignment changed the document:\n second = %#v\n third = %#v", second, third)
			}
		})
	}
}

// TestVerifyProseAbbreviationNotExpanded: an abbreviation that means something
// else in ordinary prose stays as written in a summary or bullet, even when the
// vacancy names a skill it could stand for. "RAG status" is red/amber/green
// project health, not retrieval augmented generation; "our CSM team" is
// customer success, not a Certified ScrumMaster.
func TestVerifyProseAbbreviationNotExpanded(t *testing.T) {
	cases := []struct {
		name     string
		jd       string
		summary  string
		bullet   string
		expanded string
	}{
		{"rag_status", "You will build LLM features using retrieval augmented generation.",
			"Programme lead reporting RAG status to the steering committee.",
			"Ran the weekly RAG review with stakeholders.",
			"retrieval augmented generation"},
		{"csm_team", "Certified ScrumMaster with Kubernetes experience.",
			"Partnered with our CSM team on renewals.",
			"Weekly sync with the CSM and account owners.",
			"scrum"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			preferred := skilltag.PreferredFromText(tc.jd)
			doc := Document{
				Summary: tc.summary,
				Experience: []ExperienceItem{{
					Bullets: []string{tc.bullet},
				}},
			}
			got := alignDoc(t, doc, preferred)
			if strings.Contains(strings.ToLower(got.Summary), tc.expanded) {
				t.Fatalf("summary expanded an abbreviation in prose: %q", got.Summary)
			}
			if got.Summary != tc.summary {
				t.Fatalf("summary prose was rewritten; got %q, want unchanged %q", got.Summary, tc.summary)
			}
			if b := got.Experience[0].Bullets[0]; b != tc.bullet {
				t.Fatalf("bullet prose was rewritten; got %q, want unchanged %q", b, tc.bullet)
			}
		})
	}
}

// TestVerifySpellingIsCleanAndDeterministic: the spellings resolved from a
// vacancy carry none of its formatting. Markup, line breaks, doubled spaces
// and the capitals of a shouted heading stay out, so a vacancy written as
// HTML or in capitals resolves the same skills, and the same words, as the
// plain sentence. Repeated calls on one text give the same answer.
//
// Each noisy text is compared with the plain resolution case-insensitively,
// so the check pins no particular casing beyond "not all capitals".
func TestVerifySpellingIsCleanAndDeterministic(t *testing.T) {
	plain := skilltag.PreferredFromText("We run Kubernetes and infrastructure as code (Terraform).")
	if len(plain) < 2 {
		t.Fatalf("plain vacancy did not resolve both skills: %#v", plain)
	}

	noisy := map[string]string{
		"html_markup_and_line_breaks": "<ul><li>Strong <b>infrastructure</b> as code (Terraform)</li>\n" +
			"<li>Runs on\nKubernetes</li></ul> REQUIREMENTS: KUBERNETES EXPERIENCE.",
		"shouted_heading_only": "<h3>REQUIREMENTS</h3><p>KUBERNETES, INFRASTRUCTURE\nAS CODE, TERRAFORM</p>",
	}
	for name, text := range noisy {
		t.Run(name, func(t *testing.T) {
			first := skilltag.PreferredFromText(text)
			if len(first) != len(plain) {
				t.Fatalf("noisy vacancy resolved %#v, plain vacancy resolved %#v", first, plain)
			}
			for key, want := range plain {
				got, ok := first[key]
				if !ok {
					t.Fatalf("noisy vacancy lost %q: noisy %#v, plain %#v", key, first, plain)
				}
				if !strings.EqualFold(got, want) {
					t.Fatalf("noisy vacancy spelled %q as %q, plain vacancy as %q", key, got, want)
				}
				if got == strings.ToUpper(got) && got != strings.ToLower(got) && want != strings.ToUpper(want) {
					t.Fatalf("spelling %q carries the capitals of a shouted heading (plain: %q)", got, want)
				}
			}
			for i := 0; i < 200; i++ {
				if again := skilltag.PreferredFromText(text); !reflect.DeepEqual(again, first) {
					t.Fatalf("PreferredFromText is not deterministic: run %d = %#v, first = %#v", i, again, first)
				}
			}
		})
	}
}
