## Task

Candidates keep telling us that tailoring a CV to a job posting mangles it.
Here is what they report.

- Skills they never listed show up after tailoring.
  Someone who wrote "Ruby" gets "Ruby on Rails" after tailoring to a Rails job, "Spring" turns into "Spring Boot", and "CI/CD" turns into "continuous delivery".
  It doesn't stop at the skills list: the tech stack under each job and the bullet text get the same treatment.
- Ordinary wording in their experience gets rewritten.
  One candidate's "reporting RAG status to the steering committee" came back talking about retrieval augmented generation.
  An abbreviation that means something else in a normal sentence should stay as written.
- For some postings, "tailor for me" fails every single time, so the CV can never be tailored to that posting.
  The postings it happens with have non-English text in them.
- Running the automatic tailoring again keeps making some bullets longer.
  "REST APIs" picks up another "APIs" on every run.
- Now and then a skill comes out with doubled spaces, or in ALL CAPS copied from a heading in the posting.

The part where tailoring switches a skill to the spelling the posting uses is wanted and has to keep working.
If the posting says "Kubernetes" or "infrastructure as code", a CV that says "k8s" or "IaC" should switch to the posting's spelling in the skills list, in each job's stack and in the bullets.
That has to work just the same when the CV or the posting contains non-English letters.

Please find what is corrupting the tailored CVs and fix it.
Tailoring may change how a skill is spelled, but never which skill it is.
Running it again on a CV it has already tailored should change nothing, and the same posting should always give the same result.
