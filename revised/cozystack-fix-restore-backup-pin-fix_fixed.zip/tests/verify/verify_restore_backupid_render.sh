#!/usr/bin/env bash
#
# Renders the postgres chart and checks that a restore carries its base-backup
# selector into the recovery target of the cnpg.io Cluster it emits:
#   1. selector set, no recovery time: recoveryTarget.backupID carries the id
#      and no stop target is rendered, so recovery still replays the archive to
#      its end;
#   2. selector and recovery time both set: recoveryTarget carries the id and
#      targetTime keeps the requested instant.
#
# The value the chart reads the selector from is a shape the chart shapes (the
# existing recovery block already renders .Values.bootstrap.recoveryTime onto the
# CNPG field named targetTime - the value key and the CNPG field are not the same
# word), so this verifier does not assume what that value is called. It collects
# the bootstrap value keys the chart's templates read and the keys values.yaml
# declares under bootstrap, drops the recovery keys the chart already had, and
# tries each remaining key on its own. The key that puts the id at
# bootstrap.recovery.recoveryTarget.backupID (the name the cnpg.io Cluster CRD
# gives the field) is the selector. The restore controller writes the selector
# onto the Postgres app spec, so the same key must also be a field of the
# Postgres app type the controller patches.
#
# Exit codes:
#   0        - every render case holds
#   non-zero - one does not

set -euo pipefail

REPO="/repo/${REPO_NAME:-cozystack}"
CHART="${REPO}/packages/apps/postgres"
TEMPLATE_DIR="${CHART}/templates"
APP_TYPES_DIR="${REPO}/internal/backupcontroller/postgresapp"

# A distinctive, timestamp-shaped id that does not collide with the other
# recovery values the render carries (server names, the recovery instant).
BACKUP_ID="20260921T062713"
RECOVERY_TIME="2026-09-22T10:00:00Z"

# Recovery value keys the chart already had before a base-backup selector was
# added. Any other bootstrap value key is a candidate for the selector.
KNOWN_BOOTSTRAP_KEYS=$'enabled\noldName\nserverName\nnewServerName\nrecoveryTime'

if [[ ! -d "${TEMPLATE_DIR}" ]]; then
  echo "render: chart templates not found at ${TEMPLATE_DIR}" >&2
  exit 1
fi

# Candidate keys: every .Values.bootstrap.<key> (dotted paths included) the
# templates read, plus every key declared under bootstrap in values.yaml, minus
# the keys the chart already had. Scans the whole templates tree so a selector
# routed through a helper template is still found.
mapfile -t NEW_KEYS < <(
  {
    grep -rhoE '\.Values\.bootstrap\.[A-Za-z0-9_.]+' "${TEMPLATE_DIR}" \
      | sed -e 's/^\.Values\.bootstrap\.//' -e 's/\.*$//' || true
    awk '
      /^bootstrap:/ { inb = 1; next }
      inb && /^[^ \t#]/ { inb = 0 }
      inb && /^  [A-Za-z0-9_]+:/ { k = $0; sub(/^  /, "", k); sub(/:.*/, "", k); print k }
    ' "${CHART}/values.yaml"
  } | sort -u | grep -vxF "${KNOWN_BOOTSTRAP_KEYS}" || true
)

# Common inputs for a restore render: a bootstrap.recovery with S3 coordinates.
BASE_ARGS=(
  --set-json '_cluster.scheduling={}'
  --set backup.enabled=true
  --set backup.useSystemBucket=false
  --set backup.s3AccessKey=AKIAEXAMPLE
  --set backup.s3SecretKey=s3cr3t
  --set backup.destinationPath=s3://bucket/pg-test/
  --set bootstrap.enabled=true
  --set bootstrap.oldName=pg-test
)

render() {
  helm template pg-test . --namespace tenant-test "${BASE_ARGS[@]}" "$@"
}

# Prints the lines nested under the rendered recoveryTarget key.
recovery_target() {
  awk '
    rt {
      match($0, /^[ \t]*/)
      if ($0 !~ /^[ \t]*$/ && RLENGTH <= ind) { rt = 0 } else { print; next }
    }
    /^[ \t]*recoveryTarget:[ \t]*$/ { rt = 1; match($0, /^[ \t]*/); ind = RLENGTH }
  '
}

# Succeeds when the block on stdin sets field to value, quoted or not.
field_is() {
  grep -E "^[[:space:]]*$1:[[:space:]]*[\"']?$2[\"']?[[:space:]]*$" >/dev/null
}

cd "${CHART}"

SELECTOR=""
SELECTOR_ONLY=""
for k in "${NEW_KEYS[@]}"; do
  [[ -n "${k}" ]] || continue
  out="$(render --set "bootstrap.${k}=${BACKUP_ID}" 2>/dev/null)" || continue
  if printf '%s\n' "${out}" | recovery_target | field_is backupID "${BACKUP_ID}"; then
    SELECTOR="${k}"
    SELECTOR_ONLY="${out}"
    break
  fi
done

if [[ -z "${SELECTOR}" ]]; then
  echo "fail: no bootstrap value carries the base backup into recoveryTarget.backupID;" >&2
  echo "      the recovery would let the plugin pick a backup from the catalog instead." >&2
  if [[ ${#NEW_KEYS[@]} -eq 0 || -z "${NEW_KEYS[*]}" ]]; then
    echo "      (the chart reads and declares no bootstrap value key beyond the pre-existing ones.)" >&2
  fi
  exit 1
fi
echo "ok: bootstrap.${SELECTOR} renders recoveryTarget.backupID (${BACKUP_ID})"

FIELD="${SELECTOR##*.}"
if ! grep -rqE "json:\"${FIELD}[,\"]" "${APP_TYPES_DIR}"; then
  echo "fail: the chart reads bootstrap.${SELECTOR}, but the Postgres app type the restore controller patches has no field named ${FIELD}" >&2
  exit 1
fi

# Case 1: with no recovery time the restore still recovers to the end of the
# archive, so no stop target sits next to the selector.
if printf '%s\n' "${SELECTOR_ONLY}" | recovery_target \
    | grep -E '^[[:space:]]*(targetTime|targetLSN|targetXID|targetName):|^[[:space:]]*targetImmediate:[[:space:]]*true' >/dev/null; then
  echo "fail: with no recovery time the recovery target also sets a stop target, so recovery stops short of the end of the archive:" >&2
  printf '%s\n' "${SELECTOR_ONLY}" | recovery_target >&2
  exit 1
fi
echo "ok: with no recovery time no stop target is rendered"

# Case 2: selector and recovery time together.
BOTH_RENDER="$(render --set "bootstrap.${SELECTOR}=${BACKUP_ID}" --set "bootstrap.recoveryTime=${RECOVERY_TIME}")"
BOTH="$(printf '%s\n' "${BOTH_RENDER}" | recovery_target)"
if ! printf '%s\n' "${BOTH}" | field_is backupID "${BACKUP_ID}"; then
  echo "fail: with a recovery time set, recoveryTarget.backupID no longer carries ${BACKUP_ID}" >&2
  exit 1
fi
if ! printf '%s\n' "${BOTH}" | field_is targetTime "${RECOVERY_TIME}"; then
  echo "fail: with the selector set, recoveryTarget.targetTime no longer carries ${RECOVERY_TIME}" >&2
  exit 1
fi
echo "ok: selector and recovery time render together (${BACKUP_ID}, ${RECOVERY_TIME})"
