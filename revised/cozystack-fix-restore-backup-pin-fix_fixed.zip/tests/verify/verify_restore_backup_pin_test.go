package backupcontroller

// White-box checks for the CNPG copy-restore path: they drive the real
// reconcile entry point (reconcileCNPGRestore) against a fake API server and
// read back the recovery configuration the target Postgres app is patched with
// when a restore runs. The repo's own suite for this package is white-box
// (package backupcontroller) for the same reason - the restore logic is
// package-internal with no exported seam - so these live in the same package
// and reach the same functions its siblings do.
//
// This file owns TestMain, so the shared runner moves the package's other
// *_test.go files aside while it runs and restores them afterwards. That keeps
// a self-contained copy of the small fixtures it needs (a Postgres app builder,
// a fake client builder, a dynamic-client scheme) rather than borrowing the
// siblings', which are not present during the run.
//
// What this file reads from the source status of the restored backup (its
// barman id and when it ended) are fields the CNPG Backup resource carries in
// its own CRD (status.backupId / status.stoppedAt). What it reads back off the
// patched app is matched by the VALUE it expects to find, not by the name of
// the field that carries it: the recovery configuration the restore writes onto
// the app is a shape the change gets to choose, so a check that named a field
// would accept only one spelling of a free choice. Finding the id among the
// recovery settings holds whatever the change calls the field.

import (
	"context"
	"encoding/json"
	"strings"
	"testing"
	"time"

	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apimachinery/pkg/types"
	dynamicfake "k8s.io/client-go/dynamic/fake"
	"k8s.io/client-go/kubernetes/scheme"
	"k8s.io/client-go/tools/record"
	"sigs.k8s.io/controller-runtime/pkg/client"
	clientfake "sigs.k8s.io/controller-runtime/pkg/client/fake"

	strategyv1alpha1 "github.com/cozystack/cozystack/api/backups/strategy/v1alpha1"
	backupsv1alpha1 "github.com/cozystack/cozystack/api/backups/v1alpha1"
	"github.com/cozystack/cozystack/internal/backupcontroller/cnpgtypes"
	"github.com/cozystack/cozystack/internal/backupcontroller/postgresapp"
)

func TestMain(m *testing.M) {
	m.Run()
}

// --- self-contained fixtures ------------------------------------------------

func mkPostgresApp(name, namespace string) *postgresapp.Postgres {
	return &postgresapp.Postgres{
		TypeMeta: metav1.TypeMeta{
			APIVersion: postgresapp.GroupVersion.String(),
			Kind:       postgresapp.Kind,
		},
		ObjectMeta: metav1.ObjectMeta{Name: name, Namespace: namespace},
	}
}

func mkDynamicScheme(t *testing.T) *runtime.Scheme {
	t.Helper()
	s := runtime.NewScheme()
	_ = scheme.AddToScheme(s)
	s.AddKnownTypeWithName(schema.GroupVersionKind{Group: "helm.toolkit.fluxcd.io", Version: "v2", Kind: "HelmRelease"}, &unstructured.Unstructured{})
	s.AddKnownTypeWithName(schema.GroupVersionKind{Group: "helm.toolkit.fluxcd.io", Version: "v2", Kind: "HelmReleaseList"}, &unstructured.UnstructuredList{})
	return s
}

func mkFakeClient(t *testing.T, objs ...client.Object) client.Client {
	t.Helper()
	s := runtime.NewScheme()
	_ = scheme.AddToScheme(s)
	_ = backupsv1alpha1.AddToScheme(s)
	_ = strategyv1alpha1.AddToScheme(s)
	_ = cnpgtypes.AddToScheme(s)
	_ = postgresapp.AddToScheme(s)
	return clientfake.NewClientBuilder().
		WithScheme(s).
		WithObjects(objs...).
		WithStatusSubresource(&backupsv1alpha1.BackupJob{}, &backupsv1alpha1.RestoreJob{}, &backupsv1alpha1.Backup{}).
		Build()
}

// bootstrapHasValue reports whether the value appears anywhere in the recovery
// settings the restore wrote onto the app. It serializes the whole bootstrap
// block and looks for the value rather than reading a named field, so it holds
// regardless of what the change calls the field that carries the base-backup
// id. The id used in these tests is a distinctive timestamp-shaped token that
// does not collide with the other bootstrap values (server names, recovery
// instants).
func bootstrapHasValue(t *testing.T, b postgresapp.Bootstrap, value string) bool {
	t.Helper()
	raw, err := json.Marshal(b)
	if err != nil {
		t.Fatalf("marshal bootstrap: %v", err)
	}
	return strings.Contains(string(raw), value)
}

// documentedTimeLayouts are the two ways the restore option and the chart
// document a recovery instant: RFC3339, and PostgreSQL's own timestamp text with
// an hour or hour-and-minute offset.
var documentedTimeLayouts = []string{
	time.RFC3339Nano,
	"2006-01-02 15:04:05.999999999-07",
	"2006-01-02 15:04:05.999999999-07:00",
}

func parseDocumentedTime(s string) (time.Time, bool) {
	for _, layout := range documentedTimeLayouts {
		if ts, err := time.Parse(layout, s); err == nil {
			return ts, true
		}
	}
	return time.Time{}, false
}

// bootstrapCarriesTime reports whether the requested recovery instant reaches
// the recovery settings: as the text the RestoreJob gave, or, for a time in one
// of the documented forms, as any value in the settings that names the same
// instant (a restore may write it back in another documented spelling).
func bootstrapCarriesTime(t *testing.T, b postgresapp.Bootstrap, recoveryTime string) bool {
	t.Helper()
	if bootstrapHasValue(t, b, recoveryTime) {
		return true
	}
	want, ok := parseDocumentedTime(recoveryTime)
	if !ok {
		return false
	}
	raw, err := json.Marshal(b)
	if err != nil {
		t.Fatalf("marshal bootstrap: %v", err)
	}
	var fields map[string]any
	if err := json.Unmarshal(raw, &fields); err != nil {
		t.Fatalf("decode bootstrap: %v", err)
	}
	var found bool
	var walk func(v any)
	walk = func(v any) {
		switch x := v.(type) {
		case string:
			if got, ok := parseDocumentedTime(x); ok && got.Equal(want) {
				found = true
			}
		case map[string]any:
			for _, e := range x {
				walk(e)
			}
		case []any:
			for _, e := range x {
				walk(e)
			}
		}
	}
	walk(fields)
	return found
}

// restoreWorld seeds a tenant with one Postgres app, the backup artifact that
// names a source cnpg.io/Backup, a CNPG strategy, and (optionally) that
// cnpg.io/Backup. It drives a restore and returns the bootstrap the app ends up
// patched with, plus the recorder so the caller can inspect emitted events.
type restoreWorld struct {
	ns, appName, cnpgBkName string
	// bkName is the Backup artifact the RestoreJob names; empty means "bk".
	bkName string
}

func (w restoreWorld) backupName() string {
	if w.bkName == "" {
		return "bk"
	}
	return w.bkName
}

func newRestoreWorld() restoreWorld {
	return restoreWorld{ns: "tenant", appName: "app", cnpgBkName: "cnpgbk"}
}

func (w restoreWorld) backupArtifact(t *testing.T) *backupsv1alpha1.Backup {
	t.Helper()
	snap, err := marshalCNPGBackupSnapshot(mkPostgresApp(w.appName, w.ns), nil)
	if err != nil {
		t.Fatalf("marshal snapshot: %v", err)
	}
	apiGroup := backupsv1alpha1.DefaultApplicationAPIGroup
	strategyGroup := strategyv1alpha1.GroupVersion.Group
	return &backupsv1alpha1.Backup{
		ObjectMeta: metav1.ObjectMeta{Namespace: w.ns, Name: w.backupName()},
		Spec: backupsv1alpha1.BackupSpec{
			ApplicationRef: corev1.TypedLocalObjectReference{APIGroup: &apiGroup, Kind: postgresAppKind, Name: w.appName},
			StrategyRef:    corev1.TypedLocalObjectReference{APIGroup: &strategyGroup, Kind: strategyv1alpha1.CNPGStrategyKind, Name: "cnpg-strategy"},
			DriverMetadata: map[string]string{
				cnpgServerNameKey:      w.appName,
				cnpgDestinationPathKey: "s3://bucket/" + w.appName + "/",
				cnpgBackupNameKey:      w.cnpgBkName,
			},
		},
		Status: backupsv1alpha1.BackupStatus{UnderlyingResources: snap},
	}
}

func (w restoreWorld) strategy() *strategyv1alpha1.CNPG {
	return &strategyv1alpha1.CNPG{
		ObjectMeta: metav1.ObjectMeta{Name: "cnpg-strategy"},
		Spec: strategyv1alpha1.CNPGSpec{
			Template: strategyv1alpha1.CNPGTemplate{
				BarmanObjectStore: strategyv1alpha1.BarmanObjectStoreTemplate{DestinationPath: "s3://bucket/"},
			},
		},
	}
}

// sourceBackup is the completed cnpg.io/Backup the restore names. The backup id
// is barman's identifier for its base backup; stoppedAt (RFC3339) is when that
// base backup ended. A restore reads both from the live cnpg.io/Backup to
// decide whether it can start from this backup.
func (w restoreWorld) sourceBackup(t *testing.T, backupID, stoppedAt string) *cnpgtypes.Backup {
	t.Helper()
	return w.cnpgBackup(t, w.cnpgBkName, backupID, stoppedAt)
}

// cnpgBackup builds a completed cnpg.io/Backup of the app's cluster under the
// given name. An empty stoppedAt leaves the end time unrecorded. It carries the
// cnpg.io/cluster label the backup driver puts on every backup it creates, so a
// lookup of the cluster's backups by label finds it as it would on a cluster.
//
// The status is seeded by unmarshalling the status field names the CNPG Backup
// CRD defines (phase, endWal, backupId, stoppedAt) rather than by naming Go
// struct fields. A restore reads these off a live object via the API server, so
// the field that carries the id must be tagged with the CRD's wire name to be
// populated at all - seeding through that same wire name exercises the real read
// path without assuming what the Go field is called.
func (w restoreWorld) cnpgBackup(t *testing.T, name, backupID, stoppedAt string) *cnpgtypes.Backup {
	t.Helper()
	bk := &cnpgtypes.Backup{
		ObjectMeta: metav1.ObjectMeta{
			Namespace: w.ns, Name: name,
			Labels: map[string]string{cnpgClusterLabel: cnpgClusterNameForApp(w.appName)},
		},
		Spec: cnpgtypes.BackupSpec{Cluster: cnpgtypes.ClusterReference{Name: cnpgClusterNameForApp(w.appName)}},
	}
	status := map[string]string{
		"phase":    cnpgBackupPhaseComplete,
		"endWal":   "000000010000000000000003",
		"backupId": backupID,
	}
	if stoppedAt != "" {
		status["stoppedAt"] = stoppedAt
	}
	statusJSON, err := json.Marshal(status)
	if err != nil {
		t.Fatalf("encode backup status: %v", err)
	}
	if err := json.Unmarshal(statusJSON, &bk.Status); err != nil {
		t.Fatalf("seed backup status %s: %v", name, err)
	}
	return bk
}

func (w restoreWorld) restoreJob(name, recoveryTime string, uid types.UID) *backupsv1alpha1.RestoreJob {
	started := metav1.NewTime(time.Date(2026, 9, 25, 0, 0, 0, 0, time.UTC))
	rj := &backupsv1alpha1.RestoreJob{
		ObjectMeta: metav1.ObjectMeta{Namespace: w.ns, Name: name, UID: uid},
		Spec:       backupsv1alpha1.RestoreJobSpec{BackupRef: corev1.LocalObjectReference{Name: w.backupName()}},
		Status:     backupsv1alpha1.RestoreJobStatus{StartedAt: &started, Phase: backupsv1alpha1.RestoreJobPhaseRunning},
	}
	if recoveryTime != "" {
		rj.Spec.Options = &runtime.RawExtension{Raw: []byte(`{"recoveryTime":"` + recoveryTime + `"}`)}
	}
	return rj
}

// run drives a single restore against a fresh world. sourceBackup, if nil, is
// NOT seeded - the catalog no longer holds it. extra objects (other backups of
// the same cluster) are seeded next to it. Returns the bootstrap the app is
// patched with plus the recorder.
func (w restoreWorld) run(t *testing.T, sourceBackup *cnpgtypes.Backup, recoveryTime string, extra ...client.Object) (postgresapp.Bootstrap, *record.FakeRecorder) {
	t.Helper()
	ctx := context.Background()
	app := mkPostgresApp(w.appName, w.ns)
	backup := w.backupArtifact(t)
	objs := []client.Object{backup, w.restoreJob("rj", recoveryTime, "uid-rj"), w.strategy(), app}
	if sourceBackup != nil {
		objs = append(objs, sourceBackup)
	}
	objs = append(objs, extra...)
	c := mkFakeClient(t, objs...)
	recorder := record.NewFakeRecorder(10)
	r := &RestoreJobReconciler{Client: c, Interface: dynamicfake.NewSimpleDynamicClient(mkDynamicScheme(t)), Recorder: recorder}
	bootstrap := w.reconcileOnce(t, ctx, c, r, "rj")
	return bootstrap, recorder
}

// reconcileOnce reconciles the named RestoreJob through reconcileCNPGRestore and
// returns the recovery bootstrap the target app carries afterwards.
func (w restoreWorld) reconcileOnce(t *testing.T, ctx context.Context, c client.Client, r *RestoreJobReconciler, rjName string) postgresapp.Bootstrap {
	t.Helper()
	rj := &backupsv1alpha1.RestoreJob{}
	if err := c.Get(ctx, client.ObjectKey{Namespace: w.ns, Name: rjName}, rj); err != nil {
		t.Fatalf("get seeded RestoreJob %q: %v", rjName, err)
	}
	backup := &backupsv1alpha1.Backup{}
	if err := c.Get(ctx, client.ObjectKey{Namespace: w.ns, Name: w.backupName()}, backup); err != nil {
		t.Fatalf("get seeded Backup: %v", err)
	}
	if _, err := r.reconcileCNPGRestore(ctx, rj, backup); err != nil {
		t.Fatalf("reconcileCNPGRestore(%s): %v", rjName, err)
	}
	patched := &postgresapp.Postgres{}
	if err := c.Get(ctx, client.ObjectKey{Namespace: w.ns, Name: w.appName}, patched); err != nil {
		t.Fatalf("get patched Postgres app: %v", err)
	}
	if !patched.Spec.Bootstrap.Enabled {
		t.Fatalf("the restore did not reach the bootstrap patch")
	}
	return patched.Spec.Bootstrap
}

// A completed backup used across the guard cases: it ends at 06:27:23 UTC.
var (
	fixtureBackupID = "20260921T062713"
	fixtureStopped  = "2026-09-21T06:27:23Z"
)

// neighbours are an older and a newer completed backup of the same cluster,
// seeded next to the named one. The newer one ends after the fixture backup
// and before the later recovery times the cases use, so a restore that picks
// some other backup by time, rather than the one it names, puts one of these
// ids in the recovery settings.
func (w restoreWorld) neighbours(t *testing.T) []client.Object {
	t.Helper()
	return []client.Object{
		w.cnpgBackup(t, w.appName+"-0-older", neighbourIDs[0], "2026-09-11T19:44:58Z"),
		w.cnpgBackup(t, w.appName+"-z-newer", neighbourIDs[1], "2026-09-21T20:05:49Z"),
	}
}

var neighbourIDs = []string{"20260911T194402", "20260921T200511"}

// noNeighbourPinned fails the test if the recovery settings carry the id of a
// backup the restore does not name.
func noNeighbourPinned(t *testing.T, b postgresapp.Bootstrap) {
	t.Helper()
	for _, id := range neighbourIDs {
		if bootstrapHasValue(t, b, id) {
			t.Errorf("the recovery settings carry %s, a backup the restore does not name", id)
		}
	}
}

// warnings drains the recorder and returns every Warning event it buffered.
// Every event is read rather than only the first, so an incidental
// informational event does not mask the one that matters.
func warnings(recorder *record.FakeRecorder) []string {
	var out []string
	for {
		select {
		case ev := <-recorder.Events:
			if strings.HasPrefix(ev, corev1.EventTypeWarning) {
				out = append(out, ev)
			}
		default:
			return out
		}
	}
}

// --- behavioral checks ------------------------------------------------------

// A restore that names a backup and asks for no point in time starts from
// exactly that backup, so the recovery settings carry its id and no other
// backup's. Each case seeds other completed backups of the same cluster next to
// the named one: newer ones, older ones, or one of each, under names that sort
// before and after it, so neither the newest, the oldest, the first nor the last
// backup of the cluster stands in for the one the restore names. The named
// backup is present, so the restore raises no warning.
func TestRestorePinsNamedBackup(t *testing.T) {
	type otherBackup struct{ name, id, stopped string }
	cases := []struct {
		name                string
		world               restoreWorld
		backupID, stoppedAt string
		others              []otherBackup
	}{
		{
			name:      "a newer backup sorts before the named one",
			world:     restoreWorld{ns: "tenant", appName: "app", cnpgBkName: "cnpgbk"},
			backupID:  fixtureBackupID,
			stoppedAt: fixtureStopped,
			others:    []otherBackup{{"app-0-later", "20260924T081502", "2026-09-24T08:15:40Z"}},
		},
		{
			name:      "a newer backup sorts after the named one",
			world:     restoreWorld{ns: "tenant", appName: "orders", cnpgBkName: "orders-a-weekly"},
			backupID:  "20260918T221005",
			stoppedAt: "2026-09-18T22:10:59Z",
			others:    []otherBackup{{"orders-z-later", "20260923T030411", "2026-09-23T03:04:52Z"}},
		},
		{
			name:      "an older backup sorts after the named one",
			world:     restoreWorld{ns: "tenant", appName: "ledger", cnpgBkName: "ledger-a-daily"},
			backupID:  "20260920T051530",
			stoppedAt: "2026-09-20T05:16:12Z",
			others:    []otherBackup{{"ledger-z-earlier", "20260911T194402", "2026-09-11T19:44:58Z"}},
		},
		{
			name:      "the named backup sits between an older and a newer one",
			world:     restoreWorld{ns: "tenant", appName: "billing", cnpgBkName: "billing-m-weekly"},
			backupID:  "20260916T032011",
			stoppedAt: "2026-09-16T03:21:05Z",
			others: []otherBackup{
				{"billing-a-earlier", "20260909T032007", "2026-09-09T03:20:49Z"},
				{"billing-z-later", "20260923T032014", "2026-09-23T03:21:01Z"},
			},
		},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			w := tc.world
			var extra []client.Object
			for _, o := range tc.others {
				extra = append(extra, w.cnpgBackup(t, o.name, o.id, o.stopped))
			}
			b, recorder := w.run(t, w.sourceBackup(t, tc.backupID, tc.stoppedAt), "", extra...)
			if !bootstrapHasValue(t, b, tc.backupID) {
				t.Errorf("the restore did not pin the backup it names: %s not found in the recovery settings", tc.backupID)
			}
			for _, o := range tc.others {
				if bootstrapHasValue(t, b, o.id) {
					t.Errorf("the recovery settings carry %s, a backup the restore does not name", o.id)
				}
			}
			if ws := warnings(recorder); len(ws) > 0 {
				t.Errorf("a restore whose named backup is present raised a warning: %v", ws)
			}
		})
	}
}

// A point in time only selects a backup once the backup has finished. The end
// time is recorded to the second while the catalog compares to the microsecond,
// so a backup is pinned only once the requested instant is a full second past
// its end; an instant before that leaves the choice to the plugin, which can
// land on an older backup. The instant is read in RFC3339 and in the
// PostgreSQL form the chart's own example uses (date, space, time, optional
// fraction, an offset of +HH or +HH:MM). Three offset cases put the local
// clock on the other side of the end from the UTC instant, so only a read that
// applies the offset, with its sign, decides them right. An instant with no
// offset does not pin. An older and a newer backup of the same cluster sit next
// to the named one, and neither may be pinned in its place.
func TestRestoreHonorsRecoveryTimePrecision(t *testing.T) {
	cases := []struct {
		name         string
		recoveryTime string
		wantPinned   bool
	}{
		{"a full second after the end pins it", "2026-09-21T06:27:24Z", true},
		{"well after the end pins it", "2026-09-22T10:00:00Z", true},
		{"a timezone offset still resolves after the end", "2026-09-22T10:00:00+02:00", true},
		{"exactly the recorded end does not pin", "2026-09-21T06:27:23Z", false},
		{"less than a second after the end does not pin", "2026-09-21T06:27:23.5Z", false},
		{"just under a second after the end does not pin", "2026-09-21T06:27:23.999Z", false},
		{"before the end does not pin", "2026-09-21T05:00:00Z", false},
		{"postgres form a full second after the end pins it", "2026-09-21 06:27:24.00000+00", true},
		{"postgres form with no fraction pins it", "2026-09-22 10:00:00+00", true},
		{"postgres form less than a second after the end does not pin", "2026-09-21 06:27:23.5+00", false},
		{"postgres form at the end in a negative hour offset does not pin", "2026-09-21 01:27:23-05", false},
		{"postgres form a second past the end in a positive hour offset pins it", "2026-09-21 08:27:24+02", true},
		{"postgres form inside the last second in a positive hour offset does not pin", "2026-09-21 08:27:23.999+02", false},
		{"postgres form a second past the end in a negative offset with minutes pins it", "2026-09-21 01:57:24-04:30", true},
		{"postgres form inside the last second in a positive offset with minutes does not pin", "2026-09-21 11:57:23.25+05:30", false},
		{"postgres form with no offset does not pin", "2026-09-22 10:00:00", false},
		{"RFC3339 layout with no offset does not pin", "2026-09-22T10:00:00", false},
		{"free text does not pin", "tomorrow at noon", false},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			w := newRestoreWorld()
			b, _ := w.run(t, w.sourceBackup(t, fixtureBackupID, fixtureStopped), tc.recoveryTime, w.neighbours(t)...)
			noNeighbourPinned(t, b)
			got := bootstrapHasValue(t, b, fixtureBackupID)
			if tc.wantPinned && !got {
				t.Errorf("recovery to %q should pin the backup, but %s is not in the recovery settings", tc.recoveryTime, fixtureBackupID)
			}
			if !tc.wantPinned && got {
				t.Errorf("recovery to %q should not pin the backup, but %s is in the recovery settings", tc.recoveryTime, fixtureBackupID)
			}
			// Whether or not the backup is pinned, the requested point in time
			// still reaches the recovery settings.
			if !bootstrapCarriesTime(t, b, tc.recoveryTime) {
				t.Errorf("the requested recovery time %q is missing from the recovery settings", tc.recoveryTime)
			}
		})
	}
}

// A backup whose end time was never recorded cannot be shown to have finished
// by a requested point in time, so such a request does not start from it. A
// restore that asks for no point in time still starts from it.
func TestRestoreWithoutRecordedEnd(t *testing.T) {
	const backupID = "20260920T140233"
	cases := []struct {
		name         string
		recoveryTime string
		wantPinned   bool
	}{
		{"no point in time pins it", "", true},
		{"a point in time does not pin it", "2026-09-22T10:00:00Z", false},
		{"a point in time in the postgres form does not pin it", "2026-09-22 10:00:00+00", false},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			w := newRestoreWorld()
			b, _ := w.run(t, w.sourceBackup(t, backupID, ""), tc.recoveryTime, w.neighbours(t)...)
			noNeighbourPinned(t, b)
			got := bootstrapHasValue(t, b, backupID)
			if tc.wantPinned && !got {
				t.Errorf("recovery to %q should pin the backup, but %s is not in the recovery settings", tc.recoveryTime, backupID)
			}
			if !tc.wantPinned && got {
				t.Errorf("recovery to %q should not pin a backup with no recorded end, but %s is in the recovery settings", tc.recoveryTime, backupID)
			}
		})
	}
}

// When retention has removed the source cnpg.io/Backup, its base backup is gone
// from the catalog; pinning an id the catalog has lost would fail the recovery
// after the target is purged. So the restore leaves the choice to the plugin
// and raises a Warning event that names the backup it could not use. The two
// cases use different backup names, so only a message built from the backup
// at hand names it. Other backups of the cluster are still present, and none
// of them may be pinned in its place.
func TestRestoreWithGoneSourceDoesNotPinAndSurfaces(t *testing.T) {
	cases := []struct {
		name         string
		world        restoreWorld
		recoveryTime string
	}{
		{"no recoveryTime", restoreWorld{ns: "tenant", appName: "orders", cnpgBkName: "orders-nightly-x7k2p", bkName: "orders-nightly"}, ""},
		{"with recoveryTime", restoreWorld{ns: "tenant", appName: "billing", cnpgBkName: "billing-weekly-4qzt9", bkName: "billing-weekly"}, "2026-09-22T10:00:00Z"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			w := tc.world
			b, recorder := w.run(t, nil, tc.recoveryTime, w.neighbours(t)...)
			noNeighbourPinned(t, b)
			if bootstrapHasValue(t, b, fixtureBackupID) {
				t.Errorf("a gone source must not pin: %s should not be in the recovery settings (the catalog no longer holds that base backup)", fixtureBackupID)
			}
			ws := warnings(recorder)
			if len(ws) == 0 {
				t.Fatalf("no warning event: a restore that cannot use the backup it names must tell the operator")
			}
			named := false
			for _, ev := range ws {
				if strings.Contains(ev, w.backupName()) {
					named = true
				}
			}
			if !named {
				t.Errorf("no warning names the backup %q the restore could not use: %v", w.backupName(), ws)
			}
		})
	}
}

// A choice left over in the recovery settings from an earlier restore must not
// leak into a later one. A first restore pins the backup; a second restore on
// the same app whose own computation yields no pin must clear the pinned value
// rather than keep it. The second restore gets there two ways: it asks for a
// point in time before the backup ended, or the named backup's cnpg.io/Backup
// has been removed in between.
func TestRestoreClearsStaleBackupID(t *testing.T) {
	cases := []struct {
		name        string
		secondTime  string
		removeFirst bool
	}{
		{"the later restore asks for a time before the backup ended", "2026-09-21T05:00:00Z", false},
		{"the named backup's record is gone by the later restore", "", true},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			w := newRestoreWorld()
			ctx := context.Background()
			app := mkPostgresApp(w.appName, w.ns)
			source := w.sourceBackup(t, fixtureBackupID, fixtureStopped)
			objs := []client.Object{
				w.backupArtifact(t),
				w.restoreJob("rj-1", "", "uid-rj-1"),
				w.restoreJob("rj-2", tc.secondTime, "uid-rj-2"),
				w.strategy(), app, source,
			}
			c := mkFakeClient(t, objs...)
			r := &RestoreJobReconciler{Client: c, Interface: dynamicfake.NewSimpleDynamicClient(mkDynamicScheme(t)), Recorder: record.NewFakeRecorder(10)}

			// First restore pins the backup (no recoveryTime).
			first := w.reconcileOnce(t, ctx, c, r, "rj-1")
			if !bootstrapHasValue(t, first, fixtureBackupID) {
				t.Fatalf("setup: the first restore did not pin %s, so there is nothing stale to clear", fixtureBackupID)
			}

			if tc.removeFirst {
				if err := c.Delete(ctx, source); err != nil {
					t.Fatalf("remove the source cnpg.io/Backup: %v", err)
				}
			}

			// Second restore on the same app computes no pin and must clear
			// the stale value.
			second := w.reconcileOnce(t, ctx, c, r, "rj-2")
			if bootstrapHasValue(t, second, fixtureBackupID) {
				t.Errorf("a pin from an earlier restore leaked into a later one that should not pin: %s is still in the recovery settings", fixtureBackupID)
			}
		})
	}
}

// takeBackup runs a BackupJob through the CNPG backup driver (reconcileCNPG)
// the way a backup taken today runs: the cnpg.io/Backup the job waits on has
// completed, and the driver records the Backup artifact a restore later names.
// Whatever the driver writes onto that artifact is what the restore reads back,
// so these cases see anything the backup driver records.
func (w restoreWorld) takeBackup(t *testing.T, ctx context.Context, c client.Client, strategyName string) {
	t.Helper()
	strategyGroup := strategyv1alpha1.GroupVersion.Group
	j := &backupsv1alpha1.BackupJob{}
	if err := c.Get(ctx, client.ObjectKey{Namespace: w.ns, Name: w.backupName()}, j); err != nil {
		t.Fatalf("get seeded BackupJob: %v", err)
	}
	resolved := &ResolvedBackupConfig{
		StrategyRef: corev1.TypedLocalObjectReference{APIGroup: &strategyGroup, Kind: strategyv1alpha1.CNPGStrategyKind, Name: strategyName},
	}
	r := &BackupJobReconciler{Client: c, Recorder: record.NewFakeRecorder(10)}
	if _, err := r.reconcileCNPG(ctx, j, resolved); err != nil {
		t.Fatalf("reconcileCNPG: %v", err)
	}
	artifact := &backupsv1alpha1.Backup{}
	if err := c.Get(ctx, client.ObjectKey{Namespace: w.ns, Name: w.backupName()}, artifact); err != nil {
		t.Fatalf("the backup driver did not record a Backup artifact for a completed cnpg.io/Backup: %v", err)
	}
}

// backupWorldObjects seeds what a backup and a later restore of the app need:
// the app, the strategy, the app's live cnpg.io Cluster, a started BackupJob,
// the completed cnpg.io/Backup that job owns, and the RestoreJob.
func (w restoreWorld) backupWorldObjects(t *testing.T, backupID, stoppedAt, recoveryTime string) ([]client.Object, *cnpgtypes.Backup) {
	t.Helper()
	apiGroup := backupsv1alpha1.DefaultApplicationAPIGroup
	started := metav1.NewTime(time.Date(2026, 9, 19, 11, 0, 0, 0, time.UTC))
	job := &backupsv1alpha1.BackupJob{
		ObjectMeta: metav1.ObjectMeta{Namespace: w.ns, Name: w.backupName()},
		Spec: backupsv1alpha1.BackupJobSpec{
			ApplicationRef: corev1.TypedLocalObjectReference{APIGroup: &apiGroup, Kind: postgresAppKind, Name: w.appName},
		},
		Status: backupsv1alpha1.BackupJobStatus{StartedAt: &started, Phase: backupsv1alpha1.BackupJobPhaseRunning},
	}
	cluster := &cnpgtypes.Cluster{
		ObjectMeta: metav1.ObjectMeta{Namespace: w.ns, Name: cnpgClusterNameForApp(w.appName), UID: "uid-cluster"},
	}
	cnpgBk := w.cnpgBackup(t, w.cnpgBkName, backupID, stoppedAt)
	cnpgBk.Labels = map[string]string{
		backupsv1alpha1.OwningJobNameLabel:      job.Name,
		backupsv1alpha1.OwningJobNamespaceLabel: job.Namespace,
		cnpgClusterLabel:                        cluster.Name,
	}
	objs := []client.Object{
		mkPostgresApp(w.appName, w.ns), w.strategy(), job, cluster, cnpgBk,
		w.restoreJob("rj", recoveryTime, "uid-rj"),
	}
	objs = append(objs, w.neighbours(t)...)
	return objs, cnpgBk
}

// A backup the backup driver takes follows the same rules as an artifact that
// carries only the long-standing metadata keys: with no point in time the restore starts
// from it, a point in time uses it only once that time is a full second past
// its recorded end, and once retention has removed its cnpg.io/Backup the
// restore goes ahead without it and a Warning event names it.
func TestRestoreOfBackupTakenThroughTheBackupDriver(t *testing.T) {
	const backupID, stoppedAt = "20260919T113005", "2026-09-19T11:31:47Z"
	cases := []struct {
		name         string
		recoveryTime string
		removeRecord bool
		wantPinned   bool
	}{
		{"no point in time pins it", "", false, true},
		{"a full second past the end pins it", "2026-09-19 11:31:48+00", false, true},
		{"inside the last second does not pin", "2026-09-19T11:31:47.6Z", false, false},
		{"before the end does not pin", "2026-09-19T09:00:00Z", false, false},
		{"a record removed by retention does not pin", "", true, false},
		{"a record removed by retention does not pin a point in time", "2026-09-20T00:00:00Z", true, false},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			w := restoreWorld{ns: "tenant", appName: "inventory", cnpgBkName: "inventory-0919-r8d2m", bkName: "inventory-0919"}
			ctx := context.Background()
			objs, cnpgBk := w.backupWorldObjects(t, backupID, stoppedAt, tc.recoveryTime)
			c := mkFakeClient(t, objs...)
			w.takeBackup(t, ctx, c, w.strategy().Name)
			if tc.removeRecord {
				if err := c.Delete(ctx, cnpgBk); err != nil {
					t.Fatalf("remove the cnpg.io/Backup: %v", err)
				}
			}
			recorder := record.NewFakeRecorder(10)
			r := &RestoreJobReconciler{Client: c, Interface: dynamicfake.NewSimpleDynamicClient(mkDynamicScheme(t)), Recorder: recorder}
			b := w.reconcileOnce(t, ctx, c, r, "rj")
			noNeighbourPinned(t, b)
			got := bootstrapHasValue(t, b, backupID)
			if tc.wantPinned && !got {
				t.Errorf("recovery to %q should start from the backup it names, but %s is not in the recovery settings", tc.recoveryTime, backupID)
			}
			if !tc.wantPinned && got {
				t.Errorf("recovery to %q should not start from the backup it names, but %s is in the recovery settings", tc.recoveryTime, backupID)
			}
			ws := warnings(recorder)
			if !tc.removeRecord && len(ws) > 0 {
				t.Errorf("a restore whose named backup is present raised a warning: %v", ws)
			}
			if tc.removeRecord {
				named := false
				for _, ev := range ws {
					if strings.Contains(ev, w.backupName()) {
						named = true
					}
				}
				if !named {
					t.Errorf("no warning names the backup %q the restore could not use: %v", w.backupName(), ws)
				}
			}
		})
	}
}
