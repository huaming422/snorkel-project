#!/usr/bin/env bash
#
# Renders the postgres chart and checks that the recovery coordinates next to the
# base-backup selector keep rendering: the restored cluster's fresh archive
# prefix, the recovery source prefix, the requested recovery point, and the
# recovery ObjectStore's source path. It also checks that a restore with neither
# a selector nor a recovery point renders no recovery target. These hold on the
# tree before and after the selector is added, so they guard the surrounding
# recovery render against a regression.
#
# helm-unittest's -f globs are relative to the chart directory, so this verifier
# writes the suite it carries into a scratch dir inside the chart, runs the
# render there, then removes it - leaving the chart's own tests untouched. The
# suite is written inline (below) so the verifier is self-contained and needs no
# sibling data file at grade time.
#
# The suite asserts only names the chart already owns before this change (the
# plugin/external-cluster serverName the restore render already shapes, the
# recovery ObjectStore's source path) and the cnpg.io Cluster's own field names -
# never a base-backup selector key the change gets to choose. The recovery point
# is read from the plain `helm template` output instead, so it matches whether
# the chart writes the instant quoted or bare: helm-unittest reads a bare
# instant as a timestamp and a quoted one as a string, while the API server
# receives the same text either way.
#
# Exit codes:
#   0        - every check passes
#   non-zero - a helm-unittest failure, or a recovery target that does not match

set -euo pipefail

REPO="/repo/${REPO_NAME:-cozystack}"
CHART="${REPO}/packages/apps/postgres"
RECOVERY_TIME="2026-09-22T10:00:00Z"

SCRATCH="${CHART}/.sb-verify-adjacent"
cleanup() { rm -rf "${SCRATCH}"; }
trap cleanup EXIT

mkdir -p "${SCRATCH}"
cat > "${SCRATCH}/restore_adjacent_render_test.yaml" <<'EOF'
suite: restore keeps rendering the adjacent recovery coordinates

# The base-backup selector is added alongside the recovery coordinates the chart
# already renders on restore. Those neighbours must keep rendering unchanged: the
# WAL-archive serverName on the restored cluster's plugin (a fresh prefix, so the
# restored cluster does not archive onto its recovery source), the recovery
# source serverName on the external cluster, and the recovery ObjectStore's
# destinationPath. This is a render contract that holds before and after the
# change, so it guards against a regression in the surrounding recovery render.

templates:
  - templates/db.yaml

release:
  name: pg-test
  namespace: tenant-test

set:
  _cluster:
    scheduling: {}
  backup:
    enabled: true
    useSystemBucket: false
    s3AccessKey: AKIAEXAMPLE
    s3SecretKey: s3cr3t
    destinationPath: s3://bucket/pg-test/
    endpointURL: https://s3.example:9000
  bootstrap:
    enabled: true
    oldName: pg-test
    serverName: pg-test
    newServerName: pg-test-restore-deadbeef
    recoveryTime: "2026-09-22T10:00:00Z"

tests:
  - it: "the restored cluster archives under its fresh prefix, recovers from the source prefix, with the source path intact"
    asserts:
      # WAL archiver writes to the fresh restore prefix, never the source's.
      - equal:
          path: spec.plugins[0].parameters.serverName
          value: pg-test-restore-deadbeef
        documentSelector:
          path: kind
          value: Cluster
      # Recovery still reads the source prefix.
      - equal:
          path: spec.externalClusters[0].plugin.parameters.serverName
          value: pg-test
        documentSelector:
          path: kind
          value: Cluster
      # The recovery ObjectStore still carries the source S3 coordinates.
      - equal:
          path: spec.configuration.destinationPath
          value: s3://bucket/pg-test/
        documentSelector:
          path: metadata.name
          value: pg-test-recovery
EOF

cd "${CHART}"
helm unittest -f ".sb-verify-adjacent/*_test.yaml" .

BASE_ARGS=(
  --set-json '_cluster.scheduling={}'
  --set backup.enabled=true
  --set backup.useSystemBucket=false
  --set backup.s3AccessKey=AKIAEXAMPLE
  --set backup.s3SecretKey=s3cr3t
  --set backup.destinationPath=s3://bucket/pg-test/
  --set bootstrap.enabled=true
  --set bootstrap.oldName=pg-test
  --set bootstrap.serverName=pg-test
  --set bootstrap.newServerName=pg-test-restore-deadbeef
)

render() {
  helm template pg-test . --namespace tenant-test "${BASE_ARGS[@]}" "$@"
}

# Prints the lines nested under the rendered recoveryTarget key.
recovery_target() {
  awk '
    rt {
      match($0, /^[ \t]*/)
      if ($0 !~ /^[ \t]*$/ && RLENGTH <= ind) { rt = 0 } else { print; next }
    }
    /^[ \t]*recoveryTarget:[ \t]*$/ { rt = 1; match($0, /^[ \t]*/); ind = RLENGTH }
  '
}

# The requested recovery point still reaches the recovery target.
WITH_TIME="$(render --set "bootstrap.recoveryTime=${RECOVERY_TIME}")"
if ! printf '%s\n' "${WITH_TIME}" | recovery_target \
    | grep -E "^[[:space:]]*targetTime:[[:space:]]*[\"']?${RECOVERY_TIME}[\"']?[[:space:]]*$" >/dev/null; then
  echo "fail: recoveryTarget.targetTime does not carry the requested recovery point ${RECOVERY_TIME}" >&2
  exit 1
fi
echo "ok: the recovery point renders at recoveryTarget.targetTime"

# With neither a selector nor a recovery point, the recovery target names no
# backup and no stop point, as before.
PLAIN="$(render)"
if printf '%s\n' "${PLAIN}" | recovery_target \
    | grep -E "^[[:space:]]*backupID:[[:space:]]*[\"']?[^\"'[:space:]]|^[[:space:]]*(targetTime|targetLSN|targetXID|targetName):|^[[:space:]]*targetImmediate:[[:space:]]*true" >/dev/null; then
  echo "fail: a restore with no selector and no recovery point renders a recovery target:" >&2
  printf '%s\n' "${PLAIN}" | recovery_target >&2
  exit 1
fi
echo "ok: no recovery target is rendered when neither a selector nor a recovery point is set"
