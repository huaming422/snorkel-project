
## Task

We keep hearing about Postgres restores that come back with the wrong data.
Someone restores a cluster from a specific backup and ends up with a state that backup never captured.
Clusters that were already restored once before see it the most, and point-in-time restores get hit hardest.
Still, a plain restore from a named backup has landed on the wrong one too.

When a RestoreJob names a backup, recovery has to start from that backup, even if newer backups or other branches of history sit in the same archive.
This also has to work for backups people took before your change, not only for new ones.
With no `recoveryTime`, the restore should still replay everything archived after that backup, the way it does now.

A `recoveryTime` (an RFC3339 timestamp) can only start from the named backup if that backup had finished by then.
The end time on the cnpg.io Backup (`status.stoppedAt`) only keeps whole seconds, so a time less than a full second after it counts as too early.
If the time is too early, isn't valid RFC3339, or the backup has no recorded end time, leave the choice of starting backup to work the way it does today.

Sometimes retention has already deleted the cnpg.io Backup behind the named backup.
The restore should still go ahead then, the way it does today, and raise a Kubernetes Warning event about it so the operator can see it.

Each restore makes its own choice of starting backup.
Nothing picked for an earlier restore of the same app should carry over into a later one.

Can you track down what's going on and fix it?
