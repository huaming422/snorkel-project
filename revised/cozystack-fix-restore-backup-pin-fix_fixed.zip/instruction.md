
## Task

We keep hearing about Postgres restores that come back with the wrong data.
Someone restores a cluster from a specific backup and ends up with a state that backup never captured.
Clusters that were already restored once before see it the most, and point-in-time restores get hit hardest.
Still, a plain restore from a named backup has landed on the wrong one too.

A RestoreJob that names a backup has to recover from that backup, even when the cluster has newer ones.
Backups that exist today must restore correctly as well, not only ones taken after the fix.
With no `recoveryTime`, the restore should still replay everything archived after that backup, as it does now.

A `recoveryTime` can only be served from the named backup if that backup had finished by then.
Go by the end time CNPG records on the cnpg.io Backup, and treat anything less than one full second past it as too early.
People write `recoveryTime` in two forms, and both must be read correctly, offset included.
One is RFC3339, like `2026-09-22T10:00:00Z` or `2026-09-22T12:00:00+02:00`.
The other is the form in the postgres chart's own example, `2020-11-26 15:22:00.00000+00`: a space before the time, optional fractional seconds, and an offset written as `+HH`, `-HH`, `+HH:MM` or `-HH:MM`.
A time that is too early, has no offset, or is in neither form keeps today's behavior, and so does a backup with no recorded end time.

Retention sometimes deletes the cnpg.io Backup behind a named backup.
The restore should still go ahead then and raise a Kubernetes Warning event so the operator can see it.
A restore whose cnpg.io Backup is still there raises no such warning.

Nothing an earlier restore of the same app picked should carry over into a later one.

Can you track down what's going on and fix it?
