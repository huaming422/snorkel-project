## Task

We keep getting reports of Postgres restores that come back with the wrong data.
Someone restores a cluster from a specific backup, and what comes back was rebuilt from a different backup.
Clusters that were restored before show it the most, and point-in-time restores are hit the worst, but a plain restore from a named backup has landed on the wrong one too.
A restore that names a backup has to recover from that backup, whatever other backups the cluster has, older or newer.
The people reporting this are restoring backups they already have, so a fix that only helps backups taken from now on does not help them.

A point-in-time restore can only use the named backup if that backup had certainly finished by the requested time.
Judge that by the end time CNPG records on the cnpg.io Backup, and keep in mind that CNPG drops the fraction of a second from it.
Whenever the restore can't be sure, it should behave the way it does today.

People write `recoveryTime` in RFC3339, as the RestoreJob option documents, and also the way the postgres chart's own example does, which is PostgreSQL's own timestamp text.
Both have to work, offset included.
A time with no offset is read in the database server's zone, which the restore has no way to know, so it counts as one the restore can't be sure about.
So does a time in neither form.

Retention sometimes removes a backup, cnpg.io record and all, while our Backup still lists it.
A restore from it should still go ahead the way it does today, and raise a Kubernetes Warning event that names the backup, so the operator can see it was not used.

Whatever one restore of an app decides must not carry over into the next restore of that app.

Can you track down what's going on and fix it?
