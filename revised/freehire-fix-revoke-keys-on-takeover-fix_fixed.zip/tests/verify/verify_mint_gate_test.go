//go:build integration

// Checks key creation on the HTTP endpoint: an account whose address has not been
// proven is refused and ends up with no key on record, while an account with a
// proven address is issued one. The check drives the real route (cookie session,
// then POST to the create route) against a live Postgres and asserts only that
// observable outcome, not a particular status code for the refusal.
//
// Run with: go test -tags=integration ./internal/handler/
package handler

import (
	"bytes"
	"context"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/gofiber/fiber/v2"

	"github.com/strelov1/freehire/internal/accounts"
	"github.com/strelov1/freehire/internal/auth"
	"github.com/strelov1/freehire/internal/db"
)

// TestVerifyUnverifiedAccountCannotMintAPIKey: a POST to the key-creation route from
// a holder whose address is not proven leaves no key on record, and a holder whose
// address is proven is issued one.
func TestVerifyUnverifiedAccountCannotMintAPIKey(t *testing.T) {
	pool := startPostgres(t)
	ctx := context.Background()

	var unprovenID, provenID int64
	if err := pool.QueryRow(ctx,
		`INSERT INTO users (email, password_hash, email_verified) VALUES ('mg-unproven@example.test', 'seeded-hash', false) RETURNING id`).Scan(&unprovenID); err != nil {
		t.Fatalf("seed unproven account: %v", err)
	}
	if err := pool.QueryRow(ctx,
		`INSERT INTO users (email, password_hash, email_verified) VALUES ('mg-proven@example.test', 'seeded-hash', true) RETURNING id`).Scan(&provenID); err != nil {
		t.Fatalf("seed proven account: %v", err)
	}

	iss := auth.NewIssuer("test-secret", time.Hour)
	unprovenCookie, _ := iss.Issue(unprovenID, testTokenVersion)
	provenCookie, _ := iss.Issue(provenID, testTokenVersion)

	queries := db.New(pool)
	// The handler is wired the way production builds it, with both the queries
	// and the accounts service populated, so the caller's account can be read
	// through either one.
	h := &authHandlers{queries: queries, accounts: accounts.New(accounts.NewQueriesRepository(queries, pool), authHasher{})}

	app := fiber.New(fiber.Config{ErrorHandler: RenderError})
	app.Post("/api/v1/me/api-keys", auth.RequireAuth(iss, testVersions), h.CreateAPIKey)

	mintReq := func(cookie string) *http.Request {
		r := httptest.NewRequest(fiber.MethodPost, "/api/v1/me/api-keys", bytes.NewReader([]byte(`{"name":"cli"}`)))
		r.Header.Set("Content-Type", "application/json")
		r.AddCookie(&http.Cookie{Name: auth.CookieName, Value: cookie})
		return r
	}

	liveKeyCount := func(userID int64) int {
		var n int
		if err := pool.QueryRow(ctx, "SELECT count(*) FROM api_keys WHERE user_id = $1", userID).Scan(&n); err != nil {
			t.Fatalf("count keys for %d: %v", userID, err)
		}
		return n
	}

	// A holder whose address is not proven asks for a key.
	unprovenResp, err := app.Test(mintReq(unprovenCookie))
	if err != nil {
		t.Fatalf("mint as unproven: %v", err)
	}
	if unprovenResp.StatusCode == fiber.StatusCreated {
		t.Error("the create route issued a key (201) to a holder with an unproven address")
	}
	if n := liveKeyCount(unprovenID); n != 0 {
		t.Errorf("an unproven holder ended up with %d key(s) on record, want 0", n)
	}

	// A holder whose address is proven can still create a key.
	provenResp, err := app.Test(mintReq(provenCookie))
	if err != nil {
		t.Fatalf("mint as proven: %v", err)
	}
	if provenResp.StatusCode != fiber.StatusCreated {
		t.Errorf("the create route refused a holder with a proven address (status %d, want 201)", provenResp.StatusCode)
	}
	if n := liveKeyCount(provenID); n != 1 {
		t.Errorf("a proven holder ended up with %d key(s) on record, want 1", n)
	}
}
