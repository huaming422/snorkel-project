//go:build integration

// Checks for the OAuth seizure of an unverified account: when the proven owner of an
// address signs in through a provider that vouches for it, every API key the previous
// holder had on the account stops authenticating, and keys on other accounts keep
// working. A seizure that cannot remove the keys fails as a whole and leaves the
// account as it was, and a provider sign-in that is not a seizure leaves the keys
// alone. Each check drives the accounts service the OAuth callback uses against a
// live Postgres (one cloned database per test via the testdb harness) and reads key
// liveness back through the key-authentication query the API middleware uses. The
// keys are minted through the repo's create query, the way a holder would have
// minted them, and each account holds two of them: a full-scope key that never
// expires and a cv-scope key with an expiry.
//
// Run with: go test -tags=integration ./internal/accounts/
package accounts_test

import (
	"context"
	"errors"
	"fmt"
	"testing"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgtype"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/strelov1/freehire/internal/accounts"
	"github.com/strelov1/freehire/internal/db"
	"github.com/strelov1/freehire/internal/testdb"
)

// chkHasher satisfies accounts.PasswordHasher. The seizure path never hashes or
// checks a password, so a plain stand-in keeps bcrypt out of these checks.
type chkHasher struct{}

func (chkHasher) Hash(plain string) (string, error) { return "plain:" + plain, nil }
func (chkHasher) Check(hash, plain string) error {
	if hash != "plain:"+plain {
		return errors.New("password mismatch")
	}
	return nil
}

// chkService builds the real accounts service over the real repository, the same
// pair the OAuth callback resolves identities through in production.
func chkService(pool *pgxpool.Pool) *accounts.Service {
	return accounts.New(accounts.NewQueriesRepository(db.New(pool), pool), chkHasher{})
}

// chkSeedUser inserts a password-backed account with a proven address and returns
// its id. Done by hand so the check controls the starting state exactly.
func chkSeedUser(t *testing.T, pool *pgxpool.Pool, email string) int64 {
	t.Helper()
	var id int64
	if err := pool.QueryRow(context.Background(),
		`INSERT INTO users (email, password_hash, email_verified) VALUES ($1, 'seeded-hash', true) RETURNING id`,
		email).Scan(&id); err != nil {
		t.Fatalf("seed account %s: %v", email, err)
	}
	return id
}

// chkMarkUnverified flips the account back to an unproven address, the state a
// squatter's registration sits in. Keys minted earlier stay on record.
func chkMarkUnverified(t *testing.T, pool *pgxpool.Pool, userID int64) {
	t.Helper()
	if _, err := pool.Exec(context.Background(),
		`UPDATE users SET email_verified = false WHERE id = $1`, userID); err != nil {
		t.Fatalf("mark %d unverified: %v", userID, err)
	}
}

// chkMintKeys mints two keys for the account through the create query and returns
// their hashes: a full-scope key that never expires and a cv-scope key that expires
// in a month. The account must have a proven address when this runs.
func chkMintKeys(t *testing.T, q *db.Queries, userID int64, tag string) []string {
	t.Helper()
	keys := []struct {
		hash, prefix, scope string
		expires             pgtype.Timestamptz
	}{
		{tag + "-full-hash", "fhk_" + tag[:3] + "f", "full", pgtype.Timestamptz{}},
		{tag + "-cv-hash", "fhk_" + tag[:3] + "c", "cv",
			pgtype.Timestamptz{Time: time.Now().Add(30 * 24 * time.Hour), Valid: true}},
	}
	hashes := make([]string, 0, len(keys))
	for _, k := range keys {
		if _, err := q.CreateAPIKey(context.Background(), db.CreateAPIKeyParams{
			UserID:      userID,
			Name:        tag + " " + k.scope,
			TokenHash:   k.hash,
			TokenPrefix: k.prefix,
			ExpiresAt:   k.expires,
			Scope:       k.scope,
		}); err != nil {
			t.Fatalf("mint %s key for %d: %v", k.scope, userID, err)
		}
		hashes = append(hashes, k.hash)
	}
	return hashes
}

// chkKeyAuthenticates reports whether the key with this hash still authenticates,
// read through the key-authentication query. A key that was removed or has
// otherwise stopped being valid resolves to no row.
func chkKeyAuthenticates(t *testing.T, q *db.Queries, hash string) bool {
	t.Helper()
	_, err := q.AuthenticateAPIKey(context.Background(), hash)
	if err == nil {
		return true
	}
	if errors.Is(err, pgx.ErrNoRows) {
		return false
	}
	t.Fatalf("authenticate key: %v", err)
	return false
}

// chkRequireLive fails the test at once when a freshly minted key does not
// authenticate, since every later assertion would then be meaningless.
func chkRequireLive(t *testing.T, q *db.Queries, hashes []string) {
	t.Helper()
	for _, h := range hashes {
		if !chkKeyAuthenticates(t, q, h) {
			t.Fatalf("freshly minted key %s does not authenticate; setup is wrong", h)
		}
	}
}

// TestVerifySeizureRevokesTheHoldersAPIKey: when a provider-verified sign-in seizes
// an unverified, password-backed account, both of the previous holder's keys stop
// authenticating, and the sign-in itself completes onto that same account.
func TestVerifySeizureRevokesTheHoldersAPIKey(t *testing.T) {
	pool := testdb.Pool(t)
	ctx := context.Background()
	q := db.New(pool)

	const email = "chk-seize@example.test"
	userID := chkSeedUser(t, pool, email)
	hashes := chkMintKeys(t, q, userID, "seize")
	chkRequireLive(t, q, hashes)
	chkMarkUnverified(t, pool, userID)

	got, err := chkService(pool).ResolveOAuthAccount(ctx, "google", "google-chk-seize", email, true)
	if err != nil {
		t.Fatalf("provider sign-in for the address: %v", err)
	}
	if got != userID {
		t.Fatalf("provider sign-in resolved to account %d, want the existing account %d", got, userID)
	}

	for _, h := range hashes {
		if chkKeyAuthenticates(t, q, h) {
			t.Errorf("key %s still authenticates after the account was seized by the address owner", h)
		}
	}
}

// TestVerifySeizureIsScopedToTheSeizedAccount: seizing one account takes away its
// own keys and leaves every key of a different account working.
func TestVerifySeizureIsScopedToTheSeizedAccount(t *testing.T) {
	pool := testdb.Pool(t)
	ctx := context.Background()
	q := db.New(pool)

	const seizedEmail = "chk-scope-seized@example.test"
	const bystanderEmail = "chk-scope-bystander@example.test"

	seizedID := chkSeedUser(t, pool, seizedEmail)
	bystanderID := chkSeedUser(t, pool, bystanderEmail)
	seizedKeys := chkMintKeys(t, q, seizedID, "doomed")
	bystanderKeys := chkMintKeys(t, q, bystanderID, "innocent")
	chkRequireLive(t, q, append(append([]string{}, seizedKeys...), bystanderKeys...))
	chkMarkUnverified(t, pool, seizedID)

	got, err := chkService(pool).ResolveOAuthAccount(ctx, "github", "github-chk-scope", seizedEmail, true)
	if err != nil {
		t.Fatalf("provider sign-in for the address: %v", err)
	}
	if got != seizedID {
		t.Fatalf("provider sign-in resolved to account %d, want the existing account %d", got, seizedID)
	}

	for _, h := range seizedKeys {
		if chkKeyAuthenticates(t, q, h) {
			t.Errorf("seized account's key %s still authenticates after its seizure", h)
		}
	}
	for _, h := range bystanderKeys {
		if !chkKeyAuthenticates(t, q, h) {
			t.Errorf("key %s of a different account stopped authenticating when another account was seized", h)
		}
	}
}

// chkAccountState is the part of an account a seizure changes: the password, the
// verified flag and the session generation.
type chkAccountState struct {
	passwordHash  pgtype.Text
	emailVerified bool
	tokenVersion  int32
}

func chkReadAccount(t *testing.T, pool *pgxpool.Pool, userID int64) chkAccountState {
	t.Helper()
	var s chkAccountState
	if err := pool.QueryRow(context.Background(),
		`SELECT password_hash, email_verified, token_version FROM users WHERE id = $1`,
		userID).Scan(&s.passwordHash, &s.emailVerified, &s.tokenVersion); err != nil {
		t.Fatalf("read account %d: %v", userID, err)
	}
	return s
}

// chkRefuseKeyChanges makes the database reject any change to, or removal of, this
// account's API key rows until the returned function runs. Rows of other accounts
// and new rows are not affected.
func chkRefuseKeyChanges(t *testing.T, pool *pgxpool.Pool, userID int64) func() {
	t.Helper()
	ctx := context.Background()
	if _, err := pool.Exec(ctx, `CREATE OR REPLACE FUNCTION chk_refuse_key_change() RETURNS trigger
LANGUAGE plpgsql AS $$ BEGIN RAISE EXCEPTION 'api key rows of this account cannot change right now'; END $$`); err != nil {
		t.Fatalf("create refusal function: %v", err)
	}
	if _, err := pool.Exec(ctx, fmt.Sprintf(`CREATE TRIGGER chk_refuse_key_change
BEFORE UPDATE OR DELETE ON api_keys FOR EACH ROW WHEN (OLD.user_id = %d)
EXECUTE FUNCTION chk_refuse_key_change()`, userID)); err != nil {
		t.Fatalf("create refusal trigger: %v", err)
	}
	return func() {
		if _, err := pool.Exec(ctx, `DROP TRIGGER IF EXISTS chk_refuse_key_change ON api_keys`); err != nil {
			t.Fatalf("drop refusal trigger: %v", err)
		}
	}
}

// chkAnyAlive reports the first key that still authenticates, or "" when none does.
func chkAnyAlive(t *testing.T, q *db.Queries, hashes []string) string {
	t.Helper()
	for _, h := range hashes {
		if chkKeyAuthenticates(t, q, h) {
			return h
		}
	}
	return ""
}

// TestVerifySeizureIsAllOrNothing: while the account's keys cannot be removed, a
// provider-verified sign-in for its address either completes with every key gone or
// fails with an error and leaves the password, the verified flag and the session
// generation untouched. Once the keys can be removed again, the same sign-in takes
// the account over.
func TestVerifySeizureIsAllOrNothing(t *testing.T) {
	pool := testdb.Pool(t)
	ctx := context.Background()
	q := db.New(pool)

	const email = "chk-whole@example.test"
	userID := chkSeedUser(t, pool, email)
	hashes := chkMintKeys(t, q, userID, "whole")
	chkRequireLive(t, q, hashes)
	chkMarkUnverified(t, pool, userID)
	before := chkReadAccount(t, pool, userID)
	svc := chkService(pool)

	restore := chkRefuseKeyChanges(t, pool, userID)
	got, err := svc.ResolveOAuthAccount(ctx, "google", "google-chk-whole", email, true)
	restore()

	after := chkReadAccount(t, pool, userID)
	alive := chkAnyAlive(t, q, hashes)
	if err == nil {
		if got != userID {
			t.Fatalf("provider sign-in resolved to account %d, want the existing account %d", got, userID)
		}
		if alive != "" {
			t.Fatalf("the sign-in completed but key %s still authenticates", alive)
		}
		return
	}
	if after != before {
		t.Fatalf("the sign-in failed (%v) but the account still changed: password kept %v -> %v, verified %v -> %v, session generation %d -> %d",
			err, before.passwordHash.Valid, after.passwordHash.Valid, before.emailVerified, after.emailVerified,
			before.tokenVersion, after.tokenVersion)
	}

	got, err = svc.ResolveOAuthAccount(ctx, "google", "google-chk-whole", email, true)
	if err != nil {
		t.Fatalf("provider sign-in after the earlier failure: %v", err)
	}
	if got != userID {
		t.Fatalf("provider sign-in after the earlier failure resolved to account %d, want %d", got, userID)
	}
	if h := chkAnyAlive(t, q, hashes); h != "" {
		t.Errorf("key %s still authenticates after the repeated sign-in took the account over", h)
	}
	if s := chkReadAccount(t, pool, userID); s.passwordHash.Valid {
		t.Errorf("the repeated sign-in completed but the old password is still set")
	}
}

// chkLiveness reads whether each key authenticates right now.
func chkLiveness(t *testing.T, q *db.Queries, hashes []string) []bool {
	t.Helper()
	out := make([]bool, len(hashes))
	for i, h := range hashes {
		out[i] = chkKeyAuthenticates(t, q, h)
	}
	return out
}

// chkRequireUnchanged fails when any key's liveness differs from what it was before.
func chkRequireUnchanged(t *testing.T, q *db.Queries, hashes []string, before []bool, after string) {
	t.Helper()
	for i, live := range chkLiveness(t, q, hashes) {
		if live != before[i] {
			t.Errorf("key %s went from authenticating=%v to %v after %s", hashes[i], before[i], live, after)
		}
	}
}

// TestVerifySignInsThatAreNotSeizuresKeepAPIKeys: a sign-in whose provider does not
// vouch for the address leaves the account's keys as they were, for
// an account with an unproven address and for one with a proven address. A
// provider-verified sign-in into an account whose address was already proven joins
// that account and leaves its keys working.
func TestVerifySignInsThatAreNotSeizuresKeepAPIKeys(t *testing.T) {
	pool := testdb.Pool(t)
	ctx := context.Background()
	q := db.New(pool)
	svc := chkService(pool)

	for _, tc := range []struct {
		email, tag, provider string
		unverified           bool
	}{
		{"chk-unvouched-squatted@example.test", "unvsquat", "github", true},
		{"chk-unvouched-owner@example.test", "unvowner", "google", false},
	} {
		userID := chkSeedUser(t, pool, tc.email)
		keys := chkMintKeys(t, q, userID, tc.tag)
		chkRequireLive(t, q, keys)
		if tc.unverified {
			chkMarkUnverified(t, pool, userID)
		}
		before := chkLiveness(t, q, keys)
		_, _ = svc.ResolveOAuthAccount(ctx, tc.provider, tc.provider+"-"+tc.tag, tc.email, false)
		chkRequireUnchanged(t, q, keys, before, "a sign-in that did not prove the address "+tc.email)
	}

	const provenEmail = "chk-joined@example.test"
	provenID := chkSeedUser(t, pool, provenEmail)
	provenKeys := chkMintKeys(t, q, provenID, "joined")
	chkRequireLive(t, q, provenKeys)

	got, err := svc.ResolveOAuthAccount(ctx, "google", "google-chk-joined", provenEmail, true)
	if err != nil {
		t.Fatalf("provider sign-in into a verified account: %v", err)
	}
	if got != provenID {
		t.Fatalf("provider sign-in resolved to account %d, want the verified account %d", got, provenID)
	}
	for _, h := range provenKeys {
		if !chkKeyAuthenticates(t, q, h) {
			t.Errorf("key %s stopped authenticating after a provider sign-in into an already verified account", h)
		}
	}
}
