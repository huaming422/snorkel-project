//go:build integration

// Checks for the account's own credential actions over HTTP: a password reset by
// mailed code takes away every API key on the account, while "sign out everywhere"
// and a signed-in password change made with the current password leave the
// account's keys working. Each check drives the real routes, handlers, accounts
// service, repository and code store against a live Postgres, and reads key
// liveness back through the key-authentication query the API middleware uses.
// Keys are minted through the repo's create query; each account holds a full-scope
// key that never expires and a cv-scope key with an expiry.
//
// Run with: go test -tags=integration ./internal/handler/
package handler

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgtype"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/strelov1/freehire/internal/accounts"
	"github.com/strelov1/freehire/internal/auth"
	"github.com/strelov1/freehire/internal/db"
)

// credMailer records each reset code by address. The forgot-password route mails
// from a background goroutine, so access is locked and readers poll.
type credMailer struct {
	mu    sync.Mutex
	reset map[string]string
}

func (m *credMailer) SendVerificationCode(context.Context, string, string) error { return nil }

func (m *credMailer) SendPasswordResetCode(_ context.Context, email, code string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if m.reset == nil {
		m.reset = map[string]string{}
	}
	m.reset[email] = code
	return nil
}

func (m *credMailer) waitResetCode(t *testing.T, email string) string {
	t.Helper()
	deadline := time.Now().Add(15 * time.Second)
	for time.Now().Before(deadline) {
		m.mu.Lock()
		code, ok := m.reset[email]
		m.mu.Unlock()
		if ok {
			return code
		}
		time.Sleep(20 * time.Millisecond)
	}
	t.Fatalf("no reset code was mailed to %s", email)
	return ""
}

// credEnv is the wired HTTP surface plus what the checks read back.
type credEnv struct {
	app    *fiber.App
	pool   *pgxpool.Pool
	q      *db.Queries
	iss    *auth.Issuer
	mailer *credMailer
}

// credSetup wires the real accounts service (bcrypt, real repository, real code
// store) onto the reset, password-change and sign-out-everywhere routes.
func credSetup(t *testing.T) credEnv {
	t.Helper()
	pool := startPostgres(t)
	queries := db.New(pool)
	mailer := &credMailer{}

	svc := accounts.New(accounts.NewQueriesRepository(queries, pool), authHasher{})
	svc.WithCodes(accounts.NewQueriesCodeStore(queries), mailer)

	iss := auth.NewIssuer("test-secret", time.Hour)
	h := &authHandlers{queries: queries, issuer: iss, accounts: svc}

	app := fiber.New(fiber.Config{ErrorHandler: RenderError})
	cookieAuth := auth.RequireAuth(iss, queries)
	app.Post("/api/v1/auth/password/forgot", h.ForgotPassword)
	app.Post("/api/v1/auth/password/reset", h.ResetPassword)
	app.Post("/api/v1/me/password", cookieAuth, h.ChangePassword)
	app.Post("/api/v1/auth/logout-all", cookieAuth, h.LogoutAll)
	return credEnv{app: app, pool: pool, q: queries, iss: iss, mailer: mailer}
}

// seedUser inserts an account whose password is `password` and whose address is
// proven, and returns its id.
func (e credEnv) seedUser(t *testing.T, email, password string) int64 {
	t.Helper()
	hash, err := auth.HashPassword(password)
	if err != nil {
		t.Fatalf("hash password: %v", err)
	}
	var id int64
	if err := e.pool.QueryRow(context.Background(),
		`INSERT INTO users (email, password_hash, email_verified) VALUES ($1, $2, true) RETURNING id`,
		email, hash).Scan(&id); err != nil {
		t.Fatalf("seed account %s: %v", email, err)
	}
	return id
}

func (e credEnv) markUnverified(t *testing.T, userID int64) {
	t.Helper()
	if _, err := e.pool.Exec(context.Background(),
		`UPDATE users SET email_verified = false WHERE id = $1`, userID); err != nil {
		t.Fatalf("mark %d unverified: %v", userID, err)
	}
}

// mintKeys mints a full-scope never-expiring key and a cv-scope key that expires
// in a month for the account, through the create query, and returns their hashes.
// The account must have a proven address when this runs.
func (e credEnv) mintKeys(t *testing.T, userID int64, tag string) []string {
	t.Helper()
	keys := []struct {
		hash, prefix, scope string
		expires             pgtype.Timestamptz
	}{
		{tag + "-full-hash", "fhk_" + tag[:3] + "f", "full", pgtype.Timestamptz{}},
		{tag + "-cv-hash", "fhk_" + tag[:3] + "c", "cv",
			pgtype.Timestamptz{Time: time.Now().Add(30 * 24 * time.Hour), Valid: true}},
	}
	hashes := make([]string, 0, len(keys))
	for _, k := range keys {
		if _, err := e.q.CreateAPIKey(context.Background(), db.CreateAPIKeyParams{
			UserID:      userID,
			Name:        tag + " " + k.scope,
			TokenHash:   k.hash,
			TokenPrefix: k.prefix,
			ExpiresAt:   k.expires,
			Scope:       k.scope,
		}); err != nil {
			t.Fatalf("mint %s key for %d: %v", k.scope, userID, err)
		}
		hashes = append(hashes, k.hash)
	}
	for _, h := range hashes {
		if !e.keyAuthenticates(t, h) {
			t.Fatalf("freshly minted key %s does not authenticate; setup is wrong", h)
		}
	}
	return hashes
}

// keyAuthenticates reports whether the key with this hash still authenticates.
// A key that was removed or has otherwise stopped being valid resolves to no row.
func (e credEnv) keyAuthenticates(t *testing.T, hash string) bool {
	t.Helper()
	_, err := e.q.AuthenticateAPIKey(context.Background(), hash)
	if err == nil {
		return true
	}
	if errors.Is(err, pgx.ErrNoRows) {
		return false
	}
	t.Fatalf("authenticate key: %v", err)
	return false
}

// post sends a JSON body, optionally with a session cookie, and returns the status.
func (e credEnv) post(t *testing.T, path, body, cookie string) int {
	t.Helper()
	req := httptest.NewRequest(fiber.MethodPost, path, strings.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	if cookie != "" {
		req.AddCookie(&http.Cookie{Name: auth.CookieName, Value: cookie})
	}
	resp, err := e.app.Test(req, 15_000)
	if err != nil {
		t.Fatalf("%s: %v", path, err)
	}
	resp.Body.Close()
	return resp.StatusCode
}

// cookieFor issues a session cookie at the account's current session generation.
func (e credEnv) cookieFor(t *testing.T, userID int64) string {
	t.Helper()
	version, err := e.q.GetUserTokenVersion(context.Background(), userID)
	if err != nil {
		t.Fatalf("read session generation: %v", err)
	}
	cookie, err := e.iss.Issue(userID, version)
	if err != nil {
		t.Fatalf("issue session: %v", err)
	}
	return cookie
}

// TestVerifyPasswordResetRevokesTheAccountsAPIKey: completing a reset by mailed code
// takes away every key on the account, for an account with a proven address and for
// one whose address was never proven, and leaves another account's keys working.
func TestVerifyPasswordResetRevokesTheAccountsAPIKey(t *testing.T) {
	for _, tc := range []struct {
		name       string
		email      string
		unverified bool
	}{
		{"proven address", "chk-reset-owner@example.test", false},
		{"unproven address", "chk-reset-squatted@example.test", true},
	} {
		t.Run(tc.name, func(t *testing.T) {
			e := credSetup(t)
			userID := e.seedUser(t, tc.email, "old-password-1")
			bystanderID := e.seedUser(t, "bystander-"+tc.email, "bystander-pass-1")
			keys := e.mintKeys(t, userID, "target")
			bystanderKeys := e.mintKeys(t, bystanderID, "bystander")
			if tc.unverified {
				e.markUnverified(t, userID)
			}

			if s := e.post(t, "/api/v1/auth/password/forgot", `{"email":"`+tc.email+`"}`, ""); s != fiber.StatusAccepted {
				t.Fatalf("forgot-password status = %d, want 202", s)
			}
			code := e.mailer.waitResetCode(t, tc.email)
			body := `{"email":"` + tc.email + `","code":"` + code + `","password":"brand-new-pass-1"}`
			if s := e.post(t, "/api/v1/auth/password/reset", body, ""); s != fiber.StatusOK {
				t.Fatalf("reset status = %d, want 200", s)
			}

			for _, h := range keys {
				if e.keyAuthenticates(t, h) {
					t.Errorf("key %s still authenticates after the password reset", h)
				}
			}
			for _, h := range bystanderKeys {
				if !e.keyAuthenticates(t, h) {
					t.Errorf("key %s of a different account stopped authenticating after another account's reset", h)
				}
			}
		})
	}
}

// TestVerifySelfServicePasswordChangeKeepsAPIKeys: a signed-in user who changes
// their password by giving the current one keeps every key on the account working.
func TestVerifySelfServicePasswordChangeKeepsAPIKeys(t *testing.T) {
	e := credSetup(t)
	const email = "chk-pwchange@example.test"
	userID := e.seedUser(t, email, "current-pass-1")
	keys := e.mintKeys(t, userID, "pwchange")

	body := `{"current_password":"current-pass-1","password":"rotated-pass-2"}`
	if s := e.post(t, "/api/v1/me/password", body, e.cookieFor(t, userID)); s != fiber.StatusOK {
		t.Fatalf("password change status = %d, want 200", s)
	}

	for _, h := range keys {
		if !e.keyAuthenticates(t, h) {
			t.Errorf("key %s stopped authenticating after the account's own password change", h)
		}
	}
}

// TestVerifyOrdinarySessionRevocationKeepsAPIKeys: "sign out everywhere" ends the
// account's sessions and keeps every key on the account working.
func TestVerifyOrdinarySessionRevocationKeepsAPIKeys(t *testing.T) {
	e := credSetup(t)
	const email = "chk-signout@example.test"
	userID := e.seedUser(t, email, "signout-pass-1")
	keys := e.mintKeys(t, userID, "signout")

	if s := e.post(t, "/api/v1/auth/logout-all", "", e.cookieFor(t, userID)); s != fiber.StatusNoContent {
		t.Fatalf("sign-out-everywhere status = %d, want 204", s)
	}

	for _, h := range keys {
		if !e.keyAuthenticates(t, h) {
			t.Errorf("key %s stopped authenticating after sign out everywhere", h)
		}
	}
}
