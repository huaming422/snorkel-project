//go:build integration

// Checks for the account's own credential actions over HTTP: a password reset by
// mailed code takes away every API key on the account, while "sign out everywhere"
// and a signed-in password change made with the current password leave the
// account's keys working. A reset that cannot remove the keys fails as a whole, a
// reset attempt that does not go through leaves the keys alone, and an owner who
// took the account back can create a key afterwards. Each check drives the real routes, handlers, accounts
// service, repository and code store against a live Postgres, and reads key
// liveness back through the key-authentication query the API middleware uses.
// Keys are minted through the repo's create query; each account holds a full-scope
// key that never expires and a cv-scope key with an expiry.
//
// Run with: go test -tags=integration ./internal/handler/
package handler

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgtype"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/strelov1/freehire/internal/accounts"
	"github.com/strelov1/freehire/internal/auth"
	"github.com/strelov1/freehire/internal/db"
)

// credMailer records each reset code by address. The forgot-password route mails
// from a background goroutine, so access is locked and readers poll.
type credMailer struct {
	mu    sync.Mutex
	reset map[string]string
}

func (m *credMailer) SendVerificationCode(context.Context, string, string) error { return nil }

func (m *credMailer) SendPasswordResetCode(_ context.Context, email, code string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if m.reset == nil {
		m.reset = map[string]string{}
	}
	m.reset[email] = code
	return nil
}

// forget drops the code recorded for an address, so the next wait sees only a new one.
func (m *credMailer) forget(email string) {
	m.mu.Lock()
	defer m.mu.Unlock()
	delete(m.reset, email)
}

func (m *credMailer) waitResetCode(t *testing.T, email string) string {
	t.Helper()
	deadline := time.Now().Add(15 * time.Second)
	for time.Now().Before(deadline) {
		m.mu.Lock()
		code, ok := m.reset[email]
		m.mu.Unlock()
		if ok {
			return code
		}
		time.Sleep(20 * time.Millisecond)
	}
	t.Fatalf("no reset code was mailed to %s", email)
	return ""
}

// credEnv is the wired HTTP surface plus what the checks read back.
type credEnv struct {
	app    *fiber.App
	pool   *pgxpool.Pool
	q      *db.Queries
	iss    *auth.Issuer
	mailer *credMailer
	svc    *accounts.Service
}

// credSetup wires the real accounts service (bcrypt, real repository, real code
// store) onto the reset, password-change, sign-out-everywhere and key-creation routes.
func credSetup(t *testing.T) credEnv {
	t.Helper()
	pool := startPostgres(t)
	queries := db.New(pool)
	mailer := &credMailer{}

	svc := accounts.New(accounts.NewQueriesRepository(queries, pool), authHasher{})
	svc.WithCodes(accounts.NewQueriesCodeStore(queries), mailer)

	iss := auth.NewIssuer("test-secret", time.Hour)
	h := &authHandlers{queries: queries, issuer: iss, accounts: svc}

	app := fiber.New(fiber.Config{ErrorHandler: RenderError})
	cookieAuth := auth.RequireAuth(iss, queries)
	app.Post("/api/v1/auth/password/forgot", h.ForgotPassword)
	app.Post("/api/v1/auth/password/reset", h.ResetPassword)
	app.Post("/api/v1/me/password", cookieAuth, h.ChangePassword)
	app.Post("/api/v1/auth/logout-all", cookieAuth, h.LogoutAll)
	app.Post("/api/v1/me/api-keys", cookieAuth, h.CreateAPIKey)
	return credEnv{app: app, pool: pool, q: queries, iss: iss, mailer: mailer, svc: svc}
}

// seedUser inserts an account whose password is `password` and whose address is
// proven, and returns its id.
func (e credEnv) seedUser(t *testing.T, email, password string) int64 {
	t.Helper()
	hash, err := auth.HashPassword(password)
	if err != nil {
		t.Fatalf("hash password: %v", err)
	}
	var id int64
	if err := e.pool.QueryRow(context.Background(),
		`INSERT INTO users (email, password_hash, email_verified) VALUES ($1, $2, true) RETURNING id`,
		email, hash).Scan(&id); err != nil {
		t.Fatalf("seed account %s: %v", email, err)
	}
	return id
}

func (e credEnv) markUnverified(t *testing.T, userID int64) {
	t.Helper()
	if _, err := e.pool.Exec(context.Background(),
		`UPDATE users SET email_verified = false WHERE id = $1`, userID); err != nil {
		t.Fatalf("mark %d unverified: %v", userID, err)
	}
}

// mintKeys mints a full-scope never-expiring key and a cv-scope key that expires
// in a month for the account, through the create query, and returns their hashes.
// The account must have a proven address when this runs.
func (e credEnv) mintKeys(t *testing.T, userID int64, tag string) []string {
	t.Helper()
	keys := []struct {
		hash, prefix, scope string
		expires             pgtype.Timestamptz
	}{
		{tag + "-full-hash", "fhk_" + tag[:3] + "f", "full", pgtype.Timestamptz{}},
		{tag + "-cv-hash", "fhk_" + tag[:3] + "c", "cv",
			pgtype.Timestamptz{Time: time.Now().Add(30 * 24 * time.Hour), Valid: true}},
	}
	hashes := make([]string, 0, len(keys))
	for _, k := range keys {
		if _, err := e.q.CreateAPIKey(context.Background(), db.CreateAPIKeyParams{
			UserID:      userID,
			Name:        tag + " " + k.scope,
			TokenHash:   k.hash,
			TokenPrefix: k.prefix,
			ExpiresAt:   k.expires,
			Scope:       k.scope,
		}); err != nil {
			t.Fatalf("mint %s key for %d: %v", k.scope, userID, err)
		}
		hashes = append(hashes, k.hash)
	}
	for _, h := range hashes {
		if !e.keyAuthenticates(t, h) {
			t.Fatalf("freshly minted key %s does not authenticate; setup is wrong", h)
		}
	}
	return hashes
}

// keyAuthenticates reports whether the key with this hash still authenticates.
// A key that was removed or has otherwise stopped being valid resolves to no row.
func (e credEnv) keyAuthenticates(t *testing.T, hash string) bool {
	t.Helper()
	_, err := e.q.AuthenticateAPIKey(context.Background(), hash)
	if err == nil {
		return true
	}
	if errors.Is(err, pgx.ErrNoRows) {
		return false
	}
	t.Fatalf("authenticate key: %v", err)
	return false
}

// post sends a JSON body, optionally with a session cookie, and returns the status.
func (e credEnv) post(t *testing.T, path, body, cookie string) int {
	t.Helper()
	status, _ := e.postRead(t, path, body, cookie)
	return status
}

// postRead is post that also returns the response body.
func (e credEnv) postRead(t *testing.T, path, body, cookie string) (int, []byte) {
	t.Helper()
	req := httptest.NewRequest(fiber.MethodPost, path, strings.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	if cookie != "" {
		req.AddCookie(&http.Cookie{Name: auth.CookieName, Value: cookie})
	}
	resp, err := e.app.Test(req, 15_000)
	if err != nil {
		t.Fatalf("%s: %v", path, err)
	}
	defer resp.Body.Close()
	out, err := io.ReadAll(resp.Body)
	if err != nil {
		t.Fatalf("%s: read body: %v", path, err)
	}
	return resp.StatusCode, out
}

// cookieFor issues a session cookie at the account's current session generation.
func (e credEnv) cookieFor(t *testing.T, userID int64) string {
	t.Helper()
	version, err := e.q.GetUserTokenVersion(context.Background(), userID)
	if err != nil {
		t.Fatalf("read session generation: %v", err)
	}
	cookie, err := e.iss.Issue(userID, version)
	if err != nil {
		t.Fatalf("issue session: %v", err)
	}
	return cookie
}

// TestVerifyPasswordResetRevokesTheAccountsAPIKey: completing a reset by mailed code
// takes away every key on the account, for an account with a proven address and for
// one whose address was never proven, and leaves another account's keys working.
func TestVerifyPasswordResetRevokesTheAccountsAPIKey(t *testing.T) {
	for _, tc := range []struct {
		name       string
		email      string
		unverified bool
	}{
		{"proven address", "chk-reset-owner@example.test", false},
		{"unproven address", "chk-reset-squatted@example.test", true},
	} {
		t.Run(tc.name, func(t *testing.T) {
			e := credSetup(t)
			userID := e.seedUser(t, tc.email, "old-password-1")
			bystanderID := e.seedUser(t, "bystander-"+tc.email, "bystander-pass-1")
			keys := e.mintKeys(t, userID, "target")
			bystanderKeys := e.mintKeys(t, bystanderID, "bystander")
			if tc.unverified {
				e.markUnverified(t, userID)
			}

			if s := e.post(t, "/api/v1/auth/password/forgot", `{"email":"`+tc.email+`"}`, ""); s != fiber.StatusAccepted {
				t.Fatalf("forgot-password status = %d, want 202", s)
			}
			code := e.mailer.waitResetCode(t, tc.email)
			body := `{"email":"` + tc.email + `","code":"` + code + `","password":"brand-new-pass-1"}`
			if s := e.post(t, "/api/v1/auth/password/reset", body, ""); s != fiber.StatusOK {
				t.Fatalf("reset status = %d, want 200", s)
			}

			for _, h := range keys {
				if e.keyAuthenticates(t, h) {
					t.Errorf("key %s still authenticates after the password reset", h)
				}
			}
			for _, h := range bystanderKeys {
				if !e.keyAuthenticates(t, h) {
					t.Errorf("key %s of a different account stopped authenticating after another account's reset", h)
				}
			}
		})
	}
}

// TestVerifySelfServicePasswordChangeKeepsAPIKeys: a signed-in user who changes
// their password by giving the current one keeps every key on the account working.
func TestVerifySelfServicePasswordChangeKeepsAPIKeys(t *testing.T) {
	e := credSetup(t)
	const email = "chk-pwchange@example.test"
	userID := e.seedUser(t, email, "current-pass-1")
	keys := e.mintKeys(t, userID, "pwchange")

	body := `{"current_password":"current-pass-1","password":"rotated-pass-2"}`
	if s := e.post(t, "/api/v1/me/password", body, e.cookieFor(t, userID)); s != fiber.StatusOK {
		t.Fatalf("password change status = %d, want 200", s)
	}

	for _, h := range keys {
		if !e.keyAuthenticates(t, h) {
			t.Errorf("key %s stopped authenticating after the account's own password change", h)
		}
	}
}

// TestVerifyOrdinarySessionRevocationKeepsAPIKeys: "sign out everywhere" ends the
// account's sessions and keeps every key on the account working.
func TestVerifyOrdinarySessionRevocationKeepsAPIKeys(t *testing.T) {
	e := credSetup(t)
	const email = "chk-signout@example.test"
	userID := e.seedUser(t, email, "signout-pass-1")
	keys := e.mintKeys(t, userID, "signout")

	if s := e.post(t, "/api/v1/auth/logout-all", "", e.cookieFor(t, userID)); s != fiber.StatusNoContent {
		t.Fatalf("sign-out-everywhere status = %d, want 204", s)
	}

	for _, h := range keys {
		if !e.keyAuthenticates(t, h) {
			t.Errorf("key %s stopped authenticating after sign out everywhere", h)
		}
	}
}

// requestResetCode asks for a reset code and returns the one mailed to the address.
func (e credEnv) requestResetCode(t *testing.T, email string) string {
	t.Helper()
	e.mailer.forget(email)
	if s := e.post(t, "/api/v1/auth/password/forgot", `{"email":"`+email+`"}`, ""); s != fiber.StatusAccepted {
		t.Fatalf("forgot-password status = %d, want 202", s)
	}
	return e.mailer.waitResetCode(t, email)
}

func (e credEnv) reset(t *testing.T, email, code, password string) int {
	t.Helper()
	return e.post(t, "/api/v1/auth/password/reset",
		`{"email":"`+email+`","code":"`+code+`","password":"`+password+`"}`, "")
}

// credAccountState is the part of an account a reset changes: the password, the
// verified flag and the session generation.
type credAccountState struct {
	passwordHash  string
	emailVerified bool
	tokenVersion  int32
}

func (e credEnv) readAccount(t *testing.T, userID int64) credAccountState {
	t.Helper()
	var s credAccountState
	if err := e.pool.QueryRow(context.Background(),
		`SELECT coalesce(password_hash, ''), email_verified, token_version FROM users WHERE id = $1`,
		userID).Scan(&s.passwordHash, &s.emailVerified, &s.tokenVersion); err != nil {
		t.Fatalf("read account %d: %v", userID, err)
	}
	return s
}

// refuseKeyChanges makes the database reject any change to, or removal of, this
// account's API key rows until the returned function runs. Rows of other accounts
// and new rows are not affected.
func (e credEnv) refuseKeyChanges(t *testing.T, userID int64) func() {
	t.Helper()
	ctx := context.Background()
	if _, err := e.pool.Exec(ctx, `CREATE OR REPLACE FUNCTION cred_refuse_key_change() RETURNS trigger
LANGUAGE plpgsql AS $$ BEGIN RAISE EXCEPTION 'api key rows of this account cannot change right now'; END $$`); err != nil {
		t.Fatalf("create refusal function: %v", err)
	}
	if _, err := e.pool.Exec(ctx, fmt.Sprintf(`CREATE TRIGGER cred_refuse_key_change
BEFORE UPDATE OR DELETE ON api_keys FOR EACH ROW WHEN (OLD.user_id = %d)
EXECUTE FUNCTION cred_refuse_key_change()`, userID)); err != nil {
		t.Fatalf("create refusal trigger: %v", err)
	}
	return func() {
		if _, err := e.pool.Exec(ctx, `DROP TRIGGER IF EXISTS cred_refuse_key_change ON api_keys`); err != nil {
			t.Fatalf("drop refusal trigger: %v", err)
		}
	}
}

// ageResetCode moves the outstanding reset code's issue time back past the resend
// wait, so a new code can be requested at once.
func (e credEnv) ageResetCode(t *testing.T, userID int64) {
	t.Helper()
	if _, err := e.pool.Exec(context.Background(),
		`UPDATE user_email_codes SET created_at = now() - interval '10 minutes' WHERE user_id = $1`, userID); err != nil {
		t.Fatalf("age reset code: %v", err)
	}
}

func (e credEnv) anyAlive(t *testing.T, hashes []string) string {
	t.Helper()
	for _, h := range hashes {
		if e.keyAuthenticates(t, h) {
			return h
		}
	}
	return ""
}

// createKey asks the key-creation route for a key as the account's current session
// and, when it is issued, checks that the returned token authenticates.
func (e credEnv) createKey(t *testing.T, userID int64, name string) {
	t.Helper()
	status, body := e.postRead(t, "/api/v1/me/api-keys", `{"name":"`+name+`"}`, e.cookieFor(t, userID))
	if status != fiber.StatusCreated {
		t.Errorf("key creation for the account's owner: status %d, want 201 (%s)", status, body)
		return
	}
	var out struct {
		Data struct {
			Token string `json:"token"`
		} `json:"data"`
	}
	if err := json.Unmarshal(body, &out); err != nil || out.Data.Token == "" {
		t.Errorf("key creation answered 201 without a token: %s", body)
		return
	}
	if !e.keyAuthenticates(t, auth.HashAPIKey(out.Data.Token)) {
		t.Errorf("the key created for the account's owner does not authenticate")
	}
}

// TestVerifyPasswordResetIsAllOrNothing: while the account's keys cannot be removed,
// a reset with a valid mailed code either completes with every key gone or fails
// with an error and leaves the password, the verified flag and the session
// generation untouched. Once the keys can be removed again, a new reset goes through
// and takes every key away.
func TestVerifyPasswordResetIsAllOrNothing(t *testing.T) {
	for _, tc := range []struct {
		name       string
		email      string
		unverified bool
	}{
		{"proven address", "chk-whole-owner@example.test", false},
		{"unproven address", "chk-whole-squatted@example.test", true},
	} {
		t.Run(tc.name, func(t *testing.T) {
			e := credSetup(t)
			userID := e.seedUser(t, tc.email, "old-password-1")
			keys := e.mintKeys(t, userID, "wholereset")
			if tc.unverified {
				e.markUnverified(t, userID)
			}
			code := e.requestResetCode(t, tc.email)
			before := e.readAccount(t, userID)

			restore := e.refuseKeyChanges(t, userID)
			status := e.reset(t, tc.email, code, "brand-new-pass-1")
			restore()

			after := e.readAccount(t, userID)
			alive := e.anyAlive(t, keys)
			if status >= 200 && status < 300 {
				if alive != "" {
					t.Fatalf("the reset answered %d but key %s still authenticates", status, alive)
				}
				return
			}
			if after != before {
				t.Fatalf("the reset failed (status %d) but the account still changed: password replaced %v, verified %v -> %v, session generation %d -> %d",
					status, after.passwordHash != before.passwordHash, before.emailVerified, after.emailVerified,
					before.tokenVersion, after.tokenVersion)
			}

			e.ageResetCode(t, userID)
			code = e.requestResetCode(t, tc.email)
			if s := e.reset(t, tc.email, code, "second-new-pass-2"); s != fiber.StatusOK {
				t.Fatalf("reset after the earlier failure: status %d, want 200", s)
			}
			if h := e.anyAlive(t, keys); h != "" {
				t.Errorf("key %s still authenticates after the repeated reset went through", h)
			}
		})
	}
}

func (e credEnv) liveness(t *testing.T, hashes []string) []bool {
	t.Helper()
	out := make([]bool, len(hashes))
	for i, h := range hashes {
		out[i] = e.keyAuthenticates(t, h)
	}
	return out
}

// TestVerifyResetAttemptsThatDoNotCompleteKeepAPIKeys: asking for a reset code, a
// reset with a wrong code and a reset whose new password is rejected all leave every
// key as it was. The reset that then goes through takes the keys away, and the owner
// can create a new key right after.
func TestVerifyResetAttemptsThatDoNotCompleteKeepAPIKeys(t *testing.T) {
	for _, tc := range []struct {
		name       string
		email      string
		unverified bool
	}{
		{"proven address", "chk-attempt-owner@example.test", false},
		{"unproven address", "chk-attempt-squatted@example.test", true},
	} {
		t.Run(tc.name, func(t *testing.T) {
			e := credSetup(t)
			userID := e.seedUser(t, tc.email, "old-password-1")
			keys := e.mintKeys(t, userID, "attempt")
			if tc.unverified {
				e.markUnverified(t, userID)
			}
			before := e.liveness(t, keys)
			requireUnchanged := func(after string) {
				t.Helper()
				for i, live := range e.liveness(t, keys) {
					if live != before[i] {
						t.Fatalf("key %s went from authenticating=%v to %v after %s", keys[i], before[i], live, after)
					}
				}
			}

			code := e.requestResetCode(t, tc.email)
			requireUnchanged("a reset code was requested")

			wrong := "000000"
			if code == wrong {
				wrong = "111111"
			}
			if s := e.reset(t, tc.email, wrong, "brand-new-pass-1"); s == fiber.StatusOK {
				t.Fatalf("a reset with a wrong code was accepted")
			}
			requireUnchanged("a reset with a wrong code")

			if s := e.reset(t, tc.email, code, "short"); s == fiber.StatusOK {
				t.Fatalf("a reset with a too-short new password was accepted")
			}
			requireUnchanged("a reset whose new password was rejected")

			if s := e.reset(t, tc.email, code, "brand-new-pass-1"); s != fiber.StatusOK {
				t.Fatalf("reset with the mailed code: status %d, want 200", s)
			}
			if h := e.anyAlive(t, keys); h != "" {
				t.Fatalf("key %s still authenticates after the reset went through", h)
			}
			e.createKey(t, userID, "after reset")
		})
	}
}

// TestVerifyOwnerCanCreateKeysAfterSeizure: after a provider-verified sign-in takes
// an unverified account over, the owner's new session can create a working key.
func TestVerifyOwnerCanCreateKeysAfterSeizure(t *testing.T) {
	e := credSetup(t)
	const email = "chk-seized-owner@example.test"
	userID := e.seedUser(t, email, "squatter-pass-1")
	keys := e.mintKeys(t, userID, "seizedowner")
	e.markUnverified(t, userID)

	got, err := e.svc.ResolveOAuthAccount(context.Background(), "google", "google-chk-seized-owner", email, true)
	if err != nil {
		t.Fatalf("provider sign-in for the address: %v", err)
	}
	if got != userID {
		t.Fatalf("provider sign-in resolved to account %d, want the existing account %d", got, userID)
	}
	if h := e.anyAlive(t, keys); h != "" {
		t.Fatalf("key %s still authenticates after the account was taken over", h)
	}
	e.createKey(t, userID, "after seizure")
}
