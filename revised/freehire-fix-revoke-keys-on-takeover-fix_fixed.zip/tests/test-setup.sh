#!/usr/bin/env bash
# Sourced (not exec'd) by the harbor runner so the exported env vars stay alive
# for the `go test` process. Idempotent: the Dockerfile already baked the native
# Postgres 18 cluster, the Go module cache, and the build cache, so the steps
# below are fast guards rather than first-time setup.
#
# The integration tests talk to a real Postgres via the internal/testdb
# harness. That harness honors FREEHIRE_TEST_DSN (baked as an ENV in the image)
# and, when it is set, clones a per-test database from a migrated template on
# the already-running cluster instead of starting a testcontainer, since this
# image cannot launch containers. The template is built on first use from the
# checked-out migrations/ directory.
set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/freehire}"
PGDATA="${PGDATA:-/var/lib/postgresql/18/task}"
PGBIN="/usr/lib/postgresql/18/bin"
export PATH="${PGBIN}:${PATH}"

# FREEHIRE_TEST_DSN is baked into the image ENV; set it defensively in case the
# runner strips the image environment.
export FREEHIRE_TEST_DSN="${FREEHIRE_TEST_DSN:-postgres://hire:hire@localhost:5432/postgres?sslmode=disable}"

# The cluster's data dir is owned by the unprivileged user `dev` (uid 1000), and
# the server process refuses to run as root. This setup runs as whoever the
# runner is (root in the verifier phase), so start the cluster as `dev`, matching
# how the image baked and stopped it, instead of directly. When already running
# as `dev`, su is a harmless re-entry.
PG_LOG="/tmp/pg-test-setup.log"
pg_as_dev() {
    # Run a Postgres control command as the data-dir owner. The log file is created
    # by `dev` so a later tail can read it regardless of who we started as.
    su dev -c "$*"
}

# 1. Start the baked Postgres cluster (idempotent). The cluster was initdb'd at
#    build time and left stopped; pg_ctl start is a no-op if it is already up.
#    /var/run/postgresql is created in the image layer but some runtimes (e.g. Modal)
#    remount /var/run as tmpfs at container start, evicting that directory. Ensure
#    it exists before pg_ctl tries to create its socket lock file there.
install -d -o dev -g dev /var/run/postgresql
if ! pg_isready -h localhost -p 5432 -q 2>/dev/null; then
    pg_as_dev "${PGBIN}/pg_ctl -D ${PGDATA} -w -l ${PG_LOG} start" \
        || { echo "[test-setup] pg_ctl start failed:"; tail -40 "${PG_LOG}" 2>/dev/null || true; exit 1; }
fi

# Wait for the socket to accept connections (cold start can take a moment).
for _ in $(seq 1 30); do
    if pg_isready -h localhost -p 5432 -q 2>/dev/null; then
        break
    fi
    sleep 0.5
done
pg_isready -h localhost -p 5432 -q \
    || { echo "[test-setup] Postgres did not become ready"; tail -40 /tmp/pg-test-setup.log || true; exit 1; }

# 2. Ensure the admin database the DSN points at exists (initdb creates it, but
#    recreate defensively in case a fresh data dir is ever used).
psql -h localhost -U hire -d postgres -tAc 'select 1' >/dev/null 2>&1 \
    || createdb -h localhost -U hire postgres >/dev/null 2>&1 || true

# 3. Toolchain sanity.
cd "${REPO_DIR}"
go version

echo "[test-setup] ready: ${REPO_DIR} (go=$(go version | awk '{print $3}'), pg=$(pg_isready -h localhost -p 5432 2>/dev/null || echo down), dsn set)"
