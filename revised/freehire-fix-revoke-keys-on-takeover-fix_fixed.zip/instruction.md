## Task

Taking an account back doesn't fully lock the old holder out, and that's a security hole.

Here's the setup.
Someone can register a freehire account with a password against an email address they don't own, and just never verify it.
When the real owner of that address later signs in with a provider that has verified it (Google, GitHub and so on), freehire gives them the account: the squatter's password is wiped and their sessions are ended.
A password reset with the emailed code is the other way an owner gets an account back, and it also ends every session.

The problem is API keys.
If the old holder created a key before the takeover or the reset, that key keeps working afterwards.
It still gets through on every route that accepts either a key or a session, so they can keep reading the account's inbox and individual emails after losing the password and the sessions.

A second hole makes it worse: an account whose email was never verified can still create a key in the first place.

What we need:

- After a takeover like that, or once a reset with the emailed code goes through, none of that account's keys should work any more.
- That means every key the account had, whatever its scope or expiry date, not just one of them.
- Keys that belong to other accounts must keep working.
- An account with an unverified email should be refused when it tries to create a key, and end up with no key.
- Accounts with a verified email must still be able to create keys.
- "Sign out everywhere" and changing your own password while signed in (by typing the current one) are not takeovers, and API keys must keep working after both, because people's scripts and integrations rely on that.
