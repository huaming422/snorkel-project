## Task

We took a node out of a qdrant cluster on purpose with `DELETE /cluster/peer/{id}` and stopped it.
Later we tried to bring the same machine back as a new single-node cluster by starting it as a first peer with `--reinit`, on its old storage directory.

Usually it dies on startup:

```
ERROR qdrant::startup: Panic occurred ... Can't initialize consensus: Failed to apply configuration change entry
Caused by:
    Service internal error: Error in Raft consensus: removed all voters
```

Other times the process stays up, but `/readyz` never returns 200 while the old cluster is still running.
Any new node we start with `--bootstrap` pointing at it never goes ready either.

The node should come back as a one-node cluster that goes ready, takes changes like creating a collection, and lets new nodes join it and go ready.
Its `/readyz` should only wait on nodes that are part of its current cluster, so old-cluster nodes that are still running never hold it back, including after a plain restart without `--reinit`.
