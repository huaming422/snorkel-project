## Task

We removed a node from a qdrant cluster on purpose with `DELETE /cluster/peer/{id}` and stopped it.
Later we tried to bring the same machine back as a new single-node cluster with `--reinit`.

Usually it dies on startup:

```
ERROR qdrant::startup: Panic occurred ... Can't initialize consensus: Failed to apply configuration change entry
Caused by:
    Service internal error: Error in Raft consensus: removed all voters
```

Other times the process stays up, but `/readyz` never returns 200.

It should come up healthy as a standalone cluster that takes writes like creating a collection, and new nodes should be able to join it.
