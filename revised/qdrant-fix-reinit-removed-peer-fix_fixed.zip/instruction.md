## Task

We took a node out of a qdrant cluster on purpose with `DELETE /cluster/peer/{id}` and stopped it.
Later we tried to bring the same machine back as a new single-node cluster by starting it as a first peer with `--reinit`, on its old storage directory.

Usually it dies on startup:

```
ERROR qdrant::startup: Panic occurred ... Can't initialize consensus: Failed to apply configuration change entry
Caused by:
    Service internal error: Error in Raft consensus: removed all voters
```

Other times the process stays up, but `/readyz` never returns 200 while the old cluster is still running.
Any new node we start with `--bootstrap` pointing at it never goes ready either.

It should come up healthy as a standalone cluster that takes writes like creating a collection, and accept new nodes joining it.
