## Task

We took a node out of a qdrant cluster on purpose with `DELETE /cluster/peer/{id}` and stopped it.
Later we tried to bring the same machine back as a new single-node cluster by starting it as a first peer with `--reinit`, on its old storage directory.

Usually it dies on startup:

```
ERROR qdrant::startup: Panic occurred ... Can't initialize consensus: Failed to apply configuration change entry
Caused by:
    Service internal error: Error in Raft consensus: removed all voters
```

Other times the process stays up, but `/readyz` never returns 200.
Restarting that node later without `--reinit`, while the old cluster is still running, gets stuck on `/readyz` the same way.
If a brand-new node joins it with `--bootstrap`, the new node lists a peer from the old cluster in its `/cluster` output and never goes ready either.

A node brought back like this should start cleanly as the only member and leader of its new cluster.
It should go ready, accept normal changes such as creating a collection, and let new nodes join it with the right membership.
