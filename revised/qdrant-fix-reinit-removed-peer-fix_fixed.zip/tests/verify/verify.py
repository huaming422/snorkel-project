"""Behavioral checks for re-initializing a peer that was removed from its cluster.

Every scenario runs real qdrant nodes and drives them only through their public
surface:

  * the ``qdrant`` binary CLI (``--reinit``, ``--bootstrap``, ``--uri``),
  * the HTTP API (``GET /readyz``, ``GET /cluster``,
    ``DELETE /cluster/peer/{id}``, ``PUT /collections/{name}``),
  * the persisted ``storage/raft_state.json`` file, used only to put a stopped
    peer into a known on-disk state before it starts again.

The assertions read HTTP status codes, the collection list, and the cluster
size, peer ids and leader id from ``/cluster``. No log line is used as a
pass/fail gate.

The few helpers below follow the repo's ``tests/consensus_tests/utils.py``
(same ``QDRANT__...`` env vars, same ``/cluster`` and ``/readyz`` wrappers), but
use only ``requests`` and the standard library so the file runs in the verifier
venv without the repo's gRPC client packages.
"""

from __future__ import annotations

import json
import os
import pathlib
import shutil
import socket
import time
from contextlib import closing
from subprocess import Popen
from typing import Callable, Optional

import pytest
import requests

# The compiled binary and the stock config live in the task repo. The binary
# location honors CARGO_TARGET_DIR (the image builds into a shared, pre-warmed
# target dir); tests/test-setup.sh also bridges a repo-local ./target symlink,
# so both resolutions work.
REPO_DIR = pathlib.Path("/repo/qdrant")
CONFIG_DIR = REPO_DIR / "config"


def _qdrant_exec() -> str:
    target_dir = os.environ.get("CARGO_TARGET_DIR", str(REPO_DIR / "target"))
    candidates = [
        pathlib.Path(target_dir) / "debug" / "qdrant",
        REPO_DIR / "target" / "debug" / "qdrant",
    ]
    for cand in candidates:
        if cand.exists():
            return str(cand)
    # Fall back to the repo-local path; the ensuing spawn error names it clearly.
    return str(REPO_DIR / "target" / "debug" / "qdrant")


WAIT_TIME_SEC = 30
RETRY_INTERVAL_SEC = 0.2

# Starting a debug build, electing a leader and bootstrapping a new peer take
# longer than a steady-state query, so readiness and membership waits get more
# room than the repo's 30s default. A node that exits or never goes ready still
# fails the wait.
READY_TIMEOUT = 90
CLUSTER_TIMEOUT = 90

N_PEERS = 2


# --- process management -----------------------------------------------------

class PeerProcess:
    def __init__(self, proc: Popen, http_port: int, grpc_port: int, p2p_port: int):
        self.proc = proc
        self.http_port = http_port
        self.grpc_port = grpc_port
        self.p2p_port = p2p_port
        self.pid = proc.pid

    def kill(self) -> None:
        self.proc.kill()
        self.proc.wait()


# Tracks spawned peers so the autouse fixture can reap any that leak out of a
# test (e.g. after an assertion failure mid-scenario).
_processes: list[PeerProcess] = []


@pytest.fixture(autouse=True)
def _reap_processes():
    # Reap anything left over from a previous test before starting a new one.
    while _processes:
        p = _processes.pop()
        try:
            p.kill()
        except Exception:
            pass
    yield
    while _processes:
        p = _processes.pop()
        try:
            p.kill()
        except Exception:
            pass


def _free_port() -> int:
    with closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as s:
        s.bind(("", 0))
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        return s.getsockname()[1]


def _free_port_triple() -> int:
    """Return a base port P such that P, P+1, P+2 are all free right now."""
    for _ in range(200):
        base = _free_port()
        ok = True
        socks = []
        try:
            for off in (0, 1, 2):
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                try:
                    s.bind(("", base + off))
                    socks.append(s)
                except OSError:
                    ok = False
                    break
            if ok:
                return base
        finally:
            for s in socks:
                s.close()
    raise RuntimeError("could not allocate a free contiguous port triple")


def _uri(port: int) -> str:
    return f"http://127.0.0.1:{port}"


def _peer_env(p2p_port: int, grpc_port: int, http_port: int) -> dict:
    env = os.environ.copy()
    env["QDRANT__CLUSTER__ENABLED"] = "true"
    env["QDRANT__CLUSTER__P2P__PORT"] = str(p2p_port)
    env["QDRANT__SERVICE__HTTP_PORT"] = str(http_port)
    env["QDRANT__SERVICE__GRPC_PORT"] = str(grpc_port)
    env["QDRANT__LOG_LEVEL"] = "INFO,raft::raft=info"
    return env


def _make_peer_folder(base_path: pathlib.Path, peer_number: int) -> pathlib.Path:
    peer_dir = base_path / f"peer{peer_number}"
    peer_dir.mkdir()
    shutil.copytree(CONFIG_DIR, peer_dir / "config")
    return peer_dir


def _start_first_peer(peer_dir: pathlib.Path, log_file: str, reinit: bool = False):
    base_port = _free_port_triple()
    p2p_port, grpc_port, http_port = base_port, base_port + 1, base_port + 2
    bootstrap_uri = _uri(p2p_port)
    args = [_qdrant_exec(), "--uri", bootstrap_uri]
    if reinit:
        args.append("--reinit")
    log = open(peer_dir / log_file, "w")
    proc = Popen(args, env=_peer_env(p2p_port, grpc_port, http_port), cwd=peer_dir, stdout=log, stderr=log)
    _processes.append(PeerProcess(proc, http_port, grpc_port, p2p_port))
    return _uri(http_port), bootstrap_uri


def _start_peer(peer_dir: pathlib.Path, log_file: str, bootstrap_uri: str, reinit: bool = False) -> str:
    base_port = _free_port_triple()
    p2p_port, grpc_port, http_port = base_port, base_port + 1, base_port + 2
    this_uri = _uri(p2p_port)
    args = [_qdrant_exec(), "--bootstrap", bootstrap_uri, "--uri", this_uri]
    if reinit:
        args.append("--reinit")
    log = open(peer_dir / log_file, "w")
    proc = Popen(args, env=_peer_env(p2p_port, grpc_port, http_port), cwd=peer_dir, stdout=log, stderr=log)
    _processes.append(PeerProcess(proc, http_port, grpc_port, p2p_port))
    return _uri(http_port)


# --- HTTP wrappers (pre-existing public API) --------------------------------

def _get_cluster_info(uri: str) -> dict:
    r = requests.get(f"{uri}/cluster", timeout=10)
    assert r.status_code == 200, f"GET {uri}/cluster -> {r.status_code}: {r.text}"
    return r.json()["result"]


def _peer_is_online(uri: str) -> bool:
    try:
        return requests.get(f"{uri}/readyz", timeout=10).status_code == 200
    except requests.exceptions.RequestException:
        return False


def _leader_is_defined(uri: str) -> bool:
    try:
        return _get_cluster_info(uri)["raft_info"]["leader"] is not None
    except (requests.exceptions.RequestException, AssertionError, KeyError):
        return False


def _get_leader(uri: str) -> Optional[int]:
    return _get_cluster_info(uri)["raft_info"]["leader"]


def _check_leader(uri: str, expected_leader) -> bool:
    try:
        return _get_cluster_info(uri)["raft_info"]["leader"] == expected_leader
    except (requests.exceptions.RequestException, AssertionError, KeyError):
        return False


def _cluster_size(uri: str) -> int:
    return len(_get_cluster_info(uri)["peers"])


def _check_cluster_size(uri: str, expected_size: int) -> bool:
    try:
        return _cluster_size(uri) == expected_size
    except (requests.exceptions.RequestException, AssertionError, KeyError):
        return False


def _wait_for(condition: Callable[..., bool], *args, timeout: float = WAIT_TIME_SEC) -> None:
    start = time.time()
    while not condition(*args):
        if time.time() - start > timeout:
            raise AssertionError(
                f"timed out after {timeout}s waiting for {getattr(condition, '__name__', condition)}"
            )
        time.sleep(RETRY_INTERVAL_SEC)


def _wait_for_peer_online(uri: str, timeout: float = READY_TIMEOUT) -> None:
    _wait_for(_peer_is_online, uri, timeout=timeout)


def _start_cluster(tmp_path: pathlib.Path, num_peers: int):
    peer_dirs = [_make_peer_folder(tmp_path, i) for i in range(num_peers)]
    peer_api_uris = []
    bootstrap_api_uri, bootstrap_uri = _start_first_peer(peer_dirs[0], "peer_0.log")
    peer_api_uris.append(bootstrap_api_uri)
    _wait_for(_check_cluster_size, bootstrap_api_uri, 1, timeout=CLUSTER_TIMEOUT)
    _wait_for(_leader_is_defined, bootstrap_api_uri, timeout=CLUSTER_TIMEOUT)
    leader = _get_leader(bootstrap_api_uri)
    for i in range(1, num_peers):
        peer_api_uris.append(_start_peer(peer_dirs[i], f"peer_{i}.log", bootstrap_uri))
    # Wait for all peers to see the full, consistent cluster with one leader.
    for uri in peer_api_uris:
        _wait_for(_check_cluster_size, uri, num_peers, timeout=CLUSTER_TIMEOUT)
        _wait_for(_check_leader, uri, leader, timeout=CLUSTER_TIMEOUT)
    return peer_api_uris, peer_dirs, bootstrap_uri


# --- scenario helpers -------------------------------------------------------

def _remove_peer_and_stop(peer_api_uris, peer_dirs, idx):
    """Gracefully remove peer ``idx`` from consensus, then stop its process.

    In a 2-node cluster the removal only commits once the removed peer itself
    acknowledges it, so the removed peer has recorded its own removal before it
    is stopped. Returns the removed peer's id and data dir.
    """
    removed_peer_id = _get_cluster_info(peer_api_uris[idx])["peer_id"]
    removed_peer_dir = peer_dirs[idx]
    keep_uri = peer_api_uris[1 - idx]

    res = requests.delete(f"{keep_uri}/cluster/peer/{removed_peer_id}?timeout=60", timeout=70)
    assert res.status_code == 200, f"graceful peer removal failed: HTTP {res.status_code} {res.text}"

    # The surviving peer is now a single-node cluster, which also confirms the
    # removal committed (and was therefore persisted on the removed peer).
    _wait_for(_check_cluster_size, keep_uri, 1, timeout=CLUSTER_TIMEOUT)

    # Stop the removed peer (its own consensus already stopped on self-removal).
    for p in list(_processes):
        if p.http_port == int(peer_api_uris[idx].rsplit(":", 1)[1]):
            p.kill()
            _processes.remove(p)
            break
    return removed_peer_id, removed_peer_dir


def _inject_pre_apply_state(removed_peer_dir, first_peer_id, foreign_uri):
    """Put a stopped, removed peer into the "killed before it caught up" state.

    This is the on-disk state of a peer that was stopped right after its removal
    was agreed, before it processed any of it: its saved state still lists the
    old first peer's address and still names the old first peer as the
    cluster's first voter, it has processed nothing, and its saved commit index
    is 0.
    """
    raft_state_path = removed_peer_dir / "storage" / "raft_state.json"
    raft_state = json.loads(raft_state_path.read_text())
    raft_state["peer_address_by_id"][str(first_peer_id)] = foreign_uri
    raft_state["first_voter"] = first_peer_id
    raft_state["apply_progress_queue"] = None
    raft_state["state"]["hard_state"]["commit"] = 0
    raft_state_path.write_text(json.dumps(raft_state))


def _create_collection(uri: str, name: str) -> requests.Response:
    return requests.put(
        f"{uri}/collections/{name}?timeout=60",
        json={"vectors": {"size": 4, "distance": "Dot"}},
        timeout=70,
    )


# --- tests ------------------------------------------------------------------

@pytest.mark.parametrize(
    "killed_before_catching_up",
    [False, True],
    ids=["stopped_after_removal", "killed_before_catching_up"],
)
def test_reinit_removed_peer_recovers(tmp_path: pathlib.Path, killed_before_catching_up: bool):
    """A removed peer, re-initialized reusing its data dir, boots and runs its own cluster.

    Two on-disk states of the removed peer: stopped normally after the removal,
    and stopped before it caught up with the removal. In both, starting it with
    ``--reinit`` as a first peer must give a process that stays up, answers
    ``/readyz`` with 200, leads a cluster of one that does not list the old
    first peer, and commits a new collection.
    """
    peer_api_uris, peer_dirs, bootstrap_uri = _start_cluster(tmp_path, N_PEERS)

    first_peer_id = _get_cluster_info(peer_api_uris[0])["peer_id"]
    _removed_id, removed_peer_dir = _remove_peer_and_stop(peer_api_uris, peer_dirs, 1)

    if killed_before_catching_up:
        _inject_pre_apply_state(removed_peer_dir, first_peer_id, bootstrap_uri)

    reinit_api_uri, _reinit_bootstrap_uri = _start_first_peer(
        removed_peer_dir, "removed_peer_reinit.log", reinit=True,
    )

    _wait_for_peer_online(reinit_api_uri)
    _wait_for(_leader_is_defined, reinit_api_uri, timeout=CLUSTER_TIMEOUT)
    leader = _get_leader(reinit_api_uri)

    assert _check_cluster_size(reinit_api_uri, 1), (
        "re-initialized removed peer did not come up as a single-peer cluster; "
        f"cluster info: {_get_cluster_info(reinit_api_uri)}"
    )
    assert str(first_peer_id) not in _get_cluster_info(reinit_api_uri)["peers"], (
        "old cluster peer is listed in the re-initialized peer's cluster"
    )

    # The cluster of one has to take writes: creating a collection goes through
    # consensus and only returns 200 once the change is committed and applied.
    res = _create_collection(reinit_api_uri, "after_reinit")
    assert res.status_code == 200, (
        f"re-initialized peer could not commit a collection: HTTP {res.status_code} {res.text}; "
        f"cluster info: {_get_cluster_info(reinit_api_uri)}"
    )
    collections = requests.get(f"{reinit_api_uri}/collections", timeout=10).json()["result"]["collections"]
    assert "after_reinit" in [c["name"] for c in collections], (
        f"collection missing after a 200 create: {collections}"
    )

    info = _get_cluster_info(reinit_api_uri)
    assert info["raft_info"]["leader"] == leader, (
        f"leader changed on a single-peer cluster: was {leader}, now {info['raft_info']['leader']}"
    )
    assert _check_cluster_size(reinit_api_uri, 1), (
        f"single-peer cluster grew after a collection create: {info}"
    )


def test_reinit_removed_peer_seeds_fresh_peer(tmp_path: pathlib.Path):
    """A brand-new peer can join the cluster of a re-initialized removed peer.

    The removed peer is left in the "killed before it caught up" state, started
    with ``--reinit``, and then a new peer bootstraps from it. The new peer must
    answer ``/readyz`` with 200 and report the re-initialized peer's leader.
    """
    peer_api_uris, peer_dirs, bootstrap_uri = _start_cluster(tmp_path, N_PEERS)

    first_peer_id = _get_cluster_info(peer_api_uris[0])["peer_id"]
    _removed_id, removed_peer_dir = _remove_peer_and_stop(peer_api_uris, peer_dirs, 1)

    _inject_pre_apply_state(removed_peer_dir, first_peer_id, bootstrap_uri)

    reinit_api_uri, reinit_bootstrap_uri = _start_first_peer(
        removed_peer_dir, "removed_peer_reinit.log", reinit=True,
    )
    _wait_for_peer_online(reinit_api_uri)
    _wait_for(_leader_is_defined, reinit_api_uri, timeout=CLUSTER_TIMEOUT)
    leader = _get_leader(reinit_api_uri)

    assert _check_cluster_size(reinit_api_uri, 1), (
        "re-initialized peer kept the old cluster's peer in its membership; "
        f"cluster info: {_get_cluster_info(reinit_api_uri)}"
    )

    # Bootstrap a brand-new peer from the re-initialized one.
    new_peer_dir = _make_peer_folder(tmp_path, N_PEERS)
    new_peer_uri = _start_peer(new_peer_dir, "new_peer.log", reinit_bootstrap_uri)

    # The new peer has to go ready and follow the re-initialized peer's leader.
    _wait_for_peer_online(new_peer_uri)
    _wait_for(_check_leader, new_peer_uri, leader, timeout=CLUSTER_TIMEOUT)


def test_reinit_healthy_cluster_still_works(tmp_path: pathlib.Path):
    """Re-initializing a healthy two-node cluster still ends as a two-node cluster.

    Both peers are stopped, the first peer is started with ``--reinit``, and the
    other peer rejoins with ``--reinit --bootstrap``. Both peers must go ready,
    agree on one leader and report a cluster of two. Only this end state is
    checked; how many peers the first peer lists before the other one rejoins
    is not.
    """
    _peer_api_uris, peer_dirs, _bootstrap_uri = _start_cluster(tmp_path, N_PEERS)

    # Stop all peers, keep their data dirs.
    while _processes:
        _processes.pop().kill()

    # Re-initialize the first peer, then re-join the rest with --reinit.
    restarted_uris = []
    bootstrap_api_uri, new_bootstrap_uri = _start_first_peer(
        peer_dirs[0], "peer_0_restarted.log", reinit=True,
    )
    restarted_uris.append(bootstrap_api_uri)
    _wait_for_peer_online(bootstrap_api_uri)
    _wait_for(_leader_is_defined, bootstrap_api_uri, timeout=CLUSTER_TIMEOUT)

    for i in range(1, len(peer_dirs)):
        restarted_uris.append(
            _start_peer(peer_dirs[i], f"peer_{i}_restarted.log", new_bootstrap_uri, reinit=True)
        )

    # Every peer is online, all agree on one leader, and the cluster has two peers.
    for uri in restarted_uris:
        _wait_for_peer_online(uri)
    leader = _get_leader(bootstrap_api_uri)
    for uri in restarted_uris:
        _wait_for(_check_cluster_size, uri, N_PEERS, timeout=CLUSTER_TIMEOUT)
        _wait_for(_check_leader, uri, leader, timeout=CLUSTER_TIMEOUT)
