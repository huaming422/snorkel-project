#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier (set -euo pipefail inherited).
# The behavioral verifier is a pytest consensus integration test that spawns the
# compiled qdrant binary and drives multi-node clusters over HTTP. We must have a
# freshly built qdrant binary that includes the user changes, built fully
# offline from the warm cargo cache baked into the image.
cd /repo/qdrant

# Offline switch: a cache miss must fail fast here instead of reaching a registry.
export CARGO_NET_OFFLINE=true

echo "[test-setup] rustc:  $(rustc --version 2>&1 | head -1)"
echo "[test-setup] cargo:  $(cargo --version 2>&1 | head -1)"

# Build the qdrant binary that the consensus integration tests execute. The image
# pre-built the workspace, so this is an incremental recompile of the user
# changes only.
if cargo build --locked --offline --bin qdrant > /tmp/qdrant-build.log 2>&1; then
    echo "[offline-first] qdrant binary built from warm cargo cache"
else
    echo "[test-setup] offline build failed; see log tail:" >&2
    tail -80 /tmp/qdrant-build.log >&2
    exit 1
fi

# The image sets CARGO_TARGET_DIR=/opt/cache/cargo-target (shared, pre-warmed),
# so cargo emits the binary under "$CARGO_TARGET_DIR/debug/qdrant", NOT under the
# repo-local ./target that the consensus-test helpers expect. utils.py's
# get_qdrant_exec() resolves the binary as "<repo>/target/debug/qdrant" (relative
# to its own file), so bridge the two by pointing ./target at the real target dir
# used for the build. This keeps the warm incremental cache (no copy, no rebuild)
# while making the binary visible where the harness looks for it.
TARGET_DIR="${CARGO_TARGET_DIR:-/repo/qdrant/target}"
BUILT_BIN="${TARGET_DIR%/}/debug/qdrant"

test -x "${BUILT_BIN}" \
    || { echo "[test-setup] built qdrant binary missing at ${BUILT_BIN}" >&2; exit 1; }

if [ "${TARGET_DIR%/}" != "/repo/qdrant/target" ] && [ ! -e /repo/qdrant/target ]; then
    ln -s "${TARGET_DIR%/}" /repo/qdrant/target
fi

test -x /repo/qdrant/target/debug/qdrant \
    || { echo "[test-setup] target/debug/qdrant not resolvable after bridge" >&2; exit 1; }

echo "[test-setup] qdrant binary available at /repo/qdrant/target/debug/qdrant"
echo "[test-setup] Setup complete."
