# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
"""
Behavioral checks for the dataset table-binding authorization contract.

These tests drive the behavior through pre-existing public interfaces: the
dataset create/update/duplicate commands, the v1 import entry point, the
legacy datasource save view, the table metadata endpoint, the query-backed
chart-data processor, and the central access method's long-standing
signature. Each test runs the real authorization code and asserts only the
observable allow/deny outcome or the stored state. No test passes, imports or
asserts a name a fix is free to choose (an opt-out keyword, a param-comparison
helper, a render or param validation error class, a per-call-site helper).

The contract they check: editing rights on a dataset do not count as access
to a table when a dataset is defined over it or repointed at it; holders of
datasource, schema, catalog or database access keep working; unreadable
template params are rejected; and a dataset's owner keeps exploring it.

Fixtures are self-contained: when this file is collected from the ``verify/``
directory the repository's own unit-test ``conftest`` is not in scope, so the
app/app-context fixtures and an in-memory session are defined locally. The app
builder and the feature-flag helper are imported from the repository's
unit-test support module (they build the same app the rest of the unit tier
uses).

The data-access primitives the check consults (whether the caller holds a
direct grant, a broader schema/catalog grant, access to the whole connection,
is an editor of a registered dataset, and which datasets are registered for a
table) are the only things stubbed, so each scenario is a precise "who holds
what" world. Everything downstream (SQL parsing, Jinja rendering, catalog and
schema permission derivation, the engine spec) runs for real.
"""

from __future__ import annotations

import inspect
import uuid
from contextlib import contextmanager, ExitStack
from types import SimpleNamespace
from typing import Any, Iterator
from unittest.mock import patch

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from tests.unit_tests.conftest import build_app, with_feature_flags

# The application must be constructed before the command modules below are
# imported: their table-mapped models (e.g. the connection model's encrypted
# columns) resolve an application-bound field factory at class-definition time,
# which raises unless an app already exists. The repository's own test tiers get
# this for free because a session-scoped conftest builds the app before any test
# module is collected; collected from this directory that conftest is not in
# scope, so the app is built here, once, at import.
_APP = build_app()

from superset import db, security_manager  # noqa: E402
from superset.commands.dataset.create import CreateDatasetCommand  # noqa: E402
from superset.commands.dataset.duplicate import (  # noqa: E402
    DuplicateDatasetCommand,
)
from superset.commands.dataset.exceptions import (  # noqa: E402
    DatasetAccessDeniedError,
    DatasetDataAccessIsNotAllowed,
    DatasetForbiddenError,
    DatasetInvalidError,
)
from superset.commands.dataset.importers.v1.utils import (  # noqa: E402
    import_dataset,
)
from superset.commands.dataset.update import UpdateDatasetCommand  # noqa: E402
from superset.common.query_context_processor import (  # noqa: E402
    QueryContextProcessor,
)
from superset.connectors.sqla.models import SqlaTable  # noqa: E402
from superset.databases.api import DatabaseRestApi  # noqa: E402
from superset.exceptions import SupersetSecurityException  # noqa: E402
from superset.models.core import Database  # noqa: E402
from superset.utils import json as superset_json  # noqa: E402
from superset.utils.core import DatasourceType  # noqa: E402
# Imported at module top (under the app built above) rather than lazily inside
# the legacy-save test: the view module pulls in engine specs whose class bodies
# call flask-babel's ``_`` at import, which needs the babel extension the built
# app installs -- importing it later under a bare request context would raise.
from superset.views.datasource.views import Datasource as _DatasourceView  # noqa: E402


# --------------------------------------------------------------------------- #
# App / context fixtures (self-contained; conftest is out of scope here).
# --------------------------------------------------------------------------- #
@pytest.fixture(scope="module")
def app() -> Any:
    return _APP


@pytest.fixture(autouse=True)
def app_context(app: Any) -> Iterator[None]:
    with app.app_context():
        yield


# --------------------------------------------------------------------------- #
# Grant "kinds" the access check asks about. These are the long-standing
# permission view-menu names the authorization layer has always used.
# --------------------------------------------------------------------------- #
GRANT_DATASOURCE = "datasource_access"
GRANT_SCHEMA = "schema_access"
GRANT_CATALOG = "catalog_access"

# Connection label used for the real engine-backed database. Deliberately not
# any database name referenced in test SQL -- the behavior must not depend on
# it (the connection label is a renameable display name).
CONN_NAME = "probe_conn"

# A registered dataset for the referenced table whose perm the caller does NOT
# hold: the dataset the caller can edit without being able to read its table.
DECOY_PERM = f"[{CONN_NAME}].[public].[orders](id:1)"


# --------------------------------------------------------------------------- #
# Databases. Two real engine-backed connections so URL parsing, engine-spec
# resolution and SQL parsing all run for real:
#   * a SQLite connection (no server catalogs) for the schema fallthrough and
#     the SQL/template paths;
#   * an MSSQL connection (real T-SQL dialect) for the catalog fallthrough,
#     which SQLite cannot model -- mirroring the connection kind the repo's own
#     offline unit tests use to exercise catalogs without a live server.
# The only live-connection call (resolving a query's default schema) is stubbed
# so no server is required.
# --------------------------------------------------------------------------- #
def _sqlite_database() -> Database:
    database = Database(database_name=CONN_NAME, sqlalchemy_uri="sqlite://")
    patch.object(
        database, "get_default_schema_for_query", return_value=None
    ).start()
    return database


def _mssql_database() -> Database:
    database = Database(
        database_name=CONN_NAME,
        sqlalchemy_uri="mssql+pymssql://user:pw@host:1433/abcm",
    )
    patch.object(
        database, "get_default_schema_for_query", return_value=None
    ).start()
    return database


@pytest.fixture(autouse=True)
def _stop_patches() -> Iterator[None]:
    """Ensure every ad-hoc ``patch.object(...).start()`` is torn down."""
    yield
    patch.stopall()


@contextmanager
def access_world(
    *,
    grants: set[str] | None = None,
    grant_view_menus: set[str] | None = None,
    is_editor: bool = False,
    registered_perm: str | None = None,
    database_access: bool = False,
    real_lookup: bool = False,
) -> Iterator[None]:
    """Install a 'who holds what' world around the real access check.

    :param grants: permission kinds the caller holds for ANY view-menu
        (e.g. ``{schema_access}``); use this for the simple "holds the kind"
        scenarios.
    :param grant_view_menus: when set, the caller holds a grant only for these
        exact view-menu names -- used to pin a grant to a specific
        catalog/schema/dataset perm string.
    :param is_editor: whether the caller is an editor/owner of the registered
        dataset the lookup returns.
    :param registered_perm: perm string of a dataset registered for the
        referenced table (``None`` -> no dataset registered for it).
    :param database_access: whether the caller has access to the whole
        connection (the broadest grant, which short-circuits everything).
    :param real_lookup: when True, the lookup of datasets registered for a
        table is left unstubbed, so it reads the rows stored in the session.
    """
    grants = grants or set()
    grant_view_menus = grant_view_menus or set()

    def can_access(permission: str, view_menu: str) -> bool:
        if permission in grants:
            return True
        return bool(grant_view_menus) and view_menu in grant_view_menus

    registered = (
        [SimpleNamespace(perm=registered_perm, sql=None, catalog=None)]
        if registered_perm
        else []
    )

    with ExitStack() as stack:
        stack.enter_context(
            patch.object(security_manager, "can_access", side_effect=can_access)
        )
        stack.enter_context(
            patch.object(
                security_manager, "can_access_database", return_value=database_access
            )
        )
        stack.enter_context(
            patch.object(security_manager, "can_access_schema", return_value=False)
        )
        stack.enter_context(
            patch.object(
                security_manager, "_semantic_layer_grant_allows", return_value=False
            )
        )
        stack.enter_context(
            patch.object(security_manager, "is_editor", return_value=is_editor)
        )
        stack.enter_context(
            patch.object(security_manager, "is_admin", return_value=False)
        )
        stack.enter_context(
            patch.object(security_manager, "is_guest_user", return_value=False)
        )
        if not real_lookup:
            stack.enter_context(
                patch.object(
                    SqlaTable, "query_datasources_by_name", return_value=registered
                )
            )
        yield


def _access_denied(exc: DatasetInvalidError) -> bool:
    """Whether a command's validation failure was a data-access denial."""
    return any(
        isinstance(e, DatasetDataAccessIsNotAllowed) for e in exc._exceptions
    )


# --------------------------------------------------------------------------- #
# Create-command driver. Patches only the DAO lookups that would otherwise hit
# a metadata DB; the access decision underneath is the real one.
# --------------------------------------------------------------------------- #
def _run_create(database: Database, properties: dict[str, Any]) -> None:
    with (
        patch(
            "superset.commands.dataset.create.DatasetDAO.get_database_by_id",
            return_value=database,
        ),
        patch(
            "superset.commands.dataset.create.DatasetDAO.validate_uniqueness",
            return_value=True,
        ),
        patch(
            "superset.commands.dataset.create.DatasetDAO.validate_table_exists",
            return_value=True,
        ),
        patch(
            "superset.commands.dataset.create.populate_subjects",
            return_value=None,
        ),
    ):
        CreateDatasetCommand(properties).validate()


# =========================================================================== #
# Explore-your-own-dataset is preserved on the datasource= branch, the path
# chart-data takes for a saved dataset (query_context= routes to datasource=).
# A dataset editor with no other grant passes there.
# =========================================================================== #
def test_editor_passes_on_default_path() -> None:
    # The branch is called directly, the way chart-data on a saved TABLE
    # dataset reaches it, so the check does not depend on the processor's
    # internals.
    datasource = SimpleNamespace(
        perm=DECOY_PERM,
        sql=None,
        catalog=None,
        type=DatasourceType.TABLE,  # required by raise_for_unsupported_guest_rls
    )
    with access_world(is_editor=True, registered_perm=DECOY_PERM):
        # Must not raise: editorship authorizes exploring your own dataset
        # via the datasource= branch.
        security_manager.raise_for_access(datasource=datasource)


# =========================================================================== #
# Explore-your-own-dataset also covers the table metadata endpoint for the
# table the caller's own dataset reads: an owner with no other grant still gets
# the metadata back, not the "No such table" 404 the endpoint answers with on a
# denial.
#
# Driven through the endpoint body the way the legacy-save test below drives
# its view: the Flask-AppBuilder decorators are peeled off with
# ``inspect.unwrap`` and the body runs inside a GET request context carrying the
# query string. Only the DAO lookup and the engine-spec metadata read (which
# would open a live connection) are stubbed; the access decision is the real
# one.
# =========================================================================== #
def test_owner_reads_own_dataset_table_metadata() -> None:
    database = _sqlite_database()
    view = SimpleNamespace(
        table_metadata=DatabaseRestApi.table_metadata,
        incr_stats=lambda *args, **kwargs: None,
        response=lambda status, **payload: (status, payload),
    )
    with (
        patch(
            "superset.databases.api.DatabaseDAO.find_by_id",
            return_value=database,
        ),
        patch.object(
            database.db_engine_spec,
            "get_table_metadata",
            return_value={"name": "orders"},
        ),
        access_world(is_editor=True, registered_perm=DECOY_PERM),
        _APP.test_request_context(
            "/api/v1/database/1/table_metadata/?name=orders&schema=public",
            method="GET",
        ),
    ):
        result = inspect.unwrap(DatabaseRestApi.table_metadata)(view, 1)

    assert result == (200, {"name": "orders"})


# =========================================================================== #
# Query-backed chart-data runs a stored query's raw SQL, so editorship of a
# same-named dataset does not authorize its tables there.
# =========================================================================== #
def test_editor_denied_on_query_backed_chart_data() -> None:
    database = _sqlite_database()
    stored_query = SimpleNamespace(
        type=DatasourceType.QUERY,
        database=database,
        schema="public",
        catalog=None,
        sql="SELECT * FROM orders",
    )
    query_context = SimpleNamespace(datasource=stored_query, queries=[])
    processor = QueryContextProcessor(query_context)

    with access_world(is_editor=True, registered_perm=DECOY_PERM):
        with pytest.raises(SupersetSecurityException):
            processor.raise_for_access()


# =========================================================================== #
# Schema, catalog and database holders can still define a dataset over the
# table. Driven through the real create command so the command's own call into
# the access check is what is exercised.
# =========================================================================== #
def test_schema_holder_can_create_physical_dataset() -> None:
    database = _sqlite_database()
    with access_world(grants={GRANT_SCHEMA}):
        # No editorship, no registered dataset -- only the broader grant holds.
        _run_create(
            database, {"database": 1, "table_name": "orders", "schema": "public"}
        )  # must not raise


def test_catalog_holder_can_create_physical_dataset() -> None:
    # SQLite cannot model catalogs; use a real MSSQL connection whose engine
    # spec reports catalog support, exactly as the repo's own offline tests do.
    database = _mssql_database()
    patch.object(database.db_engine_spec, "supports_catalog", True).start()
    catalog_perm = f"[{CONN_NAME}].[other]"
    with access_world(grants=set(), grant_view_menus={catalog_perm}):
        _run_create(
            database,
            {
                "database": 1,
                "table_name": "foo",
                "schema": "dbo",
                "catalog": "other",
            },
        )  # must not raise


def test_database_holder_can_create_physical_dataset() -> None:
    database = _sqlite_database()
    with access_world(database_access=True):
        _run_create(
            database, {"database": 1, "table_name": "orders", "schema": "public"}
        )  # must not raise


# =========================================================================== #
# Creating a dataset over a table the caller cannot access is refused even when
# the caller is the editor of a same-named dataset.
# =========================================================================== #
def test_create_refused_for_editor_without_data_access() -> None:
    database = _sqlite_database()
    with access_world(is_editor=True, registered_perm=DECOY_PERM):
        with pytest.raises(DatasetInvalidError) as excinfo:
            _run_create(
                database,
                {"database": 1, "table_name": "orders", "schema": "public"},
            )
    assert _access_denied(excinfo.value)


def test_create_allowed_with_real_data_access() -> None:
    database = _sqlite_database()
    # The caller holds a datasource grant on the registered dataset.
    with access_world(
        grants={GRANT_DATASOURCE}, registered_perm=DECOY_PERM
    ):
        _run_create(
            database, {"database": 1, "table_name": "orders", "schema": "public"}
        )  # must not raise


# =========================================================================== #
# A virtual dataset whose SQL is ``SELECT * FROM {{ p }}`` is authorized
# against the table the submitted params resolve to, not a default.
# =========================================================================== #
@with_feature_flags(ENABLE_TEMPLATE_PROCESSING=True)
def test_templated_create_refused_when_resolved_table_inaccessible() -> None:
    database = _sqlite_database()
    # No grant anywhere, editor of a same-named dataset: the resolved table is
    # private.
    with access_world(is_editor=True, registered_perm=DECOY_PERM):
        with pytest.raises(DatasetInvalidError) as excinfo:
            _run_create(
                database,
                {
                    "database": 1,
                    "table_name": "report",
                    "schema": "public",
                    "sql": "SELECT * FROM {{ p }}",
                    "template_params": '{"p": "private.secret"}',
                },
            )
    assert _access_denied(excinfo.value)


@with_feature_flags(ENABLE_TEMPLATE_PROCESSING=True)
def test_templated_create_allowed_when_resolved_schema_accessible() -> None:
    database = _sqlite_database()
    # Hold schema access to the schema the params resolve the FROM to.
    schema_perm = f"[{CONN_NAME}].[private]"
    with access_world(grants=set(), grant_view_menus={schema_perm}):
        _run_create(
            database,
            {
                "database": 1,
                "table_name": "report",
                "schema": "public",
                "sql": "SELECT * FROM {{ p }}",
                "template_params": '{"p": "private.secret"}',
            },
        )  # must not raise


# =========================================================================== #
# Repointing an existing dataset to an inaccessible table is refused for a user
# who only edits it, whether the repoint changes the table name or schema of a
# physical dataset, the SQL of a virtual one, the schema its unqualified SQL
# resolves against, or only its template params. A repoint the caller has
# schema access for, and a save that does not change the binding, succeed.
# =========================================================================== #
def _existing_model(database: Database, **overrides: Any) -> SqlaTable:
    model = SqlaTable(
        table_name="orders",
        schema="public",
        catalog=None,
        database=database,
        sql=None,
        template_params=None,
    )
    for key, value in overrides.items():
        setattr(model, key, value)
    return model


@contextmanager
def _update_world(model: SqlaTable) -> Iterator[None]:
    with (
        patch(
            "superset.commands.dataset.update.DatasetDAO.find_by_id",
            return_value=model,
        ),
        patch.object(security_manager, "raise_for_editorship", return_value=None),
        patch(
            "superset.commands.dataset.update.raise_if_managed_externally",
            return_value=None,
        ),
        patch(
            "superset.commands.dataset.update.compute_subjects",
            return_value=None,
        ),
        patch(
            "superset.commands.dataset.update.DatasetDAO.validate_update_uniqueness",
            return_value=True,
        ),
    ):
        yield


def _run_update(model_id: int, properties: dict[str, Any]) -> None:
    UpdateDatasetCommand(model_id, properties).validate()


@pytest.mark.parametrize(
    "repoint",
    [{"schema": "private"}, {"table_name": "secret"}],
    ids=["schema", "table_name"],
)
def test_update_repoint_physical_refused_for_editor_without_access(
    repoint: dict[str, Any],
) -> None:
    database = _sqlite_database()
    model = _existing_model(database)
    with (
        _update_world(model),
        access_world(is_editor=True, registered_perm=DECOY_PERM),
    ):
        with pytest.raises(DatasetInvalidError) as excinfo:
            _run_update(1, repoint)
    assert _access_denied(excinfo.value)


def test_update_repoint_allowed_for_target_schema_holder() -> None:
    database = _sqlite_database()
    model = _existing_model(database)
    with (
        _update_world(model),
        access_world(
            grant_view_menus={f"[{CONN_NAME}].[private]"},
            is_editor=True,
            registered_perm=DECOY_PERM,
        ),
    ):
        _run_update(1, {"schema": "private"})  # must not raise


def test_update_sql_repoint_refused_for_editor_without_access() -> None:
    database = _sqlite_database()
    model = _existing_model(
        database,
        table_name="report",
        sql="SELECT * FROM public.ok",
    )
    with (
        _update_world(model),
        access_world(is_editor=True, registered_perm=DECOY_PERM),
    ):
        with pytest.raises(DatasetInvalidError) as excinfo:
            _run_update(1, {"sql": "SELECT * FROM private.secret"})
    assert _access_denied(excinfo.value)


def test_update_virtual_schema_repoint_refused_for_editor_without_access() -> None:
    database = _sqlite_database()
    # Unqualified names resolve against the query's schema, as the engine does
    # when the connection has no fixed default.
    patch.object(
        database,
        "get_default_schema_for_query",
        side_effect=lambda query, template_params=None: query.schema,
    ).start()
    model = _existing_model(
        database,
        table_name="report",
        sql="SELECT * FROM orders",
    )
    # The caller can read the current schema but not the one the save moves
    # the dataset's SQL to.
    with (
        _update_world(model),
        access_world(
            grant_view_menus={f"[{CONN_NAME}].[public]"},
            is_editor=True,
            registered_perm=DECOY_PERM,
        ),
    ):
        with pytest.raises(DatasetInvalidError) as excinfo:
            _run_update(1, {"schema": "private"})
    assert _access_denied(excinfo.value)


def test_update_metadata_only_save_succeeds_for_editor() -> None:
    database = _sqlite_database()
    model = _existing_model(database, description="old")
    with (
        _update_world(model),
        access_world(is_editor=True, registered_perm=DECOY_PERM),
    ):
        # No binding change -> no data-access re-check -> editor can still save.
        _run_update(1, {"description": "new"})  # must not raise


# --------------------------------------------------------------------------- #
# A params-only change that execution would read differently (a templated FROM
# resolving to another table) re-authorizes the binding; a params echo that
# renders identically does not.
# --------------------------------------------------------------------------- #
@with_feature_flags(ENABLE_TEMPLATE_PROCESSING=True)
def test_update_params_only_repoint_refused_for_editor() -> None:
    database = _sqlite_database()
    model = _existing_model(
        database,
        table_name="report",
        sql="SELECT * FROM {{ t }}",
        template_params='{"t": "public.ok"}',
    )
    with (
        _update_world(model),
        access_world(is_editor=True, registered_perm=DECOY_PERM),
    ):
        with pytest.raises(DatasetInvalidError) as excinfo:
            # Same SQL text, new params repoint the FROM to a private table.
            _run_update(1, {"template_params": '{"t": "private.secret"}'})
    assert _access_denied(excinfo.value)


@with_feature_flags(ENABLE_TEMPLATE_PROCESSING=True)
def test_update_params_echo_does_not_block_editor() -> None:
    database = _sqlite_database()
    model = _existing_model(
        database,
        table_name="report",
        sql="SELECT * FROM {{ t }}",
        template_params='{"t": "public.ok"}',
    )
    with (
        _update_world(model),
        access_world(is_editor=True, registered_perm=DECOY_PERM),
    ):
        # Re-sending the same params (reformatted) is not a repoint.
        _run_update(1, {"template_params": '{"t":   "public.ok"}'})  # must not raise


# =========================================================================== #
# A template_params value that is not a JSON object (here a JSON array) is
# rejected as invalid input on update and on create. The rejection may surface
# as the command's validation-error aggregate or as an authorization error;
# the request must not go through.
# =========================================================================== #
@with_feature_flags(ENABLE_TEMPLATE_PROCESSING=True)
def test_nonobject_template_params_rejected_fail_closed() -> None:
    database = _sqlite_database()
    model = _existing_model(
        database,
        table_name="report",
        sql="SELECT * FROM {{ t }}",
        template_params='{"t": "public.ok"}',
    )
    with (
        _update_world(model),
        access_world(is_editor=True, registered_perm=DECOY_PERM),
    ):
        # A JSON array is not a valid params object: it is rejected, never
        # authorized against a guessed or default render.
        with pytest.raises((DatasetInvalidError, SupersetSecurityException)):
            _run_update(1, {"template_params": "[1, 2, 3]"})


@with_feature_flags(ENABLE_TEMPLATE_PROCESSING=True)
def test_nonobject_template_params_rejected_on_create() -> None:
    database = _sqlite_database()
    # The caller can read the table the SQL names, so the params are the only
    # thing wrong with the request.
    with access_world(grant_view_menus={f"[{CONN_NAME}].[public]"}):
        with pytest.raises((DatasetInvalidError, SupersetSecurityException)):
            _run_create(
                database,
                {
                    "database": 1,
                    "table_name": "report",
                    "schema": "public",
                    "sql": "SELECT * FROM public.orders",
                    "template_params": "[1, 2, 3]",
                },
            )


# =========================================================================== #
# Duplicate command. Copying a virtual dataset runs the base's stored SQL as
# the caller's own new dataset, so it requires data access to the tables that
# SQL reads, not editorship of the base (which the object-level check on the
# base accepts). An editor of the base with no data access is refused; one who
# holds schema access to those tables can copy it.
# =========================================================================== #
@contextmanager
def _duplicate_world(base_model: SqlaTable) -> Iterator[None]:
    with (
        patch(
            "superset.commands.dataset.duplicate.DatasetDAO.find_by_id",
            return_value=base_model,
        ),
        patch(
            "superset.commands.dataset.duplicate.DatasetDAO.validate_uniqueness",
            return_value=True,
        ),
        patch(
            "superset.commands.utils.populate_subject_list",
            return_value=[],
        ),
    ):
        yield


def test_duplicate_refused_for_editor_without_sql_access() -> None:
    database = _sqlite_database()
    base_model = _existing_model(
        database,
        table_name="base_virtual",
        sql="SELECT * FROM orders",
        template_params=None,
    )
    with (
        _duplicate_world(base_model),
        access_world(is_editor=True, registered_perm=DECOY_PERM),
    ):
        # A denial here may surface as the forbidden-error this command already
        # raises for base-object access, as the validation-error aggregate the
        # sibling define paths use, or as the raw authorization error -- assert
        # that the copy is refused, not one chosen wrapper class.
        with pytest.raises(
            (
                DatasetAccessDeniedError,
                DatasetInvalidError,
                SupersetSecurityException,
            )
        ):
            DuplicateDatasetCommand(
                {"base_model_id": 1, "table_name": "copy"}
            ).validate()


def test_duplicate_allowed_for_schema_holder() -> None:
    database = _sqlite_database()
    base_model = _existing_model(
        database,
        table_name="base_virtual",
        sql="SELECT * FROM public.orders",
        template_params=None,
    )
    with (
        _duplicate_world(base_model),
        access_world(
            grant_view_menus={f"[{CONN_NAME}].[public]"},
            is_editor=True,
            registered_perm=DECOY_PERM,
        ),
    ):
        DuplicateDatasetCommand(
            {"base_model_id": 1, "table_name": "copy"}
        ).validate()  # must not raise


# =========================================================================== #
# Overwrite import. Repointing a stored dataset to a table the caller cannot
# access is refused and leaves the stored row as it was once the transaction
# is rolled back, as the import command does on any error. Holding
# ``datasource_access`` on the dataset being overwritten is not access to the
# table it would point at. A caller with schema access to the target schema
# can import the repoint. Runs against a real in-memory session so
# ``import_from_dict`` and the stored state run for real.
# =========================================================================== #
@contextmanager
def _in_memory_session() -> Iterator[Any]:
    """A real in-memory SQLite session wired where the import code reads it.

    Mirrors the repository's own unit-test session fixture: patch the shared
    ``db.session`` so the import code (and its lookups) see one in-memory
    connection.
    """
    engine = create_engine("sqlite://")
    session = sessionmaker(bind=engine)()
    session.remove = lambda: None  # flask calls db.session.remove()
    with patch("superset.db.session", session):
        SqlaTable.metadata.create_all(engine)
        yield session


def _import_config(database_id: int, **overrides: Any) -> dict[str, Any]:
    config: dict[str, Any] = {
        "uuid": str(uuid.uuid4()),
        "table_name": "orders",
        "schema": "public",
        "catalog": None,
        "sql": "",
        "database_id": database_id,
        "metrics": [],
        "columns": [],
    }
    config.update(overrides)
    return config


def _seed_stored_dataset(session: Any) -> tuple[int, int, str, str]:
    """Commit one physical dataset on ``public.orders``.

    Returns the database id, the dataset id, its uuid and its permission name.
    """
    database = Database(database_name=CONN_NAME, sqlalchemy_uri="sqlite://")
    session.add(database)
    session.flush()
    ds_uuid = str(uuid.uuid4())
    existing = SqlaTable(
        table_name="orders",
        schema="public",
        catalog=None,
        database=database,
        uuid=ds_uuid,
    )
    session.add(existing)
    session.flush()
    dataset_perm = existing.perm or security_manager.get_dataset_perm(
        existing.id, "orders", CONN_NAME
    )
    ids = (database.id, existing.id, ds_uuid, dataset_perm)
    session.commit()
    return ids


@contextmanager
def _import_hooks() -> Iterator[None]:
    # The permission bookkeeping run on every dataset UPDATE looks up existing
    # permission rows through the security manager's own session, which this
    # in-memory session does not share, so it would re-insert rows that already
    # exist. It maintains permission rows only and takes no part in the access
    # decision, so it is stubbed to let an update flush.
    with patch.object(security_manager, "dataset_before_update", return_value=None):
        yield


def _stored_schema(session: Any, dataset_id: int) -> str | None:
    session.rollback()
    return session.get(SqlaTable, dataset_id).schema


def test_import_overwrite_repoint_refused_without_data_access() -> None:
    with _in_memory_session() as session, _import_hooks():
        database_id, dataset_id, ds_uuid, _ = _seed_stored_dataset(session)

        config = _import_config(
            database_id, uuid=ds_uuid, schema="private"  # repoint to a new schema
        )
        # can_write granted (reach the binding check) and editor (pass the
        # overwrite permission gate) -- the only thing that can refuse is the
        # table-binding authorization against the requested (private) schema.
        with access_world(
            grant_view_menus={"Dataset"},  # the can_write("Dataset") gate
            is_editor=True,
            registered_perm=DECOY_PERM,
            database_access=False,
        ):
            # The denial may surface either as the data-access failure this
            # command family raises or as the underlying authorization error it
            # wraps -- assert the refusal, not one chosen wrapper class.
            with pytest.raises((DatasetAccessDeniedError, SupersetSecurityException)):
                import_dataset(config, overwrite=True)

        assert _stored_schema(session, dataset_id) == "public"


def test_import_overwrite_repoint_refused_for_holder_of_overwritten_dataset() -> None:
    with _in_memory_session() as session, _import_hooks():
        database_id, dataset_id, ds_uuid, dataset_perm = _seed_stored_dataset(
            session
        )

        config = _import_config(database_id, uuid=ds_uuid, schema="private")
        # The caller holds datasource_access on the stored dataset itself, and
        # the lookup of datasets registered for a table reads the real rows.
        # No dataset is registered for private.orders, so nothing grants
        # access to the table the import would point the dataset at.
        with access_world(
            grant_view_menus={"Dataset", dataset_perm},
            is_editor=True,
            real_lookup=True,
        ):
            with pytest.raises((DatasetAccessDeniedError, SupersetSecurityException)):
                import_dataset(config, overwrite=True)

        assert _stored_schema(session, dataset_id) == "public"


def test_import_overwrite_repoint_allowed_for_target_schema_holder() -> None:
    with _in_memory_session() as session, _import_hooks():
        database_id, dataset_id, ds_uuid, _ = _seed_stored_dataset(session)

        config = _import_config(database_id, uuid=ds_uuid, schema="private")
        with access_world(
            grant_view_menus={"Dataset", f"[{CONN_NAME}].[private]"},
            is_editor=True,
            registered_perm=DECOY_PERM,
        ):
            dataset = import_dataset(config, overwrite=True)

        assert dataset.id == dataset_id
        assert dataset.schema == "private"


# =========================================================================== #
# The legacy /datasource/save/ endpoint (the Datasource.save view that backs
# the Explore "Edit dataset" dialog) also repoints an existing dataset, so the
# save requires data access on the target table, not editorship of a
# same-named dataset.
#
# Driven through the public view exactly as the repository's own
# tests/unit_tests/views/datasource/views_test.py does: the Flask-AppBuilder
# permission decorators are peeled off with ``inspect.unwrap`` and the body is
# invoked inside a POST request context carrying the save payload. The access
# decision underneath is the real ``raise_for_access`` running in the
# ``access_world`` -- the only things stubbed are the DAO lookup that would hit
# a metadata DB and the editorship gate the endpoint applies before the
# table-binding check (the caller legitimately owns the dataset being edited).
# =========================================================================== #
def _unwrapped_save() -> Any:
    """The underlying ``Datasource.save`` body, past the FAB permission
    decorators (mirrors the repo's own ``inspect.unwrap`` view-test helper)."""
    return inspect.unwrap(_DatasourceView.save)


def _save_view_self() -> SimpleNamespace:
    """A minimal stand-in for the bound view instance ``save`` runs against."""
    return SimpleNamespace(json_response=lambda data, *a, **k: data)


def test_legacy_save_repoint_refused_for_editor_without_access() -> None:
    """The legacy save endpoint refuses an editor-only repoint to a private table.

    The caller owns the dataset being edited (the editorship gate the endpoint
    runs first is satisfied) and edits a same-named dataset, but holds no
    datasource / schema / database grant on the schema the save repoints the
    dataset to. The save is refused, surfaced as the forbidden error this
    endpoint raises or the underlying authorization error it wraps.
    """
    with _in_memory_session() as session:
        # Flush so database.id and datasource.database_id are real integers:
        # the save view answers with an error response, without reaching the
        # access check, when the dataset has no database.
        database = Database(database_name=CONN_NAME, sqlalchemy_uri="sqlite://")
        patch.object(
            database, "get_default_schema_for_query", return_value=None
        ).start()
        session.add(database)
        session.flush()

        datasource = SqlaTable(
            table_name="orders",
            schema="public",
            catalog=None,
            database=database,
            sql=None,
            template_params=None,
        )
        session.add(datasource)
        session.flush()

        payload = {
            "id": datasource.id,
            "type": "table",
            "columns": [],
            "database": {"id": database.id},
            # Repoint the physical dataset to a different, inaccessible schema.
            "table_name": "secret",
            "schema": "private",
        }
        # Run in the built app's context so the real access check's flask-babel
        # message lookup and feature-flag reads resolve, exactly as the
        # repository's own view tests run under the session app.
        with (
            patch(
                "superset.views.datasource.views.DatasourceDAO.get_datasource",
                return_value=datasource,
            ),
            # The caller owns the dataset being edited: the
            # endpoint's editorship gate passes, isolating the table-binding
            # access decision.
            patch.object(
                security_manager, "raise_for_editorship", return_value=None
            ),
            access_world(is_editor=True, registered_perm=DECOY_PERM),
            _APP.test_request_context(
                "/datasource/save/",
                method="POST",
                data={"data": superset_json.dumps(payload)},
            ),
        ):
            with pytest.raises((DatasetForbiddenError, SupersetSecurityException)):
                _unwrapped_save()(_save_view_self())
