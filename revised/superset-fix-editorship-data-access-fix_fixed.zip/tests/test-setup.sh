#!/usr/bin/env bash
# test-setup.sh - runs once before the verifier, with network available.
#
# The task runs offline: the full Superset dependency closure at the base
# commit is already baked into the app venv (/opt/superset-venv, on PATH)
# during the image build, and the canonical verifier stack is baked into
# /opt/tooling/venv. So the normal path here is a no-op check that everything
# tests/verify/verify.py imports is available WITHOUT touching the network.
# Any install below is offline-first (UV_OFFLINE=1 against the warm uv cache)
# with a loud, logged online fallback, never a bare unpinned `pip install`.
set -euo pipefail

REPO=/repo/superset
APP_PY=/opt/superset-venv/bin/python
UV=/opt/tooling/uv/uv

cd "$REPO"

echo "[test-setup] verifying baked app closure is importable (offline)"
if ! "$APP_PY" - <<'PY'
import importlib
for mod in ("superset", "pytest", "flask", "sqlalchemy", "jinja2"):
    importlib.import_module(mod)
print("[test-setup] app closure OK")
PY
then
    echo "[test-setup] baked closure incomplete; reinstalling offline from warm cache" >&2
    UV_OFFLINE=1 "$UV" pip install --python "$APP_PY" -r requirements/development.txt \
        > /tmp/test-setup-deps.log 2>&1 \
        || { echo "[test-setup] offline reinstall FAILED; online fallback" >&2; \
             tail -80 /tmp/test-setup-deps.log >&2; \
             "$UV" pip install --python "$APP_PY" -r requirements/development.txt \
                 > /tmp/test-setup-deps-online.log 2>&1 \
                 || { tail -80 /tmp/test-setup-deps-online.log >&2; exit 1; }; }
    "$APP_PY" -c "import superset, pytest, flask, sqlalchemy, jinja2"
fi

echo "[test-setup] verifier stack present in /opt/tooling/venv"
/opt/tooling/venv/bin/python -c "import pytest, jinja2, unidiff" \
    || { echo "[test-setup] verifier venv missing packages" >&2; exit 1; }

echo "[test-setup] done"
