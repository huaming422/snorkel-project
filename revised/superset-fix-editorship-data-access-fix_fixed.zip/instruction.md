## Task

During an access review we removed every data grant a user had, and they could still pull rows from `public.orders`.
They never opened SQL Lab.
They own a dataset called `orders`, and that alone lets them build a new dataset over the real table, or point one of their datasets at it, and chart it.

Repro for a user with no `datasource_access`, schema, catalog or database grant on `public.orders`, who owns some other dataset named `orders`:

- Creating a physical dataset on `public.orders` succeeds.
- Editing one of their datasets through PUT `/api/v1/dataset/<id>` succeeds when it changes the table name or schema, the SQL, or for templated SQL like `SELECT * FROM {{ t }}` only the `template_params`, and the dataset then reads the new table.
- The same repoint from the Explore "Edit dataset" dialog (POST `/datasource/save/`) succeeds.
- Duplicating a virtual dataset they own copies its SQL into a new dataset even when they cannot read the tables it selects from.
- Importing a dataset export with overwrite on, with the schema changed, repoints the existing dataset.
  It also works for someone who has `datasource_access` on the dataset being overwritten but no access to the table it now points at.
- Chart data for a chart built on a saved SQL Lab query that reads `public.orders` comes back for them.

All of these should be refused unless the user can read the table the dataset ends up reading.
On create and on PUT edits that means the normal table access error ("You need access to the following tables: ...").
A refused import must leave the stored dataset exactly as it was.

Templated SQL has to be checked against the table it resolves to with the dataset's own `template_params`.
Today, creating `SELECT * FROM {{ t }}` with `{"t": "private.secret"}` fails validation even for someone with schema access to `private`.
It should go through for them, and fail with the table access error for someone with no access.
`template_params` that are not a JSON object, for example `[1, 2, 3]`, should be rejected on create and on PUT edits instead of ignored.

Please don't break what works today:

- `datasource_access` on a dataset for the table, or schema, catalog or database access, is still enough to create a dataset on it.
- Schema access to the target is still enough to repoint a dataset there through PUT, to duplicate a virtual dataset that reads it, and to import an overwrite that points there.
- PUT edits that don't change what a dataset reads still save for its owner, for example a new description, or the same `template_params` sent back with different spacing.
- An owner with no other grant can still explore their own dataset: chart data on it works, and so does `/api/v1/database/<id>/table_metadata/` for its table.
