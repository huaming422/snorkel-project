#!/usr/bin/env bash
# Structural check (criterion 8): the workspace still compiles and the repo's
# existing optimizer unit tests still pass. These tests are part of the repo,
# not authored here. The image pre-builds the workspace, so this run is
# incremental.
set -euo pipefail

cd /repo/turso

# Run the existing optimizer unit tests. A compile error in the crate is
# reported as a failure.
cargo test -p turso_core translate::optimizer -- --test-threads=1
