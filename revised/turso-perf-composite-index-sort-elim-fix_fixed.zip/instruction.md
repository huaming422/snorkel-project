## Task

Queries that read through a composite index in turso are a lot slower than they should be when they look like this:
the WHERE clause fixes the first index column (or the first few) with `=`, and the ORDER BY asks for columns that come later in that same index.
On a table with about 100k rows one of these takes around 145 ms, while sqlite answers the same kind of query in roughly 20 µs.
The rows are correct, they just come back slowly, and the gap grows with the number of matching rows, so a small table hides it.
Running `EXPLAIN QUERY PLAN` on one of them shows the index seek followed by a `USE SORTER FOR ORDER BY` step (`USE TEMP B-TREE FOR ORDER BY` when there is a LIMIT), even though the index already hands the rows back in the order asked for.

Please get rid of that extra ordering work wherever the index really does guarantee the order.
These are the shapes we need covered:

- ORDER BY on the index columns after the fixed ones, in the direction the index declares them.
- ORDER BY that also names the fixed columns, in any direction, since they only ever hold one value.
- An index where one key is an expression such as `lower(title)`, when the query writes that same expression, including when the ordering comes from a GROUP BY on it.
- A rowid or INTEGER PRIMARY KEY term at the end of the ORDER BY, ascending, after the index columns, since rows with equal index keys come back in rowid order.
- A LEFT JOIN where the ORDER BY only uses columns of the left-hand table.

Be careful here.
Lots of queries look like these, but the index does not guarantee their order.
Those must return the same rows in the same order as today and keep their sort step.
Don't work around it by adding an index, rewriting the queries or changing the schema; this needs to be fixed in how turso plans queries.
