#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
#
# The verifier for this task is a dotnet test driven by the shell runner
# (verify.sh). The image baked the full NuGet dependency closure at the base
# commit (quantconnect/lean foundation image + a Release build of
# QuantConnect.Lean.sln warmed ~/.nuget/packages), so the verifier's compile of
# the Tests project resolves entirely from the image with no network.
cd /repo/Lean

# Restore from the baked cache first. If that misses, the second restore tries
# the configured package sources, which the verifier network does not reach, so a
# stale bake fails here with the restore log instead of partway through the build.
export DOTNET_CLI_TELEMETRY_OPTOUT=1
export DOTNET_NOLOGO=1
export DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1

# The in-repo LocalPackages source was registered at image-build time; the first
# restore reads only that source and the warm global package cache.
if dotnet restore QuantConnect.Lean.sln --source "$HOME/.nuget/packages" \
        --source /repo/Lean/LocalPackages > /tmp/test-setup-restore.log 2>&1; then
    echo "[offline-first] NuGet restore satisfied from image bake"
elif dotnet restore QuantConnect.Lean.sln >> /tmp/test-setup-restore.log 2>&1; then
    echo "[test-setup] NuGet restore completed online (image bake was stale)"
else
    tail -60 /tmp/test-setup-restore.log >&2; exit 1
fi

# No services to start and no data to seed: the checks run in-process. No
# assertion logic lives here.
