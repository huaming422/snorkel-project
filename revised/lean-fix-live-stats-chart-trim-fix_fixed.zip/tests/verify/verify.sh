#!/usr/bin/env bash
#
# Builds the repo's test project with one added behavioral test fixture and runs
# that fixture's methods. Exits 0 only if every method passes.
#
# Mechanism: the shell runner invokes this file with cwd = the repo root and
# reports a single pass/fail from the exit code. The fixture lives beside this
# script; it is copied into the repo's test tree, compiled against the submitted
# source, and executed in isolation via a name filter so unrelated suites do not
# run.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="${REPO_DIR:-/repo/Lean}"
cd "$REPO_DIR"

export DOTNET_CLI_TELEMETRY_OPTOUT=1
export DOTNET_NOLOGO=1
export DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1

FIXTURE_SRC="$SCRIPT_DIR/Verify_LiveStatsChartTrim.cs"
FIXTURE_DST="$REPO_DIR/Tests/Engine/Results/Verify_LiveStatsChartTrim.cs"
TEST_PROJECT="$REPO_DIR/Tests/QuantConnect.Tests.csproj"

if [[ ! -f "$FIXTURE_SRC" ]]; then
    echo "verify: fixture source missing at $FIXTURE_SRC" >&2
    exit 2
fi
if [[ ! -f "$TEST_PROJECT" ]]; then
    echo "verify: test project missing at $TEST_PROJECT" >&2
    exit 2
fi

cp "$FIXTURE_SRC" "$FIXTURE_DST"
cleanup() { rm -f "$FIXTURE_DST"; }
trap cleanup EXIT

# Build once against the baked NuGet cache (offline-first). The image warmed the
# global package cache at the base commit, so this compile resolves with no
# network; if the bake is stale, dotnet falls back to its configured sources.
BUILD_LOG="$(mktemp)"
if ! dotnet build "$TEST_PROJECT" -c Release /v:minimal /p:WarningLevel=0 \
        > "$BUILD_LOG" 2>&1; then
    echo "verify: test project failed to build" >&2
    tail -120 "$BUILD_LOG" >&2
    exit 1
fi

# Run only this fixture's methods. All must pass for a zero exit.
#
# The fixture defines a fixed number of behavioral methods; require that exact
# count to actually run. A filter that silently matches nothing (renamed
# namespace, dropped fixture) otherwise lets `dotnet test` exit 0 on zero tests,
# which would report success with nothing checked.
EXPECTED_TESTS=4
TEST_LOG="$(mktemp)"
set +e
dotnet test "$TEST_PROJECT" -c Release --no-build \
    --filter "FullyQualifiedName~QuantConnect.Tests.Engine.Results.Verify_LiveStatsChartTrim" \
    > "$TEST_LOG" 2>&1
TEST_RC=$?
set -e

# Parse the run summary: "... Failed: N, Passed: N, Skipped: N, Total: N".
SUMMARY="$(grep -Eo 'Failed:[[:space:]]*[0-9]+,[[:space:]]*Passed:[[:space:]]*[0-9]+,[[:space:]]*Skipped:[[:space:]]*[0-9]+,[[:space:]]*Total:[[:space:]]*[0-9]+' "$TEST_LOG" | tail -1 || true)"
PASSED_COUNT="$(sed -nE 's/.*Passed:[[:space:]]*([0-9]+).*/\1/p' <<< "$SUMMARY")"
TOTAL_COUNT="$(sed -nE 's/.*Total:[[:space:]]*([0-9]+).*/\1/p' <<< "$SUMMARY")"

if [[ "$TEST_RC" -ne 0 ]]; then
    echo "verify: one or more behavioral checks failed" >&2
    tail -200 "$TEST_LOG" >&2
    exit 1
fi
if [[ -z "$TOTAL_COUNT" || "$TOTAL_COUNT" -lt "$EXPECTED_TESTS" || "$PASSED_COUNT" != "$TOTAL_COUNT" ]]; then
    echo "verify: expected $EXPECTED_TESTS checks to run and pass; summary was: ${SUMMARY:-<none found>}" >&2
    tail -200 "$TEST_LOG" >&2
    exit 2
fi

echo "verify: $PASSED_COUNT/$TOTAL_COUNT behavioral checks passed"
tail -20 "$TEST_LOG"
exit 0
