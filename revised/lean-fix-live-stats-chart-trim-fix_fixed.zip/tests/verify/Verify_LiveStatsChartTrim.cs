/*
 * Behavioral checks for the live result handler's periodic chart maintenance.
 *
 * Each check builds a live session through the public Sample path (the daily
 * sample) and the protected equity sampling the live handler runs between daily
 * samples, runs the private periodic-maintenance entry point (Update) by
 * reflection, and then reads the public StatisticsResults() output. Only members
 * that already exist on the handler are used: Sample, SampleEquity, Update,
 * StatisticsResults and the private _next* schedule fields.
 *
 * What the checks assert:
 * - after maintenance on a long session, the live risk statistics are the same
 *   ones the full session history gives for the numbers built from the
 *   return series;
 * - what the handler keeps for a long session grows by about a daily amount, not
 *   by every intraday equity sample, whether it is held in Charts or anywhere
 *   else the handler can reach;
 * - ordinary chart series keep only the short recent window;
 * - a second maintenance pass leaves the statistics unchanged.
 *
 * The maintenance reassigns each series' Values list to a new list, so a list
 * reference captured before the pass is stale after it. Every assertion re-reads
 * the list from Charts after the pass via Points().
 */

using System;
using System.Linq;
using System.Reflection;
using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;
using QuantConnect.Packets;
using QuantConnect.Interfaces;
using QuantConnect.Algorithm;
using QuantConnect.Statistics;
using QuantConnect.Securities;
using QuantConnect.Data.UniverseSelection;
using QuantConnect.Lean.Engine.Results;
using QuantConnect.Lean.Engine.DataFeeds;
using QuantConnect.Tests.Engine.DataFeeds;
using QuantConnect.Lean.Engine.TransactionHandlers;
using QuantConnect.Tests.Common.Data.UniverseSelection;

namespace QuantConnect.Tests.Engine.Results
{
    [TestFixture]
    public class Verify_LiveStatsChartTrim
    {
        private const BindingFlags Flags = BindingFlags.NonPublic | BindingFlags.Instance;

        // Intraday equity samples seeded per calendar day in the memory checks (one
        // every 2 minutes; a live node samples equity every few seconds).
        private const int IntradayPerDay = 720;

        // The memory checks accept keeping up to a quarter of the seeded intraday
        // rate, about one point every 8 minutes.
        private const int RetainedPerDayLimit = IntradayPerDay / 4;

        // A subclass that idles the background maintenance thread (its loop body is
        // a protected method) so the test can drive the periodic maintenance itself
        // rather than racing a timer.
        private class QuietHandler : LiveTradingResultHandler
        {
            protected override void Run()
            {
                // Intentionally idle: the test invokes the maintenance pass directly.
            }

            // The same steps the live handler takes on its frequent equity sample
            // between daily samples: refresh the portfolio value, update the
            // current equity bar and add it to the equity series.
            public void SampleIntradayEquity(DateTime time)
            {
                UpdatePortfolioValues(time);
                UpdateAlgorithmEquity();
                SampleEquity(time);
            }
        }

        private static void SetField(LiveTradingResultHandler handler, string name, object value)
        {
            var field = typeof(LiveTradingResultHandler).GetField(name, Flags);
            Assert.IsNotNull(field, $"Expected field {name} on the live result handler.");
            field.SetValue(handler, value);
        }

        private static DateTime GetDateField(LiveTradingResultHandler handler, string name)
        {
            var field = typeof(LiveTradingResultHandler).GetField(name, Flags);
            Assert.IsNotNull(field, $"Expected field {name} on the live result handler.");
            return (DateTime)field.GetValue(handler);
        }

        // Builds a fully-initialized live result handler with a locked stub
        // algorithm, mirroring the existing LiveTradingResultHandlerTests setup.
        // The stub algorithm is handed back so a test can move the portfolio value
        // between samples and produce a real performance series.
        private static QuietHandler BuildHandler(out IDisposable[] disposables, out QCAlgorithm algorithm)
        {
            var api = new Api.Api();
            var messaging = new QuantConnect.Messaging.Messaging();
            disposables = new IDisposable[] { api, messaging };

            var handler = new QuietHandler();
            handler.Initialize(new(new LiveNodePacket(), messaging, api, new BacktestingTransactionHandler(), null));

            var algo = new AlgorithmStub(createDataManager: false);
            algo.SetFinishedWarmingUp();
            var dataManager = new DataManagerStub(new NoopDataFeed(), algo);
            algo.SubscriptionManager.SetDataManager(dataManager);
            // extendedMarketHours makes the live handler sample on every call rather
            // than only during the equity's regular session, so a test can seed a
            // dense history deterministically regardless of wall-clock date.
            var aapl = algo.AddEquity("AAPL", extendedMarketHours: true);
            // Risk-statistic generation needs the trading-days-per-year setting; it is
            // normally set by the setup handler. Without it, statistics generation
            // throws internally and returns an empty result regardless of history.
            algo.Settings.TradingDaysPerYear = 252;
            algo.PostInitialize();
            handler.SetAlgorithm(algo, 100000);
            handler.OnSecuritiesChanged(SecurityChangesTests.AddedNonInternal(aapl));

            // The maintenance loop only runs for a locked (fully-initialized) algorithm.
            algo.SetLocked();
            algorithm = algo;
            return handler;
        }

        // Moves the portfolio value, then takes one daily sample through the public
        // Sample path, so equity/return/benchmark get a real series.
        private static void SampleDay(LiveTradingResultHandler handler, QCAlgorithm algo, DateTime time, decimal cashDelta)
        {
            MoveCash(algo, cashDelta);
            algo.SetDateTime(time);
            handler.Sample(time);
        }

        private static void MoveCash(QCAlgorithm algo, decimal cashDelta)
        {
            algo.Portfolio.CashBook["USD"].AddAmount(cashDelta);
            algo.Portfolio.InvalidateTotalPortfolioValue();
        }

        // Seeds a session the way a live node fills it: one daily sample at the start
        // of each calendar day and IntradayPerDay equity samples later that day, for
        // every day from oldestDay back to 5 days ago, then a few daily samples
        // inside the last 2 days. The intraday cash moves cancel out over a day, so
        // the daily returns carry the variance.
        private static void SeedLiveSession(QuietHandler handler, QCAlgorithm algo, DateTime now, int oldestDay)
        {
            var deltas = new[] { 1500m, -800m, 2200m, -500m, 1800m, -1200m, 2600m, -1600m };
            var step = 0;
            for (var day = oldestDay; day >= 5; day--)
            {
                var dayStart = now.Date.AddDays(-day);
                SampleDay(handler, algo, dayStart, deltas[step++ % deltas.Length]);
                for (var i = 0; i < IntradayPerDay; i++)
                {
                    MoveCash(algo, i % 2 == 0 ? 25m : -25m);
                    handler.SampleIntradayEquity(dayStart.AddMinutes(1 + 2 * i));
                }
            }

            SampleDay(handler, algo, now.AddHours(-30), 1300m);
            SampleDay(handler, algo, now.AddHours(-5), -900m);
            SampleDay(handler, algo, now.AddHours(-1), 1700m);
        }

        // Runs exactly one periodic-maintenance pass with only the chart-maintenance
        // branch due, then confirms that branch ran.
        private static void DriveMaintenance(LiveTradingResultHandler handler)
        {
            var now = DateTime.UtcNow;

            // Enter the maintenance body; keep the date bookkeeping branch quiet.
            SetField(handler, "_nextUpdate", now.AddHours(-1));
            SetField(handler, "_currentUtcDate", now.Date);

            // Push every other periodic branch into the future so only the
            // chart-maintenance branch fires this pass (avoids the heavy storage
            // and remote-API branches).
            foreach (var name in new[]
            {
                "_nextChartsUpdate", "_nextLogStoreUpdate", "_nextStatisticsUpdate",
                "_nextStatusUpdate", "_nextInsightStoreUpdate"
            })
            {
                SetField(handler, name, now.AddYears(1));
            }

            // Make the chart-maintenance branch due now.
            SetField(handler, "_nextChartTrimming", now.AddHours(-1));

            var update = typeof(LiveTradingResultHandler).GetMethod("Update", Flags);
            Assert.IsNotNull(update, "Expected private Update() on the live result handler.");
            update.Invoke(handler, null);

            // The maintenance body swallows its own exceptions, so an early failure
            // would silently skip the chart-maintenance branch and leave the series
            // untouched. The branch reschedules its own next run on completion; use
            // that reschedule as proof the branch ran this pass.
            Assert.Greater(GetDateField(handler, "_nextChartTrimming"), now.AddMinutes(5),
                "The periodic chart-maintenance branch did not run this pass.");
        }

        // Always re-reads the current Values list from Charts (the maintenance
        // reassigns it, so a reference captured earlier would be stale).
        private static List<ISeriesPoint> Points(LiveTradingResultHandler handler, string chartKey, string seriesKey)
        {
            Assert.IsTrue(handler.Charts.ContainsKey(chartKey), $"Missing chart {chartKey}.");
            Assert.IsTrue(handler.Charts[chartKey].Series.ContainsKey(seriesKey), $"Missing series {seriesKey}.");
            return handler.Charts[chartKey].Series[seriesKey].Values;
        }

        private static void Dispose(IDisposable[] disposables, LiveTradingResultHandler handler)
        {
            try { handler.Exit(); } catch { /* best effort */ }
            foreach (var d in disposables)
            {
                try { d.Dispose(); } catch { /* best effort */ }
            }
        }

        [Test]
        public void LiveStatisticsStayComputableOverALongSession()
        {
            var handler = BuildHandler(out var disposables, out var algo);
            try
            {
                var now = DateTime.UtcNow;

                // Daily samples over most of a year, moving the portfolio value each
                // day so the return series has real variance.
                var deltas = new[] { 1500m, -800m, 2200m, -500m, 1800m, -1200m, 2600m };
                var step = 0;
                for (var day = 300; day >= 3; day -= 2)
                {
                    SampleDay(handler, algo, now.AddDays(-day), deltas[step % deltas.Length]);
                    step++;
                }
                // Two samples inside the last 2 days.
                SampleDay(handler, algo, now.AddHours(-5), 1300m);
                SampleDay(handler, algo, now.AddHours(-1), -900m);

                // The statistics the full session history gives. A zero here means
                // the seeding produced no real performance series.
                var statsBefore = handler.StatisticsResults();
                Assert.AreNotEqual(0m, statsBefore.TotalPerformance.PortfolioStatistics.AnnualStandardDeviation,
                    "Precondition: the seeded session did not produce a non-zero statistics baseline.");

                DriveMaintenance(handler);

                var statsAfter = handler.StatisticsResults();
                var stats = statsAfter.TotalPerformance.PortfolioStatistics;

                Assert.AreNotEqual(0m, stats.AnnualStandardDeviation,
                    "Annual standard deviation reads zero after maintenance on a long session.");
                Assert.AreNotEqual(0m, stats.ProbabilisticSharpeRatio,
                    "The probabilistic Sharpe ratio reads zero after maintenance on a long session.");
                Assert.AreEqual(DescribeReturnStatistics(statsBefore), DescribeReturnStatistics(statsAfter),
                    "After maintenance the live risk statistics differ from the ones the full session history gives.");
            }
            finally
            {
                Dispose(disposables, handler);
            }
        }

        [Test]
        public void RetainedStatisticsHistoryIsMemoryBounded()
        {
            // A shorter and a longer session, each seeded with dense intraday equity.
            // The growth between them is what the handler keeps per extra day of
            // session, counted over everything reachable from the handler.
            const int shortOldestDay = 35;
            const int longOldestDay = 125;
            var shortRetained = RetainedAfterMaintenance(shortOldestDay, checkChartSeries: false);
            var longRetained = RetainedAfterMaintenance(longOldestDay, checkChartSeries: true);

            var extraDays = longOldestDay - shortOldestDay;
            var growthPerDay = (double)(longRetained - shortRetained) / extraDays;
            Assert.Less(growthPerDay, RetainedPerDayLimit,
                $"The handler kept {longRetained - shortRetained} more objects for {extraDays} more days of session "
                + $"({growthPerDay:F1} per day with {IntradayPerDay} intraday equity samples per day, limit {RetainedPerDayLimit}); "
                + "what it keeps grows with every intraday sample.");
        }

        // Seeds one session, runs maintenance, checks the statistics are still there
        // and returns how much the handler holds afterwards. With checkChartSeries set,
        // also checks how many points each statistics series keeps behind the last
        // 3 days, against the same per-day limit.
        private static long RetainedAfterMaintenance(int oldestDay, bool checkChartSeries)
        {
            var handler = BuildHandler(out var disposables, out var algo);
            try
            {
                var now = DateTime.UtcNow;
                SeedLiveSession(handler, algo, now, oldestDay);

                DriveMaintenance(handler);

                var stats = handler.StatisticsResults().TotalPerformance.PortfolioStatistics;
                Assert.AreNotEqual(0m, stats.AnnualStandardDeviation,
                    "The live risk statistics read zero after maintenance on a long session.");

                if (checkChartSeries)
                {
                    var oldRegionBoundary = now.AddDays(-3);
                    var seededOldDays = oldestDay - 5 + 1;
                    var seededOld = seededOldDays * (IntradayPerDay + 1);
                    var seriesCap = seededOldDays * RetainedPerDayLimit;

                    foreach (var (chartKey, seriesKey) in new[]
                    {
                        (BaseResultsHandler.StrategyEquityKey, BaseResultsHandler.EquityKey),
                        (BaseResultsHandler.StrategyEquityKey, BaseResultsHandler.ReturnKey),
                        (BaseResultsHandler.BenchmarkKey, BaseResultsHandler.BenchmarkKey),
                    })
                    {
                        var retainedOld = Points(handler, chartKey, seriesKey)
                            .Count(p => p.Time < oldRegionBoundary);
                        Assert.Less(retainedOld, seriesCap,
                            $"The series {chartKey}->{seriesKey} kept {retainedOld} points older than 3 days "
                            + $"after {seededOldDays} seeded days ({seededOld} equity samples, limit {seriesCap}).");
                    }
                }

                return CountReachable(handler);
            }
            finally
            {
                Dispose(disposables, handler);
            }
        }

        [Test]
        public void NonStatisticsSeriesTrimmedToRecentWindow()
        {
            var handler = BuildHandler(out var disposables, out _);
            try
            {
                var now = DateTime.UtcNow;

                var chart = new Chart("CustomDiagnostics");
                chart.Series.Add("CustomMetric", new Series("CustomMetric", SeriesType.Line, 0));
                handler.Charts["CustomDiagnostics"] = chart;
                var custom = Points(handler, "CustomDiagnostics", "CustomMetric");

                // Points spanning ~10 days back; only those within the recent
                // window (~2 days) should survive.
                for (var day = 10; day >= 3; day--)
                {
                    custom.Add(new ChartPoint(now.AddDays(-day), day));
                }
                custom.Add(new ChartPoint(now.AddHours(-1), 0));

                DriveMaintenance(handler);

                custom = Points(handler, "CustomDiagnostics", "CustomMetric");

                var olderThanAWeek = now.AddDays(-7);
                Assert.IsFalse(custom.Any(v => v.Time < olderThanAWeek),
                    "A non-statistics series kept points from more than a week ago.");
                Assert.IsTrue(custom.Any(v => v.Time > now.AddHours(-2)),
                    "A non-statistics series dropped its most recent point.");
            }
            finally
            {
                Dispose(disposables, handler);
            }
        }

        [Test]
        public void RepeatedMaintenanceIsIdempotent()
        {
            var handler = BuildHandler(out var disposables, out var algo);
            try
            {
                var now = DateTime.UtcNow;

                // Seed a long daily session through the public Sample path.
                var deltas = new[] { 1500m, -800m, 2200m, -500m, 1800m };
                var step = 0;
                for (var day = 60; day >= 3; day--)
                {
                    SampleDay(handler, algo, now.AddDays(-day), deltas[step % deltas.Length]);
                    step++;
                }
                SampleDay(handler, algo, now.AddHours(-1), 1000m);

                DriveMaintenance(handler);

                // Snapshot the statistics the handler reports after the first pass,
                // read through the public StatisticsResults() output.
                var firstPass = Describe(handler.StatisticsResults());

                DriveMaintenance(handler);

                var secondPass = Describe(handler.StatisticsResults());

                Assert.AreEqual(firstPass, secondPass,
                    "A second maintenance pass changed the live statistics.");
            }
            finally
            {
                Dispose(disposables, handler);
            }
        }

        // The risk statistics built from the return series alone (probabilistic
        // Sharpe ratio, volatility and value at risk), as a stable string.
        private static string DescribeReturnStatistics(StatisticsResults results)
        {
            var s = results.TotalPerformance.PortfolioStatistics;
            return string.Join("|",
                s.ProbabilisticSharpeRatio,
                s.AnnualStandardDeviation,
                s.AnnualVariance,
                s.ValueAtRisk99);
        }

        // A stable string describing the risk statistics, used to compare two
        // statistics results without depending on any internal representation.
        private static string Describe(StatisticsResults results)
        {
            var s = results.TotalPerformance.PortfolioStatistics;
            return string.Join("|",
                s.ProbabilisticSharpeRatio,
                s.SharpeRatio,
                s.AnnualStandardDeviation,
                s.AnnualVariance,
                s.ValueAtRisk99);
        }

        // Counts the objects reachable from the handler, plus those reachable from
        // static fields of the result-handler types and the chart types, plus every
        // value stored as a collection element. Plain value fields (numbers, dates)
        // are not counted. The algorithm object is not followed, since its state does
        // not belong to the handler. Collections are read by enumeration; QuantConnect
        // types, key/value pairs, lazy values and tuples are read field by field.
        private static long CountReachable(LiveTradingResultHandler handler)
        {
            var visited = new HashSet<object>(ReferenceEqualityComparer.Instance);
            var pending = new Stack<(object Value, bool IsElement)>();
            pending.Push((handler, false));

            foreach (var type in StaticRootTypes())
            {
                foreach (var field in type.GetFields(BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.DeclaredOnly))
                {
                    PushField(pending, field, null);
                }
            }

            long count = 0;
            while (pending.Count > 0)
            {
                var (value, isElement) = pending.Pop();
                var type = value.GetType();
                if (type.IsValueType)
                {
                    if (isElement)
                    {
                        count++;
                    }
                }
                else
                {
                    if (!visited.Add(value))
                    {
                        continue;
                    }
                    count++;
                }

                if (value is string || value is IAlgorithm || value is Delegate || value is MemberInfo)
                {
                    continue;
                }

                if (type.IsArray || IsSystemCollection(type))
                {
                    try
                    {
                        foreach (var item in (IEnumerable)value)
                        {
                            if (item != null)
                            {
                                pending.Push((item, true));
                            }
                        }
                    }
                    catch (Exception)
                    {
                        // A collection that cannot be enumerated right now is counted once.
                    }
                    continue;
                }

                if (!IsFieldWalked(type))
                {
                    continue;
                }

                for (var t = type; t != null && t != typeof(object); t = t.BaseType)
                {
                    foreach (var field in t.GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.DeclaredOnly))
                    {
                        PushField(pending, field, value);
                    }
                }
            }

            return count;
        }

        private static void PushField(Stack<(object Value, bool IsElement)> pending, FieldInfo field, object owner)
        {
            var fieldType = field.FieldType;
            if (field.IsLiteral || fieldType.IsPointer || fieldType.IsByRefLike || fieldType.IsPrimitive || fieldType.IsEnum)
            {
                return;
            }

            object value;
            try
            {
                value = field.GetValue(owner);
            }
            catch (Exception)
            {
                return;
            }

            if (value == null)
            {
                return;
            }

            var valueType = value.GetType();
            if (valueType.IsValueType && !IsFieldWalked(valueType) && !IsSystemCollection(valueType))
            {
                return;
            }
            pending.Push((value, false));
        }

        private static IEnumerable<Type> StaticRootTypes()
        {
            var resultsNamespace = typeof(LiveTradingResultHandler).Namespace;
            var engineTypes = LoadableTypes(typeof(LiveTradingResultHandler).Assembly)
                .Where(t => t.Namespace == resultsNamespace);
            var chartTypes = LoadableTypes(typeof(BaseSeries).Assembly)
                .Where(t => typeof(BaseSeries).IsAssignableFrom(t)
                    || typeof(Chart).IsAssignableFrom(t)
                    || typeof(ISeriesPoint).IsAssignableFrom(t));
            return engineTypes.Concat(chartTypes).Where(t => !t.ContainsGenericParameters);
        }

        private static IEnumerable<Type> LoadableTypes(Assembly assembly)
        {
            try
            {
                return assembly.GetTypes();
            }
            catch (ReflectionTypeLoadException e)
            {
                return e.Types.Where(t => t != null);
            }
        }

        private static bool IsSystemCollection(Type type)
        {
            if (!typeof(IEnumerable).IsAssignableFrom(type))
            {
                return false;
            }
            if (type.Namespace != null && type.Namespace.StartsWith("System.Collections", StringComparison.Ordinal))
            {
                return true;
            }
            return type.IsGenericType
                && type.GetGenericTypeDefinition().FullName == "System.Runtime.CompilerServices.ConditionalWeakTable`2";
        }

        private static bool IsFieldWalked(Type type)
        {
            if (type.Namespace != null && type.Namespace.StartsWith("QuantConnect", StringComparison.Ordinal))
            {
                return true;
            }
            if (!type.IsGenericType)
            {
                return false;
            }
            var definition = type.GetGenericTypeDefinition();
            var name = definition.FullName ?? string.Empty;
            return definition == typeof(KeyValuePair<,>)
                || definition == typeof(Lazy<>)
                || name.StartsWith("System.Tuple`", StringComparison.Ordinal)
                || name.StartsWith("System.ValueTuple`", StringComparison.Ordinal);
        }

        private class NoopDataFeed : IDataFeed
        {
            public bool IsActive { get; }

            public void Initialize(
                IAlgorithm algorithm,
                AlgorithmNodePacket job,
                IResultHandler resultHandler,
                IMapFileProvider mapFileProvider,
                IFactorFileProvider factorFileProvider,
                IDataProvider dataProvider,
                IDataFeedSubscriptionManager subscriptionManager,
                IDataFeedTimeProvider dataFeedTimeProvider,
                IDataChannelProvider dataChannelProvider)
            {
            }

            public Subscription CreateSubscription(SubscriptionRequest request) => null;

            public void RemoveSubscription(Subscription subscription) { }

            public void Exit() { }
        }
    }
}
