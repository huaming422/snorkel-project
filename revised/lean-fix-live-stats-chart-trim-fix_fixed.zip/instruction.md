## Task

Something is off in the live view for algos we leave running for weeks.
Right after a deploy the risk numbers look sensible.
Give it some uptime, though, and they all fall to 0% and stay there.
PSR is the one people notice, but Sharpe, volatility and VaR go with it, along with anything else worked out from the equity curve, the daily returns and the benchmark.
Redeploying makes them look normal again, only for them to hit zero the same way a while later.

Can you track down why this happens on long sessions and fix it?
Whether an algo has been live for a week or for most of a year, PSR, volatility and VaR should come out the same as they would from everything it has recorded since it started.
If its equity is only sampled once a day, Sharpe and drawdown should match that full history too.
Those numbers also shouldn't change on their own while no new data is coming in.
And the node's memory use over a months-long session has to stay about where it is today.
