## Task

On our long-running live algos the risk stats in the live view end up reading 0%.
That's the probabilistic Sharpe ratio and the other live numbers built from equity, returns and the benchmark, like Sharpe, volatility and VaR.
They look fine when the algo starts, then once it has been up for a while they drop to zero and stay there.
A restart brings them back, but before long they slide back to zero.

Can you find out why the live stats go wrong on a long session and fix it?
On an algo that has been live for most of a year, the probabilistic Sharpe ratio, volatility and VaR should come out the same as they would from everything it has recorded since it started.
Those numbers also shouldn't change on their own while no new data is coming in.
And the node's memory use over a months-long session has to stay about where it is today.
