## Task

We keep getting reports that `session/new` over ACP hangs on some `gjc` sessions, and on others it just fails.
Every report so far comes from someone whose chat-notification daemon was in a bad state at the time: stuck, crashed, or refusing the bot's identity.
Closing a session can hang the same way.
When the daemon is healthy, sessions open and close fine.

Notifications are a side channel, so a broken daemon can cost a session its notifications but nothing more.
Opening and closing the session has to go through either way, and the session's SDK endpoint has to show up like it normally does.
That goes for Telegram, Discord and Slack.

A session should only send notifications under a setup the daemon has confirmed, so it has none until the daemon says yes.
If the daemon was only stuck and answers later, that session's notifications should turn on by themselves, without waiting for some other session event.

When someone changes a token, the chat or channel the bot posts to, or the Slack user allowed to send commands, notifications should pause until the daemon confirms the new setup, then pick back up.
With Discord or Slack, changing redaction or verbosity counts as a setup change too.
Once the daemon has confirmed a setup, gjc shouldn't keep going back to it on every session event.
On a Telegram-only setup, a redaction or verbosity change shouldn't send gjc back to the daemon at all.
