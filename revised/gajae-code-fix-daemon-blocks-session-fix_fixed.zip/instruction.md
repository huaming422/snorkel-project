## Task

We keep getting reports that `session/new` over ACP hangs on some `gjc` sessions, and on others it just fails.
Every report so far comes from someone whose chat-notification daemon was in a bad state at the time: stuck, crashed, or refusing the bot's identity.
Closing a session can hang the same way.
When the daemon is healthy, sessions open and close fine.

Notifications are a side channel, so a broken daemon can cost a session its notifications but nothing more.
Opening and closing the session has to go through either way, and the session's SDK endpoint has to show up like it normally does.
That goes for Telegram, Discord and Slack.

A session should only send notifications under a setup the daemon has confirmed, so it has none until the daemon says yes.
If the daemon was only stuck and answers later, that session's notifications should turn on by themselves, without waiting for some other session event.

Each configured daemon's ownership is tied to part of the setup.
When a setting it is tied to changes, notifications should pause until that daemon confirms the new setup, then pick back up.
A settings change that no configured daemon's ownership is tied to shouldn't send gjc back to the daemon at all.
Once the daemon has confirmed a setup, gjc shouldn't keep going back to it on every session event.

If the daemon crashed instead of answering, the next session event after it comes back should ask it again, and notifications should turn on once it says yes.
While it is down and nothing happens in the session, gjc shouldn't keep retrying it back to back.
