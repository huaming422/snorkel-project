#!/usr/bin/env bash
# Environment bootstrap for the verifier. Sourced (not exec'd) by the harbor
# runner, so env vars set here stay live for the verifier subprocess.
#
# The image already carries the full offline closure: bun deps
# (bun install --frozen-lockfile at the base commit) and the compiled
# @gajae-code/natives NAPI addon (packages/natives/native/pi_natives.*.node).
# The TypeScript coding-agent tests run straight from source under `bun test`,
# so there is no workspace build step to repeat here. This script only
# verifies the baked closure is intact and installs the runner's own tomli
# dependency defensively.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/gajae-code}"
export REPO_DIR
cd "$REPO_DIR"

# Fail a cache miss fast instead of hanging on a dead network during the
# offline solve and verify phases.
export BUN_CONFIG_NO_CLEAR_TERMINAL=1

# The harbor runner reads the per-task verify.toml via Python's tomllib. The
# canonical verifier venv at /opt/tooling runs Python 3.12 (tomllib is in the
# stdlib there), so there is no tomli install to do here. The runner routes
# verifier infrastructure through VERIFIER_PYTHON, not the Ubuntu system 3.10.

# Sanity check: bun must be resolvable.
if ! command -v bun >/dev/null 2>&1; then
    echo "test-setup.sh: bun not found on PATH. The image build is corrupt." >&2
    exit 1
fi

# Sanity check: the native NAPI addon must be present. The coding-agent tests
# import src/, which loads @gajae-code/natives at module init; a missing .node
# surfaces later as a confusing "Failed to load pi_natives native addon".
# Bail now with a clear message. The addon is baked at build and is never
# rebuilt here.
if ! ls packages/natives/native/pi_natives.*.node >/dev/null 2>&1; then
    echo "test-setup.sh: @gajae-code/natives addon (.node) missing from" \
         "packages/natives/native/. The image build is corrupt." >&2
    exit 1
fi

# Sanity check: workspace node_modules must be present (baked at build).
if ! [ -x node_modules/.bin/biome ] && ! [ -d node_modules/@gajae-code ]; then
    echo "test-setup.sh: workspace node_modules missing or incomplete." \
         "The image build is corrupt." >&2
    exit 1
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR bun=$(bun --version 2>/dev/null || echo unknown)" \
     "addon=$(ls packages/natives/native/pi_natives.*.node 2>/dev/null | xargs -n1 basename | tr '\n' ' ')"
