"""Behavioral verification for chat-daemon session isolation.

The subject suite (``daemon-isolation.test.ts``, shipped beside this file) is
written for the repository's own test runtime: it imports ``bun:test`` and uses
runtime primitives (``Bun.sleep``, ``Promise.withResolvers``) that only the
repo-native ``bun test`` command can execute. The shared JavaScript runner
drives Node (jest/vitest) and cannot run it. So this module runs the suite once
through ``bun test`` and reports each behavioral scenario as its own case.

This file imports no repository code; it only orchestrates a subprocess, so it
runs cleanly under the shared verifier interpreter. The ``bun`` subprocess is
the repository's own test command, executed against its own source tree.

Each scenario drives the public ``createNotificationsExtension`` dependency
seam and the ``NotificationSessionController`` query/reconcile surface, which
both already exist in the repository, and never any newly introduced
identifier.
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path

import pytest

# --- Locate the repository and the subject suite ----------------------------

VERIFY_DIR = Path(__file__).resolve().parent
SUBJECT_TEST = VERIFY_DIR / "daemon-isolation.test.ts"


def _repo_dir() -> Path:
    """Resolve the checked-out repository root.

    ``run_verify`` runs this file with the repository as the working directory
    and also exports ``REPO_DIR`` / ``REPO_NAME``; fall back to the conventional
    mount path so a direct invocation still works.
    """
    env = os.environ.get("REPO_DIR")
    if env and Path(env).is_dir():
        return Path(env)
    name = os.environ.get("REPO_NAME", "gajae-code")
    candidate = Path(f"/repo/{name}")
    if candidate.is_dir():
        return candidate
    return Path.cwd()


REPO_DIR = _repo_dir()
# The package whose source the suite imports via `../src/...`, and whose
# relative `./helpers/...` imports must resolve. The suite must execute from
# inside this package's `test/` directory.
PACKAGE_DIR = REPO_DIR / "packages" / "coding-agent"
TEST_HOST_DIR = PACKAGE_DIR / "test"

# Scenario -> stable substring of the subject test's human-readable name. Each
# tuple becomes one case. Substrings are matched (not equality) so cosmetic
# wording drift in a test title never silently drops a scenario.
PROVIDERS = ("telegram", "discord", "slack")
SETUP_CHANGES: list[tuple[str, str]] = [
    ("telegram_bot_token", "a Telegram bot token rotation withholds"),
    ("discord_bot_token", "a Discord bot token rotation withholds"),
    ("discord_channel", "a Discord channel change withholds"),
    ("slack_bot_token", "a Slack bot token rotation withholds"),
    ("slack_app_token", "a Slack app token rotation withholds"),
    ("slack_channel", "a Slack channel change withholds"),
    ("slack_authorized_user", "a Slack authorized-user change withholds"),
    ("discord_redaction_on", "turning redaction on with Discord withholds"),
    ("discord_verbosity", "a verbosity change with Discord withholds"),
    ("slack_redaction_off", "turning redaction off with Slack withholds"),
    ("slack_verbosity", "a verbosity change with Slack withholds"),
]
SCENARIOS: list[tuple[str, str]] = [
    *[(f"wedged_daemon_never_blocks_startup_{p}", f"settles while the {p} daemon ensure stays wedged") for p in PROVIDERS],
    *[(f"crashed_daemon_never_blocks_startup_{p}", f"settle when the {p} daemon ensure rejects") for p in PROVIDERS],
    *[(f"stuck_daemon_recovers_by_itself_{p}", f"once a stuck {p} daemon answers") for p in PROVIDERS],
    ("blocked_identity_degrades_delivery_only", "telegram daemon that refuses the identity leaves session open and close working"),
    ("credential_rotation_reproves", "same-length telegram token change on session_start asks the daemon again"),
    ("delivery_only_change_reuses_outcome", "telegram-only redaction and verbosity change on session_start does not ask the daemon again"),
    ("identity_change_withholds_adapters", "a Telegram chat change withholds notifications"),
    *[(f"setup_change_withholds_{name}", needle) for name, needle in SETUP_CHANGES],
    *[(f"late_old_answer_ignored_{p}", f"a late answer for the old {p} setup does not turn notifications on") for p in PROVIDERS],
    *[(f"confirmed_setup_not_rechecked_{p}", f"a confirmed {p} setup is not sent back to the daemon") for p in PROVIDERS],
    ("presentation_policy_identity_telegram", "telegram-only redaction change on reconcile does not ask the daemon again"),
]

# Ceiling for one bun run of the whole suite. Passing cases settle in seconds;
# a case whose session open or reconcile never settles waits out its own 8-15s
# limit plus the cleanup hook, so a tree where most cases hang needs a few
# minutes. Kept inside the [pytest] timeout in verify.toml.
BUN_TIMEOUT_SEC = 420


def _run_suite() -> dict[str, bool]:
    """Run the subject suite once through ``bun test`` and return {name: passed}.

    The suite file is copied into the package's own ``test/`` directory so its
    relative imports resolve against the real source tree, executed there, then
    removed. Results come from the structured report; a non-structured run falls
    back to the console markers.
    """
    if shutil.which("bun") is None:
        pytest.fail("bun is not on PATH; the repository's test runtime is unavailable")
    if not SUBJECT_TEST.is_file():
        pytest.fail(f"subject suite missing at {SUBJECT_TEST}")
    if not TEST_HOST_DIR.is_dir():
        pytest.fail(f"package test directory missing at {TEST_HOST_DIR}")

    injected = TEST_HOST_DIR / "zz-verify-daemon-isolation.test.ts"
    report_dir = Path(tempfile.mkdtemp(prefix="daemon-isolation-report-"))
    report_path = report_dir / "report.xml"
    try:
        shutil.copyfile(SUBJECT_TEST, injected)
        env = {
            **os.environ,
            "GJC_NOTIFICATIONS": "1",
            "BUN_CONFIG_NO_CLEAR_TERMINAL": "1",
        }
        # Path is relative to cwd (the package dir) so bun runs exactly this
        # file; the structured JUnit report is written outside the repo tree so
        # it can never land in a diff.
        rel = injected.relative_to(PACKAGE_DIR).as_posix()
        cmd = [
            "bun",
            "test",
            rel,
            "--reporter=junit",
            f"--reporter-outfile={report_path}",
        ]
        try:
            proc = subprocess.run(
                cmd,
                cwd=str(PACKAGE_DIR),
                env=env,
                capture_output=True,
                text=True,
                timeout=BUN_TIMEOUT_SEC,
                check=False,
            )
        except subprocess.TimeoutExpired as exc:
            # A run that never finishes reports every scenario as not run, so
            # each one fails instead of raising an infrastructure error.
            print(f"bun test timed out after {BUN_TIMEOUT_SEC}s:\n{exc.stdout or ''}\n{exc.stderr or ''}")
            return {}

        print("=== bun test stdout ===")
        print(proc.stdout)
        print("=== bun test stderr ===")
        print(proc.stderr)

        results = _parse_junit(report_path)
        if not results:
            results = _parse_console(proc.stdout + "\n" + proc.stderr)
        return results
    finally:
        injected.unlink(missing_ok=True)
        shutil.rmtree(report_dir, ignore_errors=True)


def _parse_junit(path: Path) -> dict[str, bool]:
    if not path.is_file():
        return {}
    try:
        root = ET.parse(str(path)).getroot()  # noqa: S314 - trusted local report
    except ET.ParseError:
        return {}
    results: dict[str, bool] = {}
    for tc in root.iter("testcase"):
        name = tc.get("name", "")
        if not name:
            continue
        failed = tc.find("failure") is not None or tc.find("error") is not None
        # A test may appear once; if duplicated, a failure wins.
        results[name] = results.get(name, True) and not failed
    return results


_CONSOLE_RE = re.compile(r"^\s*\((pass|fail|skip|todo)\)\s+(.*?)(?:\s+\[[0-9.]+m?s\])?\s*$")


def _parse_console(output: str) -> dict[str, bool]:
    """Fallback parse of ``bun test`` console lines: ``(pass) <name>`` etc."""
    results: dict[str, bool] = {}
    for line in output.splitlines():
        m = _CONSOLE_RE.match(line)
        if not m:
            continue
        status, name = m.group(1), m.group(2).strip()
        # bun prefixes the test name with the file/suite via `>`; keep the tail.
        name = name.split(" > ")[-1].strip()
        passed = status in ("pass", "skip", "todo")
        results[name] = results.get(name, True) and passed
    return results


@pytest.fixture(scope="session")
def suite_results() -> dict[str, bool]:
    return _run_suite()


def _match(results: dict[str, bool], needle: str) -> bool | None:
    for name, passed in results.items():
        if needle in name:
            return passed
    return None


@pytest.mark.parametrize("criterion,needle", SCENARIOS, ids=[s[0] for s in SCENARIOS])
def test_behavioral_scenario(suite_results: dict[str, bool], criterion: str, needle: str) -> None:
    outcome = _match(suite_results, needle)
    if outcome is None:
        observed = "\n".join(sorted(suite_results)) or "(no scenarios reported)"
        pytest.fail(
            f"scenario '{criterion}' did not run. Expected a test matching "
            f"'{needle}'. Observed scenarios:\n{observed}"
        )
    assert outcome, f"scenario '{criterion}' failed (test matching '{needle}')"


def test_full_suite_reported(suite_results: dict[str, bool]) -> None:
    """Guard that the whole suite ran and no scenario silently vanished."""
    missing = [crit for crit, needle in SCENARIOS if _match(suite_results, needle) is None]
    assert not missing, (
        "the daemon-isolation suite did not report every scenario; missing: "
        + ", ".join(missing)
    )
