/**
 * Session lifecycle with an unhealthy chat-notification daemon.
 *
 * The chat daemons (Telegram, Discord, Slack) are optional notification
 * adapters. Opening and closing a session must settle and publish the core SDK
 * endpoint whatever state the daemon is in: stuck (its ensure never settles),
 * crashed (its ensure rejects) or refusing the configured identity. Delivery
 * runs only under a configuration the daemon has confirmed, comes on by itself
 * once a stuck daemon answers, and is withheld while a changed configuration
 * waits for confirmation.
 */
import { afterEach, expect, test } from "bun:test";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { getNotificationConfig } from "../src/sdk/bus/config";
import { createNotificationsExtension } from "../src/sdk/bus/index";
import { NotificationSessionController } from "../src/sdk/bus/session-control";
import {
	cleanupFixtureRoot,
	createNotificationFixtureRoot,
	type FixtureRootCleanup,
	isolatedNotificationSettings,
	registerNotificationRuntime,
} from "./helpers/notification-settings";

const TOKEN = "1234567890:ABCDEFghijkLmnOpQrsTuvWxYz012345678";
type Handler = (event: unknown, ctx: unknown) => unknown;
type Provider = "telegram" | "discord" | "slack";

const PROVIDER_SETTINGS: Record<Provider, Record<string, unknown>> = {
	telegram: {
		"notifications.enabled": true,
		"notifications.telegram.botToken": TOKEN,
		"notifications.telegram.chatId": "12345",
	},
	discord: {
		"notifications.enabled": true,
		"notifications.discord.botToken": "discord-token-0001",
		"notifications.discord.applicationId": "app",
		"notifications.discord.guildId": "guild",
		"notifications.discord.parentChannelId": "parent",
	},
	slack: {
		"notifications.enabled": true,
		"notifications.slack.botToken": "slack-bot-token-0001",
		"notifications.slack.appToken": "slack-app-token-0001",
		"notifications.slack.workspaceId": "workspace",
		"notifications.slack.channelId": "channel",
	},
};

const cleanups: FixtureRootCleanup[] = [];
let restoreEnv: (() => void) | undefined;
afterEach(async () => {
	restoreEnv?.();
	restoreEnv = undefined;
	for (const cleanup of cleanups.splice(0)) await cleanupFixtureRoot(cleanup);
});

function enableNotificationsEnv(): void {
	const prev = process.env.GJC_NOTIFICATIONS;
	process.env.GJC_NOTIFICATIONS = "1";
	restoreEnv = () => {
		if (prev === undefined) delete process.env.GJC_NOTIFICATIONS;
		else process.env.GJC_NOTIFICATIONS = prev;
	};
}

async function createIsolationHarness(input: {
	prefix: string;
	ensureTelegramDaemon?: (input: {
		settings: unknown;
	}) => Promise<"owner_spawned" | "attached" | "disabled" | "blocked">;
	ensureProviderDaemon?: (provider: "discord" | "slack", settings: unknown) => Promise<unknown>;
	settingsOverrides?: Record<string, unknown>;
}) {
	const cwd = fs.mkdtempSync(path.join(os.tmpdir(), input.prefix));
	const agentDir = path.join(cwd, ".gjc", "agent");
	const cleanup = await createNotificationFixtureRoot(cwd, agentDir);
	cleanups.push(cleanup);
	const settings = isolatedNotificationSettings(agentDir, input.settingsOverrides ?? PROVIDER_SETTINGS.telegram);
	const handlers = new Map<string, Handler>();
	const api = {
		on: (event: string, handler: Handler) => handlers.set(event, handler),
		registerCommand: () => {},
		sendUserMessage: async () => {},
	} as never;
	const controller = new NotificationSessionController({
		eligible: true,
		getConfig: () => getNotificationConfig(settings),
	});
	createNotificationsExtension(api, {
		settings,
		controller,
		...(input.ensureTelegramDaemon ? { ensureTelegramDaemon: input.ensureTelegramDaemon as never } : {}),
		...(input.ensureProviderDaemon ? { ensureProviderDaemon: input.ensureProviderDaemon as never } : {}),
	});
	const sid = `${input.prefix}${process.pid}-${Date.now()}-${Math.random().toString(36).slice(2)}`;
	const ctx = {
		cwd,
		sessionManager: {
			getSessionId: () => sid,
			getSessionName: () => "Isolation",
			getArtifactsDir: () => cwd,
			getCwd: () => cwd,
		},
	} as never;
	registerNotificationRuntime(cleanup, {
		key: "daemon-isolation-session",
		shutdown: async () => {
			await handlers.get("session_shutdown")?.({ type: "session_shutdown" }, ctx);
		},
	});
	return {
		handlers,
		ctx,
		settings,
		controller,
		endpoint: path.join(cwd, ".gjc", "state", "sdk", `${sid}.json`),
	};
}

/**
 * Builds a harness whose only configured provider is `provider`, with `ensure`
 * installed on that provider's daemon hook. `ensure` returns the value the
 * daemon answers with ("attached" when it accepts the configuration).
 */
function createProviderHarness(provider: Provider, prefix: string, ensure: () => Promise<unknown>, overrides = {}) {
	const settingsOverrides = { ...PROVIDER_SETTINGS[provider], ...overrides };
	if (provider === "telegram") {
		return createIsolationHarness({
			prefix,
			settingsOverrides,
			ensureTelegramDaemon: ensure as never,
		});
	}
	return createIsolationHarness({
		prefix,
		settingsOverrides,
		ensureProviderDaemon: async name => (name === provider ? await ensure() : "attached"),
	});
}

async function settlesWithin<T>(work: Promise<T> | T, ms: number): Promise<"settled" | "hung"> {
	return await Promise.race([
		Promise.resolve(work).then(
			() => "settled" as const,
			() => "settled" as const,
		),
		Bun.sleep(ms).then(() => "hung" as const),
	]);
}

async function waitFor(condition: () => boolean, ms = 8_000): Promise<void> {
	const deadline = Date.now() + ms;
	while (!condition() && Date.now() < deadline) await Bun.sleep(25);
}

/** Watches `running` for `ms` and reports whether it was ever true. */
async function everRunningWithin(harness: { controller: NotificationSessionController; ctx: never }, ms: number) {
	const deadline = Date.now() + ms;
	let seen = harness.controller.query(harness.ctx).running;
	while (!seen && Date.now() < deadline) {
		await Bun.sleep(25);
		seen = harness.controller.query(harness.ctx).running;
	}
	return seen;
}

for (const provider of ["telegram", "discord", "slack"] as const) {
	test(`an awaited session_start settles while the ${provider} daemon ensure stays wedged`, async () => {
		enableNotificationsEnv();
		let ensureCalls = 0;
		// This ensure never settles for the whole test.
		const wedge = Promise.withResolvers<"attached">();
		const harness = await createProviderHarness(provider, `gjc-daemon-wedge-${provider}-`, () => {
			ensureCalls += 1;
			return wedge.promise;
		});

		const started = await settlesWithin(
			harness.handlers.get("session_start")!({ type: "session_start" }, harness.ctx),
			15_000,
		);
		expect(started).toBe("settled");
		expect(fs.existsSync(harness.endpoint)).toBe(true);
		await waitFor(() => ensureCalls > 0, 5_000);
		expect(ensureCalls).toBeGreaterThan(0);

		const shutdown = await settlesWithin(
			harness.handlers.get("session_shutdown")!({ type: "session_shutdown" }, harness.ctx),
			15_000,
		);
		expect(shutdown).toBe("settled");
		wedge.resolve("attached");
	}, 60_000);

	test(`session_start and session_shutdown settle when the ${provider} daemon ensure rejects`, async () => {
		enableNotificationsEnv();
		let ensureCalls = 0;
		const harness = await createProviderHarness(provider, `gjc-daemon-crash-${provider}-`, async () => {
			ensureCalls += 1;
			throw new Error(`${provider} daemon exited before answering`);
		});

		// Awaited directly: a rejected session_start fails this test.
		await harness.handlers.get("session_start")!({ type: "session_start" }, harness.ctx);
		expect(fs.existsSync(harness.endpoint)).toBe(true);
		await waitFor(() => ensureCalls > 0);
		expect(ensureCalls).toBeGreaterThan(0);
		// The daemon never confirmed this configuration, so nothing is delivered.
		expect(await everRunningWithin(harness, 1_000)).toBe(false);

		const shutdown = await settlesWithin(
			harness.handlers.get("session_shutdown")!({ type: "session_shutdown" }, harness.ctx),
			15_000,
		);
		expect(shutdown).toBe("settled");
	}, 60_000);

	test(`notifications come on by themselves once a stuck ${provider} daemon answers`, async () => {
		enableNotificationsEnv();
		let ensureCalls = 0;
		const stuck = Promise.withResolvers<void>();
		const harness = await createProviderHarness(provider, `gjc-daemon-recover-${provider}-`, async () => {
			ensureCalls += 1;
			await stuck.promise;
			return "attached";
		});

		const started = await settlesWithin(
			harness.handlers.get("session_start")!({ type: "session_start" }, harness.ctx),
			15_000,
		);
		expect(started).toBe("settled");
		await waitFor(() => ensureCalls > 0);
		expect(ensureCalls).toBeGreaterThan(0);
		expect(harness.controller.query(harness.ctx).running).toBe(false);

		// The daemon answers. No further session event is sent.
		stuck.resolve();
		await waitFor(() => harness.controller.query(harness.ctx).running);
		expect(harness.controller.query(harness.ctx).running).toBe(true);
	}, 60_000);
}

test("a telegram daemon that refuses the identity leaves session open and close working with notifications off", async () => {
	enableNotificationsEnv();
	let ensureCalls = 0;
	const harness = await createIsolationHarness({
		prefix: "gjc-daemon-blocked-",
		ensureTelegramDaemon: async () => {
			ensureCalls += 1;
			return "blocked";
		},
	});
	// Awaited directly: a rejected session_start fails this test.
	await harness.handlers.get("session_start")!({ type: "session_start" }, harness.ctx);
	expect(fs.existsSync(harness.endpoint)).toBe(true);
	await waitFor(() => ensureCalls > 0);
	expect(ensureCalls).toBeGreaterThan(0);
	// The daemon refused this identity, so nothing is delivered.
	expect(await everRunningWithin(harness, 1_000)).toBe(false);

	const shutdown = await settlesWithin(
		harness.handlers.get("session_shutdown")!({ type: "session_shutdown" }, harness.ctx),
		15_000,
	);
	expect(shutdown).toBe("settled");
}, 60_000);

test("a same-length telegram token change on session_start asks the daemon again", async () => {
	enableNotificationsEnv();
	const rotated = `9876543210:${"Z".repeat(TOKEN.length - "9876543210:".length)}`;
	expect(rotated).toHaveLength(TOKEN.length);
	let ensureCalls = 0;
	const harness = await createIsolationHarness({
		prefix: "gjc-daemon-rotate-",
		ensureTelegramDaemon: async () => {
			ensureCalls += 1;
			return "attached";
		},
	});
	await harness.handlers.get("session_start")!({ type: "session_start" }, harness.ctx);
	await waitFor(() => ensureCalls >= 1);
	const afterStart = ensureCalls;
	expect(afterStart).toBeGreaterThanOrEqual(1);

	// After the token changes, the daemon is asked again.
	harness.settings.set("notifications.telegram.botToken", rotated);
	await harness.handlers.get("session_start")!({ type: "session_start" }, harness.ctx);
	await waitFor(() => ensureCalls > afterStart);
	expect(ensureCalls).toBeGreaterThan(afterStart);
}, 60_000);

test("a telegram-only redaction and verbosity change on session_start does not ask the daemon again", async () => {
	enableNotificationsEnv();
	let ensureCalls = 0;
	const harness = await createIsolationHarness({
		prefix: "gjc-daemon-delivery-only-",
		ensureTelegramDaemon: async () => {
			ensureCalls += 1;
			return "attached";
		},
	});
	await harness.handlers.get("session_start")!({ type: "session_start" }, harness.ctx);
	await waitFor(() => harness.controller.query(harness.ctx).running);
	const settledCalls = ensureCalls;
	expect(settledCalls).toBeGreaterThanOrEqual(1);

	// Telegram-only setup: redaction and verbosity change, nothing else.
	harness.settings.set("notifications.redact", true);
	harness.settings.set("notifications.verbosity", "verbose");
	await harness.handlers.get("session_start")!({ type: "session_start" }, harness.ctx);
	await Bun.sleep(2_000);
	expect(ensureCalls).toBe(settledCalls);
}, 60_000);

test("a Telegram chat change withholds notifications until the daemon confirms the new setup", async () => {
	enableNotificationsEnv();
	let defer = false;
	const entered = Promise.withResolvers<void>();
	const release = Promise.withResolvers<void>();
	const harness = await createIsolationHarness({
		prefix: "gjc-daemon-reproof-",
		ensureTelegramDaemon: async () => {
			if (!defer) return "attached";
			entered.resolve();
			await release.promise;
			return "attached";
		},
	});
	await harness.handlers.get("session_start")!({ type: "session_start" }, harness.ctx);
	await waitFor(() => harness.controller.query(harness.ctx).running);
	expect(harness.controller.query(harness.ctx).running).toBe(true);

	// The destination chat changes.
	defer = true;
	harness.settings.set("notifications.telegram.chatId", "99999");
	const settled = await settlesWithin(harness.controller.reconcileCurrentSession(harness.ctx), 8_000);
	expect(settled).toBe("settled");
	await Promise.race([
		entered.promise,
		Bun.sleep(5_000).then(() => {
			throw new Error("the daemon was not asked to confirm the new configuration");
		}),
	]);
	// Nothing is delivered while the new configuration is unconfirmed.
	expect(harness.controller.query(harness.ctx).running).toBe(false);

	// Once the daemon confirms it, delivery comes back.
	release.resolve();
	await waitFor(() => harness.controller.query(harness.ctx).running);
	expect(harness.controller.query(harness.ctx).running).toBe(true);
}, 60_000);

/**
 * Setup changes on every provider: each one stops delivery until the daemon
 * confirms the new setup, then delivery resumes. Token rotations keep the
 * token length, so only the value differs.
 */
for (const scenario of [
	{
		name: "a Telegram bot token rotation",
		provider: "telegram",
		initial: {},
		key: "notifications.telegram.botToken",
		value: `9876543210:${"Q".repeat(TOKEN.length - "9876543210:".length)}`,
	},
	{
		name: "a Discord bot token rotation",
		provider: "discord",
		initial: {},
		key: "notifications.discord.botToken",
		value: "discord-token-0002",
	},
	{
		name: "a Discord channel change",
		provider: "discord",
		initial: {},
		key: "notifications.discord.parentChannelId",
		value: "parent-2",
	},
	{
		name: "a Slack bot token rotation",
		provider: "slack",
		initial: {},
		key: "notifications.slack.botToken",
		value: "slack-bot-token-0002",
	},
	{
		name: "a Slack app token rotation",
		provider: "slack",
		initial: {},
		key: "notifications.slack.appToken",
		value: "slack-app-token-0002",
	},
	{
		name: "a Slack channel change",
		provider: "slack",
		initial: {},
		key: "notifications.slack.channelId",
		value: "channel-2",
	},
	{
		name: "a Slack authorized-user change",
		provider: "slack",
		initial: { "notifications.slack.authorizedUserId": "U-original" },
		key: "notifications.slack.authorizedUserId",
		value: "U-rotated",
	},
	{
		name: "turning redaction on with Discord",
		provider: "discord",
		initial: { "notifications.redact": false },
		key: "notifications.redact",
		value: true,
	},
	{
		name: "a verbosity change with Discord",
		provider: "discord",
		initial: { "notifications.verbosity": "lean" },
		key: "notifications.verbosity",
		value: "verbose",
	},
	{
		name: "turning redaction off with Slack",
		provider: "slack",
		initial: { "notifications.redact": true },
		key: "notifications.redact",
		value: false,
	},
	{
		name: "a verbosity change with Slack",
		provider: "slack",
		initial: { "notifications.verbosity": "lean" },
		key: "notifications.verbosity",
		value: "verbose",
	},
] as const) {
	test(`${scenario.name} withholds notifications until the daemon confirms the new setup`, async () => {
		enableNotificationsEnv();
		let ensureCalls = 0;
		let defer = false;
		const entered = Promise.withResolvers<void>();
		const release = Promise.withResolvers<void>();
		const harness = await createProviderHarness(
			scenario.provider,
			`gjc-daemon-setup-${scenario.provider}-`,
			async () => {
				ensureCalls += 1;
				if (!defer) return "attached";
				entered.resolve();
				await release.promise;
				return "attached";
			},
			scenario.initial,
		);
		await harness.handlers.get("session_start")!({ type: "session_start" }, harness.ctx);
		await waitFor(() => harness.controller.query(harness.ctx).running);
		expect(harness.controller.query(harness.ctx).running).toBe(true);
		const afterStart = ensureCalls;

		defer = true;
		harness.settings.set(scenario.key, scenario.value);
		const settled = await settlesWithin(harness.controller.reconcileCurrentSession(harness.ctx), 8_000);
		expect(settled).toBe("settled");
		await Promise.race([
			entered.promise,
			Bun.sleep(5_000).then(() => {
				throw new Error("the daemon was not asked to confirm the new setup");
			}),
		]);
		expect(ensureCalls).toBeGreaterThan(afterStart);
		expect(harness.controller.query(harness.ctx).running).toBe(false);

		release.resolve();
		await waitFor(() => harness.controller.query(harness.ctx).running);
		expect(harness.controller.query(harness.ctx).running).toBe(true);
	}, 60_000);
}

/**
 * The daemon is still working on the setup the session started with when that
 * setup changes. Its late answer for the old setup must not turn notifications
 * on; only an answer given after the change does.
 */
for (const scenario of [
	{ provider: "telegram", key: "notifications.telegram.chatId", value: "77777" },
	{ provider: "discord", key: "notifications.discord.parentChannelId", value: "parent-late" },
	{ provider: "slack", key: "notifications.slack.botToken", value: "slack-bot-token-0003" },
] as const) {
	test(`a late answer for the old ${scenario.provider} setup does not turn notifications on after a setup change`, async () => {
		enableNotificationsEnv();
		const answers: Array<() => void> = [];
		const harness = await createProviderHarness(
			scenario.provider,
			`gjc-daemon-late-${scenario.provider}-`,
			() =>
				new Promise(resolve => {
					answers.push(() => resolve("attached"));
				}),
		);
		const started = await settlesWithin(
			harness.handlers.get("session_start")!({ type: "session_start" }, harness.ctx),
			15_000,
		);
		expect(started).toBe("settled");
		await waitFor(() => answers.length > 0);
		const forOldSetup = answers.length;
		expect(forOldSetup).toBeGreaterThan(0);
		expect(harness.controller.query(harness.ctx).running).toBe(false);

		harness.settings.set(scenario.key, scenario.value);
		const settled = await settlesWithin(harness.controller.reconcileCurrentSession(harness.ctx), 8_000);
		expect(settled).toBe("settled");

		// The daemon now accepts the setup it was asked about before the change.
		for (const answer of answers.slice(0, forOldSetup)) answer();
		expect(await everRunningWithin(harness, 1_000)).toBe(false);

		// It is asked about the new setup and accepts that too.
		await waitFor(() => answers.length > forOldSetup);
		expect(answers.length).toBeGreaterThan(forOldSetup);
		for (const answer of answers.slice(forOldSetup)) answer();
		await waitFor(() => harness.controller.query(harness.ctx).running);
		expect(harness.controller.query(harness.ctx).running).toBe(true);
	}, 60_000);
}

for (const provider of ["telegram", "discord", "slack"] as const) {
	test(`a confirmed ${provider} setup is not sent back to the daemon on later session events`, async () => {
		enableNotificationsEnv();
		let ensureCalls = 0;
		const harness = await createProviderHarness(provider, `gjc-daemon-confirmed-${provider}-`, async () => {
			ensureCalls += 1;
			return "attached";
		});
		await harness.handlers.get("session_start")!({ type: "session_start" }, harness.ctx);
		await waitFor(() => harness.controller.query(harness.ctx).running);
		expect(harness.controller.query(harness.ctx).running).toBe(true);
		const confirmedCalls = ensureCalls;
		expect(confirmedCalls).toBeGreaterThanOrEqual(1);

		// Nothing in the setup changes.
		await harness.handlers.get("session_start")!({ type: "session_start" }, harness.ctx);
		await harness.controller.reconcileCurrentSession(harness.ctx);
		await harness.controller.reconcileCurrentSession(harness.ctx);
		await Bun.sleep(2_000);
		expect(ensureCalls).toBe(confirmedCalls);
		expect(harness.controller.query(harness.ctx).running).toBe(true);
	}, 60_000);
}

test("a telegram-only redaction change on reconcile does not ask the daemon again", async () => {
	enableNotificationsEnv();
	let ensureCalls = 0;
	const harness = await createIsolationHarness({
		prefix: "gjc-daemon-redact-tg-",
		ensureTelegramDaemon: async () => {
			ensureCalls += 1;
			return "attached";
		},
	});
	await harness.handlers.get("session_start")!({ type: "session_start" }, harness.ctx);
	await waitFor(() => harness.controller.query(harness.ctx).running);
	const afterStart = ensureCalls;
	expect(afterStart).toBeGreaterThanOrEqual(1);

	harness.settings.set("notifications.redact", true);
	await harness.controller.reconcileCurrentSession(harness.ctx);
	await Bun.sleep(2_000);
	expect(ensureCalls).toBe(afterStart);
}, 60_000);
