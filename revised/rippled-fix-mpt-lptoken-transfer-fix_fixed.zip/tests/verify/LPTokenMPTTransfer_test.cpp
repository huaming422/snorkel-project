// AMM LPToken movement when a pool asset is an MPT without CanTransfer.
// This suite is separate from the existing LPTokenTransfer suite and runs
// under its own name.
//
// Every case goes through the jtx transaction interface (Env, pay, offer) and
// checks result codes, LPToken balances and the order book. No internal
// helper is named, so the checks hold however the restriction is wired in.

#include <test/jtx/AMM.h>
#include <test/jtx/AMMTest.h>
#include <test/jtx/Env.h>
#include <test/jtx/TestHelpers.h>
#include <test/jtx/amount.h>
#include <test/jtx/mpt.h>
#include <test/jtx/offer.h>
#include <test/jtx/pay.h>
#include <test/jtx/ter.h>
#include <test/jtx/trust.h>
#include <test/jtx/txflags.h>

#include <xrpl/beast/unit_test/suite.h>
#include <xrpl/protocol/Feature.h>
#include <xrpl/protocol/TER.h>
#include <xrpl/protocol/TxFlags.h>

#include <cstdint>

namespace xrpl::test {

class LPTokenMPTTransfer_test : public jtx::AMMTest
{
    // A direct LPToken payment between two non-issuer holders is blocked when
    // a pool asset is an MPT without CanTransfer. The payment fails with a
    // final tec code and no LPTokens move. tecNO_AUTH (the MPT transfer check)
    // and tecPATH_DRY (the result a frozen pool asset gives) are both
    // accepted. With CanTransfer set the payment goes through. Payments from
    // the MPT issuer always work, since the issuer seeds the pool. Both pool
    // asset orderings are covered.
    void
    testDirectPayment(FeatureBitset features)
    {
        testcase("MPT LPToken direct payment");

        using namespace jtx;

        // An MPT can only be an AMM pool asset once featureMPTokensV2 is
        // active, so these cases need it.
        if (!features[featureMPTokensV2])
            return;

        auto run = [&](std::uint32_t mptFlags, bool poolXrpToBtc) {
            Env env{*this, features};
            env.fund(XRP(30'000), gw_, alice_, bob_);
            env.close();

            // gw is the MPT issuer; it may seed the pool regardless of whether
            // the MPT permits third-party transfers.
            MPT const btc = MPTTester(
                {.env = env,
                 .issuer = gw_,
                 .holders = {alice_},
                 .pay = 1'000,
                 .flags = mptFlags});

            auto const asset1 = poolXrpToBtc ? XRP(10'000) : btc(10'000);
            auto const asset2 = poolXrpToBtc ? btc(10'000) : XRP(10'000);
            AMM const amm(env, gw_, asset1, asset2);
            auto const lpIssue = amm.lptIssue();

            env.trust(STAmount{lpIssue, 100'000}, alice_);
            env.trust(STAmount{lpIssue, 100'000}, bob_);
            env.close();

            // gw is the pool MPT's issuer, so it can pay LPTokens to alice
            // even without CanTransfer.
            env(pay(gw_, alice_, STAmount{lpIssue, 1'000}));
            env.close();
            BEAST_EXPECT(amm.expectLPTokens(alice_, IOUAmount{1'000, 0}));

            if ((mptFlags & tfMPTCanTransfer) != 0u)
            {
                // The pool MPT allows transfers, so the holder-to-holder
                // payment goes through.
                env(pay(alice_, bob_, STAmount{lpIssue, 100}));
                env.close();
                BEAST_EXPECT(amm.expectLPTokens(alice_, IOUAmount{900, 0}));
                BEAST_EXPECT(amm.expectLPTokens(bob_, IOUAmount{100, 0}));
            }
            else
            {
                // The pool MPT forbids transfers between holders, so the
                // payment fails and both balances stay where they were.
                env(pay(alice_, bob_, STAmount{lpIssue, 100}), Ter(std::ignore));
                auto const result = env.ter();
                BEAST_EXPECTS(
                    result == tecNO_AUTH || result == tecPATH_DRY,
                    "blocked LPToken payment returned " + transToken(result));
                env.close();
                BEAST_EXPECT(amm.expectLPTokens(alice_, IOUAmount{1'000, 0}));
                BEAST_EXPECT(amm.expectLPTokens(bob_, IOUAmount{0, 0}));
            }
        };

        // Without CanTransfer the payment is blocked, with it the payment
        // goes through. Both pool asset orderings.
        run(tfMPTCanTrade, true);
        run(tfMPTCanTrade, false);
        run(tfMPTCanTrade | tfMPTCanTransfer, true);
        run(tfMPTCanTrade | tfMPTCanTransfer, false);
    }

    // Same order book result as a frozen pool asset. A pool MPT without
    // CanTransfer leaves the holder's LPTokens unspendable, so a sell offer
    // funded by them fails with tecUNFUNDED_OFFER and no offer is created.
    // With CanTransfer the offer is created. Both pool asset orderings are
    // covered.
    void
    testOffer(FeatureBitset features)
    {
        testcase("MPT LPToken offer funding");

        using namespace jtx;

        if (!features[featureMPTokensV2])
            return;

        auto run = [&](std::uint32_t mptFlags, bool poolXrpToBtc) {
            Env env{*this, features};
            env.fund(XRP(30'000), gw_, carol_);
            env.close();

            MPT const btc = MPTTester(
                {.env = env,
                 .issuer = gw_,
                 .holders = {carol_},
                 .pay = 1'000,
                 .flags = mptFlags});

            auto const asset1 = poolXrpToBtc ? XRP(10'000) : btc(10'000);
            auto const asset2 = poolXrpToBtc ? btc(10'000) : XRP(10'000);
            AMM const amm(env, gw_, asset1, asset2);
            auto const lpIssue = amm.lptIssue();

            env.trust(STAmount{lpIssue, 100'000}, carol_);
            env.close();

            // gw is the pool MPT's issuer, so it can pay LPTokens to carol
            // in every case.
            env(pay(gw_, carol_, STAmount{lpIssue, 1'000}));
            env.close();

            if ((mptFlags & tfMPTCanTransfer) != 0u)
            {
                // The LPTokens are spendable, so the sell offer is created.
                env(offer(carol_, XRP(10), STAmount{lpIssue, 10}),
                    Txflags(tfPassive));
                env.close();
                BEAST_EXPECT(expectOffers(env, carol_, 1));
            }
            else
            {
                // The LPTokens can't be spent, so the sell offer is unfunded
                // and never created, as with a frozen pool asset.
                env(offer(carol_, XRP(10), STAmount{lpIssue, 10}),
                    Txflags(tfPassive),
                    Ter(tecUNFUNDED_OFFER));
                env.close();
                BEAST_EXPECT(expectOffers(env, carol_, 0));
            }
        };

        run(tfMPTCanTrade, true);
        run(tfMPTCanTrade, false);
        run(tfMPTCanTrade | tfMPTCanTransfer, true);
        run(tfMPTCanTrade | tfMPTCanTransfer, false);
    }

public:
    void
    run() override
    {
        FeatureBitset const all{jtx::testableAmendments()};

        testDirectPayment(all);
        testOffer(all);
    }
};

BEAST_DEFINE_TESTSUITE(LPTokenMPTTransfer, app, xrpl);

}  // namespace xrpl::test
