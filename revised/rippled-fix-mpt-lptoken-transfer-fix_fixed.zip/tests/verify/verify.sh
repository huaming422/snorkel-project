#!/usr/bin/env bash
#
# Behavioral verifier for rippled-fix-mpt-lptoken-transfer.
#
# Builds a standalone beast unit-test suite into xrpld together with the
# current libxrpl sources, then drives AMM LPToken movement through the jtx
# transaction interface. Two suites run:
#
#   * LPTokenMPTTransfer - with a pool MPT that lacks CanTransfer, LPToken
#     payments and sell offers between non-issuer holders are blocked. With
#     CanTransfer they work, and payments from the MPT issuer always work.
#     Both pool asset orderings are covered.
#   * LPTokenTransfer - the existing suite, run again so frozen pool assets
#     and plain IOU/XRP pools keep their current behavior.
#
# The suite is copied into src/test/app, which the build picks up through a
# CONFIGURE_DEPENDS glob, so no build files change.
#
# Before the build, the script also checks that no new amendment was
# registered since the base commit. The script exits zero only when that
# check and both suites pass. It runs from /repo/rippled.

set -euo pipefail

REPO="/repo/rippled"
BUILD="${REPO}/build"
SUITE_SRC="/tests/verify/LPTokenMPTTransfer_test.cpp"
SUITE_DST="${REPO}/src/test/app/LPTokenMPTTransfer_test.cpp"

cd "${REPO}"

echo "[verify] toolchain: $(cc --version 2>&1 | head -1)"
echo "[verify] build dir: $([ -d "${BUILD}" ] && echo present || echo MISSING)"

if [ ! -d "${BUILD}" ]; then
    echo "[verify] FATAL: expected pre-configured build dir at ${BUILD}" >&2
    exit 2
fi

status=0

# rippled declares amendments with XRPL_FEATURE(Name, ...) and XRPL_FIX(Name, ...)
# lines in features.macro. Collect the names on lines added and removed since
# the base commit. Editing an existing amendment line is fine, but a name that
# only shows up on the added side is a new amendment.
BASE_REF_FILE="/var/lib/devcontainer_base_ref"
if [ ! -f "${BASE_REF_FILE}" ]; then
    echo "[verify] FATAL: base ref file ${BASE_REF_FILE} not found" >&2
    exit 2
fi
BASE="$(tr -d '[:space:]' < "${BASE_REF_FILE}")"

amendment_names() {
    sed -nE 's/^[-+][[:space:]]*XRPL_(FEATURE|FIX)[[:space:]]*\([[:space:]]*([A-Za-z0-9_]+).*/\1 \2/p' | sort -u
}
DIFF="$(git diff "${BASE}")"
ADDED="$(printf '%s\n' "${DIFF}" | grep -E '^\+[^+]' | amendment_names || true)"
REMOVED="$(printf '%s\n' "${DIFF}" | grep -E '^-[^-]' | amendment_names || true)"
NEW_AMENDMENTS="$(comm -23 <(printf '%s\n' "${ADDED}") <(printf '%s\n' "${REMOVED}") | sed '/^$/d')"

echo "[verify] checking for newly registered amendments"
if [ -n "${NEW_AMENDMENTS}" ]; then
    echo "[verify] FAIL: new amendment(s) registered:" >&2
    printf '%s\n' "${NEW_AMENDMENTS}" | sed 's/^/  /' >&2
    status=1
else
    echo "[verify] no new amendment registered"
fi

# Install the behavioral suite into the auto-globbed test tree.
cp "${SUITE_SRC}" "${SUITE_DST}"
echo "[verify] installed suite -> ${SUITE_DST}"

# Size the build to available memory: xrpld's link step is memory-heavy, and the
# container is capped at a few GB. Allow ~1 job per 2 GB, clamped to the CPU
# count, floor of 1.
CPUS="$(nproc)"
MEM_KB="$(awk '/MemTotal/ {print $2}' /proc/meminfo)"
JOBS_BY_MEM=$(( MEM_KB / (2 * 1024 * 1024) ))
JOBS="${CPUS}"
if [ "${JOBS_BY_MEM}" -lt "${JOBS}" ]; then JOBS="${JOBS_BY_MEM}"; fi
if [ "${JOBS}" -lt 1 ]; then JOBS=1; fi
echo "[verify] building xrpld with ${JOBS} job(s) (cpus=${CPUS})"

# Re-run configure so the glob sees the new test file, then build xrpld. Only
# changed libxrpl files and the suite recompile before the relink.
cmake -S . -B build -G Ninja \
    -DCMAKE_TOOLCHAIN_FILE="${BUILD}/generators/conan_toolchain.cmake" \
    -DCMAKE_BUILD_TYPE=Release -Dxrpld=ON -Dtests=ON
cmake --build build --target xrpld --parallel "${JOBS}"

XRPLD="${BUILD}/xrpld"
if [ ! -x "${XRPLD}" ]; then
    echo "[verify] FATAL: xrpld binary not built at ${XRPLD}" >&2
    exit 2
fi

echo "[verify] running new behavioral suite: LPTokenMPTTransfer"
if ! "${XRPLD}" --unittest=LPTokenMPTTransfer --unittest-jobs 1; then
    echo "[verify] FAIL: LPTokenMPTTransfer" >&2
    status=1
fi

echo "[verify] running regression suite: LPTokenTransfer"
if ! "${XRPLD}" --unittest=LPTokenTransfer --unittest-jobs 1; then
    echo "[verify] FAIL: LPTokenTransfer (regression)" >&2
    status=1
fi

if [ "${status}" -eq 0 ]; then
    echo "[verify] amendment check and all suites passed"
fi
exit "${status}"
