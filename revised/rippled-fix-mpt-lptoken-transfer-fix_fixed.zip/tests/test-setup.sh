#!/usr/bin/env bash
# Setup for rippled-fix-mpt-lptoken-transfer.
#
# No services to start and no data to seed. The image already holds the full
# Conan dependency cache for the base commit and a configured Ninja build dir
# at /repo/rippled/build (xrpld, xrpl_tests and xrpld_tests built once). Work
# in the container runs offline: incremental rebuilds reuse every third-party
# dependency and only recompile changed translation units.
#
# The verifier compiles its own beast unit-test suite into xrpld and runs it
# with `xrpld --unittest=<SuiteName>`. Everything it needs is in the image, so
# this script only prints the toolchain to make a broken environment easy to
# spot in the logs.
set -euo pipefail

echo "[test-setup] gcc:       $(gcc --version 2>&1 | head -1)"
echo "[test-setup] cmake:     $(cmake --version 2>&1 | head -1)"
echo "[test-setup] conan:     $(conan --version 2>&1 | head -1)"
echo "[test-setup] repo:      /repo/rippled"
echo "[test-setup] build dir: $([ -d /repo/rippled/build ] && echo present || echo MISSING)"
echo "[test-setup] xrpld bin: $([ -x /repo/rippled/build/xrpld ] && echo present || echo MISSING)"
echo "[test-setup] Setup complete."
