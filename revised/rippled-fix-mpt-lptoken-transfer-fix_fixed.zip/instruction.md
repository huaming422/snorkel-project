## Task

If an AMM pool holds an MPT that was issued without CanTransfer, the pool's LPTokens can still move freely between holders.
A holder who isn't the MPT issuer can pay them to someone else or use them to fund an offer, which gets around the issuer's restriction.
LPTokens should be handled the way they already are when a pool asset is frozen, where they can't be paid to another holder and can't back an offer.
Block both of those for non-issuer holders whenever any MPT in the pool doesn't allow transfers.
The MPT issuer still seeds the pool and hands out LPTokens, so transfers that involve the issuer have to keep working.
Pools whose MPT allows transfers, and pools without an MPT, should behave as they do now.
No new amendment should be registered for this change.
