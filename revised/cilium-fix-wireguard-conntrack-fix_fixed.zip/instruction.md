## Task

Since a recent Cilium upgrade, traffic that reaches our nodes through the WireGuard tunnel is no longer tracked by conntrack once it has been decrypted.
Our nodes run a default-DROP host firewall that admits traffic with `--ctstate NEW,RELATED,ESTABLISHED` rules.
Those rules no longer match anything that came out of the tunnel, so legitimate packets get dropped with no error anywhere.
SNAT to the node address is broken over the tunnel too.
When a process on one node talks to a pod on another node, the replies come back with the wrong source address and get thrown away, so things like DNS lookups from the host time out.
The same upgrade also made Cilium's own filter and nat chains accept decrypted tunnel traffic outright, whether it is meant for the node or is being forwarded through it.
Before the upgrade, Cilium left that traffic to the same rules as everything else.
The clusters are dual-stack and we see all of this on IPv4 and IPv6 alike.

Please put decrypted tunnel traffic back the way it was before the upgrade: tracked by conntrack, and not accepted by Cilium's chains on its own.
The encrypted WireGuard packets traveling between nodes should stay the way they are now, in both directions: they skip conntrack and Cilium's own iptables rules let them through.
That treatment shouldn't spread to any other traffic.

Several of our clusters run in tunnel mode with WireGuard on top, over VXLAN or Geneve, not always on the default port, and some with an IPv6 underlay.
A couple of those also encrypt node-to-node traffic and use Cilium's kube-proxy replacement, and one runs with `enableIdentityMark: false` in its Helm values.
Cross-node pod traffic has to work on every one of them, default-DROP nodes included.
Our firewall has no rules for the overlay traffic that comes out of the WireGuard tunnel, and that traffic skips conntrack like all overlay traffic, which should stay that way.
Overlay traffic that was never encrypted shouldn't get any new way through either.

Some of our other clusters use IPsec instead, and they're fine, so they should keep working exactly as they do today.
