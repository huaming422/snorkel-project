## Task

Since a recent Cilium upgrade, traffic that reaches our nodes through the WireGuard tunnel is no longer tracked by conntrack once it has been decrypted.
Our nodes run a default-DROP host firewall that admits traffic with `--ctstate NEW,RELATED,ESTABLISHED` rules.
Those rules no longer match anything that came out of the tunnel, so legitimate packets get dropped with no error anywhere.
SNAT to the node address is broken over the tunnel too.
When a process on one node talks to a pod on another node, the replies come back with the wrong source address and get thrown away, so things like DNS lookups from the host time out.
All of this worked before the upgrade.
The clusters are dual-stack and we see it on IPv4 and IPv6 alike.

Please get decrypted tunnel traffic going through conntrack again.
The encrypted WireGuard packets traveling between nodes should stay the way they are now, in both directions: they skip conntrack and Cilium's own iptables rules let them through.
That treatment shouldn't spread to any other traffic.
Some of our other clusters use IPsec instead, and they're fine, so they should keep working exactly as they do today.
