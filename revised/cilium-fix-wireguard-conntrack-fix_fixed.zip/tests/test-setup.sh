#!/usr/bin/env bash
# All deps (Go toolchain, module cache, prewarmed build cache) are baked into
# the image at the base commit. The verifier is a Go unit test that needs no
# services and no external downloads. Nothing to install at verifier time.
set -euo pipefail
echo "[test-setup] no-op for cilium-fix-wireguard-conntrack"
