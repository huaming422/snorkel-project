// SPDX-License-Identifier: Apache-2.0
// Copyright Authors of Cilium

// Behavioral checks for the host iptables rules Cilium installs on encrypted
// clusters.
//
// Each check builds an unexported *manager with a SharedConfig, runs the
// manager's full rule install (installRules) against a recording fake at the
// command interface (ip4tables / ip6tables), and then asks what the recorded
// rules do to sample packets: is the packet skipped by conntrack in the raw
// table, and is it let through by Cilium's filter or nat chains. The checks
// look at what a rule matches (protocol, ports, interfaces, packet mark,
// conntrack state), not at how it is spelled, so the selector, comment text,
// -A vs -I and the method that emits the rule are all free. Match conditions
// this file does not model (addresses, sets, other match modules) are treated
// as satisfied.
//
// The WireGuard checks run each setup the clusters use: native routing, and
// tunnel mode on VXLAN's port, Geneve's port and a non-default port.
//
// The BPF C code cannot be built in this image, so the mark the datapath
// gives an arriving WireGuard packet is read from its source (see
// wgvHostMarks). The mark only decides which packet the checks feed to the
// rules.
//
// The symbols here are prefixed wgv* to avoid colliding with the package's
// own iptables_test.go, which defines its own mock in the same package.

package iptables

import (
	"fmt"
	"log/slog"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"testing"
)

// wgvListenPort is the UDP port the WireGuard tunnel device listens on and
// sends from, on every node.
const wgvListenPort = 51871

// wgvRecorder is a fake command interface (iptablesInterface) that records
// every argument list it is asked to run, instead of shelling out.
type wgvRecorder struct {
	prog string
	cmds [][]string
}

func (r *wgvRecorder) getProg() string  { return r.prog }
func (r *wgvRecorder) getIpset() string { return "" }
func (r *wgvRecorder) getMode() string  { return "" }

func (r *wgvRecorder) runProgOutput(args []string) (string, error) {
	r.cmds = append(r.cmds, append([]string(nil), args...))
	return "", nil
}

func (r *wgvRecorder) runProg(args []string) error {
	_, err := r.runProgOutput(args)
	return err
}

// wgvInstall runs the manager's rule install for cfg and returns the parsed
// rules per family.
func wgvInstall(t *testing.T, cfg SharedConfig) ([]wgvRule, []wgvRule) {
	t.Helper()
	ip4 := &wgvRecorder{prog: "iptables"}
	ip6 := &wgvRecorder{prog: "ip6tables"}
	m := &manager{
		logger:          slog.New(slog.DiscardHandler),
		haveSocketMatch: true,
		sharedCfg:       cfg,
		ip4tables:       ip4,
		ip6tables:       ip6,
	}
	if err := m.installRules(desiredState{installRules: true}); err != nil {
		t.Fatalf("installRules returned error: %v", err)
	}
	return wgvParseAll(ip4.cmds), wgvParseAll(ip6.cmds)
}

// wgvPacket is a sample packet as netfilter sees it at one hook.
type wgvPacket struct {
	desc         string
	proto        int // IP protocol number
	sport, dport int // 0 for protocols without ports
	mark         uint32
	in, out      string // interfaces, "" when not known at that hook
	untracked    bool   // conntrack state: UNTRACKED, otherwise NEW
}

const (
	wgvTCP    = 6
	wgvUDP    = 17
	wgvICMP   = 1
	wgvICMPv6 = 58
	wgvESP    = 50
)

// wgvRule is one appended or inserted rule, reduced to what it matches.
type wgvRule struct {
	table, chain string
	target       string
	notrack      bool
	conds        []func(p wgvPacket) bool
	text         string
}

func (r wgvRule) matches(p wgvPacket) bool {
	for _, c := range r.conds {
		if !c(p) {
			return false
		}
	}
	return true
}

func wgvParseAll(cmds [][]string) []wgvRule {
	var out []wgvRule
	for _, c := range cmds {
		if r, ok := wgvParse(c); ok {
			out = append(out, r)
		}
	}
	return out
}

func wgvIsOption(tok string) bool { return tok == "!" || strings.HasPrefix(tok, "-") }

func wgvProto(v string) int {
	switch strings.ToLower(v) {
	case "all", "0":
		return 0
	case "tcp", "6":
		return wgvTCP
	case "udp", "17":
		return wgvUDP
	case "icmp", "1":
		return wgvICMP
	case "icmpv6", "ipv6-icmp", "58":
		return wgvICMPv6
	case "esp", "50":
		return wgvESP
	}
	return -1
}

// wgvPortSpec parses "a", "a:b" or a comma list of those.
func wgvPortSpec(v string) func(int) bool {
	type rng struct{ lo, hi int }
	var rs []rng
	for _, part := range strings.Split(v, ",") {
		lo, hi := part, part
		if i := strings.Index(part, ":"); i >= 0 {
			lo, hi = part[:i], part[i+1:]
		}
		l, errL := strconv.Atoi(lo)
		h, errH := strconv.Atoi(hi)
		if lo == "" {
			l, errL = 0, nil
		}
		if hi == "" {
			h, errH = 65535, nil
		}
		if errL != nil || errH != nil {
			return func(int) bool { return false }
		}
		rs = append(rs, rng{l, h})
	}
	return func(port int) bool {
		if port == 0 {
			return false
		}
		for _, r := range rs {
			if port >= r.lo && port <= r.hi {
				return true
			}
		}
		return false
	}
}

func wgvIface(v string) func(string) bool {
	if strings.HasSuffix(v, "+") {
		prefix := strings.TrimSuffix(v, "+")
		return func(name string) bool { return name != "" && strings.HasPrefix(name, prefix) }
	}
	return func(name string) bool { return name == v }
}

func wgvMark(v string) func(uint32) bool {
	val, mask := v, "0xffffffff"
	if i := strings.Index(v, "/"); i >= 0 {
		val, mask = v[:i], v[i+1:]
	}
	x, errX := strconv.ParseUint(val, 0, 32)
	m, errM := strconv.ParseUint(mask, 0, 32)
	if errX != nil || errM != nil {
		return func(uint32) bool { return false }
	}
	return func(mark uint32) bool { return mark&uint32(m) == uint32(x) }
}

// wgvState matches a conntrack state list such as "NEW,ESTABLISHED". A packet
// is UNTRACKED when a raw rule skipped conntrack for it, and NEW otherwise.
func wgvState(v string) func(wgvPacket) bool {
	states := map[string]bool{}
	for _, s := range strings.Split(strings.ToUpper(v), ",") {
		states[s] = true
	}
	return func(p wgvPacket) bool {
		if p.untracked {
			return states["UNTRACKED"]
		}
		return states["NEW"]
	}
}

// wgvParse reads one iptables argument list. Only -A/-I commands are rules;
// everything else (chain creation, listing, deletion) is ignored.
func wgvParse(args []string) (wgvRule, bool) {
	r := wgvRule{table: "filter", text: strings.Join(args, " ")}
	isRule := false
	neg := false
	add := func(c func(p wgvPacket) bool) {
		n := neg
		neg = false
		r.conds = append(r.conds, func(p wgvPacket) bool { return c(p) != n })
	}
	next := func(i *int) string {
		*i++
		if *i < len(args) {
			return args[*i]
		}
		return ""
	}
	for i := 0; i < len(args); i++ {
		tok := args[i]
		switch tok {
		case "!":
			neg = true
		case "-t", "--table":
			r.table = next(&i)
		case "-A", "--append", "-I", "--insert":
			isRule = true
			r.chain = next(&i)
			if tok == "-I" || tok == "--insert" {
				if i+1 < len(args) {
					if _, err := strconv.Atoi(args[i+1]); err == nil {
						i++
					}
				}
			}
		case "-D", "--delete", "-N", "--new-chain", "-E", "--rename-chain", "-F", "--flush",
			"-X", "--delete-chain", "-S", "--list-rules", "-L", "--list", "-P", "--policy",
			"-R", "--replace", "-Z", "--zero", "-C", "--check":
			return wgvRule{}, false
		case "-w", "--wait", "-W", "--wait-interval":
			if i+1 < len(args) && !wgvIsOption(args[i+1]) {
				i++
			}
		case "-p", "--protocol":
			want := wgvProto(next(&i))
			add(func(p wgvPacket) bool { return want == 0 || p.proto == want })
		case "--dport", "--destination-port", "--dports", "--destination-ports":
			in := wgvPortSpec(next(&i))
			add(func(p wgvPacket) bool { return in(p.dport) })
		case "--sport", "--source-port", "--sports", "--source-ports":
			in := wgvPortSpec(next(&i))
			add(func(p wgvPacket) bool { return in(p.sport) })
		case "--ports":
			in := wgvPortSpec(next(&i))
			add(func(p wgvPacket) bool { return in(p.sport) || in(p.dport) })
		case "-i", "--in-interface":
			is := wgvIface(next(&i))
			add(func(p wgvPacket) bool { return is(p.in) })
		case "-o", "--out-interface":
			is := wgvIface(next(&i))
			add(func(p wgvPacket) bool { return is(p.out) })
		case "--mark":
			is := wgvMark(next(&i))
			add(func(p wgvPacket) bool { return is(p.mark) })
		case "--ctstate", "--state":
			add(wgvState(next(&i)))
		case "-m", "--match", "--comment":
			next(&i)
			neg = false
		case "-j", "--jump":
			r.target = next(&i)
			rest := args[i+1:]
			for _, a := range rest {
				if a == "--notrack" && r.target == "CT" {
					r.notrack = true
				}
			}
			if r.target == "NOTRACK" {
				r.notrack = true
			}
			i = len(args)
		default:
			// A match option this file does not model: treat it as satisfied
			// and skip its arguments.
			neg = false
			for i+1 < len(args) && !wgvIsOption(args[i+1]) {
				i++
			}
		}
	}
	return r, isRule
}

// wgvHook maps each of Cilium's chains to the built-in chain that jumps to it.
// A rule placed directly in the built-in chain counts when a check asks that
// nothing skips or accepts a packet; when a check asks that Cilium's rules do
// skip or accept it, only Cilium's own chain counts.
var wgvHook = map[string]string{
	ciliumInputChain:     "INPUT",
	ciliumOutputChain:    "OUTPUT",
	ciliumForwardChain:   "FORWARD",
	ciliumPreRawChain:    "PREROUTING",
	ciliumOutputRawChain: "OUTPUT",
	ciliumPreNatChain:    "PREROUTING",
	ciliumPostNatChain:   "POSTROUTING",
	ciliumOutputNatChain: "OUTPUT",
}

// wgvHits lists the rules in table/chain (and, with hook, the built-in chain
// feeding it) that match p and pass the filter.
func wgvHits(rules []wgvRule, table, chain string, hook bool, p wgvPacket, want func(wgvRule) bool) []string {
	var hits []string
	for _, r := range rules {
		inChain := r.chain == chain || (hook && r.chain == wgvHook[chain])
		if r.table == table && inChain && want(r) && r.matches(p) {
			hits = append(hits, r.text)
		}
	}
	return hits
}

func wgvNotrack(r wgvRule) bool { return r.notrack }
func wgvAccept(r wgvRule) bool  { return r.target == "ACCEPT" }

// wgvWithState sets the packet's conntrack state from the raw chain it went
// through before reaching chain.
func wgvWithState(rules []wgvRule, chain string, p wgvPacket) wgvPacket {
	raw := ciliumPreRawChain
	if chain == ciliumOutputChain || chain == ciliumOutputNatChain {
		raw = ciliumOutputRawChain
	}
	p.untracked = len(wgvHits(rules, "raw", raw, false, p, wgvNotrack)) > 0
	return p
}

// wgvSkipsConntrack lists every raw rule that skips conntrack for p.
func wgvSkipsConntrack(rules []wgvRule, chain string, p wgvPacket) []string {
	return wgvHits(rules, "raw", chain, true, p, wgvNotrack)
}

// wgvCiliumSkips lists Cilium's own raw rules that skip conntrack for p.
func wgvCiliumSkips(rules []wgvRule, chain string, p wgvPacket) []string {
	return wgvHits(rules, "raw", chain, false, p, wgvNotrack)
}

// wgvAccepted lists every rule that accepts p.
func wgvAccepted(rules []wgvRule, table, chain string, p wgvPacket) []string {
	return wgvHits(rules, table, chain, true, wgvWithState(rules, chain, p), wgvAccept)
}

// wgvCiliumAccepts lists Cilium's own rules that accept p.
func wgvCiliumAccepts(rules []wgvRule, table, chain string, p wgvPacket) []string {
	return wgvHits(rules, table, chain, false, wgvWithState(rules, chain, p), wgvAccept)
}

// wgvDump lists the rules installed in one table, for failure messages.
func wgvDump(rules []wgvRule, table string) string {
	var b strings.Builder
	for _, r := range rules {
		if r.table == table {
			b.WriteString("\n  ")
			b.WriteString(r.text)
		}
	}
	return b.String()
}

type wgvFamily struct {
	name  string
	rules []wgvRule
	icmp  int
}

func wgvFamilies(t *testing.T, cfg SharedConfig) []wgvFamily {
	r4, r6 := wgvInstall(t, cfg)
	return []wgvFamily{
		{name: "IPv4", rules: r4, icmp: wgvICMP},
		{name: "IPv6", rules: r6, icmp: wgvICMPv6},
	}
}

// wgvTunnelPorts are the overlay ports of the tunnel-mode setups: VXLAN's,
// Geneve's and a non-default one.
var wgvTunnelPorts = []int{8472, 6081, 9711}

// wgvSetup is one cluster setup the WireGuard checks run.
type wgvSetup struct {
	name        string
	cfg         SharedConfig
	overlayPort int // 0 when not in tunnel mode
}

func wgvSetups() []wgvSetup {
	out := []wgvSetup{{name: "native routing",
		cfg: SharedConfig{EnableIPv4: true, EnableIPv6: true, EnableWireguard: true}}}
	for _, port := range wgvTunnelPorts {
		out = append(out, wgvSetup{name: fmt.Sprintf("tunnel mode on port %d", port),
			cfg: SharedConfig{EnableIPv4: true, EnableIPv6: true, EnableWireguard: true,
				TunnelingEnabled: true, TunnelPort: uint16(port)},
			overlayPort: port})
	}
	return out
}

func wgvTunnelSetups() []wgvSetup {
	var out []wgvSetup
	for _, s := range wgvSetups() {
		if s.overlayPort != 0 {
			out = append(out, s)
		}
	}
	return out
}

// Traffic that came out of the tunnel as it reaches the stack: several
// protocols and marks, arriving on the WireGuard device or, for host delivery,
// on cilium_host. UDP to a tunnel port that is not the setup's own overlay
// port is ordinary traffic too.
func wgvDecrypted(icmp, overlayPort int) []wgvPacket {
	marks := []uint32{0x00000d00, 0x12340d00, 0x00060d00, 0x00020d01}
	ifaces := []string{"cilium_wg0", "cilium_host"}
	var out []wgvPacket
	for _, in := range ifaces {
		for _, mark := range marks {
			out = append(out,
				wgvPacket{desc: "decrypted TCP to 10250", proto: wgvTCP, sport: 40112, dport: 10250, mark: mark, in: in},
				wgvPacket{desc: "decrypted TCP to 6443", proto: wgvTCP, sport: 51544, dport: 6443, mark: mark, in: in},
				wgvPacket{desc: "decrypted UDP to 53", proto: wgvUDP, sport: 33871, dport: 53, mark: mark, in: in},
				wgvPacket{desc: "decrypted ICMP", proto: icmp, mark: mark, in: in},
			)
			for _, port := range wgvTunnelPorts {
				if port != overlayPort {
					out = append(out, wgvPacket{desc: fmt.Sprintf("decrypted UDP to %d", port),
						proto: wgvUDP, sport: 47301, dport: port, mark: mark, in: in})
				}
			}
		}
	}
	return out
}

// Ordinary node traffic that is not WireGuard transport, including overlay
// packets that arrive unencrypted on the node's own interfaces.
func wgvPlainInbound(icmp int) []wgvPacket {
	out := []wgvPacket{
		{desc: "plain UDP to 53", proto: wgvUDP, sport: 40000, dport: 53, in: "eth0"},
		{desc: "plain TCP to 443", proto: wgvTCP, sport: 40002, dport: 443, in: "eth0"},
		{desc: "plain ICMP", proto: icmp, in: "ens5"},
	}
	for _, port := range wgvTunnelPorts {
		out = append(out,
			wgvPacket{desc: fmt.Sprintf("plain UDP to %d", port), proto: wgvUDP, sport: 40001, dport: port, in: "ens5"},
			wgvPacket{desc: fmt.Sprintf("plain UDP to %d", port), proto: wgvUDP, sport: 52113, dport: port, in: "eth0"},
		)
	}
	return out
}

func wgvPlainOutbound() []wgvPacket {
	return []wgvPacket{
		{desc: "host UDP to 53", proto: wgvUDP, sport: 40003, dport: 53, out: "eth0"},
		{desc: "host TCP to a remote pod over the tunnel", proto: wgvTCP, sport: 40004, dport: 8080, out: "cilium_wg0"},
		{desc: "host UDP to a remote pod over the tunnel", proto: wgvUDP, sport: 40005, dport: 53, out: "cilium_wg0"},
	}
}

// Overlay packets of a tunnel-mode setup after decryption, on each device the
// checks try. Whether they carry a mark depends on agent settings the iptables
// manager does not see, so each is tried with and without one.
func wgvDecryptedOverlay(port int) []wgvPacket {
	var out []wgvPacket
	for _, sport := range []int{53211, 40517} {
		for _, pm := range []struct {
			in   string
			mark uint32
		}{{"cilium_wg0", 0}, {"cilium_wg0", 0x00000d00}, {"cilium_host", 0}, {"cilium_host", 0x00060d00}} {
			out = append(out, wgvPacket{desc: fmt.Sprintf("decrypted overlay packet to %d", port),
				proto: wgvUDP, sport: sport, dport: port, mark: pm.mark, in: pm.in})
		}
	}
	return out
}

// Encrypted WireGuard transport packets between nodes. A leaving one carries
// the WireGuard device's firewall mark (0xe00). An arriving one carries
// whatever the host program gives it, see wgvArriving.
func wgvTunnelInbound(in string, mark uint32) wgvPacket {
	p := wgvPacket{desc: "arriving WireGuard packet on " + in, proto: wgvUDP,
		sport: wgvListenPort, dport: wgvListenPort, mark: mark, in: in}
	if mark != 0 {
		p.desc += fmt.Sprintf(" with mark %#x", mark)
	}
	return p
}

// wgvRepoRoot finds the repository root by walking up from the test's working
// directory to the directory that holds bpf/bpf_host.c.
func wgvRepoRoot() (string, error) {
	dir, err := os.Getwd()
	if err != nil {
		return "", err
	}
	for {
		if _, err := os.Stat(filepath.Join(dir, "bpf", "bpf_host.c")); err == nil {
			return dir, nil
		}
		parent := filepath.Dir(dir)
		if parent == dir {
			return "", os.ErrNotExist
		}
		dir = parent
	}
}

// wgvRepoFile reads a file relative to the repository root, found by walking
// up from the test's working directory.
func wgvRepoFile(rel string) ([]byte, error) {
	dir, err := os.Getwd()
	if err != nil {
		return nil, err
	}
	for {
		b, err := os.ReadFile(filepath.Join(dir, rel))
		if err == nil {
			return b, nil
		}
		parent := filepath.Dir(dir)
		if parent == dir {
			return nil, err
		}
		dir = parent
	}
}

func wgvStripComments(src string) string {
	var b strings.Builder
	for i := 0; i < len(src); i++ {
		if strings.HasPrefix(src[i:], "//") {
			j := strings.IndexByte(src[i:], '\n')
			if j < 0 {
				break
			}
			i += j - 1
			continue
		}
		if strings.HasPrefix(src[i:], "/*") {
			j := strings.Index(src[i+2:], "*/")
			if j < 0 {
				break
			}
			i += j + 3
			continue
		}
		b.WriteByte(src[i])
	}
	return b.String()
}

// wgvBPFSources returns the comment-stripped C sources under bpf/ (headers
// and programs, tests excluded), concatenated.
func wgvBPFSources() string {
	var b strings.Builder
	for _, pat := range []string{"bpf/*.c", "bpf/*.h", "bpf/lib/*.h", "bpf/include/bpf/*.h"} {
		root, err := wgvRepoRoot()
		if err != nil {
			return ""
		}
		files, _ := filepath.Glob(filepath.Join(root, pat))
		for _, f := range files {
			if raw, err := os.ReadFile(f); err == nil {
				b.WriteString(wgvStripComments(string(raw)))
				b.WriteString("\n")
			}
		}
	}
	return b.String()
}

// wgvMarkDefs reads every numeric #define in the C sources.
func wgvMarkDefs(all string) map[string]uint32 {
	defs := map[string]uint32{"MARK_MAGIC_DECRYPT": 0x0d00, "MARK_MAGIC_IDENTITY": 0x0f00}
	re := regexp.MustCompile(`#define\s+([A-Za-z_][A-Za-z0-9_]*)\s+\(?\s*(0x[0-9A-Fa-f]+|[0-9]+)\b`)
	for _, m := range re.FindAllStringSubmatch(all, -1) {
		if v, err := strconv.ParseUint(m[2], 0, 32); err == nil {
			defs[m[1]] = uint32(v)
		}
	}
	return defs
}

var wgvCall = regexp.MustCompile(`\b([a-z_][a-z0-9_]*)\s*\(`)

// wgvWithHelpers returns code followed by the bodies of the functions it
// calls, one level deep, as defined anywhere in all.
func wgvWithHelpers(code, all string) string {
	var b strings.Builder
	b.WriteString(code)
	seen := map[string]bool{"ctx_is_wireguard": true, "if": true, "likely": true, "unlikely": true}
	for _, m := range wgvCall.FindAllStringSubmatch(code, -1) {
		name := m[1]
		if seen[name] {
			continue
		}
		seen[name] = true
		def := regexp.MustCompile(`\b` + regexp.QuoteMeta(name) + `\s*\([^;{)]*\)\s*\{`)
		loc := def.FindStringIndex(all)
		if loc == nil {
			continue
		}
		depth := 0
		for e := loc[1] - 1; e < len(all); e++ {
			if all[e] == '{' {
				depth++
			} else if all[e] == '}' {
				depth--
				if depth == 0 {
					b.WriteString("\n")
					b.WriteString(all[loc[1]-1 : e+1])
					break
				}
			}
		}
	}
	return b.String()
}

var wgvMarkName = regexp.MustCompile(`MARK_MAGIC_[A-Z0-9_]+`)

var wgvMarkAssign = regexp.MustCompile(`->mark\s*\|?=\s*\(?\s*(0x[0-9A-Fa-f]+|[0-9]+|[A-Za-z_][A-Za-z0-9_]*)`)

// wgvMarkIn returns the mark that code sets: the decrypt mark for a
// set_decrypt_mark call, the value assigned to a packet mark (a number or a
// #define), or the value of the first MARK_MAGIC_* name that is not a mask.
// ok is false when code sets no mark.
func wgvMarkIn(code string, defs map[string]uint32) (mark uint32, ok bool) {
	if strings.Contains(code, "set_decrypt_mark(") {
		return defs["MARK_MAGIC_DECRYPT"], true
	}
	for _, m := range wgvMarkAssign.FindAllStringSubmatch(code, -1) {
		if v, err := strconv.ParseUint(m[1], 0, 32); err == nil {
			return uint32(v), true
		}
		if v, found := defs[m[1]]; found {
			return v, true
		}
	}
	for _, name := range wgvMarkName.FindAllString(code, -1) {
		if strings.HasSuffix(name, "_MASK") {
			continue
		}
		if v, found := defs[name]; found {
			return v, true
		}
	}
	return 0, false
}

// wgvHostMarks reports, per family ("IPv4", "IPv6"), the mark the host
// program gives an arriving WireGuard packet, read from its source together
// with the helpers that code calls. A family is missing from the map when that
// code cannot be found.
func wgvHostMarks(t *testing.T) map[string]uint32 {
	t.Helper()
	states := map[string]uint32{}
	raw, err := wgvRepoFile("bpf/bpf_host.c")
	if err != nil {
		t.Logf("bpf/bpf_host.c not readable (%v); arriving WireGuard packets are tried with and without the decrypt mark", err)
		return states
	}
	all := wgvBPFSources()
	defs := wgvMarkDefs(all)
	src := wgvStripComments(string(raw))
	type seen struct {
		mark uint32
		n    int
	}
	found := map[string]*seen{}
	for off := 0; ; {
		i := strings.Index(src[off:], "ctx_is_wireguard(")
		if i < 0 {
			break
		}
		idx := off + i
		off = idx + 1
		v6 := strings.LastIndex(src[:idx], "case bpf_htons(ETH_P_IPV6)")
		v4 := strings.LastIndex(src[:idx], "case bpf_htons(ETH_P_IP)")
		family := ""
		switch {
		case v6 > v4:
			family = "IPv6"
		case v4 > v6:
			family = "IPv4"
		}
		end := strings.Index(src[idx:], "#endif")
		if family == "" || end < 0 {
			continue
		}
		mark, _ := wgvMarkIn(wgvWithHelpers(src[idx:idx+end], all), defs)
		if s, ok := found[family]; ok {
			if s.mark != mark {
				s.n = -1
			}
			continue
		}
		found[family] = &seen{mark: mark, n: 1}
	}
	for family, s := range found {
		if s.n > 0 {
			states[family] = s.mark
		}
	}
	t.Logf("arriving WireGuard packet marks per bpf/bpf_host.c: %v", states)
	return states
}

// wgvArriving returns the arriving WireGuard packets on dev that the rules must
// handle for one family, and whether catching any one of them is enough (the
// case when the host program's marking could not be told).
func wgvArriving(states map[string]uint32, family, dev string) ([]wgvPacket, bool) {
	if mark, ok := states[family]; ok {
		return []wgvPacket{wgvTunnelInbound(dev, mark)}, false
	}
	return []wgvPacket{wgvTunnelInbound(dev, 0), wgvTunnelInbound(dev, 0x00000d00)}, true
}

// wgvHandled applies hit to each arriving packet and reports whether the
// required ones are all handled (or any one, when anyOf is set).
func wgvHandled(pkts []wgvPacket, anyOf bool, hit func(wgvPacket) bool) bool {
	n := 0
	for _, p := range pkts {
		if hit(p) {
			n++
		}
	}
	if anyOf {
		return n > 0
	}
	return n == len(pkts)
}

func wgvDescAll(pkts []wgvPacket) string {
	var d []string
	for _, p := range pkts {
		d = append(d, wgvDesc(p))
	}
	return strings.Join(d, " / ")
}

func wgvTunnelOutbound(out string) wgvPacket {
	return wgvPacket{desc: "leaving WireGuard packet on " + out, proto: wgvUDP,
		sport: wgvListenPort, dport: wgvListenPort, mark: 0x00000e00, out: out}
}

func wgvDesc(p wgvPacket) string {
	return fmt.Sprintf("%s (mark %#08x, in %q, out %q)", p.desc, p.mark, p.in, p.out)
}

// TestVerifyWireguardDecryptedTrafficIsTracked: with WireGuard on, traffic
// that came out of the tunnel after decryption, and ordinary node traffic,
// goes through conntrack. No raw-table rule skips conntrack for those packets,
// on either family, in any setup. In tunnel mode the setup's own overlay
// packets are left out here, since all overlay traffic skips conntrack.
func TestVerifyWireguardDecryptedTrafficIsTracked(t *testing.T) {
	for _, s := range wgvSetups() {
		for _, f := range wgvFamilies(t, s.cfg) {
			for _, p := range append(wgvDecrypted(f.icmp, s.overlayPort), wgvPlainInbound(f.icmp)...) {
				if s.overlayPort != 0 && p.proto == wgvUDP && p.dport == s.overlayPort {
					continue
				}
				if hits := wgvSkipsConntrack(f.rules, ciliumPreRawChain, p); len(hits) > 0 {
					t.Errorf("%s, %s: %s skips conntrack in %s via %q; rules:%s",
						s.name, f.name, wgvDesc(p), ciliumPreRawChain, hits, wgvDump(f.rules, "raw"))
				}
			}
			for _, p := range wgvPlainOutbound() {
				if hits := wgvSkipsConntrack(f.rules, ciliumOutputRawChain, p); len(hits) > 0 {
					t.Errorf("%s, %s: %s skips conntrack in %s via %q; rules:%s",
						s.name, f.name, wgvDesc(p), ciliumOutputRawChain, hits, wgvDump(f.rules, "raw"))
				}
			}
		}
	}
}

// TestVerifyWireguardDecryptedTrafficNotAccepted: with WireGuard on, Cilium's
// filter and nat chains do not accept decrypted traffic on their own, whether
// it is delivered to the node or forwarded through it, on either family, in any
// setup.
func TestVerifyWireguardDecryptedTrafficNotAccepted(t *testing.T) {
	for _, s := range wgvSetups() {
		for _, f := range wgvFamilies(t, s.cfg) {
			for _, p := range wgvDecrypted(f.icmp, s.overlayPort) {
				for _, tc := range [][2]string{{"filter", ciliumInputChain}, {"nat", ciliumPreNatChain}} {
					if hits := wgvAccepted(f.rules, tc[0], tc[1], p); len(hits) > 0 {
						t.Errorf("%s, %s: %s is accepted in %s %s via %q; rules:%s",
							s.name, f.name, wgvDesc(p), tc[0], tc[1], hits, wgvDump(f.rules, tc[0]))
					}
				}
				if p.in != "cilium_wg0" {
					continue
				}
				fwd := p
				fwd.desc += ", forwarded"
				fwd.out = "eth0"
				for _, tc := range [][2]string{{"filter", ciliumForwardChain}, {"nat", ciliumPostNatChain}} {
					if hits := wgvAccepted(f.rules, tc[0], tc[1], fwd); len(hits) > 0 {
						t.Errorf("%s, %s: %s is accepted in %s %s via %q; rules:%s",
							s.name, f.name, wgvDesc(fwd), tc[0], tc[1], hits, wgvDump(f.rules, tc[0]))
					}
				}
			}
		}
	}
}

// TestVerifyWireguardTunnelPacketsSkipConntrack: with WireGuard on, Cilium's
// raw rules make the encrypted WireGuard packets between nodes skip conntrack
// in both directions, on either family, in any setup. Arriving packets carry
// the mark the host program gives them (wgvHostMarks).
func TestVerifyWireguardTunnelPacketsSkipConntrack(t *testing.T) {
	states := wgvHostMarks(t)
	for _, s := range wgvSetups() {
		for _, f := range wgvFamilies(t, s.cfg) {
			for _, dev := range []string{"eth0", "ens5"} {
				in, anyOf := wgvArriving(states, f.name, dev)
				if !wgvHandled(in, anyOf, func(p wgvPacket) bool {
					return len(wgvCiliumSkips(f.rules, ciliumPreRawChain, p)) > 0
				}) {
					t.Errorf("%s, %s: %s is tracked in %s; rules:%s",
						s.name, f.name, wgvDescAll(in), ciliumPreRawChain, wgvDump(f.rules, "raw"))
				}
				out := wgvTunnelOutbound(dev)
				if len(wgvCiliumSkips(f.rules, ciliumOutputRawChain, out)) == 0 {
					t.Errorf("%s, %s: %s is tracked in %s; rules:%s",
						s.name, f.name, wgvDesc(out), ciliumOutputRawChain, wgvDump(f.rules, "raw"))
				}
			}
		}
	}
}

// TestVerifyWireguardTunnelPacketsAccepted: with WireGuard on, Cilium's
// filter rules let the encrypted WireGuard packets between nodes through on
// input and output, on either family, in any setup, and do not let ordinary
// traffic through, including overlay packets that arrive unencrypted on the
// node's own interfaces. Arriving packets carry the mark the host program
// gives them (wgvHostMarks).
func TestVerifyWireguardTunnelPacketsAccepted(t *testing.T) {
	states := wgvHostMarks(t)
	for _, s := range wgvSetups() {
		for _, f := range wgvFamilies(t, s.cfg) {
			for _, dev := range []string{"eth0", "ens5"} {
				in, anyOf := wgvArriving(states, f.name, dev)
				if !wgvHandled(in, anyOf, func(p wgvPacket) bool {
					return len(wgvCiliumAccepts(f.rules, "filter", ciliumInputChain, p)) > 0
				}) {
					t.Errorf("%s, %s: %s is not accepted in %s; rules:%s",
						s.name, f.name, wgvDescAll(in), ciliumInputChain, wgvDump(f.rules, "filter"))
				}
				out := wgvTunnelOutbound(dev)
				if len(wgvCiliumAccepts(f.rules, "filter", ciliumOutputChain, out)) == 0 {
					t.Errorf("%s, %s: %s is not accepted in %s; rules:%s",
						s.name, f.name, wgvDesc(out), ciliumOutputChain, wgvDump(f.rules, "filter"))
				}
			}
			for _, p := range wgvPlainInbound(f.icmp) {
				if hits := wgvAccepted(f.rules, "filter", ciliumInputChain, p); len(hits) > 0 {
					t.Errorf("%s, %s: %s is accepted in %s via %q; rules:%s",
						s.name, f.name, wgvDesc(p), ciliumInputChain, hits, wgvDump(f.rules, "filter"))
				}
			}
			for _, p := range wgvPlainOutbound() {
				if hits := wgvAccepted(f.rules, "filter", ciliumOutputChain, p); len(hits) > 0 {
					t.Errorf("%s, %s: %s is accepted in %s via %q; rules:%s",
						s.name, f.name, wgvDesc(p), ciliumOutputChain, hits, wgvDump(f.rules, "filter"))
				}
			}
		}
	}
}

// TestVerifyWireguardOverlayTrafficAccepted: in tunnel mode with WireGuard on,
// the overlay packets that come out of the tunnel after decryption skip
// conntrack and are let through by Cilium's input rules, for the setup's own
// tunnel port, on either family, on each device they reach the stack on, with
// or without a mark.
func TestVerifyWireguardOverlayTrafficAccepted(t *testing.T) {
	for _, s := range wgvTunnelSetups() {
		for _, f := range wgvFamilies(t, s.cfg) {
			for _, p := range wgvDecryptedOverlay(s.overlayPort) {
				if len(wgvCiliumSkips(f.rules, ciliumPreRawChain, p)) == 0 {
					t.Errorf("%s, %s: %s is tracked in %s; rules:%s",
						s.name, f.name, wgvDesc(p), ciliumPreRawChain, wgvDump(f.rules, "raw"))
				}
				if len(wgvCiliumAccepts(f.rules, "filter", ciliumInputChain, p)) == 0 {
					t.Errorf("%s, %s: %s is not accepted in %s; rules:%s",
						s.name, f.name, wgvDesc(p), ciliumInputChain, wgvDump(f.rules, "filter"))
				}
			}
		}
	}
}

// TestVerifyIPSecRulesUnchanged: with IPsec on and WireGuard off, packets
// carrying the IPsec decrypt mark (0x*d00) or encrypt mark (0x*e00) keep
// skipping conntrack in the raw pre-routing and output chains and keep being
// accepted in Cilium's filter and nat chains, on either family, while ordinary
// traffic stays tracked.
func TestVerifyIPSecRulesUnchanged(t *testing.T) {
	cfg := SharedConfig{EnableIPv4: true, EnableIPv6: true, EnableIPSec: true}
	marks := []uint32{0x00070d00, 0x00071e00, 0x00030d00, 0x00032e00}
	acceptChains := map[string][][2]string{
		"IPv4": {{"filter", ciliumInputChain}, {"filter", ciliumOutputChain}, {"filter", ciliumForwardChain},
			{"nat", ciliumPostNatChain}, {"nat", ciliumOutputNatChain}, {"nat", ciliumPreNatChain}},
		"IPv6": {{"filter", ciliumInputChain}, {"filter", ciliumOutputChain}, {"filter", ciliumForwardChain},
			{"nat", ciliumPostNatChain}},
	}
	for _, f := range wgvFamilies(t, cfg) {
		for _, mark := range marks {
			in := wgvPacket{desc: "IPsec packet arriving", proto: wgvESP, mark: mark, in: "eth0", out: "eth1"}
			out := wgvPacket{desc: "IPsec packet leaving", proto: wgvESP, mark: mark, out: "eth0"}
			if len(wgvCiliumSkips(f.rules, ciliumPreRawChain, in)) == 0 {
				t.Errorf("%s: %s is tracked in %s; rules:%s", f.name, wgvDesc(in), ciliumPreRawChain, wgvDump(f.rules, "raw"))
			}
			if len(wgvCiliumSkips(f.rules, ciliumOutputRawChain, out)) == 0 {
				t.Errorf("%s: %s is tracked in %s; rules:%s", f.name, wgvDesc(out), ciliumOutputRawChain, wgvDump(f.rules, "raw"))
			}
			for _, tc := range acceptChains[f.name] {
				if len(wgvCiliumAccepts(f.rules, tc[0], tc[1], in)) == 0 {
					t.Errorf("%s: %s is not accepted in %s %s; rules:%s",
						f.name, wgvDesc(in), tc[0], tc[1], wgvDump(f.rules, tc[0]))
				}
			}
		}
		for _, p := range wgvPlainInbound(f.icmp) {
			if hits := wgvSkipsConntrack(f.rules, ciliumPreRawChain, p); len(hits) > 0 {
				t.Errorf("%s: %s skips conntrack in %s via %q; rules:%s",
					f.name, wgvDesc(p), ciliumPreRawChain, hits, wgvDump(f.rules, "raw"))
			}
		}
	}
}
