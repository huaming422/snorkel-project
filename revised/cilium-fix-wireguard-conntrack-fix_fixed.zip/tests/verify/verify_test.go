// SPDX-License-Identifier: Apache-2.0
// Copyright Authors of Cilium

// Behavioral checks for the host iptables rules Cilium installs on encrypted
// clusters.
//
// Each check builds an unexported *manager with a SharedConfig, runs the
// manager's full rule install (installRules) against a recording fake at the
// command interface (ip4tables / ip6tables), and then asks what the recorded
// rules do to sample packets: is the packet skipped by conntrack in the raw
// table, and is it let through by Cilium's filter or nat chains. The checks
// look at what a rule matches (protocol, ports, interfaces, packet mark), not
// at how it is spelled, so the selector, comment text, -A vs -I and the method
// that emits the rule are all free. Match conditions this file does not model
// (addresses, sets, other match modules) are treated as satisfied.
//
// The symbols here are prefixed wgv* to avoid colliding with the package's
// own iptables_test.go, which defines its own mock in the same package.

package iptables

import (
	"fmt"
	"log/slog"
	"strconv"
	"strings"
	"testing"
)

// wgvListenPort is the UDP port the WireGuard tunnel device listens on and
// sends from, on every node.
const wgvListenPort = 51871

// wgvRecorder is a fake command interface (iptablesInterface) that records
// every argument list it is asked to run, instead of shelling out.
type wgvRecorder struct {
	prog string
	cmds [][]string
}

func (r *wgvRecorder) getProg() string  { return r.prog }
func (r *wgvRecorder) getIpset() string { return "" }
func (r *wgvRecorder) getMode() string  { return "" }

func (r *wgvRecorder) runProgOutput(args []string) (string, error) {
	r.cmds = append(r.cmds, append([]string(nil), args...))
	return "", nil
}

func (r *wgvRecorder) runProg(args []string) error {
	_, err := r.runProgOutput(args)
	return err
}

// wgvInstall runs the manager's rule install for cfg and returns the parsed
// rules per family.
func wgvInstall(t *testing.T, cfg SharedConfig) ([]wgvRule, []wgvRule) {
	t.Helper()
	ip4 := &wgvRecorder{prog: "iptables"}
	ip6 := &wgvRecorder{prog: "ip6tables"}
	m := &manager{
		logger:          slog.New(slog.DiscardHandler),
		haveSocketMatch: true,
		sharedCfg:       cfg,
		ip4tables:       ip4,
		ip6tables:       ip6,
	}
	if err := m.installRules(desiredState{installRules: true}); err != nil {
		t.Fatalf("installRules returned error: %v", err)
	}
	return wgvParseAll(ip4.cmds), wgvParseAll(ip6.cmds)
}

// wgvPacket is a sample packet as netfilter sees it at one hook.
type wgvPacket struct {
	desc         string
	proto        int // IP protocol number
	sport, dport int // 0 for protocols without ports
	mark         uint32
	in, out      string // interfaces, "" when not known at that hook
}

const (
	wgvTCP    = 6
	wgvUDP    = 17
	wgvICMP   = 1
	wgvICMPv6 = 58
	wgvESP    = 50
)

// wgvRule is one appended or inserted rule, reduced to what it matches.
type wgvRule struct {
	table, chain string
	target       string
	notrack      bool
	conds        []func(p wgvPacket) bool
	text         string
}

func (r wgvRule) matches(p wgvPacket) bool {
	for _, c := range r.conds {
		if !c(p) {
			return false
		}
	}
	return true
}

func wgvParseAll(cmds [][]string) []wgvRule {
	var out []wgvRule
	for _, c := range cmds {
		if r, ok := wgvParse(c); ok {
			out = append(out, r)
		}
	}
	return out
}

func wgvIsOption(tok string) bool { return tok == "!" || strings.HasPrefix(tok, "-") }

func wgvProto(v string) int {
	switch strings.ToLower(v) {
	case "all", "0":
		return 0
	case "tcp", "6":
		return wgvTCP
	case "udp", "17":
		return wgvUDP
	case "icmp", "1":
		return wgvICMP
	case "icmpv6", "ipv6-icmp", "58":
		return wgvICMPv6
	case "esp", "50":
		return wgvESP
	}
	return -1
}

// wgvPortSpec parses "a", "a:b" or a comma list of those.
func wgvPortSpec(v string) func(int) bool {
	type rng struct{ lo, hi int }
	var rs []rng
	for _, part := range strings.Split(v, ",") {
		lo, hi := part, part
		if i := strings.Index(part, ":"); i >= 0 {
			lo, hi = part[:i], part[i+1:]
		}
		l, errL := strconv.Atoi(lo)
		h, errH := strconv.Atoi(hi)
		if lo == "" {
			l, errL = 0, nil
		}
		if hi == "" {
			h, errH = 65535, nil
		}
		if errL != nil || errH != nil {
			return func(int) bool { return false }
		}
		rs = append(rs, rng{l, h})
	}
	return func(port int) bool {
		if port == 0 {
			return false
		}
		for _, r := range rs {
			if port >= r.lo && port <= r.hi {
				return true
			}
		}
		return false
	}
}

func wgvIface(v string) func(string) bool {
	if strings.HasSuffix(v, "+") {
		prefix := strings.TrimSuffix(v, "+")
		return func(name string) bool { return name != "" && strings.HasPrefix(name, prefix) }
	}
	return func(name string) bool { return name == v }
}

func wgvMark(v string) func(uint32) bool {
	val, mask := v, "0xffffffff"
	if i := strings.Index(v, "/"); i >= 0 {
		val, mask = v[:i], v[i+1:]
	}
	x, errX := strconv.ParseUint(val, 0, 32)
	m, errM := strconv.ParseUint(mask, 0, 32)
	if errX != nil || errM != nil {
		return func(uint32) bool { return false }
	}
	return func(mark uint32) bool { return mark&uint32(m) == uint32(x) }
}

// wgvParse reads one iptables argument list. Only -A/-I commands are rules;
// everything else (chain creation, listing, deletion) is ignored.
func wgvParse(args []string) (wgvRule, bool) {
	r := wgvRule{table: "filter", text: strings.Join(args, " ")}
	isRule := false
	neg := false
	add := func(c func(p wgvPacket) bool) {
		n := neg
		neg = false
		r.conds = append(r.conds, func(p wgvPacket) bool { return c(p) != n })
	}
	next := func(i *int) string {
		*i++
		if *i < len(args) {
			return args[*i]
		}
		return ""
	}
	for i := 0; i < len(args); i++ {
		tok := args[i]
		switch tok {
		case "!":
			neg = true
		case "-t", "--table":
			r.table = next(&i)
		case "-A", "--append", "-I", "--insert":
			isRule = true
			r.chain = next(&i)
			if tok == "-I" || tok == "--insert" {
				if i+1 < len(args) {
					if _, err := strconv.Atoi(args[i+1]); err == nil {
						i++
					}
				}
			}
		case "-D", "--delete", "-N", "--new-chain", "-E", "--rename-chain", "-F", "--flush",
			"-X", "--delete-chain", "-S", "--list-rules", "-L", "--list", "-P", "--policy",
			"-R", "--replace", "-Z", "--zero", "-C", "--check":
			return wgvRule{}, false
		case "-w", "--wait", "-W", "--wait-interval":
			if i+1 < len(args) && !wgvIsOption(args[i+1]) {
				i++
			}
		case "-p", "--protocol":
			want := wgvProto(next(&i))
			add(func(p wgvPacket) bool { return want == 0 || p.proto == want })
		case "--dport", "--destination-port", "--dports", "--destination-ports":
			in := wgvPortSpec(next(&i))
			add(func(p wgvPacket) bool { return in(p.dport) })
		case "--sport", "--source-port", "--sports", "--source-ports":
			in := wgvPortSpec(next(&i))
			add(func(p wgvPacket) bool { return in(p.sport) })
		case "--ports":
			in := wgvPortSpec(next(&i))
			add(func(p wgvPacket) bool { return in(p.sport) || in(p.dport) })
		case "-i", "--in-interface":
			is := wgvIface(next(&i))
			add(func(p wgvPacket) bool { return is(p.in) })
		case "-o", "--out-interface":
			is := wgvIface(next(&i))
			add(func(p wgvPacket) bool { return is(p.out) })
		case "--mark":
			is := wgvMark(next(&i))
			add(func(p wgvPacket) bool { return is(p.mark) })
		case "-m", "--match", "--comment":
			next(&i)
			neg = false
		case "-j", "--jump":
			r.target = next(&i)
			rest := args[i+1:]
			for _, a := range rest {
				if a == "--notrack" && r.target == "CT" {
					r.notrack = true
				}
			}
			if r.target == "NOTRACK" {
				r.notrack = true
			}
			i = len(args)
		default:
			// A match option this file does not model: treat it as satisfied
			// and skip its arguments.
			neg = false
			for i+1 < len(args) && !wgvIsOption(args[i+1]) {
				i++
			}
		}
	}
	return r, isRule
}

// wgvHits lists the rules in table/chain that match p and pass the filter.
func wgvHits(rules []wgvRule, table, chain string, p wgvPacket, want func(wgvRule) bool) []string {
	var hits []string
	for _, r := range rules {
		if r.table == table && r.chain == chain && want(r) && r.matches(p) {
			hits = append(hits, r.text)
		}
	}
	return hits
}

func wgvNotrack(r wgvRule) bool { return r.notrack }
func wgvAccept(r wgvRule) bool  { return r.target == "ACCEPT" }

func wgvSkipsConntrack(rules []wgvRule, chain string, p wgvPacket) []string {
	return wgvHits(rules, "raw", chain, p, wgvNotrack)
}

func wgvAccepted(rules []wgvRule, table, chain string, p wgvPacket) []string {
	return wgvHits(rules, table, chain, p, wgvAccept)
}

// wgvDump lists the rules installed in one table, for failure messages.
func wgvDump(rules []wgvRule, table string) string {
	var b strings.Builder
	for _, r := range rules {
		if r.table == table {
			b.WriteString("\n  ")
			b.WriteString(r.text)
		}
	}
	return b.String()
}

type wgvFamily struct {
	name  string
	rules []wgvRule
	icmp  int
}

func wgvFamilies(t *testing.T, cfg SharedConfig) []wgvFamily {
	r4, r6 := wgvInstall(t, cfg)
	return []wgvFamily{
		{name: "IPv4", rules: r4, icmp: wgvICMP},
		{name: "IPv6", rules: r6, icmp: wgvICMPv6},
	}
}

// Packets that come out of the WireGuard tunnel after decryption. The
// datapath marks them as decrypted (0x*d00 in the low 12 bits, identity in the
// upper bits), and they reach the stack either on the WireGuard device or,
// for host delivery, on cilium_host.
func wgvDecrypted(icmp int) []wgvPacket {
	marks := []uint32{0x00000d00, 0x12340d00, 0x00060d00, 0x00020d01}
	ifaces := []string{"cilium_wg0", "cilium_host"}
	var out []wgvPacket
	for _, in := range ifaces {
		for _, mark := range marks {
			out = append(out,
				wgvPacket{desc: "decrypted TCP to 10250", proto: wgvTCP, sport: 40112, dport: 10250, mark: mark, in: in},
				wgvPacket{desc: "decrypted TCP to 6443", proto: wgvTCP, sport: 51544, dport: 6443, mark: mark, in: in},
				wgvPacket{desc: "decrypted UDP to 53", proto: wgvUDP, sport: 33871, dport: 53, mark: mark, in: in},
				wgvPacket{desc: "decrypted ICMP", proto: icmp, mark: mark, in: in},
			)
		}
	}
	return out
}

// Ordinary node traffic that is not WireGuard transport.
func wgvPlainInbound(icmp int) []wgvPacket {
	return []wgvPacket{
		{desc: "plain UDP to 53", proto: wgvUDP, sport: 40000, dport: 53, in: "eth0"},
		{desc: "plain UDP to 8472", proto: wgvUDP, sport: 40001, dport: 8472, in: "ens5"},
		{desc: "plain TCP to 443", proto: wgvTCP, sport: 40002, dport: 443, in: "eth0"},
		{desc: "plain ICMP", proto: icmp, in: "ens5"},
	}
}

func wgvPlainOutbound() []wgvPacket {
	return []wgvPacket{
		{desc: "host UDP to 53", proto: wgvUDP, sport: 40003, dport: 53, out: "eth0"},
		{desc: "host TCP to a remote pod over the tunnel", proto: wgvTCP, sport: 40004, dport: 8080, out: "cilium_wg0"},
		{desc: "host UDP to a remote pod over the tunnel", proto: wgvUDP, sport: 40005, dport: 53, out: "cilium_wg0"},
	}
}

// Encrypted WireGuard transport packets between nodes. An arriving one may or
// may not carry the decrypt mark, depending on the datapath; a leaving one
// carries the WireGuard device's firewall mark (0xe00).
func wgvTunnelInbound(in string) (unmarked, marked wgvPacket) {
	unmarked = wgvPacket{desc: "arriving WireGuard packet on " + in, proto: wgvUDP,
		sport: wgvListenPort, dport: wgvListenPort, in: in}
	marked = unmarked
	marked.desc += " with the decrypt mark"
	marked.mark = 0x00000d00
	return
}

func wgvTunnelOutbound(out string) wgvPacket {
	return wgvPacket{desc: "leaving WireGuard packet on " + out, proto: wgvUDP,
		sport: wgvListenPort, dport: wgvListenPort, mark: 0x00000e00, out: out}
}

func wgvCfg() SharedConfig {
	return SharedConfig{EnableIPv4: true, EnableIPv6: true, EnableWireguard: true}
}

func wgvDesc(p wgvPacket) string {
	return fmt.Sprintf("%s (mark %#08x, in %q, out %q)", p.desc, p.mark, p.in, p.out)
}

// TestVerifyWireguardDecryptedTrafficIsTracked: with WireGuard on, traffic
// that came out of the tunnel after decryption, and ordinary node traffic,
// goes through conntrack. No raw-table rule skips conntrack for those packets,
// on either family.
func TestVerifyWireguardDecryptedTrafficIsTracked(t *testing.T) {
	for _, f := range wgvFamilies(t, wgvCfg()) {
		for _, p := range append(wgvDecrypted(f.icmp), wgvPlainInbound(f.icmp)...) {
			if hits := wgvSkipsConntrack(f.rules, ciliumPreRawChain, p); len(hits) > 0 {
				t.Errorf("%s: %s skips conntrack in %s via %q; rules:%s",
					f.name, wgvDesc(p), ciliumPreRawChain, hits, wgvDump(f.rules, "raw"))
			}
		}
		for _, p := range wgvPlainOutbound() {
			if hits := wgvSkipsConntrack(f.rules, ciliumOutputRawChain, p); len(hits) > 0 {
				t.Errorf("%s: %s skips conntrack in %s via %q; rules:%s",
					f.name, wgvDesc(p), ciliumOutputRawChain, hits, wgvDump(f.rules, "raw"))
			}
		}
	}
}

// TestVerifyWireguardTunnelPacketsSkipConntrack: with WireGuard on, the
// encrypted WireGuard packets between nodes skip conntrack in both directions,
// on either family. An arriving packet counts as skipped when a raw-table
// rule catches it with or without the decrypt mark.
func TestVerifyWireguardTunnelPacketsSkipConntrack(t *testing.T) {
	for _, f := range wgvFamilies(t, wgvCfg()) {
		for _, dev := range []string{"eth0", "ens5"} {
			unmarked, marked := wgvTunnelInbound(dev)
			if len(wgvSkipsConntrack(f.rules, ciliumPreRawChain, unmarked)) == 0 &&
				len(wgvSkipsConntrack(f.rules, ciliumPreRawChain, marked)) == 0 {
				t.Errorf("%s: %s is tracked in %s with and without the decrypt mark; rules:%s",
					f.name, unmarked.desc, ciliumPreRawChain, wgvDump(f.rules, "raw"))
			}
			out := wgvTunnelOutbound(dev)
			if len(wgvSkipsConntrack(f.rules, ciliumOutputRawChain, out)) == 0 {
				t.Errorf("%s: %s is tracked in %s; rules:%s",
					f.name, wgvDesc(out), ciliumOutputRawChain, wgvDump(f.rules, "raw"))
			}
		}
	}
}

// TestVerifyWireguardTunnelPacketsAccepted: with WireGuard on, Cilium's
// filter rules let the encrypted WireGuard packets between nodes through on
// input and output, on either family, and do not wave through ordinary
// traffic. An arriving packet counts as let through when a rule accepts it
// with or without the decrypt mark.
func TestVerifyWireguardTunnelPacketsAccepted(t *testing.T) {
	for _, f := range wgvFamilies(t, wgvCfg()) {
		for _, dev := range []string{"eth0", "ens5"} {
			unmarked, marked := wgvTunnelInbound(dev)
			if len(wgvAccepted(f.rules, "filter", ciliumInputChain, unmarked)) == 0 &&
				len(wgvAccepted(f.rules, "filter", ciliumInputChain, marked)) == 0 {
				t.Errorf("%s: %s is not accepted in %s with or without the decrypt mark; rules:%s",
					f.name, unmarked.desc, ciliumInputChain, wgvDump(f.rules, "filter"))
			}
			out := wgvTunnelOutbound(dev)
			if len(wgvAccepted(f.rules, "filter", ciliumOutputChain, out)) == 0 {
				t.Errorf("%s: %s is not accepted in %s; rules:%s",
					f.name, wgvDesc(out), ciliumOutputChain, wgvDump(f.rules, "filter"))
			}
		}
		for _, p := range wgvPlainInbound(f.icmp) {
			if hits := wgvAccepted(f.rules, "filter", ciliumInputChain, p); len(hits) > 0 {
				t.Errorf("%s: %s is accepted in %s via %q; rules:%s",
					f.name, wgvDesc(p), ciliumInputChain, hits, wgvDump(f.rules, "filter"))
			}
		}
		for _, p := range wgvPlainOutbound() {
			if hits := wgvAccepted(f.rules, "filter", ciliumOutputChain, p); len(hits) > 0 {
				t.Errorf("%s: %s is accepted in %s via %q; rules:%s",
					f.name, wgvDesc(p), ciliumOutputChain, hits, wgvDump(f.rules, "filter"))
			}
		}
	}
}

// TestVerifyIPSecRulesUnchanged: with IPsec on and WireGuard off, packets
// carrying the IPsec decrypt mark (0x*d00) or encrypt mark (0x*e00) keep
// skipping conntrack in the raw pre-routing and output chains and keep being
// accepted in Cilium's filter and nat chains, on either family, while ordinary
// traffic stays tracked.
func TestVerifyIPSecRulesUnchanged(t *testing.T) {
	cfg := SharedConfig{EnableIPv4: true, EnableIPv6: true, EnableIPSec: true}
	marks := []uint32{0x00070d00, 0x00071e00, 0x00030d00, 0x00032e00}
	acceptChains := map[string][][2]string{
		"IPv4": {{"filter", ciliumInputChain}, {"filter", ciliumOutputChain}, {"filter", ciliumForwardChain},
			{"nat", ciliumPostNatChain}, {"nat", ciliumOutputNatChain}, {"nat", ciliumPreNatChain}},
		"IPv6": {{"filter", ciliumInputChain}, {"filter", ciliumOutputChain}, {"filter", ciliumForwardChain},
			{"nat", ciliumPostNatChain}},
	}
	for _, f := range wgvFamilies(t, cfg) {
		for _, mark := range marks {
			in := wgvPacket{desc: "IPsec packet arriving", proto: wgvESP, mark: mark, in: "eth0", out: "eth1"}
			out := wgvPacket{desc: "IPsec packet leaving", proto: wgvESP, mark: mark, out: "eth0"}
			if len(wgvSkipsConntrack(f.rules, ciliumPreRawChain, in)) == 0 {
				t.Errorf("%s: %s is tracked in %s; rules:%s", f.name, wgvDesc(in), ciliumPreRawChain, wgvDump(f.rules, "raw"))
			}
			if len(wgvSkipsConntrack(f.rules, ciliumOutputRawChain, out)) == 0 {
				t.Errorf("%s: %s is tracked in %s; rules:%s", f.name, wgvDesc(out), ciliumOutputRawChain, wgvDump(f.rules, "raw"))
			}
			for _, tc := range acceptChains[f.name] {
				if len(wgvAccepted(f.rules, tc[0], tc[1], in)) == 0 {
					t.Errorf("%s: %s is not accepted in %s %s; rules:%s",
						f.name, wgvDesc(in), tc[0], tc[1], wgvDump(f.rules, tc[0]))
				}
			}
		}
		for _, p := range wgvPlainInbound(f.icmp) {
			if hits := wgvSkipsConntrack(f.rules, ciliumPreRawChain, p); len(hits) > 0 {
				t.Errorf("%s: %s skips conntrack in %s via %q; rules:%s",
					f.name, wgvDesc(p), ciliumPreRawChain, hits, wgvDump(f.rules, "raw"))
			}
		}
	}
}
