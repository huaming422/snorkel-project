## Task

Pi already stores a branch tree for each conversation, so one earlier prompt can have several continuations.
Our chat view ignores that and shows a single linear thread.
There's no way to go back to an earlier prompt and take it somewhere else, or to look at the other continuations Pi already has.

Add branch navigation inside the transcript itself, without a separate panel or tree view.

## User stories / requirements

- Editing an earlier prompt puts its text back in the composer and hides that prompt and everything after it, without changing the saved conversation.
  If the user leaves the composer instead of sending, the edit is dropped and the transcript comes back unchanged.
  Only sending the edited prompt creates the new branch.
- For a prompt with several continuations, picking another sibling shows that branch's transcript and brings back its own context and token usage.
  Switching only changes the conversation.
  No file edits get rolled back.
- When a branch switch can't be confirmed, for example because Pi's reply to it got lost, the next message is not sent, since it could land on the wrong branch.
  Sending works again once the conversation has been reconciled with Pi.
- The main and side chat composers keep separate unsent text, and a branch edit in the main chat never moves text into or out of the side composer.
  If a main chat send is refused after an unconfirmed branch switch, its text goes back to the main composer.
- A prompt with more than one continuation gets a small marker and inline controls for moving between its branches, showing which branch out of how many is selected, with accessible labels on every control.
  None of this appears on the first prompt, or for providers without native branches.
- After the user sends an edited prompt or switches to another branch, Pi itself carries on from that branch.
  The next reply is built only from the messages on that branch, never from whichever branch Pi happened to save last.
