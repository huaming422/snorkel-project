import { randomUUID } from 'node:crypto';
import * as fs from 'node:fs';
import * as path from 'node:path';

// Public native SDK surface an extension can use to read or extend a session file on disk.
export class SessionManager {
  static open(file, sessionDir) { return new SessionManager(file, sessionDir); }
  constructor(file, sessionDir) {
    this.file = file;
    this.sessionDir = sessionDir ?? path.dirname(file);
    this.records = fs.readFileSync(file, 'utf8').trim().split('\n').map(line => JSON.parse(line));
    this.leafId = this.getEntries().at(-1)?.id ?? null;
  }
  isPersisted() { return true; }
  getCwd() { return this.getHeader()?.cwd; }
  getSessionDir() { return this.sessionDir; }
  getSessionFile() { return this.file; }
  getHeader() { return this.records.find(record => record.type === 'session') ?? null; }
  getSessionId() { return this.getHeader()?.id; }
  getEntries() { return this.records.filter(record => record.type !== 'session'); }
  getEntry(id) { return this.getEntries().find(entry => entry.id === id); }
  getChildren(id) { return this.getEntries().filter(entry => entry.parentId === id); }
  getLeafId() { return this.leafId; }
  getLeafEntry() { return this.leafId ? this.getEntry(this.leafId) : undefined; }
  getLabel(id) {
    let label;
    for (const entry of this.getEntries()) if (entry.type === 'label' && entry.targetId === id) label = entry.label || undefined;
    return label;
  }
  getBranch(fromId) {
    const result = [];
    for (let entry = this.getEntry(fromId ?? this.leafId); entry; entry = entry.parentId ? this.getEntry(entry.parentId) : undefined) result.unshift(entry);
    return result;
  }
  branch(id) {
    if (!this.getEntry(id)) throw new Error(`Entry ${id} not found`);
    this.leafId = id;
  }
  resetLeaf() { this.leafId = null; }
  #append(entry) {
    const full = { id: randomUUID(), parentId: this.leafId, timestamp: new Date().toISOString(), ...entry };
    this.records.push(full);
    fs.appendFileSync(this.file, JSON.stringify(full) + '\n');
    this.leafId = full.id;
    return full.id;
  }
  appendMessage(message) { return this.#append({ type: 'message', message }); }
  appendCustomEntry(customType, data) { return this.#append({ type: 'custom', customType, data }); }
  appendLabelChange(targetId, label) {
    if (!this.getEntry(targetId)) throw new Error(`Entry ${targetId} not found`);
    return this.#append({ type: 'label', targetId, label });
  }
  appendSessionInfo(name) { return this.#append({ type: 'session_info', name }); }
  // Writes the path up to leafId into a new session file and continues there, as Pi does.
  createBranchedSession(leafId) {
    let parentId = null;
    const copied = this.getBranch(leafId).filter(entry => entry.type !== 'label')
      .map(entry => { const copy = { ...entry, parentId }; parentId = entry.id; return copy; });
    const id = randomUUID();
    const file = path.join(this.sessionDir, `${id}.jsonl`);
    const header = { ...this.getHeader(), id, parentSession: this.file };
    fs.writeFileSync(file, [header, ...copied].map(record => JSON.stringify(record)).join('\n') + '\n');
    this.file = file;
    this.records = [header, ...copied];
    this.leafId = copied.at(-1)?.id ?? null;
    return file;
  }
}
