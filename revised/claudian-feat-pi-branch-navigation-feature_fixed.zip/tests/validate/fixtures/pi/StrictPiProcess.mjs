import { execFile } from 'node:child_process';
import * as fs from 'node:fs';
import * as path from 'node:path';
import * as readline from 'node:readline';
import { pathToFileURL } from 'node:url';

// A deterministic Pi RPC peer that follows Pi's own rules for the session tree.
// It answers Pi's RPC commands and replies "Unknown command" to anything else.
// Extensions load the way Pi loads them (--extension / -e, or .pi/extensions in the
// working directory) and get Pi's extension API: every ctx.ui method Pi offers in RPC
// mode, the read-only session manager, and the command context (navigateTree, fork,
// switchSession, newSession, ...). A command that throws is reported as an
// extension_error and the prompt still succeeds, as in Pi.
// Reopening a session puts the leaf on the last entry of the file, as Pi does.
// The leaf only moves through Pi calls.
// Every prompt appends one line to $CLAUDIAN_TEST_PI_ROOT/contexts.jsonl with the
// ids of the message entries on the active path at the moment the prompt arrived.
const root = process.env.CLAUDIAN_TEST_PI_ROOT;
const args = process.argv.slice(2);
const flag = name => { const i = args.indexOf(name); return i < 0 ? null : args[i + 1]; };
const noSession = args.includes('--no-session');
const contextsFile = path.join(root, 'contexts.jsonl');
const memoryRecords = [];
let sessionFile = noSession ? null : flag('--session') ?? path.join(root, 'source.jsonl');
const sessionDir = () => flag('--session-dir') ?? (sessionFile ? path.dirname(sessionFile) : root);
let sequence = 0;
const nextId = prefix => `${prefix}-${++sequence}`;
const now = () => new Date(Date.UTC(2026, 0, 1, 0, 0, sequence)).toISOString();

const write = record => process.stdout.write(JSON.stringify(record) + '\n');
const respond = (request, data) => write({ type: 'response', id: request.id, command: request.type, success: true, ...(data === undefined ? {} : { data }) });
const fail = (request, error) => write({ type: 'response', id: request.id, command: request.type, success: false, error });

const readRecords = file => file === null ? memoryRecords : fs.existsSync(file)
  ? fs.readFileSync(file, 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line))
  : [];
const header = () => readRecords(sessionFile).find(record => record.type === 'session') ?? null;
const entries = () => readRecords(sessionFile).filter(record => record.type !== 'session');
const entry = id => entries().find(record => record.id === id);
const lastEntryId = file => readRecords(file).filter(record => record.id && record.type !== 'session').at(-1)?.id ?? null;
const pathTo = id => {
  const byId = new Map(entries().map(record => [record.id, record]));
  const result = [];
  for (let current = id; current && byId.has(current); current = byId.get(current).parentId) result.unshift(byId.get(current));
  return result;
};
let leafId = lastEntryId(sessionFile);
const activePath = () => pathTo(leafId);
const append = record => {
  const full = { parentId: leafId, timestamp: now(), ...record, id: record.id ?? nextId(record.type) };
  if (sessionFile === null) memoryRecords.push(full);
  else fs.appendFileSync(sessionFile, JSON.stringify(full) + '\n');
  leafId = full.id;
  return full.id;
};
const labelOf = id => {
  let label;
  for (const record of entries()) if (record.type === 'label' && record.targetId === id) label = record.label || undefined;
  return label;
};
const tree = () => {
  const nodes = new Map(entries().map(record => [record.id, { entry: record, children: [], label: labelOf(record.id) }]));
  const roots = [];
  for (const node of nodes.values()) {
    const parent = node.entry.parentId ? nodes.get(node.entry.parentId) : undefined;
    (parent ? parent.children : roots).push(node);
  }
  return roots;
};
const textOf = content => typeof content === 'string' ? content
  : Array.isArray(content) ? content.filter(part => part.type === 'text').map(part => part.text).join('') : '';
const newSessionFile = records => {
  const id = nextId('pi-session');
  const file = path.join(sessionDir(), `${id}.jsonl`);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const head = { type: 'session', version: 3, id, cwd: process.cwd(), timestamp: now(), ...(sessionFile ? { parentSession: sessionFile } : {}) };
  fs.writeFileSync(file, [head, ...records].map(record => JSON.stringify(record)).join('\n') + '\n');
  return file;
};
const openSession = file => { sessionFile = file; leafId = lastEntryId(file); };
// Copies the path up to targetId into a new session file, as Pi's fork does.
const forkTo = targetId => {
  let parentId = null;
  const records = (targetId ? pathTo(targetId) : []).filter(record => record.type !== 'label')
    .map(record => { const copy = { ...record, parentId }; parentId = record.id; return copy; });
  openSession(newSessionFile(records));
};

// A prompt: record which messages are on the active path, then append the exchange.
let streaming = false;
const runPrompt = (text, images) => {
  const ordinal = readRecords(contextsFile).length + 1;
  fs.appendFileSync(contextsFile, JSON.stringify({
    file: sessionFile, ...(noSession ? { text, images: images ?? [] } : {}),
    ids: activePath().filter(record => record.type === 'message').map(record => record.id),
  }) + '\n');
  streaming = true;
  append({ type: 'message', id: `pi-user-${ordinal}`, message: { role: 'user', content: text } });
  append({ type: 'message', id: `pi-assistant-${ordinal}`,
    message: { role: 'assistant', usage: { input: ordinal * 1000, output: 10 }, content: [{ type: 'text', text: `Reply ${ordinal}` }] } });
  write({ type: 'agent_start' });
  write({ type: 'message_update', assistantMessageEvent: { text_delta: `Reply ${ordinal}` } });
  write({ type: 'agent_end' });
  streaming = false;
};

// Extension UI in RPC mode: every request carries an id, dialogs wait for extension_ui_response.
const pendingDialogs = new Map();
const uiRequest = request => write({ type: 'extension_ui_request', id: nextId('ui'), ...request });
const dialog = (request, fallback, read, options) => new Promise(resolve => {
  if (options?.signal?.aborted) { resolve(fallback); return; }
  const id = nextId('ui');
  const timer = options?.timeout ? setTimeout(() => { pendingDialogs.delete(id); resolve(fallback); }, options.timeout) : null;
  pendingDialogs.set(id, response => { if (timer) clearTimeout(timer); resolve(response.cancelled ? fallback : read(response)); });
  write({ type: 'extension_ui_request', id, ...request });
});
const ui = {
  select: (title, options, opts) => dialog({ method: 'select', title, options, timeout: opts?.timeout }, undefined, r => r.value, opts),
  confirm: (title, message, opts) => dialog({ method: 'confirm', title, message, timeout: opts?.timeout }, false, r => r.confirmed ?? false, opts),
  input: (title, placeholder, opts) => dialog({ method: 'input', title, placeholder, timeout: opts?.timeout }, undefined, r => r.value, opts),
  editor: (title, prefill) => dialog({ method: 'editor', title, prefill }, undefined, r => r.value),
  notify: (message, notifyType) => uiRequest({ method: 'notify', message, notifyType }),
  setStatus: (statusKey, statusText) => uiRequest({ method: 'setStatus', statusKey, statusText }),
  setWidget: (widgetKey, content, options) => {
    if (content === undefined || Array.isArray(content)) uiRequest({ method: 'setWidget', widgetKey, widgetLines: content, widgetPlacement: options?.placement });
  },
  setTitle: title => uiRequest({ method: 'setTitle', title }),
  setEditorText: text => uiRequest({ method: 'set_editor_text', text }),
  pasteToEditor: text => uiRequest({ method: 'set_editor_text', text }),
  getEditorText: () => '',
  onTerminalInput: () => () => undefined,
  setWorkingMessage: () => undefined,
  setWorkingVisible: () => undefined,
  setWorkingIndicator: () => undefined,
  setHiddenThinkingLabel: () => undefined,
  setFooter: () => undefined,
  setHeader: () => undefined,
  custom: async () => undefined,
  addAutocompleteProvider: () => undefined,
  setEditorComponent: () => undefined,
  getEditorComponent: () => undefined,
  theme: {},
  getAllThemes: () => [],
  getTheme: () => undefined,
  setTheme: () => ({ success: false, error: 'Theme switching not supported in RPC mode' }),
  getToolsExpanded: () => false,
  setToolsExpanded: () => undefined,
};

const sessionManager = {
  getCwd: () => header()?.cwd ?? process.cwd(),
  getSessionDir: () => sessionDir(),
  getSessionId: () => header()?.id,
  getSessionFile: () => sessionFile ?? undefined,
  getLeafId: () => leafId,
  getLeafEntry: () => leafId ? entry(leafId) : undefined,
  getEntry: id => entry(id),
  getChildren: id => entries().filter(record => record.parentId === id),
  getLabel: id => labelOf(id),
  getBranch: fromId => pathTo(fromId ?? leafId),
  buildContextEntries: () => activePath(),
  buildSessionProjection: () => ({ messages: activePath().filter(record => record.type === 'message').map(record => record.message) }),
  buildSessionContext: () => ({ messages: activePath().filter(record => record.type === 'message').map(record => record.message) }),
  getHeader: () => header(),
  getEntries: () => entries(),
  getTree: () => tree(),
  getSessionName: () => entries().filter(record => record.type === 'session_info').at(-1)?.name || undefined,
};

const sessionStats = () => {
  let usage;
  for (const record of [...activePath()].reverse()) {
    if (record.message?.role === 'assistant' && record.message.usage) { usage = record.message.usage; break; }
  }
  return { sessionFile: sessionFile ?? undefined, sessionId: header()?.id, contextUsage: { tokens: usage ? usage.input + usage.output : null, contextWindow: 200000 } };
};

const commands = new Map();
const context = () => {
  const ctx = {
    ui, mode: 'rpc', hasUI: true, cwd: process.cwd(), sessionManager,
    modelRegistry: { getAll: () => [], getAvailable: () => [], find: () => undefined },
    model: undefined, scopedModels: [], thinkingLevel: 'off', signal: undefined,
    isIdle: () => !streaming,
    isProjectTrusted: () => true,
    abort: () => undefined,
    hasPendingMessages: () => false,
    shutdown: () => undefined,
    getContextUsage: () => { const { contextUsage } = sessionStats(); return { ...contextUsage, percent: null }; },
    compact: () => undefined,
    getSystemPrompt: () => '',
    getSystemPromptOptions: () => ({}),
    waitForIdle: async () => undefined,
    reload: async () => undefined,
    // Navigating to a user message selects its parent, so the prompt can be edited and re-sent.
    navigateTree: async (targetId, options) => {
      if (streaming) throw new Error('Wait for the current response to finish before navigating the session tree.');
      if (targetId === leafId) return { cancelled: false };
      const target = entry(targetId);
      if (!target) throw new Error(`Entry ${targetId} not found`);
      leafId = target.message?.role === 'user' || target.type === 'custom_message' ? target.parentId : target.id;
      if (options?.label) append({ type: 'label', targetId, label: options.label });
      return { cancelled: false };
    },
    fork: async (entryId, options) => {
      const target = entry(entryId);
      if (!target) throw new Error('Invalid entry ID for forking');
      if (options?.position === 'at') forkTo(target.id);
      else if (target.type !== 'message' || target.message.role !== 'user') throw new Error('Invalid entry ID for forking');
      else forkTo(target.parentId);
      await options?.withSession?.(replaced());
      return { cancelled: false };
    },
    switchSession: async (file, options) => {
      if (!fs.existsSync(file)) throw new Error(`Session file not found: ${file}`);
      openSession(file);
      await options?.withSession?.(replaced());
      return { cancelled: false };
    },
    newSession: async options => {
      openSession(newSessionFile([]));
      await options?.withSession?.(replaced());
      return { cancelled: false };
    },
  };
  return ctx;
};
const replaced = () => ({ ...context(), sendMessage: async (message, options) => api.sendMessage(message, options), sendUserMessage: async content => api.sendUserMessage(content) });

const listeners = new Map();
const api = {
  registerCommand: (name, command) => commands.set(name, command),
  registerTool: () => undefined,
  registerShortcut: () => undefined,
  registerFlag: () => undefined,
  getFlag: () => undefined,
  registerMessageRenderer: () => undefined,
  registerMarkdownTransformer: () => undefined,
  registerEntryRenderer: () => undefined,
  registerProvider: () => undefined,
  on: (event, handler) => {
    listeners.set(event, [...(listeners.get(event) ?? []), handler]);
    return () => listeners.set(event, (listeners.get(event) ?? []).filter(item => item !== handler));
  },
  events: { on: () => () => undefined, emit: () => undefined },
  appendEntry: (customType, data) => { append({ type: 'custom', customType, data }); },
  setLabel: (targetId, label) => {
    if (!entry(targetId)) throw new Error(`Entry ${targetId} not found`);
    append({ type: 'label', targetId, label });
  },
  setSessionName: name => { append({ type: 'session_info', name }); },
  getSessionName: () => sessionManager.getSessionName(),
  sendMessage: async message => {
    append({ type: 'custom_message', customType: message.customType, content: message.content, display: message.display, details: message.details });
  },
  sendUserMessage: async content => runPrompt(textOf(content), Array.isArray(content) ? content.filter(part => part.type === 'image') : []),
  exec: (command, commandArgs, options) => new Promise(resolve => execFile(command, commandArgs, { cwd: options?.cwd ?? process.cwd() },
    (error, stdout, stderr) => resolve({ stdout, stderr, code: error ? (typeof error.code === 'number' ? error.code : 1) : 0, killed: false }))),
  getActiveTools: () => [],
  getAllTools: () => [],
  setActiveTools: () => undefined,
  getCommands: () => [...commands.keys()].map(name => ({ name, source: 'extension' })),
  setModel: async () => true,
  getThinkingLevel: () => 'off',
  setThinkingLevel: () => undefined,
};

// Extensions: explicit --extension / -e paths, then .pi/extensions in the working directory.
const extensionPaths = [];
args.forEach((arg, index) => { if ((arg === '--extension' || arg === '-e') && args[index + 1]) extensionPaths.push(path.resolve(args[index + 1])); });
if (!args.includes('--no-extensions') && !args.includes('-ne')) {
  const directory = path.join(process.cwd(), '.pi', 'extensions');
  if (fs.existsSync(directory)) {
    for (const name of fs.readdirSync(directory).sort()) {
      const full = path.join(directory, name);
      if (/\.(ts|js|mjs)$/.test(name)) extensionPaths.push(full);
      else if (fs.statSync(full).isDirectory()) {
        const index = ['index.ts', 'index.js', 'index.mjs'].map(file => path.join(full, file)).find(file => fs.existsSync(file));
        if (index) extensionPaths.push(index);
      }
    }
  }
}
for (const extensionPath of extensionPaths) {
  // Extensions may import the Pi SDK; serve the session manager shim next to the extension.
  const sdkDir = path.join(path.dirname(extensionPath), 'node_modules', '@mariozechner', 'pi-coding-agent');
  fs.mkdirSync(sdkDir, { recursive: true });
  fs.writeFileSync(path.join(sdkDir, 'package.json'), JSON.stringify({ type: 'module', main: 'index.js' }));
  fs.copyFileSync(new URL('./PiSessionManager.mjs', import.meta.url), path.join(sdkDir, 'index.js'));
  const extension = await import(pathToFileURL(extensionPath).href);
  await extension.default(api);
}

const runCommand = async (request, message) => {
  const space = message.indexOf(' ');
  const name = space < 0 ? message.slice(1) : message.slice(1, space);
  try {
    await commands.get(name).handler(space < 0 ? '' : message.slice(space + 1), context());
  } catch (error) {
    write({ type: 'extension_error', extensionPath: `command:${name}`, event: 'command', error: error instanceof Error ? error.message : String(error) });
  }
  respond(request, { disposition: 'handled' });
};
const isCommand = message => message?.startsWith('/') && commands.has(message.slice(1).split(' ')[0]);

const handle = async request => {
  switch (request.type) {
    case 'extension_ui_response': {
      const resolve = pendingDialogs.get(request.id);
      pendingDialogs.delete(request.id);
      resolve?.(request);
      return;
    }
    case 'prompt':
    case 'steer':
    case 'follow_up':
      if (isCommand(request.message)) { await runCommand(request, request.message); return; }
      respond(request, { disposition: 'started' });
      runPrompt(request.message, request.images);
      return;
    case 'get_state':
      respond(request, { sessionId: header()?.id ?? 'pi-source', sessionFile: sessionFile ?? undefined, sessionName: sessionManager.getSessionName(),
        isStreaming: streaming, isCompacting: false, thinkingLevel: 'off', steeringMode: 'one-at-a-time', followUpMode: 'one-at-a-time',
        autoCompactionEnabled: false, messageCount: activePath().filter(record => record.type === 'message').length, pendingMessageCount: 0, pid: process.pid });
      return;
    case 'get_commands': respond(request, { commands: [...commands.keys()].map(name => ({ name, source: 'extension' })) }); return;
    case 'get_entries': {
      let list = entries();
      if (request.since !== undefined) {
        const index = list.findIndex(record => record.id === request.since);
        if (index < 0) { fail(request, `Entry not found: ${request.since}`); return; }
        list = list.slice(index + 1);
      }
      respond(request, { entries: list, leafId });
      return;
    }
    case 'get_tree': respond(request, { tree: tree(), leafId }); return;
    case 'get_messages': respond(request, { messages: activePath().filter(record => record.type === 'message').map(record => record.message) }); return;
    case 'get_fork_messages':
      respond(request, { messages: entries().filter(record => record.type === 'message' && record.message.role === 'user')
        .map(record => ({ entryId: record.id, text: textOf(record.message.content) })) });
      return;
    case 'get_last_assistant_text': {
      const last = activePath().filter(record => record.message?.role === 'assistant').at(-1);
      respond(request, { text: last ? textOf(last.message.content) : null });
      return;
    }
    case 'switch_session':
      if (!fs.existsSync(request.sessionPath)) { fail(request, `Session file not found: ${request.sessionPath}`); return; }
      openSession(request.sessionPath);
      respond(request, { cancelled: false });
      return;
    case 'new_session': openSession(newSessionFile([])); respond(request, { cancelled: false }); return;
    case 'fork': {
      const target = entry(request.entryId);
      if (!target || target.type !== 'message' || target.message.role !== 'user') { fail(request, 'Invalid entry ID for forking'); return; }
      forkTo(target.parentId);
      respond(request, { text: textOf(target.message.content), cancelled: false });
      return;
    }
    case 'clone':
      if (!leafId) { fail(request, 'Cannot clone session: no current entry selected'); return; }
      forkTo(leafId);
      respond(request, { cancelled: false });
      return;
    case 'set_session_name':
      if (!request.name?.trim()) { fail(request, 'Session name cannot be empty'); return; }
      append({ type: 'session_info', name: request.name.trim() });
      respond(request);
      return;
    case 'get_session_stats': respond(request, sessionStats()); return;
    case 'get_available_models': respond(request, { models: [] }); return;
    case 'get_available_thinking_levels': respond(request, { levels: ['off', 'high'] }); return;
    case 'cycle_model':
    case 'cycle_thinking_level':
      respond(request, null); return;
    case 'clear_queue': respond(request, { steering: [], followUp: [] }); return;
    case 'compact': respond(request, { summary: '', firstKeptEntryId: leafId, tokensBefore: 0 }); return;
    case 'bash': respond(request, { output: '', exitCode: 0, cancelled: false, truncated: false }); return;
    case 'export_html': respond(request, { path: path.join(root, 'session.html') }); return;
    case 'set_model':
    case 'set_thinking_level':
    case 'set_steering_mode':
    case 'set_follow_up_mode':
    case 'set_auto_compaction':
    case 'set_auto_retry':
    case 'abort':
    case 'abort_retry':
    case 'abort_bash':
      respond(request, {}); return;
    default:
      fail(request, `Unknown command: ${request.type}`);
  }
};

// Start reading only after the extensions have registered their commands.
const lines = readline.createInterface({ input: process.stdin, crlfDelay: Infinity });
for await (const line of lines) {
  const request = JSON.parse(line);
  void handle(request).catch(error => fail(request, error instanceof Error ? error.message : String(error)));
}
