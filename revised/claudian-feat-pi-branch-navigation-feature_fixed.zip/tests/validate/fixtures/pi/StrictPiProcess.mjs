import * as fs from 'node:fs';
import * as path from 'node:path';
import * as readline from 'node:readline';
import { pathToFileURL } from 'node:url';

// A deterministic Pi RPC peer that follows Pi's own rules for the session tree.
// It answers only Pi's real RPC commands and replies "Unknown command" to anything else.
// Reopening a session puts the leaf on the last entry of the file, as Pi does.
// The leaf only moves through Pi calls: a prompt, switch_session, or an
// extension's navigateTree / switchSession / appendEntry.
// Every prompt appends one line to $CLAUDIAN_TEST_PI_ROOT/contexts.jsonl with the
// ids of the message entries on the active path at the moment the prompt arrived.
const root = process.env.CLAUDIAN_TEST_PI_ROOT;
const args = process.argv.slice(2);
const sessionIndex = args.indexOf('--session');
const noSession = args.includes('--no-session');
let sessionFile = noSession ? null : sessionIndex < 0 ? path.join(root, 'source.jsonl') : args[sessionIndex + 1];
const memoryRecords = [];
const contextsFile = path.join(root, 'contexts.jsonl');
const write = record => process.stdout.write(JSON.stringify(record) + '\n');
const respond = (request, data) => write({ type: 'response', id: request.id, command: request.type, success: true, data });
const fail = (request, error) => write({ type: 'response', id: request.id, command: request.type, success: false, error });
const readRecords = file => file === null ? memoryRecords : fs.existsSync(file)
  ? fs.readFileSync(file, 'utf8').trim().split('\n').filter(Boolean).map(line => JSON.parse(line))
  : [];
const lastEntryId = file => readRecords(file).filter(record => record.id && record.type !== 'session').at(-1)?.id ?? null;
const activePath = () => {
  const byId = new Map(readRecords(sessionFile).map(record => [record.id, record]));
  const entries = [];
  for (let id = leafId; id && byId.has(id); id = byId.get(id).parentId) entries.unshift(byId.get(id));
  return entries;
};
let leafId = lastEntryId(sessionFile);
const commands = new Map();
const extensionIndex = args.indexOf('--extension');
if (extensionIndex >= 0) {
  // Extensions may import the Pi SDK; serve the session manager shim next to the extension.
  const sdkDir = path.join(path.dirname(args[extensionIndex + 1]), 'node_modules', '@mariozechner', 'pi-coding-agent');
  fs.mkdirSync(sdkDir, { recursive: true });
  fs.writeFileSync(path.join(sdkDir, 'package.json'), JSON.stringify({ type: 'module', main: 'index.js' }));
  fs.copyFileSync(new URL('./PiSessionManager.mjs', import.meta.url), path.join(sdkDir, 'index.js'));
  const extension = await import(pathToFileURL(args[extensionIndex + 1]).href);
  extension.default({
    registerCommand: (name, command) => commands.set(name, command),
    appendEntry: customType => {
      const entry = { type: 'custom', customType, id: `anchor-${Date.now()}`, parentId: leafId };
      fs.appendFileSync(sessionFile, JSON.stringify(entry) + '\n');
      leafId = entry.id;
    },
    on: () => undefined,
  });
}
const extensionContext = {
  isIdle: () => true,
  sessionManager: {
    getLeafId: () => leafId,
    getLeafEntry: () => readRecords(sessionFile).find(record => record.id === leafId),
    getSessionId: () => readRecords(sessionFile)[0]?.id,
    getSessionFile: () => sessionFile,
    getHeader: () => readRecords(sessionFile)[0],
    getEntry: id => readRecords(sessionFile).find(record => record.id === id),
    getEntries: () => readRecords(sessionFile).filter(record => record.type !== 'session'),
    getBranch: () => activePath(),
  },
  // Navigating to a user message selects its parent, so the prompt can be edited and re-sent.
  navigateTree: async id => {
    if (id === leafId) return { cancelled: false };
    const entry = readRecords(sessionFile).find(record => record.id === id);
    if (!entry) throw new Error('Missing tree entry');
    leafId = entry.message?.role === 'user' || entry.type === 'custom_message' ? entry.parentId : entry.id;
    return { cancelled: false };
  },
  switchSession: async (file, options) => {
    sessionFile = file;
    leafId = lastEntryId(file);
    await options?.withSession?.(extensionContext);
    return { cancelled: false };
  },
  ui: { setStatus: (statusKey, statusText) => write({ type: 'extension_ui_request', method: 'setStatus', statusKey, statusText }) },
};

// Start reading only after the extension has registered its commands.
const lines = readline.createInterface({ input: process.stdin, crlfDelay: Infinity });
for await (const line of lines) {
  const request = JSON.parse(line);
  switch (request.type) {
    case 'get_state': {
      const [header] = readRecords(sessionFile);
      respond(request, { sessionId: header?.id ?? 'pi-source', sessionFile, pid: process.pid });
      break;
    }
    case 'get_commands': respond(request, { commands: [...commands.keys()].map(name => ({ name, source: 'extension' })) }); break;
    case 'get_entries': respond(request, { entries: readRecords(sessionFile).filter(record => record.type !== 'session'), leafId }); break;
    case 'get_messages': respond(request, { messages: activePath().filter(entry => entry.type === 'message').map(entry => entry.message) }); break;
    case 'switch_session':
      if (!fs.existsSync(request.sessionPath)) { fail(request, `Session file not found: ${request.sessionPath}`); break; }
      sessionFile = request.sessionPath;
      leafId = lastEntryId(sessionFile);
      respond(request, { cancelled: false });
      break;
    case 'set_model':
    case 'set_thinking_level':
    case 'abort':
      respond(request, {}); break;
    case 'get_session_stats': {
      let usage;
      for (const entry of activePath().reverse()) {
        if (entry.message?.role === 'assistant' && entry.message.usage) { usage = entry.message.usage; break; }
      }
      respond(request, { contextUsage: { tokens: usage ? usage.input + usage.output : null, contextWindow: 200000 } });
      break;
    }
    case 'steer':
    case 'prompt': {
      const commandName = request.message?.split(' ')[0]?.slice(1);
      if (request.message?.startsWith('/') && commands.has(commandName)) {
        await commands.get(commandName).handler(request.message.slice(commandName.length + 2), extensionContext);
        respond(request, {});
        break;
      }
      const ordinal = readRecords(contextsFile).length + 1;
      fs.appendFileSync(contextsFile, JSON.stringify({
        file: sessionFile, ...(noSession ? { text: request.message, images: request.images ?? [] } : {}),
        ids: activePath().filter(entry => entry.type === 'message').map(entry => entry.id),
      }) + '\n');
      const entries = [
        { type: 'message', id: `pi-user-${ordinal}`, parentId: leafId,
          message: { role: 'user', content: request.message } },
        { type: 'message', id: `pi-assistant-${ordinal}`, parentId: `pi-user-${ordinal}`,
          message: { role: 'assistant', usage: { input: ordinal * 1000, output: 10 }, content: [{ type: 'text', text: `Reply ${ordinal}` }] } },
      ];
      leafId = entries.at(-1).id;
      if (noSession) memoryRecords.push(...entries);
      else fs.appendFileSync(sessionFile, entries.map(entry => JSON.stringify(entry)).join('\n') + '\n');
      respond(request, {});
      write({ type: 'agent_start' });
      write({ type: 'message_update', assistantMessageEvent: { text_delta: `Reply ${ordinal}` } });
      write({ type: 'agent_end' });
      break;
    }
    case 'extension_ui_response': break;
    default:
      fail(request, `Unknown command: ${request.type}`);
  }
}
