## Task

We'd like Compute nodes to scale out and back in by themselves, the way a cloud auto-scaling group does.
There's no new UI to build for this.
It's all about how the nodes behave in the simulation.

## User stories / requirements

- When an auto-scaling Compute fleet runs hot for a while without a break, it starts another instance.
  It carries no load until it has warmed up, but it is paid for from the start.
  Under continued load the fleet keeps growing, with a pause between new instances, and never passes its maximum instance count.
- Once an auto-scaling Compute fleet goes quiet, it gives instances back over time until it is down to its minimum instance count, and never goes below that.
  When load sits in the middle band, between busy and quiet, the fleet keeps its current size instead of flapping up and down.
- Any service that isn't an auto-scaling Compute node gives exactly the same capacity and load it did before this change, and doesn't grow however busy it gets.
  That includes a Compute node whose auto-scaling is turned off.
- Saving and reloading brings an auto-scaling fleet back with the ready instances and capacity it had when saved.
  An instance that was still warming up is not brought back, and a saved size above the maximum loads at the maximum.
  Saves from before this feature load with auto-scaling off and one instance.

## General instructions

- The code repo is at /repo/server-survival.
- You are inside of a Docker container with no network access. You may not be able to perform all operations you would normally be able to do on a local machine. The project's dependencies and toolchain are already installed and the package manager caches are populated, so build and test with what is in the image; anything that needs to be downloaded will fail rather than hang.
- You are expected to act autonomously as a software engineer to complete tasks you are given.
- Do not stop until you feel you have completed the task and your code changes can be merged.
- You may need to use software engineering skills like analyzing the codebase, researching technologies, running services, analyzing logs, etc. to complete the task. Not all tasks will be solvable by reading source code alone.
