Two slow spots in opensre and one setting that does nothing.

When I start the interactive shell and pick the first item on the onboarding demo menu, the reply stalls for a few seconds before anything shows up.
Profiling that turn, the wait is setting up the model client (the SDK import alone takes a while) plus a fresh read of my hosted credit balance.
Both could be done while I'm still reading the menu.
That prep must not hold up the prompt or quitting, though.
If it hangs on the network, the shell should still open, quitting should still take a few seconds at most, and the process should still exit.
If the model client can't be set up (say my credentials are missing), the prep should keep quiet about it and still do the credit read.

The balance read during the menu shouldn't go stale before I pick something, either.
If I have credits left, a balance read within the last minute is fine to reuse, and after that it should be read again.
A zero or unreadable balance should keep getting re-checked after a few seconds, like now.
And once a hosted model request comes back saying my OpenSRE credits are exhausted, stop trusting the balance read earlier.

The second slow spot is CI repair.
When I'm signed in and it runs the local Codex agent on the hosted route, it takes far longer than the same model through our hosted gateway.
Watching it start, Codex loads my whole personal Codex setup (`CODEX_HOME`, or `~/.codex` when that's unset), with my plugins, MCP servers and skills, before it ever calls the model.
A hosted run needs none of that.
It should run against a clean Codex setup of its own and never read or copy my personal one.
My `HOME` has to stay as it is so git and gh keep my credentials.
Nothing from that run should be left on disk afterwards, whether it passed or failed.
If no scratch directory can be made (full or read-only tmp), the run should still go ahead.

Two cases should stay as they are:
- Signed-out runs use my own Codex home for `auth.json` and custom providers, so they keep it.
- Runs with `CODING_AGENT_SANDBOX=host` already get a clean gateway home, so they keep whatever `CODEX_HOME` they have.

Last, `/effort` is ignored.
I set it and the model behaves exactly as before.
The session's effort should be what the next turn's model calls use, and changing it between turns should apply from the next turn on.
`max` goes out as `xhigh`, and with no `/effort` set the provider default applies as it does now.

Apart from `/effort` starting to work, nothing a user sees should change.
