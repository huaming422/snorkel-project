"""Behavioral checks for the onboarding first-turn and coding-agent launch speed-ups.

Four groups, each driven through an interface the repository already has, so
the checks do not depend on where the new code lives or what it is called:

  A. Coding-agent launch. ``codex_backend.run()`` hands Codex a fresh home of its
     own on the hosted route under Codex's own sandbox, never the personal one
     and never a copy of it, keeps ``HOME`` and removes the fresh home after the
     run. The signed-out route and the host sandbox keep the user's home. A run
     still completes when no fresh home can be made. Observed in the
     environment given to ``subprocess.Popen``.
  B. ``/effort``. The session's reasoning effort is the active effort while the
     model is called during a shell turn (MAX is sent as ``xhigh``), and a
     change between two turns of one session reaches the second turn. Observed
     from a fake model driven through ``execute_shell_turn``, the entry every
     REPL turn takes.
  C. First-turn warm-up. With the onboarding menu offered, the client build
     (``core.llm.factory.get_llm``) and the hosted credit read
     (``prefetch_hosted_credits``) both run while the user is still on the
     menu, a failing client build stays quiet and does not skip the credit
     read, and a client build or a credit read that never returns holds up
     neither the prompt nor leaving the shell. Observed by booting
     ``run_repl_async`` in a fresh interpreter with the real ``offer_demo`` and
     the real ``InteractiveShellController``; only the keyboard loop is
     replaced, by one that sits on the menu.
  D. Hosted credit cache. A funded balance stays usable for up to a minute, an
     empty or unreadable balance is read again after a few seconds, and a
     credit-exhausted answer from the hosted proxy drops a cached balance.
     Observed by counting HTTP reads behind ``fetch_hosted_credits``.
"""

from __future__ import annotations

import io
import json
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from types import SimpleNamespace
from typing import Any
from unittest.mock import MagicMock, patch

import httpx
import pytest
from rich.console import Console

# ── Interfaces under test, all already in the repository ───────────────────
import config.account_credits as account_credits
import surfaces.interactive_shell.main as main_entrypoint
from config.llm_reasoning_effort import ReasoningEffort, get_active_reasoning_effort
from core.llm.shared.llm_retry import OpenSRECreditsExhaustedError, maybe_raise_credit_exhausted
from core.llm.types import AgentLLMResponse
from integrations.coding_agent import codex_backend
from infrastructure.turn_host.turn_runner import TurnRunner
from surfaces.interactive_shell.runtime.shell_agent import shell_agent_build_config
from surfaces.interactive_shell.runtime.shell_turn_execution import execute_shell_turn
from surfaces.interactive_shell.session import Session
from tests.core.agent.orchestration.action_execution_test_harness import (
    FakeActionLLM,
    no_tool_response,
)

# ``CODEX_HOME`` is the variable the ``codex`` CLI reads for its config,
# plugins, MCP servers and skills (default ``~/.codex``).
_CODEX_HOME = "CODEX_HOME"
# A signed-in OpenSRE account's hosted OpenAI credentials.
_HOSTED = {"OPENAI_API_KEY": "osre_pat_secret", "OPENAI_BASE_URL": "https://app.test/api/llm/v1"}
# A personal Codex setup: a config with an MCP server, a plugin and a skill.
_PERSONAL_MARKER = "personal-mcp-server-7f3a"

_POPEN = "integrations.llm_cli.agent_exec.subprocess.Popen"
_GIT_RUN = "integrations.git.local.subprocess.run"


# ── Coding-agent test doubles (shaped like the repo's own coding-agent suite) ──
def _git_run_side_effect(cmd: list[str], **_: object) -> MagicMock:
    """A git stand-in: a clean checkout with one modified file."""
    sub = cmd[1]
    if sub == "rev-parse":
        return MagicMock(returncode=0, stdout="true\n", stderr="")
    if sub == "status":
        if "-z" in cmd:
            return MagicMock(returncode=0, stdout=" M foo.py\0", stderr="")
        return MagicMock(returncode=0, stdout=" M foo.py\n", stderr="")
    if sub == "diff":
        return MagicMock(returncode=0, stdout="diff --git a/foo.py b/foo.py\n", stderr="")
    return MagicMock(returncode=0, stdout="", stderr="")


class _FakePopen:
    """A ``subprocess.Popen`` stand-in that finishes at once."""

    def __init__(self, *, stdout: str = "done\n", returncode: int = 0) -> None:
        self.stdin = io.StringIO()
        self.stdout = io.StringIO(stdout)
        self.stderr = io.StringIO("")
        self.returncode = returncode

    def poll(self) -> int:
        return self.returncode

    def wait(self, timeout: float | None = None) -> int:  # noqa: ARG002
        return self.returncode


def _spawn_recording(seen: dict[str, Any], *, returncode: int = 0):
    """A Popen stand-in that records the Codex home while the agent would run."""

    def _spawn(_argv: list[str], **kwargs: object) -> _FakePopen:
        env = kwargs["env"]
        assert isinstance(env, dict)
        seen["env"] = dict(env)
        home = env.get(_CODEX_HOME)
        seen["codex_home"] = home
        if home:
            path = Path(home)
            seen["codex_home_existed"] = path.is_dir()
            seen["codex_home_entries"] = (
                sorted(p.name for p in path.iterdir()) if path.is_dir() else []
            )
            seen["codex_home_text"] = (
                "".join(
                    p.read_text(encoding="utf-8", errors="replace")
                    for p in path.rglob("*")
                    if p.is_file()
                )
                if path.is_dir()
                else ""
            )
        return _FakePopen(returncode=returncode)

    return _spawn


def _make_personal_codex_home(path: Path) -> Path:
    """Write a personal Codex home holding things a hosted run must not load."""
    (path / "plugins" / "slow-plugin").mkdir(parents=True)
    (path / "skills" / "my-skill").mkdir(parents=True)
    (path / "skills" / "my-skill" / "SKILL.md").write_text("# my skill\n", encoding="utf-8")
    (path / "config.toml").write_text(
        f'[mcp_servers.{_PERSONAL_MARKER}]\ncommand = "sleep"\nargs = ["30"]\n',
        encoding="utf-8",
    )
    return path


def _use_hosted(monkeypatch: pytest.MonkeyPatch, hosted: dict[str, str] | None) -> None:
    monkeypatch.setattr(
        "integrations.coding_agent.codex_backend.hosted_openai_subprocess_env", lambda: hosted
    )


# ───────────────────────────── A. Coding-agent launch ─────────────────────
@pytest.mark.parametrize("personal_via", ["codex_home_env", "default_home"])
@pytest.mark.parametrize("returncode", [0, 1])
@patch(_POPEN)
@patch(_GIT_RUN, side_effect=_git_run_side_effect)
@patch("integrations.coding_agent.codex_backend._resolve_binary", return_value="/usr/bin/codex")
def test_hosted_run_uses_a_fresh_codex_home_and_removes_it(
    _mock_resolve: MagicMock,
    _mock_git: MagicMock,
    mock_popen: MagicMock,
    personal_via: str,
    returncode: int,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Hosted route, Codex's own sandbox: a fresh home, not the personal one or a copy."""
    seen: dict[str, Any] = {}
    mock_popen.side_effect = _spawn_recording(seen, returncode=returncode)
    user_home = tmp_path / "user"
    user_home.mkdir()
    monkeypatch.setenv("HOME", str(user_home))
    monkeypatch.delenv("CODING_AGENT_SANDBOX", raising=False)
    if personal_via == "codex_home_env":
        personal = _make_personal_codex_home(tmp_path / "personal-codex")
        monkeypatch.setenv(_CODEX_HOME, str(personal))
    else:
        personal = _make_personal_codex_home(user_home / ".codex")
        monkeypatch.delenv(_CODEX_HOME, raising=False)
    _use_hosted(monkeypatch, _HOSTED)
    workspace = tmp_path / "ws"
    workspace.mkdir()

    result = codex_backend.run("fix", workspace=str(workspace), model="gpt-5.6-sol", timeout_sec=60)

    assert mock_popen.call_count == 1
    assert result.success is (returncode == 0)
    codex_home = seen.get("codex_home")
    assert codex_home, "the hosted run must point Codex at a home of its own"
    fresh = Path(codex_home).resolve()
    assert fresh != personal.resolve() and personal.resolve() not in fresh.parents
    assert seen["codex_home_existed"]
    # Nothing from the personal setup is carried over.
    assert "plugins" not in seen["codex_home_entries"]
    assert "skills" not in seen["codex_home_entries"]
    assert _PERSONAL_MARKER not in seen["codex_home_text"]
    # HOME stays the user's, so git and gh keep their credentials.
    assert seen["env"].get("HOME") == str(user_home)
    # The fresh home is gone after the run, whether it succeeded or failed.
    assert not Path(codex_home).exists()
    # The personal home is left as it was.
    assert (personal / "config.toml").read_text(encoding="utf-8").count(_PERSONAL_MARKER) == 1


@pytest.mark.parametrize("user_codex_home", [True, False])
@patch(_POPEN)
@patch(_GIT_RUN, side_effect=_git_run_side_effect)
@patch("integrations.coding_agent.codex_backend._resolve_binary", return_value="/usr/bin/codex")
def test_signed_out_run_keeps_the_users_codex_home(
    _mock_resolve: MagicMock,
    _mock_git: MagicMock,
    mock_popen: MagicMock,
    user_codex_home: bool,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Signed-out runs use the user's own Codex home (auth.json, custom providers)."""
    seen: dict[str, Any] = {}
    mock_popen.side_effect = _spawn_recording(seen)
    monkeypatch.delenv("CODING_AGENT_SANDBOX", raising=False)
    user_home = str(_make_personal_codex_home(tmp_path / "user-codex"))
    if user_codex_home:
        monkeypatch.setenv(_CODEX_HOME, user_home)
    else:
        monkeypatch.delenv(_CODEX_HOME, raising=False)
    _use_hosted(monkeypatch, None)

    result = codex_backend.run("fix", workspace=str(tmp_path), model=None, timeout_sec=60)

    assert result.success is True
    if user_codex_home:
        assert seen.get("codex_home") == user_home
    else:
        assert _CODEX_HOME not in seen["env"]


@pytest.mark.parametrize("user_codex_home", [True, False])
@patch(_POPEN)
@patch(_GIT_RUN, side_effect=_git_run_side_effect)
@patch("integrations.coding_agent.codex_backend._resolve_binary", return_value="/usr/bin/codex")
def test_host_sandbox_keeps_its_codex_home(
    _mock_resolve: MagicMock,
    _mock_git: MagicMock,
    mock_popen: MagicMock,
    user_codex_home: bool,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Under the host sandbox the hosted run keeps the home it already has."""
    seen: dict[str, Any] = {}
    mock_popen.side_effect = _spawn_recording(seen)
    monkeypatch.setenv("CODING_AGENT_SANDBOX", "host")
    gateway_home = str(tmp_path / "gateway-codex")
    if user_codex_home:
        monkeypatch.setenv(_CODEX_HOME, gateway_home)
    else:
        monkeypatch.delenv(_CODEX_HOME, raising=False)
    _use_hosted(monkeypatch, _HOSTED)

    result = codex_backend.run("fix", workspace=str(tmp_path), model=None, timeout_sec=60)

    assert result.success is True
    if user_codex_home:
        assert seen.get("codex_home") == gateway_home
    else:
        assert _CODEX_HOME not in seen["env"]


@patch(_POPEN)
@patch(_GIT_RUN, side_effect=_git_run_side_effect)
@patch("integrations.coding_agent.codex_backend._resolve_binary", return_value="/usr/bin/codex")
def test_run_completes_when_no_fresh_home_can_be_made(
    _mock_resolve: MagicMock,
    _mock_git: MagicMock,
    mock_popen: MagicMock,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A temp directory that cannot be created does not stop the run."""

    def _no_tempdir(*_args: object, **_kwargs: object) -> str:
        raise OSError("read-only file system")

    seen: dict[str, Any] = {}
    mock_popen.side_effect = _spawn_recording(seen)
    monkeypatch.delenv(_CODEX_HOME, raising=False)
    monkeypatch.delenv("CODING_AGENT_SANDBOX", raising=False)
    monkeypatch.setattr(tempfile, "mkdtemp", _no_tempdir)
    _use_hosted(monkeypatch, _HOSTED)

    result = codex_backend.run("fix", workspace=str(tmp_path), model=None, timeout_sec=60)

    assert result.success is True
    assert mock_popen.call_count == 1
    # Codex is never pointed at a directory that is not there.
    if seen.get("codex_home"):
        assert seen["codex_home_existed"]


# ───────────────────────────── B. /effort ─────────────────────────────────
class _EffortLLM(FakeActionLLM):
    """Records the reasoning effort that is active when the model is called."""

    seen: list[str | None]

    def invoke(
        self,
        messages: list[dict[str, Any]],
        *,
        system: str | None = None,
        tools: list[dict[str, Any]] | None = None,
    ) -> AgentLLMResponse:
        self.seen.append(get_active_reasoning_effort())
        return super().invoke(messages, system=system, tools=tools)


# The shell's action model is resolved from these two bindings; patching both
# follows the repo's own action-turn suite.
_ACTION_LLM_FACTORY_PATCHES = (
    "core.agent_harness.turns.headless_build.default_llm_factory",
    "surfaces.interactive_shell.runtime.action_turn.default_llm_factory",
)


def _effort_turns(
    efforts: list[ReasoningEffort | None], monkeypatch: pytest.MonkeyPatch
) -> list[str | None]:
    """Run one shell turn per effort on one session and handler; return what the model saw."""
    llm = _EffortLLM([no_tool_response(f"Reply {i}.") for i in range(len(efforts))])
    llm.seen = []
    for target in _ACTION_LLM_FACTORY_PATCHES:
        monkeypatch.setattr(target, lambda: llm)
    monkeypatch.setattr("core.llm.hosted_credits.prefetch_hosted_credits", lambda: None)
    console = Console(file=io.StringIO())
    session = Session()
    handler = TurnRunner(
        console=console,
        agent_build=shell_agent_build_config(),
        retain_only_current_session=True,
    )
    for i, effort in enumerate(efforts):
        session.reasoning_effort = effort
        execute_shell_turn(f"hello {i}", session, console, is_tty=False, handler=handler)
    return llm.seen


@pytest.mark.parametrize(
    ("effort", "expected"),
    [
        (ReasoningEffort.LOW, "low"),
        (ReasoningEffort.HIGH, "high"),
        (ReasoningEffort.MAX, "xhigh"),
        (None, None),
    ],
)
def test_session_effort_is_active_during_the_turns_model_call(
    effort: ReasoningEffort | None, expected: str | None, monkeypatch: pytest.MonkeyPatch
) -> None:
    """``/effort`` on the session is the effort the model call sees; unset means the default."""
    monkeypatch.delenv("OPENSRE_REASONING_EFFORT", raising=False)
    assert _effort_turns([effort], monkeypatch) == [expected]


def test_effort_changed_between_turns_reaches_the_next_turn(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Changing ``/effort`` mid-session takes effect on the next turn, and clearing it too."""
    monkeypatch.delenv("OPENSRE_REASONING_EFFORT", raising=False)
    efforts = [ReasoningEffort.LOW, ReasoningEffort.MAX, None]
    assert _effort_turns(efforts, monkeypatch) == ["low", "xhigh", None]


# ───────────────────────────── C. First-turn warm-up ──────────────────────
# Each scenario boots the shell in a fresh interpreter. One shell runs per
# process, so state a warm-up keeps per process starts clean in every scenario.
_WARMUP_SCENARIO = r'''
import asyncio, io, json, os, sys, threading, time
from pathlib import Path

from prompt_toolkit.application import create_app_session
from prompt_toolkit.input.defaults import create_pipe_input
from prompt_toolkit.output import DummyOutput
from rich.console import Console

import config.constants as const_module
import core.llm.factory as llm_factory
import core.llm.hosted_credits as hosted_credits
import surfaces.interactive_shell.command_registry.choice_prompt as choice_prompt
import surfaces.interactive_shell.controller as shell_controller
import surfaces.interactive_shell.main as main_entrypoint
import surfaces.interactive_shell.runtime.background.workers as background_workers
import surfaces.interactive_shell.runtime.slash_adapter as slash_adapter
import surfaces.interactive_shell.runtime.startup.demo_picker as demo_picker
from config.repl_config import ReplConfig

mode, home = sys.argv[1], Path(sys.argv[2])
ran = []
state = {"menu_shown": False, "menu_pending": False}
# In "client_stuck" / "credits_stuck" mode that step blocks until released.
stuck = {"client_stuck": "client", "credits_stuck": "credits"}.get(mode)
started = {"client": threading.Event(), "credits": threading.Event()}
release = threading.Event()


class _SessionStore:
    def open_store(self, _s): return None
    def refresh_from_storage(self, _s): return None
    def flush(self, _s): return None
    def close(self, _s): return None


def _client(*_a, **_k):
    ran.append("client")
    started["client"].set()
    if mode == "client_fails":
        raise RuntimeError("Missing LLM credentials.")
    if stuck == "client":
        release.wait(60)


def _credits():
    ran.append("credits")
    started["credits"].set()
    if stuck == "credits":
        release.wait(60)


async def _input_loop(**kwargs):
    # The user sits on the onboarding menu without typing.
    state["menu_shown"] = True
    try:
        await _sit_on_menu(kwargs)
    finally:
        state["left_menu_at"] = time.monotonic()


async def _sit_on_menu(kwargs):
    state["menu_pending"] = kwargs["session"].pending_user_choice is not None
    if stuck:
        # Stay on the menu until the blocking step has started, then quit.
        deadline = time.monotonic() + 10.0
        while time.monotonic() < deadline and not started[stuck].is_set():
            await asyncio.sleep(0.02)
        await asyncio.sleep(0.3)
        return
    deadline = time.monotonic() + 5.0
    while time.monotonic() < deadline and not ("client" in ran and "credits" in ran):
        await asyncio.sleep(0.02)


# Outside services only: session file, GitHub snapshot, scheduler service check.
const_module.OPENSRE_HOME_DIR = home
import config.constants.paths as const_paths
const_paths.OPENSRE_HOME_DIR = home
main_entrypoint.identify_saved_github_username = lambda: None
main_entrypoint.SessionManager.for_session = staticmethod(lambda _s: _SessionStore())
background_workers.capture_github_connection_snapshot = lambda _s: None
background_workers._restart_stale_scheduler = lambda: None
# Make the real offer_demo open the onboarding menu.
demo_picker.is_test_run = lambda: False
demo_picker.is_onboarding_enabled = lambda: True
demo_picker.repl_tty_interactive = lambda: True
demo_picker.capture_onboarding_demo_prompted = lambda: None
demo_picker.merge_in_progress = lambda _cwd: False
choice_prompt.repl_tty_interactive = lambda: True
slash_adapter.repl_tty_interactive = lambda: True
# The two first-turn steps, observed where every caller reaches them.
llm_factory.get_llm = _client
hosted_credits.prefetch_hosted_credits = _credits
# Only the keyboard loop is replaced; the controller itself is real.
shell_controller.run_input_loop = _input_loop

outcome = {}


screen = io.StringIO()


def _shell():
    async def _main():
        with create_pipe_input() as keys, create_app_session(input=keys, output=DummyOutput()):
            return await main_entrypoint.run_repl_async(
                config=ReplConfig(), console=Console(file=screen, width=200)
            )
    try:
        outcome["rc"] = asyncio.run(_main())
    except BaseException as exc:
        outcome["error"] = f"{type(exc).__name__}: {exc}"
    outcome["returned_at"] = time.monotonic()


shell = threading.Thread(target=_shell, daemon=True)
shell.start()
shell.join(20.0)
exited = not shell.is_alive()
# Steps may finish on a background thread after the shell returns.
deadline = time.monotonic() + 3.0
both_ran = lambda: "client" in ran and "credits" in ran
while not stuck and time.monotonic() < deadline and not both_ran():
    time.sleep(0.02)
teardown = (
    outcome["returned_at"] - state["left_menu_at"]
    if "returned_at" in outcome and "left_menu_at" in state
    else None
)
print("RESULT " + json.dumps({
    "exited": exited, "teardown_seconds": teardown, "ran": ran,
    "started": {step: event.is_set() for step, event in started.items()},
    "menu_shown": state["menu_shown"], "menu_pending": state["menu_pending"],
    "screen": screen.getvalue(),
    **{k: v for k, v in outcome.items() if k != "returned_at"},
}), flush=True)
if not stuck:
    release.set()
# A normal interpreter exit: anything still running that would keep the
# process alive shows up as a process that does not end.
sys.exit(0)
'''


def _boot_shell(mode: str, tmp_path: Path) -> dict[str, Any]:
    """Run ``run_repl_async`` with the real ``offer_demo`` and controller; return what happened."""
    repo_root = Path(main_entrypoint.__file__).resolve().parents[2]
    home = tmp_path
    home.mkdir(parents=True, exist_ok=True)
    env = {
        **os.environ,
        "PYTHONPATH": os.pathsep.join([str(repo_root), os.environ.get("PYTHONPATH", "")]),
        "OPENSRE_NO_TELEMETRY": "1",
        "OPENSRE_SENTRY_DISABLED": "1",
    }
    try:
        proc = subprocess.run(
            [sys.executable, "-c", _WARMUP_SCENARIO, mode, str(home)],
            cwd=repo_root,
            env=env,
            capture_output=True,
            text=True,
            timeout=60,
        )
        stdout, stderr, process_exited = proc.stdout, proc.stderr, True
    except subprocess.TimeoutExpired as exc:
        stdout = exc.stdout.decode() if isinstance(exc.stdout, bytes) else exc.stdout or ""
        stderr = exc.stderr.decode() if isinstance(exc.stderr, bytes) else exc.stderr or ""
        process_exited = False
    lines = [line for line in stdout.splitlines() if line.startswith("RESULT ")]
    assert lines, f"the shell scenario printed no result:\n{stdout[-2000:]}\n{stderr[-4000:]}"
    return {
        **json.loads(lines[-1][len("RESULT ") :]),
        "process_exited": process_exited,
        "stderr": stderr,
    }


def test_both_first_turn_steps_run_while_the_menu_is_up(tmp_path: Path) -> None:
    """With the menu on screen, the client build and the credit read both happen."""
    result = _boot_shell("steps", tmp_path)
    assert result["exited"] and result.get("rc") == 0, result
    assert result["menu_pending"], "the onboarding menu was not offered"
    assert "client" in result["ran"] and "credits" in result["ran"], result


def test_credit_read_still_runs_after_a_client_build_failure(tmp_path: Path) -> None:
    """A client build that raises stays quiet and does not stop the credit read."""
    result = _boot_shell("client_fails", tmp_path / "fails")
    assert result["exited"] and result.get("rc") == 0, result
    assert result["menu_pending"]
    assert "client" in result["ran"] and "credits" in result["ran"], result
    # The failed prep shows nothing on the terminal while the user is on the menu:
    # the screen matches a launch whose client build succeeds.
    healthy = _boot_shell("steps", tmp_path / "healthy")
    assert result["screen"] == healthy["screen"], result["screen"][-2000:]
    assert "Missing LLM credentials" not in result["stderr"], result["stderr"][-2000:]


@pytest.mark.parametrize("step", ["client", "credits"])
def test_a_stuck_warm_up_holds_up_neither_the_prompt_nor_the_exit(
    step: str, tmp_path: Path
) -> None:
    """A client build or a credit read that never returns: the prompt opens and the shell exits."""
    what = {"client": "client build", "credits": "credit read"}[step]
    result = _boot_shell(f"{step}_stuck", tmp_path)
    assert result["started"][step], f"the {what} never started"
    assert result["menu_shown"], f"the prompt never opened while the {what} was stuck"
    assert result["exited"], f"the shell did not exit while the {what} was stuck"
    assert result.get("rc") == 0, result
    # Leaving the shell takes a few seconds at most, and the process really ends.
    assert result["teardown_seconds"] is not None and result["teardown_seconds"] < 10.0, result
    assert result["process_exited"], f"the process stayed alive behind the stuck {what}"


# ───────────────────────────── D. Hosted credit cache ─────────────────────
class _Ledger:
    """Answers the hosted credit endpoint and counts the reads."""

    def __init__(self) -> None:
        self.reads = 0
        self.answer: Any = 250

    def get(self, url: str, **_kwargs: Any) -> httpx.Response:
        self.reads += 1
        request = httpx.Request("GET", url)
        if self.answer == "unreachable":
            raise httpx.ConnectError("connection refused", request=request)
        if self.answer == "server_error":
            return httpx.Response(503, request=request)
        return httpx.Response(200, json={"total": self.answer}, request=request)


class _Clock:
    def __init__(self) -> None:
        self.now = 1000.0

    def __call__(self) -> float:
        return self.now


@pytest.fixture
def ledger(monkeypatch: pytest.MonkeyPatch) -> Any:
    book = _Ledger()
    clock = _Clock()
    monkeypatch.setattr(httpx, "get", book.get)
    monkeypatch.setattr(time, "monotonic", clock)
    monkeypatch.setattr(time, "time", clock)
    monkeypatch.setattr(
        account_credits,
        "load_account_record",
        lambda: SimpleNamespace(app_url="https://app.opensre.test"),
    )
    monkeypatch.setattr(account_credits, "resolve_account_token", lambda: "osre_pat_cli_token")
    account_credits.reset_hosted_credits_cache()
    yield SimpleNamespace(book=book, clock=clock)
    account_credits.reset_hosted_credits_cache()


def _credits_left() -> int | None:
    read = account_credits.fetch_hosted_credits()
    return read.credits.total if read.credits is not None else None


@pytest.mark.parametrize("total", [250, 7])
def test_a_funded_balance_is_reused_for_up_to_a_minute(ledger: Any, total: int) -> None:
    """A balance with credits left answers later reads for a minute, then is read again."""
    ledger.book.answer = total
    assert _credits_left() == total
    ledger.clock.now += 30
    assert _credits_left() == total
    assert ledger.book.reads == 1
    ledger.book.answer = total + 1
    ledger.clock.now += 65
    assert _credits_left() == total + 1
    assert ledger.book.reads == 2


@pytest.mark.parametrize("answer", [0, "server_error", "unreachable"])
def test_an_empty_or_unreadable_balance_is_read_again_soon(ledger: Any, answer: Any) -> None:
    """A zero or unreadable balance is not trusted for long."""
    ledger.book.answer = answer
    first = _credits_left()
    assert first == (0 if answer == 0 else None)
    ledger.book.answer = 40
    ledger.clock.now += 10
    assert _credits_left() == 40
    assert ledger.book.reads >= 2


class _ProxyError(Exception):
    """Shaped like the OpenAI SDK error the hosted proxy's refusal arrives as."""

    def __init__(self, message: str, *, code: str, body: dict[str, object]) -> None:
        super().__init__(message)
        self.code = code
        self.body = body


def test_a_credit_exhausted_answer_drops_the_cached_balance(ledger: Any) -> None:
    """Once the hosted proxy reports exhaustion, the next read does not reuse the old balance."""
    ledger.book.answer = 500
    assert _credits_left() == 500
    reads_before = ledger.book.reads
    err = _ProxyError(
        "Payment required",
        code="opensre_credits_exhausted",
        body={"code": "opensre_credits_exhausted", "message": "OpenSRE credits are exhausted"},
    )
    with pytest.raises(OpenSRECreditsExhaustedError):
        maybe_raise_credit_exhausted("OpenAI", err)
    ledger.book.answer = 0
    ledger.clock.now += 2
    assert _credits_left() == 0
    assert ledger.book.reads == reads_before + 1
