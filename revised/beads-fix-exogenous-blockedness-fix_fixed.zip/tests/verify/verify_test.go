// External-package (embeddeddolt_test) behavioral tests over the exported
// EmbeddedDoltStore. Every assertion goes through existing store methods:
// CreateIssue, AddDependency / AddDependencyWithOptions, CloseIssue,
// GetReadyWork, IsBlockedBatch, RunInTransaction, Commit and the
// BlockedRecomputer capability. No internal helper is named, so the checks
// hold for any internal layout of the blocked-state computation.
//
// The store runs the embedded Dolt engine in-process over cgo, so these tests
// need the cgo build and compile only under it.

//go:build cgo

package embeddeddolt_test

import (
	"context"
	"errors"
	"sort"
	"strings"
	"testing"

	"github.com/steveyegge/beads/internal/storage"
	"github.com/steveyegge/beads/internal/types"
	"github.com/steveyegge/beads/issueops"
)

// mkIssue creates one open, permanent task through the store.
func mkIssue(t *testing.T, ctx context.Context, te *testEnv, id string) {
	t.Helper()
	err := te.store.CreateIssue(ctx, &types.Issue{
		ID:        id,
		Title:     id,
		Status:    types.StatusOpen,
		Priority:  2,
		IssueType: types.TypeTask,
	}, "tester")
	if err != nil {
		t.Fatalf("create issue %s: %v", id, err)
	}
}

// addEdge adds a dependency edge through the normal store write path (cycle and
// hierarchy guards active).
func addEdge(t *testing.T, ctx context.Context, te *testEnv, issueID, dependsOnID string, depType types.DependencyType) {
	t.Helper()
	err := te.store.AddDependency(ctx, &types.Dependency{
		IssueID:     issueID,
		DependsOnID: dependsOnID,
		Type:        depType,
	}, "tester")
	if err != nil {
		t.Fatalf("add dep %s -> %s (%s): %v", issueID, dependsOnID, depType, err)
	}
}

// addEdgeSkippingCycleCheck adds an edge that closes a loop. It builds the
// "epic blocks on its own children" shape, where the epic already depends on
// items that are then filed beneath it. The transaction surface honors
// SkipCycleCheck; the store-level call builds its own options and does not.
func addEdgeSkippingCycleCheck(t *testing.T, ctx context.Context, te *testEnv, issueID, dependsOnID string, depType types.DependencyType) {
	t.Helper()
	err := te.store.RunInTransaction(ctx, "test: seed close-gate edge", func(tx storage.Transaction) error {
		return tx.AddDependencyWithOptions(ctx,
			&types.Dependency{IssueID: issueID, DependsOnID: dependsOnID, Type: depType},
			"tester", storage.DependencyAddOptions{SkipCycleCheck: true})
	})
	if err != nil {
		t.Fatalf("add dep (skip cycle) %s -> %s (%s): %v", issueID, dependsOnID, depType, err)
	}
}

// readySet returns the set of issue IDs the store reports as ready-to-work.
func readySet(t *testing.T, ctx context.Context, te *testEnv) map[string]bool {
	t.Helper()
	ready, err := te.store.GetReadyWork(ctx, types.WorkFilter{Status: types.StatusOpen})
	if err != nil {
		t.Fatalf("GetReadyWork: %v", err)
	}
	set := map[string]bool{}
	for _, issue := range ready {
		set[issue.ID] = true
	}
	return set
}

// blockedFlags returns the stored is-blocked flag (the one `bd blocked` lists
// by) for the given ids.
func blockedFlags(t *testing.T, ctx context.Context, te *testEnv, ids ...string) map[string]bool {
	t.Helper()
	got, err := te.store.IsBlockedBatch(ctx, ids)
	if err != nil {
		t.Fatalf("IsBlockedBatch: %v", err)
	}
	return got
}

// seedCloseGate builds a close-gate epic: P blocks on C1 and C2 (so P cannot
// close until they finish), and C1, C2 are then filed under P. The blocks edges
// go in before the hierarchy exists; the parent-child edges close the gate.
func seedCloseGate(t *testing.T, ctx context.Context, te *testEnv, p, c1, c2 string) {
	t.Helper()
	mkIssue(t, ctx, te, p)
	mkIssue(t, ctx, te, c1)
	mkIssue(t, ctx, te, c2)
	addEdge(t, ctx, te, p, c1, types.DepBlocks)
	addEdge(t, ctx, te, p, c2, types.DepBlocks)
	addEdgeSkippingCycleCheck(t, ctx, te, c1, p, types.DepParentChild)
	addEdgeSkippingCycleCheck(t, ctx, te, c2, p, types.DepParentChild)
}

// recomputeAllBlocked runs a full repair of the is-blocked projection and
// returns how many rows it had to correct. The full repair refuses a dirty
// working set, so commit the staged writes first (matching the store's own
// recompute precondition).
func recomputeAllBlocked(t *testing.T, ctx context.Context, te *testEnv) int {
	t.Helper()
	if err := te.store.Commit(ctx, "seed consistent graph"); err != nil {
		t.Fatalf("commit before recompute: %v", err)
	}
	rc, ok := storage.UnwrapStore(te.store).(storage.BlockedRecomputer)
	if !ok {
		t.Fatalf("store does not expose BlockedRecomputer")
	}
	changed, err := rc.RecomputeAllBlocked(ctx)
	if err != nil {
		t.Fatalf("RecomputeAllBlocked: %v", err)
	}
	return changed
}

// TestReadyChildrenUnderCloseGate: the children of an epic that blocks only on
// items inside its own subtree are ready and not blocked, and the epic itself
// stays blocked and out of ready work.
func TestReadyChildrenUnderCloseGate(t *testing.T) {
	te := newTestEnv(t, "cg")
	ctx := t.Context()

	seedCloseGate(t, ctx, te, "cg-p", "cg-c1", "cg-c2")

	ready := readySet(t, ctx, te)
	for _, child := range []string{"cg-c1", "cg-c2"} {
		if !ready[child] {
			t.Errorf("%s missing from ready work: the children of a close-gate epic must stay workable", child)
		}
	}
	if ready["cg-p"] {
		t.Error("cg-p is ready, but it still blocks on two open children")
	}

	flags := blockedFlags(t, ctx, te, "cg-p", "cg-c1", "cg-c2")
	if !flags["cg-p"] {
		t.Error("cg-p should report blocked: it depends on two open children")
	}
	if flags["cg-c1"] || flags["cg-c2"] {
		t.Errorf("close-gate children must not be blocked: cg-c1=%v cg-c2=%v", flags["cg-c1"], flags["cg-c2"])
	}
}

// TestReadyGrandchildUnderCloseGate: the close gate sits over a grandchild.
// P blocks on G, and G lives two parent-child levels below P (under child C),
// next to a second child C2 that P does not block on. P stays blocked; C, C2
// and G are ready and not blocked. A full repair afterwards corrects nothing.
func TestReadyGrandchildUnderCloseGate(t *testing.T) {
	te := newTestEnv(t, "gc")
	ctx := t.Context()

	for _, id := range []string{"gc-p", "gc-c", "gc-c2", "gc-g"} {
		mkIssue(t, ctx, te, id)
	}
	// Gate goes in while P and G are unrelated.
	addEdge(t, ctx, te, "gc-p", "gc-g", types.DepBlocks)
	addEdge(t, ctx, te, "gc-c", "gc-p", types.DepParentChild)
	addEdge(t, ctx, te, "gc-c2", "gc-p", types.DepParentChild)
	// The edge that files G under C closes the gate; it skips the cycle guard,
	// since P already blocks on G.
	addEdgeSkippingCycleCheck(t, ctx, te, "gc-g", "gc-c", types.DepParentChild)

	flags := blockedFlags(t, ctx, te, "gc-p", "gc-c", "gc-c2", "gc-g")
	if !flags["gc-p"] {
		t.Error("gc-p should report blocked: it still depends on an open grandchild")
	}
	for _, id := range []string{"gc-c", "gc-c2", "gc-g"} {
		if flags[id] {
			t.Errorf("%s is under gc-p's own subtree and must not be blocked by the close gate", id)
		}
	}

	ready := readySet(t, ctx, te)
	for _, id := range []string{"gc-c", "gc-c2", "gc-g"} {
		if !ready[id] {
			t.Errorf("%s missing from ready work: everything under a close-gate epic must stay workable, including the grandchild that frees it", id)
		}
	}
	if ready["gc-p"] {
		t.Error("gc-p is ready, but it still blocks on an open grandchild")
	}

	ids := []string{"gc-p", "gc-c", "gc-c2", "gc-g"}
	incremental := blockedFlags(t, ctx, te, ids...)
	if changed := recomputeAllBlocked(t, ctx, te); changed != 0 {
		t.Errorf("full repair corrected %d rows on the grandchild close gate; it must find nothing to correct", changed)
	}
	if fullRepair := blockedFlags(t, ctx, te, ids...); !sameFlags(incremental, fullRepair) {
		t.Errorf("incremental vs full-repair is_blocked disagree: incremental=%v full-repair=%v", incremental, fullRepair)
	}
}

// TestExogenousBlockednessStillPropagates: a parent blocked by an item outside
// its own subtree passes that block down to its children, which report blocked
// and stay out of ready work. A full repair afterwards corrects nothing.
func TestExogenousBlockednessStillPropagates(t *testing.T) {
	te := newTestEnv(t, "exo")
	ctx := t.Context()

	for _, id := range []string{"exo-p", "exo-c1", "exo-c2", "exo-x"} {
		mkIssue(t, ctx, te, id)
	}
	// P is blocked by X, which lives outside P's subtree.
	addEdge(t, ctx, te, "exo-p", "exo-x", types.DepBlocks)
	// C1, C2 are children of P.
	addEdge(t, ctx, te, "exo-c1", "exo-p", types.DepParentChild)
	addEdge(t, ctx, te, "exo-c2", "exo-p", types.DepParentChild)

	flags := blockedFlags(t, ctx, te, "exo-x", "exo-p", "exo-c1", "exo-c2")
	if flags["exo-x"] {
		t.Error("exo-x is open and unblocked; it must not report blocked")
	}
	if !flags["exo-p"] {
		t.Error("exo-p is blocked by the external exo-x and must report blocked")
	}
	if !flags["exo-c1"] || !flags["exo-c2"] {
		t.Errorf("children of an externally-blocked parent must inherit the block: exo-c1=%v exo-c2=%v", flags["exo-c1"], flags["exo-c2"])
	}

	ready := readySet(t, ctx, te)
	for _, id := range []string{"exo-c1", "exo-c2"} {
		if ready[id] {
			t.Errorf("%s is ready, but its parent is blocked by an external item", id)
		}
	}

	ids := []string{"exo-x", "exo-p", "exo-c1", "exo-c2"}
	incremental := blockedFlags(t, ctx, te, ids...)
	if changed := recomputeAllBlocked(t, ctx, te); changed != 0 {
		t.Errorf("full repair corrected %d rows under an externally blocked parent; it must find nothing to correct", changed)
	}
	if fullRepair := blockedFlags(t, ctx, te, ids...); !sameFlags(incremental, fullRepair) {
		t.Errorf("incremental vs full-repair is_blocked disagree: incremental=%v full-repair=%v", incremental, fullRepair)
	}
}

// TestExogenousBlockednessPropagatesThroughNestedCloseGate: a close-gate epic
// that sits under an epic blocked from outside still passes the outside block
// down. Q is blocked by external X. P is a child of Q and is itself a
// close-gate epic (P blocks on its own child C). The block from X reaches P
// through Q and reaches C through P, so C reports blocked and is not ready.
// A full repair afterwards corrects nothing.
func TestExogenousBlockednessPropagatesThroughNestedCloseGate(t *testing.T) {
	te := newTestEnv(t, "nx")
	ctx := t.Context()

	for _, id := range []string{"nx-x", "nx-q", "nx-p", "nx-c"} {
		mkIssue(t, ctx, te, id)
	}
	// Q is blocked by X, which lives outside the Q/P/C subtree.
	addEdge(t, ctx, te, "nx-q", "nx-x", types.DepBlocks)
	// The close gate on P goes in while P and C are unrelated: P blocks on C.
	addEdge(t, ctx, te, "nx-p", "nx-c", types.DepBlocks)
	// P is a child of Q (no cycle: Q blocks only on X).
	addEdge(t, ctx, te, "nx-p", "nx-q", types.DepParentChild)
	// C is a child of P; this closes the gate (P already blocks on C), so it
	// must skip the cycle guard.
	addEdgeSkippingCycleCheck(t, ctx, te, "nx-c", "nx-p", types.DepParentChild)

	flags := blockedFlags(t, ctx, te, "nx-x", "nx-q", "nx-p", "nx-c")
	if flags["nx-x"] {
		t.Error("nx-x is open and unblocked; it must not report blocked")
	}
	if !flags["nx-q"] {
		t.Error("nx-q should report blocked: it depends on the external nx-x")
	}
	if !flags["nx-p"] {
		t.Error("nx-p should report blocked: its parent nx-q is blocked from outside the subtree, so the external block reaches P")
	}
	if !flags["nx-c"] {
		t.Error("nx-c should report blocked: the external block above its epic propagates all the way down; it is not merely gated by its own in-subtree epic")
	}

	ready := readySet(t, ctx, te)
	if ready["nx-c"] {
		t.Error("nx-c is ready, but the epic above it is blocked by an external item, so the block reaches C")
	}

	ids := []string{"nx-x", "nx-q", "nx-p", "nx-c"}
	incremental := blockedFlags(t, ctx, te, ids...)
	if changed := recomputeAllBlocked(t, ctx, te); changed != 0 {
		t.Errorf("full repair corrected %d rows on the nested close gate; it must find nothing to correct", changed)
	}
	if fullRepair := blockedFlags(t, ctx, te, ids...); !sameFlags(incremental, fullRepair) {
		t.Errorf("incremental vs full-repair is_blocked disagree: incremental=%v full-repair=%v", incremental, fullRepair)
	}
}

// The four TestCloseGateWithOutside* tests cover an epic held both by its own
// close gate and by an outside item. P blocks on its child M1 and on the
// unrelated Y, and M2 is a second child P does not block on. While Y is open
// the outside block reaches both children. After Y closes, P is held only by
// M1, so M1 and M2 come back as ready while P stays blocked. A full repair
// corrects nothing at either point. The outside edge is a blocks or a
// conditional-blocks edge, and it goes in either before the children are filed
// under P or after the gate already exists.

func TestCloseGateWithOutsideBlocker(t *testing.T) {
	checkCloseGateWithOutsideBlocker(t, "mba", types.DepBlocks, false)
}

func TestCloseGateWithOutsideBlockerAddedLater(t *testing.T) {
	checkCloseGateWithOutsideBlocker(t, "mbb", types.DepBlocks, true)
}

func TestCloseGateWithOutsideConditionalBlocker(t *testing.T) {
	checkCloseGateWithOutsideBlocker(t, "mca", types.DepConditionalBlocks, false)
}

func TestCloseGateWithOutsideConditionalBlockerAddedLater(t *testing.T) {
	checkCloseGateWithOutsideBlocker(t, "mcb", types.DepConditionalBlocks, true)
}

func checkCloseGateWithOutsideBlocker(t *testing.T, prefix string, outsideType types.DependencyType, outsideLast bool) {
	t.Helper()
	te := newTestEnv(t, prefix)
	ctx := t.Context()
	p, m1, m2, y := prefix+"-p", prefix+"-m1", prefix+"-m2", prefix+"-y"
	ids := []string{p, m1, m2}

	for _, id := range []string{p, m1, m2, y} {
		mkIssue(t, ctx, te, id)
	}
	addEdge(t, ctx, te, p, m1, types.DepBlocks)
	if !outsideLast {
		addEdge(t, ctx, te, p, y, outsideType)
	}
	// Filing M1 under P closes the gate, so it skips the cycle guard.
	addEdgeSkippingCycleCheck(t, ctx, te, m1, p, types.DepParentChild)
	addEdge(t, ctx, te, m2, p, types.DepParentChild)
	if outsideLast {
		addEdge(t, ctx, te, p, y, outsideType)
	}

	flags := blockedFlags(t, ctx, te, y, p, m1, m2)
	if flags[y] {
		t.Errorf("%s is open and unblocked; it must not report blocked", y)
	}
	if !flags[p] {
		t.Errorf("%s should report blocked: it depends on the open %s and %s", p, y, m1)
	}
	if !flags[m1] || !flags[m2] {
		t.Errorf("children of an epic held by the outside %s (%s edge) must inherit the block: %s=%v %s=%v", y, outsideType, m1, flags[m1], m2, flags[m2])
	}
	ready := readySet(t, ctx, te)
	for _, id := range ids {
		if ready[id] {
			t.Errorf("%s is ready while the outside %s still holds its epic", id, y)
		}
	}
	assertFullRepairAgrees(t, ctx, te, ids...)

	if err := te.store.CloseIssue(ctx, y, "done", "tester", ""); err != nil {
		t.Fatalf("close %s: %v", y, err)
	}

	flags = blockedFlags(t, ctx, te, p, m1, m2)
	if !flags[p] {
		t.Errorf("%s should still report blocked: it depends on the open %s", p, m1)
	}
	if flags[m1] || flags[m2] {
		t.Errorf("after %s closed, only the close gate holds %s, so its children must not be blocked: %s=%v %s=%v", y, p, m1, flags[m1], m2, flags[m2])
	}
	ready = readySet(t, ctx, te)
	for _, id := range []string{m1, m2} {
		if !ready[id] {
			t.Errorf("%s missing from ready work after the outside blocker %s closed", id, y)
		}
	}
	if ready[p] {
		t.Errorf("%s is ready, but it still blocks on the open %s", p, m1)
	}
	assertFullRepairAgrees(t, ctx, te, ids...)
}

// assertFullRepairAgrees reads the blocked flags for ids, runs a full repair and
// reads them again. The repair must correct nothing and both reads must match.
func assertFullRepairAgrees(t *testing.T, ctx context.Context, te *testEnv, ids ...string) {
	t.Helper()
	incremental := blockedFlags(t, ctx, te, ids...)
	if changed := recomputeAllBlocked(t, ctx, te); changed != 0 {
		t.Errorf("full repair corrected %d rows; it must find nothing to correct", changed)
	}
	if fullRepair := blockedFlags(t, ctx, te, ids...); !sameFlags(incremental, fullRepair) {
		t.Errorf("incremental vs full-repair is_blocked disagree: incremental=%v full-repair=%v", incremental, fullRepair)
	}
}

// TestIncrementalAgreesWithFullRepair: the blocked flags kept up by ordinary
// writes match a full repair. The close-gate shape is built through the normal
// write path, the flags are read, a full repair runs, and the flags are read
// again. The repair corrects nothing and both reads are identical.
func TestIncrementalAgreesWithFullRepair(t *testing.T) {
	te := newTestEnv(t, "ls")
	ctx := t.Context()

	seedCloseGate(t, ctx, te, "ls-p", "ls-c1", "ls-c2")
	ids := []string{"ls-p", "ls-c1", "ls-c2"}

	incremental := blockedFlags(t, ctx, te, ids...)

	if changed := recomputeAllBlocked(t, ctx, te); changed != 0 {
		t.Errorf("full repair corrected %d rows over an incrementally-maintained graph; the two recompute paths disagree", changed)
	}

	fullRepair := blockedFlags(t, ctx, te, ids...)
	if !sameFlags(incremental, fullRepair) {
		t.Errorf("incremental vs full-repair is_blocked disagree: incremental=%v full-repair=%v", incremental, fullRepair)
	}
}

// TestDependencyHierarchyRefusalUnchanged: adding a blocks edge from an item
// onto its own descendant is refused with the typed hierarchy-conflict error,
// and a blocks edge onto an unrelated item is still accepted. The refusal is
// matched by its error type, its descendant flag and the fixed part of its
// message.
func TestDependencyHierarchyRefusalUnchanged(t *testing.T) {
	te := newTestEnv(t, "hc")
	ctx := t.Context()

	mkIssue(t, ctx, te, "hc-p")
	mkIssue(t, ctx, te, "hc-c")
	// hc-c is a child of hc-p.
	addEdge(t, ctx, te, "hc-c", "hc-p", types.DepParentChild)

	// Attempting a blocks edge from the ancestor onto its own descendant must be
	// refused with a hierarchy conflict.
	err := te.store.AddDependency(ctx, &types.Dependency{
		IssueID:     "hc-p",
		DependsOnID: "hc-c",
		Type:        types.DepBlocks,
	}, "tester")
	if err == nil {
		t.Fatal("blocks edge from an ancestor onto its own descendant was accepted; the hierarchy refusal is gone")
	}
	var conflict *issueops.DependencyHierarchyConflictError
	if !errors.As(err, &conflict) {
		t.Fatalf("expected a DependencyHierarchyConflictError, got %T: %v", err, err)
	}
	if conflict.BlockerIsAncestor {
		t.Errorf("blocker hc-c is a descendant of hc-p, so BlockerIsAncestor must be false, got true")
	}
	if !strings.Contains(err.Error(), "cannot be blocked by its descendant") {
		t.Errorf("refusal message changed: got %q, want it to contain %q", err.Error(), "cannot be blocked by its descendant")
	}

	// A blocking edge between unrelated items is still accepted.
	mkIssue(t, ctx, te, "hc-free")
	addEdge(t, ctx, te, "hc-p", "hc-free", types.DepBlocks)
}

func sameFlags(a, b map[string]bool) bool {
	if len(a) != len(b) {
		return false
	}
	keys := make([]string, 0, len(a))
	for k := range a {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	for _, k := range keys {
		if a[k] != b[k] {
			return false
		}
	}
	return true
}
