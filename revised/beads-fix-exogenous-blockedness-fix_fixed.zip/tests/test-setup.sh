#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
cd /repo/beads

# Offline switches: a cache miss fails fast instead of reaching for a dead
# network. Dependencies are baked into the image (module and build cache), so
# everything resolves from the cache.
export GOFLAGS=-mod=mod
export GOPROXY=off
export CGO_ENABLED=1

# Dependencies: offline-first against the image bake, logged online fallback.
if go mod download > /tmp/test-setup-install.log 2>&1; then
    echo "[offline-first] go modules satisfied from image"
elif GOPROXY=https://proxy.golang.org GOFLAGS=-mod=mod go mod download >> /tmp/test-setup-install.log 2>&1; then
    echo "[test-setup] go modules downloaded online (image bake was stale)"
else
    tail -40 /tmp/test-setup-install.log >&2; exit 1
fi

# No services to start and no data to seed: the bug reproduces fully in-process
# through the embedded (cgo) Dolt store exercised by the Go verifier. No
# assertion logic here.
