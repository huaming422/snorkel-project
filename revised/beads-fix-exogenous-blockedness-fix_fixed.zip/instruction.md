## Task

Whole epics are disappearing from `bd ready` for us.
It happens with the usual close-gate setup.
An epic gets `blocks` dependencies on a set of items, and those items are then filed under the epic as its children, so nobody can close the epic before they are done.
Once the gate is in place, every item under the epic comes back blocked.
`bd ready` shows none of them and `bd blocked` lists all of them, even though the only thing they wait on is their own epic.
Nothing clears it later either, so that part of the tree is stuck for good.

What we expect instead:

- An item under a close-gated epic that has nothing else holding it shows up in `bd ready` and stays out of `bd blocked`, including a grandchild the gate points at two levels down and the epic's other children in that setup.
- The epic itself still counts as blocked until the items it waits on are closed, so it stays out of `bd ready` until then and shows up there once the last of them closes and nothing else holds it.
- Anything outside an epic's own subtree that keeps the epic blocked (an open `blocks` or `conditional-blocks` target, or a `waits-for` gate whose target still has open children) also blocks every item under that epic until it clears, including when it sits on the epic that a close-gated epic is filed under.
- If an epic has its own close gate and is also held by one of those outside reasons, the items under it stay blocked while that reason holds and come back into `bd ready` once it clears, whether the outside dependency was added before or after the gate.
- After any of these changes, `bd recompute-blocked` finds nothing to correct.
- Making an epic block on one of its own children after the child is filed under it is still refused with the same "cannot be blocked by its descendant" error as today.
