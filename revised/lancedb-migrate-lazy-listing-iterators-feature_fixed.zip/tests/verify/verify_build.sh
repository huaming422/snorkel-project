#!/usr/bin/env bash
# Workspace build check for the listing change.
#
# Builds the test targets of every workspace member, then the core crate's test
# targets with the remote feature on. It names no listing types, so it reads
# only whether the tree compiles:
#
#   * `cargo build --locked --tests` over the whole workspace covers the core
#     crate, the napi and pyo3 binding crates, and every in-tree test target.
#   * `cargo build --locked --tests --features remote -p lancedb` also covers
#     the remote client code that the stories drive.
#
# The image pre-builds `cargo build --locked --tests`, so the default-feature
# build is incremental; the remote-feature build compiles the remote module
# once. A non-zero exit carries the first cargo failure.
set -euo pipefail

# Pin the toolchain the image baked, ahead of anything on PATH, and keep
# cargo off the network: the image carries the full dependency closure.
export RUSTUP_TOOLCHAIN="${RUSTUP_TOOLCHAIN:-1.97.0}"
export CARGO_TERM_COLOR="${CARGO_TERM_COLOR:-never}"
export CARGO_NET_OFFLINE="${CARGO_NET_OFFLINE:-true}"

cd /repo/lancedb

echo "[verify_build] workspace test build (default features)"
cargo build --locked --tests

echo "[verify_build] lancedb test build (--features remote)"
cargo build --locked --tests --features remote -p lancedb

echo "[verify_build] ok"
