// Shared HTTP/1.1 mock for the connection-level listing stories.
//
// Staged into `rust/lancedb/tests/listing_mock/mod.rs` by validation-setup.sh
// so every generated story test can `mod listing_mock;` and drive the public
// remote client against a loopback server, fully offline.
//
// This module owns only the per-page server wire shape that the client already
// speaks: a GET or POST to a `/list` route answered with
// `{ "<key>": [ ... ], "page_token": "..." }`. It records every request it
// receives (method, path, query string, body) and replies with the scripted
// pages it was handed, in order. It deals purely in the wire-level JSON, not in
// any client-side types.
//
// Items per kind:
//   secrets   -> { "secrets": [ { "name": <s> }, ... ], "page_token": <tok> }
//   views     -> { "views":   [ <s>, ... ],            "page_token": <tok> }
//   jobs      -> { "jobs":    [ { "job_id": <s>, "table": "t",
//                                  "job_type": "create_index",
//                                  "state": "in_progress",
//                                  "created_at_millis": 1 }, ... ],
//                  "page_token": <tok> }
//   functions -> { "functions": [ { "definition": { ...version record,
//                                                     "name": <s> } }, ... ],
//                  "page_token": <tok> }
// An empty `page_token` string means "no further page" (the client treats an
// empty token as the end of the sequence).

#![allow(dead_code)]

use std::sync::{Arc, Mutex};

use serde_json::{json, Value};
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::TcpListener;

/// One request the server observed.
#[derive(Clone, Debug)]
pub struct Recorded {
    pub method: String,
    pub path: String,
    pub query: String,
    pub body: String,
}

/// A loopback HTTP server that answers `/list` calls with scripted pages.
pub struct MockServer {
    port: u16,
    requests: Arc<Mutex<Vec<Recorded>>>,
}

impl MockServer {
    /// Bind a loopback server that will reply with `responses` (status, body)
    /// in order, one per incoming request. Returns once it is accepting.
    pub async fn start(responses: Vec<(u16, String)>) -> MockServer {
        let listener = TcpListener::bind("127.0.0.1:0")
            .await
            .expect("bind loopback listener");
        let port = listener.local_addr().expect("local addr").port();
        let requests: Arc<Mutex<Vec<Recorded>>> = Arc::new(Mutex::new(Vec::new()));

        let queue = Arc::new(Mutex::new(responses.into_iter().collect::<Vec<_>>()));
        let req_log = requests.clone();

        tokio::spawn(async move {
            loop {
                let (mut socket, _) = match listener.accept().await {
                    Ok(pair) => pair,
                    Err(_) => break,
                };

                // Read the request head.
                let mut buf: Vec<u8> = Vec::with_capacity(1024);
                let mut tmp = [0u8; 1024];
                let header_end = loop {
                    if let Some(pos) = find_subslice(&buf, b"\r\n\r\n") {
                        break pos;
                    }
                    let n = match socket.read(&mut tmp).await {
                        Ok(0) | Err(_) => break usize::MAX,
                        Ok(n) => n,
                    };
                    buf.extend_from_slice(&tmp[..n]);
                };
                if header_end == usize::MAX {
                    continue;
                }

                let head = String::from_utf8_lossy(&buf[..header_end]).to_string();
                let content_length = parse_content_length(&head);

                // Read any remaining body bytes.
                let mut body_bytes = buf[header_end + 4..].to_vec();
                while body_bytes.len() < content_length {
                    let n = match socket.read(&mut tmp).await {
                        Ok(0) | Err(_) => break,
                        Ok(n) => n,
                    };
                    body_bytes.extend_from_slice(&tmp[..n]);
                }
                body_bytes.truncate(content_length);

                let (method, target) = parse_request_line(&head);
                let (path, query) = match target.split_once('?') {
                    Some((p, q)) => (p.to_string(), q.to_string()),
                    None => (target.clone(), String::new()),
                };

                req_log.lock().unwrap().push(Recorded {
                    method,
                    path,
                    query,
                    body: String::from_utf8_lossy(&body_bytes).to_string(),
                });

                let (status, payload) = {
                    let mut q = queue.lock().unwrap();
                    if q.is_empty() {
                        (500u16, "{}".to_string())
                    } else {
                        q.remove(0)
                    }
                };

                let reason = if status == 200 { "OK" } else { "ERR" };
                let response = format!(
                    "HTTP/1.1 {status} {reason}\r\nContent-Type: application/json\r\nContent-Length: {len}\r\nConnection: close\r\n\r\n{payload}",
                    len = payload.as_bytes().len(),
                );
                let _ = socket.write_all(response.as_bytes()).await;
                let _ = socket.flush().await;
            }
        });

        MockServer { port, requests }
    }

    /// The port the server bound to.
    pub fn port(&self) -> u16 {
        self.port
    }

    /// The `http://127.0.0.1:<port>` base to hand to `host_override`.
    pub fn base_url(&self) -> String {
        format!("http://127.0.0.1:{}", self.port)
    }

    /// Every request observed so far, in arrival order.
    pub fn requests(&self) -> Vec<Recorded> {
        self.requests.lock().unwrap().clone()
    }

    /// How many requests the server has observed so far.
    pub fn request_count(&self) -> usize {
        self.requests.lock().unwrap().len()
    }
}

/// Build one `secrets` page body. `names` become `{ "name": <s> }` entries;
/// an empty `token` marks the end of the sequence.
pub fn secrets_body(names: &[String], token: &str) -> String {
    let items: Vec<Value> = names.iter().map(|n| json!({ "name": n })).collect();
    json!({ "secrets": items, "page_token": token }).to_string()
}

/// Build one `views` page body. `names` are emitted as bare strings.
pub fn views_body(names: &[String], token: &str) -> String {
    let items: Vec<Value> = names.iter().map(|n| Value::String(n.clone())).collect();
    json!({ "views": items, "page_token": token }).to_string()
}

/// Build one `jobs` page body. Each id becomes a job row with the other fields
/// filled with fixed, valid placeholders.
pub fn jobs_body(ids: &[String], token: &str) -> String {
    let items: Vec<Value> = ids
        .iter()
        .map(|id| {
            json!({
                "job_id": id,
                "table": "t",
                "job_type": "create_index",
                "state": "in_progress",
                "created_at_millis": 1
            })
        })
        .collect();
    json!({ "jobs": items, "page_token": token }).to_string()
}

/// One canonical function-version record, as the server returns it under each
/// `definition`. The `name` is substituted per entry so pages carry
/// distinguishable, orderable function names; every other field is a fixed,
/// valid placeholder so the record deserializes.
fn function_definition(name: &str) -> Value {
    json!({
        "created_at": "2026-08-21T00:00:00Z",
        "disabled": false,
        "image": {
            "descriptor": {
                "behavior": {
                    "result_stability": "input_and_context",
                    "side_effects": "non_idempotent"
                },
                "entrypoint": "app.function:create",
                "format_version": 1,
                "interface": { "type": "lance.scalar", "version": 1 },
                "python": {
                    "abi_tag": "cp312",
                    "executable": "/usr/local/bin/python3",
                    "implementation": "cpython",
                    "import_paths": ["/opt/function/code"],
                    "version": "3.12.14"
                },
                "python_api": 1,
                "requires": { "capabilities": [], "kernel_min": "4.18.0" },
                "schemas": {
                    "initialization": "/opt/function/schemas/initialization.arrow",
                    "input": "/opt/function/schemas/input.arrow",
                    "output": "/opt/function/schemas/output.arrow"
                }
            },
            "manifest_digest": "sha256:7e22f815b6648e14f093a3979a8e5a2082fa773ebe1ec84b135cae7e84d6f8e6",
            "source": false
        },
        "location": "memory:///fixture",
        "metadata": {},
        "name": name,
        "object_id": "fixture",
        "secret_bindings": [
            { "kind": "env", "secret_ref": { "name": "hf-prod" }, "variable": "HF_TOKEN" }
        ],
        "signature": {
            "inputs": [{ "arrow_type": "utf8", "name": "text", "nullable": true }],
            "output": { "arrow_type": "list<float32>", "kind": "scalar", "nullable": false }
        },
        "version": "1"
    })
}

/// Build one `functions` page body. Each name becomes a function entry whose
/// `definition` is a full version record carrying that name; an empty `token`
/// marks the end of the sequence.
pub fn functions_body(names: &[String], token: &str) -> String {
    let items: Vec<Value> = names
        .iter()
        .map(|n| json!({ "definition": function_definition(n) }))
        .collect();
    json!({ "functions": items, "page_token": token }).to_string()
}

fn find_subslice(haystack: &[u8], needle: &[u8]) -> Option<usize> {
    if needle.is_empty() || haystack.len() < needle.len() {
        return None;
    }
    haystack
        .windows(needle.len())
        .position(|window| window == needle)
}

fn parse_content_length(head: &str) -> usize {
    for line in head.lines() {
        if let Some((name, value)) = line.split_once(':') {
            if name.trim().eq_ignore_ascii_case("content-length") {
                return value.trim().parse().unwrap_or(0);
            }
        }
    }
    0
}

fn parse_request_line(head: &str) -> (String, String) {
    let first = head.lines().next().unwrap_or("");
    let mut parts = first.split_whitespace();
    let method = parts.next().unwrap_or("").to_string();
    let target = parts.next().unwrap_or("").to_string();
    (method, target)
}
