## Task

Listing secrets, views, functions, jobs or materialized views on a connection blocks until every page has come back from the server, and only then does the caller get one big vector.
On a namespace with lots of resources that first result takes a long time to show up.
Jobs are worse, because the job listing stops after a fixed number of pages.
A long job history comes back cut short, with no error.

We'd like these listings to hand back a lazy sequence that pulls pages as the caller reads through it.
Callers should be able to say which page token to start from and how many results to ask for per page.

The Node and Python binding crates call these listings too, so their Rust code has to move to the new API.
They may keep handing their callers the full list.
Letting those callers page through as well is a plus, not a must.
The TypeScript and Python packages layered on top of the bindings stay as they are.
Keep the server routes and the shape of their responses unchanged.
Everything in the workspace, each crate's own tests included, has to keep building against the new signatures.
The dependencies already in the tree are enough, so leave the manifests and the lockfile alone.

## User stories / requirements

- Whichever of the five listings a caller opens, no request goes to the server until they read the first result, and the next page is only requested once they read past the end of the current one.
- Listing jobs on a history of well over a hundred pages returns every job, all the way to the last page.
- An empty page that still carries a continuation token does not end the listing, and when the caller passes a page token to start from, the first request picks up from that token.
- Asking for a page size of zero, or one too big for a signed 32-bit integer, makes the listing fail with an invalid-input error before anything is sent to the server.
- If the server answers with the same continuation token it was just sent, the listing stops with an error rather than asking for that page again and again.
- Against a local (non-remote) database, listing materialized views with a page size smaller than the number of views still returns every view, and only the views, in one collect.
- Collecting a whole multi-page listing in one call gives the complete set in server order, the same result the old all-at-once call returned.
