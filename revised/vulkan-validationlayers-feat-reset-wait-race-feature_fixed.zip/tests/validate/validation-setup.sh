#!/usr/bin/env bash
# Validation setup for vulkan-validationlayers-feat-reset-wait-race.
#
# The stories drive the repo's compiled Layer Validation Test binary
# (build/tests/vk_layer_validation_tests). This script copies the story gtest
# programs into the repo's test tree, registers them with CMake, and rebuilds
# incrementally so the binary contains both the implementation's layers/
# changes and the story programs. It ends with a loud smoke guard.
#
# No package installs happen here: the behavior is pure C++ exercised through
# the mock ICD, and the full toolchain + build tree are already baked into the
# image at the base commit.

set -euo pipefail

REPO="/repo/Vulkan-ValidationLayers"
HARNESS_SRC="/tests/validate/event_reset_wait_race.cpp"
DEST_REL="tests/unit/event_reset_wait_race.cpp"
DEST="${REPO}/${DEST_REL}"
CMAKE_LISTS="${REPO}/tests/CMakeLists.txt"

echo "[validation-setup] repo: ${REPO}"
cd "${REPO}"

# --- 1. Copy the story gtest programs into the repo test tree ----------------
if [ ! -f "${HARNESS_SRC}" ]; then
    echo "[validation-setup] FATAL: harness source missing at ${HARNESS_SRC}" >&2
    exit 1
fi
install -m 0644 "${HARNESS_SRC}" "${DEST}"
echo "[validation-setup] installed story gtest programs -> ${DEST_REL}"

# --- 2. Register with CMake (idempotent, additive target_sources) -----------
# target_sources() is additive, so a standalone call appended once is safe and
# does not disturb the existing big source list. The guard keeps re-runs clean.
REG_LINE="target_sources(vk_layer_validation_tests PRIVATE unit/event_reset_wait_race.cpp)"
REG_MARKER="# reset-after-wait event validation programs"
if ! grep -qF "${REG_MARKER}" "${CMAKE_LISTS}"; then
    {
        printf '\n%s\n' "${REG_MARKER}"
        printf '%s\n' "${REG_LINE}"
    } >> "${CMAKE_LISTS}"
    echo "[validation-setup] registered story programs in tests/CMakeLists.txt"
else
    echo "[validation-setup] story programs already registered; skipping"
fi

# --- 3. Incremental rebuild -------------------------------------------------
# Editing CMakeLists.txt triggers CMake's automatic reconfigure on the next
# build invocation; only the new translation unit compiles plus a relink (and
# whatever the implementation changed under layers/). Fail loudly on any build error.
echo "[validation-setup] building vk_layer_validation_tests (incremental)..."
if ! cmake --build build --target vk_layer_validation_tests > /tmp/vvl_validation_build.log 2>&1; then
    echo "[validation-setup] FATAL: build failed" >&2
    tail -120 /tmp/vvl_validation_build.log >&2
    exit 1
fi
echo "[validation-setup] build ok"

# --- 4. Smoke guard ---------------------------------------------------------
# A broken environment must error the trial, never silently score 0.0.
BIN="build/tests/vk_layer_validation_tests"
if [ ! -x "${BIN}" ]; then
    echo "[validation-setup] FATAL: test binary missing at ${BIN}" >&2
    exit 1
fi

# The story fixtures must be present in the compiled binary; if the registration
# or build silently dropped them, every story would fail opaquely. List tests and
# require the story fixtures to be enumerable.
if ! "${BIN}" --gtest_list_tests > /tmp/vvl_gtest_list.txt 2>&1; then
    echo "[validation-setup] FATAL: could not list gtest tests" >&2
    tail -60 /tmp/vvl_gtest_list.txt >&2
    exit 1
fi
for fixture in ResetWaitRaceNegative ResetWaitRacePositive ResetWaitRaceSyncVal; do
    if ! grep -q "${fixture}" /tmp/vvl_gtest_list.txt; then
        echo "[validation-setup] FATAL: story fixture ${fixture} not found in test binary" >&2
        exit 1
    fi
done
echo "[validation-setup] smoke guard passed: story fixtures present"
echo "[validation-setup] done"
