/*
 * Copyright (c) 2015-2026 The Khronos Group Inc.
 * Copyright (c) 2015-2026 Valve Corporation
 * Copyright (c) 2015-2026 LunarG, Inc.
 * Copyright (c) 2015-2026 Google, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 */

// Layer Validation Test programs for the reset-after-wait execution dependency on events.
// Each program records set/wait/reset commands against the mock ICD and uses the ErrorMonitor
// to require exactly which of the four spec VUIDs is reported, or that nothing is reported.
// The fixtures only use the Vulkan command-recording API and the debug messenger output.
//
// Fixture names are unique so this file does not collide with event.cpp or event_positive.cpp.
// The vkCmdResetEvent2 path is recorded with vk::CmdResetEvent2 directly because the
// CommandBuffer helper for it is not part of this version of the test framework.

#include "../framework/layer_validation_tests.h"
#include "../framework/sync_val_tests.h"

class ResetWaitRaceNegative : public SyncObjectTest {};
class ResetWaitRacePositive : public SyncObjectTest {};
class ResetWaitRaceSyncVal : public VkSyncValTest {};

// ---------------------------------------------------------------------------
// Story: reset_after_wait_unsafe_flagged
// ---------------------------------------------------------------------------

// The wait makes COMPUTE available and the reset runs at TRANSFER, which is not ordered after it.
TEST_F(ResetWaitRaceNegative, UnsafeResetFlagged) {
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);

    m_command_buffer.Begin();
    m_command_buffer.SetEvent(event);
    m_command_buffer.WaitEvent(event, VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
    monitor_.SetDesiredError("VUID-vkCmdResetEvent-event-03834");
    m_command_buffer.ResetEvent(event, VK_PIPELINE_STAGE_TRANSFER_BIT);
    monitor_.VerifyFound();
    m_command_buffer.End();
}

// vkCmdResetEvent after a vkCmdWaitEvents2 wait reports -03835.
TEST_F(ResetWaitRaceNegative, CoreResetAfterWait2SelectsVuid03835) {
    SetTargetApiVersion(VK_API_VERSION_1_3);
    AddRequiredFeature(vkt::Feature::synchronization2);
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);

    VkMemoryBarrier2 barrier = vku::InitStructHelper();
    barrier.srcStageMask = VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT;
    barrier.dstStageMask = VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT;

    m_command_buffer.Begin();
    m_command_buffer.SetEvent2(event, barrier);
    m_command_buffer.WaitEvent2(event, barrier);
    monitor_.SetDesiredError("VUID-vkCmdResetEvent-event-03835");
    m_command_buffer.ResetEvent(event, VK_PIPELINE_STAGE_TRANSFER_BIT);
    monitor_.VerifyFound();
    m_command_buffer.End();
}

// Reset at exactly the stage the wait made available: nothing is reported.
TEST_F(ResetWaitRacePositive, SafeResetSilent) {
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);

    m_command_buffer.Begin();
    m_command_buffer.SetEvent(event);
    m_command_buffer.WaitEvent(event, VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
    m_command_buffer.ResetEvent(event, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
    m_command_buffer.End();
}

// A reset at ALL_COMMANDS covers every stage the wait made available.
TEST_F(ResetWaitRacePositive, ResetAtAllCommandsSilent) {
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);

    m_command_buffer.Begin();
    m_command_buffer.SetEvent(event);
    m_command_buffer.WaitEvent(event, VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
    m_command_buffer.ResetEvent(event, VK_PIPELINE_STAGE_ALL_COMMANDS_BIT);
    m_command_buffer.End();
}

// A wait whose destination is ALL_COMMANDS orders a reset at any stage after it.
TEST_F(ResetWaitRacePositive, WaitAtAllCommandsSilent) {
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);

    m_command_buffer.Begin();
    m_command_buffer.SetEvent(event);
    m_command_buffer.WaitEvent(event, VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, VK_PIPELINE_STAGE_ALL_COMMANDS_BIT);
    m_command_buffer.ResetEvent(event, VK_PIPELINE_STAGE_TRANSFER_BIT);
    m_command_buffer.End();
}

// ALL_GRAPHICS includes VERTEX_SHADER, so a reset at ALL_GRAPHICS is ordered after a wait that made VERTEX_SHADER available.
TEST_F(ResetWaitRacePositive, ResetAtAllGraphicsSilent) {
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);

    m_command_buffer.Begin();
    m_command_buffer.SetEvent(event);
    m_command_buffer.WaitEvent(event, VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, VK_PIPELINE_STAGE_VERTEX_SHADER_BIT);
    m_command_buffer.ResetEvent(event, VK_PIPELINE_STAGE_ALL_GRAPHICS_BIT);
    m_command_buffer.End();
}

// A wait whose destination is ALL_GRAPHICS covers FRAGMENT_SHADER, so a reset at FRAGMENT_SHADER is ordered after it.
TEST_F(ResetWaitRacePositive, WaitAtAllGraphicsSilent) {
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);

    m_command_buffer.Begin();
    m_command_buffer.SetEvent(event);
    m_command_buffer.WaitEvent(event, VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, VK_PIPELINE_STAGE_ALL_GRAPHICS_BIT);
    m_command_buffer.ResetEvent(event, VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT);
    m_command_buffer.End();
}

// Synchronization validation turned on: the unsafe reset is still reported once, with the core VUID only.
TEST_F(ResetWaitRaceSyncVal, SingleReportWithSyncValEnabled) {
    RETURN_IF_SKIP(InitSyncVal());

    vkt::Event event(*m_device);

    m_command_buffer.Begin();
    m_command_buffer.SetEvent(event, VK_PIPELINE_STAGE_TRANSFER_BIT);
    m_command_buffer.WaitEvent(event, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT);
    monitor_.SetDesiredError("VUID-vkCmdResetEvent-event-03834");
    m_command_buffer.ResetEvent(event, VK_PIPELINE_STAGE_TRANSFER_BIT);
    monitor_.VerifyFound();
    m_command_buffer.End();
}

// Synchronization validation turned on and core checks turned off: synchronization validation itself
// reports nothing for the same unordered reset.
TEST_F(ResetWaitRaceSyncVal, SyncValAloneSilent) {
    const VkValidationFeatureEnableEXT enables[] = {VK_VALIDATION_FEATURE_ENABLE_SYNCHRONIZATION_VALIDATION_EXT};
    const VkValidationFeatureDisableEXT disables[] = {VK_VALIDATION_FEATURE_DISABLE_CORE_CHECKS_EXT};
    VkValidationFeaturesEXT validation_features = vku::InitStructHelper();
    validation_features.enabledValidationFeatureCount = 1;
    validation_features.pEnabledValidationFeatures = enables;
    validation_features.disabledValidationFeatureCount = 1;
    validation_features.pDisabledValidationFeatures = disables;
    AddRequiredExtensions(VK_EXT_VALIDATION_FEATURES_EXTENSION_NAME);
    RETURN_IF_SKIP(InitFramework(&validation_features));
    RETURN_IF_SKIP(InitState());

    vkt::Event event(*m_device);

    m_command_buffer.Begin();
    m_command_buffer.SetEvent(event, VK_PIPELINE_STAGE_TRANSFER_BIT);
    m_command_buffer.WaitEvent(event, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT);
    m_command_buffer.ResetEvent(event, VK_PIPELINE_STAGE_TRANSFER_BIT);
    m_command_buffer.End();
}

// vkCmdResetEvent2 at ALL_GRAPHICS after a wait that made VERTEX_SHADER available: nothing is reported.
TEST_F(ResetWaitRacePositive, Reset2AtAllGraphicsSilent) {
    SetTargetApiVersion(VK_API_VERSION_1_3);
    AddRequiredFeature(vkt::Feature::synchronization2);
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);

    m_command_buffer.Begin();
    m_command_buffer.SetEvent(event);
    m_command_buffer.WaitEvent(event, VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, VK_PIPELINE_STAGE_VERTEX_SHADER_BIT);
    vk::CmdResetEvent2(m_command_buffer, event, VK_PIPELINE_STAGE_2_ALL_GRAPHICS_BIT);
    m_command_buffer.End();
}

// Same as SyncValAloneSilent with vkCmdResetEvent2: synchronization validation reports nothing.
TEST_F(ResetWaitRaceSyncVal, SyncValAloneSilentReset2) {
    SetTargetApiVersion(VK_API_VERSION_1_3);
    AddRequiredFeature(vkt::Feature::synchronization2);
    const VkValidationFeatureEnableEXT enables[] = {VK_VALIDATION_FEATURE_ENABLE_SYNCHRONIZATION_VALIDATION_EXT};
    const VkValidationFeatureDisableEXT disables[] = {VK_VALIDATION_FEATURE_DISABLE_CORE_CHECKS_EXT};
    VkValidationFeaturesEXT validation_features = vku::InitStructHelper();
    validation_features.enabledValidationFeatureCount = 1;
    validation_features.pEnabledValidationFeatures = enables;
    validation_features.disabledValidationFeatureCount = 1;
    validation_features.pDisabledValidationFeatures = disables;
    AddRequiredExtensions(VK_EXT_VALIDATION_FEATURES_EXTENSION_NAME);
    RETURN_IF_SKIP(InitFramework(&validation_features));
    RETURN_IF_SKIP(InitState());

    vkt::Event event(*m_device);

    m_command_buffer.Begin();
    m_command_buffer.SetEvent(event, VK_PIPELINE_STAGE_TRANSFER_BIT);
    m_command_buffer.WaitEvent(event, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT);
    vk::CmdResetEvent2(m_command_buffer, event, VK_PIPELINE_STAGE_2_TRANSFER_BIT);
    m_command_buffer.End();
}

// ---------------------------------------------------------------------------
// Story: reset_after_wait_chained_safe
// ---------------------------------------------------------------------------

// Two vkCmdPipelineBarrier2 calls in a row: COMPUTE->TRANSFER, then TRANSFER->COLOR_ATTACHMENT_OUTPUT.
// The reset at COLOR_ATTACHMENT_OUTPUT is ordered after the wait through that chain.
TEST_F(ResetWaitRacePositive, ChainedBarrierSafe) {
    SetTargetApiVersion(VK_API_VERSION_1_3);
    AddRequiredFeature(vkt::Feature::synchronization2);
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);

    VkMemoryBarrier2 wait_barrier = vku::InitStructHelper();
    wait_barrier.srcStageMask = VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT;
    wait_barrier.dstStageMask = VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT;

    VkMemoryBarrier2 transfer_barrier = vku::InitStructHelper();
    transfer_barrier.srcStageMask = VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT;
    transfer_barrier.dstStageMask = VK_PIPELINE_STAGE_2_TRANSFER_BIT;

    VkMemoryBarrier2 color_barrier = vku::InitStructHelper();
    color_barrier.srcStageMask = VK_PIPELINE_STAGE_2_TRANSFER_BIT;
    color_barrier.dstStageMask = VK_PIPELINE_STAGE_2_COLOR_ATTACHMENT_OUTPUT_BIT;

    m_command_buffer.Begin();
    m_command_buffer.SetEvent2(event, wait_barrier);
    m_command_buffer.WaitEvent2(event, wait_barrier);
    m_command_buffer.Barrier(transfer_barrier);
    m_command_buffer.Barrier(color_barrier);
    m_command_buffer.ResetEvent(event, VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT);
    m_command_buffer.End();
}

// A vkCmdPipelineBarrier (COMPUTE->TRANSFER) after the wait orders the reset at TRANSFER.
TEST_F(ResetWaitRacePositive, Sync1BarrierChainSafe) {
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);

    m_command_buffer.Begin();
    m_command_buffer.SetEvent(event);
    m_command_buffer.WaitEvent(event, VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
    vk::CmdPipelineBarrier(m_command_buffer, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT, 0, 0, nullptr, 0,
                           nullptr, 0, nullptr);
    m_command_buffer.ResetEvent(event, VK_PIPELINE_STAGE_TRANSFER_BIT);
    m_command_buffer.End();
}

// A vkCmdPipelineBarrier2 holding only a buffer memory barrier (COMPUTE->TRANSFER) orders the reset at TRANSFER.
TEST_F(ResetWaitRacePositive, BufferBarrierChainSafe) {
    SetTargetApiVersion(VK_API_VERSION_1_3);
    AddRequiredFeature(vkt::Feature::synchronization2);
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);
    vkt::Buffer buffer(*m_device, 256, VK_BUFFER_USAGE_TRANSFER_DST_BIT);

    VkBufferMemoryBarrier2 buffer_barrier = vku::InitStructHelper();
    buffer_barrier.srcStageMask = VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT;
    buffer_barrier.dstStageMask = VK_PIPELINE_STAGE_2_TRANSFER_BIT;
    buffer_barrier.buffer = buffer;
    buffer_barrier.offset = 0;
    buffer_barrier.size = VK_WHOLE_SIZE;

    m_command_buffer.Begin();
    m_command_buffer.SetEvent(event);
    m_command_buffer.WaitEvent(event, VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
    m_command_buffer.Barrier(buffer_barrier);
    m_command_buffer.ResetEvent(event, VK_PIPELINE_STAGE_TRANSFER_BIT);
    m_command_buffer.End();
}

// A vkCmdPipelineBarrier2 holding only an image memory barrier (COMPUTE->TRANSFER) orders the reset at TRANSFER.
TEST_F(ResetWaitRacePositive, ImageBarrierChainSafe) {
    SetTargetApiVersion(VK_API_VERSION_1_3);
    AddRequiredFeature(vkt::Feature::synchronization2);
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);
    vkt::Image image(*m_device, 32, 32, VK_FORMAT_R8G8B8A8_UNORM, VK_IMAGE_USAGE_TRANSFER_DST_BIT);

    VkImageMemoryBarrier2 image_barrier = vku::InitStructHelper();
    image_barrier.srcStageMask = VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT;
    image_barrier.dstStageMask = VK_PIPELINE_STAGE_2_TRANSFER_BIT;
    image_barrier.oldLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    image_barrier.newLayout = VK_IMAGE_LAYOUT_GENERAL;
    image_barrier.image = image;
    image_barrier.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1};

    m_command_buffer.Begin();
    m_command_buffer.SetEvent(event);
    m_command_buffer.WaitEvent(event, VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
    m_command_buffer.Barrier(image_barrier);
    m_command_buffer.ResetEvent(event, VK_PIPELINE_STAGE_TRANSFER_BIT);
    m_command_buffer.End();
}

// One vkCmdPipelineBarrier2 with COMPUTE->TRANSFER and VERTEX_SHADER->COLOR_ATTACHMENT_OUTPUT. Each barrier
// keeps its own stage masks, so nothing in that call orders COLOR_ATTACHMENT_OUTPUT after the wait.
TEST_F(ResetWaitRaceNegative, IndependentBarriersDoNotChain) {
    SetTargetApiVersion(VK_API_VERSION_1_3);
    AddRequiredFeature(vkt::Feature::synchronization2);
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);

    VkMemoryBarrier2 barrier = vku::InitStructHelper();
    barrier.srcStageMask = VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT;
    barrier.dstStageMask = VK_PIPELINE_STAGE_2_TRANSFER_BIT;

    VkMemoryBarrier2 barrier2 = vku::InitStructHelper();
    barrier2.srcStageMask = VK_PIPELINE_STAGE_2_VERTEX_SHADER_BIT;
    barrier2.dstStageMask = VK_PIPELINE_STAGE_2_COLOR_ATTACHMENT_OUTPUT_BIT;

    const VkMemoryBarrier2 barriers[2] = {barrier, barrier2};

    VkDependencyInfo dep_info = vku::InitStructHelper();
    dep_info.memoryBarrierCount = 2;
    dep_info.pMemoryBarriers = barriers;

    m_command_buffer.Begin();
    m_command_buffer.SetEvent(event);
    m_command_buffer.WaitEvent(event, VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
    m_command_buffer.Barrier(dep_info);
    monitor_.SetDesiredError("VUID-vkCmdResetEvent-event-03834");
    m_command_buffer.ResetEvent(event, VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT);
    monitor_.VerifyFound();
    m_command_buffer.End();
}

// One vkCmdPipelineBarrier2 with COMPUTE->COPY and COPY->COLOR_ATTACHMENT_OUTPUT. Barriers in the same call do not
// chain with each other the way two calls in a row would, so the reset at COLOR_ATTACHMENT_OUTPUT is reported.
TEST_F(ResetWaitRaceNegative, SameCallBarriersDoNotChain) {
    SetTargetApiVersion(VK_API_VERSION_1_3);
    AddRequiredFeature(vkt::Feature::synchronization2);
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);

    VkMemoryBarrier2 barrier = vku::InitStructHelper();
    barrier.srcStageMask = VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT;
    barrier.dstStageMask = VK_PIPELINE_STAGE_2_COPY_BIT;

    VkMemoryBarrier2 barrier2 = vku::InitStructHelper();
    barrier2.srcStageMask = VK_PIPELINE_STAGE_2_COPY_BIT;
    barrier2.dstStageMask = VK_PIPELINE_STAGE_2_COLOR_ATTACHMENT_OUTPUT_BIT;

    const VkMemoryBarrier2 barriers[2] = {barrier, barrier2};

    VkDependencyInfo dep_info = vku::InitStructHelper();
    dep_info.memoryBarrierCount = 2;
    dep_info.pMemoryBarriers = barriers;

    m_command_buffer.Begin();
    m_command_buffer.SetEvent(event);
    m_command_buffer.WaitEvent(event, VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
    m_command_buffer.Barrier(dep_info);
    monitor_.SetDesiredError("VUID-vkCmdResetEvent-event-03834");
    m_command_buffer.ResetEvent(event, VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT);
    monitor_.VerifyFound();
    m_command_buffer.End();
}

// A vkCmdPipelineBarrier whose source (VERTEX_SHADER) is not ordered after the wait does not order the reset.
TEST_F(ResetWaitRaceNegative, UnrelatedSync1BarrierFlagged) {
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);

    m_command_buffer.Begin();
    m_command_buffer.SetEvent(event);
    m_command_buffer.WaitEvent(event, VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
    vk::CmdPipelineBarrier(m_command_buffer, VK_PIPELINE_STAGE_VERTEX_SHADER_BIT, VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT, 0,
                           0, nullptr, 0, nullptr, 0, nullptr);
    monitor_.SetDesiredError("VUID-vkCmdResetEvent-event-03834");
    m_command_buffer.ResetEvent(event, VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT);
    monitor_.VerifyFound();
    m_command_buffer.End();
}

// A vkCmdPipelineBarrier2 (COMPUTE->TRANSFER) after the wait orders a vkCmdResetEvent2 at TRANSFER.
TEST_F(ResetWaitRacePositive, Reset2ChainedBarrierSafe) {
    SetTargetApiVersion(VK_API_VERSION_1_3);
    AddRequiredFeature(vkt::Feature::synchronization2);
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);

    VkMemoryBarrier2 barrier = vku::InitStructHelper();
    barrier.srcStageMask = VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT;
    barrier.dstStageMask = VK_PIPELINE_STAGE_2_TRANSFER_BIT;

    m_command_buffer.Begin();
    m_command_buffer.SetEvent(event);
    m_command_buffer.WaitEvent(event, VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
    m_command_buffer.Barrier(barrier);
    vk::CmdResetEvent2(m_command_buffer, event, VK_PIPELINE_STAGE_2_TRANSFER_BIT);
    m_command_buffer.End();
}

// IndependentBarriersDoNotChain with vkCmdResetEvent2 after vkCmdWaitEvents: -03831 is reported.
TEST_F(ResetWaitRaceNegative, Reset2IndependentBarriersFlagged) {
    SetTargetApiVersion(VK_API_VERSION_1_3);
    AddRequiredFeature(vkt::Feature::synchronization2);
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);

    VkMemoryBarrier2 barrier = vku::InitStructHelper();
    barrier.srcStageMask = VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT;
    barrier.dstStageMask = VK_PIPELINE_STAGE_2_TRANSFER_BIT;

    VkMemoryBarrier2 barrier2 = vku::InitStructHelper();
    barrier2.srcStageMask = VK_PIPELINE_STAGE_2_VERTEX_SHADER_BIT;
    barrier2.dstStageMask = VK_PIPELINE_STAGE_2_COLOR_ATTACHMENT_OUTPUT_BIT;

    const VkMemoryBarrier2 barriers[2] = {barrier, barrier2};

    VkDependencyInfo dep_info = vku::InitStructHelper();
    dep_info.memoryBarrierCount = 2;
    dep_info.pMemoryBarriers = barriers;

    m_command_buffer.Begin();
    m_command_buffer.SetEvent(event);
    m_command_buffer.WaitEvent(event, VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
    m_command_buffer.Barrier(dep_info);
    monitor_.SetDesiredError("VUID-vkCmdResetEvent2-event-03831");
    vk::CmdResetEvent2(m_command_buffer, event, VK_PIPELINE_STAGE_2_COLOR_ATTACHMENT_OUTPUT_BIT);
    monitor_.VerifyFound();
    m_command_buffer.End();
}

// ---------------------------------------------------------------------------
// Story: reset_after_wait_secondary
// ---------------------------------------------------------------------------

// The wait is in a secondary command buffer; the primary resets at a stage that is not ordered after it.
TEST_F(ResetWaitRaceNegative, SecondaryWaitRaceFlagged) {
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);

    vkt::CommandBuffer secondary(*m_device, m_command_pool, VK_COMMAND_BUFFER_LEVEL_SECONDARY);
    secondary.Begin();
    secondary.WaitEvent(event, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
    secondary.End();

    m_command_buffer.Begin();
    m_command_buffer.SetEvent(event, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
    m_command_buffer.ExecuteCommands(secondary);
    monitor_.SetDesiredError("VUID-vkCmdResetEvent-event-03834");
    m_command_buffer.ResetEvent(event, VK_PIPELINE_STAGE_TRANSFER_BIT);
    monitor_.VerifyFound();
    m_command_buffer.End();
}

// The wait is in a secondary command buffer; the primary resets at the stage that wait made available.
TEST_F(ResetWaitRacePositive, SecondaryWaitSafe) {
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);

    vkt::CommandBuffer secondary(*m_device, m_command_pool, VK_COMMAND_BUFFER_LEVEL_SECONDARY);
    secondary.Begin();
    secondary.WaitEvent(event, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
    secondary.End();

    m_command_buffer.Begin();
    m_command_buffer.SetEvent(event, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
    m_command_buffer.ExecuteCommands(secondary);
    m_command_buffer.ResetEvent(event, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
    m_command_buffer.End();
}

// The wait is in the primary and the secondary holds a COMPUTE->TRANSFER barrier, so the reset at TRANSFER
// after vkCmdExecuteCommands is ordered after the wait.
TEST_F(ResetWaitRacePositive, SecondaryBarrierSafe) {
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);

    vkt::CommandBuffer secondary(*m_device, m_command_pool, VK_COMMAND_BUFFER_LEVEL_SECONDARY);
    secondary.Begin();
    vk::CmdPipelineBarrier(secondary, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT, 0, 0, nullptr, 0,
                           nullptr, 0, nullptr);
    secondary.End();

    m_command_buffer.Begin();
    m_command_buffer.SetEvent(event, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
    m_command_buffer.WaitEvent(event, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
    m_command_buffer.ExecuteCommands(secondary);
    m_command_buffer.ResetEvent(event, VK_PIPELINE_STAGE_TRANSFER_BIT);
    m_command_buffer.End();
}

// The wait is in a secondary command buffer; the primary calls vkCmdResetEvent2 at a stage it does not cover.
TEST_F(ResetWaitRaceNegative, Reset2SecondaryWaitRaceFlagged) {
    SetTargetApiVersion(VK_API_VERSION_1_3);
    AddRequiredFeature(vkt::Feature::synchronization2);
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);

    vkt::CommandBuffer secondary(*m_device, m_command_pool, VK_COMMAND_BUFFER_LEVEL_SECONDARY);
    secondary.Begin();
    secondary.WaitEvent(event, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
    secondary.End();

    m_command_buffer.Begin();
    m_command_buffer.SetEvent(event, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
    m_command_buffer.ExecuteCommands(secondary);
    monitor_.SetDesiredError("VUID-vkCmdResetEvent2-event-03831");
    vk::CmdResetEvent2(m_command_buffer, event, VK_PIPELINE_STAGE_2_TRANSFER_BIT);
    monitor_.VerifyFound();
    m_command_buffer.End();
}

// ---------------------------------------------------------------------------
// Story: reset_after_wait2_selects_sync2_vuid
// ---------------------------------------------------------------------------

// vkCmdResetEvent2 after a vkCmdWaitEvents wait reports -03831.
TEST_F(ResetWaitRaceNegative, Sync2ResetSelectsVuid03831) {
    SetTargetApiVersion(VK_API_VERSION_1_3);
    AddRequiredFeature(vkt::Feature::synchronization2);
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);

    m_command_buffer.Begin();
    m_command_buffer.SetEvent(event);
    m_command_buffer.WaitEvent(event, VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
    monitor_.SetDesiredError("VUID-vkCmdResetEvent2-event-03831");
    vk::CmdResetEvent2(m_command_buffer, event, VK_PIPELINE_STAGE_2_TRANSFER_BIT);
    monitor_.VerifyFound();
    m_command_buffer.End();
}

// vkCmdResetEvent2 after a vkCmdWaitEvents2 wait reports -03832.
TEST_F(ResetWaitRaceNegative, Sync2ResetSelectsVuid03832) {
    SetTargetApiVersion(VK_API_VERSION_1_3);
    AddRequiredFeature(vkt::Feature::synchronization2);
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);

    VkMemoryBarrier2 barrier = vku::InitStructHelper();
    barrier.srcStageMask = VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT;
    barrier.dstStageMask = VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT;

    m_command_buffer.Begin();
    m_command_buffer.SetEvent2(event, barrier);
    m_command_buffer.WaitEvent2(event, barrier);
    monitor_.SetDesiredError("VUID-vkCmdResetEvent2-event-03832");
    vk::CmdResetEvent2(m_command_buffer, event, VK_PIPELINE_STAGE_2_TRANSFER_BIT);
    monitor_.VerifyFound();
    m_command_buffer.End();
}

// vkCmdResetEvent2 at the stage a vkCmdWaitEvents wait made available: nothing is reported.
TEST_F(ResetWaitRacePositive, Sync2ResetAfterWait1SafeSilent) {
    SetTargetApiVersion(VK_API_VERSION_1_3);
    AddRequiredFeature(vkt::Feature::synchronization2);
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);

    m_command_buffer.Begin();
    m_command_buffer.SetEvent(event);
    m_command_buffer.WaitEvent(event, VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
    vk::CmdResetEvent2(m_command_buffer, event, VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT);
    m_command_buffer.End();
}

// vkCmdResetEvent2 at the stage a vkCmdWaitEvents2 wait made available: nothing is reported.
TEST_F(ResetWaitRacePositive, Sync2ResetSafeSilent) {
    SetTargetApiVersion(VK_API_VERSION_1_3);
    AddRequiredFeature(vkt::Feature::synchronization2);
    RETURN_IF_SKIP(Init());

    vkt::Event event(*m_device);

    VkMemoryBarrier2 barrier = vku::InitStructHelper();
    barrier.srcStageMask = VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT;
    barrier.dstStageMask = VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT;

    m_command_buffer.Begin();
    m_command_buffer.SetEvent2(event, barrier);
    m_command_buffer.WaitEvent2(event, barrier);
    vk::CmdResetEvent2(m_command_buffer, event, VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT);
    m_command_buffer.End();
}

// ---------------------------------------------------------------------------
// Story: reset_after_wait_per_event
// ---------------------------------------------------------------------------

// One vkCmdWaitEvents2 waits on two events: event0 with ALL_COMMANDS->COMPUTE, event1 with COMPUTE->COPY.
// event0 is only ordered through COMPUTE, so resetting it at COPY is reported.
TEST_F(ResetWaitRaceNegative, MultipleEventsKeepOwnDependency) {
    SetTargetApiVersion(VK_API_VERSION_1_3);
    AddRequiredFeature(vkt::Feature::synchronization2);
    RETURN_IF_SKIP(Init());

    vkt::Event event0(*m_device);
    vkt::Event event1(*m_device);
    const VkEvent events[2] = {event0, event1};

    VkMemoryBarrier2 barrier0 = vku::InitStructHelper();
    barrier0.srcStageMask = VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT;
    barrier0.dstStageMask = VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT;

    VkMemoryBarrier2 barrier1 = vku::InitStructHelper();
    barrier1.srcStageMask = VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT;
    barrier1.dstStageMask = VK_PIPELINE_STAGE_2_COPY_BIT;

    VkDependencyInfo dep_infos[2];
    dep_infos[0] = vku::InitStructHelper();
    dep_infos[0].memoryBarrierCount = 1;
    dep_infos[0].pMemoryBarriers = &barrier0;
    dep_infos[1] = vku::InitStructHelper();
    dep_infos[1].memoryBarrierCount = 1;
    dep_infos[1].pMemoryBarriers = &barrier1;

    m_command_buffer.Begin();
    m_command_buffer.SetEvent2(event0, barrier0);
    m_command_buffer.SetEvent2(event1, barrier1);
    vk::CmdWaitEvents2(m_command_buffer, 2, events, dep_infos);
    monitor_.SetDesiredError("VUID-vkCmdResetEvent2-event-03832");
    vk::CmdResetEvent2(m_command_buffer, event0, VK_PIPELINE_STAGE_2_COPY_BIT);
    monitor_.VerifyFound();
    m_command_buffer.End();
}

// Same waits as above. event0 reset at COMPUTE and event1 reset at COPY are each ordered after their own wait.
TEST_F(ResetWaitRacePositive, MultipleEventsSafeResets) {
    SetTargetApiVersion(VK_API_VERSION_1_3);
    AddRequiredFeature(vkt::Feature::synchronization2);
    RETURN_IF_SKIP(Init());

    vkt::Event event0(*m_device);
    vkt::Event event1(*m_device);
    const VkEvent events[2] = {event0, event1};

    VkMemoryBarrier2 barrier0 = vku::InitStructHelper();
    barrier0.srcStageMask = VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT;
    barrier0.dstStageMask = VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT;

    VkMemoryBarrier2 barrier1 = vku::InitStructHelper();
    barrier1.srcStageMask = VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT;
    barrier1.dstStageMask = VK_PIPELINE_STAGE_2_COPY_BIT;

    VkDependencyInfo dep_infos[2];
    dep_infos[0] = vku::InitStructHelper();
    dep_infos[0].memoryBarrierCount = 1;
    dep_infos[0].pMemoryBarriers = &barrier0;
    dep_infos[1] = vku::InitStructHelper();
    dep_infos[1].memoryBarrierCount = 1;
    dep_infos[1].pMemoryBarriers = &barrier1;

    m_command_buffer.Begin();
    m_command_buffer.SetEvent2(event0, barrier0);
    m_command_buffer.SetEvent2(event1, barrier1);
    vk::CmdWaitEvents2(m_command_buffer, 2, events, dep_infos);
    vk::CmdResetEvent2(m_command_buffer, event0, VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT);
    vk::CmdResetEvent2(m_command_buffer, event1, VK_PIPELINE_STAGE_2_COPY_BIT);
    m_command_buffer.End();
}

// One vkCmdWaitEvents2 on two events: event0 with ALL_COMMANDS->COMPUTE, event1 with COMPUTE->TRANSFER.
// vkCmdResetEvent on event0 at TRANSFER, a stage only event1's dependency covers, reports -03835.
TEST_F(ResetWaitRaceNegative, MultipleEventsCoreResetKeepsOwnDependency) {
    SetTargetApiVersion(VK_API_VERSION_1_3);
    AddRequiredFeature(vkt::Feature::synchronization2);
    RETURN_IF_SKIP(Init());

    vkt::Event event0(*m_device);
    vkt::Event event1(*m_device);
    const VkEvent events[2] = {event0, event1};

    VkMemoryBarrier2 barrier0 = vku::InitStructHelper();
    barrier0.srcStageMask = VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT;
    barrier0.dstStageMask = VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT;

    VkMemoryBarrier2 barrier1 = vku::InitStructHelper();
    barrier1.srcStageMask = VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT;
    barrier1.dstStageMask = VK_PIPELINE_STAGE_2_TRANSFER_BIT;

    VkDependencyInfo dep_infos[2];
    dep_infos[0] = vku::InitStructHelper();
    dep_infos[0].memoryBarrierCount = 1;
    dep_infos[0].pMemoryBarriers = &barrier0;
    dep_infos[1] = vku::InitStructHelper();
    dep_infos[1].memoryBarrierCount = 1;
    dep_infos[1].pMemoryBarriers = &barrier1;

    m_command_buffer.Begin();
    m_command_buffer.SetEvent2(event0, barrier0);
    m_command_buffer.SetEvent2(event1, barrier1);
    vk::CmdWaitEvents2(m_command_buffer, 2, events, dep_infos);
    monitor_.SetDesiredError("VUID-vkCmdResetEvent-event-03835");
    m_command_buffer.ResetEvent(event0, VK_PIPELINE_STAGE_TRANSFER_BIT);
    monitor_.VerifyFound();
    m_command_buffer.End();
}
