## Task

Resetting an event at a stage that an earlier wait on that event doesn't order can race the wait, and the spec forbids it.
Right now only synchronization validation flags this, and most people never turn that on.
We want core validation to catch it.

## User stories / requirements

- An unordered reset gets exactly one report: VUID-vkCmdResetEvent-event-03834 or -03835 from vkCmdResetEvent, VUID-vkCmdResetEvent2-event-03831 or -03832 from vkCmdResetEvent2, the first after vkCmdWaitEvents and the second after vkCmdWaitEvents2. A reset the wait covers gets none, and meta stages like ALL_COMMANDS or ALL_GRAPHICS count as the stages they include.
- Barriers recorded between the wait and the reset can order it, also chained over several calls, with vkCmdPipelineBarrier or vkCmdPipelineBarrier2 and memory, buffer or image barriers alike. A barrier only carries the ordering on when its own source stages already come after the wait, so barriers inside one vkCmdPipelineBarrier2 call never chain together.
- Waits recorded in a secondary command buffer carry into the primary that executes it: a later unordered reset in the primary is reported, and an ordered one isn't. A barrier inside the secondary counts toward ordering too. Earlier waits don't have to be tracked past a later vkCmdExecuteCommands.
- Synchronization validation stops reporting the race itself. With it turned on next to core validation, an unordered reset still gets only the core report, and with core checks off it reports nothing for that reset.
- Each event is checked against its own wait. When one vkCmdWaitEvents2 waits on several events, each with its own dependency info, a reset of one of them is judged only by that event's dependency.
- Stage order follows the pipeline. A reset at a stage that runs logically after the waited one, like FRAGMENT_SHADER after VERTEX_SHADER, is ordered, and a reset at a logically earlier stage is not. Only waits in the current recording count, so a re-recorded command buffer starts with none.
