## Task

Core validation never reports an event reset that can race a wait on the same event.
Today only synchronization validation catches it, and most people never turn that on.

The pattern is a vkCmdWaitEvents or vkCmdWaitEvents2 on an event, followed later by vkCmdResetEvent or vkCmdResetEvent2 on that event at a stage the wait doesn't order it after.
The spec requires an execution dependency between the two, so this is a spec violation every program should hear about.

Please move this check into core validation so it runs by default, with synchronization validation off as well.
It should report the spec VUIDs: VUID-vkCmdResetEvent-event-03834 and VUID-vkCmdResetEvent-event-03835 for vkCmdResetEvent, VUID-vkCmdResetEvent2-event-03831 and VUID-vkCmdResetEvent2-event-03832 for vkCmdResetEvent2.

## User stories / requirements

- A vkCmdResetEvent that the earlier wait doesn't order gets exactly one report: -03834 after vkCmdWaitEvents, -03835 after vkCmdWaitEvents2. Synchronization validation no longer reports it on its own. A reset the wait covers gets none, and meta stages like ALL_COMMANDS or ALL_GRAPHICS count as the stages they include.
- Barriers recorded between the wait and the reset can order it, also chained over several calls, with vkCmdPipelineBarrier or vkCmdPipelineBarrier2 and memory, buffer or image barriers alike. A barrier only carries the ordering on when its own source stages already come after the wait, so barriers inside one vkCmdPipelineBarrier2 call never chain together.
- Waits recorded in a secondary command buffer carry into the primary that executes it: a later unordered reset in the primary is reported, and an ordered one isn't. A barrier inside the secondary counts toward ordering too. Waits recorded in the primary before vkCmdExecuteCommands don't have to be tracked past it.
- vkCmdResetEvent2 reports VUID-vkCmdResetEvent2-event-03831 after vkCmdWaitEvents and VUID-vkCmdResetEvent2-event-03832 after vkCmdWaitEvents2, and stays silent when the reset is ordered after the wait.
- Each event is checked against its own wait. When one vkCmdWaitEvents2 waits on several events, each with its own dependency info, a reset of one of them is judged only by that event's dependency.
