## Task

The accounts page on the dashboard has become very slow on our largest deployment.
A cold load takes about a minute, a warm reload still takes a couple of seconds, and now and then the request times out.
It keeps getting slower as the request log grows.
The usage it shows per account (requests, tokens, cost) is right and the frontend is fine; the time goes into the backend call that builds the list.

Please find out why and fix it on the backend:

- Traffic that is more than a few hours old, whether from earlier today or from months ago, shouldn't make a page load any slower.
- Every account has to keep showing the same request count, token totals and cost it shows now.
- The numbers can trail brand-new requests by up to a minute, but no longer than that.
- Deleting an account or merging a duplicate has to show on the very next load, even if the page was already loading somewhere else while it happened.
- A duplicate that gets merged when the same ChatGPT account signs in again hands its usage over to the account that stays.
- An account that is deleted and later added back starts again with no usage.
