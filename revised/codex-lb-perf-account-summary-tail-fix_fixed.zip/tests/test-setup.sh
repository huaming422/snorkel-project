#!/usr/bin/env bash
# test-setup.sh - sourced (not exec'd) before the verifier runs, so exported
# PATH / VIRTUAL_ENV / env vars persist into the verifier process.
#
# The behavioral tests import `app.*` from the codex-lb checkout, so they must
# run under the repo's own uv-synced venv at /opt/venv (NOT the isolated
# /opt/tooling verifier venv). The image bakes the full dependency closure at
# the base commit, so on a normal offline run this is a fast no-op.
set -u

REPO=/repo/codex-lb
cd "$REPO" || { echo "test-setup: $REPO missing" >&2; return 1 2>/dev/null || exit 1; }

export PATH="/usr/local/bin:$PATH"   # repo uv

# Put the repo's baked venv first so `python` / `pytest` resolve to it and
# `import app...` finds the editable repo install with all its deps.
if [ -d "$REPO/.venv" ]; then
    export VIRTUAL_ENV="$REPO/.venv"
    export PATH="$REPO/.venv/bin:$PATH"
elif [ -d /opt/venv ]; then
    export VIRTUAL_ENV=/opt/venv
    export PATH="/opt/venv/bin:$PATH"
fi

# The repo's conftest sets CODEX_LB_DATABASE_URL (SQLite tmpfile) and disables
# all schedulers/leader-election at import time, so no external services are
# needed. Re-export the SQLite/test knobs defensively in case a verifier
# constructs Settings() outside the pytest conftest import path.
export CODEX_LB_UPSTREAM_BASE_URL="${CODEX_LB_UPSTREAM_BASE_URL:-https://example.invalid/backend-api}"
export CODEX_LB_USAGE_REFRESH_ENABLED="${CODEX_LB_USAGE_REFRESH_ENABLED:-false}"
export CODEX_LB_MODEL_REGISTRY_ENABLED="${CODEX_LB_MODEL_REGISTRY_ENABLED:-false}"
export CODEX_LB_AUTOMATIONS_SCHEDULER_ENABLED="${CODEX_LB_AUTOMATIONS_SCHEDULER_ENABLED:-false}"

# Offline-first: the baked venv already satisfies the closure. Only fall back to
# an online sync (logged) if the venv is somehow incomplete.
if [ -d "$REPO/.venv" ]; then
    uv sync --offline --frozen 2>&1 | tail -3 \
        || { echo "test-setup: offline sync incomplete, falling back to online uv sync" >&2; \
             uv sync --frozen 2>&1 | tail -3; }
fi

# Sanity: the modules under test must import cleanly before any verifier runs.
python -c "import app.modules.accounts.repository; import app.modules.accounts.usage_rollup; import app.modules.request_logs.repository" \
    && echo "test-setup: codex-lb accounts modules importable" \
    || echo "test-setup: WARNING codex-lb import failed" >&2
