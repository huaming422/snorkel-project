"""Checks for the per-account usage totals on the dashboard accounts listing.

The listing is read the way the dashboard route reads it,
``AccountsService(repo=AccountsRepository(session)).list_accounts()``, and the
checks compare the ``request_usage`` it returns for each account.

Every scenario runs in a fresh Python process against its own SQLite file, so
nothing one scenario left in process memory can answer a read in another one,
and the first listing a process makes is always computed from the database.
Several scenarios use two processes in a row on the same file.

What the checks read:

- Load cost: the number of SQLite virtual-machine steps one listing call runs,
  counted through the driver's progress handler, for databases that differ only
  in how much traffic older than a few hours they hold.
- Totals: request count, total tokens, cached input tokens and cost per
  account, before and after the periodic fold pass, with repeated request rows
  and warmup rows in the data.
- Freshness: a new request shows up within a minute, and a deleted, re-added
  or merged account shows its new state on the next load, also when another
  load was already running while the delete or merge committed.
"""

from __future__ import annotations

import asyncio
import json
import os
import subprocess
import sys
import tempfile
import traceback
import uuid
from datetime import timedelta

import pytest

# The repo builds its async engine at import time from CODEX_LB_DATABASE_URL,
# and the listing code reads several CODEX_LB_* knobs. Set them before importing
# anything under ``app`` so the engine binds to a throwaway SQLite file and no
# background scheduler or leader election starts. A scenario process gets its
# own database URL from the parent before it starts.
_DB_DIR = tempfile.mkdtemp(prefix="codex-lb-accounts-summary-")
os.environ.setdefault(
    "CODEX_LB_DATABASE_URL",
    os.environ.get("CODEX_LB_TEST_DATABASE_URL", f"sqlite+aiosqlite:///{_DB_DIR}/codex-lb.db"),
)
os.environ.setdefault("CODEX_LB_UPSTREAM_BASE_URL", "https://example.invalid/backend-api")
os.environ.setdefault("CODEX_LB_USAGE_REFRESH_ENABLED", "false")
os.environ.setdefault("CODEX_LB_MODEL_REGISTRY_ENABLED", "false")
os.environ.setdefault("CODEX_LB_STICKY_SESSION_CLEANUP_ENABLED", "false")
os.environ.setdefault("CODEX_LB_HTTP_RESPONSES_SESSION_BRIDGE_ENABLED", "false")
os.environ.setdefault("CODEX_LB_QUOTA_PLANNER_SCHEDULER_ENABLED", "false")
os.environ.setdefault("CODEX_LB_UPSTREAM_ROUTE_CACHE_TTL_SECONDS", "0")
os.environ.setdefault("CODEX_LB_AUTOMATIONS_SCHEDULER_ENABLED", "false")

from app.core.crypto import TokenEncryptor  # noqa: E402
from app.core.utils.time import utcnow  # noqa: E402
from app.db.models import (  # noqa: E402
    Account,
    AccountStatus,
    AccountUsageRollup,
    AccountUsageRollupState,
    Base,
    RequestLog,
)
from app.db.session import SessionLocal, engine  # noqa: E402
from app.modules.accounts.repository import AccountsRepository  # noqa: E402
from app.modules.accounts.service import AccountsService  # noqa: E402
from app.modules.accounts.usage_rollup import run_fold_pass  # noqa: E402
from app.modules.request_logs.repository import RequestLogsRepository  # noqa: E402
from sqlalchemy import event, insert, text  # noqa: E402
from sqlalchemy.ext.asyncio import AsyncSession  # noqa: E402

# A scenario that sleeps past the one-minute freshness window needs the most.
_SCENARIO_TIMEOUT_SECONDS = 180
# How many statement positions of one listing load the race scenarios try,
# one process per position; the loop stops early once a load runs fewer.
_MAX_PAUSE_POSITIONS = 12


# ---------------------------------------------------------------------------
# Work meter: counts SQLite virtual-machine steps while armed.
# ---------------------------------------------------------------------------

_work_steps = {"n": 0}
_work_armed = {"v": False}


def _progress_tick() -> int:
    if _work_armed["v"]:
        _work_steps["n"] += 1
    return 0


@event.listens_for(engine.sync_engine, "connect")
def _install_work_meter(dbapi_conn, _record) -> None:
    """Attach a per-VM-step progress handler to every raw SQLite connection.
    No-op on a driver connection without ``set_progress_handler``."""
    raw = getattr(dbapi_conn, "_connection", None) or dbapi_conn
    inner = getattr(raw, "_conn", None) or raw
    if hasattr(inner, "set_progress_handler"):
        inner.set_progress_handler(_progress_tick, 1)


# ---------------------------------------------------------------------------
# Data helpers (same shapes as the repo's accounts usage-rollup tests).
# ---------------------------------------------------------------------------


def _reset_schema(sync_conn) -> None:
    sync_conn.execute(text("DROP TABLE IF EXISTS alembic_version"))
    sync_conn.execute(text("DROP TABLE IF EXISTS schema_migrations"))
    Base.metadata.drop_all(sync_conn)
    Base.metadata.create_all(sync_conn)


async def _reset_db() -> None:
    async with engine.begin() as conn:
        await conn.run_sync(_reset_schema)


def _make_account(account_id: str, email: str, chatgpt_account_id: str | None = None) -> Account:
    encryptor = TokenEncryptor()
    return Account(
        id=account_id,
        email=email,
        plan_type="plus",
        chatgpt_account_id=chatgpt_account_id,
        access_token_encrypted=encryptor.encrypt("access"),
        refresh_token_encrypted=encryptor.encrypt("refresh"),
        id_token_encrypted=encryptor.encrypt("id"),
        last_refresh=utcnow(),
        status=AccountStatus.ACTIVE,
        deactivation_reason=None,
    )


async def _add_account(account_id: str, email: str, chatgpt_account_id: str | None = None) -> None:
    async with SessionLocal() as session:
        await AccountsRepository(session).upsert(
            _make_account(account_id, email, chatgpt_account_id), merge_by_email=False
        )


async def _add_log(
    *,
    account_id: str,
    request_id: str,
    requested_at,
    input_tokens: int = 100,
    output_tokens: int = 50,
    cached_input_tokens: int = 0,
    cost_usd: float | None = 0.01,
    request_kind: str = "normal",
) -> None:
    async with SessionLocal() as session:
        await RequestLogsRepository(session).add_log(
            account_id=account_id,
            request_id=request_id,
            model="gpt-5.1-codex",
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cached_input_tokens=cached_input_tokens,
            latency_ms=100,
            status="success",
            error_code=None,
            requested_at=requested_at,
            cost_usd=cost_usd,
            request_kind=request_kind,
        )


def _bulk_log_rows(account_id: str, start_index: int, count: int, age: timedelta) -> list[dict]:
    """``count`` plain request-log rows, the newest ``age`` old and each next
    one a second older."""
    now = utcnow()
    return [
        dict(
            account_id=account_id,
            request_id=f"{account_id}-r{start_index + j}",
            request_kind="normal",
            requested_at=now - age - timedelta(seconds=j),
            model="gpt-5.1-codex",
            status="success",
            input_tokens=100,
            output_tokens=50,
            cached_input_tokens=0,
            reasoning_tokens=0,
            cost_usd=0.01,
            latency_ms=1,
        )
        for j in range(count)
    ]


async def _bulk_insert_logs(rows: list[dict]) -> None:
    chunk = 5000
    async with engine.begin() as conn:
        for start in range(0, len(rows), chunk):
            await conn.execute(insert(RequestLog), rows[start : start + chunk])


async def _listing() -> dict[str, dict | None]:
    """One accounts-listing load: account id -> its request usage (or None)."""
    async with SessionLocal() as session:
        accounts = await AccountsService(repo=AccountsRepository(session)).list_accounts()
    return {
        account.account_id: (account.request_usage.model_dump() if account.request_usage is not None else None)
        for account in accounts
    }


async def _measured_listing() -> tuple[int, dict[str, dict | None]]:
    _work_steps["n"] = 0
    _work_armed["v"] = True
    try:
        listing = await _listing()
    finally:
        _work_armed["v"] = False
    return _work_steps["n"], listing


async def _delete_account(account_id: str, *, delete_history: bool = False) -> None:
    async with SessionLocal() as session:
        deleted = await AccountsService(repo=AccountsRepository(session)).delete_account(
            account_id, delete_history=delete_history
        )
    assert deleted, f"deleting {account_id} reported nothing deleted"


async def _merge_reauth(account_id: str, email: str, chatgpt_account_id: str) -> None:
    """Sign the same ChatGPT account in again, which merges its duplicates
    into the account that keeps ``account_id``."""
    async with SessionLocal() as session:
        saved = await AccountsRepository(session).upsert(
            _make_account(account_id, email, chatgpt_account_id),
            merge_by_email=False,
            merge_by_chatgpt_identity=True,
        )
    assert saved.id == account_id


async def _listing_with_pause(position: int, change) -> bool:
    """Start a listing load, hold it in front of its ``position``-th statement,
    run ``change()`` to completion from another task, then let the load finish.
    Returns False when the load runs fewer statements than ``position``."""
    real_execute = AsyncSession.execute
    reached = asyncio.Event()
    release = asyncio.Event()
    state: dict = {"calls": 0, "task": None}

    async def paused_execute(self, *args, **kwargs):
        if asyncio.current_task() is state["task"]:
            state["calls"] += 1
            if state["calls"] == position:
                reached.set()
                await release.wait()
        return await real_execute(self, *args, **kwargs)

    AsyncSession.execute = paused_execute
    try:
        load = asyncio.create_task(_listing())
        state["task"] = load
        reached_wait = asyncio.create_task(reached.wait())
        await asyncio.wait({load, reached_wait}, return_when=asyncio.FIRST_COMPLETED)
        if not reached.is_set():
            reached_wait.cancel()
            await load
            return False
        change_task = asyncio.create_task(change())
        # If the change cannot finish while the load is held, let the load go
        # and finish both in order.
        await asyncio.wait({change_task}, timeout=20)
        release.set()
        await change_task
        await load
        return True
    finally:
        AsyncSession.execute = real_execute


# ---------------------------------------------------------------------------
# Scenarios. Each one runs in its own process (see ``_run``) and returns a
# JSON-serializable dict.
# ---------------------------------------------------------------------------

_SCENARIOS: dict = {}


def _scenario(fn):
    _SCENARIOS[fn.__name__] = fn
    return fn


@_scenario
async def totals_seed() -> dict:
    """Two accounts with old, recent, repeated and warmup rows; read once."""
    await _reset_db()
    now = utcnow()
    await _add_account("acc_fold", "fold@example.com")
    await _add_account("acc_fold_b", "fold-b@example.com")
    await _add_log(
        account_id="acc_fold", request_id="req_old", requested_at=now - timedelta(days=2), input_tokens=1000
    )
    # Two rows for one request (same account, request id and timestamp): the
    # listing counts it once, with the values of the row written last.
    dup_at = now - timedelta(hours=6)
    await _add_log(account_id="acc_fold", request_id="req_dup", requested_at=dup_at, input_tokens=999_999)
    await _add_log(account_id="acc_fold", request_id="req_dup", requested_at=dup_at, input_tokens=200)
    # Warmup rows never count.
    await _add_log(
        account_id="acc_fold",
        request_id="req_warm",
        requested_at=dup_at,
        request_kind="warmup",
        input_tokens=777,
    )
    await _add_log(account_id="acc_fold", request_id="req_new", requested_at=now, input_tokens=10)
    await _add_log(
        account_id="acc_fold_b",
        request_id="req_b_old",
        requested_at=now - timedelta(days=2),
        input_tokens=40,
        output_tokens=7,
        cached_input_tokens=5,
        cost_usd=0.2,
    )
    await _add_log(account_id="acc_fold_b", request_id="req_b_new", requested_at=now - timedelta(minutes=3))
    return {"listing": await _listing()}


@_scenario
async def totals_after_fold() -> dict:
    await run_fold_pass()
    return {"listing": await _listing()}


@_scenario
async def existing_rollup_seed() -> dict:
    """A database the current release has already folded up to 24 hours ago:
    rollup rows hold the older requests and the state row records that point.
    Read once."""
    await _reset_db()
    now = utcnow()
    folded_through = now - timedelta(hours=24)
    await _add_account("acc_up", "up@example.com")
    await _add_account("acc_up_b", "up-b@example.com")
    await _add_log(
        account_id="acc_up",
        request_id="req_up_old",
        requested_at=now - timedelta(days=3),
        input_tokens=1000,
        cached_input_tokens=100,
        cost_usd=0.5,
    )
    mid_at = now - timedelta(hours=12)
    await _add_log(
        account_id="acc_up", request_id="req_up_mid", requested_at=mid_at - timedelta(minutes=1), input_tokens=300
    )
    await _add_log(account_id="acc_up", request_id="req_up_dup", requested_at=mid_at, input_tokens=999_999)
    await _add_log(account_id="acc_up", request_id="req_up_dup", requested_at=mid_at, input_tokens=70)
    await _add_log(
        account_id="acc_up", request_id="req_up_warm", requested_at=mid_at, request_kind="warmup", input_tokens=777
    )
    await _add_log(
        account_id="acc_up", request_id="req_up_new", requested_at=now - timedelta(minutes=10), input_tokens=20
    )
    await _add_log(
        account_id="acc_up_b",
        request_id="req_up_b_old",
        requested_at=now - timedelta(days=2),
        input_tokens=40,
        output_tokens=7,
        cached_input_tokens=5,
        cost_usd=0.2,
    )
    await _add_log(account_id="acc_up_b", request_id="req_up_b_mid", requested_at=now - timedelta(hours=8))
    async with engine.begin() as conn:
        await conn.execute(
            insert(AccountUsageRollupState).values(id=1, folded_through=folded_through, upgrade_repair_from=None)
        )
        await conn.execute(
            insert(AccountUsageRollup),
            [
                dict(
                    account_id="acc_up",
                    request_count=1,
                    input_tokens=1000,
                    output_tokens=50,
                    cached_input_tokens=100,
                    total_cost_usd=0.5,
                ),
                dict(
                    account_id="acc_up_b",
                    request_count=1,
                    input_tokens=40,
                    output_tokens=7,
                    cached_input_tokens=5,
                    total_cost_usd=0.2,
                ),
            ],
        )
    return {"listing": await _listing()}


@_scenario
async def work_corpus(aged_rows: int, age_hours: float) -> dict:
    """40 requests from the last few minutes plus ``aged_rows`` older ones,
    folded, then one measured listing load."""
    await _reset_db()
    await _add_account("acc_scale", "scale@example.com")
    await _bulk_insert_logs(_bulk_log_rows("acc_scale", 0, 40, timedelta(minutes=10)))
    await _bulk_insert_logs(_bulk_log_rows("acc_scale", 1_000, aged_rows, timedelta(hours=age_hours)))
    await run_fold_pass()
    steps, listing = await _measured_listing()
    return {"steps": steps, "listing": listing}


@_scenario
async def deep_baseline() -> dict:
    await _reset_db()
    now = utcnow()
    await _add_account("acc_deep", "deep@example.com")
    dup_at = now - timedelta(minutes=30)
    await _add_log(account_id="acc_deep", request_id="req_dup", requested_at=dup_at, input_tokens=5)
    await _add_log(account_id="acc_deep", request_id="req_dup", requested_at=dup_at, input_tokens=7)
    await _add_log(
        account_id="acc_deep",
        request_id="req_warm",
        requested_at=now - timedelta(minutes=20),
        request_kind="warmup",
        input_tokens=999,
    )
    steps, listing = await _measured_listing()
    return {"steps": steps, "listing": listing}


@_scenario
async def deep_after_history() -> dict:
    await _bulk_insert_logs(_bulk_log_rows("acc_deep", 10_000, 12_000, timedelta(hours=6)))
    await run_fold_pass()
    steps, listing = await _measured_listing()
    return {"steps": steps, "listing": listing}


@_scenario
async def new_request_within_a_minute() -> dict:
    await _reset_db()
    now = utcnow()
    await _add_account("acc_live", "live@example.com")
    await _add_log(account_id="acc_live", request_id="req_live_1", requested_at=now - timedelta(minutes=5))
    first = await _listing()
    await _add_log(account_id="acc_live", request_id="req_live_2", requested_at=utcnow(), input_tokens=30)
    await asyncio.sleep(61)
    return {"first": first, "after_a_minute": await _listing()}


async def _two_accounts_with_folded_and_recent_usage() -> None:
    now = utcnow()
    await _add_account("acc_keep", "keep@example.com")
    await _add_account("acc_gone", "gone@example.com")
    for account_id in ("acc_keep", "acc_gone"):
        await _add_log(account_id=account_id, request_id=f"{account_id}-old", requested_at=now - timedelta(days=3))
        await _add_log(account_id=account_id, request_id=f"{account_id}-new", requested_at=now - timedelta(minutes=5))
    await run_fold_pass()


@_scenario
async def delete_and_add_back(delete_history: bool) -> dict:
    await _reset_db()
    await _two_accounts_with_folded_and_recent_usage()
    before = await _listing()
    await _delete_account("acc_gone", delete_history=delete_history)
    after_delete = await _listing()
    await _add_account("acc_gone", "gone@example.com")
    return {"before": before, "after_delete": after_delete, "after_add_back": await _listing()}


@_scenario
async def merge_duplicate() -> dict:
    await _reset_db()
    now = utcnow()
    await _add_account("acc_cc", "cc@example.com", "chatgpt_cc")
    await _add_log(account_id="acc_cc", request_id="req_cc_old", requested_at=now - timedelta(days=3))
    await _add_log(account_id="acc_cc", request_id="req_cc_new", requested_at=now - timedelta(minutes=5))
    canonical_only = await _listing()
    await _add_account("acc_cc__copy", "cc@example.com", "chatgpt_cc")
    await _add_log(
        account_id="acc_cc__copy",
        request_id="req_copy_old",
        requested_at=now - timedelta(days=3),
        input_tokens=400,
        cost_usd=0.05,
    )
    await _add_log(
        account_id="acc_cc__copy",
        request_id="req_copy_new",
        requested_at=now - timedelta(minutes=4),
        input_tokens=250,
        cost_usd=0.03,
    )
    await run_fold_pass()
    both = await _listing()
    await _merge_reauth("acc_cc", "cc@example.com", "chatgpt_cc")
    return {"canonical_only": canonical_only, "both": both, "after_merge": await _listing()}


@_scenario
async def delete_during_load(position: int) -> dict:
    await _reset_db()
    await _two_accounts_with_folded_and_recent_usage()
    reached = await _listing_with_pause(position, lambda: _delete_account("acc_gone"))
    if not reached:
        return {"reached": False}
    after_delete = await _listing()
    await _add_account("acc_gone", "gone@example.com")
    return {"reached": True, "after_delete": after_delete, "after_add_back": await _listing()}


@_scenario
async def merge_during_load(position: int) -> dict:
    await _reset_db()
    now = utcnow()
    await _add_account("acc_cc", "cc@example.com", "chatgpt_cc")
    await _add_account("acc_cc__copy", "cc@example.com", "chatgpt_cc")
    for account_id in ("acc_cc", "acc_cc__copy"):
        await _add_log(account_id=account_id, request_id=f"{account_id}-old", requested_at=now - timedelta(days=3))
        await _add_log(account_id=account_id, request_id=f"{account_id}-new", requested_at=now - timedelta(minutes=5))
    await run_fold_pass()
    reached = await _listing_with_pause(position, lambda: _merge_reauth("acc_cc", "cc@example.com", "chatgpt_cc"))
    if not reached:
        return {"reached": False}
    return {"reached": True, "after_merge": await _listing()}


# ---------------------------------------------------------------------------
# Process runner.
# ---------------------------------------------------------------------------


def _new_db_dir() -> str:
    return tempfile.mkdtemp(prefix="codex-lb-accounts-scenario-")


def _run(db_dir: str, name: str, **params) -> dict:
    """Run one scenario in a fresh interpreter on ``db_dir``'s database."""
    out_path = os.path.join(db_dir, f"{name}-{uuid.uuid4().hex}.json")
    env = dict(os.environ)
    env["CODEX_LB_DATABASE_URL"] = f"sqlite+aiosqlite:///{db_dir}/codex-lb.db"
    env["PYTHONPATH"] = os.pathsep.join(p for p in (os.getcwd(), env.get("PYTHONPATH", "")) if p)
    command = [sys.executable, os.path.abspath(__file__), name, json.dumps(params), out_path]
    try:
        proc = subprocess.run(
            command,
            env=env,
            cwd=os.getcwd(),
            capture_output=True,
            text=True,
            timeout=_SCENARIO_TIMEOUT_SECONDS,
        )
        stderr_tail = proc.stderr[-4000:]
    except subprocess.TimeoutExpired as exc:
        stderr_tail = (exc.stderr or b"")[-4000:]
        if isinstance(stderr_tail, bytes):
            stderr_tail = stderr_tail.decode(errors="replace")
        if not os.path.exists(out_path):
            pytest.fail(f"scenario {name}{params} did not finish in {_SCENARIO_TIMEOUT_SECONDS}s\n{stderr_tail}")
    if not os.path.exists(out_path):
        pytest.fail(f"scenario {name}{params} failed\n{stderr_tail}")
    with open(out_path, encoding="utf-8") as fh:
        return json.load(fh)


def _scenario_main(argv: list[str]) -> None:
    name, params, out_path = argv[1], json.loads(argv[2]), argv[3]

    async def _go() -> dict:
        return await _SCENARIOS[name](**params)

    try:
        result = asyncio.run(_go())
        with open(out_path, "w", encoding="utf-8") as fh:
            json.dump(result, fh)
    except BaseException:
        traceback.print_exc()
        sys.stderr.flush()
        os._exit(1)
    sys.stdout.flush()
    sys.stderr.flush()
    # The result is on disk; skip interpreter teardown of driver threads.
    os._exit(0)


# ---------------------------------------------------------------------------
# Reading results.
# ---------------------------------------------------------------------------


def _usage(listing: dict, account_id: str) -> dict:
    assert account_id in listing, f"{account_id} missing from the accounts listing: {sorted(listing)}"
    usage = listing[account_id]
    assert usage is not None, f"{account_id} shows no request usage"
    return usage


def _assert_usage(listing: dict, account_id: str, *, requests: int, tokens: int, cached: int, cost: float) -> None:
    usage = _usage(listing, account_id)
    assert usage["request_count"] == requests, (account_id, usage)
    assert usage["total_tokens"] == tokens, (account_id, usage)
    assert usage["cached_input_tokens"] == cached, (account_id, usage)
    assert usage["total_cost_usd"] == pytest.approx(cost, abs=1e-6), (account_id, usage)


def _assert_no_usage(listing: dict, account_id: str) -> None:
    assert account_id in listing, f"{account_id} missing from the accounts listing: {sorted(listing)}"
    usage = listing[account_id]
    assert usage is None or usage["request_count"] == 0, (
        f"{account_id} was deleted and added back but still shows request usage: {usage}"
    )


# ---------------------------------------------------------------------------
# Checks.
# ---------------------------------------------------------------------------


def test_fold_keeps_listing_totals():
    db_dir = _new_db_dir()
    before = _run(db_dir, "totals_seed")["listing"]
    _assert_usage(before, "acc_fold", requests=3, tokens=1000 + 200 + 10 + 3 * 50, cached=0, cost=0.03)
    _assert_usage(before, "acc_fold_b", requests=2, tokens=(40 + 7) + (100 + 50), cached=5, cost=0.21)

    after = _run(db_dir, "totals_after_fold")["listing"]
    _assert_usage(after, "acc_fold", requests=3, tokens=1000 + 200 + 10 + 3 * 50, cached=0, cost=0.03)
    _assert_usage(after, "acc_fold_b", requests=2, tokens=(40 + 7) + (100 + 50), cached=5, cost=0.21)


def test_existing_rollups_keep_listing_totals():
    db_dir = _new_db_dir()
    expected = {
        "acc_up": dict(requests=4, tokens=(1000 + 50) + (300 + 50) + (70 + 50) + (20 + 50), cached=100, cost=0.53),
        "acc_up_b": dict(requests=2, tokens=(40 + 7) + (100 + 50), cached=5, cost=0.21),
    }
    before = _run(db_dir, "existing_rollup_seed")["listing"]
    after = _run(db_dir, "totals_after_fold")["listing"]
    for listing in (before, after):
        for account_id, totals in expected.items():
            _assert_usage(listing, account_id, **totals)


def _work_ratio(age_hours: float) -> tuple[float, int, int]:
    small = _run(_new_db_dir(), "work_corpus", aged_rows=4_000, age_hours=age_hours)
    large = _run(_new_db_dir(), "work_corpus", aged_rows=12_000, age_hours=age_hours)
    assert _usage(small["listing"], "acc_scale")["request_count"] == 4_040
    assert _usage(large["listing"], "acc_scale")["request_count"] == 12_040
    return large["steps"] / max(small["steps"], 1), small["steps"], large["steps"]


def test_load_cost_flat_with_more_traffic_from_earlier_today():
    ratio, small_steps, large_steps = _work_ratio(age_hours=6)
    assert ratio < 1.8, (
        "an accounts listing load got more expensive with more traffic from 6+ hours ago "
        f"(work grew {ratio:.1f}x for 3x the rows: {small_steps} -> {large_steps} vm-steps)"
    )


def test_load_cost_flat_with_more_older_history():
    ratio, small_steps, large_steps = _work_ratio(age_hours=72)
    assert ratio < 1.8, (
        "an accounts listing load got more expensive with more traffic from 3+ days ago "
        f"(work grew {ratio:.1f}x for 3x the rows: {small_steps} -> {large_steps} vm-steps)"
    )


def test_deep_history_keeps_totals_and_load_cost():
    db_dir = _new_db_dir()
    base = _run(db_dir, "deep_baseline")
    base_usage = _usage(base["listing"], "acc_deep")
    assert base_usage["request_count"] == 1
    assert base_usage["total_tokens"] == 7 + 50

    deep = _run(db_dir, "deep_after_history")
    deep_usage = _usage(deep["listing"], "acc_deep")
    assert deep_usage["request_count"] == 1 + 12_000
    assert deep_usage["total_tokens"] == base_usage["total_tokens"] + 12_000 * (100 + 50)
    assert deep_usage["total_cost_usd"] == pytest.approx(base_usage["total_cost_usd"] + 12_000 * 0.01, abs=1e-6)
    assert deep["steps"] <= base["steps"] + 4_000, (
        "12,000 requests from 6+ hours ago made an accounts listing load much more expensive "
        f"({base['steps']} -> {deep['steps']} vm-steps)"
    )


def test_new_request_shows_within_a_minute():
    result = _run(_new_db_dir(), "new_request_within_a_minute")
    _assert_usage(result["first"], "acc_live", requests=1, tokens=150, cached=0, cost=0.01)
    _assert_usage(result["after_a_minute"], "acc_live", requests=2, tokens=150 + 80, cached=0, cost=0.02)


@pytest.mark.parametrize("delete_history", [False, True])
def test_deleted_account_added_back_starts_empty(delete_history):
    result = _run(_new_db_dir(), "delete_and_add_back", delete_history=delete_history)
    _assert_usage(result["before"], "acc_gone", requests=2, tokens=300, cached=0, cost=0.02)
    assert "acc_gone" not in result["after_delete"]
    _assert_usage(result["after_delete"], "acc_keep", requests=2, tokens=300, cached=0, cost=0.02)
    _assert_no_usage(result["after_add_back"], "acc_gone")
    _assert_usage(result["after_add_back"], "acc_keep", requests=2, tokens=300, cached=0, cost=0.02)


def test_merged_duplicate_usage_moves_at_once():
    result = _run(_new_db_dir(), "merge_duplicate")
    _assert_usage(result["canonical_only"], "acc_cc", requests=2, tokens=300, cached=0, cost=0.02)
    assert "acc_cc__copy" in result["both"]
    after = result["after_merge"]
    assert "acc_cc__copy" not in after
    _assert_usage(after, "acc_cc", requests=4, tokens=300 + (400 + 50) + (250 + 50), cached=0, cost=0.10)


def test_delete_while_a_load_is_running():
    for position in range(1, _MAX_PAUSE_POSITIONS + 1):
        result = _run(_new_db_dir(), "delete_during_load", position=position)
        if not result["reached"]:
            break
        assert "acc_gone" not in result["after_delete"], f"paused before statement {position}"
        _assert_usage(result["after_delete"], "acc_keep", requests=2, tokens=300, cached=0, cost=0.02)
        _assert_no_usage(result["after_add_back"], "acc_gone")
        _assert_usage(result["after_add_back"], "acc_keep", requests=2, tokens=300, cached=0, cost=0.02)


def test_merge_while_a_load_is_running():
    for position in range(1, _MAX_PAUSE_POSITIONS + 1):
        result = _run(_new_db_dir(), "merge_during_load", position=position)
        if not result["reached"]:
            break
        after = result["after_merge"]
        assert "acc_cc__copy" not in after, f"paused before statement {position}"
        _assert_usage(after, "acc_cc", requests=4, tokens=4 * 150, cached=0, cost=0.04)


if __name__ == "__main__":
    _scenario_main(sys.argv)
