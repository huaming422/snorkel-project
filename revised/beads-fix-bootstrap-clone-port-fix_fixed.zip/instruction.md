## Task

Running `bd bootstrap` on a server-mode workspace prints that the database was synced and exits 0.
Then the next command, `bd list` for example, fails because the database isn't on the server.
Only some setups do this.
When the workspace names its server port in just one place, we've never seen it.
Right before bootstrap exits there's a non-fatal warning about the post-clone step, which is easy to skip past.
On a workspace that was already initialized, bootstrap sometimes refuses instead, saying it couldn't verify the database on a server that none of our other commands talk to.

Our regular commands already connect to the right server.
Bootstrap should check for the database and clone it on whatever server those commands use in that workspace, so the workspace works as soon as bootstrap says it's done.
For a fresh checkout sitting inside another workspace's folder, that means the server the new checkout's own commands will use.
`bd init --server --external` doesn't have this problem, and the server its clone goes to should stay exactly as it is today.
