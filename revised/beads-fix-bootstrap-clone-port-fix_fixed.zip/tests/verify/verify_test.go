// Behavioral checks for which Dolt server a server-mode clone dials.
//
// The bootstrap checks run the real `bd bootstrap --yes` command in-process.
// Each one stages a server-mode workspace whose server port is named in more
// than one place, with every named port allocated and then closed, so the
// connection fails fast and the dial error names the address bootstrap really
// dialed. Every local server address bootstrap prints has to be that same
// one. The expected port is the one the workspace's ordinary
// commands connect to: the server-port environment variable first, then the
// workspace's port file and its config-file dolt.port, then the server port
// recorded in metadata.json, and the legacy BEADS_DOLT_PORT variable only when
// nothing else names one. A shared-server workspace connects to the shared
// server's port instead of anything the workspace records.
//
// The `bd init --server --external` check calls the in-package clone entry
// point with init's own clone settings and expects the port that init's own
// store connects to right after the clone.
//
// The file brings its own environment isolation, workspace builders, port
// allocator and output capture, and compiles with the repository's pure-Go tag
// and CGO disabled.
package main

import (
	"bytes"
	"fmt"
	"io"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"testing"

	"github.com/steveyegge/beads/internal/config"
	"github.com/steveyegge/beads/internal/configfile"
	"github.com/steveyegge/beads/internal/doltserver"
	"github.com/steveyegge/beads/internal/git"
)

// isolateCloneEndpointEnv clears every variable that names a Dolt server
// endpoint, its credentials or its mode, and isolates HOME (the shared-server
// directory, user config and credentials file all live there), so only what
// the test writes chooses the endpoint. The config singleton is reset before
// and after the test.
func isolateCloneEndpointEnv(t *testing.T) {
	t.Helper()
	home := t.TempDir()
	t.Setenv("HOME", home)
	t.Setenv("USERPROFILE", home)
	t.Setenv("XDG_CONFIG_HOME", filepath.Join(home, ".config"))
	t.Setenv("BEADS_SHARED_SERVER_DIR", filepath.Join(home, "shared-server"))
	for _, name := range []string{
		"BEADS_DIR",
		"BEADS_DOLT_SERVER_MODE", "BEADS_DOLT_SHARED_SERVER", "BEADS_DOLT_SERVER_HOST",
		"BEADS_DOLT_SERVER_PORT", "BEADS_DOLT_PORT", "BEADS_DOLT_SERVER_SOCKET",
		"BEADS_DOLT_DATA_DIR", "BEADS_DOLT_SERVER_DATABASE", "BEADS_DOLT_SERVER_USER",
		"BEADS_DOLT_SERVER_TLS", "BEADS_DOLT_PASSWORD", "BEADS_CREDENTIALS_FILE",
		"BD_DOLT_PORT", "BD_DOLT_SHARED_SERVER", "BD_DOLT_HOST", "BD_DOLT_MODE",
		"BEADS_TEST_MODE", "DOLT_REMOTE_USER", "DOLT_REMOTE_PASSWORD",
	} {
		t.Setenv(name, "")
	}
	t.Setenv("BD_NON_INTERACTIVE", "1")
	t.Setenv("BD_DISABLE_METRICS", "1")
	t.Setenv("BD_DISABLE_EVENT_FLUSH", "1")
	t.Setenv("GIT_AUTHOR_NAME", "clone-port")
	t.Setenv("GIT_AUTHOR_EMAIL", "clone-port@example.invalid")
	t.Setenv("GIT_COMMITTER_NAME", "clone-port")
	t.Setenv("GIT_COMMITTER_EMAIL", "clone-port@example.invalid")
	t.Setenv("GIT_CONFIG_NOSYSTEM", "1")
	config.ResetForTesting()
	t.Cleanup(config.ResetForTesting)
}

// writeConfigFile writes body to path, creating parent directories.
func writeConfigFile(t *testing.T, path, body string) {
	t.Helper()
	if err := os.MkdirAll(filepath.Dir(path), 0o700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(path, []byte(body), 0o600); err != nil {
		t.Fatal(err)
	}
}

// closedPorts returns n distinct loopback TCP ports that were allocated and
// then closed, so a dial against any of them fails fast with connection
// refused instead of reaching a live server.
func closedPorts(t *testing.T, n int) []int {
	t.Helper()
	listeners := make([]net.Listener, 0, n)
	ports := make([]int, 0, n)
	for range n {
		l, err := net.Listen("tcp", "127.0.0.1:0")
		if err != nil {
			t.Fatalf("allocate loopback port: %v", err)
		}
		listeners = append(listeners, l)
		ports = append(ports, l.Addr().(*net.TCPAddr).Port)
	}
	for _, l := range listeners {
		if err := l.Close(); err != nil {
			t.Fatalf("close loopback port: %v", err)
		}
	}
	return ports
}

// serverMetadata is a server-mode metadata.json for database dbName on the
// local host. port is its dolt_server_port (0 leaves it unset) and projectID
// its project_id (empty leaves it unset).
func serverMetadata(dbName string, port int, projectID string) *configfile.Config {
	return &configfile.Config{
		Backend:        configfile.BackendDolt,
		DoltMode:       configfile.DoltModeServer,
		DoltServerHost: "127.0.0.1",
		DoltServerPort: port,
		DoltDatabase:   dbName,
		ProjectID:      projectID,
	}
}

// saveMetadata writes cfg as beadsDir's metadata.json.
func saveMetadata(t *testing.T, beadsDir string, cfg *configfile.Config) {
	t.Helper()
	if err := os.MkdirAll(beadsDir, 0o700); err != nil {
		t.Fatal(err)
	}
	if err := cfg.Save(beadsDir); err != nil {
		t.Fatal(err)
	}
}

// configYAML is a workspace config.yaml body: the sync remote (when set) and
// dolt.port (when nonzero).
func configYAML(syncRemote string, doltPort int) string {
	var b strings.Builder
	if syncRemote != "" {
		fmt.Fprintf(&b, "sync.remote: %q\n", syncRemote)
	}
	if doltPort > 0 {
		fmt.Fprintf(&b, "dolt.port: %d\n", doltPort)
	}
	if b.Len() == 0 {
		b.WriteString("# workspace config\n")
	}
	return b.String()
}

// captureOutput redirects os.Stdout and os.Stderr while fn runs and returns
// everything written to either.
func captureOutput(t *testing.T, fn func()) string {
	t.Helper()
	r, w, err := os.Pipe()
	if err != nil {
		t.Fatalf("os.Pipe: %v", err)
	}
	origOut, origErr := os.Stdout, os.Stderr
	os.Stdout, os.Stderr = w, w
	done := make(chan string, 1)
	go func() {
		var buf bytes.Buffer
		_, _ = io.Copy(&buf, r)
		done <- buf.String()
	}()
	defer func() {
		os.Stdout, os.Stderr = origOut, origErr
		_ = w.Close()
		_ = r.Close()
	}()
	fn()
	os.Stdout, os.Stderr = origOut, origErr
	_ = w.Close()
	return <-done
}

// runBootstrap runs `bd bootstrap --yes` in-process from dir and returns the
// command's error and everything it printed. bd bootstrap runs on the shared
// cobra command and reads package globals, so they are restored afterwards.
//
// Before planning, bootstrap reconciles a server-mode metadata.json with the
// databases the server lists. No server runs here, so that step is replaced,
// as the package's own bootstrap tests replace it, by one that finds nothing
// to reconcile and keeps the metadata as written.
func runBootstrap(t *testing.T, dir string) (string, error) {
	t.Helper()
	origDBPath, origStore, origJSON := dbPath, store, jsonOutput
	origResolve := resolveBootstrapAuthoritativeMetadata
	resolveBootstrapAuthoritativeMetadata = func(string, bool) (*configfile.Config, string, error) {
		return nil, "", nil
	}
	t.Cleanup(func() {
		if store != nil && store != origStore {
			_ = store.Close()
		}
		resolveBootstrapAuthoritativeMetadata = origResolve
		dbPath, store, jsonOutput = origDBPath, origStore, origJSON
		_ = bootstrapCmd.Flags().Set("yes", "false")
		config.ResetForTesting()
		git.ResetCaches()
	})
	dbPath, store, jsonOutput = "", nil, false
	t.Chdir(dir)
	git.ResetCaches()
	// A bd process loads its configuration at startup from its working
	// directory and BEADS_DIR, before any command runs; load it the same way.
	config.ResetForTesting()
	if err := config.Initialize(); err != nil {
		t.Fatalf("config.Initialize: %v", err)
	}

	var runErr error
	out := captureOutput(t, func() {
		rootCmd.SetArgs([]string{"bootstrap", "--yes"})
		runErr = rootCmd.Execute()
	})
	if runErr != nil {
		out += "\nerror: " + runErr.Error()
	}
	return out, runErr
}

// loopbackAddr matches every local server address bootstrap prints.
var loopbackAddr = regexp.MustCompile(`127\.0\.0\.1:(\d+)`)

// requireServerPort checks that bootstrap failed, that the connection it
// attempted went to 127.0.0.1:want (the dial error names the address it
// dialed), and that every local server address it printed is that one.
func requireServerPort(t *testing.T, out string, err error, want int) {
	t.Helper()
	if err == nil {
		t.Fatalf("bd bootstrap succeeded with no server running\noutput:\n%s", out)
	}
	wantAddr := net.JoinHostPort("127.0.0.1", strconv.Itoa(want))
	if !strings.Contains(out, "dial tcp "+wantAddr) {
		t.Errorf("bd bootstrap did not connect to %s, the server this workspace's commands connect to\noutput:\n%s", wantAddr, out)
	}
	for _, m := range loopbackAddr.FindAllStringSubmatch(out, -1) {
		if m[1] != strconv.Itoa(want) {
			t.Errorf("bd bootstrap named or dialed %s, not %s\noutput:\n%s", m[0], wantAddr, out)
			break
		}
	}
}

const cloneRemote = "file:///nonexistent/clone-port-remote"

// sharedDefault, as a cloneCase sharedPortFile, turns shared-server mode on
// with no shared port file, so the shared server is on its default port; as
// want, it stands for that default port.
const sharedDefault = -2

// cloneCase is one workspace layout for TestVerifyBootstrapClonesWhereCommandsConnect.
// Port fields are indexes into the closed ports allocated for the case; -1
// means the source is not set.
type cloneCase struct {
	name string
	// metadataOnDisk writes metadata.json into the workspace itself. Without
	// it the workspace has only config.yaml, and bootstrap picks up the
	// enclosing directory's metadata.json for the clone, as a fresh clone does.
	metadataOnDisk bool
	metadataPort   int
	configPort     int
	portFilePort   int
	serverPortEnv  int
	legacyPortEnv  int
	sharedPortFile int // shared-server mode, with the shared port file naming this port (or sharedDefault)
	want           int
}

// TestVerifyBootstrapClonesWhereCommandsConnect stages workspaces whose server
// port is named in two places that disagree and checks that bd bootstrap
// clones into the port the workspace's ordinary commands connect to.
func TestVerifyBootstrapClonesWhereCommandsConnect(t *testing.T) {
	cases := []cloneCase{
		{name: "config file over legacy env", metadataOnDisk: true, metadataPort: -1, configPort: 0, portFilePort: -1, serverPortEnv: -1, legacyPortEnv: 1, sharedPortFile: -1, want: 0},
		{name: "config file over metadata", metadataOnDisk: true, metadataPort: 1, configPort: 0, portFilePort: -1, serverPortEnv: -1, legacyPortEnv: -1, sharedPortFile: -1, want: 0},
		{name: "server port env over metadata", metadataOnDisk: true, metadataPort: 1, configPort: -1, portFilePort: -1, serverPortEnv: 0, legacyPortEnv: -1, sharedPortFile: -1, want: 0},
		{name: "server port env over config file", metadataOnDisk: true, metadataPort: -1, configPort: 1, portFilePort: -1, serverPortEnv: 0, legacyPortEnv: 2, sharedPortFile: -1, want: 0},
		{name: "port file over metadata", metadataOnDisk: true, metadataPort: 1, configPort: -1, portFilePort: 0, serverPortEnv: -1, legacyPortEnv: -1, sharedPortFile: -1, want: 0},
		{name: "metadata over legacy env", metadataOnDisk: true, metadataPort: 0, configPort: -1, portFilePort: -1, serverPortEnv: -1, legacyPortEnv: 1, sharedPortFile: -1, want: 0},
		{name: "legacy env alone", metadataOnDisk: true, metadataPort: -1, configPort: -1, portFilePort: -1, serverPortEnv: -1, legacyPortEnv: 0, sharedPortFile: -1, want: 0},
		{name: "fresh clone: inherited metadata over legacy env", metadataOnDisk: false, metadataPort: 0, configPort: -1, portFilePort: -1, serverPortEnv: -1, legacyPortEnv: 1, sharedPortFile: -1, want: 0},
		{name: "fresh clone: config file over inherited metadata", metadataOnDisk: false, metadataPort: 1, configPort: 0, portFilePort: -1, serverPortEnv: -1, legacyPortEnv: -1, sharedPortFile: -1, want: 0},
		{name: "fresh clone: server port env over inherited metadata", metadataOnDisk: false, metadataPort: 1, configPort: -1, portFilePort: -1, serverPortEnv: 0, legacyPortEnv: -1, sharedPortFile: -1, want: 0},
		{name: "shared server over workspace metadata", metadataOnDisk: true, metadataPort: 1, configPort: -1, portFilePort: -1, serverPortEnv: -1, legacyPortEnv: -1, sharedPortFile: 0, want: 0},
		{name: "fresh clone: shared server over inherited metadata", metadataOnDisk: false, metadataPort: 1, configPort: -1, portFilePort: -1, serverPortEnv: -1, legacyPortEnv: -1, sharedPortFile: 0, want: 0},
		{name: "shared server default over workspace metadata", metadataOnDisk: true, metadataPort: 1, configPort: -1, portFilePort: -1, serverPortEnv: -1, legacyPortEnv: -1, sharedPortFile: sharedDefault, want: sharedDefault},
		{name: "fresh clone: shared server default over inherited metadata", metadataOnDisk: false, metadataPort: 1, configPort: -1, portFilePort: -1, serverPortEnv: -1, legacyPortEnv: -1, sharedPortFile: sharedDefault, want: sharedDefault},
	}
	for i, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			isolateCloneEndpointEnv(t)
			ports := closedPorts(t, 3)
			port := func(idx int) int {
				switch {
				case idx == sharedDefault:
					return doltserver.DefaultSharedServerPort
				case idx < 0:
					return 0
				}
				return ports[idx]
			}
			dbName := fmt.Sprintf("clone_port_%d", i)

			root := t.TempDir()
			workspace := filepath.Join(root, "project")
			beadsDir := filepath.Join(workspace, ".beads")
			writeConfigFile(t, filepath.Join(beadsDir, "config.yaml"), configYAML(cloneRemote, port(tc.configPort)))
			meta := serverMetadata(dbName, port(tc.metadataPort), "")
			if tc.metadataOnDisk {
				saveMetadata(t, beadsDir, meta)
			} else {
				saveMetadata(t, filepath.Join(root, ".beads"), meta)
			}
			if tc.portFilePort >= 0 {
				writeConfigFile(t, filepath.Join(beadsDir, "dolt-server.port"), strconv.Itoa(port(tc.portFilePort)))
			}
			if tc.serverPortEnv >= 0 {
				t.Setenv("BEADS_DOLT_SERVER_PORT", strconv.Itoa(port(tc.serverPortEnv)))
			}
			if tc.legacyPortEnv >= 0 {
				t.Setenv("BEADS_DOLT_PORT", strconv.Itoa(port(tc.legacyPortEnv)))
			}
			if tc.sharedPortFile >= 0 || tc.sharedPortFile == sharedDefault {
				t.Setenv("BEADS_DOLT_SHARED_SERVER", "1")
			}
			if tc.sharedPortFile >= 0 {
				writeConfigFile(t, filepath.Join(os.Getenv("BEADS_SHARED_SERVER_DIR"), "dolt-server.port"), strconv.Itoa(port(tc.sharedPortFile)))
			}
			t.Setenv("BEADS_DIR", beadsDir)

			out, err := runBootstrap(t, workspace)
			requireServerPort(t, out, err, port(tc.want))
		})
	}
}

// gitRun runs git in dir and fails the test on error.
func gitRun(t *testing.T, dir string, args ...string) {
	t.Helper()
	cmd := exec.Command("git", args...)
	cmd.Dir = dir
	if out, err := cmd.CombinedOutput(); err != nil {
		t.Fatalf("git %v in %s: %v\n%s", args, dir, err, out)
	}
}

// TestVerifyBootstrapNestedRigClonesWhereItsCommandsConnect bootstraps a fresh
// rig: its own git repository, with no .beads yet, whose origin carries Dolt
// data, inside an enclosing workspace whose config.yaml names a dolt.port. The
// rig's own commands read the rig's config and never that dolt.port, so with
// the legacy BEADS_DOLT_PORT as the only other port source they connect to
// that one, and the clone has to land there too.
func TestVerifyBootstrapNestedRigClonesWhereItsCommandsConnect(t *testing.T) {
	for i, dbName := range []string{"rig_alpha", "rig_beta"} {
		t.Run(dbName, func(t *testing.T) {
			isolateCloneEndpointEnv(t)
			ports := closedPorts(t, 2)
			enclosingPort, legacy := ports[0], ports[1]
			if i == 1 {
				enclosingPort, legacy = legacy, enclosingPort
			}
			t.Setenv("BEADS_DOLT_PORT", strconv.Itoa(legacy))

			town := t.TempDir()
			townBeads := filepath.Join(town, ".beads")
			writeConfigFile(t, filepath.Join(townBeads, "config.yaml"), configYAML("", enclosingPort))
			saveMetadata(t, townBeads, serverMetadata(dbName, 0, ""))

			origin := filepath.Join(t.TempDir(), "origin.git")
			gitRun(t, filepath.Dir(origin), "init", "-q", "--bare", origin)
			seed := t.TempDir()
			gitRun(t, seed, "init", "-q")
			gitRun(t, seed, "commit", "-q", "--allow-empty", "-m", "dolt data")
			gitRun(t, seed, "push", "-q", origin, "HEAD:refs/dolt/data")
			gitRun(t, seed, "push", "-q", origin, "HEAD:refs/heads/main")

			rig := filepath.Join(town, "rig")
			if err := os.MkdirAll(rig, 0o700); err != nil {
				t.Fatal(err)
			}
			gitRun(t, rig, "init", "-q")
			gitRun(t, rig, "remote", "add", "origin", origin)

			out, err := runBootstrap(t, rig)
			requireServerPort(t, out, err, legacy)
		})
	}
}

// TestVerifyBootstrapExistenceCheckAsksTheCloneServer stages an initialized
// server-mode workspace (metadata.json has a project_id) with no remote and no
// local data, so bd bootstrap asks the server whether the database exists and
// refuses to create an empty one when it cannot confirm it. The server it asks,
// and the one its refusal names, have to be the server the workspace's
// commands connect to, which is also where a clone would land.
func TestVerifyBootstrapExistenceCheckAsksTheCloneServer(t *testing.T) {
	cases := []struct {
		name string
		// where the winning port is named: "legacy" (BEADS_DOLT_PORT alone),
		// "config" (config.yaml dolt.port) or "metadata" (dolt_server_port);
		// BEADS_DOLT_PORT always names a second, losing port in the latter two.
		source string
	}{
		{name: "legacy env alone", source: "legacy"},
		{name: "config file over legacy env", source: "config"},
		{name: "metadata over legacy env", source: "metadata"},
	}
	for i, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			isolateCloneEndpointEnv(t)
			ports := closedPorts(t, 2)
			named, legacy := ports[0], ports[1]

			workspace := filepath.Join(t.TempDir(), "project")
			beadsDir := filepath.Join(workspace, ".beads")
			cfgPort, metaPort, want := 0, 0, legacy
			switch tc.source {
			case "config":
				cfgPort, want = named, named
			case "metadata":
				metaPort, want = named, named
			}
			writeConfigFile(t, filepath.Join(beadsDir, "config.yaml"), configYAML("", cfgPort))
			saveMetadata(t, beadsDir, serverMetadata(fmt.Sprintf("probe_port_%d", i), metaPort, fmt.Sprintf("proj-clone-port-%d", i)))
			t.Setenv("BEADS_DOLT_PORT", strconv.Itoa(legacy))
			t.Setenv("BEADS_DIR", beadsDir)

			out, err := runBootstrap(t, workspace)
			requireServerPort(t, out, err, want)
		})
	}
}

// TestVerifyInitCloneKeepsItsPortOrder checks the `bd init --server --external`
// clone. bd init opens its own store right after the clone, and that store
// takes the server-port environment variable or the workspace's port file and
// otherwise the legacy BEADS_DOLT_PORT, never a config-file dolt.port, so the
// clone has to land on that same port.
func TestVerifyInitCloneKeepsItsPortOrder(t *testing.T) {
	cases := []struct {
		name     string
		portFile bool
	}{
		{name: "legacy env over config file", portFile: false},
		{name: "port file over config file", portFile: true},
	}
	for i, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			isolateCloneEndpointEnv(t)
			ports := closedPorts(t, 3)
			configured, legacy, portFile := ports[0], ports[1], ports[2]
			t.Setenv("BEADS_DOLT_PORT", strconv.Itoa(legacy))
			want := legacy

			beadsDir := filepath.Join(t.TempDir(), ".beads")
			dbName := fmt.Sprintf("init_port_%d", i)
			writeConfigFile(t, filepath.Join(beadsDir, "config.yaml"), configYAML("", configured))
			saveMetadata(t, beadsDir, serverMetadata(dbName, 0, ""))
			if tc.portFile {
				writeConfigFile(t, filepath.Join(beadsDir, "dolt-server.port"), strconv.Itoa(portFile))
				t.Setenv("BEADS_DOLT_PORT", "")
				want = portFile
			}
			t.Setenv("BEADS_DIR", beadsDir)
			config.ResetForTesting()
			if err := config.Initialize(); err != nil {
				t.Fatalf("config.Initialize: %v", err)
			}

			initCfg := initTimeCloneConfig(true /*serverMode*/, "" /*host*/, 0 /*port*/, "" /*socket*/, "" /*user*/, dbName)
			err := cloneFromRemoteWithMode(t.Context(), beadsDir, cloneRemote, dbName, initCfg, remoteCloneExternalServer)
			if err == nil {
				t.Fatal("clone succeeded with no server running")
			}
			wantAddr := net.JoinHostPort("127.0.0.1", strconv.Itoa(want))
			if !strings.Contains(err.Error(), "dial tcp "+wantAddr) {
				t.Errorf("init clone error = %v, want a connection to %s, the server init's own store connects to", err, wantAddr)
			}
		})
	}
}
