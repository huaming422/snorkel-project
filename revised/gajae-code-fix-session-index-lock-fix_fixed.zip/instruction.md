## Task

`gjc` sometimes crashes right at startup.
The launch sits there for roughly a minute and then dies with:

```
Failed to acquire lock for …/sdk/sessions/index.jsonl after 600 attempts
```

It doesn't happen every time.
We see it mostly on Windows, though not only there.

The pattern so far: it only shows up while a detached background `gjc` process left over from an earlier session is still running.
Kill that leftover process by hand and launches work again.
That's our only workaround right now.
On one of the affected Windows boxes, Task Manager showed the leftover process sitting on a `powershell.exe` child that never seemed to exit.

The error doesn't help either.
All it gives us is an attempt count, with no hint of who holds the lock.

Please track down why a single background session can block every other launch, and fix it.
Some ground rules for the fix:

- No `gjc` process, background or not, should keep other launches waiting while it asks the OS about a process (its own or another session's), however long that takes.
- Don't solve it by letting a launch take the lock away from a process that's still running, even if that process has held it for a long time.
  The lock exists so two processes never write the index at once.
- A pid can die and get reused by an unrelated process.
  So a heartbeat must never be written from a liveness reading that's more than a few seconds old by the time the write happens.
  Skip that heartbeat and let the next pass write it.
  Measure that age with a clock that can't jump backward, since the system clock can.
- When a launch gives up on the lock, the error should name the pid of the process holding it.
  If the lock record says it was written by another machine (a shared folder), name that machine too, and don't describe the process as live, because there's no way to check that from here.
