// Session-index lock contention between gjc processes on one machine.
//
// Checks, through the SessionIndex class and the exported withFileLock:
// - no OS liveness probe (processIncarnation) runs while the machine-global
//   session-index lock is held, on the append, heartbeat and conditional
//   unregister paths;
// - a heartbeat is not written from a liveness reading that has aged past a
//   short bound by the time it would be committed, and that bound ignores a
//   backward wall-clock step;
// - the lock-exhaustion error names the holding pid, and reports a foreign-host
//   owner without calling it live;
// - a live owner's lock is never taken away, a throwing critical section
//   releases the lock, an aborted acquisition fails fast, and concurrent
//   launches queue behind a holder and converge on one consistent index.
//
// processIncarnation and withFileLock are observed through spies only, to see
// when a probe runs relative to the lock; no private symbol is imported.

import { describe, expect, it, vi } from "bun:test";
import * as fs from "node:fs/promises";
import * as os from "node:os";
import * as path from "node:path";
import * as lockModule from "../src/config/file-lock";
import * as incarnationModule from "../src/sdk/broker/process-incarnation";
import { SessionIndex } from "../src/sdk/broker/session-index";

// A self-pid host registration: append derives this host's own OS identity
// when pid === process.pid, so the append path runs a liveness probe.
const registration = (sessionId: string) => ({
	type: "host_registered" as const,
	sessionId,
	locator: { repo: "r", stateRoot: "q" },
	endpointGeneration: 1,
	pid: process.pid,
});

function deferred<T = void>() {
	return Promise.withResolvers<T>();
}

// Drive withFileLock through a depth-counting wrapper so any probe that runs
// while depth > 0 is inside the machine-global critical section. The wrapper
// calls the real lock, so acquisition and release work as before.
function instrumentLockDepth() {
	const realWithFileLock = lockModule.withFileLock;
	const state = { depth: 0, probedUnderLock: false };
	const lockSpy = vi
		.spyOn(lockModule, "withFileLock")
		.mockImplementation(async (filePath: Parameters<typeof realWithFileLock>[0], fn, options) => {
			state.depth++;
			try {
				return await realWithFileLock(filePath, fn, options);
			} finally {
				state.depth--;
			}
		});
	const realProcessIncarnation = incarnationModule.processIncarnation;
	const incarnationSpy = vi.spyOn(incarnationModule, "processIncarnation").mockImplementation(pid => {
		if (state.depth > 0) state.probedUnderLock = true;
		return realProcessIncarnation(pid);
	});
	return { state, lockSpy, incarnationSpy };
}

// Moves every monotonic clock source a freshness bound could read
// (performance.now, process.hrtime.bigint, Bun.nanoseconds) forward by the same
// offset. A source that cannot be spied on in this runtime is left as is.
function shiftMonotonicClocks(offsetMs: number) {
	const realPerf = performance.now.bind(performance);
	vi.spyOn(performance, "now").mockImplementation(() => realPerf() + offsetMs);
	try {
		const realHrBig = process.hrtime.bigint.bind(process.hrtime);
		vi.spyOn(process.hrtime, "bigint").mockImplementation(() => realHrBig() + BigInt(offsetMs) * 1_000_000n);
	} catch {}
	try {
		const realNanos = Bun.nanoseconds.bind(Bun);
		vi.spyOn(Bun, "nanoseconds").mockImplementation(() => realNanos() + offsetMs * 1_000_000);
	} catch {}
}

// Fires `advance()` once, at the first acquisition of the index-log lock that
// happens after at least one liveness probe (processIncarnation) has run. A
// heartbeat pass gathers liveness readings and then takes the lock to commit,
// whether it probes before its first acquisition or between a replay-release
// and the write, so a time-bounded freshness check sees the readings as aged
// wherever in the flow it lives.
function failClosedHarness(advance: () => void) {
	let incarnationCalls = 0;
	const realProcessIncarnation = incarnationModule.processIncarnation;
	const incarnationSpy = vi.spyOn(incarnationModule, "processIncarnation").mockImplementation(pid => {
		incarnationCalls++;
		return realProcessIncarnation(pid);
	});
	const handle = {
		advanced: false,
		restore() {
			lockSpy.mockRestore();
			incarnationSpy.mockRestore();
			vi.restoreAllMocks();
		},
	};
	const realWithFileLock = lockModule.withFileLock;
	const lockSpy = vi
		.spyOn(lockModule, "withFileLock")
		.mockImplementation(async (filePath: Parameters<typeof realWithFileLock>[0], fn, options) => {
			if (!handle.advanced && incarnationCalls > 0 && String(filePath).endsWith("index.jsonl")) {
				handle.advanced = true;
				advance();
			}
			return await realWithFileLock(filePath, fn, options);
		});
	return handle;
}

describe("sdk session index lock contention", () => {
	it("derives the append path's OS incarnation without holding the index lock", async () => {
		const dir = await fs.mkdtemp(path.join(os.tmpdir(), "ssb-ix-append-"));
		const index = await new SessionIndex(dir).open();
		const { state, lockSpy, incarnationSpy } = instrumentLockDepth();
		try {
			// Self-pid registration forces the host-incarnation derivation.
			const appended = await index.append(registration("probe"));
			expect(appended.hostIncarnation).toBeDefined();
			// The probe must have run (liveness is still observed) ...
			expect(incarnationSpy).toHaveBeenCalled();
			// ... but never while the machine-global lock was held.
			expect(state.probedUnderLock).toBe(false);
			// The unlocked projection still reflects the registration.
			expect(index.listSessions().sessions).toHaveLength(1);
		} finally {
			incarnationSpy.mockRestore();
			lockSpy.mockRestore();
		}
	});

	it("keeps the heartbeat checkpoint's OS probes outside the lock-held section", async () => {
		const dir = await fs.mkdtemp(path.join(os.tmpdir(), "ssb-ix-heartbeat-"));
		const index = await new SessionIndex(dir).open();
		await index.append(registration("live-host"));
		const { state, lockSpy, incarnationSpy } = instrumentLockDepth();
		try {
			expect(await index.checkpointLiveHeartbeats()).toBe(1);
			expect(incarnationSpy).toHaveBeenCalled();
			expect(state.probedUnderLock).toBe(false);
		} finally {
			incarnationSpy.mockRestore();
			lockSpy.mockRestore();
		}
	});

	it("keeps the conditional-unregister pass's OS probes outside the lock-held section", async () => {
		const dir = await fs.mkdtemp(path.join(os.tmpdir(), "ssb-ix-unregister-"));
		const index = await new SessionIndex(dir).open();
		const appended = await index.append(registration("retire-me"));
		expect(appended.hostIncarnation).toBeDefined();
		const { state, lockSpy, incarnationSpy } = instrumentLockDepth();
		try {
			expect(
				await index.unregisterIfCurrent({
					sessionId: "retire-me",
					locator: { repo: "r", stateRoot: "q" },
					endpointGeneration: 1,
					pid: process.pid,
					indexSeq: appended.indexSeq,
					processIncarnation: appended.processIncarnation,
					hostIncarnation: appended.hostIncarnation,
					identityProvenance: "composite",
					ambiguous: false,
					live: true,
					terminal: false,
					terminalUncertain: false,
				}),
			).toBe(true);
			expect(incarnationSpy).toHaveBeenCalled();
			expect(state.probedUnderLock).toBe(false);
		} finally {
			incarnationSpy.mockRestore();
			lockSpy.mockRestore();
		}
	});

	it("fails closed when the probe batch is no longer fresh by the time the lock holds it", async () => {
		const dir = await fs.mkdtemp(path.join(os.tmpdir(), "ssb-ix-stale-"));
		const seed = await new SessionIndex(dir).open();
		await seed.append(registration("slow-replay"));
		const index = await new SessionIndex(dir).open();
		// Liveness readings taken before the commit lock can go stale while the
		// pass waits: a pid can exit and be reused in that window. When the index
		// lock is taken after the probes, jump both the monotonic and the wall
		// clocks 120s forward, far past any freshness bound, so any time-based
		// bound skips the heartbeat this cycle. The backward-step case below
		// covers the wall clock alone.
		const h = failClosedHarness(() => {
			shiftMonotonicClocks(120_000);
			const realNow = Date.now;
			vi.spyOn(Date, "now").mockImplementation(() => realNow() + 120_000);
		});
		try {
			expect(await index.checkpointLiveHeartbeats()).toBe(0);
			expect(h.advanced).toBe(true);
			// No heartbeat was recorded for the still-live host.
			const rows = index.listSessions().sessions;
			expect(rows).toHaveLength(1);
			expect(rows[0]?.lastHeartbeatAt).toBeUndefined();
		} finally {
			h.restore();
		}
		// A subsequent fast pass re-observes and writes normally.
		expect(await index.checkpointLiveHeartbeats()).toBe(1);
	});

	it("keeps failing closed when the wall clock steps backward but monotonic time has advanced", async () => {
		const dir = await fs.mkdtemp(path.join(os.tmpdir(), "ssb-ix-clock-"));
		const seed = await new SessionIndex(dir).open();
		await seed.append(registration("clock-regress"));
		const index = await new SessionIndex(dir).open();
		// The wall clock steps 70s backward (manual change, NTP step, VM snapshot
		// restore) while monotonic time moves 120s forward. The readings are
		// still too old, so no heartbeat is written.
		const h = failClosedHarness(() => {
			const realNow = Date.now;
			vi.spyOn(Date, "now").mockImplementation(() => realNow() - 70_000);
			shiftMonotonicClocks(120_000);
		});
		try {
			expect(await index.checkpointLiveHeartbeats()).toBe(0);
			expect(h.advanced).toBe(true);
			const rows = index.listSessions().sessions;
			expect(rows[0]?.lastHeartbeatAt).toBeUndefined();
		} finally {
			h.restore();
		}
		expect(await index.checkpointLiveHeartbeats()).toBe(1);
	});

	it("names the holding process when a launch exhausts the lock budget", async () => {
		const dir = await fs.mkdtemp(path.join(os.tmpdir(), "ssb-ix-owner-"));
		const sessionsDir = path.join(dir, "sdk", "sessions");
		await fs.mkdir(sessionsDir, { recursive: true });
		const logPath = path.join(sessionsDir, "index.jsonl");
		// A live owner's lock dir shaped exactly like the reporter's record.
		const lockDir = `${logPath}.lock`;
		await fs.mkdir(lockDir);
		await fs.writeFile(
			path.join(lockDir, "info"),
			JSON.stringify({ pid: process.pid, start_time: "unknown", timestamp: Date.now() }),
		);
		let failure: unknown;
		try {
			await lockModule.withFileLock(logPath, async () => {}, { retries: 2, retryDelayMs: 5 });
		} catch (error) {
			failure = error;
		}
		expect(failure).toBeInstanceOf(Error);
		const message = (failure as Error).message;
		// The error names the holder by its pid, as a number with no digits
		// around it. Any wording around the pid is accepted.
		expect(new RegExp(`(^|[^0-9])${process.pid}([^0-9]|$)`).test(message)).toBe(true);
		// The live owner's lock is never taken away.
		expect(await fs.exists(lockDir)).toBe(true);
	});

	it("reports a foreign-host lock owner without mislabeling a coincident local pid", async () => {
		const dir = await fs.mkdtemp(path.join(os.tmpdir(), "ssb-ix-foreign-"));
		const sessionsDir = path.join(dir, "sdk", "sessions");
		await fs.mkdir(sessionsDir, { recursive: true });
		const logPath = path.join(sessionsDir, "index.jsonl");
		// A shared-volume lock record owned by another host: its pid is meaningful
		// only there. The same number is a live LOCAL process here (this test's own
		// pid), so a naive liveness probe would wrongly call it the live holder.
		const lockDir = `${logPath}.lock`;
		await fs.mkdir(lockDir, { recursive: true });
		await fs.writeFile(
			path.join(lockDir, "info"),
			JSON.stringify({
				pid: process.pid,
				start_time: "unknown",
				timestamp: Date.now(),
				owner_host_id: "another-host",
			}),
		);
		let failure: unknown;
		try {
			await lockModule.withFileLock(logPath, async () => {}, {
				retries: 2,
				retryDelayMs: 5,
				ownerHostId: "this-host",
			});
		} catch (error) {
			failure = error;
		}
		expect(failure).toBeInstanceOf(Error);
		const message = (failure as Error).message;
		// The foreign host id (known only from the lock record) and the recorded
		// pid both appear in the message ...
		expect(message).toContain("another-host");
		expect(new RegExp(`(^|[^0-9])${process.pid}([^0-9]|$)`).test(message)).toBe(true);
		// ... and the owner is not labelled "(live)": the same pid number is a
		// live local process here, but a foreign host's pid cannot be checked
		// from this machine.
		expect(message).not.toContain("(live)");
		expect(await fs.exists(lockDir)).toBe(true);
	});

	it("releases the lock when a critical section throws and fails an aborted acquisition fast", async () => {
		const dir = await fs.mkdtemp(path.join(os.tmpdir(), "ssb-ix-throw-"));
		const index = await new SessionIndex(dir).open();
		await index.append(registration("one"));
		const boom = new Error("critical section failed");
		await expect(
			index.withLocked(async () => {
				throw boom;
			}),
		).rejects.toBe(boom);
		// A throw inside the critical section must not leave the lock held: the
		// next operation acquires immediately rather than burning the retry budget.
		const next = await index.append(registration("two"));
		expect(next.indexSeq).toBe(2);
		expect(await fs.exists(path.join(dir, "sdk", "sessions", "index.jsonl.lock"))).toBe(false);

		// An aborted acquisition must fail fast rather than exhaust its full retry
		// budget: hold the lock in the background, start a competing acquisition,
		// and abort it while it is still contending.
		const controller = new AbortController();
		const acquired = deferred();
		const holderDone = deferred();
		void (async () => {
			await lockModule.withFileLock(path.join(dir, "sdk", "sessions", "index.jsonl"), async () => {
				acquired.resolve();
				await holderDone.promise;
			});
		})();
		await acquired.promise;
		const started = Date.now();
		const competing = lockModule
			.withFileLock(path.join(dir, "sdk", "sessions", "index.jsonl"), async () => {}, {
				signal: controller.signal,
				retries: 600,
				retryDelayMs: 100,
			})
			.catch(error => error as Error);
		setTimeout(() => controller.abort(), 150);
		const outcome = await competing;
		holderDone.resolve();
		expect(outcome).toBeInstanceOf(Error);
		expect(Date.now() - started).toBeLessThan(5_000);

		// A live owner whose lock record is two minutes old (a long critical
		// section, or a process whose event loop is stalled) keeps its lock: a
		// contender gives up with an error and the lock directory stays.
		const agedLog = path.join(dir, "aged", "index.jsonl");
		await fs.mkdir(`${agedLog}.lock`, { recursive: true });
		await fs.writeFile(
			path.join(`${agedLog}.lock`, "info"),
			JSON.stringify({ pid: process.pid, timestamp: Date.now() - 120_000 }),
		);
		let agedFailure: unknown;
		let agedRan = false;
		try {
			await lockModule.withFileLock(
				agedLog,
				async () => {
					agedRan = true;
				},
				{ retries: 3, retryDelayMs: 5 },
			);
		} catch (error) {
			agedFailure = error;
		}
		expect(agedRan).toBe(false);
		expect(agedFailure).toBeInstanceOf(Error);
		expect(await fs.exists(`${agedLog}.lock`)).toBe(true);
	});

	it("bounds concurrent launches behind a legitimate holder and converges after release", async () => {
		const dir = await fs.mkdtemp(path.join(os.tmpdir(), "ssb-ix-concurrent-"));
		const seed = await new SessionIndex(dir).open();
		await seed.append(registration("seed"));
		// A long but bounded holder (for example compaction on a large index)
		// holds the machine-global lock for a fixed delay, then releases. Its exit
		// is time-bounded, so launches cannot deadlock behind an open promise.
		const holder = seed.withLocked(async () => {
			await Bun.sleep(400);
		});
		const launches = await Promise.all(
			[0, 1, 2].map(async i => {
				await Bun.sleep(i * 25);
				const launch = await new SessionIndex(dir).open();
				return (await launch.append(registration(`launch-${i}`))).indexSeq;
			}),
		);
		await holder;
		// Every launch landed a distinct, contiguous sequence: no corruption and
		// no lost update.
		expect(new Set(launches)).toEqual(new Set([2, 3, 4]));
		const replay = await new SessionIndex(dir).open();
		expect(replay.indexSeq).toBe(4);
		expect((await replay.diagnose()).status).toBe("healthy");
	}, 30_000);
});
