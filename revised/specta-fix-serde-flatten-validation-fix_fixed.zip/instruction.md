## Task

specta-serde is supposed to catch, at export time, any type whose serde attributes describe something serde cannot round-trip, so people hear about it when they export instead of when a value blows up at runtime.
A few shapes get through.
They export `Ok` through `specta_typescript::Typescript::default().export(&types, specta_serde::Format)` and through the split `specta_serde::PhasesFormat`, and they should come back as `Err`.

- `#[serde(flatten)]` on a field whose value is a sequence, a tuple or a scalar on the wire exports fine, then serde_json fails at runtime with "can only flatten structs and maps".
  A `Vec<_>`, a tuple or a plain integer are the obvious cases, but the declared type of the field is not what determines the wire shape.
  The shape serde ends up writing is what counts, and the split format sees each direction on its own.
  The shapes serde does flatten have to keep exporting, so maps, structs, `Option` of those and enums, untagged catch-all ones like `serde_json::Value` included, stay valid however they are reached.
  The error should say the flatten is the problem and name the field.

- `#[serde(with = ...)]`, `serialize_with` or `deserialize_with` on a tuple struct or newtype struct field is accepted silently and the pre-codec type gets exported.
  The same attribute on a named struct field is already rejected unless the field carries a `#[specta(type = ...)]` override, and unnamed fields should get the same treatment.

- A key that lands twice in one JSON object exports fine and serializes fine, then serde refuses to read its own output back with "duplicate field".
  The cases to catch come from merging, where the declaration doesn't show the clash: a flattened value writes a key the parent already has, or two flattened values share one.
  Tags write keys too, so an internally tagged enum puts its tag into the object of a newtype variant's payload, and a struct-level `tag` sits next to whatever that struct flattens.
  What counts is the object serde writes, including renamed keys and keys that come up from values merged several levels down.
  The split format judges each direction on its own.
  Two ordinary fields renamed onto the same key are visible in the declaration and can be left alone.
  Maps and untagged enums only show their keys at runtime, so they never count as a clash.
  The error should name the repeated key.

- An untagged enum nested inside an internally tagged enum is rejected, which is right, but the error names the outer enum and blames it for a variant that only exists on the inner one.
  The message should point at the inner type and its own variant.

Nothing that exports and round-trips today may start failing, and recursive types still have to export without hanging.
