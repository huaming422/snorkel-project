//! Export-time validation of serde shapes that cannot round-trip.
//!
//! Every test drives the public export surface that already exists in the
//! crate and reads nothing else:
//!
//!   * `specta_typescript::Typescript::default().export(&types, specta_serde::Format)`
//!     returns `Err` for a type whose serde attributes describe a shape serde
//!     cannot (de)serialize, and `Ok` otherwise.
//!   * `specta_serde::PhasesFormat` is the split serialize/deserialize variant.
//!     It is used where a shape is only live in one direction.
//!
//! The tests register plain derived types and look only at `Result::is_ok`,
//! `Result::is_err` and the `Display` text of the returned error. A rejection
//! is checked by a substring a user would read in the message: the word
//! "flatten", the existing "Unsupported serde attribute" wording, a field
//! name, a type name, or the key that is written twice into one object. No
//! module, function or error variant from the fix is named anywhere in this
//! file.

use std::collections::HashMap;
use std::marker::PhantomData;

use serde::{Deserialize, Serialize};
use specta::{Type, Types};
use specta_typescript::Typescript;

// A named-field struct is the canonical flattenable shape; reused as the valid
// inner payload throughout.
#[derive(Type, Serialize, Deserialize, Clone)]
#[specta(collect = false)]
struct Addr {
    id: i32,
}

// ---------------------------------------------------------------------------
// Flatten target validation: rejected shapes (sequence / tuple / scalar).
// ---------------------------------------------------------------------------

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenSeq {
    head: i32,
    #[serde(flatten)]
    extra: Vec<u8>,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenTuple {
    head: i32,
    #[serde(flatten)]
    pair: (u8, u8),
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenScalar {
    head: i32,
    #[serde(flatten)]
    count: u32,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct PairPayload(i32, i32);

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenTupleStruct {
    head: i32,
    #[serde(flatten)]
    coords: PairPayload,
}

// A tuple struct with no fields still serializes as a sequence, an empty one.
#[derive(Type, Serialize)]
#[specta(collect = false)]
struct EmptyTuplePayload();

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenEmptyTupleStruct {
    head: i32,
    #[serde(flatten)]
    marker: EmptyTuplePayload,
}

// A flattened field inside an enum variant's named fields is a field like any
// other; serde applies the same runtime rule to it.
#[derive(Type, Serialize)]
#[specta(collect = false)]
#[allow(dead_code)]
enum VariantFlattenSeq {
    Payload {
        head: i32,
        #[serde(flatten)]
        extra: Vec<u8>,
    },
}

/// Exports `T` and checks that it is rejected with an error that mentions the
/// flatten and names the flattened field.
fn assert_flatten_rejected<T: Type>(format: impl specta::Format + 'static, field: &str, context: &str) {
    let err = Typescript::default()
        .export(&Types::default().register::<T>(), format)
        .expect_err(context);
    let msg = err.to_string();
    assert!(msg.contains("flatten"), "error should mention flatten: {msg}");
    assert!(
        msg.contains(field),
        "error should name the flattened field `{field}`: {msg}"
    );
}

#[test]
fn flatten_of_sequence_is_rejected() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<FlattenSeq>(),
            specta_serde::Format,
        )
        .expect_err("a flattened sequence cannot round-trip and must be rejected at export");
    let msg = err.to_string();
    assert!(msg.contains("flatten"), "error should mention flatten: {msg}");
    assert!(
        msg.contains("extra"),
        "error should point at the offending field path: {msg}"
    );
}

#[test]
fn flatten_of_tuple_is_rejected() {
    assert_flatten_rejected::<FlattenTuple>(
        specta_serde::Format,
        "pair",
        "a flattened tuple serializes as a sequence and must be rejected",
    );
}

#[test]
fn flatten_of_scalar_is_rejected() {
    assert_flatten_rejected::<FlattenScalar>(
        specta_serde::Format,
        "count",
        "a flattened scalar cannot merge into the surrounding map",
    );
}

#[test]
fn flatten_of_tuple_struct_is_rejected() {
    assert_flatten_rejected::<FlattenTupleStruct>(
        specta_serde::Format,
        "coords",
        "a tuple struct serializes as a sequence and must be rejected when flattened",
    );
}

#[test]
fn flatten_of_zero_field_tuple_struct_is_rejected() {
    assert_flatten_rejected::<FlattenEmptyTupleStruct>(
        specta_serde::Format,
        "marker",
        "a tuple struct with no fields serializes as an empty sequence",
    );
}

#[test]
fn flatten_of_sequence_in_enum_variant_is_rejected() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<VariantFlattenSeq>(),
            specta_serde::Format,
        )
        .expect_err("a flattened sequence inside a variant's named fields cannot round-trip either");
    let msg = err.to_string();
    assert!(msg.contains("flatten"), "error should mention flatten: {msg}");
    assert!(
        msg.contains("extra"),
        "error should point at the offending field: {msg}"
    );
}

// ---------------------------------------------------------------------------
// Flatten target validation: accepted shapes (struct / Option / map / enums).
// serde flattens each of these at runtime, so export must keep succeeding.
// ---------------------------------------------------------------------------

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenNamedStruct {
    head: i32,
    #[serde(flatten)]
    extra: Addr,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenOptionStruct {
    head: i32,
    #[serde(flatten)]
    extra: Option<Addr>,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenMap {
    head: i32,
    #[serde(flatten)]
    extra: HashMap<String, String>,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
#[serde(untagged)]
enum UntaggedBody {
    L { a: i32 },
    #[allow(dead_code)]
    R { b: i32 },
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenUntaggedEnum {
    head: i32,
    #[serde(flatten)]
    extra: UntaggedBody,
}

// The catch-all pattern: an untagged enum whose variants mix objects with
// scalars and sequences, the way `serde_json::Value` does. Only the active
// variant matters at runtime, so the static check keeps accepting the enum.
#[derive(Type, Serialize)]
#[specta(collect = false)]
#[serde(untagged)]
#[allow(dead_code)]
enum CatchAllBody {
    Text(String),
    Items(Vec<i32>),
    Fields { a: i32 },
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenCatchAllEnum {
    head: i32,
    #[serde(flatten)]
    extra: CatchAllBody,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
enum ExternalBody {
    A { x: i32 },
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenExternalEnum {
    head: i32,
    #[serde(flatten)]
    extra: ExternalBody,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
#[serde(tag = "k")]
enum InternalBody {
    A { x: i32 },
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenInternalEnum {
    head: i32,
    #[serde(flatten)]
    extra: InternalBody,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
#[serde(tag = "k", content = "c")]
enum AdjacentBody {
    A { x: i32 },
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenAdjacentEnum {
    head: i32,
    #[serde(flatten)]
    extra: AdjacentBody,
}

/// Exports `T` through both the unified and the split format and expects
/// both to succeed.
fn assert_exports_ok<T: Type>(context: &str) {
    Typescript::default()
        .export(&Types::default().register::<T>(), specta_serde::Format)
        .unwrap_or_else(|err| panic!("{context} should export cleanly, got: {err}"));
    Typescript::default()
        .export(&Types::default().register::<T>(), specta_serde::PhasesFormat)
        .unwrap_or_else(|err| {
            panic!("{context} should export cleanly with PhasesFormat, got: {err}")
        });
}

#[test]
fn flatten_of_named_struct_is_accepted() {
    assert_exports_ok::<FlattenNamedStruct>("flatten of a named struct");
}

#[test]
fn flatten_of_option_struct_is_accepted() {
    assert_exports_ok::<FlattenOptionStruct>("flatten of an Option<struct>");
}

#[test]
fn flatten_of_map_is_accepted() {
    assert_exports_ok::<FlattenMap>("flatten of a map");
}

#[test]
fn flatten_of_untagged_enum_is_accepted() {
    assert_exports_ok::<FlattenUntaggedEnum>("flatten of an untagged enum");
}

#[test]
fn flatten_of_untagged_enum_with_non_object_variants_is_accepted() {
    assert_exports_ok::<FlattenCatchAllEnum>(
        "flatten of an untagged enum that mixes object, scalar and sequence variants",
    );
}

#[test]
fn flatten_of_external_enum_is_accepted() {
    assert_exports_ok::<FlattenExternalEnum>("flatten of an externally tagged enum");
}

#[test]
fn flatten_of_internal_enum_is_accepted() {
    assert_exports_ok::<FlattenInternalEnum>("flatten of an internally tagged enum");
}

#[test]
fn flatten_of_adjacent_enum_is_accepted() {
    assert_exports_ok::<FlattenAdjacentEnum>("flatten of an adjacently tagged enum");
}

// ---------------------------------------------------------------------------
// Codec attribute on an unnamed (tuple/newtype) struct field.
// ---------------------------------------------------------------------------

mod wire_codec {
    use serde::{Deserialize, Deserializer, Serializer};

    pub fn serialize<S>(value: &u32, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        serializer.collect_str(value)
    }

    pub fn deserialize<'de, D>(deserializer: D) -> Result<u32, D::Error>
    where
        D: Deserializer<'de>,
    {
        String::deserialize(deserializer)?
            .parse()
            .map_err(serde::de::Error::custom)
    }
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct NewtypeCodecNoOverride(#[serde(with = "wire_codec")] u32);

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct NewtypeCodecWithOverride(
    #[specta(type = String)]
    #[serde(with = "wire_codec")]
    u32,
);

#[test]
fn codec_on_newtype_field_without_override_is_rejected() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<NewtypeCodecNoOverride>(),
            specta_serde::Format,
        )
        .expect_err(
            "a codec that changes the wire type on an unnamed field must be rejected unless the \
             field carries a type override, just like a named-struct field already is",
        );
    assert!(
        err.to_string().contains("Unsupported serde attribute"),
        "unexpected error: {err}"
    );
}

#[test]
fn codec_on_newtype_field_with_override_is_accepted() {
    let ts = Typescript::default()
        .export(
            &Types::default().register::<NewtypeCodecWithOverride>(),
            specta_serde::Format,
        )
        .expect("a type override satisfies the codec guard");
    assert!(
        ts.contains("string"),
        "the override type should be exported, got: {ts}"
    );
}

fn wire_codec_serialize<S>(value: &u32, serializer: S) -> Result<S::Ok, S::Error>
where
    S: serde::Serializer,
{
    wire_codec::serialize(value, serializer)
}

fn wire_codec_deserialize<'de, D>(deserializer: D) -> Result<u32, D::Error>
where
    D: serde::Deserializer<'de>,
{
    wire_codec::deserialize(deserializer)
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct NewtypeSerializeWithNoOverride(#[serde(serialize_with = "wire_codec_serialize")] u32);

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct TupleDeserializeWithNoOverride(
    i32,
    #[serde(deserialize_with = "wire_codec_deserialize")] u32,
);

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct NewtypeSerializeWithOverride(
    #[specta(type = String)]
    #[serde(serialize_with = "wire_codec_serialize")]
    u32,
);

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct TupleDeserializeWithOverride(
    i32,
    #[specta(type = String)]
    #[serde(deserialize_with = "wire_codec_deserialize")]
    u32,
);

#[test]
fn serialize_with_on_newtype_field_without_override_is_rejected() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<NewtypeSerializeWithNoOverride>(),
            specta_serde::Format,
        )
        .expect_err("a serialize-only codec on an unnamed field needs a type override too");
    assert!(
        err.to_string().contains("Unsupported serde attribute"),
        "unexpected error: {err}"
    );
}

#[test]
fn deserialize_with_on_tuple_struct_field_without_override_is_rejected() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<TupleDeserializeWithNoOverride>(),
            specta_serde::Format,
        )
        .expect_err("a deserialize-only codec on an unnamed field needs a type override too");
    assert!(
        err.to_string().contains("Unsupported serde attribute"),
        "unexpected error: {err}"
    );
}

#[test]
fn one_sided_codecs_on_unnamed_fields_with_override_are_accepted() {
    assert_exports_ok::<NewtypeSerializeWithOverride>("serialize_with plus a type override");
    assert_exports_ok::<TupleDeserializeWithOverride>("deserialize_with plus a type override");
}

// A codec on an unnamed field after a skipped field is still rejected: the
// skip does not let the codec slip through the guard. The rejection and its
// "Unsupported serde attribute" wording are checked; which index the message
// reports for the field is left open.
#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct NewtypeCodecAfterSkipped(#[serde(skip)] u32, #[serde(with = "wire_codec")] u32);

#[test]
fn codec_on_newtype_field_after_a_skipped_field_is_rejected() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<NewtypeCodecAfterSkipped>(),
            specta_serde::Format,
        )
        .expect_err("the codec field is still rejected after a skipped field");
    assert!(
        err.to_string().contains("Unsupported serde attribute"),
        "unexpected error: {err}"
    );
}

// ---------------------------------------------------------------------------
// Misattributed error: an untagged enum nested in an internally tagged enum.
// The reported error must name the inner type and its variant, not blame the
// outer container for a variant it does not have.
// ---------------------------------------------------------------------------

#[derive(Type, Serialize)]
#[specta(collect = false)]
#[serde(untagged)]
enum PrimPayload {
    P(u32),
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
#[serde(tag = "k")]
enum TaggedOuter {
    X(PrimPayload),
}

#[test]
fn nested_untagged_enum_error_names_the_inner_type() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<TaggedOuter>(),
            specta_serde::Format,
        )
        .expect_err("an untagged scalar payload cannot be merged with an internal tag");
    let msg = err.to_string();
    assert!(
        msg.contains("PrimPayload"),
        "error should name the inner untagged type, not only the outer enum: {msg}"
    );
    assert!(
        msg.contains("variant 'P'"),
        "error should name the inner enum's variant, not a variant of the outer enum: {msg}"
    );
}

// ---------------------------------------------------------------------------
// Wire-shape fidelity: newtype delegation, generic substitution, transparent
// nesting, conversion/phase liveness, skip liveness, and termination.
// ---------------------------------------------------------------------------

// A single-field tuple struct is a newtype: serde delegates straight to the
// inner value, so flattening it is exactly as valid as flattening that value.
#[derive(Type, Serialize)]
#[specta(collect = false)]
struct NewtypeOfStruct(Addr);

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct NewtypeOfScalar(u32);

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenNewtypeStruct {
    head: i32,
    #[serde(flatten)]
    extra: NewtypeOfStruct,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenNewtypeScalar {
    head: i32,
    #[serde(flatten)]
    extra: NewtypeOfScalar,
}

#[test]
fn flatten_of_newtype_around_struct_is_accepted() {
    assert_exports_ok::<FlattenNewtypeStruct>("flatten of a newtype wrapping a struct");
}

#[test]
fn flatten_of_newtype_around_scalar_is_rejected() {
    assert_flatten_rejected::<FlattenNewtypeScalar>(
        specta_serde::Format,
        "extra",
        "newtype delegation exposes the scalar, which serde cannot flatten",
    );
}

// A reference to a generic type carries concrete arguments, so the flatten
// target's real shape is knowable and must be substituted in.
#[derive(Type, Serialize)]
#[specta(collect = false)]
struct GenericNewtype<T>(T);

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenGenericSeq {
    head: i32,
    #[serde(flatten)]
    extra: GenericNewtype<Vec<u8>>,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenGenericStruct {
    head: i32,
    #[serde(flatten)]
    extra: GenericNewtype<Addr>,
}

#[test]
fn flatten_of_generic_newtype_over_sequence_is_rejected() {
    assert_flatten_rejected::<FlattenGenericSeq>(
        specta_serde::Format,
        "extra",
        "the concrete argument is a sequence, so the flatten target is a sequence",
    );
}

#[test]
fn flatten_of_generic_newtype_over_struct_is_accepted() {
    assert_exports_ok::<FlattenGenericStruct>("flatten of a generic newtype over a struct");
}

// The same syntactic generic reference reached under two different outer
// instantiations in one walk must be validated against each; walk order must
// not let a good instantiation mask a bad one.
#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenGenericField<T> {
    head: i32,
    #[serde(flatten)]
    body: T,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct OuterOf<T> {
    inner: FlattenGenericField<T>,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct TwoSubstitutionsGoodFirst {
    good: OuterOf<Addr>,
    bad: OuterOf<Vec<u8>>,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct TwoSubstitutionsBadFirst {
    bad: OuterOf<Vec<u8>>,
    good: OuterOf<Addr>,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct TwoSubstitutionsGoodOnly {
    good: OuterOf<Addr>,
}

#[test]
fn flatten_generic_reached_under_two_substitutions_rejects_the_bad_one() {
    assert_flatten_rejected::<TwoSubstitutionsGoodFirst>(
        specta_serde::Format,
        "body",
        "the struct instantiation seen first must not mask the sequence one",
    );

    assert_flatten_rejected::<TwoSubstitutionsBadFirst>(
        specta_serde::Format,
        "body",
        "the sequence instantiation must be rejected regardless of walk order",
    );
}

#[test]
fn flatten_generic_reached_under_one_good_substitution_is_accepted() {
    assert_exports_ok::<TwoSubstitutionsGoodOnly>("flatten of a generic under one struct arg");
}

// The flattened type is itself a generic reference whose argument is a
// placeholder of the enclosing definition, so the real shape is only known
// from the instantiation one level up.
#[derive(Type, Serialize)]
#[specta(collect = false)]
struct Holder<T> {
    head: i32,
    #[serde(flatten)]
    body: GenericNewtype<T>,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct HolderOfStruct {
    h: Holder<Addr>,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct HolderOfSeq {
    h: Holder<Vec<u8>>,
}

#[test]
fn flatten_of_generic_argument_passed_through_an_enclosing_generic_is_rejected_for_sequence() {
    assert_flatten_rejected::<HolderOfSeq>(
        specta_serde::Format,
        "body",
        "the argument written one level up is a sequence",
    );
}

#[test]
fn flatten_of_generic_argument_passed_through_an_enclosing_generic_is_accepted_for_struct() {
    assert_exports_ok::<HolderOfStruct>("flatten of a generic newtype whose argument comes from the enclosing generic");
}

// Transparent wrappers delegate straight through; nested ones still resolve to
// the innermost real shape.
#[derive(Type, Serialize)]
#[specta(collect = false)]
#[serde(transparent)]
struct TransparentInner(Vec<u8>);

#[derive(Type, Serialize)]
#[specta(collect = false)]
#[serde(transparent)]
struct TransparentOuter(TransparentInner);

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenTransparentSeq {
    head: i32,
    #[serde(flatten)]
    extra: TransparentOuter,
}

#[test]
fn flatten_of_nested_transparent_wrappers_around_sequence_is_rejected() {
    assert_flatten_rejected::<FlattenTransparentSeq>(
        specta_serde::Format,
        "extra",
        "transparent wrappers still resolve to a sequence",
    );
}

// Conversion attributes replace the declared shape with a wire shape per
// direction. A one-directional conversion leaves the opposite direction on the
// raw declared shape, which must still be checked.
#[derive(Type, Serialize, Deserialize, Clone)]
#[specta(collect = false)]
struct ConversionWire {
    id: String,
}

#[derive(Type, Serialize, Deserialize, Clone)]
#[specta(collect = false)]
#[serde(into = "ConversionWire")]
struct IntoOnlyScalar(u32);

impl From<IntoOnlyScalar> for ConversionWire {
    fn from(value: IntoOnlyScalar) -> Self {
        Self {
            id: value.0.to_string(),
        }
    }
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenIntoOnly {
    head: i32,
    #[serde(flatten)]
    extra: IntoOnlyScalar,
}

#[test]
fn flatten_of_into_only_conversion_checks_the_raw_deserialize_shape() {
    assert_flatten_rejected::<FlattenIntoOnly>(
        specta_serde::PhasesFormat,
        "extra",
        "serialize uses a struct wire, but deserialize uses the raw scalar newtype",
    );
}

// A container conversion on an enum replaces the enum's own wire shape in the
// direction the conversion applies to, so the enum's usual acceptance does not
// carry over when the target is a sequence.
#[derive(Type, Serialize, Deserialize, Clone)]
#[specta(collect = false)]
#[serde(into = "ConversionWire")]
#[allow(dead_code)]
enum IntoStructEnum {
    A { x: i32 },
}

impl From<IntoStructEnum> for ConversionWire {
    fn from(value: IntoStructEnum) -> Self {
        match value {
            IntoStructEnum::A { x } => Self { id: x.to_string() },
        }
    }
}

#[derive(Type, Serialize, Deserialize, Clone)]
#[specta(collect = false)]
#[serde(into = "Vec<u8>")]
#[allow(dead_code)]
enum IntoSeqEnum {
    A { x: i32 },
}

impl From<IntoSeqEnum> for Vec<u8> {
    fn from(value: IntoSeqEnum) -> Self {
        match value {
            IntoSeqEnum::A { x } => x.to_le_bytes().to_vec(),
        }
    }
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenIntoStructEnum {
    head: i32,
    #[serde(flatten)]
    extra: IntoStructEnum,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenIntoSeqEnum {
    head: i32,
    #[serde(flatten)]
    extra: IntoSeqEnum,
}

#[test]
fn flatten_of_enum_converted_into_a_sequence_is_rejected() {
    assert_flatten_rejected::<FlattenIntoSeqEnum>(
        specta_serde::PhasesFormat,
        "extra",
        "the serialize wire of the enum is a sequence",
    );
}

#[test]
fn flatten_of_enum_converted_into_a_struct_is_accepted() {
    Typescript::default()
        .export(
            &Types::default().register::<FlattenIntoStructEnum>(),
            specta_serde::PhasesFormat,
        )
        .expect("the serialize wire is a struct and the deserialize side is the enum itself");
}

// An explicit phase override holds both phase shapes; the live phase must be
// looked inside rather than trusting the wrapper.
#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenPhasedSeq {
    head: i32,
    #[serde(flatten)]
    #[specta(type = specta_serde::Phased<Vec<String>, Addr>)]
    extra: HashMap<String, String>,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenPhasedMap {
    head: i32,
    #[serde(flatten)]
    #[specta(type = specta_serde::Phased<HashMap<String, String>, Addr>)]
    extra: HashMap<String, String>,
}

#[test]
fn flatten_of_phased_override_with_a_sequence_phase_is_rejected() {
    assert_flatten_rejected::<FlattenPhasedSeq>(
        specta_serde::PhasesFormat,
        "extra",
        "the serialize phase is a sequence, which cannot be flattened",
    );
}

#[test]
fn flatten_of_phased_override_with_map_and_struct_phases_is_accepted() {
    Typescript::default()
        .export(
            &Types::default().register::<FlattenPhasedMap>(),
            specta_serde::PhasesFormat,
        )
        .expect("both phases are map/struct shaped, so the flatten is valid both ways");
}

// Skip liveness: a field skipped in a direction never flattens in that
// direction, so its shape there is irrelevant and must not be rejected.
#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenOneSidedSkipSeq {
    head: i32,
    #[serde(flatten, skip_serializing, default)]
    extra: Vec<u8>,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenBothSidedSkipSeq {
    head: i32,
    #[serde(flatten, skip_serializing, skip_deserializing, default)]
    extra: Vec<u8>,
}

// The serialize phase of the override is a sequence, but the field is skipped
// on serialize, so that sequence never reaches the wire. The deserialize phase
// is a struct and is live.
#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenDeadSerializeSeq {
    head: i32,
    #[serde(flatten, skip_serializing, default)]
    #[specta(type = specta_serde::Phased<Vec<String>, Addr>)]
    extra: HashMap<String, String>,
}

// The mirror image: the deserialize phase is a sequence but the field is
// skipped on deserialize, so only the struct-shaped serialize phase is live.
#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenDeadDeserializeSeq {
    head: i32,
    #[serde(flatten, skip_deserializing, default)]
    #[specta(type = specta_serde::Phased<Addr, Vec<String>>)]
    extra: HashMap<String, String>,
}

#[test]
fn flatten_of_one_sided_skip_is_rejected_on_its_live_direction() {
    // The field is skipped only on serialize, so the deserialize phase still
    // flattens a live sequence and the split formatter must reject it there.
    assert_flatten_rejected::<FlattenOneSidedSkipSeq>(
        specta_serde::PhasesFormat,
        "extra",
        "the deserialize phase flattens a live sequence",
    );
}

#[test]
fn one_sided_skip_dead_direction_is_not_required_flattenable() {
    // Each type carries a sequence only in the phase its skip removes, so the
    // split export sees a struct in every live direction and must succeed.
    Typescript::default()
        .export(
            &Types::default().register::<FlattenDeadSerializeSeq>(),
            specta_serde::PhasesFormat,
        )
        .expect("the serialize phase never renders the skip-serializing sequence");

    Typescript::default()
        .export(
            &Types::default().register::<FlattenDeadDeserializeSeq>(),
            specta_serde::PhasesFormat,
        )
        .expect("the deserialize phase never renders the skip-deserializing sequence");
}

// A one-sided skip on the enclosing variant removes every field of that
// variant from the skipped direction, so the override's sequence side is
// only live when the skip is on the other direction.
#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
#[allow(dead_code)]
enum VariantSkipSerializeSeq {
    #[serde(skip_serializing)]
    Load {
        head: i32,
        #[serde(flatten)]
        #[specta(type = specta_serde::Phased<Vec<String>, Addr>)]
        extra: HashMap<String, String>,
    },
    Other {
        x: i32,
    },
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
#[allow(dead_code)]
enum VariantSkipDeserializeSeq {
    #[serde(skip_deserializing)]
    Load {
        head: i32,
        #[serde(flatten)]
        #[specta(type = specta_serde::Phased<Vec<String>, Addr>)]
        extra: HashMap<String, String>,
    },
    Other {
        x: i32,
    },
}

#[test]
fn variant_skipped_on_serialize_does_not_require_its_serialize_shape_flattenable() {
    Typescript::default()
        .export(
            &Types::default().register::<VariantSkipSerializeSeq>(),
            specta_serde::PhasesFormat,
        )
        .expect("the variant never serializes, so only the struct-shaped deserialize side is live");
}

#[test]
fn variant_skipped_on_deserialize_still_rejects_its_live_serialize_sequence() {
    assert_flatten_rejected::<VariantSkipDeserializeSeq>(
        specta_serde::PhasesFormat,
        "extra",
        "the variant still serializes, and its serialize side is a sequence",
    );
}

#[test]
fn flatten_of_fully_skipped_sequence_is_accepted() {
    assert_exports_ok::<FlattenBothSidedSkipSeq>("flatten of a sequence skipped in both directions");
}

// Termination: resolving a self-recursive generic flatten target must not hang.
#[derive(Type, Serialize)]
#[specta(collect = false)]
struct SelfRecursiveGeneric<T>(Box<SelfRecursiveGeneric<T>>, PhantomData<T>);

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenSelfRecursiveGeneric {
    head: i32,
    #[serde(flatten)]
    extra: SelfRecursiveGeneric<Addr>,
}

/// Runs `f` on a worker thread and panics if it does not finish in `timeout`,
/// so an export that recurses forever shows up as a failed test instead of a
/// hung process.
fn with_timeout<T: Send + 'static>(
    timeout: std::time::Duration,
    f: impl FnOnce() -> T + Send + 'static,
) -> T {
    let (tx, rx) = std::sync::mpsc::channel();
    std::thread::spawn(move || {
        let _ = tx.send(f());
    });
    rx.recv_timeout(timeout)
        .expect("export did not finish in time, most likely unbounded recursion")
}

#[test]
fn flatten_of_self_recursive_generic_terminates() {
    // Only termination is asserted here. Whether this shape is accepted or
    // rejected is not part of the contract; finishing is.
    let _ = with_timeout(std::time::Duration::from_secs(10), || {
        Typescript::default().export(
            &Types::default().register::<FlattenSelfRecursiveGeneric>(),
            specta_serde::Format,
        )
    });
}

// ---------------------------------------------------------------------------
// Duplicate keys in one object. serde writes a struct's fields, the keys of
// every flattened value and an internal tag into the same JSON object. When a
// key arrives twice, serialization still succeeds but deserializing the
// output fails with `duplicate field`, so the type cannot round-trip.
// Each rejected shape below has an accepted twin of the same family.
// ---------------------------------------------------------------------------

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct TraceMeta {
    trace_id: i32,
    label: String,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct SpanMeta {
    span_id: i32,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenRepeatsSiblingKey {
    trace_id: i32,
    #[serde(flatten)]
    meta: TraceMeta,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenDistinctFromSibling {
    trace_id: i32,
    #[serde(flatten)]
    meta: SpanMeta,
}

fn assert_duplicate_key<T: Type>(format: impl specta::Format + 'static, key: &str, context: &str) {
    let err = Typescript::default()
        .export(&Types::default().register::<T>(), format)
        .expect_err(context);
    assert!(
        err.to_string().contains(key),
        "error should name the repeated key `{key}`: {err}"
    );
}

#[test]
fn flatten_repeating_a_sibling_key_is_rejected() {
    assert_duplicate_key::<FlattenRepeatsSiblingKey>(
        specta_serde::Format,
        "trace_id",
        "the flattened struct writes `trace_id` next to the struct's own `trace_id`",
    );
}

#[test]
fn flatten_with_distinct_keys_is_accepted() {
    assert_exports_ok::<FlattenDistinctFromSibling>("a flattened struct with its own keys");
}

// Two flattened values, neither visible from the other.
#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct TraceOnly {
    trace_id: i32,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct TwoFlattensShareKey {
    #[serde(flatten)]
    a: TraceMeta,
    #[serde(flatten)]
    b: Option<TraceOnly>,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct TwoFlattensDistinct {
    #[serde(flatten)]
    a: TraceMeta,
    #[serde(flatten)]
    b: Option<SpanMeta>,
}

#[test]
fn two_flattened_values_sharing_a_key_are_rejected() {
    assert_duplicate_key::<TwoFlattensShareKey>(
        specta_serde::Format,
        "trace_id",
        "both flattened values write `trace_id`; an `Option` only hides it when it is `None`",
    );
}

#[test]
fn two_flattened_values_with_distinct_keys_are_accepted() {
    assert_exports_ok::<TwoFlattensDistinct>("two flattened values with distinct keys");
}

// The repeated key sits two flattens deep, behind a newtype and a
// transparent wrapper.
#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct MetaNewtype(TraceMeta);

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
#[serde(transparent)]
struct MetaTransparent {
    inner: MetaNewtype,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct MiddleLayer {
    depth: i32,
    #[serde(flatten)]
    meta: MetaTransparent,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct DeepFlattenRepeatsKey {
    label: String,
    #[serde(flatten)]
    middle: MiddleLayer,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct DeepFlattenDistinct {
    span_id: i32,
    #[serde(flatten)]
    middle: MiddleLayer,
}

#[test]
fn key_repeated_through_nested_flattens_and_wrappers_is_rejected() {
    assert_duplicate_key::<DeepFlattenRepeatsKey>(
        specta_serde::Format,
        "label",
        "`label` comes back up through a flatten, a transparent wrapper, a newtype and another flatten",
    );
}

#[test]
fn nested_flattens_with_distinct_keys_are_accepted() {
    assert_exports_ok::<DeepFlattenDistinct>("nested flattens whose keys never meet");
}

// Keys are compared after renames, on both sides of the flatten.
#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct RenamedMeta {
    #[serde(rename = "traceId")]
    id: i32,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
#[serde(rename_all = "camelCase")]
struct RenamedCollision {
    trace_id: i32,
    #[serde(flatten)]
    meta: RenamedMeta,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct RenamedNoCollision {
    trace_id: i32,
    #[serde(flatten)]
    meta: RenamedMeta,
}

#[test]
fn keys_that_meet_only_after_renames_are_rejected() {
    assert_duplicate_key::<RenamedCollision>(
        specta_serde::Format,
        "traceId",
        "`rename_all` turns `trace_id` into the same `traceId` the flattened struct writes",
    );
}

#[test]
fn keys_that_differ_after_renames_are_accepted() {
    assert_exports_ok::<RenamedNoCollision>("`trace_id` and `traceId` are different keys");
}

// A generic flatten target only collides under some instantiations.
#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct WithExtra<T> {
    trace_id: i32,
    #[serde(flatten)]
    extra: T,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct UsesCollidingExtra {
    inner: WithExtra<TraceMeta>,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct UsesDistinctExtra {
    inner: WithExtra<SpanMeta>,
}

#[test]
fn generic_flatten_colliding_under_its_instantiation_is_rejected() {
    assert_duplicate_key::<UsesCollidingExtra>(
        specta_serde::Format,
        "trace_id",
        "`WithExtra<TraceMeta>` writes `trace_id` twice",
    );
}

#[test]
fn generic_flatten_distinct_under_its_instantiation_is_accepted() {
    assert_exports_ok::<UsesDistinctExtra>("`WithExtra<SpanMeta>` has distinct keys");
}

// A skipped field writes nothing, on either side of the flatten.
#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct TraceMetaSkippedId {
    #[serde(skip)]
    trace_id: i32,
    label: String,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenWithSkippedInnerKey {
    trace_id: i32,
    #[serde(flatten)]
    meta: TraceMetaSkippedId,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenWithSkippedOuterKey {
    #[serde(skip)]
    trace_id: i32,
    #[serde(flatten)]
    meta: TraceMeta,
}

#[test]
fn skipped_fields_do_not_claim_keys() {
    assert_exports_ok::<FlattenWithSkippedInnerKey>("the flattened `trace_id` is skipped");
    assert_exports_ok::<FlattenWithSkippedOuterKey>("the outer `trace_id` is skipped");
}

// A map flattened next to fields only receives the keys nobody else claims.
#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenMapNextToFields {
    trace_id: i32,
    #[serde(flatten)]
    rest: HashMap<String, String>,
}

#[test]
fn flattened_map_next_to_fields_is_accepted() {
    assert_exports_ok::<FlattenMapNextToFields>("a flattened catch-all map");
}

// Internally tagged enums write the tag into the payload object of a newtype
// variant. Adjacent tagging keeps the payload under its own key.
#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct KindPayload {
    kind: i32,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct KindRenamedPayload {
    #[serde(rename = "kind_code")]
    kind: i32,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
#[serde(tag = "kind")]
#[allow(dead_code)]
enum TagCollidesWithPayload {
    Event(KindPayload),
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
#[serde(tag = "kind")]
#[allow(dead_code)]
enum TagDistinctFromPayload {
    Event(KindRenamedPayload),
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
#[serde(tag = "kind", content = "body")]
#[allow(dead_code)]
enum AdjacentTagNextToPayload {
    Event(KindPayload),
}

#[test]
fn internal_tag_repeated_by_newtype_payload_is_rejected() {
    assert_duplicate_key::<TagCollidesWithPayload>(
        specta_serde::Format,
        "kind",
        "the tag and the payload's own field both write `kind`",
    );
}

#[test]
fn internal_tag_next_to_renamed_payload_field_is_accepted() {
    assert_exports_ok::<TagDistinctFromPayload>("the payload field is renamed away from the tag");
}

#[test]
fn adjacent_tag_with_same_named_payload_field_is_accepted() {
    assert_exports_ok::<AdjacentTagNextToPayload>(
        "adjacent tagging nests the payload under `body`",
    );
}

// The payload's key is only visible after following its wrappers and its own
// flatten.
#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
#[serde(transparent)]
struct KindPayloadWrapper(KindPayload);

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct PayloadWithFlatten {
    value: i32,
    #[serde(flatten)]
    extra: KindPayloadWrapper,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
#[serde(tag = "kind")]
#[allow(dead_code)]
enum TagCollidesThroughPayloadFlatten {
    Event(PayloadWithFlatten),
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
#[serde(tag = "type")]
#[allow(dead_code)]
enum TagDistinctFromPayloadFlatten {
    Event(PayloadWithFlatten),
}

#[test]
fn internal_tag_repeated_through_payload_wrappers_is_rejected() {
    assert_duplicate_key::<TagCollidesThroughPayloadFlatten>(
        specta_serde::Format,
        "kind",
        "the payload flattens a transparent wrapper whose struct writes `kind`",
    );
}

#[test]
fn internal_tag_distinct_from_payload_flatten_is_accepted() {
    assert_exports_ok::<TagDistinctFromPayloadFlatten>("the tag is `type`, the payload writes `kind`");
}

// An internally tagged enum nested as another one's payload writes its own
// tag into the same object.
#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
#[serde(tag = "kind")]
#[allow(dead_code)]
enum InnerKindTagged {
    A,
    B,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
#[serde(tag = "op")]
#[allow(dead_code)]
enum InnerOpTagged {
    A,
    B,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
#[serde(tag = "kind")]
#[allow(dead_code)]
enum OuterSameTag {
    Wrap(InnerKindTagged),
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
#[serde(tag = "kind")]
#[allow(dead_code)]
enum OuterDifferentTag {
    Wrap(InnerOpTagged),
}

#[test]
fn nested_internal_enums_with_the_same_tag_are_rejected() {
    assert_duplicate_key::<OuterSameTag>(
        specta_serde::Format,
        "kind",
        "both enums write their tag as `kind` into one object",
    );
}

#[test]
fn nested_internal_enums_with_different_tags_are_accepted() {
    assert_exports_ok::<OuterDifferentTag>("the tags `kind` and `op` sit side by side");
}

// A struct-level `#[serde(tag = ...)]` is a key like any other.
#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
#[serde(tag = "kind")]
struct StructTagCollides {
    value: i32,
    #[serde(flatten)]
    extra: KindPayload,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
#[serde(tag = "kind")]
struct StructTagDistinct {
    value: i32,
    #[serde(flatten)]
    extra: KindRenamedPayload,
}

#[test]
fn struct_tag_repeated_by_a_flattened_key_is_rejected() {
    assert_duplicate_key::<StructTagCollides>(
        specta_serde::Format,
        "kind",
        "the struct tag and the flattened field both write `kind`",
    );
}

#[test]
fn struct_tag_next_to_distinct_flattened_keys_is_accepted() {
    assert_exports_ok::<StructTagDistinct>("the flattened field writes `kind_code`");
}

// A flattened enum writes the keys of whichever variant is active.
#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
#[allow(dead_code)]
enum ExternalKeyed {
    #[serde(rename = "trace_id")]
    Trace(i32),
    Other(i32),
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
#[serde(tag = "op")]
#[allow(dead_code)]
enum InternalKeyed {
    Set { value: i32 },
    Clear { trace_id: i32 },
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenExternalVariantCollides {
    trace_id: i32,
    #[serde(flatten)]
    action: ExternalKeyed,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenExternalVariantDistinct {
    span_id: i32,
    #[serde(flatten)]
    action: ExternalKeyed,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenInternalVariantCollides {
    trace_id: i32,
    #[serde(flatten)]
    action: InternalKeyed,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenInternalTagCollides {
    op: String,
    #[serde(flatten)]
    action: InternalKeyed,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenInternalEnumDistinct {
    span_id: i32,
    #[serde(flatten)]
    action: InternalKeyed,
}

#[test]
fn flattened_enum_variant_keys_colliding_with_siblings_are_rejected() {
    assert_duplicate_key::<FlattenExternalVariantCollides>(
        specta_serde::Format,
        "trace_id",
        "the `Trace` variant flattens to a `trace_id` key",
    );
    assert_duplicate_key::<FlattenInternalVariantCollides>(
        specta_serde::Format,
        "trace_id",
        "the `Clear` variant writes `trace_id`",
    );
    assert_duplicate_key::<FlattenInternalTagCollides>(
        specta_serde::Format,
        "op",
        "the flattened enum's tag is `op`",
    );
}

#[test]
fn flattened_enums_with_distinct_keys_are_accepted() {
    assert_exports_ok::<FlattenExternalVariantDistinct>("external variant keys stay distinct");
    assert_exports_ok::<FlattenInternalEnumDistinct>("internal tag and variant keys stay distinct");
}

// Conversions decide the keys: the wire type is what gets flattened.
#[derive(Type, Serialize, Deserialize, Clone)]
#[specta(collect = false)]
struct TraceWire {
    trace_id: i32,
}

#[derive(Type, Serialize, Deserialize, Clone)]
#[specta(collect = false)]
struct SpanWire {
    span_id: i32,
}

#[derive(Type, Serialize, Deserialize, Clone)]
#[specta(collect = false)]
#[serde(into = "TraceWire", from = "TraceWire")]
struct ConvertsToTrace {
    raw: i32,
}

impl From<ConvertsToTrace> for TraceWire {
    fn from(value: ConvertsToTrace) -> Self {
        Self { trace_id: value.raw }
    }
}

impl From<TraceWire> for ConvertsToTrace {
    fn from(value: TraceWire) -> Self {
        Self { raw: value.trace_id }
    }
}

#[derive(Type, Serialize, Deserialize, Clone)]
#[specta(collect = false)]
#[serde(into = "SpanWire", from = "SpanWire")]
struct ConvertsAwayFromTrace {
    trace_id: i32,
}

impl From<ConvertsAwayFromTrace> for SpanWire {
    fn from(value: ConvertsAwayFromTrace) -> Self {
        Self {
            span_id: value.trace_id,
        }
    }
}

impl From<SpanWire> for ConvertsAwayFromTrace {
    fn from(value: SpanWire) -> Self {
        Self {
            trace_id: value.span_id,
        }
    }
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenConversionCollides {
    trace_id: i32,
    #[serde(flatten)]
    extra: ConvertsToTrace,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenConversionDistinct {
    trace_id: i32,
    #[serde(flatten)]
    extra: ConvertsAwayFromTrace,
}

#[test]
fn flattened_conversion_wire_colliding_with_a_sibling_is_rejected() {
    assert_duplicate_key::<FlattenConversionCollides>(
        specta_serde::Format,
        "trace_id",
        "the declared struct has `raw`, but its wire type writes `trace_id`",
    );
}

#[test]
fn flattened_conversion_wire_with_distinct_keys_is_accepted() {
    assert_exports_ok::<FlattenConversionDistinct>(
        "the declared struct has `trace_id`, but its wire type writes `span_id`",
    );
}

// The split export judges each direction on its own.
#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct PhasedFlattenCollides {
    trace_id: i32,
    #[serde(flatten)]
    #[specta(type = specta_serde::Phased<TraceOnly, SpanMeta>)]
    extra: HashMap<String, i32>,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct PhasedFlattenCollidesOnlyWhenSkipped {
    trace_id: i32,
    #[serde(flatten, skip_serializing, default)]
    #[specta(type = specta_serde::Phased<TraceOnly, SpanMeta>)]
    extra: HashMap<String, i32>,
}

#[test]
fn phase_override_colliding_in_its_live_direction_is_rejected() {
    assert_duplicate_key::<PhasedFlattenCollides>(
        specta_serde::PhasesFormat,
        "trace_id",
        "the serialize side flattens `trace_id` next to the struct's own `trace_id`",
    );
}

#[test]
fn phase_override_colliding_only_in_a_skipped_direction_is_accepted() {
    Typescript::default()
        .export(
            &Types::default().register::<PhasedFlattenCollidesOnlyWhenSkipped>(),
            specta_serde::PhasesFormat,
        )
        .expect("the colliding side is never serialized; the live side writes `span_id`");
}

// Termination: a struct that flattens itself through another struct must not
// hang the key check. Only finishing is asserted.
#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct CycleA {
    a: i32,
    #[serde(flatten)]
    b: Box<CycleB>,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct CycleB {
    #[serde(flatten)]
    c: CycleA,
}

#[test]
fn flatten_cycle_key_check_terminates() {
    let _ = with_timeout(std::time::Duration::from_secs(10), || {
        Typescript::default().export(&Types::default().register::<CycleA>(), specta_serde::Format)
    });
}

// ---------------------------------------------------------------------------
// The split format. Shapes rejected above through `Format` are just as broken
// when each direction is exported on its own, so `PhasesFormat` must reject
// them with the same kind of message.
// ---------------------------------------------------------------------------

#[test]
fn split_format_rejects_non_flattenable_targets() {
    use specta_serde::PhasesFormat as P;
    assert_flatten_rejected::<FlattenSeq>(P, "extra", "a flattened sequence");
    assert_flatten_rejected::<FlattenTuple>(P, "pair", "a flattened tuple");
    assert_flatten_rejected::<FlattenScalar>(P, "count", "a flattened scalar");
    assert_flatten_rejected::<FlattenTupleStruct>(P, "coords", "a flattened tuple struct");
    assert_flatten_rejected::<FlattenEmptyTupleStruct>(P, "marker", "a flattened empty tuple struct");
    assert_flatten_rejected::<VariantFlattenSeq>(P, "extra", "a flattened sequence in a variant");
    assert_flatten_rejected::<FlattenNewtypeScalar>(P, "extra", "a newtype around a scalar");
    assert_flatten_rejected::<FlattenGenericSeq>(P, "extra", "a generic newtype over a sequence");
    assert_flatten_rejected::<TwoSubstitutionsGoodFirst>(P, "body", "the sequence instantiation");
    assert_flatten_rejected::<HolderOfSeq>(P, "body", "a sequence argument from one level up");
    assert_flatten_rejected::<FlattenTransparentSeq>(P, "extra", "transparent wrappers around a sequence");
}

fn assert_codec_rejected<T: Type>(context: &str) {
    let err = Typescript::default()
        .export(&Types::default().register::<T>(), specta_serde::PhasesFormat)
        .expect_err(context);
    assert!(
        err.to_string().contains("Unsupported serde attribute"),
        "unexpected error: {err}"
    );
}

#[test]
fn split_format_rejects_codecs_on_unnamed_fields_without_override() {
    assert_codec_rejected::<NewtypeCodecNoOverride>("`with` on a newtype field");
    assert_codec_rejected::<NewtypeSerializeWithNoOverride>("`serialize_with` on a newtype field");
    assert_codec_rejected::<TupleDeserializeWithNoOverride>("`deserialize_with` on a tuple struct field");
    assert_codec_rejected::<NewtypeCodecAfterSkipped>("`with` after a skipped field");
}

// A second nested pair with different names, so the reported names have to
// come from the types themselves.
#[derive(Type, Serialize)]
#[specta(collect = false)]
#[serde(untagged)]
enum CountPayload {
    Count(i64),
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
#[serde(tag = "kind")]
enum TickEvent {
    Tick(CountPayload),
}

#[test]
fn split_format_nested_untagged_error_names_the_inner_type() {
    for (register, inner, variant) in [
        (
            Types::default().register::<TaggedOuter>(),
            "PrimPayload",
            "variant 'P'",
        ),
        (
            Types::default().register::<TickEvent>(),
            "CountPayload",
            "variant 'Count'",
        ),
    ] {
        let err = Typescript::default()
            .export(&register, specta_serde::PhasesFormat)
            .expect_err("an untagged scalar payload cannot be merged with an internal tag");
        let msg = err.to_string();
        assert!(msg.contains(inner), "error should name the inner type {inner}: {msg}");
        assert!(msg.contains(variant), "error should name the inner {variant}: {msg}");
    }
}

#[test]
fn split_format_rejects_duplicate_keys() {
    use specta_serde::PhasesFormat as P;
    assert_duplicate_key::<FlattenRepeatsSiblingKey>(P, "trace_id", "flatten repeats a sibling key");
    assert_duplicate_key::<TwoFlattensShareKey>(P, "trace_id", "two flattens share a key");
    assert_duplicate_key::<DeepFlattenRepeatsKey>(P, "label", "a key repeated through nested flattens");
    assert_duplicate_key::<RenamedCollision>(P, "traceId", "keys that meet after renames");
    assert_duplicate_key::<UsesCollidingExtra>(P, "trace_id", "a generic flatten that collides");
    assert_duplicate_key::<TagCollidesWithPayload>(P, "kind", "an internal tag repeated by its payload");
    assert_duplicate_key::<TagCollidesThroughPayloadFlatten>(P, "kind", "a tag repeated through wrappers");
    assert_duplicate_key::<OuterSameTag>(P, "kind", "nested enums with the same tag");
    assert_duplicate_key::<StructTagCollides>(P, "kind", "a struct tag repeated by a flatten");
    assert_duplicate_key::<FlattenExternalVariantCollides>(P, "trace_id", "an external variant key");
    assert_duplicate_key::<FlattenInternalVariantCollides>(P, "trace_id", "an internal variant field");
    assert_duplicate_key::<FlattenInternalTagCollides>(P, "op", "a flattened enum's tag");
    assert_duplicate_key::<FlattenConversionCollides>(P, "trace_id", "a conversion wire key");
}
