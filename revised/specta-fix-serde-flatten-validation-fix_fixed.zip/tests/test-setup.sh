#!/usr/bin/env bash
# Test-setup for specta-fix-serde-flatten-validation.
#
# The image bakes the full dependency closure at the base commit (block 8:
# `cargo fetch --locked && cargo build --locked --tests`), so the offline
# build can compile and run the focused tests with no network.
# This script only re-warms the cargo cache for the crate the verifier is
# hosted in (`specta-typescript`, whose dev-deps already pull specta +
# specta-serde + serde) and prints a diagnostic banner. No services, no seed.
#
# It runs with network available (verifier phase), so the `cargo fetch` here is
# a belt-and-suspenders no-op on the warm cache; the offline build never
# depends on it.

set -euo pipefail

cd /repo/specta

echo "[test-setup] Rust version:   $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:  $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Workspace root: /repo/specta"

# Re-fetch + compile the host crate's test target so a cold verifier run is
# fast. Offline-first (cache is baked); the online path is only a fallback.
if ! cargo build --locked --offline -p specta-typescript --tests >/tmp/test-setup-build.log 2>&1; then
    echo "[test-setup] offline build failed; retrying online" >&2
    cargo fetch --locked >/tmp/test-setup-fetch.log 2>&1 || { tail -80 /tmp/test-setup-fetch.log; exit 1; }
    cargo build --locked -p specta-typescript --tests >/tmp/test-setup-build.log 2>&1 \
        || { tail -80 /tmp/test-setup-build.log; exit 1; }
fi

echo "[test-setup] Setup complete."
