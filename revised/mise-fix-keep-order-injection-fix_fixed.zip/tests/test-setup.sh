#!/usr/bin/env bash
# Test-setup for mise-fix-keep-order-injection.
#
# The behavioral verifier drives the compiled `mise` CLI (`mise run --output
# keep-order ...`). The image already pre-fetches the full workspace dependency
# closure (`cargo fetch --locked`) and pre-builds the mise binary
# (`cargo build --locked --bin mise`), so the verifier's rebuild from the
# patched source is incremental and fully offline. There are no services to
# start and no data to seed here.

set -euo pipefail

echo "[test-setup] Rust version:    $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:   $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Workspace root:  /repo/mise"
echo "[test-setup] Cargo target:    ${CARGO_TARGET_DIR:-<default>}"
echo "[test-setup] Setup complete."
