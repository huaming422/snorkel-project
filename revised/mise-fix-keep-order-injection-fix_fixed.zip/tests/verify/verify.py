"""Behavioral verifier for mise-fix-keep-order-injection.

`mise run --output keep-order` prints each task's output as one contiguous
block, and the order of those blocks must not depend on which task happens to
finish first. These checks drive the compiled `mise` command-line tool on small
task configs and read only its output:

  * tasks started from another task's `run` list, together with what they
    bring along through `depends` / `depends_post`, come out in the same block
    order as running those tasks directly by name;
  * that order is the same on every run of the same config;
  * when tasks that print their own output start other tasks (one level deep or
    nested), the order never changes between runs, and the started tasks come
    out in the order they are written and in the order of the tasks that
    started them;
  * the by-name order still holds when one of the dependencies already ran
    earlier in the same `mise run`;
  * output keeps streaming while tasks run, including when a task in a `run`
    list only depends on other tasks;
  * each task prints one block, a dependency shared by two started tasks runs
    once, and tasks named on the command line keep the order they were named in.

Beyond the order the started tasks keep among themselves, where exactly their
blocks sit next to the parent's own block is left open, so nothing here pins
one full literal order for the printing-parent cases.

The tool is a Rust binary. This verifier builds it once from the source tree
and then only observes its command-line output, so it runs under the shared
verifier interpreter with no repository-Python dependency.
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
import tempfile
import threading
import time
from pathlib import Path

import pytest

# Where the repository is checked out in the task image.
REPO_DIR = Path(f"/repo/{os.environ.get('REPO_NAME', 'mise')}")

# Parallel jobs. With a single job the tasks run one at a time, which hides
# ordering differences.
JOBS = "4"

# Per-invocation wall-clock ceiling. Every config here finishes in a few
# seconds; this keeps a hung run from reaching the runner-level timeout.
RUN_TIMEOUT = 60

# A block line looks like `[task-name] some output`. Capture the task name.
_BLOCK_RE = re.compile(r"^\[([A-Za-z0-9_.:-]+)\]")

# How many times a stability check runs the same config. Ordering that depends
# on timing does not differ on every run, so a single comparison is not enough.
DETERMINISM_RUNS = 20

# In the streaming configs one dependency prints a line and then sleeps for
# STREAM_SLEEP seconds before it finishes. Output that streams shows that first
# line long before the run ends; output held back to the end shows it at the end.
STREAM_SLEEP = 3
STREAM_MIN_LEAD = 1.5


# --------------------------------------------------------------------------- #
# Building and running the tool
# --------------------------------------------------------------------------- #


@pytest.fixture(scope="module")
def mise_bin() -> str:
    """Build the `mise` binary once from the source tree and return its path.
    The image pre-fetches the dependency closure and pre-builds the binary, so
    this rebuild is incremental and fully offline."""
    env = {**os.environ, "CARGO_NET_OFFLINE": "true"}
    proc = subprocess.run(
        ["cargo", "build", "--bin", "mise"],
        cwd=str(REPO_DIR),
        env=env,
        capture_output=True,
        text=True,
        timeout=1500,
        check=False,
    )
    assert proc.returncode == 0, (
        "failed to build the mise binary from source:\n"
        f"{proc.stdout[-4000:]}\n{proc.stderr[-4000:]}"
    )

    candidates = []
    target_dir = os.environ.get("CARGO_TARGET_DIR")
    if target_dir:
        candidates.append(Path(target_dir) / "debug" / "mise")
    candidates.append(REPO_DIR / "target" / "debug" / "mise")

    for cand in candidates:
        if cand.is_file() and os.access(cand, os.X_OK):
            return str(cand)

    # Fallback: locate it under the cache tree.
    found = subprocess.run(
        ["find", "/opt/cache", "-name", "mise", "-type", "f", "-executable"],
        capture_output=True,
        text=True,
        check=False,
    )
    for line in found.stdout.splitlines():
        line = line.strip()
        if line.endswith("/debug/mise"):
            return line

    raise AssertionError(
        "built the project but could not locate the resulting `mise` binary; "
        f"looked at: {', '.join(str(c) for c in candidates)}"
    )


def _env(workdir: Path) -> dict[str, str]:
    """An isolated, trusted environment for running `mise` in `workdir`."""
    home = workdir / "home"
    for sub in (
        home,
        home / ".local/share/mise",
        home / ".cache/mise",
        home / ".config/mise",
        home / ".local/state/mise",
    ):
        sub.mkdir(parents=True, exist_ok=True)

    env = {
        "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
        "HOME": str(home),
        "MISE_DATA_DIR": str(home / ".local/share/mise"),
        "MISE_CACHE_DIR": str(home / ".cache/mise"),
        "MISE_CONFIG_DIR": str(home / ".config/mise"),
        "MISE_STATE_DIR": str(home / ".local/state/mise"),
        "MISE_TRUSTED_CONFIG_PATHS": str(workdir),
        "MISE_YES": "1",
        "MISE_EXPERIMENTAL": "1",
        "MISE_JOBS": JOBS,
        "MISE_USE_VERSIONS_HOST": "0",
    }
    if "CARGO_HOME" in os.environ:
        env["CARGO_HOME"] = os.environ["CARGO_HOME"]
    if "RUSTUP_HOME" in os.environ:
        env["RUSTUP_HOME"] = os.environ["RUSTUP_HOME"]
    return env


def _run(mise_bin: str, workdir: Path, *args: str) -> subprocess.CompletedProcess:
    """Run `mise <args>` in `workdir` and capture stdout and stderr (keep-order
    writes task output to stderr)."""
    return subprocess.run(
        [mise_bin, *args],
        cwd=str(workdir),
        env=_env(workdir),
        capture_output=True,
        text=True,
        timeout=RUN_TIMEOUT,
        check=False,
    )


def _keep_order(mise_bin: str, workdir: Path, *run_args: str) -> subprocess.CompletedProcess:
    """`mise run --quiet --output keep-order <run_args>` with captured output."""
    return _run(mise_bin, workdir, "run", "--quiet", "--output", "keep-order", *run_args)


def _keep_order_timed(
    mise_bin: str, workdir: Path, *run_args: str
) -> tuple[int, list[tuple[float, str]], float]:
    """Run keep-order with stdout and stderr merged into one pipe and note when
    each line arrives. Returns the exit code, the `(arrival time, line)` pairs
    and the time the output stream closed."""
    proc = subprocess.Popen(
        [mise_bin, "run", "--quiet", "--output", "keep-order", *run_args],
        cwd=str(workdir),
        env=_env(workdir),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
    )
    timed_out = threading.Event()

    def _kill() -> None:
        timed_out.set()
        proc.kill()

    watchdog = threading.Timer(RUN_TIMEOUT, _kill)
    watchdog.start()
    lines: list[tuple[float, str]] = []
    try:
        assert proc.stdout is not None
        while True:
            line = proc.stdout.readline()
            if not line:
                break
            lines.append((time.monotonic(), line.rstrip("\n")))
        closed_at = time.monotonic()
        returncode = proc.wait()
    finally:
        watchdog.cancel()
    if timed_out.is_set():
        pytest.fail(f"`mise run {' '.join(run_args)}` did not finish within {RUN_TIMEOUT}s")
    return returncode, lines, closed_at


def _block_order(output: str) -> list[str]:
    """The order task-output blocks appear in, as the sequence of distinct
    `[name]` prefixes with consecutive repeats collapsed. Each task's lines are
    contiguous under keep-order, so this is the block order."""
    order: list[str] = []
    for line in output.splitlines():
        m = _BLOCK_RE.match(line)
        if not m:
            continue
        name = m.group(1)
        if not order or order[-1] != name:
            order.append(name)
    return order


def _write_config(workdir: Path, toml: str) -> None:
    (workdir / "mise.toml").write_text(toml, encoding="utf-8")


def _fresh_workdir() -> Path:
    return Path(tempfile.mkdtemp(prefix="mise-keep-order-"))


def _assert_one_block_each(order: list[str], what: str) -> None:
    repeated = sorted({name for name in order if order.count(name) > 1})
    assert not repeated, (
        f"{what}: these tasks printed more than one block: {repeated}\n"
        f"  block order: {order}"
    )


def _stable_orders(mise_bin: str, workdir: Path, runs: int, *run_args: str) -> list[list[str]]:
    """Run the same keep-order command `runs` times, check each run succeeds
    and prints each task as one block, and return the block order of every run."""
    orders: list[list[str]] = []
    for i in range(runs):
        res = _keep_order(mise_bin, workdir, *run_args)
        assert res.returncode == 0, (
            f"run {i + 1} failed (exit {res.returncode}):\n{res.stdout}\n{res.stderr}"
        )
        order = _block_order(res.stdout + res.stderr)
        assert order, f"run {i + 1} produced no task blocks:\n{res.stdout}\n{res.stderr}"
        _assert_one_block_each(order, f"run {i + 1} of `mise run {' '.join(run_args)}`")
        orders.append(order)
    return orders


def _assert_same_every_run(orders: list[list[str]], what: str) -> None:
    first = orders[0]
    for i, order in enumerate(orders[1:], start=2):
        assert order == first, (
            f"{what}: run {i} came out in a different block order from run 1:\n"
            f"  run 1: {first}\n"
            f"  run {i}: {order}"
        )


def _assert_started_order(order: list[str], expected: list[str], what: str) -> None:
    started = [name for name in order if name in expected]
    assert started == expected, (
        f"{what}: the started tasks did not come out in the order they are "
        "written in and the order of the tasks that started them:\n"
        f"  expected: {expected}\n"
        f"  got:      {started}\n"
        f"  full block order: {order}"
    )


# --------------------------------------------------------------------------- #
# Config fixtures (test data authored here; not derived from any solution)
# --------------------------------------------------------------------------- #

# A task whose only job is to start three tasks, each with its own `depends`.
# The dependency sleeps run against declaration order, so blocks placed by
# finish time come out wrong on every run rather than only sometimes.
CONFIG_DEPENDS = """\
[tasks.launch]
run = { tasks = ["r1", "r2", "r3"] }

[tasks.r1]
depends = ["dep1"]
run = 'echo R1'

[tasks.r2]
depends = ["dep2"]
run = 'echo R2'

[tasks.r3]
depends = ["dep3"]
run = 'echo R3'

[tasks.dep1]
run = 'echo DEP1'

[tasks.dep2]
run = 'sleep 0.5; echo DEP2'

[tasks.dep3]
run = 'sleep 1; echo DEP3'
"""

# The same shape with no sleeps: the dependencies finish in whatever order the
# scheduler starts them.
CONFIG_DEPENDS_SLEEPLESS = """\
[tasks.launch]
run = { tasks = ["r1", "r2", "r3"] }

[tasks.r1]
depends = ["dep1"]
run = 'echo R1'

[tasks.r2]
depends = ["dep2"]
run = 'echo R2'

[tasks.r3]
depends = ["dep3"]
run = 'echo R3'

[tasks.dep1]
run = 'echo DEP1'

[tasks.dep2]
run = 'echo DEP2'

[tasks.dep3]
run = 'echo DEP3'
"""

# `depends_post` tasks reached through a started task. One post task sleeps,
# so its finish time differs from its declared position.
CONFIG_DEPENDS_POST = """\
[tasks.launch]
run = { tasks = ["p1", "p2"] }

[tasks.p1]
depends_post = ["post1"]
run = 'echo P1'

[tasks.p2]
depends_post = ["post2"]
run = 'echo P2'

[tasks.post1]
run = 'echo POST1'

[tasks.post2]
run = 'sleep 0.5; echo POST2'
"""

# Three tasks that each print their own output and start other tasks, run by
# name as `web ::: api ::: docs`. `web` starts two tasks from two separate run
# entries. No sleeps. Names are chosen so that neither the parents nor the
# started tasks are in alphabetical order.
CONFIG_PRINTING_PARENTS = """\
[tasks.web]
run = ["echo WEB-START", { tasks = ["web-assets"] }, { tasks = ["web-icons"] }, "echo WEB-END"]

[tasks.api]
run = ["echo API-START", { tasks = ["api-schema"] }, "echo API-END"]

[tasks.docs]
run = ["echo DOCS-START", { tasks = ["docs-site"] }, "echo DOCS-END"]

[tasks.web-assets]
run = 'echo WEB-ASSETS'

[tasks.web-icons]
run = 'echo WEB-ICONS'

[tasks.api-schema]
run = 'echo API-SCHEMA'

[tasks.docs-site]
run = 'echo DOCS-SITE'
"""
PRINTING_PARENTS_NAMED = ("web", "api", "docs")
PRINTING_PARENTS_STARTED = ["web-assets", "web-icons", "api-schema", "docs-site"]

# Nested: each printing task starts a task that itself prints and starts one
# more. Run by name as `server ::: mobile ::: admin`.
CONFIG_NESTED_INJECTION = """\
[tasks.server]
run = ["echo SERVER-START", { tasks = ["server-build"] }, "echo SERVER-END"]

[tasks.mobile]
run = ["echo MOBILE-START", { tasks = ["mobile-build"] }, "echo MOBILE-END"]

[tasks.admin]
run = ["echo ADMIN-START", { tasks = ["admin-build"] }, "echo ADMIN-END"]

[tasks.server-build]
run = ["echo SERVER-BUILD-START", { tasks = ["server-assets"] }, "echo SERVER-BUILD-END"]

[tasks.mobile-build]
run = ["echo MOBILE-BUILD-START", { tasks = ["mobile-assets"] }, "echo MOBILE-BUILD-END"]

[tasks.admin-build]
run = ["echo ADMIN-BUILD-START", { tasks = ["admin-assets"] }, "echo ADMIN-BUILD-END"]

[tasks.server-assets]
run = 'echo SERVER-ASSETS'

[tasks.mobile-assets]
run = 'echo MOBILE-ASSETS'

[tasks.admin-assets]
run = 'echo ADMIN-ASSETS'
"""
NESTED_NAMED = ("server", "mobile", "admin")
NESTED_STARTED = ["server-build", "mobile-build", "admin-build"]
NESTED_STARTED_DEEPER = ["server-assets", "mobile-assets", "admin-assets"]

# `launch` first runs `bootstrap` on its own, then starts three tasks. `package`
# depends on `bootstrap`, which has already run by then and is not run again.
# The other dependencies sleep against declaration order. The by-name form
# `check ::: test ::: package` runs `bootstrap` as an ordinary dependency.
CONFIG_ALREADY_RAN = """\
[tasks.launch]
run = [{ tasks = ["bootstrap"] }, { tasks = ["check", "test", "package"] }]

[tasks.bootstrap]
run = 'echo BOOTSTRAP'

[tasks.check]
depends = ["lint"]
run = 'echo CHECK'

[tasks.test]
depends = ["fixtures"]
run = 'echo TEST'

[tasks.package]
depends = ["bootstrap", "compile"]
run = 'echo PACKAGE'

[tasks.lint]
run = 'echo LINT'

[tasks.fixtures]
run = 'sleep 0.5; echo FIXTURES'

[tasks.compile]
run = 'sleep 1; echo COMPILE'
"""

# A task that prints nothing and only depends on two others, run directly by
# name (`agg`) and from another task's run list (`launch`). `slow` prints a line
# right away and then works for STREAM_SLEEP seconds.
CONFIG_AGGREGATOR = f"""\
[tasks.launch]
run = {{ tasks = ["agg"] }}

[tasks.agg]
depends = ["slow", "quick"]

[tasks.slow]
run = 'echo SLOW-START; sleep {STREAM_SLEEP}; echo SLOW-END'

[tasks.quick]
run = 'echo QUICK'
"""

# Three tasks named directly, not in alphabetical order.
CONFIG_NAMED_ORDER = """\
[tasks.zebra]
run = 'echo ZEBRA'

[tasks.apple]
run = 'echo APPLE'

[tasks.mango]
run = 'echo MANGO'
"""

# Two started tasks that share a dependency.
CONFIG_SHARED_DEP = """\
[tasks.launch]
run = { tasks = ["a", "b"] }

[tasks.a]
depends = ["shared"]
run = 'echo A'

[tasks.b]
depends = ["shared"]
run = 'echo B'

[tasks.shared]
run = 'echo SHARED'
"""


# --------------------------------------------------------------------------- #
# Tests
# --------------------------------------------------------------------------- #


def _assert_matches_by_name(
    mise_bin: str,
    toml: str,
    started_via: str,
    named: tuple[str, ...],
    ignore: tuple[str, ...] = (),
) -> None:
    workdir = _fresh_workdir()
    try:
        _write_config(workdir, toml)

        injected = _keep_order(mise_bin, workdir, started_via)
        assert injected.returncode == 0, (
            f"`mise run {started_via}` failed (exit {injected.returncode}):\n"
            f"{injected.stdout}\n{injected.stderr}"
        )
        by_name_args: list[str] = []
        for name in named:
            if by_name_args:
                by_name_args.append(":::")
            by_name_args.append(name)
        toplevel = _keep_order(mise_bin, workdir, *by_name_args)
        assert toplevel.returncode == 0, (
            f"by-name run failed (exit {toplevel.returncode}):\n"
            f"{toplevel.stdout}\n{toplevel.stderr}"
        )

        injected_order = [
            n for n in _block_order(injected.stdout + injected.stderr) if n not in ignore
        ]
        toplevel_order = [
            n for n in _block_order(toplevel.stdout + toplevel.stderr) if n not in ignore
        ]

        assert injected_order, f"no task blocks seen for `mise run {started_via}`:\n{injected.stdout}\n{injected.stderr}"
        assert toplevel_order, f"no task blocks seen for the by-name form:\n{toplevel.stdout}\n{toplevel.stderr}"
        _assert_one_block_each(injected_order, f"`mise run {started_via}`")
        _assert_one_block_each(toplevel_order, "the by-name form")
        assert injected_order == toplevel_order, (
            f"`mise run {started_via}` ordered its blocks differently from running "
            "the same tasks by name:\n"
            f"  started from a run list: {injected_order}\n"
            f"  named directly:          {toplevel_order}"
        )
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


def test_injected_depends_match_toplevel_form(mise_bin: str) -> None:
    """Tasks started from a run list, with their own `depends`, come out in the
    same block order as running those tasks directly by name."""
    _assert_matches_by_name(mise_bin, CONFIG_DEPENDS, "launch", ("r1", "r2", "r3"))


def test_injected_depends_order_is_deterministic(mise_bin: str) -> None:
    """Repeated runs of the same config give the same block order."""
    workdir = _fresh_workdir()
    try:
        _write_config(workdir, CONFIG_DEPENDS_SLEEPLESS)
        orders = _stable_orders(mise_bin, workdir, 6, "launch")
        _assert_same_every_run(orders, "tasks started with their own `depends`")
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


def test_depends_post_matches_toplevel_form(mise_bin: str) -> None:
    """`depends_post` tasks reached through a started task come out in the same
    block order as the by-name form."""
    _assert_matches_by_name(mise_bin, CONFIG_DEPENDS_POST, "launch", ("p1", "p2"))


def test_printing_parents_order_is_stable(mise_bin: str) -> None:
    """Tasks that print their own output and start other tasks give the same
    block order on every run, and the started tasks come out in the order they
    are written and in the order their parents were named."""
    workdir = _fresh_workdir()
    try:
        _write_config(workdir, CONFIG_PRINTING_PARENTS)
        args = [PRINTING_PARENTS_NAMED[0]]
        for name in PRINTING_PARENTS_NAMED[1:]:
            args += [":::", name]
        orders = _stable_orders(mise_bin, workdir, DETERMINISM_RUNS, *args)
        _assert_same_every_run(orders, "printing tasks that start other tasks")
        _assert_started_order(orders[0], PRINTING_PARENTS_STARTED, "printing tasks")
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


def test_nested_injection_order_is_stable(mise_bin: str) -> None:
    """A started task that itself prints and starts one more (two levels deep)
    gives the same block order on every run, and each level of started tasks
    comes out in the order of the tasks that started it."""
    workdir = _fresh_workdir()
    try:
        _write_config(workdir, CONFIG_NESTED_INJECTION)
        args = [NESTED_NAMED[0]]
        for name in NESTED_NAMED[1:]:
            args += [":::", name]
        orders = _stable_orders(mise_bin, workdir, DETERMINISM_RUNS, *args)
        _assert_same_every_run(orders, "nested started tasks")
        _assert_started_order(orders[0], NESTED_STARTED, "first level of started tasks")
        _assert_started_order(orders[0], NESTED_STARTED_DEEPER, "second level of started tasks")
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


def test_already_ran_dependency_keeps_by_name_order(mise_bin: str) -> None:
    """When a dependency of the started tasks already ran earlier in the same
    `mise run`, the other blocks still come out in the by-name order. The
    dependency's own block sits where it first ran, so it is left out of the
    comparison."""
    _assert_matches_by_name(
        mise_bin,
        CONFIG_ALREADY_RAN,
        "launch",
        ("check", "test", "package"),
        ignore=("bootstrap",),
    )
    workdir = _fresh_workdir()
    try:
        _write_config(workdir, CONFIG_ALREADY_RAN)
        orders = _stable_orders(mise_bin, workdir, 2, "launch")
        for i, order in enumerate(orders, start=1):
            assert order.count("bootstrap") == 1, (
                f"run {i}: the dependency that already ran should print exactly "
                f"one block, but the block order was: {order}"
            )
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


def _assert_streams(mise_bin: str, target: str) -> None:
    workdir = _fresh_workdir()
    try:
        _write_config(workdir, CONFIG_AGGREGATOR)
        returncode, lines, closed_at = _keep_order_timed(mise_bin, workdir, target)
        text = "\n".join(line for _, line in lines)
        assert returncode == 0, f"`mise run {target}` failed (exit {returncode}):\n{text}"
        order = _block_order(text)
        for dep in ("slow", "quick"):
            assert dep in order, f"[{dep}] block is missing from `mise run {target}`:\n{text}"
        first_at = next(t for t, line in lines if _BLOCK_RE.match(line))
        lead = closed_at - first_at
        assert lead >= STREAM_MIN_LEAD, (
            f"`mise run {target}`: the first task line appeared only {lead:.2f}s "
            f"before the run ended, although `slow` prints right away and then "
            f"works for {STREAM_SLEEP}s; the output was held back instead of "
            f"streaming:\n{text}"
        )
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


def test_aggregator_parent_streams_when_named(mise_bin: str) -> None:
    """A task that only depends on others, run by name, lets its dependencies'
    output stream while they run."""
    _assert_streams(mise_bin, "agg")


def test_aggregator_started_from_run_list_streams(mise_bin: str) -> None:
    """The same task started from another task's run list also lets its
    dependencies' output stream while they run."""
    _assert_streams(mise_bin, "launch")


def test_shared_dependency_runs_once(mise_bin: str) -> None:
    """A dependency shared by two started tasks prints one block, every task's
    block appears, and the order is the same on two runs."""
    workdir = _fresh_workdir()
    try:
        _write_config(workdir, CONFIG_SHARED_DEP)
        orders = _stable_orders(mise_bin, workdir, 2, "launch")
        for i, order in enumerate(orders, start=1):
            assert order.count("shared") == 1, (
                f"run {i}: the shared dependency should print exactly one block, "
                f"but the block order was: {order}"
            )
            for name in ("a", "b", "shared"):
                assert name in order, f"[{name}] missing from run {i}: {order}"
        _assert_same_every_run(orders, "tasks sharing a dependency")
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


def test_named_tasks_keep_command_line_order(mise_bin: str) -> None:
    """Tasks named directly on the command line come out in the order they
    were named."""
    workdir = _fresh_workdir()
    try:
        _write_config(workdir, CONFIG_NAMED_ORDER)

        res = _keep_order(mise_bin, workdir, "zebra", ":::", "apple", ":::", "mango")
        assert res.returncode == 0, (
            f"by-name run failed (exit {res.returncode}):\n{res.stdout}\n{res.stderr}"
        )
        order = _block_order(res.stdout + res.stderr)
        assert order == ["zebra", "apple", "mango"], (
            "tasks named on the command line did not keep the order they were named in:\n"
            f"  named:    ['zebra', 'apple', 'mango']\n"
            f"  produced: {order}"
        )
    finally:
        shutil.rmtree(workdir, ignore_errors=True)
