## Task

We run a lot of things with `mise run --output keep-order`.
It's supposed to print each task's output as one block and keep the blocks in an order that has nothing to do with which task finishes first.
When we name the tasks ourselves on the command line, it does.
When a task starts other tasks from its `run` list, plus whatever those pull in through `depends` or `depends_post`, it doesn't.
Running the same config twice on the same machine can give two different block orders, and often neither one matches what we get by naming those tasks directly.
It gets worse as we allow more parallel jobs.

A task that just starts a few others should give us its started tasks and their dependencies in the order we'd get by naming those started tasks directly, on every run.
And wherever one task starts others, the started tasks should come out in a fixed order: the order of the run entries that start them, and the order of the tasks that started them.

Output also gets held back on this path.
If a task in a `run` list only depends on other tasks and has nothing of its own to run, none of its dependencies' output appears until the whole run is over.
Run by name, the same task streams that output as it goes, and it should do the same here.

Everything else about keep-order should stay as it is.
Each task still prints one block, a dependency shared by several tasks still runs once, and tasks named on the command line keep the order we named them in.
Can you work out what's causing this and fix it?

## General instructions

- The code repo is at /repo/mise.
- You are inside of a Docker container with no network access. You may not be able to perform all operations you would normally be able to do on a local machine. The project's dependencies and toolchain are already installed and the package manager caches are populated, so build and test with what is in the image; anything that needs to be downloaded will fail rather than hang.
- You are expected to act autonomously as a software engineer to complete tasks you are given.
- Do not stop until you feel you have completed the task and your code changes can be merged.
- You may need to use software engineering skills like analyzing the codebase, researching technologies, running services, analyzing logs, etc. to complete the task. Not all tasks will be solvable by reading source code alone.
