## Task

We run a lot of things with `mise run --output keep-order`, because it's meant to print each task's output as one block and keep those blocks in an order that doesn't depend on which task finishes first.
That works when we name the tasks ourselves on the command line.
It stops working once a task starts other tasks from its `run` list, for example a task that exists only to launch a few others, plus whatever those bring along through `depends` or `depends_post`.
If we run the same config twice on the same machine, the blocks can come out in a different order each time, and often not in the order we get by running the same tasks directly by name.
Raising the number of parallel jobs makes it happen more often.

Launcher tasks aren't the only case.
A task that prints its own lines and then starts another task shuffles the same way, and so does a started task that goes on to start one more.
There, the started tasks should keep a fixed order, the order their run entries list them in and the order of the tasks that started them.
The order should also hold when one of the dependencies already ran earlier in the same `mise run`.

We also see output held back on this path.
When a task in a `run` list only depends on other tasks and prints nothing itself, none of its dependencies' output shows up until the whole run is over.
It should stream while they run, the way it does when we run that task by name.

The rest of keep-order should behave as it does now.
Each task still prints one block, a dependency shared by several tasks still runs once, and tasks named on the command line keep the order we named them in.
Can you find out why this happens and fix it?

## General instructions

- The code repo is at /repo/mise.
- You are inside of a Docker container with no network access. You may not be able to perform all operations you would normally be able to do on a local machine. The project's dependencies and toolchain are already installed and the package manager caches are populated, so build and test with what is in the image; anything that needs to be downloaded will fail rather than hang.
- You are expected to act autonomously as a software engineer to complete tasks you are given.
- Do not stop until you feel you have completed the task and your code changes can be merged.
- You may need to use software engineering skills like analyzing the codebase, researching technologies, running services, analyzing logs, etc. to complete the task. Not all tasks will be solvable by reading source code alone.
