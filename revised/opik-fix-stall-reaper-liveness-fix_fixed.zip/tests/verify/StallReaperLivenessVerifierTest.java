package com.comet.opik.domain;

import com.comet.opik.api.ErrorInfo;
import com.comet.opik.api.ExperimentItem;
import com.comet.opik.api.ExperimentScore;
import com.comet.opik.api.ExperimentType;
import com.comet.opik.api.ExperimentUpdate;
import com.comet.opik.api.FeedbackScoreAverage;
import com.comet.opik.api.Optimization;
import com.comet.opik.api.OptimizationStatus;
import com.comet.opik.api.OptimizationStudioConfig;
import com.comet.opik.api.OptimizationUpdate;
import com.comet.opik.api.Trace;
import com.comet.opik.api.resources.utils.ClientSupportUtils;
import com.comet.opik.api.resources.utils.TestUtils;
import com.comet.opik.api.resources.utils.WireMockUtils;
import com.comet.opik.api.resources.utils.resources.ExperimentResourceClient;
import com.comet.opik.api.resources.utils.resources.OptimizationResourceClient;
import com.comet.opik.api.resources.utils.resources.TraceResourceClient;
import com.comet.opik.extensions.DropwizardAppExtensionProvider;
import com.comet.opik.extensions.RegisterApp;
import com.comet.opik.podam.PodamFactoryUtils;
import com.comet.opik.utils.ClickHouseDateTimeFormat;
import com.comet.opik.utils.JsonUtils;
import com.google.inject.Injector;
import org.apache.commons.lang3.RandomStringUtils;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.redisson.api.RedissonReactiveClient;
import ru.vyarus.dropwizard.guice.test.ClientSupport;
import ru.vyarus.dropwizard.guice.test.jupiter.ext.TestDropwizardAppExtension;
import uk.co.jemos.podam.api.PodamFactory;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;

import static com.comet.opik.api.resources.utils.AuthTestUtils.mockTargetWorkspace;
import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;

/**
 * Behavioral checks for opik-fix-stall-reaper-liveness.
 *
 * <p>The reported symptoms are: optimization "studio" runs that spin forever (a
 * healthy, still-progressing run gets marked failed, or a genuinely dead one is
 * never marked failed), and runs that vanish, where a run that exists returns
 * not-found from the API. This class drives both through the backend's public
 * surface and asserts what the API returns.
 *
 * <p>Everything is driven through existing interfaces:
 * <ul>
 *   <li>the optimization / experiment / trace HTTP resource clients
 *       (create / upsert / get / find / update);</li>
 *   <li>the reconcile method on the Guice-injected {@code OptimizationService},
 *       the same method the scheduled job calls, invoked directly so each case
 *       is deterministic instead of waiting on wall-clock;</li>
 *   <li>the worker's cancellation channel in Redis, read through the injected
 *       {@code RedissonReactiveClient}.</li>
 * </ul>
 *
 * <p>The only raw-ClickHouse writes are timestamps the HTTP API stamps
 * server-side (a backdated run start, an old trial row) and a raw
 * {@code experiment_scores} JSON string the typed API cannot express, the state
 * older or foreign writers can leave in the column. Assertions read only the
 * API's answers and the worker's cancellation key.
 *
 * <p>The reconcile method takes two synthetic timeouts per case:
 * {@link #IMMEDIATE a zero timeout} makes any run of that status eligible, and
 * {@link #NEVER a 7-day timeout} makes nothing eligible, so a case targets
 * exactly the transition it names without sleeping.
 */
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@ExtendWith(DropwizardAppExtensionProvider.class)
class StallReaperLivenessVerifierTest {

    private static final Duration IMMEDIATE = Duration.ZERO;
    private static final Duration NEVER = Duration.ofDays(7);
    private static final Duration LOOKBACK_MARGIN = Duration.ofDays(7);
    private static final int BATCH_SIZE = 100;

    private static final String API_KEY = UUID.randomUUID().toString();
    private static final String WORKSPACE_ID = UUID.randomUUID().toString();
    private static final String TEST_WORKSPACE_NAME = "workspace" + RandomStringUtils.secure().nextAlphanumeric(36);
    private static final String USER = "user-" + RandomStringUtils.secure().nextAlphanumeric(36);

    private static final String ANALYTICS_DB = "opik";

    private final WireMockUtils.WireMockRuntime wireMock;

    @RegisterApp
    private final TestDropwizardAppExtension APP;

    {
        wireMock = WireMockUtils.startWireMock();
        NativeServiceAppExtensionShim.runMigrations();
        APP = NativeServiceAppExtensionShim.newAppExtension(wireMock.runtimeInfo());
    }

    private final PodamFactory podamFactory = PodamFactoryUtils.newPodamFactory();

    private OptimizationResourceClient optimizationResourceClient;
    private ExperimentResourceClient experimentResourceClient;
    private TraceResourceClient traceResourceClient;
    private OptimizationService optimizationService;
    private Injector injector;

    @BeforeAll
    void beforeAll(ClientSupport client, OptimizationService optimizationService, Injector injector) {
        var baseURI = TestUtils.getBaseUrl(client);
        ClientSupportUtils.config(client);

        this.optimizationResourceClient = new OptimizationResourceClient(client, baseURI, podamFactory);
        this.experimentResourceClient = new ExperimentResourceClient(client, baseURI, podamFactory);
        this.traceResourceClient = new TraceResourceClient(client, baseURI);
        this.optimizationService = optimizationService;
        this.injector = injector;

        mockTargetWorkspace(wireMock.server(), API_KEY, TEST_WORKSPACE_NAME, WORKSPACE_ID, USER);
    }

    // ================================================================
    // Symptom 1: progress-aware liveness (eternal spinner, both directions)
    // ================================================================

    @Test
    @DisplayName("crit_progress_liveness: a stale-row run with recent trial progress survives; without it, it is reaped")
    void progressAwareLiveness() {
        // Same stale row timestamp (1h old, far past the 5-minute timeout) in both runs. The only
        // difference is whether a trial experiment was created inside the window.
        var alive = seedBackdatedRunningStudioRun(Duration.ofHours(1));
        createTrialExperiment(alive);

        var dead = seedBackdatedRunningStudioRun(Duration.ofHours(1));

        reconcile(NEVER, Duration.ofMinutes(5), BATCH_SIZE);

        assertThat(statusOf(alive)).isEqualTo(OptimizationStatus.RUNNING);
        assertThat(statusOf(dead)).isEqualTo(OptimizationStatus.ERROR);
    }

    @Test
    @DisplayName("crit_progress_liveness: item-level progress within a long single trial keeps a run alive")
    void progressFromItemWithinLongTrial() {
        var id = seedBackdatedRunningStudioRun(Duration.ofHours(1));
        // The trial experiment row is itself old (backdated an hour), but items keep arriving as dataset
        // items are evaluated, the shape of one long trial. The new item is the only recent activity.
        var experimentId = createBackdatedTrialExperiment(id, Duration.ofHours(1));
        createExperimentItem(experimentId, true);

        reconcile(NEVER, Duration.ofMinutes(5), BATCH_SIZE);

        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.RUNNING);
    }

    @Test
    @DisplayName("crit_progress_liveness: progress counts per run, so a healthy run's trial does not save a stale one")
    void progressDoesNotLeakAcrossRuns() {
        var stale = seedBackdatedRunningStudioRun(Duration.ofHours(1));
        var healthy = seedBackdatedRunningStudioRun(Duration.ofHours(1));
        createTrialExperiment(healthy);

        reconcile(NEVER, Duration.ofMinutes(5), BATCH_SIZE);

        assertThat(statusOf(stale)).isEqualTo(OptimizationStatus.ERROR);
        assertThat(statusOf(healthy)).isEqualTo(OptimizationStatus.RUNNING);
    }

    @Test
    @DisplayName("crit_progress_liveness: a stale INITIALIZED run with trial progress is not killed (failed callback != dead)")
    void initializedRunWithProgressSurvives() {
        var id = seedBackdatedInitializedStudioRun(Duration.ofHours(1));
        createTrialExperiment(id);

        // An INITIALIZED run with trial rows means a mark_running callback was lost while the worker did
        // real work. It did start, so recent trial activity keeps it alive as it does a RUNNING run.
        reconcile(IMMEDIATE, NEVER, BATCH_SIZE);

        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.INITIALIZED);
    }

    @Test
    @DisplayName("crit_progress_liveness: a stale INITIALIZED run with no progress is still reaped")
    void initializedRunWithoutProgressIsReaped() {
        var id = seedBackdatedInitializedStudioRun(Duration.ofHours(1));

        reconcile(IMMEDIATE, IMMEDIATE, BATCH_SIZE);

        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.ERROR);
    }

    @Test
    @DisplayName("crit_progress_liveness: a dead run whose worker was killed mid-trial is still reaped")
    void deadRunKilledMidTrialIsReaped() {
        var id = seedStudioRun(OptimizationStatus.RUNNING);
        // The worker died partway through its only trial, leaving an item whose trace never finished.
        createTrialWithUnfinishedTraceItem(id);

        // A zero running timeout makes that item, and the row itself, older than the window.
        reconcile(NEVER, IMMEDIATE, BATCH_SIZE);

        var reaped = optimizationResourceClient.get(id, API_KEY, TEST_WORKSPACE_NAME, 200);
        assertThat(reaped.status()).isEqualTo(OptimizationStatus.ERROR);
        assertThat(reaped.errorInfo()).isNotNull();
        assertThat(reaped.errorInfo().message()).isNotBlank();
    }

    @Test
    @DisplayName("crit_liveness_clock_not_restamped: updating an old trial does not refresh liveness; run still reaped")
    void updatingOldTrialDoesNotRefreshLiveness() {
        // The run's own row reads as stale (backdated 1h), so it is past the 5m running timeout. Its
        // only trial is an hour old and is renamed just before the scan.
        var id = seedBackdatedRunningStudioRun(Duration.ofHours(1));
        var experimentId = createBackdatedTrialExperiment(id, Duration.ofHours(1));

        // Renaming an old trial is not new work, so it does not count as recent activity.
        experimentResourceClient.updateExperiment(experimentId,
                ExperimentUpdate.builder().name("renamed-after-the-window").build(),
                API_KEY, TEST_WORKSPACE_NAME, 204);

        reconcile(NEVER, Duration.ofMinutes(5), BATCH_SIZE);

        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.ERROR);
    }

    // ================================================================
    // Total-time limit, independent of progress
    // ================================================================

    @Test
    @DisplayName("crit_hard_ceiling: a RUNNING run past the ceiling is reaped despite fresh progress, citing the ceiling")
    void runningRunPastHardCeilingIsReaped() {
        var id = seedStudioRun(OptimizationStatus.RUNNING);
        createTrialExperiment(id);
        // Started 72 hours ago, but the row was written a moment ago, the state a metadata PATCH or a
        // re-upsert leaves. It has fresh trial activity and a fresh row timestamp. 72 hours is past a
        // one-day limit, the 1h limit passed below, and the 48h value verify.sh writes to the test config.
        backdateRunStart(id, Duration.ofHours(72));

        // initializedTimeout=NEVER and runningTimeout=5m with fresh activity present, so the run is past
        // the total-time limit only.
        reconcile(NEVER, Duration.ofMinutes(5), Duration.ofHours(1), BATCH_SIZE);

        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.ERROR);
    }

    @Test
    @DisplayName("crit_hard_ceiling: a progressing run that started less than a day ago keeps running")
    void runBelowHardCeilingWithProgressSurvives() {
        var id = seedStudioRun(OptimizationStatus.RUNNING);
        createTrialExperiment(id);
        // 20 hours is inside a one-day limit and inside the 48h value verify.sh writes to the test config.
        backdateRunStart(id, Duration.ofHours(20));

        reconcile(NEVER, Duration.ofMinutes(5), Duration.ofHours(24), BATCH_SIZE);

        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.RUNNING);
    }

    @Test
    @DisplayName("crit_hard_ceiling: an INITIALIZED run past the ceiling is reaped despite progress, not 'failed to start'")
    void initializedRunPastHardCeilingIsReaped() {
        var id = seedStudioRun(OptimizationStatus.INITIALIZED);
        createTrialExperiment(id);
        // Same 72-hour start as runningRunPastHardCeilingIsReaped, on a run still marked INITIALIZED.
        backdateRunStart(id, Duration.ofHours(72));

        // Both timeouts NEVER and fresh trial activity, so the run is past the total-time limit only.
        reconcile(NEVER, NEVER, Duration.ofHours(1), BATCH_SIZE);

        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.ERROR);
    }

    // ================================================================
    // created_at semantics across the upsert
    // ================================================================

    @Test
    @DisplayName("crit_created_at_preserved: a plain re-upsert preserves the run's creation time")
    void reUpsertPreservesCreatedAt() {
        var optimization = optimizationResourceClient.createPartialOptimization()
                .studioConfig(studioConfig())
                .errorInfo(null)
                .build();
        var id = optimizationResourceClient.upsert(optimization, API_KEY, TEST_WORKSPACE_NAME);
        var createdAt = optimizationResourceClient.get(id, API_KEY, TEST_WORKSPACE_NAME, 200).createdAt();

        optimizationResourceClient.upsert(optimization.toBuilder().id(id).build(), API_KEY, TEST_WORKSPACE_NAME);

        // The run's start time is the time it was first created, whatever is written to it later.
        assertThat(optimizationResourceClient.get(id, API_KEY, TEST_WORKSPACE_NAME, 200).createdAt())
                .isEqualTo(createdAt);
    }

    @Test
    @DisplayName("crit_restart_resets_created_at: restarting a platform-failed run resets created_at and clears that failure")
    void restartFromTerminalStatusResetsCreatedAtAndErrorInfo() {
        var id = seedStudioRun(OptimizationStatus.RUNNING);
        reconcile(NEVER, IMMEDIATE, BATCH_SIZE);
        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.ERROR);
        var reaped = optimizationResourceClient.get(id, API_KEY, TEST_WORKSPACE_NAME, 200);
        assertThat(reaped.errorInfo()).isNotNull();
        // The first attempt started well beyond any ceiling configured below.
        backdateRunStart(id, Duration.ofHours(48));

        // Reusing the id with a non-terminal status is a restart (SDK job redelivery).
        restart(id);

        var restarted = optimizationResourceClient.get(id, API_KEY, TEST_WORKSPACE_NAME, 200);
        // The new attempt starts its own clock instead of the first attempt's 48h-old one.
        assertThat(restarted.createdAt()).isAfter(Instant.now().minus(Duration.ofHours(1)));
        assertThat(restarted.errorInfo()).isNull();

        // And with a 24h limit the freshly restarted run is not reaped.
        reconcile(NEVER, NEVER, Duration.ofHours(24), BATCH_SIZE);
        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.RUNNING);
    }

    @Test
    @DisplayName("crit_restart_resets_created_at: restarting a completed or cancelled run starts a fresh clock")
    void restartFromCompletedOrCancelledResetsCreatedAt() {
        for (var finished : List.of(OptimizationStatus.COMPLETED, OptimizationStatus.CANCELLED)) {
            var id = seedStudioRun(finished);
            assertThat(statusOf(id)).isEqualTo(finished);
            backdateRunStart(id, Duration.ofHours(48));

            restart(id);

            var restarted = optimizationResourceClient.get(id, API_KEY, TEST_WORKSPACE_NAME, 200);
            assertThat(restarted.status()).as("status after restarting a %s run", finished)
                    .isEqualTo(OptimizationStatus.RUNNING);
            assertThat(restarted.createdAt()).as("createdAt after restarting a %s run", finished)
                    .isAfter(Instant.now().minus(Duration.ofHours(1)));
        }
    }

    @Test
    @DisplayName("crit_restart_resets_created_at: restarting a worker-failed run starts a fresh clock and keeps its error")
    void restartFromWorkerFailureKeepsErrorInfo() {
        var id = seedStudioRun(OptimizationStatus.RUNNING);
        optimizationResourceClient.update(id, OptimizationUpdate.builder()
                .status(OptimizationStatus.ERROR)
                .errorInfo(ErrorInfo.builder()
                        .exceptionType("RuntimeError")
                        .message("the evaluation crashed")
                        .traceback("Traceback (most recent call last): ...")
                        .build())
                .build(), API_KEY, TEST_WORKSPACE_NAME, 204);
        backdateRunStart(id, Duration.ofHours(48));

        restart(id);

        var restarted = optimizationResourceClient.get(id, API_KEY, TEST_WORKSPACE_NAME, 200);
        assertThat(restarted.createdAt()).isAfter(Instant.now().minus(Duration.ofHours(1)));
        // Only a failure the backend recorded itself is dropped on restart. The worker's own report stays.
        assertThat(restarted.errorInfo()).isNotNull();
        assertThat(restarted.errorInfo().message()).isEqualTo("the evaluation crashed");
    }

    // ================================================================
    // Structured failure reporting + supersede / cancel semantics
    // ================================================================

    @Test
    @DisplayName("crit_structured_error_info: a reaped run carries structured error_info, not only a log line")
    void reapedRunCarriesStructuredErrorInfo() {
        var id = seedStudioRun(OptimizationStatus.RUNNING);
        // The seed leaves errorInfo null, so everything below is the reaper's own write.
        assertThat(optimizationResourceClient.get(id, API_KEY, TEST_WORKSPACE_NAME, 200).errorInfo()).isNull();

        reconcile(NEVER, IMMEDIATE, BATCH_SIZE);

        var reaped = optimizationResourceClient.get(id, API_KEY, TEST_WORKSPACE_NAME, 200);
        assertThat(reaped.status()).isEqualTo(OptimizationStatus.ERROR);
        // The run's error info carries a readable message (the UI shows error_info.message). The type
        // token, wording and traceback text are not pinned. error_info was null before the scan, so the
        // message here was written by the scan.
        assertThat(reaped.errorInfo()).isNotNull();
        assertThat(reaped.errorInfo().message()).isNotBlank();
    }

    @Test
    @DisplayName("crit_structured_error_info: never started, no progress and past the time limit each give a different reason")
    void reapReasonTellsTheCasesApart() {
        var neverStarted = seedStudioRun(OptimizationStatus.INITIALIZED);
        reconcile(IMMEDIATE, IMMEDIATE, BATCH_SIZE);

        var noProgress = seedStudioRun(OptimizationStatus.RUNNING);
        reconcile(NEVER, IMMEDIATE, BATCH_SIZE);

        var pastLimit = seedStudioRun(OptimizationStatus.RUNNING);
        createTrialExperiment(pastLimit);
        backdateRunStart(pastLimit, Duration.ofHours(72));
        reconcile(NEVER, Duration.ofMinutes(5), Duration.ofHours(1), BATCH_SIZE);

        // Only that the three reasons differ is checked, not their wording. Each run's own id and all digits
        // are dropped first, so one template that differs only by run id, timestamp or count does not pass.
        var messages = Stream.of(neverStarted, noProgress, pastLimit)
                .map(id -> {
                    var reaped = optimizationResourceClient.get(id, API_KEY, TEST_WORKSPACE_NAME, 200);
                    assertThat(reaped.status()).isEqualTo(OptimizationStatus.ERROR);
                    assertThat(reaped.errorInfo()).isNotNull();
                    assertThat(reaped.errorInfo().message()).isNotBlank();
                    return reaped.errorInfo().message().replace(id.toString(), "").replaceAll("[0-9]", "");
                })
                .toList();
        assertThat(messages).doesNotHaveDuplicates();
    }

    @Test
    @DisplayName("crit_system_failure_superseded: a worker mark_running after a wrongful reap restores the run and clears it")
    void workerReportSupersedesPlatformDetectedFailure() {
        var id = seedStudioRun(OptimizationStatus.INITIALIZED);

        // Queue-depth case: a submission behind a full queue looks identical to one whose worker never
        // started, and is reaped on the initialized branch.
        reconcile(IMMEDIATE, IMMEDIATE, BATCH_SIZE);
        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.ERROR);

        // The worker then dequeues it and calls mark_running, and the run follows the worker's report.
        transition(id, OptimizationStatus.RUNNING);

        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.RUNNING);
        // The recorded reason described a failure that did not happen, so it is gone.
        assertThat(optimizationResourceClient.get(id, API_KEY, TEST_WORKSPACE_NAME, 200).errorInfo()).isNull();

        transition(id, OptimizationStatus.COMPLETED);
        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.COMPLETED);
    }

    @Test
    @DisplayName("crit_system_failure_superseded: a worker completion right after a wrongful reap restores the run and clears it")
    void workerCompletionSupersedesPlatformDetectedFailure() {
        var id = seedStudioRun(OptimizationStatus.RUNNING);
        reconcile(NEVER, IMMEDIATE, BATCH_SIZE);
        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.ERROR);

        // The worker was alive after all and reports its result with no running report in between.
        transition(id, OptimizationStatus.COMPLETED);

        var completed = optimizationResourceClient.get(id, API_KEY, TEST_WORKSPACE_NAME, 200);
        assertThat(completed.status()).isEqualTo(OptimizationStatus.COMPLETED);
        assertThat(completed.errorInfo()).isNull();
    }

    @Test
    @DisplayName("crit_worker_failure_not_superseded: a worker-reported failure is not overwritten by a later report")
    void workerReportedFailureIsNotSuperseded() {
        var id = seedStudioRun(OptimizationStatus.RUNNING);

        // A failure the WORKER reported is a real outcome, not the platform's guess, so it keeps winning.
        optimizationResourceClient.update(id, OptimizationUpdate.builder()
                .status(OptimizationStatus.ERROR)
                .errorInfo(ErrorInfo.builder()
                        .exceptionType("ValueError")
                        .message("the optimizer raised")
                        .traceback("Traceback (most recent call last): ...")
                        .build())
                .build(), API_KEY, TEST_WORKSPACE_NAME, 204);

        transition(id, OptimizationStatus.RUNNING);
        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.ERROR);

        transition(id, OptimizationStatus.COMPLETED);
        var current = optimizationResourceClient.get(id, API_KEY, TEST_WORKSPACE_NAME, 200);
        assertThat(current.status()).isEqualTo(OptimizationStatus.ERROR);
        assertThat(current.errorInfo()).isNotNull();
        assertThat(current.errorInfo().message()).isEqualTo("the optimizer raised");
    }

    @Test
    @DisplayName("crit_worker_failure_not_superseded: a user cancellation is not overwritten by a later worker report")
    void cancellationIsNotSuperseded() {
        var id = seedStudioRun(OptimizationStatus.RUNNING);
        transition(id, OptimizationStatus.CANCELLED);

        // CANCELLED is the user's decision and outranks anything the worker says afterwards.
        transition(id, OptimizationStatus.RUNNING);
        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.CANCELLED);

        transition(id, OptimizationStatus.COMPLETED);
        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.CANCELLED);
    }

    @Test
    @DisplayName("crit_reaped_run_cancellable: a wrongly reaped run can still be cancelled and fires the Redis signal")
    void systemDetectedFailureRemainsCancellable() {
        var id = seedStudioRun(OptimizationStatus.RUNNING);
        reconcile(NEVER, IMMEDIATE, BATCH_SIZE);
        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.ERROR);

        // The reap may have been wrong and the worker may still be running, so Cancel is accepted for
        // this ERROR rather than refused with the usual 409.
        transition(id, OptimizationStatus.CANCELLED);
        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.CANCELLED);

        // opik:cancel:<id> is the worker's only cancellation channel, so the key has to be written.
        assertThat(injector.getInstance(RedissonReactiveClient.class)
                .getBucket("opik:cancel:" + id).isExists().block()).isTrue();
    }

    @Test
    @DisplayName("crit_reaped_run_cancellable: a worker-reported failure stays uncancellable (409)")
    void workerReportedFailureIsNotCancellable() {
        var id = seedStudioRun(OptimizationStatus.RUNNING);
        optimizationResourceClient.update(id, OptimizationUpdate.builder()
                .status(OptimizationStatus.ERROR)
                .errorInfo(ErrorInfo.builder()
                        .exceptionType("ValueError")
                        .message("the optimizer raised")
                        .traceback("Traceback (most recent call last): ...")
                        .build())
                .build(), API_KEY, TEST_WORKSPACE_NAME, 204);

        // A failure the worker reported is a real outcome with nothing left to stop, so the existing
        // 409 still applies.
        optimizationResourceClient.update(id, OptimizationUpdate.builder()
                .status(OptimizationStatus.CANCELLED).build(), API_KEY, TEST_WORKSPACE_NAME, 409);

        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.ERROR);
    }

    // ================================================================
    // Symptom 2: runs that vanish / 404 (NaN and overflow on the fetch path)
    // ================================================================

    @Test
    @DisplayName("crit_nan_duration_survives: a run whose only trial item references an unfinished trace is still returned")
    void runWithUnfinishedTraceItemIsStillReturned() {
        var optimization = optimizationResourceClient.createPartialOptimization().build();
        var id = optimizationResourceClient.create(optimization, API_KEY, TEST_WORKSPACE_NAME);

        // An item referencing a still-unfinished trace is what a worker killed mid-trial leaves behind.
        // The run has no finished trace to take a duration from.
        createTrialWithUnfinishedTraceItem(id);

        var fetched = optimizationResourceClient.get(id, API_KEY, TEST_WORKSPACE_NAME, 200);
        assertThat(fetched.id()).isEqualTo(id);
        assertThat(fetched.numTrials()).isEqualTo(1L);
        // Duration aggregates are absent and the run itself is still returned.
        assertThat(fetched.bestDuration()).isNull();
        assertThat(fetched.baselineDuration()).isNull();

        // The run is on the list as well.
        var page = optimizationResourceClient.find(API_KEY, TEST_WORKSPACE_NAME, 1, 100, null, null, null, 200);
        assertThat(page.content()).extracting(Optimization::id).contains(id);
    }

    @Test
    @DisplayName("crit_nonfinite_score_excluded: a trial carrying a raw NaN experiment score is returned, that score excluded")
    void runWithNonFiniteScoreIsReturnedScoreExcluded() {
        var optimization = optimizationResourceClient.createPartialOptimization().build();
        var id = optimizationResourceClient.create(optimization, API_KEY, TEST_WORKSPACE_NAME);

        // A string-typed "NaN" is valid JSON and reads as a Float64 nan. It cannot be seeded through the
        // typed API (ExperimentScore.value is a BigDecimal), hence the raw insert.
        insertTrialWithRawScores(id,
                "[{\"name\":\"finite_metric\",\"value\":0.75},{\"name\":\"nan_metric\",\"value\":\"NaN\"}]");

        var fetched = optimizationResourceClient.get(id, API_KEY, TEST_WORKSPACE_NAME, 200);
        assertThat(fetched.id()).isEqualTo(id);
        assertThat(fetched.numTrials()).isEqualTo(1L);
        // The non-finite entry is excluded; the finite one remains.
        assertThat(fetched.experimentScores())
                .extracting(FeedbackScoreAverage::name)
                .containsExactly("finite_metric");

        var page = optimizationResourceClient.find(API_KEY, TEST_WORKSPACE_NAME, 1, 100, null, null, null, 200);
        assertThat(page.content()).extracting(Optimization::id).contains(id);
    }

    @Test
    @DisplayName("crit_overflow_aggregate_absent: finite scores summing to +Inf still return the run, overflowed aggregate null")
    void runWithOverflowingAggregateIsReturned() {
        var objectiveName = "accuracy";
        var optimization = optimizationResourceClient.createPartialOptimization()
                .objectiveName(objectiveName)
                .build();
        var id = optimizationResourceClient.create(optimization, API_KEY, TEST_WORKSPACE_NAME);

        // Two trials in one candidate, each a finite 1e308. Each score is a valid number, but their sum
        // in the derived aggregate is +Inf.
        var candidateId = UUID.randomUUID().toString();
        var metadata = JsonUtils.getJsonNodeFromString(
                JsonUtils.writeValueAsString(Map.of("candidate_id", candidateId)));
        var hugeButFinite = new BigDecimal("1e308");

        var trialIds = Stream.of(1, 2)
                .map(ignored -> experimentResourceClient.create(experimentResourceClient
                        .createPartialExperiment()
                        .optimizationId(id)
                        .type(ExperimentType.TRIAL)
                        .metadata(metadata)
                        .experimentScores(List.of(ExperimentScore.builder()
                                .name(objectiveName)
                                .value(hugeButFinite)
                                .build()))
                        .build(), API_KEY, TEST_WORKSPACE_NAME))
                .toList();

        var traceStart = Instant.now().minusSeconds(30);
        trialIds.forEach(trialId -> linkItemWithTrace(trialId, traceStart, traceStart.plusMillis(1_000)));

        await().atMost(10, TimeUnit.SECONDS)
                .pollInterval(1, TimeUnit.SECONDS)
                .untilAsserted(() -> {
                    var actual = optimizationResourceClient.get(id, API_KEY, TEST_WORKSPACE_NAME, 200);
                    assertThat(actual.id()).isEqualTo(id);
                    // An aggregate too large to represent is reported absent, not as some other number.
                    assertThat(actual.bestObjectiveScore()).isNull();
                    assertThat(actual.baselineObjectiveScore()).isNull();
                    // Durations are unaffected by the overflow and must still be computed.
                    assertThat(actual.bestDuration()).isNotNull();
                });

        var page = optimizationResourceClient.find(API_KEY, TEST_WORKSPACE_NAME, 1, 100, null, null, null, 200);
        assertThat(page.content()).extracting(Optimization::id).contains(id);
    }

    // ================================================================
    // Reconcile drivers
    // ================================================================

    private long reconcile(Duration initializedTimeout, Duration runningTimeout, int batchSize) {
        return reconcile(initializedTimeout, runningTimeout, NEVER, batchSize);
    }

    // Value for any int parameter other than the batch size (a query-tuning knob such as a candidate-scan
    // multiplier). Any positive value in the config bound [1, 1000] works. It is never asserted on and only
    // has to let the call run.
    private static final int DEFAULT_CANDIDATE_SCAN_FACTOR = 10;

    /**
     * Calls the reconcile method through reflection, so any parameter list that takes the scan's settings
     * as separate values works: the original 4-arg shape (initialized timeout, running timeout, lookback
     * margin, batch size), a shape that adds a total-time limit, a shape that adds a scan-tuning int, in
     * any order, or one settings record carrying those values.
     *
     * <p>Arguments are bound by parameter name first. The backend compiles with {@code -parameters}, so
     * names such as {@code initializedTimeout}, {@code runningHardTimeout} or {@code lookbackMargin} are
     * visible at runtime; see {@link #bindReconcileArgsByName}. When a name is missing or does not say
     * which value it takes, the positional rule in {@link #bindReconcileArgsByPosition} is used instead.
     *
     * <p>A design that does not take the total-time limit as a parameter (reading it from configuration,
     * for example) still has it exercised by the same seeded runs; only the passed value is skipped.
     *
     * <p>The method is resolved through the {@link OptimizationService} interface (and its supertypes),
     * which is present whether or not Guice wraps the implementation in a CGLIB or JDK-proxy layer.
     */
    @SuppressWarnings("unchecked")
    private long reconcile(Duration initializedTimeout, Duration runningTimeout, Duration runningHardTimeout,
            int batchSize) {
        Method method = findReconcileMethod();
        Object[] args = bindReconcileArgsByName(method, initializedTimeout, runningTimeout, runningHardTimeout,
                batchSize);
        if (args == null) {
            args = bindReconcileArgsByPosition(method, initializedTimeout, runningTimeout, runningHardTimeout,
                    batchSize);
        }
        try {
            Long transitioned = ((reactor.core.publisher.Mono<Long>) method.invoke(optimizationService, args)).block();
            assertThat(transitioned).isNotNull();
            return transitioned;
        } catch (java.lang.reflect.InvocationTargetException | IllegalAccessException e) {
            throw new RuntimeException("reconcileStalledStudioOptimizations invocation failed", e);
        }
    }

    /** Marks a parameter or record component whose name does not say which scan setting it takes. */
    private static final Object UNBOUND = new Object();

    private static final List<String> REQUIRED_SETTINGS = List.of("initialized", "running", "lookback", "batch");

    /**
     * Binds each parameter from its declared name, in whatever order the method lists them. A method whose
     * only parameter is a record (a settings object such as the reaper's config) gets one instance built
     * through the record's canonical constructor, with each component bound by its name the same way; a
     * component no rule matches gets a neutral value (1 minute, true, or the int default). See
     * {@link #settingFor} for the name rules. Returns null, so the caller falls back to the positional
     * rule, when a parameter name is not present or matches no rule, a parameter has another type, or the
     * initialized timeout, running timeout, lookback margin or batch size is not bound.
     */
    private Object[] bindReconcileArgsByName(Method method, Duration initializedTimeout, Duration runningTimeout,
            Duration runningHardTimeout, int batchSize) {
        java.lang.reflect.Parameter[] params = method.getParameters();
        java.util.Set<String> bound = new java.util.HashSet<>();
        if (params.length == 1 && params[0].getType().isRecord()) {
            Class<?> recordType = params[0].getType();
            java.lang.reflect.RecordComponent[] components = recordType.getRecordComponents();
            Class<?>[] types = new Class<?>[components.length];
            Object[] values = new Object[components.length];
            for (int i = 0; i < components.length; i++) {
                types[i] = components[i].getType();
                Object value = settingFor(components[i].getName(), types[i], initializedTimeout, runningTimeout,
                        runningHardTimeout, batchSize, bound);
                if (value == UNBOUND) {
                    value = neutralValue(types[i]);
                }
                if (value == UNBOUND) {
                    return null;
                }
                values[i] = value;
            }
            if (!bound.containsAll(REQUIRED_SETTINGS)) {
                return null;
            }
            try {
                var constructor = recordType.getDeclaredConstructor(types);
                constructor.setAccessible(true);
                return new Object[]{constructor.newInstance(values)};
            } catch (ReflectiveOperationException e) {
                throw new RuntimeException("could not build reconcile settings " + recordType, e);
            }
        }
        Object[] args = new Object[params.length];
        for (int i = 0; i < params.length; i++) {
            java.lang.reflect.Parameter param = params[i];
            if (!param.isNamePresent()) {
                return null;
            }
            Object value = settingFor(param.getName(), param.getType(), initializedTimeout, runningTimeout,
                    runningHardTimeout, batchSize, bound);
            if (value == UNBOUND) {
                return null;
            }
            args[i] = value;
        }
        if (!bound.containsAll(REQUIRED_SETTINGS)) {
            return null;
        }
        return args;
    }

    /**
     * The value for one named scan setting, or {@link #UNBOUND}. Durations (java.time or Dropwizard): a
     * name containing "initial" takes the initialized timeout; "hard", "ceiling", "max", "total" or
     * "absolute" the total-time limit; "lookback" or "margin" the lookback margin; "running",
     * "progress", "stall" or "idle" the running timeout (checked in that order, so
     * {@code runningHardTimeout} is the limit). An int whose name contains "batch" or equals "limit"
     * takes the batch size, and any other int takes {@link #DEFAULT_CANDIDATE_SCAN_FACTOR}. A setting
     * already bound, or any other name or type, is {@link #UNBOUND}.
     */
    private Object settingFor(String rawName, Class<?> type, Duration initializedTimeout, Duration runningTimeout,
            Duration runningHardTimeout, int batchSize, java.util.Set<String> bound) {
        String name = rawName.toLowerCase(java.util.Locale.ROOT);
        if (type == Duration.class || type == io.dropwizard.util.Duration.class) {
            String role;
            Duration value;
            if (name.contains("initial")) {
                role = "initialized";
                value = initializedTimeout;
            } else if (name.contains("hard") || name.contains("ceiling") || name.contains("max")
                    || name.contains("total") || name.contains("absolute")) {
                role = "hard";
                value = runningHardTimeout;
            } else if (name.contains("lookback") || name.contains("margin")) {
                role = "lookback";
                value = LOOKBACK_MARGIN;
            } else if (name.contains("running") || name.contains("progress") || name.contains("stall")
                    || name.contains("idle")) {
                role = "running";
                value = runningTimeout;
            } else {
                return UNBOUND;
            }
            if (!bound.add(role)) {
                return UNBOUND;
            }
            return type == Duration.class ? value : io.dropwizard.util.Duration.milliseconds(value.toMillis());
        }
        if (type == int.class || type == Integer.class) {
            boolean isBatch = name.contains("batch") || name.equals("limit");
            if (!bound.add(isBatch ? "batch" : "int:" + name)) {
                return UNBOUND;
            }
            return isBatch ? batchSize : DEFAULT_CANDIDATE_SCAN_FACTOR;
        }
        return UNBOUND;
    }

    /** A value for a settings-record component the scan does not use (startup delay, job interval, ...). */
    private static Object neutralValue(Class<?> type) {
        if (type == Duration.class) {
            return Duration.ofMinutes(1);
        }
        if (type == io.dropwizard.util.Duration.class) {
            return io.dropwizard.util.Duration.minutes(1);
        }
        if (type == boolean.class || type == Boolean.class) {
            return true;
        }
        return UNBOUND;
    }

    /**
     * Positional fallback. Walks the declared parameter types in order and takes the next value from a
     * Duration queue or an int queue as each slot needs:
     * <ul>
     *   <li>Durations, in order: {@code initializedTimeout}, {@code runningTimeout}, then the total-time
     *       limit only when the method declares a 4th Duration, then {@code lookbackMargin}.</li>
     *   <li>ints, in order: {@code batchSize}, then {@link #DEFAULT_CANDIDATE_SCAN_FACTOR} only when the
     *       method declares a 2nd int.</li>
     * </ul>
     */
    private Object[] bindReconcileArgsByPosition(Method method, Duration initializedTimeout, Duration runningTimeout,
            Duration runningHardTimeout, int batchSize) {
        Class<?>[] types = method.getParameterTypes();
        long durationParams = java.util.Arrays.stream(types).filter(t -> t == Duration.class).count();
        long intParams = java.util.Arrays.stream(types).filter(t -> t == int.class || t == Integer.class).count();
        if (durationParams < 3 || intParams < 1) {
            throw new RuntimeException(
                    "reconcileStalledStudioOptimizations has an unexpected signature " + method
                            + " (need >= 3 Duration params and >= 1 int param to drive the reaper scan)");
        }

        // Durations to feed, in order. The total-time limit is passed only when the method has room for
        // it (>= 4 Duration params).
        java.util.Deque<Duration> durations = new java.util.ArrayDeque<>();
        durations.add(initializedTimeout);
        durations.add(runningTimeout);
        if (durationParams >= 4) {
            durations.add(runningHardTimeout);
        }
        durations.add(LOOKBACK_MARGIN);

        // ints to feed, in order: batchSize, then the optional scan-factor knob.
        java.util.Deque<Integer> ints = new java.util.ArrayDeque<>();
        ints.add(batchSize);
        if (intParams >= 2) {
            ints.add(DEFAULT_CANDIDATE_SCAN_FACTOR);
        }

        Object[] args = new Object[types.length];
        for (int i = 0; i < types.length; i++) {
            Class<?> t = types[i];
            if (t == Duration.class) {
                args[i] = durations.poll();
            } else if (t == int.class || t == Integer.class) {
                args[i] = ints.poll();
            } else {
                throw new RuntimeException(
                        "reconcileStalledStudioOptimizations param " + i + " has unsupported type " + t
                                + " in " + method);
            }
        }
        if (durations.peek() != null || ints.peek() != null) {
            throw new RuntimeException(
                    "reconcileStalledStudioOptimizations signature " + method
                            + " does not consume all required reaper-scan arguments");
        }
        return args;
    }

    /**
     * Walk the {@link OptimizationService} interface hierarchy and return the reconcile
     * method, selecting the widest signature present (highest parameter count, >= 4).
     * When a tree keeps the 4-arg form as an overload next to a wider one, the wider
     * one is called.
     */
    private static Method findReconcileMethod() {
        java.util.Deque<Class<?>> queue = new java.util.ArrayDeque<>();
        queue.add(OptimizationService.class);
        java.util.Set<Class<?>> visited = new java.util.HashSet<>();
        Method best = null;
        while (!queue.isEmpty()) {
            Class<?> c = queue.poll();
            if (!visited.add(c)) continue;
            for (Method m : c.getDeclaredMethods()) {
                if (!"reconcileStalledStudioOptimizations".equals(m.getName())) continue;
                if (m.getParameterCount() < 4) continue;
                if (best == null || m.getParameterCount() > best.getParameterCount()) {
                    best = m;
                }
            }
            for (Class<?> iface : c.getInterfaces()) queue.add(iface);
        }
        if (best != null) return best;
        throw new RuntimeException(
                "reconcileStalledStudioOptimizations (arity >= 4) not found in OptimizationService hierarchy");
    }

    // ================================================================
    // Seed helpers: HTTP API where possible, raw ClickHouse only for
    // server-stamped timestamps and raw-JSON columns.
    // ================================================================

    private UUID seedStudioRun(OptimizationStatus status) {
        var id = seedRun(OptimizationStatus.INITIALIZED, studioConfig());
        switch (status) {
            case INITIALIZED -> {
            }
            case RUNNING -> transition(id, OptimizationStatus.RUNNING);
            case COMPLETED, CANCELLED, ERROR -> {
                transition(id, OptimizationStatus.RUNNING);
                transition(id, status);
            }
        }
        return id;
    }

    private UUID seedRun(OptimizationStatus status, OptimizationStudioConfig studioConfig) {
        var optimization = optimizationResourceClient.createPartialOptimization()
                .status(status)
                .studioConfig(studioConfig)
                // createPartialOptimization leaves Podam's random ErrorInfo in place; clear it so every
                // "the reaper wrote an ErrorInfo" assertion reflects the reaper, not the fixture.
                .errorInfo(null)
                .build();
        return optimizationResourceClient.upsert(optimization, API_KEY, TEST_WORKSPACE_NAME);
    }

    /**
     * Seeds a RUNNING studio run whose latest row version's {@code last_updated_at} is backdated by
     * {@code age}, so the row timestamp alone reads as stale. The update endpoint always stamps now and
     * the create path forces INITIALIZED, so the run is upserted twice with the same id: the create
     * (backdated a minute further) and a RUNNING re-upsert whose backdated timestamp stays the newest
     * version for dedup.
     */
    private UUID seedBackdatedRunningStudioRun(Duration age) {
        var optimization = optimizationResourceClient.createPartialOptimization()
                .studioConfig(studioConfig())
                .errorInfo(null)
                .lastUpdatedAt(Instant.now().minus(age).minus(Duration.ofMinutes(1)))
                .build();
        var id = optimizationResourceClient.upsert(optimization, API_KEY, TEST_WORKSPACE_NAME);
        optimizationResourceClient.upsert(optimization.toBuilder()
                .id(id)
                .status(OptimizationStatus.RUNNING)
                .lastUpdatedAt(Instant.now().minus(age))
                .build(), API_KEY, TEST_WORKSPACE_NAME);

        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.RUNNING);
        return id;
    }

    private UUID seedBackdatedInitializedStudioRun(Duration age) {
        var optimization = optimizationResourceClient.createPartialOptimization()
                .studioConfig(studioConfig())
                .errorInfo(null)
                .lastUpdatedAt(Instant.now().minus(age))
                .build();
        var id = optimizationResourceClient.upsert(optimization, API_KEY, TEST_WORKSPACE_NAME);

        assertThat(statusOf(id)).isEqualTo(OptimizationStatus.INITIALIZED);
        return id;
    }

    /**
     * Clones the run's latest row version with a backdated {@code created_at} and a fresh
     * {@code last_updated_at}: "started long ago, but something wrote the row a moment ago". Neither timestamp is settable through the API, so the row is
     * cloned inside ClickHouse; the new version carries the newest {@code last_updated_at} so it wins
     * dedup while the backdated {@code created_at} supplies the start.
     */
    private void backdateRunStart(UUID id, Duration startedAgo) {
        var startedAt = ClickHouseDateTimeFormat.formatNanos(Instant.now().minus(startedAgo));
        var sql = ("INSERT INTO %s.optimizations (id, dataset_id, name, workspace_id, project_id, "
                + "objective_name, status, metadata, studio_config, error_info, created_by, last_updated_by, "
                + "created_at, last_updated_at) "
                + "SELECT id, dataset_id, name, workspace_id, project_id, objective_name, status, metadata, "
                + "studio_config, error_info, created_by, last_updated_by, "
                + "toDateTime64('%s', 9, 'UTC'), now64(6) "
                + "FROM %s.optimizations WHERE id = '%s' AND workspace_id = '%s' "
                + "ORDER BY last_updated_at DESC LIMIT 1")
                .formatted(ANALYTICS_DB, startedAt, ANALYTICS_DB, id, WORKSPACE_ID);
        try (var connection = NativeServiceAppExtensionShim.newClickHouseConnection();
                var statement = connection.createStatement()) {
            statement.executeUpdate(sql);
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to backdate run start", e);
        }
    }

    /** Creates a trial experiment linked to the run, which is new activity for that run. */
    private UUID createTrialExperiment(UUID optimizationId) {
        var experiment = experimentResourceClient.createPartialExperiment()
                .optimizationId(optimizationId)
                .build();
        return experimentResourceClient.create(experiment, API_KEY, TEST_WORKSPACE_NAME);
    }

    /**
     * Inserts a trial experiment row straight into ClickHouse with a backdated {@code created_at}. The
     * API always stamps {@code created_at} server-side and the probe reads the table without FINAL, so a
     * single raw row is the only way to seed an "old trial" deterministically without sleeping the suite.
     */
    private UUID createBackdatedTrialExperiment(UUID optimizationId, Duration age) {
        var experiment = experimentResourceClient.createPartialExperiment()
                .optimizationId(optimizationId)
                .build();
        var createdAt = ClickHouseDateTimeFormat.formatNanos(Instant.now().minus(age));
        try (var connection = NativeServiceAppExtensionShim.newClickHouseConnection();
                var statement = connection.prepareStatement(
                        ("INSERT INTO %s.experiments (workspace_id, dataset_id, id, name, optimization_id, "
                                + "created_at, last_updated_at, created_by, last_updated_by) "
                                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)").formatted(ANALYTICS_DB))) {
            statement.setString(1, WORKSPACE_ID);
            statement.setString(2, experiment.datasetId().toString());
            statement.setString(3, experiment.id().toString());
            statement.setString(4, experiment.name());
            statement.setString(5, optimizationId.toString());
            statement.setString(6, createdAt);
            statement.setString(7, createdAt);
            statement.setString(8, USER);
            statement.setString(9, USER);
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to seed backdated trial experiment", e);
        }
        return experiment.id();
    }

    /**
     * Appends one experiment item to a trial, the per-dataset-item activity within a trial. The
     * trace is created first, matching the worker (trace before item). A null {@code endTime} leaves the
     * trace unfinished, so it contributes no duration.
     */
    private void createExperimentItem(UUID experimentId, boolean traceFinished) {
        var traceBuilder = podamFactory.manufacturePojo(Trace.class).toBuilder()
                .feedbackScores(null)
                .usage(null);
        if (!traceFinished) {
            traceBuilder.endTime(null).duration(null);
        }
        var traceId = traceResourceClient.createTrace(traceBuilder.build(), API_KEY, TEST_WORKSPACE_NAME);
        var item = podamFactory.manufacturePojo(ExperimentItem.class).toBuilder()
                .experimentId(experimentId)
                .traceId(traceId)
                .feedbackScores(null)
                .build();
        experimentResourceClient.createExperimentItem(Set.of(item), API_KEY, TEST_WORKSPACE_NAME);
    }

    /**
     * Links a trial with one experiment item whose trace is still unfinished (no end time, so no
     * duration), the state a worker killed mid-trial leaves behind.
     */
    private void createTrialWithUnfinishedTraceItem(UUID optimizationId) {
        var experiment = experimentResourceClient.createPartialExperiment()
                .optimizationId(optimizationId)
                .type(ExperimentType.TRIAL)
                .build();
        var experimentId = experimentResourceClient.create(experiment, API_KEY, TEST_WORKSPACE_NAME);

        var trace = podamFactory.manufacturePojo(Trace.class).toBuilder()
                .endTime(null)
                .duration(null)
                .feedbackScores(null)
                .usage(null)
                .build();
        traceResourceClient.createTrace(trace, API_KEY, TEST_WORKSPACE_NAME);

        var item = podamFactory.manufacturePojo(ExperimentItem.class).toBuilder()
                .experimentId(experimentId)
                .traceId(trace.id())
                .feedbackScores(null)
                .build();
        experimentResourceClient.createExperimentItem(Set.of(item), API_KEY, TEST_WORKSPACE_NAME);
    }

    /**
     * Appends one experiment item backed by a real trace spanning {@code [startTime, endTime]}. A null
     * {@code endTime} leaves the trace unfinished, contributing no duration.
     */
    private void linkItemWithTrace(UUID experimentId, Instant startTime, Instant endTime) {
        var trace = podamFactory.manufacturePojo(Trace.class).toBuilder()
                .startTime(startTime)
                .endTime(endTime)
                .duration(null)
                .feedbackScores(null)
                .usage(null)
                .build();
        traceResourceClient.createTrace(trace, API_KEY, TEST_WORKSPACE_NAME);

        var item = podamFactory.manufacturePojo(ExperimentItem.class).toBuilder()
                .experimentId(experimentId)
                .traceId(trace.id())
                .feedbackScores(null)
                .build();
        experimentResourceClient.createExperimentItem(Set.of(item), API_KEY, TEST_WORKSPACE_NAME);
    }

    /**
     * Inserts a trial experiment row straight into ClickHouse with a raw {@code experiment_scores} JSON
     * string. The typed API cannot produce every shape the column can hold ({@code ExperimentScore.value}
     * is a BigDecimal, so "NaN" is rejected at deserialization), but older or foreign writers can leave
     * such raw JSON in the column.
     */
    private void insertTrialWithRawScores(UUID optimizationId, String experimentScoresJson) {
        var experiment = experimentResourceClient.createPartialExperiment().build();
        try (var connection = NativeServiceAppExtensionShim.newClickHouseConnection();
                var statement = connection.prepareStatement(
                        ("INSERT INTO %s.experiments (workspace_id, dataset_id, id, name, optimization_id, "
                                + "experiment_scores, created_by, last_updated_by) "
                                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)").formatted(ANALYTICS_DB))) {
            statement.setString(1, WORKSPACE_ID);
            statement.setString(2, experiment.datasetId().toString());
            statement.setString(3, experiment.id().toString());
            statement.setString(4, experiment.name());
            statement.setString(5, optimizationId.toString());
            statement.setString(6, experimentScoresJson);
            statement.setString(7, USER);
            statement.setString(8, USER);
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new IllegalStateException("Failed to seed trial experiment with raw scores", e);
        }
    }

    /**
     * Re-upserts the run with a non-terminal status, the way the SDK restarts a job under the same id. Same
     * datasetName and name so dedup merges onto the same row; createdAt/lastUpdatedAt are left null, as the
     * SDK sends them.
     */
    private void restart(UUID id) {
        var current = optimizationResourceClient.get(id, API_KEY, TEST_WORKSPACE_NAME, 200);
        optimizationResourceClient.upsert(optimizationResourceClient.createPartialOptimization()
                .id(id)
                .datasetName(current.datasetName())
                .name(current.name())
                .status(OptimizationStatus.RUNNING)
                .studioConfig(studioConfig())
                .errorInfo(null)
                .createdAt(null)
                .lastUpdatedAt(null)
                .build(), API_KEY, TEST_WORKSPACE_NAME);
    }

    private void transition(UUID id, OptimizationStatus status) {
        optimizationResourceClient.update(id, OptimizationUpdate.builder().status(status).build(),
                API_KEY, TEST_WORKSPACE_NAME, 204);
    }

    private OptimizationStatus statusOf(UUID id) {
        return optimizationResourceClient.get(id, API_KEY, TEST_WORKSPACE_NAME, 200).status();
    }

    private OptimizationStudioConfig studioConfig() {
        // opikApiKey is @JsonIgnore and populated server-side, so we omit it.
        return podamFactory.manufacturePojo(OptimizationStudioConfig.class).toBuilder()
                .opikApiKey(null)
                .build();
    }
}
