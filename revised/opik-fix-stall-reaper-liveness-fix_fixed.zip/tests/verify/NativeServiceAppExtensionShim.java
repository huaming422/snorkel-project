package com.comet.opik.domain;

import com.comet.opik.api.resources.utils.MigrationUtils;
import com.comet.opik.api.resources.utils.TestDropwizardAppExtensionUtils;
import com.comet.opik.infrastructure.DatabaseAnalyticsFactory;
import com.github.tomakehurst.wiremock.junit5.WireMockRuntimeInfo;
import liquibase.Liquibase;
import liquibase.database.DatabaseConnection;
import liquibase.database.DatabaseFactory;
import liquibase.database.jvm.JdbcConnection;
import liquibase.exception.LiquibaseException;
import liquibase.exception.UnexpectedLiquibaseException;
import liquibase.resource.ClassLoaderResourceAccessor;
import ru.vyarus.dropwizard.guice.test.jupiter.ext.TestDropwizardAppExtension;
import ru.yandex.clickhouse.ClickHouseConnectionImpl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Map;

/**
 * Boots the opik-backend Dropwizard application against the NATIVE MySQL +
 * ClickHouse + Redis that {@code tests/test-setup.sh} started on localhost,
 * with no Testcontainers / Docker-in-Docker (not available in the task container).
 *
 * <p>This is a drop-in replacement for the Testcontainers init block used by
 * the repo's own integration tests (see {@code ExperimentAggregatesIntegrationTest}).
 * It does what that block does (run the two Liquibase migrations and
 * build a {@link TestDropwizardAppExtension}) but points every connection at
 * the baked-in localhost services instead of at ephemeral containers.
 *
 * <p>Endpoints (matching {@code src/test/resources/config-test.yml} exactly, so
 * the app itself needs no DB-connection overrides beyond what the shared
 * {@link TestDropwizardAppExtensionUtils} helper already pushes):
 * <ul>
 *   <li>MySQL      - jdbc:mysql://localhost:3306/opik   (opik/opik)</li>
 *   <li>ClickHouse - HTTP localhost:8123, db opik       (opik/opik)</li>
 *   <li>Redis      - redis://:opik@localhost:6379/0</li>
 * </ul>
 *
 * <p>The migration wiring mirrors {@code MigrationUtils.runDbMigration}
 * (which is package-private there): find the Liquibase database implementation
 * for the connection, set the changelog parameters, and run {@code update}.
 * The ClickHouse migration connection targets the {@code default} database with
 * changelog parameter {@code ANALYTICS_DB_DATABASE_NAME=opik}, so Liquibase's
 * DATABASECHANGELOG tracking table then lands in {@code default} while the
 * migrated analytics tables land in {@code opik} (pointing the connection at
 * {@code .../opik} makes migration 000017 fail).
 */
public final class NativeServiceAppExtensionShim {

    private NativeServiceAppExtensionShim() {
    }

    // --- Native localhost endpoints (identical to config-test.yml) ----------

    private static final String MYSQL_URL = "jdbc:mysql://localhost:3306/opik"
            + "?createDatabaseIfNotExist=true&rewriteBatchedStatements=true&serverTimezone=UTC";
    private static final String MYSQL_USER = "opik";
    private static final String MYSQL_PASSWORD = "opik";

    // Legacy ru.yandex.clickhouse driver URL. Target the `default` database
    // (see class-level note); credentials travel as URL query parameters, the
    // form the legacy driver parses.
    private static final String CLICKHOUSE_MIGRATION_URL =
            "jdbc:clickhouse://localhost:8123/default?user=opik&password=opik";

    private static final String CLICKHOUSE_HOST = "localhost";
    private static final int CLICKHOUSE_HTTP_PORT = 8123;
    private static final String CLICKHOUSE_USER = "opik";
    private static final String CLICKHOUSE_PASSWORD = "opik";
    private static final String CLICKHOUSE_DB = "opik";

    private static final String REDIS_URL = "redis://:opik@localhost:6379/0";

    // Changelog parameter maps (same values as {MySQL,ClickHouse}ContainerUtils
    // .migrationParameters(); inlined so the shim stays independent of the
    // Testcontainers-typed helpers).
    private static final Map<String, String> MYSQL_MIGRATION_PARAMS =
            Map.of("STATE_DB_DATABASE_NAME", "opik");
    private static final Map<String, String> CLICKHOUSE_MIGRATION_PARAMS =
            Map.of("ANALYTICS_DB_DATABASE_NAME", "opik");

    /**
     * Runs the MySQL + ClickHouse Liquibase migrations against the native
     * localhost services. Idempotent: Liquibase skips changesets already
     * recorded in DATABASECHANGELOG, so re-running against an already-migrated
     * DB is a no-op.
     */
    public static void runMigrations() {
        runMysqlMigration();
        runClickhouseMigration();
    }

    private static void runMysqlMigration() {
        try (Connection connection = DriverManager.getConnection(MYSQL_URL, MYSQL_USER, MYSQL_PASSWORD)) {
            runDbMigration(MigrationUtils.MYSQL_CHANGELOG_FILE, MYSQL_MIGRATION_PARAMS,
                    new JdbcConnection(connection));
        } catch (SQLException e) {
            throw new RuntimeException("Failed to run MySQL DB migration against native localhost:3306", e);
        }
    }

    private static void runClickhouseMigration() {
        try {
            DatabaseConnection dbConnection = new JdbcConnection(
                    new ClickHouseConnectionImpl(CLICKHOUSE_MIGRATION_URL));
            runDbMigration(MigrationUtils.CLICKHOUSE_CHANGELOG_FILE, CLICKHOUSE_MIGRATION_PARAMS, dbConnection);
        } catch (SQLException e) {
            throw new RuntimeException("Failed to run ClickHouse DB migration against native localhost:8123", e);
        }
    }

    // Mirrors MigrationUtils.runDbMigration (package-private there).
    private static void runDbMigration(String changeLogFile, Map<String, String> parameters,
            DatabaseConnection connection) {
        try {
            var database = DatabaseFactory.getInstance().findCorrectDatabaseImplementation(connection);
            try (var liquibase = new Liquibase(changeLogFile, new ClassLoaderResourceAccessor(), database)) {
                parameters.forEach(liquibase::setChangeLogParameter);
                liquibase.update("updateSql");
            }
        } catch (LiquibaseException e) {
            throw new UnexpectedLiquibaseException(e);
        }
    }

    /**
     * Builds a {@link TestDropwizardAppExtension} for the opik backend wired to
     * the native localhost services. WireMock (passed in) stands in for the
     * auth/react service, exactly as the repo's integration tests do.
     *
     * <p>The analytics host and database name come from config-test.yml; the
     * shared helper only overrides the analytics port/username/password (all
     * already equal to the native values here) plus the MySQL url, redis url,
     * and auth service url.
     */
    public static TestDropwizardAppExtension newAppExtension(WireMockRuntimeInfo runtimeInfo) {
        var databaseAnalyticsFactory = new DatabaseAnalyticsFactory();
        databaseAnalyticsFactory.setProtocol(DatabaseAnalyticsFactory.Protocol.HTTP);
        databaseAnalyticsFactory.setHost(CLICKHOUSE_HOST);
        databaseAnalyticsFactory.setPort(CLICKHOUSE_HTTP_PORT);
        databaseAnalyticsFactory.setUsername(CLICKHOUSE_USER);
        databaseAnalyticsFactory.setPassword(CLICKHOUSE_PASSWORD);
        databaseAnalyticsFactory.setDatabaseName(CLICKHOUSE_DB);

        return TestDropwizardAppExtensionUtils.newTestDropwizardAppExtension(
                MYSQL_URL, databaseAnalyticsFactory, runtimeInfo, REDIS_URL);
    }

    // Legacy ru.yandex.clickhouse driver URL pointed at the analytics database
    // ({@code opik}) rather than the migration tracking database ({@code default}).
    // This is the raw-row seed channel the Testcontainers tests get from
    // {@code ClickHouseContainer.createConnection("")}: a few timestamps the HTTP
    // API only stamps server-side (a backdated run start, an old trial row, a raw
    // experiment_scores JSON string) can be written no other way.
    private static final String CLICKHOUSE_DATA_URL =
            "jdbc:clickhouse://localhost:8123/opik?user=opik&password=opik";

    /**
     * Opens a raw JDBC connection to the analytics {@code opik} database for the
     * handful of seed writes the HTTP API cannot express (server-stamped
     * timestamps and raw-JSON columns). The caller owns the connection and must
     * close it. Only used to write fixture rows; assertions go through the API.
     */
    public static Connection newClickHouseConnection() throws SQLException {
        return new ClickHouseConnectionImpl(CLICKHOUSE_DATA_URL);
    }
}
