#!/usr/bin/env bash
#
# Behavioral verifier for opik-fix-stall-reaper-liveness (shell runner).
#
# ssb_lib has no Maven/JUnit runner, so this script copies one JUnit 5
# integration-test class (plus its native-service boot shim) into the
# opik-backend test tree and runs it with Maven against the MySQL, ClickHouse
# and Redis that tests/test-setup.sh has already started (test.sh sources
# test-setup.sh before this runner). The exit code is the result: 0 when every
# test in the class passed, non-zero when any failed or the class did not run.
#
# The test class drives the reported symptoms through existing interfaces: the
# optimization, experiment and trace HTTP resource clients, the stalled-run
# reconcile method on the injected service, and the run's own re-read.
set -euo pipefail

log() { printf '[verify] %s\n' "$*"; }

# Repo layout: clone at /repo/opik, backend module at apps/opik-backend. The
# shell runner sets cwd to /repo/opik.
REPO_ROOT="/repo/${REPO_NAME:-opik}"
BACKEND_DIR="${REPO_ROOT}/apps/opik-backend"

# Test sources are staged alongside this script under /tests/verify/.
VERIFY_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# The test class declares `package com.comet.opik.domain;` (same package as
# the existing integration tests, so it can inject Guice beans and reuse the
# resource-client helpers). Copy it into the matching test dir.
TEST_PKG_DIR="${BACKEND_DIR}/src/test/java/com/comet/opik/domain"

TEST_CLASS="StallReaperLivenessVerifierTest"
SHIM_CLASS="NativeServiceAppExtensionShim"

# Existing repo test files that call the reaper service, the reaper job and the
# optimization DAO directly. `mvn test` compiles the whole src/test tree, not
# just the -Dtest= target, so any of these that no longer match the main
# sources would break test-compile before the class above runs. They are moved
# aside for the run and restored by the cleanup trap. The same three files are
# moved on every tree, whatever the main sources look like.
STALE_TESTS=(
    "${BACKEND_DIR}/src/test/java/com/comet/opik/api/resources/v1/jobs/OptimizationStalledReaperJobTest.java"
    "${BACKEND_DIR}/src/test/java/com/comet/opik/domain/OptimizationServiceUpdateLockTest.java"
    "${BACKEND_DIR}/src/test/java/com/comet/opik/domain/OptimizationStalledReaperServiceTest.java"
)

INJECTED=()
MOVED=()
CONFIG_PATCHED=""
MVN_LOG="$(mktemp)"
# Keep the script's own exit code. Under `set -e` a false test as the last
# command here would otherwise turn a passing run into exit 1.
cleanup() {
    local status=$?
    rm -f "$MVN_LOG"
    local f
    for f in "${INJECTED[@]:-}"; do
        if [ -n "$f" ]; then
            rm -f "$f"
        fi
    done
    # Restore every repo test file moved aside, so the repo is left as it was.
    for f in "${MOVED[@]:-}"; do
        if [ -n "$f" ] && [ -f "${f}.sbbak" ]; then
            mv -f "${f}.sbbak" "$f"
        fi
    done
    if [ -n "${CONFIG_PATCHED:-}" ] && [ -f "${CONFIG_PATCHED}.sbbak" ]; then
        mv -f "${CONFIG_PATCHED}.sbbak" "$CONFIG_PATCHED"
    fi
    return "$status"
}
trap cleanup EXIT

if [ ! -d "$BACKEND_DIR" ]; then
    log "ERROR: backend module not found at $BACKEND_DIR"
    exit 2
fi

mkdir -p "$TEST_PKG_DIR"
for src in "${TEST_CLASS}.java" "${SHIM_CLASS}.java"; do
    if [ ! -f "${VERIFY_DIR}/${src}" ]; then
        log "ERROR: test source ${src} missing from ${VERIFY_DIR}"
        exit 2
    fi
    cp "${VERIFY_DIR}/${src}" "${TEST_PKG_DIR}/${src}"
    INJECTED+=("${TEST_PKG_DIR}/${src}")
    log "copied ${src} -> ${TEST_PKG_DIR}"
done

for f in "${STALE_TESTS[@]}"; do
    if [ -f "$f" ]; then
        mv -f "$f" "${f}.sbbak"
        MOVED+=("$f")
        log "moved aside $(basename "$f")"
    fi
done

# The reaper config record is bean-validated at application boot (the
# `optimizationStalledReaper` field on the top-level config carries
# `@Valid @NotNull`, so its own field constraints fire even though the reaper
# runs disabled in tests). When the main sources declare one of the two
# settings below and the repo's test config has no value for it, the app would
# stop at boot with a "may not be null" error. Each setting is added to the
# reaper block only in that case, and only for the setting that is missing; a
# tree that does not declare it, or whose test config already sets it, is left
# alone. Restored by the cleanup trap.
#   * runningHardTimeout - a Duration of at least the test config's
#     runningTimeout (26h) and at most 30d.
#   * candidateScanFactor - an int in [1, 1000].
# Neither value decides a test: every reconcile call passes its own timeouts.
CONFIG_TEST_YML="${BACKEND_DIR}/src/test/resources/config-test.yml"
CONFIG_RECORD="${BACKEND_DIR}/src/main/java/com/comet/opik/infrastructure/OptimizationStalledReaperConfig.java"
needs_key() {
    [ -f "$CONFIG_RECORD" ] && grep -qw "$1" "$CONFIG_RECORD" \
        && ! grep -qE "^[[:space:]]*$1:" "$CONFIG_TEST_YML"
}
if [ -f "$CONFIG_TEST_YML" ]; then
    add_hard=0
    add_scan=0
    if needs_key runningHardTimeout; then add_hard=1; fi
    if needs_key candidateScanFactor; then add_scan=1; fi
    if [ "$add_hard" = 1 ] || [ "$add_scan" = 1 ]; then
        cp "$CONFIG_TEST_YML" "${CONFIG_TEST_YML}.sbbak"
        CONFIG_PATCHED="$CONFIG_TEST_YML"
        # Insert right under the block header, at the block's 2-space
        # indentation, so the edit does not depend on the block's other keys.
        awk -v add_hard="$add_hard" -v add_scan="$add_scan" '
            { print }
            /^optimizationStalledReaper:[[:space:]]*$/ {
                if (add_hard == "1") print "  runningHardTimeout: 48h"
                if (add_scan == "1") print "  candidateScanFactor: 10"
            }
        ' "${CONFIG_TEST_YML}.sbbak" > "$CONFIG_TEST_YML"
        log "added missing reaper settings to test config (runningHardTimeout=${add_hard}, candidateScanFactor=${add_scan})"
    else
        log "test config needs no extra reaper settings; leaving it untouched"
    fi
else
    log "WARNING: ${CONFIG_TEST_YML} not found; proceeding without config changes"
fi

cd "$BACKEND_DIR"

# Ignore reports baked into the image or left in the working tree. Only reports
# from this run may decide whether an offline failure was a test outcome.
rm -rf target/surefire-reports

# Run only this class. No `clean`: the image pre-warms test-compile, so reusing
# target/ keeps the run well inside the 1100s budget. No
# `-Dmaven.test.failure.ignore`: a failing test must make mvn exit non-zero.
# `-o` (offline) first; fall back to online only if offline resolution fails,
# never masking a test failure.
MVN_ARGS=(-B -Dsurefire.failIfNoSpecifiedTests=true -Dtest="${TEST_CLASS}" test)

log "running: mvn -o ${MVN_ARGS[*]}"
set +e
mvn -o "${MVN_ARGS[@]}" >"$MVN_LOG" 2>&1
rc=$?
set -e
cat "$MVN_LOG"

if [ "$rc" -ne 0 ]; then
    # A killed Maven process is an environment-capacity failure. Retrying it
    # online only repeats the OOM and obscures the useful exit code.
    if [ "$rc" -eq 137 ]; then
        log "ERROR: Maven was killed with exit 137; check the sandbox memory allocation" >&2
    # Tell a test failure apart from an offline dependency-resolution miss. Put
    # the short Surefire summary on stderr so the runner's recorded failure
    # names the failing test.
    elif ls target/surefire-reports/TEST-*.xml >/dev/null 2>&1; then
        log "tests executed; mvn exit ${rc} reflects test outcome"
        grep -hE 'Tests run:.*Failures:|<<< (FAILURE|ERROR)!' \
            target/surefire-reports/*.txt 2>/dev/null | head -20 >&2 || true
    else
        log "no surefire reports after offline run (likely dependency gap); retrying online"
        : >"$MVN_LOG"
        set +e
        mvn "${MVN_ARGS[@]}" >"$MVN_LOG" 2>&1
        rc=$?
        set -e
        cat "$MVN_LOG"
        if [ "$rc" -eq 137 ]; then
            log "ERROR: Maven was killed with exit 137; check the sandbox memory allocation" >&2
        elif [ "$rc" -ne 0 ] && ls target/surefire-reports/TEST-*.xml >/dev/null 2>&1; then
            grep -hE 'Tests run:.*Failures:|<<< (FAILURE|ERROR)!' \
                target/surefire-reports/*.txt 2>/dev/null | head -20 >&2 || true
        fi
    fi
fi

log "verifier exit ${rc}"
exit "$rc"
