#!/usr/bin/env bash
#
# Runtime service-startup shim for opik-fix-stall-reaper-liveness.
#
# The behavioral check boots opik's Dropwizard backend through its JUnit
# integration-test harness, which needs REAL MySQL + ClickHouse + Redis. The
# image bakes those three natively (Testcontainers / Docker-in-Docker is not
# available in the task container). This script starts them and blocks until all three
# are healthy at the endpoints config-test.yml expects:
#
#   * MySQL         localhost:3306   user/pass opik/opik   db opik
#   * ClickHouse    localhost:8123 (HTTP) / 9000 (native)  user/pass opik/opik
#                   db opik, embedded clickhouse-keeper on 9181
#   * Redis         localhost:6379   password opik
#
# It does NOT run DB migrations: the JUnit test owns migrations via its
# MigrationUtils path (the ClickHouse migration connection targets the `default`
# database with changelog param ANALYTICS_DB_DATABASE_NAME=opik, so Liquibase's
# DATABASECHANGELOG tracking table lands in `default` while migrated tables land
# in `opik`; pointing that connection at .../opik makes migration 000017 fail).
#
# Idempotent and safe to run before `mvn test`.
set -euo pipefail

log() { printf '[test-setup] %s\n' "$*"; }

# --- MySQL -----------------------------------------------------------------
start_mysql() {
    if mysqladmin --socket=/var/run/mysqld/mysqld.sock ping >/dev/null 2>&1; then
        log "MySQL already running"
        return 0
    fi
    log "starting MySQL..."
    mkdir -p /var/run/mysqld /var/log/mysql
    chown -R mysql:mysql /var/run/mysqld /var/log/mysql /var/lib/mysql
    gosu mysql mysqld \
        --datadir=/var/lib/mysql \
        --socket=/var/run/mysqld/mysqld.sock \
        --skip-networking=0 \
        >/var/log/mysql/mysqld.out 2>&1 &
    for _ in $(seq 1 60); do
        if mysqladmin --socket=/var/run/mysqld/mysqld.sock ping >/dev/null 2>&1; then
            break
        fi
        sleep 1
    done
    mysqladmin --socket=/var/run/mysqld/mysqld.sock ping >/dev/null 2>&1 \
        || { log "ERROR: MySQL did not come up"; return 1; }
    # Wait for TCP 3306 (the app connects over TCP, not the socket).
    for _ in $(seq 1 60); do
        if mysqladmin -h 127.0.0.1 -P 3306 -u opik -popik ping >/dev/null 2>&1; then
            break
        fi
        sleep 1
    done
    mysqladmin -h 127.0.0.1 -P 3306 -u opik -popik ping >/dev/null 2>&1 \
        || { log "ERROR: MySQL not reachable over TCP 3306 as opik"; return 1; }
    # Re-assert the DB exists (idempotent; a fresh data dir would lack it).
    mysql --socket=/var/run/mysqld/mysqld.sock -u root -popik \
        -e "CREATE DATABASE IF NOT EXISTS opik;" >/dev/null 2>&1 || true
    log "MySQL ready (localhost:3306, db opik)"
}

# --- ClickHouse ------------------------------------------------------------
ch_client() { clickhouse-client --user opik --password opik "$@"; }

start_clickhouse() {
    if ch_client --query "SELECT 1" >/dev/null 2>&1; then
        log "ClickHouse already running"
    else
        log "starting ClickHouse (embedded keeper)..."
        mkdir -p /var/lib/clickhouse /var/log/clickhouse-server
        chown -R clickhouse:clickhouse /var/lib/clickhouse /var/log/clickhouse-server /etc/clickhouse-server
        gosu clickhouse clickhouse-server \
            --config-file=/etc/clickhouse-server/config.xml --daemon
        for _ in $(seq 1 60); do
            if ch_client --query "SELECT 1" >/dev/null 2>&1; then
                break
            fi
            sleep 1
        done
    fi
    ch_client --query "SELECT 1" >/dev/null 2>&1 \
        || { log "ERROR: ClickHouse did not come up on 8123/9000"; return 1; }
    # Embedded keeper must answer on 9181 for the ON CLUSTER / Replicated
    # migrations the JUnit harness runs.
    for _ in $(seq 1 60); do
        if echo ruok | { exec 3<>/dev/tcp/127.0.0.1/9181 && cat >&3 && head -c 4 <&3; } 2>/dev/null | grep -q imok; then
            break
        fi
        # Fall back to a keeper macro probe if 4lw is disabled.
        if ch_client --query "SELECT count() FROM system.macros WHERE macro IN ('cluster','shard','replica')" 2>/dev/null | grep -q '^3$'; then
            break
        fi
        sleep 1
    done
    # Re-assert the analytics DB exists (idempotent).
    ch_client --query "CREATE DATABASE IF NOT EXISTS opik" >/dev/null 2>&1 || true
    log "ClickHouse ready (localhost:8123/9000, db opik, keeper 9181)"
}

# --- Redis -----------------------------------------------------------------
start_redis() {
    if redis-cli -a opik ping 2>/dev/null | grep -q PONG; then
        log "Redis already running"
        return 0
    fi
    log "starting Redis..."
    redis-server /etc/redis/redis.conf --daemonize yes
    for _ in $(seq 1 30); do
        if redis-cli -a opik ping 2>/dev/null | grep -q PONG; then
            break
        fi
        sleep 1
    done
    redis-cli -a opik ping 2>/dev/null | grep -q PONG \
        || { log "ERROR: Redis did not come up on 6379"; return 1; }
    log "Redis ready (localhost:6379)"
}

start_mysql
start_clickhouse
start_redis

log "services ready"
# Use `return` instead of `exit` so this script is safe to `source` from
# test.sh (a sourced `exit` would terminate the parent shell) while still
# exiting cleanly when run directly (bash treats `return` outside a function
# as `exit` with the same code when the script is run directly, but not when sourced).
return 0 2>/dev/null || true
