## Task

Our optimization Studio runs in the Opik backend (`apps/opik-backend`) have two problems, and users keep reporting both.

First, the status spinner is wrong in both directions.
Some runs that are clearly still working get marked failed after a few hours.
Other runs whose worker died are never marked failed and spin forever.

Second, runs disappear.
A run that exists drops off the runs list, or opening it returns not-found, even though nobody deleted it.
We mostly see this on runs whose worker was killed partway through a trial, or whose trials ended up with odd score values.

Please fix both in the backend.
This is how runs should behave once it's fixed:

- A run counts as alive while it keeps producing work, meaning a new trial or a new evaluated item in one of its trials within the stalled-run check's running timeout.
  It doesn't matter how long ago its status last changed.
- This holds for a run still shown as initialized as well.
  If it is producing trials, the worker did start, and it should not be failed as "never started".
- Only new work counts.
  Editing an old trial, for example renaming it, is not activity, and one run's trials never keep a different run alive.
- A run that shows no new work for longer than the check's timeouts is still marked failed, as today.
- No run goes on forever, though.
  Once a run has been going for more than a day since it started, it is marked failed even if it is still producing work, and that applies to runs still shown as initialized too.
- A run's start time (`createdAt`) stays the same when the run is saved again.
  Sending a finished run (completed, cancelled or failed) again under the same id with an in-progress status is a restart, and the restart gets a fresh start time.
- When the backend fails a run, the run's error info carries a readable message saying why.
  The message should tell apart a run that never started, a run that stopped making progress, and a run that went past the one-day limit.
- A failure the backend detected is a guess.
  If the worker later reports the run as running or completed, the run follows the worker and the backend's error info is cleared.
  A restart clears it too.
- A failure the worker reported itself, or a user's cancel, stays final as it does now.
  A restart keeps the worker's error info.
- A run the backend failed can still be cancelled, and cancelling it sends the worker its usual cancel signal.
  Cancelling a run whose worker reported the failure is still refused with a 409, as today.
- A run never drops out of the API, whether it is fetched by id or listed.
  If none of its traces finished, its duration numbers are just empty.
  A score stored as NaN is left out of the run's scores while the other scores still show.
  A summary number too large to represent is shown as empty while the rest of the run, durations included, still shows.

The repo is at a fixed commit with dependencies already installed, and there is no network access.
