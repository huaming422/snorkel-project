## Task

We'd like to save trace_processor dataframes to disk and load them back later, using Apache Arrow as the file format.
Please add a serializer that writes a finalized dataframe out as an Arrow file, and a deserializer that turns that file back into a dataframe, both in `src/trace_processor/core/dataframe/`.

Callers use `ArrowSerializer::Prepare` to learn the size of the file up front, then `Write` to stream exactly that many bytes to their own sink, in whatever chunks suit the serializer.
If the sink returns an error, `Write` stops and passes that same status back.
The same serializer should work for one dataframe after another.
Using it wrong has to return an error status rather than crash, for example `Write` without a matching `Prepare`, a dataframe that isn't finalized, or a string pool other than the one the dataframe was built with.

`DeserializeFromArrow` gets the bytes through a `util::TraceBlobViewReader`, which may hold them in several chunks, may not start at offset zero, and doesn't promise any alignment.
It also takes the full `DataframeSpec`, since Arrow has nowhere to keep perfetto's own column properties such as null storage, sort order and duplicate state.
It only has to read files this serializer writes, but anything malformed, truncated or inconsistent must come back as an error status, and so must a spec that is invalid or doesn't match the file.
It must never crash or read outside the bytes it was given.

Other code will include these from `src/trace_processor/core/dataframe/arrow_serializer.h` and `src/trace_processor/core/dataframe/arrow_deserializer.h`, using `StringPool` from `src/trace_processor/containers/string_pool.h` and the reader from `src/trace_processor/util/trace_blob_view_reader.h`.
The public entry points should be exactly these:

    class ArrowSerializer {
     public:
      using WriteFn = std::function<base::Status(const uint8_t* data, size_t size)>;
      base::StatusOr<size_t> Prepare(const Dataframe& dataframe, const StringPool* pool);
      base::Status Write(const Dataframe& dataframe, const StringPool* pool, const WriteFn& write);
    };

    base::StatusOr<Dataframe> DeserializeFromArrow(
        const util::TraceBlobViewReader& reader, StringPool* pool, const DataframeSpec& spec);

## User stories / requirements

- Writing a finalized dataframe to Arrow and reading it back gives the same rows, values and missing entries, including for a dataframe with no rows or only the id column.
  The result is finalized, keeps its strings in the pool passed to the reader, and can be used like any other dataframe.
- The file is a real Arrow file that other Arrow tools can open, in the IPC file format rather than the stream format, with one record batch and strings stored as `Utf8`.
  An independent reader sees every stored column with its values and nulls as written, and no id column.
