## Task

Add a serializer that writes a finalized trace_processor dataframe out as an Apache Arrow file, and a deserializer that turns that file back into a dataframe, both in `src/trace_processor/core/dataframe/`.

The point is to trade tables with standard Arrow tooling in both directions, so a table someone saved from Python should load as well as one we wrote ourselves.

`ArrowSerializer::Prepare` returns the file size, and `Write` then streams exactly that many bytes to the caller's sink, in chunks of any size.
A sink error stops `Write` and comes back unchanged, and one serializer can be reused for one dataframe after another.
Since this is a library call, misuse returns an error status the caller can handle instead of aborting the process, whether that's `Write` without a matching `Prepare`, a dataframe that isn't finalized, or a string pool other than the one the dataframe was built with.

`DeserializeFromArrow` reads the bytes through a `util::TraceBlobViewReader`, so they can arrive in several chunks, at any offset and without alignment.
It takes the full `DataframeSpec` because Arrow has no place for perfetto's own column properties such as null storage, sort order and duplicate state.
It has to load what PyArrow writes with its default options, such as `pyarrow.ipc.new_file(...).write_table(table)`, which can spread the rows over several record batches or none and dictionary-encode strings with any integer index type.
The file's columns follow the spec's order without the id column, and each has to carry the exact Arrow counterpart of its dataframe type, an integer of the same width and signedness, a double-precision float, or `Utf8` for strings, plain or dictionary-encoded.
Files can come from anywhere, so anything the reader can't load faithfully returns an error status instead of crashing or reading past the input.
That includes bytes that aren't Arrow, a file that is cut short or whose sizes, counts or indices don't add up or point outside the data, columns whose types, count or nulls don't fit the spec, and a spec that isn't valid.

Other code will include these from `src/trace_processor/core/dataframe/arrow_serializer.h` and `src/trace_processor/core/dataframe/arrow_deserializer.h`, using `StringPool` from `src/trace_processor/containers/string_pool.h` and the reader from `src/trace_processor/util/trace_blob_view_reader.h`.
The public entry points should be exactly these:

    class ArrowSerializer {
     public:
      using WriteFn = std::function<base::Status(const uint8_t* data, size_t size)>;
      base::StatusOr<size_t> Prepare(const Dataframe& dataframe, const StringPool* pool);
      base::Status Write(const Dataframe& dataframe, const StringPool* pool, const WriteFn& write);
    };

    base::StatusOr<Dataframe> DeserializeFromArrow(
        const util::TraceBlobViewReader& reader, StringPool* pool, const DataframeSpec& spec);

## User stories / requirements

- Writing a finalized dataframe to Arrow and reading it back gives the same rows, values and missing entries, including for a dataframe with no rows or only the id column.
  The result is finalized, keeps its strings in the pool passed to the reader, and can be used like any other dataframe.
- The file is a real Arrow file that other Arrow tools can open, in the IPC file format rather than the stream format, with one record batch and strings stored as `Utf8`.
  An independent reader sees every stored column with its values and nulls as written, and no id column.
