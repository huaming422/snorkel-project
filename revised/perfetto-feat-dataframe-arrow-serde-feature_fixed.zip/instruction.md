## Task

We'd like to save trace_processor dataframes to disk and load them back later, using Apache Arrow as the file format.
Please add a serializer that writes a finalized dataframe out as an Arrow file, and a deserializer that turns that file back into a dataframe.
Both go in `src/trace_processor/core/dataframe/`, with `arrow_serializer.h` and `arrow_serializer.cc` for the writer and `arrow_deserializer.h` and `arrow_deserializer.cc` for the reader.

The output should be a regular Arrow IPC file, the "file" variant with the `ARROW1` magic at both ends, holding the whole dataframe in a single record batch.
Numeric columns become Arrow numeric arrays, string columns become Arrow `Utf8`, and columns that can hold missing values get a validity bitmap and a null count.
Some columns only store their present values (sparse null storage).
Those have to be written out in Arrow's dense layout, with one slot per row and the missing rows marked in the bitmap.
The implicit id column is only the row number, so leave it out of the file and have the reader rebuild it from the row count.
That includes a dataframe with no rows, and one with nothing but the id column.

`ArrowSerializer` works in two steps.
`Prepare` takes a finalized dataframe and the string pool it was built with, and returns the exact size of the file in bytes.
`Write` then hands the file to a sink callback from the caller, in as many pieces as it likes, and the pieces add up to exactly that size.
If the sink returns an error, `Write` stops right there and returns that same status.
One serializer object can be reused for several dataframes, one `Prepare` and `Write` pair after another.
Callers won't change the dataframe or the pool between the two steps.
Misuse has to come back as an error status, not a crash.
That covers `Write` with no `Prepare` before it, `Prepare` on a dataframe that isn't finalized or with a pool the dataframe wasn't built with, and `Write` with a different dataframe or pool than the one last prepared.

`DeserializeFromArrow` reads the file through a `util::TraceBlobViewReader`, interns the strings into the pool it is given, and returns a new, finalized dataframe.
It also takes the full `DataframeSpec`, because Arrow has nowhere to keep perfetto's own column properties such as null storage, sort order and duplicate state.
The reader may hold the bytes in several chunks, its window doesn't have to start at offset zero, and nothing about the data's alignment is guaranteed.
The deserializer only has to read files this serializer writes.
Anything malformed, truncated or inconsistent has to be rejected with an error status, and so does a spec that is invalid or doesn't match the file's columns.
It must never crash or read outside the bytes it was given.

Strings live in the existing `StringPool` from `src/trace_processor/containers/string_pool.h`, and the reader type is the `util::TraceBlobViewReader` in `src/trace_processor/util/trace_blob_view_reader.h`.
The public entry points should be exactly these:

    class ArrowSerializer {
     public:
      using WriteFn = std::function<base::Status(const uint8_t* data, size_t size)>;
      base::StatusOr<size_t> Prepare(const Dataframe& dataframe, const StringPool* pool);
      base::Status Write(const Dataframe& dataframe, const StringPool* pool, const WriteFn& write);
    };

    base::StatusOr<Dataframe> DeserializeFromArrow(
        const util::TraceBlobViewReader& reader, StringPool* pool, const DataframeSpec& spec);

## User stories / requirements

- Writing a finalized dataframe to Arrow and reading it back gives the same dataframe: the same number of rows, the same value in every column, and missing entries in the same places.
  The result is finalized and can be used like any other dataframe.
- The file is a real Arrow file, not a format only this code understands.
  An independent Arrow reader can open it and read back every row and column as written, without knowing how it was produced.
