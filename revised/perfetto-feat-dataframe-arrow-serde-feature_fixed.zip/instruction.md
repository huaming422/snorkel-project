## Task

Add a serializer that writes a finalized trace_processor dataframe out as an Apache Arrow file, and a deserializer that turns that file back into a dataframe, both in `src/trace_processor/core/dataframe/`.

Callers use `ArrowSerializer::Prepare` to learn the size of the file up front, then `Write` to stream exactly that many bytes to their own sink, in whatever chunks suit the serializer.
If the sink returns an error, `Write` stops and passes that same status back.
The same serializer should work for one dataframe after another.
Using it wrong has to return an error status rather than crash, for example `Write` without a matching `Prepare`, a dataframe that isn't finalized, or a string pool other than the one the dataframe was built with.

`DeserializeFromArrow` gets the bytes through a `util::TraceBlobViewReader`, which may hold them in several chunks, may not start at offset zero, and doesn't promise any alignment.
It also takes the full `DataframeSpec`, since Arrow has nowhere to keep perfetto's own column properties such as null storage, sort order and duplicate state.
Besides our own files, it has to load the Arrow IPC files PyArrow writes with its default options, for example a table saved from Python with `pyarrow.ipc.new_file(...).write_table(table)`.
Those can split the rows over several record batches, or have no batch at all when the table is empty, and their string columns can be dictionary-encoded with any integer index type, which is how PyArrow saves categorical data.
The file's columns line up in order with the spec's columns other than the id column, and each one needs the matching Arrow type: a signed 32-bit `Int` for Int32, an unsigned 32-bit `Int` for Uint32, a signed 64-bit `Int` for Int64, a double-precision `FloatingPoint` for Double, and `Utf8` (plain or dictionary-encoded) for String.
A column with any other type is an error, and so is a null in a column the spec says can't have one.
Bytes that aren't an Arrow file at all, a file that is cut short, and sizes, offsets, counts or dictionary indices that don't add up or point outside the data must come back as an error status.
So must a spec that is invalid or has a different number of columns than the file.
It must never crash or read outside the bytes it was given.

Other code will include these from `src/trace_processor/core/dataframe/arrow_serializer.h` and `src/trace_processor/core/dataframe/arrow_deserializer.h`, using `StringPool` from `src/trace_processor/containers/string_pool.h` and the reader from `src/trace_processor/util/trace_blob_view_reader.h`.
The public entry points should be exactly these:

    class ArrowSerializer {
     public:
      using WriteFn = std::function<base::Status(const uint8_t* data, size_t size)>;
      base::StatusOr<size_t> Prepare(const Dataframe& dataframe, const StringPool* pool);
      base::Status Write(const Dataframe& dataframe, const StringPool* pool, const WriteFn& write);
    };

    base::StatusOr<Dataframe> DeserializeFromArrow(
        const util::TraceBlobViewReader& reader, StringPool* pool, const DataframeSpec& spec);

## User stories / requirements

- Writing a finalized dataframe to Arrow and reading it back gives the same rows, values and missing entries, including for a dataframe with no rows or only the id column.
  The result is finalized, keeps its strings in the pool passed to the reader, and can be used like any other dataframe.
- The file is a real Arrow file that other Arrow tools can open, in the IPC file format rather than the stream format, with one record batch and strings stored as `Utf8`.
  An independent reader sees every stored column with its values and nulls as written, and no id column.
