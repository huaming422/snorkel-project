## Task

Add a serializer that writes a finalized trace_processor dataframe out as an Apache Arrow file, and a deserializer that turns that file back into a dataframe, both in `src/trace_processor/core/dataframe/`.

We want to trade tables with standard Arrow tooling in both directions, so a table saved from Python should load as well as one we wrote ourselves.

Callers need the file size before any bytes go out, so `Prepare` reports it and `Write` sends exactly that many bytes to the caller's sink.
If the sink fails, `Write` hands back that same error.
One serializer can be reused across dataframes.
Misuse comes back as an error status rather than aborting, for example `Write` without `Prepare`, an unfinalized dataframe, or a string pool the dataframe wasn't built with.

The deserializer's input may be split across chunks, start at any offset and have no alignment.
It has to load the files PyArrow writes by default, which can hold several record batches or none and dictionary-encoded strings with any integer index type.
The file's columns are the spec's columns in order without the id column, each with the Arrow type that matches its column type.
The spec also supplies what Arrow can't hold, such as null storage, sort order and duplicate state.
Be strict about input.
Bytes that are malformed or cut short, a file that doesn't match the spec, or an invalid spec all return an error status, never a crash or a read past the data.

Other code will include these from `src/trace_processor/core/dataframe/arrow_serializer.h` and `src/trace_processor/core/dataframe/arrow_deserializer.h`, with exactly these entry points:

    class ArrowSerializer {
     public:
      using WriteFn = std::function<base::Status(const uint8_t* data, size_t size)>;
      base::StatusOr<size_t> Prepare(const Dataframe& dataframe, const StringPool* pool);
      base::Status Write(const Dataframe& dataframe, const StringPool* pool, const WriteFn& write);
    };

    base::StatusOr<Dataframe> DeserializeFromArrow(
        const util::TraceBlobViewReader& reader, StringPool* pool, const DataframeSpec& spec);

## User stories / requirements

- Writing a finalized dataframe to Arrow and reading it back gives the same rows, values and missing entries, including for a dataframe with no rows or only the id column.
  The result is finalized, keeps its strings in the pool passed to the reader, and can be used like any other dataframe.
- The file is a real Arrow file that other Arrow tools can open, in the IPC file format rather than the stream format, with one record batch and strings stored as `Utf8`.
  An independent reader sees every stored column with its values and nulls as written, and no id column.
