/*
 * Copyright (C) 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Standalone host program that drives the public serialize/deserialize entry
// points for the validation stories. It builds a named example frame, writes
// the serialized bytes to the path given on the command line, reads them back
// through the public reader entry point, and prints a small JSON report to
// stdout describing the frame it read back. The program itself asserts nothing:
// the pytest body reads the JSON (round-trip story) or re-opens the written
// bytes with an independent reader (interop story) and does the comparing.
//
// It binds only to the two public entry points and the pre-existing public
// frame/pool/reader APIs. It includes no module-private header, so it stays
// valid against any conforming implementation of the entry points. When the
// entry points do not exist, this program fails to compile and the build step
// surfaces that loudly.

#include "src/trace_processor/core/dataframe/arrow_deserializer.h"
#include "src/trace_processor/core/dataframe/arrow_serializer.h"

#include <cstdint>
#include <cstdio>
#include <cstring>
#include <optional>
#include <string>
#include <vector>

#include "perfetto/base/status.h"
#include "perfetto/ext/base/string_view.h"
#include "perfetto/trace_processor/trace_blob.h"
#include "perfetto/trace_processor/trace_blob_view.h"
#include "src/trace_processor/containers/string_pool.h"
#include "src/trace_processor/core/dataframe/dataframe.h"
#include "src/trace_processor/core/dataframe/specs.h"
#include "src/trace_processor/util/trace_blob_view_reader.h"

namespace perfetto::trace_processor::core::dataframe {
namespace {

// Example frame specs. The column names here are a harness-owned fixture input:
// the reader entry point reconstructs the frame from the caller's spec, so these
// names are not part of the contract under test.
inline constexpr auto kMixed = CreateTypedDataframeSpec(
    {"_auto_id", "ts", "name", "value"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Int64{}, NonNull{}, Sorted{}),
    CreateTypedColumnSpec(String{}, NonNull{}, Unsorted{}),
    CreateTypedColumnSpec(Double{}, DenseNull{}, Unsorted{}));

inline constexpr auto kSparseGap = CreateTypedDataframeSpec(
    {"_auto_id", "val"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Int64{}, SparseNullWithPopcountAlways{}, Unsorted{}));

inline constexpr auto kTypes = CreateTypedDataframeSpec(
    {"_auto_id", "count", "delta", "label", "note", "ratio"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Uint32{}, NonNull{}, Unsorted{}),
    CreateTypedColumnSpec(Int32{}, DenseNull{}, Unsorted{}),
    CreateTypedColumnSpec(String{}, SparseNullWithPopcountAlways{}, Unsorted{}),
    CreateTypedColumnSpec(String{}, DenseNull{}, Unsorted{}),
    CreateTypedColumnSpec(Double{}, SparseNullWithPopcountAlways{}, Unsorted{}));

// Serialize a finalized frame to a flat byte vector via the public two-phase
// entry points. Returns false on any non-ok status.
bool Serialize(Dataframe* frame,
               const StringPool& pool,
               std::vector<uint8_t>* out) {
  frame->Finalize();
  ArrowSerializer serializer;
  auto prepared = serializer.Prepare(*frame, &pool);
  if (!prepared.ok()) {
    return false;
  }
  out->clear();
  base::Status status = serializer.Write(
      *frame, &pool, [&](const uint8_t* data, size_t size) {
        out->insert(out->end(), data, data + size);
        return base::OkStatus();
      });
  if (!status.ok()) {
    return false;
  }
  return out->size() == *prepared;
}

bool WriteFile(const std::string& path, const std::vector<uint8_t>& bytes) {
  FILE* f = std::fopen(path.c_str(), "wb");
  if (f == nullptr) {
    return false;
  }
  bool ok = bytes.empty() ||
            std::fwrite(bytes.data(), 1, bytes.size(), f) == bytes.size();
  std::fclose(f);
  return ok;
}

util::TraceBlobViewReader MakeReader(const std::vector<uint8_t>& bytes) {
  util::TraceBlobViewReader reader;
  if (!bytes.empty()) {
    reader.PushBack(
        TraceBlobView(TraceBlob::CopyFrom(bytes.data(), bytes.size())));
  }
  return reader;
}

// Serialize `src` to `path`, read it back, and store the recovered frame in
// `*dst` (with its string pool in `*out_pool`). Returns 0 on success.
int RoundTrip(Dataframe* src,
              const StringPool& pool,
              const std::string& path,
              StringPool* out_pool,
              Dataframe* dst) {
  std::vector<uint8_t> bytes;
  if (!Serialize(src, pool, &bytes)) {
    std::fprintf(stderr, "harness: serialize failed\n");
    return 1;
  }
  if (!WriteFile(path, bytes)) {
    std::fprintf(stderr, "harness: write failed\n");
    return 1;
  }
  auto reader = MakeReader(bytes);
  auto dst_or = DeserializeFromArrow(reader, out_pool, src->CreateSpec());
  if (!dst_or.ok()) {
    std::fprintf(stderr, "harness: deserialize failed\n");
    return 1;
  }
  *dst = std::move(*dst_or);
  return 0;
}

int RunMixed(const std::string& path) {
  StringPool pool;
  auto alpha = pool.InternString(base::StringView("alpha"));
  auto beta = pool.InternString(base::StringView("beta"));
  auto gamma = pool.InternString(base::StringView("gamma"));

  auto src = Dataframe::CreateFromTypedSpec(kMixed, &pool);
  src.InsertUnchecked(kMixed, std::monostate{}, int64_t{100}, alpha,
                      std::optional<double>{0.5});
  src.InsertUnchecked(kMixed, std::monostate{}, int64_t{200}, beta,
                      std::optional<double>{});
  src.InsertUnchecked(kMixed, std::monostate{}, int64_t{300}, gamma,
                      std::optional<double>{-2.25});

  StringPool out_pool;
  Dataframe dst = Dataframe::CreateFromTypedSpec(kMixed, &out_pool);
  int rc = RoundTrip(&src, pool, path, &out_pool, &dst);
  if (rc != 0) {
    return rc;
  }

  // Build each column as a JSON array, generically over the recovered row
  // count so no fixture assumption about which cells are present leaks into the
  // formatting. The pytest body re-serializes with a canonical formatter, so
  // C++ float formatting never enters the comparison.
  std::string ts = "[";
  std::string name = "[";
  std::string value = "[";
  for (uint32_t i = 0; i < dst.row_count(); ++i) {
    if (i != 0) {
      ts += ", ";
      name += ", ";
      value += ", ";
    }
    char buf[64];
    std::snprintf(buf, sizeof(buf), "%lld",
                  static_cast<long long>(dst.GetCellUnchecked<1>(kMixed, i)));
    ts += buf;
    name += "\"";
    name += out_pool.Get(dst.GetCellUnchecked<2>(kMixed, i)).ToStdString();
    name += "\"";
    auto v = dst.GetCellUnchecked<3>(kMixed, i);
    if (v.has_value()) {
      std::snprintf(buf, sizeof(buf), "%.17g", *v);
      value += buf;
    } else {
      value += "null";
    }
  }
  ts += "]";
  name += "]";
  value += "]";

  std::printf("{\"rows\": %u, \"ts\": %s, \"name\": %s, \"value\": %s}\n",
              dst.row_count(), ts.c_str(), name.c_str(), value.c_str());
  return 0;
}

int RunSparseGap(const std::string& path) {
  StringPool pool;
  auto src = Dataframe::CreateFromTypedSpec(kSparseGap, &pool);
  // 70 rows: present at logical rows 0, 65, 69 only. The present entries
  // straddle the first 64-bit validity-word boundary (row 65 lives in the
  // second word), which a dense-only or mis-popcounted implementation gets
  // wrong.
  constexpr uint32_t kRowCount = 70;
  for (uint32_t i = 0; i < kRowCount; ++i) {
    std::optional<int64_t> cell;
    if (i == 0) {
      cell = int64_t{-7};
    } else if (i == 65) {
      cell = int64_t{650000};
    } else if (i == 69) {
      cell = int64_t{99};
    }
    src.InsertUnchecked(kSparseGap, std::monostate{}, cell);
  }

  StringPool out_pool;
  Dataframe dst = Dataframe::CreateFromTypedSpec(kSparseGap, &out_pool);
  int rc = RoundTrip(&src, pool, path, &out_pool, &dst);
  if (rc != 0) {
    return rc;
  }

  uint32_t present = 0;
  for (uint32_t i = 0; i < dst.row_count(); ++i) {
    if (dst.GetCellUnchecked<1>(kSparseGap, i).has_value()) {
      ++present;
    }
  }
  auto c0 = dst.GetCellUnchecked<1>(kSparseGap, 0);
  auto c65 = dst.GetCellUnchecked<1>(kSparseGap, 65);
  auto c69 = dst.GetCellUnchecked<1>(kSparseGap, 69);

  std::printf(
      "{\"rows\": %u, \"present_count\": %u, "
      "\"present\": {\"0\": %lld, \"65\": %lld, \"69\": %lld}}\n",
      dst.row_count(), present, static_cast<long long>(c0.value_or(0)),
      static_cast<long long>(c65.value_or(0)),
      static_cast<long long>(c69.value_or(0)));
  return 0;
}

// Column types and null kinds the other cases leave out: unsigned and signed
// 32-bit integers, sparse and dense nullable strings, and a sparse double. The
// interop story reads this file with the independent reader; the report only
// carries the recovered row count.
int RunTypes(const std::string& path) {
  StringPool pool;
  auto x = pool.InternString(base::StringView("x"));
  auto yz = pool.InternString(base::StringView("yz"));
  auto qr = pool.InternString(base::StringView("qr"));
  auto st = pool.InternString(base::StringView("st"));

  auto src = Dataframe::CreateFromTypedSpec(kTypes, &pool);
  src.InsertUnchecked(kTypes, std::monostate{}, uint32_t{4000000000u},
                      std::optional<int32_t>{-5},
                      std::optional<StringPool::Id>{x},
                      std::optional<StringPool::Id>{},
                      std::optional<double>{1.5});
  src.InsertUnchecked(kTypes, std::monostate{}, uint32_t{7},
                      std::optional<int32_t>{},
                      std::optional<StringPool::Id>{},
                      std::optional<StringPool::Id>{qr},
                      std::optional<double>{});
  src.InsertUnchecked(kTypes, std::monostate{}, uint32_t{0},
                      std::optional<int32_t>{2147483647},
                      std::optional<StringPool::Id>{yz},
                      std::optional<StringPool::Id>{st},
                      std::optional<double>{-0.25});

  StringPool out_pool;
  Dataframe dst = Dataframe::CreateFromTypedSpec(kTypes, &out_pool);
  int rc = RoundTrip(&src, pool, path, &out_pool, &dst);
  if (rc != 0) {
    return rc;
  }
  std::printf("{\"rows\": %u}\n", dst.row_count());
  return 0;
}

}  // namespace
}  // namespace perfetto::trace_processor::core::dataframe

int main(int argc, char** argv) {
  using namespace perfetto::trace_processor::core::dataframe;
  if (argc != 3) {
    std::fprintf(stderr, "usage: %s <case> <output-file>\n", argv[0]);
    return 2;
  }
  const std::string which = argv[1];
  const std::string path = argv[2];
  if (which == "mixed") {
    return RunMixed(path);
  }
  if (which == "sparse_gap") {
    return RunSparseGap(path);
  }
  if (which == "types") {
    return RunTypes(path);
  }
  std::fprintf(stderr, "harness: unknown case '%s'\n", which.c_str());
  return 2;
}
