#!/usr/bin/env bash
# validation-setup.sh - prepares the environment for the two validation stories.
#
# Runs AFTER tests/test-setup.sh (which generated out/dist and linked the unit
# tests) and inside the validation step, where the network is available
# (allow_internet = true). Two jobs:
#
#   1. Build the standalone driver program the stories shell out to. Its source
#      is shipped under /tests/validate/; we stage it into the module directory,
#      add a host-executable target to the module BUILD.gn (idempotently, in a
#      clearly marked block), regenerate, and build just that target. On a tree
#      without the two public entry points this build fails loudly here rather
#      than as an opaque per-story error.
#
#   2. Install the independent columnar reader the interop story uses to re-open
#      the written bytes. It is a test-only tool (the module itself never uses
#      it), pinned exact, installed into the isolated verifier interpreter
#      offline-first with a logged online fallback.
#
# No assertion logic lives here.
set -euo pipefail

cd /repo/perfetto

VENV_PY="${VERIFIER_PYTHON:-/opt/tooling/venv/bin/python}"
_SETUP_PY="${VERIFIER_PYTHON:-python3}"

DF_DIR="src/trace_processor/core/dataframe"
HARNESS_TU="arrow_roundtrip_harness.cc"
SRC_TU="/tests/validate/${HARNESS_TU}"
DST_TU="${DF_DIR}/${HARNESS_TU}"
BUILD_GN="${DF_DIR}/BUILD.gn"
HARNESS_TARGET="arrow_roundtrip_harness"
HARNESS_BIN="out/dist/${HARNESS_TARGET}"

# This script is SOURCED by the harness driver (not executed as a subprocess),
# so a bare `exit` would terminate the whole driver before it records any
# result. Every unwind below therefore uses `return`, which the caller invokes
# as `. setup.sh || true` and then proceeds to run the stories. That is the
# intended shape: the driver program is built BEST-EFFORT here, and on a tree
# that has not introduced the public entry points the program cannot link.
# `run_case` then raises at story-execution time, which is exactly the outcome
# the stories are written to treat as a failure. A genuine packaging fault (a
# missing source file) shows up on a tree that has the entry points, where the
# same best-effort build fails and every story fails loudly.

# ── 1. Stage + wire the driver program ──────────────────────────────────────
if [ ! -f "$SRC_TU" ]; then
    echo "validation-setup: driver source $SRC_TU missing; stories will report the absence" >&2
    return 0 2>/dev/null || exit 0
fi
cp "$SRC_TU" "$DST_TU"

if [ ! -f "$BUILD_GN" ]; then
    echo "validation-setup: $BUILD_GN missing; stories will report the absence" >&2
    return 0 2>/dev/null || exit 0
fi

# Append an import + a host-executable target to the module BUILD.gn, scoped to
# a marked block and applied only when absent, so re-runs and any existing
# BUILD.gn edits never double-insert.
"$_SETUP_PY" - "$BUILD_GN" "$HARNESS_TU" "$HARNESS_TARGET" <<'PY'
import sys

path, tu, target = sys.argv[1], sys.argv[2], sys.argv[3]
marker = "# ssb-validation-harness"
text = open(path).read()
if marker in text:
    sys.exit(0)

import_line = 'import("../../../../gn/perfetto_host_executable.gni")'
block = f'''
{marker} - standalone driver for the Arrow validation stories (added by
# validation-setup.sh; not part of the task's source tree).
perfetto_host_executable("{target}") {{
  testonly = true
  sources = [ "{tu}" ]
  deps = [
    ":dataframe",
    "../../../../gn:default_deps",
    "../../../base",
    "../../containers",
    "../../util:blob",
    "../../util:trace_blob_view_reader",
    "../../../../include/perfetto/trace_processor:util",
  ]
}}
'''

# Put the import after the first existing import() line for tidiness, else at the
# top; append the target block at end of file.
lines = text.splitlines(keepends=True)
out, inserted = [], False
for ln in lines:
    out.append(ln)
    if not inserted and ln.lstrip().startswith("import("):
        out.append(import_line + "\n")
        inserted = True
if not inserted:
    out.insert(0, import_line + "\n")
text = "".join(out)
if not text.endswith("\n"):
    text += "\n"
text += block
open(path, "w").write(text)
PY

echo "validation-setup: regenerating build graph..."
if ! tools/gn gen out/dist \
    --args='is_debug=true is_hermetic_clang=false is_clang=true cc="clang" cxx="clang++"' \
    > /tmp/validation-setup-gn.log 2>&1; then
    echo "validation-setup: gn gen did not complete; stories will report the absence" >&2
    tail -n 120 /tmp/validation-setup-gn.log >&2
    return 0 2>/dev/null || exit 0
fi

# Best-effort build of the driver program. On a tree that has not introduced the
# public entry points this cannot link; that is reported by the stories at
# execution time (run_case raises), so do NOT unwind the whole driver here.
# Log in full and let story execution be the authority.
echo "validation-setup: building ${HARNESS_TARGET}..."
if ! tools/ninja -C out/dist "$HARNESS_TARGET" > /tmp/validation-setup-ninja.log 2>&1; then
    echo "validation-setup: driver did not build against this tree; stories will" >&2
    echo "validation-setup: report the absence at execution time. Build log tail:" >&2
    tail -n 160 /tmp/validation-setup-ninja.log >&2
fi

if [ ! -x "$HARNESS_BIN" ]; then
    echo "validation-setup: ${HARNESS_BIN} not present; stories will report the absence" >&2
else
    echo "validation-setup: driver built at ${HARNESS_BIN}"
fi

# ── 2. Install the independent columnar reader (test-only) ───────────────────
# Exact pin; wheel-only; offline from the local cache first, then the network
# (validation runs online). A failure here is loud: the stories cannot run
# without it.
PYARROW_PIN="pyarrow==18.1.0"
echo "validation-setup: ensuring ${PYARROW_PIN} in ${VENV_PY}..."
if "$VENV_PY" -c "import pyarrow" >/dev/null 2>&1; then
    echo "validation-setup: pyarrow already importable"
else
    if "$VENV_PY" -m pip install --no-index --only-binary=:all: "$PYARROW_PIN" \
            > /tmp/validation-setup-pyarrow.log 2>&1; then
        echo "validation-setup: installed ${PYARROW_PIN} from local cache"
    elif "$VENV_PY" -m pip install --only-binary=:all: "$PYARROW_PIN" \
            >> /tmp/validation-setup-pyarrow.log 2>&1; then
        echo "validation-setup: installed ${PYARROW_PIN} from network (offline cache miss)"
    else
        echo "validation-setup: pyarrow install failed; the interop story will report it" >&2
        tail -n 80 /tmp/validation-setup-pyarrow.log >&2
        return 0 2>/dev/null || exit 0
    fi
fi
"$VENV_PY" -c "import pyarrow; print('validation-setup: pyarrow', pyarrow.__version__)" || true

echo "validation-setup: done."
