/*
 * Copyright (C) 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Behavioural checks for dataframe Arrow serialization/deserialization. This
// translation unit is fully self-contained: it binds only to the public
// serializer/deserializer entry points and the pre-existing public dataframe
// APIs, and it re-declares the small set of Apache Arrow wire-format constants
// and packed structs it needs to inspect framing. It deliberately does not
// include any module-private Arrow header, so it stays valid against any
// conforming implementation of the two entry points.

#include "src/trace_processor/core/dataframe/arrow_deserializer.h"
#include "src/trace_processor/core/dataframe/arrow_serializer.h"

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <optional>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include "perfetto/base/status.h"
#include "perfetto/ext/base/string_view.h"
#include "perfetto/trace_processor/trace_blob.h"
#include "perfetto/trace_processor/trace_blob_view.h"
#include "src/base/test/status_matchers.h"
#include "src/trace_processor/containers/string_pool.h"
#include "src/trace_processor/core/dataframe/dataframe.h"
#include "src/trace_processor/core/dataframe/specs.h"
#include "src/trace_processor/core/dataframe/typed_cursor.h"
#include "src/trace_processor/util/flatbuffer_reader.h"
#include "src/trace_processor/util/trace_blob_view_reader.h"
#include "test/gtest_and_gmock.h"

namespace perfetto::trace_processor::core::dataframe {
namespace {

using perfetto::base::gtest_matchers::IsError;

// --- Locally declared Apache Arrow wire-format constants -------------------
//
// These mirror the official Arrow columnar/IPC "file" format. They are
// declared here (rather than shared from a module header) so that the checks
// below describe the Arrow standard itself, not any particular internal layout.

constexpr char kMagic[] = "ARROW1";
constexpr size_t kMagicSize = sizeof(kMagic) - 1;      // 6 bytes.
constexpr uint32_t kContinuation = 0xFFFFFFFF;
constexpr uint32_t kMessagePrefixSize = 8;             // continuation + size.
constexpr uint32_t kFileTrailerSize = 10;              // int32 footer size + magic.

// Flatbuffer field indices from the official Arrow schema.
namespace message_field {
constexpr uint32_t kHeader = 2;
}
namespace record_batch_field {
constexpr uint32_t kLength = 0;
constexpr uint32_t kNodes = 1;
constexpr uint32_t kBuffers = 2;
}  // namespace record_batch_field
namespace footer_field {
constexpr uint32_t kRecordBatches = 3;
}

struct MessagePrefix {
  uint32_t continuation;
  int32_t metadata_size;
};
static_assert(sizeof(MessagePrefix) == kMessagePrefixSize);

struct FieldNode {
  int64_t length;
  int64_t null_count;
};
static_assert(sizeof(FieldNode) == 2 * sizeof(int64_t));

struct ArrowBuffer {
  int64_t offset;
  int64_t length;
};
static_assert(sizeof(ArrowBuffer) == 2 * sizeof(int64_t));

struct Block {
  int64_t offset;
  int32_t metadata_length;
  int32_t padding;
  int64_t body_length;
};
static_assert(sizeof(Block) == 2 * sizeof(int64_t) + 2 * sizeof(int32_t));

template <typename T>
T Load(const uint8_t* data, uint32_t index) {
  T value;
  memcpy(&value, data + static_cast<size_t>(index) * sizeof(T), sizeof(T));
  return value;
}

// --- Inlined helpers (not shared with the module under test) ---------------

std::vector<uint8_t> Serialize(Dataframe& dataframe, const StringPool& pool) {
  dataframe.Finalize();
  ArrowSerializer serializer;
  auto prepared_size = serializer.Prepare(dataframe, &pool);
  EXPECT_OK(prepared_size);
  if (!prepared_size.ok()) {
    return {};
  }
  size_t expected_size = *prepared_size;
  std::vector<uint8_t> output;
  base::Status status =
      serializer.Write(dataframe, &pool, [&](const uint8_t* data, size_t size) {
        output.insert(output.end(), data, data + size);
        return base::OkStatus();
      });
  EXPECT_OK(status);
  EXPECT_EQ(output.size(), expected_size);
  return output;
}

util::TraceBlobViewReader MakeReader(const std::vector<uint8_t>& bytes,
                                     size_t chunk_size = 0) {
  util::TraceBlobViewReader reader;
  if (chunk_size == 0) {
    chunk_size = bytes.empty() ? 1 : bytes.size();
  }
  for (size_t i = 0; i < bytes.size(); i += chunk_size) {
    size_t length = std::min(chunk_size, bytes.size() - i);
    reader.PushBack(
        TraceBlobView(TraceBlob::CopyFrom(bytes.data() + i, length)));
  }
  return reader;
}

base::StatusOr<Dataframe> Deserialize(const std::vector<uint8_t>& bytes,
                                      StringPool* pool,
                                      const DataframeSpec& spec,
                                      size_t chunk_size = 0) {
  util::TraceBlobViewReader reader = MakeReader(bytes, chunk_size);
  return DeserializeFromArrow(reader, pool, spec);
}

template <typename Spec, typename... Values>
Dataframe MakeDataframe(const Spec& spec, StringPool* pool, Values&&... values) {
  Dataframe dataframe = Dataframe::CreateFromTypedSpec(spec, pool);
  (dataframe.InsertUnchecked(spec, std::monostate{},
                             std::forward<Values>(values)),
   ...);
  return dataframe;
}

// Parses the serialized bytes as an Arrow file and returns its single record
// batch's framing metadata using the pre-existing flatbuffer reader.
struct RecordBatch {
  Block block;
  int64_t rows;
  size_t body_offset;
  util::FlatBufferScalarVec<FieldNode> nodes;
  util::FlatBufferScalarVec<ArrowBuffer> buffers;
};

std::optional<RecordBatch> ReadRecordBatch(const std::vector<uint8_t>& bytes) {
  if (bytes.size() < kFileTrailerSize + kMagicSize) {
    return std::nullopt;
  }
  uint32_t footer_size =
      Load<uint32_t>(bytes.data() + bytes.size() - kFileTrailerSize, 0);
  if (footer_size > bytes.size() - kFileTrailerSize) {
    return std::nullopt;
  }
  size_t footer_offset = bytes.size() - kFileTrailerSize - footer_size;
  auto footer = util::FlatBufferReader::GetRoot(bytes.data() + footer_offset,
                                                footer_size);
  if (!footer) {
    return std::nullopt;
  }
  auto blocks = footer->VecScalar<Block>(footer_field::kRecordBatches);
  if (blocks.size() != 1) {
    return std::nullopt;
  }
  Block block = blocks[0];
  if (block.offset < 0 || block.metadata_length < 0) {
    return std::nullopt;
  }
  // Every framing offset derived from the serialized block table is
  // bounds-checked against the byte buffer before it is dereferenced, so a
  // non-conformant serialized file makes this helper return nullopt (a clean
  // test FAIL at the caller's ASSERT_TRUE(batch)) rather than reading out of
  // bounds and crashing the whole suite.
  size_t message_offset = static_cast<size_t>(block.offset);
  if (message_offset + kMessagePrefixSize > bytes.size()) {
    return std::nullopt;
  }
  MessagePrefix prefix = Load<MessagePrefix>(bytes.data() + message_offset, 0);
  if (prefix.continuation != kContinuation || prefix.metadata_size <= 0) {
    return std::nullopt;
  }
  size_t metadata_offset = message_offset + kMessagePrefixSize;
  if (metadata_offset + static_cast<size_t>(prefix.metadata_size) >
      bytes.size()) {
    return std::nullopt;
  }
  size_t body_offset = message_offset + static_cast<size_t>(block.metadata_length);
  if (body_offset > bytes.size()) {
    return std::nullopt;
  }
  auto message = util::FlatBufferReader::GetRoot(
      bytes.data() + metadata_offset,
      static_cast<uint32_t>(prefix.metadata_size));
  auto record_batch = message ? message->Table(message_field::kHeader)
                              : util::FlatBufferReader{};
  if (!record_batch) {
    return std::nullopt;
  }
  return RecordBatch{
      block, record_batch.Scalar<int64_t>(record_batch_field::kLength),
      body_offset,
      record_batch.VecScalar<FieldNode>(record_batch_field::kNodes),
      record_batch.VecScalar<ArrowBuffer>(record_batch_field::kBuffers)};
}

template <typename T>
T ReadBodyValue(const std::vector<uint8_t>& bytes,
                const RecordBatch& batch,
                uint32_t buffer_index,
                uint32_t value_index) {
  ArrowBuffer buffer = batch.buffers[buffer_index];
  // The buffer offset/length come from the serialized record-batch
  // metadata. Bounds-check the read against the byte buffer before touching it,
  // so a non-conformant file fails the EXPECT below (default-constructed T
  // mismatches the expected value) rather than reading out of bounds and
  // SIGSEGV-ing the whole suite.
  size_t value_offset = batch.body_offset + static_cast<size_t>(buffer.offset) +
                        static_cast<size_t>(value_index) * sizeof(T);
  if (buffer.offset < 0 || value_offset + sizeof(T) > bytes.size()) {
    ADD_FAILURE() << "body read out of range: buffer " << buffer_index
                  << " value " << value_index;
    return T{};
  }
  return Load<T>(
      bytes.data() + batch.body_offset + static_cast<size_t>(buffer.offset),
      value_index);
}

// A column with no missing values may leave its validity buffer empty or write
// a bitmap with every row's bit set. Arrow accepts both.
void ExpectAllRowsValid(const std::vector<uint8_t>& bytes,
                        const RecordBatch& batch,
                        uint32_t buffer_index,
                        uint32_t rows) {
  int64_t length = batch.buffers[buffer_index].length;
  if (length == 0) {
    return;
  }
  ASSERT_GE(length, static_cast<int64_t>((rows + 7) / 8));
  for (uint32_t row = 0; row < rows; ++row) {
    uint32_t bits = ReadBodyValue<uint8_t>(bytes, batch, buffer_index, row / 8);
    EXPECT_NE(bits & (uint32_t{1} << (row % 8)), 0u) << "row " << row;
  }
}

// Follows a flatbuffer relative offset stored at |offset_location| to the data
// it points at, returning a mutable pointer into |bytes|.
uint8_t* FollowMutableOffset(std::vector<uint8_t>* bytes,
                             const uint8_t* offset_location) {
  uint32_t relative_offset;
  memcpy(&relative_offset, offset_location, sizeof(relative_offset));
  size_t location = static_cast<size_t>(offset_location - bytes->data());
  return bytes->data() + location + relative_offset;
}

uint8_t* MutableVectorData(std::vector<uint8_t>* bytes,
                           const util::FlatBufferReader& table,
                           uint32_t field) {
  const uint8_t* vector_offset = table.FieldRaw(field, sizeof(uint32_t));
  EXPECT_NE(vector_offset, nullptr);
  uint8_t* vector = FollowMutableOffset(bytes, vector_offset);
  uint32_t count;
  memcpy(&count, vector, sizeof(count));
  EXPECT_GT(count, 0u);
  return vector + sizeof(count);
}

size_t FooterOffset(const std::vector<uint8_t>& bytes) {
  uint32_t footer_size;
  memcpy(&footer_size, bytes.data() + bytes.size() - kFileTrailerSize,
         sizeof(footer_size));
  return bytes.size() - kFileTrailerSize - footer_size;
}

Block ReadBlock(const std::vector<uint8_t>& bytes) {
  size_t footer_offset = FooterOffset(bytes);
  uint32_t footer_size =
      static_cast<uint32_t>(bytes.size() - kFileTrailerSize - footer_offset);
  auto footer = util::FlatBufferReader::GetRoot(bytes.data() + footer_offset,
                                                footer_size);
  EXPECT_TRUE(footer.has_value());
  auto blocks = footer->VecScalar<Block>(footer_field::kRecordBatches);
  EXPECT_EQ(blocks.size(), 1u);
  return blocks[0];
}

uint8_t* MutableBlock(std::vector<uint8_t>* bytes) {
  size_t footer_offset = FooterOffset(*bytes);
  uint32_t footer_size =
      static_cast<uint32_t>(bytes->size() - kFileTrailerSize - footer_offset);
  auto footer = util::FlatBufferReader::GetRoot(bytes->data() + footer_offset,
                                                footer_size);
  EXPECT_TRUE(footer.has_value());
  return MutableVectorData(bytes, *footer, footer_field::kRecordBatches);
}

util::FlatBufferReader MutableRecordBatch(std::vector<uint8_t>* bytes) {
  Block block = ReadBlock(*bytes);
  uint32_t metadata_size;
  memcpy(&metadata_size, bytes->data() + block.offset + sizeof(uint32_t),
         sizeof(metadata_size));
  auto message = util::FlatBufferReader::GetRoot(
      bytes->data() + block.offset + kMessagePrefixSize, metadata_size);
  EXPECT_TRUE(message.has_value());
  auto record_batch = message->Table(message_field::kHeader);
  EXPECT_TRUE(static_cast<bool>(record_batch));
  return record_batch;
}

// --- Dataframe specs used by the checks ------------------------------------

inline constexpr auto kUint32NonNull = CreateTypedDataframeSpec(
    {"_auto_id", "val"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Uint32{}, NonNull{}, Unsorted{}));

inline constexpr auto kInt32NonNull = CreateTypedDataframeSpec(
    {"_auto_id", "val"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Int32{}, NonNull{}, Unsorted{}));

inline constexpr auto kInt64NonNull = CreateTypedDataframeSpec(
    {"_auto_id", "val"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Int64{}, NonNull{}, Unsorted{}));

inline constexpr auto kDoubleNonNull = CreateTypedDataframeSpec(
    {"_auto_id", "val"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Double{}, NonNull{}, Unsorted{}));

inline constexpr auto kStringNonNull = CreateTypedDataframeSpec(
    {"_auto_id", "str"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(String{}, NonNull{}, Unsorted{}));

inline constexpr auto kUint32DenseNull = CreateTypedDataframeSpec(
    {"_auto_id", "val"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Uint32{}, DenseNull{}, Unsorted{}));

inline constexpr auto kDoubleDenseNull = CreateTypedDataframeSpec(
    {"_auto_id", "val"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Double{}, DenseNull{}, Unsorted{}));

inline constexpr auto kInt32Sparse = CreateTypedDataframeSpec(
    {"_auto_id", "val"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Int32{}, SparseNull{}, Unsorted{}));

inline constexpr auto kInt64SparsePopcountAlways = CreateTypedDataframeSpec(
    {"_auto_id", "val"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Int64{}, SparseNullWithPopcountAlways{}, Unsorted{}));

inline constexpr auto kStringSparse = CreateTypedDataframeSpec(
    {"_auto_id", "name"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(String{}, SparseNullWithPopcountAlways{}, Unsorted{}));

inline constexpr auto kStringDenseNull = CreateTypedDataframeSpec(
    {"_auto_id", "name"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(String{}, DenseNull{}, Unsorted{}));

inline constexpr auto kMultiColumn = CreateTypedDataframeSpec(
    {"_auto_id", "ts", "name", "value"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Int64{}, NonNull{}, Sorted{}),
    CreateTypedColumnSpec(String{}, NonNull{}, Unsorted{}),
    CreateTypedColumnSpec(Double{}, DenseNull{}, Unsorted{}));

inline constexpr auto kIdOnly = CreateTypedDataframeSpec(
    {"_auto_id"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}));

inline constexpr auto kEveryTypeDenseNull = CreateTypedDataframeSpec(
    {"_auto_id", "u32", "i32", "i64", "f64", "str"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Uint32{}, DenseNull{}, Unsorted{}),
    CreateTypedColumnSpec(Int32{}, DenseNull{}, Unsorted{}),
    CreateTypedColumnSpec(Int64{}, DenseNull{}, Unsorted{}),
    CreateTypedColumnSpec(Double{}, DenseNull{}, Unsorted{}),
    CreateTypedColumnSpec(String{}, DenseNull{}, Unsorted{}));

inline constexpr auto kEveryTypeSparse = CreateTypedDataframeSpec(
    {"_auto_id", "u32", "i32", "i64", "f64", "str"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Uint32{}, SparseNullWithPopcountAlways{}, Unsorted{}),
    CreateTypedColumnSpec(Int32{}, SparseNullWithPopcountAlways{}, Unsorted{}),
    CreateTypedColumnSpec(Int64{}, SparseNullWithPopcountAlways{}, Unsorted{}),
    CreateTypedColumnSpec(Double{}, SparseNullWithPopcountAlways{}, Unsorted{}),
    CreateTypedColumnSpec(String{}, SparseNullWithPopcountAlways{}, Unsorted{}));

inline constexpr auto kDoubleSparseUntilFinalization = CreateTypedDataframeSpec(
    {"_auto_id", "val"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Double{},
                          SparseNullWithPopcountUntilFinalization{},
                          Unsorted{}));

// ===========================================================================
// Round-trip fidelity through the public cell accessor.
// ===========================================================================

TEST(ArrowVerify, RoundtripPrimitiveUint32) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{10}, uint32_t{20},
                           uint32_t{30});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 3u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kUint32NonNull, 0)), 10u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kUint32NonNull, 1)), 20u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kUint32NonNull, 2)), 30u);
}

TEST(ArrowVerify, RoundtripPrimitiveInt32) {
  StringPool pool;
  auto src = MakeDataframe(kInt32NonNull, &pool, int32_t{-5}, int32_t{0},
                           int32_t{2147483647});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 3u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kInt32NonNull, 0)), -5);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kInt32NonNull, 1)), 0);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kInt32NonNull, 2)), 2147483647);
}

TEST(ArrowVerify, RoundtripPrimitiveInt64) {
  StringPool pool;
  auto src = MakeDataframe(kInt64NonNull, &pool, int64_t{-1000000000000},
                           int64_t{0}, int64_t{1000000000000});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 3u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kInt64NonNull, 0)), -1000000000000);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kInt64NonNull, 2)), 1000000000000);
}

TEST(ArrowVerify, RoundtripPrimitiveDouble) {
  StringPool pool;
  auto src = MakeDataframe(kDoubleNonNull, &pool, double{1.5}, double{-2.25},
                           double{3.0});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 3u);
  EXPECT_DOUBLE_EQ((dst.GetCellUnchecked<1>(kDoubleNonNull, 0)), 1.5);
  EXPECT_DOUBLE_EQ((dst.GetCellUnchecked<1>(kDoubleNonNull, 1)), -2.25);
  EXPECT_DOUBLE_EQ((dst.GetCellUnchecked<1>(kDoubleNonNull, 2)), 3.0);
}

TEST(ArrowVerify, RoundtripStringIncludingEmpty) {
  StringPool pool;
  auto hello = pool.InternString(base::StringView("hello"));
  auto world = pool.InternString(base::StringView("world"));
  auto empty = pool.InternString(base::StringView(""));
  auto src = MakeDataframe(kStringNonNull, &pool, hello, world, empty);

  // Deserialize into a fresh pool: the recovered strings must be re-interned by
  // value, independently of the source pool's ids.
  std::vector<uint8_t> bytes = Serialize(src, pool);
  StringPool other_pool;
  auto dst_or = Deserialize(bytes, &other_pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 3u);
  EXPECT_EQ(
      other_pool.Get(dst.GetCellUnchecked<1>(kStringNonNull, 0)).ToStdString(),
      "hello");
  EXPECT_EQ(
      other_pool.Get(dst.GetCellUnchecked<1>(kStringNonNull, 1)).ToStdString(),
      "world");
  EXPECT_EQ(
      other_pool.Get(dst.GetCellUnchecked<1>(kStringNonNull, 2)).ToStdString(),
      "");
}

TEST(ArrowVerify, RoundtripDenseNull) {
  StringPool pool;
  auto src =
      MakeDataframe(kUint32DenseNull, &pool, std::optional<uint32_t>{10},
                    std::optional<uint32_t>{}, std::optional<uint32_t>{30},
                    std::optional<uint32_t>{}, std::optional<uint32_t>{50});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 5u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kUint32DenseNull, 0)),
            std::optional<uint32_t>{10});
  EXPECT_EQ((dst.GetCellUnchecked<1>(kUint32DenseNull, 1)),
            std::optional<uint32_t>{});
  EXPECT_EQ((dst.GetCellUnchecked<1>(kUint32DenseNull, 2)),
            std::optional<uint32_t>{30});
  EXPECT_EQ((dst.GetCellUnchecked<1>(kUint32DenseNull, 3)),
            std::optional<uint32_t>{});
  EXPECT_EQ((dst.GetCellUnchecked<1>(kUint32DenseNull, 4)),
            std::optional<uint32_t>{50});
}

TEST(ArrowVerify, RoundtripDoubleDenseNull) {
  StringPool pool;
  auto src = MakeDataframe(kDoubleDenseNull, &pool, std::optional<double>{1.5},
                           std::optional<double>{}, std::optional<double>{3.0});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 3u);
  auto v0 = dst.GetCellUnchecked<1>(kDoubleDenseNull, 0);
  auto v1 = dst.GetCellUnchecked<1>(kDoubleDenseNull, 1);
  auto v2 = dst.GetCellUnchecked<1>(kDoubleDenseNull, 2);
  ASSERT_TRUE(v0.has_value());
  EXPECT_DOUBLE_EQ(*v0, 1.5);
  EXPECT_FALSE(v1.has_value());
  ASSERT_TRUE(v2.has_value());
  EXPECT_DOUBLE_EQ(*v2, 3.0);
}

TEST(ArrowVerify, RoundtripSparseNull) {
  StringPool pool;
  auto src = MakeDataframe(kInt64SparsePopcountAlways, &pool,
                           std::optional<int64_t>{-7}, std::optional<int64_t>{},
                           std::optional<int64_t>{99});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 3u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kInt64SparsePopcountAlways, 0)),
            std::optional<int64_t>{-7});
  EXPECT_EQ((dst.GetCellUnchecked<1>(kInt64SparsePopcountAlways, 1)),
            std::optional<int64_t>{});
  EXPECT_EQ((dst.GetCellUnchecked<1>(kInt64SparsePopcountAlways, 2)),
            std::optional<int64_t>{99});
}

// A sparse column longer than 64 rows: the present/missing pattern must survive
// reconstruction across the 64-bit validity-word boundary.
TEST(ArrowVerify, RoundtripSparseNullAcrossWordBoundary) {
  StringPool pool;
  auto src = Dataframe::CreateFromTypedSpec(kInt64SparsePopcountAlways, &pool);
  for (int64_t i = 0; i < 200; i++) {
    src.InsertUnchecked(kInt64SparsePopcountAlways, std::monostate{},
                        i % 3 == 0 ? std::optional<int64_t>{}
                                   : std::optional<int64_t>{i * 100});
  }
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 200u);
  for (uint32_t i = 0; i < 200; i++) {
    auto expected = i % 3 == 0 ? std::optional<int64_t>{}
                               : std::optional<int64_t>{int64_t{i} * 100};
    EXPECT_EQ((dst.GetCellUnchecked<1>(kInt64SparsePopcountAlways, i)), expected)
        << "row " << i;
  }
}

TEST(ArrowVerify, RoundtripAllNullSparseColumn) {
  StringPool pool;
  auto src =
      MakeDataframe(kInt64SparsePopcountAlways, &pool, std::optional<int64_t>{},
                    std::optional<int64_t>{}, std::optional<int64_t>{});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 3u);
  for (uint32_t row = 0; row < dst.row_count(); ++row) {
    EXPECT_FALSE(
        (dst.GetCellUnchecked<1>(kInt64SparsePopcountAlways, row)).has_value());
  }
}

TEST(ArrowVerify, RoundtripEmptySparseColumn) {
  StringPool pool;
  auto src = Dataframe::CreateFromTypedSpec(kInt32Sparse, &pool);
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);
  EXPECT_EQ(dst.row_count(), 0u);
}

TEST(ArrowVerify, RoundtripStringSparseNull) {
  StringPool pool;
  auto hello = pool.InternString(base::StringView("hello"));
  auto world = pool.InternString(base::StringView("world"));
  auto src = MakeDataframe(
      kStringSparse, &pool, std::optional<StringPool::Id>{hello},
      std::optional<StringPool::Id>{}, std::optional<StringPool::Id>{world});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 3u);
  auto v0 = dst.GetCellUnchecked<1>(kStringSparse, 0);
  auto v1 = dst.GetCellUnchecked<1>(kStringSparse, 1);
  auto v2 = dst.GetCellUnchecked<1>(kStringSparse, 2);
  ASSERT_TRUE(v0.has_value());
  EXPECT_EQ(pool.Get(*v0).ToStdString(), "hello");
  EXPECT_FALSE(v1.has_value());
  ASSERT_TRUE(v2.has_value());
  EXPECT_EQ(pool.Get(*v2).ToStdString(), "world");
}

TEST(ArrowVerify, RoundtripStringDenseNull) {
  StringPool pool;
  auto hello = pool.InternString(base::StringView("hello"));
  auto src = MakeDataframe(kStringDenseNull, &pool,
                           std::optional<StringPool::Id>{hello},
                           std::optional<StringPool::Id>{});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 2u);
  auto v0 = dst.GetCellUnchecked<1>(kStringDenseNull, 0);
  ASSERT_TRUE(v0.has_value());
  EXPECT_EQ(pool.Get(*v0).ToStdString(), "hello");
  EXPECT_FALSE((dst.GetCellUnchecked<1>(kStringDenseNull, 1)).has_value());
}

TEST(ArrowVerify, RoundtripIdOnly) {
  StringPool pool;
  auto src = Dataframe::CreateFromTypedSpec(kIdOnly, &pool);
  src.InsertUnchecked(kIdOnly, std::monostate{});
  src.InsertUnchecked(kIdOnly, std::monostate{});
  src.InsertUnchecked(kIdOnly, std::monostate{});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 3u);
  EXPECT_EQ((dst.GetCellUnchecked<0>(kIdOnly, 0)), 0u);
  EXPECT_EQ((dst.GetCellUnchecked<0>(kIdOnly, 2)), 2u);
}

TEST(ArrowVerify, RoundtripMultiColumn) {
  StringPool pool;
  auto a = pool.InternString(base::StringView("a"));
  auto bb = pool.InternString(base::StringView("bb"));
  auto src = Dataframe::CreateFromTypedSpec(kMultiColumn, &pool);
  src.InsertUnchecked(kMultiColumn, std::monostate{}, int64_t{100}, a,
                      std::optional<double>{0.5});
  src.InsertUnchecked(kMultiColumn, std::monostate{}, int64_t{200}, bb,
                      std::optional<double>{});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 2u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kMultiColumn, 0)), 100);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kMultiColumn, 1)), 200);
  EXPECT_EQ(pool.Get(dst.GetCellUnchecked<2>(kMultiColumn, 0)).ToStdString(),
            "a");
  EXPECT_EQ(pool.Get(dst.GetCellUnchecked<2>(kMultiColumn, 1)).ToStdString(),
            "bb");
  auto d0 = dst.GetCellUnchecked<3>(kMultiColumn, 0);
  ASSERT_TRUE(d0.has_value());
  EXPECT_DOUBLE_EQ(*d0, 0.5);
  EXPECT_FALSE((dst.GetCellUnchecked<3>(kMultiColumn, 1)).has_value());

  // The column properties come from the spec passed to the reader and must
  // survive: storage type, null storage, sort state and duplicate state.
  DataframeSpec want = src.CreateSpec();
  DataframeSpec got = dst.CreateSpec();
  ASSERT_EQ(got.column_specs.size(), want.column_specs.size());
  for (size_t i = 0; i < want.column_specs.size(); ++i) {
    const ColumnSpec& w = want.column_specs[i];
    const ColumnSpec& g = got.column_specs[i];
    EXPECT_EQ(g.type.index(), w.type.index()) << "column " << i;
    EXPECT_EQ(g.nullability.index(), w.nullability.index()) << "column " << i;
    EXPECT_EQ(g.sort_state.index(), w.sort_state.index()) << "column " << i;
    EXPECT_EQ(g.duplicate_state.index(), w.duplicate_state.index())
        << "column " << i;
  }
}

// Every storage type under one null kind, read back cell by cell. The doubles
// are not exact in single precision, and the reader gets the bytes in small
// chunks so validity, value and string buffers cross chunk boundaries.
template <typename Spec>
void ExpectEveryTypeRoundtrip(const Spec& spec) {
  StringPool pool;
  auto first = pool.InternString(base::StringView("first"));
  auto third = pool.InternString(base::StringView("third"));
  auto src = Dataframe::CreateFromTypedSpec(spec, &pool);
  src.InsertUnchecked(spec, std::monostate{},
                      std::optional<uint32_t>{4000000000u},
                      std::optional<int32_t>{},
                      std::optional<int64_t>{-9000000000},
                      std::optional<double>{0.1},
                      std::optional<StringPool::Id>{first});
  src.InsertUnchecked(spec, std::monostate{}, std::optional<uint32_t>{},
                      std::optional<int32_t>{-7}, std::optional<int64_t>{},
                      std::optional<double>{}, std::optional<StringPool::Id>{});
  src.InsertUnchecked(spec, std::monostate{}, std::optional<uint32_t>{3},
                      std::optional<int32_t>{2147483647},
                      std::optional<int64_t>{},
                      std::optional<double>{1e-300},
                      std::optional<StringPool::Id>{third});
  src.InsertUnchecked(spec, std::monostate{}, std::optional<uint32_t>{},
                      std::optional<int32_t>{}, std::optional<int64_t>{5},
                      std::optional<double>{-2.5e100},
                      std::optional<StringPool::Id>{});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  StringPool out_pool;
  auto dst_or = Deserialize(bytes, &out_pool, src.CreateSpec(),
                            /*chunk_size=*/5);
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);
  ASSERT_EQ(dst.row_count(), 4u);

  EXPECT_EQ((dst.GetCellUnchecked<1>(spec, 0)),
            std::optional<uint32_t>{4000000000u});
  EXPECT_FALSE((dst.GetCellUnchecked<1>(spec, 1)).has_value());
  EXPECT_EQ((dst.GetCellUnchecked<1>(spec, 2)), std::optional<uint32_t>{3});
  EXPECT_FALSE((dst.GetCellUnchecked<1>(spec, 3)).has_value());

  EXPECT_FALSE((dst.GetCellUnchecked<2>(spec, 0)).has_value());
  EXPECT_EQ((dst.GetCellUnchecked<2>(spec, 1)), std::optional<int32_t>{-7});
  EXPECT_EQ((dst.GetCellUnchecked<2>(spec, 2)),
            std::optional<int32_t>{2147483647});
  EXPECT_FALSE((dst.GetCellUnchecked<2>(spec, 3)).has_value());

  EXPECT_EQ((dst.GetCellUnchecked<3>(spec, 0)),
            std::optional<int64_t>{-9000000000});
  EXPECT_FALSE((dst.GetCellUnchecked<3>(spec, 1)).has_value());
  EXPECT_FALSE((dst.GetCellUnchecked<3>(spec, 2)).has_value());
  EXPECT_EQ((dst.GetCellUnchecked<3>(spec, 3)), std::optional<int64_t>{5});

  auto d0 = dst.GetCellUnchecked<4>(spec, 0);
  auto d2 = dst.GetCellUnchecked<4>(spec, 2);
  auto d3 = dst.GetCellUnchecked<4>(spec, 3);
  ASSERT_TRUE(d0.has_value());
  EXPECT_DOUBLE_EQ(*d0, 0.1);
  EXPECT_FALSE((dst.GetCellUnchecked<4>(spec, 1)).has_value());
  ASSERT_TRUE(d2.has_value());
  EXPECT_DOUBLE_EQ(*d2, 1e-300);
  ASSERT_TRUE(d3.has_value());
  EXPECT_DOUBLE_EQ(*d3, -2.5e100);

  auto s0 = dst.GetCellUnchecked<5>(spec, 0);
  auto s2 = dst.GetCellUnchecked<5>(spec, 2);
  ASSERT_TRUE(s0.has_value());
  EXPECT_EQ(out_pool.Get(*s0).ToStdString(), "first");
  EXPECT_FALSE((dst.GetCellUnchecked<5>(spec, 1)).has_value());
  ASSERT_TRUE(s2.has_value());
  EXPECT_EQ(out_pool.Get(*s2).ToStdString(), "third");
  EXPECT_FALSE((dst.GetCellUnchecked<5>(spec, 3)).has_value());
}

TEST(ArrowVerify, RoundtripEveryTypeDenseNull) {
  ExpectEveryTypeRoundtrip(kEveryTypeDenseNull);
}

TEST(ArrowVerify, RoundtripEveryTypeSparseNull) {
  ExpectEveryTypeRoundtrip(kEveryTypeSparse);
}

// Plain sparse columns and sparse columns whose popcount is dropped at
// finalization cannot be read cell by cell once finalized. Check them by
// writing the frame that came back out again and reading each row's validity
// bit and value from that second file.
template <typename Spec, typename T>
void ExpectSparseReadBack(const Spec& spec,
                          const std::vector<std::optional<T>>& cells) {
  StringPool pool;
  auto src = Dataframe::CreateFromTypedSpec(spec, &pool);
  for (const auto& cell : cells) {
    src.InsertUnchecked(spec, std::monostate{}, cell);
  }
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec(), /*chunk_size=*/5);
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);
  ASSERT_EQ(dst.row_count(), cells.size());

  std::vector<uint8_t> again = Serialize(dst, pool);
  auto batch = ReadRecordBatch(again);
  ASSERT_TRUE(batch);
  ASSERT_EQ(batch->buffers.size(), 2u);
  for (uint32_t row = 0; row < cells.size(); ++row) {
    uint32_t bits = ReadBodyValue<uint8_t>(again, *batch, 0, row / 8);
    bool present = (bits & (uint32_t{1} << (row % 8))) != 0;
    EXPECT_EQ(present, cells[row].has_value()) << "row " << row;
    if (present && cells[row].has_value()) {
      // Compare the stored bits, so doubles must come back exactly.
      T value = ReadBodyValue<T>(again, *batch, 1, row);
      T expected = *cells[row];
      EXPECT_EQ(memcmp(&value, &expected, sizeof(T)), 0) << "row " << row;
    }
  }
}

TEST(ArrowVerify, RoundtripPlainSparseNull) {
  std::vector<std::optional<int32_t>> cells;
  for (int32_t i = 0; i < 70; ++i) {
    bool present = i % 4 == 1 || i == 69;
    cells.push_back(present ? std::optional<int32_t>{i * -1000}
                            : std::optional<int32_t>{});
  }
  ExpectSparseReadBack(kInt32Sparse, cells);
}

TEST(ArrowVerify, RoundtripSparseNullWithPopcountUntilFinalization) {
  std::vector<std::optional<double>> cells;
  for (int32_t i = 0; i < 70; ++i) {
    bool present = i % 3 == 2 || i == 66;
    double value = 0.1 * static_cast<double>(i);
    cells.push_back(present ? std::optional<double>{value}
                            : std::optional<double>{});
  }
  ExpectSparseReadBack(kDoubleSparseUntilFinalization, cells);
}

// ===========================================================================
// Reader input shapes: chunked, non-zero start offset, unaligned.
// ===========================================================================

TEST(ArrowVerify, RoundtripChunkedInput) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{1}, uint32_t{2},
                           uint32_t{3}, uint32_t{4});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec(), /*chunk_size=*/7);
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);
  ASSERT_EQ(dst.row_count(), 4u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kUint32NonNull, 0)), 1u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kUint32NonNull, 3)), 4u);
}

TEST(ArrowVerify, RoundtripNonZeroStartOffset) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{42});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  // A reader whose window does not start at file offset zero.
  util::TraceBlobViewReader reader;
  std::vector<uint8_t> padding(123, 0xAB);
  reader.PushBack(
      TraceBlobView(TraceBlob::CopyFrom(padding.data(), padding.size())));
  reader.PushBack(
      TraceBlobView(TraceBlob::CopyFrom(bytes.data(), bytes.size())));
  ASSERT_TRUE(reader.PopFrontUntil(padding.size()));

  auto dst_or = DeserializeFromArrow(reader, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);
  ASSERT_EQ(dst.row_count(), 1u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kUint32NonNull, 0)), 42u);
}

TEST(ArrowVerify, RoundtripUnalignedInput) {
  StringPool pool;
  auto value = pool.InternString(base::StringView("unaligned"));
  auto src = MakeDataframe(kStringNonNull, &pool, value);
  std::vector<uint8_t> bytes = Serialize(src, pool);

  // A single-byte prefix shifts every Arrow buffer off its natural alignment.
  std::vector<uint8_t> combined(1, 0xAB);
  combined.insert(combined.end(), bytes.begin(), bytes.end());
  util::TraceBlobViewReader reader;
  reader.PushBack(
      TraceBlobView(TraceBlob::CopyFrom(combined.data(), combined.size())));
  ASSERT_TRUE(reader.PopFrontBytes(1));

  StringPool output_pool;
  auto dst_or = DeserializeFromArrow(reader, &output_pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);
  EXPECT_EQ(
      output_pool.Get(dst.GetCellUnchecked<1>(kStringNonNull, 0)).ToStdString(),
      "unaligned");
}

// ===========================================================================
// Arrow file-format conformance (framing inspected via flatbuffer parsing).
// ===========================================================================

TEST(ArrowVerify, SerializeArrowMagicHeadAndFoot) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{1});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  ASSERT_GE(bytes.size(), 2 * kMagicSize);
  EXPECT_EQ(memcmp(bytes.data(), kMagic, kMagicSize), 0);
  EXPECT_EQ(memcmp(bytes.data() + bytes.size() - kMagicSize, kMagic, kMagicSize),
            0);
}

TEST(ArrowVerify, SerializeFramingIsReadable) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{10}, uint32_t{20},
                           uint32_t{30});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto batch = ReadRecordBatch(bytes);
  ASSERT_TRUE(batch);
  EXPECT_EQ(batch->rows, 3);
}

TEST(ArrowVerify, SerializePrimitiveBuffer) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{10}, uint32_t{20},
                           uint32_t{30});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto batch = ReadRecordBatch(bytes);

  ASSERT_TRUE(batch);
  ASSERT_EQ(batch->rows, 3);
  ASSERT_EQ(batch->nodes.size(), 1u);
  EXPECT_EQ(batch->nodes[0].null_count, 0);
  ASSERT_EQ(batch->buffers.size(), 2u);
  ExpectAllRowsValid(bytes, *batch, 0, 3);
  // The Arrow IPC buffer.length field is the logical (unpadded) byte count;
  // padding between buffers is implicit. Accept any length >= the logical
  // minimum, since a conformant serializer may round up for alignment.
  EXPECT_GE(batch->buffers[1].length,
            static_cast<int64_t>(3 * sizeof(uint32_t)));
  EXPECT_EQ(ReadBodyValue<uint32_t>(bytes, *batch, 1, 0), 10u);
  EXPECT_EQ(ReadBodyValue<uint32_t>(bytes, *batch, 1, 1), 20u);
  EXPECT_EQ(ReadBodyValue<uint32_t>(bytes, *batch, 1, 2), 30u);
}

// A sparse numeric column must be densified on write: null count correct,
// validity bitmap matching the present mask, and present values at their rows.
// The value in a missing row's slot is not checked.
TEST(ArrowVerify, SerializeValidityBitmapDensifiesSparse) {
  StringPool pool;
  auto src =
      MakeDataframe(kInt32Sparse, &pool, std::optional<int32_t>{11},
                    std::optional<int32_t>{}, std::optional<int32_t>{33});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto batch = ReadRecordBatch(bytes);

  ASSERT_TRUE(batch);
  ASSERT_EQ(batch->nodes.size(), 1u);
  EXPECT_EQ(batch->nodes[0].null_count, 1);
  ASSERT_EQ(batch->buffers.size(), 2u);
  // 3 rows fit in 1 validity byte; accept >= 1 (alignment padding is allowed).
  EXPECT_GE(batch->buffers[0].length, 1);
  // Rows 0 and 2 present, row 1 missing -> bits 0b00000101.
  EXPECT_EQ(ReadBodyValue<uint8_t>(bytes, *batch, 0, 0), 0b00000101);
  EXPECT_EQ(ReadBodyValue<int32_t>(bytes, *batch, 1, 0), 11);
  EXPECT_EQ(ReadBodyValue<int32_t>(bytes, *batch, 1, 2), 33);
}

TEST(ArrowVerify, SerializeUtf8OffsetAndDataBuffers) {
  StringPool pool;
  auto hello = pool.InternString(base::StringView("hello"));
  auto empty = pool.InternString(base::StringView(""));
  auto world = pool.InternString(base::StringView("world"));
  auto src = MakeDataframe(kStringNonNull, &pool, hello, empty, world);
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto batch = ReadRecordBatch(bytes);

  ASSERT_TRUE(batch);
  ASSERT_EQ(batch->buffers.size(), 3u);  // Validity + offsets + data.
  ExpectAllRowsValid(bytes, *batch, 0, 3);
  // n+1 int32 offsets; accept >= logical minimum (alignment padding allowed).
  EXPECT_GE(batch->buffers[1].length,
            static_cast<int64_t>(4 * sizeof(int32_t)));
  // 10 data bytes ("hello" + "" + "world"); accept >= 10 (alignment padding).
  EXPECT_GE(batch->buffers[2].length, 10);
  // Monotonic offsets: 0,5,5,10.
  EXPECT_EQ(ReadBodyValue<int32_t>(bytes, *batch, 1, 0), 0);
  EXPECT_EQ(ReadBodyValue<int32_t>(bytes, *batch, 1, 1), 5);
  EXPECT_EQ(ReadBodyValue<int32_t>(bytes, *batch, 1, 2), 5);
  EXPECT_EQ(ReadBodyValue<int32_t>(bytes, *batch, 1, 3), 10);
  ArrowBuffer strings = batch->buffers[2];
  const char* string_data = reinterpret_cast<const char*>(
      bytes.data() + batch->body_offset + strings.offset);
  // strings.length >= 10; read exactly the 10 logical data bytes.
  EXPECT_EQ(std::string_view(string_data, 10), "helloworld");
}

TEST(ArrowVerify, OmitsImplicitIdColumn) {
  StringPool pool;
  auto src = Dataframe::CreateFromTypedSpec(kIdOnly, &pool);
  src.InsertUnchecked(kIdOnly, std::monostate{});
  src.InsertUnchecked(kIdOnly, std::monostate{});
  src.InsertUnchecked(kIdOnly, std::monostate{});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto batch = ReadRecordBatch(bytes);

  ASSERT_TRUE(batch);
  EXPECT_EQ(batch->rows, 3);  // Row count still recorded.
  EXPECT_EQ(batch->nodes.size(), 0u);
  EXPECT_EQ(batch->buffers.size(), 0u);
  EXPECT_EQ(batch->block.body_length, 0);
}

// ===========================================================================
// Serializer lifecycle and reuse.
// ===========================================================================

TEST(ArrowVerify, PrepareWriteLifecycle) {
  StringPool pool;
  auto value = pool.InternString(base::StringView("value"));
  auto source = MakeDataframe(kStringNonNull, &pool, value);
  auto other = MakeDataframe(kStringNonNull, &pool, value);
  StringPool other_pool;
  ArrowSerializer serializer;
  auto sink = [](const uint8_t*, size_t) { return base::OkStatus(); };

  // Write before Prepare, and Prepare on a non-finalized frame, must error.
  EXPECT_THAT(serializer.Write(source, &pool, sink), IsError());
  EXPECT_THAT(serializer.Prepare(source, &pool), IsError());

  source.Finalize();
  other.Finalize();
  // A serializer that never prepared anything must refuse a finalized frame.
  ArrowSerializer unprepared;
  EXPECT_THAT(unprepared.Write(source, &pool, sink), IsError());
  // Prepare with a mismatched pool must error.
  EXPECT_THAT(serializer.Prepare(source, &other_pool), IsError());
  ASSERT_OK(serializer.Prepare(source, &pool));
  // Write with a frame/pool that differs from the one Prepared must error.
  EXPECT_THAT(serializer.Write(other, &pool, sink), IsError());
  EXPECT_THAT(serializer.Write(source, &other_pool, sink), IsError());
  // A fresh Prepare followed by the matching Write succeeds.
  ASSERT_OK(serializer.Prepare(source, &pool));
  EXPECT_OK(serializer.Write(source, &pool, sink));
}

TEST(ArrowVerify, PreparedSizeEqualsWrittenLength) {
  StringPool pool;
  auto source = MakeDataframe(kUint32NonNull, &pool, uint32_t{1}, uint32_t{2});
  source.Finalize();
  ArrowSerializer serializer;
  auto size = serializer.Prepare(source, &pool);
  ASSERT_OK(size);
  size_t written = 0;
  ASSERT_OK(serializer.Write(source, &pool, [&](const uint8_t*, size_t len) {
    written += len;
    return base::OkStatus();
  }));
  EXPECT_EQ(written, *size);
}

TEST(ArrowVerify, CanBeReusedAcrossDataframes) {
  StringPool pool;
  auto first = MakeDataframe(kUint32NonNull, &pool, uint32_t{1});
  auto second = MakeDataframe(kStringNonNull, &pool,
                              pool.InternString(base::StringView("second")),
                              pool.InternString(base::StringView("frame")));
  first.Finalize();
  second.Finalize();
  ArrowSerializer serializer;
  std::vector<uint8_t> first_bytes;
  std::vector<uint8_t> second_bytes;

  auto write_to = [&](const Dataframe& dataframe, std::vector<uint8_t>* out) {
    auto size = serializer.Prepare(dataframe, &pool);
    ASSERT_OK(size);
    ASSERT_OK(serializer.Write(dataframe, &pool,
                               [&](const uint8_t* data, size_t length) {
                                 out->insert(out->end(), data, data + length);
                                 return base::OkStatus();
                               }));
    EXPECT_EQ(out->size(), *size);
  };
  write_to(first, &first_bytes);
  write_to(second, &second_bytes);

  // Each produced buffer must deserialize back to its own frame.
  auto first_or = Deserialize(first_bytes, &pool, first.CreateSpec());
  ASSERT_OK(first_or);
  EXPECT_EQ(first_or->row_count(), 1u);
  EXPECT_EQ((first_or->GetCellUnchecked<1>(kUint32NonNull, 0)), 1u);
  auto second_or = Deserialize(second_bytes, &pool, second.CreateSpec());
  ASSERT_OK(second_or);
  EXPECT_EQ(second_or->row_count(), 2u);
  auto second_value = second_or->GetCellUnchecked<1>(kStringNonNull, 1);
  EXPECT_EQ(pool.Get(second_value).ToStdString(), "frame");
}

// Whatever pieces Write hands to the sink, a failure on any one of them stops
// the write there and comes back as that same status.
TEST(ArrowVerify, PropagatesWriteError) {
  StringPool pool;
  auto a = pool.InternString(base::StringView("a"));
  auto bb = pool.InternString(base::StringView("bb"));
  auto source = Dataframe::CreateFromTypedSpec(kMultiColumn, &pool);
  source.InsertUnchecked(kMultiColumn, std::monostate{}, int64_t{100}, a,
                         std::optional<double>{0.5});
  source.InsertUnchecked(kMultiColumn, std::monostate{}, int64_t{200}, bb,
                         std::optional<double>{});
  source.Finalize();
  ArrowSerializer serializer;

  ASSERT_OK(serializer.Prepare(source, &pool));
  uint32_t total_calls = 0;
  ASSERT_OK(serializer.Write(source, &pool, [&](const uint8_t*, size_t) {
    ++total_calls;
    return base::OkStatus();
  }));
  ASSERT_GE(total_calls, 1u);

  for (uint32_t failing_call = 1; failing_call <= total_calls; ++failing_call) {
    ASSERT_OK(serializer.Prepare(source, &pool));
    std::string message = "sink failed on call " + std::to_string(failing_call);
    uint32_t calls = 0;
    base::Status status =
        serializer.Write(source, &pool, [&](const uint8_t*, size_t) {
          if (++calls == failing_call) {
            return base::ErrStatus("%s", message.c_str());
          }
          return base::OkStatus();
        });
    EXPECT_THAT(status, IsError()) << "failing call " << failing_call;
    EXPECT_EQ(status.message(), message);
    EXPECT_EQ(calls, failing_call);
  }
}

// ===========================================================================
// Deserializer hardening: malformed input is rejected via status, no crash.
// ===========================================================================

TEST(ArrowVerify, RejectsInvalidDataframeSpec) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{1});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  DataframeSpec invalid_spec{{"only_a_name"}, {}};
  EXPECT_THAT(Deserialize(bytes, &pool, invalid_spec), IsError());
}

TEST(ArrowVerify, RejectsTruncatedInput) {
  StringPool pool;
  auto src = MakeDataframe(kStringSparse, &pool,
                           std::optional<StringPool::Id>{pool.InternString(
                               base::StringView("some string data"))},
                           std::optional<StringPool::Id>{});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  for (size_t len = 0; len < bytes.size(); len += 7) {
    std::vector<uint8_t> truncated(bytes.begin(),
                                   bytes.begin() + static_cast<ptrdiff_t>(len));
    EXPECT_THAT(Deserialize(truncated, &pool, src.CreateSpec()), IsError())
        << "len " << len;
  }
}

TEST(ArrowVerify, RejectsCorruptFooterSize) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{1});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  uint32_t huge = 0x7FFFFFFF;
  memcpy(bytes.data() + bytes.size() - kFileTrailerSize, &huge, sizeof(huge));
  EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsInconsistentBlockLength) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{1});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  Block block;
  memcpy(&block, MutableBlock(&bytes), sizeof(block));
  block.body_length += 8;
  memcpy(MutableBlock(&bytes), &block, sizeof(block));

  EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsInconsistentFieldNode) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{1});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  auto record_batch = MutableRecordBatch(&bytes);
  uint8_t* node_data =
      MutableVectorData(&bytes, record_batch, record_batch_field::kNodes);
  FieldNode node;
  memcpy(&node, node_data, sizeof(node));
  node.null_count = 1;  // Claims a null where the buffers encode none.
  memcpy(node_data, &node, sizeof(node));

  EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsNegativeValidityBufferOffset) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{1});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  auto record_batch = MutableRecordBatch(&bytes);
  uint8_t* buffer_data =
      MutableVectorData(&bytes, record_batch, record_batch_field::kBuffers);
  ArrowBuffer buffer;
  memcpy(&buffer, buffer_data, sizeof(buffer));
  buffer.offset = -1;  // Negative offset for the validity buffer.
  memcpy(buffer_data, &buffer, sizeof(buffer));

  EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsInvalidStringOffsets) {
  StringPool pool;
  auto value = pool.InternString(base::StringView("value"));
  auto src = MakeDataframe(kStringNonNull, &pool, value);
  std::vector<uint8_t> bytes = Serialize(src, pool);

  Block block = ReadBlock(bytes);
  auto record_batch = MutableRecordBatch(&bytes);
  uint8_t* buffer_data =
      MutableVectorData(&bytes, record_batch, record_batch_field::kBuffers);
  ArrowBuffer offsets_buffer;
  memcpy(&offsets_buffer, buffer_data + sizeof(ArrowBuffer),
         sizeof(offsets_buffer));
  int32_t invalid_offset = -1;  // Non-monotonic / negative Utf8 offset.
  memcpy(bytes.data() + block.offset + block.metadata_length +
             offsets_buffer.offset + sizeof(int32_t),
         &invalid_offset, sizeof(invalid_offset));

  EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError());
}

// The checks below each push one size or offset that the file declares past
// the end of the input. The reader must report an error instead of following
// it.
TEST(ArrowVerify, RejectsBlockOffsetPastEnd) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{1});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  Block block;
  memcpy(&block, MutableBlock(&bytes), sizeof(block));
  block.offset = static_cast<int64_t>(bytes.size()) + 64;
  memcpy(MutableBlock(&bytes), &block, sizeof(block));

  EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsBlockMetadataLengthPastEnd) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{2});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  Block block;
  memcpy(&block, MutableBlock(&bytes), sizeof(block));
  block.metadata_length = 0x7FFFFFF0;
  memcpy(MutableBlock(&bytes), &block, sizeof(block));

  EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsMessageMetadataSizePastEnd) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{3});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  Block block = ReadBlock(bytes);
  int32_t huge = 0x7FFFFFF0;
  memcpy(bytes.data() + block.offset + sizeof(uint32_t), &huge, sizeof(huge));

  EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsRowCountPastBuffers) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{4});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  auto record_batch = MutableRecordBatch(&bytes);
  const uint8_t* length_field =
      record_batch.FieldRaw(record_batch_field::kLength, sizeof(int64_t));
  ASSERT_NE(length_field, nullptr);
  size_t location = static_cast<size_t>(length_field - bytes.data());
  int64_t rows = 1000000;
  memcpy(bytes.data() + location, &rows, sizeof(rows));

  EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsDataBufferPastBody) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{5});
  std::vector<uint8_t> original = Serialize(src, pool);
  int64_t body_length = ReadBlock(original).body_length;

  // The values buffer starts past the body, runs past it, or starts inside it
  // with its own length but ends past it.
  enum class Shift { kOffset, kLength, kEnd };
  for (Shift shift : {Shift::kOffset, Shift::kLength, Shift::kEnd}) {
    std::vector<uint8_t> bytes = original;
    auto record_batch = MutableRecordBatch(&bytes);
    uint8_t* buffer_data =
        MutableVectorData(&bytes, record_batch, record_batch_field::kBuffers);
    ArrowBuffer values;
    memcpy(&values, buffer_data + sizeof(ArrowBuffer), sizeof(values));
    if (shift == Shift::kOffset) {
      values.offset = int64_t{1} << 40;
    } else if (shift == Shift::kLength) {
      values.length = int64_t{1} << 40;
    } else {
      values.offset = body_length - 2;
    }
    memcpy(buffer_data + sizeof(ArrowBuffer), &values, sizeof(values));

    EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError())
        << "shift " << static_cast<int>(shift);
  }
}

TEST(ArrowVerify, RejectsStringOffsetPastData) {
  StringPool pool;
  auto value = pool.InternString(base::StringView("value"));
  auto src = MakeDataframe(kStringNonNull, &pool, value);
  std::vector<uint8_t> bytes = Serialize(src, pool);

  Block block = ReadBlock(bytes);
  auto record_batch = MutableRecordBatch(&bytes);
  uint8_t* buffer_data =
      MutableVectorData(&bytes, record_batch, record_batch_field::kBuffers);
  ArrowBuffer offsets_buffer;
  memcpy(&offsets_buffer, buffer_data + sizeof(ArrowBuffer),
         sizeof(offsets_buffer));
  int32_t past_end = 1000;  // The data buffer holds only "value".
  memcpy(bytes.data() + block.offset + block.metadata_length +
             offsets_buffer.offset + sizeof(int32_t),
         &past_end, sizeof(past_end));

  EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsNegativeRowCount) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{6});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  auto record_batch = MutableRecordBatch(&bytes);
  const uint8_t* length_field =
      record_batch.FieldRaw(record_batch_field::kLength, sizeof(int64_t));
  ASSERT_NE(length_field, nullptr);
  size_t location = static_cast<size_t>(length_field - bytes.data());
  int64_t rows = -1;
  memcpy(bytes.data() + location, &rows, sizeof(rows));

  EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsNullCountThatDisagreesWithBitmap) {
  StringPool pool;
  auto src =
      MakeDataframe(kUint32DenseNull, &pool, std::optional<uint32_t>{1},
                    std::optional<uint32_t>{}, std::optional<uint32_t>{3},
                    std::optional<uint32_t>{}, std::optional<uint32_t>{5});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  auto record_batch = MutableRecordBatch(&bytes);
  uint8_t* node_data =
      MutableVectorData(&bytes, record_batch, record_batch_field::kNodes);
  FieldNode node;
  memcpy(&node, node_data, sizeof(node));
  ASSERT_EQ(node.null_count, 2);
  node.null_count = 0;  // The bitmap still marks two rows missing.
  memcpy(node_data, &node, sizeof(node));

  EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsValuesBufferShorterThanRows) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{7}, uint32_t{8},
                           uint32_t{9});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  auto record_batch = MutableRecordBatch(&bytes);
  uint8_t* buffer_data =
      MutableVectorData(&bytes, record_batch, record_batch_field::kBuffers);
  ArrowBuffer values;
  memcpy(&values, buffer_data + sizeof(ArrowBuffer), sizeof(values));
  values.length = static_cast<int64_t>(sizeof(uint32_t));  // Room for 1 row.
  memcpy(buffer_data + sizeof(ArrowBuffer), &values, sizeof(values));

  EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsNegativeBufferLength) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{10});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  auto record_batch = MutableRecordBatch(&bytes);
  uint8_t* buffer_data =
      MutableVectorData(&bytes, record_batch, record_batch_field::kBuffers);
  ArrowBuffer values;
  memcpy(&values, buffer_data + sizeof(ArrowBuffer), sizeof(values));
  values.length = -8;
  memcpy(buffer_data + sizeof(ArrowBuffer), &values, sizeof(values));

  EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsSchemaShapeMismatch) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{1});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  // The requested schema has a different column shape than the encoded batch.
  auto dst = Dataframe::CreateFromTypedSpec(kMultiColumn, &pool);
  EXPECT_THAT(Deserialize(bytes, &pool, dst.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsGarbageInput) {
  StringPool pool;
  std::vector<uint8_t> bytes(256, 0xCD);
  auto dst = Dataframe::CreateFromTypedSpec(kUint32NonNull, &pool);
  EXPECT_THAT(Deserialize(bytes, &pool, dst.CreateSpec()), IsError());
}

// ===========================================================================
// The deserialized frame is a real finalized, queryable Dataframe.
// ===========================================================================

TEST(ArrowVerify, DeserializedFrameIsFinalized) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{1});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);
  EXPECT_TRUE(dst.finalized());
  EXPECT_EQ(dst.row_count(), 1u);
}

TEST(ArrowVerify, DeserializedFrameSupportsIndexesAndCursors) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{20}, uint32_t{10});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  uint32_t indexed_column = 1;
  auto index = dst.BuildIndex(&indexed_column, &indexed_column + 1);
  ASSERT_OK(index);
  Dataframe indexed = dst.AddIndex(std::move(*index));
  TypedCursor cursor(
      &indexed, std::vector<FilterSpec>{},
      std::vector<SortSpec>{{indexed_column, SortDirection::kAscending}});
  cursor.ExecuteUnchecked();
  ASSERT_FALSE(cursor.Eof());
  EXPECT_EQ(cursor.GetCellUnchecked<1>(kUint32NonNull), 10u);
  cursor.Next();
  ASSERT_FALSE(cursor.Eof());
  EXPECT_EQ(cursor.GetCellUnchecked<1>(kUint32NonNull), 20u);
  cursor.Next();
  EXPECT_TRUE(cursor.Eof());
}

}  // namespace
}  // namespace perfetto::trace_processor::core::dataframe
