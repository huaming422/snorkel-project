/*
 * Copyright (C) 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Behavioral checks for dataframe Arrow serialization/deserialization. This
// translation unit is fully self-contained: it binds only to the public
// serializer/deserializer entry points and the pre-existing public dataframe
// APIs, and it re-declares the small set of Apache Arrow wire-format constants
// and packed structs it needs to inspect framing. It deliberately does not
// include any module-private Arrow header, so it stays valid against any
// conforming implementation of the two entry points.

#include "src/trace_processor/core/dataframe/arrow_deserializer.h"
#include "src/trace_processor/core/dataframe/arrow_serializer.h"

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <optional>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include "perfetto/base/status.h"
#include "perfetto/ext/base/string_view.h"
#include "perfetto/trace_processor/trace_blob.h"
#include "perfetto/trace_processor/trace_blob_view.h"
#include "src/base/test/status_matchers.h"
#include "src/trace_processor/containers/string_pool.h"
#include "src/trace_processor/core/dataframe/dataframe.h"
#include "src/trace_processor/core/dataframe/specs.h"
#include "src/trace_processor/core/dataframe/typed_cursor.h"
#include "src/trace_processor/util/flatbuffer_reader.h"
#include "src/trace_processor/util/trace_blob_view_reader.h"
#include "test/gtest_and_gmock.h"

namespace perfetto::trace_processor::core::dataframe {
namespace {

using perfetto::base::gtest_matchers::IsError;

// --- Locally declared Apache Arrow wire-format constants -------------------
//
// These mirror the official Arrow columnar/IPC "file" format. They are
// declared here (rather than shared from a module header) so that the checks
// below describe the Arrow standard itself, not any particular internal layout.

constexpr char kMagic[] = "ARROW1";
constexpr size_t kMagicSize = sizeof(kMagic) - 1;      // 6 bytes.
constexpr uint32_t kContinuation = 0xFFFFFFFF;
constexpr uint32_t kMessagePrefixSize = 8;             // continuation + size.
constexpr uint32_t kFileTrailerSize = 10;              // int32 footer size + magic.

// Flatbuffer field indices from the official Arrow schema.
namespace message_field {
constexpr uint32_t kHeader = 2;
}
namespace record_batch_field {
constexpr uint32_t kLength = 0;
constexpr uint32_t kNodes = 1;
constexpr uint32_t kBuffers = 2;
}  // namespace record_batch_field
namespace footer_field {
constexpr uint32_t kRecordBatches = 3;
}

struct MessagePrefix {
  uint32_t continuation;
  int32_t metadata_size;
};
static_assert(sizeof(MessagePrefix) == kMessagePrefixSize);

struct FieldNode {
  int64_t length;
  int64_t null_count;
};
static_assert(sizeof(FieldNode) == 2 * sizeof(int64_t));

struct ArrowBuffer {
  int64_t offset;
  int64_t length;
};
static_assert(sizeof(ArrowBuffer) == 2 * sizeof(int64_t));

struct Block {
  int64_t offset;
  int32_t metadata_length;
  int32_t padding;
  int64_t body_length;
};
static_assert(sizeof(Block) == 2 * sizeof(int64_t) + 2 * sizeof(int32_t));

template <typename T>
T Load(const uint8_t* data, uint32_t index) {
  T value;
  memcpy(&value, data + static_cast<size_t>(index) * sizeof(T), sizeof(T));
  return value;
}

// --- Inlined helpers (not shared with the module under test) ---------------

std::vector<uint8_t> Serialize(Dataframe& dataframe, const StringPool& pool) {
  dataframe.Finalize();
  ArrowSerializer serializer;
  auto prepared_size = serializer.Prepare(dataframe, &pool);
  EXPECT_OK(prepared_size);
  if (!prepared_size.ok()) {
    return {};
  }
  size_t expected_size = *prepared_size;
  std::vector<uint8_t> output;
  base::Status status =
      serializer.Write(dataframe, &pool, [&](const uint8_t* data, size_t size) {
        output.insert(output.end(), data, data + size);
        return base::OkStatus();
      });
  EXPECT_OK(status);
  EXPECT_EQ(output.size(), expected_size);
  return output;
}

util::TraceBlobViewReader MakeReader(const std::vector<uint8_t>& bytes,
                                     size_t chunk_size = 0) {
  util::TraceBlobViewReader reader;
  if (chunk_size == 0) {
    chunk_size = bytes.empty() ? 1 : bytes.size();
  }
  for (size_t i = 0; i < bytes.size(); i += chunk_size) {
    size_t length = std::min(chunk_size, bytes.size() - i);
    reader.PushBack(
        TraceBlobView(TraceBlob::CopyFrom(bytes.data() + i, length)));
  }
  return reader;
}

base::StatusOr<Dataframe> Deserialize(const std::vector<uint8_t>& bytes,
                                      StringPool* pool,
                                      const DataframeSpec& spec,
                                      size_t chunk_size = 0) {
  util::TraceBlobViewReader reader = MakeReader(bytes, chunk_size);
  return DeserializeFromArrow(reader, pool, spec);
}

template <typename Spec, typename... Values>
Dataframe MakeDataframe(const Spec& spec, StringPool* pool, Values&&... values) {
  Dataframe dataframe = Dataframe::CreateFromTypedSpec(spec, pool);
  (dataframe.InsertUnchecked(spec, std::monostate{},
                             std::forward<Values>(values)),
   ...);
  return dataframe;
}

// Parses the serialized bytes as an Arrow file and returns its single record
// batch's framing metadata using the pre-existing flatbuffer reader.
struct RecordBatch {
  Block block;
  int64_t rows;
  size_t body_offset;
  util::FlatBufferScalarVec<FieldNode> nodes;
  util::FlatBufferScalarVec<ArrowBuffer> buffers;
};

std::optional<RecordBatch> ReadRecordBatch(const std::vector<uint8_t>& bytes) {
  if (bytes.size() < kFileTrailerSize + kMagicSize) {
    return std::nullopt;
  }
  uint32_t footer_size =
      Load<uint32_t>(bytes.data() + bytes.size() - kFileTrailerSize, 0);
  if (footer_size > bytes.size() - kFileTrailerSize) {
    return std::nullopt;
  }
  size_t footer_offset = bytes.size() - kFileTrailerSize - footer_size;
  auto footer = util::FlatBufferReader::GetRoot(bytes.data() + footer_offset,
                                                footer_size);
  if (!footer) {
    return std::nullopt;
  }
  auto blocks = footer->VecScalar<Block>(footer_field::kRecordBatches);
  if (blocks.size() != 1) {
    return std::nullopt;
  }
  Block block = blocks[0];
  if (block.offset < 0 || block.metadata_length < 0) {
    return std::nullopt;
  }
  // Every framing offset derived from the serialized block table is
  // bounds-checked against the byte buffer before it is dereferenced, so a
  // non-conformant serialized file makes this helper return nullopt (a clean
  // test FAIL at the caller's ASSERT_TRUE(batch)) rather than reading out of
  // bounds and crashing the whole suite.
  size_t message_offset = static_cast<size_t>(block.offset);
  if (message_offset + kMessagePrefixSize > bytes.size()) {
    return std::nullopt;
  }
  MessagePrefix prefix = Load<MessagePrefix>(bytes.data() + message_offset, 0);
  if (prefix.continuation != kContinuation || prefix.metadata_size <= 0) {
    return std::nullopt;
  }
  size_t metadata_offset = message_offset + kMessagePrefixSize;
  if (metadata_offset + static_cast<size_t>(prefix.metadata_size) >
      bytes.size()) {
    return std::nullopt;
  }
  size_t body_offset = message_offset + static_cast<size_t>(block.metadata_length);
  if (body_offset > bytes.size()) {
    return std::nullopt;
  }
  auto message = util::FlatBufferReader::GetRoot(
      bytes.data() + metadata_offset,
      static_cast<uint32_t>(prefix.metadata_size));
  auto record_batch = message ? message->Table(message_field::kHeader)
                              : util::FlatBufferReader{};
  if (!record_batch) {
    return std::nullopt;
  }
  return RecordBatch{
      block, record_batch.Scalar<int64_t>(record_batch_field::kLength),
      body_offset,
      record_batch.VecScalar<FieldNode>(record_batch_field::kNodes),
      record_batch.VecScalar<ArrowBuffer>(record_batch_field::kBuffers)};
}

template <typename T>
T ReadBodyValue(const std::vector<uint8_t>& bytes,
                const RecordBatch& batch,
                uint32_t buffer_index,
                uint32_t value_index) {
  ArrowBuffer buffer = batch.buffers[buffer_index];
  // The buffer offset/length come from the serialized record-batch
  // metadata. Bounds-check the read against the byte buffer before touching it,
  // so a non-conformant file fails the EXPECT below (default-constructed T
  // mismatches the expected value) rather than reading out of bounds and
  // SIGSEGV-ing the whole suite.
  size_t value_offset = batch.body_offset + static_cast<size_t>(buffer.offset) +
                        static_cast<size_t>(value_index) * sizeof(T);
  if (buffer.offset < 0 || value_offset + sizeof(T) > bytes.size()) {
    ADD_FAILURE() << "body read out of range: buffer " << buffer_index
                  << " value " << value_index;
    return T{};
  }
  return Load<T>(
      bytes.data() + batch.body_offset + static_cast<size_t>(buffer.offset),
      value_index);
}

// A column with no missing values may leave its validity buffer empty or write
// a bitmap with every row's bit set. Arrow accepts both.
void ExpectAllRowsValid(const std::vector<uint8_t>& bytes,
                        const RecordBatch& batch,
                        uint32_t buffer_index,
                        uint32_t rows) {
  int64_t length = batch.buffers[buffer_index].length;
  if (length == 0) {
    return;
  }
  ASSERT_GE(length, static_cast<int64_t>((rows + 7) / 8));
  for (uint32_t row = 0; row < rows; ++row) {
    uint32_t bits = ReadBodyValue<uint8_t>(bytes, batch, buffer_index, row / 8);
    EXPECT_NE(bits & (uint32_t{1} << (row % 8)), 0u) << "row " << row;
  }
}

// Follows a flatbuffer relative offset stored at |offset_location| to the data
// it points at, returning a mutable pointer into |bytes|.
uint8_t* FollowMutableOffset(std::vector<uint8_t>* bytes,
                             const uint8_t* offset_location) {
  uint32_t relative_offset;
  memcpy(&relative_offset, offset_location, sizeof(relative_offset));
  size_t location = static_cast<size_t>(offset_location - bytes->data());
  return bytes->data() + location + relative_offset;
}

uint8_t* MutableVectorData(std::vector<uint8_t>* bytes,
                           const util::FlatBufferReader& table,
                           uint32_t field) {
  const uint8_t* vector_offset = table.FieldRaw(field, sizeof(uint32_t));
  EXPECT_NE(vector_offset, nullptr);
  uint8_t* vector = FollowMutableOffset(bytes, vector_offset);
  uint32_t count;
  memcpy(&count, vector, sizeof(count));
  EXPECT_GT(count, 0u);
  return vector + sizeof(count);
}

size_t FooterOffset(const std::vector<uint8_t>& bytes) {
  uint32_t footer_size;
  memcpy(&footer_size, bytes.data() + bytes.size() - kFileTrailerSize,
         sizeof(footer_size));
  return bytes.size() - kFileTrailerSize - footer_size;
}

Block ReadBlock(const std::vector<uint8_t>& bytes) {
  size_t footer_offset = FooterOffset(bytes);
  uint32_t footer_size =
      static_cast<uint32_t>(bytes.size() - kFileTrailerSize - footer_offset);
  auto footer = util::FlatBufferReader::GetRoot(bytes.data() + footer_offset,
                                                footer_size);
  EXPECT_TRUE(footer.has_value());
  auto blocks = footer->VecScalar<Block>(footer_field::kRecordBatches);
  EXPECT_EQ(blocks.size(), 1u);
  return blocks[0];
}

uint8_t* MutableBlock(std::vector<uint8_t>* bytes) {
  size_t footer_offset = FooterOffset(*bytes);
  uint32_t footer_size =
      static_cast<uint32_t>(bytes->size() - kFileTrailerSize - footer_offset);
  auto footer = util::FlatBufferReader::GetRoot(bytes->data() + footer_offset,
                                                footer_size);
  EXPECT_TRUE(footer.has_value());
  return MutableVectorData(bytes, *footer, footer_field::kRecordBatches);
}

util::FlatBufferReader MutableRecordBatch(std::vector<uint8_t>* bytes) {
  Block block = ReadBlock(*bytes);
  uint32_t metadata_size;
  memcpy(&metadata_size, bytes->data() + block.offset + sizeof(uint32_t),
         sizeof(metadata_size));
  auto message = util::FlatBufferReader::GetRoot(
      bytes->data() + block.offset + kMessagePrefixSize, metadata_size);
  EXPECT_TRUE(message.has_value());
  auto record_batch = message->Table(message_field::kHeader);
  EXPECT_TRUE(static_cast<bool>(record_batch));
  return record_batch;
}

// --- Dataframe specs used by the checks ------------------------------------

inline constexpr auto kUint32NonNull = CreateTypedDataframeSpec(
    {"_auto_id", "val"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Uint32{}, NonNull{}, Unsorted{}));

inline constexpr auto kInt32NonNull = CreateTypedDataframeSpec(
    {"_auto_id", "val"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Int32{}, NonNull{}, Unsorted{}));

inline constexpr auto kInt64NonNull = CreateTypedDataframeSpec(
    {"_auto_id", "val"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Int64{}, NonNull{}, Unsorted{}));

inline constexpr auto kDoubleNonNull = CreateTypedDataframeSpec(
    {"_auto_id", "val"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Double{}, NonNull{}, Unsorted{}));

inline constexpr auto kStringNonNull = CreateTypedDataframeSpec(
    {"_auto_id", "str"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(String{}, NonNull{}, Unsorted{}));

inline constexpr auto kUint32DenseNull = CreateTypedDataframeSpec(
    {"_auto_id", "val"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Uint32{}, DenseNull{}, Unsorted{}));

inline constexpr auto kDoubleDenseNull = CreateTypedDataframeSpec(
    {"_auto_id", "val"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Double{}, DenseNull{}, Unsorted{}));

inline constexpr auto kInt32Sparse = CreateTypedDataframeSpec(
    {"_auto_id", "val"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Int32{}, SparseNull{}, Unsorted{}));

inline constexpr auto kInt64SparsePopcountAlways = CreateTypedDataframeSpec(
    {"_auto_id", "val"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Int64{}, SparseNullWithPopcountAlways{}, Unsorted{}));

inline constexpr auto kStringSparse = CreateTypedDataframeSpec(
    {"_auto_id", "name"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(String{}, SparseNullWithPopcountAlways{}, Unsorted{}));

inline constexpr auto kStringDenseNull = CreateTypedDataframeSpec(
    {"_auto_id", "name"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(String{}, DenseNull{}, Unsorted{}));

inline constexpr auto kMultiColumn = CreateTypedDataframeSpec(
    {"_auto_id", "ts", "name", "value"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Int64{}, NonNull{}, Sorted{}),
    CreateTypedColumnSpec(String{}, NonNull{}, Unsorted{}),
    CreateTypedColumnSpec(Double{}, DenseNull{}, Unsorted{}));

inline constexpr auto kIdOnly = CreateTypedDataframeSpec(
    {"_auto_id"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}));

inline constexpr auto kEveryTypeDenseNull = CreateTypedDataframeSpec(
    {"_auto_id", "u32", "i32", "i64", "f64", "str"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Uint32{}, DenseNull{}, Unsorted{}),
    CreateTypedColumnSpec(Int32{}, DenseNull{}, Unsorted{}),
    CreateTypedColumnSpec(Int64{}, DenseNull{}, Unsorted{}),
    CreateTypedColumnSpec(Double{}, DenseNull{}, Unsorted{}),
    CreateTypedColumnSpec(String{}, DenseNull{}, Unsorted{}));

inline constexpr auto kEveryTypeSparse = CreateTypedDataframeSpec(
    {"_auto_id", "u32", "i32", "i64", "f64", "str"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Uint32{}, SparseNullWithPopcountAlways{}, Unsorted{}),
    CreateTypedColumnSpec(Int32{}, SparseNullWithPopcountAlways{}, Unsorted{}),
    CreateTypedColumnSpec(Int64{}, SparseNullWithPopcountAlways{}, Unsorted{}),
    CreateTypedColumnSpec(Double{}, SparseNullWithPopcountAlways{}, Unsorted{}),
    CreateTypedColumnSpec(String{}, SparseNullWithPopcountAlways{}, Unsorted{}));

inline constexpr auto kDoubleSparseUntilFinalization = CreateTypedDataframeSpec(
    {"_auto_id", "val"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Double{},
                          SparseNullWithPopcountUntilFinalization{},
                          Unsorted{}));

// ===========================================================================
// Round-trip fidelity through the public cell accessor.
// ===========================================================================

TEST(ArrowVerify, RoundtripPrimitiveUint32) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{10}, uint32_t{20},
                           uint32_t{30});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 3u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kUint32NonNull, 0)), 10u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kUint32NonNull, 1)), 20u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kUint32NonNull, 2)), 30u);
}

TEST(ArrowVerify, RoundtripPrimitiveInt32) {
  StringPool pool;
  auto src = MakeDataframe(kInt32NonNull, &pool, int32_t{-5}, int32_t{0},
                           int32_t{2147483647});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 3u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kInt32NonNull, 0)), -5);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kInt32NonNull, 1)), 0);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kInt32NonNull, 2)), 2147483647);
}

TEST(ArrowVerify, RoundtripPrimitiveInt64) {
  StringPool pool;
  auto src = MakeDataframe(kInt64NonNull, &pool, int64_t{-1000000000000},
                           int64_t{0}, int64_t{1000000000000});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 3u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kInt64NonNull, 0)), -1000000000000);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kInt64NonNull, 2)), 1000000000000);
}

TEST(ArrowVerify, RoundtripPrimitiveDouble) {
  StringPool pool;
  auto src = MakeDataframe(kDoubleNonNull, &pool, double{1.5}, double{-2.25},
                           double{3.0});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 3u);
  EXPECT_DOUBLE_EQ((dst.GetCellUnchecked<1>(kDoubleNonNull, 0)), 1.5);
  EXPECT_DOUBLE_EQ((dst.GetCellUnchecked<1>(kDoubleNonNull, 1)), -2.25);
  EXPECT_DOUBLE_EQ((dst.GetCellUnchecked<1>(kDoubleNonNull, 2)), 3.0);
}

TEST(ArrowVerify, RoundtripStringIncludingEmpty) {
  StringPool pool;
  auto hello = pool.InternString(base::StringView("hello"));
  auto world = pool.InternString(base::StringView("world"));
  auto empty = pool.InternString(base::StringView(""));
  auto src = MakeDataframe(kStringNonNull, &pool, hello, world, empty);

  // Deserialize into a fresh pool: the recovered strings must be re-interned by
  // value, independently of the source pool's ids.
  std::vector<uint8_t> bytes = Serialize(src, pool);
  StringPool other_pool;
  auto dst_or = Deserialize(bytes, &other_pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 3u);
  EXPECT_EQ(
      other_pool.Get(dst.GetCellUnchecked<1>(kStringNonNull, 0)).ToStdString(),
      "hello");
  EXPECT_EQ(
      other_pool.Get(dst.GetCellUnchecked<1>(kStringNonNull, 1)).ToStdString(),
      "world");
  EXPECT_EQ(
      other_pool.Get(dst.GetCellUnchecked<1>(kStringNonNull, 2)).ToStdString(),
      "");
}

TEST(ArrowVerify, RoundtripDenseNull) {
  StringPool pool;
  auto src =
      MakeDataframe(kUint32DenseNull, &pool, std::optional<uint32_t>{10},
                    std::optional<uint32_t>{}, std::optional<uint32_t>{30},
                    std::optional<uint32_t>{}, std::optional<uint32_t>{50});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 5u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kUint32DenseNull, 0)),
            std::optional<uint32_t>{10});
  EXPECT_EQ((dst.GetCellUnchecked<1>(kUint32DenseNull, 1)),
            std::optional<uint32_t>{});
  EXPECT_EQ((dst.GetCellUnchecked<1>(kUint32DenseNull, 2)),
            std::optional<uint32_t>{30});
  EXPECT_EQ((dst.GetCellUnchecked<1>(kUint32DenseNull, 3)),
            std::optional<uint32_t>{});
  EXPECT_EQ((dst.GetCellUnchecked<1>(kUint32DenseNull, 4)),
            std::optional<uint32_t>{50});
}

TEST(ArrowVerify, RoundtripDoubleDenseNull) {
  StringPool pool;
  auto src = MakeDataframe(kDoubleDenseNull, &pool, std::optional<double>{1.5},
                           std::optional<double>{}, std::optional<double>{3.0});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 3u);
  auto v0 = dst.GetCellUnchecked<1>(kDoubleDenseNull, 0);
  auto v1 = dst.GetCellUnchecked<1>(kDoubleDenseNull, 1);
  auto v2 = dst.GetCellUnchecked<1>(kDoubleDenseNull, 2);
  ASSERT_TRUE(v0.has_value());
  EXPECT_DOUBLE_EQ(*v0, 1.5);
  EXPECT_FALSE(v1.has_value());
  ASSERT_TRUE(v2.has_value());
  EXPECT_DOUBLE_EQ(*v2, 3.0);
}

TEST(ArrowVerify, RoundtripSparseNull) {
  StringPool pool;
  auto src = MakeDataframe(kInt64SparsePopcountAlways, &pool,
                           std::optional<int64_t>{-7}, std::optional<int64_t>{},
                           std::optional<int64_t>{99});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 3u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kInt64SparsePopcountAlways, 0)),
            std::optional<int64_t>{-7});
  EXPECT_EQ((dst.GetCellUnchecked<1>(kInt64SparsePopcountAlways, 1)),
            std::optional<int64_t>{});
  EXPECT_EQ((dst.GetCellUnchecked<1>(kInt64SparsePopcountAlways, 2)),
            std::optional<int64_t>{99});
}

// A sparse column longer than 64 rows: the present/missing pattern must survive
// reconstruction across the 64-bit validity-word boundary.
TEST(ArrowVerify, RoundtripSparseNullAcrossWordBoundary) {
  StringPool pool;
  auto src = Dataframe::CreateFromTypedSpec(kInt64SparsePopcountAlways, &pool);
  for (int64_t i = 0; i < 200; i++) {
    src.InsertUnchecked(kInt64SparsePopcountAlways, std::monostate{},
                        i % 3 == 0 ? std::optional<int64_t>{}
                                   : std::optional<int64_t>{i * 100});
  }
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 200u);
  for (uint32_t i = 0; i < 200; i++) {
    auto expected = i % 3 == 0 ? std::optional<int64_t>{}
                               : std::optional<int64_t>{int64_t{i} * 100};
    EXPECT_EQ((dst.GetCellUnchecked<1>(kInt64SparsePopcountAlways, i)), expected)
        << "row " << i;
  }
}

TEST(ArrowVerify, RoundtripAllNullSparseColumn) {
  StringPool pool;
  auto src =
      MakeDataframe(kInt64SparsePopcountAlways, &pool, std::optional<int64_t>{},
                    std::optional<int64_t>{}, std::optional<int64_t>{});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 3u);
  for (uint32_t row = 0; row < dst.row_count(); ++row) {
    EXPECT_FALSE(
        (dst.GetCellUnchecked<1>(kInt64SparsePopcountAlways, row)).has_value());
  }
}

TEST(ArrowVerify, RoundtripEmptySparseColumn) {
  StringPool pool;
  auto src = Dataframe::CreateFromTypedSpec(kInt32Sparse, &pool);
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);
  EXPECT_EQ(dst.row_count(), 0u);
}

TEST(ArrowVerify, RoundtripStringSparseNull) {
  StringPool pool;
  auto hello = pool.InternString(base::StringView("hello"));
  auto world = pool.InternString(base::StringView("world"));
  auto src = MakeDataframe(
      kStringSparse, &pool, std::optional<StringPool::Id>{hello},
      std::optional<StringPool::Id>{}, std::optional<StringPool::Id>{world});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 3u);
  auto v0 = dst.GetCellUnchecked<1>(kStringSparse, 0);
  auto v1 = dst.GetCellUnchecked<1>(kStringSparse, 1);
  auto v2 = dst.GetCellUnchecked<1>(kStringSparse, 2);
  ASSERT_TRUE(v0.has_value());
  EXPECT_EQ(pool.Get(*v0).ToStdString(), "hello");
  EXPECT_FALSE(v1.has_value());
  ASSERT_TRUE(v2.has_value());
  EXPECT_EQ(pool.Get(*v2).ToStdString(), "world");
}

TEST(ArrowVerify, RoundtripStringDenseNull) {
  StringPool pool;
  auto hello = pool.InternString(base::StringView("hello"));
  auto src = MakeDataframe(kStringDenseNull, &pool,
                           std::optional<StringPool::Id>{hello},
                           std::optional<StringPool::Id>{});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 2u);
  auto v0 = dst.GetCellUnchecked<1>(kStringDenseNull, 0);
  ASSERT_TRUE(v0.has_value());
  EXPECT_EQ(pool.Get(*v0).ToStdString(), "hello");
  EXPECT_FALSE((dst.GetCellUnchecked<1>(kStringDenseNull, 1)).has_value());
}

TEST(ArrowVerify, RoundtripIdOnly) {
  StringPool pool;
  auto src = Dataframe::CreateFromTypedSpec(kIdOnly, &pool);
  src.InsertUnchecked(kIdOnly, std::monostate{});
  src.InsertUnchecked(kIdOnly, std::monostate{});
  src.InsertUnchecked(kIdOnly, std::monostate{});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 3u);
  EXPECT_EQ((dst.GetCellUnchecked<0>(kIdOnly, 0)), 0u);
  EXPECT_EQ((dst.GetCellUnchecked<0>(kIdOnly, 2)), 2u);
}

TEST(ArrowVerify, RoundtripMultiColumn) {
  StringPool pool;
  auto a = pool.InternString(base::StringView("a"));
  auto bb = pool.InternString(base::StringView("bb"));
  auto src = Dataframe::CreateFromTypedSpec(kMultiColumn, &pool);
  src.InsertUnchecked(kMultiColumn, std::monostate{}, int64_t{100}, a,
                      std::optional<double>{0.5});
  src.InsertUnchecked(kMultiColumn, std::monostate{}, int64_t{200}, bb,
                      std::optional<double>{});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  ASSERT_EQ(dst.row_count(), 2u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kMultiColumn, 0)), 100);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kMultiColumn, 1)), 200);
  EXPECT_EQ(pool.Get(dst.GetCellUnchecked<2>(kMultiColumn, 0)).ToStdString(),
            "a");
  EXPECT_EQ(pool.Get(dst.GetCellUnchecked<2>(kMultiColumn, 1)).ToStdString(),
            "bb");
  auto d0 = dst.GetCellUnchecked<3>(kMultiColumn, 0);
  ASSERT_TRUE(d0.has_value());
  EXPECT_DOUBLE_EQ(*d0, 0.5);
  EXPECT_FALSE((dst.GetCellUnchecked<3>(kMultiColumn, 1)).has_value());

  // The column properties come from the spec passed to the reader and must
  // survive: storage type, null storage, sort state and duplicate state.
  DataframeSpec want = src.CreateSpec();
  DataframeSpec got = dst.CreateSpec();
  ASSERT_EQ(got.column_specs.size(), want.column_specs.size());
  for (size_t i = 0; i < want.column_specs.size(); ++i) {
    const ColumnSpec& w = want.column_specs[i];
    const ColumnSpec& g = got.column_specs[i];
    EXPECT_EQ(g.type.index(), w.type.index()) << "column " << i;
    EXPECT_EQ(g.nullability.index(), w.nullability.index()) << "column " << i;
    EXPECT_EQ(g.sort_state.index(), w.sort_state.index()) << "column " << i;
    EXPECT_EQ(g.duplicate_state.index(), w.duplicate_state.index())
        << "column " << i;
  }
}

// Every storage type under one null kind, read back cell by cell. The doubles
// are not exact in single precision, and the reader gets the bytes in small
// chunks so validity, value and string buffers cross chunk boundaries.
template <typename Spec>
void ExpectEveryTypeRoundtrip(const Spec& spec) {
  StringPool pool;
  auto first = pool.InternString(base::StringView("first"));
  auto third = pool.InternString(base::StringView("third"));
  auto src = Dataframe::CreateFromTypedSpec(spec, &pool);
  src.InsertUnchecked(spec, std::monostate{},
                      std::optional<uint32_t>{4000000000u},
                      std::optional<int32_t>{},
                      std::optional<int64_t>{-9000000000},
                      std::optional<double>{0.1},
                      std::optional<StringPool::Id>{first});
  src.InsertUnchecked(spec, std::monostate{}, std::optional<uint32_t>{},
                      std::optional<int32_t>{-7}, std::optional<int64_t>{},
                      std::optional<double>{}, std::optional<StringPool::Id>{});
  src.InsertUnchecked(spec, std::monostate{}, std::optional<uint32_t>{3},
                      std::optional<int32_t>{2147483647},
                      std::optional<int64_t>{},
                      std::optional<double>{1e-300},
                      std::optional<StringPool::Id>{third});
  src.InsertUnchecked(spec, std::monostate{}, std::optional<uint32_t>{},
                      std::optional<int32_t>{}, std::optional<int64_t>{5},
                      std::optional<double>{-2.5e100},
                      std::optional<StringPool::Id>{});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  StringPool out_pool;
  auto dst_or = Deserialize(bytes, &out_pool, src.CreateSpec(),
                            /*chunk_size=*/5);
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);
  ASSERT_EQ(dst.row_count(), 4u);

  EXPECT_EQ((dst.GetCellUnchecked<1>(spec, 0)),
            std::optional<uint32_t>{4000000000u});
  EXPECT_FALSE((dst.GetCellUnchecked<1>(spec, 1)).has_value());
  EXPECT_EQ((dst.GetCellUnchecked<1>(spec, 2)), std::optional<uint32_t>{3});
  EXPECT_FALSE((dst.GetCellUnchecked<1>(spec, 3)).has_value());

  EXPECT_FALSE((dst.GetCellUnchecked<2>(spec, 0)).has_value());
  EXPECT_EQ((dst.GetCellUnchecked<2>(spec, 1)), std::optional<int32_t>{-7});
  EXPECT_EQ((dst.GetCellUnchecked<2>(spec, 2)),
            std::optional<int32_t>{2147483647});
  EXPECT_FALSE((dst.GetCellUnchecked<2>(spec, 3)).has_value());

  EXPECT_EQ((dst.GetCellUnchecked<3>(spec, 0)),
            std::optional<int64_t>{-9000000000});
  EXPECT_FALSE((dst.GetCellUnchecked<3>(spec, 1)).has_value());
  EXPECT_FALSE((dst.GetCellUnchecked<3>(spec, 2)).has_value());
  EXPECT_EQ((dst.GetCellUnchecked<3>(spec, 3)), std::optional<int64_t>{5});

  auto d0 = dst.GetCellUnchecked<4>(spec, 0);
  auto d2 = dst.GetCellUnchecked<4>(spec, 2);
  auto d3 = dst.GetCellUnchecked<4>(spec, 3);
  ASSERT_TRUE(d0.has_value());
  EXPECT_DOUBLE_EQ(*d0, 0.1);
  EXPECT_FALSE((dst.GetCellUnchecked<4>(spec, 1)).has_value());
  ASSERT_TRUE(d2.has_value());
  EXPECT_DOUBLE_EQ(*d2, 1e-300);
  ASSERT_TRUE(d3.has_value());
  EXPECT_DOUBLE_EQ(*d3, -2.5e100);

  auto s0 = dst.GetCellUnchecked<5>(spec, 0);
  auto s2 = dst.GetCellUnchecked<5>(spec, 2);
  ASSERT_TRUE(s0.has_value());
  EXPECT_EQ(out_pool.Get(*s0).ToStdString(), "first");
  EXPECT_FALSE((dst.GetCellUnchecked<5>(spec, 1)).has_value());
  ASSERT_TRUE(s2.has_value());
  EXPECT_EQ(out_pool.Get(*s2).ToStdString(), "third");
  EXPECT_FALSE((dst.GetCellUnchecked<5>(spec, 3)).has_value());
}

TEST(ArrowVerify, RoundtripEveryTypeDenseNull) {
  ExpectEveryTypeRoundtrip(kEveryTypeDenseNull);
}

TEST(ArrowVerify, RoundtripEveryTypeSparseNull) {
  ExpectEveryTypeRoundtrip(kEveryTypeSparse);
}

// Plain sparse columns and sparse columns whose popcount is dropped at
// finalization cannot be read cell by cell once finalized. Check them by
// writing the frame that came back out again and reading each row's validity
// bit and value from that second file.
template <typename Spec, typename T>
void ExpectSparseReadBack(const Spec& spec,
                          const std::vector<std::optional<T>>& cells) {
  StringPool pool;
  auto src = Dataframe::CreateFromTypedSpec(spec, &pool);
  for (const auto& cell : cells) {
    src.InsertUnchecked(spec, std::monostate{}, cell);
  }
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec(), /*chunk_size=*/5);
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);
  ASSERT_EQ(dst.row_count(), cells.size());

  std::vector<uint8_t> again = Serialize(dst, pool);
  auto batch = ReadRecordBatch(again);
  ASSERT_TRUE(batch);
  ASSERT_EQ(batch->buffers.size(), 2u);
  for (uint32_t row = 0; row < cells.size(); ++row) {
    uint32_t bits = ReadBodyValue<uint8_t>(again, *batch, 0, row / 8);
    bool present = (bits & (uint32_t{1} << (row % 8))) != 0;
    EXPECT_EQ(present, cells[row].has_value()) << "row " << row;
    if (present && cells[row].has_value()) {
      // Compare the stored bits, so doubles must come back exactly.
      T value = ReadBodyValue<T>(again, *batch, 1, row);
      T expected = *cells[row];
      EXPECT_EQ(memcmp(&value, &expected, sizeof(T)), 0) << "row " << row;
    }
  }
}

TEST(ArrowVerify, RoundtripPlainSparseNull) {
  std::vector<std::optional<int32_t>> cells;
  for (int32_t i = 0; i < 70; ++i) {
    bool present = i % 4 == 1 || i == 69;
    cells.push_back(present ? std::optional<int32_t>{i * -1000}
                            : std::optional<int32_t>{});
  }
  ExpectSparseReadBack(kInt32Sparse, cells);
}

TEST(ArrowVerify, RoundtripSparseNullWithPopcountUntilFinalization) {
  std::vector<std::optional<double>> cells;
  for (int32_t i = 0; i < 70; ++i) {
    bool present = i % 3 == 2 || i == 66;
    double value = 0.1 * static_cast<double>(i);
    cells.push_back(present ? std::optional<double>{value}
                            : std::optional<double>{});
  }
  ExpectSparseReadBack(kDoubleSparseUntilFinalization, cells);
}

// ===========================================================================
// Reader input shapes: chunked, non-zero start offset, unaligned.
// ===========================================================================

TEST(ArrowVerify, RoundtripChunkedInput) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{1}, uint32_t{2},
                           uint32_t{3}, uint32_t{4});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec(), /*chunk_size=*/7);
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);
  ASSERT_EQ(dst.row_count(), 4u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kUint32NonNull, 0)), 1u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kUint32NonNull, 3)), 4u);
}

TEST(ArrowVerify, RoundtripNonZeroStartOffset) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{42});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  // A reader whose window does not start at file offset zero.
  util::TraceBlobViewReader reader;
  std::vector<uint8_t> padding(123, 0xAB);
  reader.PushBack(
      TraceBlobView(TraceBlob::CopyFrom(padding.data(), padding.size())));
  reader.PushBack(
      TraceBlobView(TraceBlob::CopyFrom(bytes.data(), bytes.size())));
  ASSERT_TRUE(reader.PopFrontUntil(padding.size()));

  auto dst_or = DeserializeFromArrow(reader, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);
  ASSERT_EQ(dst.row_count(), 1u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kUint32NonNull, 0)), 42u);
}

TEST(ArrowVerify, RoundtripUnalignedInput) {
  StringPool pool;
  auto value = pool.InternString(base::StringView("unaligned"));
  auto src = MakeDataframe(kStringNonNull, &pool, value);
  std::vector<uint8_t> bytes = Serialize(src, pool);

  // A single-byte prefix shifts every Arrow buffer off its natural alignment.
  std::vector<uint8_t> combined(1, 0xAB);
  combined.insert(combined.end(), bytes.begin(), bytes.end());
  util::TraceBlobViewReader reader;
  reader.PushBack(
      TraceBlobView(TraceBlob::CopyFrom(combined.data(), combined.size())));
  ASSERT_TRUE(reader.PopFrontBytes(1));

  StringPool output_pool;
  auto dst_or = DeserializeFromArrow(reader, &output_pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);
  EXPECT_EQ(
      output_pool.Get(dst.GetCellUnchecked<1>(kStringNonNull, 0)).ToStdString(),
      "unaligned");
}

// ===========================================================================
// Arrow files written by another writer (PyArrow 18.1.0).
// ===========================================================================
//
// Each fixture below is the exact file PyArrow wrote, as hex. They were made
// with pyarrow.ipc.new_file(sink, table.schema) and
// writer.write_table(table, max_chunksize=N):
//
//   kPyArrowEveryType: 150 rows in batches of 50, i = 0..149,
//     u32 uint32  None if i % 4 == 1 else 4000000000 - 3 * i
//     i32 int32   (i - 70) * 30011
//     i64 int64   None if i % 3 == 0 or 60 <= i < 75 else (i - 75) * 1000000007
//     f64 double  None if i % 7 == 3 else (i + 1) / 3.0
//     str string  None if i % 5 == 2 else ('' if i % 11 == 0 else f's{i * i}')
//   kPyArrowEmpty: int64 "ts" and string "name" with no rows.
//   kPyArrowDictionary: 100 rows in batches of 40, dictionary-encoded strings,
//     state  int8 indices   None if i % 6 == 4 else
//                           ['idle', 'running', 'sleeping', 'zombie', ''][i * 3 % 5]
//     cpu    int32 indices  f'cpu{i % 9}'
//     thread uint16 indices None if i % 10 == 9 else f'thread-{i % 13}'
//   kPyArrowTypes: a int64 [1, -2], b int32 [3, -4], c uint32 [5, 6],
//     d double [0.5, 1.5], e string ['x', 'y'].
//   kPyArrowFloat32: d float [0.5, 1.5].
//   kPyArrowIndexPastDictionary: int32 indices [0, 2, 1] into ['a', 'b'].
//   kPyArrowNegativeIndex: int8 indices [1, -1, 0] into ['a', 'b'].

constexpr char kPyArrowEveryType[] =
    "4152524f57310000ffffffff400100001000000000000a000c000600050008000a000000"
    "000104000c0000000800080000000400080000000400000005000000dc00000094000000"
    "64000000300000000400000048ffffff0000010510000000180000000400000000000000"
    "0300000073747200040004000400000070ffffff00000103100000001c00000004000000"
    "00000000030000006636340000000600080006000600000000000200a0ffffff00000102"
    "100000001400000004000000000000000300000069363400d4ffffff0000000140000000"
    "ccffffff00000102100000001c0000000400000000000000030000006933320008000c00"
    "08000700080000000000000120000000100014000800060007000c000000100010000000"
    "00000102100000001c000000040000000000000003000000753332000000060008000400"
    "060000002000000000000000ffffffff5801000014000000000000000c00160006000500"
    "08000c000c0000000003040018000000a00600000000000000000a0018000c0004000800"
    "0a000000cc000000100000003200000000000000000000000b0000000000000000000000"
    "13000000000000001800000000000000c800000000000000e00000000000000000000000"
    "00000000e000000000000000c800000000000000a8010000000000001300000000000000"
    "c00100000000000090010000000000005003000000000000130000000000000068030000"
    "000000009001000000000000f80400000000000013000000000000001005000000000000"
    "cc00000000000000e005000000000000c000000000000000000000000500000032000000"
    "000000000d00000000000000320000000000000000000000000000003200000000000000"
    "11000000000000003200000000000000070000000000000032000000000000000a000000"
    "00000000dddddddddddddddddddddddddddddddddddd1d000000000000286bee00000000"
    "fa276beef7276beef4276bee00000000ee276beeeb276beee8276bee00000000e2276bee"
    "df276beedc276bee00000000d6276beed3276beed0276bee00000000ca276beec7276bee"
    "c4276bee00000000be276beebb276beeb8276bee00000000b2276beeaf276beeac276bee"
    "00000000a6276beea3276beea0276bee000000009a276bee97276bee94276bee00000000"
    "8e276bee8b276bee88276bee0000000082276bee7f276bee7c276bee0000000076276bee"
    "73276bee70276bee00000000def1dfff1967e0ff54dce0ff8f51e1ffcac6e1ff053ce2ff"
    "40b1e2ff7b26e3ffb69be3fff110e4ff2c86e4ff67fbe4ffa270e5ffdde5e5ff185be6ff"
    "53d0e6ff8e45e7ffc9bae7ff0430e8ff3fa5e8ff7a1ae9ffb58fe9fff004eaff2b7aeaff"
    "66efeaffa164ebffdcd9ebff174fecff52c4ecff8d39edffc8aeedff0324eeff3e99eeff"
    "790eefffb483efffeff8efff2a6ef0ff65e3f0ffa058f1ffdbcdf1ff1643f2ff51b8f2ff"
    "8c2df3ffc7a2f3ff0218f4ff3d8df4ff7802f5ffb377f5ffeeecf5ff2962f6ffb66ddbb6"
    "6ddbb60d00b06ddbb66ddbb66ddb3600000000000000000000000000fa9941c5eeffffff"
    "0164dc00efffffff00000000000000000ff81178efffffff16c2acb3efffffff00000000"
    "000000002456e22af0ffffff2b207d66f0ffffff000000000000000039b4b2ddf0ffffff"
    "407e4d19f1ffffff00000000000000004e128390f1ffffff55dc1dccf1ffffff00000000"
    "0000000063705343f2ffffff6a3aee7ef2ffffff000000000000000078ce23f6f2ffffff"
    "7f98be31f3ffffff00000000000000008d2cf4a8f3ffffff94f68ee4f3ffffff00000000"
    "00000000a28ac45bf4ffffffa9545f97f4ffffff0000000000000000b7e8940ef5ffffff"
    "beb22f4af5ffffff0000000000000000cc4665c1f5ffffffd31000fdf5ffffff00000000"
    "00000000e1a43574f6ffffffe86ed0aff6ffffff0000000000000000f6020627f7ffffff"
    "fdcca062f7ffffff00000000000000000b61d6d9f7ffffff122b7115f8ffffff00000000"
    "0000000020bfa68cf8ffffff278941c8f8ffffff0000000000000000351d773ff9ffffff"
    "3ce7117bf9ffffff00000000000000004a7b47f2f9fffffff7fbfd7ebfdfeff7fbfd7ebf"
    "dfeff7fbfd7e3f0000000000555555555555d53f555555555555e53f000000000000f03f"
    "0000000000000000abaaaaaaaaaafa3f0000000000000040abaaaaaaaaaa024055555555"
    "555505400000000000000840abaaaaaaaaaa0a4000000000000000000000000000001040"
    "5555555555551140abaaaaaaaaaa124000000000000014405555555555551540abaaaaaa"
    "aaaa164000000000000000005555555555551940abaaaaaaaaaa1a400000000000001c40"
    "5555555555551d40abaaaaaaaaaa1e400000000000002040000000000000000055555555"
    "555521400000000000002240abaaaaaaaaaa224055555555555523400000000000002440"
    "abaaaaaaaaaa244000000000000000000000000000002640abaaaaaaaaaa264055555555"
    "555527400000000000002840abaaaaaaaaaa284055555555555529400000000000000000"
    "abaaaaaaaaaa2a405555555555552b400000000000002c40abaaaaaaaaaa2c4055555555"
    "55552d400000000000002e4000000000000000005555555555552f400000000000003040"
    "5555555555553040abaaaaaaaaaa30407befbdf7de7befbdf7de7befbdf7de7befbd3700"
    "000000000000000000000000020000000200000004000000070000000a0000000d000000"
    "0d00000010000000130000001700000017000000170000001b0000001f00000023000000"
    "27000000270000002b0000002f0000003300000037000000370000003b0000003f000000"
    "4300000047000000470000004b0000004f00000053000000570000005700000057000000"
    "5c0000006100000066000000660000006b00000070000000750000007a0000007a000000"
    "7f0000007f0000008400000089000000890000008e000000930000000000000073317339"
    "733136733235733336733634733831733130307331363973313936733232357332353673"
    "333234733336317334303073343431733532397335373673363235733637367337383473"
    "383431733930307339363173313135367331323235733132393673313434347331353231"
    "733136303073313638317331383439733230323573323131367332333034733234303173"
    "323530307332363031733238303973323931367333313336733333363473333438317333"
    "3630307333373231ffffffff5801000014000000000000000c0016000600050008000c00"
    "0c0000000003040018000000600600000000000000000a0018000c00040008000a000000"
    "cc000000100000003200000000000000000000000b000000000000000000000007000000"
    "000000000800000000000000c800000000000000d0000000000000000000000000000000"
    "d000000000000000c80000000000000098010000000000000700000000000000a0010000"
    "000000009001000000000000300300000000000007000000000000003803000000000000"
    "9001000000000000c8040000000000000700000000000000d004000000000000cc000000"
    "00000000a005000000000000c00000000000000000000000050000003200000000000000"
    "0c000000000000003200000000000000000000000000000032000000000000001b000000"
    "000000003200000000000000070000000000000032000000000000000a00000000000000"
    "77777777777703006a276bee67276bee64276bee000000005e276bee5b276bee58276bee"
    "0000000052276bee4f276bee4c276bee0000000046276bee43276bee40276bee00000000"
    "3a276bee37276bee34276bee000000002e276bee2b276bee28276bee0000000022276bee"
    "1f276bee1c276bee0000000016276bee13276bee10276bee000000000a276bee07276bee"
    "04276bee00000000fe266beefb266beef8266bee00000000f2266beeef266beeec266bee"
    "00000000e6266beee3266beee0266bee00000000da266beed7266bee64d7f6ff9f4cf7ff"
    "dac1f7ff1537f8ff50acf8ff8b21f9ffc696f9ff010cfaff3c81faff77f6faffb26bfbff"
    "ede0fbff2856fcff63cbfcff9e40fdffd9b5fdff142bfeff4fa0feff8a15ffffc58affff"
    "000000003b75000076ea0000b15f0100ecd40100274a020062bf02009d340300d8a90300"
    "131f04004e94040089090500c47e0500fff305003a69060075de0600b0530700ebc80700"
    "263e080061b308009c280900d79d090012130a004d880a0088fd0a00c3720b00fee70b00"
    "395d0c0074d20c00af470d006d03006cdbb601005145e22dfaffffff0000000000000000"
    "5fd917a5faffffff66a3b2e0faffffff00000000000000007437e857fbffffff7b018393"
    "fbffffff00000000000000008995b80afcffffff905f5346fcffffff0000000000000000"
    "000000000000000000000000000000000000000000000000000000000000000000000000"
    "000000000000000000000000000000000000000000000000000000000000000000000000"
    "000000000000000000000000000000000000000000000000000000000000000000000000"
    "00000000000000000000000007ca9a3b000000000e943577000000000000000000000000"
    "1c286bee0000000023f2052a01000000000000000000000031863ba1010000003850d6dc"
    "01000000000000000000000046e40b54020000004daea68f020000000000000000000000"
    "5b42dc0603000000620c774203000000000000000000000070a0acb903000000776a47f5"
    "03000000000000000000000085fe7c6c040000008cc817a8040000000000000000000000"
    "9a5c4d1f05000000a126e85a050000000000000000000000fbfd7ebfdfef030000000000"
    "000031405555555555553140000000000000000000000000000032405555555555553240"
    "abaaaaaaaaaa324000000000000033405555555555553340abaaaaaaaaaa334000000000"
    "000000005555555555553440abaaaaaaaaaa344000000000000035405555555555553540"
    "abaaaaaaaaaa354000000000000036400000000000000000abaaaaaaaaaa364000000000"
    "000037405555555555553740abaaaaaaaaaa374000000000000038405555555555553840"
    "000000000000000000000000000039405555555555553940abaaaaaaaaaa394000000000"
    "00003a405555555555553a40abaaaaaaaaaa3a4000000000000000005555555555553b40"
    "abaaaaaaaaaa3b400000000000003c405555555555553c40abaaaaaaaaaa3c4000000000"
    "00003d400000000000000000abaaaaaaaaaa3d400000000000003e405555555555553e40"
    "abaaaaaaaaaa3e400000000000003f405555555555553f40000000000000000000000000"
    "00004040abaaaaaaaa2a404055555555555540400000000000804040abaaaaaaaaaa4040"
    "7befbdf7de7b030000000000050000000a0000000a0000000f0000001400000014000000"
    "19000000190000001e00000023000000280000002d0000002d0000003200000037000000"
    "3c0000003c0000003c00000041000000460000004b000000500000005000000055000000"
    "5a0000005f0000006400000064000000690000006e000000730000007800000078000000"
    "7d00000082000000870000008c0000008c0000008c00000091000000960000009b000000"
    "9b000000a0000000a5000000aa000000af000000af000000b4000000b400000000000000"
    "733235303073323630317332383039733239313673333133367333333634733334383173"
    "333630307333373231733339363973343039367334323235733436323473343736317334"
    "393030733530343173353332397335343736733536323573353737367336303834733632"
    "343173363430307336353631733638383973373035367337323235733733393673373932"
    "317338313030733832383173383634397338383336733930323573393231367339363034"
    "733130303030733130323031ffffffff5801000014000000000000000c00160006000500"
    "08000c000c0000000003040018000000800600000000000000000a0018000c0004000800"
    "0a000000cc000000100000003200000000000000000000000b0000000000000000000000"
    "07000000000000000800000000000000c800000000000000d00000000000000000000000"
    "00000000d000000000000000c80000000000000098010000000000000700000000000000"
    "a00100000000000090010000000000003003000000000000070000000000000038030000"
    "000000009001000000000000c8040000000000000700000000000000d004000000000000"
    "cc00000000000000a005000000000000de00000000000000000000000500000032000000"
    "000000000d00000000000000320000000000000000000000000000003200000000000000"
    "10000000000000003200000000000000070000000000000032000000000000000a000000"
    "00000000dddddddddddd0100d4266bee00000000ce266beecb266beec8266bee00000000"
    "c2266beebf266beebc266bee00000000b6266beeb3266beeb0266bee00000000aa266bee"
    "a7266beea4266bee000000009e266bee9b266bee98266bee0000000092266bee8f266bee"
    "8c266bee0000000086266bee83266bee80266bee000000007a266bee77266bee74266bee"
    "000000006e266bee6b266bee68266bee0000000062266bee5f266bee5c266bee00000000"
    "56266bee53266bee50266bee000000004a266bee47266bee44266bee00000000eabc0d00"
    "25320e0060a70e009b1c0f00d6910f00110710004c7c100087f11000c2661100fddb1100"
    "3851120073c61200ae3b1300e9b01300242614005f9b14009a101500d585150010fb1500"
    "4b70160086e51600c15a1700fccf17003745180072ba1800ad2f1900e8a41900231a1a00"
    "5e8f1a0099041b00d4791b000fef1b004a641c0085d91c00c04e1d00fbc31d0036391e00"
    "71ae1e00ac231f00e7981f00220e20005d83200098f82000d36d21000ee3210049582200"
    "84cd2200bf422300fab72300352d2400dbb66ddbb66d0300afba1dd205000000b684b80d"
    "060000000000000000000000c418ee8406000000cbe288c0060000000000000000000000"
    "d976be3707000000e0405973070000000000000000000000eed48eea07000000f59e2926"
    "08000000000000000000000003335f9d080000000afdf9d8080000000000000000000000"
    "18912f50090000001f5bca8b0900000000000000000000002defff020a00000034b99a3e"
    "0a0000000000000000000000424dd0b50a00000049176bf10a0000000000000000000000"
    "57aba0680b0000005e753ba40b00000000000000000000006c09711b0c00000073d30b57"
    "0c0000000000000000000000816741ce0c0000008831dc090d0000000000000000000000"
    "96c511810d0000009d8facbc0d0000000000000000000000ab23e2330e000000b2ed7c6f"
    "0e0000000000000000000000c081b2e60e000000c74b4d220f0000000000000000000000"
    "d5df82990f000000dca91dd50f0000000000000000000000ea3d534c10000000f107ee87"
    "100000000000000000000000ff9b23ff100000000666be3a11000000fd7ebfdfeff70300"
    "5555555555d540400000000000000000abaaaaaaaa2a4140555555555555414000000000"
    "00804140abaaaaaaaaaa41405555555555d5414000000000000042400000000000000000"
    "55555555555542400000000000804240abaaaaaaaaaa42405555555555d5424000000000"
    "00004340abaaaaaaaa2a434000000000000000000000000000804340abaaaaaaaaaa4340"
    "5555555555d543400000000000004440abaaaaaaaa2a4440555555555555444000000000"
    "00000000abaaaaaaaaaa44405555555555d544400000000000004540abaaaaaaaa2a4540"
    "5555555555554540000000000080454000000000000000005555555555d5454000000000"
    "00004640abaaaaaaaa2a464055555555555546400000000000804640abaaaaaaaaaa4640"
    "00000000000000000000000000004740abaaaaaaaa2a4740555555555555474000000000"
    "00804740abaaaaaaaaaa47405555555555d547400000000000000000abaaaaaaaa2a4840"
    "55555555555548400000000000804840abaaaaaaaaaa48405555555555d5484000000000"
    "000049407befbdf7de7b030000000000060000000c0000000c0000001200000018000000"
    "1e00000024000000240000002a000000300000003000000036000000360000003c000000"
    "42000000480000004e0000004e000000540000005a000000600000006000000060000000"
    "660000006c0000007200000078000000780000007e000000840000008a00000090000000"
    "90000000960000009c000000a2000000a8000000a8000000ae000000b4000000ba000000"
    "c0000000c0000000c0000000c6000000cc000000d2000000d2000000d8000000de000000"
    "000000007331303030307331303230317331303630397331303831367331313032357331"
    "313233367331313636347331313838317331323332317331323736397331323939367331"
    "333232357331333435367331333932347331343136317331343430307331353132397331"
    "353337367331353632357331353837367331363338347331363634317331363930307331"
    "373136317331373638397331373935367331383232357331383439367331393034347331"
    "393332317331393630307331393838317332303733367332313032357332313331367332"
    "313930347332323230310000ffffffff00000000100000000c001400060008000c001000"
    "0c0000000000040068000000580000000400000003000000500100000000000060010000"
    "00000000a006000000000000500900000000000060010000000000006006000000000000"
    "101100000000000060010000000000008006000000000000000000000000000008000800"
    "00000400080000000400000005000000dc00000094000000640000003000000004000000"
    "48ffffff0000010510000000180000000400000000000000030000007374720004000400"
    "0400000070ffffff00000103100000001c00000004000000000000000300000066363400"
    "00000600080006000600000000000200a0ffffff00000102100000001400000004000000"
    "000000000300000069363400d4ffffff0000000140000000ccffffff0000010210000000"
    "1c0000000400000000000000030000006933320008000c00080007000800000000000001"
    "20000000100014000800060007000c00000010001000000000000102100000001c000000"
    "040000000000000003000000753332000000060008000400060000002000000098010000"
    "4152524f5731";

constexpr char kPyArrowEmpty[] =
    "4152524f57310000ffffffffa80000001000000000000a000c000600050008000a000000"
    "000104000c00000008000800000004000800000004000000020000004400000004000000"
    "d4ffffff00000105100000001c0000000400000000000000040000006e616d6500000000"
    "0400040004000000100014000800060007000c0000001000100000000000010210000000"
    "1c0000000400000000000000020000007473000008000c00080007000800000000000001"
    "40000000ffffffff00000000100000000c001400060008000c0010000c00000000000400"
    "1c0000000c00000004000000000000000000000008000800000004000800000004000000"
    "020000004400000004000000d4ffffff00000105100000001c0000000400000000000000"
    "040000006e616d65000000000400040004000000100014000800060007000c0000001000"
    "1000000000000102100000001c0000000400000000000000020000007473000008000c00"
    "08000700080000000000000140000000b80000004152524f5731";

constexpr char kPyArrowDictionary[] =
    "4152524f57310000ffffffff40010000140000000000000000000a000c00060005000800"
    "0a00000000010400040000000cffffff0400000003000000c00000005c00000004000000"
    "5cffffff0000010514000000440000002000000004000000000000000600000074687265"
    "616400000800120008000400080000001400000002000000000000000000060008000400"
    "060000001000000050ffffffb0ffffff0000010514000000400000001c00000004000000"
    "000000000300000063707500080014000800040008000000100000000100000000000000"
    "00000000a8ffffff0000000120000000a0ffffff100018000800060007000c0010001400"
    "100000000000010514000000440000002000000004000000000000000500000073746174"
    "650000000800080000000400080000000c00000008000c00080007000800000000000001"
    "080000000400040004000000ffffffffa800000014000000000000000c00140006000500"
    "08000c000c0000000002040014000000380000000000000008000a000000040008000000"
    "1000000000000a0018000c00040008000a0000004c000000100000000500000000000000"
    "000000000300000000000000000000000000000000000000000000000000000018000000"
    "000000001800000000000000190000000000000000000000010000000500000000000000"
    "000000000000000000000000040000000a00000011000000110000001900000069646c65"
    "7a6f6d62696572756e6e696e67736c656570696e6700000000000000ffffffffb0000000"
    "14000000000000000c0014000600050008000c000c000000000204001400000050000000"
    "0000000008001200080004000800000018000000010000000000000000000a0018000c00"
    "040008000a0000004c000000100000000900000000000000000000000300000000000000"
    "000000000000000000000000000000000000000028000000000000002800000000000000"
    "240000000000000000000000010000000900000000000000000000000000000000000000"
    "04000000080000000c0000001000000014000000180000001c0000002000000024000000"
    "637075306370753163707532637075336370753463707535637075366370753763707538"
    "00000000ffffffffb000000014000000000000000c0014000600050008000c000c000000"
    "0002040014000000a8000000000000000800120008000400080000001800000002000000"
    "0000000000000a0018000c00040008000a0000004c000000100000000d00000000000000"
    "000000000300000000000000000000000000000000000000000000000000000038000000"
    "0000000038000000000000006b0000000000000000000000010000000d00000000000000"
    "000000000000000000000000080000001000000018000000200000002800000030000000"
    "380000004000000048000000510000005a000000630000006b0000007468726561642d30"
    "7468726561642d317468726561642d327468726561642d337468726561642d3474687265"
    "61642d357468726561642d367468726561642d377468726561642d387468726561642d31"
    "307468726561642d31317468726561642d31327468726561642d390000000000ffffffff"
    "e800000014000000000000000c0016000600050008000c000c0000000003040018000000"
    "380100000000000000000a0018000c00040008000a0000007c0000001000000028000000"
    "00000000000000000600000000000000000000000d000000000000001000000000000000"
    "2800000000000000380000000000000000000000000000003800000000000000a0000000"
    "00000000d8000000000000000d00000000000000e8000000000000005000000000000000"
    "000000000300000028000000000000000600000000000000280000000000000000000000"
    "0000000028000000000000000400000000000000effbbeeffbbeeffbbeeffbbe0f000000"
    "000102030000010203040001020304000002030400010003040001020004000102030000"
    "010203040000000001000000020000000300000004000000050000000600000007000000"
    "080000000000000001000000020000000300000004000000050000000600000007000000"
    "080000000000000001000000020000000300000004000000050000000600000007000000"
    "080000000000000001000000020000000300000004000000050000000600000007000000"
    "0800000000000000010000000200000003000000fffdf7df7ffffdf7df7ffffd07000000"
    "000001000200030004000500060007000800000009000a000b0000000100020003000400"
    "05000000070008000c0009000a000b000000010002000000040005000600070008000c00"
    "09000a000b000000ffffffffe800000014000000000000000c0016000600050008000c00"
    "0c0000000003040018000000280100000000000000000a0018000c00040008000a000000"
    "7c0000001000000028000000000000000000000006000000000000000000000005000000"
    "000000000800000000000000280000000000000030000000000000000000000000000000"
    "3000000000000000a000000000000000d0000000000000000500000000000000d8000000"
    "000000005000000000000000000000000300000028000000000000000700000000000000"
    "2800000000000000000000000000000028000000000000000400000000000000beeffbbe"
    "ef0000000001020304000002030400010003040001020004000102030000010203040001"
    "020304000002030404000000050000000600000007000000080000000000000001000000"
    "020000000300000004000000050000000600000007000000080000000000000001000000"
    "020000000300000004000000050000000600000007000000080000000000000001000000"
    "020000000300000004000000050000000600000007000000080000000000000001000000"
    "020000000300000004000000050000000600000007000000fffdf7df7f00000001000200"
    "0300040005000600070008000c0000000a000b0000000100020003000400050006000000"
    "08000c0009000a000b000000010002000300000005000600070008000c0009000a000b00"
    "00000000ffffffffe800000014000000000000000c0016000600050008000c000c000000"
    "0003040018000000a00000000000000000000a0018000c00040008000a0000007c000000"
    "100000001400000000000000000000000600000000000000000000000300000000000000"
    "080000000000000014000000000000002000000000000000000000000000000020000000"
    "000000005000000000000000700000000000000003000000000000007800000000000000"
    "280000000000000000000000030000001400000000000000030000000000000014000000"
    "00000000000000000000000014000000000000000200000000000000fbbe0f0000000000"
    "000100030400010200040001020300000102030400000000080000000000000001000000"
    "020000000300000004000000050000000600000007000000080000000000000001000000"
    "0200000003000000040000000500000006000000070000000800000000000000fffd0700"
    "0000000002000300040005000600070008000c00090000000b0000000100020003000400"
    "0500060007000000ffffffff00000000100000000c001400060008000c0010000c000000"
    "00000400a8000000580000000400000003000000a004000000000000f000000000000000"
    "3801000000000000c806000000000000f0000000000000002801000000000000e0080000"
    "00000000f000000000000000a00000000000000000000000030000005001000000000000"
    "b00000000000000038000000000000003802000000000000b80000000000000050000000"
    "000000004003000000000000b800000000000000a8000000000000000cffffff04000000"
    "03000000c00000005c000000040000005cffffff00000105140000004400000020000000"
    "040000000000000006000000746872656164000008001200080004000800000014000000"
    "02000000000000000000060008000400060000001000000050ffffffb0ffffff00000105"
    "14000000400000001c000000040000000000000003000000637075000800140008000400"
    "0800000010000000010000000000000000000000a8ffffff0000000120000000a0ffffff"
    "100018000800060007000c00100014001000000000000105140000004400000020000000"
    "04000000000000000500000073746174650000000800080000000400080000000c000000"
    "08000c00080007000800000000000001080000000400040004000000e00100004152524f"
    "5731";

constexpr char kPyArrowTypes[] =
    "4152524f57310000ffffffff380100001000000000000a000c000600050008000a000000"
    "000104000c0000000800080000000400080000000400000005000000d000000090000000"
    "60000000300000000400000054ffffff0000010510000000180000000400000000000000"
    "010000006500000004000400040000007cffffff00000103100000001800000004000000"
    "000000000100000064000600080006000600000000000200a8ffffff0000010210000000"
    "1800000004000000000000000100000063000600080004000600000020000000d4ffffff"
    "00000102100000001400000004000000000000000100000062000000c4ffffff00000001"
    "20000000100014000800060007000c00000010001000000000000102100000001c000000"
    "0400000000000000010000006100000008000c0008000700080000000000000140000000"
    "00000000ffffffff5801000014000000000000000c0016000600050008000c000c000000"
    "0003040018000000480000000000000000000a0018000c00040008000a000000cc000000"
    "100000000200000000000000000000000b00000000000000000000000000000000000000"
    "000000000000000010000000000000001000000000000000000000000000000010000000"
    "000000000800000000000000180000000000000000000000000000001800000000000000"
    "080000000000000020000000000000000000000000000000200000000000000010000000"
    "000000003000000000000000000000000000000030000000000000000c00000000000000"
    "400000000000000002000000000000000000000005000000020000000000000000000000"
    "000000000200000000000000000000000000000002000000000000000000000000000000"
    "020000000000000000000000000000000200000000000000000000000000000001000000"
    "00000000feffffffffffffff03000000fcffffff0500000006000000000000000000e03f"
    "000000000000f83f000000000100000002000000000000007879000000000000ffffffff"
    "00000000100000000c001400060008000c0010000c000000000004003800000028000000"
    "040000000100000048010000000000006001000000000000480000000000000000000000"
    "000000000800080000000400080000000400000005000000d00000009000000060000000"
    "300000000400000054ffffff000001051000000018000000040000000000000001000000"
    "6500000004000400040000007cffffff0000010310000000180000000400000000000000"
    "0100000064000600080006000600000000000200a8ffffff000001021000000018000000"
    "04000000000000000100000063000600080004000600000020000000d4ffffff00000102"
    "100000001400000004000000000000000100000062000000c4ffffff0000000120000000"
    "100014000800060007000c00000010001000000000000102100000001c00000004000000"
    "00000000010000006100000008000c000800070008000000000000014000000060010000"
    "4152524f5731";

constexpr char kPyArrowFloat32[] =
    "4152524f57310000ffffffff700000001000000000000a000c000600050008000a000000"
    "000104000c00000008000800000004000800000004000000010000001400000010001400"
    "0800060007000c0000001000100000000000010310000000180000000400000000000000"
    "0100000064000600080006000600000000000100ffffffff880000001400000000000000"
    "0c0016000600050008000c000c0000000003040018000000080000000000000000000a00"
    "18000c00040008000a0000003c0000001000000002000000000000000000000002000000"
    "000000000000000000000000000000000000000000000000080000000000000000000000"
    "01000000020000000000000000000000000000000000003f0000c03fffffffff00000000"
    "100000000c001400060008000c0010000c00000000000400340000002400000004000000"
    "010000008000000000000000900000000000000008000000000000000000000008000800"
    "0000040008000000040000000100000014000000100014000800060007000c0000001000"
    "100000000000010310000000180000000400000000000000010000006400060008000600"
    "0600000000000100980000004152524f5731";

constexpr char kPyArrowIndexPastDictionary[] =
    "4152524f57310000ffffffff900000001000000000000a000c000600050008000a000000"
    "0001040004000000bcffffff040000000100000014000000100018000800060007000c00"
    "10001400100000000000010514000000400000001c000000040000000000000001000000"
    "730000000800080000000400080000000c00000008000c00080007000800000000000001"
    "20000000040004000400000000000000ffffffffa800000014000000000000000c001400"
    "0600050008000c000c0000000002040014000000180000000000000008000a0000000400"
    "080000001000000000000a0018000c00040008000a0000004c0000001000000002000000"
    "000000000000000003000000000000000000000000000000000000000000000000000000"
    "0c0000000000000010000000000000000200000000000000000000000100000002000000"
    "000000000000000000000000000000000100000002000000000000006162000000000000"
    "ffffffff8800000014000000000000000c0016000600050008000c000c00000000030400"
    "18000000100000000000000000000a0018000c00040008000a0000003c00000010000000"
    "030000000000000000000000020000000000000000000000000000000000000000000000"
    "000000000c00000000000000000000000100000003000000000000000000000000000000"
    "00000000020000000100000000000000ffffffff00000000100000000c00140006000800"
    "0c0010000c00000000000400480000002800000004000000010000006801000000000000"
    "900000000000000010000000000000000000000001000000a000000000000000b0000000"
    "000000001800000000000000bcffffff0400000001000000140000001000180008000600"
    "07000c0010001400100000000000010514000000400000001c0000000400000000000000"
    "01000000730000000800080000000400080000000c00000008000c000800070008000000"
    "00000001200000000400040004000000d00000004152524f5731";

constexpr char kPyArrowNegativeIndex[] =
    "4152524f57310000ffffffff900000001000000000000a000c000600050008000a000000"
    "0001040004000000bcffffff040000000100000014000000100018000800060007000c00"
    "10001400100000000000010514000000400000001c000000040000000000000001000000"
    "730000000800080000000400080000000c00000008000c00080007000800000000000001"
    "08000000040004000400000000000000ffffffffa800000014000000000000000c001400"
    "0600050008000c000c0000000002040014000000180000000000000008000a0000000400"
    "080000001000000000000a0018000c00040008000a0000004c0000001000000002000000"
    "000000000000000003000000000000000000000000000000000000000000000000000000"
    "0c0000000000000010000000000000000200000000000000000000000100000002000000"
    "000000000000000000000000000000000100000002000000000000006162000000000000"
    "ffffffff8800000014000000000000000c0016000600050008000c000c00000000030400"
    "18000000080000000000000000000a0018000c00040008000a0000003c00000010000000"
    "030000000000000000000000020000000000000000000000000000000000000000000000"
    "000000000300000000000000000000000100000003000000000000000000000000000000"
    "01ff000000000000ffffffff00000000100000000c001400060008000c0010000c000000"
    "000004004800000028000000040000000100000068010000000000009000000000000000"
    "08000000000000000000000001000000a000000000000000b00000000000000018000000"
    "00000000bcffffff040000000100000014000000100018000800060007000c0010001400"
    "100000000000010514000000400000001c00000004000000000000000100000073000000"
    "0800080000000400080000000c00000008000c0008000700080000000000000108000000"
    "0400040004000000d00000004152524f5731";

std::vector<uint8_t> FromHex(std::string_view hex) {
  std::vector<uint8_t> bytes;
  for (size_t i = 0; i + 1 < hex.size(); i += 2) {
    bytes.push_back(static_cast<uint8_t>(
        std::stoul(std::string(hex.substr(i, 2)), nullptr, 16)));
  }
  return bytes;
}

template <typename Spec>
DataframeSpec UntypedSpec(const Spec& spec) {
  StringPool pool;
  return Dataframe::CreateFromTypedSpec(spec, &pool).CreateSpec();
}

template <typename T>
std::optional<T> AsOptional(T value) {
  return value;
}

template <typename T>
std::optional<T> AsOptional(std::optional<T> value) {
  return value;
}

std::optional<std::string> StringAt(const StringPool& pool,
                                    std::optional<StringPool::Id> id) {
  if (!id) {
    return std::nullopt;
  }
  return pool.Get(*id).ToStdString();
}

std::optional<uint32_t> PyU32(uint32_t i) {
  if (i % 4 == 1) {
    return std::nullopt;
  }
  return 4000000000u - 3 * i;
}

int32_t PyI32(uint32_t i) {
  return (static_cast<int32_t>(i) - 70) * 30011;
}

std::optional<int64_t> PyI64(uint32_t i) {
  if (i % 3 == 0 || (i >= 60 && i < 75)) {
    return std::nullopt;
  }
  return (static_cast<int64_t>(i) - 75) * 1000000007;
}

std::optional<double> PyF64(uint32_t i) {
  if (i % 7 == 3) {
    return std::nullopt;
  }
  return static_cast<double>(i + 1) / 3.0;
}

std::optional<std::string> PyStr(uint32_t i) {
  if (i % 5 == 2) {
    return std::nullopt;
  }
  return i % 11 == 0 ? "" : "s" + std::to_string(i * i);
}

inline constexpr auto kPyEveryTypeDense = CreateTypedDataframeSpec(
    {"_auto_id", "u32", "i32", "i64", "f64", "str"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Uint32{}, DenseNull{}, Unsorted{}),
    CreateTypedColumnSpec(Int32{}, NonNull{}, Unsorted{}),
    CreateTypedColumnSpec(Int64{}, SparseNullWithPopcountAlways{}, Unsorted{}),
    CreateTypedColumnSpec(Double{}, DenseNull{}, Unsorted{}),
    CreateTypedColumnSpec(String{}, SparseNullWithPopcountAlways{}, Unsorted{}));

inline constexpr auto kPyEveryTypeSparse = CreateTypedDataframeSpec(
    {"_auto_id", "u32", "i32", "i64", "f64", "str"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Uint32{}, SparseNullWithPopcountAlways{}, Unsorted{}),
    CreateTypedColumnSpec(Int32{}, DenseNull{}, Unsorted{}),
    CreateTypedColumnSpec(Int64{}, DenseNull{}, Unsorted{}),
    CreateTypedColumnSpec(Double{}, SparseNullWithPopcountAlways{}, Unsorted{}),
    CreateTypedColumnSpec(String{}, DenseNull{}, Unsorted{}));

inline constexpr auto kPyEveryTypePlainSparse = CreateTypedDataframeSpec(
    {"_auto_id", "u32", "i32", "i64", "f64", "str"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Uint32{}, SparseNull{}, Unsorted{}),
    CreateTypedColumnSpec(Int32{}, SparseNull{}, Unsorted{}),
    CreateTypedColumnSpec(Int64{},
                          SparseNullWithPopcountUntilFinalization{},
                          Unsorted{}),
    CreateTypedColumnSpec(Double{}, SparseNull{}, Unsorted{}),
    CreateTypedColumnSpec(String{}, SparseNull{}, Unsorted{}));

inline constexpr auto kPyEmpty = CreateTypedDataframeSpec(
    {"_auto_id", "ts", "name"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Int64{}, NonNull{}, Sorted{}),
    CreateTypedColumnSpec(String{}, DenseNull{}, Unsorted{}));

inline constexpr auto kPyDictionaryDense = CreateTypedDataframeSpec(
    {"_auto_id", "state", "cpu", "thread"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(String{}, DenseNull{}, Unsorted{}),
    CreateTypedColumnSpec(String{}, NonNull{}, Unsorted{}),
    CreateTypedColumnSpec(String{}, SparseNullWithPopcountAlways{}, Unsorted{}));

inline constexpr auto kPyDictionarySparse = CreateTypedDataframeSpec(
    {"_auto_id", "state", "cpu", "thread"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(String{}, SparseNullWithPopcountAlways{}, Unsorted{}),
    CreateTypedColumnSpec(String{}, DenseNull{}, Unsorted{}),
    CreateTypedColumnSpec(String{}, DenseNull{}, Unsorted{}));

inline constexpr auto kPyTypes = CreateTypedDataframeSpec(
    {"_auto_id", "a", "b", "c", "d", "e"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(Int64{}, NonNull{}, Unsorted{}),
    CreateTypedColumnSpec(Int32{}, NonNull{}, Unsorted{}),
    CreateTypedColumnSpec(Uint32{}, NonNull{}, Unsorted{}),
    CreateTypedColumnSpec(Double{}, NonNull{}, Unsorted{}),
    CreateTypedColumnSpec(String{}, NonNull{}, Unsorted{}));

inline constexpr auto kPyIndexed = CreateTypedDataframeSpec(
    {"_auto_id", "s"},
    CreateTypedColumnSpec(Id{}, NonNull{}, IdSorted{}, NoDuplicates{}),
    CreateTypedColumnSpec(String{}, DenseNull{}, Unsorted{}));

template <typename Spec>
void ExpectPyArrowEveryTypeCells(const Spec& spec,
                                 const Dataframe& dst,
                                 const StringPool& pool) {
  ASSERT_EQ(dst.row_count(), 150u);
  for (uint32_t i = 0; i < 150; ++i) {
    EXPECT_EQ(AsOptional(dst.GetCellUnchecked<1>(spec, i)), PyU32(i))
        << "row " << i;
    EXPECT_EQ(AsOptional(dst.GetCellUnchecked<2>(spec, i)),
              std::optional<int32_t>{PyI32(i)})
        << "row " << i;
    EXPECT_EQ(AsOptional(dst.GetCellUnchecked<3>(spec, i)), PyI64(i))
        << "row " << i;
    EXPECT_EQ(AsOptional(dst.GetCellUnchecked<4>(spec, i)), PyF64(i))
        << "row " << i;
    EXPECT_EQ(StringAt(pool, AsOptional(dst.GetCellUnchecked<5>(spec, i))),
              PyStr(i))
        << "row " << i;
  }
}

// Three batches of 50 rows: batch edges fall inside validity bytes and
// 64-bit words, and some batches of a column have no nulls at all.
TEST(ArrowVerify, ReadsPyArrowFileWithSeveralBatches) {
  StringPool pool;
  auto dst_or = Deserialize(FromHex(kPyArrowEveryType), &pool,
                            UntypedSpec(kPyEveryTypeDense));
  ASSERT_OK(dst_or);
  EXPECT_TRUE(dst_or->finalized());
  ExpectPyArrowEveryTypeCells(kPyEveryTypeDense, *dst_or, pool);
}

TEST(ArrowVerify, ReadsPyArrowFileUnderOtherNullStorage) {
  StringPool pool;
  auto dst_or =
      Deserialize(FromHex(kPyArrowEveryType), &pool,
                  UntypedSpec(kPyEveryTypeSparse), /*chunk_size=*/7);
  ASSERT_OK(dst_or);
  ExpectPyArrowEveryTypeCells(kPyEveryTypeSparse, *dst_or, pool);
}

// Plain sparse columns cannot be read cell by cell once finalized, so write
// the frame out again and read that copy with popcount-backed columns.
TEST(ArrowVerify, ReadsPyArrowFileIntoPlainSparseColumns) {
  StringPool pool;
  auto dst_or = Deserialize(FromHex(kPyArrowEveryType), &pool,
                            UntypedSpec(kPyEveryTypePlainSparse));
  ASSERT_OK(dst_or);
  EXPECT_EQ(dst_or->row_count(), 150u);
  std::vector<uint8_t> again = Serialize(*dst_or, pool);
  StringPool out_pool;
  auto copy_or =
      Deserialize(again, &out_pool, UntypedSpec(kPyEveryTypeSparse));
  ASSERT_OK(copy_or);
  ExpectPyArrowEveryTypeCells(kPyEveryTypeSparse, *copy_or, out_pool);
}

TEST(ArrowVerify, ReadsPyArrowFileWithNoRecordBatches) {
  StringPool pool;
  auto dst_or =
      Deserialize(FromHex(kPyArrowEmpty), &pool, UntypedSpec(kPyEmpty));
  ASSERT_OK(dst_or);
  EXPECT_TRUE(dst_or->finalized());
  EXPECT_EQ(dst_or->row_count(), 0u);
}

template <typename Spec>
void ExpectPyArrowDictionary(const Spec& spec, size_t chunk_size) {
  const char* kStates[] = {"idle", "running", "sleeping", "zombie", ""};
  StringPool pool;
  auto dst_or = Deserialize(FromHex(kPyArrowDictionary), &pool,
                            UntypedSpec(spec), chunk_size);
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);
  EXPECT_TRUE(dst.finalized());
  ASSERT_EQ(dst.row_count(), 100u);
  for (uint32_t i = 0; i < 100; ++i) {
    std::optional<std::string> state;
    if (i % 6 != 4) {
      state = kStates[i * 3 % 5];
    }
    std::optional<std::string> thread;
    if (i % 10 != 9) {
      thread = "thread-" + std::to_string(i % 13);
    }
    EXPECT_EQ(StringAt(pool, AsOptional(dst.GetCellUnchecked<1>(spec, i))),
              state)
        << "row " << i;
    EXPECT_EQ(StringAt(pool, AsOptional(dst.GetCellUnchecked<2>(spec, i))),
              std::optional<std::string>{"cpu" + std::to_string(i % 9)})
        << "row " << i;
    EXPECT_EQ(StringAt(pool, AsOptional(dst.GetCellUnchecked<3>(spec, i))),
              thread)
        << "row " << i;
  }
}

// Dictionary-encoded strings with int8, int32 and uint16 indices, one shared
// dictionary per column across three batches.
TEST(ArrowVerify, ReadsPyArrowDictionaryStrings) {
  ExpectPyArrowDictionary(kPyDictionaryDense, 0);
}

TEST(ArrowVerify, ReadsPyArrowDictionaryStringsUnderOtherNullStorage) {
  ExpectPyArrowDictionary(kPyDictionarySparse, /*chunk_size=*/5);
}

TEST(ArrowVerify, ReadsPyArrowColumnOfEachType) {
  StringPool pool;
  auto dst_or =
      Deserialize(FromHex(kPyArrowTypes), &pool, UntypedSpec(kPyTypes));
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);
  ASSERT_EQ(dst.row_count(), 2u);
  EXPECT_EQ((dst.GetCellUnchecked<1>(kPyTypes, 1)), -2);
  EXPECT_EQ((dst.GetCellUnchecked<2>(kPyTypes, 1)), -4);
  EXPECT_EQ((dst.GetCellUnchecked<3>(kPyTypes, 1)), 6u);
  EXPECT_EQ((dst.GetCellUnchecked<4>(kPyTypes, 0)), 0.5);
  EXPECT_EQ(pool.Get(dst.GetCellUnchecked<5>(kPyTypes, 1)).ToStdString(), "y");
}

// A column whose Arrow type is not the spec's type is an error, whether the
// width, the signedness or the kind differs.
TEST(ArrowVerify, RejectsArrowTypeOtherThanSpec) {
  StringPool pool;
  std::vector<uint8_t> bytes = FromHex(kPyArrowTypes);
  struct Swap {
    size_t column;
    StorageType type;
  };
  for (const Swap& swap : {Swap{1, Int32{}}, Swap{1, Double{}},
                           Swap{2, Uint32{}}, Swap{3, Int32{}},
                           Swap{4, Int64{}}, Swap{5, Int64{}}}) {
    DataframeSpec spec = UntypedSpec(kPyTypes);
    spec.column_specs[swap.column].type = swap.type;
    EXPECT_THAT(Deserialize(bytes, &pool, spec), IsError())
        << "column " << swap.column;
  }

  EXPECT_THAT(Deserialize(FromHex(kPyArrowFloat32), &pool,
                          UntypedSpec(kDoubleNonNull)),
              IsError());

  auto int64_frame = MakeDataframe(kInt64NonNull, &pool, int64_t{7});
  EXPECT_THAT(Deserialize(Serialize(int64_frame, pool), &pool,
                          UntypedSpec(kDoubleNonNull)),
              IsError());
  auto uint32_frame = MakeDataframe(kUint32NonNull, &pool, uint32_t{7});
  EXPECT_THAT(Deserialize(Serialize(uint32_frame, pool), &pool,
                          UntypedSpec(kInt32NonNull)),
              IsError());
}

TEST(ArrowVerify, RejectsNullsInNonNullColumn) {
  StringPool pool;
  DataframeSpec spec = UntypedSpec(kPyEveryTypeDense);
  spec.column_specs[1].nullability = NonNull{};
  EXPECT_THAT(Deserialize(FromHex(kPyArrowEveryType), &pool, spec), IsError());
}

TEST(ArrowVerify, RejectsDictionaryIndexOutsideDictionary) {
  StringPool pool;
  EXPECT_THAT(Deserialize(FromHex(kPyArrowIndexPastDictionary), &pool,
                          UntypedSpec(kPyIndexed)),
              IsError());
  EXPECT_THAT(Deserialize(FromHex(kPyArrowNegativeIndex), &pool,
                          UntypedSpec(kPyIndexed), /*chunk_size=*/5),
              IsError());
}

// ===========================================================================
// Arrow file-format conformance (framing inspected via flatbuffer parsing).
// ===========================================================================

TEST(ArrowVerify, SerializeArrowMagicHeadAndFoot) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{1});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  ASSERT_GE(bytes.size(), 2 * kMagicSize);
  EXPECT_EQ(memcmp(bytes.data(), kMagic, kMagicSize), 0);
  EXPECT_EQ(memcmp(bytes.data() + bytes.size() - kMagicSize, kMagic, kMagicSize),
            0);
}

TEST(ArrowVerify, SerializeFramingIsReadable) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{10}, uint32_t{20},
                           uint32_t{30});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto batch = ReadRecordBatch(bytes);
  ASSERT_TRUE(batch);
  EXPECT_EQ(batch->rows, 3);
}

TEST(ArrowVerify, SerializePrimitiveBuffer) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{10}, uint32_t{20},
                           uint32_t{30});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto batch = ReadRecordBatch(bytes);

  ASSERT_TRUE(batch);
  ASSERT_EQ(batch->rows, 3);
  ASSERT_EQ(batch->nodes.size(), 1u);
  EXPECT_EQ(batch->nodes[0].null_count, 0);
  ASSERT_EQ(batch->buffers.size(), 2u);
  ExpectAllRowsValid(bytes, *batch, 0, 3);
  // The Arrow IPC buffer.length field is the logical (unpadded) byte count;
  // padding between buffers is implicit. Accept any length >= the logical
  // minimum, since a conformant serializer may round up for alignment.
  EXPECT_GE(batch->buffers[1].length,
            static_cast<int64_t>(3 * sizeof(uint32_t)));
  EXPECT_EQ(ReadBodyValue<uint32_t>(bytes, *batch, 1, 0), 10u);
  EXPECT_EQ(ReadBodyValue<uint32_t>(bytes, *batch, 1, 1), 20u);
  EXPECT_EQ(ReadBodyValue<uint32_t>(bytes, *batch, 1, 2), 30u);
}

// A sparse numeric column must be densified on write: null count correct,
// validity bitmap matching the present mask, and present values at their rows.
// The value in a missing row's slot is not checked.
TEST(ArrowVerify, SerializeValidityBitmapDensifiesSparse) {
  StringPool pool;
  auto src =
      MakeDataframe(kInt32Sparse, &pool, std::optional<int32_t>{11},
                    std::optional<int32_t>{}, std::optional<int32_t>{33});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto batch = ReadRecordBatch(bytes);

  ASSERT_TRUE(batch);
  ASSERT_EQ(batch->nodes.size(), 1u);
  EXPECT_EQ(batch->nodes[0].null_count, 1);
  ASSERT_EQ(batch->buffers.size(), 2u);
  // 3 rows fit in 1 validity byte; accept >= 1 (alignment padding is allowed).
  EXPECT_GE(batch->buffers[0].length, 1);
  // Rows 0 and 2 present, row 1 missing -> bits 0b00000101.
  EXPECT_EQ(ReadBodyValue<uint8_t>(bytes, *batch, 0, 0), 0b00000101);
  EXPECT_EQ(ReadBodyValue<int32_t>(bytes, *batch, 1, 0), 11);
  EXPECT_EQ(ReadBodyValue<int32_t>(bytes, *batch, 1, 2), 33);
}

TEST(ArrowVerify, SerializeUtf8OffsetAndDataBuffers) {
  StringPool pool;
  auto hello = pool.InternString(base::StringView("hello"));
  auto empty = pool.InternString(base::StringView(""));
  auto world = pool.InternString(base::StringView("world"));
  auto src = MakeDataframe(kStringNonNull, &pool, hello, empty, world);
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto batch = ReadRecordBatch(bytes);

  ASSERT_TRUE(batch);
  ASSERT_EQ(batch->buffers.size(), 3u);  // Validity + offsets + data.
  ExpectAllRowsValid(bytes, *batch, 0, 3);
  // n+1 int32 offsets; accept >= logical minimum (alignment padding allowed).
  EXPECT_GE(batch->buffers[1].length,
            static_cast<int64_t>(4 * sizeof(int32_t)));
  // 10 data bytes ("hello" + "" + "world"); accept >= 10 (alignment padding).
  EXPECT_GE(batch->buffers[2].length, 10);
  // Monotonic offsets: 0,5,5,10.
  EXPECT_EQ(ReadBodyValue<int32_t>(bytes, *batch, 1, 0), 0);
  EXPECT_EQ(ReadBodyValue<int32_t>(bytes, *batch, 1, 1), 5);
  EXPECT_EQ(ReadBodyValue<int32_t>(bytes, *batch, 1, 2), 5);
  EXPECT_EQ(ReadBodyValue<int32_t>(bytes, *batch, 1, 3), 10);
  ArrowBuffer strings = batch->buffers[2];
  const char* string_data = reinterpret_cast<const char*>(
      bytes.data() + batch->body_offset + strings.offset);
  // strings.length >= 10; read exactly the 10 logical data bytes.
  EXPECT_EQ(std::string_view(string_data, 10), "helloworld");
}

TEST(ArrowVerify, OmitsImplicitIdColumn) {
  StringPool pool;
  auto src = Dataframe::CreateFromTypedSpec(kIdOnly, &pool);
  src.InsertUnchecked(kIdOnly, std::monostate{});
  src.InsertUnchecked(kIdOnly, std::monostate{});
  src.InsertUnchecked(kIdOnly, std::monostate{});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto batch = ReadRecordBatch(bytes);

  ASSERT_TRUE(batch);
  EXPECT_EQ(batch->rows, 3);  // Row count still recorded.
  EXPECT_EQ(batch->nodes.size(), 0u);
  EXPECT_EQ(batch->buffers.size(), 0u);
  EXPECT_EQ(batch->block.body_length, 0);
}

// ===========================================================================
// Serializer lifecycle and reuse.
// ===========================================================================

TEST(ArrowVerify, PrepareWriteLifecycle) {
  StringPool pool;
  auto value = pool.InternString(base::StringView("value"));
  auto source = MakeDataframe(kStringNonNull, &pool, value);
  auto other = MakeDataframe(kStringNonNull, &pool, value);
  StringPool other_pool;
  ArrowSerializer serializer;
  auto sink = [](const uint8_t*, size_t) { return base::OkStatus(); };

  // Write before Prepare, and Prepare on a non-finalized frame, must error.
  EXPECT_THAT(serializer.Write(source, &pool, sink), IsError());
  EXPECT_THAT(serializer.Prepare(source, &pool), IsError());

  source.Finalize();
  other.Finalize();
  // A serializer that never prepared anything must refuse a finalized frame.
  ArrowSerializer unprepared;
  EXPECT_THAT(unprepared.Write(source, &pool, sink), IsError());
  // Prepare with a mismatched pool must error.
  EXPECT_THAT(serializer.Prepare(source, &other_pool), IsError());
  ASSERT_OK(serializer.Prepare(source, &pool));
  // Write with a frame/pool that differs from the one Prepared must error.
  EXPECT_THAT(serializer.Write(other, &pool, sink), IsError());
  EXPECT_THAT(serializer.Write(source, &other_pool, sink), IsError());
  // A fresh Prepare followed by the matching Write succeeds.
  ASSERT_OK(serializer.Prepare(source, &pool));
  EXPECT_OK(serializer.Write(source, &pool, sink));
}

TEST(ArrowVerify, PreparedSizeEqualsWrittenLength) {
  StringPool pool;
  auto source = MakeDataframe(kUint32NonNull, &pool, uint32_t{1}, uint32_t{2});
  source.Finalize();
  ArrowSerializer serializer;
  auto size = serializer.Prepare(source, &pool);
  ASSERT_OK(size);
  size_t written = 0;
  ASSERT_OK(serializer.Write(source, &pool, [&](const uint8_t*, size_t len) {
    written += len;
    return base::OkStatus();
  }));
  EXPECT_EQ(written, *size);
}

TEST(ArrowVerify, CanBeReusedAcrossDataframes) {
  StringPool pool;
  auto first = MakeDataframe(kUint32NonNull, &pool, uint32_t{1});
  auto second = MakeDataframe(kStringNonNull, &pool,
                              pool.InternString(base::StringView("second")),
                              pool.InternString(base::StringView("frame")));
  first.Finalize();
  second.Finalize();
  ArrowSerializer serializer;
  std::vector<uint8_t> first_bytes;
  std::vector<uint8_t> second_bytes;

  auto write_to = [&](const Dataframe& dataframe, std::vector<uint8_t>* out) {
    auto size = serializer.Prepare(dataframe, &pool);
    ASSERT_OK(size);
    ASSERT_OK(serializer.Write(dataframe, &pool,
                               [&](const uint8_t* data, size_t length) {
                                 out->insert(out->end(), data, data + length);
                                 return base::OkStatus();
                               }));
    EXPECT_EQ(out->size(), *size);
  };
  write_to(first, &first_bytes);
  write_to(second, &second_bytes);

  // Each produced buffer must deserialize back to its own frame.
  auto first_or = Deserialize(first_bytes, &pool, first.CreateSpec());
  ASSERT_OK(first_or);
  EXPECT_EQ(first_or->row_count(), 1u);
  EXPECT_EQ((first_or->GetCellUnchecked<1>(kUint32NonNull, 0)), 1u);
  auto second_or = Deserialize(second_bytes, &pool, second.CreateSpec());
  ASSERT_OK(second_or);
  EXPECT_EQ(second_or->row_count(), 2u);
  auto second_value = second_or->GetCellUnchecked<1>(kStringNonNull, 1);
  EXPECT_EQ(pool.Get(second_value).ToStdString(), "frame");
}

// Whatever pieces Write hands to the sink, a failure on any one of them stops
// the write there and comes back as that same status.
TEST(ArrowVerify, PropagatesWriteError) {
  StringPool pool;
  auto a = pool.InternString(base::StringView("a"));
  auto bb = pool.InternString(base::StringView("bb"));
  auto source = Dataframe::CreateFromTypedSpec(kMultiColumn, &pool);
  source.InsertUnchecked(kMultiColumn, std::monostate{}, int64_t{100}, a,
                         std::optional<double>{0.5});
  source.InsertUnchecked(kMultiColumn, std::monostate{}, int64_t{200}, bb,
                         std::optional<double>{});
  source.Finalize();
  ArrowSerializer serializer;

  ASSERT_OK(serializer.Prepare(source, &pool));
  uint32_t total_calls = 0;
  ASSERT_OK(serializer.Write(source, &pool, [&](const uint8_t*, size_t) {
    ++total_calls;
    return base::OkStatus();
  }));
  ASSERT_GE(total_calls, 1u);

  for (uint32_t failing_call = 1; failing_call <= total_calls; ++failing_call) {
    ASSERT_OK(serializer.Prepare(source, &pool));
    std::string message = "sink failed on call " + std::to_string(failing_call);
    uint32_t calls = 0;
    base::Status status =
        serializer.Write(source, &pool, [&](const uint8_t*, size_t) {
          if (++calls == failing_call) {
            return base::ErrStatus("%s", message.c_str());
          }
          return base::OkStatus();
        });
    EXPECT_THAT(status, IsError()) << "failing call " << failing_call;
    EXPECT_EQ(status.message(), message);
    EXPECT_EQ(calls, failing_call);
  }
}

// ===========================================================================
// Deserializer hardening: malformed input is rejected via status, no crash.
// ===========================================================================

TEST(ArrowVerify, RejectsInvalidDataframeSpec) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{1});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  DataframeSpec invalid_spec{{"only_a_name"}, {}};
  EXPECT_THAT(Deserialize(bytes, &pool, invalid_spec), IsError());
}

TEST(ArrowVerify, RejectsTruncatedInput) {
  StringPool pool;
  auto src = MakeDataframe(kStringSparse, &pool,
                           std::optional<StringPool::Id>{pool.InternString(
                               base::StringView("some string data"))},
                           std::optional<StringPool::Id>{});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  for (size_t len = 0; len < bytes.size(); len += 7) {
    std::vector<uint8_t> truncated(bytes.begin(),
                                   bytes.begin() + static_cast<ptrdiff_t>(len));
    EXPECT_THAT(Deserialize(truncated, &pool, src.CreateSpec()), IsError())
        << "len " << len;
  }
}

TEST(ArrowVerify, RejectsCorruptFooterSize) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{1});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  uint32_t huge = 0x7FFFFFFF;
  memcpy(bytes.data() + bytes.size() - kFileTrailerSize, &huge, sizeof(huge));
  EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsInconsistentBlockLength) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{1});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  Block block;
  memcpy(&block, MutableBlock(&bytes), sizeof(block));
  block.body_length += 8;
  memcpy(MutableBlock(&bytes), &block, sizeof(block));

  EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsInconsistentFieldNode) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{1});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  auto record_batch = MutableRecordBatch(&bytes);
  uint8_t* node_data =
      MutableVectorData(&bytes, record_batch, record_batch_field::kNodes);
  FieldNode node;
  memcpy(&node, node_data, sizeof(node));
  node.null_count = 1;  // Claims a null where the buffers encode none.
  memcpy(node_data, &node, sizeof(node));

  EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsNegativeValidityBufferOffset) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{1});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  auto record_batch = MutableRecordBatch(&bytes);
  uint8_t* buffer_data =
      MutableVectorData(&bytes, record_batch, record_batch_field::kBuffers);
  ArrowBuffer buffer;
  memcpy(&buffer, buffer_data, sizeof(buffer));
  buffer.offset = -1;  // Negative offset for the validity buffer.
  memcpy(buffer_data, &buffer, sizeof(buffer));

  EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsInvalidStringOffsets) {
  StringPool pool;
  auto value = pool.InternString(base::StringView("value"));
  auto src = MakeDataframe(kStringNonNull, &pool, value);
  std::vector<uint8_t> bytes = Serialize(src, pool);

  Block block = ReadBlock(bytes);
  auto record_batch = MutableRecordBatch(&bytes);
  uint8_t* buffer_data =
      MutableVectorData(&bytes, record_batch, record_batch_field::kBuffers);
  ArrowBuffer offsets_buffer;
  memcpy(&offsets_buffer, buffer_data + sizeof(ArrowBuffer),
         sizeof(offsets_buffer));
  int32_t invalid_offset = -1;  // Non-monotonic / negative Utf8 offset.
  memcpy(bytes.data() + block.offset + block.metadata_length +
             offsets_buffer.offset + sizeof(int32_t),
         &invalid_offset, sizeof(invalid_offset));

  EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError());
}

// The checks below each push one size or offset that the file declares past
// the end of the input. The reader must report an error instead of following
// it.
TEST(ArrowVerify, RejectsBlockOffsetPastEnd) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{1});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  Block block;
  memcpy(&block, MutableBlock(&bytes), sizeof(block));
  block.offset = static_cast<int64_t>(bytes.size()) + 64;
  memcpy(MutableBlock(&bytes), &block, sizeof(block));

  EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsBlockMetadataLengthPastEnd) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{2});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  Block block;
  memcpy(&block, MutableBlock(&bytes), sizeof(block));
  block.metadata_length = 0x7FFFFFF0;
  memcpy(MutableBlock(&bytes), &block, sizeof(block));

  EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsMessageMetadataSizePastEnd) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{3});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  Block block = ReadBlock(bytes);
  int32_t huge = 0x7FFFFFF0;
  memcpy(bytes.data() + block.offset + sizeof(uint32_t), &huge, sizeof(huge));

  EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsRowCountPastBuffers) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{4});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  auto record_batch = MutableRecordBatch(&bytes);
  const uint8_t* length_field =
      record_batch.FieldRaw(record_batch_field::kLength, sizeof(int64_t));
  ASSERT_NE(length_field, nullptr);
  size_t location = static_cast<size_t>(length_field - bytes.data());
  int64_t rows = 1000000;
  memcpy(bytes.data() + location, &rows, sizeof(rows));

  EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsDataBufferPastBody) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{5});
  std::vector<uint8_t> original = Serialize(src, pool);
  int64_t body_length = ReadBlock(original).body_length;

  // The values buffer starts past the body, runs past it, or starts inside it
  // with its own length but ends past it.
  enum class Shift { kOffset, kLength, kEnd };
  for (Shift shift : {Shift::kOffset, Shift::kLength, Shift::kEnd}) {
    std::vector<uint8_t> bytes = original;
    auto record_batch = MutableRecordBatch(&bytes);
    uint8_t* buffer_data =
        MutableVectorData(&bytes, record_batch, record_batch_field::kBuffers);
    ArrowBuffer values;
    memcpy(&values, buffer_data + sizeof(ArrowBuffer), sizeof(values));
    if (shift == Shift::kOffset) {
      values.offset = int64_t{1} << 40;
    } else if (shift == Shift::kLength) {
      values.length = int64_t{1} << 40;
    } else {
      values.offset = body_length - 2;
    }
    memcpy(buffer_data + sizeof(ArrowBuffer), &values, sizeof(values));

    EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError())
        << "shift " << static_cast<int>(shift);
  }
}

TEST(ArrowVerify, RejectsStringOffsetPastData) {
  StringPool pool;
  auto value = pool.InternString(base::StringView("value"));
  auto src = MakeDataframe(kStringNonNull, &pool, value);
  std::vector<uint8_t> bytes = Serialize(src, pool);

  Block block = ReadBlock(bytes);
  auto record_batch = MutableRecordBatch(&bytes);
  uint8_t* buffer_data =
      MutableVectorData(&bytes, record_batch, record_batch_field::kBuffers);
  ArrowBuffer offsets_buffer;
  memcpy(&offsets_buffer, buffer_data + sizeof(ArrowBuffer),
         sizeof(offsets_buffer));
  int32_t past_end = 1000;  // The data buffer holds only "value".
  memcpy(bytes.data() + block.offset + block.metadata_length +
             offsets_buffer.offset + sizeof(int32_t),
         &past_end, sizeof(past_end));

  EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsNegativeRowCount) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{6});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  auto record_batch = MutableRecordBatch(&bytes);
  const uint8_t* length_field =
      record_batch.FieldRaw(record_batch_field::kLength, sizeof(int64_t));
  ASSERT_NE(length_field, nullptr);
  size_t location = static_cast<size_t>(length_field - bytes.data());
  int64_t rows = -1;
  memcpy(bytes.data() + location, &rows, sizeof(rows));

  EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsNullCountThatDisagreesWithBitmap) {
  StringPool pool;
  auto src =
      MakeDataframe(kUint32DenseNull, &pool, std::optional<uint32_t>{1},
                    std::optional<uint32_t>{}, std::optional<uint32_t>{3},
                    std::optional<uint32_t>{}, std::optional<uint32_t>{5});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  auto record_batch = MutableRecordBatch(&bytes);
  uint8_t* node_data =
      MutableVectorData(&bytes, record_batch, record_batch_field::kNodes);
  FieldNode node;
  memcpy(&node, node_data, sizeof(node));
  ASSERT_EQ(node.null_count, 2);
  node.null_count = 0;  // The bitmap still marks two rows missing.
  memcpy(node_data, &node, sizeof(node));

  EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsValuesBufferShorterThanRows) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{7}, uint32_t{8},
                           uint32_t{9});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  auto record_batch = MutableRecordBatch(&bytes);
  uint8_t* buffer_data =
      MutableVectorData(&bytes, record_batch, record_batch_field::kBuffers);
  ArrowBuffer values;
  memcpy(&values, buffer_data + sizeof(ArrowBuffer), sizeof(values));
  values.length = static_cast<int64_t>(sizeof(uint32_t));  // Room for 1 row.
  memcpy(buffer_data + sizeof(ArrowBuffer), &values, sizeof(values));

  EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsNegativeBufferLength) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{10});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  auto record_batch = MutableRecordBatch(&bytes);
  uint8_t* buffer_data =
      MutableVectorData(&bytes, record_batch, record_batch_field::kBuffers);
  ArrowBuffer values;
  memcpy(&values, buffer_data + sizeof(ArrowBuffer), sizeof(values));
  values.length = -8;
  memcpy(buffer_data + sizeof(ArrowBuffer), &values, sizeof(values));

  EXPECT_THAT(Deserialize(bytes, &pool, src.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsSchemaShapeMismatch) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{1});
  std::vector<uint8_t> bytes = Serialize(src, pool);

  // The requested schema has a different column shape than the encoded batch.
  auto dst = Dataframe::CreateFromTypedSpec(kMultiColumn, &pool);
  EXPECT_THAT(Deserialize(bytes, &pool, dst.CreateSpec()), IsError());
}

TEST(ArrowVerify, RejectsGarbageInput) {
  StringPool pool;
  std::vector<uint8_t> bytes(256, 0xCD);
  auto dst = Dataframe::CreateFromTypedSpec(kUint32NonNull, &pool);
  EXPECT_THAT(Deserialize(bytes, &pool, dst.CreateSpec()), IsError());
}

// ===========================================================================
// The deserialized frame is a real finalized, queryable Dataframe.
// ===========================================================================

TEST(ArrowVerify, DeserializedFrameIsFinalized) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{1});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);
  EXPECT_TRUE(dst.finalized());
  EXPECT_EQ(dst.row_count(), 1u);
}

TEST(ArrowVerify, DeserializedFrameSupportsIndexesAndCursors) {
  StringPool pool;
  auto src = MakeDataframe(kUint32NonNull, &pool, uint32_t{20}, uint32_t{10});
  std::vector<uint8_t> bytes = Serialize(src, pool);
  auto dst_or = Deserialize(bytes, &pool, src.CreateSpec());
  ASSERT_OK(dst_or);
  Dataframe dst = std::move(*dst_or);

  uint32_t indexed_column = 1;
  auto index = dst.BuildIndex(&indexed_column, &indexed_column + 1);
  ASSERT_OK(index);
  Dataframe indexed = dst.AddIndex(std::move(*index));
  TypedCursor cursor(
      &indexed, std::vector<FilterSpec>{},
      std::vector<SortSpec>{{indexed_column, SortDirection::kAscending}});
  cursor.ExecuteUnchecked();
  ASSERT_FALSE(cursor.Eof());
  EXPECT_EQ(cursor.GetCellUnchecked<1>(kUint32NonNull), 10u);
  cursor.Next();
  ASSERT_FALSE(cursor.Eof());
  EXPECT_EQ(cursor.GetCellUnchecked<1>(kUint32NonNull), 20u);
  cursor.Next();
  EXPECT_TRUE(cursor.Eof());
}

}  // namespace
}  // namespace perfetto::trace_processor::core::dataframe
