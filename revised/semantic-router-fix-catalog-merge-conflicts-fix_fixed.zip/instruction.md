## Task

Every time a Model Card PR merges, the other open catalog PRs start conflicting with main, even when they add cards for a different creator.
The author then has to merge main by hand, and that merge dismisses the approvals the PR already had, so it goes back through review.
With a batch of catalog PRs open, everything after the first one goes around this loop.

GitHub shows the conflict in the generated catalog output, on a line that changes with every regeneration no matter which card was added.
Once the author resolves that conflict and runs `make model-catalog-generate` on the merged branch, a dashboard backend Go test still fails with "unexpected generated inventory".
Someone then has to fix the catalog totals it expects by hand before CI goes green again.

What we need after the fix:

- So that PRs changing different catalog entries stop conflicting, regeneration must not write the SHA-256 of the whole `website/static/model-catalog/catalog.json` into any checked-in file.
- `BuiltIn().Digest()`, and `Digest()` on a registry compiled from it, must still equal the SHA-256 of `catalog.json` (as `sha256:<hex>`) whenever that file and the embedded catalog hold the same content.
- Adding or removing entries under `config/catalog/resources` and regenerating must leave that dashboard test passing with no edit to it, and the test has to keep its current name.
- It must still fail when the generated catalog and the authored sources disagree, for example when a source was edited and nobody regenerated, whether `catalog.json` then lists more or fewer models, providers or evaluations than are authored.
- The per-asset `verification.asset_sha256` checksums in the published catalog are real verification data, so they have to keep their current values, and when a file in the asset bundle they cover changes, regenerating has to update them to that bundle's new checksum.
