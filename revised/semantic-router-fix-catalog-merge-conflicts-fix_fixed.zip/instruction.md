## Task

Every time a Model Card PR merges, the other open catalog PRs start conflicting with main, even when they add cards for a different creator.
The author then has to merge main by hand, and that merge dismisses the approvals the PR already had, so it goes back through review.
With a batch of catalog PRs open, everything after the first one goes around this loop.

Most of those conflicts land in the same two spots, and these are the two to fix:

- the catalog digest near the top of `src/semantic-router/pkg/catalog/zz_generated_catalog.go`, which `make model-catalog-generate` rewrites on every catalog change
- the model, provider and evaluation totals in `TestGeneratedPublicModelCatalogSatisfiesDashboardContract` (`dashboard/backend/handlers`), which each new card bumps by hand

Two PRs that each add one card also bump those totals to the same numbers, so git merges that line cleanly and the total ends up wrong.
After the merge and `make model-catalog-generate`, `go test ./handlers -run TestGeneratedPublicModelCatalogSatisfiesDashboardContract` in `dashboard/backend` fails with "unexpected generated inventory" until someone edits the numbers again.

What we need after the fix:

- Regenerating the catalog for a content change should not rewrite a copy of the whole-catalog digest in any checked-in file, so PRs that touch different entries stop conflicting there.
- `BuiltIn().Digest()`, and `Digest()` on a registry compiled from it, must still equal the SHA-256 of `website/static/model-catalog/catalog.json` (as `sha256:<hex>`) whenever that file and the embedded catalog hold the same content.
- The totals that dashboard test expects have to follow what is authored under `config/catalog/resources`, so after a source change and a regeneration it passes with no edit to the test.
- Keep that test under its current name.
- It must still fail when the generated catalog and the authored sources disagree, for example when a source was edited and nobody regenerated, whether `catalog.json` then holds more or fewer models, providers or evaluations than are authored.
- The per-asset `verification.asset_sha256` checksums in the published catalog are real verification data and have to stay.
