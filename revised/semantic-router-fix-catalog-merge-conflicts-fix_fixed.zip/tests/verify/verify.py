"""Behavioral checks for the model catalog's derived values.

These checks run under the shared verifier interpreter (``VERIFIER_PYTHON`` /
``/opt/tooling/venv``). That interpreter has no YAML/jsonschema, so this module
never imports repository Python. It drives the real toolchain the same way a
maintainer would:

  * it copies the checked-out tree into a scratch workspace,
  * edits catalog sources or the embedded payload there,
  * re-runs the catalog generator with the repo's own Python, and
  * runs Go code through ``go test`` on exported entry points
    (``catalog.BuiltIn().Digest()``, ``(*EffectiveRegistry).Digest()``) and the
    dashboard backend's catalog contract test, run by its name.

Each property is about a value following its source: it is correct only if it
changes when the source changes. Showing that needs an edit plus a rebuild or a
regeneration, so the copy, edit, regenerate and run steps are the test.

Apart from the generated Go file that already embeds the catalog payload, no
check looks up a symbol, file or helper name that the implementation is free to
choose.
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

# ── Repository layout ───────────────────────────────────────────────────────
# The runner exports REPO_NAME; the checkout lives at /repo/<REPO_NAME>.
REPO_NAME = os.environ.get("REPO_NAME", "semantic-router")
REPO_DIR = Path(f"/repo/{REPO_NAME}")

# Paths inside the tree (and inside every scratch copy of it).
GO_MODULE = Path("src/semantic-router")
CATALOG_PKG = GO_MODULE / "pkg" / "catalog"
EMBED_GO = CATALOG_PKG / "zz_generated_catalog.go"
PUBLIC_JSON = Path("website/static/model-catalog/catalog.json")
GENERATOR = Path("tools/catalog/generate_model_catalog.py")
DASHBOARD_MODULE = Path("dashboard/backend")
DASHBOARD_TEST = "TestGeneratedPublicModelCatalogSatisfiesDashboardContract"

# A value that appears exactly once inside the embedded catalog payload literal,
# as a display label. Editing it changes catalog content without touching counts
# or schema identity.
PAYLOAD_PROBE_FROM = '"display_name": "MMLU-Pro"'
PAYLOAD_PROBE_TO = '"display_name": "MMLU-Proxy"'

# Authored catalog sources used by the dashboard checks. Evaluation and model
# files hold a top-level YAML sequence; each provider file holds one mapping.
EVAL_SOURCE = Path("config/catalog/resources/evaluations/single/ai21.yaml")
MODEL_SOURCE = Path("config/catalog/resources/models/single/ai21.yaml")
PROVIDER_SOURCE = Path("config/catalog/resources/providers/agnes.yaml")
PROVIDER_COPY = Path("config/catalog/resources/providers/agnes-local-copy.yaml")

# Records added in the regenerate step: a new model, a new provider that serves
# it, and a new evaluation of it, each copied from an existing record under a
# fresh id so the authored catalog stays valid.
ADDED_EVAL_SOURCE = Path("config/catalog/resources/evaluations/single/xiaomi.yaml")
ADDED_EVAL_FROM = "independent/mimo-v2-flash-critpt@1.0.0"
ADDED_MODEL_SOURCE = Path("config/catalog/resources/models/single/xiaomi.yaml")
ADDED_MODEL_FROM = "xiaomi/mimo-v2-flash"
ADDED_PROVIDER_SOURCE = Path("config/catalog/resources/providers/novita.yaml")
ADDED_PROVIDER_FROM = "novita"
FRESH_SUFFIX = "-local-copy"

# A fixed time far in the past (2000-01-01 UTC). Files a drift case edits or
# adds, and their folder, are stamped with it, so file times say nothing about
# which side changed.
OLD_STAMP = 946684800

# Per-step ceilings. The whole run is bounded by verify.toml [pytest].timeout
# (and the outer [verifier].timeout_sec); these inner limits only catch a single
# hung step.
GO_TIMEOUT = 300
GEN_TIMEOUT = 300
COPY_IGNORE_DIRS = {".git", "node_modules", ".venv"}
COPY_IGNORE_STATIC = {"img", "videos"}
COPY_IGNORE_SUFFIX = (".pdf", ".mp4", ".webm", ".mov")


# ── Workspace helpers ───────────────────────────────────────────────────────
def _copy_ignore(dirpath, names):
    """Skip heavy media and VCS trees; keep everything the build reads."""
    skip = set()
    base = os.path.basename(dirpath)
    for name in names:
        if name in COPY_IGNORE_DIRS:
            skip.add(name)
        elif base == "static" and name in COPY_IGNORE_STATIC:
            skip.add(name)
        elif name.lower().endswith(COPY_IGNORE_SUFFIX):
            skip.add(name)
    return skip


def _fresh_workspace() -> Path:
    """Copy the checkout into a scratch dir and return its root."""
    assert REPO_DIR.is_dir(), f"repository checkout not found at {REPO_DIR}"
    dst = Path(tempfile.mkdtemp(prefix="catalog-verify-"))
    workspace = dst / REPO_NAME
    shutil.copytree(REPO_DIR, workspace, ignore=_copy_ignore, symlinks=True)
    return workspace


def _catalog_python() -> str:
    """A Python that can import the catalog generator's third-party deps.

    The shared verifier interpreter cannot (no YAML/jsonschema). The image bakes
    an offline environment beside the checkout for this; fall back to a system
    interpreter that happens to have the deps.
    """
    candidates = [
        str(REPO_DIR / ".venv-agent" / "bin" / "python"),
        str(REPO_DIR / ".venv" / "bin" / "python"),
        shutil.which("python3") or "python3",
    ]
    for candidate in candidates:
        if not candidate or not (candidate == "python3" or Path(candidate).exists()):
            continue
        try:
            probe = subprocess.run(
                [candidate, "-c", "import yaml, jsonschema"],
                capture_output=True,
                timeout=60,
            )
        except (OSError, subprocess.SubprocessError):
            continue
        if probe.returncode == 0:
            return candidate
    raise RuntimeError(
        "no interpreter with the catalog generator's dependencies "
        "(PyYAML + jsonschema) was found; the image is expected to bake one "
        "beside the checkout"
    )


def _regenerate(workspace: Path) -> None:
    """Run the catalog generator in place over a scratch workspace."""
    proc = subprocess.run(
        [_catalog_python(), str(workspace / GENERATOR)],
        cwd=str(workspace),
        capture_output=True,
        text=True,
        timeout=GEN_TIMEOUT,
    )
    assert proc.returncode == 0, (
        "catalog regeneration failed (exit "
        f"{proc.returncode}):\n{proc.stdout[-1500:]}\n{proc.stderr[-1500:]}"
    )


def _run_go_test(module_dir: Path, package: str, test_re: str, timeout: int = GO_TIMEOUT):
    """Run one Go test by name; return (proc, {test_name: 'pass'|'fail'|'skip'}).

    The returned proc also carries ``packages``: {test_name: import path}.

    Deps are prewarmed in the image, so the subprocess is pinned offline and
    writable-module to stay hermetic.
    """
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "GOPROXY": "off",
        "CGO_ENABLED": "1",
        "GOTOOLCHAIN": "local",
    }
    cmd = [
        "go", "test", "-json", "-count=1",
        f"-timeout={timeout}s", "-run", test_re, package,
    ]
    proc = subprocess.run(
        cmd,
        cwd=str(module_dir),
        capture_output=True,
        text=True,
        timeout=timeout + 60,
        env=env,
    )
    outcomes: dict[str, str] = {}
    packages: dict[str, str] = {}
    for line in proc.stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        name = event.get("Test")
        action = event.get("Action")
        if name and action in ("pass", "fail", "skip"):
            outcomes[name] = action
            packages[name] = event.get("Package", "")
    proc.packages = packages
    return proc, outcomes


def _run_dashboard_test(workspace: Path, package: str = "./..."):
    """Run the catalog contract test, by default in whichever dashboard backend package holds it."""
    return _run_go_test(
        module_dir=workspace / DASHBOARD_MODULE,
        package=package,
        test_re=f"^{DASHBOARD_TEST}$",
    )


def _diag(proc) -> str:
    return f"\n--- go stdout tail ---\n{proc.stdout[-2000:]}\n--- go stderr tail ---\n{proc.stderr[-2000:]}"


def _replace_once(path: Path, old: str, new: str) -> None:
    text = path.read_text()
    count = text.count(old)
    assert count == 1, f"expected exactly one occurrence of {old!r} in {path}, found {count}"
    path.write_text(text.replace(old, new, 1))


def _first_sequence_entry(lines: list[str], path: Path) -> tuple[int, int]:
    """Line span [start, end) of the first top-level ``- `` YAML sequence entry."""
    start = next((i for i, ln in enumerate(lines) if ln.startswith("- ")), None)
    assert start is not None, f"no top-level sequence entry found in {path}"
    end = len(lines)
    for j in range(start + 1, len(lines)):
        if lines[j].startswith("- "):
            end = j
            break
    assert end > start
    return start, end


def _drop_first_sequence_entry(path: Path) -> None:
    """Remove the first top-level sequence entry with plain text edits.

    Text edits keep this runnable under the stdlib-only verifier interpreter.
    """
    lines = path.read_text().splitlines(keepends=True)
    start, end = _first_sequence_entry(lines, path)
    path.write_text("".join(lines[:start] + lines[end:]))


def _fresh_id(record_id: str) -> str:
    """A new id next to an existing one (``name@version`` keeps its version)."""
    name, at, version = record_id.partition("@")
    return f"{name}{FRESH_SUFFIX}{at}{version}"


def _copy_entry(path: Path, start: int, lines: list[str], swap: tuple[str, str] | None = None) -> None:
    """Write a copy of the sequence entry at ``start`` right after it, under a fresh id."""
    end = _first_sequence_entry(lines[start:], path)[1] + start
    head = lines[start]
    assert head.startswith("- id: "), f"entry in {path} does not start with an id"
    entry = [f"- id: {_fresh_id(head[len('- id: '):].strip())}\n"] + lines[start + 1:end]
    if swap is not None:
        entry = [swap[1] if line == swap[0] else line for line in entry]
    if not entry[-1].endswith("\n"):
        entry[-1] += "\n"
    path.write_text("".join(lines[:end] + entry + lines[end:]))


def _copy_first_sequence_entry(path: Path) -> None:
    """Add a copy of the first top-level sequence entry under a fresh id."""
    lines = path.read_text().splitlines(keepends=True)
    _copy_entry(path, _first_sequence_entry(lines, path)[0], lines)


def _copy_entry_by_id(path: Path, record_id: str, swap: tuple[str, str] | None = None) -> None:
    """Add a copy of the entry with ``record_id`` under a fresh id."""
    lines = path.read_text().splitlines(keepends=True)
    head = f"- id: {record_id}\n"
    assert head in lines, f"no entry {record_id} in {path}"
    _copy_entry(path, lines.index(head), lines, swap)


def _copy_provider(source: Path, copy: Path, swap: tuple[str, str] | None = None) -> None:
    """Write a provider file under a fresh id (each provider file holds one mapping)."""
    text = source.read_text()
    first = text.splitlines(keepends=True)[0]
    assert first.startswith("id: "), f"{source} does not start with an id"
    text = f"id: {_fresh_id(first[len('id: '):].strip())}\n" + text[len(first):]
    if swap is not None:
        assert text.count(swap[0]) == 1, f"expected one {swap[0]!r} in {source}"
        text = text.replace(swap[0], swap[1])
    copy.write_text(text)


def _inventory(workspace: Path) -> dict[str, int]:
    doc = json.loads((workspace / PUBLIC_JSON).read_text())
    return {
        "models": len(doc["models"]),
        "providers": len(doc["providers"]),
        "evaluations": len(doc["evaluations"]),
    }


def _file_stamps(workspace: Path) -> dict[Path, int]:
    """Modification time of every file in the workspace, keyed by relative path."""
    stamps: dict[Path, int] = {}
    for dirpath, dirnames, filenames in os.walk(workspace):
        dirnames[:] = [d for d in dirnames if d not in COPY_IGNORE_DIRS and d != ".venv-agent"]
        for name in filenames:
            full = Path(dirpath) / name
            try:
                stamps[full.relative_to(workspace)] = full.lstat().st_mtime_ns
            except OSError:
                continue
    return stamps


def _digest_spellings(raw: bytes) -> list[str]:
    """Text forms a stored copy of a SHA-256 value could take."""
    b64 = base64.b64encode(raw).decode()
    url = base64.urlsafe_b64encode(raw).decode()
    return sorted({b64, b64.rstrip("="), url, url.rstrip("=")})


def _is_test_file(rel: Path) -> bool:
    return rel.name.endswith("_test.go") or "testdata" in rel.parts


# ── Built-in catalog digest equals the SHA-256 of the published catalog ─────
# Edit one value in the catalog content, in both the embedded payload and the
# published JSON, identically and without regenerating. Then require
# BuiltIn().Digest() and the compiled registry's Digest() to equal the sha256 of
# the edited published document.
#
# This asserts only the observable invariant (Digest == sha256 of the public
# artifact) through the exported BuiltIn/Compile/Digest surface. It references no
# internal symbol and encodes no particular way of producing the value.
DIGEST_PROBE_TEST = """// Probe test written into a scratch copy of the repository.
package catalog

import "testing"

func TestPublishedCatalogDigestProbe(t *testing.T) {
\tconst want = "{WANT_DIGEST}"

\tregistry, err := BuiltIn()
\tif err != nil {
\t\tt.Fatalf("BuiltIn() returned error: %v", err)
\t}
\tif got := registry.Digest(); got != want {
\t\tt.Fatalf("BuiltIn().Digest() = %s, but sha256(published catalog.json) = %s", got, want)
\t}

\teffective, err := registry.Compile(CompileInput{})
\tif err != nil {
\t\tt.Fatalf("Compile(CompileInput{}) returned error: %v", err)
\t}
\tif got := effective.Digest(); got != want {
\t\tt.Fatalf("compiled registry Digest() = %s, want %s", got, want)
\t}
}
"""


def test_builtin_digest_tracks_published_catalog():
    workspace = _fresh_workspace()
    try:
        # display_name is a free-form label, so schema identity and record counts
        # are untouched: BuiltIn() still parses, and the two projections stay
        # consistent (the published document is the embedded payload plus a
        # trailing newline).
        _replace_once(workspace / EMBED_GO, PAYLOAD_PROBE_FROM, PAYLOAD_PROBE_TO)
        _replace_once(workspace / PUBLIC_JSON, PAYLOAD_PROBE_FROM, PAYLOAD_PROBE_TO)

        published = (workspace / PUBLIC_JSON).read_bytes()
        want = "sha256:" + hashlib.sha256(published).hexdigest()

        probe = workspace / CATALOG_PKG / "zzz_published_digest_probe_test.go"
        probe.write_text(DIGEST_PROBE_TEST.replace("{WANT_DIGEST}", want))

        test_name = "TestPublishedCatalogDigestProbe"
        proc, outcomes = _run_go_test(
            module_dir=workspace / GO_MODULE,
            package="./pkg/catalog",
            test_re=f"^{test_name}$",
        )
        assert test_name in outcomes, (
            "digest probe test did not run (build or discovery failure)" + _diag(proc)
        )
        assert outcomes[test_name] == "pass", (
            "after an edit to the catalog content, BuiltIn().Digest() or the "
            "compiled registry's Digest() did not equal the sha256 of the "
            "published catalog.json" + _diag(proc)
        )
    finally:
        shutil.rmtree(workspace.parent, ignore_errors=True)


# ── Dashboard contract test follows the authored catalog ────────────────────
# One workspace, three steps, all judged by the dashboard catalog contract test
# (the one that reports "unexpected generated inventory"), run by its name.
#
#   Control: on the unchanged copy the test passes. This run also finds which
#   dashboard backend package holds the test.
#
#   Drift: leave the generated catalog.json as shipped and change only the
#   authored sources, so the two disagree by one record. One case per kind
#   (model, provider, evaluation) and per direction (catalog.json lists a record
#   with no authored source; a newly authored record is missing from
#   catalog.json). Each edited or added source file, and its folder, gets an old
#   timestamp, so no source is newer than any generated file. The test must
#   fail in every case.
#
#   Regenerate: remove an evaluation and a provider from the sources and
#   regenerate; then put them back, add a new model, a provider serving it and an
#   evaluation of it, and regenerate again. After each regeneration the test must
#   pass, with no edit to it.
#
# catalog.json is never edited during the drift cases, so it parses and
# normalizes exactly as shipped; only the authored inventory differs.
def _dashboard_outcome(workspace: Path, step: str, package: str) -> str:
    proc, outcomes = _run_dashboard_test(workspace, package)
    assert DASHBOARD_TEST in outcomes, (
        f"the dashboard contract test did not run ({step})" + _diag(proc)
    )
    return outcomes[DASHBOARD_TEST]


def test_dashboard_counts_follow_sources():
    workspace = _fresh_workspace()
    try:
        shipped = _inventory(workspace)

        # The control run searches every package; later runs go straight to the
        # package that holds the test.
        proc, outcomes = _run_dashboard_test(workspace)
        assert outcomes.get(DASHBOARD_TEST) == "pass", (
            "the dashboard contract test did not pass on an unchanged copy of the tree" + _diag(proc)
        )
        package = proc.packages[DASHBOARD_TEST]

        def drop_file(path: Path):
            path.unlink()

        def copy_provider(path: Path):
            _copy_provider(path, workspace / PROVIDER_COPY)

        cases = [
            ("evaluation in catalog.json with no authored source", EVAL_SOURCE, _drop_first_sequence_entry),
            ("new authored evaluation missing from catalog.json", EVAL_SOURCE, _copy_first_sequence_entry),
            ("model in catalog.json with no authored source", MODEL_SOURCE, _drop_first_sequence_entry),
            ("new authored model missing from catalog.json", MODEL_SOURCE, _copy_first_sequence_entry),
            ("provider in catalog.json with no authored source", PROVIDER_SOURCE, drop_file),
            ("new authored provider missing from catalog.json", PROVIDER_SOURCE, copy_provider),
        ]
        stayed_green = []
        for label, rel, edit in cases:
            target = workspace / rel
            original = target.read_bytes()
            stamps = {path: path.stat() for path in (target, target.parent)}
            try:
                edit(target)
                for path in (target, workspace / PROVIDER_COPY, target.parent):
                    if path.exists():
                        os.utime(path, (OLD_STAMP, OLD_STAMP))
                assert _inventory(workspace) == shipped, (
                    "catalog.json must stay as shipped during the drift cases"
                )
                if _dashboard_outcome(workspace, label, package) != "fail":
                    stayed_green.append(label)
            finally:
                target.write_bytes(original)
                (workspace / PROVIDER_COPY).unlink(missing_ok=True)
                for path, stat in stamps.items():
                    os.utime(path, ns=(stat.st_atime_ns, stat.st_mtime_ns))

        assert not stayed_green, (
            "the dashboard contract test still passed when the authored catalog "
            "under config/catalog/resources and the generated catalog.json "
            f"disagreed by one record: {', '.join(stayed_green)}"
        )

        # An evaluation and a provider removed, regenerated: the test stays green.
        originals = {rel: (workspace / rel).read_bytes() for rel in (EVAL_SOURCE, PROVIDER_SOURCE)}
        _drop_first_sequence_entry(workspace / EVAL_SOURCE)
        (workspace / PROVIDER_SOURCE).unlink()
        _regenerate(workspace)
        removed = _inventory(workspace)
        want = {**shipped, "evaluations": shipped["evaluations"] - 1, "providers": shipped["providers"] - 1}
        assert removed == want, (
            f"regeneration did not reflect the removed source records: {shipped} -> {removed}"
        )
        assert _dashboard_outcome(workspace, "records removed", package) == "pass", (
            "the dashboard contract test failed after source records were removed "
            "and the catalog regenerated, with no edit to the test"
        )

        # Those records back, plus a new model, provider and evaluation, regenerated:
        # the test stays green.
        for rel, content in originals.items():
            (workspace / rel).write_bytes(content)
        new_model = _fresh_id(ADDED_MODEL_FROM)
        _copy_entry_by_id(workspace / ADDED_MODEL_SOURCE, ADDED_MODEL_FROM)
        _copy_provider(
            workspace / ADDED_PROVIDER_SOURCE,
            workspace / ADDED_PROVIDER_SOURCE.with_name(_fresh_id(ADDED_PROVIDER_FROM) + ".yaml"),
            (f"- catalog: {ADDED_MODEL_FROM}\n", f"- catalog: {new_model}\n"),
        )
        _copy_entry_by_id(
            workspace / ADDED_EVAL_SOURCE,
            ADDED_EVAL_FROM,
            (f"  model: {ADDED_MODEL_FROM}\n", f"  model: {new_model}\n"),
        )
        _regenerate(workspace)
        added = _inventory(workspace)
        want = {kind: count + 1 for kind, count in shipped.items()}
        assert added == want, (
            f"regeneration did not reflect the added source records: {shipped} -> {added}"
        )
        assert _dashboard_outcome(workspace, "records added", package) == "pass", (
            "the dashboard contract test failed after source records were added "
            "and the catalog regenerated, with no edit to the test"
        )
    finally:
        shutil.rmtree(workspace.parent, ignore_errors=True)


# ── Regeneration stores no copy of the whole-catalog digest ──────────────────
# Regenerate from clean sources, then compute the digest of the regenerated
# published catalog. No file the regeneration wrote (other than catalog.json
# itself) and no non-test Go source in the router module may contain that value,
# in hex (any letter case) or in base64 (standard or URL alphabet, padded or
# not).
#
# The probe keys on the value, computed fresh, never on a symbol name or a
# formula, so any naming or layout is treated the same. Per-asset verification
# digests are different values and are unaffected.
def test_regenerated_catalog_has_no_stored_whole_catalog_digest():
    workspace = _fresh_workspace()
    try:
        stamps_before = _file_stamps(workspace)
        _regenerate(workspace)
        stamps_after = _file_stamps(workspace)

        raw = hashlib.sha256((workspace / PUBLIC_JSON).read_bytes()).digest()
        hex_digest = raw.hex()
        other_spellings = _digest_spellings(raw)

        written = {
            rel for rel, stamp in stamps_after.items()
            if stamps_before.get(rel) != stamp
            and rel != PUBLIC_JSON
            and "__pycache__" not in rel.parts
        }
        go_sources = {
            rel for rel in (
                path.relative_to(workspace)
                for path in (workspace / GO_MODULE).rglob("*.go")
            )
            if not _is_test_file(rel)
        }
        scanned = sorted(written | go_sources)

        offenders = []
        for rel in scanned:
            try:
                text = (workspace / rel).read_text(errors="ignore")
            except OSError:
                continue
            if hex_digest in text.lower() or any(s in text for s in other_spellings):
                offenders.append(rel.as_posix())

        assert not offenders, (
            "after regeneration, the digest of the whole published catalog is "
            "present in checked-in files: " + ", ".join(offenders)
        )
    finally:
        shutil.rmtree(workspace.parent, ignore_errors=True)


# ── Per-asset verification digests survive regeneration ──────────────────────
# Record each asset-bearing model's verification.asset_sha256 from the shipped
# catalog.json. Regenerate from clean sources: every one of those models must
# carry the same value. Then append a line to one file of the bundle they point
# at and regenerate again: each value must now equal the bundle digest of the
# edited files, so the checksum still covers the bundle content.
ASSET_BUNDLE_DIR = Path("config/recipes/built-in/latest")
# File order and framing of the built-in model bundle digest (the five-file
# bundle contract the release tooling also checks).
ASSET_BUNDLE_FILES = ("README.md", "config.yaml", "metadata.yaml", "probes.yaml", "recipe.dsl")


def _asset_digests(workspace: Path) -> dict[str, tuple[str, object]]:
    """model id -> (asset id, verification.asset_sha256) in catalog.json."""
    doc = json.loads((workspace / PUBLIC_JSON).read_text())
    return {
        m["id"]: (m["asset"], (m.get("verification") or {}).get("asset_sha256"))
        for m in doc["models"]
        if isinstance(m.get("asset"), str) and m["asset"]
    }


def _bundle_digest(bundle: Path) -> str:
    digest = hashlib.sha256()
    for name in ASSET_BUNDLE_FILES:
        content = (bundle / name).read_bytes()
        digest.update(name.encode("utf-8"))
        digest.update(b"\0")
        digest.update(len(content).to_bytes(8, "big"))
        digest.update(content)
    return "sha256:" + digest.hexdigest()


def test_per_asset_verification_digests_preserved():
    workspace = _fresh_workspace()
    try:
        shipped = _asset_digests(workspace)
        assert shipped, "no models declare an asset; cannot check asset-level hashing"
        assert all(
            isinstance(value, str) and value.startswith("sha256:") for _, value in shipped.values()
        ), "the shipped catalog.json has an asset-bearing model without asset_sha256"

        _regenerate(workspace)
        regenerated = _asset_digests(workspace)
        changed = sorted(model for model, entry in shipped.items() if regenerated.get(model) != entry)
        assert not changed, (
            "after regeneration, verification.asset_sha256 no longer matches the "
            f"shipped value for: {', '.join(changed)}"
        )

        assets = sorted({asset for asset, _ in shipped.values()})
        bundle = workspace / ASSET_BUNDLE_DIR / assets[0]
        assert bundle.is_dir(), f"asset bundle {assets[0]} not found under {ASSET_BUNDLE_DIR}"
        readme = bundle / "README.md"
        readme.write_bytes(readme.read_bytes() + b"\nLocal note added to the bundle.\n")
        want = _bundle_digest(bundle)
        before = {value for asset, value in shipped.values() if asset == assets[0]}
        assert want not in before, "the bundle edit did not change its digest"

        _regenerate(workspace)
        edited = _asset_digests(workspace)
        stale = sorted(
            model for model, (asset, _) in shipped.items()
            if asset == assets[0] and edited.get(model) != (asset, want)
        )
        assert not stale, (
            f"after an edit to the {assets[0]} bundle and a regeneration, "
            f"verification.asset_sha256 is not the digest of the edited bundle for: {', '.join(stale)}"
        )
    finally:
        shutil.rmtree(workspace.parent, ignore_errors=True)
