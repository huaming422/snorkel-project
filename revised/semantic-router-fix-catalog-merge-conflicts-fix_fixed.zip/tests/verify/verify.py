"""Behavioral checks for the model catalog's derived values.

These checks run under the shared verifier interpreter (``VERIFIER_PYTHON`` /
``/opt/tooling/venv``). That interpreter has no YAML/jsonschema, so this module
never imports repository Python. It drives the real toolchain the same way a
maintainer would:

  * it copies the checked-out tree into a scratch workspace,
  * edits catalog sources or the embedded payload there,
  * re-runs the catalog generator with the repo's own Python, and
  * runs Go code through ``go test`` on exported entry points
    (``catalog.BuiltIn().Digest()``, ``(*EffectiveRegistry).Digest()``) and the
    dashboard catalog contract test, run by its name.

Each property is about a value following its source: it is correct only if it
changes when the source changes. Showing that needs an edit plus a rebuild or a
regeneration, so the copy, edit, regenerate and run steps are the test.

No check looks up a symbol, file or helper name that the implementation is free
to choose.
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

# ── Repository layout ───────────────────────────────────────────────────────
# The runner exports REPO_NAME; the checkout lives at /repo/<REPO_NAME>.
REPO_NAME = os.environ.get("REPO_NAME", "semantic-router")
REPO_DIR = Path(f"/repo/{REPO_NAME}")

# Paths inside the tree (and inside every scratch copy of it).
GO_MODULE = Path("src/semantic-router")
CATALOG_PKG = GO_MODULE / "pkg" / "catalog"
EMBED_GO = CATALOG_PKG / "zz_generated_catalog.go"
PUBLIC_JSON = Path("website/static/model-catalog/catalog.json")
GENERATOR = Path("tools/catalog/generate_model_catalog.py")
DASHBOARD_MODULE = Path("dashboard/backend")
DASHBOARD_TEST = "TestGeneratedPublicModelCatalogSatisfiesDashboardContract"

# A value that appears exactly once inside the embedded catalog payload literal,
# as a display label. Editing it changes catalog content without touching counts
# or schema identity.
PAYLOAD_PROBE_FROM = '"display_name": "MMLU-Pro"'
PAYLOAD_PROBE_TO = '"display_name": "MMLU-Proxy"'

# Authored catalog sources used by the dashboard checks. Evaluation and model
# files hold a top-level YAML sequence; each provider file holds one mapping.
EVAL_SOURCE = Path("config/catalog/resources/evaluations/single/ai21.yaml")
MODEL_SOURCE = Path("config/catalog/resources/models/single/ai21.yaml")
PROVIDER_SOURCE = Path("config/catalog/resources/providers/agnes.yaml")
PROVIDER_COPY = Path("config/catalog/resources/providers/agnes-duplicate.yaml")

# Per-step ceilings. The whole run is bounded by verify.toml [pytest].timeout
# (and the outer [verifier].timeout_sec); these inner limits only catch a single
# hung step.
GO_TIMEOUT = 300
GEN_TIMEOUT = 180
COPY_IGNORE_DIRS = {".git", "node_modules", ".venv"}
COPY_IGNORE_STATIC = {"img", "videos"}
COPY_IGNORE_SUFFIX = (".pdf", ".mp4", ".webm", ".mov")


# ── Workspace helpers ───────────────────────────────────────────────────────
def _copy_ignore(dirpath, names):
    """Skip heavy media and VCS trees; keep everything the build reads."""
    skip = set()
    base = os.path.basename(dirpath)
    for name in names:
        if name in COPY_IGNORE_DIRS:
            skip.add(name)
        elif base == "static" and name in COPY_IGNORE_STATIC:
            skip.add(name)
        elif name.lower().endswith(COPY_IGNORE_SUFFIX):
            skip.add(name)
    return skip


def _fresh_workspace() -> Path:
    """Copy the checkout into a scratch dir and return its root."""
    assert REPO_DIR.is_dir(), f"repository checkout not found at {REPO_DIR}"
    dst = Path(tempfile.mkdtemp(prefix="catalog-verify-"))
    workspace = dst / REPO_NAME
    shutil.copytree(REPO_DIR, workspace, ignore=_copy_ignore, symlinks=True)
    return workspace


def _catalog_python() -> str:
    """A Python that can import the catalog generator's third-party deps.

    The shared verifier interpreter cannot (no YAML/jsonschema). The image bakes
    an offline environment beside the checkout for this; fall back to a system
    interpreter that happens to have the deps.
    """
    candidates = [
        str(REPO_DIR / ".venv-agent" / "bin" / "python"),
        str(REPO_DIR / ".venv" / "bin" / "python"),
        shutil.which("python3") or "python3",
    ]
    for candidate in candidates:
        if not candidate or not (candidate == "python3" or Path(candidate).exists()):
            continue
        try:
            probe = subprocess.run(
                [candidate, "-c", "import yaml, jsonschema"],
                capture_output=True,
                timeout=60,
            )
        except (OSError, subprocess.SubprocessError):
            continue
        if probe.returncode == 0:
            return candidate
    raise RuntimeError(
        "no interpreter with the catalog generator's dependencies "
        "(PyYAML + jsonschema) was found; the image is expected to bake one "
        "beside the checkout"
    )


def _regenerate(workspace: Path) -> None:
    """Run the catalog generator in place over a scratch workspace."""
    proc = subprocess.run(
        [_catalog_python(), str(workspace / GENERATOR)],
        cwd=str(workspace),
        capture_output=True,
        text=True,
        timeout=GEN_TIMEOUT,
    )
    assert proc.returncode == 0, (
        "catalog regeneration failed (exit "
        f"{proc.returncode}):\n{proc.stdout[-1500:]}\n{proc.stderr[-1500:]}"
    )


def _run_go_test(module_dir: Path, package: str, test_re: str, timeout: int = GO_TIMEOUT):
    """Run one Go test by name; return (proc, {test_name: 'pass'|'fail'|'skip'}).

    Deps are prewarmed in the image, so the subprocess is pinned offline and
    writable-module to stay hermetic.
    """
    env = {
        **os.environ,
        "GOFLAGS": "-mod=mod",
        "GOPROXY": "off",
        "CGO_ENABLED": "1",
        "GOTOOLCHAIN": "local",
    }
    cmd = [
        "go", "test", "-json", "-count=1",
        f"-timeout={timeout}s", "-run", test_re, package,
    ]
    proc = subprocess.run(
        cmd,
        cwd=str(module_dir),
        capture_output=True,
        text=True,
        timeout=timeout + 60,
        env=env,
    )
    outcomes: dict[str, str] = {}
    for line in proc.stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        name = event.get("Test")
        action = event.get("Action")
        if name and action in ("pass", "fail", "skip"):
            outcomes[name] = action
    return proc, outcomes


def _run_dashboard_test(workspace: Path):
    return _run_go_test(
        module_dir=workspace / DASHBOARD_MODULE,
        package="./handlers",
        test_re=f"^{DASHBOARD_TEST}$",
    )


def _diag(proc) -> str:
    return f"\n--- go stdout tail ---\n{proc.stdout[-2000:]}\n--- go stderr tail ---\n{proc.stderr[-2000:]}"


def _replace_once(path: Path, old: str, new: str) -> None:
    text = path.read_text()
    count = text.count(old)
    assert count == 1, f"expected exactly one occurrence of {old!r} in {path}, found {count}"
    path.write_text(text.replace(old, new, 1))


def _first_sequence_entry(lines: list[str], path: Path) -> tuple[int, int]:
    """Line span [start, end) of the first top-level ``- `` YAML sequence entry."""
    start = next((i for i, ln in enumerate(lines) if ln.startswith("- ")), None)
    assert start is not None, f"no top-level sequence entry found in {path}"
    end = len(lines)
    for j in range(start + 1, len(lines)):
        if lines[j].startswith("- "):
            end = j
            break
    assert end > start
    return start, end


def _drop_first_sequence_entry(path: Path) -> None:
    """Remove the first top-level sequence entry with plain text edits.

    Text edits keep this runnable under the stdlib-only verifier interpreter.
    """
    lines = path.read_text().splitlines(keepends=True)
    start, end = _first_sequence_entry(lines, path)
    path.write_text("".join(lines[:start] + lines[end:]))


def _duplicate_first_sequence_entry(path: Path) -> None:
    """Write a second copy of the first top-level sequence entry right after it."""
    lines = path.read_text().splitlines(keepends=True)
    start, end = _first_sequence_entry(lines, path)
    entry = lines[start:end]
    if not entry[-1].endswith("\n"):
        entry[-1] += "\n"
    path.write_text("".join(lines[:end] + entry + lines[end:]))


def _inventory(workspace: Path) -> dict[str, int]:
    doc = json.loads((workspace / PUBLIC_JSON).read_text())
    return {
        "models": len(doc["models"]),
        "providers": len(doc["providers"]),
        "evaluations": len(doc["evaluations"]),
    }


def _file_stamps(workspace: Path) -> dict[Path, int]:
    """Modification time of every file in the workspace, keyed by relative path."""
    stamps: dict[Path, int] = {}
    for dirpath, dirnames, filenames in os.walk(workspace):
        dirnames[:] = [d for d in dirnames if d not in COPY_IGNORE_DIRS and d != ".venv-agent"]
        for name in filenames:
            full = Path(dirpath) / name
            try:
                stamps[full.relative_to(workspace)] = full.lstat().st_mtime_ns
            except OSError:
                continue
    return stamps


def _digest_spellings(raw: bytes) -> list[str]:
    """Text forms a stored copy of a SHA-256 value could take."""
    b64 = base64.b64encode(raw).decode()
    url = base64.urlsafe_b64encode(raw).decode()
    return sorted({b64, b64.rstrip("="), url, url.rstrip("=")})


def _is_test_file(rel: Path) -> bool:
    return rel.name.endswith("_test.go") or "testdata" in rel.parts


# ── Built-in catalog digest equals the SHA-256 of the published catalog ─────
# Edit one value in the catalog content, in both the embedded payload and the
# published JSON, identically and without regenerating. Then require
# BuiltIn().Digest() and the compiled registry's Digest() to equal the sha256 of
# the edited published document.
#
# This asserts only the observable invariant (Digest == sha256 of the public
# artifact) through the exported BuiltIn/Compile/Digest surface. It references no
# internal symbol and encodes no particular way of producing the value.
DIGEST_PROBE_TEST = """// Probe test written into a scratch copy of the repository.
package catalog

import "testing"

func TestPublishedCatalogDigestProbe(t *testing.T) {
\tconst want = "{WANT_DIGEST}"

\tregistry, err := BuiltIn()
\tif err != nil {
\t\tt.Fatalf("BuiltIn() returned error: %v", err)
\t}
\tif got := registry.Digest(); got != want {
\t\tt.Fatalf("BuiltIn().Digest() = %s, but sha256(published catalog.json) = %s", got, want)
\t}

\teffective, err := registry.Compile(CompileInput{})
\tif err != nil {
\t\tt.Fatalf("Compile(CompileInput{}) returned error: %v", err)
\t}
\tif got := effective.Digest(); got != want {
\t\tt.Fatalf("compiled registry Digest() = %s, want %s", got, want)
\t}
}
"""


def test_builtin_digest_tracks_published_catalog():
    workspace = _fresh_workspace()
    try:
        # display_name is a free-form label, so schema identity and record counts
        # are untouched: BuiltIn() still parses, and the two projections stay
        # consistent (the published document is the embedded payload plus a
        # trailing newline).
        _replace_once(workspace / EMBED_GO, PAYLOAD_PROBE_FROM, PAYLOAD_PROBE_TO)
        _replace_once(workspace / PUBLIC_JSON, PAYLOAD_PROBE_FROM, PAYLOAD_PROBE_TO)

        published = (workspace / PUBLIC_JSON).read_bytes()
        want = "sha256:" + hashlib.sha256(published).hexdigest()

        probe = workspace / CATALOG_PKG / "zzz_published_digest_probe_test.go"
        probe.write_text(DIGEST_PROBE_TEST.replace("{WANT_DIGEST}", want))

        test_name = "TestPublishedCatalogDigestProbe"
        proc, outcomes = _run_go_test(
            module_dir=workspace / GO_MODULE,
            package="./pkg/catalog",
            test_re=f"^{test_name}$",
        )
        assert test_name in outcomes, (
            "digest probe test did not run (build or discovery failure)" + _diag(proc)
        )
        assert outcomes[test_name] == "pass", (
            "after an edit to the catalog content, BuiltIn().Digest() or the "
            "compiled registry's Digest() did not equal the sha256 of the "
            "published catalog.json" + _diag(proc)
        )
    finally:
        shutil.rmtree(workspace.parent, ignore_errors=True)


# ── Dashboard contract test follows the authored catalog ─────────────────────
# Two phases, each over its own fresh workspace.
#
#   Phase 1: remove one evaluation record from the sources and regenerate. The
#   dashboard contract test must pass with no edit to the test.
#
#   Phase 2: leave the generated catalog.json as shipped and change only the
#   authored sources, so the two disagree by one record. One case per kind
#   (model, provider, evaluation) and per direction (catalog.json lists a record
#   with no authored source; a record is authored twice but listed once). The
#   test must fail in every case, and pass on the unchanged copy first.
#
# The generated catalog.json is never edited in Phase 2, so it parses and
# normalizes exactly as shipped; only the authored inventory differs.
def test_dashboard_counts_follow_sources():
    # Phase 1: removing a source record and regenerating keeps the test green.
    workspace = _fresh_workspace()
    try:
        before = _inventory(workspace)

        _drop_first_sequence_entry(workspace / EVAL_SOURCE)
        _regenerate(workspace)

        after = _inventory(workspace)
        assert after["evaluations"] == before["evaluations"] - 1, (
            f"regeneration did not reflect the removed source record: "
            f"evaluations {before['evaluations']} -> {after['evaluations']}"
        )
        assert after["models"] == before["models"], "model count changed unexpectedly"
        assert after["providers"] == before["providers"], "provider count changed unexpectedly"

        proc, outcomes = _run_dashboard_test(workspace)
        assert DASHBOARD_TEST in outcomes, (
            "the dashboard contract test did not run after the source edit" + _diag(proc)
        )
        assert outcomes[DASHBOARD_TEST] == "pass", (
            "the dashboard contract test failed after a source record was removed "
            "and the catalog regenerated; it is expected to pass with no edit" + _diag(proc)
        )
    finally:
        shutil.rmtree(workspace.parent, ignore_errors=True)

    # Phase 2: the authored sources and the shipped catalog.json disagree.
    drift = _fresh_workspace()
    try:
        baseline = _inventory(drift)

        proc, outcomes = _run_dashboard_test(drift)
        assert outcomes.get(DASHBOARD_TEST) == "pass", (
            "the dashboard contract test did not pass on an unchanged copy of the "
            "tree" + _diag(proc)
        )

        def drop_file(path: Path):
            path.unlink()

        def copy_file(path: Path):
            shutil.copyfile(path, drift / PROVIDER_COPY)

        cases = [
            ("evaluation in catalog.json with no authored source", EVAL_SOURCE, _drop_first_sequence_entry),
            ("evaluation authored twice, listed once in catalog.json", EVAL_SOURCE, _duplicate_first_sequence_entry),
            ("model in catalog.json with no authored source", MODEL_SOURCE, _drop_first_sequence_entry),
            ("model authored twice, listed once in catalog.json", MODEL_SOURCE, _duplicate_first_sequence_entry),
            ("provider in catalog.json with no authored source", PROVIDER_SOURCE, drop_file),
            ("provider authored twice, listed once in catalog.json", PROVIDER_SOURCE, copy_file),
        ]
        stayed_green = []
        for label, rel, edit in cases:
            target = drift / rel
            original = target.read_bytes()
            try:
                edit(target)
                assert _inventory(drift) == baseline, (
                    "catalog.json must stay as shipped during the drift cases"
                )
                proc, outcomes = _run_dashboard_test(drift)
                assert DASHBOARD_TEST in outcomes, (
                    f"the dashboard contract test did not run ({label})" + _diag(proc)
                )
                if outcomes[DASHBOARD_TEST] != "fail":
                    stayed_green.append(label)
            finally:
                target.write_bytes(original)
                (drift / PROVIDER_COPY).unlink(missing_ok=True)

        assert not stayed_green, (
            "the dashboard contract test still passed when the authored catalog "
            "under config/catalog/resources and the generated catalog.json "
            f"disagreed by one record: {', '.join(stayed_green)}"
        )
    finally:
        shutil.rmtree(drift.parent, ignore_errors=True)


# ── Regeneration stores no copy of the whole-catalog digest ──────────────────
# Regenerate from clean sources, then compute the digest of the regenerated
# published catalog. No file the regeneration wrote (other than catalog.json
# itself) and no non-test Go source in the router module may contain that value,
# in hex (any letter case) or in base64 (standard or URL alphabet, padded or
# not).
#
# The probe keys on the value, computed fresh, never on a symbol name or a
# formula, so any naming or layout is treated the same. Per-asset verification
# digests are different values and are unaffected.
def test_regenerated_catalog_has_no_stored_whole_catalog_digest():
    workspace = _fresh_workspace()
    try:
        stamps_before = _file_stamps(workspace)
        _regenerate(workspace)
        stamps_after = _file_stamps(workspace)

        raw = hashlib.sha256((workspace / PUBLIC_JSON).read_bytes()).digest()
        hex_digest = raw.hex()
        other_spellings = _digest_spellings(raw)

        written = {
            rel for rel, stamp in stamps_after.items()
            if stamps_before.get(rel) != stamp
            and rel != PUBLIC_JSON
            and "__pycache__" not in rel.parts
        }
        go_sources = {
            rel for rel in (
                path.relative_to(workspace)
                for path in (workspace / GO_MODULE).rglob("*.go")
            )
            if not _is_test_file(rel)
        }
        scanned = sorted(written | go_sources)

        offenders = []
        for rel in scanned:
            try:
                text = (workspace / rel).read_text(errors="ignore")
            except OSError:
                continue
            if hex_digest in text.lower() or any(s in text for s in other_spellings):
                offenders.append(rel.as_posix())

        assert not offenders, (
            "after regeneration, the digest of the whole published catalog is "
            "present in checked-in files: " + ", ".join(offenders)
        )
    finally:
        shutil.rmtree(workspace.parent, ignore_errors=True)


# ── Per-asset verification digests survive regeneration ──────────────────────
# Regenerate from clean sources and require the public projection to still carry
# a per-asset verification digest for every model that declares an asset.
def test_per_asset_verification_digests_preserved():
    workspace = _fresh_workspace()
    try:
        _regenerate(workspace)
        doc = json.loads((workspace / PUBLIC_JSON).read_text())
        with_asset = [
            m for m in doc["models"]
            if isinstance(m.get("asset"), str) and m["asset"]
        ]
        assert with_asset, "no models declare an asset; cannot check asset-level hashing"
        hashed = [
            m for m in with_asset
            if isinstance(m.get("verification"), dict)
            and isinstance(m["verification"].get("asset_sha256"), str)
            and m["verification"]["asset_sha256"]
        ]
        assert len(hashed) == len(with_asset), (
            "the regenerated catalog is missing per-asset verification digests: "
            f"{len(hashed)}/{len(with_asset)} asset-bearing models carry asset_sha256"
        )
    finally:
        shutil.rmtree(workspace.parent, ignore_errors=True)
