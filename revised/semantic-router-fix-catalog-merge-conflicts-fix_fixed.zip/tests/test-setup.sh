#!/usr/bin/env bash
# All required deps are baked into the image at the base commit:
#   - Go 1.25.0 toolchain + warmed module/build caches for all three modules
#     (src/semantic-router, dashboard/backend, deploy/operator), incl. the cgo
#     sqlite chain the dashboard/backend/handlers package compiles against.
#   - An offline ./.venv-agent (PyYAML==6.0.3, jsonschema==4.26.0) that the repo
#     Makefile's model-catalog targets auto-select for the catalog generator.
# Nothing to install at verifier time.
set -euo pipefail
echo "[test-setup] no-op for semantic-router-fix-catalog-merge-conflicts"
