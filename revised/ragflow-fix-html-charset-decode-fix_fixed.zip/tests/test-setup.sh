#!/usr/bin/env bash
# Verifier-time setup for ragflow-fix-html-charset-decode.
#
# Dependencies are baked into the image (module cache and a warm build cache
# for the parser package), and the run is offline, so there is nothing to
# install here.
#
# Offline-first by contract: do not fetch anything. If a future check needs a
# package the image lacks, add it to the Dockerfile instead.
set -euo pipefail
echo "[test-setup] no-op for ragflow-fix-html-charset-decode (deps baked at image build)"
