package parser

// Behavioral checks for HTML pages whose bytes are not UTF-8.
//
// Every case goes through NewHTMLParser().ParseWithResult(ctx, name, bytes)
// and asserts only on the returned items: no error, no U+FFFD in the
// extracted text, and the page's real characters present.
//
// Fixtures are built by encoding known UTF-8 source into a legacy byte
// encoding at run time with golang.org/x/text/encoding/*, so the inputs are
// real non-UTF-8 bytes rather than checked-in blobs. Each non-UTF-8 fixture
// is checked to be invalid UTF-8 before it is parsed.

import (
	"context"
	"strings"
	"testing"
	"unicode/utf8"

	"golang.org/x/text/encoding"
	"golang.org/x/text/encoding/charmap"
	"golang.org/x/text/encoding/japanese"
	"golang.org/x/text/encoding/korean"
	"golang.org/x/text/encoding/simplifiedchinese"
	"golang.org/x/text/encoding/traditionalchinese"
)

// reEncode converts a UTF-8 source string into enc's byte encoding and
// requires the result to be invalid UTF-8.
func reEncode(t *testing.T, src string, enc encoding.Encoding) []byte {
	t.Helper()
	raw, err := enc.NewEncoder().Bytes([]byte(src))
	if err != nil {
		t.Fatalf("re-encode fixture: %v", err)
	}
	if utf8.Valid(raw) {
		t.Fatal("fixture bytes are valid UTF-8, so they do not exercise a non-UTF-8 page")
	}
	return raw
}

// parse runs the input through ParseWithResult with default settings
// (NewHTMLParser leaves RemoveHeaderFooter/RemoveTOC false, so no block is
// stripped) and fails on any parse error.
func parse(t *testing.T, name string, data []byte) ParseResult {
	t.Helper()
	res := NewHTMLParser().ParseWithResult(context.Background(), name, data)
	if res.Err != nil {
		t.Fatalf("ParseWithResult(%s): %v", name, res.Err)
	}
	return res
}

// joinedText concatenates the text of every emitted item, newline-separated.
func joinedText(res ParseResult) string {
	var sb strings.Builder
	for _, it := range res.JSON {
		if s, ok := it["text"].(string); ok {
			sb.WriteString(s)
			sb.WriteByte('\n')
		}
	}
	return sb.String()
}

// assertReadable fails if the extracted text contains the U+FFFD
// replacement rune or is missing any expected substring.
func assertReadable(t *testing.T, res ParseResult, wants []string) {
	t.Helper()
	got := joinedText(res)
	if strings.ContainsRune(got, '�') {
		t.Errorf("extracted text contains U+FFFD replacement runes: %q", got)
	}
	for _, w := range wants {
		if !strings.Contains(got, w) {
			t.Errorf("extracted text missing expected content %q; got: %q", w, got)
		}
	}
}

// --- Shared fixture content ------------------------------------------------

// Simplified-Chinese balance-sheet body with a table, like the reported
// document (a Chinese financial statement saved from a finance site).
const (
	cjkTitle = "贵州茅台资产负债表"
	cjkCell  = "货币资金"
	cjkCell2 = "应收账款"
)

func gbkBody() string {
	return "<h1>" + cjkTitle + "</h1>" +
		"<table><tr><th>项目</th><th>20251231</th></tr>" +
		"<tr><td>" + cjkCell + "</td><td>56000000000.00</td></tr>" +
		"<tr><td>" + cjkCell2 + "</td><td>1200000000.00</td></tr></table>" +
		"<p>单位：元</p>"
}

// --- Pages that declare their charset ---------------------------------------

// metaCharset returns a <meta charset> tag for label.
func metaCharset(label string) string {
	return `<meta charset="` + label + `">`
}

// httpEquivCharset returns an http-equiv Content-Type tag for label.
func httpEquivCharset(label string) string {
	return `<meta http-equiv="Content-Type" content="text/html; charset=` + label + `">`
}

// A GBK page that declares its charset parses to its real Chinese text,
// whichever common label the declaration uses.
func TestDeclaredNonUTF8_Readable(t *testing.T) {
	for _, decl := range []string{
		httpEquivCharset("gb2312"),
		metaCharset("GBK"),
		metaCharset("x-gbk"),
		metaCharset("GB18030"),
	} {
		src := "<html><head>" + decl + "<title>" + cjkTitle + "</title></head><body>" +
			gbkBody() + "</body></html>"
		t.Logf("declaration %s", decl)
		res := parse(t, "balance.html", reEncode(t, src, simplifiedchinese.GBK))
		assertReadable(t, res, []string{cjkTitle, cjkCell, cjkCell2})
	}
}

// A Big5 page that declares its charset parses to its real
// Traditional-Chinese text under each Big5 label.
func TestDeclaredBig5_Readable(t *testing.T) {
	title := "臺北市政府財務報表"
	body := "流動資產合計"
	for _, label := range []string{"Big5", "big5-hkscs", "cn-big5"} {
		src := "<html><head>" + metaCharset(label) + "</head><body><h2>" + title +
			"</h2><p>" + body + "</p></body></html>"
		t.Logf("label %s", label)
		res := parse(t, "taipei.html", reEncode(t, src, traditionalchinese.Big5))
		assertReadable(t, res, []string{title, body})
	}
}

// A Shift-JIS page that declares its charset parses to its real Japanese
// text under each Shift-JIS label.
func TestDeclaredShiftJIS_Readable(t *testing.T) {
	title := "決算報告書"
	body := "流動資産の合計"
	for _, label := range []string{"Shift_JIS", "windows-31j", "x-sjis"} {
		src := "<html><head>" + metaCharset(label) + "</head><body><h2>" + title +
			"</h2><p>" + body + "</p></body></html>"
		t.Logf("label %s", label)
		res := parse(t, "kessan.html", reEncode(t, src, japanese.ShiftJIS))
		assertReadable(t, res, []string{title, body})
	}
}

// An EUC-KR page that declares its charset parses to its real Korean text.
func TestDeclaredEUCKR_Readable(t *testing.T) {
	title := "재무상태표"
	body := "유동자산 합계"
	for _, decl := range []string{metaCharset("EUC-KR"), httpEquivCharset("ks_c_5601-1987")} {
		src := "<html><head>" + decl + "</head><body><h2>" + title +
			"</h2><p>" + body + "</p></body></html>"
		t.Logf("declaration %s", decl)
		res := parse(t, "seoul.html", reEncode(t, src, korean.EUCKR))
		assertReadable(t, res, []string{title, body})
	}
}

// A Western European page that declares windows-1252 under any of its
// labels keeps the characters that only windows-1252 has (euro sign, curly
// quotes, dashes), one that declares iso-8859-1 keeps its accented letters,
// and pages that declare iso-8859-15
// or Mac Roman keep their euro sign, ligatures and accented letters, which
// sit on other bytes than in windows-1252 or iso-8859-1.
func TestDeclaredWestern_Readable(t *testing.T) {
	cases := []struct {
		decl  string
		enc   encoding.Encoding
		wants []string
	}{
		{metaCharset("Windows-1252"), charmap.Windows1252, []string{"Résultat net", "12 500 €", "“offre spéciale”"}},
		{httpEquivCharset("ISO-8859-1"), charmap.Windows1252, []string{"Übersicht der Geschäftszahlen", "Café"}},
		{metaCharset("latin1"), charmap.Windows1252, []string{"Compte de résultat", "8 750 €", "“tarif réduit”"}},
		{httpEquivCharset("cp1252"), charmap.Windows1252, []string{"Jahresabschluss", "3 400 €", "„Gewinn“ – Übersicht"}},
		{metaCharset("x-cp1252"), charmap.Windows1252, []string{"Relazione annuale", "1 950 €", "‘Totale’"}},
		{metaCharset("iso-8859-15"), charmap.ISO8859_15, []string{"Œuvre complète", "Prix 12,50 €", "cœur"}},
		{httpEquivCharset("ISO_8859-15"), charmap.ISO8859_15, []string{"Bilan de l'exercice", "Total 980 €", "Œufs"}},
		{metaCharset("macintosh"), charmap.Macintosh, []string{"Résumé annuel", "Total 4 200 €", "Œuvre"}},
		{httpEquivCharset("x-mac-roman"), charmap.Macintosh, []string{"Übersicht", "Straße", "Café"}},
	}
	for _, c := range cases {
		src := "<html><head>" + c.decl + "</head><body><h2>" + c.wants[0] + "</h2>"
		for _, w := range c.wants[1:] {
			src += "<p>" + w + "</p>"
		}
		src += "</body></html>"
		t.Logf("declaration %s", c.decl)
		res := parse(t, "western.html", reEncode(t, src, c.enc))
		assertReadable(t, res, c.wants)
	}
}

// --- Pages with no charset declaration ------------------------------------

// A GBK page with no charset declaration anywhere parses to its real
// Chinese text.
func TestUndeclaredGBK_Readable(t *testing.T) {
	src := "<html><head><title>" + cjkTitle + "</title></head><body>" +
		gbkBody() + "</body></html>"
	res := parse(t, "undeclared.html", reEncode(t, src, simplifiedchinese.GBK))
	assertReadable(t, res, []string{cjkTitle, cjkCell, cjkCell2})
}

// A Big5 page with no charset declaration parses to its true
// Traditional-Chinese characters. The exact characters must come back, so
// text that decodes cleanly into other Chinese characters does not count.
func TestUndeclaredBig5_RoundTrips(t *testing.T) {
	big5Title := "台灣大學資料庫"
	big5Body := "這是一份繁體中文測試文件。"
	src := "<html><body><h1>" + big5Title + "</h1><p>" + big5Body + "</p></body></html>"
	res := parse(t, "tw.html", reEncode(t, src, traditionalchinese.Big5))
	assertReadable(t, res, []string{big5Title, "繁體中文"})
}

// A Shift-JIS page with no charset declaration parses to its true Japanese
// kana and kanji.
func TestUndeclaredShiftJIS_RoundTrips(t *testing.T) {
	jpTitle := "日本語のテスト"
	jpBody := "これはシフトJISで書かれた文書です。東京都庁。"
	src := "<html><body><h1>" + jpTitle + "</h1><p>" + jpBody + "</p></body></html>"
	res := parse(t, "jp.html", reEncode(t, src, japanese.ShiftJIS))
	assertReadable(t, res, []string{jpTitle, "東京都庁"})
}

// --- Pages that already parse correctly -----------------------------------

// Valid UTF-8 input, with both CJK and ASCII text, parses to the same text.
func TestUTF8_Passthrough(t *testing.T) {
	src := "<html><body><h1>" + cjkTitle + "</h1><p>plain ascii content</p></body></html>"
	res := parse(t, "utf8.html", []byte(src))
	assertReadable(t, res, []string{cjkTitle, "plain ascii content"})
}

// A UTF-8 page whose first non-ASCII byte comes after a long ASCII head
// (over 1024 bytes of inline CSS, no charset declaration) parses to the
// same text.
func TestUTF8_LongASCIIHead_Passthrough(t *testing.T) {
	css := strings.Repeat("p { margin: 0; padding: 0; }\n", 50)
	src := "<html><head><style>" + css + "</style></head><body><h1>" + cjkTitle +
		"</h1><p>" + cjkCell + " 56000000000.00</p></body></html>"
	if strings.IndexFunc(src, func(r rune) bool { return r > 0x7f }) <= 1024 {
		t.Fatal("fixture's first non-ASCII byte is within the first 1024 bytes")
	}
	res := parse(t, "utf8-long-head.html", []byte(src))
	assertReadable(t, res, []string{cjkTitle, cjkCell})
}

// Empty input parses without error and yields no text.
func TestEmptyInput_NoRegression(t *testing.T) {
	res := parse(t, "empty.html", nil)
	if got := strings.TrimSpace(joinedText(res)); got != "" {
		t.Errorf("empty input produced text %q, want none", got)
	}
}

// --- Table items ----------------------------------------------------------

// The structured table item (doc_type_kwd == "table") emitted from a GBK
// page carries the real cell text.
func TestTableItemDecoded_FromGBK(t *testing.T) {
	src := "<html><head>" +
		`<meta http-equiv="Content-Type" content="text/html; charset=gb2312">` +
		"</head><body>" + gbkBody() + "</body></html>"
	res := parse(t, "table.html", reEncode(t, src, simplifiedchinese.GBK))

	var tableText string
	found := false
	for _, it := range res.JSON {
		if dt, _ := it["doc_type_kwd"].(string); dt == "table" {
			found = true
			tableText, _ = it["text"].(string)
		}
	}
	if !found {
		t.Fatalf("no doc_type_kwd==\"table\" item emitted; items: %#v", res.JSON)
	}
	if strings.ContainsRune(tableText, '�') {
		t.Errorf("table item text contains U+FFFD replacement runes: %q", tableText)
	}
	if !strings.Contains(tableText, cjkCell) {
		t.Errorf("table item missing decoded cell %q; got: %q", cjkCell, tableText)
	}
}
