## Task

Someone fed an HTML page through our ingestion setup and the parsed text came back as junk.
We run ingestion on the Go worker (`ragflow_server --ingestor`).
The page is a Chinese balance sheet saved off a finance site, and it looks fine in a browser.
After parsing, though, the text is mostly `�` characters mixed with random Latin letters, and the figures table is garbled the same way.

It isn't only that page.
Traditional Chinese pages from Taiwan (Big5), Japanese pages in Shift_JIS, and some older Korean and Western European pages all come out wrong too.
The Korean and Western ones all declare their charset in a `<meta>` tag.
The Chinese and Japanese ones are mixed, since some declare it and many have no declaration at all, because they were saved straight from a browser or exported by older tools.
When a page does declare it, the label is whatever the tool that saved it picked.
English pages and files that are already UTF-8 parse fine.

Track down why these pages turn into junk and fix it, so the text we get out of any of them matches what the page says.
Pages that parse correctly now should keep working, and keep the change limited to this bug.
