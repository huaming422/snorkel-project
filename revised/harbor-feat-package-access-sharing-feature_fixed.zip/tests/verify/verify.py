"""Backward-compatibility verifier (pass-to-pass) for
harbor-feat-package-access-sharing.

The new inspect/share/unshare contract is verified by the validation stories,
which discover the commands from the solution and exercise them. This file
holds the complementary, implementation-independent guarantee that the change
does NOT break existing clients: the top-level CLI app and its two package
subcommand groups must remain importable and registered, each must render
`--help` (exit 0), and the pre-existing commands existing invocations depend on
must stay registered.

Pass-to-pass: holds both before any change is applied (the new commands do not
exist yet) and on every valid solution (the new commands are purely additive).
These tests FAIL only if a solution breaks the pre-existing CLI surface: an
import error, a dropped subcommand group, or a removed pre-existing command.
Checking the new behavior itself is the job of the validation stories, not of
this file. The tests never reference any implementation-chosen command/flag/field name.

Runs via `/repo/harbor/.venv/bin/python -m pytest` (see verify.toml),
cwd=/repo/harbor, so `import harbor...` resolves to the editable install.
"""

from __future__ import annotations

from typer.main import get_command
from typer.testing import CliRunner

from harbor.cli.main import app

# Pre-existing package subcommand GROUPS on the top-level app (registered via
# add_typer in harbor/cli/main.py before this task). The feature mounts the new
# commands onto BOTH of these groups, so both must survive the change.
PACKAGE_GROUPS = ("task", "dataset")

# Pre-existing commands on each package group that existing invocations rely on.
# These predate this task; a valid change only ADDS commands, never removes
# these. (Chosen from the stable, non-hidden pre-existing surface.)
PREEXISTING_GROUP_COMMANDS = {
    "task": ("init", "download", "update", "annotate", "visibility", "migrate"),
    "dataset": ("list", "init", "download", "visibility"),
}

# A wide terminal so rich does not wrap names/output across lines.
_WIDE_ENV = {"COLUMNS": "1000", "TERM": "dumb"}


def _group(name: str):
    root = get_command(app)
    return getattr(root, "commands", {}).get(name)


def test_top_level_app_help_still_works() -> None:
    """The top-level harbor CLI remains invocable and `--help` renders (exit 0).

    Holds before and after any valid change; fails only if the app is broken
    (e.g. an import error introduced while adding the new commands).
    """
    result = CliRunner().invoke(app, ["--help"], env=_WIDE_ENV)
    assert result.exit_code == 0, (
        "`harbor --help` must exit 0 so existing usage keeps working; "
        f"got exit {result.exit_code}.\n{result.output}"
    )


def test_package_subcommand_groups_remain_registered_and_help() -> None:
    """Both package subcommand groups stay registered and render `--help`.

    The feature extends these groups; it must not drop or break either. True
    before and after any valid change.
    """
    for name in PACKAGE_GROUPS:
        group = _group(name)
        assert group is not None, (
            f"The '{name}' subcommand group must remain registered on the "
            "harbor CLI app."
        )
        result = CliRunner().invoke(app, [name, "--help"], env=_WIDE_ENV)
        assert result.exit_code == 0, (
            f"`harbor {name} --help` must exit 0 so existing usage keeps "
            f"working; got exit {result.exit_code}.\n{result.output}"
        )


def test_package_groups_keep_preexisting_commands() -> None:
    """Each package group still exposes its pre-existing commands.

    Existing invocations call these, so they must survive the change (true
    before any change, and after any valid fix that only ADDS the new commands).
    """
    for name, expected in PREEXISTING_GROUP_COMMANDS.items():
        group = _group(name)
        assert group is not None, f"The '{name}' subcommand group must exist."
        registered = set(getattr(group, "commands", {}))
        missing = [c for c in expected if c not in registered]
        assert not missing, (
            f"Pre-existing '{name}' commands must still be registered (existing "
            f"usage depends on them); missing: {missing}. Present: "
            f"{sorted(registered)}."
        )
