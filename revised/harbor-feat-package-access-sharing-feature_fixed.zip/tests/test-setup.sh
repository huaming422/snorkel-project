#!/usr/bin/env bash
# Container setup for verifiers. Sourced (not exec'd) so exported
# PATH/VIRTUAL_ENV persist into the verifier process, which runs under
# harbor's uv-managed venv (editable harbor + full dep tree + pytest from the
# `dev` group). The image pre-ran `uv sync --frozen` with a warm uv cache, so
# this is a fast, offline no-op on a normal trial.
set -u

REPO=/repo/harbor
cd "$REPO" || { echo "test-setup: $REPO missing" >&2; return 1 2>/dev/null || exit 1; }

export PATH="/usr/local/bin:$PATH"        # task uv (symlinked from /usr/local/uv-task)
export UV_CACHE_DIR=/opt/uv-cache         # warm cache baked at image build
export UV_OFFLINE=1                        # the build-time cache is enough offline; resolve against it first

# Rebuild/verify the venv from the warm cache. --frozen pins to uv.lock; the
# `dev` group (pytest, pytest-asyncio) installs by default. Offline first; if
# the verifier phase has network (it may, via the gateway allowlist) fall back
# to an online sync so a missing verifier-only dep can still be fetched.
uv sync --frozen 2>&1 | tail -3 || { unset UV_OFFLINE; uv sync 2>&1 | tail -3; }

# Make harbor's venv interpreter the default python/python3/pytest the verifier
# invokes, so `import harbor...` resolves to the editable repo install with all
# its deps available.
if [ -d "$REPO/.venv" ]; then
    export VIRTUAL_ENV="$REPO/.venv"
    export PATH="$REPO/.venv/bin:$PATH"
fi

# Sanity: the pre-existing modules the feature extends must import cleanly before
# any verifier runs. (The package access modules exist only after the change
# is applied, so they are intentionally NOT imported here; the
# verifiers import the new surface at run time.)
python -c "import harbor.cli.main; import harbor.cli.tasks; import harbor.cli.datasets; import harbor.db.client; import harbor.cli.download; import harbor.cli.versions" \
    && echo "test-setup: harbor importable" \
    || echo "test-setup: WARNING harbor import failed" >&2
