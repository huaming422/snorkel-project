"""Small shared helpers for the package-access story scripts.

Plain utilities only. Command names, flags and RegistryDB method names still
come from reading the change; every helper takes them as arguments.

Usage in a story script:

    import sys
    sys.path.insert(0, "/tests/validate")
    import test_harness as th

    HANDLERS = th.case_handlers("share_batch_lifecycle", {
        "dedup_preview_no_writes": dedup_preview_no_writes,
        ...one entry per case name the story lists...
    })

    def test_share_batch_lifecycle(inputs, expected, monkeypatch):
        th.run_case(HANDLERS, inputs, expected, monkeypatch)
"""

from __future__ import annotations

import tomllib
from pathlib import Path
from types import ModuleType, SimpleNamespace
from typing import Any, Callable, Iterable
from unittest.mock import AsyncMock, MagicMock

SPEC_PATH = Path(__file__).with_name("validation_spec.toml")

# Wide, plain terminal so rich output is not wrapped or colored.
CLI_ENV = {"COLUMNS": "1000", "TERM": "dumb"}

SKIP = "__skip__"


# ---------------------------------------------------------------------------
# Case coverage
# ---------------------------------------------------------------------------


def story_case_names(story_id: str) -> set[str]:
    """Every expected["case"] name the spec lists for one story."""
    spec = tomllib.loads(SPEC_PATH.read_text())
    for story in spec.get("story", []):
        if story.get("id") == story_id:
            cases = story.get("test_case", [])
            if isinstance(cases, dict):
                cases = [cases]
            return {case["expected"]["case"] for case in cases}
    raise RuntimeError(f"no story with id {story_id!r} in {SPEC_PATH}")


def case_handlers(story_id: str, handlers: dict[str, Callable[..., Any]]) -> dict:
    """Check, at import time, that a script handles every case of its story.

    A script that forgets a later case would otherwise only show up when that
    case runs. This raises as soon as the script is imported if any listed
    case has no handler, or if a handler name matches no listed case.
    """
    wanted = story_case_names(story_id)
    missing = sorted(wanted - set(handlers))
    unknown = sorted(set(handlers) - wanted)
    if missing or unknown:
        raise RuntimeError(
            f"{story_id}: script case handlers do not match the story's cases; "
            f"missing={missing} unknown={unknown}"
        )
    return handlers


def run_case(handlers: dict[str, Callable[..., Any]], inputs: dict, expected: dict, *args: Any) -> Any:
    """Call the handler named by expected["case"] with (inputs, expected, *args)."""
    name = expected["case"]
    if name not in handlers:
        raise RuntimeError(f"no handler for case {name!r}")
    return handlers[name](inputs, expected, *args)


def is_skip(value: Any) -> bool:
    return value == SKIP


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def invoke(app: Any, args: Iterable[str], **kwargs: Any) -> Any:
    """Run a Typer app in-process with the wide terminal env."""
    from typer.testing import CliRunner

    env = {**CLI_ENV, **kwargs.pop("env", {})}
    return CliRunner().invoke(app, [str(a) for a in args], env=env, **kwargs)


def command_names(app: Any) -> set[str]:
    """Names of the commands (and subgroups) registered directly on a Typer app."""
    from typer.main import get_command

    return set(getattr(get_command(app), "commands", {}) or {})


def command_options(app: Any, *path: str) -> set[str]:
    """Option strings of the command reached by `path` (one name per level)."""
    from typer.main import get_command

    cmd = get_command(app)
    for name in path:
        cmd = cmd.commands[name]
    return {opt for param in cmd.params for opt in getattr(param, "opts", [])}


# ---------------------------------------------------------------------------
# Registry mocks
# ---------------------------------------------------------------------------


def registry_db_mock(
    monkeypatch: Any,
    method_names: Iterable[str],
    also_patch: Iterable[str | ModuleType] = (),
) -> MagicMock:
    """Patch RegistryDB with a MagicMock whose named methods are AsyncMock.

    Each name must be a real method of the pre-existing RegistryDB class, so a
    command that calls a method the class does not have fails here. Besides
    `harbor.db.client.RegistryDB`, the class is also replaced in every module
    in `also_patch` that imported it by name.
    """
    import importlib

    import harbor.db.client as db_client

    names = list(method_names)
    missing = [n for n in names if not hasattr(db_client.RegistryDB, n)]
    assert not missing, f"RegistryDB has no method(s) {missing}"

    db = MagicMock()
    for name in names:
        setattr(db, name, AsyncMock())
    factory = MagicMock(return_value=db)
    monkeypatch.setattr(db_client, "RegistryDB", factory)
    for mod in also_patch:
        mod = importlib.import_module(mod) if isinstance(mod, str) else mod
        if hasattr(mod, "RegistryDB"):
            monkeypatch.setattr(mod, "RegistryDB", factory)
    return db


def await_total(db: Any, method_names: Iterable[str]) -> int:
    """Summed await_count over the named mocked methods."""
    return sum(getattr(db, name).await_count for name in method_names)


def write_call_count(
    db: Any,
    update_methods: Iterable[str] = (),
    no_write_kwarg: str | None = None,
    write_methods: Iterable[str] = (),
) -> int:
    """Count the calls that really change access.

    A call to one of `update_methods` counts when its `no_write_kwarg` keyword
    is missing or falsy; every call to one of `write_methods` counts.
    """
    count = 0
    for name in update_methods:
        for call in getattr(db, name).await_args_list:
            if not (no_write_kwarg and call.kwargs.get(no_write_kwarg)):
                count += 1
    for name in write_methods:
        count += getattr(db, name).await_count
    return count


class FakeQuery:
    """Chainable stand-in for a postgrest query; `execute()` returns the rows."""

    def __init__(self, data: Any):
        self._data = data

    def __getattr__(self, _name: str) -> Callable[..., "FakeQuery"]:
        return lambda *a, **k: self

    async def execute(self) -> SimpleNamespace:
        return SimpleNamespace(data=self._data)


class FakeClient:
    """Backend client whose table and rpc queries answer by name.

    A table with no entry answers no rows; an rpc with no entry answers None.
    """

    def __init__(self, tables: dict[str, Any], rpcs: dict[str, Any] | None = None):
        self._tables = tables
        self._rpcs = rpcs or {}

    def table(self, name: str) -> FakeQuery:
        return FakeQuery(self._tables.get(name, []))

    def rpc(self, name: str = "", *_a: Any, **_k: Any) -> FakeQuery:
        return FakeQuery(self._rpcs.get(name))


def fake_backend(
    monkeypatch: Any, tables: dict[str, Any], rpcs: dict[str, Any] | None = None
) -> FakeClient:
    """Replace only the authenticated backend client under RegistryDB."""
    client = FakeClient(tables, rpcs)
    monkeypatch.setattr(
        "harbor.db.client.create_authenticated_client",
        AsyncMock(return_value=client),
    )
    return client
