## Task

Owners who publish task or dataset packages to the registry can't see from the CLI who is able to use them, and can't give another organization access or take it away.
Add commands to both `harbor task` and `harbor dataset` for inspecting a package's access and for sharing or unsharing it with other organizations.
Datasets that reference tasks the user can't fully reach should fail cleanly instead of producing partial or misleading results.
The confirmation shown before publishing a dataset as public should also be accurate: only the dataset and the tasks owned by the dataset's own organization become public, and access to other organizations' tasks stays as it is.

## User stories / requirements

- Inspecting a task or dataset package shows who has access and whether the viewer may manage it.
  For a viewer who can't manage it, the sensitive provenance is left out entirely, and empty grant lists are dropped from machine-readable output.
  Malformed invocations, such as a bare name, a reference pinned to a version with `@`, or an unknown extra argument, are rejected without contacting the registry.
  An inaccessible package is denied without revealing whether it exists.
- Sharing or unsharing takes one or more target organizations, drops case-insensitive duplicates while keeping the original order, and rejects the whole command if any target is empty.
  A preview asks the registry what each target's change would do and writes nothing.
  An apply previews every target first, so a preview failure on any target means nothing is written, then writes the grants and reports a result per target.
  If a write fails partway, the report names which targets completed, which one has an unknown outcome, and which were not attempted.
- If a share or unshare isn't confirmed up front and isn't running in an interactive terminal, the command shows the preview once and stops without applying anything.
  With explicit confirmation it applies the change.
  Preview mode never prompts.
- When any task a dataset references is unavailable to the user, downloading the dataset, running a job on it, or adding it to a local dataset.toml with `harbor add` stops with an error saying how many tasks are out of reach.
  Nothing is left behind: no output directory, no job directory, and no change to the manifest.
  A dataset that resolves to no tasks at all is refused the same way.
- Listing a dataset version's tasks marks each one as available or unavailable to the current user.
  An unavailable task shows only an opaque identifier, with no name, organization, digest, or other detail.
