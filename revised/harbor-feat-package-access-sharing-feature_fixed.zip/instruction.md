## Task

Package owners can publish tasks and datasets to the registry, but the CLI gives them no way to check who can use a package, or to open it up to another organization and close it off again.
Add commands under both `harbor task` and `harbor dataset` that show a package's access and that share it with, or unshare it from, other organizations.
While you're in there, datasets that point at tasks the user can't fully reach need to stop with a clear error, so nobody ends up with a half-finished download or job.
The prompt shown before a public dataset publish also overstates what becomes public, so fix its wording too.

## User stories / requirements

- The access view for a task or dataset package lists the organizations that can use it and says if the current user is allowed to manage it.
  Someone without manage rights gets no provenance fields at all, not even empty ones, and a grant list with nothing in it is left out of the JSON output.
  A bare name, a reference with an `@version` on the end, or a stray extra argument is a bad invocation and fails before any registry call.
  When the user can't reach a package, the error looks the same whether the package is missing or forbidden.
- Share and unshare take one or more organizations as targets.
  Targets that differ only in letter case count once, in the order they first appeared, and a single blank target makes the whole command fail.
  In preview mode the command asks the registry what would change for each target, and writes nothing.
  When applying, every target is previewed before the first write, so a failed preview for any target means no grant is written at all.
  After that the grants are written, and each target gets its own result.
  If one write fails midway, the output lists the targets that finished, the one whose outcome is unknown, and the ones never tried.
- Without up-front confirmation, and outside an interactive terminal, share and unshare print the preview a single time and exit without changing anything.
  Passing the confirmation goes ahead with the change.
  A preview run never asks for input.
- If even one task referenced by a dataset is out of the user's reach, downloading that dataset, running a job against it, or adding it to a local dataset.toml with `harbor add` ends with an error giving the number of unreachable tasks.
  Nothing lands on disk in that case: no output directory, no job directory, and the manifest stays as it was.
  A dataset with zero tasks gets the same refusal.
- The task listing for a dataset version flags every task as reachable or not for the current user.
  For a task that isn't reachable, the only thing shown is an opaque id, with no name, organization, digest or anything else about it.
- Before a dataset is published as public, the confirmation prompt tells the user that the change covers the dataset and the referenced tasks owned by the dataset's own organization, and that tasks owned by other organizations keep their current access.
  It must not say or suggest that every task in the dataset becomes public.
