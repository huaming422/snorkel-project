// `spill_pool::channel` may carry a deprecation note in some versions of the
// crate while keeping the same signature and return types. Allow the lint so
// this file builds against either form without naming any newer entry point.
#![allow(deprecated)]

//! Behavioral checks for the spill pool in `datafusion-physical-plan`.
//!
//! The checks go through the public spill-pool constructor, which hands back a
//! cloneable producer handle plus a consumer stream. This integration test
//! links against the crate from outside, so only its public API is visible.
//!
//! Interface used (same signatures however the pool is implemented inside):
//!   * `spill_pool::channel(max_file_size, spill_manager)` -> (producer, stream)
//!   * producer `Clone`
//!   * producer `push_batch(&RecordBatch) -> Result<()>`
//!   * consumer stream `.next().await` yielding `Option<Result<RecordBatch>>`
//!
//! No internal type is imported, so the pool is free to track files and
//! handles however it likes. The checks only look at whether the consumer
//! terminates and what it receives.
//!
//! Each drain runs under `tokio::time::timeout`. A consumer that never reaches
//! end-of-stream would otherwise block the whole `cargo test` process until the
//! outer runner budget. With the bound, a drain that does not finish in time is
//! reported as a normal assertion failure. The bound is well below the
//! runner's `[rust] timeout`.

use std::io::Write;
use std::pin::Pin;
use std::sync::Arc;
use std::time::Duration;

use arrow::array::{ArrayRef, Int32Array};
use arrow::datatypes::{DataType, Field, Schema};
use arrow::record_batch::RecordBatch;
use bytes::Bytes;
use datafusion_execution::disk_manager::{DiskManagerBuilder, DiskManagerMode};
use datafusion_execution::runtime_env::{RuntimeEnv, RuntimeEnvBuilder};
use datafusion_execution::{SpillFile, SpillWriter, TempFileFactory};
use datafusion_physical_plan::metrics::{ExecutionPlanMetricsSet, SpillMetrics};
use datafusion_physical_plan::spill::spill_pool::channel;
use datafusion_physical_plan::SpillManager;
use futures::{Stream, StreamExt};

/// Single-column Int32 schema, mirroring the pool's own test helpers.
fn test_schema() -> Arc<Schema> {
    Arc::new(Schema::new(vec![Field::new("a", DataType::Int32, false)]))
}

/// Build a spill manager over the single-column schema, the same construction
/// the crate's own in-module tests use, expressed through public types only.
fn new_spill_manager() -> Arc<SpillManager> {
    let env = Arc::new(RuntimeEnv::default());
    let metrics = SpillMetrics::new(&ExecutionPlanMetricsSet::new(), 0);
    let schema = test_schema();
    Arc::new(SpillManager::new(env, metrics, schema))
}

/// An in-memory spill backend, expressed through the execution crate's public
/// `SpillFile` / `SpillWriter` / `TempFileFactory` traits. The pool writes
/// batches into a `Vec<u8>` instead of a real temp file, so a test can control
/// file creation precisely without touching the disk. Byte-level fidelity does
/// not matter here: these tests assert on termination and on which batches
/// arrive at the public boundary, not on the raw bytes.
#[derive(Default)]
struct MemSpillFile {
    bytes: Arc<std::sync::Mutex<Vec<u8>>>,
}

impl SpillFile for MemSpillFile {
    fn size(&self) -> Option<u64> {
        Some(self.bytes.lock().unwrap().len() as u64)
    }

    fn read_stream(&self) -> datafusion_common::Result<Pin<Box<dyn Stream<Item = datafusion_common::Result<Bytes>> + Send>>> {
        let bytes = Bytes::from(self.bytes.lock().unwrap().clone());
        Ok(Box::pin(futures::stream::once(async move { Ok(bytes) })))
    }

    fn open_writer(&self) -> datafusion_common::Result<Box<dyn SpillWriter>> {
        Ok(Box::new(MemSpillWriter {
            bytes: Arc::clone(&self.bytes),
        }))
    }
}

struct MemSpillWriter {
    bytes: Arc<std::sync::Mutex<Vec<u8>>>,
}

impl Write for MemSpillWriter {
    fn write(&mut self, buf: &[u8]) -> std::io::Result<usize> {
        self.bytes.lock().unwrap().extend_from_slice(buf);
        Ok(buf.len())
    }
    fn flush(&mut self) -> std::io::Result<()> {
        Ok(())
    }
}

impl SpillWriter for MemSpillWriter {
    fn finish(&mut self) -> datafusion_common::Result<()> {
        Ok(())
    }
}

/// A temp-file factory that *measures* how many producers are inside spill-file
/// creation at the same time, without ever blocking indefinitely.
///
/// On each creation it bumps an in-flight counter, records the running maximum,
/// then waits (for at most `window`) for the in-flight count to reach `want`.
/// If `want` producers overlap it returns immediately; otherwise it gives up
/// after the window and returns anyway, so no producer is ever stuck here. The
/// high-water mark in `max_inflight` is the result: a pool that lets producers
/// create files concurrently reaches `want`, while a pool that admits one
/// producer at a time into the write path tops out at 1.
struct OverlapProbeFactory {
    inflight: std::sync::atomic::AtomicUsize,
    max_inflight: std::sync::atomic::AtomicUsize,
    want: usize,
    window: Duration,
}

impl OverlapProbeFactory {
    fn new(want: usize, window: Duration) -> Self {
        Self {
            inflight: std::sync::atomic::AtomicUsize::new(0),
            max_inflight: std::sync::atomic::AtomicUsize::new(0),
            want,
            window,
        }
    }

    fn observed_max(&self) -> usize {
        self.max_inflight.load(std::sync::atomic::Ordering::SeqCst)
    }
}

impl TempFileFactory for OverlapProbeFactory {
    fn create_temp_file(&self, _description: &str) -> datafusion_common::Result<Arc<dyn SpillFile>> {
        use std::sync::atomic::Ordering::SeqCst;
        let now = self.inflight.fetch_add(1, SeqCst) + 1;
        self.max_inflight.fetch_max(now, SeqCst);

        // Bounded wait for another creator to overlap with us. This holds the
        // first creator inside the factory long enough for a concurrent creator
        // to arrive; if none arrives, it times out and the high-water mark
        // stays at 1.
        let deadline = std::time::Instant::now() + self.window;
        while self.inflight.load(SeqCst) < self.want && std::time::Instant::now() < deadline {
            std::thread::sleep(Duration::from_millis(5));
        }
        self.max_inflight.fetch_max(self.inflight.load(SeqCst), SeqCst);

        self.inflight.fetch_sub(1, SeqCst);
        Ok(Arc::new(MemSpillFile::default()))
    }
}

/// Build a spill manager whose disk backend is the supplied factory, so a test
/// can intercept and coordinate file creation. Uses only public builder APIs.
fn spill_manager_with_factory(factory: Arc<dyn TempFileFactory>) -> Arc<SpillManager> {
    let env = RuntimeEnvBuilder::new()
        .with_disk_manager_builder(
            DiskManagerBuilder::default().with_mode(DiskManagerMode::Custom(factory)),
        )
        .build_arc()
        .expect("runtime env builds");
    let metrics = SpillMetrics::new(&ExecutionPlanMetricsSet::new(), 0);
    Arc::new(SpillManager::new(env, metrics, test_schema()))
}

/// A `count`-row batch whose first value is `start`; `start` doubles as a
/// stable identity for the batch so the consumer can confirm nothing is lost.
fn make_batch(start: i32, count: i32) -> RecordBatch {
    let schema = test_schema();
    let a: ArrayRef = Arc::new(Int32Array::from((start..start + count).collect::<Vec<_>>()));
    RecordBatch::try_new(schema, vec![a]).unwrap()
}

/// First value of a batch's single Int32 column, used as the batch's identity.
fn batch_identity(batch: &RecordBatch) -> i32 {
    batch
        .column(0)
        .as_any()
        .downcast_ref::<Int32Array>()
        .expect("column 0 is Int32")
        .value(0)
}

// Large enough that a tiny Int32 batch never triggers size-based file
// rotation, so write files stay open across concurrent pushes and are only
// closed when the producers drop.
const MAX_FILE_SIZE: usize = 1024 * 1024;
const ROWS_PER_BATCH: i32 = 10;

/// A pool driven by many concurrent producer handles drains every pushed batch
/// to the single consumer and then reaches end-of-stream once all producers
/// have dropped.
///
/// Scenario: clone the producer into many concurrent tasks on a multi-thread
/// runtime, each pushing many small batches; drain the consumer under an
/// in-test time bound; assert the drain completed (bound did not elapse) and
/// that the consumer observed exactly the full set of pushed batches. Repeated
/// over several rounds because the interleaving of producers varies from run
/// to run.
#[tokio::test(flavor = "multi_thread", worker_threads = 8)]
async fn concurrent_writers_drain_without_stall() {
    const WRITERS: i32 = 16;
    const BATCHES_PER_WRITER: i32 = 16;
    const ROUNDS: usize = 3;
    const PER_ROUND_BOUND: Duration = Duration::from_secs(20);

    let total: i32 = WRITERS * BATCHES_PER_WRITER;

    for round in 0..ROUNDS {
        let (writer, mut reader) = channel(MAX_FILE_SIZE, new_spill_manager());

        // Fan the producer out across concurrent tasks.
        let mut producer_tasks = Vec::with_capacity(WRITERS as usize);
        for w in 0..WRITERS {
            let writer = writer.clone();
            producer_tasks.push(tokio::spawn(async move {
                for b in 0..BATCHES_PER_WRITER {
                    // Distinct identity per batch across all producers:
                    // (w * BATCHES_PER_WRITER + b) in 0..total, scaled so the
                    // first column value encodes it.
                    let id = w * BATCHES_PER_WRITER + b;
                    let batch = make_batch(id * ROWS_PER_BATCH, ROWS_PER_BATCH);
                    writer.push_batch(&batch).expect("push_batch failed");
                }
            }));
        }
        // Drop the original handle; EOF for the consumer must be driven by the
        // last live producer dropping, which happens as the tasks finish.
        drop(writer);

        // Drain the consumer under a hard time bound. The consumer must see
        // every batch and then end-of-stream well inside it.
        let drained = tokio::time::timeout(PER_ROUND_BOUND, async move {
            let mut identities = Vec::with_capacity(total as usize);
            while let Some(item) = reader.next().await {
                let batch = item.expect("reader yielded an error");
                assert_eq!(
                    batch.num_rows() as i32,
                    ROWS_PER_BATCH,
                    "round {round}: each delivered batch keeps its row count",
                );
                identities.push(batch_identity(&batch) / ROWS_PER_BATCH);
            }
            identities
        })
        .await;

        // Producers never hang (only the consumer can), so joining them is
        // safe regardless of the drain outcome.
        for task in producer_tasks {
            task.await.expect("a producer task panicked");
        }

        let mut identities = drained.unwrap_or_else(|_| {
            panic!(
                "round {round}: consumer did not reach end-of-stream within {:?} \
                 after all {WRITERS} concurrent producers finished and dropped",
                PER_ROUND_BOUND
            )
        });

        // Completeness: every pushed batch arrived exactly once (order across
        // concurrent producers is not guaranteed, so compare as a sorted set).
        identities.sort_unstable();
        let expected: Vec<i32> = (0..total).collect();
        assert_eq!(
            identities, expected,
            "round {round}: consumer must receive every pushed batch exactly once \
             with nothing dropped or duplicated",
        );
    }
}

/// More than one producer can be inside the write path at the same time;
/// producers are not made to take turns.
///
/// Draining every batch eventually is not enough on its own: a pool that runs
/// all producers through one lock held across the entire write path (file
/// creation, append and rotation) also drains everything, one producer at a
/// time. This case checks that producers can work concurrently.
///
/// Mechanism, observed only at the public boundary: install a spill backend
/// that records the high-water mark of how many producers are simultaneously
/// inside spill-file creation, waiting a bounded moment for overlap but never
/// blocking indefinitely. Launch two producer handles, each pushing one batch
/// into the empty pool so each must create its first write file, then fully
/// drain the consumer so nothing is left outstanding. Two producers that work
/// concurrently are both seen in flight at once (observed max == 2); a pool
/// that admits only one active producer at a time only ever shows one.
///
/// It pins no data structure and imports nothing beyond the public API. The
/// probe never blocks forever, so the result is always a normal pass or
/// assertion failure, not a stuck process.
#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn concurrent_writers_make_progress_in_parallel() {
    const BOUND: Duration = Duration::from_secs(20);
    // Bounded per-creation overlap window: long enough for a concurrent
    // creator to show up, short enough that a one-at-a-time pool just times
    // out cheaply. Two creators, so the target overlap is 2.
    let probe = Arc::new(OverlapProbeFactory::new(2, Duration::from_secs(5)));
    let factory: Arc<dyn TempFileFactory> = probe.clone();
    let (writer, mut reader) = channel(MAX_FILE_SIZE, spill_manager_with_factory(factory));
    let writer2 = writer.clone();

    // Each producer pushes a single distinct batch; each triggers its own
    // first-file creation, which is where the overlap is measured. Blocking
    // tasks because the write path and the probe both use std sync.
    let p1 = tokio::task::spawn_blocking({
        let w = writer.clone();
        move || w.push_batch(&make_batch(0, ROWS_PER_BATCH))
    });
    let p2 = tokio::task::spawn_blocking(move || {
        writer2.push_batch(&make_batch(ROWS_PER_BATCH, ROWS_PER_BATCH))
    });
    // Drop the original handle; the two task-owned handles drive EOF on finish.
    drop(writer);

    // Fully drain the consumer and join the producers under a bound. The probe
    // never blocks forever, so both pushes always return. (Exact delivered-set
    // completeness under ordinary timing is asserted by the sibling tests;
    // this case perturbs file-creation timing to probe concurrency, so it only
    // requires termination here, not a specific delivered set.)
    tokio::time::timeout(BOUND, async move {
        while let Some(item) = reader.next().await {
            item.expect("reader yielded an error");
        }
        p1.await.expect("producer 1 task panicked").expect("push_batch 1 failed");
        p2.await.expect("producer 2 task panicked").expect("push_batch 2 failed");
    })
    .await
    .expect("two-producer pool did not drain within the bound");

    // Both producers were inside spill-file creation at the same time. A pool
    // that lets only one producer into the write path at a time leaves the
    // first creator alone for the whole overlap window and records 1.
    let observed = probe.observed_max();
    assert_eq!(
        observed, 2,
        "expected two producers to be in the spill-pool write path concurrently, \
         but at most {observed} was ever in flight",
    );
}

/// A single-producer pool delivers every batch to the consumer in strict FIFO
/// (write) order, with none lost.
#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn single_writer_preserves_fifo() {
    const N: i32 = 25;
    const BOUND: Duration = Duration::from_secs(20);

    let (writer, mut reader) = channel(MAX_FILE_SIZE, new_spill_manager());

    // Push batches with strictly increasing identity.
    for i in 0..N {
        writer
            .push_batch(&make_batch(i * ROWS_PER_BATCH, ROWS_PER_BATCH))
            .expect("push_batch failed");
    }
    drop(writer);

    let order = tokio::time::timeout(BOUND, async move {
        let mut seen = Vec::with_capacity(N as usize);
        while let Some(item) = reader.next().await {
            let batch = item.expect("reader yielded an error");
            seen.push(batch_identity(&batch) / ROWS_PER_BATCH);
        }
        seen
    })
    .await
    .expect("single-producer drain must not hang");

    let expected: Vec<i32> = (0..N).collect();
    assert_eq!(
        order, expected,
        "a single-producer pool must deliver batches in the exact order written, \
         with none lost",
    );
}

/// The consumer must not observe end-of-stream while any producer handle is
/// still alive. Create a handle and a clone, drop one, and confirm the
/// consumer does NOT see EOF while the surviving handle is alive; once the
/// surviving handle writes and drops, the consumer sees its data and only then
/// reaches EOF.
#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn clone_drop_does_not_signal_eof_prematurely() {
    let (writer1, mut reader) = channel(MAX_FILE_SIZE, new_spill_manager());
    let writer2 = writer1.clone();

    // writer2 waits for a signal before writing its single batch, then drops.
    let (proceed_tx, proceed_rx) = tokio::sync::oneshot::channel::<()>();
    let writer2_task = tokio::spawn(async move {
        proceed_rx.await.unwrap();
        writer2
            .push_batch(&make_batch(10 * ROWS_PER_BATCH, ROWS_PER_BATCH))
            .expect("push_batch failed");
        // writer2 dropped here: this is the last live handle, so EOF follows.
    });

    // writer1 writes one batch then drops (NOT the last handle).
    writer1
        .push_batch(&make_batch(0, ROWS_PER_BATCH))
        .expect("push_batch failed");
    drop(writer1);

    // Consume writer1's batch.
    let batch1 = reader
        .next()
        .await
        .expect("expected writer1's batch")
        .expect("reader yielded an error");
    assert_eq!(batch_identity(&batch1), 0);

    // Release writer2.
    proceed_tx.send(()).unwrap();

    // The consumer must wait for writer2's data, not report EOF, because a
    // producer handle is still alive. Bounded so a consumer that never returns
    // fails rather than blocking the process.
    let batch2 = tokio::time::timeout(Duration::from_secs(10), reader.next())
        .await
        .expect("reader timed out waiting for a live producer's batch");
    let batch2 = batch2
        .expect("consumer must not reach EOF while a producer handle is alive")
        .expect("reader yielded an error");
    assert_eq!(batch_identity(&batch2), 10 * ROWS_PER_BATCH);

    writer2_task.await.expect("writer2 task panicked");

    // All handles dropped and all data consumed: now EOF is expected.
    let eof = tokio::time::timeout(Duration::from_secs(10), reader.next())
        .await
        .expect("reader timed out at end-of-stream");
    assert!(
        eof.is_none(),
        "consumer must reach EOF once all producer handles have dropped",
    );
}
