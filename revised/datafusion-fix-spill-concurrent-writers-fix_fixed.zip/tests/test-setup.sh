#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier (set -euo pipefail inherited).
# This is a native-Rust task: the verifier injects an integration test under
# datafusion/physical-plan/tests/ and runs `cargo test --test <name>`. The image
# already baked the full dependency closure at the base commit
# (`cargo fetch --locked` + `cargo test --no-run -p datafusion-physical-plan`),
# so grading must resolve everything from the warmed registry/git cache and
# never reach a network. There are no services to start and no data to seed.
cd /repo/datafusion

# Cut the network for cargo so a cache miss fails fast here instead of silently
# reaching crates.io during the offline smoke fold.
export CARGO_NET_OFFLINE=true

# Dependencies: offline-first against the image bake, logged online fallback.
# `--locked` keeps Cargo.lock authoritative so no resolution drift sneaks in.
if cargo fetch --locked --offline > /tmp/test-setup-fetch.log 2>&1; then
    echo "[offline-first] cargo deps satisfied from image bake"
elif cargo fetch --locked >> /tmp/test-setup-fetch.log 2>&1; then
    echo "[test-setup] cargo deps fetched online (image bake was stale)"
else
    tail -40 /tmp/test-setup-fetch.log >&2; exit 1
fi
