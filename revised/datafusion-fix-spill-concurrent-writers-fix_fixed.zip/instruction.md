## Task

Some of our bigger queries hang once they run short on memory and start spilling to disk.
They don't error out, they just stop making progress and sit there until someone cancels them.
It isn't consistent, since the same query over the same data usually finishes and only some runs get stuck.
We see it more on machines with more cores and when the memory limit is set low.

Can you figure out why and fix it so these queries always finish?
Results still need to be correct, complete and in the same order as before wherever order is kept today.
The public APIs need to stay as they are, since other code depends on them.
