## Task

Some of our queries hang forever once they run low on memory and start spilling to disk.
The one we keep hitting is a sort-merge join that feeds an aggregate, run with a high target partition count and a tight memory limit.
One partition finishes, then the query just sits there and never completes until we cancel it.
Nothing is printed, no error comes back, and the process goes idle while it waits.
With a single partition the same query over the same data always completes.
It is also intermittent, since most runs with many partitions finish fine and only some get stuck.
More partitions and a lower memory limit make it happen a lot more often, so it looks like a timing problem when many tasks spill at once.

Please find out why these queries hang and fix it so they always finish.

- Every row still has to come back, with nothing dropped or duplicated.
- Plans that keep rows in order today still need to return them in the same order.
- Several tasks must still be able to spill at the same time, including opening new spill files, so making them take turns is not an acceptable fix.
- Keep the existing public APIs working, because other code builds against them.
