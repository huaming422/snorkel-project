## Task

Some of our queries hang forever once they run low on memory and start spilling to disk.
The one we keep hitting is a sort-merge join feeding an aggregate, with a high target partition count and a tight memory limit.
One partition finishes, then the query just sits there with no error until we cancel it.
With a single partition the same query over the same data always completes.
It's intermittent too, since most runs with many partitions finish fine and only some get stuck.
More partitions and a lower memory limit make it show up a lot more often.

Need to track down why these hang and get them finishing every time.
Every row still has to come back exactly once, and plans that return rows in order today should keep doing that.
The existing public APIs also need to keep working, since other code builds against them.
