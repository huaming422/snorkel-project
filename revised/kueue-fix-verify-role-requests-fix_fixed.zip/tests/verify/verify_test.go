// Copyright 2026 The Kueue Authors.
// SPDX-License-Identifier: Apache-2.0

// Internal-package (pod) behavioral test for the pod-group ungating path.
//
// Every assertion goes through the existing entry point
// (*Pod).Run(ctx, c, wl, podSetsInfo, recorder, msg). Each test seeds an
// admitted Workload and a group of gated Pods, calls Run, then reads back
// only externally visible state: the persisted scheduling gate of each Pod
// (re-read from the client), the type of each recorded event (Normal vs
// Warning), and the returned error.
//
// Each Workload carries the admission a ClusterQueue would have given it,
// so the reservation can be read from the PodSet templates or from the
// admitted resource usage. The Warning event's reason and message are not
// read, and no helper or opt-in toggle is named, so any code shape that
// produces the same gate state, event types and error at the Run boundary
// works.
//
// Being in package pod lets the harness set the unexported group fields
// (isGroup, list) and call the unexported isGated helper to read persisted
// gate state the same way production code does.
package pod

import (
	"errors"
	"testing"

	corev1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/api/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/utils/ptr"
	"sigs.k8s.io/controller-runtime/pkg/client"

	kueue "sigs.k8s.io/kueue/apis/kueue/v1beta2"
	vrindexer "sigs.k8s.io/kueue/pkg/controller/core/indexer"
	"sigs.k8s.io/kueue/pkg/podset"
	utiltesting "sigs.k8s.io/kueue/pkg/util/testing"
	utiltestingapi "sigs.k8s.io/kueue/pkg/util/testing/v1beta2"
	testingpod "sigs.k8s.io/kueue/pkg/util/testingjobs/pod"
)

const (
	vrRoleA = "role-a"
	vrRoleB = "role-b"
)

// vrRunInfo returns one PodSetInfo per PodSet of the Workload, the way the
// admitted Workload hands them to Run.
func vrRunInfo(wl *kueue.Workload) []podset.PodSetInfo {
	infos := make([]podset.PodSetInfo, 0, len(wl.Spec.PodSets))
	for i := range wl.Spec.PodSets {
		infos = append(infos, podset.PodSetInfo{Name: wl.Spec.PodSets[i].Name})
	}
	return infos
}

// vrGatedPod builds a gated group Pod annotated with the given role requesting the given cpu.
func vrGatedPod(name, role, cpu string) corev1.Pod {
	return *testingpod.MakePod(name, metav1.NamespaceDefault).
		Image("", nil).
		Request(corev1.ResourceCPU, cpu).
		RoleHash(role).
		KueueSchedulingGate().
		Obj()
}

// vrGatedCPUMemoryPod builds a gated role-a Pod requesting cpu and memory.
func vrGatedCPUMemoryPod(name, cpu, memory string) corev1.Pod {
	return *testingpod.MakePod(name, metav1.NamespaceDefault).
		Image("", nil).
		Request(corev1.ResourceCPU, cpu).
		Request(corev1.ResourceMemory, memory).
		RoleHash(vrRoleA).
		KueueSchedulingGate().
		Obj()
}

// vrGatedGPUPod requests cpu plus a resource the role reserves none of.
func vrGatedGPUPod(name string) corev1.Pod {
	return *testingpod.MakePod(name, metav1.NamespaceDefault).
		Image("", nil).
		Request(corev1.ResourceCPU, "1").
		Request(corev1.ResourceName("nvidia.com/gpu"), "1").
		RoleHash(vrRoleA).
		KueueSchedulingGate().
		Obj()
}

// vrGatedLimitsPod sets an equal request+limit, for a role whose template carries only limits.
func vrGatedLimitsPod(name, cpu string) corev1.Pod {
	return *testingpod.MakePod(name, metav1.NamespaceDefault).
		Image("", nil).
		RequestAndLimit(corev1.ResourceCPU, cpu).
		RoleHash(vrRoleA).
		KueueSchedulingGate().
		Obj()
}

// vrGatedRuntimeClassPod carries RuntimeClass overhead so its effective request exceeds its bare request.
func vrGatedRuntimeClassPod(name, cpu string) corev1.Pod {
	p := vrGatedPod(name, vrRoleA, cpu)
	p.Spec.RuntimeClassName = ptr.To("kata")
	p.Spec.Overhead = corev1.ResourceList{corev1.ResourceCPU: resource.MustParse("500m")}
	return p
}

// vrGatedInitPod adds an init container with the given cpu request next to a 1-cpu main container.
func vrGatedInitPod(name, cpu string) corev1.Pod {
	p := testingpod.MakePod(name, metav1.NamespaceDefault).
		Image("", nil).
		Request(corev1.ResourceCPU, "1").
		RoleHash(vrRoleA).
		KueueSchedulingGate().
		Obj()
	p.Spec.InitContainers = []corev1.Container{{
		Name:  "init",
		Image: p.Spec.Containers[0].Image,
		Resources: corev1.ResourceRequirements{
			Requests: corev1.ResourceList{corev1.ResourceCPU: resource.MustParse(cpu)},
		},
	}}
	return *p
}

// vrGatedSidecarPod adds a restartable init (sidecar) container with the given cpu request next to a 1-cpu main container.
func vrGatedSidecarPod(name, cpu string) corev1.Pod {
	p := testingpod.MakePod(name, metav1.NamespaceDefault).
		Image("", nil).
		Request(corev1.ResourceCPU, "1").
		RoleHash(vrRoleA).
		KueueSchedulingGate().
		Obj()
	always := corev1.ContainerRestartPolicyAlways
	p.Spec.InitContainers = []corev1.Container{{
		Name:          "sidecar",
		Image:         p.Spec.Containers[0].Image,
		RestartPolicy: &always,
		Resources: corev1.ResourceRequirements{
			Requests: corev1.ResourceList{corev1.ResourceCPU: resource.MustParse(cpu)},
		},
	}}
	return *p
}

// vrGatedPodLevelPod puts the given cpu request at the pod level.
func vrGatedPodLevelPod(name, cpu string) corev1.Pod {
	p := testingpod.MakePod(name, metav1.NamespaceDefault).
		Image("", nil).
		Request(corev1.ResourceCPU, "1").
		RoleHash(vrRoleA).
		KueueSchedulingGate().
		Obj()
	p.Spec.Resources = &corev1.ResourceRequirements{
		Requests: corev1.ResourceList{corev1.ResourceCPU: resource.MustParse(cpu)},
	}
	return *p
}

// vrAdmitted gives wl the admission a ClusterQueue records for it: one
// assignment per PodSet with its count and, per resource, the count times
// the per-Pod amount quota was charged for that PodSet.
func vrAdmitted(wl *kueue.Workload, perPod map[kueue.PodSetReference]corev1.ResourceList) *kueue.Workload {
	assignments := make([]kueue.PodSetAssignment, 0, len(wl.Spec.PodSets))
	for i := range wl.Spec.PodSets {
		ps := &wl.Spec.PodSets[i]
		psa := utiltestingapi.MakePodSetAssignment(ps.Name).Count(ps.Count).Obj()
		for name, q := range perPod[ps.Name] {
			total := q.DeepCopy()
			total.Mul(int64(ps.Count))
			psa.ResourceUsage[name] = total
		}
		assignments = append(assignments, psa)
	}
	wl.Status.Admission = utiltestingapi.MakeAdmission("cq").PodSets(assignments...).Obj()
	return wl
}

func vrCPU(cpu string) corev1.ResourceList {
	return corev1.ResourceList{corev1.ResourceCPU: resource.MustParse(cpu)}
}

func vrWorkloadRequest(cpu string) *kueue.Workload {
	return vrAdmitted(utiltestingapi.MakeWorkload("wl", metav1.NamespaceDefault).
		PodSets(*utiltestingapi.MakePodSet(kueue.NewPodSetReference(vrRoleA), 2).
			Request(corev1.ResourceCPU, cpu).
			Obj()).
		Obj(), map[kueue.PodSetReference]corev1.ResourceList{vrRoleA: vrCPU(cpu)})
}

func vrWorkloadCPUMemory(cpu, memory string) *kueue.Workload {
	return vrAdmitted(utiltestingapi.MakeWorkload("wl", metav1.NamespaceDefault).
		PodSets(*utiltestingapi.MakePodSet(kueue.NewPodSetReference(vrRoleA), 2).
			Request(corev1.ResourceCPU, cpu).
			Request(corev1.ResourceMemory, memory).
			Obj()).
		Obj(), map[kueue.PodSetReference]corev1.ResourceList{vrRoleA: {
		corev1.ResourceCPU:    resource.MustParse(cpu),
		corev1.ResourceMemory: resource.MustParse(memory),
	}})
}

// vrWorkloadTwoRoles has a small role-a (1 cpu) and a large role-b (4 cpu).
func vrWorkloadTwoRoles() *kueue.Workload {
	return vrAdmitted(utiltestingapi.MakeWorkload("wl", metav1.NamespaceDefault).
		PodSets(
			*utiltestingapi.MakePodSet(kueue.NewPodSetReference(vrRoleA), 2).
				Request(corev1.ResourceCPU, "1").
				Obj(),
			*utiltestingapi.MakePodSet(kueue.NewPodSetReference(vrRoleB), 1).
				Request(corev1.ResourceCPU, "4").
				Obj(),
		).
		Obj(), map[kueue.PodSetReference]corev1.ResourceList{vrRoleA: vrCPU("1"), vrRoleB: vrCPU("4")})
}

// vrWorkloadRole wraps one role-a PodSet that quota charged perPod for each Pod.
func vrWorkloadRole(ps *utiltestingapi.PodSetWrapper, perPod corev1.ResourceList) *kueue.Workload {
	return vrAdmitted(utiltestingapi.MakeWorkload("wl", metav1.NamespaceDefault).
		PodSets(*ps.Obj()).
		Obj(), map[kueue.PodSetReference]corev1.ResourceList{vrRoleA: perPod})
}

func vrRolePodSet(cpu string) *utiltestingapi.PodSetWrapper {
	return utiltestingapi.MakePodSet(kueue.NewPodSetReference(vrRoleA), 2).Request(corev1.ResourceCPU, cpu)
}

// vrWorkloadLimit sets only a cpu limit on the role; quota charges the limit.
func vrWorkloadLimit(cpu string) *kueue.Workload {
	return vrAdmitted(utiltestingapi.MakeWorkload("wl", metav1.NamespaceDefault).
		PodSets(*utiltestingapi.MakePodSet(kueue.NewPodSetReference(vrRoleA), 2).
			Limit(corev1.ResourceCPU, cpu).
			Obj()).
		Obj(), map[kueue.PodSetReference]corev1.ResourceList{vrRoleA: vrCPU(cpu)})
}

// vrWorkloadNoRequests sets nothing on the role; quota charged the
// namespace LimitRange default request, given as defaultCPU.
func vrWorkloadNoRequests(defaultCPU string) *kueue.Workload {
	return vrAdmitted(utiltestingapi.MakeWorkload("wl", metav1.NamespaceDefault).
		PodSets(*utiltestingapi.MakePodSet(kueue.NewPodSetReference(vrRoleA), 2).Obj()).
		Obj(), map[kueue.PodSetReference]corev1.ResourceList{vrRoleA: vrCPU(defaultCPU)})
}

// vrWorkloadRuntimeClass requests 1 cpu under the kata RuntimeClass; quota
// charged the request plus the class's 500m overhead.
func vrWorkloadRuntimeClass() *kueue.Workload {
	return vrAdmitted(utiltestingapi.MakeWorkload("wl", metav1.NamespaceDefault).
		PodSets(*utiltestingapi.MakePodSet(kueue.NewPodSetReference(vrRoleA), 2).
			Request(corev1.ResourceCPU, "1").
			RuntimeClass("kata").
			Obj()).
		Obj(), map[kueue.PodSetReference]corev1.ResourceList{vrRoleA: vrCPU("1500m")})
}

// vrOutcome captures only externally-observable state after a Run:
// the persisted scheduling-gate of each Pod (keyed by name), per-Pod event
// type counts, and the returned error.
type vrOutcome struct {
	err      error
	gated    map[string]bool
	warnings map[string]int
	normals  map[string]int
}

// vrRun drives (*Pod).Run on p and re-reads the persisted state of pods.
// initObjects seeds cluster objects the reservation depends on (LimitRange,
// RuntimeClass); pass none when the role already carries explicit requests.
func vrRun(t *testing.T, p *Pod, wl *kueue.Workload, infos []podset.PodSetInfo, pods []corev1.Pod, initObjects ...client.Object) vrOutcome {
	t.Helper()

	ctx, _ := utiltesting.ContextWithLog(t)
	clientBuilder := utiltesting.NewClientBuilder()
	if err := SetupIndexes(ctx, utiltesting.AsIndexer(clientBuilder)); err != nil {
		t.Fatalf("could not setup indexes: %v", err)
	}
	kClient := clientBuilder.
		WithIndex(&corev1.LimitRange{}, vrindexer.LimitRangeHasContainerOrPodType, vrindexer.IndexLimitRangeHasContainerOrPodType).
		WithObjects(initObjects...).
		WithLists(&corev1.PodList{Items: pods}).
		Build()
	recorder := &utiltesting.EventRecorder{}

	out := vrOutcome{
		gated:    map[string]bool{},
		warnings: map[string]int{},
		normals:  map[string]int{},
	}
	out.err = p.Run(ctx, kClient, wl, infos, recorder, "")

	for i := range pods {
		got := &corev1.Pod{}
		if err := kClient.Get(ctx, client.ObjectKeyFromObject(&pods[i]), got); err != nil {
			t.Fatalf("get pod %q after Run: %v", pods[i].Name, err)
		}
		out.gated[pods[i].Name] = isGated(got)
	}
	for _, ev := range recorder.RecordedEvents {
		switch ev.EventType {
		case corev1.EventTypeWarning:
			out.warnings[ev.Key.Name]++
		case corev1.EventTypeNormal:
			out.normals[ev.Key.Name]++
		}
	}
	return out
}

// vrRunGroup runs pods as one group admitted with wl.
func vrRunGroup(t *testing.T, wl *kueue.Workload, pods []corev1.Pod, initObjects ...client.Object) vrOutcome {
	t.Helper()
	p := FromObject(&pods[0])
	p.isGroup = true
	p.list.Items = pods
	return vrRun(t, p, wl, vrRunInfo(wl), pods, initObjects...)
}

func vrAssertGated(t *testing.T, out vrOutcome, name string, want bool) {
	t.Helper()
	if got, ok := out.gated[name]; !ok {
		t.Errorf("pod %q not found after Run", name)
	} else if got != want {
		t.Errorf("pod %q still gated = %v, want %v", name, got, want)
	}
}

func vrAssertWarned(t *testing.T, out vrOutcome, name string) {
	t.Helper()
	if out.warnings[name] == 0 {
		t.Errorf("pod %q: want a Warning-type event, got none", name)
	}
}

func vrAssertNoWarning(t *testing.T, out vrOutcome, name string) {
	t.Helper()
	if out.warnings[name] != 0 {
		t.Errorf("pod %q: want no Warning-type event, got %d", name, out.warnings[name])
	}
}

// vrAssertHeld checks a Pod kept back for not fitting its role: still
// gated, warned, and with no Normal (Started) event.
func vrAssertHeld(t *testing.T, out vrOutcome, name string) {
	t.Helper()
	vrAssertGated(t, out, name, true)
	vrAssertWarned(t, out, name)
	if out.normals[name] != 0 {
		t.Errorf("pod %q kept gated: want no Normal-type event, got %d", name, out.normals[name])
	}
}

func vrAssertStarted(t *testing.T, out vrOutcome, name string) {
	t.Helper()
	if out.normals[name] == 0 {
		t.Errorf("pod %q: want a Normal-type event for the ungated pod, got none", name)
	}
}

func vrAssertNoError(t *testing.T, out vrOutcome) {
	t.Helper()
	if out.err != nil {
		t.Fatalf("Run returned error, want nil: %v", out.err)
	}
}

// TestVerifyOversizedPodKeptGated: a Pod whose role-hash annotation names a
// PodSet it does not fit stays gated and gets a Warning event instead of a
// Started event, while the Pods that fit their role are ungated normally.
// Run returns no error and the oversized Pod is still present afterwards
// (vrRun fails the test on a missing Pod).
func TestVerifyOversizedPodKeptGated(t *testing.T) {
	t.Run("forged_hash_requesting_more_cpu_keeps_only_that_pod_gated", func(t *testing.T) {
		out := vrRunGroup(t,
			vrWorkloadRequest("1"),
			[]corev1.Pod{vrGatedPod("p1", vrRoleA, "1"), vrGatedPod("p2", vrRoleA, "2")},
		)
		vrAssertNoError(t, out)
		vrAssertGated(t, out, "p1", false)
		vrAssertNoWarning(t, out, "p1")
		vrAssertStarted(t, out, "p1")
		vrAssertHeld(t, out, "p2")
	})

	// role-a reserves 1 cpu and role-b reserves 4. "forged" names role-a but
	// requests 2 cpu, which role-b could hold; it is judged against role-a.
	// "worker" requests 2 cpu under role-b, below that role's reservation.
	t.Run("pod_naming_the_small_role_is_judged_against_that_role", func(t *testing.T) {
		out := vrRunGroup(t,
			vrWorkloadTwoRoles(),
			[]corev1.Pod{
				vrGatedPod("lead", vrRoleA, "1"),
				vrGatedPod("forged", vrRoleA, "2"),
				vrGatedPod("worker", vrRoleB, "2"),
			},
		)
		vrAssertNoError(t, out)
		vrAssertGated(t, out, "lead", false)
		vrAssertNoWarning(t, out, "lead")
		vrAssertGated(t, out, "worker", false)
		vrAssertNoWarning(t, out, "worker")
		vrAssertStarted(t, out, "worker")
		vrAssertHeld(t, out, "forged")
	})

	t.Run("pod_requesting_more_memory_is_kept_gated", func(t *testing.T) {
		out := vrRunGroup(t,
			vrWorkloadCPUMemory("1", "1Gi"),
			[]corev1.Pod{vrGatedCPUMemoryPod("p1", "1", "1Gi"), vrGatedCPUMemoryPod("p2", "1", "2Gi")},
		)
		vrAssertNoError(t, out)
		vrAssertGated(t, out, "p1", false)
		vrAssertNoWarning(t, out, "p1")
		vrAssertHeld(t, out, "p2")
	})

	t.Run("pod_requesting_an_unreserved_resource_is_kept_gated", func(t *testing.T) {
		out := vrRunGroup(t,
			vrWorkloadRequest("1"),
			[]corev1.Pod{vrGatedGPUPod("p1")},
		)
		vrAssertNoError(t, out)
		vrAssertHeld(t, out, "p1")
	})
}

// TestVerifyEffectiveReservation: fit is measured against the role's
// reservation as quota counts it (limits fill in missing requests per
// resource, LimitRange default requests fill in the rest, RuntimeClass
// overhead added, and the role's own init, sidecar and pod-level requests
// counted) and against the Pod's own request as Kubernetes computes it
// (init containers by maximum, sidecars added to the main containers,
// pod-level requests, overhead).
func TestVerifyEffectiveReservation(t *testing.T) {
	t.Run("limits_only_role_fitting_pod_is_ungated", func(t *testing.T) {
		out := vrRunGroup(t, vrWorkloadLimit("1"), []corev1.Pod{vrGatedLimitsPod("p1", "1")})
		vrAssertNoError(t, out)
		vrAssertGated(t, out, "p1", false)
		vrAssertNoWarning(t, out, "p1")
	})

	t.Run("limits_only_role_oversized_pod_is_kept_gated", func(t *testing.T) {
		out := vrRunGroup(t, vrWorkloadLimit("1"), []corev1.Pod{vrGatedLimitsPod("p1", "2")})
		vrAssertNoError(t, out)
		vrAssertHeld(t, out, "p1")
	})

	// A memory limit fills in the missing memory request even though the
	// role already sets a cpu request.
	t.Run("limit_fills_a_missing_request_next_to_a_set_one", func(t *testing.T) {
		wl := vrWorkloadRole(vrRolePodSet("1").Limit(corev1.ResourceMemory, "1Gi"),
			corev1.ResourceList{corev1.ResourceCPU: resource.MustParse("1"), corev1.ResourceMemory: resource.MustParse("1Gi")})
		out := vrRunGroup(t, wl, []corev1.Pod{vrGatedCPUMemoryPod("p1", "1", "1Gi")})
		vrAssertNoError(t, out)
		vrAssertGated(t, out, "p1", false)
		vrAssertNoWarning(t, out, "p1")
	})

	t.Run("limitrange_default_request_fitting_pod_is_ungated", func(t *testing.T) {
		lr := utiltesting.MakeLimitRange("defaults", metav1.NamespaceDefault).
			WithValue("DefaultRequest", corev1.ResourceCPU, "1").
			Obj()
		out := vrRunGroup(t, vrWorkloadNoRequests("1"), []corev1.Pod{vrGatedPod("p1", vrRoleA, "1")}, lr)
		vrAssertNoError(t, out)
		vrAssertGated(t, out, "p1", false)
		vrAssertNoWarning(t, out, "p1")
	})

	t.Run("limitrange_default_request_oversized_pod_is_kept_gated", func(t *testing.T) {
		lr := utiltesting.MakeLimitRange("defaults", metav1.NamespaceDefault).
			WithValue("DefaultRequest", corev1.ResourceCPU, "1").
			Obj()
		out := vrRunGroup(t, vrWorkloadNoRequests("1"), []corev1.Pod{vrGatedPod("p1", vrRoleA, "2")}, lr)
		vrAssertNoError(t, out)
		vrAssertHeld(t, out, "p1")
	})

	// The LimitRange default memory request fills in the missing memory
	// request even though the role already sets a cpu request.
	t.Run("limitrange_fills_a_missing_request_next_to_a_set_one", func(t *testing.T) {
		lr := utiltesting.MakeLimitRange("defaults", metav1.NamespaceDefault).
			WithValue("DefaultRequest", corev1.ResourceMemory, "1Gi").
			Obj()
		wl := vrWorkloadRole(vrRolePodSet("1"),
			corev1.ResourceList{corev1.ResourceCPU: resource.MustParse("1"), corev1.ResourceMemory: resource.MustParse("1Gi")})
		out := vrRunGroup(t, wl, []corev1.Pod{vrGatedCPUMemoryPod("p1", "1", "1Gi")}, lr)
		vrAssertNoError(t, out)
		vrAssertGated(t, out, "p1", false)
		vrAssertNoWarning(t, out, "p1")
	})

	t.Run("runtimeclass_overhead_fitting_pod_is_ungated", func(t *testing.T) {
		rc := utiltesting.MakeRuntimeClass("kata", "kata").
			PodOverhead(corev1.ResourceList{corev1.ResourceCPU: resource.MustParse("500m")}).
			Obj()
		out := vrRunGroup(t, vrWorkloadRuntimeClass(), []corev1.Pod{vrGatedRuntimeClassPod("p1", "1")}, rc)
		vrAssertNoError(t, out)
		vrAssertGated(t, out, "p1", false)
		vrAssertNoWarning(t, out, "p1")
	})

	t.Run("runtimeclass_overhead_oversized_pod_is_kept_gated", func(t *testing.T) {
		rc := utiltesting.MakeRuntimeClass("kata", "kata").
			PodOverhead(corev1.ResourceList{corev1.ResourceCPU: resource.MustParse("500m")}).
			Obj()
		out := vrRunGroup(t, vrWorkloadRuntimeClass(), []corev1.Pod{vrGatedRuntimeClassPod("p1", "2")}, rc)
		vrAssertNoError(t, out)
		vrAssertHeld(t, out, "p1")
	})

	// The Pod's own overhead counts even when its role has no RuntimeClass:
	// 1 cpu plus 500m overhead needs 1.5 cpu, more than the 1 cpu role.
	t.Run("pod_overhead_counts_against_a_role_without_one", func(t *testing.T) {
		out := vrRunGroup(t, vrWorkloadRequest("1"), []corev1.Pod{vrGatedRuntimeClassPod("p1", "1")})
		vrAssertNoError(t, out)
		vrAssertHeld(t, out, "p1")
	})

	// An init container runs before the main container, so 1 cpu of init
	// next to 1 cpu of main needs 1 cpu in total.
	t.Run("init_container_within_reservation_is_ungated", func(t *testing.T) {
		out := vrRunGroup(t, vrWorkloadRequest("1"), []corev1.Pod{vrGatedInitPod("p1", "1")})
		vrAssertNoError(t, out)
		vrAssertGated(t, out, "p1", false)
		vrAssertNoWarning(t, out, "p1")
	})

	// The role itself has a 2 cpu init container, so it reserves 2 cpu.
	t.Run("role_with_init_container_reserves_it", func(t *testing.T) {
		wl := vrWorkloadRole(vrRolePodSet("1").InitContainers(corev1.Container{
			Name:      "init",
			Resources: corev1.ResourceRequirements{Requests: vrCPU("2")},
		}), vrCPU("2"))
		out := vrRunGroup(t, wl, []corev1.Pod{vrGatedInitPod("p1", "2")})
		vrAssertNoError(t, out)
		vrAssertGated(t, out, "p1", false)
		vrAssertNoWarning(t, out, "p1")
	})

	t.Run("init_container_request_above_reservation_keeps_pod_gated", func(t *testing.T) {
		out := vrRunGroup(t, vrWorkloadRequest("1"), []corev1.Pod{vrGatedInitPod("p1", "2")})
		vrAssertNoError(t, out)
		vrAssertHeld(t, out, "p1")
	})

	// A sidecar runs next to the main container, so 1 cpu of sidecar plus
	// 1 cpu of main needs 2 cpu: that fits a 2 cpu role but not a 1 cpu role.
	t.Run("sidecar_and_main_within_reservation_is_ungated", func(t *testing.T) {
		out := vrRunGroup(t, vrWorkloadRequest("2"), []corev1.Pod{vrGatedSidecarPod("p1", "1")})
		vrAssertNoError(t, out)
		vrAssertGated(t, out, "p1", false)
		vrAssertNoWarning(t, out, "p1")
	})

	// The role itself runs a 1 cpu sidecar next to its 1 cpu main container,
	// so it reserves 2 cpu.
	t.Run("role_with_sidecar_reserves_main_plus_sidecar", func(t *testing.T) {
		always := corev1.ContainerRestartPolicyAlways
		wl := vrWorkloadRole(vrRolePodSet("1").InitContainers(corev1.Container{
			Name:          "sidecar",
			RestartPolicy: &always,
			Resources:     corev1.ResourceRequirements{Requests: vrCPU("1")},
		}), vrCPU("2"))
		out := vrRunGroup(t, wl, []corev1.Pod{vrGatedSidecarPod("p1", "1")})
		vrAssertNoError(t, out)
		vrAssertGated(t, out, "p1", false)
		vrAssertNoWarning(t, out, "p1")
	})

	t.Run("sidecar_request_adds_to_main_container", func(t *testing.T) {
		out := vrRunGroup(t, vrWorkloadRequest("1"), []corev1.Pod{vrGatedSidecarPod("p1", "1")})
		vrAssertNoError(t, out)
		vrAssertHeld(t, out, "p1")
	})

	t.Run("sidecar_request_above_reservation_keeps_pod_gated", func(t *testing.T) {
		out := vrRunGroup(t, vrWorkloadRequest("1"), []corev1.Pod{vrGatedSidecarPod("p1", "2")})
		vrAssertNoError(t, out)
		vrAssertHeld(t, out, "p1")
	})

	// A pod-level request replaces the sum of the containers, so a 2 cpu
	// pod-level request over a 1 cpu container needs 2 cpu, not 3.
	t.Run("pod_level_request_within_reservation_is_ungated", func(t *testing.T) {
		out := vrRunGroup(t, vrWorkloadRequest("2"), []corev1.Pod{vrGatedPodLevelPod("p1", "2")})
		vrAssertNoError(t, out)
		vrAssertGated(t, out, "p1", false)
		vrAssertNoWarning(t, out, "p1")
	})

	// The role itself carries a 2 cpu pod-level request over a 1 cpu
	// container, so it reserves 2 cpu.
	t.Run("role_with_pod_level_request_reserves_it", func(t *testing.T) {
		wl := vrWorkloadRole(vrRolePodSet("1").PodLevelRequest(corev1.ResourceCPU, "2"), vrCPU("2"))
		out := vrRunGroup(t, wl, []corev1.Pod{vrGatedPodLevelPod("p1", "2")})
		vrAssertNoError(t, out)
		vrAssertGated(t, out, "p1", false)
		vrAssertNoWarning(t, out, "p1")
	})

	t.Run("pod_level_request_above_reservation_keeps_pod_gated", func(t *testing.T) {
		out := vrRunGroup(t, vrWorkloadRequest("1"), []corev1.Pod{vrGatedPodLevelPod("p1", "2")})
		vrAssertNoError(t, out)
		vrAssertHeld(t, out, "p1")
	})
}

// TestVerifyHonestGroupUngated: groups whose Pods all fit their roles are
// ungated with Normal events and no warnings, and single Pods outside a
// group keep their existing behavior.
func TestVerifyHonestGroupUngated(t *testing.T) {
	t.Run("every_pod_fitting_its_role_is_ungated_with_no_warnings", func(t *testing.T) {
		out := vrRunGroup(t,
			vrWorkloadRequest("1"),
			[]corev1.Pod{vrGatedPod("p1", vrRoleA, "1"), vrGatedPod("p2", vrRoleA, "1")},
		)
		vrAssertNoError(t, out)
		for _, name := range []string{"p1", "p2"} {
			vrAssertGated(t, out, name, false)
			vrAssertNoWarning(t, out, name)
			vrAssertStarted(t, out, name)
		}
	})

	t.Run("two_roles_each_pod_at_its_own_reservation_is_ungated", func(t *testing.T) {
		out := vrRunGroup(t,
			vrWorkloadTwoRoles(),
			[]corev1.Pod{vrGatedPod("lead", vrRoleA, "1"), vrGatedPod("worker", vrRoleB, "4")},
		)
		vrAssertNoError(t, out)
		for _, name := range []string{"lead", "worker"} {
			vrAssertGated(t, out, name, false)
			vrAssertNoWarning(t, out, name)
			vrAssertStarted(t, out, name)
		}
	})

	// A single Pod outside a group is ungated as before, even when it asks
	// for more than its Workload's PodSet lists.
	t.Run("single_pod_outside_a_group_is_ungated_as_before", func(t *testing.T) {
		pods := []corev1.Pod{*testingpod.MakePod("solo", metav1.NamespaceDefault).
			Image("", nil).
			Request(corev1.ResourceCPU, "2").
			KueueSchedulingGate().
			Obj()}
		wl := vrAdmitted(utiltestingapi.MakeWorkload("wl", metav1.NamespaceDefault).
			PodSets(*utiltestingapi.MakePodSet(kueue.DefaultPodSetName, 1).
				Request(corev1.ResourceCPU, "1").
				Obj()).
			Obj(), map[kueue.PodSetReference]corev1.ResourceList{kueue.DefaultPodSetName: vrCPU("1")})
		out := vrRun(t, FromObject(&pods[0]), wl, vrRunInfo(wl), pods)
		vrAssertNoError(t, out)
		vrAssertGated(t, out, "solo", false)
		vrAssertNoWarning(t, out, "solo")
		vrAssertStarted(t, out, "solo")
	})

	t.Run("single_pod_rejects_multiple_podset_infos", func(t *testing.T) {
		pods := []corev1.Pod{*testingpod.MakePod("test-pod", metav1.NamespaceDefault).Obj()}
		p := FromObject(&pods[0])

		ctx, _ := utiltesting.ContextWithLog(t)
		clientBuilder := utiltesting.NewClientBuilder()
		if err := SetupIndexes(ctx, utiltesting.AsIndexer(clientBuilder)); err != nil {
			t.Fatalf("could not setup indexes: %v", err)
		}
		kClient := clientBuilder.WithLists(&corev1.PodList{Items: pods}).Build()

		gotErr := p.Run(ctx, kClient,
			utiltestingapi.MakeWorkload("wl", metav1.NamespaceDefault).Obj(),
			make([]podset.PodSetInfo, 2), &utiltesting.EventRecorder{}, "")
		if !errors.Is(gotErr, podset.ErrInvalidPodsetInfo) {
			t.Errorf("want ErrInvalidPodsetInfo for a single pod given 2 pod-set infos, got %v", gotErr)
		}
	})
}

// TestVerifyUnknownRolePermanentError: a role-hash naming a role with no
// PodSet in the Workload returns the permanent invalid-podset error and the
// Pod stays gated.
func TestVerifyUnknownRolePermanentError(t *testing.T) {
	unknown := vrGatedPod("p1", "role-unknown", "1")

	out := vrRunGroup(t, vrWorkloadRequest("1"), []corev1.Pod{unknown})

	if !errors.Is(out.err, podset.ErrInvalidPodsetInfo) {
		t.Errorf("want ErrInvalidPodsetInfo for an unknown role, got %v", out.err)
	}
	if !podset.IsPermanent(out.err) {
		t.Errorf("want a permanent error for an unknown role, got %v", out.err)
	}
	vrAssertGated(t, out, "p1", true)
}
