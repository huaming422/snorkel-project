## Task

One of our pod groups ends up using more ClusterQueue quota than its Workload reserved.
Every Pod in a group carries a `kueue.x-k8s.io/role-hash` annotation that names its role (PodSet) in the Workload, and Kueue lifts the Pod's scheduling gate once the group is admitted.
When a Pod names a small role but asks for far more than that role reserved, Kueue still lifts its gate and the Pod gets scheduled on the small role's reservation.

Please track down why that happens and fix it.

A Pod that wants more than the role it names reserved should stay gated and get a Warning event, not the `Started` event its peers get.
Going over on any single resource is enough, including one the role reserved none of, like a GPU on a CPU-only role.
It doesn't matter that some bigger role in the same Workload could have held the Pod.
The role it names is the one that counts.
The rest of the group should carry on as today, with Pods that fit getting ungated with their `Started` event and no warning.
Holding one Pod back must not fail the Workload or surface as an error from the controller.

"Fits" should mean the same thing the rest of the system means by it.
On the role's side that is what quota charged its PodSet, after the usual defaulting of the role's containers and any RuntimeClass overhead.
On the Pod's side it is what the scheduler would size the Pod at, so init and sidecar containers, pod-level requests and overhead all play their normal part.

A Pod whose annotation names a role the Workload doesn't have should keep failing with the permanent `invalid podset infos` error it gets today, and single Pods outside a group should keep ungating as they do now.
