## Task

Spreadsheet tables currently reach the Go ingestion pipeline in two shapes.
The CSV, XLSX and XLS parsers emit one record per row, with fields like `cells`, `headers`, `table_id`, `row_start`/`row_end`/`col_start`/`col_end` and a `ck_type` of `table_row` or `table_header`, and some paths also render the sheet as an HTML table.
The chunkers and the index write each read whichever shape they were written for, so the same sheet can be chunked and stored differently depending on the path.

Move the table path to one shape: a rendered `<table>` per sheet with a `positions` matrix beside it, and get rid of the per-row records.
The matrix has one tuple `[sheet, rowStart, rowEnd, colStart, colEnd]` for each rendered row, header first, in the same order as the rows in the markup.

The table chunker should read that table back row by row:

- Each data row becomes one chunk whose text has one `- <column>: <value>` line per non-empty cell, joined with `\n`, with column names from the header row.
- Empty cells are left out, and a row with no values gives no chunk.
- A table whose only row is the header stays a single chunk with its markup unchanged.
- A row chunk's `positions` holds just that row's tuple, but only when the item has a `sheet_index` and its matrix has exactly one tuple per rendered row.
- In every other case the row chunks get no positions.
- An item whose text isn't table markup, such as an old `- name: Alice` row record, passes through as one chunk, unchanged and without positions.

When chunks are written for indexing, the `positions` value turns into `page_num_int`, `top_int` and `position_int`, and the two kinds of tuple must stay apart:

- A chunk with a `sheet_index` is a spreadsheet chunk, and its tuples go into `position_int` only.
- For a spreadsheet chunk, `page_num_int` is not set and a `top_int` the chunk already has (its row index) is kept.
- Any other chunk carries PDF layout boxes `[page, left, right, top, bottom]` and fills all three fields.
- Page numbers are already 1-based by this point, so store them as they are.
- If the flattened positions array isn't a multiple of five long, drop it and write none of the three fields.

Keep the exported constructors and method signatures of the parsers and chunkers as they are, and leave non-table behavior alone.

## User stories / requirements

- Parsing a CSV, XLSX or XLS file gives one rendered table item per sheet, captioned with the sheet name (`Data` for CSV): the header row, then the data rows in file order, cell and caption text HTML-escaped. Its matrix has one tuple per rendered row, and no item keeps the old per-row fields.
- A rendered table over the general chunker's token budget is split into several chunks. Each part is a rendered table repeating the caption and header row, and its positions are the header tuple plus only its own rows' tuples. Every data row lands in exactly one part, and a table that fits stays whole.
