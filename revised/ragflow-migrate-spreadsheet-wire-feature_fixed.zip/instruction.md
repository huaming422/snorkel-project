## Task

Spreadsheet tables reach the Go ingestion pipeline in two shapes, per-row records and a rendered HTML table.
The chunkers and the index write each read whichever one they were written for, so the same sheet comes out differently depending on the path.

Move the table path to one shape: a rendered `<table>` per sheet with a `positions` matrix beside it.
Each matrix entry is a `[sheet, rowStart, rowEnd, colStart, colEnd]` tuple, one per rendered row, header first.
The per-row records go away, and with them their fields (`cells`, `headers`, `table_id`, the row and column ranges, and the `table_row`/`table_header` ck_type).
Exported constructors and method signatures stay as they are.

## User stories / requirements

- Parsing a CSV, XLSX or XLS file gives one rendered table item per sheet, captioned with the sheet name (`Data` for CSV): the header row, then the data rows in file order, cell and caption text HTML-escaped. Its matrix has one tuple per rendered row, and no item keeps the old per-row fields.
- A rendered table over the general chunker's token budget is split into several chunks. Each part is a rendered table repeating the caption and header row, and its positions are the header tuple plus only its own rows' tuples. Every data row lands in exactly one part, and a table that fits stays whole.
- The table chunker turns each data row of a rendered table into one chunk whose text is one `- <column>: <value>` line per non-empty cell, joined with newlines. A row with no values gives no chunk, a header-only table stays one unchanged chunk, and text that isn't table markup passes through unchanged.
- A row chunk from the table chunker carries only its own row's position tuple, and only when the item has a `sheet_index` and exactly one tuple per rendered row. When the tuple count doesn't match the rows, or there is no `sheet_index`, the row chunks carry no positions.
- When chunks are prepared for indexing, a chunk with a `sheet_index` writes its position tuples to `position_int` only. Its `page_num_int` stays unset, and a `top_int` it already carries is kept.
- When chunks are prepared for indexing, a chunk without a `sheet_index` holds PDF boxes `[page, left, right, top, bottom]` and gets `page_num_int`, `top_int` and `position_int`, with the page stored as given. For any chunk, positions whose flattened length isn't a multiple of five write none of those fields.
