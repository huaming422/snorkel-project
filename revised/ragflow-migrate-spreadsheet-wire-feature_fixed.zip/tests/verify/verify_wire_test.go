//
//  Copyright 2026 The InfiniFlow Authors. All Rights Reserved.
//
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

// Checks for spreadsheet tables carried as one rendered table.
//
// The table chunker is driven through NewTableChunker and Component.Invoke,
// and only out["chunks"] is read. The index-write step is driven through
// indexdoc.ProcessChunksForPipeline, and only the fields it writes
// (position_int, page_num_int, top_int) are read. No unexported helper and
// no intermediate positions encoding is named here.
package chunker

import (
	"context"
	"encoding/json"
	"reflect"
	"testing"
	"time"

	"ragflow/internal/ingestion/task/indexdoc"
)

// verifyFixedTime is a deterministic timestamp for the index-write boundary;
// ProcessChunksForPipeline only formats it into bookkeeping fields the position
// assertions never read.
func verifyFixedTime() time.Time {
	return time.Date(2026, 1, 1, 0, 0, 0, 0, time.UTC)
}

// verifyTableChunks drives the table chunker through its public constructor and
// the runtime Component contract, returning the emitted chunk maps.
func verifyTableChunks(t *testing.T, inputs map[string]any) []map[string]any {
	t.Helper()
	comp, err := NewTableChunker(nil)
	if err != nil {
		t.Fatalf("NewTableChunker: %v", err)
	}
	out, err := comp.Invoke(context.Background(), nil, inputs)
	if err != nil {
		t.Fatalf("TableChunker.Invoke: %v", err)
	}
	if e, ok := out["_ERROR"]; ok && e != nil {
		t.Fatalf("TableChunker reported input error: %v", e)
	}
	chunks, ok := out["chunks"].([]map[string]any)
	if !ok {
		t.Fatalf("out[\"chunks\"] = %T, want []map[string]any", out["chunks"])
	}
	return chunks
}

// verifyText returns a chunk's text field as a string.
func verifyText(t *testing.T, chunk map[string]any) string {
	t.Helper()
	s, ok := chunk["text"].(string)
	if !ok {
		t.Fatalf("chunk text = %T, want string (chunk=%#v)", chunk["text"], chunk)
	}
	return s
}

// verifyNoPositions asserts a chunk carries no position tuples: the key is
// absent, nil, or an empty [][]float64.
func verifyNoPositions(t *testing.T, chunk map[string]any, context string) {
	t.Helper()
	v, ok := chunk["positions"]
	if !ok || v == nil {
		return
	}
	if m, ok := v.([][]float64); ok {
		if len(m) != 0 {
			t.Fatalf("%s: chunk carries positions %v, want none", context, m)
		}
		return
	}
	t.Fatalf("%s: chunk carries positions %v (%T), want none", context, v, v)
}

// verifyOwnTuple asserts a chunk carries exactly one 5-field position tuple and
// returns it. positions on a chunker-emitted chunk decode as [][]float64.
func verifyOwnTuple(t *testing.T, chunk map[string]any, context string) []float64 {
	t.Helper()
	v, ok := chunk["positions"]
	if !ok || v == nil {
		t.Fatalf("%s: chunk carries no positions, want its own tuple", context)
	}
	m, ok := v.([][]float64)
	if !ok {
		t.Fatalf("%s: positions = %T, want [][]float64", context, v)
	}
	if len(m) != 1 {
		t.Fatalf("%s: chunk carries %d position tuples, want exactly its own one: %v", context, len(m), m)
	}
	if len(m[0]) != 5 {
		t.Fatalf("%s: position tuple has %d fields, want 5: %v", context, len(m[0]), m[0])
	}
	return m[0]
}

// ---------------------------------------------------------------------------
// Table chunker: one chunk per data row with "- column: value" lines, empty
// cells and all-empty rows left out, and a header-only table kept whole.
// ---------------------------------------------------------------------------

func TestVerifyTableChunkerExpandsRenderedTableRows(t *testing.T) {
	// A rendered table: header row, two data rows (the second has an empty
	// cell), and one all-empty data row.
	table := "<table><caption>orders</caption>\n" +
		"<tr><th>ID</th><th>Status</th></tr>\n" +
		"<tr><td>A-1</td><td>paid</td></tr>\n" +
		"<tr><td>A-2</td><td></td></tr>\n" +
		"<tr><td></td><td></td></tr>\n" +
		"</table>\n"
	chunks := verifyTableChunks(t, map[string]any{
		"name":          "orders.xlsx",
		"output_format": "json",
		"json": []map[string]any{
			{"text": table, "doc_type_kwd": "table", "ck_type": "table"},
		},
	})

	// One chunk per non-empty DATA row: the two populated rows expand, the
	// all-empty row produces nothing.
	if len(chunks) != 2 {
		t.Fatalf("got %d chunks, want one per non-empty data row (2)", len(chunks))
	}
	// Each chunk's text repeats the column names with that row's values;
	// an empty cell is omitted from the row's record.
	if got := verifyText(t, chunks[0]); got != "- ID: A-1\n- Status: paid" {
		t.Fatalf("chunk0 text = %q, want the first data row's field:value record", got)
	}
	if got := verifyText(t, chunks[1]); got != "- ID: A-2" {
		t.Fatalf("chunk1 text = %q, want the second data row with its empty cell dropped", got)
	}
}

func TestVerifyTableChunkerKeepsHeaderOnlyTableWhole(t *testing.T) {
	// A table whose only row is the header has nothing to expand: the whole
	// rendered markup stays a single chunk.
	table := "<table><caption>t</caption>\n<tr><th>A</th><th>B</th></tr>\n</table>\n"
	chunks := verifyTableChunks(t, map[string]any{
		"name":          "template.xlsx",
		"output_format": "json",
		"json": []map[string]any{
			{"text": table, "doc_type_kwd": "table", "ck_type": "table"},
		},
	})
	if len(chunks) != 1 {
		t.Fatalf("got %d chunks, want the header-only table kept whole (1)", len(chunks))
	}
	if got := verifyText(t, chunks[0]); got != table {
		t.Fatalf("header-only chunk text = %q, want the whole rendered markup", got)
	}
}

// ---------------------------------------------------------------------------
// Row positions: a row chunk carries only its own tuple, and only when the
// item has a sheet_index and one tuple per rendered row. A misaligned matrix
// or an item without sheet_index gives no positions, and plain record text
// passes through as one chunk with none.
// ---------------------------------------------------------------------------

func TestVerifyRowChunkCarriesOnlyItsOwnPositionTuple(t *testing.T) {
	// Row-aligned matrix: one 5-field tuple per rendered row (header included).
	table := "<table><caption>orders</caption>\n" +
		"<tr><th>ID</th><th>Status</th></tr>\n" +
		"<tr><td>A-1</td><td>paid</td></tr>\n" +
		"<tr><td>A-2</td><td>due</td></tr>\n" +
		"</table>\n"
	chunks := verifyTableChunks(t, map[string]any{
		"name":          "orders.xlsx",
		"output_format": "json",
		"json": []map[string]any{
			{
				"text":         table,
				"doc_type_kwd": "table",
				"ck_type":      "table",
				"sheet_index":  1,
				"positions": [][]float64{
					{1, 1, 1, 1, 2}, // header row tuple
					{1, 2, 2, 1, 2}, // first data row tuple
					{1, 3, 3, 1, 2}, // second data row tuple
				},
			},
		},
	})
	if len(chunks) != 2 {
		t.Fatalf("got %d chunks, want one per data row (2)", len(chunks))
	}
	first := verifyOwnTuple(t, chunks[0], "data row 0")
	second := verifyOwnTuple(t, chunks[1], "data row 1")
	// Each chunk holds its OWN row's tuple, not the header's and not the
	// whole matrix. The two data rows differ in their second field.
	if first[1] != 2 {
		t.Fatalf("data row 0 tuple = %v, want the row-2 coordinate (not the header's)", first)
	}
	if second[1] != 3 {
		t.Fatalf("data row 1 tuple = %v, want the row-3 coordinate", second)
	}
}

func TestVerifyMisalignedMatrixYieldsNoRowPositions(t *testing.T) {
	// One tuple for three rendered rows is not one tuple per row, so no row
	// chunk carries a tuple.
	table := "<table><tr><th>ID</th></tr><tr><td>a</td></tr><tr><td>b</td></tr></table>"
	chunks := verifyTableChunks(t, map[string]any{
		"name":          "sheet.csv",
		"output_format": "json",
		"json": []map[string]any{
			{
				"text":         table,
				"doc_type_kwd": "table",
				"ck_type":      "table",
				"sheet_index":  1,
				"positions":    [][]float64{{1, 1, 2, 1, 1}}, // one whole-table tuple, 3 rows
			},
		},
	})
	if len(chunks) != 2 {
		t.Fatalf("got %d chunks, want one per data row (2)", len(chunks))
	}
	for i, c := range chunks {
		verifyNoPositions(t, c, "misaligned matrix chunk")
		_ = i
	}
}

func TestVerifyNonSpreadsheetPayloadYieldsNoRowPositions(t *testing.T) {
	// Without sheet_index the matrix is not read as row tuples, even though
	// its count matches the rendered rows.
	table := "<table><tr><th>ID</th></tr><tr><td>a</td></tr><tr><td>b</td></tr></table>"
	chunks := verifyTableChunks(t, map[string]any{
		"name":          "document.docx",
		"output_format": "json",
		"json": []map[string]any{
			{
				"text":         table,
				"doc_type_kwd": "table",
				"ck_type":      "table",
				"positions":    [][]float64{{1, 1, 1, 1, 1}, {1, 2, 2, 1, 1}, {1, 3, 3, 1, 1}},
			},
		},
	})
	if len(chunks) != 2 {
		t.Fatalf("got %d chunks, want one per data row (2)", len(chunks))
	}
	for _, c := range chunks {
		verifyNoPositions(t, c, "non-spreadsheet chunk")
	}
}

func TestVerifyLegacyRecordPassesThroughUnchanged(t *testing.T) {
	// Plain "- field: value" record text is not table markup: it stays one
	// chunk, unchanged, with no positions.
	record := "- name: Alice\n- age: 30"
	chunks := verifyTableChunks(t, map[string]any{
		"name":          "legacy.csv",
		"output_format": "json",
		"json": []map[string]any{
			{"text": record, "doc_type_kwd": "table"},
		},
	})
	if len(chunks) != 1 {
		t.Fatalf("got %d chunks, want the legacy record passed through as one", len(chunks))
	}
	if got := verifyText(t, chunks[0]); got != record {
		t.Fatalf("legacy chunk text = %q, want it unchanged", got)
	}
	verifyNoPositions(t, chunks[0], "legacy record")
}

// ---------------------------------------------------------------------------
// Index write: a chunk with sheet_index gets position_int only and keeps its
// top_int; any other chunk gets page_num_int, top_int and position_int with
// the page number stored as given; a flattened length that is not a multiple
// of five writes none of the three.
// ---------------------------------------------------------------------------

func verifyHasKey(chunk map[string]any, key string) bool {
	v, ok := chunk[key]
	return ok && v != nil
}

// verifyFloatMatrix decodes an index field through JSON so any numeric slice
// type the writer chose compares the same way.
func verifyFloatMatrix(t *testing.T, v any) [][]float64 {
	t.Helper()
	raw, err := json.Marshal(v)
	if err != nil {
		t.Fatalf("marshal %v: %v", v, err)
	}
	var m [][]float64
	if err := json.Unmarshal(raw, &m); err != nil {
		t.Fatalf("position_int %s is not a matrix of numbers: %v", raw, err)
	}
	return m
}

// verifyFloatList decodes a flat index field through JSON.
func verifyFloatList(t *testing.T, v any) []float64 {
	t.Helper()
	raw, err := json.Marshal(v)
	if err != nil {
		t.Fatalf("marshal %v: %v", v, err)
	}
	var l []float64
	if err := json.Unmarshal(raw, &l); err != nil {
		t.Fatalf("field %s is not a list of numbers: %v", raw, err)
	}
	return l
}

func TestVerifySpreadsheetChunkStoresCellRangeFieldOnly(t *testing.T) {
	// A chunk with sheet_index and an existing top_int row index.
	chunk := map[string]any{
		"text":        "- ID: A-1\n- Status: paid",
		"sheet_index": 1,
		"top_int":     []int{41},
		"positions":   [][]float64{{1, 42, 42, 1, 3}},
	}
	if _, err := indexdoc.ProcessChunksForPipeline([]map[string]any{chunk}, "doc-1", "orders.xlsx", verifyFixedTime()); err != nil {
		t.Fatalf("ProcessChunksForPipeline: %v", err)
	}
	if !verifyHasKey(chunk, "position_int") {
		t.Fatalf("spreadsheet chunk missing position_int: %#v", chunk)
	}
	if got := verifyFloatMatrix(t, chunk["position_int"]); !reflect.DeepEqual(got, [][]float64{{1, 42, 42, 1, 3}}) {
		t.Fatalf("spreadsheet chunk position_int = %v, want [[1 42 42 1 3]]", got)
	}
	if verifyHasKey(chunk, "page_num_int") {
		t.Fatalf("spreadsheet chunk populated page_num_int %v, want it left untouched", chunk["page_num_int"])
	}
	// The existing top_int row index is kept.
	top, ok := chunk["top_int"].([]int)
	if !ok || len(top) != 1 || top[0] != 41 {
		t.Fatalf("spreadsheet chunk top_int = %v, want the row index [41] preserved", chunk["top_int"])
	}
}

func TestVerifyPDFChunkStoresAllCoordinateFields(t *testing.T) {
	// A chunk without sheet_index: page_num_int, top_int and position_int are
	// all written.
	chunk := map[string]any{
		"text":      "a paragraph",
		"positions": [][]float64{{2, 10, 20, 30, 40}},
	}
	if _, err := indexdoc.ProcessChunksForPipeline([]map[string]any{chunk}, "doc-2", "report.pdf", verifyFixedTime()); err != nil {
		t.Fatalf("ProcessChunksForPipeline: %v", err)
	}
	for _, key := range []string{"page_num_int", "top_int", "position_int"} {
		if !verifyHasKey(chunk, key) {
			t.Fatalf("PDF chunk missing %s: %#v", key, chunk)
		}
	}
	// The stored page equals the input page (already 1-based).
	page, ok := chunk["page_num_int"].([]int)
	if !ok || len(page) != 1 || page[0] != 2 {
		t.Fatalf("PDF chunk page_num_int = %v, want [2] (no double increment)", chunk["page_num_int"])
	}
	if got := verifyFloatList(t, chunk["top_int"]); !reflect.DeepEqual(got, []float64{30}) {
		t.Fatalf("PDF chunk top_int = %v, want [30] (the box's top)", got)
	}
	if got := verifyFloatMatrix(t, chunk["position_int"]); !reflect.DeepEqual(got, [][]float64{{2, 10, 20, 30, 40}}) {
		t.Fatalf("PDF chunk position_int = %v, want [[2 10 20 30 40]]", got)
	}
}

func TestVerifyMalformedPositionArrayIsDropped(t *testing.T) {
	// Three values flattened is not a multiple of five.
	chunk := map[string]any{
		"text":      "a paragraph",
		"positions": [][]float64{{1, 2, 3}},
	}
	if _, err := indexdoc.ProcessChunksForPipeline([]map[string]any{chunk}, "doc-3", "report.pdf", verifyFixedTime()); err != nil {
		t.Fatalf("ProcessChunksForPipeline: %v", err)
	}
	for _, key := range []string{"page_num_int", "top_int", "position_int"} {
		if verifyHasKey(chunk, key) {
			t.Fatalf("malformed positions produced %s = %v, want it dropped", key, chunk[key])
		}
	}
}

func TestVerifyMalformedSpreadsheetPositionsAreDropped(t *testing.T) {
	// A chunk with sheet_index and four values flattened: nothing is written
	// to position_int or page_num_int, and its own top_int stays.
	chunk := map[string]any{
		"text":        "- ID: B-7",
		"sheet_index": 2,
		"top_int":     []int{7},
		"positions":   [][]float64{{2, 8, 8, 1}},
	}
	if _, err := indexdoc.ProcessChunksForPipeline([]map[string]any{chunk}, "doc-4", "ledger.xlsx", verifyFixedTime()); err != nil {
		t.Fatalf("ProcessChunksForPipeline: %v", err)
	}
	for _, key := range []string{"position_int", "page_num_int"} {
		if verifyHasKey(chunk, key) {
			t.Fatalf("malformed spreadsheet positions produced %s = %v, want it dropped", key, chunk[key])
		}
	}
	top, ok := chunk["top_int"].([]int)
	if !ok || len(top) != 1 || top[0] != 7 {
		t.Fatalf("spreadsheet chunk top_int = %v, want the row index [7] kept", chunk["top_int"])
	}
}
