//
//  Copyright 2026 The InfiniFlow Authors. All Rights Reserved.
//
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

// Checks for spreadsheet tables carried as one rendered table.
//
// The table chunker is driven through NewTableChunker and Component.Invoke,
// and only out["chunks"] is read. The index-write step is driven through
// indexdoc.ProcessChunksForPipeline, and only the fields it writes
// (position_int, page_num_int, top_int) are read. The parsed-file cases build
// a CSV or an in-memory workbook, parse it with the CSV, XLSX and XLS parsers
// (ParseWithResult) and hand res.JSON to the table chunker or the Q&A chunker
// (NewQAChunker). No unexported helper and no intermediate positions encoding
// is named here.
package chunker

import (
	"bytes"
	"context"
	"encoding/json"
	"image"
	"image/color"
	"image/png"
	"reflect"
	"strings"
	"testing"
	"time"

	"github.com/xuri/excelize/v2"

	"ragflow/internal/ingestion/task/indexdoc"
	"ragflow/internal/parser/parser"
)

// verifyFixedTime is a deterministic timestamp for the index-write boundary;
// ProcessChunksForPipeline only formats it into bookkeeping fields the position
// assertions never read.
func verifyFixedTime() time.Time {
	return time.Date(2026, 1, 1, 0, 0, 0, 0, time.UTC)
}

// verifyTableChunks drives the table chunker through its public constructor and
// the runtime Component contract, returning the emitted chunk maps.
func verifyTableChunks(t *testing.T, inputs map[string]any) []map[string]any {
	t.Helper()
	comp, err := NewTableChunker(nil)
	if err != nil {
		t.Fatalf("NewTableChunker: %v", err)
	}
	out, err := comp.Invoke(context.Background(), nil, inputs)
	if err != nil {
		t.Fatalf("TableChunker.Invoke: %v", err)
	}
	if e, ok := out["_ERROR"]; ok && e != nil {
		t.Fatalf("TableChunker reported input error: %v", e)
	}
	chunks, ok := out["chunks"].([]map[string]any)
	if !ok {
		t.Fatalf("out[\"chunks\"] = %T, want []map[string]any", out["chunks"])
	}
	return chunks
}

// verifyText returns a chunk's text field as a string.
func verifyText(t *testing.T, chunk map[string]any) string {
	t.Helper()
	s, ok := chunk["text"].(string)
	if !ok {
		t.Fatalf("chunk text = %T, want string (chunk=%#v)", chunk["text"], chunk)
	}
	return s
}

// verifyNoPositions asserts a chunk carries no position tuples: the key is
// absent, nil, or an empty [][]float64.
func verifyNoPositions(t *testing.T, chunk map[string]any, context string) {
	t.Helper()
	v, ok := chunk["positions"]
	if !ok || v == nil {
		return
	}
	if m, ok := v.([][]float64); ok {
		if len(m) != 0 {
			t.Fatalf("%s: chunk carries positions %v, want none", context, m)
		}
		return
	}
	t.Fatalf("%s: chunk carries positions %v (%T), want none", context, v, v)
}

// verifyOwnTuple asserts a chunk carries exactly one 5-field position tuple and
// returns it. positions on a chunker-emitted chunk decode as [][]float64.
func verifyOwnTuple(t *testing.T, chunk map[string]any, context string) []float64 {
	t.Helper()
	v, ok := chunk["positions"]
	if !ok || v == nil {
		t.Fatalf("%s: chunk carries no positions, want its own tuple", context)
	}
	m, ok := v.([][]float64)
	if !ok {
		t.Fatalf("%s: positions = %T, want [][]float64", context, v)
	}
	if len(m) != 1 {
		t.Fatalf("%s: chunk carries %d position tuples, want exactly its own one: %v", context, len(m), m)
	}
	if len(m[0]) != 5 {
		t.Fatalf("%s: position tuple has %d fields, want 5: %v", context, len(m[0]), m[0])
	}
	return m[0]
}

// ---------------------------------------------------------------------------
// Table chunker: one chunk per data row with "- column: value" lines, empty
// cells and all-empty rows left out, and a header-only table kept whole.
// ---------------------------------------------------------------------------

func TestVerifyTableChunkerExpandsRenderedTableRows(t *testing.T) {
	// A rendered table: header row, two data rows (the second has an empty
	// cell), and one all-empty data row.
	table := "<table><caption>orders</caption>\n" +
		"<tr><th>ID</th><th>Status</th></tr>\n" +
		"<tr><td>A-1</td><td>paid</td></tr>\n" +
		"<tr><td>A-2</td><td></td></tr>\n" +
		"<tr><td></td><td></td></tr>\n" +
		"</table>\n"
	chunks := verifyTableChunks(t, map[string]any{
		"name":          "orders.xlsx",
		"output_format": "json",
		"json": []map[string]any{
			{"text": table, "doc_type_kwd": "table", "ck_type": "table"},
		},
	})

	// One chunk per non-empty DATA row: the two populated rows expand, the
	// all-empty row produces nothing.
	if len(chunks) != 2 {
		t.Fatalf("got %d chunks, want one per non-empty data row (2)", len(chunks))
	}
	// Each chunk's text repeats the column names with that row's values;
	// an empty cell is omitted from the row's record.
	if got := verifyText(t, chunks[0]); got != "- ID: A-1\n- Status: paid" {
		t.Fatalf("chunk0 text = %q, want the first data row's field:value record", got)
	}
	if got := verifyText(t, chunks[1]); got != "- ID: A-2" {
		t.Fatalf("chunk1 text = %q, want the second data row with its empty cell dropped", got)
	}
}

func TestVerifyTableChunkerKeepsHeaderOnlyTableWhole(t *testing.T) {
	// A table whose only row is the header has nothing to expand: the whole
	// rendered markup stays a single chunk.
	table := "<table><caption>t</caption>\n<tr><th>A</th><th>B</th></tr>\n</table>\n"
	chunks := verifyTableChunks(t, map[string]any{
		"name":          "template.xlsx",
		"output_format": "json",
		"json": []map[string]any{
			{"text": table, "doc_type_kwd": "table", "ck_type": "table"},
		},
	})
	if len(chunks) != 1 {
		t.Fatalf("got %d chunks, want the header-only table kept whole (1)", len(chunks))
	}
	if got := verifyText(t, chunks[0]); got != table {
		t.Fatalf("header-only chunk text = %q, want the whole rendered markup", got)
	}
}

// ---------------------------------------------------------------------------
// Row positions: a row chunk carries only its own tuple, and only when the
// item has a sheet_index and one tuple per rendered row. A misaligned matrix
// or an item without sheet_index gives no positions, and plain record text
// passes through as one chunk with none.
// ---------------------------------------------------------------------------

func TestVerifyRowChunkCarriesOnlyItsOwnPositionTuple(t *testing.T) {
	// Row-aligned matrix: one 5-field tuple per rendered row (header included).
	table := "<table><caption>orders</caption>\n" +
		"<tr><th>ID</th><th>Status</th></tr>\n" +
		"<tr><td>A-1</td><td>paid</td></tr>\n" +
		"<tr><td>A-2</td><td>due</td></tr>\n" +
		"</table>\n"
	chunks := verifyTableChunks(t, map[string]any{
		"name":          "orders.xlsx",
		"output_format": "json",
		"json": []map[string]any{
			{
				"text":         table,
				"doc_type_kwd": "table",
				"ck_type":      "table",
				"sheet_index":  1,
				"positions": [][]float64{
					{1, 1, 1, 1, 2}, // header row tuple
					{1, 2, 2, 1, 2}, // first data row tuple
					{1, 3, 3, 1, 2}, // second data row tuple
				},
			},
		},
	})
	if len(chunks) != 2 {
		t.Fatalf("got %d chunks, want one per data row (2)", len(chunks))
	}
	first := verifyOwnTuple(t, chunks[0], "data row 0")
	second := verifyOwnTuple(t, chunks[1], "data row 1")
	// Each chunk holds its OWN row's tuple, not the header's and not the
	// whole matrix. The two data rows differ in their second field.
	if first[1] != 2 {
		t.Fatalf("data row 0 tuple = %v, want the row-2 coordinate (not the header's)", first)
	}
	if second[1] != 3 {
		t.Fatalf("data row 1 tuple = %v, want the row-3 coordinate", second)
	}
}

func TestVerifyMisalignedMatrixYieldsNoRowPositions(t *testing.T) {
	// One tuple for three rendered rows is not one tuple per row, so no row
	// chunk carries a tuple.
	table := "<table><tr><th>ID</th></tr><tr><td>a</td></tr><tr><td>b</td></tr></table>"
	chunks := verifyTableChunks(t, map[string]any{
		"name":          "sheet.csv",
		"output_format": "json",
		"json": []map[string]any{
			{
				"text":         table,
				"doc_type_kwd": "table",
				"ck_type":      "table",
				"sheet_index":  1,
				"positions":    [][]float64{{1, 1, 2, 1, 1}}, // one whole-table tuple, 3 rows
			},
		},
	})
	if len(chunks) != 2 {
		t.Fatalf("got %d chunks, want one per data row (2)", len(chunks))
	}
	for i, c := range chunks {
		verifyNoPositions(t, c, "misaligned matrix chunk")
		_ = i
	}
}

func TestVerifyNonSpreadsheetPayloadYieldsNoRowPositions(t *testing.T) {
	// Without sheet_index the matrix is not read as row tuples, even though
	// its count matches the rendered rows.
	table := "<table><tr><th>ID</th></tr><tr><td>a</td></tr><tr><td>b</td></tr></table>"
	chunks := verifyTableChunks(t, map[string]any{
		"name":          "document.docx",
		"output_format": "json",
		"json": []map[string]any{
			{
				"text":         table,
				"doc_type_kwd": "table",
				"ck_type":      "table",
				"positions":    [][]float64{{1, 1, 1, 1, 1}, {1, 2, 2, 1, 1}, {1, 3, 3, 1, 1}},
			},
		},
	})
	if len(chunks) != 2 {
		t.Fatalf("got %d chunks, want one per data row (2)", len(chunks))
	}
	for _, c := range chunks {
		verifyNoPositions(t, c, "non-spreadsheet chunk")
	}
}

func TestVerifyLegacyRecordPassesThroughUnchanged(t *testing.T) {
	// Plain "- field: value" record text is not table markup: it stays one
	// chunk, unchanged, with no positions.
	record := "- name: Alice\n- age: 30"
	chunks := verifyTableChunks(t, map[string]any{
		"name":          "legacy.csv",
		"output_format": "json",
		"json": []map[string]any{
			{"text": record, "doc_type_kwd": "table"},
		},
	})
	if len(chunks) != 1 {
		t.Fatalf("got %d chunks, want the legacy record passed through as one", len(chunks))
	}
	if got := verifyText(t, chunks[0]); got != record {
		t.Fatalf("legacy chunk text = %q, want it unchanged", got)
	}
	verifyNoPositions(t, chunks[0], "legacy record")
}

// ---------------------------------------------------------------------------
// Index write: a chunk with sheet_index gets position_int only and keeps its
// top_int; any other chunk gets page_num_int, top_int and position_int with
// the page number stored as given; a flattened length that is not a multiple
// of five writes none of the three.
// ---------------------------------------------------------------------------

func verifyHasKey(chunk map[string]any, key string) bool {
	v, ok := chunk[key]
	return ok && v != nil
}

// verifyFloatMatrix decodes an index field through JSON so any numeric slice
// type the writer chose compares the same way.
func verifyFloatMatrix(t *testing.T, v any) [][]float64 {
	t.Helper()
	raw, err := json.Marshal(v)
	if err != nil {
		t.Fatalf("marshal %v: %v", v, err)
	}
	var m [][]float64
	if err := json.Unmarshal(raw, &m); err != nil {
		t.Fatalf("position_int %s is not a matrix of numbers: %v", raw, err)
	}
	return m
}

// verifyFloatList decodes a flat index field through JSON.
func verifyFloatList(t *testing.T, v any) []float64 {
	t.Helper()
	raw, err := json.Marshal(v)
	if err != nil {
		t.Fatalf("marshal %v: %v", v, err)
	}
	var l []float64
	if err := json.Unmarshal(raw, &l); err != nil {
		t.Fatalf("field %s is not a list of numbers: %v", raw, err)
	}
	return l
}

func TestVerifySpreadsheetChunkStoresCellRangeFieldOnly(t *testing.T) {
	// A chunk with sheet_index and an existing top_int row index.
	chunk := map[string]any{
		"text":        "- ID: A-1\n- Status: paid",
		"sheet_index": 1,
		"top_int":     []int{41},
		"positions":   [][]float64{{1, 42, 42, 1, 3}},
	}
	if _, err := indexdoc.ProcessChunksForPipeline([]map[string]any{chunk}, "doc-1", "orders.xlsx", verifyFixedTime()); err != nil {
		t.Fatalf("ProcessChunksForPipeline: %v", err)
	}
	if !verifyHasKey(chunk, "position_int") {
		t.Fatalf("spreadsheet chunk missing position_int: %#v", chunk)
	}
	if got := verifyFloatMatrix(t, chunk["position_int"]); !reflect.DeepEqual(got, [][]float64{{1, 42, 42, 1, 3}}) {
		t.Fatalf("spreadsheet chunk position_int = %v, want [[1 42 42 1 3]]", got)
	}
	if verifyHasKey(chunk, "page_num_int") {
		t.Fatalf("spreadsheet chunk populated page_num_int %v, want it left untouched", chunk["page_num_int"])
	}
	// The existing top_int row index is kept.
	top, ok := chunk["top_int"].([]int)
	if !ok || len(top) != 1 || top[0] != 41 {
		t.Fatalf("spreadsheet chunk top_int = %v, want the row index [41] preserved", chunk["top_int"])
	}
}

func TestVerifyPDFChunkStoresAllCoordinateFields(t *testing.T) {
	// A chunk without sheet_index: page_num_int, top_int and position_int are
	// all written.
	chunk := map[string]any{
		"text":      "a paragraph",
		"positions": [][]float64{{2, 10, 20, 30, 40}},
	}
	if _, err := indexdoc.ProcessChunksForPipeline([]map[string]any{chunk}, "doc-2", "report.pdf", verifyFixedTime()); err != nil {
		t.Fatalf("ProcessChunksForPipeline: %v", err)
	}
	for _, key := range []string{"page_num_int", "top_int", "position_int"} {
		if !verifyHasKey(chunk, key) {
			t.Fatalf("PDF chunk missing %s: %#v", key, chunk)
		}
	}
	// The stored page equals the input page (already 1-based).
	page, ok := chunk["page_num_int"].([]int)
	if !ok || len(page) != 1 || page[0] != 2 {
		t.Fatalf("PDF chunk page_num_int = %v, want [2] (no double increment)", chunk["page_num_int"])
	}
	if got := verifyFloatList(t, chunk["top_int"]); !reflect.DeepEqual(got, []float64{30}) {
		t.Fatalf("PDF chunk top_int = %v, want [30] (the box's top)", got)
	}
	if got := verifyFloatMatrix(t, chunk["position_int"]); !reflect.DeepEqual(got, [][]float64{{2, 10, 20, 30, 40}}) {
		t.Fatalf("PDF chunk position_int = %v, want [[2 10 20 30 40]]", got)
	}
}

func TestVerifyMalformedPositionArrayIsDropped(t *testing.T) {
	// Three values flattened is not a multiple of five.
	chunk := map[string]any{
		"text":      "a paragraph",
		"positions": [][]float64{{1, 2, 3}},
	}
	if _, err := indexdoc.ProcessChunksForPipeline([]map[string]any{chunk}, "doc-3", "report.pdf", verifyFixedTime()); err != nil {
		t.Fatalf("ProcessChunksForPipeline: %v", err)
	}
	for _, key := range []string{"page_num_int", "top_int", "position_int"} {
		if verifyHasKey(chunk, key) {
			t.Fatalf("malformed positions produced %s = %v, want it dropped", key, chunk[key])
		}
	}
}

func TestVerifyMalformedSpreadsheetPositionsAreDropped(t *testing.T) {
	// A chunk with sheet_index and four values flattened: nothing is written
	// to position_int or page_num_int, and its own top_int stays.
	chunk := map[string]any{
		"text":        "- ID: B-7",
		"sheet_index": 2,
		"top_int":     []int{7},
		"positions":   [][]float64{{2, 8, 8, 1}},
	}
	if _, err := indexdoc.ProcessChunksForPipeline([]map[string]any{chunk}, "doc-4", "ledger.xlsx", verifyFixedTime()); err != nil {
		t.Fatalf("ProcessChunksForPipeline: %v", err)
	}
	for _, key := range []string{"position_int", "page_num_int"} {
		if verifyHasKey(chunk, key) {
			t.Fatalf("malformed spreadsheet positions produced %s = %v, want it dropped", key, chunk[key])
		}
	}
	top, ok := chunk["top_int"].([]int)
	if !ok || len(top) != 1 || top[0] != 7 {
		t.Fatalf("spreadsheet chunk top_int = %v, want the row index [7] kept", chunk["top_int"])
	}
}

// ---------------------------------------------------------------------------
// Parsed spreadsheets read back by the chunkers. Each case builds a real file,
// parses it with the CSV, XLSX or XLS parser, and hands res.JSON to the table
// or Q&A chunker, so the parser's rendering and the chunker's reading have to
// agree.
// ---------------------------------------------------------------------------

// verifySheet is one worksheet: its name and its rows by sheet row number
// (row 1 first). A nil row is left blank in the workbook.
type verifySheet struct {
	name string
	rows [][]string
}

// verifyPNG returns a small valid PNG for anchoring an image in a workbook.
func verifyPNG(t *testing.T) []byte {
	t.Helper()
	img := image.NewRGBA(image.Rect(0, 0, 4, 4))
	for x := 0; x < 4; x++ {
		for y := 0; y < 4; y++ {
			img.Set(x, y, color.RGBA{R: 200, G: uint8(40 * x), B: uint8(40 * y), A: 255})
		}
	}
	var buf bytes.Buffer
	if err := png.Encode(&buf, img); err != nil {
		t.Fatalf("png encode: %v", err)
	}
	return buf.Bytes()
}

// verifyWorkbook builds an .xlsx in memory. images maps "sheet!cell" to the
// alt text of a PNG anchored at that cell.
func verifyWorkbook(t *testing.T, sheets []verifySheet, images map[string]string) []byte {
	t.Helper()
	f := excelize.NewFile()
	defer f.Close()
	for i, s := range sheets {
		if i == 0 {
			if err := f.SetSheetName("Sheet1", s.name); err != nil {
				t.Fatalf("SetSheetName: %v", err)
			}
		} else if _, err := f.NewSheet(s.name); err != nil {
			t.Fatalf("NewSheet: %v", err)
		}
		for r, row := range s.rows {
			if row == nil {
				continue
			}
			cell, err := excelize.CoordinatesToCellName(1, r+1)
			if err != nil {
				t.Fatalf("CoordinatesToCellName: %v", err)
			}
			values := make([]any, len(row))
			for j, v := range row {
				values[j] = v
			}
			if err := f.SetSheetRow(s.name, cell, &values); err != nil {
				t.Fatalf("SetSheetRow: %v", err)
			}
		}
	}
	for at, alt := range images {
		sheet, cell, _ := strings.Cut(at, "!")
		pic := &excelize.Picture{Extension: ".png", File: verifyPNG(t), Format: &excelize.GraphicOptions{AltText: alt}}
		if err := f.AddPictureFromBytes(sheet, cell, pic); err != nil {
			t.Fatalf("AddPictureFromBytes %s: %v", at, err)
		}
	}
	buf, err := f.WriteToBuffer()
	if err != nil {
		t.Fatalf("WriteToBuffer: %v", err)
	}
	return buf.Bytes()
}

// verifyParsedWorkbook parses the same workbook bytes with the XLSX and the
// XLS parser and returns both item lists, keyed by parser.
func verifyParsedWorkbook(t *testing.T, data []byte) map[string][]map[string]any {
	t.Helper()
	xlsx, err := parser.NewXLSXParser("")
	if err != nil {
		t.Fatalf("NewXLSXParser: %v", err)
	}
	xls, err := parser.NewXLSParser("")
	if err != nil {
		t.Fatalf("NewXLSParser: %v", err)
	}
	out := map[string][]map[string]any{}
	for name, res := range map[string]parser.ParseResult{
		"xlsx": xlsx.ParseWithResult(context.Background(), "book.xlsx", data),
		"xls":  xls.ParseWithResult(context.Background(), "book.xls", data),
	} {
		if res.Err != nil {
			t.Fatalf("%s parse: %v", name, res.Err)
		}
		out[name] = res.JSON
	}
	return out
}

// verifyParsedCSV parses CSV text and returns its items.
func verifyParsedCSV(t *testing.T, name, text string) []map[string]any {
	t.Helper()
	res := parser.NewCSVParser().ParseWithResult(context.Background(), name, []byte(text))
	if res.Err != nil {
		t.Fatalf("csv parse: %v", res.Err)
	}
	return res.JSON
}

// verifyMatrixOf decodes any item's positions through JSON; absent is empty.
func verifyMatrixOf(t *testing.T, item map[string]any) [][]float64 {
	t.Helper()
	raw := item["positions"]
	if raw == nil {
		return nil
	}
	b, err := json.Marshal(raw)
	if err != nil {
		t.Fatalf("marshal positions: %v", err)
	}
	var m [][]float64
	if err := json.Unmarshal(b, &m); err != nil {
		t.Fatalf("positions %s is not a matrix of numbers: %v", b, err)
	}
	return m
}

// verifyIsImage reports whether a parsed item or chunk is an image.
func verifyIsImage(item map[string]any) bool {
	if v, _ := item["doc_type_kwd"].(string); v == "image" {
		return true
	}
	if v, _ := item["ck_type"].(string); v == "image" {
		return true
	}
	return false
}

// verifyIsTable reports whether a parsed item holds a rendered table.
func verifyIsTable(item map[string]any) bool {
	s, _ := item["text"].(string)
	return strings.Contains(s, "<table")
}

type verifyRowWant struct {
	text  string
	tuple []float64
}

// verifyTableRowChunks runs the table chunker over parsed items and checks
// every chunk in order: a row chunk's exact text and its own single tuple, or
// an image chunk where want.text is "<image>".
func verifyTableRowChunks(t *testing.T, label, file string, items []map[string]any, want []verifyRowWant) {
	t.Helper()
	chunks := verifyTableChunks(t, map[string]any{"name": file, "output_format": "json", "json": items})
	if len(chunks) != len(want) {
		texts := make([]string, len(chunks))
		for i, c := range chunks {
			texts[i], _ = c["text"].(string)
		}
		t.Fatalf("%s: got %d chunks %q, want %d", label, len(chunks), texts, len(want))
	}
	for i, w := range want {
		if w.text == "<image>" {
			if !verifyIsImage(chunks[i]) {
				t.Fatalf("%s: chunk %d = %#v, want the anchored image here", label, i, chunks[i]["text"])
			}
			continue
		}
		if got := verifyText(t, chunks[i]); got != w.text {
			t.Fatalf("%s: chunk %d text = %q, want %q", label, i, got, w.text)
		}
		if got := verifyMatrixOf(t, chunks[i]); !reflect.DeepEqual(got, [][]float64{w.tuple}) {
			t.Fatalf("%s: chunk %d positions = %v, want only its own tuple %v", label, i, got, w.tuple)
		}
	}
}

func TestVerifyParsedSheetKeepsSourceRowNumbers(t *testing.T) {
	// Sheet 2 has blank rows 3 and 5, and row 6 fills only its second column.
	data := verifyWorkbook(t, []verifySheet{
		{name: "Cover", rows: [][]string{{"Title"}, {"stock list"}}},
		{name: "Stock", rows: [][]string{
			{"Part", "Qty", "Bin"},
			{"bolt", "12", "A1"},
			nil,
			{"nut", "40"},
			nil,
			{"", "7", "C4"},
		}},
	}, nil)
	for kind, items := range verifyParsedWorkbook(t, data) {
		var tables []map[string]any
		for _, it := range items {
			if verifyIsTable(it) {
				tables = append(tables, it)
			}
		}
		if len(tables) != 2 {
			t.Fatalf("%s: got %d rendered tables, want one per sheet (2)", kind, len(tables))
		}
		wantMatrix := [][]float64{{2, 1, 1, 1, 3}, {2, 2, 2, 1, 3}, {2, 4, 4, 1, 2}, {2, 6, 6, 2, 3}}
		if got := verifyMatrixOf(t, tables[1]); !reflect.DeepEqual(got, wantMatrix) {
			t.Fatalf("%s: Stock matrix = %v, want %v (blank rows left out, each row its own sheet row and filled columns)", kind, got, wantMatrix)
		}
		if got := strings.Count(strings.ToLower(tables[1]["text"].(string)), "<tr"); got != 4 {
			t.Fatalf("%s: Stock table renders %d rows, want 4 (header and the three filled rows)", kind, got)
		}
		verifyTableRowChunks(t, kind, "book."+kind, items, []verifyRowWant{
			{"- Title: stock list", []float64{1, 2, 2, 1, 1}},
			{"- Part: bolt\n- Qty: 12\n- Bin: A1", []float64{2, 2, 2, 1, 3}},
			{"- Part: nut\n- Qty: 40", []float64{2, 4, 4, 1, 2}},
			{"- Qty: 7\n- Bin: C4", []float64{2, 6, 6, 2, 3}},
		})
	}
}

func TestVerifyParsedRowTextIsPlainText(t *testing.T) {
	// Markup characters and quoted commas survive the render and read-back as
	// the characters the file holds, in both column names and values.
	csv := "Q&A,Note\nR&D,a < b\n\"x, \"\"y\"\"\",<ok> & 'z'\n"
	items := verifyParsedCSV(t, "notes.csv", csv)
	verifyTableRowChunks(t, "csv", "notes.csv", items, []verifyRowWant{
		{"- Q&A: R&D\n- Note: a < b", []float64{1, 2, 2, 1, 2}},
		{"- Q&A: x, \"y\"\n- Note: <ok> & 'z'", []float64{1, 3, 3, 1, 2}},
	})
}

func TestVerifySheetImageSplitsTableAtItsAnchor(t *testing.T) {
	// An image anchored on blank row 4 sits between rows 3 and 5. A second
	// image anchored below the last row comes after the table.
	data := verifyWorkbook(t, []verifySheet{
		{name: "Parts", rows: [][]string{
			{"Part", "Qty"},
			{"bolt", "12"},
			{"nut", "40"},
			nil,
			{"gear", "3"},
			{"cam", "9"},
		}},
	}, map[string]string{"Parts!B4": "wiring diagram", "Parts!A9": "label photo"})
	for kind, items := range verifyParsedWorkbook(t, data) {
		var shape []string
		for _, it := range items {
			switch {
			case verifyIsImage(it):
				shape = append(shape, "image")
			case verifyIsTable(it):
				shape = append(shape, "table")
			default:
				shape = append(shape, "other")
			}
		}
		if want := []string{"table", "image", "table", "image"}; !reflect.DeepEqual(shape, want) {
			t.Fatalf("%s: parsed items = %v, want %v (the table cut at the image's row)", kind, shape, want)
		}
		wantMatrices := [][][]float64{
			{{1, 1, 1, 1, 2}, {1, 2, 2, 1, 2}, {1, 3, 3, 1, 2}},
			{{1, 1, 1, 1, 2}, {1, 5, 5, 1, 2}, {1, 6, 6, 1, 2}},
		}
		for i, idx := range []int{0, 2} {
			text := items[idx]["text"].(string)
			for _, header := range []string{"Part", "Qty"} {
				if !strings.Contains(text, header) {
					t.Fatalf("%s: table part %d does not repeat the header %q: %q", kind, i, header, text)
				}
			}
			if got := verifyMatrixOf(t, items[idx]); !reflect.DeepEqual(got, wantMatrices[i]) {
				t.Fatalf("%s: table part %d matrix = %v, want %v", kind, i, got, wantMatrices[i])
			}
		}
		if strings.Contains(items[0]["text"].(string), "gear") || strings.Contains(items[2]["text"].(string), "bolt") {
			t.Fatalf("%s: a row landed on the wrong side of the image", kind)
		}
		verifyTableRowChunks(t, kind, "book."+kind, items, []verifyRowWant{
			{"- Part: bolt\n- Qty: 12", []float64{1, 2, 2, 1, 2}},
			{"- Part: nut\n- Qty: 40", []float64{1, 3, 3, 1, 2}},
			{"<image>", nil},
			{"- Part: gear\n- Qty: 3", []float64{1, 5, 5, 1, 2}},
			{"- Part: cam\n- Qty: 9", []float64{1, 6, 6, 1, 2}},
			{"<image>", nil},
		})
	}
}

// verifyQAChunks drives the Q&A chunker over parsed items.
func verifyQAChunks(t *testing.T, file, fileType string, items []map[string]any) []map[string]any {
	t.Helper()
	comp, err := NewQAChunker(map[string]any{"lang": "english"})
	if err != nil {
		t.Fatalf("NewQAChunker: %v", err)
	}
	out, err := comp.Invoke(context.Background(), nil, map[string]any{
		"name": file, "file_type": fileType, "output_format": "json", "json": items,
	})
	if err != nil {
		t.Fatalf("QAChunker.Invoke: %v", err)
	}
	if e, ok := out["_ERROR"]; ok && e != nil {
		t.Fatalf("QAChunker reported input error: %v", e)
	}
	chunks, ok := out["chunks"].([]map[string]any)
	if !ok {
		t.Fatalf("out[\"chunks\"] = %T, want []map[string]any", out["chunks"])
	}
	return chunks
}

type verifyQAWant struct {
	text  string
	tuple []float64
	top   float64
}

func verifyQAPairs(t *testing.T, label string, chunks []map[string]any, want []verifyQAWant) {
	t.Helper()
	if len(chunks) != len(want) {
		texts := make([]string, len(chunks))
		for i, c := range chunks {
			texts[i], _ = c["text"].(string)
		}
		t.Fatalf("%s: got %d Q&A chunks %q, want %d", label, len(chunks), texts, len(want))
	}
	for i, w := range want {
		if got := verifyText(t, chunks[i]); got != w.text {
			t.Fatalf("%s: pair %d text = %q, want %q", label, i, got, w.text)
		}
		if got := verifyMatrixOf(t, chunks[i]); !reflect.DeepEqual(got, [][]float64{w.tuple}) {
			t.Fatalf("%s: pair %d positions = %v, want only its row's tuple %v", label, i, got, w.tuple)
		}
		if !verifyHasKey(chunks[i], "top_int") {
			t.Fatalf("%s: pair %d has no top_int, want [%v]", label, i, w.top)
		}
		if got := verifyFloatList(t, chunks[i]["top_int"]); !reflect.DeepEqual(got, []float64{w.top}) {
			t.Fatalf("%s: pair %d top_int = %v, want [%v] (its sheet row minus one)", label, i, got, w.top)
		}
	}
}

func TestVerifyQAChunkerReadsParsedWorkbook(t *testing.T) {
	// A Q&A sheet has no header: row 1 is the first pair. Row 3 is blank, so
	// the pairs sit on sheet rows 1, 2 and 4. Outside a CSV, a row with a
	// third cell still gives a pair from its first two.
	data := verifyWorkbook(t, []verifySheet{
		{name: "FAQ", rows: [][]string{
			{"What is RAG?", "Retrieval plus generation"},
			{"Who maintains it?", "InfiniFlow"},
			nil,
			{"Is it free?", "Yes & open", "see site"},
		}},
	}, nil)
	for kind, items := range verifyParsedWorkbook(t, data) {
		verifyQAPairs(t, kind, verifyQAChunks(t, "faq."+kind, kind, items), []verifyQAWant{
			{"Question: What is RAG?\tAnswer: Retrieval plus generation", []float64{1, 1, 1, 1, 2}, 0},
			{"Question: Who maintains it?\tAnswer: InfiniFlow", []float64{1, 2, 2, 1, 2}, 1},
			{"Question: Is it free?\tAnswer: Yes & open", []float64{1, 4, 4, 1, 3}, 3},
		})
	}
}

func TestVerifyQAChunkerReadsParsedCSV(t *testing.T) {
	// In a CSV, a row without exactly two cells is added to the previous
	// answer instead of becoming a pair.
	csv := "q1,a1\nq2,a2,extra\nq3,x < 3\n"
	items := verifyParsedCSV(t, "faq.csv", csv)
	verifyQAPairs(t, "csv", verifyQAChunks(t, "faq.csv", "csv", items), []verifyQAWant{
		{"Question: q1\tAnswer: a1\nq2,a2,extra", []float64{1, 1, 1, 1, 2}, 0},
		{"Question: q3\tAnswer: x < 3", []float64{1, 3, 3, 1, 2}, 2},
	})
}
