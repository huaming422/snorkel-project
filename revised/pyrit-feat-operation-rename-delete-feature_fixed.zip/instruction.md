## Task

Operation names are set for good at creation right now, and there is no way to delete an Operation.
So a typo in a name never goes away, and Operations made by mistake just sit in the list.
We'd like operators to be able to rename and delete Operations through the backend's Operations API.

A new name should pass the same checks we already run when an Operation is created.
Activity that points at an Operation only by its name (the deprecated way) isn't linked to it by id.
It shouldn't count as usage or block a delete, and a delete should leave it alone.
Local runs sit on SQLite, which doesn't enforce foreign keys, while production can be on SQL Server, which does.
Callers need to see the same results on both.

Other endpoints, and attacks apart from what's described below, should keep working the way they do now.

## User stories / requirements

- Renaming: PATCH now takes a name as well as a description, and anything not sent stays as it was.
  If two edits overlap, the later one sticks.
  Names stay unique ignoring case and outer whitespace, so taking a name another Operation already has gets refused, with a reply naming the Operation that holds it.
- Fetching one Operation now also returns its usage: how many scenario runs, findings and attack results are linked to it.
  A brand-new Operation shows zero for all three.
- Delete only goes through when nothing is linked to the Operation.
  A successful delete returns no content, an unknown id gets not-found, and an Operation still in use is refused with the same usage numbers a read of it shows.
  Any signed-in user can delete, with no extra permission.
- A delete and new activity for the same Operation can land at once, and one side has to lose cleanly.
  Either the delete sees the new row and is refused, or the write fails since that Operation no longer exists.
  Nothing may reference a deleted Operation, whether or not the database checks foreign keys.
- Deleting an Operation while an SDK attack runs under it shouldn't break the attack.
  It finishes and saves its result without the Operation link, as do later steps of multi-step attacks and every objective in a batch.
  An attack given an Operation id that never existed is still rejected before it starts.
- The basics don't change: creating an Operation, seeing it listed and opening it still show the name and description it was saved with.
