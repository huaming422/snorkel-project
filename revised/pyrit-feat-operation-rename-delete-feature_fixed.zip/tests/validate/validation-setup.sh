#!/usr/bin/env bash
# Extends test-setup.sh with the smoke guard the validation stories need.
#
# Dependencies are already in the image and the implementation change adds
# none, so nothing is installed here. The script activates the repo's uv venv
# and stops early with a clear error if anything the stories import is missing,
# so a broken import shows up here instead of as a confusing story failure.
set -euo pipefail

cd /repo/pyrit

# Inherit env + venv state from the base test setup.
if [ -f /tests/test-setup.sh ]; then
    # shellcheck disable=SC1091
    source /tests/test-setup.sh
fi

export VIRTUAL_ENV=/opt/venv
export PATH="/opt/venv/bin:${PATH}"

# Smoke guard: every pre-existing interface the harness and stories import must
# load under the repo interpreter. This includes the FastAPI app + TestClient,
# the memory layer and its bindings, the attack-execution entry points, the
# pre-existing models the stories seed with, and the repo test-support helpers
# (resolved via the `tests` pythonpath entry declared in validation_spec.toml).
uv run --no-sync python - <<'PY'
import sys

sys.path.insert(0, "tests")

# HTTP surface.
from fastapi.testclient import TestClient  # noqa: F401
from pyrit.backend.main import app  # noqa: F401
from pyrit.backend.authentication_policy import AuthenticationPolicy  # noqa: F401
from pyrit import _compatibility  # noqa: F401

# Memory layer + binding.
from pyrit.memory import CentralMemory, MemoryInterface, SQLiteMemory  # noqa: F401
from test_support.fixtures import use_sqlite_memory  # noqa: F401

# Attack-execution entry points used by the in-flight story.
from pyrit.executor.attack import AttackExecutor, PromptSendingAttack  # noqa: F401
from pyrit.executor.attack.compound import (  # noqa: F401
    SequenceCompletionPolicy,
    SequentialAttack,
    SequentialChildAttack,
)
from pyrit.executor.attack.core.attack_parameters import AttackParameters  # noqa: F401
from pyrit.executor.attack.core.attack_strategy import AttackContext, AttackStrategy  # noqa: F401

# Pre-existing models + test doubles the stories seed/assert with.
from pyrit.models import (  # noqa: F401
    AttackResult,
    AttackResultSelection,
    AttackSeedGroup,
    ComponentIdentifier,
    Finding,
    Operation,
    ScenarioResult,
    SeedObjective,
)
from unit.mocks import MockPromptTarget, make_scenario_result  # noqa: F401

# The validation harness itself must import under this interpreter.
sys.path.insert(0, "/tests/validate")
import test_harness  # noqa: F401

print("pyrit validation env ready")
PY

echo "[validation-setup] pyrit validation env ready"
