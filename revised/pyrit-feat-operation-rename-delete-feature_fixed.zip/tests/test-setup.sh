#!/usr/bin/env bash
# Sourced before the tests run to get the PyRIT environment ready.
# Repo dependencies and the dev/test group are already installed in the image
# (`uv sync --all-extras --group dev`), and this feature needs nothing new, so
# nothing gets installed here. The script just activates the repo venv and
# checks that the main modules import.
set -euo pipefail

cd /repo/pyrit

# Make the repo's uv-managed venv active for anything invoked via a clean env.
export VIRTUAL_ENV=/opt/venv
export PATH="/opt/venv/bin:${PATH}"

# Sanity: the backend app, the memory layer, and the attack core must import,
# and pytest's asyncio mode must be available (used by the validation stories).
uv run --no-sync python - <<'PY'
import pyrit
from pyrit.backend.main import app  # noqa: F401
from pyrit.memory import MemoryInterface  # noqa: F401
from pyrit.executor.attack import AttackExecutor, PromptSendingAttack  # noqa: F401
import pytest_asyncio  # noqa: F401
print("pyrit test env ready")
PY
