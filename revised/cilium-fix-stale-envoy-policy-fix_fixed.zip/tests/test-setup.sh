#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
cd /repo/cilium

# This repository vendors its dependencies and its own build config compiles and tests with
# -mod=vendor. Build from the checked-in vendor/ tree: it is the tested, internally-consistent
# dependency set and needs no network or module cache (GOPROXY=off keeps the compile hermetic;
# the implementation phase has no network). Verify the vendor tree is present and consistent so a stale
# image fails fast instead of mid-compile.
export GOFLAGS=-mod=vendor GOPROXY=off

if [ -d vendor ] && [ -f vendor/modules.txt ]; then
    echo "[vendor] building from checked-in vendor/ tree"
else
    echo "[test-setup] vendor/ tree missing (image bake stale?)" >&2
    exit 1
fi

# No services, no data seeding, no assertion logic: the behavior is exercised directly
# through the in-process Envoy xDS control-path unit tests.
