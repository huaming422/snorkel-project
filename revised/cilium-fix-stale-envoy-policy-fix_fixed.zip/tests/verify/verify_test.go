// SPDX-License-Identifier: Apache-2.0
// Copyright Authors of Cilium

// In-package tests for the Envoy network-policy update/remove control path.
//
// Everything is driven through the method pair on *xdsServer
// (UpdateNetworkPolicy / RemoveNetworkPolicy) and observed through the read
// surfaces the access-log path already uses: localEndpointStore's
// getLocalEndpoint(name), the network-policy cache's Lookup(typeURL, name), and
// the access-log server's connection handler, which books each log entry's
// proxy statistics on the endpoint that the entry's policy name resolves to.
// State is seeded only through UpdateNetworkPolicy, never through the internal
// store setters, so the tests do not depend on the store's internal layout.
//
// Fixtures (endpoint IDs, IP strings, identity labels) are local test values.
// What matters is that two endpoints share one address, modelling address reuse
// after workload churn, and that the IDs and addresses differ between cases.
package envoy

import (
	"context"
	"net"
	"os"
	"strconv"
	"sync/atomic"
	"testing"

	"github.com/cilium/hive/hivetest"
	cilium "github.com/cilium/proxy/go/cilium/api"
	"github.com/stretchr/testify/require"
	"golang.org/x/sys/unix"
	"google.golang.org/protobuf/proto"

	"github.com/cilium/cilium/pkg/crypto/certificatemanager"
	envoypolicy "github.com/cilium/cilium/pkg/envoy/policy"
	"github.com/cilium/cilium/pkg/envoy/test"
	"github.com/cilium/cilium/pkg/identity"
	"github.com/cilium/cilium/pkg/identity/identitymanager"
	k8sConst "github.com/cilium/cilium/pkg/k8s/apis/cilium.io"
	"github.com/cilium/cilium/pkg/labels"
	"github.com/cilium/cilium/pkg/policy"
	"github.com/cilium/cilium/pkg/policy/api"
	"github.com/cilium/cilium/pkg/proxy/accesslog"
	testpolicy "github.com/cilium/cilium/pkg/testutils/policy"
)

// vrfEndpointMock is the listener-aware endpoint mock from xds_server_test.go
// plus a counter of the proxy statistics the access-log server books on it.
type vrfEndpointMock struct {
	*listenerProxyUpdaterMock
	proxyStats atomic.Int32
}

func (m *vrfEndpointMock) UpdateProxyStatistics(proxyType, l4Protocol string, port, proxyPort uint16, ingress, request bool,
	verdict accesslog.FlowVerdict) {
	m.proxyStats.Add(1)
}

func vrfEndpoint(id uint64, ipv4, ipv6 string) *vrfEndpointMock {
	return &vrfEndpointMock{listenerProxyUpdaterMock: &listenerProxyUpdaterMock{ProxyUpdaterMock: &test.ProxyUpdaterMock{
		Id:   id,
		Ipv4: ipv4,
		Ipv6: ipv6,
	}}}
}

// vrfNewXDSServer constructs an *xdsServer wired to a fresh correlation store and
// an initialized network-policy cache/mutator, using only pre-existing constructors.
func vrfNewXDSServer(t *testing.T) *xdsServer {
	logger := hivetest.Logger(t)
	xds := newXDSServer(
		logger,
		nil,
		nil,
		newLocalEndpointStore(),
		xdsServerConfig{},
		certificatemanager.NewMockSecretManagerInline(),
	)
	xds.l7RulesTranslator = envoypolicy.NewEnvoyL7RulesTranslator(logger, nil)
	return xds
}

// vrfNewPolicyRepo builds a policy repository holding a single egress-allow rule
// and returns it along with the local identity the rule selects. Reused to distill
// a real *policy.EndpointPolicy for any endpoint under test.
func vrfNewPolicyRepo(t *testing.T) (*policy.Repository, *identity.Identity) {
	logger := hivetest.Logger(t)
	localIdentity := identity.NewIdentity(9001, labels.LabelArray{
		labels.NewLabel("id", "a", labels.LabelSourceK8s),
		labels.NewLabel(k8sConst.PodNamespaceLabel, "default", labels.LabelSourceK8s),
	}.Labels())

	idMgr := identitymanager.NewIDManager(logger)
	repo := policy.NewPolicyRepository(
		logger,
		identity.IdentityMap{localIdentity.ID: localIdentity.LabelArray},
		nil,
		envoypolicy.NewEnvoyL7RulesTranslator(logger, certificatemanager.NewMockSecretManagerInline()),
		idMgr,
		testpolicy.NewPolicyMetricsNoop(),
	)
	idMgr.Add(localIdentity)
	t.Cleanup(func() { idMgr.Remove(localIdentity) })

	rule := &api.Rule{
		EndpointSelector: api.NewESFromLabels(labels.ParseSelectLabel("id=a")),
		Egress: []api.EgressRule{{
			EgressCommonRule: api.EgressCommonRule{
				ToEndpoints: []api.EndpointSelector{api.WildcardEndpointSelector},
			},
		}},
	}
	require.NoError(t, rule.Sanitize())
	repo.MustAddList(api.Rules{rule})
	return repo, localIdentity
}

// vrfDistill resolves and distills an endpoint policy for the given endpoint from repo.
func vrfDistill(t *testing.T, repo *policy.Repository, localIdentity *identity.Identity, ep *vrfEndpointMock) *policy.EndpointPolicy {
	logger := hivetest.Logger(t)
	selPolicy, _, err := repo.GetSelectorPolicy(localIdentity, 0, &dummyPolicyStats{}, ep.GetID())
	require.NoError(t, err)
	epp := selPolicy.DistillPolicy(logger, ep.listenerProxyUpdaterMock, nil)
	t.Cleanup(func() { epp.Detach(logger) })
	return epp
}

// vrfUpdate pushes the endpoint's policy and requires a successful update.
func vrfUpdate(t *testing.T, xds *xdsServer, repo *policy.Repository, id *identity.Identity, ep *vrfEndpointMock) func() error {
	t.Helper()
	err, revert := xds.UpdateNetworkPolicy(ep, vrfDistill(t, repo, id, ep), nil)
	require.NoError(t, err)
	require.NotNil(t, revert)
	return revert
}

func vrfPolicyName(ep *vrfEndpointMock) string {
	return strconv.FormatUint(ep.GetID(), 10)
}

func vrfRequireOwner(t *testing.T, xds *xdsServer, name string, want *vrfEndpointMock) {
	t.Helper()
	got := xds.localEndpointStore.getLocalEndpoint(name)
	require.NotNil(t, got, "name %s resolves to no endpoint", name)
	require.Equal(t, want.GetID(), got.GetID(), "name %s", name)
}

func vrfRequireUnowned(t *testing.T, xds *xdsServer, name string) {
	t.Helper()
	require.Nil(t, xds.localEndpointStore.getLocalEndpoint(name), "name %s", name)
}

func vrfRequirePolicy(t *testing.T, xds *xdsServer, ep *vrfEndpointMock, present bool) {
	t.Helper()
	res, err := xds.networkPolicyCache.Lookup(NetworkPolicyTypeURL, vrfPolicyName(ep))
	require.NoError(t, err)
	if present {
		require.NotNil(t, res, "policy resource %s", vrfPolicyName(ep))
	} else {
		require.Nil(t, res, "policy resource %s", vrfPolicyName(ep))
	}
}

// vrfAccessLogger is a ProxyAccessLogger that returns an empty request record.
type vrfAccessLogger struct{}

func (vrfAccessLogger) NewLogRecord(context.Context, accesslog.FlowType, bool, ...accesslog.LogTag) (*accesslog.LogRecord, error) {
	return &accesslog.LogRecord{Type: accesslog.TypeRequest, ObservationPoint: accesslog.Ingress}, nil
}

func (vrfAccessLogger) Log(*accesslog.LogRecord) {}

// vrfDeliverLog sends one access-log entry with the given policy name through the
// access-log server's connection handler, sharing the xDS server's store.
func vrfDeliverLog(t *testing.T, xds *xdsServer, policyName string) {
	t.Helper()
	fds, err := unix.Socketpair(unix.AF_UNIX, unix.SOCK_SEQPACKET|unix.SOCK_CLOEXEC, 0)
	require.NoError(t, err)
	readFile := os.NewFile(uintptr(fds[0]), "vrf-accesslog-read")
	writeFile := os.NewFile(uintptr(fds[1]), "vrf-accesslog-write")
	conn, err := net.FileConn(readFile)
	require.NoError(t, err)
	require.NoError(t, readFile.Close())
	unixConn, ok := conn.(*net.UnixConn)
	require.True(t, ok)

	msg, err := proto.Marshal(&cilium.LogEntry{PolicyName: policyName, IsIngress: true, EntryType: cilium.EntryType_Request})
	require.NoError(t, err)
	_, err = writeFile.Write(msg)
	require.NoError(t, err)
	require.NoError(t, writeFile.Close())

	als := newAccessLogServer(hivetest.Logger(t), vrfAccessLogger{}, t.TempDir(), 0, xds.localEndpointStore, 4096)
	als.handleConn(context.Background(), unixConn)
}

// vrfRequireBooked delivers one log entry under name and requires that exactly
// want (or nobody, when want is nil) gets its proxy statistics.
func vrfRequireBooked(t *testing.T, xds *xdsServer, name string, want *vrfEndpointMock, all ...*vrfEndpointMock) {
	t.Helper()
	before := make([]int32, len(all))
	for i, ep := range all {
		before[i] = ep.proxyStats.Load()
	}
	vrfDeliverLog(t, xds, name)
	for i, ep := range all {
		delta := ep.proxyStats.Load() - before[i]
		if ep == want {
			require.Equal(t, int32(1), delta, "log entry for %s must be booked on endpoint %d", name, ep.GetID())
		} else {
			require.Equal(t, int32(0), delta, "log entry for %s booked on endpoint %d", name, ep.GetID())
		}
	}
}

// vrfReuseCase is one address-reuse layout: the stale endpoints are pushed first,
// then current takes over one address from each of them.
type vrfReuseCase struct {
	name      string
	stale     []*vrfEndpointMock
	current   *vrfEndpointMock
	bystander *vrfEndpointMock
}

func vrfReuseCases() []vrfReuseCase {
	return []vrfReuseCase{
		{
			name:      "shared-ipv4",
			stale:     []*vrfEndpointMock{vrfEndpoint(500, "10.0.0.159", "fd00:10:244::500")},
			current:   vrfEndpoint(2766, "10.0.0.159", "fd00:10:244::ab0e"),
			bystander: vrfEndpoint(4100, "10.0.0.77", "fd00:10:244::77"),
		},
		{
			name:      "shared-ipv6",
			stale:     []*vrfEndpointMock{vrfEndpoint(731, "10.0.1.12", "fd00:10:244::1c")},
			current:   vrfEndpoint(1843, "10.0.1.40", "fd00:10:244::1c"),
			bystander: vrfEndpoint(2207, "10.0.1.66", "fd00:10:244::42"),
		},
		{
			name: "two-stale-owners",
			stale: []*vrfEndpointMock{
				vrfEndpoint(612, "10.0.2.5", "fd00:10:244::2:5"),
				vrfEndpoint(958, "10.0.2.9", "fd00:10:244::2:9"),
			},
			current:   vrfEndpoint(3310, "10.0.2.5", "fd00:10:244::2:9"),
			bystander: vrfEndpoint(845, "10.0.2.31", "fd00:10:244::2:31"),
		},
	}
}

// vrfSeed pushes a co-resident bystander and every stale endpoint, then the
// current endpoint, and returns the bystander and the current update's revert.
func vrfSeed(t *testing.T, xds *xdsServer, repo *policy.Repository, id *identity.Identity, tc vrfReuseCase) (*vrfEndpointMock, func() error) {
	t.Helper()
	vrfUpdate(t, xds, repo, id, tc.bystander)
	for _, s := range tc.stale {
		vrfUpdate(t, xds, repo, id, s)
		vrfRequireOwner(t, xds, s.Ipv4, s)
		vrfRequireOwner(t, xds, s.Ipv6, s)
		vrfRequirePolicy(t, xds, s, true)
	}
	return tc.bystander, vrfUpdate(t, xds, repo, id, tc.current)
}

func vrfNotOwnedBy(name string, ep *vrfEndpointMock) bool {
	return name != ep.Ipv4 && name != ep.Ipv6
}

// TestStaleEntryEvictedOnUpdate: after a policy update for an endpoint that takes
// over an address still held by an earlier, different endpoint instance, every
// address of the current endpoint resolves to it, no address resolves to a
// superseded endpoint (including addresses the current endpoint never reports),
// and a co-resident endpoint keeps its entries.
func TestStaleEntryEvictedOnUpdate(t *testing.T) {
	for _, tc := range vrfReuseCases() {
		t.Run(tc.name, func(t *testing.T) {
			repo, id := vrfNewPolicyRepo(t)
			xds := vrfNewXDSServer(t)
			bystander, _ := vrfSeed(t, xds, repo, id, tc)

			vrfRequireOwner(t, xds, tc.current.Ipv4, tc.current)
			vrfRequireOwner(t, xds, tc.current.Ipv6, tc.current)
			for _, s := range tc.stale {
				for _, name := range []string{s.Ipv4, s.Ipv6} {
					if vrfNotOwnedBy(name, tc.current) {
						vrfRequireUnowned(t, xds, name)
					}
				}
			}
			vrfRequireOwner(t, xds, bystander.Ipv4, bystander)
			vrfRequireOwner(t, xds, bystander.Ipv6, bystander)
		})
	}
}

// TestStaleXdsPolicyDeletedOnConflict: after the same takeover, the superseded
// endpoints' policy resources (keyed by endpoint ID) are gone from the
// proxy-facing cache, while the current endpoint's and a co-resident endpoint's
// resources are still served.
func TestStaleXdsPolicyDeletedOnConflict(t *testing.T) {
	for _, tc := range vrfReuseCases() {
		t.Run(tc.name, func(t *testing.T) {
			repo, id := vrfNewPolicyRepo(t)
			xds := vrfNewXDSServer(t)
			bystander, _ := vrfSeed(t, xds, repo, id, tc)

			for _, s := range tc.stale {
				vrfRequirePolicy(t, xds, s, false)
			}
			vrfRequirePolicy(t, xds, tc.current, true)
			vrfRequirePolicy(t, xds, bystander, true)
		})
	}
}

// TestStoreSurvivesPolicyUpdateRevert: running the current endpoint's update
// revert function (used when the proxy does not take the update) leaves the
// address attribution as it was after the update. The current endpoint still owns
// its addresses, the superseded endpoints own none, and their policy resources
// stay deleted.
func TestStoreSurvivesPolicyUpdateRevert(t *testing.T) {
	for _, tc := range vrfReuseCases() {
		t.Run(tc.name, func(t *testing.T) {
			repo, id := vrfNewPolicyRepo(t)
			xds := vrfNewXDSServer(t)
			bystander, revert := vrfSeed(t, xds, repo, id, tc)

			require.NoError(t, revert())

			vrfRequireOwner(t, xds, tc.current.Ipv4, tc.current)
			vrfRequireOwner(t, xds, tc.current.Ipv6, tc.current)
			for _, s := range tc.stale {
				for _, name := range []string{s.Ipv4, s.Ipv6} {
					if vrfNotOwnedBy(name, tc.current) {
						vrfRequireUnowned(t, xds, name)
					}
				}
				vrfRequirePolicy(t, xds, s, false)
			}
			vrfRequireOwner(t, xds, bystander.Ipv4, bystander)
			vrfRequirePolicy(t, xds, bystander, true)
		})
	}
}

// TestLateTeardownKeepsReusedAddress: when a superseded endpoint is torn down
// after the current endpoint took over its address, the current endpoint keeps
// its addresses and its policy resource.
func TestLateTeardownKeepsReusedAddress(t *testing.T) {
	for _, tc := range vrfReuseCases() {
		t.Run(tc.name, func(t *testing.T) {
			repo, id := vrfNewPolicyRepo(t)
			xds := vrfNewXDSServer(t)
			bystander, _ := vrfSeed(t, xds, repo, id, tc)

			for _, s := range tc.stale {
				xds.RemoveNetworkPolicy(s)
			}

			vrfRequireOwner(t, xds, tc.current.Ipv4, tc.current)
			vrfRequireOwner(t, xds, tc.current.Ipv6, tc.current)
			vrfRequirePolicy(t, xds, tc.current, true)
			for _, s := range tc.stale {
				vrfRequirePolicy(t, xds, s, false)
			}
			vrfRequireOwner(t, xds, bystander.Ipv4, bystander)
			vrfRequirePolicy(t, xds, bystander, true)
		})
	}
}

// TestAccessLogAttributionAfterReuse: access-log entries delivered through the
// access-log server are booked on the current endpoint for a reused address,
// and on nobody for a superseded endpoint's other address. This holds right after
// the takeover, after the current update is reverted, and after the superseded
// endpoint is torn down late.
func TestAccessLogAttributionAfterReuse(t *testing.T) {
	for _, tc := range vrfReuseCases() {
		t.Run(tc.name, func(t *testing.T) {
			repo, id := vrfNewPolicyRepo(t)
			xds := vrfNewXDSServer(t)
			bystander, revert := vrfSeed(t, xds, repo, id, tc)
			all := append([]*vrfEndpointMock{tc.current, bystander}, tc.stale...)

			check := func() {
				t.Helper()
				for _, s := range tc.stale {
					for _, name := range []string{s.Ipv4, s.Ipv6} {
						if vrfNotOwnedBy(name, tc.current) {
							vrfRequireBooked(t, xds, name, nil, all...)
						} else {
							vrfRequireBooked(t, xds, name, tc.current, all...)
						}
					}
				}
				vrfRequireBooked(t, xds, bystander.Ipv6, bystander, all...)
			}

			check()
			require.NoError(t, revert())
			check()
			for _, s := range tc.stale {
				xds.RemoveNetworkPolicy(s)
			}
			check()
		})
	}
}

// TestTeardownRemovesAllEntries: tearing an endpoint down removes every
// correlation entry belonging to that endpoint instance, including an entry under
// an address it reported earlier but no longer reports at removal time (one of
// its addresses changed while it was live), and removes its policy resource. A
// co-resident endpoint keeps its entries and its policy resource.
func TestTeardownRemovesAllEntries(t *testing.T) {
	cases := []struct {
		name       string
		ep         *vrfEndpointMock
		other      *vrfEndpointMock
		changeAddr func(ep *vrfEndpointMock) string
	}{
		{
			name:  "ipv4-changed",
			ep:    vrfEndpoint(2766, "10.0.0.159", "fd00:10:244::ab0e"),
			other: vrfEndpoint(4100, "10.0.0.77", "fd00:10:244::77"),
			changeAddr: func(ep *vrfEndpointMock) string {
				old := ep.Ipv4
				ep.Ipv4 = "10.0.0.200"
				return old
			},
		},
		{
			name:  "ipv6-changed",
			ep:    vrfEndpoint(1517, "10.0.3.21", "fd00:10:244::3:21"),
			other: vrfEndpoint(2048, "10.0.3.88", "fd00:10:244::3:88"),
			changeAddr: func(ep *vrfEndpointMock) string {
				old := ep.Ipv6
				ep.Ipv6 = "fd00:10:244::3:99"
				return old
			},
		},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			repo, id := vrfNewPolicyRepo(t)
			xds := vrfNewXDSServer(t)

			vrfUpdate(t, xds, repo, id, tc.other)
			vrfUpdate(t, xds, repo, id, tc.ep)
			vrfRequireOwner(t, xds, tc.ep.Ipv4, tc.ep)
			vrfRequireOwner(t, xds, tc.ep.Ipv6, tc.ep)

			oldAddr := tc.changeAddr(tc.ep)

			xds.RemoveNetworkPolicy(tc.ep)

			vrfRequireUnowned(t, xds, oldAddr)
			vrfRequireUnowned(t, xds, tc.ep.Ipv4)
			vrfRequireUnowned(t, xds, tc.ep.Ipv6)
			vrfRequirePolicy(t, xds, tc.ep, false)

			vrfRequireOwner(t, xds, tc.other.Ipv4, tc.other)
			vrfRequireOwner(t, xds, tc.other.Ipv6, tc.other)
			vrfRequirePolicy(t, xds, tc.other, true)
		})
	}
}

// TestNormalUpdateAndHostSkip: a non-conflicting update records the endpoint
// under every address it reports, publishes its policy resource and gets its
// access-log entries booked; an endpoint that reports no addresses (the host
// endpoint) is skipped without error and without publishing anything.
func TestNormalUpdateAndHostSkip(t *testing.T) {
	repo, id := vrfNewPolicyRepo(t)
	xds := vrfNewXDSServer(t)

	normalEP := vrfEndpoint(3001, "10.0.0.50", "fd00:10:244::50")
	vrfUpdate(t, xds, repo, id, normalEP)

	vrfRequireOwner(t, xds, normalEP.Ipv4, normalEP)
	vrfRequireOwner(t, xds, normalEP.Ipv6, normalEP)
	vrfRequirePolicy(t, xds, normalEP, true)
	vrfRequireBooked(t, xds, normalEP.Ipv4, normalEP, normalEP)

	hostEP := vrfEndpoint(1, "", "")
	vrfUpdate(t, xds, repo, id, hostEP)
	vrfRequirePolicy(t, xds, hostEP, false)
}
