## Task

On nodes with a lot of pod churn, the L7 proxy holds on to state from pods that are already gone.
The pattern is always the same: a pod is deleted, and a new pod on that node is handed one of its addresses.
From then on the proxy can keep serving the old pod's network policy.
Access-log entries for the address get booked on the old endpoint, or on no endpoint at all, instead of on the new pod.
It never recovers by itself, and restarting the agent and the proxy is the only thing that clears it today.

What we have seen so far:

- It happens with IPv4 reuse and with IPv6 reuse, and our pods are dual-stack with one address of each family.
- A new pod sometimes gets its IPv4 address from one departed pod and its IPv6 address from another.
- We can't count on the old pod's teardown reaching the proxy side before the new pod shows up, since it sometimes arrives later and sometimes never seems to arrive.
- It also shows up after the proxy fails to take the new pod's policy push and the agent rolls that push back.
- A pod whose address changed while it was running leaves entries behind under its old address once it is deleted.

Please find out why this state survives and fix it so that, as soon as the new pod's policy is pushed:

- The departed pods' policies are no longer served to the proxy.
- No address is attributed to a departed pod any more, including the addresses the new pod did not take.
- The reused addresses are attributed to the new pod, and they stay that way if the push is rolled back or the old pod's teardown arrives late.

Deleting a pod should still drop its policy, and if its address changed while it was running, it should also clear what was recorded under the old address.
Other pods on the node must keep their policies and their access-log attribution.
Normal policy updates, and the host endpoint that has no addresses of its own, should behave as they do today.
