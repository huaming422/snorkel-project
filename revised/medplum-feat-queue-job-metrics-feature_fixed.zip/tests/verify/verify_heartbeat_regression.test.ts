// @ts-nocheck
// SPDX-License-Identifier: Apache-2.0
//
// Queue-health heartbeat: it keeps reading the same five queues (subscription,
// cron, download, batch, set-accounts) and keeps publishing each one's waiting and
// delayed counts under a name that carries the queue. The other registered
// queues are not read by the heartbeat.
//
// Interface under test: the existing `initOtelHeartbeat()` export, driven the way
// the repo's own otel tests drive it (stubbed database pool, a dispatched
// heartbeat event). Every worker queue is registered in the shared queue registry
// as its own mock queue with its own counts, so the check holds whether the
// heartbeat reaches the queues through the per-worker getters or the registry.
// The OTel meter is spied so recordings are observed by metric name across
// instrument kinds.

import { sleep } from '@medplum/core';
import { metrics } from '@opentelemetry/api';
import { vi } from 'vitest';
import * as databaseModule from './database';
import { heartbeat } from './heartbeat';
import { cleanupOtelHeartbeat, initOtelHeartbeat } from './otel/otel';
import { queueRegistry } from './workers/utils';

process.env.OTLP_METRICS_ENDPOINT = 'http://localhost:4318/v1/metrics';

const recordsByName = new Map();
function instrumentFor(name) {
  const rec = (...callArgs) => {
    if (!recordsByName.has(name)) {
      recordsByName.set(name, []);
    }
    recordsByName.get(name).push(callArgs);
  };
  return { add: rec, record: rec };
}

// A queue mock that answers every count getter the heartbeat might read.
function createMockQueue(waiting, delayed, active) {
  return {
    getWaitingCount: vi.fn().mockResolvedValue(waiting),
    getDelayedCount: vi.fn().mockResolvedValue(delayed),
    getActiveCount: vi.fn().mockResolvedValue(active),
    close: vi.fn().mockResolvedValue(undefined),
  };
}

// Registry name -> metric token, with distinct counts per queue.
const HEARTBEAT_QUEUES = [
  { name: 'SubscriptionQueue', token: 'subscription', waiting: 11, delayed: 21 },
  { name: 'CronQueue', token: 'cron', waiting: 12, delayed: 22 },
  { name: 'DownloadQueue', token: 'download', waiting: 13, delayed: 23 },
  { name: 'BatchQueue', token: 'batch', waiting: 14, delayed: 24 },
  { name: 'SetAccountsQueue', token: 'set-accounts', waiting: 15, delayed: 25 },
];
const OTHER_QUEUES = [
  'DispatchQueue',
  'ReindexQueue',
  'PostDeployMigrationQueue',
  'LambdaCleanerQueue',
  'DataWarehouseSyncQueue',
];

const norm = (s) => s.toLowerCase().replace(/[^a-z0-9]/g, '');

/** The latest value recorded under a name carrying both the queue token and the metric word. */
function valueFor(token, metricWord) {
  for (const [name, calls] of recordsByName) {
    const n = norm(name);
    if (n.includes(norm(token)) && n.includes(metricWord)) {
      return calls[calls.length - 1][0];
    }
  }
  return undefined;
}

describe('queue-health heartbeat - waiting/delayed regression', () => {
  const heartbeatQueues = new Map();
  const otherQueues = new Map();

  beforeAll(() => {
    vi.spyOn(metrics, 'getMeter').mockReturnValue({
      createCounter: (name) => instrumentFor(name),
      createUpDownCounter: (name) => instrumentFor(name),
      createGauge: (name) => instrumentFor(name),
      createHistogram: (name) => instrumentFor(name),
      createObservableGauge: () => ({ addCallback: () => undefined, removeCallback: () => undefined }),
    });

    for (const q of HEARTBEAT_QUEUES) {
      const queue = createMockQueue(q.waiting, q.delayed, 2);
      heartbeatQueues.set(q.token, queue);
      queueRegistry.add(q.name, queue, undefined);
    }
    for (const [i, name] of OTHER_QUEUES.entries()) {
      const queue = createMockQueue(31 + i, 41 + i, 51 + i);
      otherQueues.set(name, queue);
      queueRegistry.add(name, queue, undefined);
    }
  });

  beforeEach(() => {
    recordsByName.clear();
    cleanupOtelHeartbeat();
  });

  afterAll(async () => {
    cleanupOtelHeartbeat();
    await Promise.all(queueRegistry.closeAll());
    vi.restoreAllMocks();
  });

  test('a heartbeat reads waiting and delayed counts for the five heartbeat queues only', async () => {
    const getDatabasePoolSpy = vi
      .spyOn(databaseModule, 'getDatabasePool')
      .mockImplementation(() => ({ query: async () => undefined }));

    initOtelHeartbeat();
    heartbeat.dispatchEvent({ type: 'heartbeat' });
    await sleep(0);

    expect(getDatabasePoolSpy).toHaveBeenCalled();

    // Each heartbeat queue is read once per heartbeat, and its own waiting and
    // delayed counts are published under a name carrying that queue.
    for (const q of HEARTBEAT_QUEUES) {
      const queue = heartbeatQueues.get(q.token);
      expect(queue.getWaitingCount).toHaveBeenCalledTimes(1);
      expect(queue.getDelayedCount).toHaveBeenCalledTimes(1);
      expect(valueFor(q.token, 'waiting')).toBe(q.waiting);
      expect(valueFor(q.token, 'delayed')).toBe(q.delayed);
    }

    // Queues outside the heartbeat set are not read.
    for (const [name, queue] of otherQueues) {
      expect({ name, waiting: queue.getWaitingCount.mock.calls.length }).toStrictEqual({ name, waiting: 0 });
      expect({ name, delayed: queue.getDelayedCount.mock.calls.length }).toStrictEqual({ name, delayed: 0 });
      expect({ name, active: queue.getActiveCount.mock.calls.length }).toStrictEqual({ name, active: 0 });
    }

    cleanupOtelHeartbeat();
    getDatabasePoolSpy.mockRestore();
  });
});
