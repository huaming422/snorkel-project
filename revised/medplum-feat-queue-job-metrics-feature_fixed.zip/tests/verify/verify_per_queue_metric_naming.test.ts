// @ts-nocheck
// SPDX-License-Identifier: Apache-2.0
//
// Per-queue naming and coverage of the worker-side job metrics.
//
//  1. Per-queue metrics carry the queue in the metric name, the way the existing
//     waiting/delayed counts are named: driving two different workers' processors
//     records the in-flight series under two distinct, queue-identifying names,
//     not one shared name told apart only by an attribute.
//
//  2. The worker-side metrics cover the eight listed worker queues (dispatch,
//     subscription, download, cron, batch, set-accounts, lambda-cleaner,
//     data-warehouse-sync). Reindex and post-deploy migration are not checked
//     either way.
//
//  3. Each queue's in-flight level is its own: with a download job and a batch
//     job running at the same time, settling the batch job brings the batch level
//     to 0 and leaves the download level at 1.
//
// Interface under test: the existing exported worker initializers.
// `bullmq.Worker` is globally mocked, so the processor each initializer built is
// recoverable from the mock's call record; the OTel meter is spied so instrument
// activity is observed by metric name across every instrument kind (an up/down
// counter's `.add`, a gauge's `.record`, a counter, a histogram, or an observable
// callback), so any instrument that gives a per-queue series is accepted.

import { metrics } from '@opentelemetry/api';
import { Worker } from 'bullmq';
import { vi } from 'vitest';
import { loadTestConfig } from './config/loader';
import * as contextModule from './context';
import { initBatchWorker } from './workers/batch';
import { initCronWorker } from './workers/cron';
import { initDataWarehouseSyncWorker } from './workers/data-warehouse-sync';
import { initDispatchWorker } from './workers/dispatch';
import { initDownloadWorker } from './workers/download';
import { initLambdaCleanerWorker } from './workers/lambda-cleaner';
import { initSetAccountsWorker } from './workers/set-accounts';
import { initSubscriptionWorker } from './workers/subscription';

// Recording helpers are no-ops unless a metrics endpoint is configured.
process.env.OTLP_METRICS_ENDPOINT = 'http://localhost:4318/v1/metrics';

// metric name -> array of recorded call-args, populated by whichever instrument
// kind the code under test uses. Instruments are memoized by otel per name, so a single
// stable recorder per name captures every movement regardless of instrument kind.
const recordsByName = new Map();
// name -> observable-gauge/counter callbacks, invoked on demand so a polled
// (callback-read) in-flight instrument is admitted alongside synchronous ones.
const observableCallbacks = new Map();

function recordUnder(name, ...callArgs) {
  if (!recordsByName.has(name)) {
    recordsByName.set(name, []);
  }
  recordsByName.get(name).push(callArgs);
}

// Synchronous instruments (Counter.add, UpDownCounter.add, Gauge.record,
// Histogram.record): the same recorder keyed by metric name.
function instrumentFor(name) {
  const rec = (...callArgs) => recordUnder(name, ...callArgs);
  return { add: rec, record: rec };
}

// Observable instruments (createObservable{Gauge,Counter,UpDownCounter}): capture
// registered callbacks so an "atomic integer read by a gauge callback" design still
// registers. Invoked after the processor is driven; the callback observes the
// maintained in-flight value, recorded under whatever name(s) it observes.
function observableFor(name) {
  return {
    addCallback: (cb) => {
      if (!observableCallbacks.has(name)) {
        observableCallbacks.set(name, []);
      }
      observableCallbacks.get(name).push(cb);
    },
    removeCallback: () => undefined,
  };
}

function pollObservables() {
  for (const [name, cbs] of observableCallbacks) {
    for (const cb of cbs) {
      try {
        // ObservableResult.observe(value, attributes) -> record by creation name.
        cb({ observe: (value) => recordUnder(name, value) });
      } catch {
        // A fragile callback must never break the verifier.
      }
    }
  }
}

// The eight listed worker queues. Reindex and post-deploy-migration are not
// checked either way.
const INSTRUMENTED_WORKERS = [
  { token: 'subscription', init: initSubscriptionWorker },
  { token: 'cron', init: initCronWorker },
  { token: 'download', init: initDownloadWorker },
  { token: 'dispatch', init: initDispatchWorker },
  { token: 'batch', init: initBatchWorker },
  { token: 'set-accounts', init: initSetAccountsWorker },
  { token: 'data-warehouse-sync', init: initDataWarehouseSyncWorker },
  { token: 'lambda-cleaner', init: initLambdaCleanerWorker },
];

const norm = (s) => s.toLowerCase().replace(/[^a-z0-9]/g, '');

/**
 * The current level across the given metric names. Values recorded through
 * add() are signed deltas once any is negative (level = running sum); otherwise
 * they are absolute levels (level = latest value).
 */
function levelOf(names) {
  let level = 0;
  for (const name of names) {
    const values = (recordsByName.get(name) ?? []).map((args) => Number(args[0]) || 0);
    if (values.length === 0) {
      continue;
    }
    level += values.some((v) => v < 0) ? values.reduce((a, b) => a + b, 0) : values[values.length - 1];
  }
  return level;
}

/** Build the worker and return the processor it passed to `new Worker(...)`. */
function captureProcessor(init, config) {
  const before = vi.mocked(Worker).mock.calls.length;
  init(config, { workerEnabled: true });
  const calls = vi.mocked(Worker).mock.calls;
  if (calls.length <= before) {
    throw new Error('worker initializer did not construct a Worker');
  }
  return calls[calls.length - 1][1];
}

/**
 * Drive the captured processor and return the metric names that received a
 * recording. The in-flight "job started" movement lands synchronously, before the
 * job body is awaited, so the returned promise is not awaited (the real job body
 * needs a database and rejects); the rejection is swallowed.
 */
function namesRecordedWhileDriving(processor) {
  recordsByName.clear();
  const job = { id: 'verify-job', data: {} };
  const signal = new AbortController().signal;
  let settled;
  try {
    settled = processor(job, 'verify-token', signal);
  } catch {
    settled = undefined; // synchronous throw: the start-movement still landed
  }
  if (settled && typeof settled.then === 'function') {
    settled.then(
      () => undefined,
      () => undefined
    );
  }
  // Read any polled (observable-callback) instruments at this mid-flight point,
  // where a maintained in-flight value is non-zero.
  pollObservables();
  return [...recordsByName.keys()];
}

describe('queue job metrics - per-queue naming and coverage', () => {
  let config;

  beforeAll(async () => {
    config = await loadTestConfig();
    // The data-warehouse-sync worker only constructs its Worker when its sync
    // feature is configured (enabled + a valid destination); otherwise
    // `initDataWarehouseSyncWorker` returns before `new Worker(...)`. Every other
    // worker ignores this field. A local destination needs no AWS/Redis and keeps
    // construction in process (the scheduler refresh it starts is fire-and-forget
    // and its errors are caught).
    config.dataWarehouse = {
      enabled: true,
      cron: '0 0 * * *',
      destination: 'local',
      localBasePath: '/tmp/dw-verify',
    };
    // Install BEFORE any instrument is created (otel memoizes the meter on first
    // use). Each create* returns a recorder keyed by the metric name.
    vi.spyOn(metrics, 'getMeter').mockReturnValue({
      createCounter: (name) => instrumentFor(name),
      createUpDownCounter: (name) => instrumentFor(name),
      createGauge: (name) => instrumentFor(name),
      createHistogram: (name) => instrumentFor(name),
      createObservableGauge: (name) => observableFor(name),
      createObservableCounter: (name) => observableFor(name),
      createObservableUpDownCounter: (name) => observableFor(name),
    });
  });

  // Runs first, so no job started by a later test is still pending while it reads levels.
  test('each queue keeps its own in-flight level while jobs on two queues overlap', async () => {
    recordsByName.clear();

    // Hold each job body open until the test releases it. The download worker runs
    // its job body through tryRunInRequestContext, the batch worker through
    // runInAuthenticatedContext.
    let releaseDownload;
    let releaseBatch;
    const downloadSpy = vi
      .spyOn(contextModule, 'tryRunInRequestContext')
      .mockImplementation(() => new Promise((resolve) => (releaseDownload = resolve)));
    const batchSpy = vi
      .spyOn(contextModule, 'runInAuthenticatedContext')
      .mockImplementation(() => new Promise((resolve) => (releaseBatch = resolve)));

    try {
      const downloadProcessor = captureProcessor(initDownloadWorker, config);
      const batchProcessor = captureProcessor(initBatchWorker, config);
      const signal = new AbortController().signal;

      const downloadDone = downloadProcessor({ id: 'verify-download', data: {} }, 'verify-token', signal);
      const batchDone = batchProcessor({ id: 'verify-batch', data: {} }, 'verify-token', signal);
      await vi.waitFor(() => {
        expect(releaseDownload).toBeTypeOf('function');
        expect(releaseBatch).toBeTypeOf('function');
      });

      // The in-flight series are the queue-token names recorded while both jobs run.
      pollObservables();
      const inFlightNames = (token) => [...recordsByName.keys()].filter((n) => norm(n).includes(norm(token)));
      const downloadNames = inFlightNames('download');
      const batchNames = inFlightNames('batch');
      expect(downloadNames.length).toBeGreaterThan(0);
      expect(batchNames.length).toBeGreaterThan(0);
      expect(levelOf(downloadNames)).toBe(1);
      expect(levelOf(batchNames)).toBe(1);

      releaseBatch(undefined);
      await batchDone;
      pollObservables();
      expect(levelOf(batchNames)).toBe(0);
      expect(levelOf(downloadNames)).toBe(1);

      releaseDownload(undefined);
      await downloadDone;
      pollObservables();
      expect(levelOf(downloadNames)).toBe(0);
    } finally {
      downloadSpy.mockRestore();
      batchSpy.mockRestore();
    }
  });

  test('two different workers record the in-flight series under distinct, queue-identifying names', () => {
    const cronNames = namesRecordedWhileDriving(captureProcessor(initCronWorker, config));
    const subscriptionNames = namesRecordedWhileDriving(captureProcessor(initSubscriptionWorker, config));

    // Each worker records at least one metric whose name carries its own queue
    // token, so the queue lives in the name rather than in an attribute on one
    // shared name.
    const cronOwn = cronNames.filter((n) => norm(n).includes(norm('cron')));
    const subOwn = subscriptionNames.filter((n) => norm(n).includes(norm('subscription')));
    expect(cronOwn.length).toBeGreaterThan(0);
    expect(subOwn.length).toBeGreaterThan(0);

    // A shared-name-with-attribute design would make these identical; they differ.
    expect(new Set(cronOwn)).not.toEqual(new Set(subOwn));
    for (const n of cronOwn) {
      expect(norm(n).includes(norm('subscription'))).toBe(false);
    }
  });

  test('the in-flight series covers the eight listed worker queues', () => {
    const uncovered = [];
    for (const { token, init } of INSTRUMENTED_WORKERS) {
      const names = namesRecordedWhileDriving(captureProcessor(init, config));
      const matched = names.some((n) => norm(n).includes(norm(token)));
      if (!matched) {
        uncovered.push(token);
      }
    }
    expect(uncovered).toStrictEqual([]);
  });
});
