// @ts-nocheck
// SPDX-License-Identifier: Apache-2.0
//
// Batch queue entry total: async batch jobs on the resumable (re-entrant) path
// keep a running total of individual bundle entries processed.
//
// Two jobs with different entry counts (3, then 5) run one after the other, and
// the total must read 3 after the first and 8 after the second, so a fixed
// per-job amount does not match.
//
// Interface under test: the existing `initBatchWorker` initializer and the
// re-entrant `execBatchJob` loop it drives. `bullmq.Worker` is globally mocked
// (see test.setup.ts), so the processor the initializer handed to
// `new Worker(...)` is recoverable from the mock's call record. The loop's
// durable collaborators (checkpoint store, system repo, batch processor, async-job
// executor, binary upload, authenticated context) are stubbed so the loop runs a
// set number of entries in process, with no Postgres, Redis or object storage.
// The OTel meter is spied so recordings are observed by metric name across every
// instrument kind; the entry metric is matched by name containment ('batch' and
// 'entr'), so any instrument and any such name is accepted.

import { metrics } from '@opentelemetry/api';
import { BatchProcessor } from '@medplum/fhir-router';
import { Worker } from 'bullmq';
import { vi } from 'vitest';
import { loadTestConfig } from './config/loader';
import * as contextModule from './context';
import * as binaryModule from './fhir/binary';
import { AsyncJobExecutor } from './fhir/operations/utils/asyncjobexecutor';
import * as accessPolicyModule from './fhir/accesspolicy';
import * as repoModule from './fhir/repo';
import { BatchCheckpointStore } from './fhir/batch/checkpoint-store';
import * as meModule from './auth/me';
import { initBatchWorker } from './workers/batch';

// Recording helpers are no-ops unless a metrics endpoint is configured.
process.env.OTLP_METRICS_ENDPOINT = 'http://localhost:4318/v1/metrics';

// Entry counts of the two jobs run in order. The running total must read
// RUNNING_TOTALS[i] after job i.
const JOB_ENTRY_COUNTS = [3, 5];
const RUNNING_TOTALS = [3, 8];

// The entry count the stubbed loop works through for the job being run.
let entryCount = 0;

// metric name -> list of { kind, value } recordings. 'delta' comes from add()
// (counters, up/down counters), 'level' from record() or an observable callback
// (gauges). Instruments are memoized per name by otel, so one recorder per name
// captures every movement regardless of instrument kind.
const recordsByName = new Map();
const observableCallbacks = new Map();

function recordUnder(name, kind, value) {
  if (!recordsByName.has(name)) {
    recordsByName.set(name, []);
  }
  recordsByName.get(name).push({ kind, value: Number(value) || 0 });
}

// Synchronous instruments (Counter.add, UpDownCounter.add, Gauge.record,
// Histogram.record), keyed by metric name.
function instrumentFor(name) {
  return {
    add: (value) => recordUnder(name, 'delta', value),
    record: (value) => recordUnder(name, 'level', value),
  };
}

// Observable instruments: capture registered callbacks so an "atomic integer read
// by a gauge callback" design still registers; invoked after the loop is driven.
function observableFor(name) {
  return {
    addCallback: (cb) => {
      if (!observableCallbacks.has(name)) {
        observableCallbacks.set(name, []);
      }
      observableCallbacks.get(name).push(cb);
    },
    removeCallback: () => undefined,
  };
}

function pollObservables() {
  for (const [name, cbs] of observableCallbacks) {
    for (const cb of cbs) {
      try {
        cb({ observe: (value) => recordUnder(name, 'level', value) });
      } catch {
        // A fragile callback must never break the verifier.
      }
    }
  }
}

const norm = (s) => s.toLowerCase().replace(/[^a-z0-9]/g, '');

/**
 * The current entry total: the latest level for a gauge-style metric, otherwise
 * the sum of the deltas added so far. Only names carrying both the batch queue
 * and the entry token count.
 */
function entryTotal() {
  const names = [...recordsByName.keys()].filter((n) => norm(n).includes('batch') && norm(n).includes('entr'));
  let deltas = 0;
  let level;
  for (const name of names) {
    for (const { kind, value } of recordsByName.get(name)) {
      if (kind === 'level') {
        level = value;
      } else {
        deltas += value;
      }
    }
  }
  return { names, total: level ?? deltas };
}

/** The processor `initBatchWorker` passed to `new Worker(queueName, processor, opts)`. */
function captureBatchProcessor(config) {
  const before = vi.mocked(Worker).mock.calls.length;
  initBatchWorker(config, { workerEnabled: true });
  const calls = vi.mocked(Worker).mock.calls;
  if (calls.length <= before) {
    throw new Error('initBatchWorker did not construct a Worker');
  }
  // new Worker(queueName, processor, opts) - processor is the second argument.
  return calls[calls.length - 1][1];
}

describe('queue job metrics - batch entries processed', () => {
  let config;
  let processor;

  beforeAll(async () => {
    config = await loadTestConfig();

    // Install the meter spy BEFORE any instrument is created (otel memoizes the
    // meter and each instrument on first use). Every create* returns a recorder
    // keyed by the metric name, so the observation is instrument-agnostic.
    vi.spyOn(metrics, 'getMeter').mockReturnValue({
      createCounter: (name) => instrumentFor(name),
      createUpDownCounter: (name) => instrumentFor(name),
      createGauge: (name) => instrumentFor(name),
      createHistogram: (name) => instrumentFor(name),
      createObservableGauge: (name) => observableFor(name),
      createObservableCounter: (name) => observableFor(name),
      createObservableUpDownCounter: (name) => observableFor(name),
    });

    // Stub the re-entrant loop's durable collaborators so execBatchJob runs
    // `entryCount` entries in process.

    // Run the authenticated-context callback directly (no repo/redis/login setup).
    vi.spyOn(contextModule, 'runInAuthenticatedContext').mockImplementation(
      async (_authState, _requestId, _traceId, _options, fn) => fn()
    );

    // A system repo whose AsyncJob read is always active (so the loop proceeds) and
    // whose clone() is itself (AsyncJobExecutor's constructor clones it).
    const fakeSystemRepo = {
      readResource: vi.fn().mockImplementation(async (_type, id) => ({
        resourceType: 'AsyncJob',
        id,
        status: 'accepted',
      })),
      clone() {
        return fakeSystemRepo;
      },
    };
    vi.spyOn(repoModule, 'getShardSystemRepo').mockReturnValue(fakeSystemRepo);

    // The submitting user's repo is only used to assemble/upload the result binary.
    const fakeUserRepo = {
      clone() {
        return fakeUserRepo;
      },
    };
    vi.spyOn(meModule, 'getUserConfiguration').mockResolvedValue({});
    vi.spyOn(accessPolicyModule, 'getRepoForLogin').mockResolvedValue(fakeUserRepo);
    vi.spyOn(binaryModule, 'uploadBinaryData').mockResolvedValue({ resourceType: 'Binary', id: 'verify-binary' });

    // Durable checkpoint store: all reads/writes are no-ops; assembly reads back no
    // chunks (results come from this run's memory, which we leave empty).
    vi.spyOn(BatchCheckpointStore.prototype, 'loadInputBundle').mockImplementation(async () => ({
      resourceType: 'Bundle',
      type: 'batch',
      entry: Array.from({ length: entryCount }, () => ({
        request: { method: 'POST', url: 'Patient' },
        resource: { resourceType: 'Patient' },
      })),
    }));
    vi.spyOn(BatchCheckpointStore.prototype, 'saveInitialState').mockResolvedValue(undefined);
    vi.spyOn(BatchCheckpointStore.prototype, 'loadInitialState').mockResolvedValue(undefined);
    vi.spyOn(BatchCheckpointStore.prototype, 'saveResultChunk').mockResolvedValue(undefined);
    vi.spyOn(BatchCheckpointStore.prototype, 'loadAllResults').mockResolvedValue({});
    vi.spyOn(BatchCheckpointStore.prototype, 'cleanup').mockResolvedValue(undefined);

    // The AsyncJob is completed/failed through the executor; make those no-ops.
    vi.spyOn(AsyncJobExecutor.prototype, 'completeJob').mockResolvedValue(undefined);
    vi.spyOn(AsyncJobExecutor.prototype, 'failJob').mockResolvedValue(undefined);

    // Drive the real re-entrant processor over exactly `entryCount` entries without
    // a live FHIR router / Postgres: preprocess yields an initial state with an
    // `entryCount`-entry bundle, and the one-at-a-time cursor advances that many times.
    let processed = 0;
    vi.spyOn(BatchProcessor.prototype, 'preprocess').mockImplementation(async () => {
      processed = 0;
      return {
        bundle: {
          resourceType: 'Bundle',
          type: 'batch',
          entry: Array.from({ length: entryCount }, () => ({})),
        },
        bundleInfo: {},
        resolvedIdentities: Object.create(null),
        preprocessResults: Object.create(null),
      };
    });
    vi.spyOn(BatchProcessor.prototype, 'hasMoreEntries').mockImplementation(() => processed < entryCount);
    vi.spyOn(BatchProcessor.prototype, 'processNextEntry').mockImplementation(async () => {
      processed++;
    });
    vi.spyOn(BatchProcessor.prototype, 'getPosition').mockImplementation(() => processed);
    vi.spyOn(BatchProcessor.prototype, 'takePendingResults').mockImplementation(() => null);

    processor = captureBatchProcessor(config);
  });

  afterAll(() => {
    vi.restoreAllMocks();
  });

  test('the batch queue keeps a running total of bundle entries processed across jobs', async () => {
    recordsByName.clear();
    observableCallbacks.clear();

    for (const [i, count] of JOB_ENTRY_COUNTS.entries()) {
      entryCount = count;
      // A re-entrant batch job (ReentrantBatchJobData: has asyncJobId, no asyncJob).
      // Checkpoint thresholds are pushed out of reach so the only checkpoint is the
      // final one, keeping the in-process run deterministic.
      const job = {
        id: `verify-batch-job-${i}`,
        name: 'BatchJobData',
        queueName: 'BatchQueue',
        token: 'verify-token',
        data: {
          asyncJobId: `verify-async-job-${i}`,
          authState: { login: { id: 'l' }, project: { id: 'p' }, membership: { id: 'm' } },
          checkpointEntries: count + 1000,
          checkpointIntervalMs: 3_600_000,
        },
        async updateData(newData) {
          this.data = newData;
        },
        moveToDelayed: vi.fn().mockResolvedValue(undefined),
      };

      // The job completes normally (a throw here fails the test).
      await processor(job, 'verify-token', new AbortController().signal);
      pollObservables();

      // A metric whose name carries both the batch queue and the entry token
      // (the per-queue job metrics carry 'batch' but not 'entr').
      const { names, total } = entryTotal();
      expect(names.length).toBeGreaterThan(0);
      expect(total).toBe(RUNNING_TOTALS[i]);
    }
  });
});
