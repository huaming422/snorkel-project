// @ts-nocheck
// SPDX-License-Identifier: Apache-2.0
//
// Processor arity: the processor each worker hands to BullMQ still declares at
// least three parameters (job, token, abort signal). BullMQ reads
// `processor.length >= 3` to decide whether to construct and pass an abort
// signal, so a two-parameter (or rest-parameter, length 0) layer in front of the
// job code means the signal is never supplied.
//
// Interface under test: the existing exported worker initializers
// (`init<Name>Worker(config, options?)`). `bullmq` is globally mocked by the server
// package's `test.setup.ts` (`Worker` is a `vi.fn()`), so the processor the
// initializer handed to `new Worker(...)` is recoverable from the mock's call
// record, with no Redis, no Postgres and no live job execution.

import { Worker } from 'bullmq';
import { vi } from 'vitest';
import { loadTestConfig } from './config/loader';
import { initBatchWorker } from './workers/batch';
import { initCronWorker } from './workers/cron';
import { initDataWarehouseSyncWorker } from './workers/data-warehouse-sync';
import { initDispatchWorker } from './workers/dispatch';
import { initDownloadWorker } from './workers/download';
import { initLambdaCleanerWorker } from './workers/lambda-cleaner';
import { initSetAccountsWorker } from './workers/set-accounts';
import { initSubscriptionWorker } from './workers/subscription';

// The eight listed worker queues.
const LISTED_WORKERS = [
  { token: 'dispatch', init: initDispatchWorker },
  { token: 'subscription', init: initSubscriptionWorker },
  { token: 'download', init: initDownloadWorker },
  { token: 'cron', init: initCronWorker },
  { token: 'batch', init: initBatchWorker },
  { token: 'set-accounts', init: initSetAccountsWorker },
  { token: 'lambda-cleaner', init: initLambdaCleanerWorker },
  { token: 'data-warehouse-sync', init: initDataWarehouseSyncWorker },
];

// The recording helpers are no-ops unless a metrics endpoint is configured; set it
// so any instrumentation is live while the workers are built.
process.env.OTLP_METRICS_ENDPOINT = 'http://localhost:4318/v1/metrics';

/** The processor function the initializer passed as `new Worker(queueName, processor, opts)`. */
function captureProcessor(init, config) {
  const before = vi.mocked(Worker).mock.calls.length;
  init(config, { workerEnabled: true });
  const calls = vi.mocked(Worker).mock.calls;
  if (calls.length <= before) {
    throw new Error('worker initializer did not construct a Worker');
  }
  // new Worker(queueName, processor, opts) - processor is the second argument.
  return calls[calls.length - 1][1];
}

describe('queue job metrics - processor arity', () => {
  let config;
  let cronProcessor;

  beforeAll(async () => {
    config = await loadTestConfig();
    // The data-warehouse-sync worker only constructs its Worker when its sync
    // feature is configured; a local destination keeps construction in process.
    // Every other worker ignores this field.
    config.dataWarehouse = {
      enabled: true,
      cron: '0 0 * * *',
      destination: 'local',
      localBasePath: '/tmp/dw-verify-arity',
    };
    cronProcessor = captureProcessor(initCronWorker, config);
  });

  test('the worker processor declares at least three parameters', () => {
    expect(typeof cronProcessor).toBe('function');
    // BullMQ's own threshold for supplying the abort signal.
    expect(cronProcessor.length).toBeGreaterThanOrEqual(3);
  });

  test('arity holds for every listed worker', () => {
    const arities = Object.fromEntries(
      LISTED_WORKERS.map(({ token, init }) => [token, captureProcessor(init, config).length >= 3])
    );
    expect(arities).toStrictEqual(Object.fromEntries(LISTED_WORKERS.map(({ token }) => [token, true])));
  });
});
