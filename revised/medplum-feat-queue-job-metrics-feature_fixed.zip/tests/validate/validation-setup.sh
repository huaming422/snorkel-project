#!/usr/bin/env bash
# validation-setup.sh - environment bootstrap for the test runner.
#
# Mirrors tests/test-setup.sh: dependencies are baked into the image, so this
# only restores node_modules if user changes removed it, offline-first with a
# logged online fallback. The validation specs are pure vitest unit tests (bullmq
# is globally mocked in src/__mocks__/bullmq.ts and the DB pool is stubbed), so
# NO Postgres or Redis is required.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/medplum}"
cd "$REPO_DIR"

# Keep the task's own npm offline; the Dockerfile warmed /root/.npm at build.
export npm_config_cache=/root/.npm

node --version
npm --version

# Restore workspace deps only if user changes removed them (no-op otherwise).
if [ ! -d "node_modules" ] || [ ! -d "packages/server/node_modules" ]; then
    echo "[validation-setup] node_modules missing - restoring with npm ci (offline)..."
    { npm ci --no-audit --no-fund --offline > /tmp/npm-ci-validate.log 2>&1 \
        && echo "[offline-first] npm ci satisfied from image cache"; } \
      || { echo "[validation-setup] offline npm ci failed; retrying online"; npm ci --no-audit --no-fund; }
fi

export PATH="$REPO_DIR/node_modules/.bin:$PATH"

# Loud smoke guard: vitest must be runnable, or every story would fail opaquely.
if ! npx --no-install vitest --version > /tmp/vitest-version.log 2>&1; then
    echo "[validation-setup] FATAL: vitest not runnable in packages/server" >&2
    tail -40 /tmp/vitest-version.log >&2 || true
    exit 1
fi

echo "[validation-setup] ready: $REPO_DIR (node=$(node --version), npm=$(npm --version), vitest=$(cat /tmp/vitest-version.log))"
