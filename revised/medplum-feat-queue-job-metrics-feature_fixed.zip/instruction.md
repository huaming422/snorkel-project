## Task

Operators can see that our background job queues exist, but not how busy each one is or how much work a given server process gets through.
Add per-queue telemetry for that on top of the job system we already run.
Export raw counts only, and don't work out rates here, since the backend can do that.

The worker-side numbers below cover the dispatch, subscription, download, cron, batch, set-accounts, lambda-cleaner and data-warehouse-sync workers.
Reindex and post-deploy migration can stay as they are.
Every new per-queue series carries its queue in the metric name, the way the existing waiting and delayed counts already do.

Keep job cancellation possible on every listed worker.
Whatever you add around our job code, BullMQ still has to be willing to pass each job's abort signal through to it, so we can wire cancellation up later.

The batch queue also gets its own entries metric, a running total of bundle entries processed by async batch jobs on the re-entrant path.
Jobs that still go through the older single-pass path don't have to count toward it.

The queue-health heartbeat should keep reading the same five queues it reads today (subscription, cron, download, batch, set-accounts) and keep publishing their waiting and delayed counts as it does now.
Don't add queues to it or drop any.

## User stories / requirements

- For each listed worker queue, the server reports how many jobs this process has in flight. The count goes up when a job starts and back down when it settles, whether the job succeeds, throws, or is handed back for a later attempt, so an idle queue reads zero.
- For each listed worker queue, the server keeps a running count of jobs whose work finished normally. A job that throws, or that is deferred to a later attempt, does not move this count.
- On each heartbeat, the queue-health telemetry reports how many jobs the broker considers active for every queue it already covers, next to the existing waiting and delayed counts and named the same way.
