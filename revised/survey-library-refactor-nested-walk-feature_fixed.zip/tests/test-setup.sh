#!/usr/bin/env bash
# test-setup.sh: environment bootstrap for the verifier. Sourced by
# tests/test.sh (not exec'd) under its `set -euo pipefail`, so exports stay
# alive for vitest. Idempotent: the install guard below only does work if
# node_modules was removed from the checkout.
#
# Dependencies are baked into the image (the survey-core dependency tree,
# vitest included), so the normal path is a no-op. It has to work offline
# against that bake; the online branch is a logged fallback only.

cd /repo/survey-library/packages/survey-core

# Cut the network path by default so a cache miss fails fast instead of
# reaching a registry.
export npm_config_offline=true

node --version
npm --version

# Dependencies: offline-first against the image bake, logged online fallback.
if [ -d node_modules/.bin ] && [ -x node_modules/.bin/vitest ]; then
    echo "[offline-first] deps already present from image bake"
elif npm ci --offline --prefer-offline > /tmp/test-setup-install.log 2>&1; then
    echo "[offline-first] deps satisfied from image cache"
elif { unset npm_config_offline; npm ci >> /tmp/test-setup-install.log 2>&1; }; then
    echo "[test-setup] deps installed online (image bake was stale)"
else
    tail -40 /tmp/test-setup-install.log >&2; exit 1
fi

export PATH="/repo/survey-library/packages/survey-core/node_modules/.bin:$PATH"

echo "[test-setup] ready: $(pwd) (node=$(node --version), npm=$(npm --version))"
