## Task

In survey-core, each container question has its own code for walking the elements nested inside it.
That goes for the matrices, dynamic panels, multiple text, custom and composite questions, and checkbox or radiogroup questions whose choices carry panels.
Right now the data check in `setData` and the cleanup in `clearIncorrectValues(true)` get into matrix cells and dynamic panel items, but not into choice panels, and the cleanup also skips custom and composite content.
We'd prefer this fixed by giving those types one shared walk, rather than adding yet another copy per type.

## User stories / requirements

- setData reports bad answers held in a checkbox or radiogroup choice panel like top-level ones, at the top-level keys its questions write to, and clearIncorrectValues(true) removes them. This holds whether or not the panel's choice is selected, and for a select inside a dynamic panel item, which still flags those keys as unknown.
- clearIncorrectValues(true) removes a bad answer held inside a custom question's content or a composite question's content panel, which setData reports at the answer's path in the data, and keeps the valid parts of the value.
- When the survey is completed, questions in the panel of an unselected choice lose their answers like any hidden question, whether the answer came in with the data or was typed before the choice was unselected. A selected choice's panel keeps its answers, and clearInvisibleValues set to "none" keeps everything.
