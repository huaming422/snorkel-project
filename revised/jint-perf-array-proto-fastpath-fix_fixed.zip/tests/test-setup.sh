#!/usr/bin/env bash
# Verifier-time setup for jint-perf-array-proto-fastpath.
#
# The full dependency closure is baked into the image at the base commit:
# the .NET 10 SDK lives at /opt/dotnet, the NuGet package cache is warm at
# /opt/cache/nuget (NUGET_PACKAGES), and Jint.Tests was restored + built for
# net10.0 in the clone layer. The agent phase runs offline (agent_offline=true),
# so everything needed to `dotnet build`/`dotnet test` the engine is already on
# disk. This step therefore only needs to make the toolchain reachable and
# confirm an offline restore still resolves; it does NOT pull from the network.
set -euo pipefail

export DOTNET_ROOT="${DOTNET_ROOT:-/opt/dotnet}"
export PATH="/opt/dotnet:${PATH}"
export NUGET_PACKAGES="${NUGET_PACKAGES:-/opt/cache/nuget}"
export DOTNET_CLI_TELEMETRY_OPTOUT=1
export DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1
export DOTNET_NOLOGO=1

echo "[test-setup] dotnet: $(dotnet --version)"

# Warm/confirm the restore from the baked cache without touching the network.
# NuGetAudit=false disables vulnerability-database fetches that require network
# even when all packages are already in NUGET_PACKAGES (the baked local cache).
# Offline-first; if (and only if) something is genuinely missing and the
# verifier phase has network, fall back to a normal restore and log it loudly.
if dotnet restore Jint.slnx --no-http-cache -p:NuGetAudit=false > /tmp/test-setup-restore.log 2>&1; then
  echo "[test-setup] offline restore OK (warm cache)"
else
  echo "[test-setup] offline restore incomplete; attempting online fallback" >&2
  tail -40 /tmp/test-setup-restore.log >&2 || true
  dotnet restore Jint.slnx -p:NuGetAudit=false > /tmp/test-setup-restore-online.log 2>&1 \
    || { tail -60 /tmp/test-setup-restore-online.log >&2; exit 1; }
fi

echo "[test-setup] ready for jint-perf-array-proto-fastpath"
