## Task

Array-heavy scripts in Jint allocate far more than they should, and a few array cases give wrong keys or values.

I measured with `GC.GetAllocatedBytesForCurrentThread()` around one `Engine.Evaluate` of a prepared script, after five warm-up runs of the same script.
All arrays below use the stock prototype:

- 200 `for (k in arr)` loops over a packed 1,000-element array: about 1.66 MB.
- The same 200 loops over a 1,000-slot array that only fills every 4th slot: about 1.66 MB.
- 20 passes of `holey[i] | 0` over an 8,000-slot array where three of every four slots are holes: about 7.2 MB.
- The same 20 passes with `i in holey` instead: about 7.2 MB.
- 200 for-in loops over a sparse array with 250 values spread between index 1,000,000 and about 26,000,000: about 4 MB.

Each of these should land in the low kilobytes, and anything over 200 KB per evaluation is still a bug.

Wrong results we hit:

- Enumerable indexes added to `Array.prototype` are missing from for-in:

```js
Array.prototype[5] = 'inherited';
Array.prototype[1] = 'shadowed';
var out = [];
for (var k in [10, 20]) out.push(k);
out.join(',');   // "0,1", expected "0,1,5"
```

- It also happens when the loop already ran a few times before the index was added to `Array.prototype`.
- for-in over a sparse array lists indexes in the order they were assigned, not in ascending numeric order.
  After `a[4000000000] = 4; a[3] = 3; a[1000000] = 1;` we get `4000000000,3,1000000` instead of `3,1000000,4000000000`.
  The same thing shows up when the sparse array has a custom prototype with its own keys.
- With a Proxy as the array's prototype, reading a hole skips the proxy's `get` trap:

```js
var log = [];
var p = new Proxy({1: 'target'}, {
  get: function (t, k, r) { log.push(k + ':' + r.marker); return r.marker; }
});
var a = ['own']; a.marker = 'array'; Object.setPrototypeOf(a, p);
a[1];             // "target", expected "array"
log.join(',');    // "", expected "1:array"
```

Everything else has to keep working as it does now.
That includes key order and snapshot rules when the array changes in the middle of a loop, nested and interleaved loops, own and inherited accessors, `in` checks that never call a getter, and `Reflect.get` receivers.
Array methods over a Proxy prototype must keep calling `has` before `get`, trap exceptions must still reach the script, and a revoked proxy prototype must still throw only for inherited lookups.
