package schema

// Checks for opening a database through MigrateUp when one of its aux tables
// holds rows the storage engine cannot decode.
//
// They run the public MigrateUp entry point, the one every open uses, against a
// real embedded Dolt database in a temp dir. The connection goes through a thin
// driver wrapper: while a table is marked unreadable, any query that reads that
// table's text cells (a SELECT of a text column or *, or a dolt_diff /
// dolt_history read of the table) fails with the engine's "invalid hash length"
// error, the way corrupted storage fails. Writes and every other read go to the
// engine unchanged. COUNT(*) and information_schema probes are not affected,
// since they decode no text cell.
//
// The first open of each check upgrades a fresh database with the table already
// unreadable. User data and a configured custom issue type are then committed,
// so the next open has upgrade work to do (the custom-type backfill) and runs
// the whole pass. That later open is the one each check looks at. The checks
// read only the database: the error MigrateUp returns, what HEAD holds, and
// what stays in the working set.

import (
	"context"
	"database/sql"
	"database/sql/driver"
	"errors"
	"net/url"
	"regexp"
	"strings"
	"sync"
	"testing"

	doltembed "github.com/dolthub/driver/v2"
)

const vmuDatabase = "vmu_beads"

// vmuCustomType is the custom issue type committed to config before the later
// open. Its backfill into custom_types is the upgrade work that open commits.
const vmuCustomType = "vmu_review"

// vmuTextColumns lists, for each committed aux table, the text columns whose
// cells the decode failure hits.
var vmuTextColumns = map[string][]string{
	"comments":             {"text"},
	"issue_snapshots":      {"original_content", "archived_events"},
	"compaction_snapshots": {"snapshot_json"},
}

// ---------------------------------------------------------------------------
// Unreadable-table driver wrapper
// ---------------------------------------------------------------------------

// vmuStorage holds which table currently cannot be decoded, if any.
type vmuStorage struct {
	mu    sync.Mutex
	table string
	err   error
}

func (s *vmuStorage) markUnreadable(table string, err error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.table, s.err = table, err
}

func (s *vmuStorage) repair() { s.markUnreadable("", nil) }

var vmuSpace = regexp.MustCompile(`\s+`)

// readErr returns the decode error when query reads text cells of the
// unreadable table, and nil otherwise.
func (s *vmuStorage) readErr(query string) error {
	s.mu.Lock()
	table, err := s.table, s.err
	s.mu.Unlock()
	if table == "" {
		return nil
	}
	q := strings.ToLower(vmuSpace.ReplaceAllString(query, " "))
	if strings.Contains(q, "information_schema") {
		return nil
	}
	// Diff and history reads decode the rows on both sides of the diff.
	if (strings.Contains(q, "dolt_diff(") || strings.Contains(q, "dolt_patch(")) &&
		strings.Contains(q, "'"+table+"'") {
		return err
	}
	if regexp.MustCompile(`\bdolt_(?:diff|history|commit_diff)_` + table + `\b`).MatchString(q) {
		return err
	}
	// A row read of the table itself fails when it selects a text column or *.
	from := regexp.MustCompile("\\b(?:from|join) `?" + table + "`?(?:[\\s,;)]|$)").FindStringIndex(q)
	if from == nil {
		return nil
	}
	head := q[:from[0]]
	i := strings.LastIndex(head, "select ")
	if i < 0 {
		return nil
	}
	selected := strings.ReplaceAll(head[i+len("select "):], "count(*)", "")
	if strings.Contains(selected, "*") {
		return err
	}
	for _, col := range vmuTextColumns[table] {
		if regexp.MustCompile(`\b` + col + `\b`).MatchString(selected) {
			return err
		}
	}
	return nil
}

type vmuConnector struct {
	inner   driver.Connector
	storage *vmuStorage
}

func (c vmuConnector) Connect(ctx context.Context) (driver.Conn, error) {
	conn, err := c.inner.Connect(ctx)
	if err != nil {
		return nil, err
	}
	return &vmuConn{inner: conn, storage: c.storage}, nil
}

func (c vmuConnector) Driver() driver.Driver { return c.inner.Driver() }

type vmuConn struct {
	inner   driver.Conn
	storage *vmuStorage
}

func (c *vmuConn) Prepare(query string) (driver.Stmt, error) {
	return c.PrepareContext(context.Background(), query)
}

func (c *vmuConn) PrepareContext(ctx context.Context, query string) (driver.Stmt, error) {
	if err := c.storage.readErr(query); err != nil {
		return nil, err
	}
	if p, ok := c.inner.(driver.ConnPrepareContext); ok {
		return p.PrepareContext(ctx, query)
	}
	return c.inner.Prepare(query)
}

func (c *vmuConn) QueryContext(ctx context.Context, query string, args []driver.NamedValue) (driver.Rows, error) {
	if err := c.storage.readErr(query); err != nil {
		return nil, err
	}
	q, ok := c.inner.(driver.QueryerContext)
	if !ok {
		return nil, driver.ErrSkip
	}
	return q.QueryContext(ctx, query, args)
}

func (c *vmuConn) ExecContext(ctx context.Context, query string, args []driver.NamedValue) (driver.Result, error) {
	e, ok := c.inner.(driver.ExecerContext)
	if !ok {
		return nil, driver.ErrSkip
	}
	return e.ExecContext(ctx, query, args)
}

func (c *vmuConn) Begin() (driver.Tx, error) {
	return c.BeginTx(context.Background(), driver.TxOptions{})
}

func (c *vmuConn) BeginTx(ctx context.Context, opts driver.TxOptions) (driver.Tx, error) {
	if b, ok := c.inner.(driver.ConnBeginTx); ok {
		return b.BeginTx(ctx, opts)
	}
	return c.inner.Begin() //nolint:staticcheck // fallback for drivers without BeginTx
}

func (c *vmuConn) Close() error { return c.inner.Close() }

func (c *vmuConn) Ping(ctx context.Context) error {
	if p, ok := c.inner.(driver.Pinger); ok {
		return p.Ping(ctx)
	}
	return nil
}

func (c *vmuConn) ResetSession(ctx context.Context) error {
	if r, ok := c.inner.(driver.SessionResetter); ok {
		return r.ResetSession(ctx)
	}
	return nil
}

func (c *vmuConn) IsValid() bool {
	if v, ok := c.inner.(driver.Validator); ok {
		return v.IsValid()
	}
	return true
}

// ---------------------------------------------------------------------------
// Embedded store
// ---------------------------------------------------------------------------

// vmuStore is one embedded database that a check opens several times, the way
// separate bd commands would.
type vmuStore struct {
	t       *testing.T
	dir     string
	storage *vmuStorage
}

func vmuNewStore(t *testing.T) *vmuStore {
	t.Helper()
	s := &vmuStore{t: t, dir: t.TempDir(), storage: &vmuStorage{}}
	conn, closeConn := s.open("", &vmuStorage{})
	defer closeConn()
	if _, err := conn.ExecContext(context.Background(), "CREATE DATABASE IF NOT EXISTS "+vmuDatabase); err != nil {
		t.Fatalf("create database: %v", err)
	}
	return s
}

// open returns one pinned connection, as a bd command uses for its open.
func (s *vmuStore) open(database string, storage *vmuStorage) (*sql.Conn, func()) {
	s.t.Helper()
	v := url.Values{}
	v.Set(doltembed.CommitNameParam, "beads")
	v.Set(doltembed.CommitEmailParam, "beads@local")
	v.Set(doltembed.MultiStatementsParam, "true")
	if database != "" {
		v.Set(doltembed.DatabaseParam, database)
	}
	cfg, err := doltembed.ParseDSN("file://" + s.dir + "?" + v.Encode())
	if err != nil {
		s.t.Fatalf("parse dsn: %v", err)
	}
	connector, err := doltembed.NewConnector(cfg)
	if err != nil {
		s.t.Fatalf("new connector: %v", err)
	}
	db := sql.OpenDB(vmuConnector{inner: connector, storage: storage})
	conn, err := db.Conn(context.Background())
	if err != nil {
		_ = db.Close()
		_ = connector.Close()
		s.t.Fatalf("pin connection: %v", err)
	}
	return conn, func() {
		_ = conn.Close()
		_ = db.Close()
		if err := connector.Close(); err != nil && !errors.Is(err, context.Canceled) {
			s.t.Logf("close connector: %v", err)
		}
	}
}

// migrate opens the database with the store's current storage state and runs
// MigrateUp, as every bd open does.
func (s *vmuStore) migrate() error {
	s.t.Helper()
	conn, closeConn := s.open(vmuDatabase, s.storage)
	defer closeConn()
	_, err := MigrateUp(context.Background(), conn)
	return err
}

// exec runs statements on a separate open whose storage reads cleanly.
func (s *vmuStore) exec(stmts ...string) {
	s.t.Helper()
	conn, closeConn := s.open(vmuDatabase, &vmuStorage{})
	defer closeConn()
	for _, stmt := range stmts {
		if _, err := conn.ExecContext(context.Background(), stmt); err != nil {
			s.t.Fatalf("%s: %v", stmt, err)
		}
	}
}

// count runs a COUNT query on a separate open whose storage reads cleanly.
func (s *vmuStore) count(query string, args ...any) int {
	s.t.Helper()
	conn, closeConn := s.open(vmuDatabase, &vmuStorage{})
	defer closeConn()
	var n int
	if err := conn.QueryRowContext(context.Background(), query, args...).Scan(&n); err != nil {
		s.t.Fatalf("%s: %v", query, err)
	}
	return n
}

// ---------------------------------------------------------------------------
// Shared setup
// ---------------------------------------------------------------------------

// vmuUserRow is one uncommitted user edit to an aux table, identified by its
// text so it can be found again whatever id it ends up with.
type vmuUserRow struct {
	insert string
	match  string
	arg    string
}

func vmuRowFor(table, marker string) vmuUserRow {
	switch table {
	case "comments":
		return vmuUserRow{
			insert: "INSERT INTO comments (id, issue_id, author, text) VALUES ('0b9f6c1e-vmu-" + marker + "', 'vmu-1', 'dana', 'note " + marker + "')",
			match:  "issue_id = 'vmu-1' AND text = ?",
			arg:    "note " + marker,
		}
	case "issue_snapshots":
		return vmuUserRow{
			insert: "INSERT INTO issue_snapshots (id, issue_id, snapshot_time, compaction_level, original_size, compressed_size, original_content, archived_events) VALUES ('4c2a7d90-vmu-" + marker + "', 'vmu-1', '2026-08-01 10:00:00', 1, 10, 5, 'snapshot " + marker + "', '[]')",
			match:  "issue_id = 'vmu-1' AND original_content = ?",
			arg:    "snapshot " + marker,
		}
	case "compaction_snapshots":
		return vmuUserRow{
			insert: "INSERT INTO compaction_snapshots (id, issue_id, compaction_level, snapshot_json) VALUES ('9e15b3f2-vmu-" + marker + "', 'vmu-1', 1, '{\"m\":\"" + marker + "\"}')",
			match:  "issue_id = 'vmu-1' AND snapshot_json = ?",
			arg:    "{\"m\":\"" + marker + "\"}",
		}
	}
	panic("vmu: no user row for " + table)
}

// vmuAfterSkippedUpgrade returns a store whose first upgrade ran while table
// could not be decoded, and which has more upgrade work pending: an issue and a
// custom issue type are committed after that first open. table is still
// unreadable when it returns.
func vmuAfterSkippedUpgrade(t *testing.T, table string, decodeErr error) *vmuStore {
	t.Helper()
	s := vmuNewStore(t)
	s.storage.markUnreadable(table, decodeErr)
	if err := s.migrate(); err != nil {
		t.Fatalf("first open with %s unreadable must succeed, got: %v", table, err)
	}
	s.exec(
		"INSERT INTO issues (id, title, description, design, acceptance_criteria, notes, status, priority, issue_type) "+
			"VALUES ('vmu-1', 'first issue', '', '', '', '', 'open', 2, 'task')",
		"REPLACE INTO config (`key`, value) VALUES ('types.custom', '"+vmuCustomType+"')",
		"CALL DOLT_COMMIT('-Am', 'user: add issue and custom type')",
	)
	return s
}

// vmuCommittedPass checks that the later open committed its upgrade work: the
// configured custom type is in HEAD.
func vmuCommittedPass(t *testing.T, s *vmuStore) {
	t.Helper()
	if n := s.count("SELECT COUNT(*) FROM custom_types AS OF 'HEAD' WHERE name = ?", vmuCustomType); n != 1 {
		t.Fatalf("the later open did not commit its upgrade work: custom type %q is in HEAD %d times, want 1", vmuCustomType, n)
	}
}

// ---------------------------------------------------------------------------
// Checks
// ---------------------------------------------------------------------------

// TestVerifyMigrateUpReopensWithDirtyUnreadableTable: after an upgrade that ran
// into an unreadable aux table, a later open that has upgrade work to do
// succeeds even when the user has uncommitted edits in that table. This holds
// while the table is still unreadable and after its storage has been repaired,
// and the user's edit is still there afterwards.
func TestVerifyMigrateUpReopensWithDirtyUnreadableTable(t *testing.T) {
	cases := []struct {
		name     string
		table    string
		err      error
		repaired bool
	}{
		{"comments_still_unreadable", "comments",
			errors.New("Error 1105 (HY000): panic recovered: invalid hash length: 19"), false},
		{"compaction_snapshots_still_unreadable", "compaction_snapshots",
			errors.New("invalid hash length: 1"), false},
		{"comments_repaired", "comments",
			errors.New("panic recovered: invalid hash length: 19"), true},
		{"issue_snapshots_repaired", "issue_snapshots",
			errors.New("Error 1105 (HY000): panic recovered: invalid hash length: 1"), true},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			s := vmuAfterSkippedUpgrade(t, c.table, c.err)
			row := vmuRowFor(c.table, "dirty")
			s.exec(row.insert)
			if c.repaired {
				s.storage.repair()
			}

			if err := s.migrate(); err != nil {
				t.Fatalf("later open with uncommitted edits in %s must succeed, got: %v", c.table, err)
			}
			vmuCommittedPass(t, s)
			if n := s.count("SELECT COUNT(*) FROM "+c.table+" WHERE "+row.match, row.arg); n != 1 {
				t.Fatalf("the user's edit to %s is present %d times after the open, want 1", c.table, n)
			}
		})
	}
}

// TestVerifyMigrateUpKeepsOtherUncommittedEdits: on that later open, uncommitted
// user edits in a different aux table, one that read fine all along, stay
// uncommitted. They are not part of the commit the open makes, and they are
// still in the working set afterwards.
func TestVerifyMigrateUpKeepsOtherUncommittedEdits(t *testing.T) {
	cases := []struct {
		name     string
		table    string
		other    string
		err      error
		repaired bool
	}{
		{"comments_unreadable_issue_snapshots_edited", "comments", "issue_snapshots",
			errors.New("Error 1105 (HY000): panic recovered: invalid hash length: 19"), false},
		{"compaction_snapshots_repaired_comments_edited", "compaction_snapshots", "comments",
			errors.New("panic recovered: invalid hash length: 1"), true},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			s := vmuAfterSkippedUpgrade(t, c.table, c.err)
			row := vmuRowFor(c.other, "pending")
			s.exec(row.insert)
			if c.repaired {
				s.storage.repair()
			}

			if err := s.migrate(); err != nil {
				t.Fatalf("later open must succeed, got: %v", err)
			}
			vmuCommittedPass(t, s)
			if n := s.count("SELECT COUNT(*) FROM "+c.other+" AS OF 'HEAD' WHERE "+row.match, row.arg); n != 0 {
				t.Fatalf("the user's uncommitted edit to %s was committed by the open (found %d in HEAD), want it left uncommitted", c.other, n)
			}
			if n := s.count("SELECT COUNT(*) FROM "+c.other+" WHERE "+row.match, row.arg); n != 1 {
				t.Fatalf("the user's uncommitted edit to %s is present %d times in the working set, want 1", c.other, n)
			}
			if n := s.count("SELECT COUNT(*) FROM dolt_status WHERE table_name = ?", c.other); n == 0 {
				t.Fatalf("%s no longer shows as changed in the working set, want the user's edit still pending", c.other)
			}
		})
	}
}
