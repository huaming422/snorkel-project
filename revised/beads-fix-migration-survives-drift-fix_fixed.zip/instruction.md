## Task

Since the latest CLI upgrade, some users can't get into their existing database at all.
Every bd command they run crashes on open with an invalid hash length panic from the storage engine.
It happens on every start, so no command gets them back in.
Their databases opened fine on the previous version.
It's not everyone, since most databases upgrade and open with no trouble.
Please fix it so the affected databases open again.
