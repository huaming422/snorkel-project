## Task

Since the latest CLI upgrade, some users can't get into their existing database at all.
Any bd command they run panics inside the storage engine right as it starts, before doing any work, and exits with an error that ends like this:

```
Error 1105 (HY000): panic recovered: invalid hash length: 19
```

On one user's machine the number at the end is 1 instead of 19.
It happens on every start, so no command gets them back in.
Their databases opened fine on the previous version.
It's not everyone, since most databases upgrade and open with no trouble.
Please fix it so the affected databases open again.
