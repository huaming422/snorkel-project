## Task

Since the latest CLI upgrade, some users can't open their database at all.
Every bd command fails right at startup, before it does any work.
It happens on every start, so they have no way back in.
It only hits some older databases, and fresh ones upgrade and open fine.

This is what people pasted from their terminals:

```
Error 1105 (HY000): panic recovered: invalid hash length: 19
Error 1105 (HY000): panic recovered: invalid hash length: 1
panic: invalid hash length: 19
```

Please get these databases opening again.
Upgrade errors that have nothing to do with this, like a duplicate key or a different engine panic, should still fail the way they do today.
Users can repair the storage with Dolt separately.
When they upgrade again after that, their databases should end up consistent with their teammates' clones and not diverge any further.
