## Task

Since the latest CLI upgrade, some users can't open their database at all.
Every bd command fails right at startup, before it does any work, with a panic from the storage engine that says `invalid hash length`.
It happens on every start, so they have no way back in.
Clean databases upgrade and open fine.
The broken ones all seem to carry some low-level encoding inconsistency in how their history and comments data sits on disk.
Repairing those rows takes Dolt's own tooling.
bd can't do it, so it has to cope with storage it can't read.

Please get these databases opening again.
The error text isn't always the same.
We've seen `invalid hash length: 19` on reads and `invalid hash length: 1` elsewhere, and it doesn't always come wrapped in the engine's `panic recovered:` prefix.
Any other failure during the upgrade, whether a duplicate key or an unrelated panic, should still stop it like it does today.
Those are migration bugs we need to see.
Whatever the upgrade has to leave undone on an unreadable table can't stay undone forever, though.
Once someone repairs the storage, a later upgrade run should go back and finish that work on those tables, and only on those.
Tables that already went through should be left alone.
