## Task

Since the latest CLI upgrade, some users can't open their database at all.
Every bd command they run fails with this:

```
Error 1105 (HY000): panic recovered: invalid hash length: 19
```

Most people upgraded without any trouble.
Can you get the affected users working again?
