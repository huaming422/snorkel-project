## Task

Since the latest CLI upgrade, some users can't get into their existing database at all.
Every bd command they run crashes with an `invalid hash length` panic from the storage engine, and they're locked out completely.
Their databases opened fine on the previous version.
It's not everyone.
Please fix it so the affected databases open again.
