## Task

Since the latest CLI upgrade, some users can't get into their existing database at all.
Every bd command they run crashes at startup with a panic from the storage engine, raised while it reads stored data it can't decode.
Their databases opened fine on the previous version.
It's not everyone.
Please fix it so the affected databases open again.
Uncommitted edits in unrelated tables should stay uncommitted.
