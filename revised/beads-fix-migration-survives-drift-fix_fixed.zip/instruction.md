## Task

Since the latest CLI upgrade, some users can't open their existing database anymore.
Every bd command they run against it fails with an error.
It's not everyone.
This needs a fix.
