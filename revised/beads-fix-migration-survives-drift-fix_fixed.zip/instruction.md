## Task

Since the latest CLI upgrade, some users can't open their database at all.
Every bd command fails at startup, on every run, before it does any work.
Most people upgraded without any trouble.

This is what the stuck users pasted from their terminals:

```
Error 1105 (HY000): panic recovered: invalid hash length: 19
Error 1105 (HY000): panic recovered: invalid hash length: 1
panic: invalid hash length: 19
```

These databases need to open again.
