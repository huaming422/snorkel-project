## Task

Since the latest CLI upgrade, some users can't get into their existing database at all.
Every bd command they run crashes with a panic at startup.
Their databases opened fine on the previous version.
It's not everyone.
Please fix it so the affected databases open again.
