## Task

Since the latest CLI upgrade, some users can't open their database at all.
Every bd command they run fails with `Error 1105 (HY000): panic recovered`.
Most people upgraded without any trouble.
Let's get them unblocked.
