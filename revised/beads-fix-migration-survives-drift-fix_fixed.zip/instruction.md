## Task

Since the latest CLI upgrade, some users can't open their database at all.
Every bd command fails right at startup, before it does any work.
It happens on every start, so they have no way back in.
Clean databases upgrade and open fine.
The broken ones all seem to have something wrong in their history and comments storage.

This is what people pasted from their terminals:

```
Error 1105 (HY000): panic recovered: invalid hash length: 19
Error 1105 (HY000): panic recovered: invalid hash length: 1
panic: invalid hash length: 19
```

Please get these databases opening again.
Upgrade errors that have nothing to do with this, like a duplicate key or a different engine panic, should still fail the way they do today.
Some of these users will fix their storage later with Dolt's own tools.
When they do, their next upgrade should bring the history and comments data bd couldn't read back in line with their teammates' clones.
Until then, merges keep duplicating those rows.
Data that came through the first upgrade fine shouldn't be touched again on one machine, because that would knock it out of line instead.
