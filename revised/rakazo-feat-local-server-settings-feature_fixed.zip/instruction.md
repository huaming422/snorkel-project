## Task

Desktop users have no way back into their model settings or server integrations once first-time setup is done.
Nothing in the desktop app's menus opens them, and when nobody is signed in there is no route to them at all.
Add a way for the desktop host to open and use those settings from inside the app, signed in or not.

Only the machine running the desktop app and its bundled local server should get this.
A browser with a normal signed-in session, or someone using the regular web app, must not be able to use this path.

Leave the signed-in settings on web and mobile alone.
This adds a separate path next to them and does not change them.

## User stories / requirements

- The host gets in by sending a secret its local server was configured with.
  Requests without that exact secret are refused, including a wrong secret and a request that only has a normal signed-in browser session.
  If the server has no secret configured, nothing gets in this way.
- Once the host is let in, every change applies to the deployment owner's account, and the server works out who that is by itself.
  Any account or workspace named by the caller is ignored.
  If no owner account exists yet, the request is refused rather than carried out.
- Through this path the host can reach the operations it needs to manage models and to manage server integrations.
  Every other application operation is refused here, even with a valid secret.
- The desktop app sends these settings requests only to its own local server and only for the allowed settings operations, and it never sends the host secret anywhere else.
  The requests carry no normal browser credentials and do not follow redirects to another location.
- Which operations the settings path offers, and the address the settings page lives at, are defined once in a shared place that the desktop app and the local server both read.
  That shared definition has to work in the packaged desktop build too, not just when running from source with the dev tooling.
- Opened from the desktop app, the settings page works without anyone signed in and lets the host manage both models and server integrations.
  It lives at its own dedicated host settings address, not inside the normal signed-in web flow, and does not show up at other addresses.
- The host can open the settings from inside the desktop app, for example from a menu item or a dedicated settings window, without typing the address in.
  What it opens is the shared host settings address, and the opened page can reach its settings operations.
