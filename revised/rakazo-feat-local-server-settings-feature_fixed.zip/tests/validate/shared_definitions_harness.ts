// @ts-nocheck
//
// Harness for the shared-definitions story.
//
// alterSharedDefinitions takes the real exports of the submission's shared
// settings module and returns a copy where the settings surface is served
// under a different address prefix and has a different set of operations: some
// operations are added and some removed. Every export that carries those
// definitions is rewritten consistently (the prefix string, the in-scope
// predicate, and any exported list or set of operations), so code that reads
// the shared module follows the new definitions, and code that keeps its own
// copy of the prefix or the operation list does not.
//
// Usage in a story test file (the specifier is the one the server code
// imports the shared module by; mock each one it uses):
//
//   vi.mock("<specifier>", async (importOriginal) => {
//     const { alterSharedDefinitions } = await import("./shared_definitions_harness");
//     return alterSharedDefinitions(await importOriginal(), {
//       prefixExport: "<NAME OF THE PREFIX CONSTANT>",
//       predicateExports: ["<NAME OF THE IN-SCOPE PREDICATE>"],
//       listExports: ["<NAME OF AN EXPORTED OPERATION LIST OR SET>"],
//       newPrefix: "/alt-host-settings-7f3a/rpc",
//       add: ["bots/list"],
//       remove: ["models/list"],
//     });
//   });
//
// Operation names in `add` and `remove` are written with "/" between segments
// ("models/list"). The harness accepts the predicate being called with a full
// request pathname (prefix included), a bare operation path ("models/list",
// "/models/list" or "models.list"), or an array of path segments.

type Options = {
  prefixExport?: string;
  predicateExports?: string[];
  listExports?: string[];
  newPrefix: string;
  add?: string[];
  remove?: string[];
};

function trimSlashes(value: string) {
  return value.replace(/^\/+/, "").replace(/\/+$/, "");
}

export function alterSharedDefinitions(original: any, options: Options) {
  const add = (options.add ?? []).map(trimSlashes);
  const remove = (options.remove ?? []).map(trimSlashes);
  const oldPrefix =
    options.prefixExport && typeof original[options.prefixExport] === "string"
      ? String(original[options.prefixExport]).replace(/\/+$/, "")
      : null;
  const newPrefix = options.newPrefix.replace(/\/+$/, "");
  if (options.prefixExport && oldPrefix === null) {
    throw new Error(`shared module has no string export "${options.prefixExport}"`);
  }

  const altered: any = { ...original };
  if (options.prefixExport) altered[options.prefixExport] = newPrefix;

  for (const name of options.predicateExports ?? []) {
    const predicate = original[name];
    if (typeof predicate !== "function") {
      throw new Error(`shared module has no function export "${name}"`);
    }
    altered[name] = (...args: any[]) => {
      const [arg, ...rest] = args;
      let op: string;
      let forward = arg;
      if (Array.isArray(arg)) {
        op = arg.map(String).join("/");
      } else if (typeof arg === "string") {
        if (oldPrefix !== null && arg.startsWith(`${newPrefix}/`)) {
          op = trimSlashes(arg.slice(newPrefix.length));
          forward = `${oldPrefix}${arg.slice(newPrefix.length)}`;
        } else if (oldPrefix !== null && arg.startsWith(`${oldPrefix}/`)) {
          // The old address is no longer the settings surface.
          return false;
        } else {
          op = trimSlashes(arg).split(".").join("/");
        }
      } else {
        return predicate(...args);
      }
      if (add.includes(op)) return true;
      if (remove.includes(op)) return false;
      return predicate(forward, ...rest);
    };
  }

  for (const name of options.listExports ?? []) {
    const list = original[name];
    const items: string[] = list instanceof Set ? [...list] : Array.isArray(list) ? [...list] : null;
    if (items === null) throw new Error(`shared module export "${name}" is not a list or set`);
    const sample = items.find((item) => typeof item === "string" && /models/.test(item)) ?? items[0] ?? "";
    const dotted = sample.includes(".") && !sample.includes("/");
    const leading = sample.startsWith("/");
    const spell = (op: string) => {
      const body = dotted ? op.split("/").join(".") : op;
      return leading ? `/${body}` : body;
    };
    const normalize = (item: string) => trimSlashes(String(item)).split(".").join("/");
    const next = items.filter((item) => !remove.includes(normalize(item)));
    for (const op of add) if (!next.some((item) => normalize(item) === op)) next.push(spell(op));
    altered[name] =
      list instanceof Set ? new Set(next) : Object.isFrozen(list) ? Object.freeze(next) : next;
  }
  return altered;
}
