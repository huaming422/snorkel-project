#!/usr/bin/env bash
# validation-setup.sh: environment bootstrap for the validation stories.
#
# Sourced by the harbor validation runner before vitest runs, so exported
# env vars and PATH changes stay alive for the test process. Idempotent.
#
# The Dockerfile already installs the pnpm dependency closure at the base
# commit (`pnpm install --frozen-lockfile`, warm store under
# /opt/cache/pnpm-dev). This script re-runs that install only as a guard when
# node_modules is missing, regenerates the Prisma client if it is
# missing, and then runs a loud sanity check that the toolchain and the
# workspace packages the stories import resolve. The stories are
# mock-based (mocked prisma / oRPC handler / fetch, a fake `electron` module
# for the desktop main process) plus one native-Node load probe, so no
# database, server, or display is required.

set -e

REPO_DIR="${REPO_DIR:-/repo/rakazo}"
cd "$REPO_DIR"

echo "[validation-setup] repo: $REPO_DIR"

# --- Toolchain sanity (fail loud if the pinned toolchain is absent) --------
node --version
pnpm --version
npx vitest --version

# --- Dependency closure guard (offline-first against the warm store) -------
if [ ! -d "node_modules/.pnpm" ]; then
    echo "[validation-setup] node_modules missing; reinstalling..."
    if pnpm install --frozen-lockfile --offline 2>&1 | tail -15; then
        echo "[validation-setup] offline install ok"
    else
        echo "[validation-setup] offline install failed; retrying online (network fallback)..."
        pnpm install --frozen-lockfile 2>&1 | tail -15
    fi
fi

# --- Prisma client guard ---------------------------------------------------
# The API stories import from @rakazo/db (mocked at the call boundary, but the
# module must still resolve its generated client). No database connection is
# made.
if [ -d "packages/db" ] && [ ! -d "node_modules/.prisma/client" ] \
   && [ ! -d "node_modules/@prisma/client" ]; then
    echo "[validation-setup] generating prisma client..."
    pnpm --filter @rakazo/db exec prisma generate 2>&1 | tail -10 || true
fi

# --- Dedicated vitest config for the web settings-surface story ------------
# The settings-surface story renders the apps/web React app in a
# jsdom DOM. It uses a dedicated vitest config (rather than apps/web's own
# vite.config.ts) so the story never has to load the app's server/proxy config,
# which the implementation change may edit, for example by importing workspace
# values into it at config-load time. The config is shipped alongside the story harness
# in /tests/validate/ and placed at the apps/web package root here, next to the
# package the story's config_dir points at. Idempotent.
WEB_CFG_SRC="/tests/validate/vitest.host-settings.config.ts"
WEB_CFG_DEST="$REPO_DIR/apps/web/vitest.host-settings.config.ts"
if [ -f "$WEB_CFG_SRC" ] && [ -d "$REPO_DIR/apps/web" ]; then
    cp "$WEB_CFG_SRC" "$WEB_CFG_DEST"
    echo "[validation-setup] placed web settings-surface vitest config at $WEB_CFG_DEST"
fi

# --- Story harness files ---------------------------------------------------
# Two stories import a helper that sits next to their test file:
#   - desktop_main_harness.ts (desktop entry story): a fake `electron` module and
#     a fake local server, so the story can run the real desktop main process
#     module, trigger its in-app entry and follow a request to the server;
#   - shared_definitions_harness.ts (shared definitions story): rewrites the
#     shared settings exports so the story can check the server follows them.
# The driver copies each story into <package>/src/__validation__/, so the
# helpers go there too. Idempotent.
for pair in "desktop_main_harness.ts:apps/desktop/src" "shared_definitions_harness.ts:apps/api/src"; do
    HARNESS_SRC="/tests/validate/${pair%%:*}"
    HARNESS_DIR="$REPO_DIR/${pair#*:}/__validation__"
    if [ -f "$HARNESS_SRC" ] && [ -d "$REPO_DIR/${pair#*:}" ]; then
        mkdir -p "$HARNESS_DIR"
        cp "$HARNESS_SRC" "$HARNESS_DIR/"
        echo "[validation-setup] placed ${pair%%:*} in $HARNESS_DIR"
    fi
done

# --- Workspace binaries on PATH --------------------------------------------
export PATH="$REPO_DIR/node_modules/.bin:$PATH"

# --- Loud smoke guard ------------------------------------------------------
# Confirm the packages the stories resolve against are present. This catches a
# broken install before vitest reports a confusing module-resolution failure.
# It deliberately does NOT import the modules under test; it only checks the
# pre-existing workspace deps.
node -e '
  const r = require("node:module").createRequire(process.cwd() + "/package.json");
  for (const pkg of ["hono", "vitest"]) {
    try { r.resolve(pkg); }
    catch (e) { console.error("[validation-setup] cannot resolve " + pkg + ": " + e.message); process.exit(1); }
  }
  console.error("[validation-setup] workspace dep resolution ok");
'

echo "[validation-setup] ready: $REPO_DIR (node=$(node --version), pnpm=$(pnpm --version))"
