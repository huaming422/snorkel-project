// @ts-nocheck
//
// Harness for the desktop in-app entry story.
//
// It runs the real Electron main process module (apps/desktop/src/main.ts) under
// vitest with a fake `electron` module, against a fake local server. The fake
// records what the main process does: the application menu it builds, the
// windows it opens and the addresses they load, the IPC handlers it registers,
// the request hooks it installs on each window's session, and every request
// that reaches the local server (with its headers). Nothing in here knows the
// submission's names: the story reads the patch to decide which menu item,
// window, IPC channel or request hook to drive.
//
// Usage in a story test file placed in apps/desktop/src/__validation__/:
//
//   vi.mock("electron", async () => (await import("./desktop_main_harness")).electronModule());
//   const { bootDesktopMain } = await import("./desktop_main_harness");
//   const desktop = await bootDesktopMain(() => import("../main"));
//
// bootDesktopMain prepares a profile with a saved local-server setup ("new"
// mode, loopback address) and the stack secret file the app writes, starts the
// main module, and resolves once the main app window has loaded the local
// server. At that point the app is in its normal "connected to my local server"
// state, with nobody signed in.

type Listener = (...args: any[]) => any;

class Emitter {
  private listeners = new Map<string, Listener[]>();
  on(name: string, fn: Listener) {
    const list = this.listeners.get(name) ?? [];
    list.push(fn);
    this.listeners.set(name, list);
    return this;
  }
  addListener(name: string, fn: Listener) {
    return this.on(name, fn);
  }
  once(name: string, fn: Listener) {
    const wrapped = (...args: any[]) => {
      this.removeListener(name, wrapped);
      return fn(...args);
    };
    (wrapped as any).original = fn;
    return this.on(name, wrapped);
  }
  removeListener(name: string, fn: Listener) {
    const list = this.listeners.get(name) ?? [];
    this.listeners.set(
      name,
      list.filter((item) => item !== fn && (item as any).original !== fn),
    );
    return this;
  }
  off(name: string, fn: Listener) {
    return this.removeListener(name, fn);
  }
  removeAllListeners(name?: string) {
    if (name === undefined) this.listeners.clear();
    else this.listeners.delete(name);
    return this;
  }
  emit(name: string, ...args: any[]) {
    for (const fn of [...(this.listeners.get(name) ?? [])]) fn(...args);
    return true;
  }
  listenerCount(name: string) {
    return (this.listeners.get(name) ?? []).length;
  }
}

/** A callable, constructible object that answers any property with another stub. */
function stub(): any {
  const fn = function () {};
  return new Proxy(fn, {
    get: (_t, prop) => {
      if (prop === "then") return undefined;
      if (prop === Symbol.toPrimitive) return () => "";
      return stub();
    },
    apply: () => stub(),
    construct: () => stub(),
  });
}

export type ServerRequest = {
  url: string;
  origin: string;
  pathname: string;
  method: string;
  headers: Record<string, string>;
  body: string;
  credentials?: string;
  redirect?: string;
  via: string;
};

const state: any = {
  userData: "",
  localOrigin: "http://127.0.0.1:47321",
  stackToken: "",
  imageTag: "harness-image-tag",
  windows: [] as any[],
  sessions: new Map<string, any>(),
  ipcHandlers: new Map<string, Listener>(),
  ipcListeners: new Map<string, Listener[]>(),
  menuTemplates: [] as any[],
  applicationMenu: null as any,
  requests: [] as ServerRequest[],
  dialogs: [] as any[],
  openedExternal: [] as string[],
  nextContentsId: 1,
  module: null as any,
};

function lowerHeaders(input: any): Record<string, string> {
  const out: Record<string, string> = {};
  if (!input) return out;
  if (typeof input.forEach === "function" && !Array.isArray(input)) {
    input.forEach((value: string, key: string) => {
      out[String(key).toLowerCase()] = String(value);
    });
    return out;
  }
  const entries = Array.isArray(input) ? input : Object.entries(input);
  for (const [key, value] of entries) {
    out[String(key).toLowerCase()] = Array.isArray(value) ? value.join(", ") : String(value);
  }
  return out;
}

/** The fake local server and the fake network behind it. */
async function serve(input: any, init: any = {}, via: string): Promise<Response> {
  let url: string;
  let method = init?.method;
  let headers = init?.headers;
  let body = init?.body;
  if (typeof input === "string") url = input;
  else if (input instanceof URL) url = input.href;
  else {
    url = input.url;
    method = method ?? input.method;
    headers = headers ?? input.headers;
    if (body === undefined && typeof input.text === "function") {
      try {
        body = await input.clone().text();
      } catch {
        body = undefined;
      }
    }
  }
  const parsed = new URL(url);
  const record: ServerRequest = {
    url: parsed.href,
    origin: parsed.origin,
    pathname: parsed.pathname,
    method: String(method ?? "GET").toUpperCase(),
    headers: lowerHeaders(headers),
    body: typeof body === "string" ? body : body == null ? "" : String(body),
    credentials: init?.credentials,
    redirect: init?.redirect,
    via,
  };
  state.requests.push(record);
  if (parsed.origin !== state.localOrigin) {
    throw new TypeError(`net::ERR_NAME_NOT_RESOLVED ${parsed.origin}`);
  }
  if (parsed.pathname === "/.well-known/rakazo-desktop-stack") {
    return new Response(JSON.stringify({ ok: true, imageTag: state.imageTag }), {
      status: 200,
      headers: { "content-type": "application/json" },
    });
  }
  if (record.method === "GET" || record.method === "HEAD") {
    return new Response("<!doctype html><html><body><div id=root></div></body></html>", {
      status: 200,
      headers: { "content-type": "text/html" },
    });
  }
  return new Response(JSON.stringify({ json: { ok: true } }), {
    status: 200,
    headers: { "content-type": "application/json" },
  });
}

function makeSession(name: string) {
  const hooks = new Map<string, Array<{ filter: any; listener: Listener }>>();
  const register = (event: string) => (filterOrListener: any, maybeListener?: Listener) => {
    const listener = typeof filterOrListener === "function" ? filterOrListener : maybeListener;
    const filter = typeof filterOrListener === "function" ? null : filterOrListener;
    if (listener === null || listener === undefined) {
      hooks.set(event, []);
      return;
    }
    // Electron keeps one listener per event and session; a new one replaces it.
    hooks.set(event, [{ filter, listener }]);
  };
  const emitter = new Emitter();
  const sessionObject: any = {
    name,
    hooks,
    webRequest: {
      onBeforeRequest: register("onBeforeRequest"),
      onBeforeSendHeaders: register("onBeforeSendHeaders"),
      onSendHeaders: register("onSendHeaders"),
      onHeadersReceived: register("onHeadersReceived"),
      onResponseStarted: register("onResponseStarted"),
      onBeforeRedirect: register("onBeforeRedirect"),
      onCompleted: register("onCompleted"),
      onErrorOccurred: register("onErrorOccurred"),
    },
    protocol: {
      handled: new Map<string, Listener>(),
      handle(scheme: string, handler: Listener) {
        this.handled.set(scheme, handler);
      },
      unhandle(scheme: string) {
        this.handled.delete(scheme);
      },
      isProtocolHandled(scheme: string) {
        return this.handled.has(scheme);
      },
    },
    cookies: {
      get: async () => [],
      set: async () => undefined,
      remove: async () => undefined,
      flushStore: async () => undefined,
      on: () => undefined,
    },
    fetch: (input: any, init?: any) => serve(input, init, `session.fetch:${name}`),
    clearStorageData: async () => undefined,
    clearCache: async () => undefined,
    clearCodeCaches: async () => undefined,
    clearAuthCache: async () => undefined,
    flushStorageData: () => undefined,
    setPermissionRequestHandler: () => undefined,
    setPermissionCheckHandler: () => undefined,
    setDevicePermissionHandler: () => undefined,
    setDisplayMediaRequestHandler: () => undefined,
    setUserAgent: () => undefined,
    getUserAgent: () => "harness",
    setProxy: async () => undefined,
    setPreloads: () => undefined,
    getPreloads: () => [],
    registerPreloadScript: () => "preload",
    on: emitter.on.bind(emitter),
    once: emitter.once.bind(emitter),
    removeListener: emitter.removeListener.bind(emitter),
  };
  return sessionObject;
}

function sessionFor(partition?: string | null) {
  const key = partition ? String(partition) : "<default>";
  let value = state.sessions.get(key);
  if (!value) {
    value = makeSession(key);
    state.sessions.set(key, value);
  }
  return value;
}

class FakeWebContents extends Emitter {
  id: number;
  session: any;
  owner: any;
  loadedUrls: string[] = [];
  sent: Array<{ channel: string; args: any[] }> = [];
  mainFrame: any;
  windowOpenHandler: Listener | null = null;
  destroyed = false;
  constructor(owner: any, partition?: string | null) {
    super();
    this.id = state.nextContentsId++;
    this.owner = owner;
    this.session = sessionFor(partition);
    this.mainFrame = { url: "", routingId: this.id, processId: 1, frameTreeNodeId: this.id };
  }
  async loadURL(url: string) {
    this.loadedUrls.push(url);
    this.mainFrame.url = url;
    for (const { listener } of this.session.hooks.get("onCompleted") ?? []) {
      try {
        listener({
          webContentsId: this.id,
          resourceType: "mainFrame",
          statusCode: 200,
          url,
          method: "GET",
        });
      } catch {
        /* a hook error does not stop the load */
      }
    }
    this.emit("did-start-loading");
    this.emit("dom-ready");
    this.emit("did-finish-load");
    this.emit("did-stop-loading");
    this.owner?.emit("ready-to-show");
  }
  async loadFile(file: string) {
    return this.loadURL(`file://${file}`);
  }
  getURL() {
    return this.mainFrame.url;
  }
  async executeJavaScript() {
    return true;
  }
  isCrashed() {
    return false;
  }
  isLoading() {
    return false;
  }
  isDestroyed() {
    return this.destroyed;
  }
  send(channel: string, ...args: any[]) {
    this.sent.push({ channel, args });
  }
  setWindowOpenHandler(handler: Listener) {
    this.windowOpenHandler = handler;
  }
  reload() {}
  openDevTools() {}
  closeDevTools() {}
  focus() {}
  setZoomFactor() {}
  setAudioMuted() {}
  setBackgroundThrottling() {}
  setUserAgent() {}
  setIgnoreMenuShortcuts() {}
  getTitle() {
    return "";
  }
}

class FakeBrowserWindow extends Emitter {
  static fromWebContents(contents: any) {
    return state.windows.find((win: any) => win.webContents === contents) ?? null;
  }
  static fromId(id: number) {
    return state.windows.find((win: any) => win.id === id) ?? null;
  }
  static getAllWindows() {
    return state.windows.filter((win: any) => !win.destroyed);
  }
  static getFocusedWindow() {
    return state.windows.filter((win: any) => !win.destroyed && win.visible).at(-1) ?? null;
  }
  id: number;
  options: any;
  webContents: FakeWebContents;
  destroyed = false;
  visible: boolean;
  title: string;
  constructor(options: any = {}) {
    super();
    this.options = options;
    this.webContents = new FakeWebContents(this, options?.webPreferences?.partition ?? null);
    this.id = this.webContents.id;
    this.visible = options?.show !== false;
    this.title = options?.title ?? "";
    state.windows.push(this);
  }
  get loadedUrls() {
    return this.webContents.loadedUrls;
  }
  get preload(): string | undefined {
    return this.options?.webPreferences?.preload;
  }
  loadURL(url: string) {
    return this.webContents.loadURL(url);
  }
  loadFile(file: string) {
    return this.webContents.loadFile(file);
  }
  show() {
    this.visible = true;
    this.emit("show");
  }
  showInactive() {
    this.show();
  }
  hide() {
    this.visible = false;
    this.emit("hide");
  }
  focus() {
    this.emit("focus");
  }
  blur() {}
  isVisible() {
    return this.visible;
  }
  isDestroyed() {
    return this.destroyed;
  }
  isFocused() {
    return this.visible;
  }
  isMinimized() {
    return false;
  }
  isMaximized() {
    return false;
  }
  isFullScreen() {
    return false;
  }
  close() {
    if (this.destroyed) return;
    let prevented = false;
    this.emit("close", { preventDefault: () => (prevented = true) });
    if (!prevented) this.destroy();
  }
  destroy() {
    if (this.destroyed) return;
    this.destroyed = true;
    this.webContents.destroyed = true;
    this.emit("closed");
  }
  setTitle(title: string) {
    this.title = title;
  }
  getTitle() {
    return this.title;
  }
  getBounds() {
    return { x: 0, y: 0, width: 1200, height: 800 };
  }
  setBounds() {}
  setSize() {}
  setMinimumSize() {}
  center() {}
  maximize() {}
  unmaximize() {}
  minimize() {}
  restore() {}
  setFullScreen() {}
  setMenu() {}
  setMenuBarVisibility() {}
  setAutoHideMenuBar() {}
  removeMenu() {}
  setParentWindow() {}
  setAlwaysOnTop() {}
  setBackgroundColor() {}
  setVibrancy() {}
  setWindowButtonVisibility() {}
  setIcon() {}
  setResizable() {}
  setClosable() {}
  setSheetOffset() {}
  getParentWindow() {
    return null;
  }
  getChildWindows() {
    return [];
  }
}

function flattenMenu(template: any[] | null | undefined, out: any[] = []) {
  for (const item of template ?? []) {
    if (item === null || item === undefined) continue;
    out.push(item);
    const submenu = Array.isArray(item.submenu) ? item.submenu : item.submenu?.items;
    if (Array.isArray(submenu)) flattenMenu(submenu, out);
  }
  return out;
}

function buildElectronModule() {
  const appEmitter = new Emitter();
  const paths = new Map<string, string>();
  const app: any = {
    isPackaged: false,
    name: "Rakazo",
    getName: () => "Rakazo",
    getVersion: () => "0.0.0-harness",
    getLocale: () => "en-US",
    getAppPath: () => (state.userData ? `${state.userData}/app` : "/nonexistent-app"),
    getPath: (name: string) =>
      paths.get(name) ?? (name === "userData" ? state.userData : `${state.userData}/../${name}`),
    setPath: (name: string, value: string) => paths.set(name, value),
    whenReady: () => Promise.resolve(),
    isReady: () => true,
    on: (name: string, fn: Listener) => (appEmitter.on(name, fn), app),
    once: (name: string, fn: Listener) => (appEmitter.once(name, fn), app),
    off: (name: string, fn: Listener) => (appEmitter.removeListener(name, fn), app),
    removeListener: (name: string, fn: Listener) => (appEmitter.removeListener(name, fn), app),
    emit: (name: string, ...args: any[]) => appEmitter.emit(name, ...args),
    quit: () => undefined,
    exit: () => undefined,
    relaunch: () => undefined,
    focus: () => undefined,
    requestSingleInstanceLock: () => true,
    hasSingleInstanceLock: () => true,
    setAsDefaultProtocolClient: () => true,
    isDefaultProtocolClient: () => true,
    setAppUserModelId: () => undefined,
    setName: () => undefined,
    setAboutPanelOptions: () => undefined,
    commandLine: { appendSwitch: () => undefined, hasSwitch: () => false },
    dock: { setIcon: () => undefined, show: async () => undefined, hide: () => undefined },
  };
  const ipcMain: any = {
    handle: (channel: string, fn: Listener) => {
      state.ipcHandlers.set(channel, fn);
    },
    handleOnce: (channel: string, fn: Listener) => {
      state.ipcHandlers.set(channel, fn);
    },
    removeHandler: (channel: string) => {
      state.ipcHandlers.delete(channel);
    },
    on: (channel: string, fn: Listener) => {
      const list = state.ipcListeners.get(channel) ?? [];
      list.push(fn);
      state.ipcListeners.set(channel, list);
      return ipcMain;
    },
    once: (channel: string, fn: Listener) => ipcMain.on(channel, fn),
    removeListener: () => ipcMain,
    removeAllListeners: () => ipcMain,
  };
  const Menu: any = {
    buildFromTemplate: (template: any[]) => {
      state.menuTemplates.push(template);
      return { template, items: template, popup: () => undefined, closePopup: () => undefined };
    },
    setApplicationMenu: (menu: any) => {
      state.applicationMenu = menu;
    },
    getApplicationMenu: () => state.applicationMenu,
    sendActionToFirstResponder: () => undefined,
  };
  const session: any = {
    get defaultSession() {
      return sessionFor(null);
    },
    fromPartition: (partition: string) => sessionFor(partition),
    fromPath: (p: string) => sessionFor(`path:${p}`),
  };
  const net: any = {
    fetch: (input: any, init?: any) => serve(input, init, "net.fetch"),
    isOnline: () => true,
    request: () => stub(),
  };
  const shell: any = {
    openExternal: async (url: string) => {
      state.openedExternal.push(url);
    },
    openPath: async () => "",
    showItemInFolder: () => undefined,
    beep: () => undefined,
  };
  const dialog: any = {
    showMessageBox: async (...args: any[]) => {
      state.dialogs.push(args);
      return { response: 0, checkboxChecked: false };
    },
    showMessageBoxSync: (...args: any[]) => {
      state.dialogs.push(args);
      return 0;
    },
    showErrorBox: (...args: any[]) => {
      state.dialogs.push(args);
    },
    showOpenDialog: async () => ({ canceled: true, filePaths: [] }),
    showSaveDialog: async () => ({ canceled: true }),
  };
  const known: any = {
    app,
    BrowserWindow: FakeBrowserWindow,
    ipcMain,
    Menu,
    MenuItem: class {
      constructor(options: any) {
        Object.assign(this, options);
      }
    },
    net,
    session,
    shell,
    dialog,
    protocol: {
      handle: () => undefined,
      unhandle: () => undefined,
      registerSchemesAsPrivileged: () => undefined,
      isProtocolHandled: () => false,
    },
    nativeTheme: Object.assign(new Emitter(), { shouldUseDarkColors: false, themeSource: "system" }),
    screen: {
      getPrimaryDisplay: () => ({ workAreaSize: { width: 1440, height: 900 }, bounds: { x: 0, y: 0, width: 1440, height: 900 } }),
      getAllDisplays: () => [],
      on: () => undefined,
    },
    globalShortcut: { register: () => true, unregister: () => undefined, unregisterAll: () => undefined },
    powerMonitor: { on: () => undefined },
    nativeImage: { createFromPath: () => stub(), createEmpty: () => stub() },
    autoUpdater: stub(),
    crashReporter: { start: () => undefined },
    contextBridge: { exposeInMainWorld: () => undefined },
    ipcRenderer: { invoke: async () => undefined, on: () => undefined, send: () => undefined },
    webContents: {
      fromId: (id: number) => state.windows.find((win: any) => win.webContents.id === id)?.webContents ?? null,
      getAllWebContents: () => state.windows.map((win: any) => win.webContents),
    },
  };
  const module = new Proxy(known, {
    get: (target, prop) => {
      if (prop === "default") return module;
      if (prop === "__esModule") return true;
      if (prop === "then") return undefined;
      if (prop in target) return target[prop];
      return stub();
    },
    has: () => true,
  });
  return module;
}

/** The fake `electron` module. Pass this from `vi.mock("electron", ...)`. */
export function electronModule() {
  if (state.module === null) state.module = buildElectronModule();
  return state.module;
}

function matchesFilter(filter: any, url: string) {
  const urls: string[] = filter?.urls ?? [];
  if (urls.length === 0) return true;
  return urls.some((pattern) => {
    const re = new RegExp(
      "^" +
        pattern
          .replace(/[.+?^${}()|[\]\\]/g, "\\$&")
          .replace(/\*/g, ".*") +
        "$",
    );
    return re.test(url);
  });
}

async function runHook(listener: Listener, details: any): Promise<any> {
  return await new Promise((resolve) => {
    let done = false;
    const finish = (value: any) => {
      if (!done) {
        done = true;
        resolve(value ?? {});
      }
    };
    try {
      const out = listener(details, finish);
      if (out && typeof out.then === "function") out.then(() => finish(undefined), () => finish(undefined));
    } catch {
      finish({});
    }
    setTimeout(() => finish({}), 2000);
  });
}

export type DesktopProbe = Awaited<ReturnType<typeof bootDesktopMain>>;

/**
 * Prepare a connected local-server profile, start the real main module through
 * `loadMain`, and resolve once the main app window has loaded the local server.
 */
export async function bootDesktopMain(loadMain: () => Promise<unknown>) {
  electronModule();
  const { mkdtemp, mkdir, writeFile } = await import("node:fs/promises");
  const { randomBytes } = await import("node:crypto");
  const os = await import("node:os");
  const path = await import("node:path");

  const root = await mkdtemp(path.join(os.tmpdir(), "desktop-entry-"));
  state.userData = path.join(root, "userData");
  const stack = path.join(state.userData, "stack");
  await mkdir(stack, { recursive: true });
  state.stackToken = randomBytes(32).toString("hex");
  await writeFile(path.join(stack, ".desktop-stack-token"), `${state.stackToken}\n`, { mode: 0o600 });
  await writeFile(path.join(stack, ".desktop-web-url"), state.localOrigin, { mode: 0o600 });
  await writeFile(
    path.join(state.userData, "setup.json"),
    `${JSON.stringify({ mode: "new", serverUrl: state.localOrigin }, null, 2)}\n`,
    { mode: 0o600 },
  );

  for (const name of [
    "RAKAZO_WEB_URL",
    "RAKAZO_FORCE_SETUP",
    "RAKAZO_PERFORMANCE_USER_DATA",
    "RAKAZO_PERFORMANCE_CLEAR_CACHE",
    "RAKAZO_LOCAL_WEB_URL",
  ]) {
    delete process.env[name];
  }
  process.env.RAKAZO_IMAGE_TAG = state.imageTag;
  process.env.RAKAZO_DISABLE_AUTO_UPDATE = "1";
  process.env.RAKAZO_DISABLE_WARM_WINDOW = "1";

  // Code that uses the global fetch from the main process reaches the same fake network.
  globalThis.fetch = ((input: any, init?: any) => serve(input, init, "fetch")) as any;

  await loadMain();

  const loadedLocalRoot = () =>
    state.windows.some((win: any) =>
      win.loadedUrls.some((url: string) => {
        try {
          return new URL(url).origin === state.localOrigin;
        } catch {
          return false;
        }
      }),
    );
  if (!(await waitFor(loadedLocalRoot, 15_000))) {
    throw new Error(
      "desktop main did not open the local server: " +
        JSON.stringify({
          windows: state.windows.map((win: any) => win.loadedUrls),
          dialogs: state.dialogs,
          requests: state.requests.map((req: any) => `${req.method} ${req.url}`),
        }),
    );
  }
  // Let the startup path finish (commit the app switch, close setup).
  await new Promise((r) => setTimeout(r, 100));

  const probe = {
    /** The local server address the app manages, e.g. "http://127.0.0.1:47321". */
    localOrigin: state.localOrigin as string,
    /** The secret the app's local server was configured with (the stack secret file). */
    stackToken: state.stackToken as string,
    /** All windows the main process created, in order. */
    windows: state.windows as any[],
    /** The main app window (the first window that loaded the local server). */
    mainWindow: state.windows.find((win: any) => win.loadedUrls.length > 0) ?? null,
    /** Every request any part of the main process (or a simulated page) sent. */
    requests: state.requests as ServerRequest[],
    /** Message boxes the main process showed (useful when an entry refuses to open). */
    dialogs: state.dialogs as any[],
    /** Registered `ipcMain.handle` channels and handlers. */
    ipcHandlers: state.ipcHandlers as Map<string, Listener>,
    /** Registered `ipcMain.on` channels and listeners. */
    ipcListeners: state.ipcListeners as Map<string, Listener[]>,
    /** Every item of the current application menu, flattened (submenus included). */
    menuItems(): any[] {
      return flattenMenu(state.applicationMenu?.template ?? state.menuTemplates.at(-1));
    },
    /** Every item of every menu template the main process built (context menus, tray). */
    allMenuItems(): any[] {
      return state.menuTemplates.flatMap((template: any[]) => flattenMenu(template));
    },
    /** Windows created after `count` windows existed. */
    windowsSince(count: number): any[] {
      return state.windows.slice(count);
    },
    /** The pathname of each address a window loaded. */
    loadedPaths(win: any): string[] {
      return win.loadedUrls.map((url: string) => {
        try {
          return new URL(url).pathname;
        } catch {
          return url;
        }
      });
    },
    /** Requests that reached the local server, optionally only for one pathname. */
    serverRequests(pathname?: string): ServerRequest[] {
      return state.requests.filter(
        (req: ServerRequest) =>
          req.origin === state.localOrigin && (pathname === undefined || req.pathname === pathname),
      );
    },
    /** The IPC event a renderer in `win` produces (main frame, at its loaded address). */
    ipcEvent(win: any) {
      const contents = win.webContents;
      return {
        sender: contents,
        senderFrame: contents.mainFrame,
        frameId: contents.mainFrame.routingId,
        processId: 1,
        returnValue: undefined,
        reply: () => undefined,
      };
    },
    /** Invoke an `ipcMain.handle` channel as the page in `win` would. */
    async invoke(channel: string, win: any, ...args: any[]) {
      const handler = state.ipcHandlers.get(channel);
      if (!handler) throw new Error(`no ipcMain.handle("${channel}")`);
      return handler(probe.ipcEvent(win), ...args);
    },
    /**
     * Simulate the page in `win` issuing `fetch(url, init)`: the window session's
     * request hooks run first (onBeforeRequest may cancel or redirect,
     * onBeforeSendHeaders may change headers), then the request goes to the
     * fake network. Returns `{ blocked, status, body }`.
     */
    async pageRequest(win: any, url: string, init: any = {}) {
      const sessionObject = win.webContents.session;
      let target = url;
      const base = {
        id: Math.floor(Math.random() * 1e9),
        url: target,
        method: String(init.method ?? "GET").toUpperCase(),
        webContentsId: win.webContents.id,
        webContents: win.webContents,
        frame: win.webContents.mainFrame,
        resourceType: "xhr",
        referrer: win.webContents.getURL(),
        timestamp: Date.now(),
        uploadData: init.body ? [{ bytes: Buffer.from(String(init.body)) }] : undefined,
      };
      for (const { filter, listener } of sessionObject.hooks.get("onBeforeRequest") ?? []) {
        if (!matchesFilter(filter, target)) continue;
        const res = await runHook(listener, { ...base, url: target });
        if (res?.cancel) return { blocked: true, status: 0, body: "" };
        if (res?.redirectURL) target = res.redirectURL;
      }
      let headers: Record<string, string> = { ...lowerHeaders(init.headers) };
      for (const { filter, listener } of sessionObject.hooks.get("onBeforeSendHeaders") ?? []) {
        if (!matchesFilter(filter, target)) continue;
        const res = await runHook(listener, { ...base, url: target, requestHeaders: { ...headers } });
        if (res?.cancel) return { blocked: true, status: 0, body: "" };
        if (res?.requestHeaders) headers = lowerHeaders(res.requestHeaders);
      }
      try {
        const response = await serve(target, { ...init, headers }, `page:${win.id}`);
        return { blocked: false, status: response.status, body: await response.text() };
      } catch (error) {
        return { blocked: true, status: 0, body: String(error) };
      }
    },
    waitFor,
  };
  return probe;
}

export async function waitFor(check: () => boolean, timeoutMs = 5_000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (check()) return true;
    await new Promise((r) => setTimeout(r, 20));
  }
  return check();
}
