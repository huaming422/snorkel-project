// @ts-nocheck
//
// Validation harness for the host-only settings SURFACE story.
//
// The submission adds a desktop-host-only settings experience: a surface the
// local server renders at a dedicated settings-page address, reachable from the
// desktop app with no signed-in browser session, that lets the host manage its
// models and its server integrations. This harness renders the submission's OWN
// top-level web application component (apps/web/src/App, a pre-existing symbol)
// at a page address the caller supplies, with no authenticated session and with
// a permissive desktop bridge installed, then drives the surface's own
// navigation and reports what management content it surfaced.
//
// It is delivery-agnostic: it does not know the submission's page component
// name, its routing mechanism (an App-level pathname branch, a <Route>, a
// section query param, …), its nav-control labels, or the shape of the desktop
// transport bridge. It discovers the surface by rendering the real app at the
// address and reading the resulting DOM.
//
// Module loads use dynamic import() (not require) so this harness resolves the
// repo's .tsx/.ts sources under vitest's ESM loader, and so the caller's jsdom
// environment and the window location/bridge shims are in place before React
// and the app modules evaluate.

type HostSettingsProbe = {
  // The surface rendered at the settings-page address with no session is a
  // host-settings experience (it surfaced settings-management affordances),
  // rather than the ordinary signed-in web flow's sign-in / loading state.
  reachedWithoutSession: boolean;
  // Model management was surfaced (an active-model / provider-management area).
  modelManagement: boolean;
  // Integration management was surfaced (a server-integration configuration area).
  integrationManagement: boolean;
  // Lowercased text content of the rendered document, for diagnostics.
  text: string;
};

function installPermissiveBridge(): void {
  // One success payload that satisfies whatever the settings surface fires on
  // mount: a configurable integration-setup state with no providers, empty
  // model catalog/credential/server lists, an owner "me". The bridge answers in
  // the shapes submissions use: a request(pathname, body) returning
  // {status, body}, a call(procedure, input) returning {ok, status, body}, or a
  // direct value. It is always the same oRPC-wrapped JSON, so the surface renders its
  // management UI rather than only an error state.
  const payload = {
    canConfigure: true,
    providers: [],
    catalog: [],
    credentials: [],
    models: [],
    servers: [],
    defaultModel: null,
    defaultProvider: null,
  };
  const okStatus = 200;
  const asBody = () => JSON.stringify({ json: payload });
  const bridge: any = {
    platform: "test",
    request: async () => ({ status: okStatus, body: asBody() }),
    call: async () => ({ ok: true, status: okStatus, body: { json: payload } }),
    invoke: async () => ({ status: okStatus, body: { json: payload } }),
    close: async () => {},
    window: { close: async () => {}, minimize: async () => {} },
  };
  const nested = {
    request: bridge.request,
    call: bridge.call,
    invoke: bridge.invoke,
    close: bridge.close,
  };
  bridge.localSettings = nested;
  bridge.hostSettings = nested;
  bridge.settings = nested;
  (window as any).rakazoDesktop = bridge;
  (window as any).rakazoHostSettings = nested;
  (window as any).rakazoLocalSettings = nested;
}

async function activateI18n(): Promise<any> {
  const { i18n } = await import("@lingui/core");
  try {
    i18n.load("en", {});
    i18n.activate("en");
  } catch {
    /* already active */
  }
  return i18n;
}

/**
 * Render the submission's web application at `pageAddress` with no signed-in
 * session, surface model and integration management by exercising the page's
 * own navigation, and return what was observed.
 *
 * @param pageAddress the settings-page address constant the submission exports
 *   from its shared contract. Pass the submission's OWN value; do not hardcode a
 *   literal.
 */
export async function renderHostSettingsSurface(pageAddress: string): Promise<HostSettingsProbe> {
  if (typeof document === "undefined") {
    throw new Error(
      "renderHostSettingsSurface requires a DOM. Add `// @vitest-environment jsdom` " +
        "as the first line of the test file.",
    );
  }
  if (typeof pageAddress !== "string" || !pageAddress.startsWith("/")) {
    throw new Error(
      `renderHostSettingsSurface needs the submission's settings-page address ` +
        `(a "/"-prefixed string); got ${JSON.stringify(pageAddress)}. Import it from the ` +
        `submission's shared contract and pass its value.`,
    );
  }

  // Point the browser location at the settings-page address BEFORE the app
  // module loads, so an App that branches on window.location.pathname sees it.
  try {
    delete (window as any).location;
    (window as any).location = new URL("http://127.0.0.1:5173" + pageAddress);
  } catch {
    try {
      window.history.replaceState({}, "", pageAddress);
    } catch {
      /* ignore */
    }
  }

  installPermissiveBridge();
  const i18n = await activateI18n();

  const { act, createElement } = await import("react");
  const { createRoot } = await import("react-dom/client");
  const { I18nProvider } = await import("@lingui/react");
  const { MemoryRouter } = await import("react-router-dom");
  // The submission's own top-level application component (pre-existing symbol).
  const { App } = await import("../App");

  (globalThis as any).IS_REACT_ACT_ENVIRONMENT = true;

  const container = document.createElement("div");
  document.body.appendChild(container);
  const root = createRoot(container);

  const flush = async () => {
    await act(async () => {
      await new Promise((r) => setTimeout(r, 60));
    });
  };

  const tree = createElement(
    I18nProvider,
    { i18n },
    createElement(MemoryRouter, { initialEntries: [pageAddress] }, createElement(App)),
  );
  await act(async () => {
    root.render(tree);
  });
  await flush();

  const bodyText = () => (document.body.textContent || "").toLowerCase();

  const controlsMatching = (re: RegExp) =>
    [...document.querySelectorAll('button, [role="tab"], a')].filter((el) =>
      re.test((el.textContent || "").toLowerCase()),
    );
  const clickEl = async (el: Element) => {
    try {
      await act(async () => {
        el.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true }));
      });
      await flush();
    } catch {
      /* a nav click that throws is not fatal to the probe */
    }
  };

  // Surface the model-management area, then the integration-management area, by
  // clicking the surface's own navigation controls (one at a time).
  for (const el of controlsMatching(/model/)) await clickEl(el);
  const afterModelText = bodyText();
  for (const el of controlsMatching(/integration/)) await clickEl(el);
  const finalText = bodyText();

  // Model management: an active-model readout or a provider-management area is
  // the management affordance the reused model-settings surface renders.
  const modelManagement =
    /active model/.test(finalText) ||
    /provider/.test(afterModelText) ||
    /model catalog/.test(finalText) ||
    !!document.querySelector('[data-testid*="model" i]');

  // Integration management: a server-integration configuration area. The reused
  // integration-setup surface renders a "server integrations" heading and an
  // integration-options fieldset / managed provider choices (Composio /
  // Pipedream).
  const integrationManagement =
    /server integrations/.test(finalText) ||
    /composio|pipedream/.test(finalText) ||
    !!document.querySelector("fieldset[aria-label]") ||
    !!document.querySelector('[data-testid*="integration" i]');

  // A genuine host-settings experience surfaced management affordances; the bare
  // sign-in / loading / session-unavailable flow surfaces neither.
  const reachedWithoutSession = modelManagement || integrationManagement;

  try {
    await act(async () => {
      root.unmount();
    });
  } catch {
    /* ignore teardown races */
  }
  await new Promise<void>((r) => setTimeout(r, 0));
  container.remove();

  return {
    reachedWithoutSession,
    modelManagement,
    integrationManagement,
    text: finalText.slice(0, 4000),
  };
}
