#!/usr/bin/env bash
# test-setup.sh: environment bootstrap for the verifier.
# Sourced (not exec'd) by the harbor verifier runner so env vars and
# anything else stay alive for vitest.
#
# Idempotent. The Dockerfile already installs the pnpm dependency closure
# at the base commit (`pnpm install --frozen-lockfile`, store warm under
# /opt/cache/pnpm-dev); this re-runs it only as a guard when node_modules is
# missing. The verifier starts native Node child processes and needs no
# database, server, or display.

set -e

REPO_DIR="${REPO_DIR:-/repo/rakazo}"
cd "$REPO_DIR"

node --version
pnpm --version

# Reinstall workspace deps only if they are missing. Offline-first
# against the warm store; fall back to an online install (logged) if the
# offline store is missing a needed package.
if [ ! -d "node_modules/.pnpm" ]; then
    echo "[test-setup] node_modules missing; reinstalling..."
    if pnpm install --frozen-lockfile --offline 2>&1 | tail -15; then
        echo "[test-setup] offline install ok"
    else
        echo "[test-setup] offline install failed; retrying online (network fallback)..."
        pnpm install --frozen-lockfile 2>&1 | tail -15
    fi
fi

# Generate the Prisma client if it is missing, so workspace modules that
# import @rakazo/db resolve. No database connection is made.
if [ -d "packages/db" ] && [ ! -d "node_modules/.prisma/client" ] \
   && [ ! -d "node_modules/@prisma/client" ]; then
    echo "[test-setup] generating prisma client..."
    pnpm --filter @rakazo/db exec prisma generate 2>&1 | tail -10 || true
fi

# Make workspace binaries available on PATH.
export PATH="$REPO_DIR/node_modules/.bin:$PATH"

# Build the shared contracts package when its manifest declares a build script,
# so any built `dist/` entry it exports exists before the verifier loads the
# package the way the packaged desktop app does. With no build script this is a
# no-op. A failing build does not stop setup: the verifier then loads the
# package as it stands, and an entry that cannot load fails there.
if [ -f "packages/contracts/package.json" ] \
   && node -e 'process.exit(require("./packages/contracts/package.json").scripts && require("./packages/contracts/package.json").scripts.build ? 0 : 1)' 2>/dev/null; then
    echo "[test-setup] building @rakazo/contracts (dist entry present in its package manifest)..."
    pnpm --filter @rakazo/contracts run build 2>&1 | tail -10 || \
        echo "[test-setup] contracts build reported an error; continuing with the package as it stands"
fi

echo "[test-setup] ready: $REPO_DIR (node=$(node --version), pnpm=$(pnpm --version))"
