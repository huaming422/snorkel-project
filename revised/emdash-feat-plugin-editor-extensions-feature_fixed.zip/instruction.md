## Task

We want sandboxed plugins to add to the screen where someone edits a saved entry, without ever seeing what the user has typed but not saved.
There are two kinds of editor extension: a panel the plugin renders next to the entry, and an action the user clicks to run on it.
Leave the React admin UI, the browser side, the CLI and the marketplace out of this pass.

## User stories / requirements

- Only a signed-in caller using the app's same-origin header, holding the route's permission, and either the entry's author or holding `content:edit_any` can run an extension; anyone else gets a client error. The plugin receives only the saved entry's collection, id, locale and version, the admin locale and its direction, and the extension id.
- The host resolves exactly one extension: the requested kind and id, from an enabled plugin, listed for the entry's collection. No match, a disabled plugin, or two declarations sharing that id gets a client error. An extension bound to a public route is never called.
- A client can reach both kinds of extension through a route the app mounts, and calling it runs the extension for that saved entry. Whatever the client sends along with an action is not passed on, and the action still runs.
- A panel request is a plain load or an existing Block Kit interaction (block action or form submit); anything else gets a client error. Panels reply with Block Kit. Actions may only notify, refresh, or navigate somewhere safe (not a `javascript:` URL), never refresh and navigate together. Any other plugin reply becomes a server error.
- Plugins can declare editor panels and actions in their manifest, and the host keeps valid declarations. It refuses a bundle when a declaration is malformed or ambiguous, goes beyond what the host allows, isn't backed by one of the plugin's private routes, or would let a dangerous action run without asking the user first.
