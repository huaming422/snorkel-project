## Task

Sandboxed plugins can't add anything to the screen where someone edits a saved entry.
We want plugins to offer two kinds of editor extension there.
A panel is a surface the plugin renders next to the entry.
An action is something the user clicks to run on the entry.
Each extension is served by one of the plugin's private routes, and the editor calls it over the EmDash API.

The plugin gets only what the host builds for it: the saved entry's identity (collection, id, locale, version), the admin locale for the request with its text direction, and which extension is running.
No field values reach the plugin, and nothing the user has typed but not saved.
Whatever the client sends along with an action is not passed on, and the action still runs.

If the caller isn't allowed, no extension matches, or a panel request is malformed, the client gets a client error and the plugin is not called.
Panels reply with an ordinary Block Kit response.
A plugin reply that breaks the rules below is a server error and never reaches the client.

This is server work only: the endpoint, the payload checks and the manifest fields.
Leave out the admin React UI, browser flows, and the CLI and marketplace tooling.

## User stories / requirements

- Before calling the plugin, the host reloads the saved entry and checks the caller: signed in, sending the same-origin header, allowed by the route's permission, and either the entry's author or holding `content:edit_any`. An extension bound to a public route is never called. The plugin then gets only the host-built context.
- The host resolves exactly one extension for a request: the requested kind and id, from an enabled plugin, listed for the entry's collection. If nothing matches, the plugin is disabled, or two declarations share that id, the request is refused.
- A client can reach both kinds of extension through a route the app mounts, and calling it runs the extension for that saved entry.
- A panel request carries a plain load or one of the existing Block Kit interactions (a block action or a form submit), and anything outside those shapes is refused before the plugin runs. An action reply may only notify, refresh, or navigate somewhere safe (never a `javascript:` URL), and it can't both refresh and navigate.
- Plugins declare editor panels and actions in their manifest, and valid ones are kept. The host refuses a plugin bundle when one kind repeats an id, an id isn't a lowercase slug, a kind exceeds its cap, an extension names an undeclared or public route, or a dangerous action lacks a confirmation step.
