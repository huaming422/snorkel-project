## Task

Sandboxed plugins can't add anything to the screen where someone edits a saved entry.
We want plugins to offer two kinds of editor extension there.
A panel is a surface the plugin renders next to the entry.
An action is something the user clicks to run on the entry.
Each extension is served by one of the plugin's private routes, and the admin client calls it over the EmDash API.

The host sits between the client and the plugin and builds everything the plugin gets.
For one call, the plugin sees only:

- the saved entry's collection, id, locale and version;
- the admin locale for the request, resolved the way the admin already does it (the `emdash-locale` cookie, then `Accept-Language`), plus that locale's text direction;
- the id of the extension being run.

No field values reach the plugin, and nothing the user has typed but not saved.
An action request may carry any body, but the host ignores it and still runs the action.
A panel request carries one interaction, which the host checks before passing it on.

Status codes follow the rest of the API.
Not signed in is a 401.
A missing `X-EmDash-Request: 1` header, or a user who may not act on the entry, is a 403.
No matching extension is a 404.
A malformed panel interaction is a 4xx.
Panels reply with an ordinary Block Kit response.
A plugin reply that breaks the rules below is a 5xx and never reaches the client.
Whenever a request is refused, the plugin is not called.

This is server work only: the endpoint, the payload checks and the manifest fields.
Leave out the admin React UI, browser flows, and the CLI and marketplace tooling.

## User stories / requirements

- Before calling the plugin, the host reloads the saved entry and checks the caller: signed in, sending the same-origin header, allowed by the route's permission, and either the entry's author or holding `content:edit_any`. An extension bound to a public route is never called. The plugin then gets only the host-built context.
- The host resolves exactly one extension for a request: the requested kind and id, from an enabled plugin, listed for the entry's collection. If nothing matches, the plugin is disabled, or two declarations share that id, the answer is a 404.
- A client can reach both kinds of extension through a route the app mounts, and calling it runs the extension for that saved entry.
- A panel interaction is a load, a Block Kit `block_action` or a `form_submit`, each with only its own fields; the last two need an `action_id`, and form `values` must be an object. An action reply may only notify, refresh, or navigate somewhere safe (never a `javascript:` URL), and it can't both refresh and navigate.
- Plugins declare editor panels and actions in their manifest, and valid ones are kept. The host refuses a plugin bundle when one kind repeats an id, an id isn't a lowercase slug, a kind exceeds its cap, an extension names an undeclared or public route, or a dangerous action lacks a confirmation step.
