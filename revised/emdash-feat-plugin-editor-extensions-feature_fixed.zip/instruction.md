## Task

Sandboxed plugins can't add anything to the screen where someone edits a saved entry.
We want them to offer two kinds of editor extension there: a panel the plugin renders next to the entry, and an action the user clicks to run on it.
The plugin stays sandboxed, so it should never see what the user has typed but not saved.
Skip the admin React UI, browser flows and the CLI and marketplace tooling for now.

## User stories / requirements

- Before calling the plugin, the host reloads the saved entry and requires a signed-in caller sending the same-origin header, with the route's permission and either authorship or `content:edit_any`. Anyone else gets a client error. The plugin receives only the entry's collection, id, locale and version, the admin locale and its direction, and the extension id.
- The host resolves exactly one extension: the requested kind and id, from an enabled plugin, listed for the entry's collection. No match, a disabled plugin, or two declarations sharing that id gets a client error. An extension bound to a public route is never called.
- A client can reach both kinds of extension through a route the app mounts, and calling it runs the extension for that saved entry. Whatever the client sends along with an action is not passed on, and the action still runs.
- A panel request is a plain load or an existing Block Kit interaction (block action or form submit); anything else gets a client error. Panels reply with Block Kit. Actions may only notify, refresh, or navigate somewhere safe (not a `javascript:` URL), never refresh and navigate together. Any other plugin reply becomes a server error.
- Plugins declare editor panels and actions in their manifest, and valid ones are kept. The host refuses a plugin bundle when one kind repeats an id, an id isn't a lowercase slug, a kind exceeds its cap, an extension names an undeclared or public route, or a dangerous action lacks a confirmation step.
