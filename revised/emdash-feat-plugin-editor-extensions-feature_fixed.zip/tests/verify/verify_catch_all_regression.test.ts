// Authorization of the plugin API catch-all (`/_emdash/api/plugins/{id}/*`):
// private routes need a caller holding the route's permission (default
// plugins:manage) and the `X-EmDash-Request: 1` header; public routes need
// neither and get no caller bound. Drives the catch-all's GET/POST exports
// with a stub runtime, the way the repo's own route tests do.
import { Role, type RoleLevel } from "@emdash-cms/auth";
import type { APIRoute } from "astro";
import { describe, expect, it, vi } from "vitest";

import { GET, POST } from "../../../src/astro/routes/api/plugins/[pluginId]/[...path].js";

// The methods passed in answer as configured. Any other runtime method the
// catch-all consults answers undefined, the same as a route the runtime knows
// nothing extra about. "then" stays absent so the stub is never awaited as a
// promise.
function stubRuntime(methods: Record<string, unknown>) {
	return new Proxy(methods, {
		get(target, key) {
			if (typeof key !== "string" || key === "then") return undefined;
			if (Object.hasOwn(target, key)) return target[key];
			return () => undefined;
		},
	});
}

function createLocals(role: RoleLevel | null, routePublic: boolean, permission?: string) {
	const handlePluginApiRoute = vi.fn(async () => ({ success: true, data: { ok: true } }));
	return {
		locals: {
			user: role == null ? null : { id: "u1", role },
			emdash: stubRuntime({
				handlePluginApiRoute,
				getPluginRouteMeta: () => ({ public: routePublic, permission }),
			}),
		},
		handlePluginApiRoute,
	};
}

function invoke(
	handler: APIRoute,
	method: string,
	locals: unknown,
	{ csrf = true }: { csrf?: boolean } = {},
) {
	const headers = new Headers();
	if (csrf) headers.set("X-EmDash-Request", "1");
	const request = new Request("https://example.com/_emdash/api/plugins/demo/updateHomeConfig", {
		method,
		headers,
	});
	return handler({
		params: { pluginId: "demo", path: "updateHomeConfig" },
		request,
		locals,
	} as never);
}

describe("plugin API catch-all authorization", () => {
	it("blocks an editor on a private route via POST", async () => {
		const { locals, handlePluginApiRoute } = createLocals(Role.EDITOR, false);
		const res = await invoke(POST, "POST", locals);
		expect(res.status).toBe(403);
		expect(handlePluginApiRoute).not.toHaveBeenCalled();
	});

	it("blocks an editor on a private route via GET (method does not tier auth)", async () => {
		const { locals, handlePluginApiRoute } = createLocals(Role.EDITOR, false);
		const res = await invoke(GET, "GET", locals);
		expect(res.status).toBe(403);
		expect(handlePluginApiRoute).not.toHaveBeenCalled();
	});

	it("honors a private route's explicitly declared permission", async () => {
		const { locals, handlePluginApiRoute } = createLocals(Role.EDITOR, false, "content:create");
		const res = await invoke(POST, "POST", locals);
		expect(res.status).toBe(200);
		expect(handlePluginApiRoute).toHaveBeenCalledOnce();
	});

	it("rejects a private request without the same-origin signal even for an admin", async () => {
		const { locals, handlePluginApiRoute } = createLocals(Role.ADMIN, false);
		const res = await invoke(GET, "GET", locals, { csrf: false });
		expect(res.status).toBe(403);
		expect(handlePluginApiRoute).not.toHaveBeenCalled();
	});

	it("allows an admin carrying the same-origin signal", async () => {
		const { locals, handlePluginApiRoute } = createLocals(Role.ADMIN, false);
		const res = await invoke(POST, "POST", locals);
		expect(res.status).toBe(200);
		expect(handlePluginApiRoute).toHaveBeenCalledOnce();
	});

	it("leaves public routes reachable without auth or the same-origin signal", async () => {
		const { locals, handlePluginApiRoute } = createLocals(null, true);
		const res = await invoke(GET, "GET", locals, { csrf: false });
		expect(res.status).toBe(200);
		expect(handlePluginApiRoute).toHaveBeenCalledOnce();
	});

	it("forwards the authenticated caller for private routes", async () => {
		const { locals, handlePluginApiRoute } = createLocals(Role.ADMIN, false);
		const res = await invoke(POST, "POST", locals);
		expect(res.status).toBe(200);
		// The first five arguments (id, method, path, request, caller) are the
		// forwarding contract; trailing optional arguments are not asserted.
		expect(handlePluginApiRoute).toHaveBeenCalledOnce();
		const [pluginId, method, path, forwardedRequest, caller] =
			handlePluginApiRoute.mock.calls[0];
		expect(pluginId).toBe("demo");
		expect(method).toBe("POST");
		expect(path).toBe("/updateHomeConfig");
		// The forwarded request may come from another global realm, so only its
		// shape is checked, not its constructor.
		expect(forwardedRequest).toBeTruthy();
		expect(typeof (forwardedRequest as Request).method).toBe("string");
		expect(caller).toMatchObject({ id: "u1", role: Role.ADMIN });
	});

	it("does not bind an ambient session as the caller of a public route", async () => {
		const { locals, handlePluginApiRoute } = createLocals(Role.ADMIN, true);
		const res = await invoke(GET, "GET", locals, { csrf: false });
		expect(res.status).toBe(200);
		expect(handlePluginApiRoute).toHaveBeenCalledOnce();
		const [pluginId, method, path, forwardedRequest, caller] =
			handlePluginApiRoute.mock.calls[0];
		expect(pluginId).toBe("demo");
		expect(method).toBe("GET");
		expect(path).toBe("/updateHomeConfig");
		// Shape only, as above.
		expect(forwardedRequest).toBeTruthy();
		// A public route gets no caller, even when an admin session is present.
		expect(caller).toBeUndefined();
	});
});
