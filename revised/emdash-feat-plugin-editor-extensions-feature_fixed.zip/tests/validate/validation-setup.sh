#!/usr/bin/env bash
# validation-setup.sh: environment bootstrap for the validation story scripts.
# Sourced by the validation harness before it runs each story. Idempotent and
# offline-first: the image baked the full dependency closure and a workspace
# build, so the common path does no network I/O. It mirrors tests/test-setup.sh
# because the validation story files run under the SAME core vitest config and
# resolve the SAME cross-package built outputs.

set -e

REPO_DIR="${REPO_DIR:-/repo/emdash}"
cd "$REPO_DIR"

# Sanity: the pinned toolchain is reachable.
node --version
pnpm --version
npx vitest --version

# Sync pnpm's internal state (needed for pnpm verifyDepsBeforeRun=error with CI env).
# Under the offline fold the harness sets CI=true, which flips pnpm's
# enableGlobalVirtualStore setting away from the state baked at image build and
# trips [ERR_PNPM_VERIFY_DEPS_BEFORE_RUN] on any subsequent `pnpm --filter ... build`.
# Running install unconditionally re-syncs that state. It is offline-first (the
# image baked the full closure) and completes in ~430ms, so it is cheap to always run.
echo "[validation-setup] syncing workspace deps (offline, frozen)..."
pnpm install --frozen-lockfile --offline 2>&1 | tail -5

# Always rebuild these packages. The story files run under packages/core's
# vitest config, which has no src alias, so cross-package imports
# (@emdash-cms/blocks/server, @emdash-cms/auth) resolve to each package's built
# dist/. The dist/ baked into the image reflects the original source, so it is
# rebuilt here from the current source. Caches are warm, so this is fast.
echo "[validation-setup] building @emdash-cms/blocks (from current source)..."
pnpm --filter @emdash-cms/blocks build 2>&1 | tail -5
echo "[validation-setup] building emdash core (from current source)..."
pnpm --filter emdash build 2>&1 | tail -5

# Build the rest of the workspace if any package's dist is missing (covers a
# fresh node_modules after a reinstall).
need_build=0
for pkg_json in packages/*/package.json; do
    pkg_dir=$(dirname "$pkg_json")
    if [ ! -d "$pkg_dir/dist" ] && [ -f "$pkg_dir/tsconfig.json" ]; then
        need_build=1
        break
    fi
done
if [ "$need_build" = "1" ]; then
    echo "[validation-setup] building all workspace packages..."
    pnpm run build 2>&1 | tail -5
fi

# Make workspace bins available to the harness.
export PATH="$REPO_DIR/node_modules/.bin:$PATH"

# Fail fast if a built entrypoint the stories import is missing, so a broken
# build shows up here instead of as import errors inside every story.
node -e '
const fs = require("fs");
const path = require("path");
const repoDir = process.env.REPO_DIR || "/repo/emdash";
const required = [
  // Block Kit library server entrypoint.
  path.join(repoDir, "packages/blocks/dist/server.js"),
  // Core built entrypoint.
  path.join(repoDir, "packages/core/dist/index.mjs"),
];
const missing = required.filter((p) => !fs.existsSync(p));
if (missing.length > 0) {
  console.error("[validation-setup] Missing built outputs:", missing.join(", "));
  process.exit(1);
}
console.log("[validation-setup] built outputs OK (blocks/server, core index)");
'

echo "[validation-setup] ready: $REPO_DIR (node=$(node --version), pnpm=$(pnpm --version))"
