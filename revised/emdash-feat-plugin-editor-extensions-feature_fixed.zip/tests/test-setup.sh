#!/usr/bin/env bash
# Sourced (not exec'd) by the verifier runner so env vars stay alive for vitest.
# Idempotent. Runs with network available (verifier phase) but offline-first:
# the image baked the full dependency closure into /opt/cache/pnpm-dev and a
# workspace build, so the common path does no network I/O.

set -e

REPO_DIR="${REPO_DIR:-/repo/emdash}"
cd "$REPO_DIR"

node --version
pnpm --version

# Sync pnpm's internal state (needed for pnpm verifyDepsBeforeRun=error with CI env).
# Under the offline fold the harness sets CI=true, which flips pnpm's
# enableGlobalVirtualStore setting away from the state baked at image build and
# trips [ERR_PNPM_VERIFY_DEPS_BEFORE_RUN] on any subsequent `pnpm --filter ... build`.
# Running install unconditionally re-syncs that state. It is offline-first (the
# image baked the full closure) and completes in ~430ms, so it is cheap to always run.
echo "[test-setup] syncing workspace deps (offline, frozen)..."
pnpm install --frozen-lockfile --offline 2>&1 | tail -5

# Always rebuild these packages. The core unit tests import cross-package code
# (@emdash-cms/blocks/server, @emdash-cms/auth, @emdash-cms/admin/locales) that
# vitest resolves to each package's built dist/ (core's vitest config has no src
# alias). The dist/ baked into the image reflects the original source, so it is
# rebuilt here from the current source. The build cache is warm, so this is fast.
echo "[test-setup] building @emdash-cms/blocks (from current source)..."
pnpm --filter @emdash-cms/blocks build 2>&1 | tail -5
echo "[test-setup] building emdash core (from current source)..."
pnpm --filter emdash build 2>&1 | tail -5

# Build the rest of the workspace if any package's dist is missing (covers a
# fresh node_modules after a reinstall).
need_build=0
for pkg_json in packages/*/package.json; do
    pkg_dir=$(dirname "$pkg_json")
    if [ ! -d "$pkg_dir/dist" ] && [ -f "$pkg_dir/tsconfig.json" ]; then
        need_build=1
        break
    fi
done
if [ "$need_build" = "1" ]; then
    echo "[test-setup] building all workspace packages..."
    pnpm run build 2>&1 | tail -5
fi

# Make workspace bins available to the runner.
export PATH="$REPO_DIR/node_modules/.bin:$PATH"

echo "[test-setup] ready: $REPO_DIR (node=$(node --version), pnpm=$(pnpm --version))"
