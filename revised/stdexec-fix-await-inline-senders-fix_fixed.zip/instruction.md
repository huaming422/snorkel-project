## Task

We write coroutines with the library's `ex::task<T>` (it comes in with `<stdexec/execution.hpp>`, and our code has `namespace ex = std::execution`) and `co_await` senders inside them.
A coroutine that awaits a long run of cheap senders, ones that finish as soon as they start, crashes.

Here is the smallest repro, the body of a `task<int>`:

```cpp
int sum = 0;
for (int i = 0; i < 1'000'000; ++i)
    sum += co_await ex::just(42);
co_return sum;
```

We run it with `ex::sync_wait(...)`.
Instead of handing back the sum, the process dies with a stack overflow.

Only long runs of these awaits inside one coroutine do this.
With a few thousand iterations the same loop finishes fine, and one await or a handful of them work as they should, whether the sender gives a value, an error or a stop.
It isn't tied to `just`.
A loop over `co_await ex::read_env(ex::get_scheduler)`, `co_await ex::schedule(ex::inline_scheduler{})` or `co_await (ex::just(i) | ex::then(f))` with a `noexcept` `f` dies the same way.
So does a loop where each awaited sender fails right away with an error that the coroutine catches before going round again.

Please make these coroutines run to the end without the stack getting deeper as the loop goes on, so the repro returns its sum.
Awaits on senders that finish later, on another thread or scheduler, have to keep working the way they do today, including ones that end in an error or a stop.

The library is header-only.
Its source is at `/repo/stdexec`, already configured and built under `/repo/stdexec/build`, so rebuilds are incremental.
There's no network access, but everything the build needs is already there.
