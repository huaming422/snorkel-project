#!/usr/bin/env bash
# test-setup.sh - sourced before the verifier runs.
#
# stdexec is a header-only C++20 library, so there is no library to rebuild;
# code that uses it just recompiles against the current headers. This script
# does two things:
#   1. Rebuilds the pre-configured test tree incrementally, so only the
#      translation units that include changed headers recompile.
#   2. Leaves that build in place so the verifier can compile its own
#      standalone programs against /repo/stdexec/include and run the project's
#      own task tests.
#
# Runs offline. All dependencies are baked into the image under
# /repo/stdexec/build/_deps; no network is used here.
set -euo pipefail

REPO=/repo/stdexec
BUILD="${REPO}/build"

cd "${REPO}"

echo "test-setup: incremental reconfigure + build of the test tree..."
# The build dir was configured when the image was built, with
# -DSTDEXEC_BUILD_TESTS=ON and its dependencies under build/_deps, so this
# step needs no network. Only the TUs that include changed headers recompile.
if [ -d "${BUILD}" ]; then
  # Build the full test target so the verifier can run the project's own
  # task cases.
  cmake --build "${BUILD}" --target test.stdexec > /tmp/test-setup-build.log 2>&1 || {
    echo "test-setup: test.stdexec build failed; tail of log:" >&2
    tail -120 /tmp/test-setup-build.log >&2
    exit 1
  }
else
  echo "test-setup: ${BUILD} missing, reconfiguring from scratch (offline)..." >&2
  cmake -S "${REPO}" -B "${BUILD}" -DCMAKE_BUILD_TYPE=Release -DSTDEXEC_BUILD_TESTS=ON \
    > /tmp/test-setup-configure.log 2>&1 || {
      echo "test-setup: configure failed; tail of log:" >&2
      tail -120 /tmp/test-setup-configure.log >&2
      exit 1
    }
  cmake --build "${BUILD}" --target test.stdexec > /tmp/test-setup-build.log 2>&1 || {
    echo "test-setup: test.stdexec build failed; tail of log:" >&2
    tail -120 /tmp/test-setup-build.log >&2
    exit 1
  }
fi

# Sanity: the headers must still compile in a small standalone program, so a
# syntax error shows up here before the verifier's own programs use them.
echo "test-setup: header syntax sanity compile..."
SANITY_SRC=$(mktemp /tmp/stdexec-sanity-XXXX.cpp)
cat > "${SANITY_SRC}" <<'CPP'
#include <exec/task.hpp>
#include <stdexec/execution.hpp>
namespace ex = std::execution;
ex::task<int> __sanity() { co_return co_await ex::just(1); }
int main() { return 0; }
CPP
if ! g++-12 -std=c++20 -DSTDEXEC_NAMESPACE=std::execution \
      -I"${REPO}/include" "${SANITY_SRC}" -o /tmp/stdexec-sanity \
      > /tmp/test-setup-sanity.log 2>&1; then
  echo "test-setup: headers failed to compile a standalone program:" >&2
  tail -120 /tmp/test-setup-sanity.log >&2
  rm -f "${SANITY_SRC}"
  exit 1
fi
rm -f "${SANITY_SRC}"

echo "test-setup: ready."
