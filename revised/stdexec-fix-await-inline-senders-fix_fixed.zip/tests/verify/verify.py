"""Behavioral checks for long runs of inline-completing awaits in stdexec's task.

Everything goes through the library's public coroutine surface: define an
``ex::task<T>`` coroutine, ``co_await`` senders inside it and drive it with
``ex::sync_wait``. No internal symbol or header path is inspected, so any
change that keeps these programs correct passes, however it is named or
factored.

Each test writes a small standalone C++20 program, compiles it with g++-12
against the headers under ``/repo/stdexec/include`` using the project's
namespace flag, and runs it. The million-iteration loops run on a worker
thread with a fixed 512 KiB stack, and the headline program also measures how
far the stack moved between an early and the last iteration of its loop. The
stop program is built with AddressSanitizer, so any read or write of freed
memory while a task ends stopped makes it exit with an error report.

The module imports no project Python and needs no ``[pytest] command``
override; it runs under the default verifier interpreter.
"""

from __future__ import annotations

import glob
import os
import subprocess
import tempfile

import pytest


# Toolchain and repo constants:
#  - ``g++-12``: the compiler the image installs (stdexec needs GCC >= 12).
#  - ``-std=c++20``: the library is C++20; GCC 12 enables coroutines with it.
#  - ``-DSTDEXEC_NAMESPACE=std::execution``: the project's own build and tests
#    use this, so ``std::execution`` is the namespace the headers fill in.
#  - ``-lpthread``: the fixed-stack worker uses POSIX threads.
# No -O flag is passed, so the programs build at g++'s default level.
CXX = os.environ.get("STDEXEC_CXX", "g++-12")
REPO = os.environ.get("STDEXEC_REPO", "/repo/stdexec")
INCLUDE = f"{REPO}/include"
BUILD = f"{REPO}/build"

CXX_FLAGS = [
    "-std=c++20",
    "-DSTDEXEC_NAMESPACE=std::execution",
    f"-I{INCLUDE}",
]
LINK_FLAGS = ["-lpthread"]

# Compiling a template-heavy stdexec translation unit takes most of each
# test's time; the loops themselves are short. Both limits sit well inside
# the 1200 s verifier timeout.
COMPILE_TIMEOUT = 300
RUN_TIMEOUT = 120

# 1,000,000 awaits of just(42).
EXPECTED_SUM_JUST = 42_000_000
# 1,000,000 iterations adding 42 after each read_env await.
EXPECTED_SUM_READ_ENV = 42_000_000
# Sum of i % 3 for i in [0, 1,000,000).
EXPECTED_SUM_INLINE_SCHEDULE = 999_999
# Sum of (i % 5) * 2 for i in [0, 1,000,000), each value passed through then.
EXPECTED_SUM_THEN_CHAIN = 4_000_000
# Sum of i % 7 for i in [0, 200,000), each value delivered as a caught error.
EXPECTED_SUM_CAUGHT_ERRORS = 599_994

# Loops over senders the instruction does not name, 1,000,000 awaits each:
# Sum of (i % 6) + 1, the value let_value hands back from just(i % 6).
EXPECTED_SUM_LET_VALUE = 3_499_996
# Sum of i % 4 through upon_error, which leaves values alone.
EXPECTED_SUM_UPON_ERROR = 1_500_000
# Sum of i % 9 through upon_stopped, which leaves values alone.
EXPECTED_SUM_UPON_STOPPED = 3_999_996
# Sum of (i % 5) + 3, sent by exec::just_from.
EXPECTED_SUM_JUST_FROM = 5_000_000
# Sum of i % 8 through write_env.
EXPECTED_SUM_WRITE_ENV = 3_500_000

# Each of the stop program's 50 rounds runs a task that returns
# 0+1+...+19 = 190 from twenty value awaits, one that returns 60 from thirty
# caught errors of (i % 3) + 1, one that returns 10 + 20 + 90 = 120 from ten
# rounds of read_env, inline schedule and then awaits, and four tasks that end
# stopped (200 in all).
EXPECTED_STOPPED = 200
EXPECTED_ASAN_VALUES = 50 * 190
EXPECTED_ASAN_ERRORS = 50 * 60
EXPECTED_ASAN_OTHERS = 50 * 120
ASAN_FLAGS = ["-fsanitize=address", "-fno-omit-frame-pointer"]
# Leak checking is off: it needs ptrace, which containers often block, and the
# check is about freed memory being touched, not about leaks.
ASAN_ENV = {"ASAN_OPTIONS": "detect_leaks=0"}

# Stack size of the worker thread that runs the long loops.
WORKER_STACK_BYTES = 512 * 1024

# Largest allowed distance between the stack positions measured at an early
# and at the last iteration of the headline loop. A loop whose stack stays
# put measures 0; the limit leaves room for a design that unwinds every so
# often, and is far below what a million nested frames would need.
MAX_STACK_DRIFT_BYTES = 256 * 1024


# ── C++ programs (public surface only) ─────────────────────────────────────

# One million awaits of just(42) in one task, driven by sync_wait on the
# fixed-size worker stack. stack_mark() returns the address of a local in a
# non-inlined call, which tracks how deep the stack is at that point.
PROG_HEADLINE = r"""
#include <exec/task.hpp>
#include <stdexec/execution.hpp>
#include <cstdint>
#include <cstdio>
#include <pthread.h>
namespace ex = std::execution;

static long g_result = -999;
static std::uintptr_t g_mark_early = 0;
static std::uintptr_t g_mark_last = 0;

[[gnu::noinline]] static std::uintptr_t stack_mark() {
  volatile char probe = 0;
  return reinterpret_cast<std::uintptr_t>(&probe);
}

ex::task<int> loop_just() {
  int sum = 0;
  for (int i = 0; i < 1000000; ++i) {
    sum += co_await ex::just(42);
    if (i == 1) g_mark_early = stack_mark();
    if (i == 999999) g_mark_last = stack_mark();
  }
  co_return sum;
}

static void* worker(void*) {
  auto r = ex::sync_wait(loop_just());
  g_result = r ? (long)std::get<0>(*r) : -2;
  return nullptr;
}

int main() {
  pthread_attr_t attr;
  pthread_attr_init(&attr);
  pthread_attr_setstacksize(&attr, %(stack)d);
  pthread_t t;
  if (pthread_create(&t, &attr, worker, nullptr) != 0) { std::printf("spawn-fail\n"); return 3; }
  pthread_join(t, nullptr);
  pthread_attr_destroy(&attr);
  long drift = g_mark_early > g_mark_last ? (long)(g_mark_early - g_mark_last)
                                          : (long)(g_mark_last - g_mark_early);
  std::printf("result=%%ld\n", g_result);
  std::printf("marks=%%d\n", (g_mark_early != 0 && g_mark_last != 0) ? 1 : 0);
  std::printf("drift=%%ld\n", drift);
  return g_result == %(expected)d ? 0 : 1;
}
""" % {"stack": WORKER_STACK_BYTES, "expected": EXPECTED_SUM_JUST}

# Four more long loops over senders that also finish inside start, each in
# its own task and run one after another on the fixed-size worker stack:
#  - read_env(get_scheduler), a different sender factory from just;
#  - schedule(inline_scheduler{}), a scheduler's sender;
#  - just(i % 5) | then(noexcept function), an adaptor over just;
#  - just_error(i % 7) caught inside the loop, so every await completes with
#    an error that the coroutine handles before the next iteration.
# Each result is printed as soon as its loop ends.
PROG_OTHER_INLINE = r"""
#include <exec/task.hpp>
#include <stdexec/execution.hpp>
#include <cstdio>
#include <pthread.h>
namespace ex = std::execution;

static long g_read_env = -999;
static long g_inline_schedule = -999;
static long g_then_chain = -999;
static long g_caught_errors = -999;

ex::task<int> loop_read_env() {
  int sum = 0;
  for (int i = 0; i < 1000000; ++i) {
    co_await ex::read_env(ex::get_scheduler);
    sum += 42;
  }
  co_return sum;
}

ex::task<int> loop_inline_schedule() {
  int sum = 0;
  for (int i = 0; i < 1000000; ++i) {
    co_await ex::schedule(ex::inline_scheduler{});
    sum += i %% 3;
  }
  co_return sum;
}

ex::task<int> loop_then_chain() {
  int sum = 0;
  for (int i = 0; i < 1000000; ++i)
    sum += co_await (ex::just(i %% 5) | ex::then([](int x) noexcept { return x * 2; }));
  co_return sum;
}

ex::task<int> loop_caught_errors() {
  int sum = 0;
  for (int i = 0; i < 200000; ++i) {
    try {
      co_await ex::just_error(i %% 7);
    } catch (int e) {
      sum += e;
    }
  }
  co_return sum;
}

static long run(ex::task<int> t) {
  auto r = ex::sync_wait(std::move(t));
  return r ? (long)std::get<0>(*r) : -2;
}

static void* worker(void*) {
  g_read_env = run(loop_read_env());
  std::printf("read_env=%%ld\n", g_read_env);
  std::fflush(stdout);
  g_inline_schedule = run(loop_inline_schedule());
  std::printf("inline_schedule=%%ld\n", g_inline_schedule);
  std::fflush(stdout);
  g_then_chain = run(loop_then_chain());
  std::printf("then_chain=%%ld\n", g_then_chain);
  std::fflush(stdout);
  g_caught_errors = run(loop_caught_errors());
  std::printf("caught_errors=%%ld\n", g_caught_errors);
  std::fflush(stdout);
  return nullptr;
}

int main() {
  pthread_attr_t attr;
  pthread_attr_init(&attr);
  pthread_attr_setstacksize(&attr, %(stack)d);
  pthread_t t;
  if (pthread_create(&t, &attr, worker, nullptr) != 0) { std::printf("spawn-fail\n"); return 3; }
  pthread_join(t, nullptr);
  pthread_attr_destroy(&attr);
  bool ok = g_read_env == %(read_env)d
         && g_inline_schedule == %(inline_schedule)d
         && g_then_chain == %(then_chain)d
         && g_caught_errors == %(caught_errors)d;
  return ok ? 0 : 1;
}
""" % {
    "stack": WORKER_STACK_BYTES,
    "read_env": EXPECTED_SUM_READ_ENV,
    "inline_schedule": EXPECTED_SUM_INLINE_SCHEDULE,
    "then_chain": EXPECTED_SUM_THEN_CHAIN,
    "caught_errors": EXPECTED_SUM_CAUGHT_ERRORS,
}

# Five more long loops, over senders that finish inside start but are not
# among the ones the instruction lists, on the same fixed-size worker stack:
#  - just(i % 6) | let_value(x -> just(x + 1));
#  - just(i % 4) | upon_error(...), which passes the value through;
#  - just(i % 9) | upon_stopped(...), which passes the value through;
#  - exec::just_from, which sends (i % 5) + 3 through its sink;
#  - write_env(just(i % 8), a never-stop token).
PROG_UNLISTED_INLINE = r"""
#include <exec/just_from.hpp>
#include <exec/task.hpp>
#include <stdexec/execution.hpp>
#include <cstdio>
#include <pthread.h>
namespace ex = std::execution;

static long g_let_value = -999;
static long g_upon_error = -999;
static long g_upon_stopped = -999;
static long g_just_from = -999;
static long g_write_env = -999;

ex::task<long> loop_let_value() {
  long sum = 0;
  for (int i = 0; i < 1000000; ++i)
    sum += co_await (ex::just(i %% 6) | ex::let_value([](int x) noexcept { return ex::just(x + 1); }));
  co_return sum;
}

ex::task<long> loop_upon_error() {
  long sum = 0;
  for (int i = 0; i < 1000000; ++i)
    sum += co_await (ex::just(i %% 4) | ex::upon_error([](auto) noexcept { return -1000; }));
  co_return sum;
}

ex::task<long> loop_upon_stopped() {
  long sum = 0;
  for (int i = 0; i < 1000000; ++i)
    sum += co_await (ex::just(i %% 9) | ex::upon_stopped([]() noexcept { return -1000; }));
  co_return sum;
}

ex::task<long> loop_just_from() {
  long sum = 0;
  for (int i = 0; i < 1000000; ++i)
    sum += co_await exec::just_from([i](auto sink) noexcept { return sink(i %% 5 + 3); });
  co_return sum;
}

ex::task<long> loop_write_env() {
  long sum = 0;
  for (int i = 0; i < 1000000; ++i)
    sum += co_await ex::write_env(ex::just(i %% 8), ex::prop{ex::get_stop_token, ex::never_stop_token{}});
  co_return sum;
}

static long run(ex::task<long> t) {
  auto r = ex::sync_wait(std::move(t));
  return r ? std::get<0>(*r) : -2;
}

static void* worker(void*) {
  g_let_value = run(loop_let_value());
  std::printf("let_value=%%ld\n", g_let_value);
  std::fflush(stdout);
  g_upon_error = run(loop_upon_error());
  std::printf("upon_error=%%ld\n", g_upon_error);
  std::fflush(stdout);
  g_upon_stopped = run(loop_upon_stopped());
  std::printf("upon_stopped=%%ld\n", g_upon_stopped);
  std::fflush(stdout);
  g_just_from = run(loop_just_from());
  std::printf("just_from=%%ld\n", g_just_from);
  std::fflush(stdout);
  g_write_env = run(loop_write_env());
  std::printf("write_env=%%ld\n", g_write_env);
  std::fflush(stdout);
  return nullptr;
}

int main() {
  pthread_attr_t attr;
  pthread_attr_init(&attr);
  pthread_attr_setstacksize(&attr, %(stack)d);
  pthread_t t;
  if (pthread_create(&t, &attr, worker, nullptr) != 0) { std::printf("spawn-fail\n"); return 3; }
  pthread_join(t, nullptr);
  pthread_attr_destroy(&attr);
  bool ok = g_let_value == %(let_value)d
         && g_upon_error == %(upon_error)d
         && g_upon_stopped == %(upon_stopped)d
         && g_just_from == %(just_from)d
         && g_write_env == %(write_env)d;
  return ok ? 0 : 1;
}
""" % {
    "stack": WORKER_STACK_BYTES,
    "let_value": EXPECTED_SUM_LET_VALUE,
    "upon_error": EXPECTED_SUM_UPON_ERROR,
    "upon_stopped": EXPECTED_SUM_UPON_STOPPED,
    "just_from": EXPECTED_SUM_JUST_FROM,
    "write_env": EXPECTED_SUM_WRITE_ENV,
}

# Built with AddressSanitizer. Each round runs, one after another:
#  - a task of twenty just(i) awaits that returns their sum;
#  - a task of thirty just_error((i % 3) + 1) awaits, each caught in the loop;
#  - a task of ten rounds of read_env(get_scheduler), schedule(inline_scheduler{})
#    and just(i) | then(x * 2), adding 1, 2 and 2 * i;
#  - four tasks that end stopped through a sender that stops as soon as it
#    starts: just_stopped() first thing, just_stopped() after a run of just
#    awaits, just(n) | let_value(-> just_stopped()), and
#    just_stopped() | then(f).
# Code after a stopped await bumps g_after, so a stop that lets the task go
# on shows up there. The program prints the totals and exits 0.
PROG_STOP_ASAN = r"""
#include <exec/task.hpp>
#include <stdexec/execution.hpp>
#include <cstdio>
namespace ex = std::execution;

static int g_after = 0;

ex::task<int> values() {
  int s = 0;
  for (int i = 0; i < 20; ++i) s += co_await ex::just(i);
  co_return s;
}

ex::task<int> caught_errors() {
  int s = 0;
  for (int i = 0; i < 30; ++i) {
    try {
      co_await ex::just_error(i % 3 + 1);
    } catch (int e) {
      s += e;
    }
  }
  co_return s;
}

ex::task<int> other_inline() {
  int s = 0;
  for (int i = 0; i < 10; ++i) {
    co_await ex::read_env(ex::get_scheduler);
    s += 1;
    co_await ex::schedule(ex::inline_scheduler{});
    s += 2;
    s += co_await (ex::just(i) | ex::then([](int x) noexcept { return x * 2; }));
  }
  co_return s;
}

ex::task<int> stop_first() {
  co_await ex::just_stopped();
  ++g_after;
  co_return 1;
}

ex::task<int> stop_after_run(int n) {
  int s = 0;
  for (int i = 0; i < n; ++i) s += co_await ex::just(i);
  co_await ex::just_stopped();
  ++g_after;
  co_return s;
}

ex::task<int> stop_via_let_value(int n) {
  int s = co_await ex::just(n);
  co_await (ex::just(n) | ex::let_value([](int) noexcept { return ex::just_stopped(); }));
  ++g_after;
  co_return s;
}

ex::task<int> stop_via_then() {
  co_await (ex::just_stopped() | ex::then([]() noexcept {}));
  ++g_after;
  co_return 7;
}

static long value_of(ex::task<int> t) {
  auto r = ex::sync_wait(std::move(t));
  return r ? (long)std::get<0>(*r) : -100000;
}

int main() {
  long values_total = 0;
  long errors_total = 0;
  long others_total = 0;
  int stopped = 0;
  for (int k = 0; k < 50; ++k) {
    values_total += value_of(values());
    errors_total += value_of(caught_errors());
    others_total += value_of(other_inline());
    stopped += !ex::sync_wait(stop_first());
    stopped += !ex::sync_wait(stop_after_run(100 + k));
    stopped += !ex::sync_wait(stop_via_let_value(k));
    stopped += !ex::sync_wait(stop_via_then());
  }
  std::printf("values=%ld\n", values_total);
  std::printf("errors=%ld\n", errors_total);
  std::printf("others=%ld\n", others_total);
  std::printf("stopped=%d\n", stopped);
  std::printf("after_stop=%d\n", g_after);
  return 0;
}
"""

# A short loop of ordinary inline awaits returns 0+1+2+3+4 = 10.
PROG_SMALL = r"""
#include <exec/task.hpp>
#include <stdexec/execution.hpp>
#include <cstdio>
namespace ex = std::execution;

ex::task<int> small() {
  int s = 0;
  for (int i = 0; i < 5; ++i) s += co_await ex::just(i);
  co_return s;
}

int main() {
  auto r = ex::sync_wait(small());
  long v = r ? (long)std::get<0>(*r) : -1;
  std::printf("small=%ld\n", v);
  return v == 10 ? 0 : 1;
}
"""

# Single awaits that end in an error or a stop:
#  - just() | then(throwing function), which throws as soon as it starts:
#    the error comes out of sync_wait as the same exception;
#  - starts_on(another thread, just_error(runtime_error("far"))), which
#    finishes later on that thread: the error
#    comes out of sync_wait as the same exception;
#  - starts_on(another thread, just_stopped()): the task ends stopped, so
#    sync_wait returns an empty result and the code after the await never runs.
# Each outcome is printed so the test checks the actual values.
PROG_ERROR = r"""
#include <exec/single_thread_context.hpp>
#include <exec/task.hpp>
#include <stdexec/execution.hpp>
#include <cstdio>
#include <stdexcept>
namespace ex = std::execution;

static bool g_after_stop = false;

ex::task<int> errtask() {
  int x = co_await (ex::just() | ex::then([]() -> int { throw std::runtime_error("boom"); }));
  co_return x;
}

ex::task<int> far_error(exec::single_thread_context& ctx) {
  co_await ex::starts_on(ctx.get_scheduler(), ex::just_error(std::runtime_error("far")));
  co_return 1;
}

ex::task<int> far_stop(exec::single_thread_context& ctx) {
  co_await ex::starts_on(ctx.get_scheduler(), ex::just_stopped());
  g_after_stop = true;
  co_return 1;
}

int main() {
  try {
    auto r = ex::sync_wait(errtask());
    std::printf("NO-EXCEPTION has-value=%d\n", (int)(bool)r);
  } catch (const std::runtime_error& e) {
    std::printf("caught=%s\n", e.what());
  } catch (...) {
    std::printf("caught=other\n");
  }
  std::fflush(stdout);

  exec::single_thread_context ctx;
  try {
    auto r = ex::sync_wait(far_error(ctx));
    std::printf("far_error=NO-EXCEPTION has-value=%d\n", (int)(bool)r);
  } catch (const std::runtime_error& e) {
    std::printf("far_error=%s\n", e.what());
  } catch (...) {
    std::printf("far_error=other\n");
  }
  std::fflush(stdout);

  auto r = ex::sync_wait(far_stop(ctx));
  std::printf("far_stop=%s\n", r ? "has-value" : "stopped");
  std::printf("after_stop=%d\n", g_after_stop ? 1 : 0);
  return 0;
}
"""


# ── Compile / run helpers ──────────────────────────────────────────────────


def _compile(source: str, stem: str, workdir: str, extra_flags: list[str] = ()) -> str:
    """Compile *source* against the repo headers and return the binary path.

    A compile failure fails the test, with the tail of the compiler's stderr.
    """
    src_path = os.path.join(workdir, f"{stem}.cpp")
    bin_path = os.path.join(workdir, stem)
    with open(src_path, "w") as f:
        f.write(source)

    cmd = [CXX, *CXX_FLAGS, *extra_flags, src_path, "-o", bin_path, *LINK_FLAGS]
    try:
        proc = subprocess.run(
            cmd, capture_output=True, text=True, timeout=COMPILE_TIMEOUT, check=False
        )
    except subprocess.TimeoutExpired:
        pytest.fail(f"compiling {stem}.cpp against {INCLUDE} took more than {COMPILE_TIMEOUT}s.")
    assert proc.returncode == 0, (
        f"{stem}.cpp failed to compile against {INCLUDE} (exit {proc.returncode}). "
        f"The task/co_await/sync_wait surface has to stay usable.\n"
        f"--- compiler stderr (tail) ---\n{proc.stderr[-3000:]}"
    )
    assert os.path.isfile(bin_path), f"{stem}: compiler produced no binary"
    return bin_path


def _run(bin_path: str, stem: str, env: dict[str, str] | None = None) -> subprocess.CompletedProcess:
    try:
        return subprocess.run(
            [bin_path],
            capture_output=True,
            text=True,
            timeout=RUN_TIMEOUT,
            check=False,
            env={**os.environ, **env} if env else None,
        )
    except subprocess.TimeoutExpired:
        pytest.fail(f"{stem} did not finish within {RUN_TIMEOUT}s.")


def _value(stdout: str, key: str) -> str | None:
    for line in stdout.splitlines():
        if line.startswith(f"{key}="):
            return line.split("=", 1)[1].strip()
    return None


# ── Tests ──────────────────────────────────────────────────────────────────


def test_million_just_awaits_return_sum_on_flat_stack():
    """A task<int> awaiting just(42) one million times returns 42,000,000.

    The loop runs under sync_wait on a 512 KiB worker stack and has to exit
    cleanly with the exact sum. The stack position measured at iteration 1
    and at the last iteration may differ by at most MAX_STACK_DRIFT_BYTES.
    """
    with tempfile.TemporaryDirectory(prefix="stdexec-verify-") as wd:
        binary = _compile(PROG_HEADLINE, "headline", wd)
        proc = _run(binary, "headline")
        assert proc.returncode == 0, (
            f"the million-await just(42) loop did not complete on a "
            f"{WORKER_STACK_BYTES}-byte stack (exit {proc.returncode}; a negative "
            f"code means the process was killed by a signal).\n"
            f"stdout: {proc.stdout!r}\nstderr: {proc.stderr[-800:]!r}"
        )
        assert _value(proc.stdout, "result") == str(EXPECTED_SUM_JUST), (
            f"expected result={EXPECTED_SUM_JUST}, got stdout {proc.stdout!r}."
        )
        assert _value(proc.stdout, "marks") == "1", (
            f"the loop body did not record both stack positions; stdout {proc.stdout!r}."
        )
        drift = int(_value(proc.stdout, "drift") or "-1")
        assert 0 <= drift <= MAX_STACK_DRIFT_BYTES, (
            f"the stack moved {drift} bytes between iteration 1 and the last "
            f"iteration of the million-await loop; the limit is "
            f"{MAX_STACK_DRIFT_BYTES} bytes."
        )


def test_other_inline_senders_and_caught_errors_on_flat_stack():
    """Long loops over other inline senders also finish with the right sums.

    On the same 512 KiB worker stack, one after another: a million awaits of
    read_env(get_scheduler) (sum 42,000,000), a million awaits of
    schedule(inline_scheduler{}) (sum of i % 3, 999,999), a million awaits of
    just(i % 5) | then(x * 2) with a noexcept function (4,000,000), and 200,000
    awaits of just_error(i % 7) caught inside the loop (sum of the caught
    values, 599,994).
    """
    with tempfile.TemporaryDirectory(prefix="stdexec-verify-") as wd:
        binary = _compile(PROG_OTHER_INLINE, "other_inline", wd)
        proc = _run(binary, "other_inline")
        expected = {
            "read_env": EXPECTED_SUM_READ_ENV,
            "inline_schedule": EXPECTED_SUM_INLINE_SCHEDULE,
            "then_chain": EXPECTED_SUM_THEN_CHAIN,
            "caught_errors": EXPECTED_SUM_CAUGHT_ERRORS,
        }
        got = {key: _value(proc.stdout, key) for key in expected}
        assert proc.returncode == 0, (
            f"the long loops did not all complete on a {WORKER_STACK_BYTES}-byte "
            f"stack (exit {proc.returncode}; a negative code means the process "
            f"was killed by a signal). Loops finished so far: {got}.\n"
            f"stderr: {proc.stderr[-800:]!r}"
        )
        for key, value in expected.items():
            assert got[key] == str(value), (
                f"expected {key}={value}, got {got[key]!r} (stdout {proc.stdout!r})."
            )


def test_unlisted_inline_senders_on_flat_stack():
    """Inline senders beyond the listed ones also finish with the right sums.

    On the same 512 KiB worker stack, a million awaits each of
    just(i % 6) | let_value(x -> just(x + 1)) (3,499,996),
    just(i % 4) | upon_error(...) (1,500,000),
    just(i % 9) | upon_stopped(...) (3,999,996),
    exec::just_from sending (i % 5) + 3 (5,000,000) and
    write_env(just(i % 8), ...) (3,500,000).
    """
    with tempfile.TemporaryDirectory(prefix="stdexec-verify-") as wd:
        binary = _compile(PROG_UNLISTED_INLINE, "unlisted_inline", wd)
        proc = _run(binary, "unlisted_inline")
        expected = {
            "let_value": EXPECTED_SUM_LET_VALUE,
            "upon_error": EXPECTED_SUM_UPON_ERROR,
            "upon_stopped": EXPECTED_SUM_UPON_STOPPED,
            "just_from": EXPECTED_SUM_JUST_FROM,
            "write_env": EXPECTED_SUM_WRITE_ENV,
        }
        got = {key: _value(proc.stdout, key) for key in expected}
        assert proc.returncode == 0, (
            f"the long loops did not all complete on a {WORKER_STACK_BYTES}-byte "
            f"stack (exit {proc.returncode}; a negative code means the process "
            f"was killed by a signal). Loops finished so far: {got}.\n"
            f"stderr: {proc.stderr[-800:]!r}"
        )
        for key, value in expected.items():
            assert got[key] == str(value), (
                f"expected {key}={value}, got {got[key]!r} (stdout {proc.stdout!r})."
            )


def test_inline_stops_end_tasks_cleanly_under_asan():
    """Tasks that stop through an inline sender end stopped, with no memory errors.

    Built with AddressSanitizer, 50 rounds of: twenty value awaits (190 per
    round), thirty caught errors (60 per round), ten rounds of read_env,
    inline schedule and then awaits (120 per round) and four tasks that end
    stopped through just_stopped(), just_stopped() after a run of just
    awaits, let_value returning just_stopped(), and just_stopped() | then(f).
    Every stopped task makes sync_wait return an empty result, no code after
    a stopped await runs, and the sanitizer reports nothing.
    """
    with tempfile.TemporaryDirectory(prefix="stdexec-verify-") as wd:
        binary = _compile(PROG_STOP_ASAN, "stop_asan", wd, ASAN_FLAGS)
        proc = _run(binary, "stop_asan", ASAN_ENV)
        assert "AddressSanitizer" not in proc.stderr, (
            f"AddressSanitizer reported an error while tasks ended stopped "
            f"(exit {proc.returncode}).\nstdout: {proc.stdout!r}\n"
            f"stderr (head): {proc.stderr[:3000]}"
        )
        assert proc.returncode == 0, (
            f"the stop program did not exit cleanly (exit {proc.returncode}).\n"
            f"stdout: {proc.stdout!r}\nstderr: {proc.stderr[-800:]!r}"
        )
        expected = {
            "values": EXPECTED_ASAN_VALUES,
            "errors": EXPECTED_ASAN_ERRORS,
            "others": EXPECTED_ASAN_OTHERS,
            "stopped": EXPECTED_STOPPED,
            "after_stop": 0,
        }
        for key, value in expected.items():
            assert _value(proc.stdout, key) == str(value), (
                f"expected {key}={value}, got {_value(proc.stdout, key)!r} "
                f"(stdout {proc.stdout!r})."
            )


def test_small_await_loop_returns_value():
    """A task<int> with five awaits of just(i) returns 0+1+2+3+4 = 10."""
    with tempfile.TemporaryDirectory(prefix="stdexec-verify-") as wd:
        binary = _compile(PROG_SMALL, "small", wd)
        proc = _run(binary, "small")
        assert proc.returncode == 0 and "small=10" in proc.stdout, (
            f"a 5-await task<int> must return 10; got exit {proc.returncode}, "
            f"stdout {proc.stdout!r}."
        )


def test_awaited_errors_and_stops_propagate():
    """Errors and stops from single awaits reach the caller.

    An error thrown inside ``then`` as soon as it starts and an error sent
    later from another thread both come out of sync_wait as the same
    exception, and a stop sent from another thread makes sync_wait return an
    empty result without running the code after the await.
    """
    with tempfile.TemporaryDirectory(prefix="stdexec-verify-") as wd:
        binary = _compile(PROG_ERROR, "error", wd)
        proc = _run(binary, "error")
        assert proc.returncode == 0, (
            f"the error/stop program did not exit cleanly (exit {proc.returncode}).\n"
            f"stdout: {proc.stdout!r}\nstderr: {proc.stderr[-800:]!r}"
        )
        expected = {"caught": "boom", "far_error": "far", "far_stop": "stopped", "after_stop": "0"}
        for key, value in expected.items():
            assert _value(proc.stdout, key) == value, (
                f"expected {key}={value}, got {_value(proc.stdout, key)!r} "
                f"(stdout {proc.stdout!r})."
            )


def test_existing_task_suite_still_passes():
    """The project's own Catch2 ``[task]`` cases still pass.

    They cover scheduler affinity after awaiting work on another thread,
    stopped propagation, allocator handling and awaiting just, just_error and
    just_stopped. ``test-setup.sh`` has already rebuilt ``test.stdexec``
    against the current headers; this runs only the ``[task]`` tag.
    """
    candidates = glob.glob(f"{BUILD}/**/test.stdexec", recursive=True)
    candidates = [c for c in candidates if os.access(c, os.X_OK)]
    assert candidates, (
        f"could not find an executable test.stdexec under {BUILD}; "
        f"test-setup.sh should have rebuilt it."
    )
    binary = candidates[0]
    try:
        proc = subprocess.run(
            [binary, "[task]"],
            capture_output=True,
            text=True,
            timeout=RUN_TIMEOUT,
            cwd=BUILD,
            check=False,
        )
    except subprocess.TimeoutExpired:
        pytest.fail(f"existing [task] suite exceeded {RUN_TIMEOUT}s")
    assert proc.returncode == 0, (
        f"the existing [types][task] Catch2 cases failed (exit {proc.returncode}).\n"
        f"stdout (tail): {proc.stdout[-2000:]}\nstderr (tail): {proc.stderr[-800:]}"
    )
