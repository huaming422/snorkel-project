//! Behavioral verifier for decoding an erasure-coded volume back to a
//! normal volume, on volume servers that keep data and index files on
//! separate disks and on single-disk servers.
//!
//! The verifier drives two public interfaces of the `seaweed_volume` crate:
//!
//!   * `VolumeGrpcService` (public struct, public `state` field) implementing
//!     the generated `VolumeServer` gRPC trait. The decode entry point is
//!     `volume_ec_shards_to_volume`; shards are produced with
//!     `volume_ec_shards_generate` and needles are deleted from the mounted
//!     EC volume with `volume_ec_blob_delete`.
//!   * The public `Store` API (`add_location` with data and index dirs,
//!     `add_volume`, `find_volume_mut`, `mount_ec_shard`, `unmount_ec_shards`,
//!     `mount_volume`, `read_volume_needle`, `write_volume_needle`) plus the
//!     `Volume`/`EcVolume` accessors used to build fixtures and read results.
//!
//! Each fixture builds a real store in a temp directory, writes a few
//! needles, encodes them, deletes the source data/index files (leaving only
//! shards + sealed index + deletion journals, as a decode target has), and
//! places the sealed index and journals where the server and the shard-copy
//! step leave them. The assertions observe only decode behavior: the call's
//! result, the published files, and what the re-mounted decoded volume reads
//! back and accepts.

use std::sync::{Arc, RwLock};

use tempfile::TempDir;
use tonic::Request;

use seaweed_volume::config::{MinFreeSpace, ReadMode};
use seaweed_volume::pb::volume_server_pb;
use seaweed_volume::pb::volume_server_pb::volume_server_server::VolumeServer;
use seaweed_volume::security::{Guard, SigningKey};
use seaweed_volume::server::grpc_server::VolumeGrpcService;
use seaweed_volume::server::volume_server::{RuntimeMetricsConfig, VolumeServerState};
use seaweed_volume::storage::needle::needle::Needle;
use seaweed_volume::storage::needle_map::NeedleMapKind;
use seaweed_volume::storage::store::Store;
use seaweed_volume::storage::types::{Cookie, DiskType, NeedleId, VolumeId, NEEDLE_ID_SIZE};
use seaweed_volume::storage::volume::VolumeSpec;

const VID: VolumeId = VolumeId(1);
const SHARD_COUNT: u8 = 14;

/// The body stored for needle `id`, used to build fixtures and to check that a
/// live needle read back from the decoded volume is byte-for-byte intact.
fn needle_body(id: u64) -> Vec<u8> {
    format!("split idx decode needle {id}").into_bytes()
}

/// Where the decode target keeps its files.
#[derive(Clone, Copy, PartialEq)]
enum Layout {
    /// Separate data and index dirs; the sealed index sits in the index dir,
    /// where the shard-copy step leaves it.
    SplitSealedIndexOnIdxDisk,
    /// Separate data and index dirs; the sealed index sits beside the shards
    /// in the data dir.
    SplitSealedIndexBesideData,
    /// One dir holds shards, sealed index and journal.
    SingleDisk,
}

/// Base path of volume 1's files in `dir`, as the server names them.
fn base(dir: &str, collection: &str) -> String {
    if collection.is_empty() {
        format!("{dir}/{}", VID.0)
    } else {
        format!("{dir}/{collection}_{}", VID.0)
    }
}

/// Wrap a `Store` in a minimal server state built entirely from the public
/// constructor surface. The guard is created with no whitelist and no signing
/// key, so write security is inactive and in-process admin calls are allowed
/// without peer info. This mirrors the public `http_integration` test setup.
fn state_from_store(store: Store) -> Arc<VolumeServerState> {
    let guard = Guard::new(&[], SigningKey(vec![]), 0, SigningKey(vec![]), 0);
    Arc::new(VolumeServerState {
        store: RwLock::new(store),
        guard: RwLock::new(guard),
        is_stopping: RwLock::new(false),
        maintenance: std::sync::atomic::AtomicBool::new(false),
        state_version: std::sync::atomic::AtomicU32::new(0),
        concurrent_upload_limit: 0,
        concurrent_download_limit: 0,
        inflight_upload_data_timeout: std::time::Duration::from_secs(60),
        inflight_download_data_timeout: std::time::Duration::from_secs(60),
        inflight_upload_bytes: std::sync::atomic::AtomicI64::new(0),
        inflight_download_bytes: std::sync::atomic::AtomicI64::new(0),
        upload_notify: tokio::sync::Notify::new(),
        download_notify: tokio::sync::Notify::new(),
        data_center: String::new(),
        rack: String::new(),
        file_size_limit_bytes: 0,
        maintenance_byte_per_second: 0,
        is_heartbeating: std::sync::atomic::AtomicBool::new(true),
        has_master: false,
        pre_stop_seconds: 0,
        volume_state_notify: tokio::sync::Notify::new(),
        write_queue: std::sync::OnceLock::new(),
        read_mode: ReadMode::Local,
        allow_untrusted_remote_endpoints: false,
        master_url: String::new(),
        master_urls: Vec::new(),
        seed_master_set: std::collections::HashSet::new(),
        current_master_url: tokio::sync::RwLock::new(String::new()),
        self_url: String::new(),
        http_client: reqwest::Client::new(),
        outgoing_http_scheme: "http".to_string(),
        outgoing_grpc_tls: None,
        metrics_runtime: std::sync::RwLock::new(RuntimeMetricsConfig::default()),
        metrics_notify: tokio::sync::Notify::new(),
        fix_jpg_orientation: false,
        has_slow_read: false,
        read_buffer_size_bytes: 1024 * 1024,
        security_file: String::new(),
        cli_white_list: vec![],
        state_file_path: String::new(),
    })
}

/// A built decode target. `tmp` keeps the directories alive.
struct Target {
    service: VolumeGrpcService,
    _tmp: TempDir,
    data: String,
    collection: &'static str,
}

/// Build a decode target.
///
/// Writes needles 1..=3 to a volume in `collection`, encodes them, then
/// removes the source data/index files so only the shards and sealed
/// index/journals remain, with the sealed index placed as `layout` says.
/// `copied_journal` ids are written as a deletion journal into the index dir,
/// where the shard-copy step appends the journals it collects from other
/// shard holders (on a single disk that is the one dir). `server_deletes` are
/// then deleted through the server's EC blob delete call on the mounted EC
/// volume, which journals them beside its sealed index.
async fn make_decode_target(
    layout: Layout,
    collection: &'static str,
    copied_journal: &[u64],
    server_deletes: &[u64],
) -> Target {
    let tmp = TempDir::new().unwrap();
    let data = tmp.path().join("data").to_str().unwrap().to_string();
    let idx = if layout == Layout::SingleDisk {
        data.clone()
    } else {
        tmp.path().join("idx").to_str().unwrap().to_string()
    };
    std::fs::create_dir_all(&data).unwrap();
    std::fs::create_dir_all(&idx).unwrap();

    let mut store = Store::new(NeedleMapKind::InMemory);
    store
        .add_location(
            &data,
            &idx,
            10,
            DiskType::HardDrive,
            MinFreeSpace::Percent(0.0),
            Vec::new(),
        )
        .unwrap();
    store
        .add_volume(
            VID,
            DiskType::HardDrive,
            &VolumeSpec {
                collection,
                ..VolumeSpec::default()
            },
        )
        .unwrap();

    {
        let (_, volume) = store.find_volume_mut(VID).unwrap();
        for id in 1..=3u64 {
            let body = needle_body(id);
            let mut needle = Needle {
                id: NeedleId(id),
                cookie: Cookie(id as u32),
                data_size: body.len() as u32,
                data: body,
                ..Needle::default()
            };
            volume.write_needle(&mut needle, true, false).unwrap();
        }
        volume.sync_to_disk().unwrap();
    }

    let service = VolumeGrpcService {
        state: state_from_store(store),
    };
    service
        .volume_ec_shards_generate(Request::new(
            volume_server_pb::VolumeEcShardsGenerateRequest {
                volume_id: VID.0,
                collection: collection.to_string(),
            },
        ))
        .await
        .unwrap();

    // Turn the encoded volume into a pure decode target: drop the source
    // data/index files so only shards + sealed index/journal remain, and put
    // the sealed index and the copied deletion journal where they sit on this
    // layout.
    {
        let mut store = service.state.store.write().unwrap();
        store.unmount_volume(VID).unwrap();
        std::fs::remove_file(format!("{}.dat", base(&data, collection))).unwrap();
        std::fs::remove_file(format!("{}.idx", base(&idx, collection))).unwrap();
        let sealed_index_dir = match layout {
            Layout::SplitSealedIndexOnIdxDisk => {
                std::fs::rename(
                    format!("{}.ecx", base(&data, collection)),
                    format!("{}.ecx", base(&idx, collection)),
                )
                .unwrap();
                idx.clone()
            }
            Layout::SplitSealedIndexBesideData | Layout::SingleDisk => data.clone(),
        };
        let mut journal_bytes = Vec::new();
        for id in copied_journal {
            let mut buf = [0u8; NEEDLE_ID_SIZE];
            NeedleId(*id).to_bytes(&mut buf);
            journal_bytes.extend_from_slice(&buf);
        }
        std::fs::write(format!("{}.ecj", base(&idx, collection)), journal_bytes).unwrap();

        for shard_id in 0..SHARD_COUNT {
            store.mount_ec_shard(VID, collection, shard_id, "").unwrap();
        }
        assert_eq!(
            store.find_ec_volume(VID).unwrap().ecx_actual_dir(),
            sealed_index_dir,
            "fixture precondition: the mounted volume reads its sealed index from {sealed_index_dir}"
        );
    }

    for &id in server_deletes {
        service
            .volume_ec_blob_delete(Request::new(volume_server_pb::VolumeEcBlobDeleteRequest {
                volume_id: VID.0,
                collection: collection.to_string(),
                file_key: id,
                version: 0,
            }))
            .await
            .unwrap_or_else(|e| panic!("fixture: deleting needle {id} from the EC volume: {e:?}"));
    }

    Target {
        service,
        _tmp: tmp,
        data,
        collection,
    }
}

/// Build a decode request for volume 1 in the target's collection.
fn decode_request(t: &Target) -> Request<volume_server_pb::VolumeEcShardsToVolumeRequest> {
    Request::new(volume_server_pb::VolumeEcShardsToVolumeRequest {
        volume_id: VID.0,
        collection: t.collection.to_string(),
        ..Default::default()
    })
}

/// Decode a target whose every needle is deleted and assert the call reports
/// no live entries and publishes no decoded data file.
async fn assert_reports_no_live_entries(t: &Target) {
    let err = t
        .service
        .volume_ec_shards_to_volume(decode_request(t))
        .await
        .expect_err("a fully-deleted volume must not decode as a populated volume");
    // The outcome is the server's no-live-entries signal. The check reads the
    // message, not a specific gRPC status code.
    assert!(
        err.message().contains("no live entries"),
        "a fully-deleted volume should report no live entries, got {err:?}"
    );
    let dat = format!("{}.dat", base(&t.data, t.collection));
    assert!(
        !std::path::Path::new(&dat).exists(),
        "no decoded data file may be left behind when the volume has no live entries"
    );
}

/// Mount the decoded normal volume and assert its observable contents: that it
/// is not forced read-only, that exactly the expected number of needles are
/// live, that every `live` needle reads back intact, that every `deleted`
/// needle reads as absent, and that the volume accepts a fresh write/read
/// afterwards.
///
/// The live-needle count is checked as `file_count - deleted_count` rather than
/// pinning the raw (file_count, deleted_count) pair: an interior deleted
/// needle may be kept as a tombstoned row (counted as garbage) or dropped
/// outright, and both leave the same set of needles live. A deleted tail
/// needle is checked by the read-absent and writable assertions.
fn assert_decoded_volume(t: &Target, live: &[u64], deleted: &[u64]) {
    let mut store = t.service.state.store.write().unwrap();
    let all_shards: Vec<u8> = (0..SHARD_COUNT).collect();
    store.unmount_ec_shards(VID, &all_shards);
    store
        .mount_volume(VID, t.collection, DiskType::HardDrive)
        .unwrap();

    let (_, v) = store.find_volume(VID).unwrap();
    assert_eq!(
        v.file_count() - v.deleted_count(),
        live.len() as i64,
        "decoded volume should report exactly {} live needle(s)",
        live.len()
    );
    assert!(
        !v.is_no_write_or_delete(),
        "decoded volume must stay writable: no index row may point past the end of the data file"
    );

    for &id in live {
        let mut n = Needle {
            id: NeedleId(id),
            ..Needle::default()
        };
        store
            .read_volume_needle(VID, &mut n)
            .unwrap_or_else(|e| panic!("live needle {id} should read back: {e:?}"));
        assert_eq!(n.data, needle_body(id), "live needle {id} body intact");
    }
    for &id in deleted {
        let mut n = Needle {
            id: NeedleId(id),
            ..Needle::default()
        };
        assert!(
            store.read_volume_needle(VID, &mut n).is_err(),
            "needle {id} was deleted after encoding and must stay deleted"
        );
    }

    let body = b"written after decode".to_vec();
    let mut n = Needle {
        id: NeedleId(4),
        cookie: Cookie(4),
        data_size: body.len() as u32,
        data: body.clone(),
        ..Needle::default()
    };
    store
        .write_volume_needle(VID, &mut n, true)
        .expect("decoded volume should accept a fresh write");
    let mut n = Needle {
        id: NeedleId(4),
        ..Needle::default()
    };
    store.read_volume_needle(VID, &mut n).unwrap();
    assert_eq!(n.data, body, "freshly written needle reads back");
}

/// Split layout, sealed index on the index disk, no deletions: the decode
/// succeeds and the re-mounted normal volume reads back every live needle and
/// stays writable.
///
/// The test does not assert which directory the rebuilt regular index lands
/// in. The mount resolves the index from either the data or the index
/// directory, so both locations are accepted.
#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn split_dir_decode_succeeds() {
    let t = make_decode_target(Layout::SplitSealedIndexOnIdxDisk, "", &[], &[]).await;

    t.service
        .volume_ec_shards_to_volume(decode_request(&t))
        .await
        .expect("decode on a split data/index layout should succeed");

    assert_decoded_volume(&t, &[1, 2, 3], &[]);
}

/// A split-layout volume whose every needle was deleted after encoding is
/// reported as having no live entries (so the caller purges the shards) and
/// leaves no decoded data file behind.
#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn all_deleted_reports_empty() {
    let t = make_decode_target(Layout::SplitSealedIndexOnIdxDisk, "", &[1, 2, 3], &[]).await;
    assert_reports_no_live_entries(&t).await;
}

/// The same no-live-entries outcome on a single-disk server, with the
/// deletions made through the server's EC delete call.
#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn all_deleted_single_disk_reports_empty() {
    let t = make_decode_target(Layout::SingleDisk, "", &[], &[1, 2, 3]).await;
    assert_reports_no_live_entries(&t).await;
}

/// Needles deleted after encoding do not reappear: both an interior deleted
/// needle and a tail-deleted needle read as absent from the decoded volume,
/// the live needle still reads back, and the mount stays writable.
///
/// The copied journal holds each delete twice, as it does when the copy step
/// ran again for a retried decode; each needle still counts as deleted once.
///
/// The test does not assert the decoded data file's exact byte length: a
/// decode may cut the deleted tail bytes from the data or keep them with the
/// row tombstoned inside the file, as long as the needle is unreadable and the
/// volume writable.
#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn tail_deleted_not_resurrected() {
    // Needle 1 is interior; needle 3 is the tail. Both are journaled deleted,
    // and the journal was appended twice.
    let t =
        make_decode_target(Layout::SplitSealedIndexOnIdxDisk, "", &[1, 3, 1, 3], &[]).await;

    t.service
        .volume_ec_shards_to_volume(decode_request(&t))
        .await
        .expect("decode with tail/interior deletions should succeed");

    // Needle 2 is the only live needle; needles 1 and 3 were deleted.
    assert_decoded_volume(&t, &[2], &[1, 3]);
}

/// On a single-disk server, needles deleted after encoding stay deleted in
/// the decoded volume, its live count matches, and the volume stays writable.
/// Needle 1 is in the journal twice (a copy appended again for a retried
/// decode); needle 3 was deleted through the server's EC delete call.
#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn single_disk_deleted_stay_deleted() {
    let t = make_decode_target(Layout::SingleDisk, "", &[1, 1], &[3]).await;

    t.service
        .volume_ec_shards_to_volume(decode_request(&t))
        .await
        .expect("decode on a single disk with deletions should succeed");

    assert_decoded_volume(&t, &[2], &[1, 3]);
}

/// The sealed index can sit beside the shards while the collected deletion
/// journal lands in the index dir. The tail needle 3 is recorded only in the
/// index-dir journal and reads as absent from the decoded volume. Needle 1 is
/// recorded in both journals and counts as deleted once. Needle 2 reads back.
#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn index_dir_journal_honored_with_sealed_index_beside_data() {
    let t = make_decode_target(Layout::SplitSealedIndexBesideData, "", &[1, 3], &[1]).await;

    t.service
        .volume_ec_shards_to_volume(decode_request(&t))
        .await
        .expect("decode should succeed with the sealed index beside the shards");

    assert_decoded_volume(&t, &[2], &[1, 3]);
}

/// With the sealed index beside the shards, deletions recorded on both disks
/// count: needle 1 is in the journal copied into the index dir, needle 3 was
/// deleted through the server (journaled beside the sealed index). Both read
/// as absent, needle 2 reads back. The volume is in a named collection.
#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn deletions_on_both_disks_are_honored() {
    let t = make_decode_target(Layout::SplitSealedIndexBesideData, "pics", &[1], &[3]).await;

    t.service
        .volume_ec_shards_to_volume(decode_request(&t))
        .await
        .expect("decode with deletions on both disks should succeed");

    assert_decoded_volume(&t, &[2], &[1, 3]);
}

/// Deletions split across both disks that together cover every needle
/// (needles 1 and 2 in the index-dir journal, needle 3 deleted through the
/// server beside the sealed index) leave no live entries.
#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn all_deleted_across_both_disks_reports_empty() {
    let t = make_decode_target(Layout::SplitSealedIndexBesideData, "pics", &[1, 2], &[3]).await;
    assert_reports_no_live_entries(&t).await;
}
