#!/usr/bin/env bash
# Test-setup for seaweedfs-fix-ec-decode-split-dir.
#
# The image bakes the full seaweed-volume dependency closure and its test
# binaries at the base commit (environment/Dockerfile step 10), so both the
# offline coding phase and the test runner can `cargo test` the crate without
# any network. There are no services to start and no data to seed: the verifier
# builds its fixtures (EC volumes on split data/idx stores and on a single-disk
# store) entirely in-process through the crate's public API.
set -euo pipefail

echo "[test-setup] Rust:   $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo:  $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Crate:  /repo/seaweedfs/seaweed-volume"
echo "[test-setup] Setup complete."
