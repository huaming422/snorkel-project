## Task

We run the Rust volume server (`seaweed-volume`) on boxes where data and index live on different disks (`-dir` and `-dir.idx`).
On those boxes `ec.decode` usually can't turn an erasure-coded volume back into a normal one.
`VolumeEcShardsToVolume` fails with `WriteIdxFileFromEcIndex: No such file or directory (os error 2)`.
By then it has already written the decoded `.dat`, so someone has to remove it by hand.
The same decode works on single-disk boxes.

Deletes made after encoding are mishandled too:

- When every needle was deleted after encoding, the decode should fail with the usual `has no live entries` error and write no `.dat`, so `ec.decode` can purge the shards.
  Right now it decodes the volume as if nothing had been deleted, and that happens on single-disk boxes as well.
- Needles deleted after encoding show up as live again in the decoded volume.
  Those deletes can be journaled on either disk, next to the volume's `.ecx` or in the index directory, where `ec.decode` appends the journals it copies from the other shard holders.
  Deletes from both places have to count.
  The same delete can also show up more than once, for example when a retried decode copies the journals again, and it still counts as one delete.

After a decode the volume should mount like any other one.
It stays writable, live needles read back with their original contents, deleted needles stay gone, and its live file count matches what is left.
