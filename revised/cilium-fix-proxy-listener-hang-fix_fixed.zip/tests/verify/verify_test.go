// SPDX-License-Identifier: Apache-2.0
// Copyright Authors of Cilium

// Drives the embedded xDS server headless through its listener entry points
// (AddListener, AddMetricsListener, RemoveListener) and the resource-mutator
// operations Upsert, UseCurrent and HandleResourceVersionAck, which stage and
// observe a pending policy wait. Every assertion is made on the wait itself:
// the per-update callback and the caller's completion wait group.
//
// Internal package (envoy) so the server can be built with the same
// constructor the package's embedded Envoy test uses, and so a wait can be
// staged on the per-type mutators the server wires at construction.
//
// Identifiers carry a vrf prefix so this file composes cleanly with the
// package's own internal test files.

package envoy

import (
	"context"
	"testing"
	"time"

	"github.com/cilium/hive/hivetest"
	"github.com/stretchr/testify/require"

	cilium "github.com/cilium/proxy/go/cilium/api"
	envoy_config_route "github.com/envoyproxy/go-control-plane/envoy/config/route/v3"

	"github.com/cilium/cilium/pkg/completion"
	"github.com/cilium/cilium/pkg/envoy/xds"
	"github.com/cilium/cilium/pkg/policy"
	testipcache "github.com/cilium/cilium/pkg/testutils/ipcache"
)

const (
	// vrfNode is a single node id shared between staging a wait and
	// acknowledging it. The listener path treats node ids opaquely; the value
	// only has to be internally consistent within a scenario. It mirrors the
	// canonical single-node id the server itself passes on resource deletes.
	vrfNode = "127.0.0.1"

	// vrfSettleDeadline bounds how long a wait is allowed to take once the
	// triggering action has run. Resolution happens inline during the action,
	// so a settling wait returns immediately; the bound only caps how long a
	// wait that never settles blocks before the assertion reports it.
	vrfSettleDeadline = 2 * time.Second

	// vrfPendingWindow is a short observation window used to confirm a wait has
	// NOT settled. Nothing resolves it during the window, so it is stable.
	vrfPendingWindow = 300 * time.Millisecond

	// vrfStillPendingWindow is how long a wait must stay unresolved while a
	// proxy listener is still configured. It is longer than vrfSettleDeadline
	// plus every precondition window used in this file, so a wait resolved by
	// a timer instead of by a listener removal shows up inside it.
	vrfStillPendingWindow = 3 * time.Second

	// vrfWaitCtxTimeout is intentionally long so a staged wait never resolves
	// on its own via context expiry within an observation window; any
	// resolution seen in a scenario comes from the listener removal.
	vrfWaitCtxTimeout = 60 * time.Second

	// vrfAckVersion is a version far above any version the fresh per-scenario
	// caches will assign, so an acknowledgement unambiguously covers the staged
	// update regardless of the exact cache version counter.
	vrfAckVersion = 1000

	// vrfMetricsPort is the port of the Envoy metrics listener, a listener that
	// is not a policy-enforcing proxy listener.
	vrfMetricsPort = 9964
)

// vrfSignal observes a single resource wait. The mutator invokes the callback
// synchronously, exactly once, when the wait resolves; the buffered channel
// keeps that invocation non-blocking.
type vrfSignal struct {
	ch chan error
}

func vrfNewSignal() (func(error), *vrfSignal) {
	sig := &vrfSignal{ch: make(chan error, 1)}
	return func(err error) { sig.ch <- err }, sig
}

// vrfWatchWaitGroup observes a caller blocked in wg.Wait(), the call the
// endpoint manager makes while it waits for proxy updates. It must be called
// only after every wait in wg has been staged.
func vrfWatchWaitGroup(wg *completion.WaitGroup) *vrfSignal {
	sig := &vrfSignal{ch: make(chan error, 1)}
	go func() { sig.ch <- wg.Wait() }()
	return sig
}

// settled reports whether the wait resolved within d, and with what error.
// A resolved wait returns (true, err); an unresolved one returns (false, nil)
// after d elapses.
func (sig *vrfSignal) settled(d time.Duration) (bool, error) {
	select {
	case err := <-sig.ch:
		return true, err
	case <-time.After(d):
		return false, nil
	}
}

// vrfNewServer builds the embedded xDS server headless (no proxy process, no
// sockets opened), wiring the per-type resource mutators via the server's own
// constructor. Mirrors the construction used by the package's embedded test.
func vrfNewServer(t *testing.T) *xdsServer {
	t.Helper()
	logger := hivetest.Logger(t)
	s := newXDSServer(logger, nil, testipcache.NewMockIPCache(), newLocalEndpointStore(),
		xdsServerConfig{
			envoySocketDir:    GetSocketDir(t.TempDir()),
			proxyGID:          1337,
			httpNormalizePath: true,
			metrics:           xds.NewXDSMetric(),
		},
		nil)
	require.NotNil(t, s)
	return s
}

// vrfAddProxyListener adds an HTTP proxy listener the way an L7 redirect does.
// No wait group is passed, so nothing waits for the listener itself.
func vrfAddProxyListener(t *testing.T, s *xdsServer, name string, port uint16) {
	t.Helper()
	require.NoError(t, s.AddListener(name, policy.ParserTypeHTTP, port, false, false, nil, nil))
}

// vrfNewPolicyResource returns a minimal, valid network-policy message. The
// cache only stores it; policy semantics are not exercised here.
func vrfNewPolicyResource() *cilium.NetworkPolicy {
	return &cilium.NetworkPolicy{EndpointIps: []string{"10.0.0.1"}, EndpointId: 1}
}

// vrfStagePolicyWait records a pending network-policy update on the server's
// network-policy mutator and returns a handle to observe its resolution.
func vrfStagePolicyWait(t *testing.T, s *xdsServer, wg *completion.WaitGroup, name string) *vrfSignal {
	t.Helper()
	cb, sig := vrfNewSignal()
	s.networkPolicyMutator.Upsert(NetworkPolicyTypeURL, name, vrfNewPolicyResource(), []string{vrfNode}, wg, cb)
	// Precondition: the update is still waiting before any listener is removed.
	if settled, _ := sig.settled(vrfPendingWindow); settled {
		t.Fatalf("precondition failed: staged policy update %q resolved before the listener was removed", name)
	}
	return sig
}

// Network-policy updates still waiting for the proxy when its last proxy
// listener is removed settle, all of them, and the caller blocked on their
// wait group returns without an error. A metrics listener stays configured the
// whole time: it is not a proxy listener, so the removed listener is still the
// last proxy listener.
func TestVrfLastListenerCancelsNPCompletion(t *testing.T) {
	s := vrfNewServer(t)

	ctx, cancel := context.WithTimeout(context.Background(), vrfWaitCtxTimeout)
	defer cancel()
	wg := completion.NewWaitGroup(ctx)

	s.AddMetricsListener(vrfMetricsPort, nil)
	const ln = "vrf-listener"
	vrfAddProxyListener(t, s, ln, 10001)

	sigA := vrfStagePolicyWait(t, s, wg, "vrf-np-a")
	sigB := vrfStagePolicyWait(t, s, wg, "vrf-np-b")

	s.RemoveListener(ln, nil)

	settledA, _ := sigA.settled(vrfSettleDeadline)
	require.True(t, settledA,
		"removing the last proxy listener must settle a pending network-policy update, but it stayed blocked")
	settledB, _ := sigB.settled(vrfSettleDeadline)
	require.True(t, settledB,
		"every network-policy update still pending at last-listener removal must settle, not just one")

	settled, err := vrfWatchWaitGroup(wg).settled(vrfSettleDeadline)
	require.True(t, settled,
		"the caller waiting on the settled network-policy updates must return")
	require.NoError(t, err,
		"the caller waiting on the settled network-policy updates must see no error")
}

// A settled update finishes cleanly: the per-update callback carries no error.
func TestVrfCancelCompletesWithNilError(t *testing.T) {
	s := vrfNewServer(t)

	ctx, cancel := context.WithTimeout(context.Background(), vrfWaitCtxTimeout)
	defer cancel()
	wg := completion.NewWaitGroup(ctx)

	const ln = "vrf-listener"
	vrfAddProxyListener(t, s, ln, 10011)

	sig := vrfStagePolicyWait(t, s, wg, "vrf-np")

	s.RemoveListener(ln, nil)

	settled, err := sig.settled(vrfSettleDeadline)
	require.True(t, settled,
		"removing the last proxy listener must settle the pending network-policy update")
	require.NoError(t, err,
		"the settled update must carry no error")
}

// An update that left the endpoint's policy as it was only waits for the
// policy already in the cache to be acknowledged. That wait settles on
// last-listener removal as well, and its caller returns without an error.
func TestVrfLastListenerSettlesUnchangedPolicyWait(t *testing.T) {
	s := vrfNewServer(t)

	ctx, cancel := context.WithTimeout(context.Background(), vrfWaitCtxTimeout)
	defer cancel()

	const ln = "vrf-listener"
	vrfAddProxyListener(t, s, ln, 10021)

	// The policy is already in the cache; nobody waits on this write.
	s.networkPolicyMutator.Upsert(NetworkPolicyTypeURL, "vrf-np", vrfNewPolicyResource(), []string{vrfNode}, nil, nil)

	wg := completion.NewWaitGroup(ctx)
	s.networkPolicyMutator.UseCurrent(NetworkPolicyTypeURL, []string{vrfNode}, wg)
	sig := vrfWatchWaitGroup(wg)
	if settled, _ := sig.settled(vrfPendingWindow); settled {
		t.Fatal("precondition failed: the wait for the current policy resolved before the listener was removed")
	}

	s.RemoveListener(ln, nil)

	settled, err := sig.settled(vrfSettleDeadline)
	require.True(t, settled,
		"removing the last proxy listener must settle a wait for the current network policy")
	require.NoError(t, err,
		"the caller waiting for the current network policy must see no error")
}

// While another proxy listener remains, an in-flight update keeps waiting for
// a real acknowledgement. Removing the final proxy listener then settles it.
func TestVrfNonLastListenerKeepsCompletionPending(t *testing.T) {
	s := vrfNewServer(t)

	ctx, cancel := context.WithTimeout(context.Background(), vrfWaitCtxTimeout)
	defer cancel()
	wg := completion.NewWaitGroup(ctx)

	const lnA = "vrf-listener-a"
	const lnB = "vrf-listener-b"
	vrfAddProxyListener(t, s, lnA, 10031)
	vrfAddProxyListener(t, s, lnB, 10032)

	sig := vrfStagePolicyWait(t, s, wg, "vrf-np")

	// Removing one of two proxy listeners leaves the update waiting.
	s.RemoveListener(lnA, nil)
	settledEarly, _ := sig.settled(vrfStillPendingWindow)
	require.False(t, settledEarly,
		"removing a non-last proxy listener must not settle an in-flight network-policy update")

	// Removing the final proxy listener settles it.
	s.RemoveListener(lnB, nil)
	settled, err := sig.settled(vrfSettleDeadline)
	require.True(t, settled,
		"removing the last proxy listener must settle the pending network-policy update")
	require.NoError(t, err,
		"the settled update must carry no error")
}

// Only network-policy waits are resolved on last-listener removal. Pending
// waits for other kinds of proxy update (a route update staged on the route
// mutator, and a metrics listener update) are left waiting.
func TestVrfCancelScopedToNetworkPolicy(t *testing.T) {
	s := vrfNewServer(t)

	ctx, cancel := context.WithTimeout(context.Background(), vrfWaitCtxTimeout)
	defer cancel()
	wg := completion.NewWaitGroup(ctx)

	const ln = "vrf-listener"
	vrfAddProxyListener(t, s, ln, 10041)

	npSig := vrfStagePolicyWait(t, s, wg, "vrf-np")

	// Stage an unrelated route update that stays pending through the removal.
	routeCb, routeSig := vrfNewSignal()
	s.routeMutator.Upsert(RouteTypeURL, "vrf-route", &envoy_config_route.RouteConfiguration{Name: "vrf-route"},
		[]string{vrfNode}, wg, routeCb)
	if settled, _ := routeSig.settled(vrfPendingWindow); settled {
		t.Fatal("precondition failed: staged route update resolved before the listener was removed")
	}

	// Stage a listener update (the metrics listener, which is not a proxy
	// listener) that stays pending through the removal. Its caller waits on
	// its own wait group.
	listenerWG := completion.NewWaitGroup(ctx)
	s.AddMetricsListener(vrfMetricsPort, listenerWG)
	listenerSig := vrfWatchWaitGroup(listenerWG)
	if settled, _ := listenerSig.settled(vrfPendingWindow); settled {
		t.Fatal("precondition failed: staged listener update resolved before the listener was removed")
	}

	s.RemoveListener(ln, nil)

	npSettled, npErr := npSig.settled(vrfSettleDeadline)
	require.True(t, npSettled, "the network-policy update must settle on last-listener removal")
	require.NoError(t, npErr, "the settled network-policy update must carry no error")

	routeSettled, _ := routeSig.settled(vrfPendingWindow)
	require.False(t, routeSettled,
		"an unrelated route update must be left waiting; only network-policy waits are resolved on listener removal")
	listenerSettled, _ := listenerSig.settled(vrfPendingWindow)
	require.False(t, listenerSettled,
		"an unrelated listener update must be left waiting; only network-policy waits are resolved on listener removal")
}

// The ordinary acknowledgement path resolves a pending network-policy update
// with no error. No listener is removed here.
func TestVrfNormalAckStillCompletes(t *testing.T) {
	s := vrfNewServer(t)

	ctx, cancel := context.WithTimeout(context.Background(), vrfWaitCtxTimeout)
	defer cancel()
	wg := completion.NewWaitGroup(ctx)

	const name = "vrf-np"
	sig := vrfStagePolicyWait(t, s, wg, name)

	// HandleResourceVersionAck is on the exported ack-observer interface, which
	// the network-policy mutator implements. Boxing through any() reaches it
	// whether the field is interface-typed or the concrete mutator type.
	acker := any(s.networkPolicyMutator).(xds.ResourceVersionAckObserver)
	acker.HandleResourceVersionAck(vrfAckVersion, vrfAckVersion, vrfNode,
		[]string{name}, NetworkPolicyTypeURL, "")

	settled, err := sig.settled(vrfSettleDeadline)
	require.True(t, settled, "an ordinary acknowledgement must settle a pending network-policy update")
	require.NoError(t, err, "a normal acknowledgement settles the update with no error")
}
