# Sourced by the verifier runner before tests execute; exports a deterministic
# Go environment. The toolchain, module cache, and build cache are baked into the
# image at the base commit (the task runs offline), so nothing is downloaded here.

set -euo pipefail

cd /repo/cilium

export GOFLAGS="-mod=mod"
export CGO_ENABLED="1"
export GOTOOLCHAIN="local"
export GOCACHE="${GOCACHE:-/home/dev/.cache/go-build}"
export GOMODCACHE="${GOMODCACHE:-/opt/cache/go}"
mkdir -p "$GOCACHE" "$GOMODCACHE"
