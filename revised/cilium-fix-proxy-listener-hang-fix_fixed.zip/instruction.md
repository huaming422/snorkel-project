## Task

Some of our nodes get stuck applying network policy.
An update to network policy, or to the identity information policy depends on, sometimes never returns.
Whatever made the call just waits forever, and later identity updates on that node queue up behind it.

Every stuck node we've looked at had just dropped its last L7 proxy listener, for example because the last policy with HTTP rules on that node was deleted, while an update was still waiting on Envoy.
We run Envoy with its Prometheus metrics listener on, and that listener was still there.
It isn't only policy changes that get stuck.
Identity updates that leave a pod's L7 policy as it was hang the same way, and so does every update that was waiting at that moment.

Can you find out why these updates hang and make them settle?
Once the last proxy listener is gone, the updates that were waiting should finish as a normal success, not come back as an error.
Anything Envoy can still confirm should keep waiting for that confirmation like it does today.
That includes policy updates while any proxy listener is still in use, even right after one of the pods sharing it stopped using it, and route or listener updates.
Once a proxy listener comes back, policy updates should wait for Envoy to confirm them again.
