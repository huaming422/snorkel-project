## Task

Since Codex started compacting long conversations, the first follow-up after a compaction can't move to another ChatGPT account.
When the account that served the previous request can't take the retry, the proxy won't send the turn anywhere else, so the user's follow-up fails instead of carrying on.

Here's what those turns look like.
Codex resends the whole conversation each time, and the previous request the proxy sent for it ended with the compacted summary, a completed `compaction` item holding its `encrypted_content`.
The model then ran a tool search on the client side, so the new request adds a completed `tool_search_call`, its `tool_search_output` (which can list the tools that search loaded), and the user's new message.
Some follow-ups skip the tool search and are just the summary plus the new message.
Both kinds get refused right now.

These follow-ups should be able to move to another account.
When one moves, the tool search and the tools it loaded have to go with it, since the model may call those tools on the new account.

Some of these turns do belong to the original account and should stay there:
- the summary still carries the `id` that account gave it
- the tool search ran on the server side, or the tools it loaded point at something only that account has, like a file-search vector store or a function in a private namespace
- the previous request didn't end with the summary, say a web search or another message came after it
- the model made other tool calls after the summary, alone or mixed in with a tool search, and no assistant reply follows them yet (once a reply follows, the turn can move)
