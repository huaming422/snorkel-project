"""Behavioral checks for moving a post-compaction follow-up turn to another account.

Every check goes through the public functions of
``app.modules.proxy.replay_safety`` that the HTTP bridge, WebSocket path,
compact path and streaming retry path call:

    * ``responses_payload_is_account_neutral_fresh_replay``
    * ``project_responses_input_for_account_neutral_fresh_replay``
    * ``responses_input_suffix_retains_prior_output``

``_moved_input`` runs them in the order the bridge uses for a full resend whose
first ``stored_count`` items are the input of the previous request: project
the input, require the projected suffix to hold the previous response's output
followed by new input, then require the projected payload to be account
neutral. A turn stays on its account when any of the three steps refuses it,
so the checks do not depend on which step makes the call.

Payload fixtures are built here from the Responses item shapes Codex sends,
so the file stands alone when collected from /tests/verify/.
"""

from __future__ import annotations

from typing import Any

import pytest

from app.modules.proxy.replay_safety import (
    project_responses_input_for_account_neutral_fresh_replay,
    responses_input_suffix_retains_prior_output,
    responses_payload_is_account_neutral_fresh_replay,
)

# --- fixture builders --------------------------------------------------------


def _user_message(text: str = "continue") -> dict[str, Any]:
    return {"type": "message", "role": "user", "content": [{"type": "input_text", "text": text}]}


def _assistant_message(text: str) -> dict[str, Any]:
    return {
        "type": "message",
        "role": "assistant",
        "status": "completed",
        "content": [{"type": "output_text", "text": text}],
    }


def _summary(encrypted_content: str = "encrypted-context", **extra: Any) -> dict[str, Any]:
    """The encrypted summary that stands in for the trimmed history."""
    item: dict[str, Any] = {"type": "compaction", "status": "completed", "encrypted_content": encrypted_content}
    item.update(extra)
    return item


def _function_tool(name: str) -> dict[str, Any]:
    return {
        "type": "function",
        "name": name,
        "description": f"{name} helper",
        "parameters": {"type": "object", "properties": {"query": {"type": "string"}}},
    }


def _search_call(call_id: str = "call_search", query: str = "codex-lb", **extra: Any) -> dict[str, Any]:
    item: dict[str, Any] = {
        "type": "tool_search_call",
        "call_id": call_id,
        "arguments": {"query": query},
        "execution": "client",
        "status": "completed",
    }
    item.update(extra)
    return item


def _search_output(call_id: str = "call_search", **extra: Any) -> dict[str, Any]:
    item: dict[str, Any] = {
        "type": "tool_search_output",
        "call_id": call_id,
        "execution": "client",
        "output": "result",
        "status": "completed",
        "tools": [],
    }
    item.update(extra)
    return item


def _function_call(call_id: str, name: str = "lookup") -> dict[str, Any]:
    return {"type": "function_call", "call_id": call_id, "name": name, "arguments": "{}", "status": "completed"}


def _function_output(call_id: str, output: str = "result") -> dict[str, Any]:
    return {"type": "function_call_output", "call_id": call_id, "output": output, "status": "completed"}


def _moved_input(input_items: list[Any], *, stored_count: int) -> list[Any] | None:
    """Input sent to the replacement account, or None when the turn stays."""
    projection = project_responses_input_for_account_neutral_fresh_replay(input_items, stored_count=stored_count)
    if projection is None:
        return None
    if not responses_input_suffix_retains_prior_output(
        projection.input_items,
        stored_count=projection.stored_prefix_count,
        canonical_lite_developer_index=projection.canonical_lite_developer_index,
    ):
        return None
    if not responses_payload_is_account_neutral_fresh_replay({"input": projection.input_items}):
        return None
    return projection.input_items


def _types(items: list[Any]) -> list[Any]:
    return [item.get("type") for item in items]


# --- summary plus a new message moves ---------------------------------------


@pytest.mark.parametrize(
    ("encrypted_content", "text"),
    [("encrypted-context", "continue"), ("gAAAA-second-summary", "now rename the helper")],
)
def test_summary_then_message_moves(encrypted_content: str, text: str) -> None:
    """A completed summary followed by a new user message is account neutral,
    and a full resend whose previous request was that summary moves with the
    summary and the message intact."""
    input_items = [_summary(encrypted_content), _user_message(text)]
    assert responses_payload_is_account_neutral_fresh_replay({"input": input_items}) is True

    moved = _moved_input(input_items, stored_count=1)
    assert moved is not None
    assert _types(moved) == ["compaction", "message"]
    assert moved[0]["encrypted_content"] == encrypted_content
    assert moved[1]["content"][0]["text"] == text


# --- summary, client tool search, new message moves with the search kept -----


_SEARCH_CASES = [
    pytest.param(
        _search_call("call_search_a", "read config", id="tsc_owner_a"),
        _search_output("call_search_a", id="tso_owner_a", tools=[_function_tool("read_config")]),
        id="search-with-result-and-tools",
    ),
    pytest.param(
        _search_call("call_search_b", "list repos"),
        {
            "type": "tool_search_output",
            "call_id": "call_search_b",
            "execution": "client",
            "status": "completed",
            "tools": [_function_tool("list_repos"), _function_tool("open_repo")],
        },
        id="tools-only-output",
    ),
]


@pytest.mark.parametrize(("search_call", "search_output"), _SEARCH_CASES)
def test_summary_then_client_tool_search_then_message_moves(
    search_call: dict[str, Any], search_output: dict[str, Any]
) -> None:
    """After a summary-only previous request, a completed client tool search
    and a new user message move to another account. The moved input keeps the
    search call and its output, in order, with the same call id, arguments and
    loaded tools, and carries no item ids."""
    input_items = [_summary(), search_call, search_output, _user_message("continue after compaction")]
    moved = _moved_input(input_items, stored_count=1)
    assert moved is not None
    assert _types(moved) == ["compaction", "tool_search_call", "tool_search_output", "message"]
    assert moved[1]["call_id"] == moved[2]["call_id"] == search_call["call_id"]
    assert moved[1]["arguments"] == search_call["arguments"]
    assert moved[2]["tools"] == search_output["tools"]
    assert all("id" not in item for item in moved)

    id_free_items = [{key: value for key, value in item.items() if key != "id"} for item in input_items]
    assert responses_payload_is_account_neutral_fresh_replay({"input": id_free_items}) is True


# --- a summary that carries its id stays --------------------------------------


@pytest.mark.parametrize(
    "followup",
    [
        pytest.param([_user_message()], id="message-only"),
        pytest.param([_search_call(), _search_output(), _user_message()], id="with-tool-search"),
    ],
)
@pytest.mark.parametrize("summary_id", ["cmp_owner_a", "cmp_7f3e2b"])
def test_summary_with_id_stays(summary_id: str, followup: list[dict[str, Any]]) -> None:
    """A summary that still carries the id the original account gave it keeps
    the turn on that account, both as a direct payload and as a full resend."""
    input_items = [_summary(id=summary_id), *followup]
    assert responses_payload_is_account_neutral_fresh_replay({"input": input_items}) is False
    assert _moved_input(input_items, stored_count=1) is None


# --- tool search tied to the account stays -----------------------------------


@pytest.mark.parametrize(
    ("search_call", "search_output"),
    [
        pytest.param(_search_call(), _search_output(execution="server"), id="server-output"),
        pytest.param(_search_call(execution="server"), _search_output(), id="server-call"),
        pytest.param(
            _search_call(),
            _search_output(tools=[{"type": "file_search", "vector_store_ids": ["vs_owner"]}]),
            id="file-search-vector-store",
        ),
        pytest.param(
            _search_call(),
            _search_output(tools=[{"type": "function", "name": "lookup", "namespace": "private"}]),
            id="private-namespace-function",
        ),
    ],
)
def test_account_tied_tool_search_stays(search_call: dict[str, Any], search_output: dict[str, Any]) -> None:
    """A tool search that ran on the server side, or whose loaded tools refer
    to state only the original account has, keeps the turn on that account."""
    input_items = [_summary(), search_call, search_output, _user_message()]
    assert responses_payload_is_account_neutral_fresh_replay({"input": input_items}) is False
    assert _moved_input(input_items, stored_count=1) is None


# --- previous request that did not end with the summary stays ----------------


@pytest.mark.parametrize(
    ("after_summary", "suffix"),
    [
        pytest.param(
            [{"type": "web_search_call", "id": "ws_owner_a", "action": {"type": "search", "query": "codex-lb"}, "status": "completed"}],
            [_search_call(), _search_output(), _user_message("continue after compaction")],
            id="web-search-after-summary",
        ),
        pytest.param(
            [{"type": "reasoning", "id": "rs_owner_a", "summary": [], "encrypted_content": "ciphertext"}],
            [_search_call(), _search_output(), _user_message("continue after compaction")],
            id="reasoning-after-summary",
        ),
        pytest.param(
            [_user_message("first question")],
            [_assistant_message("first answer"), _user_message("second question")],
            id="message-after-summary",
        ),
    ],
)
def test_previous_request_not_ending_with_summary_stays(
    after_summary: list[dict[str, Any]], suffix: list[dict[str, Any]]
) -> None:
    """When the previous request had more items after the summary, the next
    full resend stays on its account, whether or not those items are sent
    again."""
    input_items = [_summary(), *after_summary, *suffix]
    assert _moved_input(input_items, stored_count=1 + len(after_summary)) is None


# --- other tool calls after the summary need the model's reply --------------


@pytest.mark.parametrize(
    "calls",
    [
        pytest.param(
            [_function_call("call_function"), _search_call(), _function_output("call_function"), _search_output()],
            id="interleaved-function-and-search",
        ),
        pytest.param(
            [_search_call(), _search_output(), _function_call("call_after"), _function_output("call_after")],
            id="search-then-function",
        ),
        pytest.param([_function_call("call_only"), _function_output("call_only")], id="function-only"),
        pytest.param(
            [
                {"type": "custom_tool_call", "call_id": "call_custom", "name": "apply_edit", "input": "patch body", "status": "completed"},
                {"type": "custom_tool_call_output", "call_id": "call_custom", "output": "applied", "status": "completed"},
            ],
            id="custom-tool-only",
        ),
    ],
)
def test_other_tool_calls_after_summary_without_reply_stay(calls: list[dict[str, Any]]) -> None:
    """Tool calls other than the client tool search after a summary, alone or
    mixed with a search, do not count as the previous response's output until
    an assistant reply follows them."""
    input_items = [_summary(), *calls, _user_message()]
    assert _moved_input(input_items, stored_count=1) is None


@pytest.mark.parametrize(
    "calls",
    [
        pytest.param(
            [_function_call("call_reply", "read_file"), _function_output("call_reply", "file body")],
            id="function-only",
        ),
        pytest.param(
            [_function_call("call_mixed", "open_repo"), _search_call("call_search_m"), _function_output("call_mixed"), _search_output("call_search_m")],
            id="function-and-search",
        ),
    ],
)
def test_other_tool_calls_after_summary_with_reply_move(calls: list[dict[str, Any]]) -> None:
    """The same tool calls after a summary move once the assistant reply that
    followed them is part of the resend, with every item kept in order."""
    input_items = [_summary("encrypted-reply-case"), *calls, _assistant_message("here is the file"), _user_message("thanks, next step")]
    moved = _moved_input(input_items, stored_count=1)
    assert moved is not None
    assert _types(moved) == _types(input_items)


# --- existing contract -------------------------------------------------------


def test_existing_neutral_contract_preserved() -> None:
    """A self-contained function-call loop plus a user message stays neutral,
    while reasoning state and a server-side web search with its id stay
    refused."""
    function_loop_items = [
        _function_call("call_1"),
        _function_output("call_1", "ok"),
        _user_message(),
    ]
    assert responses_payload_is_account_neutral_fresh_replay({"input": function_loop_items}) is True

    assert responses_payload_is_account_neutral_fresh_replay({"input": [{"type": "reasoning", "encrypted_content": "ciphertext"}]}) is False
    assert (
        responses_payload_is_account_neutral_fresh_replay(
            {
                "input": [
                    {"type": "web_search_call", "id": "ws_owner", "action": {"type": "search", "query": "q"}, "status": "completed"},
                    _user_message(),
                ]
            }
        )
        is False
    )
