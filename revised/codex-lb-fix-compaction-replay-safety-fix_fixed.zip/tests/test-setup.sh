#!/usr/bin/env bash
# test-setup.sh - sourced before the verifier runs (verifier phase, network up).
#
# The verifier imports the repository package from the project venv at
# /opt/venv, which the image baked offline from the lockfile. The checks are
# pure-function assertions: no services, no datastore, no network.
#
# Dependencies are baked into the image, so this script is an offline no-op in
# the common case: it only confirms the package imports. The online block is a
# logged fallback for a cold venv only.
set -euo pipefail

cd /repo/codex-lb

# Offline-first: the project venv is baked. Confirm the package imports;
# only fall back to an online sync if the venv is missing/cold.
if ! /opt/venv/bin/python -c "import app.modules.proxy.replay_safety" >/dev/null 2>&1; then
    echo "project venv cold - syncing from lockfile (online fallback)" >&2
    uv sync --frozen --all-extras --group dev > /tmp/verifier-sync.log 2>&1 \
        || (tail -50 /tmp/verifier-sync.log >&2; exit 1)
fi

# Fail fast if the functions the checks call cannot be imported.
/opt/venv/bin/python -c "import app.modules.proxy.replay_safety as r; \
    assert r.responses_payload_is_account_neutral_fresh_replay and \
           r.project_responses_input_for_account_neutral_fresh_replay and \
           r.responses_input_suffix_retains_prior_output"
