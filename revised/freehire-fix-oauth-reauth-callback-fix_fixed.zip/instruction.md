## Task

Re-authentication through a social provider is broken for our members.
Someone who is already signed in clicks "Confirm with GitHub" before a sensitive change, and GitHub stops them on its own page with:

```
The redirect_uri is not associated with this application.
```

They never get back to us, so the confirm never finishes.
Plain sign-in with GitHub, from the same browser and the same GitHub app, works fine.
We think the confirm used to work with Google.
Nobody noticed for months because the confirm buttons were only wired up in the UI recently.

Please find out why the provider turns the confirm away and fix it on our side.
The GitHub app keeps the settings it has now.

Normal sign-in has to keep working the way it does today, including in these cases:

- If someone opens a confirm, gives up on it, and later signs in normally in the same browser, that sign-in has to go through.
- On deployments that still run with the new confirm flow switched off (`AUTH_V2_ENABLED` is false), nothing from that flow may get through, and sign-in has to behave exactly as before.
