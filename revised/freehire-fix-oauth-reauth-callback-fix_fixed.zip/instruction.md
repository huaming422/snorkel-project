## Task

Re-authentication through a social provider is broken for our members.
Someone who is already signed in clicks "Confirm with GitHub" before a sensitive change, and GitHub shows them an error page instead of sending them back to us.
The confirm never finishes.
Plain sign-in with GitHub works fine for the same people.

Can you dig into why GitHub turns the confirm away and get it working again?
Normal sign-in has to keep working exactly as it does today.
Some of our deployments still have the new confirm flow turned off, and sign-in there must not change at all.
