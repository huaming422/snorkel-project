## Task

Re-authentication through a social provider is broken for our members.
Someone who is already signed in clicks "Confirm with GitHub" before a sensitive change, and GitHub shows them an error page instead of sending them back to us.
Plain sign-in with GitHub works fine for the same people.

Need the confirm working again.
The confirm screen shows a button for each provider the member has linked (GitHub, Google, LinkedIn or Apple), and the confirm has to work whichever one they pick.
Normal sign-in has to keep working exactly as it does today.
