## Task

Re-authentication through a social provider is broken for our members.
Someone who is already signed in clicks "Confirm with GitHub" before a sensitive change, and GitHub stops them on its own error page, complaining that the redirect URI is not one it knows for our app.
They never get back to us, so the confirm never finishes.
Plain sign-in with GitHub works fine for the same people.

Please find out why the confirm gets turned away and fix it.
Normal sign-in has to keep working exactly as it does today, including for someone who gave up on a confirm partway and on deployments where the new confirm flow is turned off.
