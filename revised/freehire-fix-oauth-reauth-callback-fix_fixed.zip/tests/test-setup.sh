#!/usr/bin/env bash
# Verifier-time setup for freehire-fix-oauth-reauth-callback.
#
# Everything the verifier needs is baked into the image: the Go 1.26.x toolchain,
# the full module cache (GOMODCACHE=/opt/cache/go) and build cache, and the repo
# checked out at the pre-fix commit under /repo/freehire. The two verifier tests
# are pure Go unit/handler tests (no database, no network): the registry test
# builds AuthCodeURL from static x/oauth2 endpoints, and the dispatch test drives
# a fiber.App via app.Test. So there is nothing to install here.
#
# Offline agent phase: the agent phase runs with no network; the module/build
# caches above are warm, so `go test`/`go build` resolve offline. GOFLAGS=-mod=mod
# and GOTOOLCHAIN=local are set in the image ENV. We additionally force the Go
# proxy off at verify time so a stray cache miss fails fast instead of hanging on
# a dead network.
set -euo pipefail
export GOPROXY=off
export GOFLAGS=-mod=mod
echo "[test-setup] freehire-fix-oauth-reauth-callback: deps baked into image; GOPROXY=off"
