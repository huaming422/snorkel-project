package oauth

import (
	"strings"
	"testing"

	"github.com/strelov1/freehire/internal/platform/config"
)

// A provider console has room for exactly one callback URL per application, and
// the one registered for this app is <origin>/api/v1/auth/oauth/<name>/callback.
// This checks the consent URL that the first-time sign-in flow and the
// re-authentication ("confirm with ...") flow build for the same provider, with
// no network: AuthCodeURL is a pure local string build over the static provider
// endpoints. Both must send the browser to that registered callback, and the two
// must agree.
func TestVerifyReauthCallbackMatchesSignin(t *testing.T) {
	reg := NewRegistry(map[string]config.OAuthCredentials{
		"google": {ClientID: "id", ClientSecret: "secret"},
		"github": {ClientID: "id", ClientSecret: "secret"},
	})

	const origin = "https://freehire.me"
	for _, name := range []string{"google", "github"} {
		signIn, ok := reg.Provider(name, origin)
		if !ok {
			t.Fatalf("%s not enabled for first-time sign-in", name)
		}
		reauth, ok := reg.ProviderV2(name, origin)
		if !ok {
			t.Fatalf("%s not enabled for re-authentication", name)
		}

		// The URL-encoded registered callback (freehire.me/api/v1/auth/oauth/<name>/callback)
		// must appear in the re-authentication consent URL.
		want := "freehire.me%2Fapi%2Fv1%2Fauth%2Foauth%2F" + name + "%2Fcallback"
		got := reauth.AuthCodeURL("s")
		if !strings.Contains(got, want) {
			t.Errorf("%s re-authentication consent URL does not carry the registered callback:\n got %q\nwant substring %q", name, got, want)
		}

		// And both flows must land the browser on the identical callback, so one
		// cannot drift onto a path the provider will reject.
		if signIn.AuthCodeURL("s") != got {
			t.Errorf("%s: first-time sign-in and re-authentication disagree about the callback:\n sign-in %q\n re-auth %q",
				name, signIn.AuthCodeURL("s"), got)
		}
	}
}
