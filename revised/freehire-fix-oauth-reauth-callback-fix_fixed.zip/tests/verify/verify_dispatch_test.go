package handler

import (
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/gofiber/fiber/v2"
	fiberrecover "github.com/gofiber/fiber/v2/middleware/recover"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/strelov1/freehire/internal/identity/auth"
	"github.com/strelov1/freehire/internal/identity/auth/mobileauth"
	"github.com/strelov1/freehire/internal/identity/auth/oauth"
)

// Self-contained provider/registry stubs (prefixed so they never clash with the
// package's own test helpers or anything a solution happens to add). AuthCodeURL
// is a fixed string so nothing here touches the network; the registry answers
// both the first-time sign-in and the re-authentication resolver, so it stands
// in for a deployment with the second flow turned on.
type verifyStubProvider struct{ name string }

func (p *verifyStubProvider) Name() string { return p.name }
func (p *verifyStubProvider) AuthCodeURL(state string) string {
	return "https://provider.example/consent?state=" + state
}
func (p *verifyStubProvider) FetchIdentity(context.Context, string) (oauth.Identity, error) {
	return oauth.Identity{}, nil
}

type verifyStubRegistry map[string]oauth.Provider

func (r verifyStubRegistry) Names() []string {
	names := make([]string, 0, len(r))
	for name := range r {
		names = append(names, name)
	}
	return names
}
func (r verifyStubRegistry) Provider(name, _ string) (oauth.Provider, bool) {
	p, ok := r[name]
	return p, ok
}
func (r verifyStubRegistry) ProviderV2(name, _ string) (oauth.Provider, bool) {
	p, ok := r[name]
	return p, ok
}

// Each case runs once per provider, with a state value of its own, so the
// result does not depend on one provider name or one fixed state.
var verifyCallbackCases = []struct{ provider, state string }{
	{"github", "st-gh-7Qk2"},
	{"google", "st-go-Rm91"},
}

// verifyUnreachableDB is a Postgres address nothing listens on. A pgx pool
// opens no connection until a query runs, so the handler gets a real attempt
// store whose first lookup fails at once with a connection error.
const verifyUnreachableDB = "postgres://verify:verify@127.0.0.1:1/verify?sslmode=disable&connect_timeout=2"

// verifyDispatchApp wires the callback route onto a handler with the second
// (re-authentication) flow switched on. Its attempt store points at the
// unreachable database above, so a re-authentication hand-off gets as far as
// looking up its attempt and then fails the way that flow fails. A panic guard
// turns any panic into a server-error response.
func verifyDispatchApp(t *testing.T) *fiber.App {
	t.Helper()
	pool, err := pgxpool.New(context.Background(), verifyUnreachableDB)
	if err != nil {
		t.Fatalf("pgx pool: %v", err)
	}
	t.Cleanup(pool.Close)

	app := fiber.New(fiber.Config{ErrorHandler: RenderError})
	app.Use(fiberrecover.New())
	h := &authHandlers{
		issuer: auth.NewIssuer("test-secret", time.Hour),
		oauth: verifyStubRegistry{
			"github": &verifyStubProvider{name: "github"},
			"google": &verifyStubProvider{name: "google"},
		},
		oauthCodes:     oauth.NewCodeStore(time.Minute),
		frontendOrigin: "http://app.example",
		authV2Enabled:  true,
		mobileAuth:     mobileauth.NewStore(pool),
	}
	app.Get("/api/v1/auth/oauth/:provider/callback", h.OAuthCallback)
	return app
}

// verifyCallbackResult is what the browser gets back from the callback.
type verifyCallbackResult struct {
	status   int
	location string
	code     string // the "code" field of a JSON error body, if any
	cookies  []*http.Cookie
}

// verifyCallback drives the provider hand-off the way the browser would: a GET
// to the one registered callback carrying the state and a code, with whatever
// cookies the browser brought back.
func verifyCallback(t *testing.T, app *fiber.App, provider, state string, cookies map[string]string) verifyCallbackResult {
	t.Helper()
	req := httptest.NewRequestWithContext(context.Background(), http.MethodGet,
		"/api/v1/auth/oauth/"+provider+"/callback?state="+state+"&code=C", nil)
	for name, value := range cookies {
		req.AddCookie(&http.Cookie{Name: name, Value: value})
	}
	resp, err := app.Test(req, 10000)
	if err != nil {
		t.Fatalf("%s callback request: %v", provider, err)
	}
	defer func() { _ = resp.Body.Close() }()
	raw, _ := io.ReadAll(resp.Body)
	var body struct {
		Code string `json:"code"`
	}
	_ = json.Unmarshal(raw, &body)
	return verifyCallbackResult{
		status:   resp.StatusCode,
		location: resp.Header.Get("Location"),
		code:     body.Code,
		cookies:  resp.Cookies(),
	}
}

// verifyClears reports whether the response deletes the named cookie.
func verifyClears(cookies []*http.Cookie, name string) bool {
	for _, c := range cookies {
		if c.Name == name && c.Value == "" && (c.MaxAge < 0 || (!c.Expires.IsZero() && c.Expires.Before(time.Now()))) {
			return true
		}
	}
	return false
}

// The first-time sign-in path answers every failure by redirecting the browser
// back with a generic auth_error marker. Seeing exactly this means the request
// was handled as an ordinary sign-in.
const verifySignInFailure = "http://app.example/?auth_error=oauth"

// A hand-off that comes back with the re-authentication state cookie, whose
// value equals the state the provider returned, is run by the
// re-authentication flow: it does not end at the sign-in auth_error redirect,
// the flow deletes its own single-use state cookie, and, since the attempt
// lookup cannot reach the database, it answers with its own sign-in failure
// (401, code oauth_failed).
func TestVerifyDispatchesReauthToSecondFlow(t *testing.T) {
	app := verifyDispatchApp(t)
	for _, tc := range verifyCallbackCases {
		res := verifyCallback(t, app, tc.provider, tc.state,
			map[string]string{oauthV2StateCookieName: tc.state})

		if res.location == verifySignInFailure {
			t.Errorf("%s: re-authentication hand-off was handled as an ordinary sign-in (Location %q)", tc.provider, res.location)
			continue
		}
		if !verifyClears(res.cookies, oauthV2StateCookieName) {
			t.Errorf("%s: re-authentication state cookie %q was not cleared, so the re-authentication flow did not run (status %d)", tc.provider, oauthV2StateCookieName, res.status)
		}
		if res.status != fiber.StatusUnauthorized || res.code != "oauth_failed" {
			t.Errorf("%s: got status %d code %q, want the re-authentication flow's failure answer (401, code %q) when its attempt cannot be looked up", tc.provider, res.status, res.code, "oauth_failed")
		}
	}
}

// A hand-off carrying only the sign-in state cookie is handled by the sign-in
// path with the second flow enabled. The cookie value differs from the returned
// state, so the request stops at the sign-in state check and needs no account
// resolver.
func TestVerifySignInStillHandledBySignInFlow(t *testing.T) {
	app := verifyDispatchApp(t)
	for _, tc := range verifyCallbackCases {
		loc := verifyCallback(t, app, tc.provider, tc.state,
			map[string]string{oauth.StateCookieName: tc.state + "-other"}).location

		if loc != verifySignInFailure {
			t.Errorf("%s: Location = %q, want the sign-in path to have handled it (%q)", tc.provider, loc, verifySignInFailure)
		}
	}
}

// A re-authentication cookie left over from an abandoned attempt holds a value
// the current request did not return. With the second flow on, such a callback
// is handled by the sign-in path and ends at its state-mismatch redirect.
func TestVerifyStaleReauthCookieDoesNotDivertSignIn(t *testing.T) {
	app := verifyDispatchApp(t)
	for _, tc := range verifyCallbackCases {
		loc := verifyCallback(t, app, tc.provider, tc.state,
			map[string]string{oauthV2StateCookieName: tc.state + "-stale"}).location

		if loc != verifySignInFailure {
			t.Errorf("%s: Location = %q, want the sign-in state-mismatch redirect (%q) for a re-authentication cookie that does not match the returned state", tc.provider, loc, verifySignInFailure)
		}
	}
}
