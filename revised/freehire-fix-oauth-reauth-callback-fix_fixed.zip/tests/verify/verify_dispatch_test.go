package handler

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/gofiber/fiber/v2"
	fiberrecover "github.com/gofiber/fiber/v2/middleware/recover"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/strelov1/freehire/internal/identity/auth"
	"github.com/strelov1/freehire/internal/identity/auth/mobileauth"
	"github.com/strelov1/freehire/internal/identity/auth/oauth"
)

// Self-contained provider/registry stubs (prefixed so they never clash with the
// package's own test helpers or anything a solution happens to add). AuthCodeURL
// is a fixed string so nothing here touches the network; the registry answers
// both the first-time sign-in and the re-authentication resolver, so whether the
// second flow is on comes only from the handler's setting.
//
// FetchIdentity records every code it is handed and then refuses it, the way a
// provider answers a code it will not exchange. A recorded code means the
// sign-in got past its own state check and went on to the code exchange.
type verifyStubProvider struct {
	name      string
	mu        sync.Mutex
	exchanged []string
}

func (p *verifyStubProvider) Name() string { return p.name }
func (p *verifyStubProvider) AuthCodeURL(state string) string {
	return "https://provider.example/consent?state=" + state
}
func (p *verifyStubProvider) FetchIdentity(_ context.Context, code string) (oauth.Identity, error) {
	p.mu.Lock()
	p.exchanged = append(p.exchanged, code)
	p.mu.Unlock()
	return oauth.Identity{}, errors.New("provider refused the code")
}

// exchangedCode reports whether the provider was asked to exchange code.
func (p *verifyStubProvider) exchangedCode(code string) bool {
	p.mu.Lock()
	defer p.mu.Unlock()
	for _, c := range p.exchanged {
		if c == code {
			return true
		}
	}
	return false
}

type verifyStubRegistry map[string]oauth.Provider

func (r verifyStubRegistry) Names() []string {
	names := make([]string, 0, len(r))
	for name := range r {
		names = append(names, name)
	}
	return names
}
func (r verifyStubRegistry) Provider(name, _ string) (oauth.Provider, bool) {
	p, ok := r[name]
	return p, ok
}
func (r verifyStubRegistry) ProviderV2(name, _ string) (oauth.Provider, bool) {
	p, ok := r[name]
	return p, ok
}

// Each case runs once per provider a member can link, with a state value of its
// own, so the result does not depend on one provider name or one fixed state.
// Apple comes back to the callback as a form post (state and code in the
// request body, nothing in the query); the others come back as a GET.
var verifyCallbackCases = []struct{ provider, state, method string }{
	{"github", "st-gh-7Qk2", http.MethodGet},
	{"google", "st-go-Rm91", http.MethodGet},
	{"linkedin", "st-li-4Hc8", http.MethodGet},
	{"apple", "st-ap-Wz35", http.MethodPost},
}

// verifyUnreachableDB is a Postgres address nothing listens on. A pgx pool
// opens no connection until a query runs, so the handler gets a real attempt
// store whose first lookup fails at once with a connection error.
const verifyUnreachableDB = "postgres://verify:verify@127.0.0.1:1/verify?sslmode=disable&connect_timeout=2"

// verifyDispatchApp wires the callback route onto a handler whose second
// (re-authentication) flow is switched on or off as asked. Its attempt store
// points at the unreachable database above, so a re-authentication hand-off gets
// as far as looking up its attempt and then fails the way that flow fails. A
// panic guard turns any panic into a server-error response. The provider stubs
// are returned too, so a test can see which codes were sent for exchange.
func verifyDispatchApp(t *testing.T, secondFlowEnabled bool) (*fiber.App, map[string]*verifyStubProvider) {
	t.Helper()
	pool, err := pgxpool.New(context.Background(), verifyUnreachableDB)
	if err != nil {
		t.Fatalf("pgx pool: %v", err)
	}
	t.Cleanup(pool.Close)

	stubs := map[string]*verifyStubProvider{}
	registry := verifyStubRegistry{}
	for _, name := range []string{"github", "google", "linkedin", "apple"} {
		stubs[name] = &verifyStubProvider{name: name}
		registry[name] = stubs[name]
	}

	app := fiber.New(fiber.Config{ErrorHandler: RenderError})
	app.Use(fiberrecover.New())
	h := &authHandlers{
		issuer:         auth.NewIssuer("test-secret", time.Hour),
		oauth:          registry,
		oauthCodes:     oauth.NewCodeStore(time.Minute),
		frontendOrigin: "http://app.example",
		authV2Enabled:  secondFlowEnabled,
		mobileAuth:     mobileauth.NewStore(pool),
	}
	app.Get("/api/v1/auth/oauth/:provider/callback", h.OAuthCallback)
	app.Post("/api/v1/auth/oauth/:provider/callback", h.OAuthCallback)
	return app, stubs
}

// verifyCallbackResult is what the browser gets back from the callback.
type verifyCallbackResult struct {
	status   int
	location string
	code     string // the "code" field of a JSON error body, if any
	cookies  []*http.Cookie
}

// verifyCallback drives the provider hand-off the way the browser would: a
// request to the one registered callback carrying the state and a code, with
// whatever cookies the browser brought back. A GET carries them in the query;
// a POST carries them only in a form-encoded body.
func verifyCallback(t *testing.T, app *fiber.App, provider, state, method string, cookies map[string]string) verifyCallbackResult {
	t.Helper()
	return verifyCallbackWithCode(t, app, provider, state, "C", method, cookies)
}

func verifyCallbackWithCode(t *testing.T, app *fiber.App, provider, state, code, method string, cookies map[string]string) verifyCallbackResult {
	t.Helper()
	params := url.Values{"state": {state}, "code": {code}}
	path := "/api/v1/auth/oauth/" + provider + "/callback"
	var req *http.Request
	if method == http.MethodPost {
		req = httptest.NewRequestWithContext(context.Background(), http.MethodPost, path, strings.NewReader(params.Encode()))
		req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	} else {
		req = httptest.NewRequestWithContext(context.Background(), http.MethodGet, path+"?"+params.Encode(), nil)
	}
	for name, value := range cookies {
		req.AddCookie(&http.Cookie{Name: name, Value: value})
	}
	resp, err := app.Test(req, 10000)
	if err != nil {
		t.Fatalf("%s callback request: %v", provider, err)
	}
	defer func() { _ = resp.Body.Close() }()
	raw, _ := io.ReadAll(resp.Body)
	var body struct {
		Code string `json:"code"`
	}
	_ = json.Unmarshal(raw, &body)
	return verifyCallbackResult{
		status:   resp.StatusCode,
		location: resp.Header.Get("Location"),
		code:     body.Code,
		cookies:  resp.Cookies(),
	}
}

// verifyClears reports whether the response deletes the named cookie.
func verifyClears(cookies []*http.Cookie, name string) bool {
	for _, c := range cookies {
		if c.Name == name && c.Value == "" && (c.MaxAge < 0 || (!c.Expires.IsZero() && c.Expires.Before(time.Now()))) {
			return true
		}
	}
	return false
}

// verifyJar is the browser's cookie store between two hand-offs: a response's
// Set-Cookie headers update it, and a deleted cookie leaves it.
type verifyJar map[string]string

func (j verifyJar) apply(cookies []*http.Cookie) {
	for _, c := range cookies {
		if c.Value == "" || c.MaxAge < 0 || (!c.Expires.IsZero() && c.Expires.Before(time.Now())) {
			delete(j, c.Name)
			continue
		}
		j[c.Name] = c.Value
	}
}

// The first-time sign-in path answers every failure by redirecting the browser
// back with a generic auth_error marker. Seeing exactly this means the request
// was handled as an ordinary sign-in.
const verifySignInFailure = "http://app.example/?auth_error=oauth"

// A hand-off that comes back with the re-authentication state cookie, whose
// value equals the state the provider returned, is run by the
// re-authentication flow: it does not end at the sign-in auth_error redirect,
// the flow deletes its own single-use state cookie, and, since the attempt
// lookup cannot reach the database, it answers with its own sign-in failure
// (401, code oauth_failed).
func TestVerifyDispatchesReauthToSecondFlow(t *testing.T) {
	app, _ := verifyDispatchApp(t, true)
	for _, tc := range verifyCallbackCases {
		res := verifyCallback(t, app, tc.provider, tc.state, tc.method,
			map[string]string{oauthV2StateCookieName: tc.state})

		if res.location == verifySignInFailure {
			t.Errorf("%s: re-authentication hand-off was handled as an ordinary sign-in (Location %q)", tc.provider, res.location)
			continue
		}
		if !verifyClears(res.cookies, oauthV2StateCookieName) {
			t.Errorf("%s: re-authentication state cookie %q was not cleared, so the re-authentication flow did not run (status %d)", tc.provider, oauthV2StateCookieName, res.status)
		}
		if res.status != fiber.StatusUnauthorized || res.code != "oauth_failed" {
			t.Errorf("%s: got status %d code %q, want the re-authentication flow's failure answer (401, code %q) when its attempt cannot be looked up", tc.provider, res.status, res.code, "oauth_failed")
		}
	}
}

// A hand-off carrying only the sign-in state cookie is handled by the sign-in
// path with the second flow enabled. The cookie value differs from the returned
// state, so the request stops at the sign-in state check and needs no account
// resolver.
func TestVerifySignInStillHandledBySignInFlow(t *testing.T) {
	app, _ := verifyDispatchApp(t, true)
	for _, tc := range verifyCallbackCases {
		loc := verifyCallback(t, app, tc.provider, tc.state, tc.method,
			map[string]string{oauth.StateCookieName: tc.state + "-other"}).location

		if loc != verifySignInFailure {
			t.Errorf("%s: Location = %q, want the sign-in path to have handled it (%q)", tc.provider, loc, verifySignInFailure)
		}
	}
}

// With the second flow switched off, a callback that brings back a
// re-authentication state cookie, even one whose value equals the returned
// state, is handled by the sign-in path and ends at its state-mismatch redirect.
func TestVerifyNoDispatchWhenSecondFlowDisabled(t *testing.T) {
	app, _ := verifyDispatchApp(t, false)
	for _, tc := range verifyCallbackCases {
		loc := verifyCallback(t, app, tc.provider, tc.state, tc.method,
			map[string]string{oauthV2StateCookieName: tc.state}).location

		if loc != verifySignInFailure {
			t.Errorf("%s: Location = %q, want the sign-in state-mismatch redirect (%q) while the re-authentication flow is switched off", tc.provider, loc, verifySignInFailure)
		}
	}
}

// A re-authentication cookie left over from an abandoned attempt holds a value
// the current request did not return. With the second flow on, such a callback
// is handled by the sign-in path and ends at its state-mismatch redirect.
func TestVerifyStaleReauthCookieDoesNotDivertSignIn(t *testing.T) {
	app, _ := verifyDispatchApp(t, true)
	for _, tc := range verifyCallbackCases {
		loc := verifyCallback(t, app, tc.provider, tc.state, tc.method,
			map[string]string{oauthV2StateCookieName: tc.state + "-stale"}).location

		if loc != verifySignInFailure {
			t.Errorf("%s: Location = %q, want the sign-in state-mismatch redirect (%q) for a re-authentication cookie that does not match the returned state", tc.provider, loc, verifySignInFailure)
		}
	}
}

// A member can have a sign-in going in one tab while confirming in another.
// The browser then holds both flows' state cookies, plus the sign-in's return
// path. Whichever hand-off comes back first, the other one still completes
// afterwards with the cookies the browser holds by then. The confirm ends with
// the re-authentication flow's own answer. The sign-in passes its state check
// and sends its code to the provider for exchange, and when the provider
// refuses the code it returns the member to the page the sign-in started from.
// Both orders run for every provider.
func TestVerifyConfirmAndSignInSideBySide(t *testing.T) {
	for _, confirmFirst := range []bool{true, false} {
		app, stubs := verifyDispatchApp(t, true)
		for _, tc := range verifyCallbackCases {
			confirmState, signInState := tc.state, tc.state+"-signin"
			signInCode := "code-signin-" + tc.provider
			returnPath := "/jobs/" + tc.provider + "-7"
			order := "sign-in finished first"
			if confirmFirst {
				order = "confirm finished first"
			}
			jar := verifyJar{
				oauthV2StateCookieName: confirmState,
				oauth.StateCookieName:  signInState,
				oauth.ReturnCookieName: returnPath,
			}

			confirm := func() {
				res := verifyCallback(t, app, tc.provider, confirmState, tc.method, jar)
				jar.apply(res.cookies)
				if res.location == verifySignInFailure || res.status != fiber.StatusUnauthorized || res.code != "oauth_failed" {
					t.Errorf("%s, %s: confirm got status %d code %q Location %q, want the re-authentication flow's failure answer (401, code %q)",
						tc.provider, order, res.status, res.code, res.location, "oauth_failed")
				}
			}
			signIn := func() {
				res := verifyCallbackWithCode(t, app, tc.provider, signInState, signInCode, tc.method, jar)
				jar.apply(res.cookies)
				if !stubs[tc.provider].exchangedCode(signInCode) {
					t.Errorf("%s, %s: the sign-in never sent its code to the provider for exchange (Location %q), so it did not get past its state check",
						tc.provider, order, res.location)
				}
				if want := "http://app.example" + returnPath + "?auth_error=oauth"; res.location != want {
					t.Errorf("%s, %s: sign-in Location = %q, want %q (back to the page the sign-in started from)",
						tc.provider, order, res.location, want)
				}
			}

			if confirmFirst {
				confirm()
				signIn()
			} else {
				signIn()
				confirm()
			}
		}
	}
}
