## Task

We use the MCP `get_chart_sql` tool to see the SQL a chart would run, and we often send extra filters with it in `extra_form_data` (plain `filters` or `adhoc_filters`, same as for `get_chart_data`).
When one of those filters points at a column the dataset doesn't have, `get_chart_sql` still reports success and hands back SQL that looks fine.
That filter is simply not in the SQL, and nothing in the response says it was dropped.

If I send the same chart and filter to `get_chart_data`, it refuses with:

```
Unknown dataset column(s) in filters: region_code
```

So the two tools give opposite answers for one request.

What we expect:

- `get_chart_sql` fails the request when any filter we sent names a column the dataset doesn't have, and the error names every such column.
- That holds for saved charts and unsaved Explore state alike, and for charts that run more than one query.
- Only the filters in the request count, so a filter saved on the chart for a column the dataset no longer has, or a saved time filter the dataset can't apply, must not make either tool fail.
- When none of our filters were dropped, the SQL comes back exactly as it does now.
- The chart data API's query-only response (`result_type: "query"`) lists applied and rejected filters, time filters included, the same way the full data response does.

Everything else these tools and that response do today should keep working.
