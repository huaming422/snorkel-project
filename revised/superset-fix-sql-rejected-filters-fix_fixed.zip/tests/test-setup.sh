#!/usr/bin/env bash
# test-setup.sh is sourced by tests/test.sh before verify/verify.py, under
# test.sh's `set -euo pipefail`. Brings the baked dependency closure online for
# the test phase. Must run with the network cut (the smoke gate's offline
# fold sources this inside `docker run --network none`).
#
# The image baked the full closure of requirements/development.txt, including
# the editable installs (apache-superset, apache-superset-core,
# apache-superset-extensions-cli) and the test stack (pytest, pytest-asyncio,
# fastmcp, sqlglot), into /repo/superset/.venv with a warm uv cache at
# /opt/uv-cache. There is nothing left to install at test time, so this script
# only pins uv to offline mode and verifies the environment resolves.

cd /repo/superset

# Scoped to this task's uv (never image-wide: harbor's `uv tool install` at
# trial prep needs the live network that is actually there). Offline mode is
# applied per-attempt via `--offline` on the first branch below, not exported:
# an exported UV_OFFLINE=1 would also force the online-fallback elif offline,
# defeating its purpose when the cache is stale.
export UV_CACHE_DIR=/opt/uv-cache

# Offline-first reconciliation against the image bake. `-e .` is already
# installed, so this resolves entirely from the warm cache; it is a no-op that
# proves the closure is present offline. Logged online fallback only if the
# bake was somehow stale.
#
# --no-build-isolation: editable packages (apache-superset, apache-superset-core,
# apache-superset-extensions-cli) require a build backend (setuptools) when uv
# rebuilds them in an isolated env. In the Modal vm_runtime test phase the
# network is blocked, and uv's isolated build-env resolution does not inherit the
# --offline flag, causing it to attempt PyPI access and fail. --no-build-isolation
# tells uv to use the existing venv's setuptools (already installed at test time)
# instead of constructing a fresh isolated build environment, which is both safe
# and correct since the dependency closure is fully baked into the image.
if uv pip install --python /repo/superset/.venv/bin/python --offline --no-build-isolation \
        -r requirements/development.txt > /tmp/test-setup-install.log 2>&1; then
    echo "[offline-first] deps satisfied from image bake"
elif uv pip install --python /repo/superset/.venv/bin/python --no-build-isolation \
        -r requirements/development.txt >> /tmp/test-setup-install.log 2>&1; then
    echo "[test-setup] deps installed online (image bake was stale)"
else
    tail -60 /tmp/test-setup-install.log >&2; exit 1
fi

# Smoke-test the import chain the checks exercise. Superset modules are
# app-context-bound; constructing a minimal app is the canonical way to make the
# query/MCP imports resolve at import time.
/repo/superset/.venv/bin/python - <<'PY'
from superset.app import SupersetApp
from superset.extensions import appbuilder
from superset.initialization import SupersetAppInitializer

app = SupersetApp(__name__)
app.config.from_object("superset.config")
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///"
app.config["WTF_CSRF_ENABLED"] = False
app.config["TESTING"] = True
app.config["RATELIMIT_ENABLED"] = False
app.config["CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
app.config["DATA_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
app.config["TALISMAN_ENABLED"] = False
appbuilder.baseviews = []
SupersetAppInitializer(app).init_app()
with app.app_context():
    from superset.common import query_actions  # noqa: F401
    print("[test-setup] import chain OK")
PY

echo "[test-setup] done"
