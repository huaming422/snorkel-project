"""Behavioral checks for filter handling in the chart SQL and chart data tools.

Two MCP chart tools share one chart-data query path: ``get_chart_data`` returns
executed data and ``get_chart_sql`` returns only the rendered SQL. A request can
carry extra filters (``filters`` or ``adhoc_filters`` in ``extra_form_data``).
A filter naming a column the dataset does not have is dropped while the query
is built and reported in the result's ``rejected_filters`` list.

The checks cover two sides of that contract:

* The chart-data result for a query-only request (result type ``query``),
  driven through ``superset.common.query_actions.get_query_results`` with small
  stand-in datasources. One stand-in offers the detailed query-string form
  (``get_query_str_extended`` returning a real ``QueryStringExtended``), the
  other offers only the plain string form, the way semantic views do. The
  checks read the public payload: the exact ``query`` text, ``applied_filters``
  and the reason-tagged ``rejected_filters`` list that full data results also
  carry, time filters (``__time_col``, ``__time_grain``, ``__time_range``)
  included.

* The ``get_chart_sql`` and ``get_chart_data`` tools, driven end to end through
  the fastmcp ``Client`` for unsaved Explore state and, for the SQL tool, for a
  saved chart with a stored query context. The chart-data command is replaced
  by one that returns what the repository's own ``get_query_results`` builds
  for stand-in datasets (a query-only result for the SQL tool, a full result
  for the data tool), so the tools read whatever payload the result code
  produces for a known set of dropped filters.

This file bootstraps its own minimal Superset application, mirroring the
repository's ``tests/unit_tests/conftest.py`` app fixture, so it does not rely
on the repository's test configuration being discovered.
"""

from __future__ import annotations

import asyncio
import contextlib
import importlib
import json
import os
from types import SimpleNamespace
from unittest.mock import Mock, patch

import pytest

REPO = "/repo/superset"

# --------------------------------------------------------------------------- #
# Minimal application bootstrap (mirrors tests/unit_tests/conftest.py::app).
# --------------------------------------------------------------------------- #

_APP = None


def _get_app():
    """Build and cache a minimal Superset application for the checks."""
    global _APP
    if _APP is not None:
        return _APP

    from superset.app import SupersetApp
    from superset.extensions import appbuilder
    from superset.initialization import SupersetAppInitializer

    app = SupersetApp(__name__)
    app.config.from_object("superset.config")
    app.config["SQLALCHEMY_DATABASE_URI"] = (
        os.environ.get("SUPERSET__SQLALCHEMY_DATABASE_URI") or "sqlite://"
    )
    app.config["WTF_CSRF_ENABLED"] = False
    app.config["PREVENT_UNSAFE_DB_CONNECTIONS"] = False
    app.config["TESTING"] = True
    app.config["RATELIMIT_ENABLED"] = False
    app.config["CACHE_CONFIG"] = {}
    app.config["DATA_CACHE_CONFIG"] = {}
    app.config["SERVER_NAME"] = "example.com"
    app.config["APPLICATION_ROOT"] = "/"
    app.config["PREFERRED_URL_SCHEME"] = "http"
    # The permission checks for the chart tools are exercised in their own
    # dedicated tests; disable them here so a mock user can drive tool logic.
    app.config["MCP_RBAC_ENABLED"] = False

    # appbuilder is a singleton; clear views so init can run more than once.
    appbuilder.baseviews = []
    SupersetAppInitializer(app).init_app()

    _APP = app
    return _APP


# --------------------------------------------------------------------------- #
# Lazy module handles (imported inside the application context).
# --------------------------------------------------------------------------- #


def _chart_sql_mod():
    return importlib.import_module("superset.mcp_service.chart.tool.get_chart_sql")


def _chart_data_mod():
    return importlib.import_module("superset.mcp_service.chart.tool.get_chart_data")


def _query_actions_mod():
    return importlib.import_module("superset.common.query_actions")


def _get_data_command_mod():
    return importlib.import_module("superset.commands.chart.data.get_data_command")


def _mcp_server():
    from superset.mcp_service.app import mcp

    return mcp


def _mock_user():
    user = Mock()
    user.id = 1
    user.username = "admin"
    return user


def _fake_command(result):
    """A stand-in for the chart-data command returning a fixed payload."""

    class _Command:
        def __init__(self, query_context):
            self.query_context = query_context

        def validate(self):
            return None

        def run(self):
            return result

    return _Command


def _fake_query_context(*_args, **_kwargs):
    return SimpleNamespace(datasource=SimpleNamespace(id=1, type="table"))


def _is_error(data):
    """True when the tool returned an error response rather than SQL/data."""
    return bool(data.get("error_type"))


def _message(data):
    return (data.get("error") or "") + " " + (data.get("message") or "")


def _plain(value):
    """Enum members compare as their string value."""
    return getattr(value, "value", value)


def _reason(entry):
    return _plain(entry.get("reason"))


# --------------------------------------------------------------------------- #
# Stand-in datasets and the chart-data results built from them.
# --------------------------------------------------------------------------- #

_SQL_TEXT = "SELECT country, count(*) FROM sales GROUP BY country"
_SECOND_SQL_TEXT = "SELECT region, count(*) FROM sales GROUP BY region"
_PREQUERY = "SET search_path TO reporting"

# Time filters saved on a chart whose dataset has no temporal column: the time
# column it names is missing, and grain and range have nothing to apply to.
_SAVED_TIME_EXTRAS = {
    "__time_col": "order_date",
    "__time_grain": "P1D",
    "__time_range": "Last week",
}

_FORM_DATA = {
    "datasource": "1__table",
    "datasource_id": 1,
    "datasource_type": "table",
    "viz_type": "table",
    "metrics": ["count"],
    "groupby": ["country"],
}

_COLUMNS = [
    SimpleNamespace(column_name="country", verbose_name=None, is_dttm=False),
    SimpleNamespace(column_name="region", verbose_name=None, is_dttm=False),
]


class _DetailedSource:
    """Datasource stand-in that offers the detailed query-string form."""

    query_language = "sql"

    def __init__(self, sql, applied, rejected, prequeries=(), time_column=None):
        self.columns = list(_COLUMNS)
        if time_column:
            self.columns.append(
                SimpleNamespace(column_name=time_column, verbose_name=None, is_dttm=True)
            )
        self._sql = sql
        self._applied = list(applied)
        self._rejected = list(rejected)
        self._prequeries = list(prequeries)

    def get_query_str_extended(self, query_obj, mutate=True):
        from superset.models.helpers import QueryStringExtended

        return QueryStringExtended(
            applied_template_filters=[],
            applied_filter_columns=list(self._applied),
            rejected_filter_columns=list(self._rejected),
            labels_expected=[],
            prequeries=list(self._prequeries),
            sql=self._sql,
            sql_shifted_temporal_labels=set(),
        )

    def get_query_str(self, query_obj):
        ext = self.get_query_str_extended(query_obj)
        return ";\n\n".join([*ext.prequeries, ext.sql]) + ";"


class _PlainSource:
    """Datasource stand-in that only offers the plain query string."""

    query_language = "sql"

    def __init__(self, text):
        self.columns = list(_COLUMNS)
        self._text = text

    def get_query_str(self, query_obj):
        return self._text


class _QueryObject:
    def __init__(self, datasource, applied_time_extras=None):
        self.datasource = datasource
        self.applied_time_extras = dict(applied_time_extras or {})
        self.result_type = None

    def to_dict(self):
        return {"filter": [], "extras": {}}


def _query(sql=_SQL_TEXT, *, applied=(), dropped=(), prequeries=(), time_extras=None):
    """One chart query over a stand-in dataset without a time column.

    ``dropped`` names columns the dataset does not have; ``time_extras`` are
    time filters saved on the chart.
    """
    return _DetailedSource(sql, applied, dropped, prequeries), time_extras


def _query_only_result(datasource, time_extras=None):
    """The chart-data result for a query-only request on one query."""
    from superset.common.chart_data import ChartDataResultType

    query_context = SimpleNamespace(
        datasource=datasource, result_type=ChartDataResultType.QUERY
    )
    return _query_actions_mod().get_query_results(
        ChartDataResultType.QUERY,
        query_context,
        _QueryObject(datasource, time_extras),
        False,
    )


def _full_result(datasource, time_extras=None):
    """The chart-data result for a full data request on one query.

    The query itself is reported as failed, so the result carries filter
    status but no rows.
    """
    from superset.common.chart_data import ChartDataResultType
    from superset.common.chart_data_timing import QueryAcquisitionTiming
    from superset.common.db_query_status import QueryStatus

    payload = {
        "df": None,
        "status": QueryStatus.FAILED,
        "applied_filter_columns": list(datasource._applied),
        "rejected_filter_columns": list(datasource._rejected),
    }

    class _Context:
        result_type = ChartDataResultType.FULL

        def __init__(self):
            self.datasource = datasource

        def get_df_payload_result(self, query_obj, force_cached=False):
            return SimpleNamespace(
                payload=dict(payload),
                timing=QueryAcquisitionTiming(
                    query_planning_ns=0,
                    cache_resolution_ns=0,
                    data_acquisition_ns=None,
                    payload_assembly_ns=0,
                ),
            )

    return _query_actions_mod().get_query_results(
        ChartDataResultType.FULL,
        _Context(),
        _QueryObject(datasource, time_extras),
        False,
    )


def _command_result(queries, build):
    return {"queries": [build(source, extras) for source, extras in queries]}


def _adhoc(column, value="value"):
    return {
        "clause": "WHERE",
        "expressionType": "SIMPLE",
        "subject": column,
        "operator": "==",
        "comparator": value,
    }


def _simple(column, value="value"):
    return {"col": column, "op": "==", "val": value}


# --------------------------------------------------------------------------- #
# End-to-end tool drivers.
# --------------------------------------------------------------------------- #


def _call_tool(name, request):
    from fastmcp import Client

    async def _run():
        async with Client(_mcp_server()) as client:
            res = await client.call_tool(name, {"request": request})
            return res.structured_content.get("result", res.structured_content)

    return asyncio.run(_run())


def _run_chart_sql(extra_form_data, queries):
    """Drive get_chart_sql for unsaved Explore state (form_data_key only)."""
    app = _get_app()
    mod = _chart_sql_mod()
    with app.app_context():
        command_result = _command_result(queries, _query_only_result)
        # The embedded-guest feature is disabled in this configuration, so the
        # guest denial branch short-circuits to "not a guest" without consulting
        # request state; a mock user is enough to reach the SQL logic.
        with contextlib.ExitStack() as es:
            es.enter_context(
                patch(
                    "superset.mcp_service.auth.get_user_from_request",
                    return_value=_mock_user(),
                )
            )
            es.enter_context(
                patch.object(
                    _get_data_command_mod(),
                    "ChartDataCommand",
                    _fake_command(command_result),
                )
            )
            es.enter_context(
                patch.object(
                    mod,
                    "_get_cached_form_data",
                    lambda _key: json.dumps(_FORM_DATA),
                )
            )
            es.enter_context(
                patch.object(
                    mod, "_build_query_context_from_form_data", _fake_query_context
                )
            )
            es.enter_context(
                patch.object(mod, "set_query_context_form_data", lambda *a, **k: None)
            )
            es.enter_context(
                patch.object(mod, "_resolve_datasource_name", lambda *a, **k: "sales")
            )
            es.enter_context(
                patch.object(
                    mod,
                    "event_logger",
                    SimpleNamespace(log_context=lambda **k: contextlib.nullcontext()),
                )
            )

            request = {"form_data_key": "cached-key"}
            if extra_form_data is not None:
                request["extra_form_data"] = extra_form_data
            return _call_tool("get_chart_sql", request)


def _saved_chart():
    query_context = {
        "datasource": {"id": 1, "type": "table"},
        "queries": [{"columns": ["country"], "metrics": ["count"], "filters": []}],
        "form_data": _FORM_DATA,
        "result_type": "full",
    }
    return SimpleNamespace(
        id=7,
        uuid="0f6c1a52-6d0e-4c1b-9c2e-6b1d6a1f3e77",
        slice_name="Sales by country",
        viz_type="table",
        datasource_id=1,
        datasource_type="table",
        datasource_name="sales",
        params=json.dumps(_FORM_DATA),
        query_context=json.dumps(query_context),
    )


def _run_saved_chart_sql(extra_form_data, queries):
    """Drive get_chart_sql for a saved chart that has a stored query context."""
    app = _get_app()
    mod = _chart_sql_mod()
    with app.app_context():
        from superset.charts.schemas import ChartDataQueryContextSchema

        command_result = _command_result(queries, _query_only_result)
        chart = _saved_chart()

        def _form_data_path_not_expected(*_args, **_kwargs):
            raise AssertionError(
                "the saved chart's stored query context was not used"
            )

        with contextlib.ExitStack() as es:
            es.enter_context(
                patch(
                    "superset.mcp_service.auth.get_user_from_request",
                    return_value=_mock_user(),
                )
            )
            es.enter_context(
                patch.object(
                    _get_data_command_mod(),
                    "ChartDataCommand",
                    _fake_command(command_result),
                )
            )
            es.enter_context(
                patch.object(mod, "_find_chart_by_identifier", lambda _ident: chart)
            )
            es.enter_context(
                patch.object(
                    mod,
                    "validate_chart_dataset",
                    lambda *a, **k: SimpleNamespace(
                        is_valid=True, warnings=[], error=None
                    ),
                )
            )
            es.enter_context(
                patch.object(
                    mod, "merge_extra_form_data_filters_into_query", lambda *a, **k: None
                )
            )
            es.enter_context(
                patch.object(
                    ChartDataQueryContextSchema,
                    "load",
                    lambda self, *a, **k: _fake_query_context(),
                )
            )
            es.enter_context(
                patch.object(mod, "set_query_context_form_data", lambda *a, **k: None)
            )
            es.enter_context(
                patch.object(
                    mod,
                    "_build_query_context_from_form_data",
                    _form_data_path_not_expected,
                )
            )
            es.enter_context(patch.object(mod, "_get_cached_form_data", lambda _k: None))
            es.enter_context(
                patch.object(
                    mod,
                    "event_logger",
                    SimpleNamespace(log_context=lambda **k: contextlib.nullcontext()),
                )
            )

            request = {"identifier": chart.id}
            if extra_form_data is not None:
                request["extra_form_data"] = extra_form_data
            return _call_tool("get_chart_sql", request)


def _run_chart_data(extra_form_data, queries):
    """Drive get_chart_data for unsaved Explore state (form_data_key only)."""
    app = _get_app()
    mod = _chart_data_mod()
    with app.app_context():
        command_result = _command_result(queries, _full_result)
        # Guest reads are gated on the embedded-guest feature, which is disabled
        # here, so the unsaved-chart cache path is reachable with a mock user.
        with contextlib.ExitStack() as es:
            es.enter_context(
                patch(
                    "superset.mcp_service.auth.get_user_from_request",
                    return_value=_mock_user(),
                )
            )
            es.enter_context(
                patch.object(
                    _get_data_command_mod(),
                    "ChartDataCommand",
                    _fake_command(command_result),
                )
            )
            es.enter_context(
                patch.object(
                    mod, "get_cached_form_data", lambda _key: json.dumps(_FORM_DATA)
                )
            )
            es.enter_context(
                patch.object(
                    mod, "build_query_context_from_form_data", _fake_query_context
                )
            )
            es.enter_context(
                patch.object(
                    mod,
                    "event_logger",
                    SimpleNamespace(log_context=lambda **k: contextlib.nullcontext()),
                )
            )

            request = {"form_data_key": "cached-key"}
            if extra_form_data is not None:
                request["extra_form_data"] = extra_form_data
            return _call_tool("get_chart_data", request)


_SQL_DRIVERS = {"unsaved": _run_chart_sql, "saved": _run_saved_chart_sql}


# --------------------------------------------------------------------------- #
# SQL tool: requested filters on columns the dataset does not have.
# --------------------------------------------------------------------------- #


def test_sql_rejects_unknown_adhoc_filter_column():
    """An adhoc filter on a missing column fails the request and the error
    names that column."""
    data = _run_chart_sql(
        extra_form_data={"adhoc_filters": [_adhoc("does_not_exist")]},
        queries=[_query(dropped=["does_not_exist"])],
    )
    assert _is_error(data), f"expected an error response, got: {data}"
    assert "does_not_exist" in _message(data), data


def test_sql_rejects_unknown_simple_filter_columns():
    """Plain filters on two missing columns, sent next to a valid one, fail the
    request and the error names both missing columns."""
    data = _run_chart_sql(
        extra_form_data={
            "filters": [
                _simple("country", "US"),
                _simple("regoin", "EMEA"),
                _simple("colour_code", "red"),
            ]
        },
        queries=[_query(applied=["country"], dropped=["regoin", "colour_code"])],
    )
    assert _is_error(data), f"expected an error response, got: {data}"
    message = _message(data)
    assert "regoin" in message, data
    assert "colour_code" in message, data


def test_sql_rejects_unknown_column_on_saved_chart():
    """A saved chart answered from its stored query context fails the request
    the same way and names the missing column."""
    data = _run_saved_chart_sql(
        extra_form_data={"adhoc_filters": [_adhoc("units_sold", "10")]},
        queries=[_query(dropped=["units_sold"])],
    )
    assert _is_error(data), f"expected an error response, got: {data}"
    assert "units_sold" in _message(data), data


def test_sql_rejects_unknown_column_in_later_query():
    """For a chart that runs two queries, a missing column dropped only from the
    second query still fails the request."""
    data = _run_chart_sql(
        extra_form_data={"filters": [_simple("segmnt", "retail")]},
        queries=[
            _query(_SQL_TEXT),
            _query(_SECOND_SQL_TEXT, dropped=["segmnt"]),
        ],
    )
    assert _is_error(data), f"expected an error response, got: {data}"
    assert "segmnt" in _message(data), data


# --------------------------------------------------------------------------- #
# SQL tool: requests that must still return SQL.
# --------------------------------------------------------------------------- #


@pytest.mark.parametrize("path", sorted(_SQL_DRIVERS))
def test_sql_ignores_rejections_the_request_did_not_ask_for(path):
    """A saved filter on a column the dataset no longer has, and saved time
    filters (time column, grain, range) the dataset cannot apply, do not fail a
    request whose own filters are all valid; the SQL text is the same as
    before."""
    data = _SQL_DRIVERS[path](
        extra_form_data={"filters": [_simple("country", "US")]},
        queries=[
            _query(
                applied=["country"],
                dropped=["retired_col"],
                time_extras=_SAVED_TIME_EXTRAS,
            )
        ],
    )
    assert not _is_error(data), f"expected SQL, got error: {data}"
    assert data.get("sql") == f"{_SQL_TEXT};", data


@pytest.mark.parametrize("path", sorted(_SQL_DRIVERS))
def test_sql_returned_unchanged_when_nothing_dropped(path):
    """With every requested filter applied, the SQL text is the same as before,
    statements that run ahead of the main query included."""
    data = _SQL_DRIVERS[path](
        extra_form_data={"adhoc_filters": [_adhoc("region", "EMEA")]},
        queries=[_query(applied=["region"], prequeries=[_PREQUERY])],
    )
    assert not _is_error(data), f"expected SQL, got error: {data}"
    assert data.get("sql") == f"{_PREQUERY};\n\n{_SQL_TEXT};", data


# --------------------------------------------------------------------------- #
# Data tool: same decisions as the SQL tool.
# --------------------------------------------------------------------------- #


@pytest.mark.parametrize(
    "extra_form_data, missing",
    [
        ({"adhoc_filters": [_adhoc("store_code", "S1")]}, "store_code"),
        ({"filters": [_simple("cust_tier", "gold")]}, "cust_tier"),
    ],
    ids=["adhoc_filter", "plain_filter"],
)
def test_data_and_sql_agree_on_rejection(extra_form_data, missing):
    """The data tool and the SQL tool both reject the same request and both
    name the missing column."""
    queries = [_query(dropped=[missing])]

    data_response = _run_chart_data(extra_form_data, queries)
    sql_response = _run_chart_sql(extra_form_data, queries)

    assert _is_error(data_response), f"data tool should reject: {data_response}"
    assert missing in _message(data_response), data_response
    assert _is_error(sql_response), f"SQL tool should reject: {sql_response}"
    assert missing in _message(sql_response), sql_response


def test_data_ignores_rejections_the_request_did_not_ask_for():
    """Saved filters the dataset dropped, time filters included, do not turn a
    data request with valid filters into an unknown-column error."""
    data = _run_chart_data(
        extra_form_data={"filters": [_simple("country", "US")]},
        queries=[
            _query(
                applied=["country"],
                dropped=["retired_col"],
                time_extras=_SAVED_TIME_EXTRAS,
            )
        ],
    )
    message = _message(data)
    assert data.get("error_type") != "ValidationError", data
    for name in ["retired_col", *_SAVED_TIME_EXTRAS]:
        assert name not in message, data


# --------------------------------------------------------------------------- #
# Query-only chart-data result.
# --------------------------------------------------------------------------- #


@pytest.mark.parametrize(
    "sql, prequeries, applied, rejected, expected_query",
    [
        (
            "SELECT country FROM sales",
            [],
            ["country"],
            [],
            "SELECT country FROM sales;",
        ),
        (
            "SELECT country FROM sales",
            [],
            ["country"],
            ["does_not_exist"],
            "SELECT country FROM sales;",
        ),
        (
            "SELECT region, count(*) FROM orders GROUP BY region",
            ["SET search_path TO reporting", "SET statement_timeout TO 30000"],
            ["region"],
            ["regoin", "colour_code"],
            "SET search_path TO reporting;\n\n"
            "SET statement_timeout TO 30000;\n\n"
            "SELECT region, count(*) FROM orders GROUP BY region;",
        ),
    ],
    ids=["none_dropped", "one_dropped", "two_dropped_with_prequeries"],
)
def test_query_result_lists_applied_and_rejected_filters(
    sql, prequeries, applied, rejected, expected_query
):
    """A query-only result keeps the exact SQL text it had before and reports
    the dataset's applied and dropped filter columns in the same
    applied_filters / rejected_filters shape full data results use."""
    app = _get_app()
    with app.app_context():
        datasource = _DetailedSource(sql, applied, rejected, prequeries)
        result = _query_only_result(datasource)

    assert not result.get("error"), result
    assert result.get("query") == expected_query, result
    rejected_columns = {
        _plain(entry.get("column"))
        for entry in result.get("rejected_filters") or []
        if isinstance(entry, dict) and _reason(entry) == "not_in_datasource"
    }
    assert rejected_columns == set(rejected), result
    applied_columns = {
        _plain(entry.get("column"))
        for entry in result.get("applied_filters") or []
        if isinstance(entry, dict)
    }
    assert set(applied) <= applied_columns, result


@pytest.mark.parametrize(
    "time_column, time_extras, expected_applied, expected_rejected",
    [
        (
            "order_date",
            {
                "__time_col": "order_date",
                "__time_grain": "P1D",
                "__time_range": "Last week",
            },
            {"__time_col", "__time_grain", "__time_range"},
            set(),
        ),
        (
            "order_date",
            {
                "__time_col": "country",
                "__time_grain": "P1W",
                "__time_range": "Last year",
            },
            {"__time_grain", "__time_range"},
            {("not_in_datasource", "__time_col")},
        ),
        (
            None,
            _SAVED_TIME_EXTRAS,
            set(),
            {
                ("not_in_datasource", "__time_col"),
                ("no_temporal_column", "__time_grain"),
                ("no_temporal_column", "__time_range"),
            },
        ),
    ],
    ids=[
        "dataset_with_time_column",
        "time_column_not_temporal",
        "dataset_without_time_column",
    ],
)
def test_query_result_reports_time_filters_like_full_result(
    time_column, time_extras, expected_applied, expected_rejected
):
    """A query-only result reports the saved time column, time grain and time
    range as applied or rejected, each with its reason, as full data results
    do."""
    app = _get_app()
    with app.app_context():
        datasource = _DetailedSource(
            "SELECT country FROM sales", ["country"], [], time_column=time_column
        )
        result = _query_only_result(datasource, time_extras)

    applied = {
        _plain(entry.get("column")) for entry in result.get("applied_filters") or []
    }
    rejected = {
        (_reason(entry), _plain(entry.get("column")))
        for entry in result.get("rejected_filters") or []
    }
    assert applied == {"country", *expected_applied}, result
    assert rejected == expected_rejected, result


def test_query_result_for_plain_only_datasource():
    """A datasource that only offers the plain query string keeps returning that
    string, with no error and no dropped filters reported."""
    app = _get_app()
    with app.app_context():
        datasource = _PlainSource("SELECT 1 FROM semantic_view")
        result = _query_only_result(datasource)

    assert result.get("query") == "SELECT 1 FROM semantic_view", result
    assert not result.get("error"), result
    assert not result.get("rejected_filters"), result


def test_full_result_reports_column_and_time_rejections():
    """A full data result keeps reporting a dropped dataset column and a time
    filter the dataset cannot apply, each with its own reason."""
    app = _get_app()
    with app.app_context():
        datasource = _DetailedSource("SELECT 1", ["country"], ["retired_col"])
        result = _full_result(datasource, {"__time_range": "Last week"})

    rejected = {
        (_reason(entry), _plain(entry.get("column")))
        for entry in result.get("rejected_filters") or []
    }
    assert rejected == {
        ("not_in_datasource", "retired_col"),
        ("no_temporal_column", "__time_range"),
    }, result
    applied = {
        _plain(entry.get("column")) for entry in result.get("applied_filters") or []
    }
    assert "country" in applied, result
