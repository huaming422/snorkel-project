// @ts-nocheck
//
// Behavioral checks for the preview MCP tools, driven through the server's own
// MCP server: the preview toolkit layer runs against the in-memory browser
// broker, the tools are called by name, and the returned content blocks and
// structured output are inspected. Every module imported here is part of the
// server package (the MCP server, the invocation-context service, the broker,
// and the server-config service with its test layer).
//
// Contract notes:
//   * The snapshot text an MCP client shows the model must fit under the
//     client's single-result cap (~25k tokens, ~100 KB of text). Inputs are
//     sized so each heavy field is over that cap on its own, so the size limit
//     alone decides that each one must be shortened; how far each field is cut
//     is left open.
//   * The text stays the snapshot JSON. A note on what was left out may sit in
//     another text block, in extra top-level keys of that JSON, or as a marker
//     in place of the field it replaces.
//   * The saved screenshot is found by value: any string in the structured
//     result that points under the server's base directory.
//   * An evaluate result is accepted in any form an MCP client takes: no
//     structured content, or structured content that is a JSON object (and,
//     when the tool declares an output schema, always present).

import * as NodeFS from "node:fs";
import * as NodeUtil from "node:util";

import { expect, it } from "@effect/vitest";
import * as NodeServices from "@effect/platform-node/NodeServices";
import { EnvironmentId, ProviderInstanceId, ThreadId } from "@t3tools/contracts";
import * as Deferred from "effect/Deferred";
import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as Layer from "effect/Layer";
import * as Stream from "effect/Stream";
import { McpSchema, McpServer } from "effect/unstable/ai";

import * as ServerConfig from "../config.ts";
import * as McpHttpServer from "./McpHttpServer.ts";
import * as McpInvocationContext from "./McpInvocationContext.ts";
import * as PreviewAutomationBroker from "./PreviewAutomationBroker.ts";

// Single-result cap of the MCP client (~25k tokens at ~4 bytes per token).
const CLIENT_OUTPUT_CEILING_BYTES = 100_000;

const environmentId = EnvironmentId.make("environment-mcp-test");
const threadId = ThreadId.make("thread-mcp-test");

const invocation = {
  environmentId,
  threadId,
  providerSessionId: "provider-session-mcp-test",
  providerInstanceId: ProviderInstanceId.make("codex"),
  capabilities: new Set(["preview"] as const),
  issuedAt: 1,
};

const client = McpSchema.McpServerClient.of({
  clientId: 1,
  clientCapabilities: {},
  clientInfo: { name: "mcp-test", version: "1.0.0" },
  protocolVersion: "2025-06-18",
  initializePayload: {
    protocolVersion: "2025-06-18",
    capabilities: {},
    clientInfo: { name: "mcp-test", version: "1.0.0" },
  },
  getClient: Effect.die("unused"),
});

// Preview toolkit over the MCP server, the in-memory broker, and the
// server-config test layer (a fresh temporary base directory per test).
const TestLayer = McpHttpServer.PreviewToolkitRegistrationLive.pipe(
  Layer.provideMerge(McpServer.McpServer.layer),
  Layer.provideMerge(PreviewAutomationBroker.layer),
  Layer.provideMerge(ServerConfig.layerTest(process.cwd(), { prefix: "t3-mcp-http-server-test-" })),
  Layer.provideMerge(NodeServices.layer),
);

const pngBase64 = (bytes: string) => Buffer.from(bytes).toString("base64");

const snapshotResult = {
  url: "http://example.test/",
  title: "Example",
  loading: false,
  visibleText: "Example",
  interactiveElements: [],
  accessibilityTree: {},
  consoleEntries: [],
  networkEntries: [],
  actionTimeline: [],
  screenshot: {
    mimeType: "image/png",
    data: pngBase64("png"),
    width: 10,
    height: 5,
  },
};

/** Connects a browser host that answers the n-th request with results[n] (the
 * last result repeats), and returns the request inputs it received. */
const serveResults = (clientId: string, results: ReadonlyArray<unknown>) =>
  Effect.gen(function* () {
    const broker = yield* PreviewAutomationBroker.PreviewAutomationBroker;
    const connected = yield* Deferred.make<void>();
    const inputs: Array<unknown> = [];
    const events = yield* broker.connect({ clientId, environmentId });
    yield* Stream.runForEach(events, (event) => {
      if (event.type === "connected") return Deferred.succeed(connected, undefined);
      const result = results[Math.min(inputs.length, results.length - 1)];
      inputs.push(event.request.input);
      return broker.respond({
        clientId,
        connectionId: event.connectionId,
        requestId: event.request.requestId,
        ok: true,
        result,
      });
    }).pipe(Effect.forkScoped);
    yield* Deferred.await(connected);
    return inputs;
  });

const serveResult = (clientId: string, result: unknown) => serveResults(clientId, [result]);

const callTool = (name: string, args: Record<string, unknown>) =>
  Effect.gen(function* () {
    const server = yield* McpServer.McpServer;
    return yield* server
      .callTool({ name, arguments: args })
      .pipe(
        Effect.provideService(McpInvocationContext.McpInvocationContext, invocation),
        Effect.provideService(McpSchema.McpServerClient, client),
      );
  });

const callSnapshot = (args: Record<string, unknown>) => callTool("preview_snapshot", args);

const textBlocks = (content: ReadonlyArray<{ readonly type: string; readonly text?: string }>) =>
  content.filter((block) => block.type === "text").map((block) => block.text ?? "");

const parseJson = (text: string): unknown => {
  try {
    return JSON.parse(text);
  } catch {
    return undefined;
  }
};

const isPlainObject = (value: unknown): value is Record<string, unknown> =>
  typeof value === "object" && value !== null && !Array.isArray(value);

const SNAPSHOT_KEYS = new Set([
  "url",
  "title",
  "loading",
  "visibleText",
  "interactiveElements",
  "accessibilityTree",
  "consoleEntries",
  "networkEntries",
  "actionTimeline",
  "screenshot",
]);

/**
 * Splits the snapshot's text content into the snapshot JSON the model reads
 * (the text block that parses to an object with interactiveElements) and the
 * notes around it: every other text block plus any extra top-level keys of
 * that JSON.
 */
const readSnapshotText = (content: ReadonlyArray<{ readonly type: string; readonly text?: string }>) => {
  const texts = textBlocks(content);
  let body: Record<string, any> | undefined;
  const notes: Array<string> = [];
  for (const text of texts) {
    const parsed = parseJson(text);
    if (body === undefined && isPlainObject(parsed) && Array.isArray(parsed.interactiveElements)) {
      body = parsed;
      const extra = Object.fromEntries(
        Object.entries(parsed).filter(([key]) => !SNAPSHOT_KEYS.has(key)),
      );
      if (Object.keys(extra).length > 0) notes.push(JSON.stringify(extra));
    } else {
      notes.push(text);
    }
  }
  const totalBytes = texts.reduce((sum, text) => sum + Buffer.byteLength(text, "utf8"), 0);
  return { body, notes: notes.join("\n"), totalBytes };
};

/** Index of a log entry, read from the `<prefix>-<n>:` tag its strings start with. */
const entryIndex = (entry: unknown, prefix: string): number | undefined => {
  const match = JSON.stringify(entry).match(new RegExp(`${prefix}-(\\d+):`));
  return match ? Number(match[1]) : undefined;
};

/** The tagged entries kept from a list of `total` inputs: they must be the
 * newest ones, in order. Untagged marker entries are allowed and ignored. */
const expectNewestKept = (entries: ReadonlyArray<unknown>, prefix: string, total: number) => {
  const kept = entries
    .map((entry) => entryIndex(entry, prefix))
    .filter((index): index is number => index !== undefined);
  expect(kept.length).toBeGreaterThan(0);
  expect(kept).toEqual(Array.from({ length: kept.length }, (_, i) => total - kept.length + i));
};

/** Entries in a kept list that are not one of the input entries (in-place
 * notes such as "360 older entries omitted"). */
const markerEntries = (entries: ReadonlyArray<unknown> | undefined, prefix: string) =>
  (entries ?? []).filter((entry) => entryIndex(entry, prefix) === undefined);

const collectStringsUnder = (value: unknown, prefix: string): ReadonlyArray<string> => {
  if (typeof value === "string") return value.startsWith(prefix) ? [value] : [];
  if (Array.isArray(value)) return value.flatMap((entry) => collectStringsUnder(entry, prefix));
  if (isPlainObject(value)) {
    return Object.values(value).flatMap((entry) => collectStringsUnder(entry, prefix));
  }
  return [];
};

/** Every string in the result that names a file on disk, wherever it was written. */
const existingFilePaths = (value: unknown): ReadonlyArray<string> =>
  collectStringsUnder(value, "").filter(
    (entry) => entry.startsWith("/") && NodeFS.existsSync(entry) && NodeFS.statSync(entry).isFile(),
  );

const listFiles = (dir: string): ReadonlyArray<string> =>
  NodeFS.existsSync(dir)
    ? (NodeFS.readdirSync(dir, { recursive: true }) as Array<string>).filter((entry) =>
        NodeFS.statSync(`${dir}/${entry}`).isFile(),
      )
    : [];

// Busy page: page text, three element names and the accessibility tree are
// each over the client cap on their own, plus a long console history.
const pageLine = "/Users/dev/Code/project · assistant · 79 threads\n";
const pageText = pageLine.repeat(3_200);
const oversizedElement = (name: string, index: number) => ({
  tag: "div",
  role: "presentation",
  name,
  selector: `div:nth-of-type(${index})`,
  x: 0,
  y: index * 10,
  width: 10,
  height: 10,
});
const CONSOLE_COUNT = 400;
const oversizedSnapshot = {
  ...snapshotResult,
  visibleText: pageText,
  interactiveElements: [
    oversizedElement(pageText, 1),
    oversizedElement(pageText, 2),
    oversizedElement(pageText, 3),
    oversizedElement("Continue", 4),
  ],
  accessibilityTree: {
    nodes: Array.from({ length: 2_000 }, (_, i) => ({
      nodeId: `${i}`,
      role: "generic",
      name: `/Users/dev/Code/project/thread-${i} · assistant conversation row`,
    })),
  },
  consoleEntries: Array.from({ length: CONSOLE_COUNT }, (_, i) => ({
    level: "log",
    text: `entry-${i}: ${"render pass ".repeat(34)}`,
    timestamp: "t",
  })),
};

it.effect(
  "keeps the snapshot text of a busy page under the client output cap while structuredContent stays complete",
  () =>
    Effect.scoped(
      Effect.gen(function* () {
        yield* serveResult("mcp-bounded-client", oversizedSnapshot);
        const snapshot = yield* callSnapshot({});

        expect(snapshot.isError).toBe(false);
        const { body, totalBytes } = readSnapshotText(snapshot.content);
        expect(body).toBeDefined();
        expect(totalBytes).toBeLessThanOrEqual(CLIENT_OUTPUT_CEILING_BYTES);
        expect(snapshot.content.some((block) => block.type === "image")).toBe(true);

        // The structured result still carries the whole snapshot.
        const { screenshot: _screenshot, ...expectedPage } = oversizedSnapshot;
        expect(snapshot.structuredContent).toMatchObject(expectedPage);
      }),
    ).pipe(Effect.provide(TestLayer)),
);

it.effect(
  "keeps every locator, shortens oversized fields, keeps the newest console entries and says what was left out",
  () =>
    Effect.scoped(
      Effect.gen(function* () {
        yield* serveResult("mcp-bounded-fields-client", oversizedSnapshot);
        const snapshot = yield* callSnapshot({ includeImage: false });

        expect(snapshot.isError).toBe(false);
        const { body, notes } = readSnapshotText(snapshot.content);
        expect(body).toBeDefined();

        // Every interactive element keeps its selector; long names are
        // shortened, a short name is left as it is.
        expect(body!.interactiveElements.map((element) => element.selector)).toEqual(
          oversizedSnapshot.interactiveElements.map((element) => element.selector),
        );
        for (const element of body!.interactiveElements.slice(0, 3)) {
          expect(typeof element.name).toBe("string");
          expect(element.name.length).toBeGreaterThan(0);
          expect(element.name.length).toBeLessThan(pageText.length);
        }
        expect(body!.interactiveElements[3]?.name).toBe("Continue");

        // Page text is shortened, not dropped.
        expect(typeof body!.visibleText).toBe("string");
        expect(body!.visibleText).toContain(pageLine.trim());

        // Console history keeps its newest entries.
        expectNewestKept(body!.consoleEntries, "entry", CONSOLE_COUNT);

        // The text says the accessibility tree and the console history were cut,
        // in a note or as a marker in place of the tree.
        const tree = body!.accessibilityTree;
        const treeMarker =
          tree !== undefined && !(isPlainObject(tree) && Array.isArray(tree.nodes))
            ? JSON.stringify(tree)
            : "";
        expect(/accessib|a11y|tree/i.test(notes) || treeMarker.length > 0).toBe(true);
        expect(
          /console|log/i.test(notes) || markerEntries(body!.consoleEntries, "entry").length > 0,
        ).toBe(true);
      }),
    ).pipe(Effect.provide(TestLayer)),
);

it.effect("drops log entries before any locator when every list is oversized", () =>
  Effect.scoped(
    Effect.gen(function* () {
      const long = "x".repeat(2_000);
      const tagged = (prefix: string, i: number) => `${prefix}-${i}:${long}`;
      const LOG_COUNT = 200;
      const fullLists = {
        ...snapshotResult,
        interactiveElements: Array.from({ length: 20 }, (_, i) => ({
          tag: "button",
          role: "button",
          name: `Button ${i}`,
          selector: `#button-${i}`,
          x: 0,
          y: i * 10,
          width: 10,
          height: 10,
        })),
        consoleEntries: Array.from({ length: LOG_COUNT }, (_, i) => ({
          level: "log",
          text: tagged("console", i),
          timestamp: long,
          source: long,
        })),
        networkEntries: Array.from({ length: LOG_COUNT }, (_, i) => ({
          url: tagged("network", i),
          method: "GET",
          status: 200,
          failed: false,
          errorText: long,
          timestamp: long,
        })),
        actionTimeline: Array.from({ length: LOG_COUNT }, (_, i) => ({
          id: tagged("action", i),
          action: long,
          status: "succeeded",
          startedAt: long,
          completedAt: long,
          error: long,
        })),
      };
      yield* serveResult("mcp-full-lists-client", fullLists);
      const snapshot = yield* callSnapshot({ includeImage: false });

      expect(snapshot.isError).toBe(false);
      const { body, notes, totalBytes } = readSnapshotText(snapshot.content);
      expect(body).toBeDefined();
      expect(totalBytes).toBeLessThanOrEqual(CLIENT_OUTPUT_CEILING_BYTES);

      // All twenty locators survive while the log lists take the cut.
      expect(body!.interactiveElements).toHaveLength(20);
      expect(body!.interactiveElements.map((element) => element.selector)).toEqual(
        fullLists.interactiveElements.map((element) => element.selector),
      );
      expect(body!.interactiveElements.map((element) => element.name)).toEqual(
        fullLists.interactiveElements.map((element) => element.name),
      );

      // Whatever is kept of each log list is its newest entries.
      const lists = [
        ["consoleEntries", "console"],
        ["networkEntries", "network"],
        ["actionTimeline", "action"],
      ] as const;
      let markerCount = 0;
      for (const [key, prefix] of lists) {
        const entries = (body![key] ?? []) as ReadonlyArray<unknown>;
        if (entries.some((entry) => entryIndex(entry, prefix) !== undefined)) {
          expectNewestKept(entries, prefix, LOG_COUNT);
        }
        markerCount += markerEntries(entries, prefix).length;
      }

      // The text says log entries were cut, in a note or as marker entries.
      expect(/console|network|action|log/i.test(notes) || markerCount > 0).toBe(true);
    }),
  ).pipe(Effect.provide(TestLayer)),
);

// Values an expression can return, objects and non-objects alike.
const evaluateCases = [
  ["an array", ["Connect", "Continue"]],
  ["an array of objects", [{ label: "Connect" }, { label: "Skip" }]],
  ["null", null],
  ["a string", "Continue"],
  ["a number", 42],
  ["a boolean", false],
  ["an object", { label: "Continue", enabled: true }],
] as const;

/** A JSON value that is the result itself or a one-key object holding it. */
const carries = (candidate: unknown, value: unknown) =>
  NodeUtil.isDeepStrictEqual(candidate, value) ||
  (isPlainObject(candidate) &&
    Object.keys(candidate).length === 1 &&
    NodeUtil.isDeepStrictEqual(Object.values(candidate)[0], value));

it.effect.each(evaluateCases)("returns an evaluate result of %s in a form MCP clients accept", ([, value]) =>
  Effect.scoped(
    Effect.gen(function* () {
      yield* serveResult("mcp-evaluate-client", value);
      const server = yield* McpServer.McpServer;

      const evaluated = yield* callTool("preview_evaluate", { expression: "buttons()" });
      expect(evaluated.isError).toBe(false);

      // Structured content, when present, is a JSON object carrying the value;
      // a declared output schema means it is always present.
      const evaluateTool = server.tools.find(({ tool }) => tool.name === "preview_evaluate");
      const structured = evaluated.structuredContent;
      if (evaluateTool?.tool.outputSchema !== undefined) {
        expect(evaluateTool.tool.outputSchema).toMatchObject({ type: "object" });
        expect(structured).toBeDefined();
      }
      if (structured !== undefined) {
        expect(isPlainObject(structured)).toBe(true);
        expect(carries(structured, value)).toBe(true);
      }

      // The model reads the value from the text content.
      const texts = textBlocks(evaluated.content);
      expect(texts.some((text) => carries(parseJson(text), value))).toBe(true);
    }),
  ).pipe(Effect.provide(TestLayer)),
);

it.effect(
  "saves the screenshot under the server base directory only when asked, one file per save",
  () =>
    Effect.scoped(
      Effect.gen(function* () {
        const config = yield* ServerConfig.ServerConfig;
        const fileSystem = yield* FileSystem.FileSystem;
        yield* serveResults("mcp-save-client", [
          {
            ...snapshotResult,
            url: "http://first.test/onboarding",
            screenshot: { ...snapshotResult.screenshot, data: pngBase64("first-png") },
          },
          {
            ...snapshotResult,
            url: "http://second.test/settings",
            screenshot: { ...snapshotResult.screenshot, data: pngBase64("second-png") },
          },
          snapshotResult,
        ]);

        const savedPathOf = (snapshot: McpSchema.CallToolResult) =>
          Effect.gen(function* () {
            expect(snapshot.isError).toBe(false);
            const paths = collectStringsUnder(snapshot.structuredContent, config.baseDir);
            expect(paths).toHaveLength(1);
            const path = paths[0]!;
            // The text the model reads names the same file.
            expect(textBlocks(snapshot.content).some((text) => text.includes(path))).toBe(true);
            return path;
          });

        const first = yield* savedPathOf(yield* callSnapshot({ save: true }));
        const second = yield* savedPathOf(yield* callSnapshot({ save: true, includeImage: false }));

        // Each save is its own file holding that capture's PNG bytes.
        expect(second).not.toBe(first);
        expect(Buffer.from(yield* fileSystem.readFile(first)).toString()).toBe("first-png");
        expect(Buffer.from(yield* fileSystem.readFile(second)).toString()).toBe("second-png");

        // With the option left out or set to false, nothing is written and no
        // path comes back.
        const filesBefore = listFiles(config.baseDir);
        for (const args of [{}, { save: false }]) {
          const unsaved = yield* callSnapshot(args);
          expect(unsaved.isError).toBe(false);
          expect(collectStringsUnder(unsaved.structuredContent, config.baseDir)).toHaveLength(0);
          expect(existingFilePaths(unsaved.structuredContent)).toHaveLength(0);
          expect(textBlocks(unsaved.content).some((text) => text.includes(config.baseDir))).toBe(
            false,
          );
        }
        expect(listFiles(config.baseDir)).toEqual(filesBefore);
      }),
    ).pipe(Effect.provide(TestLayer)),
);

it.effect("returns an error that names the screenshot when it cannot be saved", () =>
  Effect.scoped(
    Effect.gen(function* () {
      const config = yield* ServerConfig.ServerConfig;
      const fileSystem = yield* FileSystem.FileSystem;

      // A regular file in place of the base directory: nothing can be
      // created or written anywhere under it.
      yield* fileSystem.remove(config.baseDir, { recursive: true });
      yield* fileSystem.writeFileString(config.baseDir, "");

      yield* serveResult("mcp-save-failure-client", snapshotResult);
      const snapshot = yield* callSnapshot({ save: true });

      expect(snapshot.isError).toBe(true);
      expect(textBlocks(snapshot.content).join("\n")).toMatch(/screenshot/i);
    }),
  ).pipe(Effect.provide(TestLayer)),
);

it.effect("returns an ordinary snapshot with its full metadata, text and image", () =>
  Effect.scoped(
    Effect.gen(function* () {
      const config = yield* ServerConfig.ServerConfig;
      yield* serveResult("mcp-normal-client", snapshotResult);

      const snapshot = yield* callSnapshot({});
      expect(snapshot.isError).toBe(false);

      // Page fields and screenshot metadata round-trip; the PNG bytes travel
      // in the image block, not in the structured result.
      const { screenshot: expectedShot, ...expectedRest } = snapshotResult;
      const { data: _rawBytes, ...expectedShotMeta } = expectedShot;
      expect(snapshot.structuredContent).toMatchObject({
        ...expectedRest,
        screenshot: expectedShotMeta,
      });
      expect(collectStringsUnder(snapshot.structuredContent, config.baseDir)).toHaveLength(0);
      expect(existingFilePaths(snapshot.structuredContent)).toHaveLength(0);

      expect(textBlocks(snapshot.content).length).toBeGreaterThan(0);
      const image = snapshot.content.find((block) => block.type === "image");
      expect(image).toBeDefined();
      expect(Buffer.from(image.data).toString()).toBe("png");
    }),
  ).pipe(Effect.provide(TestLayer)),
);
