The preview browser tools the assistant gets over MCP are letting it down, and it can't check its own UI work anymore.
All three problems below showed up in one session while it was checking a change in the preview.

On a page with a lot of content, `preview_snapshot` comes back as nothing but Claude Code's truncation notice.
Claude Code drops any single tool result over about 25k tokens, so the assistant loses every locator on the page along with the rest.
The snapshot text it reads has to stay under 100 KB no matter how big the page is.
It should still be the same snapshot JSON as today, just trimmed where needed.
Locators matter most: an interactive element can lose part of a long name but should keep its selector, and the console, network and action history should go before any element is dropped.
When entries get dropped from those lists, keep the newest ones.
The text should also tell the assistant what was left out.
The structured result (`structuredContent`) should still carry the complete snapshot; only the text gets trimmed.
Snapshots of ordinary pages should come back the way they do now.

`preview_evaluate` fails with "malformed result that failed schema validation" when the expression returns an array or `null`, and the assistant has to retry with the expression wrapped in `JSON.stringify`.
Whatever an expression returns, the call should succeed and the value should be in the text the assistant reads.

There's also no way to keep a screenshot.
The image only lives in that one tool result and shows up as "Image unavailable" later in the chat.
Add a `save` option to `preview_snapshot`.
With `save: true`, write the PNG to a file under the T3 Code data directory (`T3CODE_HOME` or `--base-dir`) and return its path in both the structured result and the text.
Each save should get its own file, so a later screenshot never replaces an earlier one.
When `save` is left out or false, nothing gets written and no path comes back.
If the file can't be written, the call should fail with an error that says the screenshot couldn't be saved.
