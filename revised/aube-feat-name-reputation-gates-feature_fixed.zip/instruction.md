## Task

`aube add` already pushes back on risky packages before it installs them, and we want it to catch two more kinds of npm names.
The first is a name that looks like a typo or lookalike of a well-known package.
The second is a name that only showed up on the public registry very recently.
Both checks should behave like the low-downloads check that's already there, both in how they ask or refuse and in which names they leave alone.

For the lookalike check, every package in aube's bundled npm metadata primer counts as well-known, not just a handful of famous names picked by hand.
A name is a near miss when it's at most two edits away from a well-known name, or at most one edit when both names being compared are shorter than five characters.
Adding, dropping or changing one character is one edit, and so is swapping two characters that sit next to each other.
Two names in the same scope are compared by the part after the slash, names in different scopes are compared whole, and a scoped name is never compared with an unscoped one.

The recency window should be a new aube setting, counted in minutes.
On a machine that can't reach the registry, a package aube has looked up before should still be judged by its real first-publish date.

## User stories / requirements

- With no terminal, `aube add` refuses a near miss, and the error names the well-known package it resembles, the closest one when several are near. An exact well-known name isn't a near miss of itself, and a name with no well-known package that close goes through.
- With no terminal, `aube add` refuses a name first published inside the recency window and allows an older one. If the registry can't confirm the first-publish date, the add is refused and the error names the window setting. The window works from both `.npmrc` and the environment, and `0` turns the check off.
- A name that either new check would flag is not stopped by them when it's already in the project's lockfile, matches `allowedUnpopularPackages`, or is installed from a local folder. Passing `--allow-low-downloads` also lets it through for that one command.
- When `aube add` runs at a terminal, a near miss or a name first published inside the window gets a yes/no prompt instead of an immediate failure, and the lookalike prompt names the package it resembles. Answering yes carries on with the add and answering no stops it.
