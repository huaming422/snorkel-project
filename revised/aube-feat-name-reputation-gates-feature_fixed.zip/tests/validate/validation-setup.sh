#!/usr/bin/env bash
# Validation setup: runs after the user changes are in place, before the stories.
# One job: rebuild the `aube` CLI binary (incremental - the image baked a
# dependency-warm target dir, so only the touched workspace crates recompile and
# relink). The stories then drive that binary.
#
# No fixtures are staged here: each story builds its own throwaway project dir at
# run time (see test_harness.new_project), copying in a private copy of the
# image-baked offline metadata+content snapshot at /opt/aube-warm. This phase has
# no route to the public registry, so the stories resolve/install the two fixed
# real-world names from that snapshot (warmed at image build time), plus names
# they seed into a project's private copy, with no network. This setup just
# verifies the snapshot is present before handing off.
#
# Idempotent: re-running just rebuilds; the cargo cache survives.
set -euo pipefail

REPO=/repo/aube
AUBE_BIN=/opt/cache/cargo-target/debug/aube

# Re-export the image's pinned Rust toolchain locations. The Dockerfile sets
# these image-wide, but a validation shell may start from a clean environment.
export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
export PATH="$CARGO_HOME/bin:$PATH"

echo "validation-setup: rustc=$(rustc --version 2>&1 | head -1)"
echo "validation-setup: cargo=$(cargo --version 2>&1 | head -1)"
echo "validation-setup: node=$(node --version 2>&1 | head -1)"

# Build the aube binary with the user changes applied (incremental). `node` is on
# PATH (installed by the image) for the resolver's build script.
echo "validation-setup: building aube (incremental)..."
( cd "$REPO" && cargo build -p aube --bin aube 2>&1 | tail -8 )

test -x "$AUBE_BIN" || {
    echo "ERROR: aube binary missing at $AUBE_BIN after cargo build" >&2
    exit 1
}
echo "validation-setup: aube built at $AUBE_BIN ($("$AUBE_BIN" --version 2>&1 | head -1))"

# Loud smoke guard: if `aube add --help` itself fails, every story would fail
# with the same opaque error - surface it here instead.
"$AUBE_BIN" add --help >/dev/null 2>&1 || {
    echo "ERROR: 'aube add --help' failed; the add subcommand is not runnable" >&2
    "$AUBE_BIN" add --help || true
    exit 1
}

# Loud guard: the stories resolve/install offline from the image-baked snapshot.
# If it is missing, every story would fail with an opaque network error - surface
# the real cause here instead.
WARM=/opt/aube-warm
for name in lodash left-pad; do
    if ! ls "$WARM"/cache/packuments-full-v1/*/"$name".json >/dev/null 2>&1; then
        echo "ERROR: baked offline snapshot missing packument for '$name' under $WARM" >&2
        find "$WARM/cache/packuments-full-v1" -maxdepth 2 2>/dev/null >&2 || true
        exit 1
    fi
done
test -d "$WARM/store" || { echo "ERROR: baked content store missing at $WARM/store" >&2; exit 1; }
echo "validation-setup: offline snapshot present at $WARM (lodash, left-pad)."

echo "validation-setup: done."
