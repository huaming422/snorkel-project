#!/usr/bin/env bash
# Verifier-side setup: runs before the verifiers. The image already installed
# the Rust toolchain, warmed the cargo registry, pre-fetched dependencies, and
# pre-built the workspace at the base commit; this just re-exports the toolchain
# onto PATH (Modal starts a fresh shell per phase), pins cargo to offline so a
# cache miss fails fast instead of hanging on a dead network, and makes sure
# pytest is importable for any Python verifier.
set -euo pipefail

# Re-export the Rust toolchain paths baked by the image.
export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
export PATH="$CARGO_HOME/bin:$PATH"

# Offline switches for the task's own tooling only. These live here, NOT in the
# image, so harbor's `uv tool install` at trial prep (which runs while the
# network is still up) is unaffected. The dependency closure is already warm in
# the image, so cargo and uv must never reach the network at grade time.
export CARGO_NET_OFFLINE=true
export UV_OFFLINE=1

# Sanity check: the toolchain must be present.
rustc --version >/dev/null 2>&1 || {
    echo "ERROR: rustc not found on PATH (CARGO_HOME=$CARGO_HOME)" >&2
    exit 1
}
cargo --version >/dev/null 2>&1 || {
    echo "ERROR: cargo not found on PATH" >&2
    exit 1
}

# Ensure pytest is importable for any Python verifier. The image already
# installed it into the verifier venv; this is a belt-and-suspenders no-op when
# the cache is warm. The pin matches the canonical verifier stack; the offline
# cache satisfies it without reaching the network.
if ! python3 -c "import pytest" >/dev/null 2>&1; then
    pip3 install --break-system-packages -q "pytest==9.1.1" || true
fi

echo "test-setup: rustc=$(rustc --version), cargo=$(cargo --version | head -1), CARGO_NET_OFFLINE=$CARGO_NET_OFFLINE"
