#!/usr/bin/env bash
# Build and vet check for the adk package.
#
# Builds the package and its subpackages and runs go vet at the image's
# toolchain, with CGO enabled, the same way the race-detector test run needs it.
set -euo pipefail

export GOFLAGS="${GOFLAGS:--mod=mod}"
export CGO_ENABLED="${CGO_ENABLED:-1}"
export GOTOOLCHAIN="${GOTOOLCHAIN:-local}"
export GOMODCACHE="${GOMODCACHE:-/opt/cache/go}"
export GOCACHE="${GOCACHE:-/opt/cache/go-build}"

cd /repo/eino

# The package and its subpackages must build, and vet must stay clean.
go build ./adk/...
go vet ./adk/
