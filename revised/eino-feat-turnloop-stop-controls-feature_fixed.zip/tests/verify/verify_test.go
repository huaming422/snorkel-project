// Concurrency check for the stop/cleanup path.
//
// Drives many Push / Stop / Run / Wait calls concurrently on a running loop and
// checks that every iteration terminates. The runner uses `go test -race` with
// CGO enabled, so a data race on the shared stop/cleanup state fails the test.
//
// Everything goes through the package's existing public API (NewTurnLoop /
// TurnLoopConfig / Push / Stop / Wait and the Agent interface).
package adk_test

import (
	"context"
	"sync"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"

	"github.com/cloudwego/eino/adk"
	"github.com/cloudwego/eino/schema"
)

// verifyMockAgent is a minimal self-contained Agent built only on the public
// adk surface, so this external test package never depends on package-internal
// test helpers.
type verifyMockAgent struct {
	name string
}

func (a *verifyMockAgent) Name(_ context.Context) string        { return a.name }
func (a *verifyMockAgent) Description(_ context.Context) string { return "verify mock agent" }

func (a *verifyMockAgent) Run(_ context.Context, _ *adk.AgentInput, _ ...adk.AgentRunOption) *adk.AsyncIterator[*adk.AgentEvent] {
	iter, gen := adk.NewAsyncIteratorPair[*adk.AgentEvent]()
	go func() {
		defer gen.Close()
		gen.Send(&adk.AgentEvent{Output: &adk.AgentOutput{}})
	}()
	return iter
}

// TestVerifyConcurrentStopPushRaceFree drives concurrent producers (Push) and
// stoppers (Stop) against a running loop and asserts the loop terminates
// cleanly. Under -race it also fails on any data race in the stop/cleanup path.
func TestVerifyConcurrentStopPushRaceFree(t *testing.T) {
	for iter := 0; iter < 25; iter++ {
		ctx := context.Background()

		loop := adk.NewTurnLoop(adk.TurnLoopConfig[string]{
			GenInput: func(_ context.Context, _ *adk.TurnLoop[string], items []string) (*adk.GenInputResult[string], error) {
				return &adk.GenInputResult[string]{
					Input:    &adk.AgentInput{Messages: []adk.Message{schema.UserMessage(items[0])}},
					Consumed: items,
				}, nil
			},
			PrepareAgent: func(_ context.Context, _ *adk.TurnLoop[string], _ []string) (adk.Agent, error) {
				return &verifyMockAgent{name: "verify"}, nil
			},
			OnAgentEvents: func(_ context.Context, _ *adk.TurnContext[string], events *adk.AsyncIterator[*adk.AgentEvent]) error {
				for {
					if _, ok := events.Next(); !ok {
						break
					}
				}
				return nil
			},
		})

		loop.Run(ctx)

		var wg sync.WaitGroup
		// Concurrent producers.
		for p := 0; p < 4; p++ {
			wg.Add(1)
			go func() {
				defer wg.Done()
				for i := 0; i < 8; i++ {
					loop.Push("item")
				}
			}()
		}
		// Concurrent stoppers.
		for s := 0; s < 3; s++ {
			wg.Add(1)
			go func() {
				defer wg.Done()
				loop.Stop()
			}()
		}
		wg.Wait()

		// Ensure the loop is stopped and the exit state is retrievable without a race.
		loop.Stop()
		done := make(chan struct{})
		go func() {
			loop.Wait()
			close(done)
		}()
		select {
		case <-done:
		case <-time.After(10 * time.Second):
			t.Fatal("loop did not terminate after concurrent Stop/Push")
		}
	}

	assert.True(t, true)
}
