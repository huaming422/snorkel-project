#!/usr/bin/env bash
# Environment setup for the TurnLoop stop-controls story tests.
#
# Runs after tests/test-setup.sh has prepared the Go toolchain and before the
# story tests are written and run. The adk package needs no services; this only
# re-exports the toolchain environment so the go-test driver inherits a fixed
# configuration.
set -euo pipefail

export GOFLAGS="${GOFLAGS:--mod=mod}"
export CGO_ENABLED="${CGO_ENABLED:-1}"
export GOTOOLCHAIN="${GOTOOLCHAIN:-local}"
export GOMAXPROCS="${GOMAXPROCS:-4}"
export GOMODCACHE="${GOMODCACHE:-/opt/cache/go}"
export GOCACHE="${GOCACHE:-/opt/cache/go-build}"
mkdir -p "$GOMODCACHE" "$GOCACHE"

# Dependencies are baked into the image: resolve offline first, with a logged
# online fallback.
if ! ( cd /repo/eino && GOPROXY=off go mod download ); then
    echo "validation-setup.sh: offline module resolution failed; retrying online" >&2
    ( cd /repo/eino && go mod download ) || true
fi

echo "validation-setup.sh: Go toolchain ready."
