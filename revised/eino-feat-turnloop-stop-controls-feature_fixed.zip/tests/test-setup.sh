# Sourced before the tests run.
#
# Uses the image's Go toolchain (Go 1.23.12) and the module cache baked into the
# image. The adk package needs no external services; CGO stays on because the
# Go tests run under the race detector. Setup only exports a fixed toolchain
# environment and makes sure the cache dirs exist.
set -euo pipefail

cd /repo/eino

export GOFLAGS="-mod=mod"
export CGO_ENABLED="1"
export GOTOOLCHAIN="local"
export GOMAXPROCS="${GOMAXPROCS:-4}"
export GOMODCACHE="${GOMODCACHE:-/opt/cache/go}"
export GOCACHE="${GOCACHE:-/opt/cache/go-build}"
mkdir -p "$GOMODCACHE" "$GOCACHE"

# Dependencies are baked into the image, so resolve offline first (GOPROXY=off);
# only if that fails fall back to a logged online fetch. Normally a no-op.
if ! GOPROXY=off go mod download; then
    echo "test-setup.sh: offline module resolution failed; retrying online" >&2
    go mod download || true
fi

echo "test-setup.sh: Go toolchain ready."
