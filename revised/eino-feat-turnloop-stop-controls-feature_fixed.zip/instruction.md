## Task

People driving `TurnLoop[T]` in `adk` need more say over how a loop stops and what its cleanup does with the checkpoint.
Please add these to the public API:

- `WithSkipCheckpoint` and `WithStopCause`, as options for `Stop`.
- `StopCause`, `Checkpointed`, `CheckpointErr` and `TakeLateItems` on `TurnLoopExitState[T]`.
- `StopCause` on `TurnContext[T]`.

Stops, pushes and a running agent can all overlap here, so whatever state you add has to hold up under `go test -race`.

## User stories / requirements

- Once a loop has exited for any reason, a push returns false and keeps the item as a late item. `TakeLateItems` returns them in push order, and repeat calls return the same items. After the first call, any further push panics. If nobody calls it, late items are dropped and stay out of `UnhandledItems`.
- With a store, the exit state shows whether cleanup tried a checkpoint save, even a failed one, and reports the save error apart from the exit reason. Nothing is saved without a store, or when the loop ends on a callback error instead of a stop, even when `Stop` was called during that callback.
- A stop with `WithSkipCheckpoint` saves no checkpoint, the exit state says no save was tried, and an older checkpoint is deleted if the store can delete. Once any stop on the loop asks to skip, the loop stays that way, whichever order the stops come in.
- A stop can carry a reason through `WithStopCause`. It shows up on the exit state, and on the turn context once that turn's `Stopped` channel is closed. With several stops the first non-empty reason wins, and with no reason it is empty.
- When a loop with an existing checkpoint exits without saving a new one, a store that implements `CheckPointDeleter` gets that checkpoint deleted. A store that can't delete keeps it exactly as it was.
