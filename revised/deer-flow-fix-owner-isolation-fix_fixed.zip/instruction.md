## Task

We have a privacy problem in the gateway.
Our internal service account calls it on behalf of one customer at a time, and while acting for customer A it can read customer B's run data.
It sees B's runs in the thread's run list (plain and paged), and it can open one of B's runs by id.
From there it gets everything under that run: its messages, events and workspace changes, the join and live stream endpoints, cancel, and the artifact archive (both the manifest and the download).
The thread's token-usage totals also include B's spend.
The context window shown in that same answer can come from the model B's newest run used instead of A's.
On our hosted setup, where run events are kept in the database, B's messages also show up in the thread's message history, both the full list and the paged one.
It only happens on older shared threads, the ones with no owner on record.

What we need on those threads:

- The service sees only the runs saved for the customer it is acting for, in the run list, the paged list and single-run lookups (a run the gateway still holds in its own memory, such as one still in progress, is outside this request).
- A page of the run list holds that customer's newest runs up to the page size, and its next-page cursor leads on to the rest of them.
- Opening someone else's saved run by id answers not found, the same as when a signed-in user opens a run that isn't theirs (again leaving out runs the gateway still holds in memory).
- Join, stream, cancel and both archive endpoints answer not found for someone else's run as well.
- Someone else's run messages, events and workspace changes must not come back, and either a not-found answer or an empty one is fine there.
- With run events in the database, the thread's message history shows only the customer's own messages.
- Asking that history for the last N messages, or for a page of N, gives the customer's own N newest, and the paged view's has-more flag and cursor follow those messages only.
- Every answer that history returns, on the full list and on the pages, keeps its turn time, however many runs other customers have added to the thread since.
- A call that doesn't name a customer at all shouldn't see any customer's saved runs, run data or spend on these threads.
- With run events in the database, that call's thread message history leaves out every customer's messages as well.
- That same call still sees runs saved under the old default identity, with their run data and their spend, and with run events in the database their messages still show in its thread message history.
- The customer's own runs answer on every endpoint listed above the same way they do today.
- Token totals count only the caller's own runs, on the in-memory run store and on the SQL one.
- The context window in the token-usage answer (its size and the percentage used) comes from the model of the caller's own newest run, on either run store, and from the first configured model when the caller has no run on the thread.

Those last two points aren't limited to the service.
A signed-in user on one of these threads also gets a total that includes other people's runs, and a context window taken from someone else's newer run.
For a call that names no customer, both follow its runs saved under the old default identity.

Threads that do have an owner on record are fine today and should stay as they are.
There, the service still sees every run on the thread, including older runs saved under another identity such as the old default one, whether or not the call names a customer.
The token total on those threads still counts all of them, the context window still follows the newest run on the thread, whoever it belongs to, and the message history still shows every message.
Signed-in users already see only their own runs in the run list, and that shouldn't change.
