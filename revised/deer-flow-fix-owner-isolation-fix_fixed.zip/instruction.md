## Task

We have a privacy problem in the gateway.
Our internal service account calls it on behalf of one customer at a time, and while acting for customer A it can read customer B's run data.
It sees B's runs in the thread's run list (plain and paged), and it can open one of B's runs by id.
From there it gets everything under that run: its messages, events and workspace changes, the join and live stream endpoints, cancel, and the artifact archive (both the manifest and the download).
The thread's token-usage totals also include B's spend.
It only happens on older shared threads, the ones with no owner on record.

What we need on those threads:

- The service sees only the runs saved for the customer it is acting for, in the run list, the paged list and single-run lookups.
- Opening someone else's run by id answers not found, the same as when a signed-in user opens a run that isn't theirs.
- Join, stream, cancel and both archive endpoints answer not found for someone else's run as well.
- Someone else's messages, events and workspace changes must not come back, and either a not-found answer or an empty one is fine there.
- A call that doesn't name a customer at all shouldn't see any customer's runs or spend on these threads.
- The customer's own runs answer on every endpoint listed above the same way they do today.
- Token totals count only the caller's own runs, on the in-memory run store and on the SQL one.

That last point isn't limited to the service.
A signed-in user on one of these threads also gets a total that includes other people's runs.

Threads that do have an owner on record are fine today and should stay as they are.
There, the service still sees every run on the thread, including older runs saved under another identity such as the old default one, whether or not the call names a customer.
The token total on those threads still counts all of them.
Signed-in users already see only their own runs in the run list, and that shouldn't change.
