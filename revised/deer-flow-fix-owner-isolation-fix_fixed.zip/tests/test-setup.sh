#!/usr/bin/env bash
# Setup for the deer-flow-fix-owner-isolation verifier.
#
# The owner-isolation checks run entirely in-process: the gateway's
# thread-runs router is driven over HTTP against the harness's in-memory run /
# run-event / thread-meta stores and the SQL run store on a temporary SQLite
# file. No PostgreSQL, no running server, no network. Dependencies are baked
# into the image, so this is normally a fast no-op; it exists to repopulate the
# venv on a cold sandbox start.
set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/deer-flow}"
BACKEND_DIR="$REPO_DIR/backend"

cd "$BACKEND_DIR"

# uv sync is idempotent; the image pre-warms /opt/venv via the lockfile, so
# this only does real work on a cold start.
# Offline-first: everything is already in the warm uv cache, so the --offline
# resolve succeeds without network; the logged fallback only runs if a cold
# sandbox lost the cache.
if [ ! -d "$BACKEND_DIR/.venv" ] && [ ! -d /opt/venv ]; then
    uv sync --frozen --offline --group dev \
        || { echo "[test-setup] offline sync miss; retrying online"; uv sync --frozen --group dev; }
fi

# verify.py runs under the backend project venv via verify.toml's
# `[pytest] command` (`/opt/venv/bin/python -m pytest`) and puts the backend
# on sys.path itself, so `app` and `deerflow` resolve. The verifier
# infrastructure itself runs under VERIFIER_PYTHON (/opt/tooling/venv), which
# carries the standalone verifier deps the project venv lacks, so do NOT repoint
# it at the project venv here.

# REPO_NAME is read by /tests/run_verify.py to compute REPO_DIR.
export REPO_NAME=deer-flow
export PYTHONPATH=.

echo "[test-setup] ready: $BACKEND_DIR (verifier drives the backend pytest suite via verify.toml)"
