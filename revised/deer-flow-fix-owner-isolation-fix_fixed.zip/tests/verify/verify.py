"""Behavioral coverage for the gateway thread-runs owner boundary.

Every assertion is driven THROUGH the pre-existing
``app.gateway.routers.thread_runs.router`` HTTP surface (prefix
``/api/threads``) over the harness's run stores: the in-memory ones, plus the
SQL run repository and SQL run-event store on a temporary SQLite file for the
token totals and the thread message history. Nothing
here imports private helpers or pins their shape: the ownership check, the
run sub-resource gate and the token-usage scoping can be decomposed and named
in any way, as long as the per-endpoint observable outcomes below hold.

The scaffolding (middleware that stamps the auth trio, the real in-memory
thread-meta store standing behind ``owner_check=True``, the seed helpers)
follows the repo's own test harness for this router.
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path
from unittest.mock import MagicMock
from uuid import UUID

import pytest

# ---------------------------------------------------------------------------
# Import bootstrap. This file lives outside ``backend/tests`` so the backend
# conftest does not apply; replicate just the two things it does that matter
# here: put ``app`` / ``deerflow`` on sys.path, and pre-mock the
# ``deerflow.subagents.executor`` module to break a production circular import
# that would otherwise trip when importing the router in isolation.
# ---------------------------------------------------------------------------
_BACKEND = Path("/repo/deer-flow/backend")
if str(_BACKEND) not in sys.path:
    sys.path.insert(0, str(_BACKEND))

if "deerflow.subagents.executor" not in sys.modules:
    _executor_mock = MagicMock()
    _executor_mock.SubagentExecutor = MagicMock
    _executor_mock.SubagentResult = MagicMock
    _executor_mock.SubagentStatus = MagicMock
    _executor_mock.MAX_CONCURRENT_SUBAGENTS = 3
    _executor_mock.get_background_task_result = MagicMock()
    sys.modules["deerflow.subagents.executor"] = _executor_mock

import httpx  # noqa: E402
from fastapi import FastAPI, Request, Response  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402
from langgraph.store.memory import InMemoryStore  # noqa: E402
from starlette.middleware.base import BaseHTTPMiddleware  # noqa: E402

from app.gateway.auth.models import User  # noqa: E402
from app.gateway.auth_disabled import (  # noqa: E402
    AUTH_SOURCE_INTERNAL,
    AUTH_SOURCE_SESSION,
)
from app.gateway.authz import AuthContext, Permissions  # noqa: E402
from app.gateway.internal_auth import (  # noqa: E402
    INTERNAL_OWNER_USER_ID_HEADER_NAME,
    get_internal_user,
)
from app.gateway.routers import thread_runs  # noqa: E402
from deerflow.persistence.feedback import FeedbackRepository  # noqa: E402
from deerflow.persistence.run import RunRepository  # noqa: E402
from deerflow.persistence.thread_meta.memory import MemoryThreadMetaStore  # noqa: E402
from deerflow.runtime.events.store.db import DbRunEventStore  # noqa: E402
from deerflow.runtime.events.store.memory import MemoryRunEventStore  # noqa: E402
from deerflow.runtime.runs.manager import RunManager  # noqa: E402
from deerflow.runtime.runs.store.memory import MemoryRunStore  # noqa: E402
from deerflow.workspace_changes.types import (  # noqa: E402
    WORKSPACE_CHANGES_EVENT_CATEGORY,
    WORKSPACE_CHANGES_EVENT_TYPE,
    WORKSPACE_CHANGES_METADATA_KEY,
)

# --- stable fixture constants ------------------------------------------------
THREAD_ID = "thread-scope"
BROWSER_USER_ID = UUID("00000000-0000-0000-0000-00000000000a")

# Raw trusted-owner values as a channel worker sends them in the owner header.
# Each one contains characters that make_safe_user_id rewrites, so the
# normalized identity never equals the raw value a run row carries. Two
# distinct (acting owner, other owner) pairs keep the checks independent of
# any one spelling.
OWNER_PAIRS = [
    pytest.param("feishu:owner-777", "feishu:owner-999", id="feishu"),
    pytest.param("dingtalk:staff#42", "wecom:corp@7", id="dingtalk"),
]

# The two kinds of thread that have no owner on record: no meta row at all,
# and a meta row whose owner is empty.
SHARED_KINDS = ["missing-meta", "null-owner"]

_STUB_PERMISSIONS = [
    Permissions.THREADS_READ,
    Permissions.RUNS_READ,
    Permissions.RUNS_CANCEL,
]


class _ScopeAuthMiddleware(BaseHTTPMiddleware):
    """Stamp the same request.state trio the production AuthMiddleware stamps."""

    def __init__(self, app, *, user, auth_source: str) -> None:
        super().__init__(app)
        self._user = user
        self._auth_source = auth_source

    async def dispatch(self, request: Request, call_next) -> Response:
        request.state.user = self._user
        request.state.auth_source = self._auth_source
        request.state.auth = AuthContext(
            user=self._user, permissions=list(_STUB_PERMISSIONS)
        )
        return await call_next(request)


def _browser_user() -> User:
    return User(
        id=BROWSER_USER_ID,
        email="scope-test@example.com",
        password_hash="x",
        system_role="user",
    )


def _internal_user(owner_raw: str | None):
    # Mirrors AuthMiddleware + get_internal_user: a synthetic internal user
    # carrying the safe-spelled owner id ("default" without an owner header).
    return get_internal_user(owner_user_id=owner_raw)


def _seed_run(
    store: MemoryRunStore, run_id: str, *, user_id: str | None, status: str = "success"
) -> None:
    asyncio.run(store.put(run_id, thread_id=THREAD_ID, user_id=user_id, status=status))


def _set_run_tokens(store: MemoryRunStore, run_id: str, total: int) -> None:
    # Token totals live on the stored run snapshot; the in-memory aggregate
    # reads token_usage_by_model (with a total_tokens fallback).
    store._runs[run_id]["token_usage_by_model"] = {"model-x": {"total_tokens": total}}
    store._runs[run_id]["total_tokens"] = total


def _seed_message(
    event_store: MemoryRunEventStore, run_id: str, message_id: str
) -> None:
    asyncio.run(
        event_store.put(
            thread_id=THREAD_ID,
            run_id=run_id,
            event_type="llm.ai.response",
            category="message",
            content={
                "type": "ai",
                "id": message_id,
                "content": message_id,
                "additional_kwargs": {},
            },
            metadata={},
        )
    )


def _seed_workspace_change(
    event_store: MemoryRunEventStore, run_id: str, file_path: str
) -> None:
    # Same event shape the workspace-change recorder writes for a run.
    payload = {
        "version": 1,
        "summary": {
            "created": 1,
            "modified": 0,
            "deleted": 0,
            "symlink_created": 0,
            "additions": 1,
            "deletions": 0,
            "truncated": False,
        },
        "files": [{"path": file_path, "status": "created", "diff": "+line"}],
        "limits": {},
    }
    asyncio.run(
        event_store.put(
            thread_id=THREAD_ID,
            run_id=run_id,
            event_type=WORKSPACE_CHANGES_EVENT_TYPE,
            category=WORKSPACE_CHANGES_EVENT_CATEGORY,
            content="1 file changed +1 -0",
            metadata={WORKSPACE_CHANGES_METADATA_KEY: payload},
        )
    )


def _missing_meta_store() -> MemoryThreadMetaStore:
    """A real meta store with NO row for THREAD_ID (legacy / shared thread)."""
    return MemoryThreadMetaStore(InMemoryStore())


def _null_owner_meta_store() -> MemoryThreadMetaStore:
    """A real meta store whose THREAD_ID row exists with a NULL owner."""
    store = MemoryThreadMetaStore(InMemoryStore())
    asyncio.run(store.create(THREAD_ID, assistant_id=None, user_id=None))
    return store


def _shared_meta_store(kind: str) -> MemoryThreadMetaStore:
    if kind == "missing-meta":
        return _missing_meta_store()
    return _null_owner_meta_store()


def _established_meta_store(owner: str) -> MemoryThreadMetaStore:
    """A real meta store whose THREAD_ID row has a concrete owner."""
    store = MemoryThreadMetaStore(InMemoryStore())
    asyncio.run(store.create(THREAD_ID, assistant_id=None, user_id=owner))
    return store


def _build_app(
    *,
    user,
    auth_source: str,
    run_store,
    thread_store: MemoryThreadMetaStore,
    event_store=None,
    feedback_repo=None,
) -> FastAPI:
    app = FastAPI()
    app.add_middleware(_ScopeAuthMiddleware, user=user, auth_source=auth_source)
    app.state.thread_store = thread_store
    app.state.run_store = run_store
    app.state.run_manager = RunManager(store=run_store)
    if event_store is not None:
        app.state.run_event_store = event_store
    if feedback_repo is not None:
        app.state.feedback_repo = feedback_repo
    app.include_router(thread_runs.router)
    return app


def _make_app(**kwargs) -> TestClient:
    return TestClient(_build_app(**kwargs))


def _owner_header(owner_raw: str) -> dict[str, str]:
    return {INTERNAL_OWNER_USER_ID_HEADER_NAME: owner_raw}


def _hides_run_content(resp, *markers: str) -> bool:
    """A per-run listing for someone else's run is refused or holds none of it.

    A 404 (the run is treated as not found) and a 200 whose body carries none
    of the run's seeded content are both closed answers.
    """
    if resp.status_code == 404:
        return True
    if resp.status_code != 200:
        return False
    return not any(marker in resp.text for marker in markers)


# ===========================================================================
# Shared threads: an internal caller sees only the acting owner's runs
# ===========================================================================
@pytest.mark.parametrize("kind", SHARED_KINDS)
@pytest.mark.parametrize(("owner", "other"), OWNER_PAIRS)
def test_shared_thread_isolates_internal_caller(kind: str, owner: str, other: str) -> None:
    run_store = MemoryRunStore()
    _seed_run(run_store, "run-other", user_id=other, status="success")
    _seed_run(run_store, "run-browser", user_id=str(BROWSER_USER_ID), status="success")
    client = _make_app(
        user=_internal_user(owner),
        auth_source=AUTH_SOURCE_INTERNAL,
        run_store=run_store,
        thread_store=_shared_meta_store(kind),
    )
    h = _owner_header(owner)
    with client:
        listed = client.get(f"/api/threads/{THREAD_ID}/runs", headers=h)
        page = client.get(f"/api/threads/{THREAD_ID}/runs/page", headers=h)
        single_other = client.get(f"/api/threads/{THREAD_ID}/runs/run-other", headers=h)
        single_browser = client.get(
            f"/api/threads/{THREAD_ID}/runs/run-browser", headers=h
        )

    assert listed.status_code == 200
    assert listed.json() == []
    assert page.status_code == 200
    assert page.json()["data"] == []
    assert single_other.status_code == 404
    assert single_browser.status_code == 404


@pytest.mark.parametrize("kind", SHARED_KINDS)
def test_ownerless_internal_caller_sees_no_owner_runs(kind: str) -> None:
    # An internal call that names no owner carries the synthetic "default"
    # identity; a run saved for a real owner stays out of every read.
    owner = "feishu:owner-777"
    run_store = MemoryRunStore()
    _seed_run(run_store, "run-owner", user_id=owner, status="success")
    _set_run_tokens(run_store, "run-owner", 111)
    event_store = MemoryRunEventStore()
    _seed_message(event_store, "run-owner", "msg-owner-only")
    _seed_workspace_change(event_store, "run-owner", "report-owner-only.md")
    client = _make_app(
        user=_internal_user(None),
        auth_source=AUTH_SOURCE_INTERNAL,
        run_store=run_store,
        thread_store=_shared_meta_store(kind),
        event_store=event_store,
    )
    base = f"/api/threads/{THREAD_ID}/runs/run-owner"
    markers = ("msg-owner-only", "report-owner-only.md")
    with client:
        listed = client.get(f"/api/threads/{THREAD_ID}/runs")
        page = client.get(f"/api/threads/{THREAD_ID}/runs/page")
        single = client.get(base)
        usage = client.get(f"/api/threads/{THREAD_ID}/token-usage")
        assert _hides_run_content(client.get(base + "/messages"), *markers)
        assert _hides_run_content(client.get(base + "/events"), *markers)
        assert _hides_run_content(client.get(base + "/workspace-changes"), *markers)
        assert client.get(base + "/join").status_code == 404
        assert client.get(base + "/stream").status_code == 404
        assert client.post(base + "/stream?action=interrupt").status_code == 404
        if kind == "null-owner":
            assert client.post(base + "/cancel?action=interrupt").status_code == 404
            assert client.get(base + "/artifacts/archive").status_code == 404
            assert client.post(base + "/artifacts/archive").status_code == 404

    assert listed.status_code == 200
    assert listed.json() == []
    assert page.status_code == 200
    assert page.json()["data"] == []
    assert single.status_code == 404
    assert usage.status_code == 200
    assert usage.json()["total_tokens"] == 0
    assert usage.json()["total_runs"] == 0


@pytest.mark.parametrize("kind", SHARED_KINDS)
def test_ownerless_internal_caller_keeps_default_runs(kind: str) -> None:
    # Runs saved under the old shared "default" identity stay readable to an
    # internal call that names no owner, next to an owner's run it must not see.
    owner = "wecom:corp@7"
    run_store = MemoryRunStore()
    _seed_run(run_store, "run-owner", user_id=owner, status="success")
    _seed_run(run_store, "run-legacy-default", user_id="default", status="success")
    _set_run_tokens(run_store, "run-owner", 111)
    _set_run_tokens(run_store, "run-legacy-default", 55)
    event_store = MemoryRunEventStore()
    _seed_message(event_store, "run-legacy-default", "msg-legacy-default")
    _seed_workspace_change(event_store, "run-legacy-default", "notes-legacy.md")
    client = _make_app(
        user=_internal_user(None),
        auth_source=AUTH_SOURCE_INTERNAL,
        run_store=run_store,
        thread_store=_shared_meta_store(kind),
        event_store=event_store,
    )
    base = f"/api/threads/{THREAD_ID}/runs/run-legacy-default"
    with client:
        listed = client.get(f"/api/threads/{THREAD_ID}/runs")
        page = client.get(f"/api/threads/{THREAD_ID}/runs/page")
        single = client.get(base)
        messages = client.get(base + "/messages")
        events = client.get(base + "/events")
        workspace = client.get(base + "/workspace-changes")
        join = client.get(base + "/join")
        stream_get = client.get(base + "/stream")
        stream_post = client.post(base + "/stream?action=interrupt")
        manifest = download = cancel = None
        if kind == "null-owner":
            manifest = client.get(base + "/artifacts/archive")
            download = client.post(base + "/artifacts/archive")
            cancel = client.post(base + "/cancel?action=interrupt")
        usage = client.get(f"/api/threads/{THREAD_ID}/token-usage")

    assert listed.status_code == 200
    assert [row["run_id"] for row in listed.json()] == ["run-legacy-default"]
    assert page.status_code == 200
    assert [row["run_id"] for row in page.json()["data"]] == ["run-legacy-default"]
    assert single.status_code == 200
    assert single.json()["run_id"] == "run-legacy-default"
    assert messages.status_code == 200
    assert [row["content"]["id"] for row in messages.json()["data"]] == ["msg-legacy-default"]
    assert events.status_code == 200
    assert "msg-legacy-default" in events.text
    assert workspace.status_code == 200
    assert [f["path"] for f in workspace.json()["files"]] == ["notes-legacy.md"]
    # No stream bridge is wired on this app, so the live-stream endpoints'
    # own logic answers (503), not the not-found answer.
    assert join.status_code != 404
    assert stream_get.status_code != 404
    assert stream_post.status_code != 404
    if kind == "null-owner":
        # No recorded artifact delivery and a finished run: each answers 409.
        assert manifest.status_code == 409
        assert download.status_code == 409
        assert cancel.status_code == 409
    assert usage.status_code == 200
    assert usage.json()["total_tokens"] == 55
    assert usage.json()["total_runs"] == 1


# ===========================================================================
# Shared threads: the acting owner's own runs stay visible
# ===========================================================================
@pytest.mark.parametrize("kind", SHARED_KINDS)
@pytest.mark.parametrize(("owner", "other"), OWNER_PAIRS)
def test_acting_owner_own_runs_stay_visible(kind: str, owner: str, other: str) -> None:
    run_store = MemoryRunStore()
    _seed_run(run_store, "run-own", user_id=owner, status="success")
    client = _make_app(
        user=_internal_user(owner),
        auth_source=AUTH_SOURCE_INTERNAL,
        run_store=run_store,
        thread_store=_shared_meta_store(kind),
    )
    h = _owner_header(owner)
    with client:
        listed = client.get(f"/api/threads/{THREAD_ID}/runs", headers=h)
        page = client.get(f"/api/threads/{THREAD_ID}/runs/page", headers=h)
        single = client.get(f"/api/threads/{THREAD_ID}/runs/run-own", headers=h)

    assert listed.status_code == 200
    assert {row["run_id"] for row in listed.json()} == {"run-own"}
    assert page.status_code == 200
    assert {row["run_id"] for row in page.json()["data"]} == {"run-own"}
    assert single.status_code == 200
    assert single.json()["run_id"] == "run-own"


def _seed_interleaved_runs(store: MemoryRunStore, owner: str, other: str) -> None:
    # Three runs per owner, alternating in time, so any two neighboring runs
    # on the thread belong to different owners.
    for i in range(1, 4):
        for who, user_id in (("own", owner), ("other", other)):
            minute = 2 * i - (1 if who == "own" else 0)
            asyncio.run(
                store.put(
                    f"run-{who}-{i}",
                    thread_id=THREAD_ID,
                    user_id=user_id,
                    status="success",
                    created_at=f"2026-01-01T00:{minute:02d}:00+00:00",
                )
            )


@pytest.mark.parametrize("kind", SHARED_KINDS)
@pytest.mark.parametrize(("owner", "other"), OWNER_PAIRS)
def test_shared_thread_run_pages_hold_only_own_runs(kind: str, owner: str, other: str) -> None:
    # Newest first: run-other-3, run-own-3, run-other-2, run-own-2, ...
    run_store = MemoryRunStore()
    _seed_interleaved_runs(run_store, owner, other)
    client = _make_app(
        user=_internal_user(owner),
        auth_source=AUTH_SOURCE_INTERNAL,
        run_store=run_store,
        thread_store=_shared_meta_store(kind),
    )
    h = _owner_header(owner)
    with client:
        listed = client.get(f"/api/threads/{THREAD_ID}/runs", headers=h)
        first = client.get(f"/api/threads/{THREAD_ID}/runs/page?limit=2", headers=h)
        assert first.status_code == 200
        cursor = first.json()
        second = client.get(
            f"/api/threads/{THREAD_ID}/runs/page",
            params={
                "limit": 2,
                "before_created_at": cursor["next_before_created_at"],
                "before_run_id": cursor["next_before_run_id"],
            },
            headers=h,
        )

    assert listed.status_code == 200
    assert [row["run_id"] for row in listed.json()] == ["run-own-3", "run-own-2", "run-own-1"]
    assert [row["run_id"] for row in cursor["data"]] == ["run-own-3", "run-own-2"]
    assert cursor["has_more"] is True
    assert cursor["next_before_run_id"] == "run-own-2"
    assert second.status_code == 200
    assert [row["run_id"] for row in second.json()["data"]] == ["run-own-1"]
    assert second.json()["has_more"] is False


# ===========================================================================
# Shared threads: run sub-resources follow the run's owner
# ===========================================================================
def _seed_owner_run_with_content(owner: str, tag: str):
    run_store = MemoryRunStore()
    _seed_run(run_store, "run-owner", user_id=owner, status="success")
    event_store = MemoryRunEventStore()
    _seed_message(event_store, "run-owner", f"msg-{tag}")
    _seed_workspace_change(event_store, "run-owner", f"report-{tag}.md")
    return run_store, event_store


@pytest.mark.parametrize("kind", SHARED_KINDS)
@pytest.mark.parametrize(("owner", "other"), OWNER_PAIRS)
def test_run_subresources_hidden_from_other_owner(kind: str, owner: str, other: str) -> None:
    tag = owner.split(":")[0]
    run_store, event_store = _seed_owner_run_with_content(owner, tag)
    base = f"/api/threads/{THREAD_ID}/runs/run-owner"
    stranger = _make_app(
        user=_internal_user(other),
        auth_source=AUTH_SOURCE_INTERNAL,
        run_store=run_store,
        thread_store=_shared_meta_store(kind),
        event_store=event_store,
    )
    markers = (f"msg-{tag}", f"report-{tag}.md")
    with stranger:
        h = _owner_header(other)
        # Per-run listings: refused, or answered with none of the run's data.
        assert _hides_run_content(stranger.get(base + "/messages", headers=h), *markers)
        assert _hides_run_content(stranger.get(base + "/events", headers=h), *markers)
        assert _hides_run_content(
            stranger.get(base + "/workspace-changes", headers=h), *markers
        )
        # Live-run actions answer as for a run that is not there. A GET
        # /stream carrying ?action is rejected 405 by a separate method guard,
        # so the stream is exercised through the action-less GET and the POST.
        assert stranger.get(base + "/join", headers=h).status_code == 404
        assert stranger.get(base + "/stream", headers=h).status_code == 404
        assert (
            stranger.post(base + "/stream?action=interrupt", headers=h).status_code
            == 404
        )
        if kind == "null-owner":
            # Cancel and the artifact archive also require the thread to have
            # a meta row, so a thread with no row answers 404 before the run
            # is looked at. They are exercised on the empty-owner row.
            assert (
                stranger.post(base + "/cancel?action=interrupt", headers=h).status_code
                == 404
            )
            assert stranger.get(base + "/artifacts/archive", headers=h).status_code == 404
            assert stranger.post(base + "/artifacts/archive", headers=h).status_code == 404


@pytest.mark.parametrize("kind", SHARED_KINDS)
@pytest.mark.parametrize(("owner", "other"), OWNER_PAIRS)
def test_run_subresources_visible_to_acting_owner(kind: str, owner: str, other: str) -> None:
    tag = owner.split(":")[0]
    run_store, event_store = _seed_owner_run_with_content(owner, tag)
    base = f"/api/threads/{THREAD_ID}/runs/run-owner"
    client = _make_app(
        user=_internal_user(owner),
        auth_source=AUTH_SOURCE_INTERNAL,
        run_store=run_store,
        thread_store=_shared_meta_store(kind),
        event_store=event_store,
    )
    with client:
        h = _owner_header(owner)
        messages = client.get(base + "/messages", headers=h)
        events = client.get(base + "/events", headers=h)
        workspace = client.get(base + "/workspace-changes", headers=h)
        # The live-stream routes reach the endpoint's own logic for the owner:
        # with no stream bridge wired on this app, that logic answers 503
        # (bridge unavailable), never the not-found answer.
        join = client.get(base + "/join", headers=h)
        stream_get = client.get(base + "/stream", headers=h)
        stream_post = client.post(base + "/stream?action=interrupt", headers=h)
        manifest = download = cancel = None
        if kind == "null-owner":
            manifest = client.get(base + "/artifacts/archive", headers=h)
            download = client.post(base + "/artifacts/archive", headers=h)
            cancel = client.post(base + "/cancel?action=interrupt", headers=h)

    assert messages.status_code == 200
    assert [row["content"]["id"] for row in messages.json()["data"]] == [f"msg-{tag}"]
    assert events.status_code == 200
    assert f"msg-{tag}" in events.text
    assert f"report-{tag}.md" in events.text
    assert workspace.status_code == 200
    assert workspace.json()["available"] is True
    assert [f["path"] for f in workspace.json()["files"]] == [f"report-{tag}.md"]
    assert join.status_code != 404
    assert stream_get.status_code != 404
    assert stream_post.status_code != 404
    if kind == "null-owner":
        # A run with no recorded artifact delivery answers 409 on the archive
        # manifest, and a finished run answers 409 on cancel: the endpoint's
        # own logic decides, not the not-found answer.
        assert manifest.status_code == 409
        assert download.status_code == 409
        assert cancel.status_code == 409


# ===========================================================================
# Shared threads: token-usage totals count only the caller's own runs
# ===========================================================================
@pytest.mark.parametrize("kind", SHARED_KINDS)
@pytest.mark.parametrize(("owner", "other"), OWNER_PAIRS)
def test_token_usage_isolated_for_internal_caller(kind: str, owner: str, other: str) -> None:
    run_store = MemoryRunStore()
    _seed_run(run_store, "run-owner", user_id=owner, status="success")
    _seed_run(run_store, "run-other", user_id=other, status="success")
    _set_run_tokens(run_store, "run-owner", 111)
    _set_run_tokens(run_store, "run-other", 999)
    client = _make_app(
        user=_internal_user(owner),
        auth_source=AUTH_SOURCE_INTERNAL,
        run_store=run_store,
        thread_store=_shared_meta_store(kind),
    )
    with client:
        resp = client.get(
            f"/api/threads/{THREAD_ID}/token-usage", headers=_owner_header(owner)
        )
        with_active = client.get(
            f"/api/threads/{THREAD_ID}/token-usage?include_active=true",
            headers=_owner_header(owner),
        )

    for answer in (resp, with_active):
        assert answer.status_code == 200
        body = answer.json()
        assert body["total_tokens"] == 111
        assert body["total_runs"] == 1


@pytest.mark.parametrize("kind", SHARED_KINDS)
def test_token_usage_isolated_for_browser_session(kind: str) -> None:
    run_store = MemoryRunStore()
    _seed_run(run_store, "run-owner", user_id="feishu:owner-777", status="success")
    _seed_run(
        run_store, "run-browser", user_id=str(BROWSER_USER_ID), status="success"
    )
    _set_run_tokens(run_store, "run-owner", 111)
    _set_run_tokens(run_store, "run-browser", 222)
    client = _make_app(
        user=_browser_user(),
        auth_source=AUTH_SOURCE_SESSION,
        run_store=run_store,
        thread_store=_shared_meta_store(kind),
    )
    with client:
        resp = client.get(f"/api/threads/{THREAD_ID}/token-usage")

    assert resp.status_code == 200
    body = resp.json()
    assert body["total_tokens"] == 222
    assert body["total_runs"] == 1


# ---------------------------------------------------------------------------
# SQL run store: the same token-usage totals through RunRepository on a
# temporary SQLite file. Seeding and the HTTP calls share one event loop (the
# SQLAlchemy engine's pooled connections belong to the loop that opened them).
# ---------------------------------------------------------------------------
async def _sql_token_usage(
    tmp_path: Path,
    *,
    caller_owner: str,
    thread_owner: str | None,
    runs: list[tuple[str, str, int]],
) -> dict:
    from deerflow.persistence.engine import (
        close_engine,
        get_session_factory,
        init_engine,
    )

    url = f"sqlite+aiosqlite:///{tmp_path / 'runs.db'}"
    await init_engine("sqlite", url=url, sqlite_dir=str(tmp_path))
    try:
        repo = RunRepository(get_session_factory())
        for run_id, user_id, total in runs:
            await repo.put(run_id, thread_id=THREAD_ID, user_id=user_id, status="running")
            await repo.update_run_completion(
                run_id, status="success", total_tokens=total, lead_agent_tokens=total
            )
        thread_store = MemoryThreadMetaStore(InMemoryStore())
        if thread_owner is not None:
            await thread_store.create(THREAD_ID, assistant_id=None, user_id=thread_owner)
        app = _build_app(
            user=_internal_user(caller_owner),
            auth_source=AUTH_SOURCE_INTERNAL,
            run_store=repo,
            thread_store=thread_store,
        )
        transport = httpx.ASGITransport(app=app)
        async with httpx.AsyncClient(transport=transport, base_url="http://testserver") as client:
            resp = await client.get(
                f"/api/threads/{THREAD_ID}/token-usage",
                headers=_owner_header(caller_owner),
            )
        assert resp.status_code == 200
        return resp.json()
    finally:
        await close_engine()


@pytest.mark.parametrize(("owner", "other"), OWNER_PAIRS)
def test_token_usage_isolated_with_sql_run_store(
    tmp_path: Path, owner: str, other: str
) -> None:
    body = asyncio.run(
        _sql_token_usage(
            tmp_path,
            caller_owner=owner,
            thread_owner=None,
            runs=[("run-owner", owner, 111), ("run-other", other, 999)],
        )
    )
    assert body["total_tokens"] == 111
    assert body["total_runs"] == 1


def test_sql_token_usage_folds_on_owned_thread(tmp_path: Path) -> None:
    owner = "feishu:owner-777"
    body = asyncio.run(
        _sql_token_usage(
            tmp_path,
            caller_owner=owner,
            thread_owner=owner,
            runs=[("run-owner", owner, 111), ("run-legacy-default", "default", 55)],
        )
    )
    assert body["total_tokens"] == 166
    assert body["total_runs"] == 2


# ---------------------------------------------------------------------------
# Database-backed run events: the thread-wide message history (the full list
# and the backward page) on the SQL run store and the SQL event store, whose
# rows carry the owner each event was saved for.
# ---------------------------------------------------------------------------
async def _db_thread_history(
    tmp_path: Path,
    *,
    owner: str,
    other: str,
    caller_owner: str | None,
    thread_owner_kind: str,
    thread_owner: str | None = None,
) -> dict:
    from deerflow.persistence.engine import (
        close_engine,
        get_session_factory,
        init_engine,
    )

    url = f"sqlite+aiosqlite:///{tmp_path / 'history.db'}"
    await init_engine("sqlite", url=url, sqlite_dir=str(tmp_path))
    try:
        sf = get_session_factory()
        repo = RunRepository(sf)
        event_store = DbRunEventStore(sf)
        events = []
        # Alternating owners in time: own-1, other-1, own-2, other-2, own-3, other-3.
        for i in range(1, 4):
            for who, user_id in (("own", owner), ("other", other)):
                run_id = f"run-{who}-{i}"
                await repo.put(run_id, thread_id=THREAD_ID, user_id=user_id, status="success")
                events.append(
                    {
                        "thread_id": THREAD_ID,
                        "run_id": run_id,
                        "user_id": user_id,
                        "event_type": "llm.ai.response",
                        "category": "message",
                        "content": {
                            "type": "ai",
                            "id": f"msg-{who}-{i}",
                            "content": f"answer {who} {i}",
                            "additional_kwargs": {},
                        },
                        "metadata": {},
                    }
                )
        await event_store.put_batch(events)

        thread_store = MemoryThreadMetaStore(InMemoryStore())
        if thread_owner_kind == "null-owner":
            await thread_store.create(THREAD_ID, assistant_id=None, user_id=None)
        elif thread_owner_kind == "established":
            await thread_store.create(THREAD_ID, assistant_id=None, user_id=thread_owner)
        app = _build_app(
            user=_internal_user(caller_owner),
            auth_source=AUTH_SOURCE_INTERNAL,
            run_store=repo,
            thread_store=thread_store,
            event_store=event_store,
            feedback_repo=FeedbackRepository(sf),
        )
        h = _owner_header(caller_owner) if caller_owner else {}
        out: dict = {}
        transport = httpx.ASGITransport(app=app)
        async with httpx.AsyncClient(transport=transport, base_url="http://testserver") as client:
            path = f"/api/threads/{THREAD_ID}/messages"
            out["full"] = await client.get(path, headers=h)
            out["last_two"] = await client.get(path, params={"limit": 2}, headers=h)
            first = await client.get(path + "/page", params={"limit": 2}, headers=h)
            out["page1"] = first
            if first.status_code == 200 and first.json().get("next_before_seq"):
                out["page2"] = await client.get(
                    path + "/page",
                    params={"limit": 2, "before_seq": first.json()["next_before_seq"]},
                    headers=h,
                )
        return out
    finally:
        await close_engine()


def _message_ids(rows: list[dict]) -> list[str]:
    return [row["content"]["id"] for row in rows]


@pytest.mark.parametrize("kind", SHARED_KINDS)
@pytest.mark.parametrize(("owner", "other"), OWNER_PAIRS)
def test_db_thread_history_isolates_internal_caller(
    tmp_path: Path, kind: str, owner: str, other: str
) -> None:
    out = asyncio.run(
        _db_thread_history(
            tmp_path, owner=owner, other=other, caller_owner=owner, thread_owner_kind=kind
        )
    )
    for name in ("full", "last_two", "page1"):
        assert out[name].status_code == 200, name
        assert "answer other" not in out[name].text, name
    assert _message_ids(out["full"].json()) == ["msg-own-1", "msg-own-2", "msg-own-3"]
    # A limited read is filled from the caller's own messages, not shortened
    # by someone else's rows that sit between them.
    assert _message_ids(out["last_two"].json()) == ["msg-own-2", "msg-own-3"]
    page1 = out["page1"].json()
    assert _message_ids(page1["data"]) == ["msg-own-2", "msg-own-3"]
    assert page1["has_more"] is True
    assert "page2" in out
    page2 = out["page2"].json()
    assert out["page2"].status_code == 200
    assert _message_ids(page2["data"]) == ["msg-own-1"]
    assert page2["has_more"] is False
    assert "answer other" not in out["page2"].text


@pytest.mark.parametrize("kind", SHARED_KINDS)
def test_db_thread_history_hidden_without_owner_header(tmp_path: Path, kind: str) -> None:
    out = asyncio.run(
        _db_thread_history(
            tmp_path,
            owner="feishu:owner-777",
            other="dingtalk:staff#42",
            caller_owner=None,
            thread_owner_kind=kind,
        )
    )
    assert out["full"].status_code == 200
    assert out["full"].json() == []
    assert out["page1"].status_code == 200
    assert out["page1"].json()["data"] == []
    assert out["page1"].json()["has_more"] is False


@pytest.mark.parametrize(
    ("thread_owner", "caller_owner"),
    [
        pytest.param("feishu:owner-777", "feishu:owner-777", id="owner-header"),
        pytest.param("default", None, id="no-owner-header"),
    ],
)
def test_db_thread_history_unfiltered_on_owned_thread(
    tmp_path: Path, thread_owner: str, caller_owner: str | None
) -> None:
    out = asyncio.run(
        _db_thread_history(
            tmp_path,
            owner="feishu:owner-777",
            other="dingtalk:staff#42",
            caller_owner=caller_owner,
            thread_owner_kind="established",
            thread_owner=thread_owner,
        )
    )
    every = ["msg-own-1", "msg-other-1", "msg-own-2", "msg-other-2", "msg-own-3", "msg-other-3"]
    assert out["full"].status_code == 200
    assert _message_ids(out["full"].json()) == every
    assert _message_ids(out["last_two"].json()) == every[-2:]
    page1 = out["page1"].json()
    assert _message_ids(page1["data"]) == every[-2:]
    assert page1["has_more"] is True
    assert _message_ids(out["page2"].json()["data"]) == every[-4:-2]


# ===========================================================================
# Threads with an owner on record keep today's reads
# ===========================================================================
@pytest.mark.parametrize(
    ("thread_owner", "caller_owner", "foreign_run"),
    [
        # The owner's channel worker on the owner's thread: an older run saved
        # under the legacy "default" stamp is still part of the thread.
        pytest.param("feishu:owner-777", "feishu:owner-777", "run-legacy-default", id="owner-header"),
        # An internal call with no owner header on a thread recorded as
        # "default": a run saved under a real owner's stamp is still listed.
        pytest.param("default", None, "run-owner", id="no-owner-header"),
    ],
)
def test_established_ownership_reads_unfiltered(
    thread_owner: str, caller_owner: str | None, foreign_run: str
) -> None:
    thread_store = _established_meta_store(thread_owner)
    run_store = MemoryRunStore()
    _seed_run(run_store, "run-owner", user_id="feishu:owner-777", status="success")
    _seed_run(run_store, "run-legacy-default", user_id="default", status="success")
    _set_run_tokens(run_store, "run-owner", 111)
    _set_run_tokens(run_store, "run-legacy-default", 55)
    event_store = MemoryRunEventStore()
    _seed_message(event_store, foreign_run, "msg-foreign-stamp")
    client = _make_app(
        user=_internal_user(caller_owner),
        auth_source=AUTH_SOURCE_INTERNAL,
        run_store=run_store,
        thread_store=thread_store,
        event_store=event_store,
    )
    h = _owner_header(caller_owner) if caller_owner else {}
    with client:
        listed = client.get(f"/api/threads/{THREAD_ID}/runs", headers=h)
        page = client.get(f"/api/threads/{THREAD_ID}/runs/page", headers=h)
        usage = client.get(f"/api/threads/{THREAD_ID}/token-usage", headers=h)
        single = client.get(f"/api/threads/{THREAD_ID}/runs/{foreign_run}", headers=h)
        messages = client.get(
            f"/api/threads/{THREAD_ID}/runs/{foreign_run}/messages", headers=h
        )

    assert listed.status_code == 200
    assert {row["run_id"] for row in listed.json()} == {
        "run-owner",
        "run-legacy-default",
    }
    assert page.status_code == 200
    assert {row["run_id"] for row in page.json()["data"]} == {
        "run-owner",
        "run-legacy-default",
    }
    assert usage.status_code == 200
    body = usage.json()
    assert body["total_tokens"] == 166
    assert body["total_runs"] == 2
    assert single.status_code == 200
    assert single.json()["run_id"] == foreign_run
    assert messages.status_code == 200
    assert [row["content"]["id"] for row in messages.json()["data"]] == ["msg-foreign-stamp"]


# ===========================================================================
# Browser / API sessions keep their per-user filter on the run list
# ===========================================================================
@pytest.mark.parametrize("kind", SHARED_KINDS)
def test_browser_sessions_unchanged(kind: str) -> None:
    run_store = MemoryRunStore()
    _seed_run(
        run_store, "run-browser", user_id=str(BROWSER_USER_ID), status="success"
    )
    _seed_run(run_store, "run-owner", user_id="feishu:owner-777", status="success")
    client = _make_app(
        user=_browser_user(),
        auth_source=AUTH_SOURCE_SESSION,
        run_store=run_store,
        thread_store=_shared_meta_store(kind),
    )
    with client:
        listed = client.get(f"/api/threads/{THREAD_ID}/runs")
        cross = client.get(f"/api/threads/{THREAD_ID}/runs/run-owner")

    assert listed.status_code == 200
    assert [row["run_id"] for row in listed.json()] == ["run-browser"]
    assert cross.status_code == 404


if __name__ == "__main__":  # pragma: no cover
    sys.exit(pytest.main([__file__, "-v"]))
