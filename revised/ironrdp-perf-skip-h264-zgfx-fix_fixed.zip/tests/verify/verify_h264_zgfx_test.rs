//! Integration test for the EGFX server's ZGFX output path, exercised only
//! through the crate's public API: `GraphicsPipelineServer`, its
//! `with_compression` constructor, the `send_*_frame` queueing methods,
//! `drain_output`, and the public `zgfx::Decompressor`. Every assertion is on
//! the wire bytes a client receives or on the time `drain_output` takes.
//!
//! What a client observes, and what these tests assert:
//!
//!   1. In both compressing modes (Auto and Always), an H.264 surface command
//!      (AVC420, AVC444, or AVC444v2) leaves the server with its first ZGFX
//!      segment NOT carrying the PACKET_COMPRESSED flag, for a payload that
//!      fits one segment and for one that spans several, and the client
//!      receives its payload intact.
//!
//!   2. ClearCodec, planar, uncompressed-bitmap and progressive surface
//!      commands in the same session still carry the flag, and in Always
//!      mode so does every other PDU that is not an H.264 surface command.
//!
//!   3. A client that decodes the whole drained stream with one
//!      `Decompressor` gets every tile back byte for byte, including the
//!      compressed tiles sent after one or more H.264 commands.
//!
//!   4. Draining a large H.264 frame of each codec takes well under half the
//!      time it takes to drain a ClearCodec tile carrying the same bytes, in
//!      both compressing modes.
//!
//!   5. In Never mode nothing is compressed and the stream decodes as before.
//!
//! The helpers (`TestHandler`, `encode_pdu`, `first_segment_is_compressed`)
//! are inlined because the crate's own testsuite lives in a sibling crate
//! whose dev-dependencies are not on this test target's path.

use std::time::{Duration, Instant};

use ironrdp_core::{Decode as _, Encode, ReadCursor, WriteCursor, encode_vec};
use ironrdp_dvc::DvcProcessor as _;
use ironrdp_egfx::pdu::{
    Avc420Region, CapabilitiesAdvertisePdu, CapabilitiesV10Flags, CapabilitySet, Codec1Type, Encoding, GfxPdu,
};
use ironrdp_egfx::server::{GraphicsPipelineHandler, GraphicsPipelineServer};
use ironrdp_graphics::zgfx::{CompressionMode, Decompressor};
use ironrdp_pdu::geometry::ExclusiveRectangle;

// ---------------------------------------------------------------------------
// Inlined test helpers.
// ---------------------------------------------------------------------------

/// Minimal handler; the server drives negotiation on its own, so the callbacks
/// need no behavior for these tests.
struct TestHandler;

impl GraphicsPipelineHandler for TestHandler {
    fn capabilities_advertise(&mut self, _pdu: &CapabilitiesAdvertisePdu) {}
    fn on_ready(&mut self, _negotiated: &CapabilitySet) {}
}

/// Encode a PDU to bytes for feeding the server's `process()` method.
fn encode_pdu<T: Encode>(pdu: &T) -> Vec<u8> {
    let mut buf = vec![0u8; pdu.size()];
    let mut cursor = WriteCursor::new(&mut buf);
    pdu.encode(&mut cursor).expect("encode failed");
    buf
}

/// Whether the first ZGFX segment of a wrapped DVC message carries the
/// PACKET_COMPRESSED flag (MS-RDPEGFX 2.2.5.1 to 2.2.5.3; PACKET_COMPRESSED
/// is 0x20 in the segment flags byte). A single-part descriptor is 0xE0 with
/// the flags byte at offset 1; a multipart descriptor is 0xE1 followed by a
/// u16 segment count and a u32 uncompressed size, putting the first segment's
/// flags byte at offset 1 + 2 + 4 + 4.
fn first_segment_is_compressed(wrapped: &[u8]) -> bool {
    match wrapped[0] {
        0xE0 => wrapped[1] & 0x20 != 0,
        0xE1 => wrapped[1 + 2 + 4 + 4] & 0x20 != 0,
        descriptor => panic!("unexpected ZGFX descriptor {descriptor:#x}"),
    }
}

/// Deterministic, highly repetitive bytes that stand in for a lossless tile;
/// they compress well so a compressing mode marks them compressed.
fn clearcodec_bytes() -> Vec<u8> {
    b"lossless tile bytes that repeat ".repeat(64)
}

/// Deterministic bytes standing in for an H.264 payload of a given length.
fn h264_bytes(len: usize) -> Vec<u8> {
    (0..=u8::MAX).cycle().skip(3).step_by(7).take(len).collect()
}

/// Deterministic bytes drawn from a 40-symbol alphabet in a pseudo-random
/// order (xorshift64 from a fixed seed). ZGFX finds few long matches in them,
/// so compressing them costs real time per byte.
fn noisy_bytes(len: usize, seed: u64) -> Vec<u8> {
    let mut state = seed;
    (0..len)
        .map(|_| {
            state ^= state << 13;
            state ^= state >> 7;
            state ^= state << 17;
            b'0' + u8::try_from(state % 40).expect("below 40")
        })
        .collect()
}

/// A server in `mode` that has finished the capability exchange, with one
/// 64x64 surface created. The handshake output is left in the queue.
fn ready_server(mode: CompressionMode) -> (GraphicsPipelineServer, u16) {
    let mut server = GraphicsPipelineServer::with_compression(Box::new(TestHandler), mode);

    let caps = GfxPdu::CapabilitiesAdvertise(CapabilitiesAdvertisePdu::from_typed(&[CapabilitySet::V10 {
        flags: CapabilitiesV10Flags::SMALL_CACHE,
    }]));
    server.process(0, &encode_pdu(&caps)).expect("process capabilities");

    let surface_id = server.create_surface(64, 64).expect("create surface");
    (server, surface_id)
}

/// Queue one H.264 frame of the requested codec on `surface_id`.
fn send_h264(
    server: &mut GraphicsPipelineServer,
    codec: Codec1Type,
    surface_id: u16,
    data: &[u8],
    regions: &[Avc420Region],
) -> Option<u32> {
    match codec {
        Codec1Type::Avc420 => server.send_avc420_frame(surface_id, data, regions, 42),
        Codec1Type::Avc444 => server.send_avc444_frame(surface_id, data, regions, None, None, 42),
        Codec1Type::Avc444v2 => {
            server.send_avc444v2_frame(surface_id, Encoding::LUMA, data, regions, None, None, 42)
        }
        other => panic!("not an H.264 codec: {other:?}"),
    }
}

const H264_CODECS: [Codec1Type; 3] = [Codec1Type::Avc420, Codec1Type::Avc444, Codec1Type::Avc444v2];

fn is_h264(codec: Codec1Type) -> bool {
    H264_CODECS.contains(&codec)
}

/// A decoded WireToSurface1 observation: whether its first ZGFX segment was
/// compressed, which codec it carried, and the decoded bitmap bytes.
struct Observed {
    compressed: bool,
    codec_id: Codec1Type,
    bitmap_data: Vec<u8>,
}

/// Drain `server` and decode every message with `decompressor`, returning the
/// WireToSurface1 PDUs in order. Panics if any message fails to decode.
fn decode_drained(server: &mut GraphicsPipelineServer, decompressor: &mut Decompressor) -> Vec<Observed> {
    server
        .drain_output()
        .iter()
        .filter_map(|message| {
            let wrapped = encode_vec(message.as_ref()).expect("encode DVC message");
            let compressed = first_segment_is_compressed(&wrapped);
            let mut decoded = Vec::new();
            decompressor
                .decompress(&wrapped, &mut decoded)
                .expect("receiver decompress");
            let pdu = GfxPdu::decode(&mut ReadCursor::new(&decoded)).expect("decode PDU");
            match pdu {
                GfxPdu::WireToSurface1(wire) => Some(Observed {
                    compressed,
                    codec_id: wire.codec_id,
                    bitmap_data: wire.bitmap_data,
                }),
                _ => None,
            }
        })
        .collect()
}

/// Run the ClearCodec / H.264 / ClearCodec sequence end to end under `mode`
/// with the given H.264 `codec` and payload length, decoding the whole
/// drained stream (handshake included) with a single client-side
/// `Decompressor`. Returns the WireToSurface1 PDUs observed, in order.
fn run_sequence(mode: CompressionMode, codec: Codec1Type, h264_len: usize) -> Vec<Observed> {
    let (mut server, surface_id) = ready_server(mode);
    let mut decompressor = Decompressor::new();

    // Decode the handshake output (caps confirm, surface creation) first, as
    // a client would.
    decode_drained(&mut server, &mut decompressor);

    let clearcodec_data = clearcodec_bytes();
    let h264_data = h264_bytes(h264_len);
    let destination = ExclusiveRectangle {
        left: 0,
        top: 0,
        right: 16,
        bottom: 16,
    };
    let regions = [Avc420Region::full_frame(64, 64, 22)];

    server
        .send_clearcodec_frame(surface_id, destination.clone(), clearcodec_data.clone(), 42)
        .expect("queue first ClearCodec frame");
    send_h264(&mut server, codec, surface_id, &h264_data, &regions).expect("queue H.264 frame");
    server
        .send_clearcodec_frame(surface_id, destination, clearcodec_data, 42)
        .expect("queue second ClearCodec frame");

    decode_drained(&mut server, &mut decompressor)
}

/// Assert the shape of the sequence: exactly ClearCodec, then the H.264 codec,
/// then ClearCodec, and both ClearCodec tiles round-trip to the original
/// bytes. Shared by the tests below.
fn assert_sequence_roundtrips(observed: &[Observed], codec: Codec1Type) {
    let codecs: Vec<Codec1Type> = observed.iter().map(|o| o.codec_id).collect();
    assert_eq!(
        codecs,
        [Codec1Type::ClearCodec, codec, Codec1Type::ClearCodec],
        "expected the ClearCodec / H.264 / ClearCodec order to survive the round trip"
    );

    let expected = clearcodec_bytes();
    assert_eq!(
        observed[2].bitmap_data, expected,
        "the ClearCodec tile sent after the H.264 command must decode to its original bytes"
    );
    assert_eq!(
        observed[0].bitmap_data, expected,
        "the ClearCodec tile sent before the H.264 command must decode to its original bytes"
    );
}

// ---------------------------------------------------------------------------
// H.264 goes out uncompressed in Always mode while ClearCodec is still
// compressed.
// ---------------------------------------------------------------------------

#[test]
fn h264_uncompressed_in_always() {
    let observed = run_sequence(CompressionMode::Always, Codec1Type::Avc420, 8_000);

    assert_eq!(
        observed.len(),
        3,
        "expected ClearCodec, H.264, ClearCodec (3 surface commands)"
    );

    for o in &observed {
        match o.codec_id {
            Codec1Type::ClearCodec => assert!(
                o.compressed,
                "ordinary ClearCodec tiles should still be compressed in Always mode"
            ),
            Codec1Type::Avc420 => assert!(
                !o.compressed,
                "the H.264 surface command should be placed on the wire uncompressed \
                 (ZGFX PACKET_COMPRESSED clear) in Always mode"
            ),
            other => panic!("unexpected codec {other:?}"),
        }
    }
}

// ---------------------------------------------------------------------------
// A compressed tile sent after an H.264 command decodes to its original bytes
// on a client that decodes the whole stream.
// ---------------------------------------------------------------------------

#[test]
fn tile_after_h264_decodes_intact() {
    // Always mode, single-part H.264: every PDU must decode under one
    // Decompressor and the trailing ClearCodec must round-trip.
    let observed = run_sequence(CompressionMode::Always, Codec1Type::Avc420, 8_000);
    assert_sequence_roundtrips(&observed, Codec1Type::Avc420);
}

// ---------------------------------------------------------------------------
// Holds for every H.264 codec, for payloads just under and just over the
// segment ceiling, and in both compressing modes. The H.264 payload itself
// reaches the client intact.
// ---------------------------------------------------------------------------

#[test]
fn h264_uncompressed_all_codecs_sizes_and_modes() {
    // A ZGFX segment holds at most 65,535 bytes, and an H.264 surface command
    // adds 39 (AVC420) or 43 (AVC444, AVC444v2) bytes of headers to its
    // payload. So 8,000 and 65,400 bytes fit one segment, and 65,600 and
    // 70,000 bytes go out as a multipart message. The payload repeats every
    // 256 bytes, so Auto mode would pick the compressed form if it were
    // offered.
    for mode in [CompressionMode::Always, CompressionMode::Auto] {
        for codec in H264_CODECS {
            for &h264_len in &[8_000usize, 65_400, 65_600, 70_000] {
                let observed = run_sequence(mode, codec, h264_len);

                let h264_obs = observed
                    .iter()
                    .find(|o| o.codec_id == codec)
                    .unwrap_or_else(|| panic!("no H.264 PDU observed for {codec:?} at len {h264_len} in {mode:?}"));
                assert!(
                    !h264_obs.compressed,
                    "the H.264 surface command ({codec:?}, {h264_len} bytes) should be sent \
                     uncompressed in {mode:?} mode"
                );
                assert!(
                    h264_obs.bitmap_data.ends_with(&h264_bytes(h264_len)),
                    "the H.264 surface command ({codec:?}, {h264_len} bytes) must reach the client \
                     with its payload intact in {mode:?} mode"
                );
                for o in observed.iter().filter(|o| o.codec_id == Codec1Type::ClearCodec) {
                    assert!(
                        o.compressed,
                        "ClearCodec tiles should still be compressed in {mode:?} mode"
                    );
                }

                assert_sequence_roundtrips(&observed, codec);
            }
        }
    }
}

// ---------------------------------------------------------------------------
// A burst of several H.264 commands back to back, with ClearCodec tiles that
// repeat a tile sent before the burst, still decodes intact. The tiles after
// the burst can only decode to their original bytes if the stream stays
// decodable across every H.264 command in the run, not just one.
// ---------------------------------------------------------------------------

/// One queued frame in a mixed sequence: an ordinary ClearCodec tile, or an
/// H.264 frame of a given codec and payload length.
enum Frame {
    ClearCodec,
    H264(Codec1Type, usize),
}

/// Drive `frames` through a fresh server in `mode`, decoding the whole drained
/// stream (handshake included) with a single client-side `Decompressor`, and
/// return the observed WireToSurface1 PDUs in order. Same contract as
/// `run_sequence`, but the caller supplies an arbitrary frame list so a long
/// run of consecutive H.264 commands can be exercised.
fn run_frames(mode: CompressionMode, frames: &[Frame]) -> Vec<Observed> {
    let (mut server, surface_id) = ready_server(mode);

    // Lift the frames-in-flight backpressure so a long burst of frames can be
    // queued before draining; this run submits more frames than the default
    // acknowledgement window and never acknowledges them.
    server.set_max_frames_in_flight(0);

    let mut decompressor = Decompressor::new();
    decode_drained(&mut server, &mut decompressor);

    let destination = ExclusiveRectangle {
        left: 0,
        top: 0,
        right: 16,
        bottom: 16,
    };
    let regions = [Avc420Region::full_frame(64, 64, 22)];

    for frame in frames {
        match *frame {
            Frame::ClearCodec => {
                server
                    .send_clearcodec_frame(surface_id, destination.clone(), clearcodec_bytes(), 42)
                    .expect("queue ClearCodec frame");
            }
            Frame::H264(codec, len) => {
                send_h264(&mut server, codec, surface_id, &h264_bytes(len), &regions)
                    .expect("queue H.264 frame");
            }
        }
    }

    decode_drained(&mut server, &mut decompressor)
}

#[test]
fn tiles_decode_intact_across_h264_burst() {
    // A ClearCodec anchor, then several H.264 commands back to back mixing all
    // three codecs and both single-part (8,000 B) and multipart (70,000 B)
    // payloads, then a ClearCodec that repeats the anchor, then one more H.264
    // command, then a final ClearCodec. Every ClearCodec must decode to the
    // original bytes.
    let frames = [
        Frame::ClearCodec,
        Frame::H264(Codec1Type::Avc420, 8_000),
        Frame::H264(Codec1Type::Avc444, 70_000),
        Frame::H264(Codec1Type::Avc444v2, 8_000),
        Frame::H264(Codec1Type::Avc420, 70_000),
        Frame::ClearCodec,
        Frame::H264(Codec1Type::Avc444, 8_000),
        Frame::ClearCodec,
    ];
    let expected_codecs = [
        Codec1Type::ClearCodec,
        Codec1Type::Avc420,
        Codec1Type::Avc444,
        Codec1Type::Avc444v2,
        Codec1Type::Avc420,
        Codec1Type::ClearCodec,
        Codec1Type::Avc444,
        Codec1Type::ClearCodec,
    ];
    let expected_tile = clearcodec_bytes();

    for mode in [CompressionMode::Always, CompressionMode::Auto] {
        let observed = run_frames(mode, &frames);

        let codecs: Vec<Codec1Type> = observed.iter().map(|o| o.codec_id).collect();
        assert_eq!(
            codecs, expected_codecs,
            "the ClearCodec / H.264-burst / ClearCodec order must survive the round trip in {mode:?} mode"
        );

        for (o, frame) in observed.iter().zip(&frames) {
            if let Frame::H264(codec, len) = *frame {
                assert!(
                    !o.compressed,
                    "every H.264 surface command in the burst ({codec:?}) should be sent uncompressed \
                     in {mode:?} mode"
                );
                assert!(
                    o.bitmap_data.ends_with(&h264_bytes(len)),
                    "every H.264 surface command in the burst ({codec:?}, {len} bytes) must reach the \
                     client with its payload intact in {mode:?} mode"
                );
            } else {
                assert!(
                    o.compressed,
                    "ordinary ClearCodec tiles should still be compressed in {mode:?} mode"
                );
                assert_eq!(
                    o.bitmap_data, expected_tile,
                    "a ClearCodec tile sent around the H.264 burst failed to decode to its \
                     original bytes in {mode:?} mode"
                );
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Surface commands other than H.264 are still compressed: ClearCodec, planar,
// uncompressed bitmaps (WireToSurface1) and RemoteFX progressive
// (WireToSurface2), interleaved with H.264 commands. In Always mode the frame
// markers around them are checked too.
// ---------------------------------------------------------------------------

/// Which surface command a decoded message carried.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum Surface {
    One(Codec1Type),
    Progressive,
}

/// A decoded surface command of either kind: whether its first ZGFX segment
/// was compressed, what it carried, and the decoded bitmap bytes.
struct Tile {
    compressed: bool,
    surface: Surface,
    bitmap_data: Vec<u8>,
}

fn planar_bytes() -> Vec<u8> {
    b"planar plane run ".repeat(96)
}

fn raw_bitmap_bytes() -> Vec<u8> {
    b"raw bgrx pixel row ".repeat(80)
}

fn progressive_bytes() -> Vec<u8> {
    b"progressive tile band ".repeat(70)
}

#[test]
fn other_surface_commands_still_compressed() {
    for mode in [CompressionMode::Always, CompressionMode::Auto] {
        let (mut server, surface_id) = ready_server(mode);
        server.set_max_frames_in_flight(0);

        let mut decompressor = Decompressor::new();
        decode_drained(&mut server, &mut decompressor);

        let destination = ExclusiveRectangle {
            left: 0,
            top: 0,
            right: 16,
            bottom: 16,
        };
        let regions = [Avc420Region::full_frame(64, 64, 22)];

        server
            .send_planar_frame(surface_id, &planar_bytes(), 16, 16, 42)
            .expect("queue planar frame");
        send_h264(&mut server, Codec1Type::Avc444, surface_id, &h264_bytes(8_000), &regions)
            .expect("queue H.264 frame");
        server
            .send_uncompressed_frame(surface_id, &raw_bitmap_bytes(), 16, 16, 42)
            .expect("queue uncompressed-bitmap frame");
        send_h264(&mut server, Codec1Type::Avc420, surface_id, &h264_bytes(70_000), &regions)
            .expect("queue H.264 frame");
        server
            .send_remotefx_progressive_frame(surface_id, 7, progressive_bytes(), 42)
            .expect("queue progressive frame");
        server
            .send_clearcodec_frame(surface_id, destination, clearcodec_bytes(), 42)
            .expect("queue ClearCodec frame");

        let tiles: Vec<Tile> = server
            .drain_output()
            .iter()
            .filter_map(|message| {
                let wrapped = encode_vec(message.as_ref()).expect("encode DVC message");
                let compressed = first_segment_is_compressed(&wrapped);
                let mut decoded = Vec::new();
                decompressor
                    .decompress(&wrapped, &mut decoded)
                    .expect("receiver decompress");
                let pdu = GfxPdu::decode(&mut ReadCursor::new(&decoded)).expect("decode PDU");

                // In Always mode every PDU other than an H.264 surface command,
                // frame markers included, still carries the compressed flag.
                let h264 = matches!(&pdu, GfxPdu::WireToSurface1(wire) if is_h264(wire.codec_id));
                if mode == CompressionMode::Always && !h264 {
                    assert!(
                        compressed,
                        "the {} PDU should still be compressed in Always mode",
                        pdu.name()
                    );
                }

                match pdu {
                    GfxPdu::WireToSurface1(wire) => Some(Tile {
                        compressed,
                        surface: Surface::One(wire.codec_id),
                        bitmap_data: wire.bitmap_data,
                    }),
                    GfxPdu::WireToSurface2(wire) => Some(Tile {
                        compressed,
                        surface: Surface::Progressive,
                        bitmap_data: wire.bitmap_data,
                    }),
                    _ => None,
                }
            })
            .collect();

        let surfaces: Vec<Surface> = tiles.iter().map(|t| t.surface).collect();
        assert_eq!(
            surfaces,
            [
                Surface::One(Codec1Type::Planar),
                Surface::One(Codec1Type::Avc444),
                Surface::One(Codec1Type::Uncompressed),
                Surface::One(Codec1Type::Avc420),
                Surface::Progressive,
                Surface::One(Codec1Type::ClearCodec),
            ],
            "expected the queued surface commands in order in {mode:?} mode"
        );

        for tile in &tiles {
            let expected = match tile.surface {
                Surface::One(codec) if is_h264(codec) => {
                    assert!(
                        !tile.compressed,
                        "the H.264 surface command ({codec:?}) should be sent uncompressed in {mode:?} mode"
                    );
                    continue;
                }
                Surface::One(Codec1Type::Planar) => planar_bytes(),
                Surface::One(Codec1Type::Uncompressed) => raw_bitmap_bytes(),
                Surface::One(Codec1Type::ClearCodec) => clearcodec_bytes(),
                Surface::Progressive => progressive_bytes(),
                Surface::One(other) => panic!("unexpected codec {other:?}"),
            };
            assert!(
                tile.compressed,
                "the {:?} surface command should still be compressed in {mode:?} mode",
                tile.surface
            );
            assert_eq!(
                tile.bitmap_data, expected,
                "the {:?} surface command must decode to its original bytes in {mode:?} mode",
                tile.surface
            );
        }
    }
}

// ---------------------------------------------------------------------------
// Sending a large H.264 frame takes well under half the time it takes to
// send a ClearCodec tile that carries the same bytes.
// ---------------------------------------------------------------------------

/// Wall time of the `drain_output()` call that sends one frame on a fresh
/// session in `mode`. The handshake output is drained before the clock starts.
fn time_frame_drain(mode: CompressionMode, queue: impl FnOnce(&mut GraphicsPipelineServer, u16)) -> Duration {
    let (mut server, surface_id) = ready_server(mode);
    let _ = server.drain_output();

    queue(&mut server, surface_id);

    let start = Instant::now();
    let messages = server.drain_output();
    let elapsed = start.elapsed();

    assert_eq!(
        messages.len(),
        3,
        "expected StartFrame, the surface command and EndFrame"
    );
    elapsed
}

#[test]
fn h264_send_takes_under_half_of_compression_time() {
    // 1,000,000 bytes, so compressing them takes far longer than copying them.
    // Every frame goes through a fresh session in the same state, and the
    // fastest of five alternating rounds is kept for each frame kind, so a
    // scheduler pause cannot shrink the ClearCodec time or stretch an H.264
    // time by itself. Each of the three H.264 codecs is timed.
    let payload = noisy_bytes(1_000_000, 0x9E37_79B9_7F4A_7C15);
    let regions = [Avc420Region::full_frame(64, 64, 22)];
    let destination = ExclusiveRectangle {
        left: 0,
        top: 0,
        right: 16,
        bottom: 16,
    };

    for mode in [CompressionMode::Always, CompressionMode::Auto] {
        let mut clearcodec_best = Duration::MAX;
        let mut h264_best = [Duration::MAX; 3];

        for _ in 0..5 {
            let clearcodec = time_frame_drain(mode, |server, surface_id| {
                server
                    .send_clearcodec_frame(surface_id, destination.clone(), payload.clone(), 42)
                    .expect("queue ClearCodec frame");
            });
            clearcodec_best = clearcodec_best.min(clearcodec);

            for (best, codec) in h264_best.iter_mut().zip(H264_CODECS) {
                let h264 = time_frame_drain(mode, |server, surface_id| {
                    send_h264(server, codec, surface_id, &payload, &regions).expect("queue H.264 frame");
                });
                *best = (*best).min(h264);
            }
        }

        for (best, codec) in h264_best.into_iter().zip(H264_CODECS) {
            assert!(
                best * 2 < clearcodec_best,
                "sending a 1,000,000-byte {codec:?} frame in {mode:?} mode took {best:?}, which is not \
                 well under half of the {clearcodec_best:?} it took to send a ClearCodec tile with the \
                 same bytes"
            );
        }
    }
}

// ---------------------------------------------------------------------------
// Auto mode still round-trips the full sequence, and Never mode sends
// everything uncompressed as before.
// ---------------------------------------------------------------------------

#[test]
fn modes_preserved_auto_never() {
    // In both Auto and Never the client decodes the full sequence and the
    // trailing ClearCodec round-trips. Never sends every segment uncompressed.
    for mode in [CompressionMode::Auto, CompressionMode::Never] {
        for codec in H264_CODECS {
            let observed = run_sequence(mode, codec, 8_000);
            assert_sequence_roundtrips(&observed, codec);

            if mode == CompressionMode::Never {
                for o in &observed {
                    assert!(
                        !o.compressed,
                        "Never mode should send every surface command uncompressed ({:?})",
                        o.codec_id
                    );
                }
            }
        }
    }
}
