## Task

With ZGFX compression on, the EGFX server runs every PDU it sends through the compressor, surface commands included.
That pays off for ordinary tiles.
H.264 surface commands (AVC420, AVC444 and AVC444v2) get the same treatment, but their payload is already entropy coded.
The compressor almost never makes them smaller, so on a busy session the send path mostly burns CPU on them.

Please stop compressing H.264 surface commands.
In both modes that compress (`Auto` and `Always`), an H.264 surface command should go out in uncompressed ZGFX segments without passing through the compressor, whether it fits in one segment or needs several.
Sending a large H.264 frame should then take well under half the time the server spends sending a ClearCodec tile of the same bytes.

The rest should keep working:
- Everything else the server sends still goes through the compressor as before, including ClearCodec, planar, uncompressed-bitmap and progressive surface commands in the same session.
- A client that decodes the whole stream gets every tile back byte for byte, including compressed tiles sent after one or several H.264 commands in a row.
- With compression off (`Never`), nothing changes.
