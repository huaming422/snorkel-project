## Task

During an access audit we found stale `datasource_access` permissions in the metadata database.
Several roles still hold grants for semantic-layer views that were removed weeks ago.
All of them trace back to semantic layers being deleted, but not every layer delete leaves junk behind.

Here is the pattern we saw.
When the layer's views had been loaded in the session before the delete, their permissions and the role grants pointing at them went away as expected.
When the views had not been loaded, the permissions and grants were still there afterwards, however many views the layer had.

Please find out why and fix it.
Once a layer is deleted, none of its views' `datasource_access` permissions should remain and no role should still hold them, whether or not the views were loaded first.

Be careful about permissions that are shared.
A dataset and a semantic view can end up with the same permission name, and so can two views in different layers.
Deleting a layer, a single semantic view or a dataset must keep a permission that one of those other live resources still uses, together with its role grants.
When nothing else uses it, deleting a single view or a dataset should still remove its permission and grants the way it does today.

Some of our layers have hundreds of views nobody has opened in the current session.
Deleting one of those should work out which view permissions are still in use with a fixed number of database queries, not a lookup per view.
