"""Behavioral tests for semantic-layer permission cleanup on delete.

These tests exercise the running permission lifecycle through pre-existing,
stable interfaces only:

- ``from superset import security_manager`` and
  ``security_manager.find_permission_view_menu("datasource_access", perm)`` as
  the central probe for whether a ``datasource_access`` PermissionView still
  exists.
- The ORM models ``SemanticLayer`` / ``SemanticView`` and their pre-existing
  ``after_insert`` events (which create the per-view PermissionView on flush),
  ``SqlaTable`` / ``Database`` for the dataset-sharing scenarios, and FAB's
  ``PermissionView`` / ``Role`` for role-grant assertions.

Every check deletes through the ORM session and asserts the stored end state:
which PermissionViews exist and which grants each role still holds. No helper
of the security manager is patched or named, so any way of wiring the cleanup
is accepted as long as the stored state comes out right.

The fixtures mirror the repository's own unit-test fixtures
(``tests/unit_tests/conftest.py``): a module-scoped Superset app under an
application context, and a per-test in-memory SQLite session patched onto the
security manager and ``superset.db``. The verifier file lives outside the
repository test tree, so the fixtures are replicated here rather than resolved
from the repo conftest.
"""

from __future__ import annotations

import re
import uuid
from contextlib import ExitStack
from typing import Any, Iterator
from unittest.mock import patch

import pytest
from sqlalchemy import create_engine, event, text, update
from sqlalchemy.engine import Connection, Engine
from sqlalchemy.orm import Session, sessionmaker

PERM_TYPE = "datasource_access"

# A read of a table that stores datasource_access keys for a resource: semantic
# views, datasets and charts. Reads of the FAB permission tables are not counted.
_OWNER_TABLE_READ = re.compile(
    r"\b(?:FROM|JOIN)\s+\"?(?:semantic_views|tables|slices)\b", re.IGNORECASE
)


@pytest.fixture(scope="module")
def app() -> Iterator[Any]:
    """Build a minimal Superset app and keep it for the module."""
    from superset.app import SupersetApp
    from superset.extensions import appbuilder
    from superset.initialization import SupersetAppInitializer

    flask_app = SupersetApp(__name__)
    flask_app.config.from_object("superset.config")
    flask_app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite://"
    flask_app.config["WTF_CSRF_ENABLED"] = False
    flask_app.config["PREVENT_UNSAFE_DB_CONNECTIONS"] = False
    flask_app.config["TESTING"] = True
    flask_app.config["RATELIMIT_ENABLED"] = False
    flask_app.config["CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    flask_app.config["DATA_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    flask_app.config["SERVER_NAME"] = "example.com"
    flask_app.config["APPLICATION_ROOT"] = "/"
    # A singleton appbuilder keeps views across rebuilds; clear them so init
    # can run once more in this process.
    appbuilder.baseviews = []
    SupersetAppInitializer(flask_app).init_app()
    yield flask_app


@pytest.fixture(autouse=True)
def app_context(app: Any) -> Iterator[None]:
    """Push an application context around every test (makes the security
    manager usable), mirroring the repository's autouse fixture."""
    with app.app_context():
        yield


@pytest.fixture
def session() -> Iterator[Session]:
    """In-memory SQLite session wired onto the security manager and
    ``superset.db``, mirroring the repository's ``session`` fixture."""
    engine: Engine = create_engine("sqlite://")
    session_factory = sessionmaker(bind=engine)
    in_memory_session = session_factory()
    # Flask would call db.session.remove(); make it a no-op here.
    in_memory_session.remove = lambda: None  # type: ignore[method-assign]

    with ExitStack() as stack:
        sm_session = stack.enter_context(
            patch("superset.security.SupersetSecurityManager.session")
        )
        sm_session.return_value = in_memory_session
        sm_session.get_bind.return_value = engine
        sm_session.query = in_memory_session.query
        stack.enter_context(patch("superset.db.session", in_memory_session))
        yield in_memory_session

    in_memory_session.close()
    engine.dispose()


def _make_layer(session: Session, name: str) -> Any:
    from superset.semantic_layers.models import SemanticLayer

    layer = SemanticLayer(
        uuid=uuid.uuid4(), name=name, type="test", configuration="{}"
    )
    session.add(layer)
    session.flush()
    return layer


def _make_view(session: Session, layer: Any, name: str, view_id: int | None = None) -> Any:
    from superset.semantic_layers.models import SemanticView

    kwargs: dict[str, Any] = {
        "name": name,
        "semantic_layer_uuid": layer.uuid,
        "configuration": "{}",
    }
    if view_id is not None:
        kwargs["id"] = view_id
    view = SemanticView(**kwargs)
    session.add(view)
    session.flush()
    return view


def _make_dataset(
    session: Session, database_name: str, table_name: str, dataset_id: int
) -> Any:
    from superset.connectors.sqla.models import SqlaTable
    from superset.models.core import Database

    database = Database(database_name=database_name, sqlalchemy_uri="sqlite://")
    dataset = SqlaTable(id=dataset_id, table_name=table_name, database=database)
    session.add(dataset)
    session.flush()
    return dataset


def _pvm(perm: str) -> Any:
    from superset import security_manager

    return security_manager.find_permission_view_menu(PERM_TYPE, perm)


def _grant(session: Session, role_name: str, perms: list[str]) -> int:
    """Create a role holding the datasource_access PVM of every key."""
    from flask_appbuilder.security.sqla.models import Role

    pvms = [_pvm(perm) for perm in perms]
    assert all(pvms), "pre-existing after_insert should create a PVM per key"
    role = Role(name=role_name, permissions=pvms)
    session.add(role)
    session.commit()
    return role.id


def _granted(session: Session, role_id: int) -> list[str]:
    from flask_appbuilder.security.sqla.models import Role

    return sorted(p.view_menu.name for p in session.get(Role, role_id).permissions)


def _share_key(session: Session, view_id: int, key: str) -> None:
    """Give a view an existing key directly, without firing the update event,
    modelling a legacy shared key."""
    from superset.semantic_layers.models import SemanticView

    session.execute(
        update(SemanticView.__table__)
        .where(SemanticView.__table__.c.id == view_id)
        .values(perm=key)
    )


def _enable_fk_schema(session: Session) -> None:
    from superset.semantic_layers.models import SemanticView

    session.execute(text("PRAGMA foreign_keys=ON"))
    SemanticView.metadata.create_all(session.get_bind())


def _view_with_dataset_key(
    session: Session, owner: str, layer_name: str, view_id: int
) -> tuple[Any, Any, Any, str]:
    """Build a layer with one view whose key a live dataset also owns.

    ``dataset`` gives the dataset and the view the same id and names, so their
    keys match on their own. ``dataset_legacy_key`` gives them different ids
    and names and copies the dataset key onto the view row, modelling a
    legacy shared key. Returns the layer, the view, the dataset and the shared
    key.
    """
    if owner == "dataset":
        dataset = _make_dataset(session, layer_name, "invoices", dataset_id=view_id)
        layer = _make_layer(session, layer_name)
        view = _make_view(session, layer, "invoices", view_id=view_id)
        assert view.perm == dataset.perm
    else:
        dataset = _make_dataset(
            session, f"{layer_name} Ledger", "entries", dataset_id=view_id + 40
        )
        layer = _make_layer(session, layer_name)
        view = _make_view(session, layer, "Journal", view_id=view_id)
        _share_key(session, view.id, dataset.perm)
    return layer, view, dataset, dataset.perm


# ---------------------------------------------------------------------------
# Deleting a layer whose views are not loaded in the session removes every
# view's access permission and detaches it from its roles.
# ---------------------------------------------------------------------------
def test_removes_unloaded_child_permissions(session: Session) -> None:
    from superset.semantic_layers.models import SemanticView

    _enable_fk_schema(session)

    layer = _make_layer(session, "Deleted Layer")
    views = [
        _make_view(session, layer, name)
        for name in ("Child View", "Second Child View")
    ]
    view_perms = [view.perm for view in views]
    role_id = _grant(session, "child view reader", view_perms)

    session.expire(layer, ["semantic_views"])
    session.delete(layer)
    session.commit()
    session.expire_all()

    assert session.query(SemanticView).count() == 0
    assert all(_pvm(perm) is None for perm in view_perms)
    assert _granted(session, role_id) == []


# ---------------------------------------------------------------------------
# Same end state when the views ARE loaded in the ORM collection.
# ---------------------------------------------------------------------------
def test_removes_loaded_child_permissions(session: Session) -> None:
    from superset.semantic_layers.models import SemanticView

    _enable_fk_schema(session)

    layer = _make_layer(session, "Loaded Layer")
    views = [
        _make_view(session, layer, name)
        for name in ("Loaded Child", "Second Loaded Child")
    ]
    view_perms = [view.perm for view in views]
    role_id = _grant(session, "loaded view reader", view_perms)

    assert layer.semantic_views
    session.delete(layer)
    session.commit()
    session.expire_all()

    assert session.query(SemanticView).count() == 0
    assert all(_pvm(perm) is None for perm in view_perms)
    assert _granted(session, role_id) == []


# ---------------------------------------------------------------------------
# Deleting a layer with many unloaded views removes every view's permission and
# grant, and the number of reads of the owner tables (semantic views, datasets
# and charts) is the same for 30 views as for 4.
# ---------------------------------------------------------------------------
def _delete_unloaded_counting_owner_reads(session: Session, layer: Any) -> list[str]:
    session.refresh(layer)
    session.expire(layer, ["semantic_views"])

    connection: Connection = session.connection()
    reads: list[str] = []

    def record_read(
        _connection: Connection,
        _cursor: Any,
        statement: str,
        _parameters: Any,
        _context: Any,
        _executemany: bool,
    ) -> None:
        head = statement.lstrip().upper()
        if head.startswith(("SELECT", "WITH")) and _OWNER_TABLE_READ.search(statement):
            reads.append(statement)

    event.listen(connection, "before_cursor_execute", record_read)
    try:
        session.delete(layer)
        session.flush()
    finally:
        event.remove(connection, "before_cursor_execute", record_read)
    session.commit()
    session.expire_all()
    return reads


def test_owner_reads_do_not_grow_with_view_count(session: Session) -> None:
    from superset.semantic_layers.models import SemanticView

    _enable_fk_schema(session)

    reads_by_size: dict[int, list[str]] = {}
    for size in (4, 30):
        layer = _make_layer(session, f"Bulk Layer {size}")
        perms = [
            _make_view(session, layer, f"Bulk View {size}-{number}").perm
            for number in range(size)
        ]
        assert len(set(perms)) == size
        role_id = _grant(session, f"bulk reader {size}", perms)

        reads_by_size[size] = _delete_unloaded_counting_owner_reads(session, layer)

        assert session.query(SemanticView).count() == 0
        leftover = [perm for perm in perms if _pvm(perm) is not None]
        assert leftover == [], (
            f"{len(leftover)} of {size} view permissions left after the delete"
        )
        assert _granted(session, role_id) == []

    small, large = reads_by_size[4], reads_by_size[30]
    assert len(large) == len(small), (
        f"owner-table reads grew from {len(small)} (4 views) to {len(large)} "
        "(30 views):\n" + "\n".join(large)
    )


# ---------------------------------------------------------------------------
# Deleting a layer keeps a view's permission and grant when a dataset or a view
# in another layer still owns the same key, and still removes the layer's other
# view permission even when an unrelated dataset has that view's id and name.
# Run with the views unloaded and loaded.
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("loaded", [False, True], ids=["unloaded", "loaded"])
@pytest.mark.parametrize(
    "owner", ["dataset", "dataset_legacy_key", "view_in_other_layer"]
)
def test_layer_delete_keeps_child_perm_another_resource_owns(
    session: Session, owner: str, loaded: bool
) -> None:
    from superset.semantic_layers.models import SemanticView

    _enable_fk_schema(session)

    if owner == "view_in_other_layer":
        layer = _make_layer(session, "Archive")
        other_layer = _make_layer(session, "Reporting")
        shared_view = _make_view(session, layer, "Revenue", view_id=21)
        keeper_id = _make_view(session, other_layer, "Revenue Copy", view_id=31).id
        shared_key = shared_view.perm
        _share_key(session, keeper_id, shared_key)
    else:
        layer, shared_view, _dataset, shared_key = _view_with_dataset_key(
            session, owner, "Warehouse", view_id=7
        )
    plain_view = _make_view(session, layer, "Scratch", view_id=22)
    plain_key = plain_view.perm
    # An unrelated dataset with the plain view's id and name but its own key.
    decoy = _make_dataset(session, "Elsewhere", "Scratch", dataset_id=22)
    assert decoy.perm != plain_key
    role_id = _grant(session, f"{owner} {loaded} reader", [shared_key, plain_key])

    if loaded:
        assert len(layer.semantic_views) == 2
    else:
        session.expire(layer, ["semantic_views"])
    session.delete(layer)
    session.commit()
    session.expire_all()

    if owner == "view_in_other_layer":
        assert session.get(SemanticView, keeper_id).perm == shared_key
    assert _pvm(shared_key) is not None
    assert _pvm(plain_key) is None
    assert _granted(session, role_id) == [shared_key]


# ---------------------------------------------------------------------------
# Deleting a single view keeps its permission and grant when a dataset or a
# view in another layer still owns the same key.
# ---------------------------------------------------------------------------
@pytest.mark.parametrize(
    "owner", ["dataset", "dataset_legacy_key", "view_in_other_layer"]
)
def test_view_delete_keeps_perm_another_resource_owns(
    session: Session, owner: str
) -> None:
    from superset.semantic_layers.models import SemanticView

    _enable_fk_schema(session)

    if owner == "view_in_other_layer":
        layer = _make_layer(session, "Finance")
        other_layer = _make_layer(session, "Marketing")
        view = _make_view(session, layer, "Spend", view_id=15)
        keeper_id = _make_view(session, other_layer, "Spend Mirror", view_id=25).id
        key = view.perm
        _share_key(session, keeper_id, key)
    else:
        layer, view, _dataset, key = _view_with_dataset_key(
            session, owner, "Billing", view_id=3
        )
    view_id = view.id
    role_id = _grant(session, f"{owner} view reader", [key])

    session.delete(view)
    session.commit()
    session.expire_all()

    assert session.get(SemanticView, view_id) is None
    if owner == "view_in_other_layer":
        assert session.get(SemanticView, keeper_id).perm == key
    assert _pvm(key) is not None
    assert _granted(session, role_id) == [key]


# ---------------------------------------------------------------------------
# Deleting a single view whose key nothing else owns removes its permission and
# grant, and leaves its sibling view's permission and grant alone, even when an
# unrelated dataset has the deleted view's id and name.
# ---------------------------------------------------------------------------
def test_view_delete_removes_unshared_perm(session: Session) -> None:
    _enable_fk_schema(session)

    layer = _make_layer(session, "Operations")
    deleted = _make_view(session, layer, "Tickets", view_id=11)
    sibling = _make_view(session, layer, "Shifts", view_id=12)
    deleted_key, sibling_key = deleted.perm, sibling.perm
    decoy = _make_dataset(session, "Support", "Tickets", dataset_id=11)
    assert decoy.perm != deleted_key
    role_id = _grant(session, "operations reader", [deleted_key, sibling_key])

    session.delete(deleted)
    session.commit()
    session.expire_all()

    assert _pvm(deleted_key) is None
    assert _pvm(sibling_key) is not None
    assert _granted(session, role_id) == [sibling_key]


# ---------------------------------------------------------------------------
# Deleting a dataset whose key a live semantic view still owns keeps that
# permission and its role grant, whether the keys match on their own or the
# view carries a legacy copy of the dataset key.
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("owner", ["dataset", "dataset_legacy_key"])
def test_retains_dataset_perm_a_view_owns(session: Session, owner: str) -> None:
    from superset.connectors.sqla.models import SqlaTable
    from superset.semantic_layers.models import SemanticView

    SemanticView.metadata.create_all(session.get_bind())

    _layer, view, dataset, key = _view_with_dataset_key(
        session, owner, "Fleet", view_id=5
    )
    view_id, dataset_id = view.id, dataset.id
    role_id = _grant(session, f"{owner} dataset reader", [key])

    session.delete(dataset)
    session.commit()
    session.expire_all()

    assert session.get(SqlaTable, dataset_id) is None
    assert session.get(SemanticView, view_id) is not None
    assert _pvm(key) is not None
    assert _granted(session, role_id) == [key]


# ---------------------------------------------------------------------------
# Deleting a dataset whose key no semantic view owns removes its permission and
# grant, even when one view has the dataset's id and another has its name.
# ---------------------------------------------------------------------------
def test_dataset_delete_removes_unshared_perm(session: Session) -> None:
    from superset.semantic_layers.models import SemanticView

    SemanticView.metadata.create_all(session.get_bind())

    dataset = _make_dataset(session, "Sales", "orders", dataset_id=2)
    layer = _make_layer(session, "Sales")
    same_id = _make_view(session, layer, "returns", view_id=2)
    same_name = _make_view(session, layer, "orders", view_id=3)
    dataset_key = dataset.perm
    view_keys = sorted([same_id.perm, same_name.perm])
    assert dataset_key not in view_keys
    role_id = _grant(session, "sales reader", [dataset_key, *view_keys])

    session.delete(dataset)
    session.commit()
    session.expire_all()

    assert _pvm(dataset_key) is None
    assert all(_pvm(key) is not None for key in view_keys)
    assert _granted(session, role_id) == view_keys
