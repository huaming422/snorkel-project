#nullable enable

using System.Collections;
using System.Collections.ObjectModel;
using Jint.Runtime;
using Jint.Runtime.Interop;

namespace Jint.Tests.PublicInterface;

/// <summary>
/// Pins what a bracket index names on a wrapped CLR collection exposed to script with element writes
/// enabled. The contract under test is observable entirely through Jint's public surface: build an
/// <see cref="Engine"/>, hand it a host collection, and run script. Every assertion checks a returned
/// <see cref="Native.JsValue"/>, the host collection's own contents, or whether what left
/// <see cref="Engine.Execute(string)"/> was a script error rather than a .NET one.
///
/// <para>
/// The contract: <c>x[3]</c> and <c>x["3"]</c> are one property key, so they must give one
/// answer whichever element operation asks; a position at or past the end of a growable target behaves
/// like <c>a[a.length] = v</c> on a real array; an index the view can never hold reads like an array
/// hole; and a fixed-size or read-only exposure keeps its refusal in both spellings. Nothing here
/// references how any of that is implemented, only the outcomes a consumer sees.
/// </para>
/// </summary>
public class HostCollectionElementWriteBehaviorTests
{
    // ── helpers ──────────────────────────────────────────────────────────────────────────────────

    private static Engine WritableEngine(object host, bool strict = false)
    {
        var engine = new Engine(options =>
        {
            options.Strict = strict;
            options.Interop.AllowWrite = true;
        });
        engine.SetValue("x", host);
        return engine;
    }

    private static Engine LiveViewEngine(object host, bool strict = false)
    {
        var engine = new Engine(options =>
        {
            options.Strict = strict;
            options.Interop.AllowWrite = true;
            options.Interop.ArrayConversion = ArrayConversionMode.LiveView;
        });
        engine.SetValue("x", host);
        return engine;
    }

    private static Engine ExposedAsEngine(object target, Type exposedAs, bool strict = false)
    {
        var engine = new Engine(options =>
        {
            options.Strict = strict;
            options.Interop.AllowWrite = true;
        });
        engine.SetValue("x", ObjectWrapper.Create(engine, target, exposedAs));
        return engine;
    }

    // Runs an operation and reports what, if anything, escaped it, classifying a script TypeError apart
    // from any other outcome. The two spellings of an index must agree on this classification.
    private static string Probe(string operation, bool strict)
    {
        var prologue = strict ? "'use strict';\n" : "";
        return prologue
            + "(function () { try { " + operation + "; return 'ok'; } "
            + "catch (e) { return e instanceof TypeError ? 'TypeError' : 'other:' + e; } })()";
    }

    // ── C1: in-range element write, both spellings, no .NET exception escapes ────────────────────

    [Test]
    public void InRangeWriteAgreesAcrossBothSpellings()
    {
        foreach (var index in new[] { "2", "'2'" })
        {
            var list = new List<int> { 1, 2, 3 };
            var engine = WritableEngine(list);

            var thrown = Caught.Exception(() => engine.Execute("x[" + index + "] = 9"));

            thrown.Should().Match(e => e == null || e is JavaScriptException,
                "writing x[{0}] must answer script, not the CLR", index);
            list.Should().Equal(new[] { 1, 2, 9 }, "x[{0}] = 9 writes the slot at that offset", index);
        }
    }

    // ── C2: growth at/past the end mirrors a[a.length]=v, both spellings ──────────────────────────

    [Test]
    public void WritingAtTheEndGrowsTheTargetInEitherSpelling()
    {
        foreach (var index in new[] { "3", "'3'" })
        {
            var list = new List<int> { 1, 2, 3 };
            var engine = WritableEngine(list);

            var thrown = Caught.Exception(() => engine.Execute("x[" + index + "] = 9"));

            thrown.Should().Match(e => e == null || e is JavaScriptException,
                "growing through x[{0}] must not leak a CLR exception", index);
            list.Should().Equal(new[] { 1, 2, 3, 9 }, "x[{0}] = 9 appends like a[a.length] = v", index);
            engine.Evaluate("x.length").AsNumber().Should().Be(4);
        }
    }

    [Test]
    public void WritingPastTheEndFillsTheGapInEitherSpelling()
    {
        foreach (var index in new[] { "5", "'5'" })
        {
            var list = new List<int> { 1, 2, 3 };
            WritableEngine(list).Execute("x[" + index + "] = 9");

            list.Should().Equal(new[] { 1, 2, 3, 0, 0, 9 }, "x[{0}] = 9 past the end fills the gap with the default and writes", index);
        }
    }

    [Test]
    public void BulkCopyIntoAGrowableTargetGrowsIt()
    {
        var list = new List<int> { 1, 2, 3 };
        var engine = WritableEngine(list);

        var thrown = Caught.Exception(() => engine.Execute("Object.assign(x, { 3: 9 })"));

        thrown.Should().Match(e => e == null || e is JavaScriptException,
            "Object.assign copies over string keys and must answer script");
        list.Should().Equal(1, 2, 3, 9);
    }

    // ── C3: absent / out-of-band access reads like a hole, both spellings, no CLR exception ──────

    [Test]
    public void AbsentReadIsUndefinedInEitherSpelling()
    {
        var list = new List<int> { 1, 2, 3 };
        var engine = WritableEngine(list);

        foreach (var key in new[] { "3", "'3'", "-1", "'-1'", "'08'" })
        {
            var thrown = Caught.Exception(() => engine.Execute("void (x[" + key + "])"));
            thrown.Should().Match(e => e == null || e is JavaScriptException,
                "reading x[{0}] must answer script, not the CLR", key);
            engine.Evaluate("x[" + key + "] === undefined").AsBoolean().Should().BeTrue(
                "reading an absent position x[{0}] is a hole", key);
        }
    }

    [Test]
    public void MembershipOfAnAbsentIndexIsFalseInEitherSpelling()
    {
        var engine = WritableEngine(new List<int> { 1, 2, 3 });

        foreach (var key in new[] { "3", "'3'", "-1", "'-1'", "'08'" })
        {
            engine.Evaluate("(" + key + " in x)").AsBoolean().Should().BeFalse(
                "{0} is not a position of a three-element view", key);
        }
        engine.Evaluate("(2 in x)").AsBoolean().Should().BeTrue();
        engine.Evaluate("('2' in x)").AsBoolean().Should().BeTrue();
    }

    [Test]
    public void DeletingAnAbsentIndexSucceedsWithoutTouchingTheTarget()
    {
        var list = new List<int> { 1, 2, 3 };
        var engine = WritableEngine(list);

        foreach (var key in new[] { "3", "'3'", "-1" })
        {
            engine.Evaluate("delete x[" + key + "]").AsBoolean().Should().BeTrue(
                "delete of the absent position x[{0}] is an ordinary no-op that succeeds", key);
        }
        list.Should().Equal(new[] { 1, 2, 3 }, "deleting an absent position leaves the target untouched");
    }

    [Test]
    public void NoAccessOnAGrowableTargetLetsAClrExceptionEscape()
    {
        string[] operations =
        [
            "x[3] = 9", "x['3'] = 9", "x[5] = 9", "x['5'] = 9", "x[-1] = 9", "x['-1'] = 9",
            "x['08'] = 9", "x[2147483648] = 9", "x[3]", "x['3']", "x[-1]", "x['08']",
            "delete x[3]", "delete x['3']", "delete x[-1]", "Object.assign(x, { 4: 9 })",
        ];

        foreach (var operation in operations)
        {
            foreach (var strict in new[] { false, true })
            {
                var engine = WritableEngine(new List<int> { 1, 2, 3 }, strict);
                var thrown = Caught.Exception(() => engine.Execute(operation));

                thrown.Should().Match(e => e == null || e is JavaScriptException,
                    "'{0}' (strict={1}) must answer script, never the CLR", operation, strict);
            }
        }
    }

    // ── C4: fixed-size T[] live view, in-range string write coerces, out-of-range is TypeError ──

    [Test]
    public void FixedSizeLiveViewWritesInRangeThroughTheTypedLane()
    {
        var array = new[] { 1, 2, 3 };
        var engine = LiveViewEngine(array);

        var thrown = Caught.Exception(() => engine.Execute("x['2'] = 9"));

        thrown.Should().Match(e => e == null || e is JavaScriptException,
            "an in-range string-spelled write on a live view must not leak a CLR exception");
        array[2].Should().Be(9, "the value is coerced to the element type and written");
    }

    [Test]
    public void FixedSizeLiveViewRefusesOutOfRangeWritesWithATypeError()
    {
        foreach (var operation in new[] { "x['3'] = 9", "x[3] = 9", "x[5] = 9", "x['-1'] = 9" })
        {
            foreach (var strict in new[] { false, true })
            {
                var array = new[] { 1, 2, 3 };
                var verdict = LiveViewEngine(array, strict).Evaluate(Probe(operation, strict)).AsString();

                verdict.Should().Be("TypeError",
                    "'{0}' on a fixed-size view is a script TypeError, not a CLR exception (strict={1})",
                    operation, strict);
                array.Should().Equal(new[] { 1, 2, 3 }, "a refused write leaves the array untouched");
            }
        }

        // '08' is not how any slot index is written, so the view may refuse it with a TypeError or ignore it.
        // Either way it answers script and leaves the array as it was.
        foreach (var strict in new[] { false, true })
        {
            var array = new[] { 1, 2, 3 };
            var verdict = LiveViewEngine(array, strict).Evaluate(Probe("x['08'] = 9", strict)).AsString();

            verdict.Should().BeOneOf(new[] { "TypeError", "ok" },
                "x['08'] = 9 on a fixed-size view answers script (strict={0})", strict);
            array.Should().Equal(new[] { 1, 2, 3 }, "x['08'] = 9 leaves the array untouched");
        }
    }

    // ── C5: read-only exposure refuses element writes as ordinary [[Set]] false, both spellings ──

    [Test]
    public void ReadOnlyExposureRefusesElementWritesInEitherSpelling()
    {
        foreach (var index in new[] { "2", "'2'", "3", "'3'" })
        {
            var list = new List<int> { 1, 2, 3 };

            ExposedAsEngine(list, typeof(IReadOnlyList<int>), strict: false)
                .Evaluate(Probe("x[" + index + "] = 9", strict: false)).AsString()
                .Should().Be("ok", "a failed [[Set]] is silent outside strict mode (x[{0}])", index);
            list.Should().Equal(new[] { 1, 2, 3 }, "the underlying list is unchanged (sloppy, x[{0}])", index);

            ExposedAsEngine(list, typeof(IReadOnlyList<int>), strict: true)
                .Evaluate(Probe("x[" + index + "] = 9", strict: true)).AsString()
                .Should().Be("TypeError", "a failed [[Set]] is a TypeError in strict mode (x[{0}])", index);
            list.Should().Equal(new[] { 1, 2, 3 }, "the underlying list is unchanged (strict, x[{0}])", index);
        }
    }

    [Test]
    public void ReadOnlyCollectionRefusesElementWritesInEitherSpelling()
    {
        foreach (var index in new[] { "0", "'0'" })
        {
            var backing = new List<int> { 1, 2, 3 };
            var readOnly = new ReadOnlyCollection<int>(backing);

            WritableEngine(readOnly, strict: false)
                .Evaluate(Probe("x[" + index + "] = 9", strict: false)).AsString()
                .Should().Be("ok", "a read-only collection refuses silently outside strict mode (x[{0}])", index);

            WritableEngine(readOnly, strict: true)
                .Evaluate(Probe("x[" + index + "] = 9", strict: true)).AsString()
                .Should().Be("TypeError", "a read-only collection refuses with a TypeError in strict mode (x[{0}])", index);

            backing.Should().Equal(new[] { 1, 2, 3 }, "the backing list is never written (x[{0}])", index);
        }
    }

    // ── C6: fractional indices, expandos, refused writes and enumeration ─────────────────────────

    [Test]
    public void FractionalAndOverflowIndicesDoNotMutateTheTarget()
    {
        var list = new List<int> { 1, 2, 3 };
        var engine = WritableEngine(list);

        engine.Execute("x[3.5] = 9");
        engine.Execute("x[2 ** 31] = 9");

        list.Should().Equal(new[] { 1, 2, 3 }, "a fractional or beyond-addressable index never touches the elements");
    }

    [Test]
    public void StringMemberNamesStillAttachAsExpandoProperties()
    {
        var list = new List<int> { 1, 2, 3 };
        var engine = WritableEngine(list);

        engine.Execute("x.foo = 1");

        engine.Evaluate("x.foo").AsNumber().Should().Be(1, "an ordinary member name is an expando property");
        list.Should().Equal(new[] { 1, 2, 3 }, "an expando does not alter the elements");
    }

    [Test]
    public void WritesAreRefusedWhenWritingIsDisabledOrTheViewIsNonExtensible()
    {
        var disabledList = new List<int> { 1, 2, 3 };
        new Engine().SetValue("x", disabledList).Execute("x[3] = 9");
        disabledList.Should().Equal(new[] { 1, 2, 3 }, "with writes disabled the collection is untouched");

        var frozenList = new List<int> { 1, 2, 3 };
        WritableEngine(frozenList).Execute("Object.preventExtensions(x); x[3] = 9");
        frozenList.Should().Equal(new[] { 1, 2, 3 }, "a non-extensible view refuses the growth write");
    }

    [Test]
    public void EnumerationReflectsOnlyTheRealElements()
    {
        var engine = WritableEngine(new List<int> { 1, 2, 3 });

        engine.Evaluate("Object.keys(x).join(',')").AsString().Should().Be("0,1,2",
            "only the real positions enumerate");
        engine.Evaluate("(function () { var r = []; for (var k in x) r.push(k); return r.join(','); })()")
            .AsString().Should().Be("0,1,2", "for..in sees only the real positions");
        engine.Evaluate("JSON.stringify(x)").AsString().Should().Be("[1,2,3]",
            "serialization reflects the elements");
    }
}
