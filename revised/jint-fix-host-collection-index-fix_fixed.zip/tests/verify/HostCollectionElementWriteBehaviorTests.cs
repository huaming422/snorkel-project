#nullable enable

using System.Collections;
using System.Collections.ObjectModel;
using Jint.Runtime;
using Jint.Runtime.Interop;
using Newtonsoft.Json.Linq;

namespace Jint.Tests.PublicInterface;

/// <summary>
/// Pins what a bracket index names on a wrapped CLR collection exposed to script with element writes
/// enabled. The contract under test is observable entirely through Jint's public surface: build an
/// <see cref="Engine"/>, hand it a host collection, and run script. Every assertion checks a returned
/// <see cref="Native.JsValue"/>, the host collection's own contents, or whether what left
/// <see cref="Engine.Execute(string)"/> was a script error rather than a .NET one.
///
/// <para>
/// The contract: <c>x[3]</c> and <c>x["3"]</c> are one property key, so they must give one
/// answer whichever element operation asks; a position at or past the end of a growable target behaves
/// like <c>a[a.length] = v</c> on a real array; an index the view can never hold reads like an array
/// hole; and a fixed-size or read-only exposure keeps its refusal in both spellings. The same holds for
/// every list shape a host hands over (typed and untyped, growable, fixed-size and read-only), while a
/// list that is also keyed by name keeps answering a string key from its own keys. Nothing here
/// references how any of that is implemented, only the outcomes a consumer sees.
/// </para>
/// </summary>
public class HostCollectionElementWriteBehaviorTests
{
    // ── helpers ──────────────────────────────────────────────────────────────────────────────────

    private static Engine WritableEngine(object host, bool strict = false)
    {
        var engine = new Engine(options =>
        {
            options.Strict = strict;
            options.Interop.AllowWrite = true;
        });
        engine.SetValue("x", host);
        return engine;
    }

    private static Engine LiveViewEngine(object host, bool strict = false)
    {
        var engine = new Engine(options =>
        {
            options.Strict = strict;
            options.Interop.AllowWrite = true;
            options.Interop.ArrayConversion = ArrayConversionMode.LiveView;
        });
        engine.SetValue("x", host);
        return engine;
    }

    private static Engine ExposedAsEngine(object target, Type exposedAs, bool strict = false)
    {
        var engine = new Engine(options =>
        {
            options.Strict = strict;
            options.Interop.AllowWrite = true;
        });
        engine.SetValue("x", ObjectWrapper.Create(engine, target, exposedAs));
        return engine;
    }

    // Runs an operation and reports what, if anything, escaped it, classifying a script TypeError apart
    // from any other outcome. The two spellings of an index must agree on this classification.
    private static string Probe(string operation, bool strict)
    {
        var prologue = strict ? "'use strict';\n" : "";
        return prologue
            + "(function () { try { " + operation + "; return 'ok'; } "
            + "catch (e) { return e instanceof TypeError ? 'TypeError' : 'other:' + e; } })()";
    }

    // ── C1: in-range element write, both spellings, no .NET exception escapes ────────────────────

    [Test]
    public void InRangeWriteAgreesAcrossBothSpellings()
    {
        foreach (var index in new[] { "2", "'2'" })
        {
            foreach (var strict in new[] { false, true })
            {
                var list = new List<int> { 1, 2, 3 };
                var engine = WritableEngine(list, strict);

                var thrown = Caught.Exception(() => engine.Execute("x[" + index + "] = 9"));

                thrown.Should().BeNull("writing an existing slot through x[{0}] completes normally (strict={1})", index, strict);
                list.Should().Equal(new[] { 1, 2, 9 }, "x[{0}] = 9 writes the slot at that offset (strict={1})", index, strict);
            }
        }
    }

    // ── C2: growth at/past the end mirrors a[a.length]=v, both spellings ──────────────────────────

    [Test]
    public void WritingAtTheEndGrowsTheTargetInEitherSpelling()
    {
        foreach (var index in new[] { "3", "'3'" })
        {
            foreach (var strict in new[] { false, true })
            {
                var list = new List<int> { 1, 2, 3 };
                var engine = WritableEngine(list, strict);

                var thrown = Caught.Exception(() => engine.Execute("x[" + index + "] = 9"));

                thrown.Should().BeNull("appending through x[{0}] completes normally (strict={1})", index, strict);
                list.Should().Equal(new[] { 1, 2, 3, 9 }, "x[{0}] = 9 appends like a[a.length] = v (strict={1})", index, strict);
                engine.Evaluate("x.length").AsNumber().Should().Be(4);
            }
        }
    }

    [Test]
    public void WritingPastTheEndFillsTheGapInEitherSpelling()
    {
        foreach (var index in new[] { "5", "'5'" })
        {
            foreach (var strict in new[] { false, true })
            {
                var list = new List<int> { 1, 2, 3 };
                var engine = WritableEngine(list, strict);

                var thrown = Caught.Exception(() => engine.Execute("x[" + index + "] = 9"));

                thrown.Should().BeNull("writing past the end through x[{0}] completes normally (strict={1})", index, strict);
                list.Should().Equal(new[] { 1, 2, 3, 0, 0, 9 },
                    "x[{0}] = 9 past the end fills the gap with the default and writes (strict={1})", index, strict);
            }
        }
    }

    [Test]
    public void BulkCopyIntoAGrowableTargetGrowsIt()
    {
        var list = new List<int> { 1, 2, 3 };
        var engine = WritableEngine(list);

        var thrown = Caught.Exception(() => engine.Execute("Object.assign(x, { 3: 9 })"));

        thrown.Should().BeNull("Object.assign copies over string keys and completes normally");
        list.Should().Equal(1, 2, 3, 9);
    }

    // ── C3: absent / out-of-band access reads like a hole, both spellings, no CLR exception ──────

    [Test]
    public void AbsentReadIsUndefinedInEitherSpelling()
    {
        var list = new List<int> { 1, 2, 3 };
        var engine = WritableEngine(list);

        foreach (var key in new[] { "3", "'3'", "-1", "'-1'", "'08'" })
        {
            var thrown = Caught.Exception(() => engine.Execute("void (x[" + key + "])"));
            thrown.Should().Match(e => e == null || e is JavaScriptException,
                "reading x[{0}] must answer script, not the CLR", key);
            engine.Evaluate("x[" + key + "] === undefined").AsBoolean().Should().BeTrue(
                "reading an absent position x[{0}] is a hole", key);
        }
    }

    [Test]
    public void MembershipOfAnAbsentIndexIsFalseInEitherSpelling()
    {
        var engine = WritableEngine(new List<int> { 1, 2, 3 });

        foreach (var key in new[] { "3", "'3'", "-1", "'-1'", "'08'" })
        {
            engine.Evaluate("(" + key + " in x)").AsBoolean().Should().BeFalse(
                "{0} is not a position of a three-element view", key);
        }
        engine.Evaluate("(2 in x)").AsBoolean().Should().BeTrue();
        engine.Evaluate("('2' in x)").AsBoolean().Should().BeTrue();
    }

    [Test]
    public void DeletingAnAbsentIndexSucceedsWithoutTouchingTheTarget()
    {
        var list = new List<int> { 1, 2, 3 };
        var engine = WritableEngine(list);

        foreach (var key in new[] { "3", "'3'", "-1", "'-1'", "'08'" })
        {
            engine.Evaluate("delete x[" + key + "]").AsBoolean().Should().BeTrue(
                "delete of the absent position x[{0}] is an ordinary no-op that succeeds", key);
            list.Should().Equal(new[] { 1, 2, 3 }, "deleting the absent position x[{0}] leaves the target untouched", key);
        }
    }

    [Test]
    public void NoAccessOnAGrowableTargetLetsAClrExceptionEscape()
    {
        string[] operations =
        [
            "x[3] = 9", "x['3'] = 9", "x[5] = 9", "x['5'] = 9", "x[-1] = 9", "x['-1'] = 9",
            "x['08'] = 9", "x[2147483647] = 9", "x['2147483647'] = 9", "x[2147483648] = 9",
            "x[3]", "x['3']", "x[-1]", "x['08']", "x[2147483647]", "x['2147483647']",
            "delete x[3]", "delete x['3']", "delete x[-1]", "Object.assign(x, { 4: 9 })",
            "3 in x", "'3' in x", "-1 in x", "'-1' in x", "'08' in x",
        ];

        foreach (var operation in operations)
        {
            foreach (var strict in new[] { false, true })
            {
                var engine = WritableEngine(new List<int> { 1, 2, 3 }, strict);
                var thrown = Caught.Exception(() => engine.Execute(operation));

                thrown.Should().Match(e => e == null || e is JavaScriptException,
                    "'{0}' (strict={1}) must answer script, never the CLR", operation, strict);
            }
        }
    }

    // ── C4: fixed-size T[] live view, in-range string write coerces, out-of-range is TypeError ──

    [Test]
    public void FixedSizeLiveViewStoresAnInRangeStringWriteAsTheElementType()
    {
        var array = new[] { 1, 2, 3 };
        var engine = LiveViewEngine(array);

        var thrown = Caught.Exception(() => engine.Execute("x['2'] = 9"));

        thrown.Should().BeNull("an in-range string-spelled write on a live view completes normally");
        array[2].Should().Be(9, "the value is coerced to the element type and written");
    }

    [Test]
    public void FixedSizeLiveViewRefusesOutOfRangeWritesWithATypeError()
    {
        foreach (var operation in new[] { "x['3'] = 9", "x[3] = 9", "x[5] = 9", "x[-1] = 9", "x['-1'] = 9" })
        {
            foreach (var strict in new[] { false, true })
            {
                var array = new[] { 1, 2, 3 };
                var verdict = LiveViewEngine(array, strict).Evaluate(Probe(operation, strict)).AsString();

                verdict.Should().Be("TypeError",
                    "'{0}' on a fixed-size view is a script TypeError, not a CLR exception (strict={1})",
                    operation, strict);
                array.Should().Equal(new[] { 1, 2, 3 }, "a refused write leaves the array untouched");
            }
        }

        // '08' is not how any slot index is written, so the view may refuse it with a TypeError or ignore it.
        // Either way it answers script and leaves the array as it was.
        foreach (var strict in new[] { false, true })
        {
            var array = new[] { 1, 2, 3 };
            var verdict = LiveViewEngine(array, strict).Evaluate(Probe("x['08'] = 9", strict)).AsString();

            verdict.Should().BeOneOf(new[] { "TypeError", "ok" },
                "x['08'] = 9 on a fixed-size view answers script (strict={0})", strict);
            array.Should().Equal(new[] { 1, 2, 3 }, "x['08'] = 9 leaves the array untouched");
        }
    }

    // ── C5: read-only exposure refuses element writes as ordinary [[Set]] false, both spellings ──

    [Test]
    public void ReadOnlyExposureRefusesElementWritesInEitherSpelling()
    {
        foreach (var index in new[] { "2", "'2'", "3", "'3'" })
        {
            var list = new List<int> { 1, 2, 3 };

            ExposedAsEngine(list, typeof(IReadOnlyList<int>), strict: false)
                .Evaluate(Probe("x[" + index + "] = 9", strict: false)).AsString()
                .Should().Be("ok", "a failed [[Set]] is silent outside strict mode (x[{0}])", index);
            list.Should().Equal(new[] { 1, 2, 3 }, "the underlying list is unchanged (sloppy, x[{0}])", index);

            ExposedAsEngine(list, typeof(IReadOnlyList<int>), strict: true)
                .Evaluate(Probe("x[" + index + "] = 9", strict: true)).AsString()
                .Should().Be("TypeError", "a failed [[Set]] is a TypeError in strict mode (x[{0}])", index);
            list.Should().Equal(new[] { 1, 2, 3 }, "the underlying list is unchanged (strict, x[{0}])", index);
        }
    }

    [Test]
    public void ReadOnlyCollectionRefusesElementWritesInEitherSpelling()
    {
        foreach (var index in new[] { "0", "'0'", "3", "'3'" })
        {
            var backing = new List<int> { 1, 2, 3 };
            var readOnly = new ReadOnlyCollection<int>(backing);

            WritableEngine(readOnly, strict: false)
                .Evaluate(Probe("x[" + index + "] = 9", strict: false)).AsString()
                .Should().Be("ok", "a read-only collection refuses silently outside strict mode (x[{0}])", index);

            WritableEngine(readOnly, strict: true)
                .Evaluate(Probe("x[" + index + "] = 9", strict: true)).AsString()
                .Should().Be("TypeError", "a read-only collection refuses with a TypeError in strict mode (x[{0}])", index);

            backing.Should().Equal(new[] { 1, 2, 3 }, "the backing list is never written (x[{0}])", index);
        }
    }

    // ── C6: fractional indices, expandos, refused writes and enumeration ─────────────────────────

    [Test]
    public void FractionalAndOverflowIndicesDoNotMutateTheTarget()
    {
        var list = new List<int> { 1, 2, 3 };
        var engine = WritableEngine(list);

        engine.Execute("x[3.5] = 9");
        // past the last addressable position the write may be refused with a script error or ignored, but it
        // never reaches the list
        foreach (var operation in new[] { "x[2147483647] = 9", "x['2147483647'] = 9" })
        {
            Caught.Exception(() => engine.Execute(operation)).Should().Match(e => e == null || e is JavaScriptException,
                "'{0}' answers script, never the CLR", operation);
        }
        engine.Execute("x[2 ** 31] = 9");

        list.Should().Equal(new[] { 1, 2, 3 }, "a fractional or beyond-addressable index never touches the elements");
    }

    [Test]
    public void StringMemberNamesStillAttachAsExpandoProperties()
    {
        var list = new List<int> { 1, 2, 3 };
        var engine = WritableEngine(list);

        engine.Execute("x.foo = 1");

        engine.Evaluate("x.foo").AsNumber().Should().Be(1, "an ordinary member name is an expando property");
        list.Should().Equal(new[] { 1, 2, 3 }, "an expando does not alter the elements");
    }

    [Test]
    public void WritesAreRefusedWhenWritingIsDisabledOrTheViewIsNonExtensible()
    {
        foreach (var index in new[] { "1", "'1'", "3", "'3'" })
        {
            var disabledList = new List<int> { 1, 2, 3 };
            new Engine().SetValue("x", disabledList).Execute("x[" + index + "] = 9");
            disabledList.Should().Equal(new[] { 1, 2, 3 }, "with writes disabled x[{0}] = 9 leaves the collection untouched", index);

            var frozenList = new List<int> { 1, 2, 3 };
            WritableEngine(frozenList).Execute("Object.preventExtensions(x); x[" + index + "] = 9");
            frozenList.Should().Equal(new[] { 1, 2, 3 }, "a non-extensible view refuses the write x[{0}] = 9", index);
        }
    }

    [Test]
    public void EnumerationReflectsOnlyTheRealElements()
    {
        var engine = WritableEngine(new List<int> { 1, 2, 3 });

        engine.Evaluate("Object.keys(x).join(',')").AsString().Should().Be("0,1,2",
            "only the real positions enumerate");
        engine.Evaluate("(function () { var r = []; for (var k in x) r.push(k); return r.join(','); })()")
            .AsString().Should().Be("0,1,2", "for..in sees only the real positions");
        engine.Evaluate("JSON.stringify(x)").AsString().Should().Be("[1,2,3]",
            "serialization reflects the elements");
    }

    // ── C7: deleting an existing slot gives one answer in both spellings ──────────────────────────

    // Like Probe, but hands back what the expression evaluated to, so a delete's own answer can be compared.
    private static string Outcome(string expression, bool strict)
    {
        var prologue = strict ? "'use strict';\n" : "";
        return prologue
            + "(function () { try { return String(" + expression + "); } "
            + "catch (e) { return e instanceof TypeError ? 'TypeError' : 'other:' + e; } })()";
    }

    private static string Contents(IEnumerable items)
        => string.Join(",", items.Cast<object?>().Select(item => item?.ToString() ?? "null"));

    [Test]
    public void DeletingAnExistingSlotOfAGrowableListAgreesAcrossBothSpellings()
    {
        var targets = new (string Name, Func<IList> Create, string After)[]
        {
            ("List<int>", () => new List<int> { 1, 2, 3 }, "1,0,3"),
            ("List<string>", () => new List<string> { "a", "b", "c" }, "a,null,c"),
            ("ArrayList", () => new ArrayList { 1, "b", 3 }, "1,null,3"),
            ("ObservableCollection<int>", () => new ObservableCollection<int> { 1, 2, 3 }, "1,0,3"),
        };

        foreach (var (name, create, after) in targets)
        {
            foreach (var index in new[] { "1", "'1'" })
            {
                foreach (var strict in new[] { false, true })
                {
                    var target = create();
                    var answer = WritableEngine(target, strict).Evaluate(Outcome("delete x[" + index + "]", strict)).AsString();

                    answer.Should().Be("true", "delete x[{0}] on a {1} succeeds (strict={2})", index, name, strict);
                    Contents(target).Should().Be(after,
                        "delete x[{0}] on a {1} puts the element default back in that slot (strict={2})", index, name, strict);
                }
            }
        }
    }

    [Test]
    public void DeletingAnExistingSlotOfAFixedSizeOrReadOnlyViewIsRefusedInBothSpellings()
    {
        var targets = new (string Name, Func<IEnumerable> Create, Func<object, bool, Engine> Expose)[]
        {
            ("int[] live view", () => new[] { 1, 2, 3 }, LiveViewEngine),
            ("ArraySegment<int>", () => new ArraySegment<int>(new[] { 0, 1, 2, 3, 4 }, 1, 3), WritableEngine),
            ("ArrayList.FixedSize", () => ArrayList.FixedSize(new ArrayList { 1, 2, 3 }), WritableEngine),
            ("ReadOnlyCollection<int>", () => new ReadOnlyCollection<int>(new List<int> { 1, 2, 3 }), WritableEngine),
            ("ArrayList.ReadOnly", () => ArrayList.ReadOnly(new ArrayList { 1, 2, 3 }), WritableEngine),
            ("List<int> exposed as IReadOnlyList<int>", () => new List<int> { 1, 2, 3 },
                (target, strict) => ExposedAsEngine(target, typeof(IReadOnlyList<int>), strict)),
        };

        foreach (var (name, create, expose) in targets)
        {
            foreach (var index in new[] { "1", "'1'" })
            {
                foreach (var strict in new[] { false, true })
                {
                    var target = create();
                    var before = Contents(target);
                    var engine = expose(target, strict);
                    var answer = engine.Evaluate(Outcome("delete x[" + index + "]", strict)).AsString();

                    answer.Should().Be(strict ? "TypeError" : "false",
                        "delete x[{0}] on a {1} is refused like a frozen array's (strict={2})", index, name, strict);
                    Contents(target).Should().Be(before, "a refused delete x[{0}] leaves the {1} as it was", index, name);
                }
            }
        }
    }

    // ── C8: the same contract on the other host collections script is handed ──────────────────────

    [Test]
    public void OtherGrowableCollectionsGrowInEitherSpelling()
    {
        var targets = new (string Name, Func<IList> Create, string Value, string AtEnd, string PastEnd)[]
        {
            ("ArrayList", () => new ArrayList { 1, 2, 3 }, "9", "1,2,3,9", "1,2,3,null,null,9"),
            ("List<string>", () => new List<string> { "a", "b", "c" }, "'z'", "a,b,c,z", "a,b,c,null,null,z"),
            ("ObservableCollection<int>", () => new ObservableCollection<int> { 1, 2, 3 }, "9", "1,2,3,9", "1,2,3,0,0,9"),
        };

        foreach (var (name, create, value, atEnd, pastEnd) in targets)
        {
            foreach (var (index, expected) in new[] { ("3", atEnd), ("'3'", atEnd), ("5", pastEnd), ("'5'", pastEnd) })
            {
                foreach (var strict in new[] { false, true })
                {
                    var target = create();
                    var engine = WritableEngine(target, strict);

                    var thrown = Caught.Exception(() => engine.Execute("x[" + index + "] = " + value));

                    thrown.Should().BeNull("x[{0}] = {1} on a {2} completes normally (strict={3})", index, value, name, strict);
                    Contents(target).Should().Be(expected, "x[{0}] = {1} grows the {2} (strict={3})", index, value, name, strict);
                    engine.Evaluate("x.length").AsNumber().Should().Be(target.Count);
                }
            }

            var copyTarget = create();
            var copied = Caught.Exception(() => WritableEngine(copyTarget).Execute("Object.assign(x, { 3: " + value + " })"));
            copied.Should().BeNull("Object.assign into a {0} completes normally", name);
            Contents(copyTarget).Should().Be(atEnd, "Object.assign(x, {{ 3: {0} }}) grows the {1}", value, name);

            foreach (var operation in new[] { "x[-1] = 9", "x['-1'] = 9", "x['08'] = 9", "x[2147483647] = 9", "x['2147483647'] = 9", "x[2147483648] = 9" })
            {
                foreach (var strict in new[] { false, true })
                {
                    var thrown = Caught.Exception(() => WritableEngine(create(), strict).Execute(operation));
                    thrown.Should().Match(e => e == null || e is JavaScriptException,
                        "'{0}' on a {1} (strict={2}) must answer script, never the CLR", operation, name, strict);
                }
            }

            foreach (var key in new[] { "3", "'3'", "-1", "'-1'", "'08'" })
            {
                var target = create();
                var before = Contents(target);
                var engine = WritableEngine(target);

                engine.Evaluate(Outcome("x[" + key + "] === undefined", strict: false)).AsString()
                    .Should().Be("true", "reading the absent position x[{0}] of a {1} is a hole", key, name);
                engine.Evaluate(Outcome(key + " in x", strict: false)).AsString()
                    .Should().Be("false", "{0} is not a position of a three-element {1}", key, name);
                engine.Evaluate(Outcome("delete x[" + key + "]", strict: false)).AsString()
                    .Should().Be("true", "deleting the absent position x[{0}] of a {1} succeeds", key, name);
                Contents(target).Should().Be(before, "probing x[{0}] leaves the {1} as it was", key, name);
            }
        }
    }

    [Test]
    public void OtherFixedSizeViewsWriteInRangeAndRefuseOutOfRangeWithATypeError()
    {
        foreach (var strict in new[] { false, true })
        {
            foreach (var index in new[] { "1", "'1'" })
            {
                var buffer = new[] { 0, 1, 2, 3, 4, 5 };
                var segment = new ArraySegment<int>(buffer, 2, 3);
                WritableEngine(segment, strict).Evaluate(Probe("x[" + index + "] = 9", strict)).AsString()
                    .Should().Be("ok", "x[{0}] = 9 inside an ArraySegment<int> completes normally (strict={1})", index, strict);
                buffer.Should().Equal(new[] { 0, 1, 2, 9, 4, 5 },
                    "x[{0}] = 9 writes the segment's slot 1, which is the buffer's slot 3 (strict={1})", index, strict);

                var fixedList = ArrayList.FixedSize(new ArrayList { 1, 2, 3 });
                WritableEngine(fixedList, strict).Evaluate(Probe("x[" + index + "] = 9", strict)).AsString()
                    .Should().Be("ok", "x[{0}] = 9 inside an ArrayList.FixedSize view completes normally (strict={1})", index, strict);
                Contents(fixedList).Should().Be("1,9,3");
            }

            foreach (var operation in new[] { "x['3'] = 9", "x[3] = 9", "x['5'] = 9", "x[-1] = 9", "x['-1'] = 9" })
            {
                var buffer = new[] { 0, 1, 2, 3, 4, 5 };
                WritableEngine(new ArraySegment<int>(buffer, 2, 3), strict).Evaluate(Probe(operation, strict)).AsString()
                    .Should().Be("TypeError", "'{0}' on an ArraySegment<int> is a script TypeError (strict={1})", operation, strict);
                buffer.Should().Equal(new[] { 0, 1, 2, 3, 4, 5 }, "'{0}' leaves the buffer untouched, even past the segment's end", operation);

                var fixedList = ArrayList.FixedSize(new ArrayList { 1, 2, 3 });
                WritableEngine(fixedList, strict).Evaluate(Probe(operation, strict)).AsString()
                    .Should().Be("TypeError", "'{0}' on an ArrayList.FixedSize view is a script TypeError (strict={1})", operation, strict);
                Contents(fixedList).Should().Be("1,2,3", "'{0}' leaves the fixed-size list untouched", operation);
            }
        }
    }

    [Test]
    public void ReadOnlyArrayListRefusesElementWritesInEitherSpelling()
    {
        foreach (var index in new[] { "1", "'1'", "3", "'3'" })
        {
            foreach (var strict in new[] { false, true })
            {
                var backing = new ArrayList { 1, 2, 3 };
                WritableEngine(ArrayList.ReadOnly(backing), strict)
                    .Evaluate(Probe("x[" + index + "] = 9", strict)).AsString()
                    .Should().Be(strict ? "TypeError" : "ok",
                        "an ArrayList.ReadOnly view refuses x[{0}] = 9 like a frozen array (strict={1})", index, strict);
                Contents(backing).Should().Be("1,2,3", "the backing list is never written (x[{0}], strict={1})", index, strict);
            }
        }
    }

    // ── C9: a list that is also keyed by name keeps answering its own keys ─────────────────────────

    [Test]
    public void KeyedJsonObjectKeepsAnsweringNumberLikeKeysByName()
    {
        foreach (var strict in new[] { false, true })
        {
            var json = JObject.Parse("{\"2024\": 5, \"17\": \"a\", \"0\": true, \"name\": \"n\"}");
            var engine = WritableEngine(json, strict);

            engine.Evaluate("String(x['2024'])").AsString().Should().Be("5", "x['2024'] reads the value under the key \"2024\"");
            engine.Evaluate("String(x['17'])").AsString().Should().Be("a", "x['17'] reads the value under the key \"17\"");
            engine.Evaluate("String(x['0'])").AsString().Should().Be("true", "x['0'] reads the value under the key \"0\"");
            engine.Evaluate("String(x['name'])").AsString().Should().Be("n");
            engine.Evaluate("'2024' in x").AsBoolean().Should().BeTrue("the key \"2024\" is there");
            engine.Evaluate("'17' in x").AsBoolean().Should().BeTrue("the key \"17\" is there");
            engine.Evaluate("Object.keys(x).join(',')").AsString().Should().Be("2024,17,0,name");
            engine.Evaluate("JSON.stringify(x)").AsString().Should().Be("{\"2024\":5,\"17\":\"a\",\"0\":true,\"name\":\"n\"}");

            engine.Evaluate(Outcome("delete x['17']", strict)).AsString().Should().Be("true", "deleting the key \"17\" succeeds (strict={0})", strict);
            json.ContainsKey("17").Should().BeFalse("delete x['17'] removes the key \"17\" (strict={0})", strict);
            json.Properties().Select(p => p.Name).Should().Equal(new[] { "2024", "0", "name" }, "only the key \"17\" is removed");
        }
    }
}
