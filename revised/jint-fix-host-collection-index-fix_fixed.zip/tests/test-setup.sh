#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
#
# This task is a pure in-process library test: the verifier adds one NUnit test
# to Jint.Tests.PublicInterface (public surface only) and runs it via
# `dotnet test`. There is no service to start and no data to seed. The only job
# here is to confirm the baked .NET dependency closure is usable offline.
#
# The image baked the full NuGet closure into $NUGET_PACKAGES (/opt/nuget/packages)
# AND pre-restored + pre-built Jint.Tests.PublicInterface for net8.0 at the base
# commit, so every project already has a current obj/project.assets.json. dotnet
# has no "--offline" switch; its offline guarantee comes from exactly that state:
# when the global-packages folder is warm and the assets file is current, `dotnet
# restore` performs no network I/O (a no-op restore) and `dotnet build --no-restore`
# compiles entirely from the local cache. All dependencies are baked into the
# image, so nothing has to be fetched here.

cd /repo/jint

export DOTNET_CLI_TELEMETRY_OPTOUT=1
export DOTNET_NOLOGO=1
export DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1
export NUGET_PACKAGES="${NUGET_PACKAGES:-/opt/nuget/packages}"

# Dependencies: prove the closure resolves from the image bake (no-op restore,
# no network), with a logged online fallback in case the bake was stale. Check the
# exit status directly, and never pipe through `tail`, which would mask it.
PROJ="Jint.Tests.PublicInterface/Jint.Tests.PublicInterface.csproj"
if dotnet restore "$PROJ" > /tmp/test-setup-restore.log 2>&1; then
    echo "[offline-first] NuGet closure satisfied from image bake"
else
    echo "[test-setup] no-op restore failed; retrying (bake may be stale)" >&2
    if dotnet restore "$PROJ" --force >> /tmp/test-setup-restore.log 2>&1; then
        echo "[test-setup] NuGet packages restored (image bake was stale)"
    else
        echo "[test-setup] dotnet restore failed:" >&2
        tail -60 /tmp/test-setup-restore.log >&2
        exit 1
    fi
fi
