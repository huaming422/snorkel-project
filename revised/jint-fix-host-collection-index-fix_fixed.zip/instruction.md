## Task

We pass a few .NET collections into the engine with `AllowWrite` on, and assigning into them by index keeps blowing up.
On a `List<int>` that is allowed to grow, a line like `x[3] = 9` throws a .NET exception that comes straight out of `Execute`/`Evaluate`, so the script's own `try/catch` never gets a chance at it.
This is what lands in our host code from `engine.Execute("x[3] = 9")` on a three-element list:

```
System.ArgumentOutOfRangeException: Index was out of range. Must be non-negative and less than the size of the collection. (Parameter 'index')
```

What's odd is that the same slot acts differently when the index is a number versus a string (`x[3]` vs `x['3']`), and poking at slots that aren't there is inconsistent the same way.
My hunch is that the engine just doesn't extend the list when you write past the end, but I haven't checked.

Here's what we expect from script, whichever way the index is spelled.
Writing to a slot that already exists should just update it.
Writing at the end of a growable list should append, and writing further out should extend it with the element type's default in the gap (zeros for our `List<int>`).
`Object.assign(x, { 3: 9 })` on that list should grow it too.
Reading a slot that isn't there should give `undefined`, `in` should say `false`, and `delete` should return `true` and leave the list alone.
That goes for negative indexes and odd strings like `'-1'` or `'08'` too.
Deleting a slot that does exist, as in `delete x['1']`, should do what `delete x[1]` does today: put the element type's default back in that slot and return `true`.
No read, write, `delete`, `in` or `Object.assign` by index should let a .NET exception out of the engine, in sloppy or strict code.

It isn't only `List<int>` either.
Script also gets `ArrayList`, `ObservableCollection<int>` and `List<string>` lists from us, and all of the above should hold for them as well.
When the elements aren't a value type, the gap is filled with `null`.

Some collections shouldn't grow at all.
A plain `int[]` handed over as a live view keeps its size, so `x['2'] = 9` should store 9 as an `int` in the array, while writing past its end or at a negative index should stay the catchable `TypeError` it already is for number indexes.
An `ArraySegment<int>` over part of a buffer and a list wrapped with `ArrayList.FixedSize` should behave the same way.
A write inside one of them lands in that slot (for the segment, that is the buffer slot at the segment's offset), and a write past the end or at a negative index is a `TypeError` that leaves the data as it was.
A list script may only read, like a `ReadOnlyCollection<int>`, an `ArrayList.ReadOnly` wrapper, or a `List<int>` we pass in typed as `IReadOnlyList<int>`, should turn down every element write and stay unchanged, quietly in sloppy mode and with a `TypeError` in strict mode, like a frozen array.
Deleting a slot that exists in any of these fixed-size or read-only collections should be turned down too, with `false` in sloppy mode and a `TypeError` in strict mode, whichever way the index is written.

Please don't break what already works.
Fractional indexes, or ones from 2147483647 (`int.MaxValue`) up, shouldn't touch the elements.
A normal name like `x.foo = 1` should still become a plain property.
Writes should still be refused with `AllowWrite` off or after `Object.preventExtensions(x)`.
`Object.keys`, `for...in` and `JSON.stringify` should only see the real elements.
We also hand script Json.NET `JObject` payloads, which count as lists and as keyed objects at once, and some of their keys are numbers like `'2024'` or `'17'`.
On those, `x['2024']`, `'2024' in x`, `delete x['17']`, `Object.keys` and `JSON.stringify` all work by key today, and they should keep working that way.
