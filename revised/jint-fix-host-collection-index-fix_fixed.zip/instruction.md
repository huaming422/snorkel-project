## Task

We pass a few .NET collections into the engine with `AllowWrite` on, and assigning into them by index keeps blowing up.
On a `List<int>` that is allowed to grow, a line like `x[3] = 9` throws a .NET exception that comes straight out of `Execute`/`Evaluate`, so the script's own `try/catch` never gets a chance at it.
This is what lands in our host code from `engine.Execute("x[3] = 9")` on a three-element list:

```
System.ArgumentOutOfRangeException: Index was out of range. Must be non-negative and less than the size of the collection. (Parameter 'index')
```

What's odd is that the same slot acts differently when the index is a number versus a string (`x[3]` vs `x['3']`), and poking at slots that aren't there is inconsistent the same way.
My hunch is that the engine just doesn't extend the list when you write past the end, but I haven't checked.

Here's what we expect from script, whichever way the index is spelled.
Writing to a slot that already exists should just update it.
Writing at the end of a growable list should append, and writing further out should extend it with the element type's default in the gap (zeros for our `List<int>`), the same as making `x.length` bigger does.
`Object.assign(x, { 3: 9 })` on that list should grow it too.
Reading a slot that isn't there should give `undefined`, `in` should say `false`, and `delete` should return `true` and leave the list alone.
That goes for negative indexes and odd strings like `'-1'` or `'08'` too.
No read, write, `delete`, `in` or `Object.assign` by index should let a .NET exception out of the engine, in sloppy or strict code.

Two kinds of collections shouldn't grow at all.
A plain `int[]` handed over as a live view keeps its size, so `x['2'] = 9` should store 9 as an `int` in the array, while writing past its end or at a negative index should stay the catchable `TypeError` it already is for number indexes.
A list script may only read, like a `ReadOnlyCollection<int>` or a `List<int>` we pass in typed as `IReadOnlyList<int>`, should turn down every element write and stay unchanged, quietly in sloppy mode and with a `TypeError` in strict mode, like a frozen array.

Please don't break what already works.
Fractional indexes, or ones too big for a .NET list, shouldn't touch the elements.
A normal name like `x.foo = 1` should still become a plain property.
Writes should still be refused with `AllowWrite` off or after `Object.preventExtensions(x)`.
`Object.keys`, `for...in` and `JSON.stringify` should only see the real elements.
