"""Behavioral checks for OR conditions over joined tables and for join-chain
estimates in the turso planner.

Each check runs one `.sqltest` corpus shipped next to this file through the
sqltest conformance runner on the Rust backend and reads its JSON report.
A corpus asserts the plan line for one table (`expect pattern`), the exact
result rows (`expect`), or one HASH JOIN step's rows_per_input from
EXPLAIN QUERY PLAN FORMAT=JSON. Every rows_per_input case in c5 has a twin
query without the extra index that must print the same value.

The file only shells out to the pre-built runner and imports no repository
Python, so it runs under the shared verifier interpreter as is.

  test_or_narrows_first_table          c1_implied_in_filter.sqltest
  test_or_results_unchanged            c2_results_unchanged.sqltest
  test_outer_join_results_unchanged    c3_outer_join_safe.sqltest
  test_compound_index_keeps_lookups    c4_compound_index_kept.sqltest
  test_join_key_index_keeps_estimate   c5_hash_join_estimate.sqltest
"""

import json
import os
import subprocess
from pathlib import Path

import pytest

# Repo root: the task container clones turso to /repo/turso (see Dockerfile /
# test-setup.sh). Allow an override for local reruns.
REPO_ROOT = Path(os.environ.get("TURSO_REPO_ROOT", "/repo/turso"))
SQLTEST_MANIFEST = REPO_ROOT / "testing" / "sqltest" / "Cargo.toml"
# Corpora ship alongside this file in tests/verify/ (verify/ files are copied
# flat, without subdirectories).
CORPORA_DIR = Path(__file__).resolve().parent

# Generous per-corpus ceiling; each corpus is a handful of in-memory queries.
# The whole stack stays well under the verifier wall-clock budget.
RUN_TIMEOUT_SEC = 240


def _run_corpus(corpus_name):
    """Run one .sqltest corpus through the native (in-process) Rust backend.

    Returns (summary_dict, results_by_name) where results_by_name maps a test
    name to its outcome string ("passed" / "failed" / "error" / "skipped").
    Raises AssertionError with captured output on a runner/build failure so the
    verifier surfaces infra problems instead of silently green.
    """
    corpus_path = CORPORA_DIR / corpus_name
    assert corpus_path.is_file(), f"missing corpus {corpus_path}"

    cmd = [
        "cargo",
        "run",
        "--quiet",
        "--manifest-path",
        str(SQLTEST_MANIFEST),
        "--bin",
        "sqltest",
        "--",
        "run",
        str(corpus_path),
        "--backend",
        "rust",
        "-o",
        "json",
    ]

    proc = subprocess.run(
        cmd,
        cwd=str(REPO_ROOT),
        capture_output=True,
        text=True,
        timeout=RUN_TIMEOUT_SEC,
    )

    # sqltest exit codes: 0 = all pass/skip, 1 = a test failed OR a hard error,
    # 2 = bad args. We parse JSON regardless and judge per-test; exit code 2
    # (or unparseable output) is an infra failure.
    stdout = proc.stdout or ""
    try:
        payload = json.loads(stdout)
    except json.JSONDecodeError:
        raise AssertionError(
            f"sqltest produced no parseable JSON for {corpus_name} "
            f"(exit {proc.returncode}).\n"
            f"--- stdout ---\n{stdout[-4000:]}\n"
            f"--- stderr ---\n{(proc.stderr or '')[-4000:]}"
        )

    results_by_name = {}
    for f in payload.get("files", []):
        for r in f.get("results", []):
            results_by_name[r.get("name")] = {
                "outcome": r.get("outcome"),
                "reason": r.get("reason"),
            }

    summary = payload.get("summary", {})
    return summary, results_by_name


def _assert_all_pass(corpus_name, expected_tests):
    summary, results = _run_corpus(corpus_name)

    missing = [t for t in expected_tests if t not in results]
    assert not missing, (
        f"{corpus_name}: expected tests not found in runner output: {missing}. "
        f"Saw: {sorted(results)}"
    )

    failures = []
    for t in expected_tests:
        outcome = results[t]["outcome"]
        if outcome != "passed":
            failures.append(f"{t}: outcome={outcome} reason={results[t]['reason']}")
    assert not failures, f"{corpus_name} had non-passing tests:\n" + "\n".join(failures)

    # Defensive: the runner's own summary must agree there were no failures.
    assert summary.get("failed", 0) == 0, (
        f"{corpus_name}: runner summary reports failures: {summary}"
    )


def test_or_narrows_first_table():
    """An OR whose branches pin columns of two joined tables reaches the first
    table of a CROSS JOIN through an index search on the OR'd column (one
    search, or a multi-index OR over that index), never a full SCAN. Covers
    integer, signed and text values, parentheses, three branches, two pinned
    columns of one table, and tables with and without ANALYZE statistics.
    In a plain JOIN with an index on the OR'd column of both tables, both
    tables are read through their index, whichever order the planner picks.
    """
    _assert_all_pass(
        "c1_implied_in_filter.sqltest",
        [
            "or-narrows-first-table-by-index",
            "or-narrows-first-table-three-branches-parens",
            "or-narrows-first-table-when-branch-pins-two-of-its-columns",
            "or-narrows-first-table-with-stats",
            "or-narrows-both-tables-of-plain-join",
        ],
    )


def test_or_results_unchanged():
    """OR conditions over joined tables return the same rows as SQLite for
    negative numbers, collated text, blobs mixed with integers, NULL keys,
    cross-combinations of branch values, a column only some branches pin,
    literals on the left of `=`, LEFT and FULL OUTER joins with the OR in
    WHERE, and UPDATE and DELETE with an OR.
    """
    _assert_all_pass(
        "c2_results_unchanged.sqltest",
        [
            "or-join-negative-numbers-keep-results",
            "or-join-text-collation-keep-results",
            "or-join-blob-and-integer-keep-results",
            "or-join-null-key-keep-results",
            "or-join-rejects-cross-combinations",
            "or-join-column-missing-from-one-branch-keep-results",
            "or-join-literal-on-left-side-keep-results",
            "or-join-three-branches-two-columns-keep-results",
            "left-join-where-or-keep-results",
            "full-join-where-or-keep-results",
            "update-with-or-keeps-results",
            "delete-with-or-keeps-results",
        ],
    )


def test_outer_join_results_unchanged():
    """A LEFT JOIN with an OR over both sides, in WHERE or in the ON clause,
    still returns the NULL-extended rows for unmatched left rows.
    """
    _assert_all_pass(
        "c3_outer_join_safe.sqltest",
        [
            "outer-join-or-keeps-unmatched-left-rows",
            "outer-join-on-clause-or-keeps-unmatched-left-rows",
            "outer-join-on-clause-three-branch-or-keeps-unmatched-left-rows",
        ],
    )


def test_compound_index_keeps_lookups():
    """An OR whose groups each pin both leading columns of one two-column
    index keeps one exact lookup per group (a MULTI-INDEX OR naming that index
    once per group), on a single table with integer, text and signed values,
    with and without ANALYZE, and on a table joined to another one.
    """
    _assert_all_pass(
        "c4_compound_index_kept.sqltest",
        [
            "one-table-two-groups-keep-exact-lookups",
            "one-table-three-text-groups-keep-exact-lookups",
            "one-table-analyzed-signed-groups-keep-exact-lookups",
            "joined-table-keeps-exact-lookups",
        ],
    )


def test_join_key_index_keeps_estimate():
    """In a CROSS JOIN chain, a plain index on the second table's join column
    leaves the third table's plan line and HASH JOIN estimate the same as
    without that index: on analyzed tables the third table stays an index
    lookup, and with or without statistics the HASH JOIN rows_per_input
    matches the unindexed twin. A UNIQUE index keeps its own estimate.
    """
    _assert_all_pass(
        "c5_hash_join_estimate.sqltest",
        [
            "analyzed-visits-indexed-key-keeps-lookup",
            "analyzed-visits-unindexed-key-lookup",
            "analyzed-orders-indexed-key-keeps-lookup",
            "analyzed-orders-unindexed-key-lookup",
            "analyzed-jobs-indexed-key-keeps-lookup",
            "analyzed-jobs-unindexed-key-lookup",
            "no-stats-sessions-indexed-key-keeps-estimate",
            "no-stats-sessions-unindexed-key-estimate",
            "no-stats-reads-indexed-key-keeps-estimate",
            "no-stats-reads-unindexed-key-estimate",
            "analyzed-clicks-indexed-key-keeps-estimate",
            "analyzed-clicks-unindexed-key-estimate",
            "analyzed-loans-unique-key-estimate",
        ],
    )


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v"]))
