#!/usr/bin/env bash
# test-setup.sh — sourced before the verifier runs (verifier phase, network up,
# but the image already baked the full dependency closure so this stays offline).
#
# Pre-warms the cargo targets the verifier builds on, so the verifier's own
# cargo invocations don't pay a full cold compile inside their time budget:
#   - turso_core test binary (unit/behavioral tests over the optimizer)
#   - the sqltest conformance runner (used to assert EXPLAIN QUERY PLAN / plan
#     snapshots against the Rust backend)
# The pinned toolchain (rust-toolchain.toml at /repo/turso, channel 1.88) is
# already installed in the image; cargo uses it on first invocation.
set -euo pipefail

cd /repo/turso

echo "[test-setup] rustc:  $(rustc --version 2>&1 | head -1)"
echo "[test-setup] cargo:  $(cargo --version 2>&1 | head -1)"
echo "[test-setup] repo:   /repo/turso @ $(git rev-parse --short HEAD 2>/dev/null || echo '?')"

# Pre-build the turso_core test binary (no run) so subsequent `cargo test
# -p turso_core ...` is incremental. Loud: log + fail on error.
echo "[test-setup] pre-building turso_core test binary..."
cargo test -p turso_core --no-run > /tmp/test-setup-core.log 2>&1 \
    || { tail -80 /tmp/test-setup-core.log; exit 1; }

# Pre-build the sqltest runner used to execute .sqltest corpora on the rust backend.
echo "[test-setup] pre-building sqltest runner..."
cargo build --manifest-path testing/sqltest/Cargo.toml --bin sqltest \
    > /tmp/test-setup-sqltest.log 2>&1 \
    || { tail -80 /tmp/test-setup-sqltest.log; exit 1; }

echo "[test-setup] setup complete."
