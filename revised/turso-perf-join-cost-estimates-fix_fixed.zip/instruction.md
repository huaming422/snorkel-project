## Task

A bunch of our analytic queries got very slow, and they all share one WHERE shape: an OR of AND groups where each group pins columns on two joined tables, roughly `(a.x = 1 AND b.y = 2) OR (a.x = 2 AND b.y = 1)`.
Each group on its own is a fast lookup.
Put them behind the OR and the planner reads every row of a table, even when the column the groups pin on that table has an index of its own, and its row estimates for the join end up far off, so it also picks a poor join order.
Where a group pins two columns of one table, only one of them is indexed.
Fixing the order with CROSS JOIN doesn't help: EXPLAIN QUERY PLAN still shows a full scan of the first table.
It happens on databases we've run ANALYZE on and on ones we never analyzed, and both cases need to get faster.

Not every OR like this is slow today, and the good ones have to stay good.
When each group pins both leading columns of one two-column index, say `(t.x = 1 AND t.y = 10) OR (t.x = 2 AND t.y = 20)` with an index `t_xy` on `t(x, y)`, EXPLAIN QUERY PLAN shows `MULTI-INDEX OR t (t_xy, t_xy)`, one exact lookup per group.
We get that today on a single table and on such a table joined to another one, and it should stay that way.

The same reports turned up a second estimate problem in Q7-style join chains, for example `a CROSS JOIN b ON b.id = a.b_id CROSS JOIN c ON c.k = b.k CROSS JOIN d ON d.id = c.d_id`.
Adding a plain, non-unique index on `b.k`, alone or as the first column of a wider index, changes how the planner treats `c`, even though the pinned order never reads that index.
On analyzed tables it can turn the plan line for `c` from an index lookup into a HASH JOIN.
Where the HASH JOIN stays, with or without statistics, EXPLAIN QUERY PLAN FORMAT=JSON shows its rows_per_input about 100 times lower than for the same query without the index.
Without that index the plan and estimate for `c` look right to us, and with it they should come out the same.
A UNIQUE index on `b.k` is a different case, since each `c` row can then match at most one `b` row, and the estimate it gives for that today is fine.

Can you get the planner to use the OR conditions on each table before the join, and stop that index from skewing how the next table is planned?
These are planning changes only, so every query must return exactly the rows it returns today, outer joins included, and UPDATE or DELETE statements with such an OR must change the same rows.
Keep it general, not tuned to one query, table or set of values.
