## Task

A bunch of our analytic queries got very slow, and they all share one WHERE shape: an OR of AND groups where each group pins columns on two joined tables, roughly `(a.x = 1 AND b.y = 2) OR (a.x = 2 AND b.y = 1)`.
Each group on its own is a fast lookup.
Put them behind the OR and the planner reads every row of a table, even when the column the groups pin on that table has an index, and its row estimates for the join end up far off, so it also picks a poor join order.
Fixing the order with CROSS JOIN doesn't help: EXPLAIN QUERY PLAN still shows a full scan of the first table.
It happens on databases we've run ANALYZE on and on ones we never analyzed, and both cases need to get faster.

Can you get the planner to make use of these conditions on each table before the join?
It's a planning change only, so every query must return exactly the rows it returns today, outer joins included, and UPDATE or DELETE statements with such an OR must change the same rows.
Keep it general, not tuned to one query, table or set of values.
