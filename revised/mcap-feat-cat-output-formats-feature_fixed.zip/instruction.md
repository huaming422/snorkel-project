## Task

We want output-format control on `mcap cat`, and one way to render timestamps across the tool.

Give `cat` a `--format` option with the values `text` (the current output, still the default), `ndjson` and `csv`.
CSV export takes its topic from the existing topic selection, and the message's log time, publish time and sequence ride along as metadata columns ahead of the payload fields.

Add a global `--time-format` flag that `cat`, `info` and `list` all honor, with an automatic default plus explicit modes for RFC3339, decimal seconds and integer nanoseconds.

Wire `cat` into the CLI's existing exit-status convention so a run that dropped data is distinguishable from a clean one.

## User stories / requirements

- A topic with one steady payload shape exports as CSV with the metadata columns first, one column per payload field and one row per message, and exits cleanly.
  Columns come from the first exported message only, so a later-only field is dropped, reported on stderr, and the run exits with the warning status.
- Flattening is deterministic, giving sorted dotted names for nested keys, numerically ordered index suffixes for array elements, empty cells for nulls, and standard CSV quoting for text with commas or quotes.
  Colliding names, even against a metadata column, keep one column, and the lost value is reported on stderr with the warning status.
- CSV export takes exactly one topic, so asking for none or for several is refused with a non-zero exit before anything reaches stdout.
  A topic missing from the recording is an error exit, while a real topic with nothing in the chosen time range just warns on stderr, prints no table, and exits 0.
- In CSV and ndjson output the message times are full RFC3339 UTC strings with nine fractional digits under the default time format, whether the value is near the epoch or a real wall-clock time.
  Machine output never falls back to a bare number the way human-readable output may.
- The global time-format option reaches the `cat` text lines, `info`, and both the `list chunks` and `list attachments` tables.
  By default, human output shows wall-clock times as calendar dates and near-epoch times as decimal seconds, and each explicit mode renders those same timestamps its own way everywhere.
- Under the default time format one command never mixes the two human forms, so the first timestamp it prints sets the form for the rest of its output.
  A recording whose clock starts near zero and jumps to wall-clock time partway through (a GPS lock, say) stays in decimal seconds, and output whose first time is a calendar date keeps calendar dates for later near-epoch values.
- Newline-delimited JSON decodes by the channel's message encoding: a JSON channel gives one object per message with today's `--json` fields, and an undecodable encoding stops with an error and no output.
  `--json` stays as a synonym with a deprecation notice on stderr, and pairing it with `--format` is a usage error with no output.
