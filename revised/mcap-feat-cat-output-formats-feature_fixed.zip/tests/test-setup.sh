#!/usr/bin/env bash
# Verifier setup for mcap-feat-cat-output-formats.
# No services to start and no data to seed: the image pre-warms the cargo
# cache (including the new `csv`/`csv-core` crates) and the verifier stack is
# baked into /opt/tooling/venv. The Modal sandbox starts a fresh shell per
# phase, so re-export the toolchain paths here.
set -euo pipefail

export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
export PATH="$CARGO_HOME/bin:$PATH"

rustc --version >/dev/null 2>&1 || {
    echo "ERROR: rustc not found on PATH (CARGO_HOME=$CARGO_HOME)" >&2
    exit 1
}
cargo --version >/dev/null 2>&1 || {
    echo "ERROR: cargo not found on PATH" >&2
    exit 1
}

# Canonical verifier interpreter (baked, offline). Only assert its presence;
# never install a second verifier stack here.
VERIFIER_PYTHON="${VERIFIER_PYTHON:-/opt/tooling/venv/bin/python}"
if [ -x "$VERIFIER_PYTHON" ]; then
    echo "[test-setup] verifier python: $("$VERIFIER_PYTHON" --version 2>&1 | head -1)"
else
    echo "[test-setup] WARN: verifier python not found at $VERIFIER_PYTHON" >&2
fi

echo "[test-setup] rustc:          $(rustc --version 2>&1 | head -1)"
echo "[test-setup] cargo:          $(cargo --version 2>&1 | head -1)"
echo "[test-setup] workspace root: /repo/mcap"
echo "[test-setup] setup complete."
