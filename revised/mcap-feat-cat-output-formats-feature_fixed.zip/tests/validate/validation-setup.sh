#!/usr/bin/env bash
# Validation setup for mcap-feat-cat-output-formats.
#
# The cargo-test driver writes each story's test file into the CLI package's
# tests/ directory together with a generated `validation_params.rs` helper that
# derives `serde::Deserialize`. The CLI package depends on `serde_json` but not
# on `serde` (with derive) directly, so the helper would fail to compile. This
# script adds `serde` as a dev-dependency of the CLI package (the version is
# already in the committed lockfile transitively, so this resolves offline) and
# pre-warms the test build.
#
# IMPORTANT: test.sh *sources* this file inside `source ... || true`. Two
# consequences shape the style below:
#   * An `exit` here would terminate the whole grading script before any reward
#     file is written (the `|| true` cannot catch `exit`). So this script never
#     calls `exit`; it uses `return` for early-out, which the `|| true` absorbs,
#     letting test.sh proceed to write a reward even if setup has a problem.
#   * `set -e` is neutralized anyway by the enclosing `|| true`, so we do not
#     rely on it; failures are checked explicitly and reported loudly.
set -uo pipefail

# Pin the toolchain ahead of any stray cargo/rustc on PATH, and reuse the
# image's warm cargo cache + shared target dir (a fresh shell per phase does
# not inherit exported vars).
export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
export PATH="$CARGO_HOME/bin:$PATH"
export CARGO_NET_OFFLINE=true

REPO_DIR="/repo/${REPO_NAME:-mcap}"
CLI_MANIFEST="$REPO_DIR/rust/cli/Cargo.toml"

echo "[validation-setup] rustc: $(rustc --version 2>&1 | head -1)"
echo "[validation-setup] cargo: $(cargo --version 2>&1 | head -1)"

if [ ! -f "$CLI_MANIFEST" ]; then
    echo "ERROR: CLI manifest not found at $CLI_MANIFEST" >&2
    return 1 2>/dev/null || exit 1
fi

# Add serde (with derive) as a dev-dependency of the CLI package if it is not
# already declared under [dev-dependencies]. serde 1.x (and serde_derive) are in
# the committed lockfile transitively, so an offline resolve has the crates it
# needs. Edit the manifest directly (rather than `cargo add`) to stay
# deterministic across cargo versions. This edits Cargo.toml and therefore
# dirties Cargo.lock, so the build step below must NOT pass `--locked`.
if ! awk '/^\[dev-dependencies\]/{f=1; next} /^\[/{f=0} f && /^serde[[:space:]]*=/{found=1} END{exit !found}' "$CLI_MANIFEST"; then
    if grep -q '^\[dev-dependencies\]' "$CLI_MANIFEST"; then
        awk '
            /^\[dev-dependencies\]/ && !done {
                print
                print "serde = { version = \"1\", features = [\"derive\"] }"
                done = 1
                next
            }
            { print }
        ' "$CLI_MANIFEST" > "$CLI_MANIFEST.tmp" && mv "$CLI_MANIFEST.tmp" "$CLI_MANIFEST"
    else
        printf '\n[dev-dependencies]\nserde = { version = "1", features = ["derive"] }\n' >> "$CLI_MANIFEST"
    fi
    echo "[validation-setup] added serde (derive) dev-dependency to rust/cli"
else
    echo "[validation-setup] serde dev-dependency already present"
fi

# Pre-warm: compile the CLI package's test target so story runs stay well under
# the per-story timeout. Offline (cache is warm) but NOT --locked: we just added
# a dependency edge, so cargo must be free to update Cargo.lock from the cache.
# This matches the story runner, which also invokes `cargo test` without
# --locked. A failure here is reported loudly but does not abort grading; the
# per-story compile would surface the same error against the applied solution.
echo "[validation-setup] pre-warming cargo test build (offline)..."
if ! ( cd "$REPO_DIR" && cargo test -p mcap-cli --offline --no-run ); then
    echo "ERROR: offline test build failed; the story harness may not compile" >&2
    return 1 2>/dev/null || exit 1
fi

# Smoke guard: the built binary must run (the Dockerfile baked a release/debug
# build; the stories drive it via CARGO_BIN_EXE_mcap, but a runnable binary here
# is a cheap canary that the toolchain + cache are intact).
BIN="$CARGO_TARGET_DIR/debug/mcap"
if [ -x "$BIN" ]; then
    "$BIN" --version >/dev/null 2>&1 \
        && echo "[validation-setup] smoke: $BIN --version OK" \
        || echo "[validation-setup] WARN: $BIN present but --version failed" >&2
else
    echo "[validation-setup] note: $BIN not present yet (stories build via cargo test)"
fi

echo "[validation-setup] done. workspace=$REPO_DIR cli=rust/cli"
