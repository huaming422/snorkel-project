"""Build-and-contract gate for mcap-feat-cat-output-formats.

Everything here goes through pre-existing stable interfaces: the cargo build,
the program's own clap-generated ``--help`` text, and the built ``mcap`` binary
run against a small recording. No symbol the implementation introduces is
imported or named, and no column or mode spelling the implementation is free
to choose is asserted.

1. The CLI package builds, which is the floor for every other check.

2. The option surface named in the task is registered: a ``--format`` option
   on ``cat`` offering the tabular and json-lines modes, and a global
   ``--time-format`` option. Those three spellings are the public contract
   stated in the task description.

3. Two end-to-end runs on a fixed recording: the default text output still
   lists one line per message, and a single-topic CSV export yields a header
   that ends with the payload fields, one row per message, and RFC3339
   timestamp cells. Edge cases are covered by the validation stories, which
   adapt to the implementation's shape.

The recording is an MCAP file produced by the repository's own Rust writer and
embedded as base64 so this file stays self-contained. It holds one json channel
on topic ``/example`` with two small flat object payloads logged at exactly one
and two seconds after the epoch.
"""

from __future__ import annotations

import base64
import csv
import io
import os
import re
import subprocess
from pathlib import Path

import pytest

REPO_DIR = Path(f"/repo/{os.environ.get('REPO_NAME', 'mcap')}")
CLI_PACKAGE = "mcap-cli"
CAT_SUBCOMMAND = "cat"
TOPIC = "/example"

# Two messages: {"a":1,"b":2} at 1 s and {"a":3,"b":4} at 2 s (log and publish time).
RECORDING_B64 = "iU1DQVAwDQoBGAAAAAAAAAAAAAAAEAAAAG1jYXAtcnVzdC8wLjI1LjAGtgAAAAAAAAAAypo7AAAAAACUNXcAAAAAtgAAAAAAAAB7/5RJBAAAAHpzdGSKAAAAAAAAACi1L/0AWA0EAGKGGCRwa9IB/P9//qseKhLrAO1UE7Zb/l93HYrnmuUvI8DAL+/fSAqvgXV9GBTHpXkLrOujwLZeD0zmPwT+nUT8g9lsg/NqQRm5qdikLFavv9CkjEDVZKqin5ASSmoVyC+YnQAEDABAAEgAesC6noq/4oJMUZAyBfL9aqABAw5gCAcmAAAAAAAAAAEAIAAAAADKmjsAAAAAXgAAAAAAAAAAlDV3AAAAAIoAAAAAAAAADwQAAAAAAAAAgZ3KwAMwAAAAAAAAAAEABwAAAEV4YW1wbGUKAAAAanNvbnNjaGVtYREAAAB7InR5cGUiOiJvYmplY3QifQQcAAAAAAAAAAEAAQAIAAAAL2V4YW1wbGUEAAAAanNvbgAAAAALOAAAAAAAAAACAAAAAAAAAAEAAQAAAAAAAAAAAAAAAQAAAADKmjsAAAAAAJQ1dwAAAAAKAAAAAQACAAAAAAAAAAhOAAAAAAAAAADKmjsAAAAAAJQ1dwAAAAApAAAAAAAAAL8AAAAAAAAACgAAAAEA6AAAAAAAAAAvAAAAAAAAAAQAAAB6c3RkigAAAAAAAAC2AAAAAAAAAA4RAAAAAAAAAAMkAQAAAAAAADkAAAAAAAAADhEAAAAAAAAABF0BAAAAAAAAJQAAAAAAAAAOEQAAAAAAAAALggEAAAAAAABBAAAAAAAAAA4RAAAAAAAAAAjDAQAAAAAAAFcAAAAAAAAAAhQAAAAAAAAAJAEAAAAAAAAaAgAAAAAAALyA1x2JTUNBUDANCg=="

RFC3339_ONE_SECOND = "1970-01-01T00:00:01.000000000Z"
RFC3339_RE = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{9}Z$")


def _run(cmd: list[str], *, timeout: int) -> subprocess.CompletedProcess:
    return subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=timeout,
        cwd=str(REPO_DIR),
        check=False,
    )


def _build() -> subprocess.CompletedProcess:
    """Build the CLI package offline against the committed lockfile."""
    return _run(
        [
            "cargo",
            "build",
            "-p",
            CLI_PACKAGE,
            "--locked",
            "--offline",
        ],
        timeout=840,
    )


@pytest.fixture(scope="module")
def built() -> subprocess.CompletedProcess:
    proc = _build()
    assert proc.returncode == 0, (
        f"`cargo build -p {CLI_PACKAGE} --locked --offline` failed (exit "
        f"{proc.returncode}). The package must still compile.\n"
        f"--- stderr tail ---\n{proc.stderr[-3000:]}"
    )
    return proc


def _binary() -> Path:
    """Resolve the binary from the shared cargo target dir.

    This exercises the artifact `built` just produced rather than rebuilding.
    """
    target = Path(os.environ.get("CARGO_TARGET_DIR", str(REPO_DIR / "target")))
    binary = target / "debug" / "mcap"
    assert binary.exists(), f"built `mcap` binary not found at {binary}"
    return binary


def _help_text(built: subprocess.CompletedProcess, *args: str) -> str:
    proc = _run([str(_binary()), *args, "--help"], timeout=120)
    return proc.stdout + "\n" + proc.stderr


def _mcap(*args: str) -> subprocess.CompletedProcess:
    return _run([str(_binary()), *args], timeout=120)


def _nonempty_lines(text: str) -> list[str]:
    return [line for line in text.splitlines() if line.strip()]


def _csv_records(text: str) -> list[list[str]]:
    """Parse CSV output per RFC 4180, so quoted fields are read correctly."""
    return [record for record in csv.reader(io.StringIO(text)) if record]


@pytest.fixture(scope="module")
def recording(tmp_path_factory: pytest.TempPathFactory) -> Path:
    """Write the embedded recording to disk once per module."""
    path = tmp_path_factory.mktemp("mcap-fixtures") / "recording.mcap"
    path.write_bytes(base64.b64decode(RECORDING_B64))
    return path


def test_cli_package_builds(built: subprocess.CompletedProcess) -> None:
    """The CLI package compiles with the feature applied."""
    assert built.returncode == 0


def test_cat_exposes_format_option(built: subprocess.CompletedProcess) -> None:
    """`mcap cat --help` advertises the new --format option and its machine modes."""
    help_text = _help_text(built, CAT_SUBCOMMAND).lower()
    assert "--format" in help_text, (
        "`mcap cat --help` does not mention a --format option. The task adds a "
        "--format option to the cat subcommand."
    )
    # The two machine-output modes named in the task. `text` is the default
    # and may be implied rather than listed, so it is not required here.
    for mode in ("csv", "ndjson"):
        assert mode in help_text, (
            f"`mcap cat --help` does not advertise the '{mode}' output mode of "
            "--format."
        )


def test_global_time_format_option(built: subprocess.CompletedProcess) -> None:
    """`mcap --help` advertises the global --time-format option.

    The task names the flag but leaves the spelling of its modes to the
    implementation, so only the flag itself is required here.
    """
    help_text = _help_text(built).lower()
    assert "--time-format" in help_text, (
        "`mcap --help` does not mention a global --time-format option. The task "
        "adds --time-format spanning cat, info, and list."
    )


def test_cat_text_output_still_lists_messages(
    built: subprocess.CompletedProcess, recording: Path
) -> None:
    """The default text output keeps working: one line per message, exit 0.

    This guards the pre-existing behavior while the output path is reworked.
    The timestamp spelling is deliberately not pinned here, only the per-message
    line structure.
    """
    proc = _mcap(CAT_SUBCOMMAND, str(recording))
    assert proc.returncode == 0, f"cat exited {proc.returncode}: {proc.stderr}"
    lines = _nonempty_lines(proc.stdout)
    assert len(lines) == 2, f"expected one text line per message, got: {lines}"
    for line in lines:
        assert TOPIC in line, f"text line does not name the topic: {line!r}"


def test_cat_csv_exports_single_topic_table(
    built: subprocess.CompletedProcess, recording: Path
) -> None:
    """A uniform single-topic recording exports as a CSV table.

    The header ends with the two payload fields in sorted order after however
    many metadata columns the implementation emits. There is one row per
    message. Under the default time format the time cells are RFC3339 with
    nine fractional digits, even for a near-epoch value, so the first row
    carries the RFC3339 rendering of one second and never the bare count.
    """
    proc = _mcap(
        CAT_SUBCOMMAND, str(recording), "--format=csv", "--topics", TOPIC
    )
    assert proc.returncode == 0, f"csv export exited {proc.returncode}: {proc.stderr}"
    records = _csv_records(proc.stdout)
    assert len(records) == 3, f"expected header plus two rows, got {len(records)} records"
    header, first_row, second_row = records
    assert header[-2:] == ["a", "b"], f"header should end with the payload fields: {header}"
    assert len(header) > 2, f"header carries no metadata columns: {header}"
    assert len(first_row) == len(header), f"row width differs from header: {first_row}"
    assert first_row[-2:] == ["1", "2"], f"unexpected payload cells: {first_row[-2:]}"
    assert second_row[-2:] == ["3", "4"], f"unexpected second row: {second_row}"
    time_cells = [cell for cell in first_row if RFC3339_RE.match(cell)]
    assert time_cells and all(cell == RFC3339_ONE_SECOND for cell in time_cells), (
        f"expected RFC3339 time cells equal to {RFC3339_ONE_SECOND}, got {first_row}"
    )
    assert "1000000000" not in first_row, (
        f"a time cell fell back to a bare nanosecond count: {first_row}"
    )
