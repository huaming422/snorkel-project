import {
  mkdirSync,
  mkdtempSync,
  realpathSync,
  rmSync,
  symlinkSync,
  writeFileSync
} from 'node:fs'
import { tmpdir } from 'node:os'
import { dirname, join, sep } from 'node:path'
import { describe, expect, it } from 'vitest'

import { normalizeFilesystemLayout } from '../runtime/src/platform/filesystem-layout.js'
import { seatbeltProfile } from '../runtime/src/platform/macos-isolation.js'

// These run on Linux: the layout normalizer and seatbelt profile generator have
// no macOS host requirement. A darwin-only launch probe like the one in the
// package's own suite cannot run here. Instead the generated profile is
// evaluated below with seatbelt's rule semantics (last matching rule wins) for
// the file operations that matter, so any rule spelling or grouping with the
// same effect is accepted.
const posixIt = it.skipIf(process.platform === 'win32')

const rootLists = ['readOnlyRoots', 'readWriteRoots', 'deniedReadRoots', 'deniedWriteRoots'] as const

const layoutWith = (field: (typeof rootLists)[number], paths: string[]) =>
  normalizeFilesystemLayout({
    readOnlyRoots: [],
    readWriteRoots: [],
    deniedReadRoots: [],
    deniedWriteRoots: [],
    [field]: paths
  })

// The physical path a policy root spelled this way ends up as. Every root list
// must agree on it.
const policyPath = (path: string): string => {
  const answers = rootLists.map((field) => layoutWith(field, [path])[field])
  for (const answer of answers) expect(answer).toEqual(answers[0])
  expect(answers[0]).toHaveLength(1)
  return answers[0]![0]!
}

type Sexp = string | { symbol: string } | { regex: string } | Sexp[]

// Reads a profile into s-expressions. `;` starts a comment that runs to the end
// of the line. In a string, a backslash escapes the next character; a #"..."
// regex keeps its backslashes for the regex engine.
const parseProfile = (profile: string): Sexp[] => {
  const tokens = (
    profile.match(/;[^\n]*|#"(?:[^"\\]|\\.)*"|"(?:[^"\\]|\\.)*"|[()]|[^\s()";]+/g) ?? []
  ).filter((token) => !token.startsWith(';'))
  let index = 0
  const read = (): Sexp => {
    if (index >= tokens.length) throw new Error('Unbalanced seatbelt profile')
    const token = tokens[index++]!
    if (token === ')') throw new Error('Unbalanced seatbelt profile')
    if (token === '(') {
      const list: Sexp[] = []
      while (tokens[index] !== ')') list.push(read())
      index += 1
      return list
    }
    if (token.startsWith('#"')) return { regex: token.slice(2, -1).replace(/\\"/g, '"') }
    if (token.startsWith('"')) {
      const escapes: Record<string, string> = { n: '\n', t: '\t', r: '\r' }
      return token.slice(1, -1).replace(/\\([\s\S])/g, (_, next: string) => escapes[next] ?? next)
    }
    return { symbol: token }
  }
  const forms: Sexp[] = []
  while (index < tokens.length) forms.push(read())
  return forms
}

const symbolOf = (value: Sexp | undefined): string | undefined =>
  value && typeof value === 'object' && 'symbol' in value ? value.symbol : undefined

// true or false when the filter's answer for this path is known here, and
// undefined for a valid filter whose answer depends on something this model
// does not see (an extension, a file mode, a parameter, an entitlement...).
type Match = boolean | undefined

const not = (value: Match): Match => (value === undefined ? undefined : !value)
const all = (values: Match[]): Match =>
  values.includes(false) ? false : values.includes(undefined) ? undefined : true
const any = (values: Match[]): Match =>
  values.includes(true) ? true : values.includes(undefined) ? undefined : false

const show = (value: Sexp): string => JSON.stringify(value)

const filterMatches = (filter: Sexp, path: string, directories: ReadonlySet<string>): Match => {
  // A filter is always a form such as (literal "/path"). A bare string or regex
  // in a rule is not a seatbelt filter, and sandbox-exec rejects the profile.
  if (!Array.isArray(filter)) throw new Error(`Not a seatbelt filter: ${show(filter)}`)
  const [head, ...args] = filter
  const name = symbolOf(head)
  if (name === undefined) throw new Error(`Not a seatbelt filter: ${show(filter)}`)
  const pathArgument = (): string | undefined => {
    const [argument] = args
    if (args.length !== 1) throw new Error(`Malformed seatbelt filter: ${show(filter)}`)
    // A computed argument such as (param "NAME") has no value here.
    if (Array.isArray(argument)) return undefined
    if (typeof argument !== 'string') throw new Error(`Malformed seatbelt filter: ${show(filter)}`)
    return argument
  }
  switch (name) {
    case 'literal': {
      const argument = pathArgument()
      return argument === undefined ? undefined : path === argument
    }
    case 'subpath': {
      const argument = pathArgument()
      if (argument === undefined) return undefined
      return path === argument || path.startsWith(argument.endsWith('/') ? argument : `${argument}/`)
    }
    case 'prefix': {
      const argument = pathArgument()
      return argument === undefined ? undefined : path.startsWith(argument)
    }
    case 'regex': {
      const [argument] = args
      if (args.length !== 1) throw new Error(`Malformed seatbelt filter: ${show(filter)}`)
      if (Array.isArray(argument)) return undefined
      if (typeof argument === 'string') return new RegExp(argument).test(path)
      if (argument && typeof argument === 'object' && 'regex' in argument)
        return new RegExp(argument.regex).test(path)
      throw new Error(`Malformed seatbelt filter: ${show(filter)}`)
    }
    case 'require-not':
      if (args.length !== 1) throw new Error(`Malformed seatbelt filter: ${show(filter)}`)
      return not(filterMatches(args[0]!, path, directories))
    case 'require-all':
      return all(args.map((entry) => filterMatches(entry, path, directories)))
    case 'require-any':
      return any(args.map((entry) => filterMatches(entry, path, directories)))
    case 'vnode-type': {
      const types = args.map(symbolOf)
      if (types.length === 0 || types.includes(undefined))
        throw new Error(`Malformed seatbelt filter: ${show(filter)}`)
      return types.includes(directories.has(path) ? 'DIRECTORY' : 'REGULAR-FILE')
    }
    default:
      // Any other seatbelt filter is accepted; it only matters if the answer
      // for one of the checked operations hinges on it.
      return undefined
  }
}

const operationMatches = (pattern: string, operation: string): boolean =>
  pattern === 'default' ||
  pattern === operation ||
  (pattern.endsWith('*') && operation.startsWith(pattern.slice(0, -1)))

// Decide one file operation on one path: start from deny, and let the last
// rule whose operation and filter both match set the answer. Several filters in
// one rule match when any of them does, as in seatbelt; a (with ...) modifier
// is not a filter. When a rule's match depends on a filter this model cannot
// answer, both outcomes stay possible, and the result is 'undetermined' unless
// a later rule settles it.
const seatbeltDecision = (
  profile: string,
  operation: string,
  path: string,
  directories: ReadonlySet<string>
): 'allow' | 'deny' | 'undetermined' => {
  let possible = new Set<'allow' | 'deny'>(['deny'])
  for (const form of parseProfile(profile)) {
    if (!Array.isArray(form)) continue
    const action = symbolOf(form[0])
    if (action !== 'allow' && action !== 'deny') continue
    const operations: string[] = []
    const filters: Sexp[] = []
    for (const part of form.slice(1)) {
      const name = symbolOf(part)
      if (name !== undefined) operations.push(name)
      else if (!(Array.isArray(part) && symbolOf(part[0]) === 'with')) filters.push(part)
    }
    if (!operations.some((pattern) => operationMatches(pattern, operation))) continue
    const matched =
      filters.length === 0 ? true : any(filters.map((filter) => filterMatches(filter, path, directories)))
    if (matched === true) possible = new Set([action])
    else if (matched === undefined) possible.add(action)
  }
  return possible.size === 1 ? [...possible][0]! : 'undetermined'
}

const ancestorsOf = (path: string): string[] => {
  const result: string[] = []
  for (let current = dirname(path); ; current = dirname(current)) {
    result.push(current)
    if (current === dirname(current)) return result
  }
}

describe('sandbox filesystem path resolution', () => {
  posixIt(
    'anchors a path to the physical target its links point at, not the lexical one',
    () => {
      const root = realpathSync(mkdtempSync(join(tmpdir(), 'os-physical-path-')))
      try {
        mkdirSync(join(root, 'real', 'deep'), { recursive: true })
        symlinkSync(join(root, 'real', 'deep'), join(root, 'alias'))
        symlinkSync(join('real', 'deep'), join(root, 'relative'))
        writeFileSync(join(root, 'real', 'secret'), 'physical')
        writeFileSync(join(root, 'secret'), 'lexical')

        // A policy root spelled across the link and then back up with `..` lands
        // where the kernel lands: <root>/real/secret, never the lexical sibling
        // <root>/secret. The answer is the same in every root list.
        const spelling = `${root}${sep}alias${sep}..${sep}secret`
        expect(policyPath(spelling)).toBe(realpathSync.native(spelling))
        expect(policyPath(spelling)).toBe(join(root, 'real', 'secret'))

        // The same holds for a relative link walked back up two levels.
        const twoLevels = `${root}${sep}relative${sep}..${sep}..${sep}secret`
        expect(policyPath(twoLevels)).toBe(realpathSync.native(twoLevels))
        expect(policyPath(twoLevels)).toBe(join(root, 'secret'))
      } finally {
        rmSync(root, { recursive: true, force: true })
      }
    }
  )

  posixIt(
    'anchors a not-yet-existing leaf to its physical parent and rejects unsafe spellings',
    () => {
      const root = realpathSync(mkdtempSync(join(tmpdir(), 'os-missing-leaf-')))
      try {
        mkdirSync(join(root, 'real', 'deep'), { recursive: true })
        symlinkSync(join(root, 'real', 'deep'), join(root, 'alias'))
        writeFileSync(join(root, 'secret'), 'file')
        symlinkSync(join(root, 'absent'), join(root, 'dangling'))

        // A missing leaf behind a link anchors to the link's physical parent.
        const missing = `${root}${sep}alias${sep}..${sep}new${sep}leaf`
        expect(policyPath(missing)).toBe(
          join(realpathSync.native(`${root}${sep}alias${sep}..`), 'new', 'leaf')
        )
        expect(policyPath(missing)).toBe(join(root, 'real', 'new', 'leaf'))

        // A harmless `.` segment is accepted on a missing path.
        const missingDot = `${root}${sep}missing${sep}.${sep}leaf`
        expect(policyPath(missingDot)).toBe(join(root, 'missing', 'leaf'))
        expect(policyPath(`${root}${sep}missing${sep}.`)).toBe(join(root, 'missing'))

        // Both resolved leaves are kept when one policy list names them together.
        expect([...layoutWith('readWriteRoots', [missingDot, missing]).readWriteRoots].sort()).toEqual(
          [join(root, 'missing', 'leaf'), join(root, 'real', 'new', 'leaf')].sort()
        )

        const unsafe = [
          // `..` through a parent that does not exist.
          `${root}${sep}missing${sep}..${sep}leaf`,
          // A file standing in for a directory ancestor.
          join(root, 'secret', 'leaf'),
          // A link whose target does not exist, with and without a `.` segment.
          join(root, 'dangling', 'leaf'),
          `${root}${sep}dangling${sep}.${sep}leaf`
        ]
        for (const path of unsafe) {
          // A policy that names such a path, as a grant or as a denial, is refused.
          for (const field of rootLists) expect(() => layoutWith(field, [path])).toThrow()
        }
      } finally {
        rmSync(root, { recursive: true, force: true })
      }
    }
  )

  posixIt.each([true, false])(
    'keeps every directory above a protected path in place while sibling writes stay allowed (folder restriction %s)',
    (restricted) => {
      const root = realpathSync(mkdtempSync(join(tmpdir(), 'os-deny-ancestor-')))
      try {
        const first = join(root, 'w1')
        const second = join(root, 'w2')
        const unreadable = join(first, 'a', 'b', 'secret')
        const unwritable = join(second, 'c', 'd', 'locked')
        mkdirSync(dirname(unreadable), { recursive: true })
        mkdirSync(dirname(unwritable), { recursive: true })
        mkdirSync(join(first, 'other'))
        writeFileSync(unreadable, 'fixture')
        writeFileSync(unwritable, 'fixture')

        const profile = seatbeltProfile({
          command: 'true',
          shell: '/bin/sh',
          gatewayPort: 3128,
          gatewayCredentials: { username: 'fixture', password: 'fixture' },
          env: { PATH: '/usr/bin:/bin' },
          filesystem: {
            ...(restricted ? {} : { restrictFolders: false }),
            privateRoot: root,
            readOnlyRoots: [],
            readWriteRoots: [first, second],
            deniedReadRoots: [unreadable],
            deniedWriteRoots: [unwritable]
          }
        })
        const directories = new Set([
          ...ancestorsOf(unreadable),
          ...ancestorsOf(unwritable),
          join(first, 'other')
        ])
        const decide = (operation: string, path: string): string =>
          `${operation} ${path}: ${seatbeltDecision(profile, operation, path, directories)}`

        // No directory above either protected path can be removed or renamed
        // away, including the writable roots themselves (another writable root
        // could take them in). The filesystem root cannot be moved anyway.
        for (const target of [unreadable, unwritable]) {
          for (const ancestor of ancestorsOf(target).filter((path) => path !== dirname(path))) {
            expect(decide('file-write-unlink', ancestor)).toBe(
              `file-write-unlink ${ancestor}: deny`
            )
          }
        }

        // The protected paths stay protected.
        for (const target of [unreadable, unwritable]) {
          for (const operation of ['file-write-data', 'file-write-unlink', 'file-write-create']) {
            expect(decide(operation, target)).toBe(`${operation} ${target}: deny`)
          }
        }
        expect(decide('file-read-data', unreadable)).toBe(`file-read-data ${unreadable}: deny`)

        // Ordinary work next to them is still allowed.
        for (const sibling of [
          join(first, 'a', 'b', 'sibling.txt'),
          join(first, 'a', 'sibling.txt'),
          join(first, 'a', 'new-folder'),
          join(first, 'other', 'file.txt'),
          join(second, 'c', 'd', 'sibling.txt')
        ]) {
          for (const operation of ['file-write-create', 'file-write-data', 'file-write-unlink']) {
            expect(decide(operation, sibling)).toBe(`${operation} ${sibling}: allow`)
          }
        }
      } finally {
        rmSync(root, { recursive: true, force: true })
      }
    }
  )
})
