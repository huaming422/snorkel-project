import {
  mkdirSync,
  mkdtempSync,
  realpathSync,
  rmSync,
  symlinkSync,
  writeFileSync
} from 'node:fs'
import { tmpdir } from 'node:os'
import { dirname, join, sep } from 'node:path'
import { describe, expect, it } from 'vitest'

import {
  absolutePhysicalPath,
  hiddenByFilesystemLayout,
  normalizeFilesystemLayout
} from '../runtime/src/platform/filesystem-layout.js'
import { seatbeltProfile } from '../runtime/src/platform/macos-isolation.js'
import { ViolationLog } from '../runtime/src/gateway/violation-log.js'

// These run on Linux: the resolver, layout normalizer and seatbelt profile
// generator are all pure/filesystem helpers with no macOS host requirement.
// A darwin-only launch probe like the one in the package's own suite cannot
// run here. Instead the generated profile is evaluated below with
// seatbelt's rule semantics (last matching rule wins) for the writes that
// matter, so any rule spelling or grouping with the same effect is accepted.
const posixIt = it.skipIf(process.platform === 'win32')

type Sexp = string | { symbol: string } | { regex: string } | Sexp[]

const parseProfile = (profile: string): Sexp[] => {
  const tokens =
    profile.match(/#"(?:[^"\\]|\\.)*"|"(?:[^"\\]|\\.)*"|[()]|[^\s()"]+/g) ?? []
  let index = 0
  const read = (): Sexp => {
    const token = tokens[index++]!
    if (token === '(') {
      const list: Sexp[] = []
      while (tokens[index] !== ')') {
        if (index >= tokens.length) throw new Error('Unbalanced seatbelt profile')
        list.push(read())
      }
      index += 1
      return list
    }
    if (token.startsWith('#"')) return { regex: JSON.parse(token.slice(1)) as string }
    if (token.startsWith('"')) return JSON.parse(token) as string
    return { symbol: token }
  }
  const forms: Sexp[] = []
  while (index < tokens.length) forms.push(read())
  return forms
}

const symbolOf = (value: Sexp | undefined): string | undefined =>
  value && typeof value === 'object' && 'symbol' in value ? value.symbol : undefined

const filterMatches = (filter: Sexp, path: string, directories: ReadonlySet<string>): boolean => {
  if (typeof filter === 'string') return path === filter
  if (!Array.isArray(filter)) throw new Error(`Unsupported seatbelt filter ${JSON.stringify(filter)}`)
  const [head, ...args] = filter
  const argument = args[0]
  switch (symbolOf(head)) {
    case 'literal':
      return path === argument
    case 'subpath':
      return (
        typeof argument === 'string' &&
        (path === argument || path.startsWith(argument.endsWith('/') ? argument : `${argument}/`))
      )
    case 'prefix':
      return typeof argument === 'string' && path.startsWith(argument)
    case 'regex':
      return (
        typeof argument === 'object' &&
        argument !== null &&
        'regex' in argument &&
        new RegExp(argument.regex).test(path)
      )
    case 'require-not':
      return !filterMatches(argument!, path, directories)
    case 'require-all':
      return args.every((entry) => filterMatches(entry, path, directories))
    case 'require-any':
      return args.some((entry) => filterMatches(entry, path, directories))
    case 'vnode-type':
      return symbolOf(argument) === (directories.has(path) ? 'DIRECTORY' : 'REGULAR-FILE')
    default:
      throw new Error(`Unsupported seatbelt filter ${JSON.stringify(filter)}`)
  }
}

const operationMatches = (pattern: string, operation: string): boolean =>
  pattern === 'default' ||
  pattern === operation ||
  (pattern.endsWith('*') && operation.startsWith(pattern.slice(0, -1)))

// Decide one file operation on one path: start from deny, and let the last
// rule whose operation and filter both match set the answer.
const seatbeltDecision = (
  profile: string,
  operation: string,
  path: string,
  directories: ReadonlySet<string>
): 'allow' | 'deny' => {
  let decision: 'allow' | 'deny' = 'deny'
  for (const form of parseProfile(profile)) {
    if (!Array.isArray(form)) continue
    const action = symbolOf(form[0])
    if (action !== 'allow' && action !== 'deny') continue
    const operations: string[] = []
    const filters: Sexp[] = []
    for (const part of form.slice(1)) {
      const name = symbolOf(part)
      if (name !== undefined) operations.push(name)
      else filters.push(part)
    }
    if (!operations.some((pattern) => operationMatches(pattern, operation))) continue
    if (filters.every((filter) => filterMatches(filter, path, directories))) decision = action
  }
  return decision
}

const ancestorsOf = (path: string): string[] => {
  const result: string[] = []
  for (let current = dirname(path); ; current = dirname(current)) {
    result.push(current)
    if (current === dirname(current)) return result
  }
}

describe('sandbox filesystem path resolution', () => {
  posixIt(
    'anchors a path to the physical target its links point at, not the lexical one',
    () => {
      const root = realpathSync(mkdtempSync(join(tmpdir(), 'os-physical-path-')))
      try {
        mkdirSync(join(root, 'real', 'deep'), { recursive: true })
        symlinkSync(join(root, 'real', 'deep'), join(root, 'alias'))
        symlinkSync(join('real', 'deep'), join(root, 'relative'))
        writeFileSync(join(root, 'real', 'secret'), 'physical')
        writeFileSync(join(root, 'secret'), 'lexical')

        // A spelling that crosses the link and then walks `..` lands where the
        // kernel lands: <root>/real/secret, never the lexical sibling <root>/secret.
        const spelling = `${root}${sep}alias${sep}..${sep}secret`
        expect(absolutePhysicalPath(spelling)).toBe(realpathSync.native(spelling))
        expect(absolutePhysicalPath(spelling)).toBe(join(root, 'real', 'secret'))

        // The same holds for a relative link walked back up two levels.
        const twoLevels = `${root}${sep}relative${sep}..${sep}..${sep}secret`
        expect(absolutePhysicalPath(twoLevels)).toBe(realpathSync.native(twoLevels))
        expect(absolutePhysicalPath(twoLevels)).toBe(join(root, 'secret'))

        // Policy roots spelled through the link follow the same answer.
        expect(
          normalizeFilesystemLayout({
            readOnlyRoots: [],
            readWriteRoots: [],
            deniedReadRoots: [spelling],
            deniedWriteRoots: []
          }).deniedReadRoots
        ).toEqual([join(root, 'real', 'secret')])
      } finally {
        rmSync(root, { recursive: true, force: true })
      }
    }
  )

  posixIt(
    'anchors a not-yet-existing leaf to its physical parent and rejects unsafe spellings',
    () => {
      const root = realpathSync(mkdtempSync(join(tmpdir(), 'os-missing-leaf-')))
      try {
        mkdirSync(join(root, 'real', 'deep'), { recursive: true })
        symlinkSync(join(root, 'real', 'deep'), join(root, 'alias'))
        writeFileSync(join(root, 'secret'), 'file')
        symlinkSync(join(root, 'absent'), join(root, 'dangling'))

        // A missing leaf behind a link anchors to the link's physical parent.
        const missing = `${root}${sep}alias${sep}..${sep}new${sep}leaf`
        expect(absolutePhysicalPath(missing)).toBe(
          join(realpathSync.native(`${root}${sep}alias${sep}..`), 'new', 'leaf')
        )
        expect(absolutePhysicalPath(missing)).toBe(join(root, 'real', 'new', 'leaf'))

        // A harmless `.` segment is accepted on a missing path.
        const missingDot = `${root}${sep}missing${sep}.${sep}leaf`
        expect(absolutePhysicalPath(missingDot)).toBe(join(root, 'missing', 'leaf'))
        expect(absolutePhysicalPath(`${root}${sep}missing${sep}.`)).toBe(join(root, 'missing'))

        // The resolved leaf propagates into normalized policy roots unchanged.
        expect(
          normalizeFilesystemLayout({
            readOnlyRoots: [],
            readWriteRoots: [missingDot, missing],
            deniedReadRoots: [],
            deniedWriteRoots: []
          }).readWriteRoots
        ).toEqual([join(root, 'missing', 'leaf'), join(root, 'real', 'new', 'leaf')])

        const unsafe = [
          // `..` through a parent that does not exist.
          `${root}${sep}missing${sep}..${sep}leaf`,
          // A file standing in for a directory ancestor.
          join(root, 'secret', 'leaf'),
          // A link whose target does not exist, with and without a `.` segment.
          join(root, 'dangling', 'leaf'),
          `${root}${sep}dangling${sep}.${sep}leaf`
        ]
        for (const path of unsafe) {
          // A policy that names such a path, as a grant or as a denial, is refused.
          for (const field of ['readWriteRoots', 'readOnlyRoots', 'deniedReadRoots', 'deniedWriteRoots']) {
            expect(() =>
              normalizeFilesystemLayout({
                readOnlyRoots: [],
                readWriteRoots: [],
                deniedReadRoots: [],
                deniedWriteRoots: [],
                [field]: [path]
              })
            ).toThrow()
          }
        }
      } finally {
        rmSync(root, { recursive: true, force: true })
      }
    }
  )

  posixIt(
    'does not blame the sandbox for a missing-file error on a path that cannot exist',
    () => {
      const root = realpathSync(mkdtempSync(join(tmpdir(), 'os-diagnostic-path-')))
      try {
        writeFileSync(join(root, 'file'), 'fixture')
        symlinkSync(join(root, 'absent'), join(root, 'dangling'))
        const layout = normalizeFilesystemLayout({
          privateRoot: root,
          readOnlyRoots: [],
          readWriteRoots: [],
          deniedReadRoots: [],
          deniedWriteRoots: []
        })
        const hidden = (path: string): boolean => hiddenByFilesystemLayout(layout, path)
        const log = new ViolationLog()
        const network = 'deny network-outbound example.org:443 (not approved)'
        for (const path of [
          join(root, 'file', 'leaf'),
          join(root, 'dangling', 'leaf'),
          `${root}${sep}missing${sep}..${sep}leaf`
        ]) {
          const stderr = `cat: '${path}': No such file or directory`
          expect(log.attach('plain', stderr, hidden)).toBe(stderr)
          log.record('recorded', network)
          const annotated = log.attach('recorded', stderr, hidden)
          expect(annotated).toContain(stderr)
          expect(annotated).toContain(network)
          expect(annotated).not.toContain('OPEN_SCIENCE_FILESYSTEM_ACCESS_BLOCKED')
        }

        // A real missing path inside the hidden private folder is still reported
        // as a sandbox block.
        const privateMissing = join(root, 'not-granted.txt')
        const annotated = log.attach(
          'private',
          `cat: '${privateMissing}': No such file or directory`,
          hidden
        )
        expect(annotated).toContain(`OPEN_SCIENCE_FILESYSTEM_ACCESS_BLOCKED: ${privateMissing}`)
      } finally {
        rmSync(root, { recursive: true, force: true })
      }
    }
  )

  posixIt.each([true, false])(
    'keeps every directory above a protected path in place while sibling writes stay allowed (folder restriction %s)',
    (restricted) => {
      const root = realpathSync(mkdtempSync(join(tmpdir(), 'os-deny-ancestor-')))
      try {
        const first = join(root, 'w1')
        const second = join(root, 'w2')
        const unreadable = join(first, 'a', 'b', 'secret')
        const unwritable = join(second, 'c', 'd', 'locked')
        mkdirSync(dirname(unreadable), { recursive: true })
        mkdirSync(dirname(unwritable), { recursive: true })
        mkdirSync(join(first, 'other'))
        writeFileSync(unreadable, 'fixture')
        writeFileSync(unwritable, 'fixture')

        const profile = seatbeltProfile({
          command: 'true',
          shell: '/bin/sh',
          gatewayPort: 3128,
          gatewayCredentials: { username: 'fixture', password: 'fixture' },
          env: { PATH: '/usr/bin:/bin' },
          filesystem: {
            ...(restricted ? {} : { restrictFolders: false }),
            privateRoot: root,
            readOnlyRoots: [],
            readWriteRoots: [first, second],
            deniedReadRoots: [unreadable],
            deniedWriteRoots: [unwritable]
          }
        })
        const directories = new Set([
          ...ancestorsOf(unreadable),
          ...ancestorsOf(unwritable),
          join(first, 'other')
        ])
        const decide = (operation: string, path: string): string =>
          `${operation} ${path}: ${seatbeltDecision(profile, operation, path, directories)}`

        // No directory above either protected path can be removed or renamed
        // away, including the writable roots themselves (another writable root
        // could take them in). The filesystem root cannot be moved anyway.
        for (const target of [unreadable, unwritable]) {
          for (const ancestor of ancestorsOf(target).filter((path) => path !== dirname(path))) {
            expect(decide('file-write-unlink', ancestor)).toBe(
              `file-write-unlink ${ancestor}: deny`
            )
          }
        }

        // The protected paths stay protected.
        for (const target of [unreadable, unwritable]) {
          for (const operation of ['file-write-data', 'file-write-unlink', 'file-write-create']) {
            expect(decide(operation, target)).toBe(`${operation} ${target}: deny`)
          }
        }
        expect(decide('file-read-data', unreadable)).toBe(`file-read-data ${unreadable}: deny`)

        // Ordinary work next to them is still allowed.
        for (const sibling of [
          join(first, 'a', 'b', 'sibling.txt'),
          join(first, 'a', 'sibling.txt'),
          join(first, 'a', 'new-folder'),
          join(first, 'other', 'file.txt'),
          join(second, 'c', 'd', 'sibling.txt')
        ]) {
          for (const operation of ['file-write-create', 'file-write-data', 'file-write-unlink']) {
            expect(decide(operation, sibling)).toBe(`${operation} ${sibling}: allow`)
          }
        }
      } finally {
        rmSync(root, { recursive: true, force: true })
      }
    }
  )
})
