import { mkdtempSync, rmSync } from 'node:fs'
import { createServer, type Socket } from 'node:net'
import { request } from 'node:http'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, describe, expect, it } from 'vitest'

import { CommandGateway } from '../runtime/src/gateway/command-gateway.js'

// The gateway is driven through its public surface only: CommandGateway.open
// listens on a loopback port and we speak raw HTTP/SOCKS to it, exactly as the
// package's own gateway suite does. No internal proxy/forward helper is imported.

const credentials = { username: 'command-a', password: 'secret-a' }
const authorization = `Basic ${Buffer.from('command-a:secret-a').toString('base64')}`

const closeTasks: Array<() => Promise<void>> = []

afterEach(async () => {
  while (closeTasks.length) {
    const task = closeTasks.pop()
    try {
      await task?.()
    } catch {
      // best-effort teardown
    }
  }
})

// Listens on a loopback TCP port, or on a Unix socket path when one is given.
// Closing also drops any connection still open, so a tunnel the gateway keeps
// does not hold up teardown.
const listen = async (
  onConnection: (socket: Socket) => void,
  socketPath?: string
): Promise<{ port: number; close: () => Promise<void> }> => {
  const sockets = new Set<Socket>()
  const server = createServer((socket) => {
    sockets.add(socket)
    socket.once('close', () => sockets.delete(socket))
    socket.on('error', () => undefined)
    onConnection(socket)
  })
  await new Promise<void>((resolve, reject) => {
    server.once('error', reject)
    if (socketPath) server.listen(socketPath, resolve)
    else server.listen(0, '127.0.0.1', resolve)
  })
  const address = server.address()
  const port = address && typeof address !== 'string' ? address.port : 0
  const close = (): Promise<void> =>
    new Promise((resolve) => {
      for (const socket of sockets) socket.destroy()
      server.close(() => resolve())
    })
  closeTasks.push(close)
  return { port, close }
}

const readBytes = (socket: Socket, count: number): Promise<Buffer> =>
  new Promise((resolve, reject) => {
    let buffered = Buffer.alloc(0)
    const receive = (chunk: Buffer): void => {
      buffered = Buffer.concat([buffered, chunk])
      if (buffered.length < count) return
      socket.removeListener('data', receive)
      const result = buffered.subarray(0, count)
      const remainder = buffered.subarray(count)
      if (remainder.length) socket.unshift(remainder)
      resolve(result)
    }
    socket.on('data', receive)
    socket.once('error', reject)
  })

const readHttpHeader = (socket: Socket): Promise<string> =>
  new Promise((resolve, reject) => {
    let buffered = Buffer.alloc(0)
    const receive = (chunk: Buffer): void => {
      buffered = Buffer.concat([buffered, chunk])
      const end = buffered.indexOf('\r\n\r\n')
      if (end < 0) return
      socket.removeListener('data', receive)
      const remainder = buffered.subarray(end + 4)
      if (remainder.length) socket.unshift(remainder)
      resolve(buffered.subarray(0, end + 4).toString('latin1'))
    }
    socket.on('data', receive)
    socket.once('error', reject)
  })

// Answers a SOCKS5 no-auth greeting and an IPv4 CONNECT, as a parent proxy does.
const acceptSocks = async (socket: Socket): Promise<string> => {
  await readBytes(socket, 3)
  socket.write(Buffer.from([5, 0]))
  const destination = await readBytes(socket, 10)
  socket.write(Buffer.from([5, 0, 0, 1, 127, 0, 0, 1, 0, 80]))
  return [...destination.subarray(4, 8)].join('.')
}

const exchange = (
  port: number,
  path: string,
  method = 'GET'
): Promise<{ status: number; body: string; complete: boolean }> =>
  new Promise((resolve, reject) => {
    const outgoing = request(
      {
        hostname: '127.0.0.1',
        port,
        path,
        method,
        agent: false,
        headers: { host: 'example.test', 'proxy-authorization': authorization }
      },
      (incoming) => {
        let body = ''
        incoming.setEncoding('utf8')
        incoming.on('data', (chunk: string) => {
          body += chunk
        })
        const finish = (): void =>
          resolve({ status: incoming.statusCode!, body, complete: incoming.complete })
        incoming.on('end', finish)
        incoming.on('error', finish)
      }
    )
    outgoing.on('error', reject)
    outgoing.setTimeout(3000, () => outgoing.destroy(new Error('Fixture request timed out')))
    outgoing.end()
  })

type Route = 'direct' | 'http parent proxy' | 'socks parent proxy' | 'local rpc'
const routes: Route[] = ['direct', 'http parent proxy', 'socks parent proxy', 'local rpc']

// Opens a gateway whose upstream for the given route is a fixture that records
// the request line it receives and answers with reply(). For the HTTP parent
// proxy route the fixture plays the parent proxy; for the SOCKS route it accepts
// the tunnel first and then answers inside it.
const openRoute = async (
  route: Route,
  reply: () => string
): Promise<{ gateway: CommandGateway; url: (path: string) => string; lines: string[]; expected: (path: string) => string }> => {
  const lines: string[] = []
  const answer = async (socket: Socket): Promise<void> => {
    if (route === 'socks parent proxy') await acceptSocks(socket)
    lines.push((await readHttpHeader(socket)).split('\r\n')[0]!)
    socket.end(reply())
  }
  let socketPath: string | undefined
  if (route === 'local rpc') {
    const directory = mkdtempSync(join(tmpdir(), 'os-gateway-rpc-'))
    closeTasks.push(async () => rmSync(directory, { recursive: true, force: true }))
    socketPath = join(directory, 'rpc.sock')
  }
  const upstream = await listen((socket) => void answer(socket).catch(() => socket.destroy()), socketPath)
  const gateway = await CommandGateway.open({
    credentials,
    decide: async () => ({ allowed: true, address: '127.0.0.1' }),
    ...(route === 'http parent proxy'
      ? { parentProxy: { http: `http://127.0.0.1:${upstream.port}` } }
      : {}),
    ...(route === 'socks parent proxy'
      ? { parentProxy: { http: `socks5://127.0.0.1:${upstream.port}` } }
      : {}),
    ...(socketPath ? { localRpcSocketPath: socketPath } : {})
  })
  closeTasks.push(() => gateway.close())
  const origin =
    route === 'local rpc'
      ? 'http://open-science-notebook-rpc.invalid'
      : route === 'socks parent proxy'
        ? 'http://example.test'
        : `http://example.test:${upstream.port}`
  return {
    gateway,
    lines,
    url: (path) => `${origin}${path}`,
    // An HTTP parent proxy is asked for the absolute form at the address the
    // policy approved; every other upstream gets the origin form.
    expected: (path) =>
      `GET ${route === 'http parent proxy' ? `http://127.0.0.1:${upstream.port}` : ''}${path} HTTP/1.1`
  }
}

const clean = 'HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: close\r\n\r\nok'

// After a broken reply the gateway keeps serving: the next clean reply arrives whole.
const expectStillServing = async (
  setReply: (value: string) => void,
  gateway: CommandGateway,
  url: string
): Promise<void> => {
  setReply(clean)
  expect(await exchange(gateway.port, url)).toEqual({ status: 200, body: 'ok', complete: true })
}

describe('gateway HTTP forwarding integrity', () => {
  it.each(routes)('preserves the exact requested path and query spelling (%s)', async (route) => {
    const { gateway, url, lines, expected } = await openRoute(route, () => clean)
    for (const path of ['/a/../b', '/a/%2e%2e/b', '//a/b', '/a?', '/a?x=%2F', '/a%2Fb', '/a/./b?q=1&q=2']) {
      expect((await exchange(gateway.port, url(path))).body).toBe('ok')
      // The upstream request line carries the requested spelling byte for byte.
      expect(lines.at(-1)).toBe(expected(path))
    }
  })

  it.each(routes)(
    'answers an invalid upstream status line with a 502 and none of its body (%s)',
    async (route) => {
      let reply = clean
      const { gateway, url } = await openRoute(route, () => reply)
      for (const status of ['099', '000']) {
        reply = `HTTP/1.1 ${status} Invalid\r\nContent-Length: 6\r\n\r\nsecret`
        const failed = await exchange(gateway.port, url('/'))
        expect(failed.status).toBe(502)
        expect(failed.body).not.toContain('secret')
      }
      await expectStillServing((value) => (reply = value), gateway, url('/'))
    }
  )

  it.each(routes)(
    'delivers a complete reply whole when extra bytes follow it (%s)',
    async (route) => {
      let reply = clean
      const { gateway, url } = await openRoute(route, () => reply)
      // Declared length 3; the trailing 'def' is not part of the reply.
      reply = 'HTTP/1.1 200 OK\r\nContent-Length: 3\r\n\r\nabcdef'
      expect(await exchange(gateway.port, url('/'))).toEqual({
        status: 200,
        body: 'abc',
        complete: true
      })
      await expectStillServing((value) => (reply = value), gateway, url('/'))
    }
  )

  it.each(routes)(
    'does not pass a reply that was cut short off as a finished one (%s)',
    async (route) => {
      let reply = clean
      const { gateway, url } = await openRoute(route, () => reply)
      // Declared length 9; the upstream closes after 3 bytes.
      reply = 'HTTP/1.1 200 OK\r\nContent-Length: 9\r\n\r\nabc'
      const cut = await exchange(gateway.port, url('/'))
      if (cut.status === 502) {
        // Failing the request before it starts is fine, as long as no upstream
        // bytes are passed along.
        expect(cut.body).not.toContain('abc')
      } else {
        // Once the reply has started, the client sees it end early, with
        // nothing added after the bytes that did arrive.
        expect(cut.status).toBe(200)
        expect(cut.complete).toBe(false)
        expect('abc'.startsWith(cut.body)).toBe(true)
      }
      await expectStillServing((value) => (reply = value), gateway, url('/'))
    }
  )

  it('opens a separate SOCKS tunnel for each destination and never reuses one for another', async () => {
    const seen = [0, 1].map(() =>
      Promise.withResolvers<{ address: string; header: string }>()
    )
    let connections = 0
    const parent = await listen((socket) => {
      const index = connections++
      void (async () => {
        const address = await acceptSocks(socket)
        seen[index]!.resolve({ address, header: await readHttpHeader(socket) })
        // Offer keep-alive, so a tunnel kept for later use would be visible as
        // a reused connection on the second destination.
        socket.write(
          `HTTP/1.1 200 OK\r\nContent-Length: 1\r\nConnection: keep-alive\r\n\r\n${index}`
        )
      })().catch((error: unknown) => seen[index]?.reject(error))
    })
    const gateway = await CommandGateway.open({
      credentials,
      parentProxy: { http: `socks5://127.0.0.1:${parent.port}` },
      decide: async (host) => ({
        allowed: true,
        address: host === 'first.test' ? '203.0.113.10' : '203.0.113.11'
      })
    })
    closeTasks.push(() => gateway.close())
    for (const [index, host] of ['first.test', 'second.test'].entries()) {
      expect((await exchange(gateway.port, `http://${host}/a/../b?`)).body).toBe(String(index))
      expect(await seen[index]!.promise).toEqual({
        address: `203.0.113.${10 + index}`,
        header: expect.stringContaining('GET /a/../b? HTTP/1.1')
      })
    }
    expect(connections).toBe(2)
  })
})
