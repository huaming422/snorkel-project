import { mkdtempSync, realpathSync, rmSync, symlinkSync, writeFileSync } from 'node:fs'
import { request } from 'node:http'
import { tmpdir } from 'node:os'
import { join, sep } from 'node:path'
import { afterEach, describe, expect, it, vi } from 'vitest'

// The command's stderr is annotated through the runtime's public surface: wrap
// prepares the command with its filesystem policy, and annotateStderr adds the
// sandbox diagnostics. Only the OS launchers are replaced, the same way the
// package's own runtime-config test does, since this runner cannot start a
// real sandboxed process. The command gateway is the real one, so a network
// violation is recorded by sending a request through it.
const launch = vi.hoisted(() => ({
  gateway: undefined as
    | { port: number; credentials: { username: string; password: string } }
    | undefined
}))

vi.mock('../runtime/src/platform/linux-isolation.js', () => ({
  checkLinuxTools: () => ({ warnings: [], errors: [] }),
  linuxLaunch: async (options: {
    env: NodeJS.ProcessEnv
    gatewayPort: number
    gatewayCredentials: { username: string; password: string }
  }) => {
    launch.gateway = { port: options.gatewayPort, credentials: options.gatewayCredentials }
    return { argv: ['/sandboxed'], env: options.env, release: async () => undefined }
  }
}))

vi.mock('../runtime/src/platform/macos-isolation.js', () => ({
  macosLaunch: (options: {
    env: NodeJS.ProcessEnv
    gatewayPort: number
    gatewayCredentials: { username: string; password: string }
  }) => {
    launch.gateway = { port: options.gatewayPort, credentials: options.gatewayCredentials }
    return { argv: ['/sandboxed'], env: options.env }
  }
}))

import { NotebookNetworkRuntime } from '../runtime/src/notebook-runtime.js'

const posixIt = it.skipIf(process.platform === 'win32')
const blockedTag = 'OPEN_SCIENCE_FILESYSTEM_ACCESS_BLOCKED'

afterEach(async () => {
  await NotebookNetworkRuntime.reset()
  launch.gateway = undefined
})

// Sends one plain-HTTP request through the command's gateway, as the sandboxed
// command would, to a host the policy blocks.
const requestBlockedHost = (host: string): Promise<void> =>
  new Promise((resolve, reject) => {
    const gateway = launch.gateway!
    const { username, password } = gateway.credentials
    const outgoing = request(
      {
        hostname: '127.0.0.1',
        port: gateway.port,
        path: `http://${host}/`,
        method: 'GET',
        agent: false,
        headers: {
          host,
          'proxy-authorization': `Basic ${Buffer.from(`${username}:${password}`).toString('base64')}`
        }
      },
      (incoming) => {
        incoming.resume()
        incoming.on('end', () => resolve())
      }
    )
    outgoing.on('error', reject)
    outgoing.setTimeout(3000, () => outgoing.destroy(new Error('Fixture request timed out')))
    outgoing.end()
  })

describe('sandbox stderr diagnostics', () => {
  posixIt(
    'does not blame the sandbox for a missing-file error on a path that cannot exist',
    async () => {
      const root = realpathSync(mkdtempSync(join(tmpdir(), 'os-diagnostic-path-')))
      try {
        writeFileSync(join(root, 'file'), 'fixture')
        symlinkSync(join(root, 'absent'), join(root, 'dangling'))
        await NotebookNetworkRuntime.initialize(
          {
            allowedDomains: [],
            deniedDomains: ['blocked.test'],
            installationId: '0123456789abcdef01234567',
            windowsHostPath: 'C:\\resources\\sandbox.exe',
            windowsOwnershipRoot: 'C:\\ownership'
          },
          async () => false
        )
        const commandId = 'diagnostic'
        await NotebookNetworkRuntime.wrap({
          command: 'cat',
          commandId,
          cwd: root,
          env: {},
          filesystem: {
            privateRoot: root,
            readOnlyRoots: [],
            readWriteRoots: [],
            deniedReadRoots: [],
            deniedWriteRoots: []
          }
        })
        expect(launch.gateway).toBeDefined()

        for (const path of [
          join(root, 'file', 'leaf'),
          join(root, 'dangling', 'leaf'),
          `${root}${sep}missing${sep}..${sep}leaf`
        ]) {
          const stderr = `cat: '${path}': No such file or directory`
          // Nothing recorded: the output comes back as it was.
          expect(NotebookNetworkRuntime.annotateStderr(commandId, stderr)).toBe(stderr)

          // A blocked request recorded for the same command is still reported
          // next to that output.
          await requestBlockedHost('blocked.test')
          const annotated = NotebookNetworkRuntime.annotateStderr(commandId, stderr)
          expect(annotated).toContain(stderr)
          expect(annotated).toContain('deny network-outbound blocked.test:80')
          expect(annotated).not.toContain(blockedTag)
        }

        // A real missing path inside the hidden private folder is still reported
        // as a sandbox block.
        const privateMissing = join(root, 'not-granted.txt')
        expect(
          NotebookNetworkRuntime.annotateStderr(
            commandId,
            `cat: '${privateMissing}': No such file or directory`
          )
        ).toContain(`${blockedTag}: ${privateMissing}`)
      } finally {
        rmSync(root, { recursive: true, force: true })
      }
    }
  )
})
