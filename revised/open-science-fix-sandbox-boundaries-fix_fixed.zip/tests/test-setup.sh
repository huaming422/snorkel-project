#!/usr/bin/env bash
# Environment bootstrap for the verifier. Sourced (not exec'd) so env
# vars set here stay live for the verifier subprocess.
#
# Offline-first: the image already carries the full dependency closure at
# the base commit (npm ci ran at build time, node_modules is baked). Every
# step below is a no-op on a healthy image; the online fallbacks exist only
# to self-heal a corrupted layer and are logged loudly when they fire.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/open-science}"
export REPO_DIR
cd "$REPO_DIR"

# The verifier runner reads verify.toml under VERIFIER_PYTHON
# (/opt/tooling/venv, Python 3.12), whose stdlib ships `tomllib` - no tomli
# shim is needed, so this script installs no Python packages.
#
# vitest must be resolvable from the workspace root; a miss means a corrupted
# node_modules. Reinstall offline-first, then fall back to a networked install.
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest binary missing from node_modules/.bin/. " \
         "The image build is corrupt - re-running npm ci." >&2
    npm ci --offline --ignore-scripts >/tmp/test-setup-npm.log 2>&1 \
        || npm ci --ignore-scripts >>/tmp/test-setup-npm.log 2>&1 \
        || { tail -60 /tmp/test-setup-npm.log >&2; exit 1; }
fi

# The package under test (@aipoch/notebook-network-sandbox) is consumed by its
# own vitest tests through RELATIVE imports of runtime/src/*.ts, so source
# changes are visible to vitest without any dist rebuild of that package.
# But the package dev-depends on @aipoch/environment, a workspace dev package
# that the repo builds via `npm run build:packages` (the repo's own `pretest`
# does this). Build the dev packages defensively so an indirect workspace
# import resolves; the build-dev-packages script is incremental and a near-noop
# when nothing changed.
echo "test-setup.sh: building dev packages (build:packages)..."
npm run build:packages >/tmp/test-setup-build.log 2>&1 \
    || { echo "test-setup.sh: build:packages failed:" >&2; tail -80 /tmp/test-setup-build.log >&2; exit 1; }

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR node=$(node --version 2>/dev/null || echo unknown) vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
