## Task

The command sandbox in `@aipoch/notebook-network-sandbox` isn't enforcing its own rules anymore on macOS and plain POSIX hosts.
These rules are what keep untrusted notebook code away from protected files and off networks it was never given, so please treat this as a security bug.

Policy paths that pass through a directory symlink and then `..` are judged against the wrong place on disk.
Say `alias` links to `real/deep`: the OS opens `<dir>/alias/../secret` as `<dir>/real/secret`, but the policy treats it as `<dir>/secret`.
That can leave a protected file reachable, or refuse one that should be allowed.
A path should mean whatever the OS would open, and a path whose last part doesn't exist yet should sit under the real folder it would be created in.
Plain `.` segments are fine.
Some spellings can't be tied to a real place at all: `..` right after a folder that doesn't exist, a path through a symlink whose target is gone, or a path that uses a regular file as a folder.
If a policy lists one of those, as a grant or as a denial, building the policy should fail instead of guessing.

There's a related problem in error messages.
When a command fails with `No such file or directory` on one of those impossible paths, the sandbox adds `OPEN_SCIENCE_FILESYSTEM_ACCESS_BLOCKED` to its stderr, as if the sandbox had hidden the file.
It didn't, so that tag shouldn't be there, and annotating the output must not throw.
Any network violation recorded for that command still has to show up.
An ordinary missing file inside the hidden private folder should keep getting the blocked tag, like it does today.

On macOS there's a separate hole.
A file the policy denies, for reading or for writing, can slip out of its rule when a folder above it is renamed or removed.
One way is to rename a writable root into another writable root.
No folder above a protected path should be removable or renamable from inside the sandbox, whether folder restriction is on or off.
The protected path itself stays denied, and creating, writing or deleting other files and folders next to it has to keep working.

The outbound HTTP gateway has problems of its own.
For plain `http://` requests, the path and query sent upstream aren't always the ones the caller sent.
Spellings like `/a/../b`, `/a/%2e%2e/b`, `//a/b`, `/a?`, `/a?x=%2F` and `/a%2Fb` get rewritten on the way out.
The request target has to reach the upstream exactly as sent on every route: direct, through an HTTP parent proxy (still addressed to the IP the policy approved), through a SOCKS parent proxy, and to the local RPC socket.

Through a SOCKS parent proxy it's worse.
The proxy sees the handshake, but the request itself never arrives and the caller gets a 502 `Policy gateway could not reach the destination: ...`.
Each destination needs its own SOCKS handshake, and a tunnel opened for one host must never carry a request for another, even when the upstream offers keep-alive.

Broken upstream replies aren't handled well on any of those routes either, and an invalid status line can leave the request hanging with no answer.
- A reply with an invalid status line, such as `HTTP/1.1 099 Invalid` or `HTTP/1.1 000 Invalid`, should reach the caller as a 502 with none of the upstream body in it.
- A reply that stops before its declared `Content-Length` must not look like a finished response to the caller, and no text should be added after the bytes that already went out.
- A reply with stray bytes after its declared body should still reach the caller whole and complete.

After any of these, the gateway has to keep serving the next request normally.

Fix each one in the part of the sandbox that owns that boundary, without opening up more files or losing a denial that's right today.
The Windows AppContainer path and the Linux namespace isolation are out of scope.
