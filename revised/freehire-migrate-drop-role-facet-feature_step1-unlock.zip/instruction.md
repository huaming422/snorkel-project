## Task

We want to retire the `role` search facet. It's a cross-product of two axes the
site already has, a specialization/category axis and a seniority axis, and
production logs show it's barely used (around 1.6% of searches); everything it
can express is already expressible with those two. Retire it across the backend
search stack without standing up a replacement, and don't change what the two
surviving axes mean.

Dropping it is a public API change, so handle it gracefully — callers with stale
saved searches or shared links must still get a useful response.

Watch out for a separate, similarly-named facet that is a different filter; it
is not part of this removal.

## User stories / requirements

- When a request still carries the retired role filter (from a stale saved search or shared link), it isn't rejected, and the filter isn't quietly applied or widened; the response reports those parameters as ignored, so the caller sees the filter is gone. A live, still-supported filter sent alongside it keeps working normally.
- A separate, similarly-named people-management filter (whether a posting manages people) is a different filter and keeps working normally. It is never reported as ignored, including when a request carries both it and the retired role filter at once.
