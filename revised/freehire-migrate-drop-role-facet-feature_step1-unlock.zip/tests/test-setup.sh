#!/usr/bin/env bash
#
# test-setup.sh — sourced by the verifier harness BEFORE `go test` runs.
#
# The image already carries the full Go dependency closure at the base
# commit: block 10 warmed the module cache (GOMODCACHE=/opt/cache/go) and
# compiled every test binary, so the agent phase can build and run the
# focused tests with the network cut. This script only has to make the Go
# environment deterministic for a freshly-spawned shell that may not have
# inherited the image ENV, and (lazily, with network) ensure the verifier's
# own Python is importable.
#
# Sourced (not exec'd) so the exported environment sticks for the runner.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/freehire}"
cd "$REPO_DIR"

# Deterministic, offline-first Go environment. The verifier runs the focused
# tests with GOPROXY=off so nothing is fetched; -mod=mod matches the image.
export GOFLAGS="-mod=mod"
export GOPROXY="${GOPROXY:-off}"
export CGO_ENABLED="1"
export GOTOOLCHAIN="local"
export GOMODCACHE="${GOMODCACHE:-/opt/cache/go}"
export GOCACHE="${GOCACHE:-/home/dev/.cache/go-build}"
mkdir -p "$GOCACHE"

# Thread caps (mirror the image ENV in case the shell didn't inherit them).
export GOMAXPROCS="${GOMAXPROCS:-4}"
export OMP_THREAD_LIMIT="${OMP_THREAD_LIMIT:-4}"

# Make `go` resolvable even if the harness scrubbed PATH.
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:$PATH ;;
esac

# No Python deps to install: the structural verifier (verify.py) runs under
# VERIFIER_PYTHON (/opt/tooling/venv), which already has the canonical
# verifier stack baked into the image.

echo "test-setup.sh: ready (go $(go version 2>/dev/null | awk '{print $3}'), GOPROXY=$GOPROXY, GOMODCACHE=$GOMODCACHE)"
