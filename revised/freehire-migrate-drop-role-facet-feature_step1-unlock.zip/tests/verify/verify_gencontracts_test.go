package main

// Behavioral check on the generated front-end contracts: the generator stops
// emitting the discontinued label map but keeps the specialization vocabulary and
// the translated alias terms.
//
// This file owns TestMain so it is the only test compiled into this command's test
// binary. It asserts on the emitted string content, never on a Go identifier, so a
// solution that renames the surviving alias map still passes.

import (
	"os"
	"strings"
	"testing"
)

func TestMain(m *testing.M) {
	os.Exit(m.Run())
}

// The emitted contract no longer carries the discontinued label map nor any of its
// named values.
func TestGeneratedContractDropsDiscontinuedLabels(t *testing.T) {
	got := genVocab()
	if strings.Contains(got, "export const ROLE_LABELS") {
		t.Errorf("generated contract still emits the discontinued label map")
	}
	if strings.Contains(got, "founding_engineer") {
		t.Errorf("generated contract still emits a named value of the discontinued vocabulary")
	}
}

// The specialization vocabulary and the translated alias terms that answer the
// same question stay in the emitted contract.
func TestGeneratedContractKeepsSurvivingVocabulary(t *testing.T) {
	got := genVocab()
	if !strings.Contains(got, "export const CATEGORY_VALUES") {
		t.Errorf("generated contract lost the specialization vocabulary:\n%s", got)
	}
	if !strings.Contains(got, "data engineer") {
		t.Errorf("generated contract lost the translated alias terms:\n%s", got)
	}
}
