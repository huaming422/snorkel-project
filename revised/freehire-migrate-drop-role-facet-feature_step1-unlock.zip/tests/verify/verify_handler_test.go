package handler

// Behavioral check at the public facets HTTP endpoint: a request still carrying
// the discontinued params gets them surfaced under meta.ignored_params.
//
// This file owns TestMain so it is the only test compiled into the package; it
// drives the real handler through an in-memory fiber app and inlines its own
// double and request helper, depending on no sibling test file.

import (
	"context"
	"encoding/json"
	"io"
	"net/http/httptest"
	"os"
	"testing"

	"github.com/gofiber/fiber/v2"

	"github.com/strelov1/freehire/internal/search/search"
)

func TestMain(m *testing.M) {
	os.Exit(m.Run())
}

// stubCounter is a do-nothing facet backend: the endpoint still answers 200 and
// still reports ignored params without any live index behind it.
type stubCounter struct{}

func (stubCounter) FacetCounts(context.Context, search.FacetParams) (search.FacetResult, error) {
	return search.FacetResult{}, nil
}

func (stubCounter) DisjunctiveFacetCounts(context.Context, string, []search.FacetReq, any) (search.FacetResult, error) {
	return search.FacetResult{}, nil
}

// facetsEndpoint wires the real handler onto an in-memory app at its public route.
func facetsEndpoint() *fiber.App {
	h := &searchHandlers{facets: stubCounter{}}
	app := fiber.New(fiber.Config{ErrorHandler: RenderError})
	app.Get("/jobs/facets", h.JobFacets)
	return app
}

// getJSON performs the request and decodes the JSON body.
func getJSON(t *testing.T, app *fiber.App, target string) map[string]any {
	t.Helper()
	resp, err := app.Test(httptest.NewRequestWithContext(context.Background(), fiber.MethodGet, target, nil))
	if err != nil {
		t.Fatalf("request: %v", err)
	}
	defer resp.Body.Close()
	raw, err := io.ReadAll(resp.Body)
	if err != nil {
		t.Fatalf("read body: %v", err)
	}
	var body map[string]any
	if err := json.Unmarshal(raw, &body); err != nil {
		t.Fatalf("decode %s: %v", raw, err)
	}
	return body
}

// ignoredNames pulls the reported param names out of meta.ignored_params.
func ignoredNames(body map[string]any) []string {
	meta, _ := body["meta"].(map[string]any)
	entries, _ := meta["ignored_params"].([]any)
	var out []string
	for _, e := range entries {
		if m, ok := e.(map[string]any); ok {
			if p, ok := m["param"].(string); ok {
				out = append(out, p)
			}
		}
	}
	return out
}

func contains(ss []string, want string) bool {
	for _, s := range ss {
		if s == want {
			return true
		}
	}
	return false
}

// The endpoint lists the discontinued params under meta.ignored_params.
func TestFacetsEndpointReportsDiscontinuedParams(t *testing.T) {
	app := facetsEndpoint()
	body := getJSON(t, app, "/jobs/facets?role=senior_backend&role_exclude=x&role_mode=and")

	got := ignoredNames(body)
	for _, name := range []string{"role", "role_exclude", "role_mode"} {
		if !contains(got, name) {
			t.Errorf("meta.ignored_params = %v, missing %q", got, name)
		}
	}
}
