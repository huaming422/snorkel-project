package searchintent

// Behavioral check on the AI-intent layer: a facet name nothing serves is
// refused loudly (the drift guard), while the two surviving axes still resolve
// to their values.
//
// This file owns TestMain so it is the only test compiled into the package. It
// drives resolve() through the exported-within-package intent value and asserts
// only on returned errors and values.

import (
	"os"
	"strings"
	"testing"
)

func TestMain(m *testing.M) {
	os.Exit(m.Run())
}

// Resolving an intent that names the discontinued facet is a loud error that
// names the facet, rather than a silently-dropped field.
func TestResolveRefusesDiscontinuedFacet(t *testing.T) {
	_, err := intent{Facets: map[string][]string{"role": {"senior_backend"}}}.resolve()
	if err == nil {
		t.Fatalf("resolve accepted a facet nothing serves, want an error")
	}
	if !strings.Contains(err.Error(), "role") {
		t.Errorf("error %q does not name the discontinued facet", err.Error())
	}
}

// The two surviving axes still resolve to their canonical values.
func TestResolveKeepsSurvivingAxes(t *testing.T) {
	res, err := intent{Facets: map[string][]string{
		"category":  {"backend"},
		"seniority": {"senior"},
	}}.resolve()
	if err != nil {
		t.Fatalf("resolve rejected the surviving axes: %v", err)
	}
	if got := res.Facets["category"]; len(got) != 1 || got[0] != "backend" {
		t.Errorf("category resolved to %v, want [backend]", got)
	}
	if got := res.Facets["seniority"]; len(got) != 1 || got[0] != "senior" {
		t.Errorf("seniority resolved to %v, want [senior]", got)
	}
}
