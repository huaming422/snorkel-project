package suggest

// Behavioral check on the suggestions layer: the discontinued suggestion kind is
// no longer a recognised, single-use kind, and the builder still offers the
// specialization kind.
//
// This file owns TestMain so it is the only test compiled into the package. It
// drives the stable Parsed/Part/ExcludedKinds and Build interfaces and refers to
// the discontinued kind only by its string value, never by a named constant.

import (
	"os"
	"testing"
)

func TestMain(m *testing.M) {
	os.Exit(m.Run())
}

// The discontinued kind is no longer one of the "name it only once" kinds: a
// recognised prefix that repeats it reports nothing to exclude, because the layer
// no longer knows the kind at all.
func TestDiscontinuedKindNoLongerRecognised(t *testing.T) {
	p := Parsed{Recognised: []Part{
		{Kind: Kind("role"), Text: "one"},
		{Kind: Kind("role"), Text: "two"},
	}}
	if got := p.ExcludedKinds(); len(got) != 0 {
		t.Errorf("the discontinued kind is still a recognised single-use kind: %v", got)
	}
}

// With the discontinued kind gone, nothing suppresses a specialization whose slug
// it used to share, so the builder offers both specializations it is given.
func TestBuilderOffersSpecializations(t *testing.T) {
	docs := Build(Input{
		Categories: map[string]int{"backend": 40769, "data_engineering": 900},
		Skills:     map[string]int{"go": 120},
	})
	var specializations []string
	for _, d := range docs {
		if d.Kind == KindCategory {
			specializations = append(specializations, d.Slug)
		}
	}
	if len(specializations) != 2 {
		t.Errorf("specializations offered = %v, want both", specializations)
	}
}
