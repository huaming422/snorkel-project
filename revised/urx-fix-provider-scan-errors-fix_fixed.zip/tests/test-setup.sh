#!/usr/bin/env bash
# Test-setup for urx-fix-provider-scan-errors.
#
# urx is a binary-only crate; the behavioral verifier (verify.py) drives the
# compiled `urx` CLI against loopback mock servers. This script pre-builds the
# binary so the verifier's first invocation is fast, and proves the build
# succeeds with the dependency closure already baked into the image (offline).
# No services to start, no data to seed.
set -euo pipefail

cd /repo/urx

echo "[test-setup] Rust version:   $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:  $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Target dir:     ${CARGO_TARGET_DIR:-target}"

# Offline first. The image bakes the full dependency closure at the base commit
# and the fix needs no new crates, so a locked offline build should succeed.
# The online build below is only a logged fallback for an incomplete prebake.
# There is no network while the change is being made, so the offline path is
# the one that has to work.
export CARGO_NET_OFFLINE=true

build_log="$(mktemp)"
if cargo build --locked > "$build_log" 2>&1; then
    echo "[test-setup] Offline build OK."
else
    echo "[test-setup] Offline build FAILED; tail of log:" >&2
    tail -80 "$build_log" >&2
    echo "[test-setup] Retrying with network (fallback; indicates an incomplete prebake)..." >&2
    unset CARGO_NET_OFFLINE
    cargo build --locked > "$build_log" 2>&1 || { tail -80 "$build_log" >&2; exit 1; }
fi

bin="${CARGO_TARGET_DIR:-target}/debug/urx"
if [ ! -x "$bin" ]; then
    echo "[test-setup] ERROR: expected binary not found at $bin" >&2
    exit 1
fi
echo "[test-setup] Binary built at $bin"
"$bin" --version 2>&1 | head -1 || true
echo "[test-setup] Setup complete."
