"""Behavioral verifier for urx-fix-provider-scan-errors.

urx is a binary-only crate. There is no library target, the provider modules
are private, and their injection seams sit behind ``#[cfg(test)]``. The
compiled ``urx`` binary is the only stable public surface where this
behavior shows up, so these tests drive the binary directly and never
import, name or inspect a provider symbol. Loopback HTTP servers (and a
bound-then-closed TCP port) stand in for the target host, and the checks
read the two public output streams.

  * stdout carries discovered URLs, one per line (default plain format).
  * stderr carries the ``--stats`` per-provider summary, whose columns are
    ``provider  urls  partial  errors  elapsed``.

The contract under test is CLI-level only. A host that never answered (its
name does not resolve, the connection is refused, or nothing comes back before
the timeout) is counted as a failed scan, a host that answered with nothing is
a clean empty scan, relative ``Sitemap:`` values come out as absolute URLs resolved against
the robots.txt they came from, and ``<loc>`` values come out without
surrounding whitespace. Child sitemaps that an index lists by relative path
are fetched from the location they resolve to against that index, while
children on another host are still never requested. A listed child that
cannot be downloaded leaves the sitemap row partial instead of clean. Where
the change lives and what its helpers are called does not matter here.

Everything runs on loopback with no external network, API keys or services,
under VERIFIER_PYTHON (stdlib only).
"""

from __future__ import annotations

import http.server
import os
import socket
import subprocess
import threading
import time

import pytest

# The binary is built from /repo/urx with CARGO_TARGET_DIR pointing at the
# image's shared cache dir; resolve the path from that env var rather than
# assuming target/ under the crate.
REPO_DIR = os.environ.get("REPO_DIR", "/repo/urx")
_TARGET_DIR = os.environ.get("CARGO_TARGET_DIR", os.path.join(REPO_DIR, "target"))
URX_BIN = os.path.join(_TARGET_DIR, "debug", "urx")

# Transport timeout handed to the binary. Connection refusals on loopback are
# instant; this only bounds the (also local) read side.
PROBE_TIMEOUT_SEC = 5

# Shorter timeout for the host that accepts connections and never replies. Each
# probe against it waits the whole timeout, and the two providers send eight
# probes between them, so this keeps that run to well under a minute.
SILENT_TIMEOUT_SEC = 2


# Discovery-data bodies.

# A robots.txt advertising four kinds of Sitemap value: a root-relative path,
# a document-relative path, an absolute cross-host URL, and a non-fetchable
# scheme. The two relative values resolve against the robots.txt URL they were
# fetched from, and the junk scheme is never printed as a URL.
ROBOTS_WITH_SITEMAP_DIRECTIVES = (
    "User-agent: *\n"
    "Sitemap: /sitemap.xml\n"
    "Sitemap: sitemaps/extra.xml\n"
    "Sitemap: https://cdn.example.com/absolute.xml\n"
    "Sitemap: javascript:alert(1)\n"
)


def _pretty_urlset(host: str) -> str:
    """A urlset whose single <loc> is pretty-printed. The URL sits on its own
    line, so the <loc> text node carries a newline and indentation on both
    sides of it."""
    return (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
        "  <url>\n"
        "    <loc>\n"
        f"      http://{host}/pretty\n"
        "    </loc>\n"
        "  </url>\n"
        "</urlset>\n"
    )


# Loopback HTTP server helpers.

# Candidate sitemap locations the binary speculatively probes, so the mock
# handler can answer the ones that matter for the trimming case.
_SITEMAP_PATHS = frozenset(
    {
        "/sitemap.xml",
        "/sitemap_index.xml",
        "/sitemap.txt",
    }
)


def _make_handler(robots_body: str | None, sitemap_body_for_host: bool):
    class _Handler(http.server.BaseHTTPRequestHandler):
        def log_message(self, *_args):  # silence request logging
            pass

        def _send(self, status: int, body: bytes = b"", ctype: str = "text/plain"):
            self.send_response(status)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            if body:
                self.wfile.write(body)

        def do_GET(self):  # noqa: N802 (http.server API)
            host = self.headers.get("Host", "")
            if robots_body is not None and self.path == "/robots.txt":
                self._send(200, robots_body.encode(), "text/plain")
            elif sitemap_body_for_host and self.path in _SITEMAP_PATHS:
                self._send(200, _pretty_urlset(host).encode(), "application/xml")
            else:
                self._send(404)

    return _Handler


class _Server:
    """A ThreadingHTTPServer on 127.0.0.1:<ephemeral>, torn down on exit."""

    def __init__(self, robots_body=None, sitemap_body_for_host=False):
        handler = _make_handler(robots_body, sitemap_body_for_host)
        self._srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
        self.port = self._srv.server_address[1]
        self.host = f"127.0.0.1:{self.port}"
        self._thread = threading.Thread(target=self._srv.serve_forever, daemon=True)
        self._thread.start()

    def __enter__(self):
        return self

    def __exit__(self, *_exc):
        self._srv.shutdown()
        self._srv.server_close()


# Marker for a route that answers 200 but closes the connection before the
# promised body has been sent.
CUT_SHORT = object()


def _urlset(*urls: str) -> str:
    entries = "".join(f"  <url><loc>{u}</loc></url>\n" for u in urls)
    return (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
        f"{entries}"
        "</urlset>\n"
    )


def _sitemap_index(*locs: str) -> str:
    entries = "".join(f"  <sitemap><loc>{loc}</loc></sitemap>\n" for loc in locs)
    return (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
        f"{entries}"
        "</sitemapindex>\n"
    )


class _RouteServer:
    """A loopback server that serves a path -> body table and records every
    path it was asked for. The table can be filled after start-up, once the
    ports of all servers in a test are known. Unknown paths get a 404."""

    def __init__(self):
        self.routes: dict = {}
        self.hits: list[str] = []
        routes, hits = self.routes, self.hits

        class _Handler(http.server.BaseHTTPRequestHandler):
            def log_message(self, *_args):  # silence request logging
                pass

            def do_GET(self):  # noqa: N802 (http.server API)
                hits.append(self.path)
                body = routes.get(self.path)
                if body is None:
                    self.send_response(404)
                    self.send_header("Content-Length", "0")
                    self.end_headers()
                    return
                if body is CUT_SHORT:
                    # Promise more bytes than are sent, then hang up. HTTP/1.0
                    # closes the socket when the handler returns.
                    head = (
                        '<?xml version="1.0" encoding="UTF-8"?>\n'
                        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
                        "  <url><loc>"
                    ).encode()
                    self.send_response(200)
                    self.send_header("Content-Type", "application/xml")
                    self.send_header("Content-Length", str(len(head) + 4096))
                    self.end_headers()
                    self.wfile.write(head)
                    self.wfile.flush()
                    self.close_connection = True
                    return
                data = body.encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/xml")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

        self._srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
        self.port = self._srv.server_address[1]
        self.host = f"127.0.0.1:{self.port}"
        self._thread = threading.Thread(target=self._srv.serve_forever, daemon=True)
        self._thread.start()

    def __enter__(self):
        return self

    def __exit__(self, *_exc):
        self._srv.shutdown()
        self._srv.server_close()


def _closed_port_host() -> str:
    """Bind an ephemeral loopback port, read it, then close the socket so
    nothing listens there. A connection to it is refused outright, so the probe
    fails at the transport level. A sandbox that answers blocked public
    hostnames with a 404 would not give that."""
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return f"127.0.0.1:{port}"


def _unresolvable_host() -> str:
    """A host name that no resolver will turn into an address. The first label
    is 64 characters, one over the DNS limit, so the system resolver rejects
    the name before it asks any server; and the ``.invalid`` top-level domain
    is reserved, so a server that was asked would say no as well. Neither path
    depends on the sandbox's network setup."""
    return "urx-no-such-host-" + "x" * 47 + ".invalid"


class _SilentServer:
    """A loopback listener that completes the TCP handshake and then never
    sends a byte, so every request against it waits out the client timeout.
    Accepted connections are held open until the server is closed, so the
    client never sees the socket end either."""

    def __init__(self):
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._sock.bind(("127.0.0.1", 0))
        self._sock.listen(32)
        self._sock.settimeout(0.2)
        self.port = self._sock.getsockname()[1]
        self.host = f"127.0.0.1:{self.port}"
        self._conns: list[socket.socket] = []
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._accept_loop, daemon=True)
        self._thread.start()

    def _accept_loop(self):
        while not self._stop.is_set():
            try:
                conn, _addr = self._sock.accept()
            except socket.timeout:
                continue
            except OSError:
                return
            self._conns.append(conn)

    def __enter__(self):
        return self

    def __exit__(self, *_exc):
        self._stop.set()
        self._thread.join(timeout=2)
        for conn in self._conns:
            conn.close()
        self._sock.close()


# Running the binary + parsing its output.


def _run_urx(target: str, providers: str, timeout: int = PROBE_TIMEOUT_SEC):
    """Run the binary against ``target`` for the given provider ids and return
    (stdout, stderr). The binary exits 0 even when a provider errors, so the
    outcome is read from the streams, never from the exit code."""
    proc = subprocess.run(
        [
            URX_BIN,
            target,
            "--providers",
            providers,
            "--stats",
            "--no-progress",
            "--no-cache",
            "--timeout",
            str(timeout),
        ],
        capture_output=True,
        text=True,
        timeout=120,
        cwd=REPO_DIR,
    )
    return proc.stdout, proc.stderr


def _stdout_lines(stdout: str) -> list[str]:
    return [ln.strip() for ln in stdout.splitlines() if ln.strip()]


def _raw_stdout_lines(stdout: str) -> list[str]:
    """Physical lines exactly as emitted, with surrounding whitespace intact and
    only fully-empty lines dropped. A location printed with its indentation
    still attached shows up here as a line that is NOT equal to the clean URL."""
    return [ln for ln in stdout.splitlines() if ln != ""]


def _stats_column(stderr: str, label: str, from_end: int):
    """Return one numeric column of a provider row in the --stats table,
    matched by its display label. Columns are
    ``provider urls partial errors elapsed`` and elapsed is a single token, so
    errors is 2 from the end and partial is 3 from the end. Returns None if the
    row is absent."""
    for line in stderr.splitlines():
        stripped = line.strip()
        if stripped.lower().startswith(label.lower()):
            tokens = stripped.split()
            if len(tokens) >= from_end + 1:
                try:
                    return int(tokens[-from_end])
                except ValueError:
                    return None
    return None


def _errors_for(stderr: str, label: str):
    return _stats_column(stderr, label, 2)


def _partial_for(stderr: str, label: str):
    return _stats_column(stderr, label, 3)


# One-time build of the binary under test.


@pytest.fixture(scope="session", autouse=True)
def _built_binary():
    """Make sure the binary reflects the current source tree. The image pre-builds
    it and the setup step rebuilds after any change, but building here too keeps
    the verifier self-contained; cargo is incremental, so a warm tree is cheap.
    Deps are baked into the image, so the build runs offline."""
    env = {**os.environ, "CARGO_NET_OFFLINE": "true"}
    proc = subprocess.run(
        ["cargo", "build", "--locked"],
        cwd=REPO_DIR,
        env=env,
        capture_output=True,
        text=True,
        timeout=1000,
    )
    if proc.returncode != 0:
        pytest.fail(
            "cargo build failed; cannot exercise the binary:\n"
            + proc.stderr[-4000:]
        )
    # Give the filesystem a beat to settle the freshly linked binary.
    for _ in range(50):
        if os.path.exists(URX_BIN) and os.access(URX_BIN, os.X_OK):
            break
        time.sleep(0.1)
    assert os.access(URX_BIN, os.X_OK), f"binary not executable at {URX_BIN}"


# Tests.


def _assert_both_rows_count_an_error(stderr: str, what: str) -> None:
    """Both direct-probe discovery providers show at least one error in their
    --stats row for a host that never answered."""
    robots_errors = _errors_for(stderr, "Robots.txt")
    sitemap_errors = _errors_for(stderr, "Sitemap")

    assert robots_errors is not None, f"no Robots.txt row in stats:\n{stderr}"
    assert sitemap_errors is not None, f"no Sitemap row in stats:\n{stderr}"
    assert robots_errors >= 1, (
        f"{what} reported {robots_errors} errors for the robots provider; "
        f"expected it to be counted as a failed scan.\n{stderr}"
    )
    assert sitemap_errors >= 1, (
        f"{what} reported {sitemap_errors} errors for the sitemap provider; "
        f"expected it to be counted as a failed scan.\n{stderr}"
    )


def test_unreachable_host_counts_as_error():
    """A host that refuses every connection is reported as a scan error in the
    per-provider summary, not as a completed zero-URL scan."""
    target = _closed_port_host()
    _stdout, stderr = _run_urx(target, "robots,sitemap")
    _assert_both_rows_count_an_error(stderr, "a host that refused the connection")


def test_unresolvable_host_counts_as_error():
    """A host whose name does not resolve is reported as a scan error in the
    per-provider summary, not as a completed zero-URL scan."""
    _stdout, stderr = _run_urx(_unresolvable_host(), "robots,sitemap")
    _assert_both_rows_count_an_error(stderr, "a host whose name does not resolve")


def test_silent_host_counts_as_error():
    """A host that accepts the connection but never replies, so every probe
    times out, is reported as a scan error in the per-provider summary, not as
    a completed zero-URL scan."""
    with _SilentServer() as srv:
        _stdout, stderr = _run_urx(srv.host, "robots,sitemap", timeout=SILENT_TIMEOUT_SEC)
    _assert_both_rows_count_an_error(stderr, "a host that never replied")


def test_missing_discovery_data_is_clean_success():
    """A host that ANSWERS it has no discovery data (404 at every probed
    location) is a successful zero-URL scan: both --stats rows show zero errors
    and nothing partial, and stdout is empty."""
    with _Server(robots_body=None, sitemap_body_for_host=False) as srv:
        stdout, stderr = _run_urx(srv.host, "robots,sitemap")

    robots_errors = _errors_for(stderr, "Robots.txt")
    sitemap_errors = _errors_for(stderr, "Sitemap")

    assert robots_errors is not None, f"no Robots.txt row in stats:\n{stderr}"
    assert sitemap_errors is not None, f"no Sitemap row in stats:\n{stderr}"
    assert robots_errors == 0, (
        f"a reachable host with no discovery data reported {robots_errors} "
        f"errors for the robots provider; it must stay a clean scan.\n{stderr}"
    )
    assert sitemap_errors == 0, (
        f"a reachable host with no discovery data reported {sitemap_errors} "
        f"errors for the sitemap provider; it must stay a clean scan.\n{stderr}"
    )
    assert _partial_for(stderr, "Robots.txt") == 0, (
        f"a reachable host with no discovery data was reported partial for "
        f"the robots provider.\n{stderr}"
    )
    assert _partial_for(stderr, "Sitemap") == 0, (
        f"a reachable host with no discovery data was reported partial for "
        f"the sitemap provider.\n{stderr}"
    )
    assert _stdout_lines(stdout) == [], (
        f"expected no URLs from a host with no discovery data, got:\n{stdout}"
    )


def test_relative_discovery_references_are_resolved():
    """Relative Sitemap values in robots.txt reach stdout as absolute URLs,
    resolved against the robots.txt URL they were fetched from. Both the
    root-relative and the document-relative form are covered, and a
    non-http(s) value is never printed as a URL."""
    with _Server(robots_body=ROBOTS_WITH_SITEMAP_DIRECTIVES) as srv:
        host = srv.host
        stdout, _stderr = _run_urx(host, "robots")

    lines = _stdout_lines(stdout)

    assert f"http://{host}/sitemap.xml" in lines, (
        f"root-relative reference was not resolved to the fetched host.\n{stdout}"
    )
    assert f"http://{host}/sitemaps/extra.xml" in lines, (
        f"document-relative reference was not resolved to the fetched host.\n{stdout}"
    )
    # A non-fetchable scheme must never be emitted as if it were a URL.
    assert not any(ln.startswith("javascript:") for ln in lines), (
        f"a non-http(s) scheme leaked into the output.\n{stdout}"
    )
    # Nothing may leave the provider as an unresolved bare path.
    assert not any(ln in ("/sitemap.xml", "sitemaps/extra.xml") for ln in lines), (
        f"an unresolved relative reference leaked into the output.\n{stdout}"
    )
    assert all(ln.startswith("http://") or ln.startswith("https://") for ln in lines), (
        f"a non-URL value reached the output.\n{stdout}"
    )


def test_pretty_printed_locations_are_trimmed():
    """A <loc> value wrapped in whitespace (pretty-printed XML) reaches stdout
    as the bare URL on its own line. The check compares exact output lines,
    whitespace included."""
    with _Server(sitemap_body_for_host=True) as srv:
        host = srv.host
        stdout, _stderr = _run_urx(host, "sitemap")

    # Compare against the RAW lines, so a URL printed with indentation around
    # it does not count as the clean URL.
    raw_lines = _raw_stdout_lines(stdout)
    expected = f"http://{host}/pretty"
    assert expected in raw_lines, (
        f"the pretty-printed location was not trimmed and did not reach the "
        f"output as a clean URL; expected an exact {expected!r} line among:\n{stdout!r}"
    )
    # No emitted line may carry surrounding whitespace.
    assert all(ln == ln.strip() for ln in raw_lines), (
        f"an emitted URL carried surrounding whitespace.\n{stdout!r}"
    )


def test_relative_child_sitemaps_are_followed():
    """A sitemap index that lists its children by relative path has those
    children fetched, and their URLs reach stdout.

    Each entry resolves against the URL of the index that lists it, so
    ``posts.xml`` inside ``/blog/index.xml`` is ``/blog/posts.xml``, not
    ``/posts.xml``. One entry is pretty-printed around a root-relative path.
    A protocol-relative entry naming another loopback port is a different
    host, so that server must never be asked for anything and the URL it
    would hand out must not appear. The run stays clean, with no errors and
    nothing partial."""
    with _RouteServer() as site, _RouteServer() as other:
        host = site.host
        other.routes["/stolen.xml"] = _urlset(f"http://{host}/stolen")
        site.routes.update(
            {
                "/sitemap_index.xml": _sitemap_index(
                    "\n      /blog/index.xml\n    ",
                    "pages.xml",
                    f"//{other.host}/stolen.xml",
                ),
                "/blog/index.xml": _sitemap_index("posts.xml"),
                "/blog/posts.xml": _urlset(f"http://{host}/blog/hello"),
                "/pages.xml": _urlset(f"http://{host}/about"),
            }
        )
        stdout, stderr = _run_urx(host, "sitemap")
        other_hits = list(other.hits)

    lines = _stdout_lines(stdout)

    assert f"http://{host}/about" in lines, (
        f"a document-relative child of the root index was not followed.\n"
        f"stdout:\n{stdout}\nstats:\n{stderr}"
    )
    assert f"http://{host}/blog/hello" in lines, (
        f"a child listed by a nested index was not resolved against that "
        f"index and followed.\nstdout:\n{stdout}\nstats:\n{stderr}"
    )
    assert f"http://{host}/stolen" not in lines, (
        f"a child sitemap on another host was followed.\n{stdout}"
    )
    assert other_hits == [], (
        f"a protocol-relative child on another host was requested: {other_hits}"
    )
    assert _errors_for(stderr, "Sitemap") == 0, (
        f"a host whose sitemaps all loaded reported errors.\n{stderr}"
    )
    assert _partial_for(stderr, "Sitemap") == 0, (
        f"a host whose sitemaps all loaded was reported partial.\n{stderr}"
    )


def test_unfinished_child_sitemap_marks_partial():
    """When an index loads but one of the sitemaps it lists is cut off
    mid-download, the URLs from the other children still reach stdout and the
    sitemap row counts the run as partial, not as an error and not as a clean
    success."""
    with _RouteServer() as site:
        host = site.host
        site.routes.update(
            {
                "/sitemap.xml": _sitemap_index(
                    f"http://{host}/kept.xml",
                    f"http://{host}/cut.xml",
                ),
                "/kept.xml": _urlset(f"http://{host}/kept"),
                "/cut.xml": CUT_SHORT,
            }
        )
        stdout, stderr = _run_urx(host, "sitemap")
        cut_requested = "/cut.xml" in site.hits

    lines = _stdout_lines(stdout)

    assert cut_requested, f"the listed child was never requested.\n{stderr}"
    assert f"http://{host}/kept" in lines, (
        f"URLs from the child that did load were lost.\n"
        f"stdout:\n{stdout}\nstats:\n{stderr}"
    )
    assert _errors_for(stderr, "Sitemap") == 0, (
        f"a host that answered was counted as a failed scan.\n{stderr}"
    )
    partial = _partial_for(stderr, "Sitemap")
    assert partial is not None and partial >= 1, (
        f"a sitemap the index listed could not be downloaded, but the sitemap "
        f"row reported {partial} partial.\n{stderr}"
    )
