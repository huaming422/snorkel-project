## Task

We keep getting misleading results from the `robots` and `sitemap` providers in urx.

First, failed scans are hidden.
Point urx at a host nobody can connect to (a name that won't resolve, a port that refuses connections, a server that never replies) and the `--stats` table shows both providers finishing with zero URLs and zero errors.
A live site with no robots.txt and no sitemap produces exactly the same table.
Each provider should report the dead host as an error, and the live but empty site should keep its clean result.
The sitemap provider has a milder form of this.
When a site's sitemap index comes back fine but one of the sitemaps it lists is cut off mid-download, the run still looks clean.
We want that case flagged in the `partial` column, with the URLs from the sitemaps that did load still printed.

Second, some URLs a site publishes go missing or come out mangled.
A robots.txt line like `Sitemap: /sitemap.xml`, which uses a bare path rather than an absolute URL, never makes it into the output.
A sitemap index that names its child sitemaps with relative paths yields nothing from those children.
Relative entries should be read relative to the file that contains them, so an index in a subfolder points into that subfolder.
Children that live on some other host have to stay ignored, the same as now.
Pretty-printed sitemaps, with every `<loc>` value indented on a separate line, come out with that whitespace still wrapped around each URL.

This shouldn't need any extra flags or a different output format.
