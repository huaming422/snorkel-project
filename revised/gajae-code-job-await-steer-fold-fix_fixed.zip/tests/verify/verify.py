"""Behavioral verifier for how a running-job wait handles a mid-wait steer,
compared with a foreground shell wait.

The package under test is a bun + TypeScript workspace: its suites import
`bun:test` and Bun runtime APIs and must run under `bun test`, which the shared
JS runner (jest/vitest only) cannot drive. So this file is a thin pytest
orchestrator that shells out to the package's own `bun test`, asks for a JUnit
report, and re-exposes each case as a pytest result.

It imports no repository code, only the standard library and subprocess, so it
runs under the shared verifier interpreter with no per-task interpreter
override.

What it runs (all copied into the package's test tree, then removed):
  * job_steer_fold.verify.test.ts - checks on a steered `job poll`, driven
    through the job tool's public `execute` entry point and the session
    coordinator's public read API.
  * job_steer_fold_realsession.verify.test.ts - one check that runs a steered
    `job poll` against a real AgentSession (via the package's own
    `createAgentSession`), so the session's own fold gate is in the path.
  * three suites copied from the package's own foreground shell fold tests,
    which must keep passing.
  * a copy of the shared steer-fold test helper, so the checks do not depend on
    the repository's own test tree, which a change may edit.

Health: each file must contribute at least one case; a file that loads to zero
cases (a transpile/import failure) is surfaced as a failing health case rather
than vanishing into a vacuous pass.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

import pytest

# --- layout ----------------------------------------------------------------

_REPO_NAME = os.environ.get("REPO_NAME", "gajae-code")
REPO_DIR = Path(os.environ.get("REPO_DIR") or f"/repo/{_REPO_NAME}")
PKG_DIR = REPO_DIR / "packages" / "coding-agent"
TEST_DIR = PKG_DIR / "test"
HELPERS_DIR = TEST_DIR / "helpers"
VERIFY_DIR = Path(__file__).resolve().parent

# bun is on PATH at /opt/bun/bin in the image; fall back to that absolute path.
BUN = shutil.which("bun") or "/opt/bun/bin/bun"

# The job-poll checks first (session double, then real session), then the
# copied shell-fold suites.
TEST_FILES = [
    "job_steer_fold.verify.test.ts",
    "job_steer_fold_realsession.verify.test.ts",
    "bash_steer_fold.verify.test.ts",
    "bash_steer_fold_redteam.verify.test.ts",
    "bash_acp_terminal_fold.verify.test.ts",
]
HARNESS_FILE = "steer_fold_verify_harness.ts"

# A bun test file has a generous per-run wall-clock budget; each individual
# `it` sets its own timeout in-file (the fold cases wait out a ~2s grace window).
PER_FILE_TIMEOUT_SEC = 240


# --- bun execution + JUnit parsing -----------------------------------------


def _inject() -> list[Path]:
    """Copy the verifier's bun files into the package test tree. Returns the
    list of injected paths (removed afterwards). Overwrites nothing that is not
    a verifier-owned, uniquely-named file."""
    HELPERS_DIR.mkdir(parents=True, exist_ok=True)
    injected: list[Path] = []
    for name in TEST_FILES:
        dest = TEST_DIR / name
        shutil.copyfile(VERIFY_DIR / name, dest)
        injected.append(dest)
    harness_dest = HELPERS_DIR / HARNESS_FILE
    shutil.copyfile(VERIFY_DIR / HARNESS_FILE, harness_dest)
    injected.append(harness_dest)
    return injected


def _parse_junit(xml_path: Path) -> list[tuple[str, bool, str]]:
    """Return (case_name, passed, detail) for every <testcase> in the report."""
    if not xml_path.is_file():
        return []
    try:
        root = ET.parse(str(xml_path)).getroot()  # noqa: S314 - bun's own report file
    except ET.ParseError:
        return []
    cases: list[tuple[str, bool, str]] = []
    for tc in root.iter("testcase"):
        name = tc.get("name") or tc.get("classname") or "unnamed"
        failure = tc.find("failure")
        error = tc.find("error")
        bad = failure if failure is not None else error
        if bad is not None:
            detail = (bad.get("message") or bad.text or "failed").strip()
            cases.append((name, False, detail[:400]))
        else:
            cases.append((name, True, ""))
    return cases


def _run_one(rel_test_path: str, xml_path: Path) -> tuple[int, str, list[tuple[str, bool, str]]]:
    """Run one bun test file; return (returncode, combined_output_tail, cases)."""
    cmd = [
        BUN,
        "test",
        rel_test_path,
        "--reporter=junit",
        f"--reporter-outfile={xml_path}",
    ]
    try:
        proc = subprocess.run(
            cmd,
            cwd=str(PKG_DIR),
            capture_output=True,
            text=True,
            timeout=PER_FILE_TIMEOUT_SEC,
            check=False,
            env={**os.environ, "REPO_NAME": _REPO_NAME},
        )
        rc = proc.returncode
        out = (proc.stdout or "") + (proc.stderr or "")
    except subprocess.TimeoutExpired as exc:
        rc = -1
        out = f"bun test timed out after {PER_FILE_TIMEOUT_SEC}s\n{exc}"
    cases = _parse_junit(xml_path)
    return rc, out[-2000:], cases


def _collect() -> list[tuple[str, bool, str]]:
    """Inject, run each file under bun, flatten to (id, passed, detail).

    Per-file health: a file that produced zero cases but a non-zero exit (a
    transpile/import/load failure) becomes one failing health case so it cannot
    disappear into a vacuous pass.
    """
    results: list[tuple[str, bool, str]] = []
    injected = _inject()
    try:
        for name in TEST_FILES:
            stem = name.replace(".verify.test.ts", "").replace(".test.ts", "")
            xml_path = VERIFY_DIR / f".bun-report-{stem}.xml"
            rc, tail, cases = _run_one(f"test/{name}", xml_path)
            xml_path.unlink(missing_ok=True)
            if not cases:
                # No cases parsed: either the file failed to load or bun emitted
                # no report. Fail closed with the output tail for diagnosis.
                results.append(
                    (
                        f"{stem}::__suite_loaded__",
                        False,
                        f"bun produced no test cases for {name} (exit {rc}). Output tail:\n{tail}",
                    )
                )
                continue
            for case_name, passed, detail in cases:
                results.append((f"{stem}::{case_name}", passed, detail))
    finally:
        for path in injected:
            path.unlink(missing_ok=True)
    return results


# Run the bun suites once, at import, so each case becomes its own pytest case.
# A hard failure here (missing toolchain, missing repo tree) must not abort
# collection into an ambiguous 0-case run; surface it as a failing case.
try:
    _RESULTS = _collect()
except Exception as exc:  # noqa: BLE001 - convert any setup failure into a visible case
    _RESULTS = [("__verifier_setup__", False, f"verifier setup raised: {exc!r}")]


# --- pytest surface --------------------------------------------------------


def test_bun_available() -> None:
    """Fail loudly (not vacuously) if the bun toolchain is missing."""
    assert shutil.which("bun") or Path("/opt/bun/bin/bun").exists(), (
        "bun was not found on PATH or at /opt/bun/bin/bun; the verifier cannot run the suites"
    )


@pytest.mark.parametrize(
    ("case_id", "passed", "detail"),
    _RESULTS,
    ids=[r[0] for r in _RESULTS],
)
def test_job_await_steer_fold(case_id: str, passed: bool, detail: str) -> None:
    assert passed, f"{case_id} failed:\n{detail}"
