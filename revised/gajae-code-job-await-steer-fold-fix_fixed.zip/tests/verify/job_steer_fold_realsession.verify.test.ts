// Real-AgentSession check for a steered job poll.
//
// The other job-poll suite uses a lightweight session double whose fold request
// reaches the coordinator directly, so it never goes through the session's own
// fold-admission gate. This suite builds a real AgentSession through the
// package's own `createAgentSession` (the same construction the repo's SDK
// steer-fold tests use) and runs the real `job` tool against it, so the steer
// goes through the production session path. It imports no symbol introduced by
// a change and asserts only elapsed time and job state.
//
// STEER_FOLD_GRACE_MS is read from tools/bash, which exports it whether it is
// defined there or re-exported from a shared module.
import { afterEach, describe, expect, it } from "bun:test";
import { createMockModel, registerMockApi } from "@gajae-code/ai/providers/mock";
import { TempDir } from "@gajae-code/utils";
import { AsyncJobManager } from "../src/async";
import { Settings } from "../src/config/settings";
import { type CreateAgentSessionResult, createAgentSession } from "../src/sdk";
import { AuthStorage } from "../src/session/auth-storage";
import { SessionManager } from "../src/session/session-manager";
import type { ToolSession } from "../src/tools";
import { STEER_FOLD_GRACE_MS } from "../src/tools/bash";
import { JobTool } from "../src/tools/job";

// Shortened so a wait that is not cut short returns quickly instead of sitting
// on the default deadline; still well longer than the grace window.
const SHORT_POLL_WAIT = "5s";
// The millisecond value of SHORT_POLL_WAIT. A steered poll returns well before
// this deadline; a poll that ignores the steer sits on the full window. The
// cut-off below sits above a post-grace return (the grace window plus the
// test's 150 ms steer delay) and below the full window.
const POLL_WAIT_MS = 5_000;

interface RealScenario {
	created: CreateAgentSessionResult;
	authStorage: AuthStorage;
	tempDir: TempDir;
}

async function createRealScenario(): Promise<RealScenario> {
	const tempDir = TempDir.createSync("@gjc-job-steer-fold-real-");
	registerMockApi();
	const authStorage = await AuthStorage.create(`${tempDir.path()}/auth.db`);
	const mock = createMockModel({ handler: () => ({ content: ["idle"] }) });
	authStorage.setRuntimeApiKey(mock.model.provider, "test-key");
	const created = await createAgentSession({
		cwd: tempDir.path(),
		agentDir: tempDir.path(),
		sessionManager: SessionManager.inMemory(tempDir.path()),
		authStorage,
		settings: Settings.isolated({
			"async.enabled": true,
			"bash.autoBackground.enabled": false,
			"compaction.enabled": false,
			busyPromptMode: "steer",
		}),
		model: mock.model,
		toolNames: ["bash"],
		disableExtensionDiscovery: true,
		extensions: [],
		skills: [],
		contextFiles: [],
		promptTemplates: [],
		slashCommands: [],
		enableMCP: false,
		enableLsp: false,
		sdkHostModeSupported: false,
		notificationHostModeSupported: false,
	});
	return { created, authStorage, tempDir };
}

describe("job-await steer fold through a real session", () => {
	const scenarios: RealScenario[] = [];
	const releaseGates: Array<(value: string) => void> = [];

	afterEach(async () => {
		for (const resolve of releaseGates.splice(0)) resolve("cleanup");
		const retired = scenarios.splice(0);
		await Promise.all(
			retired.map(async scenario => {
				await scenario.created.session.dispose();
				scenario.authStorage.close();
				scenario.tempDir.removeSync();
			}),
		);
		AsyncJobManager.resetForTests();
	});

	// A steer that lands after the grace window returns the poll promptly through
	// the real session, and the watched job keeps running.
	it("returns a post-grace steered poll promptly through a real session", async () => {
		const scenario = await createRealScenario();
		scenarios.push(scenario);
		const realSession = scenario.created.session;

		// The session-owned manager that the real session's own fold path consults.
		const manager = AsyncJobManager.instance();
		if (!manager) throw new Error("expected the session-owned async job manager");

		// A job already running in the background, which is what a `poll` waits on.
		const gate = Promise.withResolvers<string>();
		releaseGates.push(gate.resolve);
		const jobId = manager.register("bash", "held await", () => gate.promise);
		const job = manager.getJob(jobId);
		if (!job) throw new Error(`expected job ${jobId}`);
		manager.markStartedInBackground(jobId, job.generation);

		// The tool session the job tool runs under: its fold methods delegate to the
		// real AgentSession, so the session's own gate decides whether the steer may
		// end the wait. The steering waiter is local to the test.
		const steeringWaiters = new Set<() => void>();
		const settings = Settings.isolated({ busyPromptMode: "steer" });
		settings.set("async.pollWaitDuration", SHORT_POLL_WAIT);
		const toolSession: ToolSession = {
			cwd: scenario.tempDir.path(),
			hasUI: false,
			settings,
			getSessionFile: () => null,
			getAsyncJobManager: () => manager,
			registerForegroundFoldParticipant: adapter => realSession.registerForegroundFoldParticipant(adapter),
			hasForegroundBashBackgroundRequestHandler: () => realSession.hasForegroundBashBackgroundRequestHandler(),
			requestForegroundBashBackground: (reason, adapter) =>
				realSession.requestForegroundBashBackground(reason, adapter),
			waitForUserSteering: (signal: AbortSignal) => {
				if (signal.aborted) return Promise.resolve();
				const { promise, resolve } = Promise.withResolvers<void>();
				const settle = () => {
					steeringWaiters.delete(settle);
					signal.removeEventListener("abort", settle);
					resolve();
				};
				steeringWaiters.add(settle);
				signal.addEventListener("abort", settle, { once: true });
				return promise;
			},
		};

		const startedAt = Date.now();
		const resultPromise = new JobTool(toolSession).execute("await-real-fold", { poll: [jobId] });
		await Bun.sleep(STEER_FOLD_GRACE_MS + 150);
		// Admit the steer into the simulated live run.
		for (const resolve of [...steeringWaiters]) resolve();
		await resultPromise;
		const elapsed = Date.now() - startedAt;

		// The poll returned well before its own window and before the held job
		// finished, and the job is still running (not killed, cancelled or
		// restarted).
		expect(elapsed).toBeLessThan(POLL_WAIT_MS - 750);
		expect(manager.getJob(jobId)?.status).toBe("running");

		gate.resolve("real result");
		await job.promise;
	}, 30_000);
});
