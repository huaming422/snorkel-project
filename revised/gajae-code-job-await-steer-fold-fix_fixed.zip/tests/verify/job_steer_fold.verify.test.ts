// Checks for how a running-job wait (`job poll`) handles a user steer that
// arrives mid-wait, compared with a foreground shell wait.
//
// Everything here drives through pre-existing surfaces only:
//   * the job tool's public `execute({ poll })` entry point,
//   * the shared steer-fold test helpers (a copy ships alongside this file so
//     the check does not depend on the repository's own test tree),
//   * the session coordinator's public read API (slotStateFor / onDelivery /
//     resolveTarget / hasFoldableParticipant) and the manager's fold-event
//     stream (JobFoldEvent) plus job metadata.
// No symbol introduced by a change is imported, and no model-facing wording is
// asserted; the checks read enum values, job lifecycle state, event counts,
// elapsed time and delivery dispositions.
//
// STEER_FOLD_GRACE_MS is read from tools/bash, which exports it whether it is
// defined there or re-exported from a shared module.
import { afterEach, beforeEach, describe, expect, it } from "bun:test";
import { AsyncJobManager } from "../src/async";
import type { FoldAdapter } from "../src/session/fold-coordinator";
import { STEER_FOLD_GRACE_MS } from "../src/tools/bash";
import { JobTool } from "../src/tools/job";
import { createSteerHarness, type SteerHarness, textOf } from "./helpers/steer_fold_verify_harness";

// The poll's own wait window is shortened so a wait that is not cut short
// returns quickly instead of sitting on the default deadline. It stays well
// longer than the grace window, so a post-grace steer has room to end the wait
// before the window would end it.
const SHORT_POLL_WAIT = "5s";
// The millisecond value of SHORT_POLL_WAIT. A steered wait returns well before
// this deadline; a wait that ignores the steer sits on it in full. The cut-off
// used below (POLL_WAIT_MS - 750) sits above a post-grace return (about the
// grace window plus a few hundred ms) and below the full window.
const POLL_WAIT_MS = 5_000;

describe("steer-triggered job await parity", () => {
	let harness: SteerHarness | undefined;

	function useHarness(options?: Parameters<typeof createSteerHarness>[1]): SteerHarness {
		const h = createSteerHarness(process.cwd(), options);
		h.session.settings.set("async.pollWaitDuration", SHORT_POLL_WAIT);
		harness = h;
		return h;
	}

	beforeEach(() => {
		harness = undefined;
	});

	afterEach(async () => {
		await harness?.manager.dispose({ timeoutMs: 200 });
		harness = undefined;
		AsyncJobManager.resetForTests();
	});

	// Register a job that stays running until the test resolves its gate, and
	// mark it as already running in the background (what a `poll` waits on).
	function registerHeldJob(h: SteerHarness, label: string, type: "bash" | "task" = "bash") {
		const gate = Promise.withResolvers<string>();
		const id = h.manager.register(type, label, () => gate.promise);
		const job = h.manager.getJob(id);
		if (!job) throw new Error(`expected job ${id}`);
		h.manager.markStartedInBackground(id, job.generation);
		// The run's generation, copied so a later restart shows up as a change.
		const startGeneration = job.generation;
		return { gate, id, job, startGeneration };
	}

	// A steer that lands after the grace window returns the poll well before its
	// own wait deadline and before any watched job completes. Every watched job
	// keeps running (not killed, cancelled or restarted), and each completion
	// shows up exactly once on a later poll.
	it("returns a post-grace await promptly and keeps every watched job running", async () => {
		const h = useHarness();
		const first = registerHeldJob(h, "first await");
		const second = registerHeldJob(h, "second await");
		const tool = new JobTool(h.session);
		const startedAt = Date.now();
		const resultPromise = tool.execute("await-fold", { poll: [first.id, second.id] });

		await Bun.sleep(STEER_FOLD_GRACE_MS + 150);
		h.steer();
		await resultPromise;
		const elapsed = Date.now() - startedAt;

		// The poll came back shortly after the steer, well under its own window.
		expect(elapsed).toBeLessThan(POLL_WAIT_MS - 750);
		// Neither watched job finished to cause the return; both are still running.
		expect(h.manager.getJob(first.id)?.status).toBe("running");
		expect(h.manager.getJob(second.id)?.status).toBe("running");
		// Same run as before the steer, not a restarted one.
		expect(h.manager.getJob(first.id)?.generation).toBe(first.startGeneration);
		expect(h.manager.getJob(second.id)?.generation).toBe(second.startGeneration);

		// Each completion shows up exactly once on a later poll.
		first.gate.resolve("first result");
		second.gate.resolve("second result");
		await Promise.all([first.job.promise, second.job.promise]);
		const completed = await tool.execute("await-complete", { poll: [first.id, second.id] });
		const text = textOf(completed);
		expect(text).toContain("first result");
		expect(text).toContain("second result");
		expect(text.split("first result").length - 1).toBe(1);
		expect(text.split("second result").length - 1).toBe(1);
	}, 15_000);

	// The fold shortcut and the SDK background control name no wait, so they act
	// only on a foreground shell wait. With only a job poll in flight there is
	// nothing for them to background, the poll leaves no delivery slot, and the
	// eventual completion is a single ordinary delivery.
	it("never lets an implicitly-targeted fold resolve to a job await", async () => {
		const h = useHarness();
		const held = registerHeldJob(h, "implicit-immune await");
		const tool = new JobTool(h.session);
		const resultPromise = tool.execute("await-implicit", { poll: [held.id] });
		await Bun.sleep(100);

		// Nothing is available to background, and asking for it changes nothing.
		expect(h.coordinator.hasFoldableParticipant()).toBe(false);
		expect(h.coordinator.resolveTarget()).toBeUndefined();
		expect(h.session.hasForegroundBashBackgroundRequestHandler?.()).toBe(false);
		expect(await h.session.requestForegroundBashBackground?.("chord")).toBe(false);
		expect(await h.session.requestForegroundBashBackground?.("sdk_control")).toBe(false);
		expect(h.folds).toHaveLength(0);
		expect(h.coordinator.slotStateFor(held.job)).toBe("none");
		expect(h.manager.getJob(held.id)?.metadata?.foldReason).toBeUndefined();

		held.gate.resolve("implicit-immune result");
		await resultPromise;
		// No leftover slot: the completion is a single ordinary delivery.
		expect(h.coordinator.onDelivery(held.job, "implicit-immune result")).toEqual({ kind: "ordinary" });
	}, 15_000);

	// A foreground shell wait keeps the fold shortcut and the SDK background
	// control even when a job poll starts waiting after it. Each trigger folds
	// the shell wait with its own reason and leaves the job poll's job untouched.
	for (const trigger of ["chord", "sdk_control"] as const) {
		it(`keeps a foreground shell wait as the ${trigger} target when a job poll registers after it`, async () => {
			const h = useHarness();
			// A foreground shell wait: a bash-managed participant registered through
			// the session the same way the shell tool does.
			const foreground = registerHeldJob(h, "foreground shell");
			const detached: Array<{ reason: string }> = [];
			const bashAdapter: FoldAdapter = {
				kind: "bash-managed",
				jobId: foreground.id,
				jobGeneration: foreground.job.generation,
				label: foreground.job.label,
				cwdSensitive: true,
				originatingTurn: true,
				outputRef: { jobId: foreground.id, generation: foreground.job.generation, instruction: "tail it" },
				getJob: () => h.manager.getJob(foreground.id),
				detachObserver: receipt => {
					detached.push({ reason: receipt.reason });
					return "resolved";
				},
				resolveForegroundObserver: () => "resolved",
			};
			h.session.registerForegroundFoldParticipant?.(bashAdapter);

			// A job poll then starts waiting, after the shell wait.
			const held = registerHeldJob(h, "later job await");
			const pollPromise = new JobTool(h.session).execute("await-after-shell", { poll: [held.id] });
			await Bun.sleep(100);

			// The trigger still targets the shell wait, not the later job poll.
			expect(h.coordinator.resolveTarget()).toBe(bashAdapter);
			expect(await h.session.requestForegroundBashBackground?.(trigger)).toBe(true);
			expect(detached).toEqual([{ reason: trigger }]);
			// The job poll's job was not touched by the trigger.
			expect(h.coordinator.slotStateFor(held.job)).toBe("none");
			expect(h.manager.getJob(held.id)?.metadata?.foldReason).toBeUndefined();

			held.gate.resolve("later result");
			foreground.gate.resolve("shell result");
			await pollPromise;
		}, 15_000);
	}

	// A job that an earlier fold already moved to the background (set up through
	// the manager's existing `markBackgrounded`) still has its poll returned
	// promptly on a post-grace steer, keeps running, and its completion shows up
	// exactly once on a later poll.
	it("releases a steered await over an already-backgrounded job and delivers exactly once", async () => {
		const h = useHarness();
		const held = registerHeldJob(h, "previously folded");
		h.manager.markBackgrounded(held.id, held.job.generation, "chord");

		const startedAt = Date.now();
		const tool = new JobTool(h.session);
		const resultPromise = tool.execute("await-refold", { poll: [held.id] });
		await Bun.sleep(STEER_FOLD_GRACE_MS + 150);
		h.steer();
		await resultPromise;
		const elapsed = Date.now() - startedAt;

		// Returned well before the full window, and the same run is still going.
		expect(elapsed).toBeLessThan(POLL_WAIT_MS - 750);
		expect(h.manager.getJob(held.id)?.status).toBe("running");
		expect(h.manager.getJob(held.id)?.generation).toBe(held.startGeneration);

		// The completion shows up exactly once on a later poll.
		held.gate.resolve("refold result");
		await held.job.promise;
		const completed = await tool.execute("await-refold-complete", { poll: [held.id] });
		const text = textOf(completed);
		expect(text).toContain("refold result");
		expect(text.split("refold result").length - 1).toBe(1);
	}, 15_000);

	// A subagent (`task`) job watched by a poll is never folded by a steer: no
	// fold event, no recorded fold reason, no delivery slot, and the job keeps
	// running. Whether the poll itself returns early on the steer or waits for
	// the task is not asserted.
	it("watches a task-backed job without minting a fold on it", async () => {
		const h = useHarness();
		const task = registerHeldJob(h, "subagent task", "task");
		const resultPromise = new JobTool(h.session).execute("await-task", { poll: [task.id] });
		await Bun.sleep(STEER_FOLD_GRACE_MS + 150);
		expect(h.session.hasForegroundBashBackgroundRequestHandler?.()).toBe(false);
		h.steer();
		await Bun.sleep(100);

		expect(h.folds).toHaveLength(0);
		expect(h.manager.getJob(task.id)?.metadata?.foldReason).toBeUndefined();
		expect(h.coordinator.slotStateFor(task.job)).toBe("none");
		expect(h.manager.getJob(task.id)?.status).toBe("running");

		// Release the subagent so the poll settles; its result goes through the
		// manager's own delivery.
		task.gate.resolve("task result");
		await resultPromise;
		expect(h.folds).toHaveLength(0);
	}, 15_000);

	// A steer that arrives inside the grace window leaves the poll waiting. The
	// watched job is still running during the probe, so a return here can only
	// come from the steer, not from the job finishing first.
	it("does not fold a steer admitted inside the grace window", async () => {
		const h = useHarness();
		const held = registerHeldJob(h, "early await");
		const resultPromise = new JobTool(h.session).execute("await-early", { poll: [held.id] });
		await Bun.sleep(100);
		h.steer();

		// The poll is still waiting a moment later (still inside the grace window).
		const stillPending = Symbol("still-pending");
		const raced = await Promise.race([
			resultPromise.then(() => "returned-early" as const),
			Bun.sleep(300).then(() => stillPending),
		]);
		expect(raced).toBe(stillPending);
		expect(h.manager.getJob(held.id)?.status).toBe("running");

		// The wait ends normally once the job completes, with no fold.
		held.gate.resolve("early result");
		const result = await resultPromise;
		expect(h.folds).toHaveLength(0);
		expect(h.manager.getJob(held.id)?.metadata?.foldReason).toBeUndefined();
		expect(textOf(result)).toContain("early result");
	}, 15_000);

	// A steer late in the grace window (500 ms before it ends) is dropped, not
	// held over: once the window has passed with no new steer, the poll is still
	// waiting. A later steer then returns the poll promptly, and the job keeps
	// running and is delivered exactly once.
	it("ignores an early steer without blocking a later post-grace steer", async () => {
		const h = useHarness();
		const held = registerHeldJob(h, "early then late await");
		const tool = new JobTool(h.session);
		const startedAt = Date.now();
		const resultPromise = tool.execute("await-early-late", { poll: [held.id] });
		await Bun.sleep(STEER_FOLD_GRACE_MS - 500);
		h.steer();

		// Past the grace window with no new steer: the poll is still waiting.
		const stillPending = Symbol("still-pending");
		const raced = await Promise.race([
			resultPromise.then(() => "returned-early" as const),
			Bun.sleep(700).then(() => stillPending),
		]);
		expect(raced).toBe(stillPending);
		expect(h.manager.getJob(held.id)?.status).toBe("running");

		// A post-grace steer now returns the poll well before its own window.
		h.steer();
		await resultPromise;
		const elapsed = Date.now() - startedAt;
		expect(elapsed).toBeLessThan(POLL_WAIT_MS - 750);
		expect(h.manager.getJob(held.id)?.status).toBe("running");
		expect(h.manager.getJob(held.id)?.generation).toBe(held.startGeneration);

		held.gate.resolve("early-late result");
		await held.job.promise;
		const completed = await tool.execute("await-early-late-complete", { poll: [held.id] });
		const text = textOf(completed);
		expect(text).toContain("early-late result");
		expect(text.split("early-late result").length - 1).toBe(1);
	}, 15_000);

	// The grace window belongs to the poll, not to the job. A job that has
	// already run past it before the poll starts still gets the full window:
	// a steer 300 ms into the poll leaves it waiting, and a steer after the
	// poll's own first 2 seconds returns it promptly with the job still running.
	it("counts the grace window from the start of the poll for a job that started earlier", async () => {
		const h = useHarness();
		const held = registerHeldJob(h, "long-running await");
		await Bun.sleep(STEER_FOLD_GRACE_MS + 500);
		expect(h.manager.getJob(held.id)?.status).toBe("running");

		const tool = new JobTool(h.session);
		const pollStartedAt = Date.now();
		const resultPromise = tool.execute("await-older-job", { poll: [held.id] });
		await Bun.sleep(300);
		h.steer();

		// Inside the poll's first 2 seconds: the poll is still waiting.
		const stillPending = Symbol("still-pending");
		const raced = await Promise.race([
			resultPromise.then(() => "returned-early" as const),
			Bun.sleep(700).then(() => stillPending),
		]);
		expect(raced).toBe(stillPending);
		expect(h.manager.getJob(held.id)?.status).toBe("running");

		// Past the poll's first 2 seconds: a new steer returns the poll promptly.
		await Bun.sleep(Math.max(0, pollStartedAt + STEER_FOLD_GRACE_MS + 150 - Date.now()));
		h.steer();
		await resultPromise;
		const elapsed = Date.now() - pollStartedAt;
		expect(elapsed).toBeLessThan(POLL_WAIT_MS - 750);
		expect(h.manager.getJob(held.id)?.status).toBe("running");
		expect(h.manager.getJob(held.id)?.generation).toBe(held.startGeneration);

		held.gate.resolve("older-job result");
		await held.job.promise;
		const completed = await tool.execute("await-older-job-complete", { poll: [held.id] });
		const text = textOf(completed);
		expect(text).toContain("older-job result");
		expect(text.split("older-job result").length - 1).toBe(1);
	}, 15_000);
});
