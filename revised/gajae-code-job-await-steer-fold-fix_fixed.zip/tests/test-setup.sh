#!/bin/bash
# Setup for the gajae-code-job-await-steer-fold verifier.
#
# Dependencies are baked into the image: the bun store, the hoisted
# node_modules, and the compiled pi-natives N-API addon
# (packages/natives/native/pi_natives.linux-<arch>.node) are all present, and
# `bun test` runs entirely from that baked tree with no install step. The
# verifier phase has no package-registry DNS, so a fresh `bun install` cannot
# reach the registry and must not be a gate here.
#
# This script therefore only (a) re-asserts the install best-effort and offline
# (a no-op warm when nothing changed, logged but never fatal), and (b) hard-
# checks the two things the suites need: the bun toolchain and the
# compiled native addon. A missing addon is rebuilt from the baked Rust
# toolchain; anything that still cannot run fails loudly.

set -uo pipefail

REPO_DIR="/repo/gajae-code"
cd "$REPO_DIR"

export REPO_NAME=gajae-code

# bun is on PATH at /opt/bun/bin (baked by the image).
command -v bun >/dev/null || { echo "bun not found on PATH" >&2; exit 1; }
echo "bun: $(bun --version)"

# Best-effort offline warm against the baked store. The closure is already
# complete, so this is a no-op when nothing changed; when the registry is
# unreachable (the normal offline case) it is skipped without failing, because
# the baked node_modules below is the real source of truth.
if bun install --frozen-lockfile --offline > /tmp/bun-install.log 2>&1; then
  echo "bun install (frozen, offline) OK"
else
  echo "offline bun install warm skipped (using the baked dependency closure); last lines:" >&2
  tail -8 /tmp/bun-install.log >&2 || true
fi

# Real gate 1: the baked hoisted node_modules the suites import from must exist.
if [ ! -d "$REPO_DIR/node_modules" ]; then
  echo "baked node_modules is missing; the dependency closure was not restored" >&2
  exit 1
fi

# Real gate 2: the native addon must be present for suites that drive through
# the job tool. It is baked; rebuild only if it is absent (needs the Rust
# toolchain, also baked). Rebuild is loud and only on the verifier side.
ADDON_GLOB=(packages/natives/native/pi_natives.linux-*.node)
if ! ls "${ADDON_GLOB[@]}" >/dev/null 2>&1; then
  echo "native addon missing; rebuilding (verifier phase):" >&2
  bun --cwd packages/natives run build > /tmp/native-build.log 2>&1 || {
    echo "native addon rebuild failed:" >&2; tail -80 /tmp/native-build.log >&2; exit 1;
  }
  echo "native addon rebuilt"
fi
