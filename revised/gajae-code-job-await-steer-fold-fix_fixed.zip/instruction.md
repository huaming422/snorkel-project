## Task

If I send a steer while the agent is blocked in a `job poll` on a running background job, my message goes nowhere.
The poll just keeps waiting until its own wait window runs out, and only then does the agent see what I typed.

Foreground `bash` doesn't have this problem.
If the command has been running for at least 2 seconds when my steer arrives, the wait ends right away, the command carries on in the background, and its output turns up on a later turn.
A steer that lands in those first 2 seconds is left alone and handled after the command finishes, and a steer that comes later still works even if an earlier one came in too soon.

Please give job waits the same treatment, with the same 2-second rule counted from when the poll started waiting.
When a steer comes in after that point, the poll should return promptly instead of sitting out its window.
The jobs it was watching must keep running on their original deadlines.
Don't kill, cancel or restart them to get the poll to return.
Each job's result should still show up exactly once on a later turn, for example in the next poll.
That also goes for a job that was already sent to the background earlier, for instance with the fold shortcut.

Subagent (`task`) jobs are a different case.
A steer must not mark them as folded, so no fold reason or fold notification for them.
They keep running and report back the way they do today.

The fold shortcut (Alt+Shift+B by default) and the SDK `bash.background` control are for the foreground `bash` command.
They should keep acting on that command even if a `job poll` started waiting after it, and when only a job poll is waiting they should find nothing to background.

The `bash` steer behavior is fine as it is, so leave it working the way it does now.
