## Task

We've had a handful of operator reports about the usage panel, and the numbers really are off.
None of it is real model work going missing or appearing out of nowhere; it's the bookkeeping.

Branching a conversation counts its history twice.
The branch shows the earlier messages, which is right, but the runs and tokens behind them get added to the totals a second time, so every fork pushes the numbers up.
Those copied messages should stay in the branch as they are, usage details included, and count only once, for the conversation they came from.
That goes for branches people made before this fix too, and for a branch of a branch.
A new run inside a branch is real work and does count.
Two separate conversations that happen to share message and call ids (an imported copy, say) are still two conversations and are counted separately.

Editing the first prompt makes the usage of the title generation that already ran drop out of the totals.
Once a title generation has finished, its usage should stay counted when the first prompt is edited, when the title is generated again afterwards (both generations count), and when the usage data is rebuilt from the saved conversations.
Only deleting the conversation should take it away.

When the local database is read-only for a moment (usually a lock), any usage measurement saved in that window is gone for good.
Once writes work again, the measurements lost that way should be saved and show up in the totals by the time the next measurement is saved, without re-running anything.
If a conversation was deleted in the meantime, drop its measurement instead of writing it back.
A measurement with bad numbers (a negative token count, for example) shouldn't be saved, and it shouldn't hold up the ones that come after it.

The coverage line reads something like "Token totals are available for 1 of 2 runs in this period."
That count is pieced together from run and response numbers that don't match up (automatic corrections, runs that cross midnight), so it can be flat wrong while looking precise.
We'd rather not show a figure we can't back up, so take the exact count out of that line.
Keep the "Older conversations or some providers may not report usage." sentence, so people still know the totals can be incomplete.

Totals worked out straight from the saved conversations should match what the panel shows, branches included.
Leave the rest of the counting as it is: automatic calls add tokens but aren't runs, a run counts on the day it started, and its tokens count on the day the answer finished.

This is an accounting fix, so no new tables, columns or migrations.
