// @ts-nocheck
//
// Usage accounting checks. Every case drives the existing public surface only:
// the renderer session store actions build conversations, the shared Session
// codec round-trips them the way the app saves them, and a real on-disk SQLite
// project is read back through SessionProjectionRepository.usage() and the
// renderer analytics selectors.
//
// Branch cases read run and token totals plus the saved fields of every copied
// message. Title cases read totals and stored auxiliary rows. Recorder cases
// read stored rows and usage() totals after the database is writable again. The
// schema case reads the tables, columns and migration ledger of a migrated
// database.

import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import type { PrismaClient } from '@prisma/client'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

vi.mock('electron', () => ({ app: { getPath: () => '/home/user', isPackaged: true } }))

import {
  createSessionFile,
  persistedChatSessionCodec,
  type PersistedChatSession
} from '../../shared/session-persistence'
import {
  createInitialSessionState,
  toPersistedSession,
  useSessionStore
} from '../../renderer/src/stores/session-store'
import {
  buildTokenUsageAnalytics,
  buildTokenUsageAnalyticsFromProjection,
  selectTokenUsageSummary,
  type TokenUsageSummary
} from '../../renderer/src/pages/settings/token-usage-analytics'
import { createProjectDbClient, migrateApplicationDatabase } from '../projects/prisma-client'
import { SessionProjectionRepository } from './projection'
import {
  SessionAuxiliaryTurnUsageRecorder,
  type SessionAuxiliaryTurnUsageRecord
} from './auxiliary-turn-usage'

const usage = { inputTokens: 10, cacheTokens: 2, outputTokens: 3, turnCount: 1 }
const today = new Date(2026, 8, 6, 12).getTime()
let now = today
let client: PrismaClient
let storageRoot: string
let repository: SessionProjectionRepository

beforeEach(async () => {
  now = today
  vi.spyOn(Date, 'now').mockImplementation(() => now)
  useSessionStore.setState(createInitialSessionState())
  storageRoot = await mkdtemp(join(tmpdir(), 'open-science-usage-accounting-'))
  client = createProjectDbClient(storageRoot)
  await migrateApplicationDatabase(client)
  await client.project.create({ data: { id: 'project-1', name: 'Project' } })
  repository = new SessionProjectionRepository(async () => client)
})

afterEach(async () => {
  vi.restoreAllMocks()
  await client?.$disconnect()
  if (storageRoot) await rm(storageRoot, { recursive: true, force: true })
})

// A single human run: user prompt → agent answer → finishRun. `reported`
// controls whether turnUsage/model-call usage is attached; `application` marks
// the prompt as an automatic/application-attributed turn (a correction) rather
// than a human turn.
const run = (
  sessionId: string,
  reported = true,
  application = false
): { prompt: { messageId: string }; answer: { messageId: string } } => {
  const prompt = useSessionStore.getState().appendUserMessage({
    sessionId,
    projectId: 'project-1',
    cwd: '/workspace',
    agentFrameworkId: 'opencode',
    content: application ? 'Reviewer correction' : 'Human prompt',
    ...(application
      ? {
          attribution: {
            kind: 'application' as const,
            feature: 'reviewer' as const,
            purpose: 'correction' as const,
            causeReviewId: 'review-1'
          }
        }
      : {})
  })!
  now += 1
  const answer = useSessionStore.getState().appendAgentMessageChunk({
    sessionId,
    streamId: `${prompt.messageId}-stream`,
    eventId: `${prompt.messageId}-event`,
    content: 'Answer'
  })!
  now += 1
  useSessionStore
    .getState()
    .finishRun(
      sessionId,
      reported ? usage : undefined,
      undefined,
      undefined,
      reported ? [{ id: `${prompt.messageId}-call`, index: 0, ...usage }] : undefined
    )
  return { prompt, answer }
}

// Persist through the exact path the app uses: Session store → codec → the
// JSON round-trip the renderer performs on save → repository prepare/commit.
const save = async (id: string): Promise<PersistedChatSession> => {
  const state = useSessionStore.getState()
  const input = persistedChatSessionCodec.parse(
    JSON.parse(
      JSON.stringify(
        createSessionFile(
          toPersistedSession(
            state.sessions.find((session) => session.id === id)!,
            state.streamingMessages
          )
        )
      )
    )
  )
  const prepared = await repository.prepareSave(input)
  await repository.commitSave(prepared)
  return prepared
}

const summary = async (period: 'all' | 'today' = 'all'): Promise<TokenUsageSummary> =>
  selectTokenUsageSummary(buildTokenUsageAnalyticsFromProjection(await repository.usage(), now), period)

// The panel's fallback: totals worked out from the saved sessions themselves.
const savedSummary = (sessions: readonly PersistedChatSession[]): TokenUsageSummary =>
  selectTokenUsageSummary(buildTokenUsageAnalytics(sessions, now), 'all')

const auxRecord = (sessionId: string, eventId: string): SessionAuxiliaryTurnUsageRecord => ({
  projectId: 'project-1',
  sessionId,
  eventId,
  source: 'side-chat',
  frameworkId: 'opencode',
  model: 'model',
  completedAtMs: 100,
  usage: { inputTokens: 10, cacheTokens: 2, outputTokens: 3 }
})

// The saved fields a copied message keeps. Event and stream ids belong to the
// run that wrote the message and are not carried into another session; fields
// a copy adds are allowed.
const keptFields = ({ eventIds, streamId, ...fields }: PersistedChatMessage): object =>
  JSON.parse(JSON.stringify(fields))

const expectCopied = (
  branch: PersistedChatSession,
  originals: readonly PersistedChatMessage[]
): void => {
  for (const original of originals) {
    expect(branch.messages.find((message) => message.id === original.id)).toMatchObject(
      keptFields(original)
    )
  }
}

// Column count of every table at the pinned commit, after every migration ran.
const SCHEMA_COLUMNS: Record<string, number> = {
  ArtifactLineage: 8, ArtifactLiteratureManifest: 7, ArtifactMessageSnapshot: 13,
  ArtifactVersion: 38, ArtifactVersionInput: 18, ComputeAuthOperation: 6, ComputeCredential: 4,
  ComputeHost: 19, ComputeJob: 39, ComputeJobOperation: 13, ContentBlob: 8, FileOriginSession: 9,
  Finding: 11, GrantedLocalRoot: 6, LiteratureAttachment: 7, LiteratureAttachmentVersion: 10,
  LiteratureCollection: 8, LiteratureCollectionItem: 4, LiteratureCreator: 8,
  LiteratureIdentifier: 7, LiteratureInboxCandidate: 16, LiteratureInboxPdf: 9,
  LiteratureItem: 22, LiteratureItemCreator: 4, LiteratureSourceRecord: 9, ManagedFile: 18,
  ManagedFileSessionSync: 9, ManagedFileVersionWriteOperation: 17, MemoryCategory: 9,
  MemoryEntry: 11, MemoryEntryFts: 1, MemoryEntryFts_config: 2, MemoryEntryFts_data: 2,
  MemoryEntryFts_docsize: 2, MemoryEntryFts_idx: 3, MemorySettings: 5,
  NotificationInboxItem: 16, PendingSessionReconciliation: 4, PermissionGrant: 11,
  PermissionGrantSeed: 2, Project: 11, ProjectDeletionIntent: 2, ProjectLiterature: 4,
  ProjectPreviewState: 5, Review: 12, ReviewFindingDisposition: 10, ReviewScopeSnapshot: 12,
  Session: 19, SessionArtifactRef: 3, SessionAuxiliaryTurnUsage: 13, SessionModelCallUsage: 16,
  SessionNumberSequence: 2, SessionProjectionState: 3, SessionRun: 3, SessionTurnUsage: 13,
  Tag: 9, TagAssignment: 4, UnreadTaskSession: 2, UploadFile: 8, UploadVersion: 19,
  VisionEvidence: 15, _open_science_migrations: 3
}

const saveEmptySession = async (id: string): Promise<void> => {
  const session = await repository.prepareSave({
    id,
    projectId: 'project-1',
    title: 'Session',
    cwd: '/workspace',
    status: 'idle',
    createdAt: 1,
    updatedAt: 1,
    messages: []
  })
  await repository.commitSave(session)
}

describe('usage accounting through store, Session codec, and SQLite', () => {
  it('branch_excludes_inherited: a branch keeps inherited history visible but does not re-count it', async () => {
    const { prompt, answer } = run('source')
    const source = await save('source')
    const originalDays = buildTokenUsageAnalyticsFromProjection(await repository.usage(), now).last30Days
    expect(await summary()).toMatchObject({ totalSessions: 1, totalRuns: 1, totalTokens: 15 })

    now += 86_400_000
    const branch = useSessionStore
      .getState()
      .branchInNewSession({ sourceSessionId: 'source', sourceMessageId: answer.messageId })!
    useSessionStore
      .getState()
      .bindPendingSession({ pendingSessionId: branch.sessionId, sessionId: 'branch' })
    const saved = await save('branch')

    // The copied prompt and answer stay in the branch with their saved fields,
    // usage included ...
    expect(source.messages.map((message) => message.id)).toEqual([prompt.messageId, answer.messageId])
    expectCopied(saved, source.messages)
    expect(saved.messages.find((message) => message.id === answer.messageId)?.turnUsage).toEqual(usage)
    // ... but contributes no new run or token to the totals.
    expect(await summary()).toMatchObject({ totalSessions: 2, totalRuns: 1, totalTokens: 15 })
    const branchDays = buildTokenUsageAnalyticsFromProjection(await repository.usage(), now).last30Days
    expect(branchDays.find((day) => day.dayStart === originalDays.at(-1)!.dayStart)?.totalTokens).toBe(15)
  })

  it('legacy_branch_excludes_inherited: a branch saved by an older build is not re-counted either', async () => {
    const { answer } = run('source')
    const source = await save('source')
    now += 86_400_000
    const branch = useSessionStore
      .getState()
      .branchInNewSession({ sourceSessionId: 'source', sourceMessageId: answer.messageId })!
    useSessionStore
      .getState()
      .bindPendingSession({ pendingSessionId: branch.sessionId, sessionId: 'branch' })
    const saved = await save('branch')

    // An older branch file holds the source's saved messages unchanged, under the
    // branch's own id, dates and branchSource fields. Building it from the source
    // JSON means no field added by a newer build is present, whatever its name.
    const { sessionId, agentFrameId, messageBranchId, headMessageId } = saved.branchSource!
    const legacy = {
      ...structuredClone(source),
      id: saved.id,
      number: saved.number,
      title: saved.title,
      createdAt: saved.createdAt,
      updatedAt: saved.updatedAt,
      branchSource: {
        sessionId,
        ...(agentFrameId ? { agentFrameId } : {}),
        ...(messageBranchId ? { messageBranchId } : {}),
        headMessageId
      }
    }
    await repository.replaceAll([source, legacy])

    expect(await summary()).toMatchObject({ totalSessions: 2, totalRuns: 1, totalTokens: 15 })
    expect(savedSummary([source, legacy])).toMatchObject({ totalSessions: 2, totalRuns: 1, totalTokens: 15 })
  })

  it('nested_and_independent_identity: nested branches and independent sessions reusing IDs stay independent', async () => {
    const { answer } = run('source')
    const source = await save('source')
    now += 86_400_000
    const branch = useSessionStore
      .getState()
      .branchInNewSession({ sourceSessionId: 'source', sourceMessageId: answer.messageId })!
    useSessionStore
      .getState()
      .bindPendingSession({ pendingSessionId: branch.sessionId, sessionId: 'branch' })
    await save('branch')
    expect(await summary()).toMatchObject({ totalSessions: 2, totalRuns: 1, totalTokens: 15 })

    // A real new run on the branch is counted.
    const next = run('branch')
    const savedBranch = await save('branch')
    expect(await summary()).toMatchObject({ totalSessions: 2, totalRuns: 2, totalTokens: 30 })

    // Nesting another branch adds a session but no run (inherited prefix only).
    const nested = useSessionStore
      .getState()
      .branchInNewSession({ sourceSessionId: 'branch', sourceMessageId: next.answer.messageId })!
    useSessionStore
      .getState()
      .bindPendingSession({ pendingSessionId: nested.sessionId, sessionId: 'nested' })
    const savedNested = await save('nested')
    // Each copied message keeps the fields it was first saved with.
    expect(savedNested.messages).toHaveLength(4)
    expectCopied(savedNested, [
      ...source.messages,
      ...savedBranch.messages.filter(
        (message) => message.id === next.prompt.messageId || message.id === next.answer.messageId
      )
    ])
    expect(await summary()).toMatchObject({ totalSessions: 3, totalRuns: 2, totalTokens: 30 })
    expect(savedSummary([source, savedBranch, savedNested])).toMatchObject({
      totalSessions: 3,
      totalRuns: 2,
      totalTokens: 30
    })

    // An independent session that reuses the source's message/call IDs must keep
    // its own execution identity: equal IDs do NOT collapse into shared accounting.
    const independent = await repository.prepareSave({ ...source, id: 'independent', number: undefined })
    await repository.commitSave(independent)
    expect(await summary()).toMatchObject({ totalSessions: 4, totalRuns: 3, totalTokens: 45 })
    expect(savedSummary([source, savedBranch, savedNested, independent])).toMatchObject({
      totalSessions: 4,
      totalRuns: 3,
      totalTokens: 45
    })
  })

  it('application_calls_counted_not_as_runs: automatic calls add tokens but not human runs', async () => {
    run('coverage')
    run('coverage', false)
    run('coverage', true, true)
    await save('coverage')
    expect(await summary()).toMatchObject({ newRuns: 2, totalTokens: 30 })
  })

  it('run_date_grouping: runs count on start date, tokens on completion date (cross-midnight)', async () => {
    now = new Date(2026, 8, 5, 23, 59).getTime()
    const prompt = useSessionStore
      .getState()
      .appendUserMessage({ sessionId: 'midnight', projectId: 'project-1', content: 'Late prompt' })!
    now = new Date(2026, 8, 6, 0, 1).getTime()
    useSessionStore
      .getState()
      .appendAgentMessageChunk({
        sessionId: 'midnight',
        streamId: 'late-answer',
        eventId: 'late-event',
        content: 'Answer'
      })
    useSessionStore.getState().finishRun('midnight', usage)
    expect(useSessionStore.getState().sessions[0].messages[1].responseToMessageId).toBe(prompt.messageId)

    now = today
    run('midnight', false)
    await save('midnight')

    // Today's token total includes the run whose completion crossed midnight;
    // today's run count does not (that run started the prior day).
    expect(await summary('today')).toMatchObject({ newRuns: 1, totalTokens: 15 })
    expect(await summary()).toMatchObject({ newRuns: 2 })
  })

  it('title_usage_retained_across_edit_and_rebuild: finished title usage survives edits, a new title and rebuilds', async () => {
    const { prompt } = run('details')
    const details = {
      sourceMessageId: prompt.messageId,
      requestId: 'details-request',
      status: 'succeeded' as const,
      queuedAt: now,
      startedAt: now,
      completedAt: now,
      frameworkId: 'opencode' as const,
      model: 'title-model',
      reasoningEffort: 'default' as const,
      usage: { inputTokens: 4, cacheTokens: 1, outputTokens: 2 }
    }
    useSessionStore.setState((state) => ({
      sessions: state.sessions.map((session) => ({ ...session, sessionDetailsGeneration: details }))
    }))
    await save('details')
    expect(await summary()).toMatchObject({ totalTokens: 22 })

    // First-prompt edit: the prompt is cut and replaced by a new message, then the
    // session is saved through the codec. The title usage stays in the totals.
    now += 1
    useSessionStore.getState().truncateSessionFromMessage('details', prompt.messageId)
    const editedPrompt = useSessionStore
      .getState()
      .appendUserMessage({ sessionId: 'details', content: 'Edited prompt' })!
    const edited = await save('details')
    expect(await summary()).toMatchObject({ totalTokens: 22 })

    // Rebuilding from the saved session twice keeps one stored row and the same total.
    await repository.replaceAll([edited])
    await repository.replaceAll([edited])
    expect(await client.sessionAuxiliaryTurnUsage.count()).toBe(1)
    expect(await summary()).toMatchObject({ totalTokens: 22 })

    // A second finished title generation for the edited prompt adds its own usage.
    useSessionStore.setState((state) => ({
      sessions: state.sessions.map((session) => ({
        ...session,
        sessionDetailsGeneration: {
          ...details,
          sourceMessageId: editedPrompt.messageId,
          requestId: 'details-request-2'
        }
      }))
    }))
    const regenerated = await save('details')
    await save('details')
    await repository.clearForRebuild()
    await repository.replaceAll([regenerated])
    expect(await client.sessionAuxiliaryTurnUsage.count()).toBe(2)
    expect(await summary()).toMatchObject({ totalTokens: 29 })

    // Deleting the whole session is the only thing that removes the title usage.
    await repository.commitDelete('project-1', 'details')
    expect(await client.sessionAuxiliaryTurnUsage.count()).toBe(0)
  })

  it('auxiliary_retry_recovers_after_readonly: measurements refused while read-only are saved once writes work again', async () => {
    await saveEmptySession('session')
    const recorder = new SessionAuxiliaryTurnUsageRecorder(async () => client)

    // SQLite itself refuses the writes (no mocking), as in a short read-only
    // window; reads still work. How record() reports a refused write (rejecting
    // or resolving) is left open, so either outcome is accepted.
    await client.$executeRawUnsafe('PRAGMA query_only = ON')
    await recorder.record(auxRecord('session', 'first')).catch(() => undefined)
    await recorder.record(auxRecord('session', 'first-b')).catch(() => undefined)
    expect(await client.sessionAuxiliaryTurnUsage.count()).toBe(0)
    await client.$executeRawUnsafe('PRAGMA query_only = OFF')

    // The next measurement saves normally. Once it is saved and usage is read,
    // both refused measurements are stored, each exactly once.
    await recorder.record(auxRecord('session', 'second'))
    const total = (await repository.usage()).usageEvents.reduce(
      (sum, event) => sum + event.inputTokens + event.cacheTokens + event.outputTokens,
      0
    )
    const rows = await client.sessionAuxiliaryTurnUsage.findMany({ orderBy: { eventId: 'asc' } })
    expect(rows.map((row) => row.eventId)).toEqual(['first', 'first-b', 'second'])
    expect(total).toBe(45)
  })

  it('auxiliary_retry_discards_deleted_and_malformed: a deleted session or bad numbers never get stored or hold up later records', async () => {
    await saveEmptySession('session')
    await saveEmptySession('session-2')
    const recorder = new SessionAuxiliaryTurnUsageRecorder(async () => client)
    const stored = async (): Promise<string[]> =>
      (
        await client.sessionAuxiliaryTurnUsage.findMany({
          orderBy: [{ sessionId: 'asc' }, { eventId: 'asc' }]
        })
      ).map((row) => `${row.sessionId}/${row.eventId}`)

    // Two measurements are refused while read-only, one per session; then the
    // first session is deleted.
    await client.$executeRawUnsafe('PRAGMA query_only = ON')
    await recorder.record(auxRecord('session', 'first')).catch(() => undefined)
    await recorder.record(auxRecord('session-2', 'kept')).catch(() => undefined)
    await client.$executeRawUnsafe('PRAGMA query_only = OFF')
    await client.session.update({ where: { id: 'session' }, data: { deletedAtMs: 200n } })

    // A later record for the live session saves normally. The deleted session's
    // measurement is never written; the live session's refused one is.
    await recorder.record(auxRecord('session-2', 'later'))
    await repository.usage()
    expect(await stored()).toEqual(['session-2/kept', 'session-2/later'])

    // Negative token counts are never stored and do not hold up the next valid
    // record. How record() reports the refusal is left open.
    const malformed = auxRecord('session-2', 'invalid')
    malformed.usage.inputTokens = -1
    await recorder.record(malformed).catch(() => undefined)
    const malformedOutput = auxRecord('session-2', 'invalid-output')
    malformedOutput.usage.outputTokens = -1
    await recorder.record(malformedOutput).catch(() => undefined)
    await recorder.record(auxRecord('session-2', 'valid'))
    await repository.usage()
    expect(await stored()).toEqual(['session-2/kept', 'session-2/later', 'session-2/valid'])
  })

  it('renderer_analytics_matches_projection: both accounting surfaces agree on a branched scenario', async () => {
    const { answer } = run('source')
    await save('source')
    now += 86_400_000
    const branch = useSessionStore
      .getState()
      .branchInNewSession({ sourceSessionId: 'source', sourceMessageId: answer.messageId })!
    useSessionStore
      .getState()
      .bindPendingSession({ pendingSessionId: branch.sessionId, sessionId: 'branch' })
    await save('branch')

    // Renderer analytics over the raw persisted sessions ...
    const state = useSessionStore.getState()
    const rawSessions = state.sessions.map((session) =>
      persistedChatSessionCodec.parse(
        JSON.parse(
          JSON.stringify(createSessionFile(toPersistedSession(session, state.streamingMessages)))
        )
      )
    )
    const fromRaw = selectTokenUsageSummary(buildTokenUsageAnalytics(rawSessions, now), 'all')
    // ... and the main-process SQLite projection must agree.
    const fromProjection = selectTokenUsageSummary(
      buildTokenUsageAnalyticsFromProjection(await repository.usage(), now),
      'all'
    )
    expect(fromRaw.totalSessions).toBe(fromProjection.totalSessions)
    expect(fromRaw.totalRuns).toBe(fromProjection.totalRuns)
    expect(fromRaw.totalTokens).toBe(fromProjection.totalTokens)
    expect(fromProjection).toMatchObject({ totalSessions: 2, totalRuns: 1, totalTokens: 15 })
  })

  it('schema_unchanged: a migrated database has the same tables, columns and migrations as before', async () => {
    const tables = await client.$queryRawUnsafe<{ name: string }[]>(
      `SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' ORDER BY name`
    )
    const columns: Record<string, number> = {}
    for (const { name } of tables) {
      columns[name] = (await client.$queryRawUnsafe<unknown[]>(`PRAGMA table_info("${name}")`)).length
    }
    expect(columns).toEqual(SCHEMA_COLUMNS)

    const migrations = await client.$queryRawUnsafe<{ id: string }[]>(
      'SELECT id FROM "_open_science_migrations" ORDER BY id'
    )
    expect(migrations).toHaveLength(30)
    expect(migrations.at(-1)?.id).toBe('0030_literature_foundation')
  })
})
