// @vitest-environment jsdom
// @ts-nocheck
//
// Coverage note check. Renders the real TokenUsagePanel through the repo's own
// render setup (createRoot + act, the root vitest config's jsdom polyfills and
// i18n setup) from saved sessions in which two runs fall in the period and only
// one of them reported usage, then reads the rendered DOM only:
//
//   - no exact share of runs ("1 of 2 runs", "1/2 runs", "1 run out of 2", "50% of runs")
//     anywhere in the panel;
//   - the "Older conversations or some providers may not report usage." sentence
//     is still shown;
//   - the token totals still render.

import { act } from 'react'
import { createRoot, type Root } from 'react-dom/client'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

import type { PersistedChatMessage, PersistedChatSession } from '../../../../shared/session-persistence'
import type { Project } from '../../../../shared/projects'
import { TokenUsagePanel } from './TokenUsagePanel'

const localTime = (year: number, month: number, day: number, hour = 12): number =>
  new Date(year, month - 1, day, hour).getTime()

const message = (
  id: string,
  role: PersistedChatMessage['role'],
  createdAt: number,
  overrides: Partial<PersistedChatMessage> = {}
): PersistedChatMessage => ({
  id,
  role,
  content: id,
  status: 'complete',
  eventIds: [],
  createdAt,
  updatedAt: createdAt,
  ...overrides
})

// A session with two human runs in the period and only one that reported usage:
// yesterday's agent answer carries turnUsage, today's does not.
const coverageGapSession = (now: number): PersistedChatSession => {
  const yesterday = new Date(now)
  yesterday.setDate(yesterday.getDate() - 1)
  const yesterdayAt = yesterday.getTime()

  return {
    id: 'session-1',
    projectId: 'project-1',
    title: 'Usage session',
    cwd: '/workspace',
    status: 'idle',
    artifacts: [],
    createdAt: yesterdayAt,
    updatedAt: now,
    messages: [
      message('user-yesterday', 'user', yesterdayAt),
      message('agent-yesterday', 'agent', yesterdayAt, {
        completedAt: yesterdayAt,
        turnUsage: { inputTokens: 100, cacheTokens: 20, outputTokens: 30 }
      }),
      message('user-today', 'user', now),
      message('agent-today', 'agent', now, { turnUsageUnavailable: true })
    ]
  }
}

const createProject = (now: number): Project => ({
  id: 'project-1',
  name: 'Usage project',
  description: '',
  isExample: false,
  createdAt: now,
  updatedAt: now
})

// An exact share of runs, e.g. "1 of 2 runs", "3 out of 4 runs", "1/2 runs", "1 run out of 2",
// "1 of the 2 runs", "50% of runs".
const EXACT_RUN_SHARE =
  /\b\d+\s*(?:of|out\s+of|\/)\s*(?:the\s+)?\d+\s+runs?\b|\b\d+\s+runs?\s+(?:out\s+)?of\s+(?:the\s+)?\d+\b|\b\d+(?:\.\d+)?\s*%\s*of\s+(?:the\s+)?runs?\b/i
const KEPT_NOTE = 'Older conversations or some providers may not report usage.'

let container: HTMLDivElement
let root: Root
const originalApi = window.api

beforeEach(() => {
  container = document.createElement('div')
  document.body.appendChild(container)
  root = createRoot(container)
})

afterEach(() => {
  act(() => root.unmount())
  vi.useRealTimers()
  window.api = originalApi
  container.remove()
  document.body.innerHTML = ''
})

describe('TokenUsagePanel coverage note', () => {
  it('coverage_note_has_no_exact_run_ratio: a reported/unreported mix shows no exact share of runs and keeps the note', () => {
    const now = localTime(2026, 8, 15, 18)

    act(() => {
      root.render(
        <TokenUsagePanel sessions={[coverageGapSession(now)]} projects={[createProject(now)]} now={now} />
      )
    })

    expect(document.body.textContent ?? '').not.toMatch(EXACT_RUN_SHARE)

    // The kept sentence is still shown.
    expect(document.body.textContent ?? '').toContain(KEPT_NOTE)

    // Token totals still render: 100 + 20 + 30 = 150.
    const summary = document.body.querySelector('[data-slot="token-usage-summary"]')
    expect(summary?.textContent).toContain('Total tokens')
    expect(summary?.textContent).toContain('150')
  })
})
