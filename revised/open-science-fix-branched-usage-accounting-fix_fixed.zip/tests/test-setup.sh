#!/usr/bin/env bash
# Environment bootstrap for the verifier.
#
# open-science's vitest runs TypeScript source directly through the workspace
# aliases (resolve.alias '@' -> src/renderer/src in vitest.config.ts), so there
# is no dist/ build step to replay: an edit to src/ is visible immediately.
# What the verifier DOES need is a generated Prisma client whose fingerprint
# matches prisma/schema.prisma, because `pretest`
# (scripts/check-prisma-client.mjs) refuses to run the suite otherwise, and the
# SessionProjectionRepository tests open a real on-disk SQLite project through
# that client.
#
# Dependencies are already baked into the image at the base commit (npm ci ran
# in the Docker build, and its postinstall ran `prisma generate`). This script
# is offline-first: it only touches the network as a logged fallback if the
# baked client is somehow missing. The harbor runner sources (not exec's) this
# file so any env it exports stays live for the verifier subprocess.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/open-science}"
export REPO_DIR
cd "$REPO_DIR"

# vitest must be resolvable from the workspace root. A failure here means a
# corrupted node_modules; bail now rather than on a confusing "command not
# found" mid-run.
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest binary missing from node_modules/.bin/." >&2
    echo "test-setup.sh: node_modules looks corrupted; attempting offline npm ci." >&2
    npm ci --offline --ignore-scripts \
        || { echo "test-setup.sh: offline npm ci failed; falling back to online." >&2; \
             npm ci --ignore-scripts; }
fi

# Ensure the Prisma client exists and matches prisma/schema.prisma. If the
# baked client is already in sync, check-prisma-client.mjs is a no-op and we
# skip regeneration entirely (offline-first). Only regenerate when it reports a
# mismatch or is absent.
if node scripts/check-prisma-client.mjs >/tmp/prisma-check.log 2>&1; then
    echo "test-setup.sh: Prisma client is in sync; no regeneration needed."
else
    echo "test-setup.sh: Prisma client out of date or missing; regenerating..." >&2
    cat /tmp/prisma-check.log >&2 || true
    # `prisma generate` uses the engine binaries already cached in the image;
    # with network available in the verifier phase it will fetch only if a
    # cache entry is missing.
    npx --no-install prisma generate > /tmp/prisma-generate.log 2>&1 \
        || { echo "test-setup.sh: prisma generate failed:" >&2; \
             tail -80 /tmp/prisma-generate.log >&2; exit 1; }
    node scripts/check-prisma-client.mjs \
        || { echo "test-setup.sh: Prisma client still out of sync after generate." >&2; exit 1; }
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
