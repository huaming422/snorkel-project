// @ts-nocheck
//
// Behavioral coverage for how a ChatGPT-subscription Codex session requests
// and reports its usable context window, through four existing seams:
//
//   1. ProviderRuntimeProjectionOwner.resolveRuntimeTarget and the Codex
//      framework's prepareModelConfig: for every model the OpenAI catalog
//      lists, the launch config requests that model's published window and an
//      auto-compaction limit within it.
//   2. The same pair with a model the catalog does not list (or no model):
//      neither launch-config key is emitted.
//   3. AcpContextUsagePolicy.resolve: the window surfaced to the usage UI and
//      the preflight estimate is left unset for a Codex backend on every
//      route, and stays the provider window for Claude Code and OpenCode.
//   4. AcpModelChangeWorkflow.apply: a mid-session switch to a different
//      window requests a reconnect and sends no live model switch; a switch
//      between equal windows is applied live with no reconnect.
//
// Assertions are on the launch config JSON, the resolved selectedWindow and
// the requests the workflow makes (reconnect, live config switch, context
// tracker restart).

import type { ActiveSession, ClientConnection, SessionConfigOption } from '@agentclientprotocol/sdk'
import { getOfficialVendor } from '@aipoch/providers'
import { describe, expect, it, vi } from 'vitest'

import type { SessionPermissionProfileState } from '../../shared/permission-profiles'
import type { AgentModelChangeTarget } from '../agent-framework'
import { claudeCodeFramework, getAgentFramework, opencodeFramework } from '../agent-framework'
import type {
  AcpBackendGenerationOwner,
  AcpBackendGenerationView
} from './backend-generation-owner'
import type { AcpConnectionResourceOwner } from './connection-resource-owner'
import { AcpContextUsagePolicy } from './context-usage-policy'
import type { ContextUsageTracker } from './context-usage-tracker'
import { AcpModelChangeWorkflow } from './model-change-workflow'
import type { AcpSessionConfigurator } from './session-configurator'
import { AcpSessionRegistry } from './session-registry'
import { ProviderRuntimeProjectionOwner } from '../settings/provider-runtime-projection'
import type { StoredProvider } from '../settings/types'

const codexFramework = getAgentFramework('codex')

// Every model the OpenAI catalog lists, with its published window. The two
// spot values below keep the loop from passing on an empty or one-window list.
const CATALOG_MODELS = (getOfficialVendor('openai')?.models ?? []).map(
  ({ id, contextWindow }) => [id, contextWindow] as const
)
const SPOT_WINDOWS = [
  ['gpt-5.4', 1_050_000],
  ['gpt-5.4-mini', 400_000]
] as const

const launchConfig = (provider: unknown): Record<string, unknown> => {
  const config = codexFramework.prepareModelConfig(provider as never, {
    storageRoot: '/data',
    executablePath: '/runtime/codex-acp'
  })
  return JSON.parse(config.env?.CODEX_CONFIG ?? '{}')
}

// --- Interface 1 + 2: runtime projection -> Codex launch config ------------

describe('Codex subscription context window projection', () => {
  // The two subscription logins (`codex-isolated`, `codex-shared`) and the
  // OpenAI-vendor `official` API-key entry. None carries a credential, so no
  // secure-storage host is needed to project it.
  const subscriptionProvider = (
    type: 'official' | 'codex-isolated' | 'codex-shared'
  ): StoredProvider => ({
    id: type,
    type,
    name: 'OpenAI',
    ...(type === 'official' ? { vendorId: 'openai' as const } : {})
  })

  it('lists models with more than one published window', () => {
    expect(CATALOG_MODELS).toEqual(expect.arrayContaining(SPOT_WINDOWS.map((entry) => [...entry])))
  })

  it.each(['official', 'codex-isolated', 'codex-shared'] as const)(
    'requests the selected model published window and its auto-compaction limit for %s',
    (type) => {
      const owner = new ProviderRuntimeProjectionOwner()
      const provider = subscriptionProvider(type)
      const before = structuredClone(provider)

      for (const [model, window] of CATALOG_MODELS) {
        const target = owner.resolveRuntimeTarget(
          provider,
          { kind: 'required', model },
          codexFramework
        )
        expect(target.provider.model).toBe(model)
        // The launch config requests exactly the published window. The
        // auto-compaction limit is a positive integer no larger than that
        // window; its exact fraction is not pinned. Which layer looks the
        // window up is left open.
        const parsed = launchConfig(target.provider)
        expect(parsed).toMatchObject({
          model,
          model_context_window: window
        })
        const autoCompactLimit = parsed.model_auto_compact_token_limit
        expect(typeof autoCompactLimit).toBe('number')
        expect(Number.isInteger(autoCompactLimit)).toBe(true)
        expect(autoCompactLimit).toBeGreaterThan(0)
        expect(autoCompactLimit).toBeLessThanOrEqual(window)
      }
      // Projection is read-only on the stored provider.
      expect(provider).toEqual(before)
    }
  )

  // The `official` API-key entry fills an absent selection with a catalog
  // model, so an unlisted or absent model is checked on the two subscription
  // logins only.
  it.each(['codex-isolated', 'codex-shared'] as const)(
    'leaves the native default in place for an unknown %s model',
    (type) => {
      const owner = new ProviderRuntimeProjectionOwner()
      const provider = subscriptionProvider(type)

      for (const model of [undefined, 'unpublished-model']) {
        const resolved = owner.resolveProvider(provider, model)
        // Neither key is emitted, so codex-acp keeps its own default.
        const parsed = launchConfig(resolved)
        expect(parsed).not.toHaveProperty('model_context_window')
        expect(parsed).not.toHaveProperty('model_auto_compact_token_limit')
      }
    }
  )
})

// --- Interface 3: usage policy selectedWindow ------------------------------

const policyBackend = (
  overrides: Partial<AcpBackendGenerationView> = {}
): AcpBackendGenerationView => ({
  framework: opencodeFramework,
  session: { model: 'requested/model', modelRequired: false },
  prompt: { systemPromptAppends: [] },
  context: { model: 'tokenizer/model', window: 128_000, supportsImageInput: false },
  adapter: { nativeMcpEnabled: true, bridgeMcpAliasesEnabled: false },
  ...overrides
})

const resolvePolicy = (backend: AcpBackendGenerationView) =>
  new AcpContextUsagePolicy({
    backend: () => backend,
    appliedModel: () => 'confirmed/model',
    systemPromptAppends: () => [],
    tooling: () => ({ artifacts: false, notebook: false, skillImport: false })
  }).resolve('session-1')

describe('Codex usage-window reporting policy', () => {
  it.each(['codex-responses', 'codex-responses-compatibility', 'codex-bridge'] as const)(
    'does not surface the requested window for a Codex backend on %s',
    (route) => {
      for (const [model, window] of SPOT_WINDOWS) {
        const resolved = resolvePolicy(
          policyBackend({
            framework: codexFramework,
            modelRoute: route,
            context: { model, window, supportsImageInput: true }
          })
        )
        // The usage UI and preflight estimate go by the capacity Codex reports
        // in its own usage updates, so no requested window is surfaced.
        expect(resolved.selectedWindow).toBeUndefined()
      }
    }
  )

  it.each(['claude-code', 'opencode'] as const)(
    'surfaces the provider window for a %s backend',
    (frameworkId) => {
      const resolved = resolvePolicy(policyBackend({ framework: getAgentFramework(frameworkId) }))
      // Claude Code and OpenCode keep the provider window.
      expect(resolved.selectedWindow).toBe(128_000)
    }
  )
})

// --- Interface 4: model-change workflow reconnect vs live apply ------------

const permissionProfile: SessionPermissionProfileState = {
  selectedProfile: 'ask',
  effectiveProfile: 'ask',
  currentModeId: 'default',
  availableModeIds: ['default'],
  fullAccessAvailable: false
}

const modelOption = (currentValue = 'model-a'): SessionConfigOption =>
  ({
    type: 'select',
    id: 'model',
    name: 'Model',
    category: 'model',
    currentValue,
    options: ['model-a', 'model-b', 'model-c'].map((value) => ({ value, name: value }))
  }) as SessionConfigOption

const target = (
  model: string,
  overrides: Partial<AgentModelChangeTarget> = {}
): AgentModelChangeTarget => ({
  frameworkId: 'claude-code',
  providerId: 'provider-a',
  backendId: 'claude-code:provider',
  route: 'claude-anthropic',
  model,
  sessionModel: model,
  sessionModelRequired: false,
  reasoningEffort: 'default',
  supportsImageInput: false,
  ...overrides
})

const createHarness = (backendOverrides: Partial<AcpBackendGenerationView> = {}) => {
  let busy = false
  let connected = true
  let providerReconnectPending = false
  let replayableImageHistory = true
  let backend: AcpBackendGenerationView = {
    framework: claudeCodeFramework,
    providerId: 'provider-a',
    backendId: 'claude-code:provider',
    modelRoute: 'claude-anthropic',
    session: { model: 'model-a', modelRequired: false },
    prompt: { systemPromptAppends: [] },
    context: { model: 'model-a', supportsImageInput: false },
    adapter: { nativeMcpEnabled: true, bridgeMcpAliasesEnabled: false },
    ...backendOverrides
  }
  let options = [modelOption()]
  const request = vi.fn(async (_method: unknown, params: unknown) => {
    const value = (params as { value: string }).value
    options = [modelOption(value)]
    return { configOptions: options }
  })
  const connection = { agent: { request } } as unknown as ClientConnection
  const session = {
    sessionId: 'provider-session',
    newSessionResponse: { configOptions: options },
    dispose: vi.fn()
  } as unknown as ActiveSession
  const registry = new AcpSessionRegistry()
  const reserved = registry.reserve({ sessionIds: ['app-session', session.sessionId] })
  if (reserved.collision) throw reserved.collision
  const entry = registry.publish(reserved.reservation, 'app-session', {
    session,
    cwd: '/workspace',
    projectId: 'project-a',
    frameworkId: 'claude-code',
    backendId: backend.backendId,
    permissionProfile,
    appliedModel: 'model-a',
    configOptions: options
  })
  reserved.reservation.release()
  const updateAggregateModel = vi.spyOn(entry.aggregate, 'updateModel')

  const updateModel = vi.fn((next: AgentModelChangeTarget) => {
    backend = {
      ...backend,
      providerId: next.providerId,
      backendId: next.backendId,
      modelRoute: next.route,
      session: {
        ...backend.session,
        model: next.sessionModel,
        modelRequired: next.sessionModelRequired,
        ...(next.reasoningEffort === 'default' ? {} : { effort: next.reasoningEffort })
      },
      context: {
        model: next.model,
        ...(next.contextWindow ? { window: next.contextWindow } : {}),
        supportsImageInput: next.supportsImageInput
      }
    }
    return backend
  })
  const updateReasoningEffort = vi.fn((effort: 'default' | 'low' | 'medium' | 'high' | 'max') => {
    backend = {
      ...backend,
      session: {
        ...backend.session,
        ...(effort === 'default' ? {} : { effort })
      }
    }
    return backend
  })
  const backendGeneration = {
    get current() {
      return backend
    },
    updateModel,
    updateReasoningEffort
  } as Pick<AcpBackendGenerationOwner, 'current' | 'updateModel' | 'updateReasoningEffort'>

  const setProviderTransportTarget = vi.fn(() => true)
  const setMessagesBridgeTarget = vi.fn(() => true)
  const setBridgeReasoningEffort = vi.fn()
  const connectionResources = {
    epoch: 1,
    get connection() {
      return connected ? connection : undefined
    },
    get isShuttingDown() {
      return false
    },
    get messagesBridgeAvailable() {
      return false
    },
    get providerTransportAvailable() {
      return false
    },
    assertCurrentConnection: vi.fn(),
    setProviderTransportTarget,
    setMessagesBridgeTarget,
    setBridgeModelTarget: vi.fn(() => true),
    setBridgeReasoningEffort
  } as Pick<
    AcpConnectionResourceOwner,
    | 'epoch'
    | 'connection'
    | 'isShuttingDown'
    | 'messagesBridgeAvailable'
    | 'providerTransportAvailable'
    | 'assertCurrentConnection'
    | 'setProviderTransportTarget'
    | 'setMessagesBridgeTarget'
    | 'setBridgeModelTarget'
    | 'setBridgeReasoningEffort'
  >

  const applyLiveEffort = vi.fn(async () => ({ reconnectRequired: false }))
  const clearContext = vi.fn()
  const beginContext = vi.fn()
  const emitState = vi.fn()
  const requestReconnect = vi.fn(async () => undefined)
  const recoverFailedReconnect = vi.fn()
  const reportReconnectFailure = vi.fn()
  const workflow = new AcpModelChangeWorkflow({
    backendGeneration,
    connectionResources,
    registry,
    configurator: { applyLiveEffort } as Pick<AcpSessionConfigurator, 'applyLiveEffort'>,
    contextUsage: {
      clear: clearContext,
      beginSession: beginContext
    } as Pick<ContextUsageTracker, 'clear' | 'beginSession'>,
    currentStatus: () => (connected ? 'connected' : 'closed'),
    providerReconnectPending: () => providerReconnectPending,
    isGenerationBusy: () => busy,
    contextEstimateInput: () => ({ frameworkId: 'claude-code', model: backend.context.model }),
    hasReplayableImageHistory: vi.fn(async () => replayableImageHistory),
    emitState,
    requestReconnect,
    recoverFailedReconnect,
    reportReconnectFailure,
    diagnosticContext: () => ({})
  })

  return {
    workflow,
    request,
    requestReconnect,
    updateModel,
    clearContext,
    beginContext,
    setBusy: (value: boolean) => {
      busy = value
    },
    setConnected: (value: boolean) => {
      connected = value
    },
    setProviderReconnectPending: (value: boolean) => {
      providerReconnectPending = value
    }
  }
}

describe('Codex model-change capacity handling', () => {
  it.each(['codex-responses', 'codex-responses-compatibility', 'codex-bridge'] as const)(
    'reconnects %s before applying a different native capacity',
    async (route) => {
      for (const [previous, next] of [
        [1_050_000, 400_000],
        [400_000, 1_050_000],
        [undefined, 1_050_000],
        [1_050_000, undefined]
      ]) {
        for (const model of ['model-a', 'model-b']) {
          const harness = createHarness({
            framework: codexFramework,
            modelRoute: route,
            context: { model: 'model-a', window: previous, supportsImageInput: false }
          })
          await expect(
            harness.workflow.apply(
              target(model, { frameworkId: 'codex', route, contextWindow: next })
            )
          ).resolves.toBe(true)
          // A different window goes through one reconnect, and no live model
          // switch is sent on the old connection.
          expect(harness.requestReconnect).toHaveBeenCalledOnce()
          expect(harness.request).not.toHaveBeenCalled()
        }
      }
    }
  )

  it.each(['codex-responses', 'codex-responses-compatibility', 'codex-bridge'] as const)(
    'applies a live %s switch when the window is unchanged',
    async (route) => {
      for (const window of [1_050_000, 400_000, undefined]) {
        const harness = createHarness({
          framework: codexFramework,
          modelRoute: route,
          context: { model: 'model-a', window, supportsImageInput: false }
        })
        await expect(
          harness.workflow.apply(
            target('model-b', { frameworkId: 'codex', route, contextWindow: window })
          )
        ).resolves.toBe(true)
        // An equal window is switched in place: no reconnect, and the context
        // tracker starts again on the new model.
        expect(harness.requestReconnect).not.toHaveBeenCalled()
        expect(harness.beginContext).toHaveBeenCalledWith(
          'app-session',
          expect.objectContaining({ model: 'model-b' })
        )
      }
    }
  )
})
