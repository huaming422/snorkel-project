#!/usr/bin/env bash
# Verifier-phase setup for open-science-fix-codex-context-window.
#
# Sourced (not exec'd) by the harbor runner, so env vars set here stay live
# for the verifier subprocess.
#
# The code under test lives in `src/main/*.ts`, which vitest transforms
# straight from source, so user changes there are picked up with no rebuild.
# Dependencies are baked into the image. Workspace packages are rebuilt below
# (offline, from the installed deps) so a change under `packages/*` is also
# reflected in their dist/ output.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/open-science}"
export REPO_DIR
cd "$REPO_DIR"

# The harbor runner reads verify.toml via tomllib. The canonical verifier venv
# runs Python 3.12, which has tomllib in the standard library, so no TOML
# parser install is needed here.

# Sanity check: vitest must be resolvable from the workspace root. A failure
# here points at a corrupted node_modules, so say so now instead of a
# confusing "vitest: command not found" later. Recover offline-first from the
# warm npm cache and fall back to an online install only if that fails.
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest missing from node_modules/.bin/, image looks" \
         "corrupt; recovering from the warm npm cache (offline-first)." >&2
    npm ci --offline || { echo "test-setup.sh: offline npm ci failed; retrying online." >&2; npm ci; }
fi

# Rebuild workspace packages so their dist/ output matches the source. This
# mirrors the repo's own pretest (`build:packages`), builds from the installed
# deps and needs no network.
echo "test-setup.sh: building workspace packages (npm run build:packages)..."
npm run build:packages

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
