## Task

The context-usage readout is wrong on Codex sessions that are signed in with a ChatGPT subscription.
Whatever model I pick, the usable window it shows doesn't line up with that model.
On some models it looks like a small fixed default, and on others it's far bigger than what the model can really use.
The pre-send warning that a message might trigger compaction is off in the same way, because it works from the same number.
Changing models in the middle of a session doesn't help either, since the readout never follows the new pick.
Claude Code and OpenCode sessions show the right window, so this looks like a Codex problem.

What I'd expect instead:

- When a subscription session starts (shared or isolated login) on a model the OpenAI catalog lists, Codex is asked for that model's published window, together with an auto-compaction limit above zero that is no bigger than that window.
- An OpenAI API-key provider on Codex already gets its window sent this way, and that should keep working.
- Working out the window for a session doesn't change the saved provider settings.
- If the subscription model isn't in the catalog, or no model is picked at all, neither a window nor a compaction limit is sent, so Codex keeps its own default instead of a made-up number.
- For a Codex session, the readout and the pre-send estimate go by the usable capacity Codex reports back during the session, not by the published total, since Codex holds part of that total back.
- Claude Code and OpenCode sessions keep showing the provider's window, as they do now.
- Switching a Codex session to a model with a different window reconnects the session so the new window takes effect, without first switching the model in place on the old connection.
- Switching between two models that have the same window happens in place, with no reconnect.
