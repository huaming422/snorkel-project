## Task

The context-usage readout is wrong on Codex sessions that are signed in with a ChatGPT subscription.
Whatever model I pick, the usable window it shows doesn't line up with that model.
On some models it looks like a small fixed default, and on others it's far bigger than what the model can really use.
The pre-send warning that a message might trigger compaction is off in the same way, because it works from the same number.
Changing models in the middle of a session doesn't help either, since the readout never follows the new pick.
Claude Code and OpenCode sessions show the right window, so this looks like a Codex problem.

What I'd expect instead:

- On either subscription login (shared or isolated) and on an OpenAI API key, a Codex session on a model the OpenAI catalog lists runs with that model's published window, and auto-compaction kicks in somewhere above zero and no later than that window.
- Starting a session leaves my saved provider settings as they were.
- On a subscription model the catalog doesn't list, or with no model picked, Codex stays on its own default window and compaction point rather than a guessed number.
- On Codex, the readout and the pre-send warning show the usable window Codex itself reports for the session, not the model's published total.
- Claude Code and OpenCode sessions keep showing the provider's window, as they do now.
- Moving a Codex session to a model with a different window reconnects the session, so it ends up on the new window.
- Moving between two models with the same window carries on in the same session, with no reconnect.
