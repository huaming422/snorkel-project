#!/usr/bin/env bash
# Sourced (not exec'd) by the verifier runner so env vars stay alive for
# vitest. Idempotent.
#
# @rakazo/core is an ESM workspace package whose "." export resolves to
# ./src/index.ts directly (package.json "exports" has no dist build step), and
# vitest runs TypeScript sources through its own transform, so there is NO
# per-package build to rebuild after source edits. The focused suite is pure,
# in-process, and needs no datastore: packages/testkit/src/pin-test-env.ts
# (the root vitest setupFile) deletes DATABASE_URL unless VERIFY_DATABASE=1,
# which this task never sets.

set -e

REPO_DIR="${REPO_DIR:-/repo/rakazo}"
cd "$REPO_DIR"

node --version
pnpm --version

# Install workspace deps if missing. The image baked the full closure at the
# base commit with the store warm, so the offline frozen replay is a no-op on
# the shipped image; this branch only fires if node_modules was removed.
if [ ! -d "node_modules/.pnpm" ]; then
    echo "[test-setup] pnpm install (offline, frozen)..."
    pnpm install --frozen-lockfile --ignore-scripts --offline 2>&1 | tail -10
fi

# Make node_modules/.bin available to the runner.
export PATH="$REPO_DIR/node_modules/.bin:$PATH"

echo "[test-setup] ready: $REPO_DIR (node=$(node --version), pnpm=$(pnpm --version))"
