#!/usr/bin/env bash
# Environment bootstrap for the generated test scripts. Idempotent.
#
# Mirrors tests/test-setup.sh. The core package is an ESM workspace package whose
# "." export resolves to ./src/index.ts directly (package.json "exports" has NO
# dist build step), and the repo has a single root vitest.config.ts (no
# per-package project configs) that transforms TypeScript sources through
# vitest's own transform. So there is NO build to run: the test files are copied
# under packages/core/src/__validation__/ and import the package barrel by
# relative path (../index.js), picking up source edits directly. The
# focused suite is pure and in-process and needs no datastore:
# packages/testkit/src/pin-test-env.ts (the root setupFile) deletes DATABASE_URL
# unless VERIFY_DATABASE=1, which this task never sets.

set -e

REPO_DIR="${REPO_DIR:-/repo/rakazo}"
cd "$REPO_DIR"

# Sanity: Node + pnpm + vitest are reachable.
node --version
pnpm --version
npx vitest --version

# Re-install workspace deps only if missing. The image baked the full closure at
# the base commit with the pnpm store warm, so the offline frozen replay is a
# no-op on the shipped image; this branch only fires if node_modules
# was removed during a run.
if [ ! -d "node_modules/.pnpm" ]; then
    echo "[validation-setup] re-installing pnpm deps (offline, frozen)..."
    pnpm install --frozen-lockfile --ignore-scripts --offline 2>&1 | tail -10
fi

# Loud guard: the package barrel the tests import (../index.js from
# __validation__/, i.e. packages/core/src/index.ts) must exist, and vitest's
# binary must be resolvable; otherwise every story would fail opaquely at
# import/collection time. Fail here with a clear cause instead.
if [ ! -f "packages/core/src/index.ts" ]; then
    echo "[validation-setup] FATAL: packages/core/src/index.ts (package barrel) missing" >&2
    exit 1
fi
if [ ! -e "node_modules/vitest" ]; then
    echo "[validation-setup] FATAL: vitest not installed in node_modules" >&2
    exit 1
fi

# Make node_modules/.bin available to the runner.
export PATH="$REPO_DIR/node_modules/.bin:$PATH"

echo "[validation-setup] ready: $REPO_DIR (node=$(node --version), pnpm=$(pnpm --version))"
