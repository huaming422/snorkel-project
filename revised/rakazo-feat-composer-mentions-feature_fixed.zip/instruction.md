## Task

Today the `@` picker in the chat composer only knows about the bots in the current group and `@everyone`, and the web and mobile composers each keep their own copy of that code.
We want it to offer groups, routines and connectors too, with the logic living once in `@rakazo/core` so both composers can share it.

Add two functions to the package's public exports.
The first takes the text typed after `@` plus the bots, groups, routines and connectors on hand, and returns the chips to show.
The second takes the picked chips, the raw draft text with its `@` tokens still in it, and whether the draft has attachments.
It returns a send plan covering the text that goes out, the routines to test-run, the group to open, the connectors the message targets, whether a message is sent at all, and whether the whole thing is a no-op.

Both apps import this, so keep it plain logic with no database, network or UI framework, and hand results back directly instead of as promises.
Leave the API routes, the contract schemas and the composer screens alone in this change.

## User stories / requirements

- Typing after `@` lists the chips whose names match, ignoring case, across bots, groups, routines and connectors.
  `@everyone` shows only when the caller asks for it, and the user's current group is never suggested.
  A limit caps the matches, and candidates that don't match never take a slot.
  With no limit, every match comes back.
- If two routines have the same name, each chip shows the name of the bot that owns it, so the user can tell them apart.
  A routine whose name is unique shows no bot name.
- A group chip opens that group.
  The outgoing text is the draft minus the `@` tokens of picked groups and routines; the rest stays, bot and connector tokens too.
  A lone group chip sends nothing, with no made-up body; leftover words go to the group.
  Names may have spaces or accents; line breaks stay.
- Routine chips are test-run, once each even if the same routine was picked twice, and a group chip beside them still opens.
  A message goes out when some text is left or the draft has attachments, and only then.
  If nothing goes out, no group opens and no routine runs, it's a no-op.
- Each connector the user already owns is a send target.
  Ones the user doesn't own yet still need authorization, so they aren't targets.
  Instead, the outgoing text gets a short line naming only them, and the user's words stay.
  If two of those connectors have the same name, the line lists that name once.
