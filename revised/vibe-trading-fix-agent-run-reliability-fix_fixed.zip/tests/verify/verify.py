"""Behavioral checks for agent run reliability on the report-update workflow.

The checks drive pre-existing public surfaces only:

  * ``GroundingLedger.validate_final_answer`` (the answer-grounding gate),
  * ``AgentLoop(...).run(...)`` with a real ``ChatLLM`` (the run result),
  * ``get_env_config()`` (the documented home of every environment setting).

Loop checks talk to a local OpenAI-compatible endpoint that answers from a
script, so the whole provider stack (ChatLLM, the LangChain model and the
HTTP client) runs for real. A scripted "hold" keeps the connection open and
sends keep-alive bytes but no content, which is how a stalled provider looks
from the client side.

Runner note: this file is executed by ``uv run --no-sync pytest`` with the
working directory at the repository root. The ``agent`` source root is added
to ``sys.path`` and the runtime home is redirected to a throwaway directory,
the same isolation the repository's own test conftest installs.
"""

from __future__ import annotations

import json
import os
import sys
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

import pytest

# --------------------------------------------------------------------------- #
# Import bootstrap + runtime-root isolation (installed before importing any
# package module, because a few module-level constants bind the home-derived
# paths at import time).
# --------------------------------------------------------------------------- #
_AGENT_SRC_ROOT = Path.cwd() / "agent"
if _AGENT_SRC_ROOT.is_dir() and str(_AGENT_SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(_AGENT_SRC_ROOT))

_SANDBOX_HOME = Path(tempfile.mkdtemp(prefix="vt-verify-home-")).resolve()
os.environ.pop("VIBE_TRADING_HOME", None)
os.environ["HOME"] = str(_SANDBOX_HOME)
os.environ["USERPROFILE"] = str(_SANDBOX_HOME)
(_SANDBOX_HOME / ".vibe-trading").mkdir(parents=True, exist_ok=True)

_LLM_TIMEOUT_ENV = "VIBE_TRADING_LLM_TIMEOUT_SECONDS"


# --------------------------------------------------------------------------- #
# Grounding gate: two observed trading days written as a run-dir OHLC CSV.
# --------------------------------------------------------------------------- #
_EVIDENCE = {"2026-08-10": 21.5, "2026-08-11": 23.0}


def _ledger_with_evidence():
    """Return a ledger whose identity is locked by a ``search_symbol`` result
    and whose price evidence is a per-symbol CSV under ``data/raw`` holding
    the closes in ``_EVIDENCE``."""
    from src.agent.grounding import GroundingLedger

    tmp = Path(tempfile.mkdtemp(prefix="vt-ground-"))
    raw = tmp / "data" / "raw"
    raw.mkdir(parents=True)
    rows = "".join(
        f"{day},{close - 0.5},{close + 0.3},{close - 0.6},{close},{close},1000000\n"
        for day, close in _EVIDENCE.items()
    )
    (raw / "INTC_US.csv").write_text(
        "Date,Open,High,Low,Close,Adj Close,Volume\n" + rows, encoding="utf-8"
    )
    ledger = GroundingLedger(run_dir=tmp, user_message="请更新 INTC.US 的趋势报告")
    ledger.ingest_tool_result(
        tool_name="search_symbol",
        arguments={"query": "INTC"},
        result=json.dumps(
            {
                "ok": True,
                "source": "symbol_search",
                "data": {
                    "query": "INTC",
                    "count": 1,
                    "candidates": [
                        {
                            "symbol": "INTC.US",
                            "name": "Intel",
                            "market": "us",
                            "type": "equity",
                            "exchange": "NMS",
                            "source": "yahoo",
                        }
                    ],
                    "sources": {"yahoo": "ok"},
                },
            },
            ensure_ascii=False,
        ),
        call_id="lock1",
        success=True,
    )
    return ledger


def _close_report(rows: list[tuple[str, str]]) -> str:
    """A sourced close table for INTC.US with one row per (date cell, close)."""
    body = "".join(f"| {cell} | {close} |\n" for cell, close in rows)
    return (
        "INTC.US（yahoo，USD）数据来源：yahoo\n\n"
        "| 日期 | 收盘 |\n"
        "|---|---:|\n" + body
    )


def _validate(text: str):
    return _ledger_with_evidence().validate_final_answer(text)


# Date cells written with a weekday or session note, each paired with the
# observed close for the day it names.
_ANNOTATED_CORRECT = [
    ("2026-08-11(二)", "23.0"),
    ("2026-08-10盘中", "21.5"),
    ("2026-08-11(周二)盘中", "23.0"),
    ("2026-08-10 Mon", "21.5"),
    ("08-10 周一", "21.5"),
    ("08-11周二盘中", "23.0"),
    ("08-11(Tue)", "23.0"),
    ("2026-08-11收盘", "23.0"),
    ("08-10 close", "21.5"),
    ("08-11周二收盘", "23.0"),
]


@pytest.mark.parametrize("cell,close", _ANNOTATED_CORRECT)
def test_annotated_date_row_with_observed_close_is_accepted(cell: str, close: str) -> None:
    """A row whose date cell carries a weekday or session note and whose
    close matches that day's evidence passes the grounding gate."""
    result = _validate(_close_report([(cell, close)]))
    assert result.valid is True, (cell, close, result.issues)


def test_report_with_several_annotated_rows_is_accepted() -> None:
    """A table mixing note styles across days passes when every close matches
    the evidence for its own day."""
    result = _validate(
        _close_report([("2026-08-10(一)", "21.5"), ("08-11 周二", "23.0")])
    )
    assert result.valid is True, result.issues


# Each row below names a day and quotes a close that is not that day's
# observed close: another day's close, an invented figure, or a close for a
# day with no evidence at all (another day, or the same day in another year).
_ANNOTATED_WRONG = [
    ("2026-08-11(二)", "21.5"),
    ("08-10(Mon)", "23.0"),
    ("08-11周二盘中", "99.99"),
    ("2026-08-10盘中", "88.8"),
    ("2026-08-12(三)", "21.5"),
    ("08-12 周三", "23.0"),
    ("2026-08-10 close", "23.0"),
    ("2025-08-11(二)", "23.0"),
    ("2024-08-10 Mon", "21.5"),
]


@pytest.mark.parametrize("cell,close", _ANNOTATED_WRONG)
def test_annotated_date_row_with_unobserved_close_is_rejected(cell: str, close: str) -> None:
    """An annotated date cell does not loosen the price check: a close that
    is not the observed close for the named day is still rejected."""
    result = _validate(_close_report([(cell, close)]))
    assert result.valid is False, (cell, close, result.issues)


def test_one_wrong_row_rejects_an_otherwise_correct_report() -> None:
    result = _validate(
        _close_report([("2026-08-10(一)", "21.5"), ("08-11 周二", "21.5")])
    )
    assert result.valid is False, result.issues


def test_existing_grounding_rejections_and_acceptances_hold() -> None:
    """Plain date cells keep their current results, and drafts with an
    unsourced symbol or no currency/source are still rejected."""
    for cell, close in (("08-10", "21.5"), ("2026-08-11", "23.0"), ("08-11(二)", "23.0")):
        result = _validate(_close_report([(cell, close)]))
        assert result.valid is True, (cell, close, result.issues)

    for cell, close in (
        ("08-11", "21.5"),
        ("2026-08-10", "99.99"),
        ("08-12", "23.0"),
        ("2025-08-11", "23.0"),
    ):
        result = _validate(_close_report([(cell, close)]))
        assert result.valid is False, (cell, close, result.issues)

    unsourced = _validate("ZZZ.US（yahoo，USD）在 2026-08-10 的已观测收盘价为 100.0。")
    assert unsourced.valid is False, unsourced.issues

    missing_provenance = _validate("INTC.US 在 2026-08-10 的收盘价为 21.5。")
    assert missing_provenance.valid is False, missing_provenance.issues


# --------------------------------------------------------------------------- #
# Scripted OpenAI-compatible provider.
# --------------------------------------------------------------------------- #
class _FakeProvider:
    """Local chat-completions endpoint that answers from a script.

    A request that carries the agent's system prompt takes the next reply from
    ``streams``; a request without one (the conversation summary) takes the
    next reply from ``summaries``. Either kind is served streamed or not,
    as the client asks. A reply is a list of steps:

      * ``("text", s)`` sends ``s`` as answer text,
      * ``("reason", s)`` sends ``s`` as reasoning text,
      * ``("tool", name)`` sends a call to tool ``name`` with no arguments,
      * ``("hold", seconds)`` keeps the connection open, sending only
        keep-alive bytes, until the time passes or ``release`` is set.
    """

    def __init__(self) -> None:
        self.streams: list[list[tuple[str, Any]]] = []
        self.summaries: list[list[tuple[str, Any]]] = []
        self.requests: list[dict[str, Any]] = []
        self.release = threading.Event()
        owner = self

        class _Handler(BaseHTTPRequestHandler):
            def log_message(self, *args: Any) -> None:
                return None

            def do_POST(self) -> None:
                length = int(self.headers.get("Content-Length") or 0)
                body = json.loads(self.rfile.read(length) or b"{}")
                streaming = bool(body.get("stream"))
                summary = not any(
                    m.get("role") == "system" for m in body.get("messages") or []
                )
                owner.requests.append({"summary": summary, "body": body})
                script = owner.summaries if summary else owner.streams
                steps = script.pop(0) if script else [("text", "")]
                try:
                    owner._reply(self, streaming, steps)
                except (BrokenPipeError, ConnectionResetError):
                    pass

        self._server = ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
        self._server.daemon_threads = True
        threading.Thread(target=self._server.serve_forever, daemon=True).start()
        self.base_url = f"http://127.0.0.1:{self._server.server_address[1]}/v1"

    def answer_requests(self) -> list[dict[str, Any]]:
        return [r for r in self.requests if not r["summary"]]

    def summary_requests(self) -> list[dict[str, Any]]:
        return [r for r in self.requests if r["summary"]]

    def _hold(self, out: Any, seconds: float, filler: bytes) -> None:
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline and not self.release.is_set():
            out.write(filler)
            out.flush()
            time.sleep(0.1)

    def _reply(self, handler: BaseHTTPRequestHandler, streaming: bool, steps: list) -> None:
        handler.send_response(200)
        handler.send_header(
            "Content-Type", "text/event-stream" if streaming else "application/json"
        )
        handler.send_header("Connection", "close")
        handler.end_headers()
        out = handler.wfile
        if not streaming:
            text = ""
            for kind, value in steps:
                if kind == "text":
                    text += value
                elif kind == "hold":
                    self._hold(out, value, b" ")
            out.write(
                json.dumps(
                    {
                        "id": "reply",
                        "object": "chat.completion",
                        "created": 0,
                        "model": "test-model",
                        "choices": [
                            {
                                "index": 0,
                                "message": {"role": "assistant", "content": text},
                                "finish_reason": "stop",
                            }
                        ],
                        "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
                    }
                ).encode()
            )
            out.flush()
            return

        def event(delta: dict[str, Any], finish: str | None = None) -> None:
            chunk = {
                "id": "chunk",
                "object": "chat.completion.chunk",
                "created": 0,
                "model": "test-model",
                "choices": [{"index": 0, "delta": delta, "finish_reason": finish}],
            }
            out.write(b"data: " + json.dumps(chunk).encode() + b"\n\n")
            out.flush()

        started = False
        finish = "stop"
        for kind, value in steps:
            if kind == "hold":
                self._hold(out, value, b": keep-alive\n\n")
                continue
            if not started:
                event({"role": "assistant", "content": ""})
                started = True
            if kind == "text":
                event({"content": value})
            elif kind == "reason":
                event({"reasoning_content": value})
            elif kind == "tool":
                event(
                    {
                        "tool_calls": [
                            {
                                "index": 0,
                                "id": f"call_{len(self.requests)}",
                                "type": "function",
                                "function": {"name": value, "arguments": "{}"},
                            }
                        ]
                    }
                )
                finish = "tool_calls"
        if not started:
            event({"role": "assistant", "content": ""})
        event({}, finish)
        out.write(b"data: [DONE]\n\n")
        out.flush()

    def close(self) -> None:
        self.release.set()
        self._server.shutdown()
        self._server.server_close()


@pytest.fixture
def provider(monkeypatch):
    from src.config.accessor import reset_env_config

    fake = _FakeProvider()
    monkeypatch.setenv("LANGCHAIN_PROVIDER", "openai")
    monkeypatch.setenv("LANGCHAIN_MODEL_NAME", "test-model")
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test-0000000000000000")
    monkeypatch.setenv("OPENAI_BASE_URL", fake.base_url)
    monkeypatch.setenv("VT_STREAM_RETRY_DELAY_S", "0")
    monkeypatch.setenv(_LLM_TIMEOUT_ENV, "1")
    reset_env_config()
    try:
        yield fake
    finally:
        fake.close()
        reset_env_config()


def _set_llm_timeout(monkeypatch, seconds: str) -> None:
    from src.config.accessor import reset_env_config

    monkeypatch.setenv(_LLM_TIMEOUT_ENV, seconds)
    reset_env_config()


def _agent(max_iterations: int):
    from src.agent.loop import AgentLoop
    from src.agent.tools import BaseTool, ToolRegistry
    from src.memory.persistent import PersistentMemory
    from src.providers.chat import ChatLLM

    class _NoteProgressTool(BaseTool):
        name = "note_progress"
        description = "Record that a step of the task is done."
        repeatable = True

        def execute(self, **kwargs: Any) -> str:
            return json.dumps({"status": "ok"})

    registry = ToolRegistry()
    registry.register(_NoteProgressTool())
    tmp = Path(tempfile.mkdtemp(prefix="vt-loop-"))
    return AgentLoop(
        registry=registry,
        llm=ChatLLM(),
        max_iterations=max_iterations,
        persistent_memory=PersistentMemory(memory_dir=tmp / "memory"),
    )


def _run_with_deadline(provider: _FakeProvider, agent: Any, message: str, seconds: float, **kwargs: Any):
    """Run ``agent`` on a worker thread; return (result, finished_in_time).

    Held provider connections are released afterwards so a run that is still
    waiting can finish and the thread does not outlive the test.
    """
    outcome: dict[str, Any] = {}

    def _run() -> None:
        outcome["result"] = agent.run(message, **kwargs)

    worker = threading.Thread(target=_run, daemon=True)
    worker.start()
    worker.join(seconds)
    in_time = not worker.is_alive()
    provider.release.set()
    worker.join(30)
    return outcome.get("result"), in_time


# --------------------------------------------------------------------------- #
# Tool-call markup returned as the answer text.
# --------------------------------------------------------------------------- #
_MARKUP_ANSWERS = [
    'Final answer: <｜｜DSML｜｜tool_calls> <｜｜DSML｜｜invoke name="trading_quote"> (my full response here)',
    'Here it is <||DSML||tool_calls><||DSML||invoke name="write_file"><||DSML||parameter name="path">plan.md',
    '报告如下：<tool_calls><invoke name="write_file"><parameter name="path">trend.md</parameter></invoke></tool_calls>',
]
_MARKUP_FRAGMENTS = ("<", "DSML", "tool_calls", "invoke", "parameter name")


@pytest.mark.parametrize("markup", _MARKUP_ANSWERS)
def test_markup_answer_is_asked_again_while_iterations_remain(provider, markup: str) -> None:
    """When the model answers with tool-call markup and the run has
    iterations left, the run asks again and delivers the plain answer."""
    provider.streams[:] = [[("text", markup)], [("text", "趋势报告已更新完成。")]]
    result = _agent(3).run("update the trading trend report")
    assert result["status"] == "success", result
    assert result["content"] == "趋势报告已更新完成。", result["content"]
    assert len(provider.answer_requests()) == 2


@pytest.mark.parametrize("markup", _MARKUP_ANSWERS)
def test_markup_answer_on_last_iteration_is_not_delivered(provider, markup: str) -> None:
    """With no iterations left, the markup is still not handed to the user."""
    provider.streams[:] = [[("text", markup)]]
    result = _agent(1).run("update the trading trend report")
    content = result.get("content") or ""
    for fragment in _MARKUP_FRAGMENTS:
        assert fragment not in content, (fragment, content)


@pytest.mark.parametrize("max_iterations", [1, 3])
def test_plain_answer_with_angle_brackets_is_delivered(provider, max_iterations: int) -> None:
    answer = "RSI < 30 视为超卖，> 70 视为超买，a<b 时继续观察。"
    provider.streams[:] = [[("text", answer)]]
    result = _agent(max_iterations).run("跟我打个招呼")
    assert result["status"] == "success", result
    assert result["content"] == answer
    assert len(provider.answer_requests()) == 1


# --------------------------------------------------------------------------- #
# Empty replies (no text, no tool calls).
# --------------------------------------------------------------------------- #
def test_single_empty_reply_is_retried(provider) -> None:
    provider.streams[:] = [[("text", "")], [("text", "你好，我在。")]]
    result = _agent(3).run("跟我打个招呼")
    assert result["status"] == "success", result
    assert result["content"] == "你好，我在。"
    assert len(provider.answer_requests()) == 2


def test_empty_replies_with_a_tool_call_between_are_each_retried(provider) -> None:
    """Two empty replies that are not back to back (a tool call came in
    between) each get their retry, and the run delivers its answer."""
    provider.streams[:] = [
        [("text", "")],
        [("tool", "note_progress")],
        [("text", "")],
        [("text", "报告已写好。")],
    ]
    result = _agent(6).run("跟我打个招呼")
    assert result["status"] == "success", result
    assert result["content"] == "报告已写好。"
    assert len(provider.answer_requests()) == 4


def test_two_empty_replies_in_a_row_fail_the_run(provider) -> None:
    provider.streams[:] = [[("text", "")] for _ in range(6)]
    result = _agent(6).run("跟我打个招呼")
    assert result["status"] == "failed", result
    assert str(result.get("reason", "")).startswith("empty_model_response"), result
    assert len(provider.answer_requests()) == 2


# --------------------------------------------------------------------------- #
# Model calls that go quiet.
# --------------------------------------------------------------------------- #
_STALLED_FIRST_REPLIES = [
    [("hold", 2.0), ("text", "stale answer")],
    [("text", "stale "), ("hold", 2.0), ("text", "answer")],
    [("text", "stale "), ("hold", 120.0), ("text", "answer")],
]


@pytest.mark.parametrize("stalled", _STALLED_FIRST_REPLIES)
def test_stalled_reply_is_abandoned_and_retried(provider, stalled: list) -> None:
    """With a 1 second limit, a reply that goes quiet for longer (before it
    starts, midway, or for good) is given up and retried once; the run
    delivers the retried answer."""
    provider.streams[:] = [stalled, [("text", "fresh answer")]]
    result, in_time = _run_with_deadline(provider, _agent(2), "跟我打个招呼", 30)
    assert in_time, "the run was still waiting on the stalled reply after 30s"
    assert result["status"] == "success", result
    assert result["content"] == "fresh answer", result["content"]
    assert len(provider.answer_requests()) == 2


def test_reply_that_stalls_again_fails_the_run(provider) -> None:
    """A retried reply that stalls again ends the run as failed instead of
    retrying without end."""
    provider.streams[:] = [
        [("hold", 120.0), ("text", "late")],
        [("hold", 120.0), ("text", "late")],
        [("text", "never requested")],
        [("text", "never requested")],
    ]
    result, in_time = _run_with_deadline(provider, _agent(3), "跟我打个招呼", 30)
    assert in_time, "the run was still retrying the stalled reply after 30s"
    assert result["status"] == "failed", result
    assert len(provider.answer_requests()) == 2


@pytest.mark.parametrize(
    "limit,gap,chunks,kind",
    [
        ("1", 0.3, 8, "text"),
        ("4", 2.5, 3, "text"),
        ("1", 0.3, 8, "reason"),
    ],
)
def test_steady_reply_longer_than_the_limit_is_kept(
    provider, monkeypatch, limit: str, gap: float, chunks: int, kind: str
) -> None:
    """A reply that keeps streaming, answer text or reasoning, is not cut
    off, even when the whole reply takes longer than the limit."""
    _set_llm_timeout(monkeypatch, limit)
    steps: list[tuple[str, Any]] = []
    for i in range(chunks):
        steps += [("hold", gap), (kind, f"part{i} ")]
    if kind == "reason":
        steps.append(("text", "answer after thinking"))
        expected = "answer after thinking"
    else:
        expected = "".join(f"part{i} " for i in range(chunks))
    provider.streams[:] = [steps, [("text", "retried answer")]]
    result = _agent(2).run("跟我打个招呼")
    assert result["status"] == "success", result
    assert result["content"] == expected, result["content"]
    assert len(provider.answer_requests()) == 1


_SUMMARY_MARKER = "HANDOFF-SUMMARY-7Q"


@pytest.mark.parametrize(
    "limit,summary_hold,deadline,summary_used",
    [
        ("1", 120.0, 5, False),
        ("8", 6.0, 30, True),
    ],
)
def test_conversation_summary_respects_the_limit(
    provider, monkeypatch, limit: str, summary_hold: float, deadline: float, summary_used: bool
) -> None:
    """When a long conversation is compacted, a summary call that stays quiet
    past the limit is given up: the run still shortens the conversation,
    continues and answers. A summary that arrives within the limit is used."""
    _set_llm_timeout(monkeypatch, limit)
    monkeypatch.setenv("TOKEN_THRESHOLD", "4000")
    from src.config.accessor import reset_env_config

    reset_env_config()
    history = [
        {
            "role": "user" if i % 2 == 0 else "assistant",
            "content": f"history-turn-{i:02d} " + "x" * 2000,
        }
        for i in range(30)
    ]
    provider.summaries[:] = [[("hold", summary_hold), ("text", _SUMMARY_MARKER)]]
    provider.streams[:] = [[("text", "continued after compaction")]]

    result, in_time = _run_with_deadline(
        provider, _agent(2), "跟我打个招呼", deadline, history=history
    )

    assert provider.summary_requests(), "the conversation was never sent for summarizing"
    assert in_time, f"the run was still waiting on the summary after {deadline}s"
    assert result["status"] == "success", result
    assert result["content"] == "continued after compaction"
    sent = json.dumps(provider.answer_requests()[0]["body"]["messages"], ensure_ascii=False)
    kept = sum(f"history-turn-{i:02d}" in sent for i in range(30))
    assert kept < 30, "the conversation was sent on without being shortened"
    assert (_SUMMARY_MARKER in sent) is summary_used, sent[:400]


# --------------------------------------------------------------------------- #
# The model-call limit setting.
# --------------------------------------------------------------------------- #
def _settings_named(name: str) -> list[Any]:
    from src.config.accessor import get_env_config

    found: list[Any] = []

    def walk(node: Any) -> None:
        if isinstance(node, dict):
            for key, value in node.items():
                if key == name:
                    found.append(value)
                walk(value)

    walk(get_env_config().model_dump(by_alias=True))
    return found


def test_llm_timeout_setting_has_a_default_and_reads_the_environment(monkeypatch) -> None:
    """The setting resolves through the settings accessor, with a default of
    a few minutes (one to ten) and the environment value when set."""
    from src.config.accessor import reset_env_config

    monkeypatch.delenv(_LLM_TIMEOUT_ENV, raising=False)
    reset_env_config()
    try:
        defaults = _settings_named(_LLM_TIMEOUT_ENV)
        assert defaults, f"{_LLM_TIMEOUT_ENV} is not a known setting"
        assert all(60 <= float(v) <= 600 for v in defaults), defaults

        monkeypatch.setenv(_LLM_TIMEOUT_ENV, "7")
        reset_env_config()
        assert all(float(v) == 7.0 for v in _settings_named(_LLM_TIMEOUT_ENV))
    finally:
        reset_env_config()
