## Task

Our scheduled "update the trading trend/plan report" runs keep failing at the very end, when the data is already fetched and most or all of the report is written.

What we keep seeing in these runs:

- Correct reports get rejected.
  When the date column reads `2026-08-11(二)`, `2026-08-11 Tue`, `08-11 周二`, `08-11周二盘中` or `08-11(Tue)`, every price in that row comes back as `numeric_claim_unavailable`, even though it matches what the run fetched for that day.
  The run redrafts until it gives up and never updates the file.
  Rows dated `08-11`, `2026-08-11` or `08-11(二)` go through fine.
- Some runs "succeed" and hand the user raw tool-call markup instead of an answer, for example `<｜｜DSML｜｜tool_calls> <｜｜DSML｜｜invoke name="trading_quote">`, `<||DSML||tool_calls>` or `<tool_calls><invoke name="write_file">`.
- A single empty reply from the provider (no text and no tool call) ends the run, even a few seconds after the report file was written, with `empty_model_response: provider=openai model=deepseek-v4-pro iteration 7 returned no content and no tool calls`.
- Runs freeze for half an hour with no activity until someone kills them.
  The provider keeps the connection open but stops sending anything, sometimes in the middle of an answer and sometimes while a long conversation is being summarized (the log ends at `Auto compact: folding 1 summary chunks`).
  Lowering `TIMEOUT_SECONDS` does not help.

What we need:

- A date cell that carries a weekday or session note is checked against the data for that day.
  The price checks stay exactly as strict as they are now.
  A wrong price, another day's price, or a price for a day the run never fetched (the same date in another year counts) is still rejected, and so is anything the gate rejects today.
- Tool-call markup never reaches the user.
  If the run still has iterations left, ask the model again and deliver its real answer.
  Ordinary answers that contain `<` (like `RSI < 30`) go out unchanged.
- One empty reply gets one retry.
  Two back to back still fail the run with the same `empty_model_response` error.
- Add a `VIBE_TRADING_LLM_TIMEOUT_SECONDS` setting, on by default with a limit of a few minutes.
  A model call that sends nothing for longer than that is given up.
  A stalled answer gets one retry like any other transient provider error, and if the retry stalls too the run fails.
  A stalled summary means the conversation still gets shortened, just without the summary, and the run carries on, while a summary that arrives in time is used as before.
  A reply that keeps streaming, reasoning included, is never cut off, however long it takes in total.
