## Task

A fuzzing run against our JSON functions turned up a batch of inputs where we don't behave like SQLite.
I checked each case against the sqlite3 shell, and they fall into a few groups.

The worst ones are binary JSON blobs that crash the engine.
This one, passed to `json()`, panics and takes the whole process down:

```sql
SELECT json(x'6454EF97933F5D');
```

SQLite just answers `malformed JSON` there.
The same kind of broken number, sitting inside a bigger binary array or object, also panics `json_each` and `json_tree`.
Those two can also panic on a blob whose text value or object key isn't valid UTF-8.
None of this should ever crash.
Each of these queries should fail with a normal error, and the connection should keep working afterward.

Other broken blobs don't crash, they just return junk.
`SELECT json(x'04')` and `SELECT json(x'443078314A')` both return an empty string, where SQLite reports `malformed JSON`.
`json_each` over a blob whose first element is an array holding a broken number returns `[` as that row's value.
These should be errors too.

In text input, we accept some numbers that SQLite rejects with `malformed JSON`.
These should be errors whether the number is the whole document or a value inside an array or object:
- a sign with no digits, like `-`
- an exponent with no digits, like `1e`, `1e+` or `1e-`

A lone `+`, a hex prefix with no digits (`0x`), leading zeros (`00`, `01`), doubled signs (`--1`, `++1`, `+-1`) and an empty or blank string are already errors, and they need to stay that way.

`NaN` goes the other way.
It is valid JSON5 in any letter case (`NaN`, `nan`, `nAn`, `NAN`), and SQLite turns it into `null`.
For us, `SELECT json('NaN')` fails.

Valid input has to keep working as it does now:
- Valid binary JSON, whether we wrote it with `jsonb()` or SQLite did, still comes back as the same text through `json()`.
- JSON5 numbers in text input keep their canonical text: hex integers become decimal, `4.` becomes `4.0`, `.25` becomes `0.25`, a leading `+` is dropped, and `Infinity` prints as `9e999`.
- `json_each` and `json_tree` over valid text or binary JSON return the same keys, full keys, types and values (text, integer and real) as they do now.

Please fix this at the root instead of special-casing these inputs.
