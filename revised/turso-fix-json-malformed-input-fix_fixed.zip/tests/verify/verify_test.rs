//! Behavioral checks for the SQL JSON functions (`json`, `json_each`,
//! `json_tree`) driven through a real `turso_core::Connection`.
//!
//! Every check here speaks SQL and inspects the returned rows, or the fact
//! that a query returned an error. None of them reach into the private
//! `core/json` helpers, name an internal symbol, or match a specific
//! error-message string. A query that must reject malformed input is asserted
//! only to return `Err`, so any wording is acceptable.
//!
//! Binary inputs are written as SQL blob literals. Each one is either produced
//! by `jsonb()` in the same query, or is a byte sequence in the binary JSON
//! layout (one header byte holding the payload size in the high nibble and the
//! element type in the low nibble, followed by the payload).
//!
//! The connection/exec helpers below are inlined: the repo's integration
//! helpers (`tests/integration/common.rs`) live in a module that is private to
//! the `integration_tests` target and cannot be imported from a sibling
//! integration test. These few functions mirror that module's `TempDatabase` /
//! `try_limbo_exec_rows` shape.

use std::sync::Arc;

use turso_core::{Connection, Database, LimboError};

/// Owned, comparable mirror of `turso_core::Value` so assertions don't depend
/// on the engine value type's lifetime or trait impls.
#[derive(Debug, Clone, PartialEq)]
enum Cell {
    Null,
    Int(i64),
    Real(f64),
    Text(String),
    Blob(Vec<u8>),
}

/// Fresh file-backed temp database + connection, mirroring `TempDatabase`.
fn connect() -> (tempfile::TempDir, Arc<Connection>) {
    let dir = tempfile::TempDir::new().expect("create temp dir");
    let mut path = dir.path().to_path_buf();
    path.push("verify.db");
    let io = Arc::new(turso_core::PlatformIO::new().expect("platform io"));
    let db: Arc<Database> =
        Database::open_file(io, path.to_str().expect("utf8 path")).expect("open db");
    let conn = db.connect().expect("connect");
    // Keep `dir` alive for the lifetime of the connection: dropping it would
    // remove the backing file.
    (dir, conn)
}

/// Run a query and collect its rows, returning `Err` if preparation or
/// execution fails (the engine surfaces malformed input as an execution error).
fn exec(conn: &Arc<Connection>, sql: &str) -> Result<Vec<Vec<Cell>>, LimboError> {
    let mut stmt = conn.prepare(sql)?;
    let mut rows: Vec<Vec<Cell>> = Vec::new();
    stmt.run_with_row_callback(|row| {
        let cells = row
            .get_values()
            .map(|v| match v {
                turso_core::Value::Null => Cell::Null,
                turso_core::Value::Integer(i) => Cell::Int(*i),
                turso_core::Value::Float(f) => Cell::Real(*f),
                turso_core::Value::Text(t) => Cell::Text(t.as_str().to_string()),
                turso_core::Value::Blob(b) => Cell::Blob(b.to_vec()),
            })
            .collect();
        rows.push(cells);
        Ok(())
    })?;
    Ok(rows)
}

/// All rows of a query that must succeed.
fn rows(conn: &Arc<Connection>, sql: &str) -> Vec<Vec<Cell>> {
    exec(conn, sql).unwrap_or_else(|e| panic!("query failed unexpectedly: {sql}: {e}"))
}

/// Single-cell text result from a one-row, one-column query.
fn one_text(conn: &Arc<Connection>, sql: &str) -> String {
    let rows = rows(conn, sql);
    assert_eq!(rows.len(), 1, "expected exactly one row from {sql}");
    assert_eq!(rows[0].len(), 1, "expected exactly one column from {sql}");
    match &rows[0][0] {
        Cell::Text(t) => t.clone(),
        other => panic!("expected a text cell from {sql}, got {other:?}"),
    }
}

/// The first column of every row, as text.
fn first_col_text(conn: &Arc<Connection>, sql: &str) -> Vec<String> {
    rows(conn, sql)
        .iter()
        .map(|r| match &r[0] {
            Cell::Text(t) => t.clone(),
            other => panic!("expected a text cell from {sql}, got {other:?}"),
        })
        .collect()
}

/// The query must come back as an error, not as rows.
fn assert_rejected(conn: &Arc<Connection>, sql: &str) {
    let res = exec(conn, sql);
    assert!(
        res.is_err(),
        "{sql} should surface an error, but it returned {res:?}"
    );
}

/// A plain valid query still works on the same connection.
fn assert_connection_usable(conn: &Arc<Connection>) {
    assert_eq!(one_text(conn, "SELECT json('[1,\"a\"]')"), r#"[1,"a"]"#);
}

fn text(s: &str) -> Cell {
    Cell::Text(s.to_string())
}

// ---------------------------------------------------------------------------
// Values that must parse and produce a specific result.
// ---------------------------------------------------------------------------

/// `NaN` in any letter case is a JSON5 value that maps to the JSON `null`
/// value, as in SQLite. It must not be rejected.
#[test]
fn json_nan_maps_to_null() {
    let (_dir, conn) = connect();
    for input in ["NaN", "nan", "nAn", "NAN"] {
        assert_eq!(
            one_text(&conn, &format!("SELECT json('{input}')")),
            "null",
            "json('{input}')"
        );
    }
    assert_eq!(one_text(&conn, "SELECT json('[NaN,1]')"), "[null,1]");
}

// ---------------------------------------------------------------------------
// Malformed text inputs that must surface an error to the SQL caller.
// ---------------------------------------------------------------------------

/// A bare sign, an exponent with no digits, or a hex prefix with no digits is
/// not a valid number, whether it is the whole document or a value inside an
/// array or object.
#[test]
fn json_malformed_numbers_are_rejected() {
    let (_dir, conn) = connect();
    for input in [
        "-", "+", "1e", "1e+", "1e-", "0x", "2E", "-7e-", "-0x", "[1e]", "{\"a\":-}",
        "[1,2E+]", "[+]",
    ] {
        assert_rejected(&conn, &format!("SELECT json('{input}')"));
    }
}

/// Leading zeros and doubled signs are not valid numbers and must be rejected.
#[test]
fn json_leading_zeros_and_doubled_signs_are_rejected() {
    let (_dir, conn) = connect();
    for input in ["00", "01", "--1", "++1", "-01", "[1,02]", "+-1"] {
        assert_rejected(&conn, &format!("SELECT json('{input}')"));
    }
}

/// An empty or blank string is not valid JSON and must be rejected.
#[test]
fn json_empty_string_is_rejected() {
    let (_dir, conn) = connect();
    assert_rejected(&conn, "SELECT json('')");
    assert_rejected(&conn, "SELECT json('   ')");
}

// ---------------------------------------------------------------------------
// Malformed binary inputs: an error, never a crash, and the connection
// keeps working afterward.
// ---------------------------------------------------------------------------

/// Binary values whose number payload is broken: non-ASCII bytes inside the
/// number, a hex prefix followed by a non-hex character, and an empty number.
#[test]
fn json_malformed_binary_payload_errors_without_crashing() {
    let (_dir, conn) = connect();
    for blob in [
        "6454EF97933F5D", // payload "T" + a 3-byte character + "?]"
        "5430C3A93132",   // payload "0" + a 2-byte character + "12"
        "543078E282AC",   // payload "0x" + a 3-byte character
        "443078314A",     // payload "0x1J"
        "04",             // empty number payload
    ] {
        assert_rejected(&conn, &format!("SELECT json(x'{blob}')"));
        assert_connection_usable(&conn);
    }
}

/// The same broken numbers placed inside a larger binary array or object make
/// `json_each` and `json_tree` return an error, and the connection keeps
/// working.
#[test]
fn json_each_and_tree_malformed_binary_errors_without_crashing() {
    let (_dir, conn) = connect();
    for sql in [
        // [1, <number "T" + 3-byte character + "?]">]
        "SELECT key, value, type FROM json_each(x'9B13316454EF97933F5D')",
        // {"k": <number "T" + 3-byte character + "?]">}
        "SELECT fullkey, value FROM json_tree(x'9C176B6454EF97933F5D')",
        // [1, <number "0" + 2-byte character + "12">]
        "SELECT fullkey, value FROM json_tree(x'8B13315430C3A93132')",
        // [[<number "0x1J">], 1]: the first element is an array
        "SELECT key, value FROM json_each(x'8B5B443078314A1331')",
    ] {
        assert_rejected(&conn, sql);
        assert_connection_usable(&conn);
    }
}

/// Binary text or an object key that is not valid UTF-8 makes `json_each` and
/// `json_tree` return an error, and the connection keeps working.
#[test]
fn json_each_and_tree_invalid_utf8_binary_errors_without_crashing() {
    let (_dir, conn) = connect();
    for sql in [
        // [1, <text FF FE>, 2, 3]
        "SELECT key, value FROM json_each(x'9B133127FFFE13321333')",
        // {<key FF FE>: 1, "a": 2}
        "SELECT fullkey, value FROM json_tree(x'9C27FFFE133117611332')",
    ] {
        assert_rejected(&conn, sql);
        assert_connection_usable(&conn);
    }
}

// ---------------------------------------------------------------------------
// Valid inputs that must keep producing the same output (no over-rejection).
// ---------------------------------------------------------------------------

/// Valid JSON5 inputs still parse and serialize to the same canonical JSON:
/// hex integers, leading and trailing-dot decimals, a leading plus sign, and
/// Infinity.
#[test]
fn valid_json5_still_round_trips() {
    let (_dir, conn) = connect();
    assert_eq!(one_text(&conn, "SELECT json('{a: 0x0}')"), r#"{"a":0}"#);
    assert_eq!(one_text(&conn, "SELECT json('{x: 4.}')"), r#"{"x":4.0}"#);
    assert_eq!(
        one_text(&conn, "SELECT json('{x: Infinity}')"),
        r#"{"x":9e999}"#
    );
    assert_eq!(
        one_text(&conn, "SELECT json('[+5,-0x1A,.25]')"),
        "[5,-26,0.25]"
    );
    assert_eq!(one_text(&conn, "SELECT json('-1')"), "-1");
    assert_eq!(one_text(&conn, "SELECT json('{\"k\":1}')"), r#"{"k":1}"#);
}

/// Valid binary JSON converts back to the same text, both when it comes from
/// `jsonb()` and when it is a value in the same binary layout written by
/// another engine.
#[test]
fn valid_binary_json_round_trips() {
    let (_dir, conn) = connect();
    assert_eq!(
        one_text(&conn, r#"SELECT json(jsonb('{"a":[1,2.5,"x",null,true]}'))"#),
        r#"{"a":[1,2.5,"x",null,true]}"#
    );
    assert_eq!(
        one_text(&conn, "SELECT json(jsonb('[-0x10,+5,.5,7.]'))"),
        "[-16,5,0.5,7.0]"
    );
    assert_eq!(
        one_text(&conn, r#"SELECT json(jsonb('{"k":[0xFF,-3,"t"],"n":null}'))"#),
        r#"{"k":[255,-3,"t"],"n":null}"#
    );
    // {"a":[1,2.5,"x",null,true]}
    assert_eq!(
        one_text(&conn, "SELECT json(x'CC0D1761AB133135322E3517780001')"),
        r#"{"a":[1,2.5,"x",null,true]}"#
    );
    // 0x1F and -0x10 stored as JSON5 integers
    assert_eq!(one_text(&conn, "SELECT json(x'4430783146')"), "31");
    assert_eq!(one_text(&conn, "SELECT json(x'542D30783130')"), "-16");
}

/// The JSON table-valued functions keep returning correct keys, values, types
/// and full-key paths, for text input and for binary input.
#[test]
fn json_each_and_tree_valid_inputs_unchanged() {
    let (_dir, conn) = connect();

    let fullkeys = first_col_text(
        &conn,
        r#"SELECT fullkey FROM json_tree('{"a":1,"b":{"c":2},"d":[3,4]}') ORDER BY id"#,
    );
    assert_eq!(
        fullkeys,
        vec!["$", "$.a", "$.b", "$.b.c", "$.d", "$.d[0]", "$.d[1]"]
    );

    let values = first_col_text(
        &conn,
        r#"SELECT value FROM json_each('["x","y","z"]') ORDER BY id"#,
    );
    assert_eq!(values, vec!["x", "y", "z"]);

    assert_eq!(
        rows(
            &conn,
            r#"SELECT key, value, type FROM json_each('[1,2.5,"z",-3]') ORDER BY id"#
        ),
        vec![
            vec![Cell::Int(0), Cell::Int(1), text("integer")],
            vec![Cell::Int(1), Cell::Real(2.5), text("real")],
            vec![Cell::Int(2), text("z"), text("text")],
            vec![Cell::Int(3), Cell::Int(-3), text("integer")],
        ]
    );

    assert_eq!(
        rows(
            &conn,
            r#"SELECT value, type FROM json_each(jsonb('[0x1F,-2,3.5,"s"]')) ORDER BY id"#
        ),
        vec![
            vec![Cell::Int(31), text("integer")],
            vec![Cell::Int(-2), text("integer")],
            vec![Cell::Real(3.5), text("real")],
            vec![text("s"), text("text")],
        ]
    );

    assert_eq!(
        rows(
            &conn,
            r#"SELECT fullkey, value FROM json_tree(jsonb('{"p":{"q":[7,"w"]}}')) ORDER BY id"#
        ),
        vec![
            vec![text("$"), text(r#"{"p":{"q":[7,"w"]}}"#)],
            vec![text("$.p"), text(r#"{"q":[7,"w"]}"#)],
            vec![text("$.p.q"), text(r#"[7,"w"]"#)],
            vec![text("$.p.q[0]"), Cell::Int(7)],
            vec![text("$.p.q[1]"), text("w")],
        ]
    );

    assert_eq!(
        rows(
            &conn,
            r#"SELECT fullkey, value FROM json_tree('{"a b":1,"c_d":[2]}') ORDER BY id"#
        ),
        vec![
            vec![text("$"), text(r#"{"a b":1,"c_d":[2]}"#)],
            vec![text("$.\"a b\""), Cell::Int(1)],
            vec![text("$.\"c_d\""), text("[2]")],
            vec![text("$.\"c_d\"[0]"), Cell::Int(2)],
        ]
    );
}
