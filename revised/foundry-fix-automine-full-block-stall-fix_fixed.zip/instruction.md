## Task

We have a deploy script that sends a big batch of transactions back-to-back to a local anvil node running with automine, then waits for every receipt.
When the batch is bigger than what fits in one block, anvil mines a single block and then goes quiet.
The rest of the batch stays in the pool, nothing else gets mined, and the script waits on those receipts forever.
A batch small enough for one block is fine and still goes out in one block.
Could you find out why the node stops there and get it to keep going until the leftovers are mined?
We've also had a transaction sitting in the pool that can't fit in any block at all, for example after lowering the block gas limit with `evm_setBlockGasLimit`.
That one should just stay pending, and anvil shouldn't keep mining empty blocks because of it.
