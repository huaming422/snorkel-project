"""Behavioral checks for how account creation reports a failed write.

Every check drives the public ``SQLiteUserRepository.create_user`` method
against a real local (aiosqlite) engine built through the repository's own
persistence lifecycle (``init_engine`` / ``get_session_factory`` /
``close_engine``), the same way the repo's ``tests/test_auth.py`` does.
Nothing here imports a helper the fix may add.

What the checks hold to, without pinning any wording:
  * A failure is never pinned on an email address as a duplicate unless the
    email really is the duplicate. Naming the address as context is fine.
  * A collision on an already-linked SSO identity is reported as that
    identity, and a genuine email duplicate still names the supplied address.
  * Any other duplicate still raises ``ValueError`` (the error the register,
    setup and SSO callers catch) and reads as a duplicate, not as an identity
    or email problem.
  * A write failure that is not a duplicate (a missing required value) says
    what went wrong and is not reported as a duplicate. Re-raising the
    original error or translating it are both accepted.

The Postgres cases feed ``create_user`` an error built the way SQLAlchemy's
asyncpg adapter builds one: a DB-API error whose text is
"<driver class>: <driver message>" and whose ``pgcode``/``sqlstate`` carry the
status, raised from the driver error that also carries ``constraint_name``.
"""

from __future__ import annotations

import asyncio
import re
import sqlite3
import sys
from pathlib import Path
from unittest.mock import patch
from uuid import uuid4

import pytest

# ---------------------------------------------------------------------------
# Import context. This file runs out-of-tree (not under backend/tests), so the
# repo conftest that normally wires sys.path is not auto-loaded. Replicate the
# two inserts it performs, and pre-mock the one module the repo conftest guards
# against a circular import, before importing any ``app`` module. test-setup.sh
# also exports PYTHONPATH as a backstop.
# ---------------------------------------------------------------------------
_BACKEND = Path("/repo/deer-flow/backend")
for _p in (str(_BACKEND), str(_BACKEND / "scripts")):
    if _p not in sys.path:
        sys.path.insert(0, _p)

if "deerflow.subagents.executor" not in sys.modules:
    from unittest.mock import MagicMock

    sys.modules["deerflow.subagents.executor"] = MagicMock()

from app.gateway.auth.models import User  # noqa: E402
from app.gateway.auth.repositories import sqlite as sqlite_repo  # noqa: E402
from app.gateway.auth.repositories.sqlite import SQLiteUserRepository  # noqa: E402
from deerflow.persistence.engine import (  # noqa: E402
    close_engine,
    get_session_factory,
    init_engine,
)
from sqlalchemy.exc import IntegrityError  # noqa: E402

# The statement text SQLAlchemy attaches to a failed users insert.
_INSERT_SQL = (
    "INSERT INTO users (id, email, password_hash, system_role, created_at, "
    "oauth_provider, oauth_id, needs_setup, token_version) "
    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
)


class UniqueViolationError(Exception):
    """Stand-in for asyncpg's unique-violation error."""

    sqlstate = "23505"

    def __init__(self, constraint_name: str) -> None:
        super().__init__(f'duplicate key value violates unique constraint "{constraint_name}"')
        self.constraint_name = constraint_name
        self.column_name = None


class NotNullViolationError(Exception):
    """Stand-in for asyncpg's not-null-violation error."""

    sqlstate = "23502"

    def __init__(self, column_name: str) -> None:
        super().__init__(f'null value in column "{column_name}" of relation "users" violates not-null constraint')
        self.constraint_name = None
        self.column_name = column_name


class AsyncAdaptIntegrityError(Exception):
    """Stand-in for the DB-API IntegrityError the asyncpg adapter raises."""


def _asyncpg_integrity_error(driver_error: Exception) -> IntegrityError:
    adapted = AsyncAdaptIntegrityError(f"{type(driver_error)}: {driver_error}")
    adapted.pgcode = adapted.sqlstate = driver_error.sqlstate
    adapted.__cause__ = driver_error
    return IntegrityError(_INSERT_SQL, {}, orig=adapted)


def _run(scenario) -> None:
    """Run an async scenario with a fresh engine, always tearing it down."""
    asyncio.run(scenario())


_DUPLICATE_WORDS = re.compile(r"already|taken|in use|exists|registered|duplicate|conflict")


def _blames_email(message: str, email: str) -> bool:
    """True when the message calls an email address the duplicate."""
    lowered = message.lower()
    address = email.lower()
    if re.search(r"(duplicate|conflicting|existing) e-?mail", lowered):
        return True
    for match in re.finditer(r"e-?mail", lowered.replace(address, "<address>")):
        if _DUPLICATE_WORDS.search(lowered.replace(address, "<address>")[match.end() : match.end() + 40]):
            return True
    position = lowered.find(address)
    while position != -1:
        if re.search(r"already|is taken|in use", lowered[position + len(address) : position + len(address) + 40]):
            return True
        position = lowered.find(address, position + 1)
    return False


def _assert_identity_conflict(message: str, *, email: str, provider: str, oauth_id: str) -> None:
    assert not _blames_email(message, email), f"identity collision reported as an email duplicate: {message!r}"
    lowered = message.lower()
    tokens = ("oauth", "sso", "identity", "linked", "login", "provider", "subject", provider.lower(), oauth_id.lower())
    assert any(token in lowered for token in tokens), f"identity collision not reported as the identity: {message!r}"


def _assert_other_duplicate(message: str, *, email: str) -> None:
    assert not _blames_email(message, email), f"other duplicate reported as an email duplicate: {message!r}"
    lowered = message.lower()
    assert not any(token in lowered for token in ("oauth", "sso", "identity", "linked")), (
        f"other duplicate reported as an identity collision: {message!r}"
    )
    tokens = ("already", "duplicate", "unique", "conflict", "primary key", "pkey", "users.id")
    assert any(token in lowered for token in tokens), f"other duplicate not reported as a duplicate: {message!r}"


def _assert_non_duplicate_cause_named(exc: BaseException, *, email: str, column: str) -> None:
    """A missing required value says what went wrong and is not called a
    duplicate, whatever exception type carries it."""
    message = str(exc.orig) if isinstance(exc, IntegrityError) else str(exc)
    lowered = message.lower()
    assert not _blames_email(message, email), f"non-duplicate failure reported as an email duplicate: {message!r}"
    assert not re.search(r"already|duplicate|conflict|unique", lowered), (
        f"non-duplicate failure reported as a duplicate: {message!r}"
    )
    tokens = (column, "null", "required", "missing")
    assert any(token in lowered for token in tokens), f"non-duplicate failure does not name the missing value: {message!r}"


# ── an SSO identity collision is reported as the identity, not the email ─────


def test_oauth_identity_collision_not_blamed_on_email(tmp_path):
    async def _scenario() -> None:
        url = f"sqlite+aiosqlite:///{tmp_path}/scratch.db"
        await init_engine("sqlite", url=url, sqlite_dir=str(tmp_path))
        try:
            repo = SQLiteUserRepository(get_session_factory())
            first = User(
                email="linked-a@test.com",
                password_hash=None,
                system_role="user",
                oauth_provider="github",
                oauth_id="dup-123",
            )
            created = await repo.create_user(first)
            assert created.oauth_id == "dup-123"

            # Same (provider, oauth_id) pair, different email.
            second = User(
                email="linked-b@test.com",
                password_hash=None,
                system_role="user",
                oauth_provider="github",
                oauth_id="dup-123",
            )
            with pytest.raises(ValueError) as caught:
                await repo.create_user(second)
            _assert_identity_conflict(str(caught.value), email="linked-b@test.com", provider="github", oauth_id="dup-123")
        finally:
            await close_engine()

    _run(_scenario)


# ── a duplicate id is reported as a duplicate, not as an identity or email ───


def test_duplicate_primary_key_not_misreported_as_oauth_or_email(tmp_path):
    async def _scenario() -> None:
        url = f"sqlite+aiosqlite:///{tmp_path}/scratch.db"
        await init_engine("sqlite", url=url, sqlite_dir=str(tmp_path))
        try:
            repo = SQLiteUserRepository(get_session_factory())
            shared_id = uuid4()
            await repo.create_user(User(id=shared_id, email="first@test.com", password_hash="h", system_role="user"))

            # Same id, different email: the email is free, the id is not.
            duplicate = User(id=shared_id, email="second@test.com", password_hash="h", system_role="user")
            with pytest.raises(ValueError) as caught:
                await repo.create_user(duplicate)
            _assert_other_duplicate(str(caught.value), email="second@test.com")
        finally:
            await close_engine()

    _run(_scenario)


# ── a missing required value is not reported as a duplicate ──────────────────


def test_non_uniqueness_failure_names_real_cause(tmp_path):
    async def _scenario() -> None:
        url = f"sqlite+aiosqlite:///{tmp_path}/scratch.db"
        await init_engine("sqlite", url=url, sqlite_dir=str(tmp_path))
        try:
            repo = SQLiteUserRepository(get_session_factory())
            not_null = IntegrityError(
                _INSERT_SQL,
                {},
                orig=sqlite3.IntegrityError("NOT NULL constraint failed: users.system_role"),
            )
            with patch.object(sqlite_repo.AsyncSession, "commit", side_effect=not_null):
                with pytest.raises(Exception) as caught:
                    await repo.create_user(User(email="x@test.com", password_hash="h", system_role="user"))
            _assert_non_duplicate_cause_named(caught.value, email="x@test.com", column="system_role")
        finally:
            await close_engine()

    _run(_scenario)


# ── an email duplicate that reaches the write still names the address ────────


def test_email_race_still_reports_email(tmp_path):
    async def _scenario() -> None:
        url = f"sqlite+aiosqlite:///{tmp_path}/scratch.db"
        await init_engine("sqlite", url=url, sqlite_dir=str(tmp_path))
        try:
            repo = SQLiteUserRepository(get_session_factory())
            await repo.create_user(User(email="race@test.com", password_hash="h", system_role="user"))

            # A second insert that got past the "is this email taken" lookup,
            # as a concurrent request would; the write itself then collides.
            racing = User(email="race@test.com", password_hash="h", system_role="user")
            with patch.object(sqlite_repo.AsyncSession, "scalar", return_value=None):
                with pytest.raises(ValueError, match="race@test.com") as caught:
                    await repo.create_user(racing)
            assert not any(token in str(caught.value).lower() for token in ("oauth", "sso", "identity")), (
                f"email duplicate reported as an identity collision: {caught.value!r}"
            )
        finally:
            await close_engine()

    _run(_scenario)


# ── the same outcomes for errors shaped like a Postgres deployment's ─────────


def test_postgres_shaped_exception_classified_through_create_user(tmp_path):
    async def _scenario() -> None:
        url = f"sqlite+aiosqlite:///{tmp_path}/scratch.db"
        await init_engine("sqlite", url=url, sqlite_dir=str(tmp_path))
        try:
            repo = SQLiteUserRepository(get_session_factory())

            def _make_user(email: str) -> User:
                return User(
                    email=email,
                    password_hash=None,
                    system_role="user",
                    oauth_provider="okta",
                    oauth_id="pg-7741",
                )

            def _fail_commit(driver_error: Exception):
                return patch.object(
                    sqlite_repo.AsyncSession,
                    "commit",
                    side_effect=_asyncpg_integrity_error(driver_error),
                )

            with _fail_commit(UniqueViolationError("idx_users_oauth_identity")):
                with pytest.raises(ValueError) as caught:
                    await repo.create_user(_make_user("pg-oauth@test.com"))
            _assert_identity_conflict(str(caught.value), email="pg-oauth@test.com", provider="okta", oauth_id="pg-7741")

            with _fail_commit(UniqueViolationError("ix_users_email")):
                with pytest.raises(ValueError, match="pg-email@test.com") as caught:
                    await repo.create_user(_make_user("pg-email@test.com"))
            assert not any(token in str(caught.value).lower() for token in ("oauth", "sso", "identity")), (
                f"email duplicate reported as an identity collision: {caught.value!r}"
            )

            with _fail_commit(UniqueViolationError("users_pkey")):
                with pytest.raises(ValueError) as caught:
                    await repo.create_user(_make_user("pg-pk@test.com"))
            _assert_other_duplicate(str(caught.value), email="pg-pk@test.com")

            with _fail_commit(NotNullViolationError("system_role")):
                with pytest.raises(Exception) as caught:
                    await repo.create_user(_make_user("pg-notnull@test.com"))
            _assert_non_duplicate_cause_named(caught.value, email="pg-notnull@test.com", column="system_role")
        finally:
            await close_engine()

    _run(_scenario)


# ── the happy path and the ordinary duplicate-email lookup are unchanged ─────


def test_happy_path_and_duplicate_email_precheck_unchanged(tmp_path):
    async def _scenario() -> None:
        url = f"sqlite+aiosqlite:///{tmp_path}/scratch.db"
        await init_engine("sqlite", url=url, sqlite_dir=str(tmp_path))
        try:
            repo = SQLiteUserRepository(get_session_factory())

            created = await repo.create_user(
                User(
                    email="new@test.com",
                    password_hash="fakehash",
                    system_role="admin",
                    needs_setup=True,
                    token_version=3,
                )
            )
            assert created.needs_setup is True
            assert created.token_version == 3
            fetched = await repo.get_user_by_email("new@test.com")
            assert fetched is not None
            assert fetched.token_version == 3

            # An ordinary duplicate email is still rejected with a ValueError
            # naming the address.
            with pytest.raises(ValueError, match="new@test.com"):
                await repo.create_user(User(email="new@test.com", password_hash="h2", system_role="user"))
        finally:
            await close_engine()

    _run(_scenario)
