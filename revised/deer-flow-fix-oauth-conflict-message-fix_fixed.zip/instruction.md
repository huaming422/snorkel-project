## Task

Account creation on the gateway sometimes fails with "Email already registered: <address>" even though no account has that address.
It shows up most with SSO, when two logins belong to one upstream user but carry different emails.
The second login fails, and the error names its own email, which nobody has registered.
The same message also comes back for write failures that have nothing to do with email, like a duplicate user id or a row missing a required value.
It only happens when the new account is written, never at the earlier "is this email taken" lookup, so people keep checking the email field and can't tell what collided.
We hit it on both SQLite and Postgres deployments.

Instead, the error should match what happened:

- An SSO identity that is already linked to an account is reported as that identity, not as an email problem.
- An email that really is taken, even one that only collides when the row is written, is still reported with that address.
- Any other duplicate still reads as a duplicate, without being pinned on an email or an SSO identity.
- A write that fails for a reason other than a duplicate says what failed and isn't reported as an account that already exists.

Duplicates should keep raising the same kind of error they raise today.
The register, first-admin setup and SSO login flows catch it to answer with a 4xx instead of a 500.
