# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

"""
Behavioral checks for stopping SQL Lab queries on Impala.

A SQL Lab worker polls the live Impala operation in ``handle_cursor`` while a
separate stop request updates the same Query row. The checks below cover:

  - a SQL Lab stop of a running Impala query whose cancel handle is published is
    carried out on the live cursor (``cancel_operation``), with no HTTP call to
    the coordinator;
  - chart cancellation still cancels an Impala query through the coordinator's
    HTTP endpoint;
  - a query that reached success, failed or timed_out while the stop was being
    prepared keeps that status, and the stop reports False;
  - a stop seen while the Celery worker polls an impyla cursor ends as STOPPED;
  - the poll loop sees a STOPPED committed by another session while the worker
    holds a repeatable-read snapshot.

The race needs a live coordinator at any higher level, so the checks call the
existing entry points directly: ``superset.sql_lab.cancel_query``,
``SQLExecutor._cancel_query``, ``ImpalaEngineSpec.handle_cursor``,
``superset.tasks.query_cancel.cancel_chart_query`` and
``celery_task._execute_sql_statements``. They import only names that already
exist (the ``QUERY_*`` keys in ``superset.constants`` and ``QueryStatus``) and
assert outcomes: whether the coordinator was called, whether the live operation
was cancelled, and the final query status.

Fixtures live in ``conftest.py`` beside this file, because the repository's test
``conftest.py`` is not on the collection path from here.
"""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, Mock, patch

import pytest
from flask import Flask
from pytest_mock import MockerFixture
from sqlalchemy import create_engine, event, update
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session

from superset.constants import (
    QUERY_CANCEL_KEY,
    QUERY_DISPATCHED_KEY,
    QUERY_EARLY_CANCEL_KEY,
)
from superset.db_engine_specs.impala import ImpalaEngineSpec
from superset.sql.execution import celery_task
from superset.sql.execution.executor import SQLExecutor
from superset.sql_lab import cancel_query
from superset.utils.core import QueryStatus

CANCEL_ID = "0123456789abcdef:fedcba9876543210"


# =============================================================================
# SQL Lab stop of a running query with a published handle uses the live cursor.
# =============================================================================
@pytest.mark.parametrize("use_executor", [False, True])
def test_impala_stop_uses_live_cursor(use_executor: bool) -> None:
    """Stopping a running Impala query whose cancel handle is already published
    cancels it through the live cursor only.

    The stop is driven through both stop callers (``cancel_query`` and
    ``SQLExecutor._cancel_query``), then the worker's ``handle_cursor`` poll runs.
    The poll cancels and closes the operation, and the coordinator gets no HTTP
    request.
    """
    app = Flask(__name__)
    app.config["DB_POLL_INTERVAL_SECONDS"] = {"impala": 0}
    query = MagicMock(
        id=1,
        extra={QUERY_CANCEL_KEY: CANCEL_ID, QUERY_DISPATCHED_KEY: True},
        status="running",
        progress=0,
    )
    query.database.db_engine_spec = ImpalaEngineSpec
    query.database.url_object.host = "impala.example.com"

    def set_extra_json_key(key: str, value: bool) -> None:
        query.extra[key] = value

    query.set_extra_json_key.side_effect = set_extra_json_key

    with (
        app.app_context(),
        patch("superset.db_engine_specs.impala.db") as db,
        patch("superset.db_engine_specs.impala.requests.post") as post,
    ):
        # Preparing the stop does not cancel through the coordinator and does not
        # commit a second time.
        if use_executor:
            assert SQLExecutor._cancel_query(query.database, query)
        else:
            assert cancel_query(query)
        db.session.commit.assert_not_called()

        cursor = Mock()
        cursor.status.return_value = "RUNNING_STATE"
        ImpalaEngineSpec.handle_cursor(cursor, query)

    # The stop was routed to the live cursor: the early-cancel flag is set, no
    # HTTP cancel was issued, and the operation was cancelled and closed.
    assert query.extra[QUERY_EARLY_CANCEL_KEY] is True
    post.assert_not_called()
    cursor.cancel_operation.assert_called_once_with()
    cursor.close_operation.assert_called_once_with()
    cursor.close.assert_called_once_with()


# =============================================================================
# Chart cancellation of an Impala query goes through the coordinator.
# =============================================================================
@pytest.mark.parametrize(
    ("host", "cancel_id"),
    [
        ("impala.example.com", CANCEL_ID),
        ("coordinator-2.internal", "a1b2c3d4e5f60718:8f9e0d1c2b3a4958"),
    ],
)
def test_chart_cancel_reaches_coordinator(
    mocker: MockerFixture, app: Flask, host: str, cancel_id: str
) -> None:
    """Chart cancellation has no polling worker, so cancelling an Impala chart
    query sends the cancel handle to the coordinator's HTTP endpoint and reports
    success when the coordinator accepts it.
    """
    from superset.tasks.query_cancel import cancel_chart_query

    database = MagicMock()
    database.db_engine_spec = ImpalaEngineSpec
    database.url_object.host = host
    mocker.patch.dict(app.config, {"IMPALA_CANCEL_QUERY_ALLOW_INTERNAL_HOSTS": True})
    post = mocker.patch("superset.db_engine_specs.impala.requests.post")
    post.return_value.status_code = 200

    assert cancel_chart_query(database, cancel_id) is True
    post.assert_called_once()
    args, kwargs = post.call_args
    url = args[0] if args else kwargs["url"]
    assert host in url
    assert cancel_id in url


# =============================================================================
# A stop that finds the query finished keeps its terminal status.
# =============================================================================
@pytest.mark.parametrize("caller", ["executor", "sql_lab"])
@pytest.mark.parametrize("finished_status", ["success", "failed", "timed_out"])
def test_stop_preserves_finished_status(
    mocker: MockerFixture,
    database: Any,
    finished_status: str,
    caller: str,
) -> None:
    """A query that reached a finished status while the stop was being prepared
    is not cancelled, and its terminal status is kept.

    ``prepare_cancel_query`` is made to observe the query finishing. The stop
    caller then returns False and performs no engine cancellation. Both stop
    callers are covered: the executor's ``_cancel_query`` and SQL Lab's
    ``cancel_query``, which is the stop path the query DAO drives.
    """
    mock_query = MagicMock()
    mock_query.status = QueryStatus.RUNNING
    mock_query.extra = {QUERY_CANCEL_KEY: CANCEL_ID}
    mock_query.database = database

    def finish(query: MagicMock) -> None:
        query.status = QueryStatus(finished_status)

    mocker.patch.object(
        database.db_engine_spec, "has_implicit_cancel", return_value=False
    )
    mocker.patch.object(
        database.db_engine_spec, "prepare_cancel_query", side_effect=finish
    )
    cancel_mock = mocker.patch.object(
        database.db_engine_spec, "cancel_query", return_value=True
    )
    get_engine = mocker.patch.object(database, "get_sqla_engine")

    if caller == "executor":
        result = SQLExecutor._cancel_query(database, mock_query)
    else:
        result = cancel_query(mock_query)

    assert result is False
    assert mock_query.status == QueryStatus(finished_status)
    cancel_mock.assert_not_called()
    get_engine.assert_not_called()


# =============================================================================
# A stopped impyla cursor on the Celery path ends as STOPPED.
# =============================================================================
@pytest.mark.parametrize("stop_intent", ["executor", "early", "status"])
def test_celery_stopped_not_success(
    mocker: MockerFixture,
    mock_query: Any,
    mock_database: Any,
    stop_intent: str,
) -> None:
    """A stop seen while the Celery worker polls an Impala operation finalizes
    the query as STOPPED.

    A cancelled impyla cursor clears ``cursor.description``, the same as a
    statement with no result set. The stop is applied three ways (through the
    executor stop caller, through the early-cancel flag and through a STOPPED
    status), and each run ends STOPPED with no results stored.
    """
    impyla = pytest.importorskip("impala.hiveserver2")

    mock_query.sql = "SELECT 1"
    mock_query.database = mock_database
    mock_database.db_engine_spec = ImpalaEngineSpec
    mock_query.extra = {QUERY_CANCEL_KEY: CANCEL_ID}
    mock_query.set_extra_json_key.side_effect = lambda key, value: (
        mock_query.extra.update({key: value})
    )
    cursor = impyla.HiveServer2Cursor(MagicMock())
    operation = MagicMock(has_result_set=True)

    def execute_async(sql: str) -> None:
        cursor._last_operation = operation
        cursor._last_operation_active = True

    def stop_before_poll() -> str:
        if stop_intent == "executor":
            assert SQLExecutor._cancel_query(mock_database, mock_query)
        elif stop_intent == "early":
            mock_query.extra[QUERY_EARLY_CANCEL_KEY] = True
        else:
            mock_query.status = QueryStatus.STOPPED
        return "RUNNING_STATE"

    operation.get_status.side_effect = stop_before_poll
    mocker.patch.object(cursor, "execute_async", side_effect=execute_async)
    connection = mock_database.get_raw_connection.return_value.__enter__.return_value
    connection.cursor.return_value = cursor
    mocker.patch.object(ImpalaEngineSpec, "get_cancel_query_id", return_value=None)
    mocker.patch(
        "superset.sql.execution.celery_task._get_query", return_value=mock_query
    )
    finalize = mocker.spy(celery_task, "_finalize_successful_query")
    store = mocker.patch("superset.sql.execution.celery_task._store_results_in_backend")
    mocker.patch("superset.sql.execution.celery_task.results_backend", MagicMock())
    post = mocker.patch("superset.db_engine_specs.impala.requests.post")

    payload = celery_task._execute_sql_statements(123, "SELECT 1", None)

    operation.cancel.assert_called_once_with()
    operation.close.assert_called_once_with()
    assert cursor.description is None
    assert payload is not None
    assert payload["status"] == QueryStatus.STOPPED
    assert mock_query.status == QueryStatus.STOPPED
    connection.commit.assert_not_called()
    finalize.assert_not_called()
    store.assert_not_called()
    post.assert_not_called()


# =============================================================================
# handle_cursor sees a STOPPED committed by another session while the worker
# holds a repeatable-read snapshot.
# =============================================================================
@pytest.fixture
def iso_session_engine(tmp_path: Path) -> Iterator[Engine]:
    # A short busy timeout turns a leaked write lock into a fast failure.
    engine = create_engine(
        f"sqlite:///{tmp_path / 'metadata.db'}", connect_args={"timeout": 1}
    )
    yield engine
    engine.dispose()


@pytest.fixture
def iso_snapshot_engine(iso_session_engine: Engine) -> Iterator[Engine]:
    """An engine whose transactions keep the snapshot of their first read until
    they end, standing in for a repeatable-read worker: WAL plus explicit BEGIN.
    """
    engine = create_engine(iso_session_engine.url, connect_args={"timeout": 1})

    @event.listens_for(engine, "connect")
    def connect(dbapi_connection: Any, _: Any) -> None:
        # Let SQLAlchemy own transaction boundaries so SELECTs run inside them.
        dbapi_connection.isolation_level = None
        dbapi_connection.execute("PRAGMA journal_mode=WAL")

    @event.listens_for(engine, "begin")
    def begin(connection: Any) -> None:
        connection.exec_driver_sql("BEGIN")

    yield engine
    engine.dispose()


@pytest.fixture
def iso_query_id(iso_session_engine: Engine) -> int:
    from superset.models.core import Database
    from superset.models.sql_lab import Query

    Query.metadata.create_all(iso_session_engine)  # pylint: disable=no-member
    database = Database(database_name="my_database", sqlalchemy_uri="sqlite://")
    query = Query(
        client_id="foo",
        database=database,
        sql="select * from bar",
        status=QueryStatus.RUNNING,
        extra_json=f'{{"{QUERY_CANCEL_KEY}": "{CANCEL_ID}"}}',
    )
    with Session(iso_session_engine) as seed:
        seed.add_all([database, query])
        seed.commit()
        return query.id


def _worker_commits(engine: Engine, query_id: int, **values: Any) -> None:
    """Commit a write from another connection, as the SQL Lab worker would."""
    from superset.models.sql_lab import Query

    with Session(engine) as worker:
        worker.execute(update(Query).where(Query.id == query_id).values(**values))
        worker.commit()


def test_handle_cursor_sees_committed_stop(
    mocker: MockerFixture,
    iso_session_engine: Engine,
    iso_snapshot_engine: Engine,
    iso_query_id: int,
) -> None:
    """A poll sees a STOPPED committed by another request after the worker's
    snapshot was taken, and cancels the live operation.

    The worker's session already holds a snapshot that shows RUNNING when the
    other request commits STOPPED. The coordinator keeps reporting the operation
    as running for several polls before it would finish on its own, and the live
    operation is cancelled and closed within that window.
    """
    from superset.models.sql_lab import Query

    app = Flask(__name__)
    app.config["DB_POLL_INTERVAL_SECONDS"] = {"impala": 0}
    worker = Session(iso_snapshot_engine)
    mocker.patch("superset.db.session", worker)
    query = worker.query(Query).filter_by(id=iso_query_id).one()

    # Another request commits the stop after the worker has taken its snapshot.
    _worker_commits(iso_session_engine, iso_query_id, status=QueryStatus.STOPPED)
    worker.refresh(query)
    assert query.status == QueryStatus.RUNNING

    polls = iter(["RUNNING_STATE"] * 5)
    cursor = Mock()
    cursor.status.side_effect = lambda: next(polls, "FINISHED_STATE")
    cursor.get_log.return_value = ""
    with app.app_context():
        ImpalaEngineSpec.handle_cursor(cursor, query)

    cursor.cancel_operation.assert_called_once_with()
    cursor.close_operation.assert_called_once_with()
    worker.close()
