# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

"""
Behavioral checks for stopping SQL Lab queries on Impala.

A SQL Lab worker polls the live Impala operation in ``handle_cursor`` while a
separate stop request updates the same Query row. The checks below cover these cases.

  - A stop of a running Impala query whose cancel handle is published is
    carried out on the live cursor (``cancel_operation``), with no HTTP call to
    the coordinator.
  - A running Impala query that nobody stopped is polled to completion and its
    operation is left alone.
  - Chart cancellation still cancels an Impala query through the coordinator's
    HTTP endpoint.
  - A query that reached success, failed or timed_out while the stop was being
    prepared keeps that status and gets no engine cancel.
  - A stop of a running query on a non-Impala database still sends the engine
    cancel with the published handle.
  - A stop seen while the Celery worker polls an impyla cursor ends as STOPPED.
  - The poll loop sees a STOPPED committed by another session while the worker
    holds a repeatable-read snapshot.

Stops are sent through the two stop entry points, ``QueryDAO.stop_query`` (the
SQL Lab stop endpoint) and the ``cancel`` method of the handle the SQL executor
returns for an async query. Both run against a file-backed SQLite metadata
database, so the stopped row is a real committed row. Worker-side checks drive
``ImpalaEngineSpec.handle_cursor``, the Celery task ``execute_sql_task`` and
``cancel_chart_query``. The coordinator's HTTP endpoint and the engine
connection are patched, so no check needs a live Impala.

They import only names that already exist, such as the ``QUERY_*`` keys in
``superset.constants`` and ``QueryStatus``. Each check asserts an outcome, such
as whether the coordinator got a request or what status the query ended with.

Fixtures live in ``conftest.py`` beside this file, because the repository's test
``conftest.py`` is not on the collection path from here.
"""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, Mock

import pytest
from flask import current_app, Flask
from pytest_mock import MockerFixture
from sqlalchemy import create_engine, event, update
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session

from superset.constants import (
    QUERY_CANCEL_KEY,
    QUERY_DISPATCHED_KEY,
    QUERY_EARLY_CANCEL_KEY,
)
from superset.daos.query import QueryDAO
from superset.db_engine_specs.impala import ImpalaEngineSpec
from superset.db_engine_specs.sqlite import SqliteEngineSpec
from superset.sql.execution.celery_task import execute_sql_task
from superset.sql.execution.executor import SQLExecutor
from superset.utils import json
from superset.utils.core import QueryStatus

CANCEL_ID = "0123456789abcdef:fedcba9876543210"
QUERY_ID = 123
CLIENT_ID = "stop-check"
USER_ID = 7


@pytest.fixture
def stop_engine(tmp_path: Path) -> Iterator[Engine]:
    """A file-backed metadata database holding the Database and Query tables."""
    from superset.models.core import Database
    from superset.models.sql_lab import Query

    engine = create_engine(f"sqlite:///{tmp_path / 'stop.db'}")
    Database.__table__.create(engine)
    Database.metadata.tables["ssh_tunnels"].create(engine)
    Query.__table__.create(engine)
    yield engine
    engine.dispose()


def _seed_running_query(
    engine: Engine, session: Session, sqlalchemy_uri: str, extra: dict[str, Any]
) -> Any:
    """Store one database and one RUNNING query, and return the query."""
    from superset.models.core import Database
    from superset.models.sql_lab import Query

    # Core inserts avoid unrelated permission-creation ORM event handlers.
    session.execute(
        Database.__table__.insert().values(
            id=1, database_name="stop-check", sqlalchemy_uri=sqlalchemy_uri
        )
    )
    query = Query(
        id=QUERY_ID,
        client_id=CLIENT_ID,
        user_id=USER_ID,
        database_id=1,
        status=QueryStatus.RUNNING,
        extra_json=json.dumps(extra),
    )
    session.add(query)
    session.commit()
    return query


def _send_stop(caller: str, query: Any) -> None:
    """Stop the query through the SQL Lab endpoint path or an async handle."""
    if caller == "dao":
        QueryDAO.stop_query(CLIENT_ID)
    else:
        SQLExecutor(query.database)._create_async_handle(QUERY_ID).cancel()


# =============================================================================
# A stop of a running query with a published handle uses the live cursor.
# =============================================================================
@pytest.mark.parametrize("caller", ["dao", "async_handle"])
def test_impala_stop_uses_live_cursor(
    mocker: MockerFixture, stop_engine: Engine, caller: str
) -> None:
    """Stopping a running Impala query whose cancel handle is already published
    cancels it through the live cursor only.

    The stop goes through the SQL Lab stop path or the async handle's
    ``cancel``, then the worker's ``handle_cursor`` poll runs. The poll cancels
    and closes the operation, the coordinator gets no HTTP request, and the
    query is stored as STOPPED.
    """
    from superset.models.core import Database
    from superset.models.sql_lab import Query

    mocker.patch.object(Database, "db_engine_spec", ImpalaEngineSpec)
    mocker.patch.object(Database, "get_sqla_engine")
    mocker.patch.dict(
        current_app.config,
        {
            "IMPALA_CANCEL_QUERY_ALLOW_INTERNAL_HOSTS": True,
            "DB_POLL_INTERVAL_SECONDS": {"impala": 0},
        },
    )
    post = mocker.patch("superset.db_engine_specs.impala.requests.post")
    post.return_value.status_code = 200

    with Session(stop_engine) as stop_session:
        query = _seed_running_query(
            stop_engine,
            stop_session,
            "impala://impala.example.com:21050/default",
            {QUERY_CANCEL_KEY: CANCEL_ID, QUERY_DISPATCHED_KEY: True},
        )
        mocker.patch("superset.daos.query.db.session", stop_session)
        mocker.patch("superset.daos.query.get_user_id", return_value=USER_ID)

        _send_stop(caller, query)

        cursor = Mock()
        cursor.status.return_value = "RUNNING_STATE"
        cursor.get_log.return_value = ""
        ImpalaEngineSpec.handle_cursor(cursor, query)

    post.assert_not_called()
    cursor.cancel_operation.assert_called_once_with()
    cursor.close_operation.assert_called_once_with()
    cursor.close.assert_called_once_with()
    with Session(stop_engine) as verify_session:
        stored = verify_session.get(Query, QUERY_ID)
        assert stored is not None
        assert stored.status == QueryStatus.STOPPED


# =============================================================================
# A running query that nobody stopped is not cancelled by the poll loop.
# =============================================================================
@pytest.mark.parametrize(
    "states",
    [
        ["RUNNING_STATE", "RUNNING_STATE", "RUNNING_STATE"],
        ["PENDING_STATE", "INITIALIZED_STATE", "RUNNING_STATE", "RUNNING_STATE"],
    ],
)
def test_unstopped_query_is_not_cancelled(
    mocker: MockerFixture, stop_engine: Engine, states: list[str]
) -> None:
    """A running Impala query with no stop request is polled until the
    coordinator reports it finished.

    The operation is never cancelled or closed by the poll, and the stored
    status stays RUNNING.
    """
    from superset.models.sql_lab import Query

    mocker.patch.dict(current_app.config, {"DB_POLL_INTERVAL_SECONDS": {"impala": 0}})
    with Session(stop_engine) as worker:
        query = _seed_running_query(
            stop_engine, worker, "impala://impala.example.com:21050/default", {}
        )
        mocker.patch("superset.db.session", worker)

        polls = iter(states)
        cursor = Mock()
        cursor.status.side_effect = lambda: next(polls, "FINISHED_STATE")
        cursor.get_log.return_value = ""
        ImpalaEngineSpec.handle_cursor(cursor, query)

    cursor.cancel_operation.assert_not_called()
    cursor.close_operation.assert_not_called()
    with Session(stop_engine) as verify_session:
        stored = verify_session.get(Query, QUERY_ID)
        assert stored is not None
        assert stored.status == QueryStatus.RUNNING


# =============================================================================
# Chart cancellation of an Impala query goes through the coordinator.
# =============================================================================
@pytest.mark.parametrize(
    ("host", "cancel_id"),
    [
        ("impala.example.com", CANCEL_ID),
        ("coordinator-2.internal", "a1b2c3d4e5f60718:8f9e0d1c2b3a4958"),
    ],
)
def test_chart_cancel_reaches_coordinator(
    mocker: MockerFixture, app: Flask, host: str, cancel_id: str
) -> None:
    """Chart cancellation has no polling worker.

    Cancelling an Impala chart query sends the cancel handle to the
    coordinator's HTTP endpoint. The call reports success when the coordinator
    accepts it.
    """
    from superset.tasks.query_cancel import cancel_chart_query

    database = MagicMock()
    database.db_engine_spec = ImpalaEngineSpec
    database.url_object.host = host
    mocker.patch.dict(app.config, {"IMPALA_CANCEL_QUERY_ALLOW_INTERNAL_HOSTS": True})
    post = mocker.patch("superset.db_engine_specs.impala.requests.post")
    post.return_value.status_code = 200

    assert cancel_chart_query(database, cancel_id) is True
    post.assert_called_once()
    args, kwargs = post.call_args
    url = args[0] if args else kwargs["url"]
    assert host in url
    assert cancel_id in url


# =============================================================================
# A stop that finds the query finished keeps its terminal status.
# =============================================================================
@pytest.mark.parametrize("caller", ["dao", "async_handle"])
@pytest.mark.parametrize(
    "finished_status",
    [QueryStatus.SUCCESS, QueryStatus.FAILED, QueryStatus.TIMED_OUT],
)
def test_stop_preserves_finished_status(
    mocker: MockerFixture,
    stop_engine: Engine,
    finished_status: QueryStatus,
    caller: str,
) -> None:
    """A query that the worker finished while the stop was being prepared keeps
    its terminal status and is not cancelled in the engine.

    The worker commits the finished row from its own session while the engine
    spec prepares the stop, and the stop request's session reads it back. The
    engine's cancel is never called, and the stored row keeps the worker's
    status, results key and end time. The database is not Impala, so this
    covers the engine-neutral stop path.
    """
    from superset.models.core import Database
    from superset.models.sql_lab import Query

    mocker.patch.object(SqliteEngineSpec, "has_implicit_cancel", return_value=False)
    engine_cancel = mocker.patch.object(
        SqliteEngineSpec, "cancel_query", return_value=True
    )
    mocker.patch.object(Database, "get_sqla_engine")

    with Session(stop_engine) as stop_session:
        query = _seed_running_query(
            stop_engine,
            stop_session,
            "sqlite://",
            {QUERY_CANCEL_KEY: "finish-race-handle", QUERY_DISPATCHED_KEY: True},
        )
        mocker.patch("superset.daos.query.db.session", stop_session)
        mocker.patch("superset.daos.query.get_user_id", return_value=USER_ID)

        def finish_during_prepare(loaded_query: Any) -> None:
            with Session(stop_engine) as worker_session:
                finished = worker_session.get(Query, QUERY_ID)
                assert finished is not None
                finished.status = finished_status
                finished.results_key = "worker-results"
                finished.end_time = 1234.5
                worker_session.commit()
            stop_session.refresh(loaded_query)

        mocker.patch.object(
            SqliteEngineSpec,
            "prepare_cancel_query",
            side_effect=finish_during_prepare,
        )

        _send_stop(caller, query)

    engine_cancel.assert_not_called()
    with Session(stop_engine) as verify_session:
        stored = verify_session.get(Query, QUERY_ID)
        assert stored is not None
        assert stored.status == finished_status
        assert stored.results_key == "worker-results"
        assert stored.end_time == 1234.5


# =============================================================================
# A stop of a running query on another engine still cancels it in the engine.
# =============================================================================
@pytest.mark.parametrize("caller", ["dao", "async_handle"])
def test_running_stop_cancels_in_engine(
    mocker: MockerFixture, stop_engine: Engine, caller: str
) -> None:
    """Stopping a running query on a database with no polling worker sends the
    engine cancel with the published handle, and the query is stored as
    STOPPED.
    """
    from superset.models.core import Database
    from superset.models.sql_lab import Query

    mocker.patch.object(SqliteEngineSpec, "has_implicit_cancel", return_value=False)
    engine_cancel = mocker.patch.object(
        SqliteEngineSpec, "cancel_query", return_value=True
    )
    mocker.patch.object(Database, "get_sqla_engine")

    with Session(stop_engine) as stop_session:
        query = _seed_running_query(
            stop_engine,
            stop_session,
            "sqlite://",
            {QUERY_CANCEL_KEY: "running-handle", QUERY_DISPATCHED_KEY: True},
        )
        mocker.patch("superset.daos.query.db.session", stop_session)
        mocker.patch("superset.daos.query.get_user_id", return_value=USER_ID)

        _send_stop(caller, query)

    engine_cancel.assert_called_once()
    assert engine_cancel.call_args.args[2] == "running-handle"
    with Session(stop_engine) as verify_session:
        stored = verify_session.get(Query, QUERY_ID)
        assert stored is not None
        assert stored.status == QueryStatus.STOPPED


# =============================================================================
# A stopped impyla cursor on the Celery path ends as STOPPED.
# =============================================================================
@pytest.mark.parametrize("stop_intent", ["early", "status"])
def test_celery_stopped_not_success(
    mocker: MockerFixture,
    mock_query: Any,
    mock_database: Any,
    stop_intent: str,
) -> None:
    """A stop seen while the Celery worker polls an Impala operation finalizes
    the query as STOPPED.

    A cancelled impyla cursor clears ``cursor.description``, the same as a
    statement with no result set. The stop shows up as the early-cancel flag or
    a STOPPED status while the Celery task ``execute_sql_task`` runs. Each run
    ends STOPPED with no results stored.
    """
    impyla = pytest.importorskip("impala.hiveserver2")
    from superset.sql.execution import celery_task

    mock_query.sql = "SELECT 1"
    mock_query.database = mock_database
    mock_database.db_engine_spec = ImpalaEngineSpec
    mock_query.extra = {QUERY_CANCEL_KEY: CANCEL_ID}
    mock_query.set_extra_json_key.side_effect = lambda key, value: (
        mock_query.extra.update({key: value})
    )
    cursor = impyla.HiveServer2Cursor(MagicMock())
    operation = MagicMock(has_result_set=True)

    def execute_async(sql: str) -> None:
        cursor._last_operation = operation
        cursor._last_operation_active = True

    def stop_before_poll() -> str:
        if stop_intent == "early":
            mock_query.extra[QUERY_EARLY_CANCEL_KEY] = True
        else:
            mock_query.status = QueryStatus.STOPPED
        return "RUNNING_STATE"

    operation.get_status.side_effect = stop_before_poll
    mocker.patch.object(cursor, "execute_async", side_effect=execute_async)
    connection = mock_database.get_raw_connection.return_value.__enter__.return_value
    connection.cursor.return_value = cursor
    mocker.patch.object(ImpalaEngineSpec, "get_cancel_query_id", return_value=None)
    mocker.patch(
        "superset.sql.execution.celery_task._get_query", return_value=mock_query
    )
    mocker.patch("superset.sql.execution.celery_task.security_manager")
    mocker.patch.dict(current_app.config, {"STATS_LOGGER": MagicMock()})
    finalize = mocker.spy(celery_task, "_finalize_successful_query")
    store = mocker.patch("superset.sql.execution.celery_task._store_results_in_backend")
    mocker.patch("superset.sql.execution.celery_task.results_backend", MagicMock())
    post = mocker.patch("superset.db_engine_specs.impala.requests.post")

    payload = execute_sql_task(QUERY_ID, "SELECT 1")

    operation.cancel.assert_called_once_with()
    operation.close.assert_called_once_with()
    assert cursor.description is None
    assert payload is not None
    assert payload["status"] == QueryStatus.STOPPED
    assert mock_query.status == QueryStatus.STOPPED
    connection.commit.assert_not_called()
    finalize.assert_not_called()
    store.assert_not_called()
    post.assert_not_called()


# =============================================================================
# handle_cursor sees a STOPPED committed by another session while the worker
# holds a repeatable-read snapshot.
# =============================================================================
@pytest.fixture
def iso_session_engine(tmp_path: Path) -> Iterator[Engine]:
    # A short busy timeout turns a leaked write lock into a fast failure.
    engine = create_engine(
        f"sqlite:///{tmp_path / 'metadata.db'}", connect_args={"timeout": 1}
    )
    yield engine
    engine.dispose()


@pytest.fixture
def iso_snapshot_engine(iso_session_engine: Engine) -> Iterator[Engine]:
    """An engine whose transactions keep the snapshot of their first read until
    they end, standing in for a repeatable-read worker: WAL plus explicit BEGIN.
    """
    engine = create_engine(iso_session_engine.url, connect_args={"timeout": 1})

    @event.listens_for(engine, "connect")
    def connect(dbapi_connection: Any, _: Any) -> None:
        # Let SQLAlchemy own transaction boundaries so SELECTs run inside them.
        dbapi_connection.isolation_level = None
        dbapi_connection.execute("PRAGMA journal_mode=WAL")

    @event.listens_for(engine, "begin")
    def begin(connection: Any) -> None:
        connection.exec_driver_sql("BEGIN")

    yield engine
    engine.dispose()


@pytest.fixture
def iso_query_id(iso_session_engine: Engine) -> int:
    from superset.models.core import Database
    from superset.models.sql_lab import Query

    Query.metadata.create_all(iso_session_engine)  # pylint: disable=no-member
    database = Database(database_name="my_database", sqlalchemy_uri="sqlite://")
    query = Query(
        client_id="foo",
        database=database,
        sql="select * from bar",
        status=QueryStatus.RUNNING,
        extra_json=f'{{"{QUERY_CANCEL_KEY}": "{CANCEL_ID}"}}',
    )
    with Session(iso_session_engine) as seed:
        seed.add_all([database, query])
        seed.commit()
        return query.id


def _worker_commits(engine: Engine, query_id: int, **values: Any) -> None:
    """Commit a write from another connection, as the SQL Lab worker would."""
    from superset.models.sql_lab import Query

    with Session(engine) as worker:
        worker.execute(update(Query).where(Query.id == query_id).values(**values))
        worker.commit()


def test_handle_cursor_sees_committed_stop(
    mocker: MockerFixture,
    iso_session_engine: Engine,
    iso_snapshot_engine: Engine,
    iso_query_id: int,
) -> None:
    """A poll sees a STOPPED committed by another request after the worker's
    snapshot was taken, and cancels the live operation.

    The worker's session already holds a snapshot that shows RUNNING when the
    other request commits STOPPED. The coordinator reports the operation as
    running for several polls before it would finish on its own. The live
    operation is cancelled and closed within that window.
    """
    from superset.models.sql_lab import Query

    app = Flask(__name__)
    app.config["DB_POLL_INTERVAL_SECONDS"] = {"impala": 0}
    worker = Session(iso_snapshot_engine)
    mocker.patch("superset.db.session", worker)
    query = worker.query(Query).filter_by(id=iso_query_id).one()

    # Another request commits the stop after the worker has taken its snapshot.
    _worker_commits(iso_session_engine, iso_query_id, status=QueryStatus.STOPPED)
    worker.refresh(query)
    assert query.status == QueryStatus.RUNNING

    polls = iter(["RUNNING_STATE"] * 5)
    cursor = Mock()
    cursor.status.side_effect = lambda: next(polls, "FINISHED_STATE")
    cursor.get_log.return_value = ""
    with app.app_context():
        ImpalaEngineSpec.handle_cursor(cursor, query)

    cursor.cancel_operation.assert_called_once_with()
    cursor.close_operation.assert_called_once_with()
    worker.close()
