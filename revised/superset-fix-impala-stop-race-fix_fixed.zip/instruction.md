## Task

We're getting reports that Stop doesn't work for Impala queries in SQL Lab.
Someone starts a long query against one of our Impala databases, clicks Stop, and the query ends up failed with an Impala error instead of stopped.

There's also a rarer problem that shows up on other databases too.
Once in a while a query that already finished gets marked as stopped, because someone clicked Stop at about the same time.
It should keep the status it actually finished with, however it finished.

Please fix both, so Stop on a running Impala query leaves it stopped and a finished query keeps its real status.
