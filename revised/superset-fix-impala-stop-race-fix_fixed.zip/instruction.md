## Task

We're getting reports that Stop doesn't work for Impala queries in SQL Lab.
Someone runs a long query against one of our Impala databases, clicks Stop while it's still going, and the query fails instead of stopping.
The UI and the logs both show this error:

```
Invalid or unknown query handle
```

If the query was actively running, the run request comes back as a 500.
If it was still waiting in Impala's admission queue, the query ends up marked "failed" instead of "stopped".
In both cases the Stop request itself says it worked.
Hive and Presto queries stop fine, so this is only Impala.
Our Superset metadata database is MySQL, in case that matters.

There's a second, rarer problem, and it isn't limited to Impala.
Once in a while a query finishes on its own right as someone hits Stop, and it gets recorded as "stopped" anyway.
That happens whether it succeeded, failed or timed out.
If the query is already done by the time the stop reaches it, the stop shouldn't cancel anything and should report that there was nothing to stop.
The query keeps its real result.

Please fix it so Stop on an Impala query in SQL Lab really stops it and the query ends as "stopped".
A query that finished on its own should keep its real outcome.
Cancelling Impala chart queries works today and needs to keep working.
