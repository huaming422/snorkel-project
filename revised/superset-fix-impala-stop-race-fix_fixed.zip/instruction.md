## Task

We're getting reports that Stop doesn't work for Impala queries in SQL Lab.
Someone starts a long query against one of our Impala databases, clicks Stop, and the query ends up failed instead of stopped.
The error people see is:

```
Invalid or unknown query handle
```

There's a second, rarer problem, and it isn't limited to Impala.
Once in a while a query finishes on its own right as someone hits Stop, and it gets recorded as "stopped" anyway.
That happens whether it succeeded, failed or timed out.
If the query is already done by the time the stop reaches it, the stop shouldn't cancel anything and should report that there was nothing to stop.

Please fix it so Stop on an Impala query ends it as "stopped", and a query that finished on its own keeps its real outcome.
