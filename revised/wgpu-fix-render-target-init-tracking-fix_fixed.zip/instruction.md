## Task

We keep reading back junk from render targets after a render pass, and I've narrowed it down to a few setups.

Render into one depth slice of a fresh 3D color texture with a clear and store, then copy every mip level of the texture out to a buffer.
The slice we drew into is fine, but the other slices of that mip level come back full of garbage, and the garbage isn't the same from one run to the next.

Discard one depth slice of a 3D texture that already holds data, with either load or clear as the load op.
Afterwards every slice of that mip level reads back as zero, so the data in the slices we never touched is gone.

Attach two slices of the same 3D texture to one pass, discarding one of them and storing the other (cleared or loaded).
The discarded slice comes back still holding the color it was cleared to, and when the other slice is loaded, the rest of that mip level loses its data too.

Use a combined depth/stencil attachment where one aspect is cleared and the other is loaded, with both aspects set to discard.
The loaded aspect still reads back its old values afterwards instead of zero.

We see the same results whether the copy is in the same command encoder as the pass or comes after a later submit.

Texels nobody has written yet, and texels a pass discarded, should read back as zero.
Everything else should keep what we wrote, including the other slices of a 3D texture and the other mip levels and layers of a depth/stencil texture.
Zero-initialized readback that already works today should keep working.
Can you find out why this happens and fix it?
