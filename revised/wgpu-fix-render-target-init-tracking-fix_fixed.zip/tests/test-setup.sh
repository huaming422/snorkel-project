#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
# This repo is Rust-only and the dependency closure (crate sources + the
# prebuilt V8 download pulled by the workspace) was baked into the image at the
# base commit, so there is nothing to install here. We only pin cargo to its
# offline cache so a cache miss fails fast instead of reaching for crates.io,
# and confirm the GPU test prerequisites the image baked are in place.
cd /repo/wgpu

# Rust: offline-first against the image's warm cargo cache.
export CARGO_NET_OFFLINE=true

# The wgpu-test harness (tests/src/native.rs) reads ../.gpuconfig at startup and
# panics without it. The image baked it from the lavapipe adapter in block 7b.
if [[ ! -s /repo/wgpu/.gpuconfig ]]; then
    echo "[test-setup] .gpuconfig missing or empty, regenerating from lavapipe" >&2
    WGPU_INFO_SAVE_GPUCONFIG_REPORT=1 cargo test -p wgpu-info --locked generate_gpuconfig_report -- --nocapture
fi
echo "[test-setup] .gpuconfig present ($(wc -c < /repo/wgpu/.gpuconfig) bytes)"

# LVP_POISON_MEMORY=true is set as an image ENV; echo it so the logs record
# that uninitialized reads will surface as the poison pattern, not zeros.
echo "[test-setup] LVP_POISON_MEMORY=${LVP_POISON_MEMORY:-unset}"
