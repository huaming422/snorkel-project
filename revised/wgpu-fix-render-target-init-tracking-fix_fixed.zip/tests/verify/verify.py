"""Behavioral checks for zero-initialized readback of wgpu render targets.

Drives the project's own GPU test suite through the public ``wgpu``
device/queue/render-pass API and texture readback. It creates 3D and
depth/stencil textures, renders into or discards specific depth slices, mip
levels and array layers, copies the whole texture to a buffer, and asserts
that untouched and discarded regions read back zero while written regions keep
their data. The checks only use the public API and never name any of the
crate's internal types.

Observing the fault requires a backend that exposes real uninitialized memory.
The image builds Mesa's CPU Vulkan adapter (llvmpipe) and sets
LVP_POISON_MEMORY=true so freshly-allocated memory is filled with a non-zero
pattern; a zero-filling backend cannot reproduce the fault. The GPU suite uses a
one-test-per-process harness, so the binary is run single-threaded.

The test sources (the readback helper, the WGSL copy shader, and the GPU test
module) are shipped alongside this file and copied over the repository's
versions before the build, so the suite always runs these exact cases.
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
from pathlib import Path

import pytest

REPO = Path(f"/repo/{os.environ.get('REPO_NAME', 'wgpu')}")

# The GPU suite's one-test-per-process harness aborts if more than one test runs
# in a process, so it is driven single-threaded. A cold compile of the GPU test
# binary against the changed wgpu crates dominates the wall clock; the
# filtered suite itself runs in a couple of seconds.
CARGO_TIMEOUT_SEC = 1500

# Overlay targets inside the test crate. Keeping the readback helper and copy
# shader in sync with the GPU test module is what lets the cases observe
# per-subresource contents, so all three are copied together.
OVERLAY = {
    "zero_init.rs": "tests/tests/wgpu-gpu/zero_init.rs",
    "image.rs": "tests/src/image.rs",
    "copy_texture_to_buffer.wgsl": "tests/src/copy_texture_to_buffer.wgsl",
}

# Each behavioral case names the observable property it pins. The names are the
# GPU test functions as libtest reports them (module-qualified, lowercased).
TARGET_CASES = {
    "slice_init": "zero_init::render_pass_store_to_3d_depth_slice_inits_other_slices",
    "slice_discard": "zero_init::discarding_3d_depth_slice_preserves_other_slices",
    "multi_slice": "zero_init::discarding_3d_depth_slice_alongside_another_slice_in_same_pass",
    "ds_divergent": "zero_init::discarding_both_depth_and_stencil_with_diverging_load_ops",
}

# libtest line: "test [running] [Vulkan/llvmpipe .../0] zero_init::name ... ok"
_RESULT_RE = re.compile(r"^test\s+(.+?)\s+\.\.\.\s+(ok|FAILED|ignored)\s*$", re.MULTILINE)


def _overlay_directed_tests() -> None:
    here = Path(__file__).resolve().parent
    for src_name, repo_rel in OVERLAY.items():
        src = here / src_name
        dst = REPO / repo_rel
        if not src.is_file():
            raise AssertionError(f"missing directed-test source {src}")
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dst)


def _run_suite() -> dict[str, str]:
    """Build and run the GPU zero-init suite once; return {case_name: status}.

    A case name maps to the last-seen status for that name. Names are matched by
    the module-qualified suffix (the runtime prefixes a backend/adapter tag).
    """
    _overlay_directed_tests()

    env = dict(os.environ)
    # crates.io is not reachable at this point, and every crate the test binary
    # needs is already in the image's warm cargo cache. Build offline so a cache
    # miss fails loudly here instead of hanging on an unreachable registry.
    env["CARGO_NET_OFFLINE"] = "true"
    # The poison backend is set as an image ENV; assert it so a misconfigured
    # image fails loudly here instead of silently reading back zeros.
    if env.get("LVP_POISON_MEMORY") != "true":
        env["LVP_POISON_MEMORY"] = "true"

    # Build and run the whole zero_init module in one process. Each check below
    # reads the status of the case it names.
    cmd = [
        "cargo",
        "test",
        "--locked",
        "-p",
        "wgpu-test",
        "--test",
        "wgpu-gpu",
        "--",
        "zero_init",
        "--test-threads=1",
    ]
    try:
        proc = subprocess.run(
            cmd,
            cwd=str(REPO),
            env=env,
            capture_output=True,
            text=True,
            timeout=CARGO_TIMEOUT_SEC,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        raise AssertionError(
            f"GPU suite timed out after {CARGO_TIMEOUT_SEC}s (build + run)"
        ) from exc

    combined = (proc.stdout or "") + "\n" + (proc.stderr or "")
    results: dict[str, str] = {}
    for m in _RESULT_RE.finditer(combined):
        full_name, status = m.group(1).strip(), m.group(2)
        # Strip the runtime "[running] [backend/adapter/idx] " prefix, keeping
        # the module-qualified name the directed tests declare.
        key = full_name
        idx = full_name.find("zero_init::")
        if idx != -1:
            key = full_name[idx:]
        results[key] = status

    if not results:
        tail = combined[-3000:]
        raise AssertionError(
            f"GPU suite produced no parseable test results (exit {proc.returncode}). "
            f"Tail of output:\n{tail}"
        )
    return results


@pytest.fixture(scope="session")
def suite() -> dict[str, str]:
    return _run_suite()


def _assert_case_passed(results: dict[str, str], name: str) -> None:
    status = results.get(name)
    if status is None:
        ran = ", ".join(sorted(results)[:40])
        raise AssertionError(f"case {name!r} did not run. Cases seen: {ran}")
    assert status == "ok", f"case {name!r} reported {status}, expected ok"


def test_slice_init(suite: dict[str, str]) -> None:
    """Rendering into one depth slice of a 3D color texture, at two mip levels,
    leaves every other slice and mip level of a fresh texture reading back zero,
    with the readback in the same encoder or a later one."""
    _assert_case_passed(suite, TARGET_CASES["slice_init"])


def test_slice_discard(suite: dict[str, str]) -> None:
    """A discarded depth slice, at two mip levels, reads back zero while every
    other slice and mip level keeps its data, with the readback in the same
    encoder or a later one."""
    _assert_case_passed(suite, TARGET_CASES["slice_discard"])


def test_multi_slice(suite: dict[str, str]) -> None:
    """With two slices of one 3D texture attached to the same pass, the discarded
    slice reads back zero and every other slice keeps its data."""
    _assert_case_passed(suite, TARGET_CASES["multi_slice"])


def test_ds_divergent(suite: dict[str, str]) -> None:
    """A depth/stencil attachment that clears one aspect and loads the other, with
    both aspects discarded, reads back zero in both aspects while other mip
    levels and array layers keep their data."""
    _assert_case_passed(suite, TARGET_CASES["ds_divergent"])


def test_existing_init_unchanged(suite: dict[str, str]) -> None:
    """Every other zero-initialization case (2D textures, array layers, mip
    levels, copies, buffers) passes."""
    targets = set(TARGET_CASES.values())
    others = {name: st for name, st in suite.items() if name not in targets}
    assert others, "no other zero_init cases ran, so the suite did not execute"
    failed = sorted(name for name, st in others.items() if st == "FAILED")
    assert not failed, f"other zero_init cases failed: {failed}"
