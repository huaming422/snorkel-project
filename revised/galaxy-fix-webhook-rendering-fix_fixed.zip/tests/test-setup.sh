#!/usr/bin/env bash
# tests/test-setup.sh - Make sure the galaxy client workspace can run vitest.
# Idempotent.
#
# Dependencies are baked into the image: the client's pnpm dependency tree is
# installed at build time from its lockfile against a warm pnpm store, so in
# normal operation nothing below does any work. node_modules is only rebuilt
# from that store if an implementation change removed it.

set -euo pipefail

cd /repo/galaxy/client

# Rebuild node_modules from the local store first; fall back to a plain frozen
# install with a logged notice only if the store cannot satisfy the lockfile.
if [ ! -d node_modules/.pnpm ]; then
    pnpm install --frozen-lockfile --offline 2>&1 | tail -10 \
        || { echo "[test-setup] offline replay incomplete; retrying frozen install"; \
             pnpm install --frozen-lockfile 2>&1 | tail -10; }
fi

# Sanity: vitest is reachable from the client workspace.
( node --version && pnpm exec vitest --version ) \
    || echo "[test-setup] WARN: vitest --version failed; tests may not run"

echo "[test-setup] galaxy client vitest env ready"
