// @ts-nocheck
//
// Verifier for the tool and workflow webhook panels.
//
// Runs under the galaxy client vitest workspace (happy-dom) and only drives
// interfaces that already exist in the client and the webhook plugin folders:
//
//   1. The Webhook.vue component. It is mounted with `@/utils/webhooks`
//      replaced by a fixture list, and every script element the page receives
//      is caught at the moment it would be inserted into the document. The
//      check is that the webhook's `#<id>` element is already in the document
//      at that moment (or when the script body is run directly), so a plugin
//      script can look up its element as soon as it runs.
//   2. The plugin `script.js` files under test/functional/webhooks/{phdcomics,
//      xkcd}. Galaxy injects these verbatim and runs them in page scope. Each
//      one is run in a page that has jQuery and a `Galaxy` object but neither
//      Backbone nor underscore, with its `#<id>` element present. The script
//      must not throw, must draw the panel with the element ids its stylesheet
//      targets, must ask only same-origin URLs for data (fetch, XHR and
//      script-tag requests are all recorded), and must show the comic that
//      its `api/webhooks/<id>/data` endpoint returns.
//   3. The xkcd data endpoint. Galaxy serves `api/webhooks/xkcd/data` by
//      loading `<plugin dir>/__init__.py` from its file path and returning
//      `main(trans, webhook, params)`, or `{}` when the plugin has no such
//      file. That call is reproduced in a Python subprocess with outbound HTTP
//      answered by a fake xkcd.com, and its JSON result is what the xkcd panel
//      is served in the end-to-end check.

import { spawnSync } from "node:child_process";
import { existsSync, readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

import { getLocalVue } from "@tests/vitest/helpers";
import { mount } from "@vue/test-utils";
import flushPromises from "flush-promises";
import jQuery from "jquery";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import Webhook from "./Webhook.vue";

// ---------------------------------------------------------------------------
// Webhook.vue fixtures.
// ---------------------------------------------------------------------------
const PROBE_MARK = "webhook-mount-probe-5e21";

const mocks = vi.hoisted(() => ({
    current: null as null | Record<string, unknown>,
}));

vi.mock("@/utils/webhooks", () => ({
    loadWebhooks: vi.fn(async () => [mocks.current]),
    pickWebhook: vi.fn((list: unknown[]) => list[0]),
}));

const localVue = getLocalVue();

// A webhook model as the webhooks API returns it. The script body reports
// whether its own element exists when it is run directly; a script element
// carrying it is recorded when it is inserted (see catchScriptInsertions).
function webhookFixture(id: string) {
    return {
        id,
        type: ["tool", "workflow"],
        activate: true,
        weight: 1,
        styles: "",
        script:
            `/* ${PROBE_MARK} */\n` +
            `if (typeof globalThis.__webhookMountProbe === "function") {\n` +
            `    globalThis.__webhookMountProbe(document.getElementById(${JSON.stringify(id)}) !== null);\n` +
            `}\n`,
    };
}

// Replace the insertion methods of <head> and <body> with ones that record,
// for each script element carrying the probe, whether `#<id>` is in the
// document at insertion time. A browser runs an inline script at that point.
// The recorded script element is not inserted; other nodes are.
function catchScriptInsertions(id: string, record: (present: boolean) => void): () => void {
    const restores: Array<() => void> = [];
    const isProbe = (node: unknown) =>
        node &&
        (node as Element).tagName &&
        String((node as Element).tagName).toUpperCase() === "SCRIPT" &&
        String((node as Element).textContent || "").includes(PROBE_MARK);
    const present = () => document.getElementById(id) !== null;

    for (const parent of [document.head, document.body]) {
        for (const method of ["appendChild", "insertBefore", "append", "prepend"]) {
            const hadOwn = Object.prototype.hasOwnProperty.call(parent, method);
            const ownValue = (parent as any)[method];
            const original = (parent as any)[method];
            (parent as any)[method] = function (...args: unknown[]) {
                const nodes = method === "append" || method === "prepend" ? args : [args[0]];
                const probes = nodes.filter(isProbe);
                if (probes.length > 0) {
                    probes.forEach(() => record(present()));
                    const rest = nodes.filter((node) => !isProbe(node));
                    if (rest.length === 0) {
                        return args[0];
                    }
                    if (method === "append" || method === "prepend") {
                        return original.apply(this, rest);
                    }
                }
                return original.apply(this, args);
            };
            restores.push(() => {
                if (hadOwn) {
                    (parent as any)[method] = ownValue;
                } else {
                    delete (parent as any)[method];
                }
            });
        }
    }
    return () => restores.forEach((restore) => restore());
}

// Wait until `done()` holds, draining promise callbacks and letting timers
// and frame callbacks fire between checks. Bounded by `maxMs`.
async function settle(done: () => boolean, maxMs = 1500) {
    const start = Date.now();
    await flushPromises();
    while (!done() && Date.now() - start < maxMs) {
        await new Promise((r) => setTimeout(r, 10));
        await flushPromises();
    }
}

describe.each([{ id: "phdcomics" }, { id: "xkcd" }])("Webhook.vue with webhook $id", ({ id }) => {
    let record: ReturnType<typeof vi.fn>;
    let restoreInsertions: () => void;

    beforeEach(() => {
        record = vi.fn();
        mocks.current = webhookFixture(id);
        (globalThis as any).__webhookMountProbe = (present: boolean) => record(present);
        restoreInsertions = catchScriptInsertions(id, record);
    });

    afterEach(() => {
        restoreInsertions();
        delete (globalThis as any).__webhookMountProbe;
        document.body.innerHTML = "";
    });

    it("puts the webhook's element in the page before its script runs", async () => {
        const wrapper = mount(Webhook as object, {
            localVue,
            propsData: { type: "tool", toolId: "cat1", toolVersion: "1.0" },
            attachTo: document.body,
        });

        await settle(() => record.mock.calls.length > 0);

        expect(record, "the webhook script never reached the page").toHaveBeenCalled();
        for (const [present] of record.mock.calls) {
            expect(present, `#${id} was not in the document when the webhook script ran`).toBe(true);
        }
        if (typeof wrapper.destroy === "function") {
            wrapper.destroy();
        } else if (typeof wrapper.unmount === "function") {
            wrapper.unmount();
        }
    });
});

// ---------------------------------------------------------------------------
// Plugin script helpers.
// ---------------------------------------------------------------------------

// The plugin folders live under <repo>/test/functional/webhooks/. vitest runs
// from <repo>/client and this file sits beside Webhook.vue, so look for the
// repo root from both places.
function repoRoot(): string {
    const here = dirname(fileURLToPath(import.meta.url));
    const candidates = [resolve(process.cwd(), ".."), process.cwd(), resolve(here, "..", "..", "..", "..")];
    for (const root of candidates) {
        if (existsSync(resolve(root, "test/functional/webhooks"))) {
            return root;
        }
    }
    return resolve(process.cwd(), "..");
}

function pluginDir(name: string): string {
    return resolve(repoRoot(), "test/functional/webhooks", name);
}

function readServedScript(name: string): string {
    return readFileSync(resolve(pluginDir(name), "script.js"), "utf8");
}

// Drop line and block comments so the text check looks at code only. A
// comment that mentions an old library name is fine.
function stripComments(source: string): string {
    return source.replace(/\/\*[\s\S]*?\*\//g, " ").replace(/(^|[^:])\/\/[^\n]*/g, "$1 ");
}

// Calls into the libraries the page no longer exposes.
const REMOVED_GLOBAL_PATTERNS = [/Backbone\./, /_\.(template|each|map|extend|isEmpty)\(/];

// Globals the page does not have while a plugin script runs.
const WITHHELD_GLOBALS = ["Backbone", "_"];

// Globals the page does have: jQuery, and a Galaxy object with a root path.
function installPageGlobals(): () => void {
    const values: Record<string, unknown> = { $: jQuery, jQuery, Galaxy: { root: "/" } };
    const saved: Record<string, unknown> = {};
    const had: Record<string, boolean> = {};
    for (const key of Object.keys(values)) {
        had[key] = key in (globalThis as any);
        saved[key] = (globalThis as any)[key];
        (globalThis as any)[key] = values[key];
    }
    return () => {
        for (const key of Object.keys(values)) {
            if (had[key]) {
                (globalThis as any)[key] = saved[key];
            } else {
                try {
                    delete (globalThis as any)[key];
                } catch {
                    (globalThis as any)[key] = undefined;
                }
            }
        }
    };
}

function runServedScriptInPageScope(scriptText: string): { threw: boolean; error: unknown } {
    const saved: Record<string, unknown> = {};
    const had: Record<string, boolean> = {};
    for (const key of WITHHELD_GLOBALS) {
        had[key] = key in (globalThis as any);
        saved[key] = (globalThis as any)[key];
        try {
            delete (globalThis as any)[key];
        } catch {
            (globalThis as any)[key] = undefined;
        }
    }
    try {
        // Same wrapping Galaxy uses when it injects a webhook script: the body
        // inside an IIFE, evaluated in global scope.
        // eslint-disable-next-line no-new-func
        const run = new Function(`(function(){\n${scriptText}\n})();`);
        run();
        return { threw: false, error: undefined };
    } catch (error) {
        return { threw: true, error };
    } finally {
        for (const key of WITHHELD_GLOBALS) {
            if (had[key]) {
                (globalThis as any)[key] = saved[key];
            } else {
                try {
                    delete (globalThis as any)[key];
                } catch {
                    (globalThis as any)[key] = undefined;
                }
            }
        }
    }
}

// A URL is third-party when it resolves to another origin than the page's.
function isThirdPartyUrl(url: string): boolean {
    try {
        return new URL(url, document.location.href).origin !== document.location.origin;
    } catch {
        return false;
    }
}

// True when `url` is Galaxy's data endpoint for webhook `name`
// (`api/webhooks/<name>/data`, optionally followed by `/<params>`).
function isDataEndpoint(url: string, name: string): boolean {
    try {
        const path = new URL(url, document.location.href).pathname;
        return new RegExp(`(^|/)api/webhooks/${name}/data(/|$)`).test(path);
    } catch {
        return false;
    }
}

// ---------------------------------------------------------------------------
// The xkcd data endpoint, reproduced in Python.
// ---------------------------------------------------------------------------
const HELPER_RESULT_MARK = "@@WEBHOOK_HELPER_RESULT@@";

// argv: helper path, plugin dir, repo root. Loads the helper the way Galaxy's
// webhook data controller does and prints the JSON-encoded result. Requests
// to xkcd.com through urllib or requests are answered with comic JSON whose
// image URLs carry a fixed marker; every other connection fails.
const HELPER_DRIVER = String.raw`
import importlib.util, io, json, os, random, socket, sys, traceback, types
import urllib.error, urllib.parse, urllib.request
from email.message import Message

helper_path, plugin_dir, repo_root = sys.argv[1], sys.argv[2], sys.argv[3]
MARK = "@@WEBHOOK_HELPER_RESULT@@"
TOKEN = "vrf5e21"
LATEST = 2917
requested = []
served = []


def blocked(*args, **kwargs):
    raise OSError("outbound connections are not available")


socket.create_connection = blocked
socket.socket.connect = blocked
socket.socket.connect_ex = blocked


def comic_body(url):
    parts = urllib.parse.urlsplit(url)
    host = (parts.hostname or "").lower()
    if host != "xkcd.com" and not host.endswith(".xkcd.com"):
        return None
    numbers = [s for s in parts.path.split("/") if s.isdigit()]
    num = int(numbers[-1]) if numbers else LATEST
    if num < 1 or num > LATEST:
        num = LATEST
    img = "https://imgs.xkcd.com/comics/%s_%d.png" % (TOKEN, num)
    served.append(img)
    body = {
        "month": "1", "num": num, "link": "", "year": "2024", "news": "",
        "safe_title": "Comic %d" % num, "transcript": "",
        "alt": "alt text %s %d" % (TOKEN, num), "img": img,
        "title": "Comic %s %d" % (TOKEN, num), "day": "1",
    }
    return json.dumps(body).encode("utf-8")


class FakeResponse(io.BytesIO):
    def __init__(self, url, data):
        super().__init__(data)
        self.url = url
        self.status = 200
        self.code = 200
        self.reason = "OK"
        self.headers = Message()
        self.headers["Content-Type"] = "application/json"
        self.msg = self.headers

    def getcode(self):
        return 200

    def geturl(self):
        return self.url

    def info(self):
        return self.headers

    def getheader(self, name, default=None):
        return self.headers.get(name, default)


def fake_urlopen(target, *args, **kwargs):
    url = target.full_url if hasattr(target, "full_url") else str(target)
    requested.append(url)
    data = comic_body(url)
    if data is None:
        raise urllib.error.URLError("only xkcd.com answers here")
    return FakeResponse(url, data)


urllib.request.urlopen = fake_urlopen
urllib.request.OpenerDirector.open = lambda self, target, *args, **kwargs: fake_urlopen(target)

try:
    import requests

    def fake_request(self, method, url, *args, **kwargs):
        params = kwargs.get("params")
        url = requests.Request(method, str(url), params=params).prepare().url
        requested.append(url)
        data = comic_body(url)
        if data is None:
            raise requests.exceptions.ConnectionError("only xkcd.com answers here")
        response = requests.models.Response()
        response.status_code = 200
        response.reason = "OK"
        response._content = data
        response.url = url
        response.encoding = "utf-8"
        response.headers["Content-Type"] = "application/json"
        response.request = requests.Request(method, url).prepare()
        return response

    requests.sessions.Session.request = fake_request
except ImportError:
    pass

sys.path.append(os.path.join(repo_root, "lib"))

out = {"requested": requested, "served": served}
try:
    config = {"id": "xkcd", "type": ["tool", "workflow"], "activate": True}
    try:
        import yaml
        with open(os.path.join(plugin_dir, "config.yml")) as fh:
            config = yaml.safe_load(fh) or config
    except Exception:
        pass
    webhook = types.SimpleNamespace(
        id=config.get("id", "xkcd"), type=config.get("type"), activate=config.get("activate", False),
        weight=config.get("weight", 1), path=plugin_dir, styles="", script="", helper=helper_path, config=config,
    )
    trans = types.SimpleNamespace(app=None, user=None, request=None, response=None)
    spec = importlib.util.spec_from_file_location(plugin_dir, helper_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    random.seed(20261102)
    result = module.main(trans, webhook, {})
    out["result"] = json.loads(json.dumps(result))
except Exception:
    out["error"] = traceback.format_exc()
print(MARK + json.dumps(out))
`;

type HelperRun = { result?: unknown; requested?: string[]; served?: string[]; error?: string; missing?: boolean };

let helperRunCache: HelperRun | null = null;

function findPython(): string | null {
    for (const candidate of ["python3", "/opt/tooling/venv/bin/python", "python"]) {
        const probe = spawnSync(candidate, ["-c", "import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)"], {
            encoding: "utf8",
        });
        if (probe.status === 0) {
            return candidate;
        }
    }
    return null;
}

// What Galaxy's `api/webhooks/xkcd/data` endpoint would answer.
function runXkcdDataEndpoint(): HelperRun {
    if (helperRunCache) {
        return helperRunCache;
    }
    const dir = pluginDir("xkcd");
    const helperPath = resolve(dir, "__init__.py");
    if (!existsSync(helperPath)) {
        helperRunCache = { missing: true, result: {}, requested: [], served: [] };
        return helperRunCache;
    }
    const python = findPython();
    if (!python) {
        helperRunCache = { error: "no Python interpreter was found to run the xkcd data endpoint" };
        return helperRunCache;
    }
    const run = spawnSync(python, ["-I", "-c", HELPER_DRIVER, helperPath, dir, repoRoot()], {
        encoding: "utf8",
        timeout: 60000,
    });
    const line = (run.stdout || "").split("\n").find((l) => l.startsWith(HELPER_RESULT_MARK));
    helperRunCache = line
        ? JSON.parse(line.slice(HELPER_RESULT_MARK.length))
        : { error: `the xkcd data endpoint produced no result (exit ${run.status}): ${run.stderr || run.error}` };
    return helperRunCache;
}

// ---------------------------------------------------------------------------
// Plugin script tests.
// ---------------------------------------------------------------------------
const SERVED_PLUGINS = [{ name: "phdcomics" }, { name: "xkcd" }];

// Element ids each plugin's styles.css targets inside the panel.
const STYLED_IDS = ["header", "name", "img"];

describe("webhook plugin scripts", () => {
    // Answers both plugins' success branches, for the checks that do not
    // depend on which endpoint is asked.
    const anyComicPayload = {
        success: true,
        error: "",
        src: "/static/comic-any.png",
        comic: { img: "/static/comic-any.png", alt: "alt text", title: "comic title" },
    };

    // Every URL a script asks for data, by fetch, XHR or a script element.
    let requestedUrls: string[] = [];
    let createdScripts: Element[] = [];
    let respond: (url: string) => { status: number; body: unknown };

    let savedFetch: unknown;
    let hadFetch: boolean;
    let RealXHR: unknown;
    let hadOwnCreateElement: boolean;
    let ownCreateElement: unknown;
    let restorePageGlobals: () => void;
    let errorSpy: ReturnType<typeof vi.spyOn>;
    let warnSpy: ReturnType<typeof vi.spyOn>;

    function allRequestedUrls(): string[] {
        const scriptUrls = createdScripts
            .map((el) => (el as HTMLScriptElement).getAttribute("src") || (el as HTMLScriptElement).src || "")
            .filter((src) => src !== "");
        return [...requestedUrls, ...scriptUrls];
    }

    beforeEach(() => {
        requestedUrls = [];
        createdScripts = [];
        respond = () => ({ status: 200, body: anyComicPayload });

        hadFetch = "fetch" in (globalThis as any);
        savedFetch = (globalThis as any).fetch;
        (globalThis as any).fetch = vi.fn().mockImplementation((input: unknown) => {
            const url = typeof input === "string" ? input : (input as any)?.url ?? String(input);
            requestedUrls.push(url);
            const answer = respond(url);
            return Promise.resolve({
                ok: answer.status >= 200 && answer.status < 300,
                status: answer.status,
                json: () => Promise.resolve(answer.body),
                text: () => Promise.resolve(JSON.stringify(answer.body)),
            });
        });

        // jQuery's ajax goes through XMLHttpRequest.
        RealXHR = (globalThis as any).XMLHttpRequest;
        class MockXHR {
            constructor() {
                this.readyState = 0;
                this.status = 0;
                this.statusText = "";
                this.responseText = "";
                this.response = "";
                this._listeners = {};
                this.onreadystatechange = null;
                this.onload = null;
            }
            open(method: string, url: string) {
                this._url = String(url);
                requestedUrls.push(this._url);
                this.readyState = 1;
            }
            setRequestHeader() {}
            overrideMimeType() {}
            getAllResponseHeaders() {
                return "content-type: application/json\r\n";
            }
            getResponseHeader() {
                return "application/json";
            }
            abort() {}
            addEventListener(type: string, cb: (ev: Event) => void) {
                (this._listeners[type] = this._listeners[type] || []).push(cb);
            }
            removeEventListener() {}
            send() {
                setTimeout(() => {
                    const answer = respond(this._url);
                    const text = JSON.stringify(answer.body);
                    this.readyState = 4;
                    this.status = answer.status;
                    this.statusText = answer.status === 200 ? "OK" : "Not Found";
                    this.responseText = text;
                    this.response = text;
                    if (typeof this.onreadystatechange === "function") {
                        this.onreadystatechange();
                    }
                    (this._listeners["readystatechange"] || []).forEach((cb) => cb.call(this, new Event("readystatechange")));
                    (this._listeners["load"] || []).forEach((cb) => cb.call(this, new Event("load")));
                    if (typeof this.onload === "function") {
                        this.onload();
                    }
                }, 0);
            }
        }
        (globalThis as any).XMLHttpRequest = MockXHR;

        // Script elements are how JSONP and similar loaders ask for data.
        hadOwnCreateElement = Object.prototype.hasOwnProperty.call(document, "createElement");
        ownCreateElement = (document as any).createElement;
        const realCreateElement = (document as any).createElement;
        (document as any).createElement = function (tagName: string, options?: unknown) {
            const el = realCreateElement.call(document, tagName, options);
            if (String(tagName).toLowerCase() === "script") {
                createdScripts.push(el);
            }
            return el;
        };

        restorePageGlobals = installPageGlobals();

        // A script's own logging (a failed image or script load) is not what
        // these checks look at; a thrown error is caught and asserted directly.
        errorSpy = vi.spyOn(console, "error").mockImplementation(() => {});
        warnSpy = vi.spyOn(console, "warn").mockImplementation(() => {});
        document.body.innerHTML = "";
    });

    afterEach(() => {
        errorSpy.mockRestore();
        warnSpy.mockRestore();
        restorePageGlobals();
        if (hadOwnCreateElement) {
            (document as any).createElement = ownCreateElement;
        } else {
            delete (document as any).createElement;
        }
        if (hadFetch) {
            (globalThis as any).fetch = savedFetch;
        } else {
            delete (globalThis as any).fetch;
        }
        (globalThis as any).XMLHttpRequest = RealXHR;
        document.body.innerHTML = "";
    });

    function mountPointFor(name: string): HTMLElement {
        const mountPoint = document.createElement("div");
        mountPoint.id = name;
        document.body.appendChild(mountPoint);
        return mountPoint;
    }

    describe.each(SERVED_PLUGINS)("$name", ({ name }) => {
        it("does not call the libraries the page no longer exposes", () => {
            const code = stripComments(readServedScript(name));
            for (const pattern of REMOVED_GLOBAL_PATTERNS) {
                expect(pattern.test(code), `${name} script still calls a removed global matching ${pattern}`).toBe(false);
            }
        });

        it("draws its panel and asks only its own origin for data", async () => {
            const mountPoint = mountPointFor(name);

            const { threw, error } = runServedScriptInPageScope(readServedScript(name));
            expect(threw, `script threw: ${error}`).toBe(false);

            await settle(() => false, 50);

            for (const suffix of STYLED_IDS) {
                expect(
                    mountPoint.querySelector(`#${name}-${suffix}`),
                    `${name} panel has no #${name}-${suffix} element`,
                ).not.toBeNull();
            }

            const urls = allRequestedUrls();
            expect(urls.length, `${name} script asked for no comic data`).toBeGreaterThan(0);
            for (const url of urls) {
                expect(
                    isThirdPartyUrl(url),
                    `${name} script asked a third-party origin for data directly (${url})`,
                ).toBe(false);
            }
        });
    });

    it("phdcomics shows the comic its data endpoint returns", async () => {
        const comicSrc = "https://www.phdcomics.com/comics/archive/phd_vrf5e21_8813.gif";
        respond = (url) =>
            isDataEndpoint(url, "phdcomics")
                ? { status: 200, body: { success: true, error: "", src: comicSrc } }
                : { status: 404, body: {} };

        const mountPoint = mountPointFor("phdcomics");
        const { threw, error } = runServedScriptInPageScope(readServedScript("phdcomics"));
        expect(threw, `script threw: ${error}`).toBe(false);

        await settle(() => mountPoint.innerHTML.includes(comicSrc));
        expect(
            mountPoint.innerHTML.includes(comicSrc),
            "the phdcomics panel never showed the comic from api/webhooks/phdcomics/data",
        ).toBe(true);
    });

    it("the xkcd data endpoint returns a comic fetched from xkcd", () => {
        const run = runXkcdDataEndpoint();
        expect(run.missing, "Galaxy has no data endpoint helper for the xkcd webhook").not.toBe(true);
        expect(run.error, `the xkcd data endpoint failed: ${run.error}`).toBeUndefined();
        const served = run.served || [];
        expect(served.length, "the xkcd data endpoint never asked xkcd.com for a comic").toBeGreaterThan(0);
        const payload = JSON.stringify(run.result ?? null);
        expect(
            served.some((img) => payload.includes(img)),
            `the xkcd data endpoint result carries no comic image from xkcd.com: ${payload}`,
        ).toBe(true);
    });

    it("xkcd shows the comic its data endpoint returns", async () => {
        const run = runXkcdDataEndpoint();
        expect(run.error, `the xkcd data endpoint failed: ${run.error}`).toBeUndefined();
        const served = run.served || [];
        respond = (url) => (isDataEndpoint(url, "xkcd") ? { status: 200, body: run.result ?? {} } : { status: 404, body: {} });

        const mountPoint = mountPointFor("xkcd");
        const { threw, error } = runServedScriptInPageScope(readServedScript("xkcd"));
        expect(threw, `script threw: ${error}`).toBe(false);

        const shown = () => served.some((img) => mountPoint.innerHTML.includes(img));
        await settle(shown);
        expect(served.length > 0 && shown(), "the xkcd panel never showed the comic from api/webhooks/xkcd/data").toBe(
            true,
        );
    });
});
