## Task

The webhook panels on the tool and workflow pages have gone blank.
After you run a tool or open a workflow, the webhook container is on the page, but nothing gets drawn inside it: no header, no comic, nothing.
There's no error on the page, so apart from the empty space everything looks normal.

Not every webhook is affected.
The GTN webhook in the masthead still works, so the webhook system isn't down as a whole.
The phdcomics and xkcd panels are the ones that went blank.
It started after a client cleanup that changed which third-party libraries the page exposes as globals.
That cleanup is staying.
Please don't bring the dropped libraries back, either as page globals or as a stand-in handed to the plugin scripts, since we don't want to maintain a lookalike of them either.
The plugins need to work with what the page still provides.
The cleanup never touched the plugin files, but it's fine to change them now.

I also tried a tiny test plugin whose script just writes some text into its own `#<webhook id>` element.
It finds nothing, because that element isn't on the page yet when the script runs.
A plugin script should be able to look up its element right away, without polling or waiting for it.

xkcd has a second problem.
Even before the cleanup, the xkcd panel never showed a comic on our HTTPS server.
The browser console showed this:

```
Mixed Content: The page at 'https://galaxy.example.org/' was loaded over HTTPS, but requested an insecure script 'http://dynamic.xkcd.com/api-0/jsonp/comic?callback=...'. This request has been blocked; the content must be served over HTTPS.
```

Switching that call to https from the page doesn't help either, because xkcd's JSON API doesn't send CORS headers.
So the browser shouldn't talk to xkcd at all.
The panel should get its comic from Galaxy at `api/webhooks/xkcd/data`, the same way phdcomics gets its comic from `api/webhooks/phdcomics/data`.

The goal is to have both panels show their header and their comic again.
Keep the element ids the plugins' stylesheets already target (the panel, its header, its name and its image area), so the existing styles still apply.
