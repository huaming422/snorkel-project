#!/usr/bin/env bash
#
# test-setup.sh - sourced by the verifier harness BEFORE `go test` runs.
#
# The image bakes the full Go module cache and a warm build cache at the
# base commit (Dockerfile blocks 8 + 10), so the verifier needs no network
# fetch. This script only (re)asserts the environment shape a freshly
# spawned harness shell needs, and flips Go into fail-fast offline mode so a
# cache miss surfaces immediately instead of hanging on a dead network.
#
# Sourced (not exec'd): the exports must stick for the test runner.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/App-Store-Connect-CLI}"
cd "$REPO_DIR"

# Make `go` reachable even if the harness scrubbed PATH.
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:/root/go/bin:$PATH ;;
esac

# The cmdtest suite's TestMain sets ASC_BYPASS_KEYCHAIN=1 itself, but export
# it here too so a direct `go test` of any package behaves the same.
export ASC_BYPASS_KEYCHAIN=1
export GOTOOLCHAIN=local

# Everything the verifier compiles is already in the module cache. Fail fast
# on a miss rather than reaching for a network that may not be there
# (scoped to this task's go invocations only).
export GOFLAGS=-mod=mod
export GOPROXY=off

echo "test-setup.sh: ready (ASC_BYPASS_KEYCHAIN=1, GOPROXY=off, module cache baked)"
