package cmdtest

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/rudrankriyam/App-Store-Connect-CLI/internal/asc"
	"github.com/rudrankriyam/App-Store-Connect-CLI/internal/cli/validate"
	"github.com/rudrankriyam/App-Store-Connect-CLI/internal/validation"
)

// basePriceScenario parameterizes the price-schedule side of the readiness run.
// Everything else is served from the healthy validValidateFixture() data so the
// only variable under test is how the app's base-territory price reads back.
type basePriceScenario struct {
	// priceSchedule is the body for GET /v1/apps/app-1/appPriceSchedule.
	// Empty means a healthy schedule whose id is "sched-1".
	priceSchedule string
	// baseTerritory is the body for GET /v1/appPriceSchedules/{id}/baseTerritory.
	// Empty means the USA base territory.
	baseTerritory string
	// baseTerritoryStatus overrides the base-territory HTTP status (0 = 200).
	baseTerritoryStatus int
	// manualPrices is the body for GET /v1/appPriceSchedules/{id}/manualPrices.
	// Empty means one paid USA price that started in 2020 and never ends.
	manualPrices string
	// manualPricesStatus overrides the manual-prices HTTP status (0 = 200).
	manualPricesStatus int
}

const healthyPriceScheduleBody = `{"data":{"type":"appPriceSchedules","id":"sched-1","attributes":{}}}`

func territoryBody(id, currency string) string {
	return fmt.Sprintf(`{"data":{"type":"territories","id":%q,"attributes":{"currency":%q}}}`, id, currency)
}

func ascErrorBody(status int, code, detail string) string {
	return fmt.Sprintf(`{"errors":[{"status":"%d","code":%q,"title":%q,"detail":%q}]}`, status, code, http.StatusText(status), detail)
}

// appPriceRow is one manual price. An empty end date means the price never
// ends. Each row points at its own price point, which the page includes with
// the given customer price.
type appPriceRow struct {
	id            string
	territory     string
	startDate     string
	endDate       string
	customerPrice string
}

// manualPricesPage builds a single manual-prices page with the rows and their
// included price points.
func manualPricesPage(rows ...appPriceRow) string {
	data := make([]string, 0, len(rows))
	included := make([]string, 0, len(rows))
	for _, row := range rows {
		attrs := fmt.Sprintf(`"manual":true,"startDate":%q`, row.startDate)
		if row.endDate != "" {
			attrs += fmt.Sprintf(`,"endDate":%q`, row.endDate)
		}
		pricePointID := "pp-" + row.id
		data = append(data, fmt.Sprintf(`{"type":"appPrices","id":%q,"attributes":{%s},"relationships":{"territory":{"data":{"type":"territories","id":%q}},"appPricePoint":{"data":{"type":"appPricePoints","id":%q}}}}`, row.id, attrs, row.territory, pricePointID))
		included = append(included, fmt.Sprintf(`{"type":"appPricePoints","id":%q,"attributes":{"customerPrice":%q,"proceeds":%q}}`, pricePointID, row.customerPrice, row.customerPrice))
	}
	return fmt.Sprintf(`{"data":[%s],"included":[%s],"links":{"next":""}}`, strings.Join(data, ","), strings.Join(included, ","))
}

func dateFromToday(days int) string {
	return time.Now().UTC().AddDate(0, 0, days).Format("2006-01-02")
}

// newBasePriceTestClient serves the healthy readiness data and overlays the
// scenario's price-schedule, base-territory, and price-list responses for the
// app's price schedule.
func newBasePriceTestClient(t *testing.T, scenario basePriceScenario) *asc.Client {
	t.Helper()

	tmpDir := t.TempDir()
	keyPath := filepath.Join(tmpDir, "key.p8")
	writeECDSAPEM(t, keyPath)

	f := validValidateFixture()

	priceSchedule := scenario.priceSchedule
	if priceSchedule == "" {
		priceSchedule = healthyPriceScheduleBody
	}
	baseTerritory := scenario.baseTerritory
	if baseTerritory == "" {
		baseTerritory = territoryBody("USA", "USD")
	}
	manualPrices := scenario.manualPrices
	if manualPrices == "" {
		manualPrices = manualPricesPage(appPriceRow{id: "price-usa", territory: "USA", startDate: "2020-01-01", customerPrice: "4.99"})
	}

	transport := roundTripFunc(func(req *http.Request) (*http.Response, error) {
		if req.Method != http.MethodGet {
			return jsonResponse(http.StatusMethodNotAllowed, `{"errors":[{"status":405}]}`)
		}

		path := req.URL.Path
		switch {
		case path == "/v1/apps/app-1":
			return jsonResponse(http.StatusOK, f.app)
		case path == "/v1/apps/app-1/appStoreVersions":
			return jsonResponse(http.StatusOK, f.versions)
		case path == "/v1/appStoreVersions/ver-1":
			return jsonResponse(http.StatusOK, f.version)
		case path == "/v1/apps/app-1/appInfos":
			return jsonResponse(http.StatusOK, f.appInfos)
		case path == "/v1/appInfos/info-1/appInfoLocalizations":
			return jsonResponse(http.StatusOK, f.appInfoLocs)
		case path == "/v1/appInfos/info-1/relationships/primaryCategory":
			return jsonResponse(http.StatusOK, f.primaryCategory)
		case path == "/v1/appStoreVersions/ver-1/appStoreVersionLocalizations":
			return jsonResponse(http.StatusOK, f.versionLocs)
		case path == "/v1/appInfos/info-1/ageRatingDeclaration":
			return jsonResponse(http.StatusOK, f.ageRating)
		case path == "/v1/appStoreVersions/ver-1/appStoreReviewDetail":
			return jsonResponse(http.StatusOK, f.reviewDetails)
		case path == "/v1/appStoreVersions/ver-1/build":
			return jsonResponse(http.StatusOK, f.build)

		case path == "/v1/apps/app-1/appPriceSchedule":
			return jsonResponse(http.StatusOK, priceSchedule)
		case strings.HasPrefix(path, "/v1/appPriceSchedules/") && strings.HasSuffix(path, "/baseTerritory"):
			if scenario.baseTerritoryStatus != 0 {
				return jsonResponse(scenario.baseTerritoryStatus, baseTerritory)
			}
			return jsonResponse(http.StatusOK, baseTerritory)
		case strings.HasPrefix(path, "/v1/appPriceSchedules/") && strings.HasSuffix(path, "/manualPrices"):
			if scenario.manualPricesStatus != 0 {
				return jsonResponse(scenario.manualPricesStatus, manualPrices)
			}
			return jsonResponse(http.StatusOK, manualPrices)
		case strings.HasPrefix(path, "/v1/appPriceSchedules/") && strings.HasSuffix(path, "/automaticPrices"):
			return jsonResponse(http.StatusOK, `{"data":[],"links":{"next":""}}`)

		case path == "/v1/apps/app-1/appAvailabilityV2":
			return jsonResponse(http.StatusOK, f.availabilityV2)
		case path == "/v1/territories":
			return jsonResponse(http.StatusOK, f.pricingTerritories)
		case strings.HasPrefix(path, "/v2/appAvailabilities/") && strings.HasSuffix(path, "/territoryAvailabilities"):
			return jsonResponse(http.StatusOK, f.territories)
		case strings.HasPrefix(path, "/v1/appStoreVersionLocalizations/") && strings.HasSuffix(path, "/appScreenshotSets"):
			localizationID := strings.TrimSuffix(strings.TrimPrefix(path, "/v1/appStoreVersionLocalizations/"), "/appScreenshotSets")
			if body, ok := f.screenshotSets[localizationID]; ok {
				return jsonResponse(http.StatusOK, body)
			}
			return jsonResponse(http.StatusOK, `{"data":[]}`)
		case strings.HasPrefix(path, "/v1/appScreenshotSets/") && strings.HasSuffix(path, "/appScreenshots"):
			setID := strings.TrimSuffix(strings.TrimPrefix(path, "/v1/appScreenshotSets/"), "/appScreenshots")
			if body, ok := f.screenshotsBySet[setID]; ok {
				return jsonResponse(http.StatusOK, body)
			}
			return jsonResponse(http.StatusOK, `{"data":[]}`)
		case path == "/v1/apps/app-1/subscriptionGroups":
			return jsonResponse(http.StatusOK, f.subscriptionGroups)
		case strings.HasPrefix(path, "/v1/subscriptionGroups/") && strings.HasSuffix(path, "/subscriptionGroupLocalizations"):
			return jsonResponse(http.StatusOK, `{"data":[]}`)
		case strings.HasPrefix(path, "/v1/subscriptionGroups/") && strings.HasSuffix(path, "/subscriptions"):
			groupID := strings.TrimSuffix(strings.TrimPrefix(path, "/v1/subscriptionGroups/"), "/subscriptions")
			if body, ok := f.subscriptionsByGroup[groupID]; ok {
				return jsonResponse(http.StatusOK, body)
			}
			return jsonResponse(http.StatusOK, `{"data":[]}`)
		case strings.HasPrefix(path, "/v1/subscriptions/") && strings.HasSuffix(path, "/subscriptionLocalizations"):
			return jsonResponse(http.StatusOK, `{"data":[]}`)
		case strings.HasPrefix(path, "/v1/subscriptions/") && strings.HasSuffix(path, "/prices"):
			return jsonResponse(http.StatusOK, `{"data":[]}`)
		case strings.HasPrefix(path, "/v1/subscriptions/") && strings.HasSuffix(path, "/images"):
			subscriptionID := strings.TrimSuffix(strings.TrimPrefix(path, "/v1/subscriptions/"), "/images")
			if body, ok := f.imagesBySubscription[subscriptionID]; ok {
				return jsonResponse(http.StatusOK, body)
			}
			return jsonResponse(http.StatusOK, `{"data":[]}`)
		case path == "/v1/apps/app-1/inAppPurchasesV2":
			return jsonResponse(http.StatusOK, `{"data":[]}`)
		}

		return jsonResponse(http.StatusNotFound, `{"errors":[{"status":404}]}`)
	})

	client, err := asc.NewClientWithHTTPClient("KEY123", "ISS456", keyPath, &http.Client{Transport: transport})
	if err != nil {
		t.Fatalf("failed to create client: %v", err)
	}
	return client
}

// runReadiness drives the real validate command against the scenario and returns
// the parsed JSON report plus the run error (non-nil and a ReportedError when the
// report has blocking issues).
func runReadiness(t *testing.T, scenario basePriceScenario) (validation.Report, error) {
	t.Helper()

	client := newBasePriceTestClient(t, scenario)
	restore := validate.SetClientFactory(func() (*asc.Client, error) {
		return client, nil
	})
	defer restore()

	root := RootCommand("1.2.3")

	var runErr error
	stdout, _ := captureOutput(t, func() {
		if err := root.Parse([]string{"validate", "--app", "app-1", "--version-id", "ver-1"}); err != nil {
			t.Fatalf("parse error: %v", err)
		}
		runErr = root.Run(context.Background())
	})

	var report validation.Report
	if err := json.Unmarshal([]byte(stdout), &report); err != nil {
		t.Fatalf("failed to parse JSON report: %v\nstdout: %s\nrun error: %v", err, stdout, runErr)
	}
	return report, runErr
}

func isReportedError(err error) bool {
	if err == nil {
		return false
	}
	_, ok := errors.AsType[ReportedError](err)
	return ok
}

// isAppPricingCheck reports whether a check is about the app's own price. Any
// id, field, resource type, or message that mentions price or pricing counts,
// except subscription and in-app purchase checks, which have their own prices.
func isAppPricingCheck(check validation.CheckResult) bool {
	id := strings.ToLower(check.ID)
	if strings.HasPrefix(id, "subscriptions.") || strings.HasPrefix(id, "iap.") {
		return false
	}
	for _, text := range []string{check.ID, check.Field, check.ResourceType, check.Message} {
		if strings.Contains(strings.ToLower(text), "pric") {
			return true
		}
	}
	return false
}

func appPricingChecksAt(report validation.Report, severity validation.Severity) []string {
	ids := make([]string, 0)
	for _, check := range report.Checks {
		if check.Severity == severity && isAppPricingCheck(check) {
			ids = append(ids, check.ID)
		}
	}
	return ids
}

func assertBlockingPricingError(t *testing.T, report validation.Report, runErr error) {
	t.Helper()
	if ids := appPricingChecksAt(report, validation.SeverityError); len(ids) == 0 {
		t.Fatalf("expected a blocking pricing error, got checks %+v", report.Checks)
	}
	if !isReportedError(runErr) {
		t.Fatalf("expected the run to report a blocking error, got %v", runErr)
	}
}

// A schedule whose base territory has no price that applies today or starts
// later must give a blocking pricing error. End dates are exclusive, so a
// price ending today or earlier no longer applies, and prices for other
// territories do not count.
func TestReadinessBlocksConfiguredScheduleWithoutBasePrice(t *testing.T) {
	cases := []struct {
		name         string
		manualPrices string
	}{
		{
			name:         "empty manual price list",
			manualPrices: `{"data":[],"links":{"next":""}}`,
		},
		{
			name:         "only price ended today",
			manualPrices: manualPricesPage(appPriceRow{id: "price-today", territory: "USA", startDate: "2020-01-01", endDate: dateFromToday(0), customerPrice: "4.99"}),
		},
		{
			name:         "only price ended yesterday",
			manualPrices: manualPricesPage(appPriceRow{id: "price-yesterday", territory: "USA", startDate: "2020-01-01", endDate: dateFromToday(-1), customerPrice: "2.99"}),
		},
		{
			name:         "only another territory is priced",
			manualPrices: manualPricesPage(appPriceRow{id: "price-can", territory: "CAN", startDate: "2020-01-01", customerPrice: "6.99"}),
		},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			report, runErr := runReadiness(t, basePriceScenario{manualPrices: tc.manualPrices})
			assertBlockingPricingError(t, report, runErr)
		})
	}
}

// A base territory with a price that applies today or starts later gives a
// clean pricing result: no pricing error or warning, and the run passes.
func TestReadinessAcceptsPresentBasePrice(t *testing.T) {
	cases := []struct {
		name     string
		scenario basePriceScenario
	}{
		{
			name: "paid price active now",
			scenario: basePriceScenario{manualPrices: manualPricesPage(
				appPriceRow{id: "price-paid", territory: "USA", startDate: "2020-01-01", customerPrice: "4.99"},
			)},
		},
		{
			name: "free price active now",
			scenario: basePriceScenario{manualPrices: manualPricesPage(
				appPriceRow{id: "price-free", territory: "USA", startDate: "2020-01-01", customerPrice: "0.0"},
			)},
		},
		{
			name: "price starting today",
			scenario: basePriceScenario{manualPrices: manualPricesPage(
				appPriceRow{id: "price-today", territory: "USA", startDate: dateFromToday(0), customerPrice: "2.49"},
			)},
		},
		{
			name: "price scheduled to start later",
			scenario: basePriceScenario{manualPrices: manualPricesPage(
				appPriceRow{id: "price-later", territory: "USA", startDate: "2999-01-01", customerPrice: "1.99"},
			)},
		},
		{
			name: "price ending tomorrow",
			scenario: basePriceScenario{manualPrices: manualPricesPage(
				appPriceRow{id: "price-tomorrow", territory: "USA", startDate: "2020-01-01", endDate: dateFromToday(1), customerPrice: "3.99"},
			)},
		},
		{
			name: "earlier price ended and a newer one is active",
			scenario: basePriceScenario{manualPrices: manualPricesPage(
				appPriceRow{id: "price-old", territory: "USA", startDate: "2019-01-01", endDate: "2020-01-01", customerPrice: "0.99"},
				appPriceRow{id: "price-new", territory: "USA", startDate: "2020-01-01", customerPrice: "1.99"},
			)},
		},
		{
			name: "base territory CAN priced in CAN",
			scenario: basePriceScenario{
				baseTerritory: territoryBody("CAN", "CAD"),
				manualPrices: manualPricesPage(
					appPriceRow{id: "price-can", territory: "CAN", startDate: "2020-01-01", customerPrice: "5.99"},
				),
			},
		},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			report, runErr := runReadiness(t, tc.scenario)

			if ids := appPricingChecksAt(report, validation.SeverityError); len(ids) != 0 {
				t.Fatalf("expected no pricing error for a priced app, got %v (checks %+v)", ids, report.Checks)
			}
			if ids := appPricingChecksAt(report, validation.SeverityWarning); len(ids) != 0 {
				t.Fatalf("expected no pricing warning for a priced app, got %v (checks %+v)", ids, report.Checks)
			}
			if runErr != nil {
				t.Fatalf("expected the run to stay non-blocking, got %v", runErr)
			}
		})
	}
}

// An app App Store Connect reports as never priced (its schedule's base
// territory or price list reads back as the "no resource of type 'null'" 404)
// must give a blocking pricing error.
func TestReadinessReportsNeverConfiguredScheduleAsMissing(t *testing.T) {
	neverPriced := ascErrorBody(http.StatusNotFound, "NOT_FOUND", "There is no resource of type 'null' with id 'app-1'")
	neverPricedSchedule := `{"data":{"type":"appPriceSchedules","id":"app-1"}}`

	cases := []struct {
		name     string
		scenario basePriceScenario
	}{
		{
			name: "price list read says never priced",
			scenario: basePriceScenario{
				priceSchedule:      neverPricedSchedule,
				manualPricesStatus: http.StatusNotFound,
				manualPrices:       neverPriced,
			},
		},
		{
			name: "base territory and price list reads say never priced",
			scenario: basePriceScenario{
				priceSchedule:       neverPricedSchedule,
				baseTerritoryStatus: http.StatusNotFound,
				baseTerritory:       neverPriced,
				manualPricesStatus:  http.StatusNotFound,
				manualPrices:        neverPriced,
			},
		},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			report, runErr := runReadiness(t, tc.scenario)
			assertBlockingPricingError(t, report, runErr)
		})
	}
}

// When the base territory or price list cannot be read, or a price cannot be
// tied to a territory, readiness gives a non-blocking pricing warning, no
// pricing error, and the run passes.
func TestReadinessDegradesUnreadablePricingToWarning(t *testing.T) {
	cases := []struct {
		name     string
		scenario basePriceScenario
	}{
		{
			name: "manual prices rate limited",
			scenario: basePriceScenario{
				manualPricesStatus: http.StatusTooManyRequests,
				manualPrices:       ascErrorBody(http.StatusTooManyRequests, "RATE_LIMITED", "rate limited"),
			},
		},
		{
			name: "manual prices server error",
			scenario: basePriceScenario{
				manualPricesStatus: http.StatusServiceUnavailable,
				manualPrices:       ascErrorBody(http.StatusServiceUnavailable, "SERVICE_UNAVAILABLE", "service unavailable"),
			},
		},
		{
			name: "manual prices forbidden",
			scenario: basePriceScenario{
				manualPricesStatus: http.StatusForbidden,
				manualPrices:       ascErrorBody(http.StatusForbidden, "FORBIDDEN_ERROR", "The API key in use does not allow this request"),
			},
		},
		{
			name: "manual prices unrelated not found",
			scenario: basePriceScenario{
				manualPricesStatus: http.StatusNotFound,
				manualPrices:       ascErrorBody(http.StatusNotFound, "NOT_FOUND", "resource not found"),
			},
		},
		{
			name:     "manual price has no territory",
			scenario: basePriceScenario{manualPrices: `{"data":[{"type":"appPrices","id":"opaque","attributes":{"manual":true}}],"links":{"next":""}}`},
		},
		{
			name: "base territory rate limited",
			scenario: basePriceScenario{
				baseTerritoryStatus: http.StatusTooManyRequests,
				baseTerritory:       ascErrorBody(http.StatusTooManyRequests, "RATE_LIMITED", "rate limited"),
			},
		},
		{
			name: "base territory server error",
			scenario: basePriceScenario{
				baseTerritoryStatus: http.StatusInternalServerError,
				baseTerritory:       ascErrorBody(http.StatusInternalServerError, "INTERNAL_ERROR", "internal error"),
			},
		},
		{
			name: "base territory forbidden",
			scenario: basePriceScenario{
				baseTerritoryStatus: http.StatusForbidden,
				baseTerritory:       ascErrorBody(http.StatusForbidden, "FORBIDDEN_ERROR", "The API key in use does not allow this request"),
			},
		},
		{
			name: "base territory unrelated not found",
			scenario: basePriceScenario{
				baseTerritoryStatus: http.StatusNotFound,
				baseTerritory:       ascErrorBody(http.StatusNotFound, "NOT_FOUND", "resource not found"),
			},
		},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			report, runErr := runReadiness(t, tc.scenario)

			if ids := appPricingChecksAt(report, validation.SeverityWarning); len(ids) == 0 {
				t.Fatalf("expected a pricing warning, got %+v", report.Checks)
			}
			if ids := appPricingChecksAt(report, validation.SeverityError); len(ids) != 0 {
				t.Fatalf("expected no blocking pricing error for an unreadable price, got %v (checks %+v)", ids, report.Checks)
			}
			if runErr != nil {
				t.Fatalf("expected the run to stay non-blocking, got %v", runErr)
			}
		})
	}
}
