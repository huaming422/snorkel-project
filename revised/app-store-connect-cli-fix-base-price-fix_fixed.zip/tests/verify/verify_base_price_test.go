package cmdtest

import (
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"path/filepath"
	"strconv"
	"strings"
	"testing"
	"time"

	"github.com/rudrankriyam/App-Store-Connect-CLI/internal/asc"
	"github.com/rudrankriyam/App-Store-Connect-CLI/internal/cli/validate"
	"github.com/rudrankriyam/App-Store-Connect-CLI/internal/validation"
)

// basePriceScenario parameterizes the price-schedule side of the readiness run.
// Everything else is served from the healthy validValidateFixture() data so the
// only variable under test is how the app's base-territory price reads back.
type basePriceScenario struct {
	// priceSchedule is the body for GET /v1/apps/app-1/appPriceSchedule.
	// Empty means a healthy schedule whose id is "sched-1".
	priceSchedule string
	// baseTerritory is the body for GET /v1/appPriceSchedules/{id}/baseTerritory.
	// Empty means the USA base territory.
	baseTerritory string
	// baseTerritoryStatus overrides the base-territory HTTP status (0 = 200).
	baseTerritoryStatus int
	// baseTerritoryHangs holds the base-territory request open until the
	// request's context ends. A request that is still open after
	// unansweredRequestWait gets the normal base-territory body.
	baseTerritoryHangs bool
	// requestTimeout, when set, is exported as ASC_TIMEOUT for the run.
	requestTimeout string
	// priceList is the manual price list for
	// GET /v1/appPriceSchedules/{id}/manualPrices, served one page per entry
	// and chained through links.next. Empty means one paid USA price that
	// started in 2020 and never ends.
	priceList []pricePage
}

// unansweredRequestWait is how long a held-open request waits for its context
// to end before it answers normally.
const unansweredRequestWait = 15 * time.Second

// pricePage is one page of the manual price list. A non-zero status answers
// that page with the status and body instead of rows. A hang page holds the
// request open until its context ends, and answers with its rows only if the
// request is still open after unansweredRequestWait.
type pricePage struct {
	rows   []appPriceRow
	status int
	body   string
	hang   bool
}

func onePage(rows ...appPriceRow) []pricePage {
	return []pricePage{{rows: rows}}
}

func errorPage(status int, body string) pricePage {
	return pricePage{status: status, body: body}
}

func hangPage(rows ...appPriceRow) pricePage {
	return pricePage{rows: rows, hang: true}
}

// holdOpen waits for the request's context to end and returns its error. If
// the context is still live after unansweredRequestWait, it returns answer().
func holdOpen(req *http.Request, answer func() (*http.Response, error)) (*http.Response, error) {
	timer := time.NewTimer(unansweredRequestWait)
	defer timer.Stop()
	select {
	case <-req.Context().Done():
		return nil, req.Context().Err()
	case <-timer.C:
		return answer()
	}
}

const healthyPriceScheduleBody = `{"data":{"type":"appPriceSchedules","id":"sched-1","attributes":{}}}`

func territoryBody(id, currency string) string {
	return fmt.Sprintf(`{"data":{"type":"territories","id":%q,"attributes":{"currency":%q}}}`, id, currency)
}

func ascErrorBody(status int, code, detail string) string {
	return fmt.Sprintf(`{"errors":[{"status":"%d","code":%q,"title":%q,"detail":%q}]}`, status, code, http.StatusText(status), detail)
}

// appPriceRow is one manual price. An empty end date means the price never
// ends. Each row points at its own price point, which the page includes with
// the given customer price.
//
// idOnly rows come back the way App Store Connect often sends them: no
// territory relationship and no endDate attribute, with the territory, price
// point and dates carried only in the base64 JSON resource id. untied rows
// have neither a territory relationship nor a decodable id.
type appPriceRow struct {
	id            string
	territory     string
	startDate     string
	endDate       string
	customerPrice string
	idOnly        bool
	untied        bool
}

func scheduleDateSeconds(t *testing.T, date string) float64 {
	t.Helper()
	if date == "" {
		return 0
	}
	parsed, err := time.Parse("2006-01-02", date)
	if err != nil {
		t.Fatalf("bad fixture date %q: %v", date, err)
	}
	return float64(parsed.UTC().Unix())
}

func encodePricingID(t *testing.T, payload map[string]any) string {
	t.Helper()
	data, err := json.Marshal(payload)
	if err != nil {
		t.Fatalf("failed to encode pricing id: %v", err)
	}
	return base64.RawURLEncoding.EncodeToString(data)
}

// renderPricePage builds one manual-prices page body with the rows, their
// included price points, and next (empty on the last page).
func renderPricePage(t *testing.T, rows []appPriceRow, next string) string {
	t.Helper()
	data := make([]string, 0, len(rows))
	included := make([]string, 0, len(rows))
	for _, row := range rows {
		if row.untied {
			data = append(data, fmt.Sprintf(`{"type":"appPrices","id":%q,"attributes":{"manual":true}}`, row.id))
			continue
		}
		if row.idOnly {
			pointKey := "pp-" + row.id
			id := encodePricingID(t, map[string]any{"s": "app-1", "t": row.territory, "p": pointKey, "sd": scheduleDateSeconds(t, row.startDate), "ed": scheduleDateSeconds(t, row.endDate)})
			pointID := encodePricingID(t, map[string]any{"s": "app-1", "t": row.territory, "p": pointKey})
			attrs := `"manual":true`
			if row.startDate != "" {
				attrs += fmt.Sprintf(`,"startDate":%q`, row.startDate)
			}
			data = append(data, fmt.Sprintf(`{"type":"appPrices","id":%q,"attributes":{%s}}`, id, attrs))
			included = append(included, fmt.Sprintf(`{"type":"appPricePoints","id":%q,"attributes":{"customerPrice":%q,"proceeds":%q}}`, pointID, row.customerPrice, row.customerPrice))
			continue
		}
		attrs := fmt.Sprintf(`"manual":true,"startDate":%q`, row.startDate)
		if row.endDate != "" {
			attrs += fmt.Sprintf(`,"endDate":%q`, row.endDate)
		}
		pricePointID := "pp-" + row.id
		data = append(data, fmt.Sprintf(`{"type":"appPrices","id":%q,"attributes":{%s},"relationships":{"territory":{"data":{"type":"territories","id":%q}},"appPricePoint":{"data":{"type":"appPricePoints","id":%q}}}}`, row.id, attrs, row.territory, pricePointID))
		included = append(included, fmt.Sprintf(`{"type":"appPricePoints","id":%q,"attributes":{"customerPrice":%q,"proceeds":%q}}`, pricePointID, row.customerPrice, row.customerPrice))
	}
	return fmt.Sprintf(`{"data":[%s],"included":[%s],"links":{"next":%q}}`, strings.Join(data, ","), strings.Join(included, ","), next)
}

// servePriceList answers one manual-prices request. The first request has no
// cursor; later pages are reached through the cursor in links.next, which
// keeps the request's other query parameters. filter[territory] keeps only
// rows for the listed territories (untied rows always stay) and drops pages
// left empty, the way the list reads when App Store Connect filters it.
func servePriceList(t *testing.T, req *http.Request, pages []pricePage) (*http.Response, error) {
	query := req.URL.Query()
	visible := pages
	if filter := strings.TrimSpace(query.Get("filter[territory]")); filter != "" {
		wanted := map[string]bool{}
		for _, territory := range strings.Split(filter, ",") {
			wanted[strings.ToUpper(strings.TrimSpace(territory))] = true
		}
		visible = make([]pricePage, 0, len(pages))
		for _, page := range pages {
			if page.status != 0 || page.hang {
				visible = append(visible, page)
				continue
			}
			kept := make([]appPriceRow, 0, len(page.rows))
			for _, row := range page.rows {
				if row.untied || wanted[row.territory] {
					kept = append(kept, row)
				}
			}
			if len(kept) > 0 {
				visible = append(visible, pricePage{rows: kept})
			}
		}
		if len(visible) == 0 {
			visible = []pricePage{{}}
		}
	}

	index := 0
	if cursor := query.Get("cursor"); cursor != "" {
		parsed, err := strconv.Atoi(strings.TrimPrefix(cursor, "page-"))
		if err != nil || parsed < 1 || parsed >= len(visible) {
			return jsonResponse(http.StatusBadRequest, ascErrorBody(http.StatusBadRequest, "PARAMETER_ERROR.INVALID", "invalid cursor"))
		}
		index = parsed
	}
	page := visible[index]
	if page.status != 0 {
		return jsonResponse(page.status, page.body)
	}
	next := ""
	if index+1 < len(visible) {
		nextQuery := req.URL.Query()
		nextQuery.Set("cursor", fmt.Sprintf("page-%d", index+1))
		next = "https://api.appstoreconnect.apple.com" + req.URL.Path + "?" + nextQuery.Encode()
	}
	body := renderPricePage(t, page.rows, next)
	if page.hang {
		return holdOpen(req, func() (*http.Response, error) {
			return jsonResponse(http.StatusOK, body)
		})
	}
	return jsonResponse(http.StatusOK, body)
}

func dateFromToday(days int) string {
	return time.Now().UTC().AddDate(0, 0, days).Format("2006-01-02")
}

// newBasePriceTestClient serves the healthy readiness data and overlays the
// scenario's price-schedule, base-territory, and price-list responses for the
// app's price schedule.
func newBasePriceTestClient(t *testing.T, scenario basePriceScenario) *asc.Client {
	t.Helper()

	tmpDir := t.TempDir()
	keyPath := filepath.Join(tmpDir, "key.p8")
	writeECDSAPEM(t, keyPath)

	f := validValidateFixture()

	priceSchedule := scenario.priceSchedule
	if priceSchedule == "" {
		priceSchedule = healthyPriceScheduleBody
	}
	baseTerritory := scenario.baseTerritory
	if baseTerritory == "" {
		baseTerritory = territoryBody("USA", "USD")
	}
	priceList := scenario.priceList
	if len(priceList) == 0 {
		priceList = onePage(appPriceRow{id: "price-usa", territory: "USA", startDate: "2020-01-01", customerPrice: "4.99"})
	}

	transport := roundTripFunc(func(req *http.Request) (*http.Response, error) {
		if req.Method != http.MethodGet {
			return jsonResponse(http.StatusMethodNotAllowed, `{"errors":[{"status":405}]}`)
		}

		path := req.URL.Path
		switch {
		case path == "/v1/apps/app-1":
			return jsonResponse(http.StatusOK, f.app)
		case path == "/v1/apps/app-1/appStoreVersions":
			return jsonResponse(http.StatusOK, f.versions)
		case path == "/v1/appStoreVersions/ver-1":
			return jsonResponse(http.StatusOK, f.version)
		case path == "/v1/apps/app-1/appInfos":
			return jsonResponse(http.StatusOK, f.appInfos)
		case path == "/v1/appInfos/info-1/appInfoLocalizations":
			return jsonResponse(http.StatusOK, f.appInfoLocs)
		case path == "/v1/appInfos/info-1/relationships/primaryCategory":
			return jsonResponse(http.StatusOK, f.primaryCategory)
		case path == "/v1/appStoreVersions/ver-1/appStoreVersionLocalizations":
			return jsonResponse(http.StatusOK, f.versionLocs)
		case path == "/v1/appInfos/info-1/ageRatingDeclaration":
			return jsonResponse(http.StatusOK, f.ageRating)
		case path == "/v1/appStoreVersions/ver-1/appStoreReviewDetail":
			return jsonResponse(http.StatusOK, f.reviewDetails)
		case path == "/v1/appStoreVersions/ver-1/build":
			return jsonResponse(http.StatusOK, f.build)

		case path == "/v1/apps/app-1/appPriceSchedule":
			return jsonResponse(http.StatusOK, priceSchedule)
		case strings.HasPrefix(path, "/v1/appPriceSchedules/") && strings.HasSuffix(path, "/baseTerritory"):
			if scenario.baseTerritoryHangs {
				return holdOpen(req, func() (*http.Response, error) {
					return jsonResponse(http.StatusOK, baseTerritory)
				})
			}
			if scenario.baseTerritoryStatus != 0 {
				return jsonResponse(scenario.baseTerritoryStatus, baseTerritory)
			}
			return jsonResponse(http.StatusOK, baseTerritory)
		case strings.HasPrefix(path, "/v1/appPriceSchedules/") && strings.HasSuffix(path, "/manualPrices"):
			return servePriceList(t, req, priceList)
		case strings.HasPrefix(path, "/v1/appPriceSchedules/") && strings.HasSuffix(path, "/automaticPrices"):
			return jsonResponse(http.StatusOK, `{"data":[],"links":{"next":""}}`)

		case path == "/v1/apps/app-1/appAvailabilityV2":
			return jsonResponse(http.StatusOK, f.availabilityV2)
		case path == "/v1/territories":
			return jsonResponse(http.StatusOK, f.pricingTerritories)
		case strings.HasPrefix(path, "/v2/appAvailabilities/") && strings.HasSuffix(path, "/territoryAvailabilities"):
			return jsonResponse(http.StatusOK, f.territories)
		case strings.HasPrefix(path, "/v1/appStoreVersionLocalizations/") && strings.HasSuffix(path, "/appScreenshotSets"):
			localizationID := strings.TrimSuffix(strings.TrimPrefix(path, "/v1/appStoreVersionLocalizations/"), "/appScreenshotSets")
			if body, ok := f.screenshotSets[localizationID]; ok {
				return jsonResponse(http.StatusOK, body)
			}
			return jsonResponse(http.StatusOK, `{"data":[]}`)
		case strings.HasPrefix(path, "/v1/appScreenshotSets/") && strings.HasSuffix(path, "/appScreenshots"):
			setID := strings.TrimSuffix(strings.TrimPrefix(path, "/v1/appScreenshotSets/"), "/appScreenshots")
			if body, ok := f.screenshotsBySet[setID]; ok {
				return jsonResponse(http.StatusOK, body)
			}
			return jsonResponse(http.StatusOK, `{"data":[]}`)
		case path == "/v1/apps/app-1/subscriptionGroups":
			return jsonResponse(http.StatusOK, f.subscriptionGroups)
		case strings.HasPrefix(path, "/v1/subscriptionGroups/") && strings.HasSuffix(path, "/subscriptionGroupLocalizations"):
			return jsonResponse(http.StatusOK, `{"data":[]}`)
		case strings.HasPrefix(path, "/v1/subscriptionGroups/") && strings.HasSuffix(path, "/subscriptions"):
			groupID := strings.TrimSuffix(strings.TrimPrefix(path, "/v1/subscriptionGroups/"), "/subscriptions")
			if body, ok := f.subscriptionsByGroup[groupID]; ok {
				return jsonResponse(http.StatusOK, body)
			}
			return jsonResponse(http.StatusOK, `{"data":[]}`)
		case strings.HasPrefix(path, "/v1/subscriptions/") && strings.HasSuffix(path, "/subscriptionLocalizations"):
			return jsonResponse(http.StatusOK, `{"data":[]}`)
		case strings.HasPrefix(path, "/v1/subscriptions/") && strings.HasSuffix(path, "/prices"):
			return jsonResponse(http.StatusOK, `{"data":[]}`)
		case strings.HasPrefix(path, "/v1/subscriptions/") && strings.HasSuffix(path, "/images"):
			subscriptionID := strings.TrimSuffix(strings.TrimPrefix(path, "/v1/subscriptions/"), "/images")
			if body, ok := f.imagesBySubscription[subscriptionID]; ok {
				return jsonResponse(http.StatusOK, body)
			}
			return jsonResponse(http.StatusOK, `{"data":[]}`)
		case path == "/v1/apps/app-1/inAppPurchasesV2":
			return jsonResponse(http.StatusOK, `{"data":[]}`)
		}

		return jsonResponse(http.StatusNotFound, `{"errors":[{"status":404}]}`)
	})

	client, err := asc.NewClientWithHTTPClient("KEY123", "ISS456", keyPath, &http.Client{Transport: transport})
	if err != nil {
		t.Fatalf("failed to create client: %v", err)
	}
	return client
}

// runReadiness drives the real validate command against the scenario and returns
// the parsed JSON report plus the run error (non-nil and a ReportedError when the
// report has blocking issues).
func runReadiness(t *testing.T, scenario basePriceScenario) (validation.Report, error) {
	t.Helper()

	if scenario.requestTimeout != "" {
		t.Setenv("ASC_TIMEOUT", scenario.requestTimeout)
	}
	client := newBasePriceTestClient(t, scenario)
	restore := validate.SetClientFactory(func() (*asc.Client, error) {
		return client, nil
	})
	defer restore()

	root := RootCommand("1.2.3")

	var runErr error
	stdout, _ := captureOutput(t, func() {
		if err := root.Parse([]string{"validate", "--app", "app-1", "--version-id", "ver-1"}); err != nil {
			t.Fatalf("parse error: %v", err)
		}
		runErr = root.Run(context.Background())
	})

	var report validation.Report
	if err := json.Unmarshal([]byte(stdout), &report); err != nil {
		t.Fatalf("failed to parse JSON report: %v\nstdout: %s\nrun error: %v", err, stdout, runErr)
	}
	return report, runErr
}

func isReportedError(err error) bool {
	if err == nil {
		return false
	}
	_, ok := errors.AsType[ReportedError](err)
	return ok
}

// isAppPricingCheck reports whether a check is about the app's own price. Any
// id, field, resource type, or message that mentions price or pricing counts,
// except subscription and in-app purchase checks, which have their own prices.
func isAppPricingCheck(check validation.CheckResult) bool {
	id := strings.ToLower(check.ID)
	if strings.HasPrefix(id, "subscriptions.") || strings.HasPrefix(id, "iap.") {
		return false
	}
	for _, text := range []string{check.ID, check.Field, check.ResourceType, check.Message} {
		if strings.Contains(strings.ToLower(text), "pric") {
			return true
		}
	}
	return false
}

func appPricingChecksAt(report validation.Report, severity validation.Severity) []string {
	ids := make([]string, 0)
	for _, check := range report.Checks {
		if check.Severity == severity && isAppPricingCheck(check) {
			ids = append(ids, check.ID)
		}
	}
	return ids
}

func assertBlockingPricingError(t *testing.T, report validation.Report, runErr error) {
	t.Helper()
	if ids := appPricingChecksAt(report, validation.SeverityError); len(ids) == 0 {
		t.Fatalf("expected a blocking pricing error, got checks %+v", report.Checks)
	}
	if !isReportedError(runErr) {
		t.Fatalf("expected the run to report a blocking error, got %v", runErr)
	}
}

// A schedule whose base territory has no price that applies today or starts
// later must give a blocking pricing error. End dates are exclusive, so a
// price ending today or earlier no longer applies, and prices for other
// territories do not count, on any page of the list and whether the row
// carries its territory and dates as fields or only in its id.
func TestReadinessBlocksConfiguredScheduleWithoutBasePrice(t *testing.T) {
	cases := []struct {
		name      string
		priceList []pricePage
	}{
		{
			name:      "empty manual price list",
			priceList: onePage(),
		},
		{
			name:      "only price ended today",
			priceList: onePage(appPriceRow{id: "price-today", territory: "USA", startDate: "2020-01-01", endDate: dateFromToday(0), customerPrice: "4.99"}),
		},
		{
			name:      "only price ended yesterday",
			priceList: onePage(appPriceRow{id: "price-yesterday", territory: "USA", startDate: "2020-01-01", endDate: dateFromToday(-1), customerPrice: "2.99"}),
		},
		{
			name:      "only another territory is priced",
			priceList: onePage(appPriceRow{id: "price-can", territory: "CAN", startDate: "2020-01-01", customerPrice: "6.99"}),
		},
		{
			name:      "id-only price ended today",
			priceList: onePage(appPriceRow{id: "price-id-today", territory: "USA", startDate: "2021-03-01", endDate: dateFromToday(0), customerPrice: "3.49", idOnly: true}),
		},
		{
			name: "id-only prices for other territories over two pages",
			priceList: []pricePage{
				{rows: []appPriceRow{
					{id: "price-gbr", territory: "GBR", startDate: "2020-01-01", customerPrice: "4.49", idOnly: true},
					{id: "price-deu", territory: "DEU", startDate: "2020-01-01", customerPrice: "4.99", idOnly: true},
				}},
				{rows: []appPriceRow{
					{id: "price-jpn", territory: "JPN", startDate: "2020-01-01", customerPrice: "700", idOnly: true},
				}},
			},
		},
		{
			name: "base price ended on page one, later page prices other territories",
			priceList: []pricePage{
				{rows: []appPriceRow{
					{id: "price-usa-old", territory: "USA", startDate: "2019-01-01", endDate: dateFromToday(-30), customerPrice: "0.99"},
					{id: "price-fra", territory: "FRA", startDate: "2020-01-01", customerPrice: "1.09"},
				}},
				{rows: []appPriceRow{
					{id: "price-aus", territory: "AUS", startDate: "2020-01-01", customerPrice: "1.49", idOnly: true},
				}},
			},
		},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			report, runErr := runReadiness(t, basePriceScenario{priceList: tc.priceList})
			assertBlockingPricingError(t, report, runErr)
		})
	}
}

// A base territory with a price that applies today or starts later gives a
// clean pricing result: no pricing error or warning, and the run passes. The
// price may sit on any page and may carry its territory and dates only in its
// id. A price that cannot be tied to a territory changes nothing once the base
// territory has such a price, and the schedule's id plays no part.
func TestReadinessAcceptsPresentBasePrice(t *testing.T) {
	cases := []struct {
		name     string
		scenario basePriceScenario
	}{
		{
			name: "paid price active now",
			scenario: basePriceScenario{priceList: onePage(
				appPriceRow{id: "price-paid", territory: "USA", startDate: "2020-01-01", customerPrice: "4.99"},
			)},
		},
		{
			name: "free price active now",
			scenario: basePriceScenario{priceList: onePage(
				appPriceRow{id: "price-free", territory: "USA", startDate: "2020-01-01", customerPrice: "0.0"},
			)},
		},
		{
			name: "price starting today",
			scenario: basePriceScenario{priceList: onePage(
				appPriceRow{id: "price-today", territory: "USA", startDate: dateFromToday(0), customerPrice: "2.49"},
			)},
		},
		{
			name: "price scheduled to start later",
			scenario: basePriceScenario{priceList: onePage(
				appPriceRow{id: "price-later", territory: "USA", startDate: "2999-01-01", customerPrice: "1.99"},
			)},
		},
		{
			name: "price ending tomorrow",
			scenario: basePriceScenario{priceList: onePage(
				appPriceRow{id: "price-tomorrow", territory: "USA", startDate: "2020-01-01", endDate: dateFromToday(1), customerPrice: "3.99"},
			)},
		},
		{
			name: "earlier price ended and a newer one is active",
			scenario: basePriceScenario{priceList: onePage(
				appPriceRow{id: "price-old", territory: "USA", startDate: "2019-01-01", endDate: "2020-01-01", customerPrice: "0.99"},
				appPriceRow{id: "price-new", territory: "USA", startDate: "2020-01-01", customerPrice: "1.99"},
			)},
		},
		{
			name: "base territory CAN priced in CAN",
			scenario: basePriceScenario{
				baseTerritory: territoryBody("CAN", "CAD"),
				priceList: onePage(
					appPriceRow{id: "price-can", territory: "CAN", startDate: "2020-01-01", customerPrice: "5.99"},
				),
			},
		},
		{
			name: "id-only base price active now",
			scenario: basePriceScenario{priceList: onePage(
				appPriceRow{id: "price-id-free", territory: "USA", startDate: "2022-06-01", customerPrice: "0.00", idOnly: true},
			)},
		},
		{
			name: "id-only base price ending tomorrow after one that ended",
			scenario: basePriceScenario{priceList: onePage(
				appPriceRow{id: "price-id-old", territory: "USA", startDate: "2020-01-01", endDate: dateFromToday(-2), customerPrice: "1.99", idOnly: true},
				appPriceRow{id: "price-id-tomorrow", territory: "USA", startDate: dateFromToday(-2), endDate: dateFromToday(1), customerPrice: "2.99", idOnly: true},
			)},
		},
		{
			name: "base price only on a later page",
			scenario: basePriceScenario{priceList: []pricePage{
				{rows: []appPriceRow{
					{id: "price-usa-old", territory: "USA", startDate: "2019-01-01", endDate: dateFromToday(-10), customerPrice: "0.99"},
					{id: "price-gbr", territory: "GBR", startDate: "2020-01-01", customerPrice: "0.89"},
				}},
				{rows: []appPriceRow{
					{id: "price-mex", territory: "MEX", startDate: "2020-01-01", customerPrice: "19", idOnly: true},
				}},
				{rows: []appPriceRow{
					{id: "price-usa-new", territory: "USA", startDate: dateFromToday(-10), customerPrice: "1.29", idOnly: true},
				}},
			}},
		},
		{
			name: "priced schedule that carries the app's own id",
			scenario: basePriceScenario{
				priceSchedule: `{"data":{"type":"appPriceSchedules","id":"app-1","attributes":{}}}`,
				priceList: onePage(
					appPriceRow{id: "price-own-id", territory: "USA", startDate: "2021-09-01", customerPrice: "7.99"},
				),
			},
		},
		{
			name: "unmatched price next to an active base price",
			scenario: basePriceScenario{priceList: onePage(
				appPriceRow{id: "opaque-beside", untied: true},
				appPriceRow{id: "price-usa-beside", territory: "USA", startDate: "2020-01-01", customerPrice: "3.29"},
			)},
		},
		{
			name: "unmatched price on page one, id-only base price on page two",
			scenario: basePriceScenario{
				baseTerritory: territoryBody("JPN", "JPY"),
				priceList: []pricePage{
					{rows: []appPriceRow{
						{id: "opaque-first", untied: true},
						{id: "price-usa-first", territory: "USA", startDate: "2020-01-01", customerPrice: "4.99"},
					}},
					{rows: []appPriceRow{
						{id: "price-jpn-second", territory: "JPN", startDate: dateFromToday(-5), endDate: dateFromToday(3), customerPrice: "500", idOnly: true},
					}},
				},
			},
		},
		{
			name: "base territory BRA priced later on a second page",
			scenario: basePriceScenario{
				baseTerritory: territoryBody("BRA", "BRL"),
				priceList: []pricePage{
					{rows: []appPriceRow{
						{id: "price-usa", territory: "USA", startDate: "2020-01-01", customerPrice: "4.99"},
					}},
					{rows: []appPriceRow{
						{id: "price-bra", territory: "BRA", startDate: "2999-06-01", customerPrice: "24.90", idOnly: true},
					}},
				},
			},
		},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			report, runErr := runReadiness(t, tc.scenario)

			if ids := appPricingChecksAt(report, validation.SeverityError); len(ids) != 0 {
				t.Fatalf("expected no pricing error for a priced app, got %v (checks %+v)", ids, report.Checks)
			}
			if ids := appPricingChecksAt(report, validation.SeverityWarning); len(ids) != 0 {
				t.Fatalf("expected no pricing warning for a priced app, got %v (checks %+v)", ids, report.Checks)
			}
			if runErr != nil {
				t.Fatalf("expected the run to stay non-blocking, got %v", runErr)
			}
		})
	}
}

// An app App Store Connect reports as never priced (its schedule's base
// territory or price list reads back as the "no resource of type 'null'" 404)
// must give a blocking pricing error.
func TestReadinessReportsNeverConfiguredScheduleAsMissing(t *testing.T) {
	neverPriced := ascErrorBody(http.StatusNotFound, "NOT_FOUND", "There is no resource of type 'null' with id 'app-1'")
	neverPricedSchedule := `{"data":{"type":"appPriceSchedules","id":"app-1"}}`

	cases := []struct {
		name     string
		scenario basePriceScenario
	}{
		{
			name: "price list read says never priced",
			scenario: basePriceScenario{
				priceSchedule: neverPricedSchedule,
				priceList:     []pricePage{errorPage(http.StatusNotFound, neverPriced)},
			},
		},
		{
			name: "base territory and price list reads say never priced",
			scenario: basePriceScenario{
				priceSchedule:       neverPricedSchedule,
				baseTerritoryStatus: http.StatusNotFound,
				baseTerritory:       neverPriced,
				priceList:           []pricePage{errorPage(http.StatusNotFound, neverPriced)},
			},
		},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			report, runErr := runReadiness(t, tc.scenario)
			assertBlockingPricingError(t, report, runErr)
		})
	}
}

// When the base territory or any page of the price list cannot be read
// (including a request still unanswered at the ASC_TIMEOUT request timeout),
// or a price cannot be tied to a territory and nothing else gives the base
// territory a price that applies today or starts later, readiness gives a
// non-blocking pricing warning, no pricing error, and the run passes.
func TestReadinessDegradesUnreadablePricingToWarning(t *testing.T) {
	otherTerritoryPage := pricePage{rows: []appPriceRow{
		{id: "price-ita", territory: "ITA", startDate: "2020-01-01", customerPrice: "2.29", idOnly: true},
	}}

	cases := []struct {
		name     string
		scenario basePriceScenario
	}{
		{
			name: "manual prices rate limited",
			scenario: basePriceScenario{priceList: []pricePage{
				errorPage(http.StatusTooManyRequests, ascErrorBody(http.StatusTooManyRequests, "RATE_LIMITED", "rate limited")),
			}},
		},
		{
			name: "manual prices server error",
			scenario: basePriceScenario{priceList: []pricePage{
				errorPage(http.StatusServiceUnavailable, ascErrorBody(http.StatusServiceUnavailable, "SERVICE_UNAVAILABLE", "service unavailable")),
			}},
		},
		{
			name: "manual prices forbidden",
			scenario: basePriceScenario{priceList: []pricePage{
				errorPage(http.StatusForbidden, ascErrorBody(http.StatusForbidden, "FORBIDDEN_ERROR", "The API key in use does not allow this request")),
			}},
		},
		{
			name: "manual prices unrelated not found",
			scenario: basePriceScenario{priceList: []pricePage{
				errorPage(http.StatusNotFound, ascErrorBody(http.StatusNotFound, "NOT_FOUND", "resource not found")),
			}},
		},
		{
			name:     "manual price has no territory",
			scenario: basePriceScenario{priceList: onePage(appPriceRow{id: "opaque", untied: true})},
		},
		{
			name: "later price page rate limited",
			scenario: basePriceScenario{priceList: []pricePage{
				otherTerritoryPage,
				errorPage(http.StatusTooManyRequests, ascErrorBody(http.StatusTooManyRequests, "RATE_LIMITED", "rate limited")),
			}},
		},
		{
			name: "later price page server error",
			scenario: basePriceScenario{priceList: []pricePage{
				otherTerritoryPage,
				errorPage(http.StatusInternalServerError, ascErrorBody(http.StatusInternalServerError, "INTERNAL_ERROR", "internal error")),
			}},
		},
		{
			name: "later price page has a price with no territory",
			scenario: basePriceScenario{priceList: []pricePage{
				otherTerritoryPage,
				{rows: []appPriceRow{{id: "opaque-2", untied: true}}},
			}},
		},
		{
			name: "unmatched price and a base price that ended today",
			scenario: basePriceScenario{priceList: onePage(
				appPriceRow{id: "price-usa-ended", territory: "USA", startDate: "2020-01-01", endDate: dateFromToday(0), customerPrice: "4.99"},
				appPriceRow{id: "opaque-3", untied: true},
			)},
		},
		{
			name: "unmatched price and an id-only base price that ended earlier",
			scenario: basePriceScenario{
				baseTerritory: territoryBody("DEU", "EUR"),
				priceList: []pricePage{
					{rows: []appPriceRow{
						{id: "price-deu-ended", territory: "DEU", startDate: "2020-01-01", endDate: dateFromToday(-4), customerPrice: "5.99", idOnly: true},
						{id: "price-usa-live", territory: "USA", startDate: "2020-01-01", customerPrice: "5.99"},
					}},
					{rows: []appPriceRow{{id: "opaque-4", untied: true}}},
				},
			},
		},
		{
			name: "manual prices never answer",
			scenario: basePriceScenario{
				requestTimeout: "1s",
				priceList: []pricePage{
					hangPage(appPriceRow{id: "price-usa-first-hang", territory: "USA", startDate: "2020-01-01", customerPrice: "1.49"}),
				},
			},
		},
		{
			name: "later price page never answers",
			scenario: basePriceScenario{
				requestTimeout: "1s",
				priceList: []pricePage{
					otherTerritoryPage,
					hangPage(appPriceRow{id: "price-usa-late", territory: "USA", startDate: "2020-01-01", customerPrice: "2.99"}),
				},
			},
		},
		{
			name: "base territory never answers",
			scenario: basePriceScenario{
				requestTimeout:     "1s",
				baseTerritoryHangs: true,
			},
		},
		{
			name: "base territory rate limited",
			scenario: basePriceScenario{
				baseTerritoryStatus: http.StatusTooManyRequests,
				baseTerritory:       ascErrorBody(http.StatusTooManyRequests, "RATE_LIMITED", "rate limited"),
			},
		},
		{
			name: "base territory server error",
			scenario: basePriceScenario{
				baseTerritoryStatus: http.StatusInternalServerError,
				baseTerritory:       ascErrorBody(http.StatusInternalServerError, "INTERNAL_ERROR", "internal error"),
			},
		},
		{
			name: "base territory forbidden",
			scenario: basePriceScenario{
				baseTerritoryStatus: http.StatusForbidden,
				baseTerritory:       ascErrorBody(http.StatusForbidden, "FORBIDDEN_ERROR", "The API key in use does not allow this request"),
			},
		},
		{
			name: "base territory unrelated not found",
			scenario: basePriceScenario{
				baseTerritoryStatus: http.StatusNotFound,
				baseTerritory:       ascErrorBody(http.StatusNotFound, "NOT_FOUND", "resource not found"),
			},
		},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			report, runErr := runReadiness(t, tc.scenario)

			if ids := appPricingChecksAt(report, validation.SeverityWarning); len(ids) == 0 {
				t.Fatalf("expected a pricing warning, got %+v", report.Checks)
			}
			if ids := appPricingChecksAt(report, validation.SeverityError); len(ids) != 0 {
				t.Fatalf("expected no blocking pricing error for an unreadable price, got %v (checks %+v)", ids, report.Checks)
			}
			if runErr != nil {
				t.Fatalf("expected the run to stay non-blocking, got %v", runErr)
			}
		})
	}
}
