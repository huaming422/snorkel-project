## Task

Our first iOS app passed `asc validate --app 6741234567 --version-id <version>` last week, and its report had nothing to say about pricing.
We sent it to review, and App Store Connect rejected the submission with "App is not eligible for submission until pricing has been set."
Nobody had ever picked a price for the app's base territory.
`asc pricing current --app 6741234567` saw the problem and printed "App 6741234567 has no price schedule configured yet".
Behind that message is a 404 from App Store Connect whose detail is "There is no resource of type 'null' with id '6741234567'".

Readiness should catch this before a reviewer does.
`asc validate` should report a blocking pricing error, and fail the run, for an app in that state.
It should do the same for an app that has a price schedule but no base territory price that applies today or starts later.
A price stops applying on its end date, so one that ends today or ended earlier doesn't count.
A price set only for some other territory doesn't count either.
Free counts as a price, and so does a price that starts later or ends after today.
An app with a base territory price like that should get no pricing error or warning.

This has to hold for older apps too.
One of ours has years of price changes across a few dozen territories.
Many rows in its manual price list come back with no territory relationship and no endDate field, but `asc pricing current` still prints the right current USA price for it.
Validate has to get the right answer from that whole list too.

Don't turn a failed read into that error, though.
Sometimes the base territory request, or any page of the price list, is rate limited, hits a server error, is refused for permissions, gets a 404 for some other reason, or just hangs until our `ASC_TIMEOUT` runs out.
In those cases validate should still print its report, with a non-blocking pricing warning in place of the error.
No pricing error, and the run shouldn't fail because of it.

Now and then the list also has a row that can't be matched to any territory.
That row only matters when it might be the base territory's price, because nothing else on the list gives that territory one that applies today or starts later.
Then validate can't tell either way and should give the same warning.
