## Task

Our first iOS app passed `asc validate --app 6741234567 --version-id <version>` last week, and its report had nothing to say about pricing.
We sent it to review, and App Store Connect rejected the submission with "App is not eligible for submission until pricing has been set."
Nobody had ever picked a price for the app's base territory.
`asc pricing current --app 6741234567` saw the problem and printed "App 6741234567 has no price schedule configured yet".
Behind that message, App Store Connect answers the base territory or price list request for the app's price schedule with a 404 whose detail is "There is no resource of type 'null' with id '6741234567'".

Readiness should catch this before a reviewer does.
`asc validate` should report a blocking pricing error, and fail the run, for an app in that state.
It should do the same for an app that has a price schedule but no base territory price that applies today or starts later.
A price stops applying on its end date, so one that ends today or ended earlier doesn't count.
A price set only for some other territory doesn't count either.
Free counts as a price, and so does a price that starts later or ends after today.
An app with a base territory price like that should get no pricing error or warning.

This has to hold for older apps too.
One of ours has years of price changes across a few dozen territories, so App Store Connect sends its manual price list over several pages, and the current USA price isn't on the first one.
Rows in that list often have no territory relationship and no endDate field, and the territory and dates are only inside the price's id.
`asc pricing current` already reads that list correctly, and validate has to read all of it the same way.

Don't turn a failed read into that error, though.
Sometimes the base territory request, or any page of the price list, is rate limited, hits a server error, is refused for permissions, or gets a 404 for some other reason.
The list can also come back with a price that can't be matched to a territory.
In those cases validate should still print its report with a non-blocking pricing warning, like the "could not verify app price schedule" warning it shows today when Pricing and Availability is rate limited.
No pricing error, and the run shouldn't fail because of it.
