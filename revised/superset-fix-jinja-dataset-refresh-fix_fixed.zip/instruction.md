## Task

Saving a virtual dataset whose SQL uses Jinja (`{% if ... %}` or `{{ ... }}` blocks) pops an "Invalid SQL" error toast in the dataset editor.
The edits still save.
Plain SQL datasets save with no toast.
People read that toast as a failed save, so these datasets should save cleanly.
A dataset that really is broken should still fail to save like it does today, whether that's bad SQL, a template Superset blocks as unsafe, or a database it can't reach.
