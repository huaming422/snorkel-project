## Task

The vector-store ingestion pipeline in the semantic router gets shutdown wrong when one of its workers is stuck inside an embed call.
Here is what we see with a worker wedged like that:

- A stop with a short deadline times out with `context.DeadlineExceeded`, which is fine.
  Calling stop again then returns nil, even though the stuck worker never exited.
  A retry should keep getting the deadline error until the workers are really gone, and get nil only after that.
- Calling start after that timed-out stop goes ahead right away while the old run is still unwinding.
  Start should wait until the previous run has fully drained, however long that takes, then bring up a fresh run that takes new files through to `completed`.
  A bounded stop called while that start is still waiting should still come back on time with the deadline error.
- If files are still waiting in the queue and the metadata store hangs on writes, a bounded stop runs far past its deadline.
  It should come back on time with the deadline error.
  By the time it returns, each queued file should already read `failed` with the `pipeline_stopped` error code, and each vector store's file counts should show its own queued files as failed instead of in progress.
  The file the stuck worker holds stays in progress, and the totals do not change.

The runtime that owns the pipeline makes this worse on shutdown.
When the pipeline does not drain in time, it still closes the vector backend and the metadata registry and reports no error.
It should return an error that still matches `context.DeadlineExceeded` under `errors.Is`, and leave the backend and registry open because workers may still be using them.
A shutdown that drains in time should still close both and return nil.

Keep the existing start, stop, attach and file-status methods and the runtime shutdown call as they are today.
