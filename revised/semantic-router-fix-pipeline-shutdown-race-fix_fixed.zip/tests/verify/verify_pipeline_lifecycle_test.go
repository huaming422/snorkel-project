/*
Copyright 2025 vLLM Semantic Router.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

// Drives the ingestion pipeline's shutdown/restart contract through its
// pre-existing public API only (NewIngestionPipeline + Start/Stop/AttachFile/
// GetFileStatus and Manager.CreateStore/GetStore). Every assertion is on an
// exported return value or on the store's FileCounts, never on internal
// lifecycle fields.
//
// External test package (vectorstore_test) with unique `vrf`-prefixed
// identifiers so it compiles cleanly alongside the package's own in-package
// test files without colliding with their fixtures.
package vectorstore_test

import (
	"context"
	"fmt"
	"os"
	"sync"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	vs "github.com/vllm-project/semantic-router/src/semantic-router/pkg/vectorstore"
)

// vrfBlockingEmbedder models an embedding stage that ignores ctx and blocks
// inside Embed until released, so a worker can be wedged deterministically,
// which is the condition a bounded Stop(ctx) has to handle. It is the
// verifier's own copy of the pattern; it references no unexported repo symbol.
type vrfBlockingEmbedder struct {
	dim         int
	startOnce   sync.Once
	releaseOnce sync.Once
	started     chan struct{}
	release     chan struct{}
}

func vrfNewBlockingEmbedder(dim int) *vrfBlockingEmbedder {
	return &vrfBlockingEmbedder{
		dim:     dim,
		started: make(chan struct{}),
		release: make(chan struct{}),
	}
}

func (e *vrfBlockingEmbedder) Embed(_ context.Context, _ string) ([]float32, error) {
	e.startOnce.Do(func() { close(e.started) })
	<-e.release
	emb := make([]float32, e.dim)
	for i := range emb {
		emb[i] = 0.1
	}
	return emb, nil
}

func (e *vrfBlockingEmbedder) Dimension() int { return e.dim }

// releaseAll unblocks every Embed call. Safe to call more than once.
func (e *vrfBlockingEmbedder) releaseAll() {
	e.releaseOnce.Do(func() { close(e.release) })
}

// vrfInstantEmbedder returns a fixed-dimension vector immediately, modelling a
// healthy embedding stage for the non-regression happy-path check.
type vrfInstantEmbedder struct{ dim int }

func (e *vrfInstantEmbedder) Embed(_ context.Context, _ string) ([]float32, error) {
	emb := make([]float32, e.dim)
	for i := range emb {
		emb[i] = 0.1
	}
	return emb, nil
}

func (e *vrfInstantEmbedder) Dimension() int { return e.dim }

// vrfStallingStoreRegistry embeds an in-memory metadata registry and, once
// stalled, makes SaveStore block until its ctx is cancelled. It is the
// verifier's own copy of the stalling-registry pattern (StoreRegistry is a
// pre-existing public interface); it references no unexported repo symbol.
type vrfStallingStoreRegistry struct {
	vs.StoreRegistry
	mu        sync.RWMutex
	stalled   bool
	startedCh chan struct{}
	once      sync.Once
}

func vrfNewStallingStoreRegistry() *vrfStallingStoreRegistry {
	return &vrfStallingStoreRegistry{
		StoreRegistry: vs.NewMemoryMetadataRegistry(),
		startedCh:     make(chan struct{}),
	}
}

func (r *vrfStallingStoreRegistry) SaveStore(ctx context.Context, store *vs.VectorStore) error {
	r.mu.RLock()
	stalled := r.stalled
	r.mu.RUnlock()
	if stalled {
		r.once.Do(func() { close(r.startedCh) })
		<-ctx.Done()
		return ctx.Err()
	}
	return r.StoreRegistry.SaveStore(ctx, store)
}

func (r *vrfStallingStoreRegistry) stall() {
	r.mu.Lock()
	r.stalled = true
	r.mu.Unlock()
}

func (r *vrfStallingStoreRegistry) resume() {
	r.mu.Lock()
	r.stalled = false
	r.mu.Unlock()
}

// vrfFixture bundles a fully wired pipeline over in-memory backends. Tests that
// only wedge one job use two workers, so one worker stays idle and exits as soon
// as the pipeline stops while the other is still wedged.
type vrfFixture struct {
	backend  *vs.MemoryBackend
	store    *vs.FileStore
	mgr      *vs.Manager
	pipeline *vs.IngestionPipeline
	tempDir  string
	ctx      context.Context
}

func vrfNewFixture(t *testing.T, embedder vs.Embedder, registry vs.StoreRegistry, workers int) *vrfFixture {
	t.Helper()
	tempDir, err := os.MkdirTemp("", "vrf-pipeline-lifecycle-*")
	require.NoError(t, err)

	backend := vs.NewMemoryBackend(vs.MemoryBackendConfig{})
	store, err := vs.NewFileStore(tempDir, vs.NewMemoryMetadataRegistry())
	require.NoError(t, err)

	mgr := vs.NewManager(backend, registry, 3, vs.BackendTypeMemory)
	pipeline := vs.NewIngestionPipeline(
		backend,
		store,
		mgr,
		embedder,
		vs.PipelineConfig{Workers: workers, QueueSize: 10},
	)
	pipeline.Start()

	return &vrfFixture{
		backend:  backend,
		store:    store,
		mgr:      mgr,
		pipeline: pipeline,
		tempDir:  tempDir,
		ctx:      context.Background(),
	}
}

// vrfStopResult is the outcome of a bounded Stop run in the background.
type vrfStopResult struct {
	err      error
	elapsed  time.Duration
	returned bool
}

// vrfRunStopBounded runs pipeline.Stop(ctx) on a goroutine and waits at most
// `wait` for it to return. A Stop that does not honor its deadline then shows
// up as a fast assertion failure (returned == false) instead of hanging the
// whole go-test process.
func vrfRunStopBounded(pipeline *vs.IngestionPipeline, ctx context.Context, wait time.Duration) vrfStopResult {
	done := make(chan vrfStopResult, 1)
	start := time.Now()
	go func() {
		err := pipeline.Stop(ctx)
		done <- vrfStopResult{err: err, elapsed: time.Since(start), returned: true}
	}()
	select {
	case res := <-done:
		return res
	case <-time.After(wait):
		return vrfStopResult{returned: false, elapsed: time.Since(start)}
	}
}

// vrfPoll repeatedly evaluates cond until it returns true or the timeout
// elapses. Returns true if cond succeeded within the window.
func vrfPoll(timeout, interval time.Duration, cond func() bool) bool {
	deadline := time.Now().Add(timeout)
	for {
		if cond() {
			return true
		}
		if time.Now().After(deadline) {
			return false
		}
		time.Sleep(interval)
	}
}

// A bounded Stop that times out with a worker wedged mid-embed returns the
// deadline error, and a SECOND Stop on the still-draining pipeline ALSO returns
// the deadline error (not nil). Once the wedged stage is released, a retried
// Stop returns nil.
func TestVerifyStopTimeoutNotFalseClean(t *testing.T) {
	embedder := vrfNewBlockingEmbedder(3)
	f := vrfNewFixture(t, embedder, vs.NewMemoryMetadataRegistry(), 2)
	t.Cleanup(func() {
		embedder.releaseAll()
		_ = f.pipeline.Stop(context.Background())
		_ = os.RemoveAll(f.tempDir)
	})

	store, err := f.mgr.CreateStore(f.ctx, vs.CreateStoreRequest{Name: "stop-timeout"})
	require.NoError(t, err)
	record, err := f.store.Save("active.txt", []byte("active content"), "assistants")
	require.NoError(t, err)
	_, err = f.pipeline.AttachFile(store.ID, record.ID, nil)
	require.NoError(t, err)

	// Wait until the worker is wedged inside Embed.
	require.True(t, vrfPoll(5*time.Second, 10*time.Millisecond, func() bool {
		select {
		case <-embedder.started:
			return true
		default:
			return false
		}
	}), "embedder never entered its blocked stage")

	// First bounded Stop: the wedged worker cannot drain, so Stop must honor its
	// deadline and return context.DeadlineExceeded.
	ctx1, cancel1 := context.WithTimeout(context.Background(), 100*time.Millisecond)
	defer cancel1()
	res1 := vrfRunStopBounded(f.pipeline, ctx1, 3*time.Second)
	require.True(t, res1.returned, "first Stop did not return within its bound (deadline not honored)")
	require.ErrorIs(t, res1.err, context.DeadlineExceeded, "first bounded Stop should return the deadline error")

	// Second bounded Stop on the still-draining pipeline: it must report that the
	// pipeline is still stopping (the deadline error), NOT falsely claim a clean
	// shutdown by returning nil.
	ctx2, cancel2 := context.WithTimeout(context.Background(), 100*time.Millisecond)
	defer cancel2()
	res2 := vrfRunStopBounded(f.pipeline, ctx2, 3*time.Second)
	require.True(t, res2.returned, "second Stop did not return within its bound")
	require.ErrorIs(t, res2.err, context.DeadlineExceeded,
		"second Stop on a still-draining pipeline must return the deadline error, not nil")

	// Release the wedged stage; a retried Stop must now be able to observe the
	// worker join and return nil.
	embedder.releaseAll()
	require.True(t, vrfPoll(5*time.Second, 50*time.Millisecond, func() bool {
		ctx3, cancel3 := context.WithTimeout(context.Background(), time.Second)
		defer cancel3()
		return f.pipeline.Stop(ctx3) == nil
	}), "Stop never returned nil after the wedged stage was released")
}

// After a Stop that timed out with a worker still wedged, Start must not
// complete until the previous run finishes draining, however long that takes
// (the worker is held for 35s here, longer than any timeout the pipeline or
// runtime defines). A bounded Stop called while that Start is
// waiting still returns on time with the deadline error. Once the wedged stage
// is released and the old workers exit, Start completes, a newly attached file
// reaches 'completed', and a final Stop returns nil.
func TestVerifyRestartWaitsForPreviousRun(t *testing.T) {
	embedder := vrfNewBlockingEmbedder(3)
	f := vrfNewFixture(t, embedder, vs.NewMemoryMetadataRegistry(), 2)
	t.Cleanup(func() {
		embedder.releaseAll()
		_ = f.pipeline.Stop(context.Background())
		_ = os.RemoveAll(f.tempDir)
	})

	store, err := f.mgr.CreateStore(f.ctx, vs.CreateStoreRequest{Name: "restart-wait"})
	require.NoError(t, err)
	record, err := f.store.Save("restart.txt", []byte("content"), "assistants")
	require.NoError(t, err)
	_, err = f.pipeline.AttachFile(store.ID, record.ID, nil)
	require.NoError(t, err)
	require.True(t, vrfPoll(5*time.Second, 10*time.Millisecond, func() bool {
		select {
		case <-embedder.started:
			return true
		default:
			return false
		}
	}), "embedder never entered its blocked stage")

	ctx, cancel := context.WithTimeout(context.Background(), 100*time.Millisecond)
	defer cancel()
	res := vrfRunStopBounded(f.pipeline, ctx, 3*time.Second)
	require.True(t, res.returned, "bounded Stop did not return within its bound")
	require.ErrorIs(t, res.err, context.DeadlineExceeded)

	// Start while the previous run is still draining: it must block until that
	// run is done, so `started` must NOT close while the worker is still wedged.
	started := make(chan struct{})
	go func() {
		f.pipeline.Start()
		close(started)
	}()
	stayedBlocked := true
	deadline := time.Now().Add(35 * time.Second)
	for time.Now().Before(deadline) {
		select {
		case <-started:
			stayedBlocked = false
		default:
		}
		if !stayedBlocked {
			break
		}
		time.Sleep(50 * time.Millisecond)
	}
	require.True(t, stayedBlocked,
		"Start completed while the previous run was still draining")

	// A bounded Stop issued while Start is waiting must not be held up by it.
	waitCtx, waitCancel := context.WithTimeout(context.Background(), 100*time.Millisecond)
	defer waitCancel()
	waitRes := vrfRunStopBounded(f.pipeline, waitCtx, 3*time.Second)
	require.True(t, waitRes.returned, "bounded Stop during a waiting Start did not return within its bound")
	require.ErrorIs(t, waitRes.err, context.DeadlineExceeded,
		"bounded Stop during a waiting Start should return the deadline error")
	select {
	case <-started:
		t.Fatal("Start completed while the previous run was still draining")
	default:
	}

	// Release the wedged stage; the old workers join and Start can now complete.
	embedder.releaseAll()
	require.True(t, vrfPoll(5*time.Second, 20*time.Millisecond, func() bool {
		select {
		case <-started:
			return true
		default:
			return false
		}
	}), "Start never completed after the previous run drained")

	// A fresh run is going: a newly attached file must reach completed.
	second, err := f.store.Save("restart-second.txt", []byte("new content"), "assistants")
	require.NoError(t, err)
	vsf, err := f.pipeline.AttachFile(store.ID, second.ID, nil)
	require.NoError(t, err)
	require.True(t, vrfPoll(5*time.Second, 50*time.Millisecond, func() bool {
		status, statusErr := f.pipeline.GetFileStatus(vsf.ID)
		return statusErr == nil && status.Status == "completed"
	}), "file attached after restart never reached 'completed'")

	require.NoError(t, f.pipeline.Stop(context.Background()), "final Stop after a clean restart should return nil")
}

// With a metadata registry that stalls SaveStore and nine queued jobs, a
// bounded Stop with a 200ms deadline returns in under 700ms, with the deadline
// error.
func TestVerifyBoundedStopReturnsOnTimeWithStalledRegistry(t *testing.T) {
	embedder := vrfNewBlockingEmbedder(3)
	registry := vrfNewStallingStoreRegistry()
	f := vrfNewFixture(t, embedder, registry, 1)
	t.Cleanup(func() {
		registry.resume()
		embedder.releaseAll()
		_ = os.RemoveAll(f.tempDir)
	})

	store, err := f.mgr.CreateStore(f.ctx, vs.CreateStoreRequest{Name: "stalled-registry"})
	require.NoError(t, err)

	first, err := f.store.Save("active.txt", []byte("active content"), "assistants")
	require.NoError(t, err)
	_, err = f.pipeline.AttachFile(store.ID, first.ID, nil)
	require.NoError(t, err)
	require.True(t, vrfPoll(5*time.Second, 10*time.Millisecond, func() bool {
		select {
		case <-embedder.started:
			return true
		default:
			return false
		}
	}), "embedder never entered its blocked stage")

	for i := 0; i < 9; i++ {
		record, saveErr := f.store.Save("queued.txt", []byte("queued content"), "assistants")
		require.NoError(t, saveErr)
		_, attachErr := f.pipeline.AttachFile(store.ID, record.ID, nil)
		require.NoError(t, attachErr)
	}

	registry.stall()
	ctx, cancel := context.WithTimeout(context.Background(), 200*time.Millisecond)
	defer cancel()
	res := vrfRunStopBounded(f.pipeline, ctx, 3*time.Second)
	require.True(t, res.returned,
		"bounded Stop did not return within 3s; queued-job cleanup did not honor the Stop deadline")
	require.ErrorIs(t, res.err, context.DeadlineExceeded, "bounded Stop should return the deadline error")
	require.Less(t, res.elapsed, 700*time.Millisecond,
		"bounded Stop with a 200ms deadline took 700ms or more with queued jobs and a stalled registry")
}

// When a bounded Stop with queued jobs returns, every queued-but-unprocessed
// file already reads 'failed' with error code 'pipeline_stopped', and each
// store's FileCounts account its own queued files as Failed (not left stuck
// InProgress). Queued files are spread over two stores so each store's counts
// are checked on their own. The still-wedged in-flight job remains InProgress.
func TestVerifyQueuedCountsConsistentAfterBoundedStop(t *testing.T) {
	embedder := vrfNewBlockingEmbedder(3)
	registry := vrfNewStallingStoreRegistry()
	f := vrfNewFixture(t, embedder, registry, 1)
	t.Cleanup(func() {
		registry.resume()
		embedder.releaseAll()
		_ = os.RemoveAll(f.tempDir)
	})

	store, err := f.mgr.CreateStore(f.ctx, vs.CreateStoreRequest{Name: "stalled-counts"})
	require.NoError(t, err)
	other, err := f.mgr.CreateStore(f.ctx, vs.CreateStoreRequest{Name: "stalled-counts-other"})
	require.NoError(t, err)

	first, err := f.store.Save("active.txt", []byte("active content"), "assistants")
	require.NoError(t, err)
	_, err = f.pipeline.AttachFile(store.ID, first.ID, nil)
	require.NoError(t, err)
	require.True(t, vrfPoll(5*time.Second, 10*time.Millisecond, func() bool {
		select {
		case <-embedder.started:
			return true
		default:
			return false
		}
	}), "embedder never entered its blocked stage")

	// Two queued files on the first store (behind the wedged job) and one on
	// the second store.
	var queuedIDs []string
	for _, storeID := range []string{store.ID, store.ID, other.ID} {
		record, saveErr := f.store.Save("queued.txt", []byte("queued content"), "assistants")
		require.NoError(t, saveErr)
		status, attachErr := f.pipeline.AttachFile(storeID, record.ID, nil)
		require.NoError(t, attachErr)
		queuedIDs = append(queuedIDs, status.ID)
	}

	registry.stall()
	ctx, cancel := context.WithTimeout(context.Background(), 200*time.Millisecond)
	defer cancel()
	res := vrfRunStopBounded(f.pipeline, ctx, 3*time.Second)
	require.True(t, res.returned, "bounded Stop did not return within its bound")
	require.ErrorIs(t, res.err, context.DeadlineExceeded)

	// Each queued-but-unprocessed file must end failed with the stop code.
	for _, id := range queuedIDs {
		status, statusErr := f.pipeline.GetFileStatus(id)
		require.NoError(t, statusErr)
		assert.Equal(t, "failed", status.Status, "queued file should be marked failed after a bounded Stop")
		require.NotNil(t, status.LastError, "a failed queued file must carry an error")
		assert.Equal(t, "pipeline_stopped", status.LastError.Code,
			"queued files failed by Stop should carry the pipeline_stopped code")
	}

	// Counts must be consistent per store: on the first store the wedged
	// in-flight job stays InProgress and its two queued jobs move to Failed;
	// on the second store its one queued job moves to Failed. Totals are
	// unchanged.
	updated, err := f.mgr.GetStore(store.ID)
	require.NoError(t, err)
	assert.Equal(t, 1, updated.FileCounts.InProgress, "the wedged in-flight job should remain in progress")
	assert.Equal(t, 2, updated.FileCounts.Failed, "the two queued jobs on the first store should be accounted as failed")
	assert.Equal(t, 3, updated.FileCounts.Total, "total file count should be unchanged by the bounded Stop")

	otherUpdated, err := f.mgr.GetStore(other.ID)
	require.NoError(t, err)
	assert.Equal(t, 0, otherUpdated.FileCounts.InProgress, "the second store has no job left in progress")
	assert.Equal(t, 1, otherUpdated.FileCounts.Failed, "the queued job on the second store should be accounted as failed")
	assert.Equal(t, 1, otherUpdated.FileCounts.Total, "the second store's total should be unchanged by the bounded Stop")
}

// A normal lifecycle (Start, AttachFile, let the embed complete) drives the
// file to 'completed', a subsequent Stop returns nil, and the store counts the
// file as completed.
func TestVerifyCleanLifecycleCompletes(t *testing.T) {
	f := vrfNewFixture(t, &vrfInstantEmbedder{dim: 3}, vs.NewMemoryMetadataRegistry(), 1)
	t.Cleanup(func() {
		_ = f.pipeline.Stop(context.Background())
		_ = os.RemoveAll(f.tempDir)
	})

	store, err := f.mgr.CreateStore(f.ctx, vs.CreateStoreRequest{Name: "clean-lifecycle"})
	require.NoError(t, err)
	record, err := f.store.Save("doc.txt", []byte("hello world content for ingestion"), "assistants")
	require.NoError(t, err)
	vsf, err := f.pipeline.AttachFile(store.ID, record.ID, nil)
	require.NoError(t, err)

	require.True(t, vrfPoll(5*time.Second, 25*time.Millisecond, func() bool {
		status, statusErr := f.pipeline.GetFileStatus(vsf.ID)
		return statusErr == nil && status.Status == "completed"
	}), "a normally attached file never reached 'completed'")

	require.NoError(t, f.pipeline.Stop(context.Background()), "a clean Stop should return nil")

	updated, err := f.mgr.GetStore(store.ID)
	require.NoError(t, err)
	assert.Equal(t, 1, updated.FileCounts.Completed, "the completed job should be counted")
}

// vrfPacedEmbedder returns a vector after a short pause, so jobs stay in the
// queue long enough for a Stop to find some of them still waiting.
type vrfPacedEmbedder struct {
	dim   int
	pause time.Duration
}

func (e *vrfPacedEmbedder) Embed(_ context.Context, _ string) ([]float32, error) {
	time.Sleep(e.pause)
	emb := make([]float32, e.dim)
	for i := range emb {
		emb[i] = 0.1
	}
	return emb, nil
}

func (e *vrfPacedEmbedder) Dimension() int { return e.dim }

// Two Stop calls overlap while a worker is wedged mid-embed. The first has a
// 4s deadline and is still waiting when the second, with a 100ms deadline,
// starts. The second returns on time with the deadline error, and the first
// does not return while the worker is still wedged. An AttachFile issued
// during the stop returns an error right away and leaves the store's counts
// alone. Once the wedged stage is released, the first Stop returns nil within
// its own deadline, and the wedged file ends 'completed' or 'failed' with the
// store's counts balanced.
func TestVerifyOverlappingStopsHonorTheirOwnDeadlines(t *testing.T) {
	embedder := vrfNewBlockingEmbedder(3)
	f := vrfNewFixture(t, embedder, vs.NewMemoryMetadataRegistry(), 2)
	t.Cleanup(func() {
		embedder.releaseAll()
		_ = f.pipeline.Stop(context.Background())
		_ = os.RemoveAll(f.tempDir)
	})

	store, err := f.mgr.CreateStore(f.ctx, vs.CreateStoreRequest{Name: "overlapping-stops"})
	require.NoError(t, err)
	record, err := f.store.Save("wedged.txt", []byte("wedged content"), "assistants")
	require.NoError(t, err)
	wedged, err := f.pipeline.AttachFile(store.ID, record.ID, nil)
	require.NoError(t, err)
	require.True(t, vrfPoll(5*time.Second, 10*time.Millisecond, func() bool {
		select {
		case <-embedder.started:
			return true
		default:
			return false
		}
	}), "embedder never entered its blocked stage")

	longCtx, longCancel := context.WithTimeout(context.Background(), 4*time.Second)
	defer longCancel()
	longDone := make(chan error, 1)
	go func() { longDone <- f.pipeline.Stop(longCtx) }()
	time.Sleep(100 * time.Millisecond)

	shortCtx, shortCancel := context.WithTimeout(context.Background(), 100*time.Millisecond)
	defer shortCancel()
	short := vrfRunStopBounded(f.pipeline, shortCtx, 3*time.Second)
	require.True(t, short.returned, "a 100ms Stop overlapping a longer Stop did not return within 3s")
	require.ErrorIs(t, short.err, context.DeadlineExceeded,
		"a 100ms Stop overlapping a longer Stop should return the deadline error")
	require.Less(t, short.elapsed, 600*time.Millisecond,
		"a 100ms Stop overlapping a longer Stop took 600ms or more")

	type attachResult struct {
		err      error
		returned bool
	}
	attachDone := make(chan attachResult, 1)
	late, err := f.store.Save("late.txt", []byte("late content"), "assistants")
	require.NoError(t, err)
	go func() {
		_, attachErr := f.pipeline.AttachFile(store.ID, late.ID, nil)
		attachDone <- attachResult{err: attachErr, returned: true}
	}()
	var attach attachResult
	select {
	case attach = <-attachDone:
	case <-time.After(500 * time.Millisecond):
	}
	require.True(t, attach.returned, "AttachFile during a stop did not return within 500ms")
	require.Error(t, attach.err, "AttachFile during a stop should be refused")
	during, err := f.mgr.GetStore(store.ID)
	require.NoError(t, err)
	assert.Equal(t, 1, during.FileCounts.Total, "a refused AttachFile should not change the store's total")
	assert.Equal(t, 1, during.FileCounts.InProgress, "a refused AttachFile should not change the in-progress count")

	select {
	case longErr := <-longDone:
		t.Fatalf("the 4s Stop returned %v while the worker was still wedged", longErr)
	default:
	}

	embedder.releaseAll()
	select {
	case longErr := <-longDone:
		require.NoError(t, longErr, "the 4s Stop should return nil once the wedged worker exits")
	case <-time.After(5 * time.Second):
		t.Fatal("the 4s Stop never returned after the wedged stage was released")
	}

	status, err := f.pipeline.GetFileStatus(wedged.ID)
	require.NoError(t, err)
	assert.Contains(t, []string{"completed", "failed"}, status.Status,
		"the wedged file should settle once its worker exits")
	settled, err := f.mgr.GetStore(store.ID)
	require.NoError(t, err)
	assert.Equal(t, 0, settled.FileCounts.InProgress, "nothing should stay in progress after the stop finished")
	assert.Equal(t, 1, settled.FileCounts.Total, "the store's total should be unchanged")
	assert.Equal(t, 1, settled.FileCounts.Completed+settled.FileCounts.Failed,
		"completed plus failed should equal the total")
}

// Stop and Start are cycled 100 times on one pipeline while four goroutines keep
// attaching files to two stores. Every Stop returns nil and every Start
// returns. Once attaching ends and the pipeline is stopped, every file whose
// AttachFile returned no error reads 'completed' or 'failed', and each store's
// counts match those files: Total equals its accepted attaches, InProgress is
// zero, and Completed and Failed equal the files in each state.
func TestVerifyRepeatedCyclesWithConcurrentAttachesLoseNoFiles(t *testing.T) {
	f := vrfNewFixture(t, &vrfPacedEmbedder{dim: 3, pause: time.Millisecond}, vs.NewMemoryMetadataRegistry(), 2)
	t.Cleanup(func() {
		_ = f.pipeline.Stop(context.Background())
		_ = os.RemoveAll(f.tempDir)
	})

	storeA, err := f.mgr.CreateStore(f.ctx, vs.CreateStoreRequest{Name: "cycles-a"})
	require.NoError(t, err)
	storeB, err := f.mgr.CreateStore(f.ctx, vs.CreateStoreRequest{Name: "cycles-b"})
	require.NoError(t, err)
	storeIDs := []string{storeA.ID, storeB.ID}

	var (
		mu       sync.Mutex
		accepted = map[string][]string{}
		stopAll  = make(chan struct{})
		attachWG sync.WaitGroup
	)
	for g := 0; g < 4; g++ {
		record, saveErr := f.store.Save(fmt.Sprintf("cycle-%d.txt", g), []byte("cycle content"), "assistants")
		require.NoError(t, saveErr)
		attachWG.Add(1)
		go func(g int, fileID string) {
			defer attachWG.Done()
			for i := 0; ; i++ {
				select {
				case <-stopAll:
					return
				default:
				}
				storeID := storeIDs[(g+i)%2]
				vsf, attachErr := f.pipeline.AttachFile(storeID, fileID, nil)
				if attachErr != nil {
					continue
				}
				mu.Lock()
				accepted[storeID] = append(accepted[storeID], vsf.ID)
				mu.Unlock()
			}
		}(g, record.ID)
	}

	for cycle := 0; cycle < 100; cycle++ {
		time.Sleep(4 * time.Millisecond)
		stopCtx, stopCancel := context.WithTimeout(context.Background(), 5*time.Second)
		res := vrfRunStopBounded(f.pipeline, stopCtx, 6*time.Second)
		stopCancel()
		require.True(t, res.returned, "Stop in cycle %d did not return", cycle)
		require.NoError(t, res.err, "Stop in cycle %d should return nil with no wedged worker", cycle)

		started := make(chan struct{})
		go func() {
			f.pipeline.Start()
			close(started)
		}()
		select {
		case <-started:
		case <-time.After(5 * time.Second):
			t.Fatalf("Start in cycle %d never returned", cycle)
		}
	}
	time.Sleep(4 * time.Millisecond)
	close(stopAll)
	attachWG.Wait()

	finalCtx, finalCancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer finalCancel()
	final := vrfRunStopBounded(f.pipeline, finalCtx, 6*time.Second)
	require.True(t, final.returned, "the final Stop did not return")
	require.NoError(t, final.err, "the final Stop should return nil")

	total := 0
	for _, storeID := range storeIDs {
		ids := accepted[storeID]
		total += len(ids)
		completed, failed := 0, 0
		for _, id := range ids {
			status, statusErr := f.pipeline.GetFileStatus(id)
			require.NoError(t, statusErr, "an accepted file has no status")
			switch status.Status {
			case "completed":
				completed++
			case "failed":
				failed++
			default:
				t.Errorf("accepted file %s still reads %q after the pipeline stopped", id, status.Status)
			}
		}
		got, getErr := f.mgr.GetStore(storeID)
		require.NoError(t, getErr)
		assert.Equal(t, len(ids), got.FileCounts.Total, "store %s total should equal its accepted attaches", storeID)
		assert.Equal(t, 0, got.FileCounts.InProgress, "store %s should have nothing in progress", storeID)
		assert.Equal(t, completed, got.FileCounts.Completed, "store %s completed count should match its completed files", storeID)
		assert.Equal(t, failed, got.FileCounts.Failed, "store %s failed count should match its failed files", storeID)
	}
	require.Greater(t, total, 0, "no AttachFile was accepted across the cycles")
}
