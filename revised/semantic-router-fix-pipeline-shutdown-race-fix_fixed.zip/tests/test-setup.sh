#!/usr/bin/env bash
# Environment bootstrap for the verifier.
#
# The focused tests live in src/semantic-router/pkg/{vectorstore,routerruntime}
# and link three CPU-only Rust FFI libraries via cgo: candle-binding
# (candle_semantic_router), ml-binding (ml_semantic_router) and nlp-binding
# (nlp_binding). The image already built all three at the task base commit and
# warmed the Go module + test compile, so the no-network work session needs
# nothing here. This script only re-exports the link/runtime paths and verifies
# the baked artifacts are present; it has a logged online fallback that runs only
# if a prebuilt library is missing.
#
# Sourced (not exec'd) by the harbor runner so env vars set here stay live for
# the verifier subprocess.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/semantic-router}"
export REPO_DIR
MODULE_DIR="$REPO_DIR/src/semantic-router"
CANDLE_REL="$REPO_DIR/candle-binding/target/release"
ML_REL="$REPO_DIR/ml-binding/target/release"
NLP_REL="$REPO_DIR/nlp-binding/target/release"

export CGO_ENABLED=1
export CGO_LDFLAGS="-L${CANDLE_REL} -L${ML_REL} -L${NLP_REL}"
export LD_LIBRARY_PATH="${CANDLE_REL}:${ML_REL}:${NLP_REL}${LD_LIBRARY_PATH:+:${LD_LIBRARY_PATH}}"
# The lifecycle tests use in-memory backends only; skip the service-backed suites.
export SR_TEST_MODE=true
export SKIP_MILVUS_TESTS=true SKIP_QDRANT_TESTS=true SKIP_REDIS_TESTS=true SKIP_VALKEY_TESTS=true

cd "$MODULE_DIR"

# Offline-first: the three FFI libraries must already be baked. If they are (the
# expected case), do nothing online. Only if one is missing do we rebuild it,
# logging the fallback loudly so a silent network dependency cannot hide.
rebuild_if_missing() {
    local dir="$1" lib="$2" flags="$3"
    if ls "${dir}"/lib"${lib}".* >/dev/null 2>&1; then
        echo "test-setup.sh: FFI library ${lib} present (offline path)."
    else
        echo "test-setup.sh: WARNING FFI library ${lib} missing at ${dir}; rebuilding (online fallback)." >&2
        ( cd "${dir%/target/release}" && cargo build --release ${flags} )
    fi
}
rebuild_if_missing "$CANDLE_REL" candle_semantic_router "--no-default-features"
rebuild_if_missing "$ML_REL" ml_semantic_router ""
rebuild_if_missing "$NLP_REL" nlp_binding ""

# Sanity check: the verifier packages must compile against the baked caches.
if ! go vet ./pkg/vectorstore/ ./pkg/routerruntime/ >/dev/null 2>&1; then
    echo "test-setup.sh: 'go vet ./pkg/{vectorstore,routerruntime}' reported issues (continuing; the verifier compile decides)." >&2
fi

echo "test-setup.sh: ready. MODULE_DIR=$MODULE_DIR go=$(go version 2>/dev/null | awk '{print $3}') ffi=${CANDLE_REL}:${ML_REL}:${NLP_REL}"
