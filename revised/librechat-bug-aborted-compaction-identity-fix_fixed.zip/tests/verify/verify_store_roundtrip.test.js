/**
 * The compaction marker survives a reload of the job through the store.
 *
 * The stop path reads the job back from the job store. On a Redis deployment
 * that read goes through the Redis store's serialize and deserialize, so this
 * test runs the same controller start and abort-route stop as the content test
 * over a job store whose every read is passed through RedisJobStore's own
 * serialize and deserialize. The compaction check reads only the saved
 * response row: it still carries the compaction marker and offers no usable or
 * finished-looking summary. The ordinary checks run a generation that is not a
 * compaction through the same store: its saved row comes back exactly as it
 * streamed, with no marker, no failed flag and no error part, and its user row
 * is still written. No stored field is read by name, and the row may be stamped
 * in the library or in the route.
 */
const express = require('express');
const request = require('supertest');
const { ContentTypes, isUserInitiatedCompaction } = require('librechat-data-provider');

const mockSaveMessage = jest.fn(async (_ctx, m) => m);

jest.mock('@librechat/data-schemas', () => {
  const actual = jest.requireActual('@librechat/data-schemas');
  return {
    ...actual,
    logger: { debug: jest.fn(), info: jest.fn(), warn: jest.fn(), error: jest.fn() },
  };
});

jest.mock('@librechat/api', () => {
  const actual = jest.requireActual('@librechat/api');
  return {
    ...actual,
    isEnabled: jest.fn().mockReturnValue(false),
    isAgentTriggerRequest: jest.fn(() => false),
    captureScheduleFireContext: jest.fn((req) => {
      req._isScheduledFire = false;
      req._isManualScheduledFire = false;
    }),
    checkAndIncrementPendingRequest: jest.fn().mockResolvedValue({ allowed: true }),
    decrementPendingRequest: jest.fn(),
  };
});

jest.mock('~/models', () => {
  const actual = jest.requireActual('~/models');
  return {
    ...actual,
    initializeMessageBudget: jest.fn(),
    saveMessage: (...args) => mockSaveMessage(...args),
    getPersistedPrivateTextId: jest.fn().mockResolvedValue(null),
    getPrivateMessageTexts: jest.fn().mockResolvedValue([]),
    saveConvo: jest.fn().mockResolvedValue({}),
    getConvo: jest.fn().mockResolvedValue(null),
    getMessages: jest.fn().mockResolvedValue([]),
    isAgentTriggerPrincipalActive: jest.fn().mockReturnValue(true),
    isSubagentOwnerAdmissible: jest.fn().mockReturnValue(true),
  };
});

jest.mock('~/server/cleanup', () => ({ disposeClient: jest.fn() }));
jest.mock('~/server/services/MCPRequestContext', () => ({
  getMCPRequestContext: jest.fn().mockResolvedValue(null),
  cleanupMCPRequestContextForReq: jest.fn(),
}));
jest.mock('~/server/services/Schedules', () => ({
  recordScheduleOutcome: jest.fn().mockResolvedValue(true),
  beginScheduledStop: jest.fn().mockResolvedValue(true),
  acknowledgeScheduledStopPersistence: jest.fn().mockResolvedValue(undefined),
  isScheduleLive: jest.fn().mockReturnValue(false),
}));
jest.mock('~/server/middleware', () => ({
  uaParser: (q, s, n) => n(),
  checkBan: (q, s, n) => n(),
  requireJwtAuth: (q, s, n) => {
    q.user = { id: 'u-ok' };
    n();
  },
  moderateText: (q, s, n) => n(),
  agentEventUserLimiter: (q, s, n) => n(),
  messageIpLimiter: (q, s, n) => n(),
  configMiddleware: (q, s, n) => n(),
  messageUserLimiter: (q, s, n) => n(),
}));
jest.mock('~/server/routes/agents/chat', () => require('express').Router());
jest.mock('~/server/routes/agents/v1', () => ({ v1: require('express').Router() }));
jest.mock('~/server/routes/agents/management', () => require('express').Router());

const {
  GenerationJobManager,
  InMemoryJobStore,
  InMemoryEventTransport,
  RedisJobStore,
  isUsableSummaryPart,
} = require('@librechat/api');
const ResumableAgentController = require('~/server/controllers/agents/request');
const agentRoutes = require('~/server/routes/agents/index');

/**
 * A job store that keeps jobs in memory but passes every read through the
 * Redis store's own serialize and deserialize, the round trip a Redis
 * deployment performs, so the test tracks whatever fields that store carries.
 */
function makeRoundTripStore() {
  const base = new InMemoryJobStore();
  let redis;
  try {
    redis = new RedisJobStore({ isCluster: false });
  } catch (e) {
    redis = null;
  }
  const origGetJob = base.getJob.bind(base);
  base.getJob = async (streamId) => {
    const job = await origGetJob(streamId);
    if (!job || !redis) {
      return job;
    }
    const serialized = redis['serializeJob'](job);
    // The reloaded job is only what deserialize rebuilds from the wire form;
    // nothing from the live object comes back.
    return redis['deserializeJob'](serialized);
  };
  return base;
}

function makeRes() {
  return {
    headersSent: false,
    statusCode: 200,
    status: jest.fn(function (c) {
      this.statusCode = c;
      return this;
    }),
    json: jest.fn(function () {
      return this;
    }),
    end: jest.fn(function () {
      return this;
    }),
    write: jest.fn(() => true),
    setHeader: jest.fn(),
    flushHeaders: jest.fn(),
    on: jest.fn(),
    removeListener: jest.fn(),
  };
}

/**
 * Start a real generation (a compaction when `compact` is set) and, while it is
 * live, stop it with a real POST to the abort route. The job store is the
 * round-trip store, so the abort path reads the reloaded job. Returns the
 * persisted response row and every saved row off the `saveMessage` spy.
 */
async function stopAndCapture({ app, compact, content, conversationId, parentMessageId }) {
  let abortResp;
  const req = {
    body: {
      text: '',
      ...(compact ? { compact: true } : {}),
      conversationId,
      parentMessageId,
      endpointOption: { endpoint: 'agents', modelOptions: { model: 'gpt-4.1' } },
    },
    config: { summarization: { enabled: true } },
    user: { id: 'u-ok' },
    on: jest.fn(),
    app: { locals: {} },
  };
  const initializeClient = async () => {
    GenerationJobManager.setContentParts(conversationId, content);
    abortResp = await request(app)
      .post('/api/agents/chat/abort')
      .set('X-LibreChat-Generation-Protocol', '2')
      .send({ conversationId, generationProtocolVersion: 2 });
    const stop = new Error('__stop__');
    stop.__stop = true;
    throw stop;
  };
  try {
    await ResumableAgentController(req, makeRes(), jest.fn(), initializeClient, jest.fn());
  } catch (e) {
    if (!e.__stop) {
      throw e;
    }
  }
  const saved = mockSaveMessage.mock.calls.map((c) => c[1]);
  const responseRow = saved.find((m) => m.isCreatedByUser === false);
  return { resp: abortResp, responseRow, saved };
}

describe('stopped generation after a job-store round trip', () => {
  let app;
  let store;
  beforeAll(() => {
    app = express();
    app.use(express.json());
    app.use('/api/agents', agentRoutes);
  });
  beforeEach(() => {
    mockSaveMessage.mockClear();
    store = makeRoundTripStore();
    GenerationJobManager.configure({
      jobStore: store,
      eventTransport: new InMemoryEventTransport(),
      isRedis: false,
      cleanupOnComplete: false,
    });
    GenerationJobManager.initialize();
  });
  afterEach(async () => {
    await GenerationJobManager.destroy();
  });

  // After the job is read back through the Redis serialize/deserialize, the
  // stopped compaction's row is still the compaction's own, and its cut-off
  // summary is either dropped or flagged failed.
  it('still stamps the stopped turn after the job reloads through the store', async () => {
    const partialSummary = {
      type: ContentTypes.SUMMARY,
      content: [{ type: ContentTypes.TEXT, text: 'Half a summary' }],
      summarizing: true,
    };
    const { resp, responseRow } = await stopAndCapture({
      app,
      compact: true,
      conversationId: '11111111-1111-4111-8111-111111111111',
      parentMessageId: '22222222-2222-4222-8222-222222222222',
      content: [partialSummary],
    });

    expect(resp.status).toBe(200);
    expect(responseRow).toBeDefined();
    expect(isUserInitiatedCompaction(responseRow)).toBe(true);
    expect(responseRow.content.every((p) => !isUsableSummaryPart(p))).toBe(true);
    expect(
      responseRow.content.every(
        (p) => p.type !== ContentTypes.SUMMARY || isUsableSummaryPart(p) || p.failed === true,
      ),
    ).toBe(true);
  });

  // A generation that is not a compaction, read back through the same store:
  // the reloaded job must not come back looking like a compaction, so the saved
  // row is exactly what streamed and the user row is still written first.
  it.each([
    {
      name: 'text only',
      content: [{ type: ContentTypes.TEXT, text: 'Partial answer after reload' }],
      conversationId: '33333333-3333-4333-8333-333333333333',
      parentMessageId: '44444444-4444-4444-8444-444444444444',
    },
    {
      name: 'automatic summary still streaming',
      content: [
        {
          type: ContentTypes.SUMMARY,
          content: [{ type: ContentTypes.TEXT, text: 'Summary of older turns, cut' }],
          summarizing: true,
        },
      ],
      conversationId: '55555555-5555-4555-8555-555555555555',
      parentMessageId: '66666666-6666-4666-8666-666666666666',
    },
  ])('leaves an ordinary stopped generation unchanged after the reload ($name)', async (c) => {
    const expected = JSON.parse(JSON.stringify(c.content));
    const { resp, responseRow, saved } = await stopAndCapture({
      app,
      compact: false,
      content: c.content,
      conversationId: c.conversationId,
      parentMessageId: c.parentMessageId,
    });

    expect(resp.status).toBe(200);
    expect(responseRow).toBeDefined();
    expect(responseRow.content).toEqual(expected);
    expect(isUserInitiatedCompaction(responseRow)).toBe(false);
    expect(responseRow.content.every((p) => p.initiatedBy == null)).toBe(true);
    expect(responseRow.content.every((p) => p.failed == null)).toBe(true);
    expect(responseRow.content.some((p) => p.type === ContentTypes.ERROR)).toBe(false);
    const userRow = saved.find((m) => m.isCreatedByUser === true);
    expect(userRow).toBeDefined();
    expect(responseRow.parentMessageId).toBe(userRow.messageId);
  });
});
