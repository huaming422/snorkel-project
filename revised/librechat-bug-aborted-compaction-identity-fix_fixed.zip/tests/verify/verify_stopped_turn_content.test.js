/**
 * Terminal stop of a manual compaction: the content of the turn the stop saves.
 *
 * A real agent generation is started through the request controller with
 * `req.body.compact`, and while that job is live a real HTTP POST to the abort
 * route stops it. The saved response row is read off a `saveMessage` spy, so
 * the checks look only at the stored row, never at where it was stamped.
 *
 * The row is read the way the client reads it:
 * - `isUserInitiatedCompaction` decides whether the turn is the compaction's
 *   own (Compact controls) or a reply to its parent (Regenerate).
 * - `isUsableSummaryPart` decides whether a summary bounds history.
 * - a summary that is neither usable nor `failed` is labeled as a finished
 *   compaction once the stream is over, so a cut-off summary has to be dropped
 *   or flagged `failed`.
 */
const express = require('express');
const request = require('supertest');
const { ContentTypes, isUserInitiatedCompaction } = require('librechat-data-provider');

const mockSaveMessage = jest.fn(async (_ctx, m) => m);

jest.mock('@librechat/data-schemas', () => {
  const actual = jest.requireActual('@librechat/data-schemas');
  return {
    ...actual,
    logger: { debug: jest.fn(), info: jest.fn(), warn: jest.fn(), error: jest.fn() },
  };
});

jest.mock('@librechat/api', () => {
  const actual = jest.requireActual('@librechat/api');
  return {
    ...actual,
    isEnabled: jest.fn().mockReturnValue(false),
    isAgentTriggerRequest: jest.fn(() => false),
    captureScheduleFireContext: jest.fn((req) => {
      req._isScheduledFire = false;
      req._isManualScheduledFire = false;
    }),
    checkAndIncrementPendingRequest: jest.fn().mockResolvedValue({ allowed: true }),
    decrementPendingRequest: jest.fn(),
  };
});

jest.mock('~/models', () => {
  const actual = jest.requireActual('~/models');
  return {
    ...actual,
    initializeMessageBudget: jest.fn(),
    saveMessage: (...args) => mockSaveMessage(...args),
    getPersistedPrivateTextId: jest.fn().mockResolvedValue(null),
    getPrivateMessageTexts: jest.fn().mockResolvedValue([]),
    saveConvo: jest.fn().mockResolvedValue({}),
    getConvo: jest.fn().mockResolvedValue(null),
    getMessages: jest.fn().mockResolvedValue([]),
    isAgentTriggerPrincipalActive: jest.fn().mockReturnValue(true),
    isSubagentOwnerAdmissible: jest.fn().mockReturnValue(true),
  };
});

jest.mock('~/server/cleanup', () => ({ disposeClient: jest.fn() }));
jest.mock('~/server/services/MCPRequestContext', () => ({
  getMCPRequestContext: jest.fn().mockResolvedValue(null),
  cleanupMCPRequestContextForReq: jest.fn(),
}));
jest.mock('~/server/services/Schedules', () => ({
  recordScheduleOutcome: jest.fn().mockResolvedValue(true),
  beginScheduledStop: jest.fn().mockResolvedValue(true),
  acknowledgeScheduledStopPersistence: jest.fn().mockResolvedValue(undefined),
  isScheduleLive: jest.fn().mockReturnValue(false),
}));
jest.mock('~/server/middleware', () => ({
  uaParser: (q, s, n) => n(),
  checkBan: (q, s, n) => n(),
  requireJwtAuth: (q, s, n) => {
    q.user = { id: 'u-ok' };
    n();
  },
  moderateText: (q, s, n) => n(),
  agentEventUserLimiter: (q, s, n) => n(),
  messageIpLimiter: (q, s, n) => n(),
  configMiddleware: (q, s, n) => n(),
  messageUserLimiter: (q, s, n) => n(),
}));
jest.mock('~/server/routes/agents/chat', () => require('express').Router());
jest.mock('~/server/routes/agents/v1', () => ({ v1: require('express').Router() }));
jest.mock('~/server/routes/agents/management', () => require('express').Router());

const {
  GenerationJobManager,
  InMemoryJobStore,
  InMemoryEventTransport,
  isUsableSummaryPart,
} = require('@librechat/api');
const ResumableAgentController = require('~/server/controllers/agents/request');
const agentRoutes = require('~/server/routes/agents/index');

function makeRes() {
  return {
    headersSent: false,
    statusCode: 200,
    status: jest.fn(function (c) {
      this.statusCode = c;
      return this;
    }),
    json: jest.fn(function () {
      return this;
    }),
    end: jest.fn(function () {
      return this;
    }),
    write: jest.fn(() => true),
    setHeader: jest.fn(),
    flushHeaders: jest.fn(),
    on: jest.fn(),
    removeListener: jest.fn(),
  };
}

/**
 * Start a real generation through the controller and, while it is live, stop it
 * with a real POST to the abort route. Returns the abort response plus the
 * persisted response row (the unfinished assistant row the route writes), read
 * off the `saveMessage` spy.
 * @returns {Promise<{resp: object, responseRow: object|undefined}>}
 */
async function stopAndCapture({ app, compact, content, conversationId, parentMessageId, extraBody }) {
  let abortResp;
  const req = {
    body: {
      text: '',
      ...(compact ? { compact: true } : {}),
      ...extraBody,
      conversationId,
      parentMessageId,
      endpointOption: { endpoint: 'agents', modelOptions: { model: 'gpt-4.1' } },
    },
    config: { summarization: { enabled: true } },
    user: { id: 'u-ok' },
    on: jest.fn(),
    app: { locals: {} },
  };
  const initializeClient = async () => {
    GenerationJobManager.setContentParts(conversationId, content);
    abortResp = await request(app)
      .post('/api/agents/chat/abort')
      .set('X-LibreChat-Generation-Protocol', '2')
      .send({ conversationId, generationProtocolVersion: 2 });
    const stop = new Error('__stop__');
    stop.__stop = true;
    throw stop;
  };
  try {
    await ResumableAgentController(req, makeRes(), jest.fn(), initializeClient, jest.fn());
  } catch (e) {
    if (!e.__stop) {
      throw e;
    }
  }
  const saved = mockSaveMessage.mock.calls.map((c) => c[1]);
  const responseRow = saved.find((m) => m.isCreatedByUser === false);
  return { resp: abortResp, responseRow };
}

/** True when no summary in the content would be shown as a finished
 *  compaction without being one: each is either usable or flagged failed. */
function noCutOffSummaryShownAsDone(content) {
  return content.every(
    (p) => p.type !== ContentTypes.SUMMARY || isUsableSummaryPart(p) || p.failed === true,
  );
}

describe('stopped compaction: saved turn content', () => {
  let app;
  beforeAll(() => {
    app = express();
    app.use(express.json());
    app.use('/api/agents', agentRoutes);
  });
  beforeEach(() => {
    mockSaveMessage.mockClear();
    GenerationJobManager.configure({
      jobStore: new InMemoryJobStore(),
      eventTransport: new InMemoryEventTransport(),
      isRedis: false,
      cleanupOnComplete: false,
    });
    GenerationJobManager.initialize();
  });
  afterEach(async () => {
    await GenerationJobManager.destroy();
  });

  // A cut-off summary: the row is the compaction's own, and the truncated text
  // is either dropped or flagged failed. Both shapes are accepted.
  it('settles a partial summary as the compaction turn with no usable checkpoint', async () => {
    const partialSummary = {
      type: ContentTypes.SUMMARY,
      content: [{ type: ContentTypes.TEXT, text: 'Half a summary' }],
      summarizing: true,
    };
    const { resp, responseRow } = await stopAndCapture({
      app,
      compact: true,
      content: [partialSummary],
      conversationId: '11111111-1111-4111-8111-111111111111',
      parentMessageId: '22222222-2222-4222-8222-222222222222',
    });

    expect(resp.status).toBe(200);
    expect(responseRow).toBeDefined();
    expect(isUserInitiatedCompaction(responseRow)).toBe(true);
    expect(responseRow.content.every((p) => !isUsableSummaryPart(p))).toBe(true);
    expect(noCutOffSummaryShownAsDone(responseRow.content)).toBe(true);
  });

  // A summary block that opened but never streamed text: the row is the
  // compaction's own, with no summary shown as finished.
  it('settles an empty placeholder as the compaction turn with no usable checkpoint', async () => {
    const { resp, responseRow } = await stopAndCapture({
      app,
      compact: true,
      content: [{ type: ContentTypes.SUMMARY, content: [], summarizing: true }],
      conversationId: '33333333-3333-4333-8333-333333333333',
      parentMessageId: '44444444-4444-4444-8444-444444444444',
    });

    expect(resp.status).toBe(200);
    expect(responseRow).toBeDefined();
    expect(isUserInitiatedCompaction(responseRow)).toBe(true);
    expect(responseRow.content.every((p) => !isUsableSummaryPart(p))).toBe(true);
    expect(noCutOffSummaryShownAsDone(responseRow.content)).toBe(true);
  });

  // Only a reasoning part streamed, with no summary and no error: the row is
  // still the compaction's own. The reasoning part may be kept or dropped.
  it('settles a run that streamed no outcome as the compaction turn with no usable checkpoint', async () => {
    const thinking = { type: 'think', think: 'planning what to summarize' };
    const { resp, responseRow } = await stopAndCapture({
      app,
      compact: true,
      content: [thinking],
      conversationId: '55555555-5555-4555-8555-555555555555',
      parentMessageId: '66666666-6666-4666-8666-666666666666',
    });

    expect(resp.status).toBe(200);
    expect(responseRow).toBeDefined();
    expect(isUserInitiatedCompaction(responseRow)).toBe(true);
    expect(responseRow.content.every((p) => !isUsableSummaryPart(p))).toBe(true);
    expect(noCutOffSummaryShownAsDone(responseRow.content)).toBe(true);
  });

  // A summary that finished before the stop landed stays a usable checkpoint
  // owned by the compaction, and is not flagged failed.
  it('keeps a finished summary as a real checkpoint', async () => {
    const usableSummary = {
      type: ContentTypes.SUMMARY,
      content: [{ type: ContentTypes.TEXT, text: 'A complete and usable summary.' }],
      boundary: { messageId: 'step_summary', contentIndex: 0 },
    };
    const { resp, responseRow } = await stopAndCapture({
      app,
      compact: true,
      content: [usableSummary],
      conversationId: '77777777-7777-4777-8777-777777777777',
      parentMessageId: '88888888-8888-4888-8888-888888888888',
    });

    expect(resp.status).toBe(200);
    expect(responseRow).toBeDefined();
    expect(isUserInitiatedCompaction(responseRow)).toBe(true);
    expect(responseRow.content.some((p) => isUsableSummaryPart(p))).toBe(true);
  });

  // An ordinary stop saves exactly what streamed: no compaction marker, no
  // failure flag and no error part. The automatic-summary cases carry summary
  // parts the run wrote on its own, which must stay unmarked. The regenerate
  // case reruns a reply under a user message with no text, which records the
  // same empty-text anchor shape a compaction does.
  it.each([
    {
      name: 'text only',
      content: [{ type: ContentTypes.TEXT, text: 'Partial answer' }],
      conversationId: '99999999-9999-4999-8999-999999999999',
      parentMessageId: 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',
    },
    {
      name: 'finished automatic summary then text',
      content: [
        {
          type: ContentTypes.SUMMARY,
          content: [{ type: ContentTypes.TEXT, text: 'Earlier turns, summarized on the fly.' }],
          boundary: { messageId: 'step_auto_summary', contentIndex: 0 },
        },
        { type: ContentTypes.TEXT, text: 'Answer after the summary' },
      ],
      conversationId: 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb',
      parentMessageId: 'cccccccc-cccc-4ccc-8ccc-cccccccccccc',
    },
    {
      name: 'automatic summary still streaming',
      content: [
        {
          type: ContentTypes.SUMMARY,
          content: [{ type: ContentTypes.TEXT, text: 'Summary in prog' }],
          summarizing: true,
        },
      ],
      conversationId: 'dddddddd-dddd-4ddd-8ddd-dddddddddddd',
      parentMessageId: 'eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee',
    },
    {
      name: 'regenerate with an automatic summary',
      content: [
        {
          type: ContentTypes.SUMMARY,
          content: [{ type: ContentTypes.TEXT, text: 'History up to the attachment.' }],
          boundary: { messageId: 'step_regen_summary', contentIndex: 0 },
        },
        { type: ContentTypes.TEXT, text: 'Second try at the answer' },
      ],
      conversationId: 'fafafafa-fafa-4afa-8afa-fafafafafafa',
      parentMessageId: 'abababab-abab-4bab-8bab-abababababab',
      extraBody: {
        isRegenerate: true,
        overrideParentMessageId: 'cdcdcdcd-cdcd-4dcd-8dcd-cdcdcdcdcdcd',
      },
    },
  ])('leaves an ordinary stopped generation unchanged ($name)', async (c) => {
    const expected = JSON.parse(JSON.stringify(c.content));
    const { resp, responseRow } = await stopAndCapture({
      app,
      compact: false,
      content: c.content,
      conversationId: c.conversationId,
      parentMessageId: c.parentMessageId,
      extraBody: c.extraBody,
    });

    expect(resp.status).toBe(200);
    expect(responseRow).toBeDefined();
    expect(responseRow.content).toEqual(expected);
    expect(isUserInitiatedCompaction(responseRow)).toBe(false);
    expect(responseRow.content.every((p) => p.initiatedBy == null)).toBe(true);
    expect(responseRow.content.every((p) => p.failed == null)).toBe(true);
    expect(responseRow.content.some((p) => p.type === ContentTypes.ERROR)).toBe(false);
  });
});
