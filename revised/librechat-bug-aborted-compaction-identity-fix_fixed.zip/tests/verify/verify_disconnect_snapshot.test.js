/**
 * The disconnect snapshot: the row the controller saves when every subscriber
 * leaves while the run may still be live. The completing run can still
 * overwrite it, so a compaction snapshot carries the compaction marker on what
 * streamed but adds no error part and flags no summary failed. An ordinary
 * snapshot is saved exactly as it streamed.
 *
 * The real request controller records `req.body.compact` and registers the
 * disconnect handler. The job manager is stubbed only to hand back that handler
 * and a resume state; the saved row is read off a `saveMessage` spy, and the
 * marker is read with the client's own `isUserInitiatedCompaction`.
 */
const { ContentTypes, isUserInitiatedCompaction } = require('librechat-data-provider');

const mockSaveMessage = jest.fn(async () => ({ _id: 'saved' }));

const mockGenerationJobManager = {
  createJob: jest.fn(),
  emitError: jest.fn().mockResolvedValue(undefined),
  completeJob: jest.fn().mockResolvedValue(undefined),
  beginProviderExecution: jest.fn().mockResolvedValue(true),
  markProviderExecutionDrained: jest.fn().mockResolvedValue(true),
  getResumeState: jest.fn(),
  getJobStore: jest.fn(),
  updateMetadata: jest.fn().mockResolvedValue(undefined),
  setContentParts: jest.fn(),
  claimGeneration: jest.fn().mockResolvedValue({ claimed: true }),
  releaseGeneration: jest.fn().mockResolvedValue(undefined),
  hasJob: jest.fn().mockResolvedValue(true),
  steering: {
    closeAndDrain: jest.fn().mockResolvedValue([]),
    park: jest.fn().mockResolvedValue(undefined),
  },
};

jest.mock('@librechat/data-schemas', () => {
  const actual = jest.requireActual('@librechat/data-schemas');
  return {
    ...actual,
    logger: { debug: jest.fn(), info: jest.fn(), warn: jest.fn(), error: jest.fn() },
  };
});

jest.mock('@librechat/api', () => {
  const actual = jest.requireActual('@librechat/api');
  return {
    ...actual,
    GenerationJobManager: mockGenerationJobManager,
    checkAndIncrementPendingRequest: jest.fn().mockResolvedValue({ allowed: true }),
    decrementPendingRequest: jest.fn(),
  };
});

jest.mock('~/models', () => {
  const actual = jest.requireActual('~/models');
  return {
    ...actual,
    initializeMessageBudget: jest.fn(),
    saveMessage: (...args) => mockSaveMessage(...args),
    saveConvo: jest.fn().mockResolvedValue({}),
    getConvo: jest.fn().mockResolvedValue({ createdAt: '2026-07-31T00:00:00.000Z' }),
    getMessages: jest.fn().mockResolvedValue([]),
    isAgentTriggerPrincipalActive: jest.fn().mockReturnValue(true),
    isSubagentOwnerAdmissible: jest.fn().mockReturnValue(true),
  };
});

jest.mock('~/server/cleanup', () => ({ disposeClient: jest.fn() }));
jest.mock('~/server/services/MCPRequestContext', () => ({
  getMCPRequestContext: jest.fn().mockResolvedValue(null),
  cleanupMCPRequestContextForReq: jest.fn(),
}));

const ResumableAgentController = require('~/server/controllers/agents/request');
const { isUsableSummaryPart } = require('@librechat/api');

function makeRes() {
  return {
    headersSent: true,
    statusCode: 200,
    status: jest.fn(function (c) {
      this.statusCode = c;
      return this;
    }),
    json: jest.fn(function () {
      return this;
    }),
    end: jest.fn(function () {
      return this;
    }),
    write: jest.fn(() => true),
    setHeader: jest.fn(),
    flushHeaders: jest.fn(),
    on: jest.fn(),
    removeListener: jest.fn(),
  };
}

/**
 * Start a generation, capture the disconnect (allSubscribersLeft) handler the
 * controller registers, then fire it with the content the run had aggregated.
 * Returns the row handed to saveMessage by the snapshot.
 */
async function snapshotOnDisconnect({ compact, aggregatedContent }) {
  mockSaveMessage.mockClear();
  const conversationId = '11111111-1111-4111-8111-111111111111';
  let handler;
  mockGenerationJobManager.getJobStore.mockReturnValue({
    getJob: jest.fn().mockResolvedValue({ createdAt: 1000 }),
  });
  mockGenerationJobManager.createJob.mockResolvedValue({
    createdAt: 1000,
    metadata: { providerExecutionId: 'seg-1', providerDrained: true },
    readyPromise: Promise.resolve(),
    abortController: new AbortController(),
    emitter: {
      on: jest.fn((event, h) => {
        if (event === 'allSubscribersLeft') {
          handler = h;
        }
      }),
    },
  });
  mockGenerationJobManager.getResumeState.mockResolvedValue({
    conversationId,
    responseMessageId: 'response-message',
    userMessage: { messageId: 'user-message' },
  });
  const req = {
    user: { id: 'u-ok' },
    body: {
      text: '',
      ...(compact ? { compact: true } : {}),
      messageId: 'user-message',
      parentMessageId: '22222222-2222-4222-8222-222222222222',
      conversationId,
      endpointOption: { endpoint: 'agents', modelOptions: { model: 'gpt-4.1' } },
    },
    config: { summarization: { enabled: true } },
    on: jest.fn(),
    app: { locals: {} },
  };
  const initializeClient = jest.fn().mockRejectedValue(new Error('stop after setup'));
  await ResumableAgentController(req, makeRes(), jest.fn(), initializeClient, null);
  if (typeof handler !== 'function') {
    throw new Error('disconnect handler was not registered');
  }
  await handler(aggregatedContent);
  return mockSaveMessage.mock.calls[0] && mockSaveMessage.mock.calls[0][1];
}

describe('disconnect snapshot: provisional row, no invented failure', () => {
  // A compaction snapshot with a partial summary is marked as the compaction's
  // own, with no error part and no summary flagged failed. The truncated text
  // may be kept or dropped; it is never offered as a usable checkpoint.
  it('marks a compaction partial summary as the compaction turn, without synthesizing a failure', async () => {
    const saved = await snapshotOnDisconnect({
      compact: true,
      aggregatedContent: [
        { type: ContentTypes.SUMMARY, content: [{ type: ContentTypes.TEXT, text: 'Half a summary' }], summarizing: true },
      ],
    });

    expect(saved).toBeDefined();
    expect(isUserInitiatedCompaction(saved)).toBe(true);
    expect(saved.content.some((p) => p.type === ContentTypes.ERROR)).toBe(false);
    for (const p of saved.content) {
      if (p.type === ContentTypes.SUMMARY) {
        expect(p.failed).not.toBe(true);
      }
    }
    expect(saved.content.every((p) => !isUsableSummaryPart(p))).toBe(true);
  });

  // A compaction snapshot with no summary and no error gets no error part and
  // no failed summary added.
  it('does not synthesize a failure for a compaction snapshot with no outcome', async () => {
    const thinking = { type: 'think', think: 'Picking what to summarize' };
    const saved = await snapshotOnDisconnect({
      compact: true,
      aggregatedContent: [thinking],
    });

    expect(saved).toBeDefined();
    expect(saved.content.some((p) => p.type === ContentTypes.ERROR)).toBe(false);
    expect(saved.content.some((p) => p.type === ContentTypes.SUMMARY && p.failed === true)).toBe(
      false,
    );
  });

  // An ordinary snapshot, with or without a summary the run wrote on its own,
  // is saved exactly as it streamed.
  it.each([
    { name: 'text only', content: [{ type: ContentTypes.TEXT, text: 'Partial response' }] },
    {
      name: 'automatic summary then text',
      content: [
        {
          type: ContentTypes.SUMMARY,
          content: [{ type: ContentTypes.TEXT, text: 'Older turns, summarized on the fly.' }],
          boundary: { messageId: 'step_auto_summary', contentIndex: 0 },
        },
        { type: ContentTypes.TEXT, text: 'Reply in progress' },
      ],
    },
    {
      name: 'automatic summary still streaming',
      content: [
        {
          type: ContentTypes.SUMMARY,
          content: [{ type: ContentTypes.TEXT, text: 'Summary in prog' }],
          summarizing: true,
        },
      ],
    },
  ])('leaves an ordinary (non-compaction) snapshot unchanged ($name)', async (c) => {
    const expected = JSON.parse(JSON.stringify(c.content));
    const saved = await snapshotOnDisconnect({
      compact: false,
      aggregatedContent: c.content,
    });

    expect(saved).toBeDefined();
    expect(saved.content).toEqual(expected);
    expect(isUserInitiatedCompaction(saved)).toBe(false);
    expect(saved.content.every((p) => !('initiatedBy' in p))).toBe(true);
    expect(saved.content.every((p) => p.failed == null)).toBe(true);
    expect(saved.content.some((p) => p.type === ContentTypes.ERROR)).toBe(false);
  });
});
