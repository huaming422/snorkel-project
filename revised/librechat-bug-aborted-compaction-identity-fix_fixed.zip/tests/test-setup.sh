#!/usr/bin/env bash
# Verifier-phase setup. Sourced (not exec'd) so exported vars survive into the
# Jest invocation. Idempotent. Runs with the model-gateway allowlist only, so
# every install is offline-first against the baked node_modules / npm cache.
set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/LibreChat}"
cd "$REPO_DIR"

node --version
npm --version

# The whole workspace was installed offline-first at the base commit during the
# image build. Replay only if node_modules is missing.
if [ ! -d "node_modules" ] || [ ! -d "packages/api/node_modules" ]; then
    echo "[test-setup] node_modules missing, replaying npm ci (offline)..."
    npm ci --no-audit --no-fund --offline 2>&1 | tail -20
fi

# packages/api's OWN Jest suite (src/agents/*.spec.ts, src/stream/__tests__/*)
# transforms TypeScript source directly through babel-jest (moduleNameMapper
# ~/ -> src), so edits under packages/api/src are picked up with no rebuild.
#
# The api workspace's controller/route Jest suites, however, import
# `@librechat/api` from its BUILT dist. Rebuild packages/api (and its workspace
# deps, which feed its build) so those suites see the current source. dist was
# built during the image build, so without this rebuild the controller tests
# would run against that older build.
echo "[test-setup] rebuilding workspace packages so dist matches the current source..."
npm run build:data-provider 2>&1 | tail -5
npm run build:data-schemas 2>&1 | tail -5
npm run build:api 2>&1 | tail -5

export PATH="$REPO_DIR/node_modules/.bin:$PATH"
export NODE_ENV=test

echo "[test-setup] ready: $REPO_DIR (node=$(node --version), npm=$(npm --version))"
