## Task

stopping a manual compaction partway through leaves a broken turn behind.

repro: open a conversation, hit Compact, and press stop while it's still summarizing.
the turn it leaves behind gets the hover and rerun controls of a normal reply.
if the branch ends on a user message you get "Regenerate", and clicking it answers that user message again instead of redoing the compaction.
reloading the page doesn't help, the saved row comes back with the same controls.

the stop also damages the message the compaction hung off.
a user message can come back with its text gone, and an assistant message can turn into an empty user row.

what I'd expect after a stop:

- the stopped turn shows up as the compaction's own turn, not as a reply to the message before it.
- that includes a stop that lands before any summary text has appeared (the model was still thinking, or the summary block had only just opened), which should show up as a failed compaction.
- a summary that got cut off isn't presented as if the compaction finished, so either drop it or show it as failed.
- if the summary had already finished right before the stop went through, it stays as a real compaction and isn't marked failed.
- the message the compaction hung off stays exactly as it was, and the stopped turn still hangs off it.

closing the tab in the middle of a compaction has the same problem.
as far as I can tell the server saves what it has once nobody is connected to the stream, and once some summary text has streamed that saved turn shows Regenerate too.
it should be marked as the compaction's turn as well, but without marking it failed or adding an error, because the compaction keeps running on the server and may still finish.

we run resumable streams on Redis with a few API replicas, so the stop request is often handled by a different instance than the one running the compaction.

compactions that finish on their own already show up correctly, this is only about stopping one.
stopping or closing the tab on a normal reply or a regenerate is fine today too, including one where the automatic summarization kicked in partway through, and that should keep working exactly as it does now.
