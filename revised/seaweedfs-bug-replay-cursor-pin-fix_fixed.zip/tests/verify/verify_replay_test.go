package dailyrun

// Daily-replay checks on buckets that mix short and long expiration rules.
// Each test runs one or two whole passes through Run, with a scripted filer
// stream as the change log, and looks only at what a caller can observe:
// which objects reached the delete client, which rule set the walker was
// handed, and where the saved cursor ended up.
//
// Helpers reused from sibling test files in this package: recordingClient /
// .seenObjects (process_matches_test.go), memPersister / newMemPersister
// (walker_recovery_test.go), stubSiblingLister (walker_interval_test.go),
// plus Cursor / Config / Run from the package itself.

import (
	"context"
	"io"
	"path"
	"strconv"
	"sync"
	"testing"
	"time"

	"github.com/seaweedfs/seaweedfs/weed/pb/filer_pb"
	"github.com/seaweedfs/seaweedfs/weed/s3api/s3lifecycle"
	"github.com/seaweedfs/seaweedfs/weed/s3api/s3lifecycle/engine"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"google.golang.org/grpc"
)

const vrBucketsPath = "/buckets"

// vrLogStream hands out a fixed list of change-log entries, then EOF, the
// way a filer ends a subscription bounded by UntilNs.
type vrLogStream struct {
	grpc.ClientStream
	entries []*filer_pb.SubscribeMetadataResponse
	next    int
}

func (s *vrLogStream) Recv() (*filer_pb.SubscribeMetadataResponse, error) {
	if s.next >= len(s.entries) {
		return nil, io.EOF
	}
	resp := s.entries[s.next]
	s.next++
	return resp, nil
}

// vrFiler serves the same change log to every subscription.
type vrFiler struct {
	filer_pb.SeaweedFilerClient
	entries []*filer_pb.SubscribeMetadataResponse
}

func (f *vrFiler) SubscribeMetadata(_ context.Context, _ *filer_pb.SubscribeMetadataRequest, _ ...grpc.CallOption) (filer_pb.SeaweedFiler_SubscribeMetadataClient, error) {
	return &vrLogStream{entries: f.entries}, nil
}

// vrPut builds a change-log PUT for bucket/key whose object was last
// modified at (runNow - age).
func vrPut(runNow time.Time, bucket, key string, age time.Duration) *filer_pb.SubscribeMetadataResponse {
	at := runNow.Add(-age)
	return &filer_pb.SubscribeMetadataResponse{
		TsNs: at.UnixNano(),
		EventNotification: &filer_pb.EventNotification{
			NewParentPath: path.Join(vrBucketsPath, bucket, path.Dir(key)),
			NewEntry: &filer_pb.Entry{
				Name:       path.Base(key),
				Attributes: &filer_pb.FuseAttributes{Mtime: at.Unix(), FileSize: 1},
			},
		},
	}
}

// vrKeys returns a generator of distinct object keys under a prefix that
// all land on shardID, so one shard's cursor sees every write in a test.
func vrKeys(t *testing.T, bucket string, shardID int) func(prefix string) string {
	n := 0
	return func(prefix string) string {
		t.Helper()
		for ; n < 100000; n++ {
			key := prefix + "o" + strconv.Itoa(n)
			if s3lifecycle.ShardID(bucket, key) == shardID {
				n++
				return key
			}
		}
		t.Fatalf("no key under %q lands on shard %d", prefix, shardID)
		return ""
	}
}

// vrSeedCursor saves a cursor whose rule-set and promoted hashes match the
// snapshot under the given retention, so the pass is a normal daily pass
// (no rule-change rewind, no first-run floor). startTsNs is where the pass
// starts reading.
func vrSeedCursor(t *testing.T, p *memPersister, snap *engine.Snapshot, shardID int, startTsNs int64, retention time.Duration, runNow time.Time) {
	t.Helper()
	require.NoError(t, p.Save(context.Background(), shardID, Cursor{
		TsNs:         startTsNs,
		RuleSetHash:  engine.ReplayContentHash(snap),
		PromotedHash: engine.PromotedHash(snap, retention),
		LastWalkedNs: runNow.UnixNano(),
	}))
}

// vrWalker records every view the walker is handed.
type vrWalker struct {
	mu    sync.Mutex
	views []*engine.Snapshot
}

func (w *vrWalker) walk(_ context.Context, view *engine.Snapshot, _ []int) error {
	w.mu.Lock()
	defer w.mu.Unlock()
	w.views = append(w.views, view)
	return nil
}

func (w *vrWalker) handedActive(key s3lifecycle.ActionKey) bool {
	w.mu.Lock()
	defer w.mu.Unlock()
	for _, v := range w.views {
		if v == nil {
			continue
		}
		if a := v.Action(key); a != nil && a.IsActive() {
			return true
		}
	}
	return false
}

// vrRun runs one pass and fails the test if it errors or does not return.
func vrRun(t *testing.T, cfg Config) {
	t.Helper()
	done := make(chan error, 1)
	go func() { done <- Run(context.Background(), cfg) }()
	select {
	case err := <-done:
		require.NoError(t, err)
	case <-time.After(30 * time.Second):
		t.Fatal("daily pass did not return")
	}
}

func vrConfig(e *engine.Engine, shardID int, log []*filer_pb.SubscribeMetadataResponse, client *recordingClient, p *memPersister, runNow time.Time) Config {
	return Config{
		Shards:      []int{shardID},
		BucketsPath: vrBucketsPath,
		Engine:      e,
		FilerClient: &vrFiler{entries: log},
		Client:      client,
		Persister:   p,
		Lister:      stubSiblingLister{},
		Now:         func() time.Time { return runNow },
	}
}

// TestVerify_CursorAdvancesPastLongRuleObject: a bucket has a 3-day and a
// 30-day expiration rule, and the change log keeps 8 days. A 30-day object
// written between two due 3-day objects must not hold the cursor: it ends on
// the last due 3-day PUT, both 3-day objects are deleted, and the 30-day
// object is not.
func TestVerify_CursorAdvancesPastLongRuleObject(t *testing.T) {
	bucket, shardID := "b1", 3
	shortRule := &s3lifecycle.Rule{ID: "short", Status: s3lifecycle.StatusEnabled, Prefix: "short/", ExpirationDays: 3}
	longRule := &s3lifecycle.Rule{ID: "long", Status: s3lifecycle.StatusEnabled, Prefix: "long/", ExpirationDays: 30}
	e := engine.New()
	e.Compile([]engine.CompileInput{{Bucket: bucket, Rules: []*s3lifecycle.Rule{shortRule, longRule}}},
		engine.CompileOptions{PriorStates: map[s3lifecycle.ActionKey]engine.PriorState{
			{Bucket: bucket, RuleHash: s3lifecycle.RuleHash(shortRule), ActionKind: s3lifecycle.ActionKindExpirationDays}: {BootstrapComplete: true},
			{Bucket: bucket, RuleHash: s3lifecycle.RuleHash(longRule), ActionKind: s3lifecycle.ActionKindExpirationDays}:  {BootstrapComplete: true},
		}})
	snap := e.Snapshot()
	for _, a := range snap.AllActions() {
		snap.MarkActive(a.Key)
	}

	runNow := time.Unix(1_700_000_000, 0).UTC()
	retention := s3lifecycle.DaysToDuration(8)
	p := newMemPersister()
	vrSeedCursor(t, p, snap, shardID, runNow.Add(-retention).UnixNano(), retention, runNow)

	key := vrKeys(t, bucket, shardID)
	shortA, longA, shortB := key("short/"), key("long/"), key("short/")
	last := vrPut(runNow, bucket, shortB, s3lifecycle.DaysToDuration(5))
	log := []*filer_pb.SubscribeMetadataResponse{
		vrPut(runNow, bucket, shortA, s3lifecycle.DaysToDuration(7)),
		vrPut(runNow, bucket, longA, s3lifecycle.DaysToDuration(6)),
		last,
	}

	client := &recordingClient{}
	walker := &vrWalker{}
	cfg := vrConfig(e, shardID, log, client, p, runNow)
	cfg.RetentionWindow = retention
	cfg.Walker = walker.walk
	vrRun(t, cfg)

	got, _, err := p.Load(context.Background(), shardID)
	require.NoError(t, err)
	assert.Equal(t, last.TsNs, got.TsNs,
		"cursor must end on the last due 3-day PUT, past the 30-day object")
	assert.ElementsMatch(t, []string{shortA, shortB}, client.seenObjects(),
		"both due 3-day objects are deleted; the 30-day object is not")
}

// TestVerify_LongAndDisabledRuleObjectsDoNotHoldCursor: same 3-day / 30-day
// mix plus a disabled 4-day rule. The 30-day object comes first in the log,
// then an object under the disabled rule, then a due 3-day object. The cursor
// ends on the 3-day PUT, and only the 3-day object is deleted.
func TestVerify_LongAndDisabledRuleObjectsDoNotHoldCursor(t *testing.T) {
	bucket, shardID := "b2", 11
	shortRule := &s3lifecycle.Rule{ID: "short", Status: s3lifecycle.StatusEnabled, Prefix: "short/", ExpirationDays: 3}
	longRule := &s3lifecycle.Rule{ID: "long", Status: s3lifecycle.StatusEnabled, Prefix: "long/", ExpirationDays: 30}
	offRule := &s3lifecycle.Rule{ID: "off", Status: s3lifecycle.StatusDisabled, Prefix: "off/", ExpirationDays: 4}
	e := engine.New()
	e.Compile([]engine.CompileInput{{Bucket: bucket, Rules: []*s3lifecycle.Rule{shortRule, longRule, offRule}}},
		engine.CompileOptions{PriorStates: map[s3lifecycle.ActionKey]engine.PriorState{
			{Bucket: bucket, RuleHash: s3lifecycle.RuleHash(shortRule), ActionKind: s3lifecycle.ActionKindExpirationDays}: {BootstrapComplete: true},
			{Bucket: bucket, RuleHash: s3lifecycle.RuleHash(longRule), ActionKind: s3lifecycle.ActionKindExpirationDays}:  {BootstrapComplete: true},
		}})
	snap := e.Snapshot()
	for _, a := range snap.AllActions() {
		snap.MarkActive(a.Key)
	}

	runNow := time.Unix(1_700_000_000, 0).UTC()
	retention := s3lifecycle.DaysToDuration(8)
	p := newMemPersister()
	vrSeedCursor(t, p, snap, shardID, runNow.Add(-retention).UnixNano(), retention, runNow)

	key := vrKeys(t, bucket, shardID)
	longA, offA, shortA := key("long/"), key("off/"), key("short/")
	shortEv := vrPut(runNow, bucket, shortA, s3lifecycle.DaysToDuration(5))
	log := []*filer_pb.SubscribeMetadataResponse{
		vrPut(runNow, bucket, longA, s3lifecycle.DaysToDuration(7)),
		vrPut(runNow, bucket, offA, s3lifecycle.DaysToDuration(6)),
		shortEv,
	}

	client := &recordingClient{}
	walker := &vrWalker{}
	cfg := vrConfig(e, shardID, log, client, p, runNow)
	cfg.RetentionWindow = retention
	cfg.Walker = walker.walk
	vrRun(t, cfg)

	got, _, err := p.Load(context.Background(), shardID)
	require.NoError(t, err)
	assert.Equal(t, shortEv.TsNs, got.TsNs,
		"cursor must end on the due 3-day PUT, past the 30-day and disabled-rule objects")
	assert.ElementsMatch(t, []string{shortA}, client.seenObjects(),
		"only the 3-day object is deleted; the 30-day and disabled-rule objects are not")
}

// TestVerify_RulesNotSwitchedOnStayQuiet: three short rules in one bucket
// under an 8-day log. "live" finished its bootstrap and is active. "fresh"
// has no stored state, so its first bootstrap has not run. "pending" is held
// in scan_only mode and its bootstrap never finished either. Every object is
// past its rule's age, but only the live rule's object may be deleted, and
// the cursor still ends on the last PUT.
func TestVerify_RulesNotSwitchedOnStayQuiet(t *testing.T) {
	bucket, shardID := "b3", 0
	live := &s3lifecycle.Rule{ID: "live", Status: s3lifecycle.StatusEnabled, Prefix: "live/", ExpirationDays: 2}
	fresh := &s3lifecycle.Rule{ID: "fresh", Status: s3lifecycle.StatusEnabled, Prefix: "fresh/", ExpirationDays: 3}
	pending := &s3lifecycle.Rule{ID: "pending", Status: s3lifecycle.StatusEnabled, Prefix: "pending/", ExpirationDays: 4}
	e := engine.New()
	e.Compile([]engine.CompileInput{{Bucket: bucket, Rules: []*s3lifecycle.Rule{live, fresh, pending}}},
		engine.CompileOptions{PriorStates: map[s3lifecycle.ActionKey]engine.PriorState{
			{Bucket: bucket, RuleHash: s3lifecycle.RuleHash(live), ActionKind: s3lifecycle.ActionKindExpirationDays}:    {BootstrapComplete: true},
			{Bucket: bucket, RuleHash: s3lifecycle.RuleHash(pending), ActionKind: s3lifecycle.ActionKindExpirationDays}: {Mode: engine.ModeScanOnly},
		}})
	snap := e.Snapshot()

	runNow := time.Unix(1_700_000_000, 0).UTC()
	retention := s3lifecycle.DaysToDuration(8)
	p := newMemPersister()
	vrSeedCursor(t, p, snap, shardID, runNow.Add(-retention).UnixNano(), retention, runNow)

	key := vrKeys(t, bucket, shardID)
	pendingA, freshA, liveA := key("pending/"), key("fresh/"), key("live/")
	last := vrPut(runNow, bucket, liveA, s3lifecycle.DaysToDuration(5))
	log := []*filer_pb.SubscribeMetadataResponse{
		vrPut(runNow, bucket, pendingA, s3lifecycle.DaysToDuration(7)),
		vrPut(runNow, bucket, freshA, s3lifecycle.DaysToDuration(6)),
		last,
	}

	client := &recordingClient{}
	walker := &vrWalker{}
	cfg := vrConfig(e, shardID, log, client, p, runNow)
	cfg.RetentionWindow = retention
	cfg.Walker = walker.walk
	vrRun(t, cfg)

	assert.ElementsMatch(t, []string{liveA}, client.seenObjects(),
		"only the active rule deletes; rules whose bootstrap has not finished stay quiet")
	got, _, err := p.Load(context.Background(), shardID)
	require.NoError(t, err)
	assert.Equal(t, last.TsNs, got.TsNs, "cursor must end on the last PUT")
}

// TestVerify_LaterPassExpiresNewlyDueObjectOnly: a 2-day and a 20-day rule
// under a 6-day log, with a walker configured. The first pass deletes the two
// due 2-day objects and hands the 20-day rule to the walker. One 2-day object
// is only a day old, so it is not due yet, and a write under no rule follows
// it. Two days later a second pass must delete that object and must not send
// deletes for the objects the first pass already handled.
func TestVerify_LaterPassExpiresNewlyDueObjectOnly(t *testing.T) {
	bucket, shardID := "b5", 7
	shortRule := &s3lifecycle.Rule{ID: "tmp", Status: s3lifecycle.StatusEnabled, Prefix: "tmp/", ExpirationDays: 2}
	longRule := &s3lifecycle.Rule{ID: "archive", Status: s3lifecycle.StatusEnabled, Prefix: "archive/", ExpirationDays: 20}
	longKey := s3lifecycle.ActionKey{Bucket: bucket, RuleHash: s3lifecycle.RuleHash(longRule), ActionKind: s3lifecycle.ActionKindExpirationDays}
	e := engine.New()
	e.Compile([]engine.CompileInput{{Bucket: bucket, Rules: []*s3lifecycle.Rule{shortRule, longRule}}},
		engine.CompileOptions{PriorStates: map[s3lifecycle.ActionKey]engine.PriorState{
			{Bucket: bucket, RuleHash: s3lifecycle.RuleHash(shortRule), ActionKind: s3lifecycle.ActionKindExpirationDays}: {BootstrapComplete: true},
			longKey: {BootstrapComplete: true},
		}})
	snap := e.Snapshot()
	for _, a := range snap.AllActions() {
		snap.MarkActive(a.Key)
	}

	runNow := time.Unix(1_700_000_000, 0).UTC()
	retention := s3lifecycle.DaysToDuration(6)
	p := newMemPersister()
	vrSeedCursor(t, p, snap, shardID, runNow.Add(-retention).UnixNano(), retention, runNow)

	key := vrKeys(t, bucket, shardID)
	tmpOld, archiveA, tmpMid, tmpYoung, logsA := key("tmp/"), key("archive/"), key("tmp/"), key("tmp/"), key("logs/")
	log := []*filer_pb.SubscribeMetadataResponse{
		vrPut(runNow, bucket, tmpOld, s3lifecycle.DaysToDuration(5)),
		vrPut(runNow, bucket, archiveA, s3lifecycle.DaysToDuration(4)),
		vrPut(runNow, bucket, tmpMid, s3lifecycle.DaysToDuration(3)),
		vrPut(runNow, bucket, tmpYoung, s3lifecycle.DaysToDuration(1)),
		vrPut(runNow, bucket, logsA, s3lifecycle.DaysToDuration(1)/2),
	}

	first := &recordingClient{}
	walker := &vrWalker{}
	cfg := vrConfig(e, shardID, log, first, p, runNow)
	cfg.RetentionWindow = retention
	cfg.Walker = walker.walk
	vrRun(t, cfg)
	assert.ElementsMatch(t, []string{tmpOld, tmpMid}, first.seenObjects(),
		"first pass deletes the due 2-day objects only")
	assert.True(t, walker.handedActive(longKey), "the walker must still be handed the 20-day rule, active")

	later := runNow.Add(s3lifecycle.DaysToDuration(2))
	second := &recordingClient{}
	cfg = vrConfig(e, shardID, log, second, p, later)
	cfg.RetentionWindow = retention
	cfg.Walker = walker.walk
	vrRun(t, cfg)
	assert.ElementsMatch(t, []string{tmpYoung}, second.seenObjects(),
		"second pass deletes the newly due object and repeats no earlier delete")
}

// TestVerify_NoRetentionWindowReplayUnchanged: with no retention window
// configured, a plain short expiration rule still deletes its due object
// through replay and the cursor moves past it, as it does today.
func TestVerify_NoRetentionWindowReplayUnchanged(t *testing.T) {
	bucket, shardID := "b4", 14
	shortRule := &s3lifecycle.Rule{ID: "short", Status: s3lifecycle.StatusEnabled, Prefix: "short/", ExpirationDays: 3}
	e := engine.New()
	e.Compile([]engine.CompileInput{{Bucket: bucket, Rules: []*s3lifecycle.Rule{shortRule}}},
		engine.CompileOptions{PriorStates: map[s3lifecycle.ActionKey]engine.PriorState{
			{Bucket: bucket, RuleHash: s3lifecycle.RuleHash(shortRule), ActionKind: s3lifecycle.ActionKindExpirationDays}: {BootstrapComplete: true},
		}})
	snap := e.Snapshot()
	for _, a := range snap.AllActions() {
		snap.MarkActive(a.Key)
	}

	runNow := time.Unix(1_700_000_000, 0).UTC()
	p := newMemPersister()
	// Start reading well before the object so a due (age > TTL) object still
	// lands inside the pass. With no retention window the promoted set is
	// taken against the largest active TTL, so seed the hash the same way.
	vrSeedCursor(t, p, snap, shardID, runNow.Add(-s3lifecycle.DaysToDuration(10)).UnixNano(), engine.MaxEffectiveTTL(snap), runNow)

	shortA := vrKeys(t, bucket, shardID)("short/")
	due := vrPut(runNow, bucket, shortA, s3lifecycle.DaysToDuration(5))

	client := &recordingClient{}
	vrRun(t, vrConfig(e, shardID, []*filer_pb.SubscribeMetadataResponse{due}, client, p, runNow)) // RetentionWindow and Walker unset

	assert.ElementsMatch(t, []string{shortA}, client.seenObjects(),
		"with no retention window the short rule still deletes its due object")
	got, _, err := p.Load(context.Background(), shardID)
	require.NoError(t, err)
	assert.Equal(t, due.TsNs, got.TsNs,
		"with no retention window the cursor moves past the handled event")
}
