package dailyrun

// Daily-replay checks on buckets that mix short and long expiration rules.
// Each test runs one or two shard passes through runShard and looks only at
// what a caller can observe: which objects reached the delete client, which
// rule set the walker was handed, and where the saved cursor ended up.
//
// Helpers reused from sibling test files in this package: recordingClient /
// .seenObjects (process_matches_test.go), memPersister / newMemPersister
// (walker_recovery_test.go), stubSiblingLister (walker_interval_test.go),
// plus Cursor / Config from the package itself.

import (
	"context"
	"testing"
	"time"

	"github.com/seaweedfs/seaweedfs/weed/pb/filer_pb"
	"github.com/seaweedfs/seaweedfs/weed/s3api/s3lifecycle"
	"github.com/seaweedfs/seaweedfs/weed/s3api/s3lifecycle/engine"
	"github.com/seaweedfs/seaweedfs/weed/s3api/s3lifecycle/reader"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// vrPut builds a meta-log PUT event for key whose object was last modified at
// (runNow - age).
func vrPut(runNow time.Time, bucket, key string, age time.Duration) *reader.Event {
	at := runNow.Add(-age)
	return &reader.Event{
		TsNs:   at.UnixNano(),
		Bucket: bucket,
		Key:    key,
		NewEntry: &filer_pb.Entry{
			Name:       key,
			Attributes: &filer_pb.FuseAttributes{Mtime: at.Unix(), FileSize: 1},
		},
	}
}

// vrSeedCursor saves a cursor whose rule-set and promoted hashes match the
// snapshot under the given retention, so runShard treats the pass as a
// normal daily pass (no rule-change rewind, no first-run floor). startTsNs
// is where the pass starts reading.
func vrSeedCursor(t *testing.T, p *memPersister, snap *engine.Snapshot, shardID int, startTsNs int64, retention time.Duration, runNowT time.Time) {
	t.Helper()
	require.NoError(t, p.Save(context.Background(), shardID, Cursor{
		TsNs:         startTsNs,
		RuleSetHash:  engine.ReplayContentHash(snap),
		PromotedHash: engine.PromotedHash(snap, retention),
		LastWalkedNs: runNowT.UnixNano(),
	}))
}

// vrEvents returns a closed channel holding evs in order.
func vrEvents(evs ...*reader.Event) chan *reader.Event {
	ch := make(chan *reader.Event, len(evs))
	for _, ev := range evs {
		ch <- ev
	}
	close(ch)
	return ch
}

// TestVerify_CursorAdvancesPastLongRuleObject: a bucket has a 3-day and a
// 30-day expiration rule, and the change log keeps 8 days. A 30-day object
// written between two due 3-day objects must not hold the cursor: it ends on
// the last due 3-day PUT, both 3-day objects are deleted, and the 30-day
// object is not.
func TestVerify_CursorAdvancesPastLongRuleObject(t *testing.T) {
	bucket := "b1"
	shortRule := &s3lifecycle.Rule{ID: "short", Status: s3lifecycle.StatusEnabled, Prefix: "short/", ExpirationDays: 3}
	longRule := &s3lifecycle.Rule{ID: "long", Status: s3lifecycle.StatusEnabled, Prefix: "long/", ExpirationDays: 30}
	e := engine.New()
	e.Compile([]engine.CompileInput{{Bucket: bucket, Rules: []*s3lifecycle.Rule{shortRule, longRule}}},
		engine.CompileOptions{PriorStates: map[s3lifecycle.ActionKey]engine.PriorState{
			{Bucket: bucket, RuleHash: s3lifecycle.RuleHash(shortRule), ActionKind: s3lifecycle.ActionKindExpirationDays}: {BootstrapComplete: true},
			{Bucket: bucket, RuleHash: s3lifecycle.RuleHash(longRule), ActionKind: s3lifecycle.ActionKindExpirationDays}:  {BootstrapComplete: true},
		}})
	snap := e.Snapshot()
	for _, a := range snap.AllActions() {
		snap.MarkActive(a.Key)
	}

	runNow := time.Unix(1_700_000_000, 0).UTC()
	retention := s3lifecycle.DaysToDuration(8)
	startTsNs := runNow.Add(-retention).UnixNano()
	p := newMemPersister()
	vrSeedCursor(t, p, snap, 0, startTsNs, retention, runNow)

	last := vrPut(runNow, bucket, "short/b", s3lifecycle.DaysToDuration(5))
	events := vrEvents(
		vrPut(runNow, bucket, "short/a", s3lifecycle.DaysToDuration(7)),
		vrPut(runNow, bucket, "long/a", s3lifecycle.DaysToDuration(6)),
		last,
	)

	client := &recordingClient{}
	cfg := Config{Persister: p, Client: client, Lister: stubSiblingLister{}, RetentionWindow: retention}
	require.NoError(t, runShard(context.Background(), cfg, snap, runNow, 0, events, nil))

	got, _, err := p.Load(context.Background(), 0)
	require.NoError(t, err)
	assert.Equal(t, last.TsNs, got.TsNs,
		"cursor must end on the last due 3-day PUT, past the 30-day object")
	assert.ElementsMatch(t, []string{"short/a", "short/b"}, client.seenObjects(),
		"both due 3-day objects are deleted; the 30-day object is not")
}

// TestVerify_LongAndDisabledRuleObjectsDoNotHoldCursor: same 3-day / 30-day
// mix plus a disabled 4-day rule. The 30-day object comes first in the log,
// then an object under the disabled rule, then a due 3-day object. The cursor
// ends on the 3-day PUT, and only the 3-day object is deleted.
func TestVerify_LongAndDisabledRuleObjectsDoNotHoldCursor(t *testing.T) {
	bucket := "b2"
	shortRule := &s3lifecycle.Rule{ID: "short", Status: s3lifecycle.StatusEnabled, Prefix: "short/", ExpirationDays: 3}
	longRule := &s3lifecycle.Rule{ID: "long", Status: s3lifecycle.StatusEnabled, Prefix: "long/", ExpirationDays: 30}
	offRule := &s3lifecycle.Rule{ID: "off", Status: s3lifecycle.StatusDisabled, Prefix: "off/", ExpirationDays: 4}
	e := engine.New()
	e.Compile([]engine.CompileInput{{Bucket: bucket, Rules: []*s3lifecycle.Rule{shortRule, longRule, offRule}}},
		engine.CompileOptions{PriorStates: map[s3lifecycle.ActionKey]engine.PriorState{
			{Bucket: bucket, RuleHash: s3lifecycle.RuleHash(shortRule), ActionKind: s3lifecycle.ActionKindExpirationDays}: {BootstrapComplete: true},
			{Bucket: bucket, RuleHash: s3lifecycle.RuleHash(longRule), ActionKind: s3lifecycle.ActionKindExpirationDays}:  {BootstrapComplete: true},
		}})
	snap := e.Snapshot()
	for _, a := range snap.AllActions() {
		snap.MarkActive(a.Key)
	}

	runNow := time.Unix(1_700_000_000, 0).UTC()
	retention := s3lifecycle.DaysToDuration(8)
	startTsNs := runNow.Add(-retention).UnixNano()
	p := newMemPersister()
	vrSeedCursor(t, p, snap, 0, startTsNs, retention, runNow)

	shortEv := vrPut(runNow, bucket, "short/a", s3lifecycle.DaysToDuration(5))
	events := vrEvents(
		vrPut(runNow, bucket, "long/a", s3lifecycle.DaysToDuration(7)),
		vrPut(runNow, bucket, "off/a", s3lifecycle.DaysToDuration(6)),
		shortEv,
	)

	client := &recordingClient{}
	cfg := Config{Persister: p, Client: client, Lister: stubSiblingLister{}, RetentionWindow: retention}
	require.NoError(t, runShard(context.Background(), cfg, snap, runNow, 0, events, nil))

	got, _, err := p.Load(context.Background(), 0)
	require.NoError(t, err)
	assert.Equal(t, shortEv.TsNs, got.TsNs,
		"cursor must end on the due 3-day PUT, past the 30-day and disabled-rule objects")
	assert.ElementsMatch(t, []string{"short/a"}, client.seenObjects(),
		"only the 3-day object is deleted; the 30-day and disabled-rule objects are not")
}

// TestVerify_RulesNotSwitchedOnStayQuiet: three short rules in one bucket
// under an 8-day log. "live" finished its bootstrap and is active. "fresh"
// has no stored state, so its first bootstrap has not run. "pending" is held
// in scan_only mode and its bootstrap never finished either. Every object is
// past its rule's age, but only the live rule's object may be deleted, and
// the cursor still ends on the last PUT.
func TestVerify_RulesNotSwitchedOnStayQuiet(t *testing.T) {
	bucket := "b3"
	live := &s3lifecycle.Rule{ID: "live", Status: s3lifecycle.StatusEnabled, Prefix: "live/", ExpirationDays: 2}
	fresh := &s3lifecycle.Rule{ID: "fresh", Status: s3lifecycle.StatusEnabled, Prefix: "fresh/", ExpirationDays: 3}
	pending := &s3lifecycle.Rule{ID: "pending", Status: s3lifecycle.StatusEnabled, Prefix: "pending/", ExpirationDays: 4}
	e := engine.New()
	e.Compile([]engine.CompileInput{{Bucket: bucket, Rules: []*s3lifecycle.Rule{live, fresh, pending}}},
		engine.CompileOptions{PriorStates: map[s3lifecycle.ActionKey]engine.PriorState{
			{Bucket: bucket, RuleHash: s3lifecycle.RuleHash(live), ActionKind: s3lifecycle.ActionKindExpirationDays}:    {BootstrapComplete: true},
			{Bucket: bucket, RuleHash: s3lifecycle.RuleHash(pending), ActionKind: s3lifecycle.ActionKindExpirationDays}: {Mode: engine.ModeScanOnly},
		}})
	snap := e.Snapshot()

	runNow := time.Unix(1_700_000_000, 0).UTC()
	retention := s3lifecycle.DaysToDuration(8)
	startTsNs := runNow.Add(-retention).UnixNano()
	p := newMemPersister()
	vrSeedCursor(t, p, snap, 0, startTsNs, retention, runNow)

	last := vrPut(runNow, bucket, "live/a", s3lifecycle.DaysToDuration(5))
	events := vrEvents(
		vrPut(runNow, bucket, "pending/a", s3lifecycle.DaysToDuration(7)),
		vrPut(runNow, bucket, "fresh/a", s3lifecycle.DaysToDuration(6)),
		last,
	)

	client := &recordingClient{}
	cfg := Config{Persister: p, Client: client, Lister: stubSiblingLister{}, RetentionWindow: retention}
	require.NoError(t, runShard(context.Background(), cfg, snap, runNow, 0, events, nil))

	assert.ElementsMatch(t, []string{"live/a"}, client.seenObjects(),
		"only the active rule deletes; rules whose bootstrap has not finished stay quiet")
	got, _, err := p.Load(context.Background(), 0)
	require.NoError(t, err)
	assert.Equal(t, last.TsNs, got.TsNs, "cursor must end on the last PUT")
}

// TestVerify_LaterPassExpiresNewlyDueObjectOnly: a 2-day and a 20-day rule
// under a 6-day log, with a walker configured. The first pass deletes the two
// due 2-day objects and hands the 20-day rule to the walker. One 2-day object
// is only a day old, so it is not due yet. Two days later a second pass must
// delete that object and must not send deletes for the objects the first pass
// already handled.
func TestVerify_LaterPassExpiresNewlyDueObjectOnly(t *testing.T) {
	bucket := "b5"
	shortRule := &s3lifecycle.Rule{ID: "tmp", Status: s3lifecycle.StatusEnabled, Prefix: "tmp/", ExpirationDays: 2}
	longRule := &s3lifecycle.Rule{ID: "archive", Status: s3lifecycle.StatusEnabled, Prefix: "archive/", ExpirationDays: 20}
	longKey := s3lifecycle.ActionKey{Bucket: bucket, RuleHash: s3lifecycle.RuleHash(longRule), ActionKind: s3lifecycle.ActionKindExpirationDays}
	e := engine.New()
	e.Compile([]engine.CompileInput{{Bucket: bucket, Rules: []*s3lifecycle.Rule{shortRule, longRule}}},
		engine.CompileOptions{PriorStates: map[s3lifecycle.ActionKey]engine.PriorState{
			{Bucket: bucket, RuleHash: s3lifecycle.RuleHash(shortRule), ActionKind: s3lifecycle.ActionKindExpirationDays}: {BootstrapComplete: true},
			longKey: {BootstrapComplete: true},
		}})
	snap := e.Snapshot()
	for _, a := range snap.AllActions() {
		snap.MarkActive(a.Key)
	}

	runNow := time.Unix(1_700_000_000, 0).UTC()
	retention := s3lifecycle.DaysToDuration(6)
	p := newMemPersister()
	vrSeedCursor(t, p, snap, 0, runNow.Add(-retention).UnixNano(), retention, runNow)

	all := []*reader.Event{
		vrPut(runNow, bucket, "tmp/old", s3lifecycle.DaysToDuration(5)),
		vrPut(runNow, bucket, "archive/a", s3lifecycle.DaysToDuration(4)),
		vrPut(runNow, bucket, "tmp/mid", s3lifecycle.DaysToDuration(3)),
		vrPut(runNow, bucket, "tmp/young", s3lifecycle.DaysToDuration(1)),
	}

	var walked []*engine.Snapshot
	walker := func(_ context.Context, view *engine.Snapshot, _ []int) error {
		walked = append(walked, view)
		return nil
	}

	first := &recordingClient{}
	cfg := Config{Persister: p, Client: first, Lister: stubSiblingLister{}, RetentionWindow: retention, Walker: walker}
	require.NoError(t, runShard(context.Background(), cfg, snap, runNow, 0, vrEvents(all...), nil))
	assert.ElementsMatch(t, []string{"tmp/old", "tmp/mid"}, first.seenObjects(),
		"first pass deletes the due 2-day objects only")
	longWalked := false
	for _, v := range walked {
		if v == nil {
			continue
		}
		if a := v.Action(longKey); a != nil && a.IsActive() {
			longWalked = true
		}
	}
	assert.True(t, longWalked, "the walker must still be handed the 20-day rule, active")

	later := runNow.Add(s3lifecycle.DaysToDuration(2))
	second := &recordingClient{}
	cfg.Client = second
	require.NoError(t, runShard(context.Background(), cfg, snap, later, 0, vrEvents(all...), nil))
	assert.ElementsMatch(t, []string{"tmp/young"}, second.seenObjects(),
		"second pass deletes the newly due object and repeats no earlier delete")
}

// TestVerify_NoRetentionWindowReplayUnchanged: with no retention window
// configured, a plain short expiration rule still deletes its due object
// through replay and the cursor moves past it, as it does today.
func TestVerify_NoRetentionWindowReplayUnchanged(t *testing.T) {
	bucket := "b4"
	shortRule := &s3lifecycle.Rule{ID: "short", Status: s3lifecycle.StatusEnabled, Prefix: "short/", ExpirationDays: 3}
	e := engine.New()
	e.Compile([]engine.CompileInput{{Bucket: bucket, Rules: []*s3lifecycle.Rule{shortRule}}},
		engine.CompileOptions{PriorStates: map[s3lifecycle.ActionKey]engine.PriorState{
			{Bucket: bucket, RuleHash: s3lifecycle.RuleHash(shortRule), ActionKind: s3lifecycle.ActionKindExpirationDays}: {BootstrapComplete: true},
		}})
	snap := e.Snapshot()
	for _, a := range snap.AllActions() {
		snap.MarkActive(a.Key)
	}

	runNow := time.Unix(1_700_000_000, 0).UTC()
	// Start reading well before the object so a due (age > TTL) object still
	// lands inside the pass.
	startTsNs := runNow.Add(-s3lifecycle.DaysToDuration(10)).UnixNano()
	p := newMemPersister()
	// With no retention window, runShard falls back to the largest active
	// TTL; seed the promoted hash the same way so the pass is a normal one.
	require.NoError(t, p.Save(context.Background(), 0, Cursor{
		TsNs:         startTsNs,
		RuleSetHash:  engine.ReplayContentHash(snap),
		PromotedHash: engine.PromotedHash(snap, engine.MaxEffectiveTTL(snap)),
		LastWalkedNs: runNow.UnixNano(),
	}))

	due := vrPut(runNow, bucket, "short/a", s3lifecycle.DaysToDuration(5))
	events := vrEvents(due)

	client := &recordingClient{}
	cfg := Config{Persister: p, Client: client, Lister: stubSiblingLister{}} // RetentionWindow unset
	require.NoError(t, runShard(context.Background(), cfg, snap, runNow, 0, events, nil))

	assert.ElementsMatch(t, []string{"short/a"}, client.seenObjects(),
		"with no retention window the short rule still deletes its due object")
	got, _, err := p.Load(context.Background(), 0)
	require.NoError(t, err)
	assert.Equal(t, due.TsNs, got.TsNs,
		"with no retention window the cursor moves past the handled event")
}
