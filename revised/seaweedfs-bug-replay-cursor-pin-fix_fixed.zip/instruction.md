## Task

Our daily S3 lifecycle replay is stuck on a couple of buckets.
The per-shard progress marker has stopped moving and doesn't catch up by itself, so the lag goes up by roughly a day every day.
Every pass starts reading the change log again from that same spot and sends deletes for objects it already removed, which eats most of the cluster's delete rate limit.
Nothing errors out, and each pass still reports success.

The buckets that hit this have two expiration rules at once, one short-lived and one much longer, and our change-log retention falls between those two lifetimes.
The change-log reader, the delete client and the S3 API all look healthy to us, so it really seems to be the replay itself.

Please reproduce it, find out why it happens and fix it.
After the fix the progress marker should keep moving forward, and the daily passes shouldn't keep re-sending deletes that are already done.
Objects under both rules still need to expire when they come due, including ones that weren't due yet on an earlier pass.
Disabled rules and rules whose first bootstrap hasn't finished shouldn't start deleting anything from the change-log replay.
