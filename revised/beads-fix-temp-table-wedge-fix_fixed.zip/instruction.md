## Task

We have a busy shared beads hub that got itself stuck twice in a single day, and both times it happened right after an ordinary open.
The hub's Dolt server runs with `@@dolt_transaction_commit=1`, so every SQL transaction commit there also becomes a Dolt commit.
Once it gets stuck, older clients that open the store won't write anymore, and `bd dolt pull` fails too.
The working set stays dirty however many times we reopen or retry.
`dolt_status` keeps listing renames from `__temp__` tables onto real tables, such as `__temp__wisps -> wisps` and `__temp__leases -> leases`, and so far only a hand repair has cleared them.

Please work out why a normal open leaves the store like this, and change it so opening a store on a server set up like ours stops stranding it.
On that server an open should finish without errors and leave a clean working set, both when it has to rebuild the store's local tables the way it does on a fresh clone and when the store is already up to date, even if an older binary was the last one to open it.
Those `__temp__` tables should never end up in the commit history, even when other clients on the hub commit while one of them exists.
Nothing else about how new tables get versioned should change, and the one-time repairs an open already runs on older stores still have to finish and leave a clean working set.
Fixing stores that older clients have already wedged is out of scope; what we need is for new opens to stop causing it.
