#!/usr/bin/env bash
# All required deps (Go 1.26.10, build-essential, libicu-dev, prewarmed Go
# module + build cache at the base commit) are baked into the image. The
# embedded-dolt engine tests build the Dolt engine in-process via cgo
# (CGO_ENABLED=1 is set in the image) and require no external services or
# network. Nothing to install at verifier time.
set -euo pipefail
echo "[test-setup] no-op for beads-fix-temp-table-wedge"
