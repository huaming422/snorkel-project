//go:build cgo

package embeddeddolt_test

import (
	"context"
	"database/sql"
	"strings"
	"testing"

	"github.com/steveyegge/beads/internal/storage/schema"
)

// olderBinaryIgnoreRows strips every dolt_ignore row whose pattern starts with
// __temp__, whatever it names, so the store's ignore list matches one an older
// binary wrote.
const olderBinaryIgnoreRows = "DELETE FROM dolt_ignore WHERE LEFT(pattern, 8) = '__temp__'"

// serverOpen runs a writable open the way a client of the hub's Dolt
// sql-server does: through schema.MigrateUpWithLock, including its lock-free
// check for an already-converged store.
func serverOpen(ctx context.Context, conn *sql.Conn) error {
	var db string
	if err := conn.QueryRowContext(ctx, "SELECT DATABASE()").Scan(&db); err != nil {
		return err
	}
	_, err := schema.MigrateUpWithLock(ctx, conn, db)
	return err
}

// headTableNames lists the tables committed at HEAD.
func headTableNames(t *testing.T, ctx context.Context, conn *sql.Conn) []string {
	t.Helper()
	rows, err := conn.QueryContext(ctx, "SHOW TABLES AS OF 'HEAD'")
	if err != nil {
		t.Fatalf("listing tables at HEAD: %v", err)
	}
	defer rows.Close()
	var names []string
	for rows.Next() {
		var name string
		if err := rows.Scan(&name); err != nil {
			t.Fatalf("listing tables at HEAD: %v", err)
		}
		names = append(names, name)
	}
	if err := rows.Err(); err != nil {
		t.Fatalf("listing tables at HEAD: %v", err)
	}
	return names
}

// beadsTempTables is every __temp__ table name the beads schema code creates:
// the tables the clone-local and main-plane rebuilds go through, and the
// scratch table of the repair that untracks a legacy cursor table.
var beadsTempTables = []string{
	"__temp__wisps", "__temp__wisp_dependencies", "__temp__wisp_events",
	"__temp__wisp_comments", "__temp__wisp_labels", "__temp__wisp_child_counters",
	"__temp__leases", "__temp__repo_mtimes", "__temp__local_metadata",
	"__temp__bd_events_journal", "__temp__bd_events_seq", "__temp__events_flip",
	untrackScratchTable,
}

// assertBlanketCommitSkipsTempTables plays another writer on the hub that
// commits everything it can while each of beadsTempTables exists, then checks
// that none of them is tracked at HEAD. The blanket commit does not depend on
// this session's transaction setting.
func assertBlanketCommitSkipsTempTables(t *testing.T, ctx context.Context, conn *sql.Conn) {
	t.Helper()
	for _, name := range beadsTempTables {
		execFrozenGuard(t, ctx, conn, "CREATE TABLE "+name+" (id INT PRIMARY KEY)")
	}
	mustDrain(t, ctx, conn, "CALL DOLT_COMMIT('-Am', 'test: another writer commits everything', '--allow-empty')")
	for _, name := range beadsTempTables {
		if trackedAtHead(t, ctx, conn, name) {
			t.Errorf("%s was swept into HEAD by another writer's blanket commit", name)
		}
	}
	for _, name := range beadsTempTables {
		execFrozenGuard(t, ctx, conn, "DROP TABLE IF EXISTS "+name)
	}
}

// enableTransactionCommit switches the session to the shared hub's server
// setting: every SQL transaction commit is also a dolt commit of every
// non-ignored change.
func enableTransactionCommit(t *testing.T, ctx context.Context, conn *sql.Conn) {
	t.Helper()
	if _, err := conn.ExecContext(ctx, "SET @@dolt_transaction_commit = 1"); err != nil {
		t.Fatalf("enable dolt_transaction_commit: %v", err)
	}
}

// cloneShapedStore returns a pinned connection to a store shaped the way a
// real clone arrives (the same steps as
// TestEmbeddedIgnoredSeriesConvergesWithFreshInitShape): committed history
// holds the main tables and the at-latest main cursor, while the clone-local
// tables and the ignored cursor are absent, so the next open rebuilds them.
// Its dolt_ignore carries no __temp__ rows.
func cloneShapedStore(t *testing.T, ctx context.Context) (*sql.Conn, func()) {
	t.Helper()
	dir := seedMainSchemaAt(t, ctx, schema.LatestVersion())
	conn, closeConn := openPinnedConn(t, ctx, dir)
	if _, err := schema.MigrateUp(ctx, conn); err != nil {
		closeConn()
		t.Fatalf("seed MigrateUp: %v", err)
	}
	for _, table := range []string{
		"wisp_dependencies", "wisp_events", "wisp_comments", "wisp_labels",
		"wisp_child_counters", "wisps", "events", "leases", "repo_mtimes",
		"local_metadata", "bd_events_journal", "bd_events_seq",
		"ignored_schema_migrations",
	} {
		execFrozenGuard(t, ctx, conn, "DROP TABLE IF EXISTS "+table)
	}
	// seedMainSchemaAt commits the statically seeded clone-local tables before
	// their ignore rows exist, so the rows go first or the drops above cannot
	// be staged; the next open re-asserts them.
	execFrozenGuard(t, ctx, conn,
		"DELETE FROM dolt_ignore WHERE pattern IN ('leases', 'bd_events_journal', 'bd_events_seq')")
	execFrozenGuard(t, ctx, conn, olderBinaryIgnoreRows)
	mustDrain(t, ctx, conn, "CALL DOLT_ADD('-A')")
	mustDrain(t, ctx, conn, "CALL DOLT_COMMIT('-m', 'test: clone-shaped baseline', '--skip-empty')")
	return conn, closeConn
}

// TestEmbeddedTempRebuildIntermediatesNeverReachHistory drives a fresh-box
// server-mode open against a real in-process engine running with
// @@dolt_transaction_commit=1, over a clone-shaped store whose dolt_ignore was
// written by an older binary. The ignored-series table rebuilds run in this
// pass and stage their work through __temp__<table> tables.
//
// The open must finish without error and bring back the clone-local tables
// with the ignored cursor at latest. No __temp__ table may appear in any
// commit's history, including after another writer's blanket commit while one
// exists, and the working set must be clean afterwards. Tables with ordinary
// names must still show up in dolt_status once the pass is done.
func TestEmbeddedTempRebuildIntermediatesNeverReachHistory(t *testing.T) {
	requireEmbedded(t)
	ctx := t.Context()

	conn, closeConn := cloneShapedStore(t, ctx)
	defer closeConn()

	enableTransactionCommit(t, ctx, conn)

	// The fresh-box open.
	if err := serverOpen(ctx, conn); err != nil {
		t.Fatalf("fresh-box MigrateUp: %v", err)
	}

	// The open did its schema work: the clone-local tables are back and the
	// ignored cursor is current.
	if v, err := schema.CurrentIgnoredVersion(ctx, conn); err != nil || v != schema.LatestIgnoredVersion() {
		t.Errorf("ignored cursor after the open = %d (err %v), want %d", v, err, schema.LatestIgnoredVersion())
	}
	for _, table := range []string{"wisps", "leases", "repo_mtimes", "local_metadata"} {
		if !tablePresent(t, ctx, conn, table) {
			t.Errorf("clone-local table %s is missing after the open", table)
		}
	}

	// No rebuild intermediate may appear in ANY commit's history.
	if leaked := tempTablesInHistory(t, ctx, conn); len(leaked) > 0 {
		t.Errorf("rebuild intermediates reached committed history: %v", leaked)
	}

	// The pass must end with a clean working set.
	dirty, err := statusTables(ctx, conn)
	if err != nil {
		t.Fatalf("read dolt_status: %v", err)
	}
	if len(dirty) > 0 {
		t.Errorf("working set dirty after the fresh-box pass: %v", dirty)
	}

	// Another writer on the hub commits everything it can while beads'
	// __temp__ tables exist; none of them may land in HEAD.
	assertBlanketCommitSkipsTempTables(t, ctx, conn)

	// Tables with ordinary names are still versioned normally: created
	// outside a transaction commit, each one shows up in dolt_status as new.
	if _, err := conn.ExecContext(ctx, "SET @@dolt_transaction_commit = 0"); err != nil {
		t.Fatalf("disable dolt_transaction_commit: %v", err)
	}
	ordinary := []string{"notes_archive", "temp_notes", "__notes", "__temporal"}
	for _, name := range ordinary {
		execFrozenGuard(t, ctx, conn, "CREATE TABLE "+name+" (id INT PRIMARY KEY)")
	}
	visible := dirtyTableNames(t, ctx, conn)
	for _, name := range ordinary {
		if !contains(visible, name) {
			t.Errorf("new table %s is hidden from dolt_status after the open; dolt_status = %v", name, visible)
		}
	}
}

// TestEmbeddedCurrentStoreOpenOnTransactionCommitServerStaysClean drives a
// routine server-mode open of a store that is already at the latest schema, on
// a session running with @@dolt_transaction_commit=1. The store's dolt_ignore
// was written by an older binary, so the open has ignore rows of its own to add
// while no migration step runs. The open must finish without error and leave a
// clean working set, and afterwards another writer's blanket commit must leave
// every beads __temp__ table out of HEAD.
func TestEmbeddedCurrentStoreOpenOnTransactionCommitServerStaysClean(t *testing.T) {
	requireEmbedded(t)
	ctx := t.Context()

	conn, closeConn := cloneShapedStore(t, ctx)
	defer closeConn()

	// Bring the store fully current with an ordinary open, then put the
	// ignore list back to the older binary's shape.
	if _, err := schema.MigrateUp(ctx, conn); err != nil {
		t.Fatalf("converging MigrateUp: %v", err)
	}
	execFrozenGuard(t, ctx, conn, olderBinaryIgnoreRows)
	mustDrain(t, ctx, conn, "CALL DOLT_ADD('dolt_ignore')")
	mustDrain(t, ctx, conn, "CALL DOLT_COMMIT('-m', 'test: older-binary ignore baseline', '--skip-empty')")

	// Preconditions: both cursors are current, so the open under test runs no
	// migration step, and the baseline itself is clean.
	if v, err := schema.CurrentVersion(ctx, conn); err != nil || v != schema.LatestVersion() {
		t.Fatalf("main cursor = %d (err %v), want %d", v, err, schema.LatestVersion())
	}
	if v, err := schema.CurrentIgnoredVersion(ctx, conn); err != nil || v != schema.LatestIgnoredVersion() {
		t.Fatalf("ignored cursor = %d (err %v), want %d", v, err, schema.LatestIgnoredVersion())
	}
	if dirty := dirtyTableNames(t, ctx, conn); len(dirty) > 0 {
		t.Fatalf("baseline working set is dirty: %v", dirty)
	}

	enableTransactionCommit(t, ctx, conn)

	if err := serverOpen(ctx, conn); err != nil {
		t.Fatalf("open of an up-to-date store: %v", err)
	}
	if dirty := dirtyTableNames(t, ctx, conn); len(dirty) > 0 {
		t.Errorf("working set dirty after opening an up-to-date store: %v", dirty)
	}

	// From this open on, another writer's blanket commit leaves beads'
	// __temp__ tables out of HEAD too.
	assertBlanketCommitSkipsTempTables(t, ctx, conn)
}

// TestEmbeddedCommittedRepairScratchIsCleanedOnOpen drives the open-time
// repair of a legacy, committed ignored_schema_migrations table end to end
// through a writable open, on its two resume routes.
//
// The repair moves the cursor rows through the scratch table
// __temp__ignored_schema_migrations_untrack. Each case leaves that scratch
// committed at HEAD, as a concurrent writer's blanket commit can, and asserts
// that precondition. After the reopen, the scratch must be gone from the
// working set and from HEAD, the working set must be clean, every cursor row
// must be present, and no table may be committed at HEAD that was not there
// before the open.
func TestEmbeddedCommittedRepairScratchIsCleanedOnOpen(t *testing.T) {
	requireEmbedded(t)
	for _, tt := range []struct {
		name string
		db   string
		// crash leaves a legacy-tracked database in the state its name
		// describes, with the scratch table not yet committed.
		crash func(t *testing.T, ctx context.Context, conn *sql.Conn)
	}{
		{
			// The cursor table is back and the operator has versioned it on
			// purpose, so the resume only removes the scratch.
			name: "cursor restored, operator override",
			db:   "scratchresume",
			crash: func(t *testing.T, ctx context.Context, conn *sql.Conn) {
				untrackCursorInPlace(t, ctx, conn)
				mustExecOn(t, ctx, conn, "REPLACE INTO dolt_ignore VALUES ('ignored_schema_migrations', false)")
			},
		},
		{
			// The cursor table's drop is committed and its rows live only in
			// the scratch, so the resume restores them before removing it.
			name: "drop committed, rows not restored",
			db:   "scratchrestore",
			crash: func(t *testing.T, ctx context.Context, conn *sql.Conn) {
				backupCursorRows(t, ctx, conn)
				mustExecOn(t, ctx, conn, "DROP TABLE IF EXISTS ignored_schema_migrations")
				mustExecOn(t, ctx, conn, "CALL DOLT_ADD('-f', 'ignored_schema_migrations')")
				mustExecOn(t, ctx, conn, "CALL DOLT_COMMIT('--skip-empty', '-m', 'test: cursor drop committed')")
			},
		},
	} {
		t.Run(tt.name, func(t *testing.T) {
			ctx := t.Context()
			f := newLegacyTrackedFixture(t, tt.db)
			var headBefore []string

			f.withRawConn(t, func(conn *sql.Conn) {
				tt.crash(t, ctx, conn)
				// A forced add puts the scratch into HEAD whatever the ignore
				// list says; the blanket commit then lands it with everything
				// else the case left in the working set.
				mustExecOn(t, ctx, conn, "CALL DOLT_ADD('-f', ?)", untrackScratchTable)
				mustExecOn(t, ctx, conn, "CALL DOLT_COMMIT('-Am', 'test: another writer commits everything')")
				if !trackedAtHead(t, ctx, conn, untrackScratchTable) {
					t.Fatalf("%s is not committed at HEAD; the committed-scratch path would not be exercised", untrackScratchTable)
				}
				headBefore = headTableNames(t, ctx, conn)
			})

			f.reopenAndClose(t)

			f.withRawConn(t, func(conn *sql.Conn) {
				if tablePresent(t, ctx, conn, untrackScratchTable) {
					t.Errorf("%s survived the open; the cleanup must always remove it", untrackScratchTable)
				}
				// Only a commit takes the table back out of HEAD, so this
				// proves the cleanup's commit landed and not just a local DROP.
				if trackedAtHead(t, ctx, conn, untrackScratchTable) {
					t.Errorf("%s is still committed at HEAD; the cleanup committed nothing", untrackScratchTable)
				}
				if dirty := dirtyTableNames(t, ctx, conn); len(dirty) > 0 {
					t.Errorf("working set is dirty after the open: %v", dirty)
				}
				if got := len(cursorRows(t, ctx, conn)); got != len(f.cursorRows) {
					t.Errorf("cursor rows = %d, want %d", got, len(f.cursorRows))
				}
				// The open versions nothing new: every table at HEAD now was
				// already there before it.
				for _, name := range headTableNames(t, ctx, conn) {
					if !contains(headBefore, name) {
						t.Errorf("%s is committed at HEAD after the open but was not before it", name)
					}
				}
			})
		})
	}
}

// tempTablesInHistory lists every __temp__ table name that appears in any
// commit's diff.
func tempTablesInHistory(t *testing.T, ctx context.Context, conn *sql.Conn) []string {
	t.Helper()
	rows, err := conn.QueryContext(ctx, "SELECT DISTINCT table_name FROM dolt_diff")
	if err != nil {
		t.Fatalf("read dolt_diff table names: %v", err)
	}
	defer rows.Close()
	var leaked []string
	for rows.Next() {
		var name string
		if err := rows.Scan(&name); err != nil {
			t.Fatalf("scan dolt_diff table name: %v", err)
		}
		if strings.HasPrefix(name, "__temp__") {
			leaked = append(leaked, name)
		}
	}
	if err := rows.Err(); err != nil {
		t.Fatalf("iterate dolt_diff table names: %v", err)
	}
	return leaked
}
