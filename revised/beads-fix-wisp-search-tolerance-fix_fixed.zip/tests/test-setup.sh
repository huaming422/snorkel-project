#!/usr/bin/env bash
# Dependencies are baked into the image and the Go build and module caches are
# warm. The verifier needs no cgo, no Dolt and no services, so there is
# nothing to install or start at verify time.
set -euo pipefail
echo "[test-setup] no-op for beads-fix-wisp-search-tolerance"
