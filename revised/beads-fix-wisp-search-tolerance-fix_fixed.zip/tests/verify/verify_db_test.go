// Behavioral verifier for the domain/db search stack.
//
// Driven through the pre-existing exported constructor and method
// db.NewIssueSQLRepository(runner).SearchAcrossIssuesAndWisps. The Runner it
// takes is satisfied directly by a go-sqlmock *sql.DB (ExecContext /
// QueryContext / QueryRowContext), so there is no real database, no cgo, and
// no Dolt. This file lives in the external test package `db_test`: it uses
// only the stable public surface and does not collide with the package's own
// in-package test files.
//
// Same contract as the classic stack: with the wisps table present, a
// missing `wisp_labels` or `leases` table surfaces as an error that carries
// the driver failure, on the ephemeral-only path and on the merged (union)
// path, while a database with no `wisps` table still searches cleanly.
//
// Each case primes one consistent database state and matches queries in any
// order, so a search may ask the cheap wisps presence probe ("SELECT 1 FROM
// wisps") before or after its other queries.
package db_test

import (
	"context"
	"database/sql"
	"errors"
	"testing"

	sqlmock "github.com/DATA-DOG/go-sqlmock"
	mysql "github.com/go-sql-driver/mysql"

	"github.com/steveyegge/beads/internal/storage/domain/db"
	"github.com/steveyegge/beads/internal/types"
)

func missingTable(table string) error {
	return &mysql.MySQLError{Number: 1146, Message: "table not found: " + table}
}

func ephemeralFilter() types.IssueFilter {
	on := true
	return types.IssueFilter{Ephemeral: &on}
}

func newMockDB(t *testing.T) (*sql.DB, sqlmock.Sqlmock) {
	t.Helper()
	sqldb, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New: %v", err)
	}
	mock.MatchExpectationsInOrder(false)
	t.Cleanup(func() { _ = sqldb.Close() })
	return sqldb, mock
}

// expectWispsProbe primes the wisps presence probe twice, answering either
// "present with rows" or "table missing". It is declared before the broader
// "FROM wisps" expectation so a probe never lands on another query's
// expectation. Cases that prime it do not assert ExpectationsWereMet, since a
// search may probe once or twice.
func expectWispsProbe(mock sqlmock.Sqlmock, present bool) {
	for i := 0; i < 2; i++ {
		e := mock.ExpectQuery("SELECT 1 FROM wisps")
		if present {
			e.WillReturnRows(sqlmock.NewRows([]string{"1"}).AddRow(1))
		} else {
			e.WillReturnError(missingTable("wisps"))
		}
	}
}

// brokenTables are tables the wisp query reads that are not part of the
// "no wisp tables at all" shape. Their absence is a damaged store.
var brokenTables = []string{"wisp_labels", "leases"}

// TestSearchEphemeralBrokenPlaneErrors: with the wisps table present and
// holding rows, an ephemeral-only search whose wisps query fails on a missing
// `wisp_labels` or `leases` table returns an error that wraps that driver
// failure.
func TestSearchEphemeralBrokenPlaneErrors(t *testing.T) {
	for _, missing := range brokenTables {
		t.Run(missing, func(t *testing.T) {
			sqldb, mock := newMockDB(t)
			gone := missingTable(missing)
			expectWispsProbe(mock, true)
			mock.ExpectQuery("FROM wisps").WillReturnError(gone)
			mock.ExpectQuery("FROM issues").WillReturnRows(sqlmock.NewRows([]string{"id"}))

			repo := db.NewIssueSQLRepository(sqldb)
			page, err := repo.SearchAcrossIssuesAndWisps(context.Background(), "", ephemeralFilter())
			if err == nil {
				t.Fatalf("search succeeded with a missing %s table, returning %d rows (want error)", missing, len(page.Items))
			}
			if !errors.Is(err, gone) {
				t.Fatalf("error does not carry the missing-%s driver failure (want errors.Is match): %v", missing, err)
			}
		})
	}
}

// TestSearchEphemeralPreMigrationEmpty: a database with no `wisps` table has
// no wisp plane, so an ephemeral-only search of it comes back empty with no
// error.
func TestSearchEphemeralPreMigrationEmpty(t *testing.T) {
	sqldb, mock := newMockDB(t)
	expectWispsProbe(mock, false)
	mock.ExpectQuery("FROM wisps").WillReturnError(missingTable("wisps"))
	mock.ExpectQuery("FROM issues").WillReturnRows(sqlmock.NewRows([]string{"id"}))

	repo := db.NewIssueSQLRepository(sqldb)
	page, err := repo.SearchAcrossIssuesAndWisps(context.Background(), "", ephemeralFilter())
	if err != nil {
		t.Fatalf("search errored on a database with no wisps table: %v", err)
	}
	if len(page.Items) != 0 {
		t.Fatalf("got %d rows, want 0 (no wisps table)", len(page.Items))
	}
}

// TestSearchEphemeralUnrelatedErrorPropagates: a failure on the wisps query
// that is not a missing table (a dropped connection) is returned to the
// caller.
func TestSearchEphemeralUnrelatedErrorPropagates(t *testing.T) {
	sqldb, mock := newMockDB(t)
	boom := errors.New("connection refused")
	mock.ExpectQuery("FROM wisps").WillReturnError(boom)

	repo := db.NewIssueSQLRepository(sqldb)
	_, err := repo.SearchAcrossIssuesAndWisps(context.Background(), "", ephemeralFilter())
	if !errors.Is(err, boom) {
		t.Fatalf("search did not return a non-table-not-exist wisps failure: %v", err)
	}
}

// TestSearchUnionHydrateBrokenPlaneErrors: a merged search (no ephemeral
// filter) over a store whose wisps table has rows returns an error when
// loading the wisp rows fails on a missing `wisp_labels` or `leases` table.
// The UNION ALL query returns one wisp-tagged id; the wisp fetch after it
// raises the missing-table error. Issue hydration has no ids to load.
func TestSearchUnionHydrateBrokenPlaneErrors(t *testing.T) {
	for _, missing := range brokenTables {
		t.Run(missing, func(t *testing.T) {
			sqldb, mock := newMockDB(t)
			gone := missingTable(missing)
			expectWispsProbe(mock, true)
			mock.ExpectQuery("UNION ALL").WillReturnRows(sqlmock.NewRows([]string{"id", "src"}).AddRow("w-1", "w"))
			mock.ExpectQuery("FROM wisps").WillReturnError(gone)

			repo := db.NewIssueSQLRepository(sqldb)
			page, err := repo.SearchAcrossIssuesAndWisps(context.Background(), "", types.IssueFilter{})
			if err == nil {
				t.Fatalf("merged search succeeded with a missing %s table, returning %d rows (want error)", missing, len(page.Items))
			}
			if !errors.Is(err, gone) {
				t.Fatalf("merged search error does not carry the missing-%s driver failure (want errors.Is match): %v", missing, err)
			}
		})
	}
}

// TestSearchMergePreMigrationReturnsIssues: a merged search over a database
// with no `wisps` table answers from the issues table alone with no error.
// The issues result is empty because the full issue row is too wide to fake
// here.
func TestSearchMergePreMigrationReturnsIssues(t *testing.T) {
	sqldb, mock := newMockDB(t)
	expectWispsProbe(mock, false)
	mock.ExpectQuery("FROM issues").WillReturnRows(sqlmock.NewRows([]string{"id"}))

	repo := db.NewIssueSQLRepository(sqldb)
	page, err := repo.SearchAcrossIssuesAndWisps(context.Background(), "", types.IssueFilter{})
	if err != nil {
		t.Fatalf("merged search errored on a database with no wisps table: %v", err)
	}
	if len(page.Items) != 0 {
		t.Fatalf("got %d rows, want 0 (no wisps table, no issue rows)", len(page.Items))
	}
}
