// Behavioral verifier for the classic issueops search stack.
//
// Driven entirely through the pre-existing exported entrypoints
// issueops.SearchIssuesInTx / SearchIssueIDsInTx. The DBTX parameter they
// take is satisfied directly by a go-sqlmock *sql.DB (ExecContext /
// QueryContext / QueryRowContext), so no real database, no cgo, and no Dolt
// are involved. This file lives in the external test package `issueops_test`
// on purpose: it exercises only the stable public surface, it cannot touch
// unexported helpers, and it will not collide with the package's own
// in-package test helpers (beginMockTx, missingTableError, ...).
//
// The contract under test: when the wisps table is present, a wisp search
// whose query hits a missing `wisp_labels` or `leases` table returns an error
// that carries the driver failure, on the ephemeral-only path and on the
// merged path, through both projections. A database with no `wisps` table
// still searches cleanly: an ephemeral search comes back empty and a merged
// search returns the durable rows. Every must-error assertion uses errors.Is
// against the primed driver sentinel, never a message substring, because the
// SQL text itself names the joined tables.
//
// Each case primes one consistent database state and matches queries in any
// order, so a search may ask the cheap wisps presence probe ("SELECT 1 FROM
// wisps") before or after its wisps query, or not at all.
package issueops_test

import (
	"context"
	"database/sql"
	"errors"
	"testing"

	sqlmock "github.com/DATA-DOG/go-sqlmock"
	mysql "github.com/go-sql-driver/mysql"

	"github.com/steveyegge/beads/internal/storage/issueops"
	"github.com/steveyegge/beads/internal/types"
)

func boolPtr(b bool) *bool { return &b }

// tableNotFound builds the driver's table-not-exist error (MySQL 1146,
// ER_NO_SUCH_TABLE) for a named table, in the message form go-mysql-server
// uses.
func tableNotFound(table string) error {
	return &mysql.MySQLError{Number: 1146, Message: "table not found: " + table}
}

func newMockDB(t *testing.T) (*sql.DB, sqlmock.Sqlmock) {
	t.Helper()
	db, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("sqlmock.New: %v", err)
	}
	mock.MatchExpectationsInOrder(false)
	t.Cleanup(func() { _ = db.Close() })
	return db, mock
}

// expectWispsProbe primes the wisps presence probe twice, answering either
// "present with rows" or "table missing". It is declared before the broader
// "FROM wisps" expectation so a probe never lands on the search query's
// expectation. Cases that prime it do not assert ExpectationsWereMet, since a
// search that never probes leaves it unused.
func expectWispsProbe(mock sqlmock.Sqlmock, present bool) {
	for i := 0; i < 2; i++ {
		e := mock.ExpectQuery("SELECT 1 FROM wisps")
		if present {
			e.WillReturnRows(sqlmock.NewRows([]string{"1"}).AddRow(1))
		} else {
			e.WillReturnError(tableNotFound("wisps"))
		}
	}
}

// searchEntryPoint wraps each exported search entrypoint behind a uniform
// (rowCount, error) shape so every behavioral case runs against both the full
// SearchIssuesInTx projection and the id-only SearchIssueIDsInTx projection.
type searchEntryPoint struct {
	name string
	run  func(context.Context, issueops.DBTX, string, types.IssueFilter) (int, error)
}

var searchEntryPoints = []searchEntryPoint{
	{
		name: "SearchIssuesInTx",
		run: func(ctx context.Context, tx issueops.DBTX, q string, f types.IssueFilter) (int, error) {
			out, err := issueops.SearchIssuesInTx(ctx, tx, q, f)
			return len(out), err
		},
	},
	{
		name: "SearchIssueIDsInTx",
		run: func(ctx context.Context, tx issueops.DBTX, q string, f types.IssueFilter) (int, error) {
			out, err := issueops.SearchIssueIDsInTx(ctx, tx, q, f)
			return len(out), err
		},
	},
}

// brokenTables are tables the wisp query reads that are not part of the
// "no wisp tables at all" shape. Their absence is a damaged store.
var brokenTables = []string{"wisp_labels", "leases"}

// TestWispSearchEphemeralBrokenPlaneErrors: with the wisps table present and
// holding rows, an ephemeral-only search whose wisps query fails on a missing
// `wisp_labels` or `leases` table returns an error that wraps that driver
// failure. The issues query is primed so that a search which answers without
// an error gets a clean (0 rows, nil) instead of an unexpected-query error.
func TestWispSearchEphemeralBrokenPlaneErrors(t *testing.T) {
	for _, missing := range brokenTables {
		for _, ep := range searchEntryPoints {
			t.Run(missing+"/"+ep.name, func(t *testing.T) {
				db, mock := newMockDB(t)
				gone := tableNotFound(missing)
				expectWispsProbe(mock, true)
				mock.ExpectQuery("FROM wisps").WillReturnError(gone)
				mock.ExpectQuery("FROM issues").WillReturnRows(sqlmock.NewRows([]string{"id"}))

				n, err := ep.run(context.Background(), db, "", types.IssueFilter{Ephemeral: boolPtr(true)})
				if err == nil {
					t.Fatalf("search succeeded with a missing %s table, returning %d rows (want error)", missing, n)
				}
				if !errors.Is(err, gone) {
					t.Fatalf("error does not carry the missing-%s driver failure (want errors.Is match): %v", missing, err)
				}
			})
		}
	}
}

// TestWispSearchEphemeralPreMigrationEmpty: a database with no `wisps` table
// has no wisp plane, so an ephemeral-only search of it comes back empty with
// no error.
func TestWispSearchEphemeralPreMigrationEmpty(t *testing.T) {
	for _, ep := range searchEntryPoints {
		t.Run(ep.name, func(t *testing.T) {
			db, mock := newMockDB(t)
			expectWispsProbe(mock, false)
			mock.ExpectQuery("FROM wisps").WillReturnError(tableNotFound("wisps"))
			mock.ExpectQuery("FROM issues").WillReturnRows(sqlmock.NewRows([]string{"id"}))

			n, err := ep.run(context.Background(), db, "", types.IssueFilter{Ephemeral: boolPtr(true)})
			if err != nil {
				t.Fatalf("search errored on a database with no wisps table: %v", err)
			}
			if n != 0 {
				t.Fatalf("got %d rows, want 0 (no wisps table)", n)
			}
		})
	}
}

// TestWispSearchEphemeralUnrelatedErrorPropagates: a failure on the wisps
// query that is not a missing table (a dropped connection) is returned to the
// caller.
func TestWispSearchEphemeralUnrelatedErrorPropagates(t *testing.T) {
	for _, ep := range searchEntryPoints {
		t.Run(ep.name, func(t *testing.T) {
			db, mock := newMockDB(t)
			boom := errors.New("connection refused")
			mock.ExpectQuery("FROM wisps").WillReturnError(boom)

			_, err := ep.run(context.Background(), db, "", types.IssueFilter{Ephemeral: boolPtr(true)})
			if !errors.Is(err, boom) {
				t.Fatalf("search did not return a non-table-not-exist wisps failure: %v", err)
			}
		})
	}
}

// TestWispSearchMergeBrokenPlaneErrors: a merged search (no ephemeral filter)
// over a store whose wisps table has rows returns an error when the wisps leg
// fails on a missing `wisp_labels` or `leases` table.
func TestWispSearchMergeBrokenPlaneErrors(t *testing.T) {
	for _, missing := range brokenTables {
		for _, ep := range searchEntryPoints {
			t.Run(missing+"/"+ep.name, func(t *testing.T) {
				db, mock := newMockDB(t)
				gone := tableNotFound(missing)
				expectWispsProbe(mock, true)
				mock.ExpectQuery("FROM issues").WillReturnRows(sqlmock.NewRows([]string{"id"}))
				mock.ExpectQuery("FROM wisps").WillReturnError(gone)

				n, err := ep.run(context.Background(), db, "", types.IssueFilter{})
				if err == nil {
					t.Fatalf("merged search succeeded with a missing %s table, returning %d rows (want error)", missing, n)
				}
				if !errors.Is(err, gone) {
					t.Fatalf("merged search error does not carry the missing-%s driver failure (want errors.Is match): %v", missing, err)
				}
			})
		}
	}
}

// TestWispSearchMergePreMigrationReturnsIssues: a merged search over a
// database with no `wisps` table answers from the issues table alone with no
// error. The id projection gets two durable rows back; the full projection
// gets an empty issues result (its row shape is too wide to fake here) and
// must still finish cleanly.
func TestWispSearchMergePreMigrationReturnsIssues(t *testing.T) {
	t.Run("SearchIssueIDsInTx", func(t *testing.T) {
		db, mock := newMockDB(t)
		expectWispsProbe(mock, false)
		mock.ExpectQuery("FROM issues").WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow("bd-1").AddRow("bd-2"))
		mock.ExpectQuery("FROM wisps").WillReturnError(tableNotFound("wisps"))

		ids, err := issueops.SearchIssueIDsInTx(context.Background(), db, "", types.IssueFilter{})
		if err != nil {
			t.Fatalf("merged search errored on a database with no wisps table: %v", err)
		}
		if len(ids) != 2 || ids[0] != "bd-1" || ids[1] != "bd-2" {
			t.Fatalf("merged search returned %v, want [bd-1 bd-2]", ids)
		}
	})
	t.Run("SearchIssuesInTx", func(t *testing.T) {
		db, mock := newMockDB(t)
		expectWispsProbe(mock, false)
		mock.ExpectQuery("FROM issues").WillReturnRows(sqlmock.NewRows([]string{"id"}))
		mock.ExpectQuery("FROM wisps").WillReturnError(tableNotFound("wisps"))

		out, err := issueops.SearchIssuesInTx(context.Background(), db, "", types.IssueFilter{})
		if err != nil {
			t.Fatalf("merged search errored on a database with no wisps table: %v", err)
		}
		if len(out) != 0 {
			t.Fatalf("merged search returned %d rows, want 0", len(out))
		}
	})
}
