## Task

Wisps (ephemeral issues) can drop out of search results without any error.
On a database that has wisps, a search limited to ephemeral issues can come back empty, and an ordinary list of both kinds can come back without its wisps.
The call still reports success, so nothing tells you the answer is short.

We've reproduced it two ways: with the wisp labels table gone, and with the leases table gone.
Either way the search behaves as if the database had no wisps at all.
It's the same on the embedded database and with `--proxied-server`.

There is one setup where an empty answer is right.
A database created before wisps existed has no wisps table, and searching it has to keep working.
There an ephemeral-only search comes back empty and an ordinary list shows the regular issues, with no error in either case.

Make search report a damaged wisp store as an error instead of a short or empty result.
The error should carry the database's own error underneath, like other storage failures do.
