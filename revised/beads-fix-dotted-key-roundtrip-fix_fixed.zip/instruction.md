## Task

`bd` keeps per-workspace settings in `.beads/config.yaml`, which is tracked in git, and some of them use dotted keys such as `sync.remote` and `dolt.port`.
Operators keep finding that these dotted settings don't stick.
`bd` saves the value without complaint, but some of the commands that need it, sync among them, act as if it was never set.

We've seen it in three situations:
- A new workspace, where `.beads/config.yaml` is still empty or holds nothing but comments.
- A file that already has the setting on a single line, like `sync.remote: git@example.com:team/issues.git`, when `bd` saves a new value for it.
- A file where the section is there but empty, such as a bare `sync:` line left behind after the last setting under it was removed.

Unsetting is unreliable too.
The command reports success, but the old value stays in effect, so a sync remote the operator removed keeps getting used.

Some files hold the same setting both ways, a `sync.remote:` line and a `sync:` section with `remote:` under it.
Then `bd config get` shows one value while sync uses the other.
`bd config get` has the right answer there, and the rest of `bd` should agree with it.

Please make saving, reading and unsetting these settings line up, including over repeated changes.
Other tools edit this file as well, so leave its comments and every setting you weren't asked to change as they are.
If `bd` can't make a change cleanly, it should return an error and leave the file untouched instead of reporting success.
