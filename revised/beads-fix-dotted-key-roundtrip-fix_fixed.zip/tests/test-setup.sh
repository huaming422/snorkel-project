#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier (set -euo pipefail inherited).
# Go-only task: the image baked the full module + build cache at the base
# commit (image blocks 5 and 7). Nothing to install at grade time; just confirm
# the module graph resolves from the warm cache with the network cut, so a cache
# miss fails here fast instead of the verifier reaching for a proxy.
cd /repo/beads

export GOFLAGS=-mod=mod GOPROXY=off GOTOOLCHAIN=local

if go mod download > /tmp/test-setup-godl.log 2>&1; then
    echo "[offline-first] go modules satisfied from image cache"
else
    echo "[test-setup] go mod download failed offline:" >&2
    tail -40 /tmp/test-setup-godl.log >&2
    exit 1
fi

# No services to start, no data to seed: the bug lives entirely in the config
# read/write/unset path, which the verifier exercises directly through the
# package functions against temp dirs it creates itself.
