/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

// @ts-nocheck
//
// Checks for "Only Total" labels on stacked bar charts split by a second
// dimension ("Split stack by").
//
// Every assertion drives the plugin's default-export props-transform
// (`transformProps` from Timeseries/transformProps.ts) and reads only its
// output: each `echartOptions.series[].stack` group key and the string each
// `series[].label.formatter({ value, dataIndex, seriesIndex })` returns. These
// are the same surfaces the plugin's own unit suite inspects, so the checks
// do not depend on how the per-group data is stored or named internally.
// Nothing here imports a newly introduced symbol or asserts an internal name.
//
// The chart-props fixture builders below mirror the plugin's existing
// test/Timeseries helpers (shared createEchartsTimeseriesTestChartProps plus a
// local query-data builder) so the relative imports resolve exactly as the
// in-repo Timeseries suite's do when this file runs from test/Timeseries.

import {
  ChartDataResponseResult,
  DataRecord,
  SqlaFormData,
} from '@superset-ui/core';
import { GenericDataType } from '@apache-superset/core/common';
import transformProps from '../../src/Timeseries/transformProps';
import {
  EchartsTimeseriesChartProps,
  EchartsTimeseriesFormData,
} from '../../src/types';
import { StackControlsValue } from '../../src/constants';
import { DEFAULT_FORM_DATA } from '../../src/Timeseries/constants';
import { createEchartsTimeseriesTestChartProps } from '../helpers';
import { BASE_TIMESTAMP } from './helpers';

// Minimal, fully-typed-at-runtime query-data builder: fills the required
// ChartDataResponseResult fields and lets a test override colnames / coltypes /
// label_map, which is what the multi-metric / multi-groupby scenarios need.
function createTestQueryData(
  data: unknown[],
  overrides?: Partial<ChartDataResponseResult> & {
    label_map?: Record<string, string[]>;
  },
): ChartDataResponseResult {
  return {
    annotation_data: null,
    cache_key: null,
    cache_timeout: null,
    cached_dttm: null,
    queried_dttm: null,
    data: data as DataRecord[],
    colnames: [],
    coltypes: [],
    error: null,
    is_cached: false,
    query: '',
    rowcount: data.length,
    sql_rowcount: data.length,
    stacktrace: null,
    status: 'success',
    from_dttm: null,
    to_dttm: null,
    label_map: {},
    ...overrides,
  } as ChartDataResponseResult;
}

// createEchartsTimeseriesTestChartProps expects defaultQueriesData as an array;
// merge the scenario's formData over the plugin defaults and build the props.
function makeChartProps(
  formData: Partial<EchartsTimeseriesFormData>,
  queriesData: ChartDataResponseResult[],
): EchartsTimeseriesChartProps {
  return createEchartsTimeseriesTestChartProps<
    EchartsTimeseriesFormData,
    EchartsTimeseriesChartProps
  >({
    defaultFormData: { ...DEFAULT_FORM_DATA, ...formData },
    defaultVizType: 'my_viz',
    defaultQueriesData: queriesData,
  });
}

const baseFormData: SqlaFormData = {
  colorScheme: 'bnbColors',
  datasource: '3__table',
  granularity_sqla: 'ds',
  metric: 'sum__num',
  groupby: ['foo', 'bar'],
  viz_type: 'my_viz',
};

type SeriesLike = {
  name?: string;
  stack?: string;
  data: unknown[];
  label: { formatter: (params: unknown) => string };
};

function getSeries(
  chartProps: EchartsTimeseriesChartProps,
): SeriesLike[] {
  return transformProps(chartProps).echartOptions.series as SeriesLike[];
}

// Label text a series shows at one x position.
function labelAt(
  series: SeriesLike[],
  s: SeriesLike,
  dataIndex: number,
): string {
  return s.label.formatter({
    value: s.data[dataIndex],
    dataIndex,
    seriesIndex: series.indexOf(s),
  });
}

// The series of `group` drawn last, which sits on top of its stack.
function topOf(series: SeriesLike[], group: SeriesLike[]): SeriesLike {
  return group.reduce((top, s) =>
    series.indexOf(s) > series.indexOf(top) ? s : top,
  );
}

// At each x position the top series of `group` shows that position's total
// and every other series of the group shows ''.
function expectTotalsOnTop(
  series: SeriesLike[],
  group: SeriesLike[],
  totals: string[],
) {
  const top = topOf(series, group);
  totals.forEach((total, dataIndex) => {
    group.forEach(s =>
      expect(labelAt(series, s, dataIndex)).toBe(s === top ? total : ''),
    );
  });
}

describe('split-stack total labels verifier', () => {
  // ------------------------------------------------------------------
  // Two metrics, two group-by columns, split dimension = the SECOND group-by.
  // Series are stacked by their region value (East/West), not by the first
  // group-by (dept). Each region's total label shows that region's own sum
  // (10+20=30, 100+200=300); the other series in the group render ''.
  // ------------------------------------------------------------------
  test('assigns stack by the configured split dimension and labels each group with its own total (multi-metric, multi-groupby)', () => {
    const multiMetricFormData: Partial<EchartsTimeseriesFormData> = {
      viz_type: 'my_viz',
      colorScheme: 'bnbColors',
      datasource: '3__table',
      granularity_sqla: 'ds',
      metrics: ['sales', 'profit'],
      groupby: ['dept', 'region'],
      stackDimension: 'region',
      stack: StackControlsValue.Stack,
      onlyTotal: true,
      showValue: true,
    };

    const multiMetricQueriesData: ChartDataResponseResult[] = [
      createTestQueryData(
        [
          {
            __timestamp: BASE_TIMESTAMP,
            'sales, HR, East': 10,
            'profit, Sales, East': 20,
            'sales, HR, West': 100,
            'profit, Sales, West': 200,
          },
        ],
        {
          colnames: [
            '__timestamp',
            'sales, HR, East',
            'profit, Sales, East',
            'sales, HR, West',
            'profit, Sales, West',
          ],
          coltypes: [
            GenericDataType.Temporal,
            GenericDataType.Numeric,
            GenericDataType.Numeric,
            GenericDataType.Numeric,
            GenericDataType.Numeric,
          ],
          label_map: {
            'sales, HR, East': ['sales', 'HR', 'East'],
            'profit, Sales, East': ['profit', 'Sales', 'East'],
            'sales, HR, West': ['sales', 'HR', 'West'],
            'profit, Sales, West': ['profit', 'Sales', 'West'],
          },
        },
      ),
    ];

    const series = getSeries(
      makeChartProps(multiMetricFormData, multiMetricQueriesData),
    );

    const eastSeries = series.filter(s => s.name?.includes('East'));
    const westSeries = series.filter(s => s.name?.includes('West'));

    expect(eastSeries).toHaveLength(2);
    expect(westSeries).toHaveLength(2);

    // Stack assignment keyed by the split dimension's value, not by 'dept'.
    eastSeries.forEach(s => expect(s.stack).toBe('East'));
    westSeries.forEach(s => expect(s.stack).toBe('West'));

    // Each group's topmost series carries that group's own total; the other
    // series in the group renders an empty label.
    const eastLabels = eastSeries.map(s =>
      s.label.formatter({
        value: s.data[0],
        dataIndex: 0,
        seriesIndex: series.indexOf(s),
      }),
    );
    expect(eastLabels).toContain('30');
    expect(eastLabels).toContain('');

    const westLabels = westSeries.map(s =>
      s.label.formatter({
        value: s.data[0],
        dataIndex: 0,
        seriesIndex: series.indexOf(s),
      }),
    );
    expect(westLabels).toContain('300');
    expect(westLabels).toContain('');

    // The total sits on the top series of each region stack.
    expectTotalsOnTop(series, eastSeries, ['30']);
    expectTotalsOnTop(series, westSeries, ['300']);

    // No label equals a dept sum (HR=110, Sales=220).
    expect(eastLabels).not.toContain('110');
    expect(eastLabels).not.toContain('220');
    expect(westLabels).not.toContain('110');
    expect(westLabels).not.toContain('220');
  });

  // ------------------------------------------------------------------
  // Three metrics, split dimension = the second group-by (size): every
  // series is stacked by its size value, so there is one stack group per
  // size.
  // ------------------------------------------------------------------
  test('produces one distinct stack group per split-dimension value', () => {
    const stackDimensionFormData: Partial<EchartsTimeseriesFormData> = {
      ...(baseFormData as EchartsTimeseriesFormData),
      metric: ['count', 'revenue', 'units'],
      metrics: ['count', 'revenue', 'units'],
      groupby: ['region', 'size'],
      stack: StackControlsValue.Stack,
      stackDimension: 'size',
      showValue: true,
      onlyTotal: true,
    };

    const stackDimensionData: ChartDataResponseResult[] = [
      createTestQueryData(
        [
          {
            __timestamp: 1609459200000,
            'count, East, Large': 10,
            'revenue, East, Large': 100,
            'units, East, Large': 30,
            'count, East, Small': 5,
            'revenue, East, Small': 50,
            'units, East, Small': 15,
            'count, West, Large': 8,
            'revenue, West, Large': 80,
            'units, West, Large': 24,
            'count, West, Small': 4,
            'revenue, West, Small': 40,
            'units, West, Small': 12,
          },
        ],
        {
          colnames: [
            '__timestamp',
            'count, East, Large',
            'revenue, East, Large',
            'units, East, Large',
            'count, East, Small',
            'revenue, East, Small',
            'units, East, Small',
            'count, West, Large',
            'revenue, West, Large',
            'units, West, Large',
            'count, West, Small',
            'revenue, West, Small',
            'units, West, Small',
          ],
          coltypes: [
            GenericDataType.Temporal,
            GenericDataType.Numeric,
            GenericDataType.Numeric,
            GenericDataType.Numeric,
            GenericDataType.Numeric,
            GenericDataType.Numeric,
            GenericDataType.Numeric,
            GenericDataType.Numeric,
            GenericDataType.Numeric,
            GenericDataType.Numeric,
            GenericDataType.Numeric,
            GenericDataType.Numeric,
            GenericDataType.Numeric,
          ],
          label_map: {
            'count, East, Large': ['count', 'East', 'Large'],
            'revenue, East, Large': ['revenue', 'East', 'Large'],
            'units, East, Large': ['units', 'East', 'Large'],
            'count, East, Small': ['count', 'East', 'Small'],
            'revenue, East, Small': ['revenue', 'East', 'Small'],
            'units, East, Small': ['units', 'East', 'Small'],
            'count, West, Large': ['count', 'West', 'Large'],
            'revenue, West, Large': ['revenue', 'West', 'Large'],
            'units, West, Large': ['units', 'West', 'Large'],
            'count, West, Small': ['count', 'West', 'Small'],
            'revenue, West, Small': ['revenue', 'West', 'Small'],
            'units, West, Small': ['units', 'West', 'Small'],
          },
        },
      ),
    ];

    const series = getSeries(
      makeChartProps(stackDimensionFormData, stackDimensionData),
    );

    expect(series).toHaveLength(12);
    series.forEach(s =>
      expect(s.stack).toBe(s.name?.includes('Large') ? 'Large' : 'Small'),
    );
    expect(new Set(series.map(s => s.stack))).toEqual(
      new Set(['Large', 'Small']),
    );
  });

  // ------------------------------------------------------------------
  // One metric, split dimension = the second group-by (region), two x
  // positions, run with vertical and horizontal bars. Each region stack shows
  // its own total at each position (West 10+20=30 then 30+40=70, East 3+4=7
  // then 5+6=11), on the top series of that stack only.
  // ------------------------------------------------------------------
  test.each(['vertical', 'horizontal'])(
    'labels each split stack with its own total at every x position (single metric, %s)',
    orientation => {
      const singleMetricFormData: Partial<EchartsTimeseriesFormData> = {
        orientation,
        viz_type: 'my_viz',
        colorScheme: 'bnbColors',
        datasource: '3__table',
        granularity_sqla: 'ds',
        metric: 'sum__num',
        metrics: ['sum__num'],
        groupby: ['city', 'region'],
        stackDimension: 'region',
        stack: StackControlsValue.Stack,
        onlyTotal: true,
        showValue: true,
      };

      const singleMetricQueriesData: ChartDataResponseResult[] = [
        createTestQueryData(
          [
            {
              __timestamp: BASE_TIMESTAMP,
              'SF, West': 10,
              'LA, West': 20,
              'NY, East': 3,
              'Boston, East': 4,
            },
            {
              __timestamp: BASE_TIMESTAMP + 300000000,
              'SF, West': 30,
              'LA, West': 40,
              'NY, East': 5,
              'Boston, East': 6,
            },
          ],
          {
            colnames: [
              '__timestamp',
              'SF, West',
              'LA, West',
              'NY, East',
              'Boston, East',
            ],
            coltypes: [
              GenericDataType.Temporal,
              GenericDataType.Numeric,
              GenericDataType.Numeric,
              GenericDataType.Numeric,
              GenericDataType.Numeric,
            ],
            label_map: {
              'SF, West': ['SF', 'West'],
              'LA, West': ['LA', 'West'],
              'NY, East': ['NY', 'East'],
              'Boston, East': ['Boston', 'East'],
            },
          },
        ),
      ];

      const series = getSeries(
        makeChartProps(singleMetricFormData, singleMetricQueriesData),
      );

      const westSeries = series.filter(s => s.name?.includes('West'));
      const eastSeries = series.filter(s => s.name?.includes('East'));
      expect(westSeries).toHaveLength(2);
      expect(eastSeries).toHaveLength(2);
      westSeries.forEach(s => expect(s.stack).toBe('West'));
      eastSeries.forEach(s => expect(s.stack).toBe('East'));

      expectTotalsOnTop(series, westSeries, ['30', '70']);
      expectTotalsOnTop(series, eastSeries, ['7', '11']);
    },
  );

  // ------------------------------------------------------------------
  // Split dimension configured but not among the group-by columns: no error,
  // one stack per x position and a single total for it.
  // ------------------------------------------------------------------
  test('degrades gracefully when the split dimension is stale (not among group-by columns)', () => {
    const staleFormData: Partial<EchartsTimeseriesFormData> = {
      viz_type: 'my_viz',
      colorScheme: 'bnbColors',
      datasource: '3__table',
      granularity_sqla: 'ds',
      metrics: ['sales', 'profit'],
      groupby: ['dept'],
      stackDimension: 'removed_dimension',
      stack: StackControlsValue.Stack,
      onlyTotal: true,
      showValue: true,
    };

    const staleQueriesData: ChartDataResponseResult[] = [
      createTestQueryData(
        [
          {
            __timestamp: BASE_TIMESTAMP,
            'sales, HR': 10,
            'profit, Sales': 20,
          },
        ],
        {
          colnames: ['__timestamp', 'sales, HR', 'profit, Sales'],
          coltypes: [
            GenericDataType.Temporal,
            GenericDataType.Numeric,
            GenericDataType.Numeric,
          ],
          label_map: {
            'sales, HR': ['sales', 'HR'],
            'profit, Sales': ['profit', 'Sales'],
          },
        },
      ),
    ];

    const chartProps = makeChartProps(staleFormData, staleQueriesData);

    expect(() => transformProps(chartProps)).not.toThrow();

    // Both series share one stack, and its total 10 + 20 = 30 shows on the
    // top series only.
    const series = getSeries(chartProps);
    expect(new Set(series.map(s => s.stack)).size).toBe(1);
    expectTotalsOnTop(series, series, ['30']);
  });

  // ------------------------------------------------------------------
  // Split values named `__proto__` and `constructor` each get their own stack
  // group and their own total.
  // ------------------------------------------------------------------
  test('handles split-dimension values matching prototype property names', () => {
    const protoFormData: Partial<EchartsTimeseriesFormData> = {
      viz_type: 'my_viz',
      colorScheme: 'bnbColors',
      datasource: '3__table',
      granularity_sqla: 'ds',
      metrics: ['sales', 'profit'],
      groupby: ['category', 'region'],
      stackDimension: 'category',
      stack: StackControlsValue.Stack,
      onlyTotal: true,
      showValue: true,
    };

    const protoQueriesData: ChartDataResponseResult[] = [
      createTestQueryData(
        [
          {
            __timestamp: BASE_TIMESTAMP,
            'sales, __proto__, East': 50,
            'profit, constructor, East': 60,
          },
        ],
        {
          colnames: [
            '__timestamp',
            'sales, __proto__, East',
            'profit, constructor, East',
          ],
          coltypes: [
            GenericDataType.Temporal,
            GenericDataType.Numeric,
            GenericDataType.Numeric,
          ],
          label_map: {
            'sales, __proto__, East': ['sales', '__proto__', 'East'],
            'profit, constructor, East': ['profit', 'constructor', 'East'],
          },
        },
      ),
    ];

    const series = getSeries(makeChartProps(protoFormData, protoQueriesData));

    expect(series).toHaveLength(2);
    const protoSeries = series.find(s => s.name?.includes('__proto__'));
    const ctorSeries = series.find(s => s.name?.includes('constructor'));

    expect(protoSeries).toBeDefined();
    expect(ctorSeries).toBeDefined();

    expect(protoSeries!.stack).toBe('__proto__');
    expect(ctorSeries!.stack).toBe('constructor');

    const protoLabel = protoSeries!.label.formatter({
      value: protoSeries!.data[0],
      dataIndex: 0,
      seriesIndex: series.indexOf(protoSeries!),
    });
    expect(protoLabel).toBe('50');

    const ctorLabel = ctorSeries!.label.formatter({
      value: ctorSeries!.data[0],
      dataIndex: 0,
      seriesIndex: series.indexOf(ctorSeries!),
    });
    expect(ctorLabel).toBe('60');
  });

  // ------------------------------------------------------------------
  // A plain stacked onlyTotal chart with no split dimension, run with vertical
  // and horizontal bars, keeps one shared stack and one total label per x
  // position, on the top series.
  // ------------------------------------------------------------------
  test.each(['vertical', 'horizontal'])(
    'keeps one total label per x position for non-split stacked onlyTotal charts (%s)',
    orientation => {
      const noSplitFormData: Partial<EchartsTimeseriesFormData> = {
        orientation,
        viz_type: 'my_viz',
        colorScheme: 'bnbColors',
        datasource: '3__table',
        granularity_sqla: 'ds',
        metric: 'sum__num',
        groupby: ['city'],
        stack: StackControlsValue.Stack,
        onlyTotal: true,
        showValue: true,
      };

      const noSplitQueriesData: ChartDataResponseResult[] = [
        createTestQueryData(
          [
            {
              __timestamp: BASE_TIMESTAMP,
              'San Francisco': 1,
              'New York': 2,
            },
            {
              __timestamp: BASE_TIMESTAMP + 300000000,
              'San Francisco': 3,
              'New York': 4,
            },
          ],
          {
            colnames: ['__timestamp', 'San Francisco', 'New York'],
            coltypes: [
              GenericDataType.Temporal,
              GenericDataType.Numeric,
              GenericDataType.Numeric,
            ],
            label_map: {
              'San Francisco': ['San Francisco'],
              'New York': ['New York'],
            },
          },
        ),
      ];

      const series = getSeries(
        makeChartProps(noSplitFormData, noSplitQueriesData),
      );

      // Every series shares one stack group.
      expect(series).toHaveLength(2);
      expect(new Set(series.map(s => s.stack)).size).toBe(1);

      // The stack total across both series (1+2=3, then 3+4=7) shows on the
      // top series only.
      expectTotalsOnTop(series, series, ['3', '7']);
    },
  );
});
