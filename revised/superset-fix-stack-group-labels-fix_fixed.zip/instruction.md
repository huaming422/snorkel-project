## Task

We use two options together on stacked bar charts.
"Split stack by" adds a second dimension, so each x-axis cluster turns into a few stacks side by side.
"Only Total" hides the per-segment labels and puts one total on top of each stack.

With both turned on, the whole cluster gets a single total label instead of one per split stack.
Each split stack should show its own total, the sum of that stack's own segments, at every x value.
With "Split stack by" off, "Only Total" already labels each stack correctly, and that should stay as it is.

Charts with more than one metric and several group-by columns have a second problem.
If the "Split stack by" column isn't the first group-by column, the bars get split by the first group-by column anyway, so the stacks and their totals are wrong.
On those charts, taking the split column out of the group-by list doesn't stop the splitting either.
The bars still come apart by the first group-by column, where we'd expect one stack per x value with a single total.

One dataset we split by has category values named `__proto__` and `constructor`, and those stacks need their totals too.

Please find out what's going on and fix it so every split stack gets the right total.
