## Task

Saving a compute host's Details document fails the first time if a resource probe has already run on that host.
To see it, add an SSH host, run a probe on it, then type something into its Details and save.
The save is refused as if someone had changed the document in the meantime, but nothing was ever saved for that host.
Saving right after adding a host, before running a probe, works fine.

Agents hit the same thing through the compute API.
An agent reads the host's details, sends new text with what it just read as the old text, and gets back `replaceDetails: old_text does not match the current details document`.

Here's what should happen:
- Reading a host's details and then saving with that read as the baseline works on the first try, from the Settings page and from the agent API, and the next read returns exactly the saved text.
- If the host gets probed again between the read and the save, successfully or not, the save still goes through, since a probe isn't an edit to the document.
- If someone else saved or cleared the document after you read it, a save based on your older read fails and their version stays.
- Concurrent appends and the 32768-character limit keep working as they do now.
- Documents that were already saved come back unchanged.
- The probe's resource numbers stay available for the host.

Please leave SSH connections, authentication, scratch paths and the probe itself alone.
