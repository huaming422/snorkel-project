// @ts-nocheck
//
// Behavioural checks for the remote-compute host details read and save path,
// driven through the pre-existing ComputeHostProfileOwner boundary (the same
// public seam the repo's own owner + concurrency suites construct directly) and
// through the renderer handlers built by createComputeHandlers.
//
// Four groups:
//  1. getDetails (repository double): a read keeps the resource observations
//     next to the document and hands back a saved document unchanged.
//  1b. read-then-save per caller (Settings handlers and the agent-facing owner,
//     each over a repository double that enforces the stored-baseline guard):
//     a probed host with no saved document saves on the first try, a probe that
//     runs again between the read and the save does not block the save, a save
//     from a stale read is refused after another writer saves or clears the
//     document, the 32768-character limit holds on a save, and a saved
//     document reads back exactly.
//  2. read-then-save on real in-memory SQLite: the first save lands for a
//     probed host with no saved document, and the second of two saves made from
//     the same first read is refused.
//  3. guarded-save / append invariants on real in-memory SQLite: concurrent
//     saves still conflict, concurrent appends both survive, and the length
//     ceiling is re-checked after a competing write.

import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

vi.mock('electron', () => ({
  ipcMain: { handle: () => undefined },
  BrowserWindow: { getAllWindows: () => [] },
  shell: { showItemInFolder: () => undefined },
  app: {
    isPackaged: false,
    getAppPath: () => process.cwd(),
    getPath: (key?: string) => {
      if (key === 'home') return process.env.OPEN_SCIENCE_STORAGE_ROOT ?? tmpdir()
      return tmpdir()
    }
  }
}))

import type { ComputeHost } from '../../shared/compute'
import type { ComputeConnectionBrokerAcquirer } from './connection-broker'
import { ComputeHostProfileOwner } from './compute-host-profile-owner'
import { createComputeHandlers } from './ipc'
import { createProjectDbClient, migrateApplicationDatabase } from '../projects/prisma-client'
import { ComputeHostRepository } from './repository'

// ---------------------------------------------------------------------------
// Helpers mirrored from the repo's own owner-seam suite, which does not export
// them, so they are re-created here.
// ---------------------------------------------------------------------------

const sampleHost = (overrides: Partial<ComputeHost> = {}): ComputeHost => ({
  id: 'host-1',
  providerId: 'ssh:biowulf',
  displayName: 'biowulf',
  shape: 'direct_ssh',
  sshAlias: 'biowulf',
  sshOverrides: undefined,
  scratchRoot: undefined,
  scratchPinned: false,
  concurrencyLimit: undefined,
  probeResult: undefined,
  detailsDoc: '',
  detailsUpdatedAt: undefined,
  detailsUpdatedBy: undefined,
  createdAt: 1,
  updatedAt: 1,
  ...overrides
})

const makeFakeRunner = (result: unknown): ComputeConnectionBrokerAcquirer => ({
  acquire: vi.fn(async () => ({
    run: vi.fn(async () => result),
    upload: vi.fn(async () => undefined),
    download: vi.fn(async () => ({
      exitCode: 0,
      stderr: '',
      timedOut: false,
      bytesWritten: 0,
      exceeded: false
    }))
  }))
})

const makeRepo = (host: ComputeHost | null = sampleHost()) => {
  const updateDetails = vi.fn(() => Promise.resolve(true))
  const repo = {
    get: vi.fn(() => Promise.resolve(host)),
    list: vi.fn(() => Promise.resolve([])),
    create: vi.fn(),
    delete: vi.fn(),
    updateProbeResult: vi.fn(() => Promise.resolve(true)),
    updateDetails,
    updateScratchPinned: vi.fn(() => Promise.resolve()),
    clearScratchRoot: vi.fn(() => Promise.resolve()),
    updateConcurrencyLimit: vi.fn(() => Promise.resolve())
  } as unknown as ComputeHostRepository
  return { repo, updateDetails }
}

const fakeRunner = makeFakeRunner({
  exitCode: 0,
  stdout: '',
  stderr: '',
  timedOut: false,
  truncated: false
})

// A successful probe snapshot: observations exist, but no document was saved.
const okProbe = {
  ok: true as const,
  probedAt: '2026-01-01T00:00:00Z',
  exitCode: 0,
  errorTail: null,
  authenticationRevision: 1,
  cpus: 64,
  memMib: 256000,
  gpus: [{ type: 'A100 80GB', count: 2 }],
  detectedScheduler: 'slurm' as const
}

// ---------------------------------------------------------------------------
// 1. A read keeps the observations and returns a saved document unchanged.
// ---------------------------------------------------------------------------

describe('getDetails keeps the document and the probe observations', () => {
  it('keeps the probe observations available alongside the document read', async () => {
    const { repo } = makeRepo(sampleHost({ detailsDoc: '', probeResult: okProbe }))
    const owner = new ComputeHostProfileOwner(fakeRunner, repo)

    const details = await owner.getDetails('ssh:biowulf')

    // Resource observations are not dropped or merged into the document: they
    // remain reachable, unchanged, as their own structured channel.
    expect(details.probeResult).toEqual(okProbe)
  })

  it('hands back a saved document verbatim alongside the untouched observations', async () => {
    const { repo } = makeRepo(
      sampleHost({ detailsDoc: 'Use the long queue.', probeResult: okProbe })
    )
    const owner = new ComputeHostProfileOwner(fakeRunner, repo)

    const details = await owner.getDetails('ssh:biowulf')

    expect(details.doc).toBe('Use the long queue.')
    expect(details.probeResult).toEqual(okProbe)
  })
})

// ---------------------------------------------------------------------------
// 1b. Read-then-save through each caller.
//
// The Settings page reads and saves through the renderer handlers; agents read
// and save through the owner boundary that the agent-facing compute API calls.
// Every case runs once per caller, over a repository double whose guarded
// update only lands when the baseline it is handed matches the stored
// document, the same optimistic guard the production repository enforces.
// ---------------------------------------------------------------------------

type DetailsCaller = {
  read: (providerId: string) => Promise<{ doc: string }>
  save: (providerId: string, text: string, oldText: string) => Promise<unknown>
}

const guardedRepo = (host: ComputeHost): ComputeHostRepository =>
  ({
    get: async () => host,
    updateDetails: async (
      _providerId: string,
      text: string,
      _author: string,
      hostId: string,
      oldText: string
    ) => {
      if (host.id !== hostId || host.detailsDoc !== oldText) return false
      host.detailsDoc = text
      return true
    }
  }) as unknown as ComputeHostRepository

const callers: Array<[string, (repo: ComputeHostRepository) => DetailsCaller]> = [
  [
    'settings handlers',
    (repo) => {
      const handlers = createComputeHandlers(repo)
      return {
        read: (providerId) => handlers.detailsGet(providerId),
        save: (providerId, text, oldText) =>
          handlers.detailsSave(providerId, text, oldText, 'user')
      }
    }
  ],
  [
    'agent owner boundary',
    (repo) => {
      const owner = new ComputeHostProfileOwner(fakeRunner, repo)
      return {
        read: (providerId) => owner.getDetails(providerId),
        save: (providerId, text, oldText) =>
          owner.replaceDetails(providerId, { text, oldText, author: 'agent' })
      }
    }
  ]
]

// A probed host that has never had its document saved: resource observations
// exist, the saved document is still empty.
const makeProbedHost = (detailsDoc = ''): ComputeHost =>
  sampleHost({
    detailsDoc,
    probeResult: {
      ok: true,
      probedAt: '2026-01-01T00:00:00Z',
      exitCode: 0,
      errorTail: null,
      authenticationRevision: 1,
      cpus: 128,
      memMib: 512000,
      gpus: [{ type: 'H100 80GB', count: 4 }],
      detectedScheduler: 'slurm'
    } as ComputeHost['probeResult']
  })

// Probe results that land between the read and the save: one with different
// resources and scheduler, one failed run.
const laterProbes: Array<[string, ComputeHost['probeResult']]> = [
  [
    'a later successful probe with different resources',
    {
      ok: true,
      probedAt: '2026-01-02T00:00:00Z',
      exitCode: 0,
      errorTail: null,
      authenticationRevision: 1,
      cpus: 32,
      memMib: 96000,
      detectedScheduler: 'pbs'
    } as ComputeHost['probeResult']
  ],
  [
    'a later failed probe',
    {
      ok: false,
      probedAt: '2026-01-03T00:00:00Z',
      exitCode: 255,
      errorTail: 'ssh: connect to host biowulf port 22: Connection timed out',
      authenticationRevision: 1
    } as ComputeHost['probeResult']
  ]
]

describe.each(callers)('read-then-save through the %s', (_name, makeCaller) => {
  it('saves on the first try for a probed host with no saved document and reads it back', async () => {
    const host = makeProbedHost()
    const caller = makeCaller(guardedRepo(host))

    const initial = await caller.read(host.providerId)
    const instructions = 'Use direct SSH. Do not submit scheduler jobs unless asked.'
    await caller.save(host.providerId, instructions, initial.doc)

    // The stored document and the next read are exactly what was saved.
    expect(host.detailsDoc).toBe(instructions)
    expect((await caller.read(host.providerId)).doc).toBe(instructions)
  })

  it.each(laterProbes)(
    'still saves when %s lands between the read and the save',
    async (_label, laterProbe) => {
      const host = makeProbedHost()
      const caller = makeCaller(guardedRepo(host))

      const initial = await caller.read(host.providerId)
      host.probeResult = laterProbe

      const instructions = 'Stage inputs under /data/scratch before running.'
      await caller.save(host.providerId, instructions, initial.doc)
      expect(host.detailsDoc).toBe(instructions)
    }
  )

  it('refuses a save from a stale read after another writer saved first', async () => {
    const host = makeProbedHost()
    const caller = makeCaller(guardedRepo(host))

    const first = await caller.read(host.providerId)
    const second = await caller.read(host.providerId)

    await caller.save(host.providerId, 'Prefer the gpu partition.', first.doc)
    await expect(
      caller.save(host.providerId, 'Prefer the cpu partition.', second.doc)
    ).rejects.toThrow()

    // The earlier writer's text is kept.
    expect(host.detailsDoc).toBe('Prefer the gpu partition.')
  })

  it('refuses a save from a stale read after another writer cleared the document', async () => {
    const host = makeProbedHost('Load the cuda module first.')
    const caller = makeCaller(guardedRepo(host))

    const first = await caller.read(host.providerId)
    const second = await caller.read(host.providerId)

    await caller.save(host.providerId, '', first.doc)
    await expect(
      caller.save(host.providerId, 'Load the cuda and nccl modules first.', second.doc)
    ).rejects.toThrow()

    // The cleared document stays cleared.
    expect(host.detailsDoc).toBe('')
  })

  it('refuses a save one character over the 32768 limit and accepts one at the limit', async () => {
    const host = makeProbedHost('Short note.')
    const caller = makeCaller(guardedRepo(host))

    const initial = await caller.read(host.providerId)
    await expect(caller.save(host.providerId, 'y'.repeat(32769), initial.doc)).rejects.toThrow(
      /32768/
    )
    expect(host.detailsDoc).toBe('Short note.')

    await caller.save(host.providerId, 'y'.repeat(32768), initial.doc)
    expect(host.detailsDoc).toBe('y'.repeat(32768))
  })

  it('reads a saved document back exactly, including a resources section in it', async () => {
    const saved = '## Resources\n\ncpus: 8\nmem: 16 GB\n\nAsk before using more than 2 nodes.'
    const host = makeProbedHost(saved)
    const caller = makeCaller(guardedRepo(host))

    expect((await caller.read(host.providerId)).doc).toBe(saved)
  })
})

describe('the settings handlers keep the probe observations', () => {
  it('keeps probe resource observations reachable on their own channel', async () => {
    const host = makeProbedHost()
    const handlers = createComputeHandlers(guardedRepo(host))

    // The host read still surfaces the probe result with its resource fields intact.
    const probe = (await handlers.get(host.providerId))?.probeResult
    expect(probe).toMatchObject({ cpus: 128, detectedScheduler: 'slurm' })
  })
})

// ---------------------------------------------------------------------------
// 2. The normal read-then-save round trip on real SQLite.
// ---------------------------------------------------------------------------

describe('read-then-save round trip (real SQLite)', () => {
  let root: string
  let client: ReturnType<typeof createProjectDbClient>
  let repository: ComputeHostRepository

  beforeEach(async () => {
    root = await mkdtemp(join(tmpdir(), 'details-roundtrip-'))
    client = createProjectDbClient(root)
    await migrateApplicationDatabase(client)
    repository = new ComputeHostRepository(async () => client)
  })

  afterEach(async () => {
    await client?.$disconnect()
    if (root) await rm(root, { recursive: true, force: true })
  })

  const owner = (): ComputeHostProfileOwner =>
    new ComputeHostProfileOwner(
      { acquire: async () => ({ run: vi.fn() }) } as unknown as ComputeConnectionBrokerAcquirer,
      repository
    )

  // A host registered with no details, then probed so it carries resource
  // observations but still has an empty saved document.
  const probedHost = async () => {
    const host = await repository.create({ sshAlias: 'biowulf', detailsDoc: '' })
    expect(
      await repository.updateProbeResult(host.providerId, okProbe, 'scheduler_cluster', host.id)
    ).toBe(true)
    return host
  }

  it('saves on the first try for a host that has a probe and no saved document', async () => {
    const host = await probedHost()
    const service = owner()

    // Normal workflow: read the current details, then save them straight back
    // using what the read handed us as the baseline.
    const { doc } = await service.getDetails(host.providerId)
    await expect(
      service.replaceDetails(host.providerId, {
        text: 'Prefer the long partition.',
        oldText: doc,
        author: 'user'
      })
    ).resolves.toBeUndefined()

    // The text actually landed.
    expect((await repository.get(host.providerId))?.detailsDoc).toBe('Prefer the long partition.')
  })

  it('refuses the second of two saves made from the same first read', async () => {
    const host = await probedHost()
    const service = owner()

    const first = await service.getDetails(host.providerId)
    const second = await service.getDetails(host.providerId)

    await expect(
      service.replaceDetails(host.providerId, {
        text: 'Use the short queue for tests.',
        oldText: first.doc,
        author: 'user'
      })
    ).resolves.toBeUndefined()
    await expect(
      service.replaceDetails(host.providerId, {
        text: 'Use the debug queue for tests.',
        oldText: second.doc,
        author: 'agent'
      })
    ).rejects.toThrow()

    expect((await repository.get(host.providerId))?.detailsDoc).toBe(
      'Use the short queue for tests.'
    )
  })
})

// ---------------------------------------------------------------------------
// 3. Guarded-save / append invariants on real SQLite.
// ---------------------------------------------------------------------------

describe('guarded-save and append invariants are preserved (real SQLite)', () => {
  let root: string
  let client: ReturnType<typeof createProjectDbClient>
  let repository: ComputeHostRepository
  const providerId = 'ssh:cluster'

  beforeEach(async () => {
    root = await mkdtemp(join(tmpdir(), 'details-cas-'))
    client = createProjectDbClient(root)
    await migrateApplicationDatabase(client)
    repository = new ComputeHostRepository(async () => client)
    await repository.create({ sshAlias: 'cluster', detailsDoc: 'base' })
  })

  afterEach(async () => {
    await client?.$disconnect()
    if (root) await rm(root, { recursive: true, force: true })
  })

  const owner = (): ComputeHostProfileOwner =>
    new ComputeHostProfileOwner(
      { acquire: async () => ({ run: vi.fn() }) } as unknown as ComputeConnectionBrokerAcquirer,
      repository
    )

  // Hold the first two public reads until both writers share one DB snapshot, so
  // the two saves genuinely race against the same baseline.
  const synchronizeReads = (): void => {
    const get = repository.get.bind(repository)
    let arrivals = 0
    let release!: () => void
    const ready = new Promise<void>((resolve) => {
      release = resolve
    })
    vi.spyOn(repository, 'get').mockImplementation(async (id) => {
      const host = await get(id)
      if (++arrivals <= 2) {
        if (arrivals === 2) release()
        await ready
      }
      return host
    })
  }

  it('rejects one of two simultaneous replacements with a conflict', async () => {
    synchronizeReads()
    const service = owner()
    const results = await Promise.allSettled(
      ['first', 'second'].map((text) =>
        service.replaceDetails(providerId, { text, oldText: 'base', author: 'user' })
      )
    )
    expect(results.filter((r) => r.status === 'fulfilled')).toHaveLength(1)
    expect(results.find((r) => r.status === 'rejected')).toMatchObject({
      reason: expect.objectContaining({ message: expect.stringMatching(/conflict|old_text/i) })
    })
  })

  it('preserves both simultaneous appends', async () => {
    synchronizeReads()
    const service = owner()
    await Promise.all(
      ['first', 'second'].map((text) => service.appendDetails(providerId, { text, author: 'agent' }))
    )
    expect((await repository.get(providerId))?.detailsDoc.split('\n').sort()).toEqual([
      'base',
      'first',
      'second'
    ])
  })

  it('re-checks the length ceiling after a competing append', async () => {
    await client.computeHost.update({
      where: { providerId },
      data: { detailsDoc: 'x'.repeat(32760) }
    })
    synchronizeReads()
    const service = owner()
    const results = await Promise.allSettled(
      ['first', 'second'].map((text) => service.appendDetails(providerId, { text, author: 'agent' }))
    )
    expect(results.filter((r) => r.status === 'fulfilled')).toHaveLength(1)
    expect(results.find((r) => r.status === 'rejected')).toMatchObject({
      reason: expect.objectContaining({ message: expect.stringContaining('32768') })
    })
  })
})
