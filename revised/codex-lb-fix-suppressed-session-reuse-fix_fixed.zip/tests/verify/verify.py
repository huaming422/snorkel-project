"""Behavioral checks for HTTP-bridge sessions around a retry-circuit cooldown.

Contract, stated at the bridge's own pre-existing interfaces:

  * A request the hard-key retry circuit turns away keeps its rejection and is
    never sent upstream: a 503 ``upstream_request_timeout`` on the submit path,
    and the eventless-timeout code on the startup-continuity path (a 503 for a
    non-streaming client, a failed response event for a streaming one).
  * When no other turn has a claim on the pooled session that request was
    using, the session is no longer offered for reuse and a close of it is
    requested.
  * When another turn does have a claim on it (a registered admission waiter, a
    queued request, or an admitted half-open probe that has not reached its
    dispatch registration yet), the session stays open and reusable, and the
    admitted probe reaches dispatch.
  * Both the submit path and the startup-continuity path follow these rules,
    for a fresh session and for one that already served earlier turns, and on
    the startup path for both continuity bindings (a hard continuity anchor and
    a previous_response_id).

What the checks drive and observe (all pre-existing symbols):

  * drive: ``ProxyService._submit_http_bridge_request`` /
    ``_submit_http_bridge_request_with_handoff`` and
    ``_stream_http_bridge_session_events``;
  * observe: the rejection payload, ``session.closed``,
    ``_http_bridge_session_reusable_for_request``, and every close requested
    for the session through either ``_close_http_bridge_session_bounded`` or
    ``_close_http_bridge_session`` (both are recorded, with any reason);
  * cooldown: the hard-key retry circuit, put into cooldown through its own
    state (``_http_bridge_retry_circuits`` + ``_HTTPBridgeRetryCircuitState``),
    the same way the repo's own bridge suite does.

"Offered for reuse" means the session is not closed, no close of it was
requested, and the bridge's reuse predicate still accepts it. So a session
flagged for retirement, closed directly, or handed to the close path all count
as not offered, whichever way the change takes it out of service.

Fixtures and factories are self-contained because the repo's test conftest is
not in scope when this file is collected from /tests/verify/; they mirror the
repo's ``tests/unit/test_proxy_http_bridge.py`` helpers (``_make_bridge_session``,
the request-state construction, and the two autouse stubs).
"""

from __future__ import annotations

import asyncio
import os
import re
import subprocess
import sys
import time
from collections import deque
from contextlib import nullcontext
from types import SimpleNamespace
from typing import Any, cast

import anyio
import pytest

from app.core.clients.proxy import ProxyResponseError
from app.core.clients.proxy_websocket import UpstreamWebSocket
from app.core.errors import HTTP_BRIDGE_EVENTLESS_TIMEOUT_CODE
from app.core.utils.request_id import reset_request_scope_id, set_request_scope_id
from app.db.models import AccountStatus
from app.modules.proxy import service as proxy_service
from app.modules.proxy._service.http_bridge import helpers as http_bridge_helpers_module
from app.modules.proxy._service.http_bridge import retry_circuit as http_bridge_retry_circuit_module
from app.modules.proxy._service.http_bridge import streaming as http_bridge_streaming_module
from unittest.mock import AsyncMock

# Where the project checkout lives when the checks run (see tests/test-setup.sh).
REPO_DIR = os.environ.get("REPO_DIR", "/repo/codex-lb")

# The pre-existing bridge unit suite that the regression guard replays.
BRIDGE_SUITE = "tests/unit/test_proxy_http_bridge.py"

# The regression guard replays the slice of that module that covers session
# submit/dispatch, idle-lease handling, and the retire/drain/close machinery,
# and requires it to keep passing. It is a keyword selection rather than a
# whole-module replay because part of the module is not hermetic when the file
# is collected on its own. Several tests in the file-account affinity and
# dead-owner-recovery area call persistence helpers without requesting any
# schema-provisioning fixture, so they only pass when an earlier sibling has
# already created the relational schema on the shared session-scoped engine;
# collected alone they fail with a missing-table error on the unchanged tree.
# A second cluster, the poison/quarantine cooldown-TTL tests, depends on the
# live wall clock and is timing-sensitive under load. Neither area is part of
# the session lifecycle these checks cover. The keyword filter keeps the
# submit, dispatch, retire, drain, idle, lease, reuse/reusable, detach,
# admission, precreated, handoff and cooldown tests and drops the non-hermetic
# clusters; it selects the same set before and after a change, so a behavior
# change on those paths still fails it.
REGRESSION_KEEP_KEYWORDS = (
    "submit or dispatch or retire or drain or idle or reusable or reuse "
    "or detach or lease or admission or precreated or handoff or cooldown"
)
REGRESSION_DROP_KEYWORDS = (
    "file_pin or file_affinity or file_account or owner_misses or stale_cached "
    "or anchor_planning or quarantine or poison or dead_owner or _ttl or recovery"
)
REGRESSION_K_EXPR = f"({REGRESSION_KEEP_KEYWORDS}) and not ({REGRESSION_DROP_KEYWORDS})"

# How long the replayed suite slice may run before it is treated as hung.
_SUITE_TIMEOUT_SEC = 420

# Ways another turn can hold a claim on a session, set through the session's
# pre-existing counters.
_OWNER_KINDS = ("admission_waiter", "queued_request")


# --------------------------------------------------------------------------- #
# Autouse stubs: mirror the repo bridge suite's module-level autouse fixtures
# so these checks do not depend on the dashboard settings cache or the
# durable recovery-attempt schema.
# --------------------------------------------------------------------------- #
@pytest.fixture(autouse=True)
def _share_proxy_dashboard_settings(monkeypatch: pytest.MonkeyPatch) -> None:
    class _SettingsCache:
        async def get(self) -> object:
            return proxy_service.get_settings()

    monkeypatch.setattr(proxy_service, "get_settings_cache", lambda: _SettingsCache())


@pytest.fixture(autouse=True)
def _stub_recovery_attempt_lookup(monkeypatch: pytest.MonkeyPatch) -> None:
    from app.modules.proxy.durable_bridge_coordinator import DurableBridgeSessionCoordinator

    monkeypatch.setattr(
        DurableBridgeSessionCoordinator,
        "lookup_recovery_attempt",
        AsyncMock(return_value=None),
    )


# --------------------------------------------------------------------------- #
# Factories: self-contained copies of the repo bridge suite helpers.
# --------------------------------------------------------------------------- #
def _make_app_settings(**overrides: Any) -> Any:
    from app.core.config.settings import Settings

    return Settings(http_responses_session_bridge_enabled=True, **overrides)


def _make_bridge_session(*, key_value: str = "bridge-test") -> Any:
    session_key = proxy_service._HTTPBridgeSessionKey("session_header", key_value, None)
    return proxy_service._HTTPBridgeSession(
        key=session_key,
        headers={"x-codex-session-id": key_value},
        affinity=proxy_service._AffinityPolicy(
            key=key_value,
            kind=proxy_service.StickySessionKind.CODEX_SESSION,
        ),
        request_model="gpt-5.2",
        account=cast(
            Any,
            SimpleNamespace(
                id="acc-bridge",
                chatgpt_account_id="workspace-bridge",
                status=AccountStatus.ACTIVE,
                plan_type="plus",
            ),
        ),
        upstream=cast(UpstreamWebSocket, SimpleNamespace(close=AsyncMock())),
        upstream_control=proxy_service._WebSocketUpstreamControl(),
        pending_requests=deque(),
        pending_lock=anyio.Lock(),
        response_create_gate=asyncio.Semaphore(1),
        queued_request_count=0,
        last_used_at=1.0,
        idle_ttl_seconds=120.0,
    )


def _arm_cooldown(service: Any, session: Any, *, cooldown_until_offset: float = 60.0) -> None:
    """Put the hard-key retry circuit for this session's key into cooldown.

    Uses the circuit's own state object, as the repo bridge suite does. A
    positive offset leaves the cooldown active; a negative offset makes it
    already expired, so the first admission claims the half-open probe.
    """
    now = time.monotonic()
    cast(Any, service)._http_bridge_retry_circuits[session.key] = (
        http_bridge_retry_circuit_module._HTTPBridgeRetryCircuitState(
            consecutive_failures=2,
            cooldown_until=now + cooldown_until_offset,
            last_detail="stream_idle_timeout",
            last_touched_monotonic=now,
        )
    )
    service._durable_bridge = SimpleNamespace(lookup_retry_circuit=AsyncMock(return_value=None))


def _make_submit_request_state(request_id: str) -> Any:
    return proxy_service._WebSocketRequestState(
        request_id=request_id,
        model="gpt-5.6-luna",
        service_tier=None,
        reasoning_effort=None,
        api_key_reservation=None,
        started_at=time.monotonic(),
        transport="http",
        awaiting_response_created=True,
        request_text='{"type":"response.create","input":"hello"}',
    )


# The two ways a follow-up turn is bound to its earlier conversation with no
# safe replay: a hard continuity anchor on the session's turn state, or a
# previous_response_id under the default (fail-closed) recovery mode.
_FOLLOW_UP_KINDS = ("turn_state_anchor", "previous_response")


def _make_startup_request_state(request_id: str, session_id: str, kind: str = "turn_state_anchor") -> Any:
    continuity: dict[str, Any] = (
        {"previous_response_id": f"resp-earlier-{request_id}"}
        if kind == "previous_response"
        else {"hard_continuity_anchor": True}
    )
    return proxy_service._WebSocketRequestState(
        request_id=request_id,
        model="gpt-5.6",
        service_tier=None,
        reasoning_effort=None,
        api_key_reservation=None,
        started_at=time.monotonic(),
        event_queue=asyncio.Queue(),
        transport="http",
        session_id=session_id,
        **continuity,
    )


# A pooled session is either fresh (it never carried a turn) or one that has
# already served earlier turns before this request picked it up.
_SESSION_HISTORIES = ("fresh", "served_earlier_turn")


def _give_history(session: Any, history: str) -> None:
    if history != "served_earlier_turn":
        return
    earlier = {
        "last_used_at": time.monotonic() - 5.0,
        "last_completed_response_id": f"resp-served-{session.key.affinity_key}",
        "previous_response_ids": {f"resp-served-{session.key.affinity_key}"},
        "last_completed_input_count": 2,
        "prewarmed": True,
    }
    applied = 0
    for name, value in earlier.items():
        if hasattr(session, name):
            setattr(session, name, value)
            applied += 1
    assert applied >= 2, "the session type no longer records earlier turns"


class _CloseRecorder:
    """Records every close requested for a session, whichever close entry is used.

    Stands in for the bounded close and the direct close so no real socket
    teardown runs, and ignores the reason a caller passes.
    """

    def __init__(self) -> None:
        self.sessions: list[Any] = []

    async def bounded(self, session: Any, *, reason: str) -> None:
        self.sessions.append(session)

    async def direct(self, session: Any, **kwargs: Any) -> None:
        self.sessions.append(session)

    def install(self, service: Any, monkeypatch: pytest.MonkeyPatch | None = None) -> None:
        if monkeypatch is None:
            service._close_http_bridge_session_bounded = self.bounded
            service._close_http_bridge_session = self.direct
        else:
            monkeypatch.setattr(service, "_close_http_bridge_session_bounded", self.bounded, raising=False)
            monkeypatch.setattr(service, "_close_http_bridge_session", self.direct, raising=False)


async def _let_background_tasks_run(rounds: int = 20) -> None:
    # Yields to the event loop without asyncio.sleep, which the startup checks
    # replace with a mock.
    loop = asyncio.get_running_loop()
    for _ in range(rounds):
        step = loop.create_future()
        loop.call_soon(step.set_result, None)
        await step


def _reusable(session: Any) -> bool:
    return http_bridge_helpers_module._http_bridge_session_reusable_for_request(
        session=session,
        key=session.key,
        incoming_turn_state=None,
        previous_response_id=None,
    )


def _offered_for_reuse(session: Any, closes: _CloseRecorder) -> bool:
    return (
        not session.closed
        and not any(closed is session for closed in closes.sessions)
        and _reusable(session)
    )


def _give_owner(session: Any, owner: str) -> None:
    if owner == "admission_waiter":
        session.admission_waiter_count = 1
    else:
        session.queued_request_count = 1


def _owner_count(session: Any, owner: str) -> int:
    if owner == "admission_waiter":
        return session.admission_waiter_count
    return session.queued_request_count


def _use_startup_settings(
    service: Any,
    monkeypatch: pytest.MonkeyPatch,
    submit: AsyncMock | None,
    kind: str = "turn_state_anchor",
) -> None:
    overrides: dict[str, Any] = (
        {}
        if kind == "previous_response"
        else {"http_responses_session_bridge_ambiguous_continuation_recovery_mode": "server_anchored_replay_once"}
    )
    monkeypatch.setattr(proxy_service, "get_settings", lambda: _make_app_settings(**overrides))
    monkeypatch.setattr(
        service, "_http_bridge_precreated_retry_cooldown_seconds", AsyncMock(return_value=30.0)
    )
    if submit is not None:
        monkeypatch.setattr(service, "_submit_http_bridge_request", submit)
    monkeypatch.setattr(http_bridge_streaming_module.asyncio, "sleep", AsyncMock())


async def _run_startup_request(
    service: Any, session: Any, request_state: Any, turn_state: str, *, stream: bool = False
) -> list[str]:
    # stream=False is a non-streaming client (errors raise); stream=True is a
    # streaming client, which gets the failure as an event instead.
    events: list[str] = []
    async for event in service._stream_http_bridge_session_events(
        session,
        request_state=request_state,
        text_data='{"type":"response.create"}',
        queue_limit=8,
        propagate_http_errors=not stream,
        downstream_turn_state=turn_state,
    ):
        events.append(event)
    return events


# --------------------------------------------------------------------------- #
# Submit path, nobody else on the session: taken out of reuse and closed.
# --------------------------------------------------------------------------- #
@pytest.mark.asyncio
@pytest.mark.parametrize("history", _SESSION_HISTORIES)
async def test_submit_cooldown_suppression_retires_unowned_session(history: str) -> None:
    service = proxy_service.ProxyService(cast(Any, nullcontext()))
    session = _make_bridge_session(key_value=f"bridge-submit-cooldown-retires-{history}")
    _give_history(session, history)
    _arm_cooldown(service, session)
    closes = _CloseRecorder()
    closes.install(service)
    request_state = _make_submit_request_state("req-submit-cooldown-retires")

    with pytest.raises(ProxyResponseError) as exc_info:
        await service._submit_http_bridge_request_with_handoff(
            session,
            request_state=request_state,
            text_data=request_state.request_text or "",
            queue_limit=8,
            request_scope_id="scope-submit-cooldown-retires",
            owned_unanchored_handoff=False,
        )
    await _let_background_tasks_run()

    assert exc_info.value.status_code == 503
    assert exc_info.value.payload["error"]["code"] == "upstream_request_timeout"
    # A later request for this key cannot be handed the same session.
    assert _offered_for_reuse(session, closes) is False


@pytest.mark.asyncio
@pytest.mark.parametrize("history", _SESSION_HISTORIES)
async def test_submit_cooldown_suppression_closes_idle_undispatched_socket(history: str) -> None:
    service = proxy_service.ProxyService(cast(Any, nullcontext()))
    session = _make_bridge_session(key_value=f"bridge-submit-cooldown-closes-idle-{history}")
    _give_history(session, history)
    _arm_cooldown(service, session)
    closes = _CloseRecorder()
    closes.install(service)
    request_state = _make_submit_request_state("req-submit-cooldown-closes-idle")

    with pytest.raises(ProxyResponseError) as exc_info:
        await service._submit_http_bridge_request_with_handoff(
            session,
            request_state=request_state,
            text_data=request_state.request_text or "",
            queue_limit=8,
            request_scope_id="scope-submit-cooldown-closes-idle",
            owned_unanchored_handoff=False,
        )
    await _let_background_tasks_run()

    assert exc_info.value.status_code == 503
    assert exc_info.value.payload["error"]["code"] == "upstream_request_timeout"
    # The session's connection is closed rather than left in the pool.
    assert closes.sessions, "no close was requested for the turned-away session"
    assert all(closed is session for closed in closes.sessions)
    # The turned-away request left nothing queued on the session.
    assert session.queued_request_count == 0
    assert len(session.pending_requests) == 0


# --------------------------------------------------------------------------- #
# Submit path, another turn has a claim on the session: left alone.
# --------------------------------------------------------------------------- #
@pytest.mark.asyncio
@pytest.mark.parametrize("owner", _OWNER_KINDS)
async def test_submit_cooldown_suppression_spares_session_in_use_by_another_turn(owner: str) -> None:
    service = proxy_service.ProxyService(cast(Any, nullcontext()))
    session = _make_bridge_session(key_value=f"bridge-cooldown-foreign-{owner}")
    _arm_cooldown(service, session)
    closes = _CloseRecorder()
    closes.install(service)
    _give_owner(session, owner)
    request_state = _make_submit_request_state(f"req-cooldown-foreign-{owner}")

    token = set_request_scope_id(f"scope-cooldown-foreign-{owner}")
    try:
        with pytest.raises(ProxyResponseError) as exc_info:
            await service._submit_http_bridge_request(
                session,
                request_state=request_state,
                text_data=request_state.request_text or "",
                queue_limit=8,
            )
    finally:
        reset_request_scope_id(token)
    await _let_background_tasks_run()

    assert exc_info.value.status_code == 503
    assert exc_info.value.payload["error"]["code"] == "upstream_request_timeout"
    assert _offered_for_reuse(session, closes) is True
    assert closes.sessions == []
    # The other turn's claim is left as it was.
    assert _owner_count(session, owner) == 1


@pytest.mark.asyncio
async def test_submit_cooldown_suppression_spares_concurrently_admitted_probe(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # Two submits on one shared session as the cooldown expires. Probe A claims
    # the half-open lease and is held inside the admission gate; sibling B then
    # runs to completion and is turned away because A holds the lease. A must
    # still reach its dispatch registration, and the session stays in service.
    service = proxy_service.ProxyService(cast(Any, nullcontext()))
    session = _make_bridge_session(key_value="bridge-cooldown-probe-race")
    _arm_cooldown(service, session, cooldown_until_offset=-1.0)
    closes = _CloseRecorder()
    closes.install(service, monkeypatch)

    real_gate = service._http_bridge_precreated_retry_allowed
    probe_in_gate = asyncio.Event()
    suppressed_done = asyncio.Event()
    gate_calls = 0
    probe_claimed_leases: list[float] = []

    async def gate(target: Any, **kwargs: Any) -> bool:
        nonlocal gate_calls
        gate_calls += 1
        allowed = await real_gate(target, **kwargs)
        if gate_calls == 1:
            # Probe A: lease claimed, decision made, still inside the gate.
            probe_claimed_leases.extend(kwargs.get("claimed_lease_out") or [])
            probe_in_gate.set()
            await suppressed_done.wait()
        return allowed

    monkeypatch.setattr(service, "_http_bridge_precreated_retry_allowed", gate)
    monkeypatch.setattr(
        service, "_http_bridge_fair_share_threshold_pct", AsyncMock(return_value=0), raising=False
    )
    # Reaching this pre-existing dispatch-registration step shows the admitted
    # probe was not rejected before it could be sent.
    monkeypatch.setattr(
        service,
        "_ensure_http_bridge_session_stream_lease_locked",
        AsyncMock(side_effect=RuntimeError("probe reached dispatch registration")),
    )
    probe_state = _make_submit_request_state("req-cooldown-probe")
    suppressed_state = _make_submit_request_state("req-cooldown-suppressed")

    async def run_probe() -> None:
        token = set_request_scope_id("scope-cooldown-probe")
        try:
            await service._submit_http_bridge_request(
                session,
                request_state=probe_state,
                text_data=probe_state.request_text or "",
                queue_limit=8,
            )
        finally:
            reset_request_scope_id(token)

    async def run_suppressed() -> None:
        await probe_in_gate.wait()
        token = set_request_scope_id("scope-cooldown-suppressed")
        try:
            await service._submit_http_bridge_request(
                session,
                request_state=suppressed_state,
                text_data=suppressed_state.request_text or "",
                queue_limit=8,
            )
        finally:
            reset_request_scope_id(token)
            suppressed_done.set()

    probe_result, suppressed_result = await asyncio.gather(
        run_probe(), run_suppressed(), return_exceptions=True
    )
    await _let_background_tasks_run()

    # The sibling was turned away by the cooldown...
    assert isinstance(suppressed_result, ProxyResponseError)
    assert suppressed_result.status_code == 503
    assert suppressed_result.payload["error"]["code"] == "upstream_request_timeout"
    # ...and the admitted probe still reached dispatch on its own session.
    assert isinstance(probe_result, RuntimeError), probe_result
    assert str(probe_result) == "probe reached dispatch registration"
    assert len(probe_claimed_leases) == 1
    # The shared session stayed in service.
    assert closes.sessions == []
    assert _offered_for_reuse(session, closes) is True


@pytest.mark.asyncio
async def test_submit_cooldown_suppression_retires_session_after_earlier_request_left(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # Request A is admitted with no cooldown in place, reaches its dispatch
    # registration and fails there, so it is gone from the session. The circuit
    # then goes into cooldown and request B on the same session is turned away.
    # Nobody is using the session any more, so B's rejection takes it out of
    # service.
    service = proxy_service.ProxyService(cast(Any, nullcontext()))
    session = _make_bridge_session(key_value="bridge-cooldown-after-earlier-request")
    service._durable_bridge = SimpleNamespace(lookup_retry_circuit=AsyncMock(return_value=None))
    closes = _CloseRecorder()
    closes.install(service, monkeypatch)
    monkeypatch.setattr(
        service, "_http_bridge_fair_share_threshold_pct", AsyncMock(return_value=0), raising=False
    )
    monkeypatch.setattr(
        service,
        "_ensure_http_bridge_session_stream_lease_locked",
        AsyncMock(side_effect=RuntimeError("earlier request reached dispatch registration")),
    )
    earlier_state = _make_submit_request_state("req-earlier-request")

    token = set_request_scope_id("scope-earlier-request")
    try:
        with pytest.raises(RuntimeError, match="earlier request reached dispatch registration"):
            await service._submit_http_bridge_request(
                session,
                request_state=earlier_state,
                text_data=earlier_state.request_text or "",
                queue_limit=8,
            )
    finally:
        reset_request_scope_id(token)
    await _let_background_tasks_run()
    # The earlier request's failure alone leaves the session in service.
    assert _offered_for_reuse(session, closes) is True

    _arm_cooldown(service, session)
    turned_away_state = _make_submit_request_state("req-after-earlier-request")
    token = set_request_scope_id("scope-after-earlier-request")
    try:
        with pytest.raises(ProxyResponseError) as exc_info:
            await service._submit_http_bridge_request(
                session,
                request_state=turned_away_state,
                text_data=turned_away_state.request_text or "",
                queue_limit=8,
            )
    finally:
        reset_request_scope_id(token)
    await _let_background_tasks_run()

    assert exc_info.value.status_code == 503
    assert exc_info.value.payload["error"]["code"] == "upstream_request_timeout"
    assert closes.sessions, "no close was requested for the turned-away session"
    assert all(closed is session for closed in closes.sessions)
    assert _offered_for_reuse(session, closes) is False


# --------------------------------------------------------------------------- #
# Startup-continuity path: the same rules.
# --------------------------------------------------------------------------- #
# Follow-up kind, client delivery (streaming or not) and session history.
_STARTUP_RETIRE_CASES = [
    pytest.param("turn_state_anchor", False, "fresh", id="turn_state_anchor"),
    pytest.param("previous_response", False, "fresh", id="previous_response"),
    pytest.param("turn_state_anchor", True, "fresh", id="turn_state_anchor-streaming"),
    pytest.param("previous_response", True, "fresh", id="previous_response-streaming"),
    pytest.param("turn_state_anchor", False, "served_earlier_turn", id="turn_state_anchor-served_earlier_turn"),
]


def _assert_follow_up_turned_away(exc_info: Any, events: list[str], *, stream: bool) -> None:
    if stream:
        # A streaming client gets one failed-response event carrying the code.
        assert exc_info is None
        assert len(events) == 1, events
        assert "response.failed" in events[0]
        assert HTTP_BRIDGE_EVENTLESS_TIMEOUT_CODE in events[0]
    else:
        assert exc_info is not None
        assert exc_info.status_code == 503
        assert exc_info.payload["error"]["code"] == HTTP_BRIDGE_EVENTLESS_TIMEOUT_CODE


async def _turn_away_follow_up(
    service: Any, session: Any, request_state: Any, turn_state: str, *, stream: bool
) -> tuple[Any, list[str]]:
    try:
        events = await _run_startup_request(service, session, request_state, turn_state, stream=stream)
    except ProxyResponseError as exc:
        return exc, []
    return None, events


@pytest.mark.asyncio
@pytest.mark.parametrize(("kind", "stream", "history"), _STARTUP_RETIRE_CASES)
async def test_startup_cooldown_terminal_retires_unowned_session(
    monkeypatch: pytest.MonkeyPatch,
    kind: str,
    stream: bool,
    history: str,
) -> None:
    label = f"{kind}-{'stream' if stream else 'json'}-{history}"
    service = proxy_service.ProxyService(cast(Any, nullcontext()))
    session = _make_bridge_session(key_value=f"sid-startup-cooldown-retires-{label}")
    _give_history(session, history)
    request_state = _make_startup_request_state(
        f"req-startup-cooldown-retires-{label}", f"turn-state-startup-retires-{label}", kind
    )
    submit = AsyncMock()
    closes = _CloseRecorder()
    _use_startup_settings(service, monkeypatch, submit, kind)
    closes.install(service, monkeypatch)

    exc, events = await _turn_away_follow_up(
        service, session, request_state, f"turn-state-startup-retires-{label}", stream=stream
    )
    await _let_background_tasks_run()

    _assert_follow_up_turned_away(exc, events, stream=stream)
    submit.assert_not_awaited()
    # The session is closed and cannot be handed to a later request.
    assert closes.sessions, "no close was requested for the turned-away session"
    assert all(closed is session for closed in closes.sessions)
    assert _offered_for_reuse(session, closes) is False


# Owner kind, follow-up kind and client delivery (streaming or not).
_STARTUP_SPARE_CASES = [
    pytest.param(owner, kind, False, id=f"{owner}-{kind}")
    for kind in _FOLLOW_UP_KINDS
    for owner in _OWNER_KINDS
] + [
    pytest.param("admission_waiter", "turn_state_anchor", True, id="admission_waiter-turn_state_anchor-streaming"),
    pytest.param("queued_request", "previous_response", True, id="queued_request-previous_response-streaming"),
]


@pytest.mark.asyncio
@pytest.mark.parametrize(("owner", "kind", "stream"), _STARTUP_SPARE_CASES)
async def test_startup_cooldown_terminal_spares_session_in_use_by_another_turn(
    monkeypatch: pytest.MonkeyPatch,
    owner: str,
    kind: str,
    stream: bool,
) -> None:
    label = f"{owner}-{kind}-{'stream' if stream else 'json'}"
    service = proxy_service.ProxyService(cast(Any, nullcontext()))
    session = _make_bridge_session(key_value=f"sid-startup-cooldown-owned-{label}")
    _give_owner(session, owner)
    request_state = _make_startup_request_state(
        f"req-startup-cooldown-owned-{label}", f"turn-state-startup-owned-{label}", kind
    )
    submit = AsyncMock()
    closes = _CloseRecorder()
    _use_startup_settings(service, monkeypatch, submit, kind)
    closes.install(service, monkeypatch)

    exc, events = await _turn_away_follow_up(
        service, session, request_state, f"turn-state-startup-owned-{label}", stream=stream
    )
    await _let_background_tasks_run()

    _assert_follow_up_turned_away(exc, events, stream=stream)
    submit.assert_not_awaited()
    # The session another turn is using stays open and reusable.
    assert closes.sessions == []
    assert _offered_for_reuse(session, closes) is True
    assert _owner_count(session, owner) == 1


@pytest.mark.asyncio
@pytest.mark.parametrize("kind", _FOLLOW_UP_KINDS)
async def test_startup_cooldown_terminal_spares_concurrently_admitted_probe(
    monkeypatch: pytest.MonkeyPatch,
    kind: str,
) -> None:
    # Probe A goes through the submit path, claims the half-open lease and is
    # held inside the admission gate. A continuity-bound request B on the same
    # session then reaches the startup cooldown terminal and is turned away. A
    # must still reach its dispatch registration, and the session stays open.
    service = proxy_service.ProxyService(cast(Any, nullcontext()))
    session = _make_bridge_session(key_value=f"sid-startup-cooldown-probe-race-{kind}")
    _arm_cooldown(service, session, cooldown_until_offset=-1.0)
    _use_startup_settings(service, monkeypatch, None, kind)
    closes = _CloseRecorder()
    closes.install(service, monkeypatch)

    real_gate = service._http_bridge_precreated_retry_allowed
    probe_in_gate = asyncio.Event()
    startup_done = asyncio.Event()
    gate_calls = 0
    probe_claimed_leases: list[float] = []

    async def gate(target: Any, **kwargs: Any) -> bool:
        nonlocal gate_calls
        gate_calls += 1
        allowed = await real_gate(target, **kwargs)
        if gate_calls == 1:
            probe_claimed_leases.extend(kwargs.get("claimed_lease_out") or [])
            probe_in_gate.set()
            await startup_done.wait()
        return allowed

    monkeypatch.setattr(service, "_http_bridge_precreated_retry_allowed", gate)
    monkeypatch.setattr(
        service, "_http_bridge_fair_share_threshold_pct", AsyncMock(return_value=0), raising=False
    )
    monkeypatch.setattr(
        service,
        "_ensure_http_bridge_session_stream_lease_locked",
        AsyncMock(side_effect=RuntimeError("probe reached dispatch registration")),
    )
    probe_state = _make_submit_request_state("req-startup-race-probe")
    startup_state = _make_startup_request_state(
        f"req-startup-race-turned-away-{kind}", f"turn-state-startup-race-{kind}", kind
    )

    async def run_probe() -> None:
        token = set_request_scope_id("scope-startup-race-probe")
        try:
            await service._submit_http_bridge_request(
                session,
                request_state=probe_state,
                text_data=probe_state.request_text or "",
                queue_limit=8,
            )
        finally:
            reset_request_scope_id(token)

    async def run_startup() -> None:
        await probe_in_gate.wait()
        try:
            await _run_startup_request(service, session, startup_state, f"turn-state-startup-race-{kind}")
        finally:
            startup_done.set()

    probe_result, startup_result = await asyncio.gather(
        run_probe(), run_startup(), return_exceptions=True
    )
    await _let_background_tasks_run()

    assert isinstance(startup_result, ProxyResponseError), startup_result
    assert startup_result.status_code == 503
    assert startup_result.payload["error"]["code"] == HTTP_BRIDGE_EVENTLESS_TIMEOUT_CODE
    assert isinstance(probe_result, RuntimeError), probe_result
    assert str(probe_result) == "probe reached dispatch registration"
    assert len(probe_claimed_leases) == 1
    assert closes.sessions == []
    assert _offered_for_reuse(session, closes) is True


# --------------------------------------------------------------------------- #
# Regression guard: the pre-existing HTTP bridge unit suite still passes.
# --------------------------------------------------------------------------- #
def test_existing_http_bridge_unit_suite_still_passes() -> None:
    """Replay the session-lifecycle slice of the bridge unit suite.

    Normal submit/dispatch, idle-lease, and drain-retirement behavior stays as
    it is. Runs in the project environment via a subprocess so the suite
    collects its own conftest and fixtures. The keyword filter (see
    REGRESSION_K_EXPR) limits the replay to those paths and leaves out the
    module's non-hermetic clusters.
    """
    cmd = [
        sys.executable,
        "-m",
        "pytest",
        BRIDGE_SUITE,
        "-k",
        REGRESSION_K_EXPR,
        "-p",
        "no:cacheprovider",
        "-q",
        "--no-header",
        "-o",
        "addopts=",
    ]
    proc = subprocess.run(
        cmd,
        cwd=REPO_DIR,
        capture_output=True,
        text=True,
        timeout=_SUITE_TIMEOUT_SEC,
    )

    assert proc.returncode == 0, (
        "The session-lifecycle slice of the HTTP bridge unit suite failed.\n"
        f"command: {' '.join(cmd)}\n"
        f"exit code: {proc.returncode}\n"
        f"--- stdout (tail) ---\n{proc.stdout[-4000:]}\n"
        f"--- stderr (tail) ---\n{proc.stderr[-2000:]}"
    )

    # The filter must keep a substantial slice of the module, not collapse to
    # a handful of tests (for example if a rename stops the keywords from
    # matching). The unchanged module selects well over 150 tests here.
    passed_match = re.search(r"(\d+) passed", proc.stdout)
    n_passed = int(passed_match.group(1)) if passed_match else 0
    assert n_passed >= 150, (
        "The regression slice collected far fewer tests than expected "
        f"({n_passed} passed); the keyword filter may no longer match the "
        "session-lifecycle tests.\n"
        f"--- stdout (tail) ---\n{proc.stdout[-4000:]}"
    )
