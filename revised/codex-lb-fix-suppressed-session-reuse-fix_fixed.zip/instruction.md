## Task

We keep hitting a rejection storm on the proxy when it's under steady concurrent load.
It starts when the upstream retry circuit for a session key goes into its cooldown.
After that, requests on that key keep failing long after the upstream is healthy again, instead of the errors stopping once the cooldown runs out.
Quiet periods look fine.

While the cooldown is on, requests on that key get turned away before anything is sent upstream.
A normal submit gets a 503 with error code `upstream_request_timeout`.
A follow-up turn that has to continue its earlier conversation and can't be replayed safely gets `bridge_eventless_timeout`, as a 503 when the client isn't streaming and as a failed response event when it is.
Those rejections are fine, and they should keep the same status and error code.

What we want after a request is turned away like that (either kind):

- If no other request is using the pooled upstream session it had opened or picked up, that session shouldn't be handed to any later request, and its connection should be closed.
- If another request does still have a claim on that session, leave the session open and usable, and let that request go ahead.
  A claim means it's queued on it, it's registered to go out on it, it was already sent on it and its response is still coming in, the session is reserved for it, or it's the request the cooldown let through and it hasn't been sent yet.

The one request the cooldown lets through must not end up failing because a sibling on the same session was turned away, for example with this 502:

```
502 {"error": {"message": "HTTP responses session bridge is retiring", "type": "server_error", "code": "upstream_unavailable"}}
```

The cooldown policy itself (when it trips and how long it lasts) is right, so don't change it.
Requests the cooldown doesn't turn away should still be queued, sent, and matched to pooled sessions exactly as they are today.
This reproduces in-process, so you don't need a live upstream to see it.
