## Task

We keep hitting a rejection storm on the proxy when it's under steady concurrent load.
It starts when the upstream retry circuit for a session key goes into its cooldown.
After that, requests on that key keep failing long after the upstream is healthy again, instead of the errors stopping once the cooldown runs out.
Quiet periods look fine.

While the cooldown is on, requests on that key get turned away with a 503.
A normal submit gets error code `upstream_request_timeout`.
A follow-up turn that has to stay on its earlier conversation and can't be replayed safely gets `bridge_eventless_timeout`.
Those rejections are fine, and they should keep the same status and error code.

Every so often the one request the cooldown does let through gets killed too, with a 502:

```
502 {"error": {"message": "HTTP responses session bridge is retiring", "type": "server_error", "code": "upstream_unavailable"}}
```

What we want after a request is turned away like that (either kind):

- If no other request is using the pooled upstream session it had opened or picked up, that session shouldn't be handed to any later request, and its connection should be closed.
- If another request does still have a claim on that session (it's queued on it, it's registered to go out on it, or it's the request the cooldown let through and it hasn't been sent yet), leave the session open and usable, and let that request go ahead.

The cooldown policy itself (when it trips and how long it lasts) is right, so don't change it.
This reproduces in-process, so you don't need a live upstream to see it.
