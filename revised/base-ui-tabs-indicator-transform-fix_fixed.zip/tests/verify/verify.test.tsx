// @ts-nocheck
//
// Behavioral checks for the Tabs highlight position.
//
// Every case renders the public component (`Tabs.Root` / `Tabs.List` /
// `Tabs.Tab` / `Tabs.Indicator`) in the repository's real-browser test tier
// (Chromium via Playwright, selected with VITEST_ENV=chromium). The highlight
// is observed only through its rendered box and the public CSS variables it
// exposes.
//
// Observation: a sibling box ("bubble") is laid over the active tab using the
// CSS variables the indicator publishes, the way a consumer would. The bubble
// and the active tab share any ancestor transform, so their on-screen
// rectangles coincide when the highlight is positioned correctly.
//
// The "rendering" group covers transformed ancestors (2D and 3D rotation,
// horizontal and vertical flips, the rotate and scale longhands), offsets measured from the tab list,
// an inner scroll container scrolled sideways or down, a tab moved by its own translation, and the exact
// CSS variable values on flat, scaled and zero-scaled lists. The second group
// runs the pre-hydration script on server-style markup, including markup inside
// a transformed container, a list that is not the offset parent, and a tab
// inside a container scrolled sideways or down.

import * as React from 'react';
import { afterEach, expect } from 'vitest';
import { Tabs } from '@base-ui/react/tabs';
import { waitFor, screen } from '@mui/internal-test-utils';
import { createRenderer, isJSDOM } from '#test-utils';
import { getCssDimensions } from '../../utils/getCssDimensions';
import { script as generatedPrehydrationScript } from './prehydrationScript.min';

describe('<Tabs.Indicator /> positioning', () => {
  const { render } = createRenderer();

  // These behaviors are only observable in a real browser: a jsdom environment
  // returns zeroed rects and does not apply CSS transforms, so the transform
  // cases cannot be exercised there.
  describe.skipIf(isJSDOM)('rendering', () => {
    function assertSize(actual: string, expected: number) {
      const actualNumber = parseFloat(actual);
      expect(Math.abs(actualNumber - expected)).toBeLessThanOrEqual(0.01);
    }

    function assertBubblePositionVariables(
      bubble: HTMLElement,
      tabList: HTMLElement,
      activeTab: HTMLElement,
    ) {
      const tabRect = activeTab.getBoundingClientRect();
      const tabListRect = tabList.getBoundingClientRect();
      const { width: tabWidth, height: tabHeight } = getCssDimensions(activeTab);
      const { width: tabListWidth, height: tabListHeight } = getCssDimensions(tabList);
      const scaleX = tabListWidth > 0 ? tabListRect.width / tabListWidth : 1;
      const scaleY = tabListHeight > 0 ? tabListRect.height / tabListHeight : 1;

      const relativeLeft =
        (tabRect.left - tabListRect.left) / scaleX + tabList.scrollLeft - tabList.clientLeft;
      const relativeTop =
        (tabRect.top - tabListRect.top) / scaleY + tabList.scrollTop - tabList.clientTop;
      const relativeRight = tabList.scrollWidth - relativeLeft - tabWidth;
      const relativeBottom = tabList.scrollHeight - relativeTop - tabHeight;

      const bubbleComputedStyle = window.getComputedStyle(bubble);
      assertSize(bubbleComputedStyle.getPropertyValue('--active-tab-left'), relativeLeft);
      assertSize(bubbleComputedStyle.getPropertyValue('--active-tab-right'), relativeRight);
      assertSize(bubbleComputedStyle.getPropertyValue('--active-tab-top'), relativeTop);
      assertSize(bubbleComputedStyle.getPropertyValue('--active-tab-bottom'), relativeBottom);
      assertSize(bubbleComputedStyle.getPropertyValue('--active-tab-width'), tabWidth);
      assertSize(bubbleComputedStyle.getPropertyValue('--active-tab-height'), tabHeight);
    }

    // Lays a box over the active tab from the published CSS variables, the same
    // way the component's consumers place the visible highlight.
    const STYLED_INDICATOR_CSS = `
      [data-testid="bubble"] {
        position: absolute;
        top: 0;
        left: 0;
        width: var(--active-tab-width);
        height: var(--active-tab-height);
        transform: translate(var(--active-tab-left), var(--active-tab-top));
      }
    `;

    // The active tab is never the first one: its offset is non-zero, so a
    // highlight placed from the wrong geometry lands visibly away from it.
    function renderTransformedTabs(
      wrapperStyle: React.CSSProperties,
      tabsListStyle: React.CSSProperties = { display: 'flex', position: 'relative' },
      activeValue = 3,
    ) {
      return render(
        <React.Fragment>
          <style>{STYLED_INDICATOR_CSS}</style>
          <div style={wrapperStyle}>
            <Tabs.Root value={activeValue}>
              <Tabs.List style={tabsListStyle}>
                <Tabs.Tab value={1} style={{ width: '80px', height: '32px' }}>
                  One
                </Tabs.Tab>
                <Tabs.Tab value={2} style={{ width: '80px', height: '32px' }}>
                  Two
                </Tabs.Tab>
                <Tabs.Tab value={3} style={{ width: '80px', height: '32px' }}>
                  Three
                </Tabs.Tab>
                <Tabs.Indicator data-testid="bubble" />
              </Tabs.List>
            </Tabs.Root>
          </div>
        </React.Fragment>,
      );
    }

    function waitForEdgeToMatch(
      edge: 'left' | 'top' | 'right' | 'bottom',
      bubble: HTMLElement,
      activeTab: HTMLElement,
    ) {
      return waitFor(() => {
        const bubbleRect = bubble.getBoundingClientRect();
        const tabRect = activeTab.getBoundingClientRect();
        expect(Math.abs(bubbleRect[edge] - tabRect[edge])).toBeLessThanOrEqual(1);
      });
    }

    // The highlight's rendered box must coincide with the active tab's box.
    // Both share the ancestor transform, so this holds for any transform.
    async function waitForBubbleToOverlapActiveTab(bubble: HTMLElement, activeTab: HTMLElement) {
      await waitForEdgeToMatch('left', bubble, activeTab);
      await waitForEdgeToMatch('top', bubble, activeTab);
      await waitForEdgeToMatch('right', bubble, activeTab);
      await waitForEdgeToMatch('bottom', bubble, activeTab);
    }

    // ----- the highlight stays on the active tab -----

    // 240px of tabs inside a 200px viewport, so the container can scroll by up to 40px.
    it.each([
      [3, 40],
      [2, 25],
    ])(
      'accounts for a scrolled container between the tab list and active tab %s scrolled by %spx',
      async (activeValue, scrollLeft) => {
        await render(
          <React.Fragment>
            <style>{STYLED_INDICATOR_CSS}</style>
            <Tabs.Root value={activeValue}>
              <Tabs.List style={{ display: 'flex', position: 'relative' }}>
                <div
                  data-testid="scroller"
                  style={{ display: 'flex', width: '200px', overflowX: 'auto' }}
                >
                  <Tabs.Tab value={1} style={{ width: '80px', height: '32px', flexShrink: 0 }}>
                    One
                  </Tabs.Tab>
                  <Tabs.Tab value={2} style={{ width: '80px', height: '32px', flexShrink: 0 }}>
                    Two
                  </Tabs.Tab>
                  <Tabs.Tab value={3} style={{ width: '80px', height: '32px', flexShrink: 0 }}>
                    Three
                  </Tabs.Tab>
                </div>
                <Tabs.Indicator data-testid="bubble" />
              </Tabs.List>
            </Tabs.Root>
          </React.Fragment>,
        );

        const scroller = screen.getByTestId('scroller');
        const bubble = screen.getByTestId('bubble');
        const activeTab = screen.getAllByRole('tab')[activeValue - 1];

        scroller.scrollLeft = scrollLeft;
        // A tab resize makes the indicator measure again after the scroll.
        activeTab.style.width = '84px';

        await waitForBubbleToOverlapActiveTab(bubble, activeTab);
      },
    );

    // 96px of tabs inside a 70px-tall container, so it can scroll by up to 26px.
    it('accounts for a vertically scrolled container between a vertical tab list and the active tab', async () => {
      await render(
        <React.Fragment>
          <style>{STYLED_INDICATOR_CSS}</style>
          <Tabs.Root value={3} orientation="vertical">
            <Tabs.List style={{ display: 'flex', position: 'relative' }}>
              <div
                data-testid="scroller"
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  height: '70px',
                  overflowY: 'auto',
                }}
              >
                <Tabs.Tab value={1} style={{ width: '80px', height: '32px', flexShrink: 0 }}>
                  One
                </Tabs.Tab>
                <Tabs.Tab value={2} style={{ width: '80px', height: '32px', flexShrink: 0 }}>
                  Two
                </Tabs.Tab>
                <Tabs.Tab value={3} style={{ width: '80px', height: '32px', flexShrink: 0 }}>
                  Three
                </Tabs.Tab>
              </div>
              <Tabs.Indicator data-testid="bubble" />
            </Tabs.List>
          </Tabs.Root>
        </React.Fragment>,
      );

      const scroller = screen.getByTestId('scroller');
      const bubble = screen.getByTestId('bubble');
      const activeTab = screen.getAllByRole('tab')[2];

      scroller.scrollTop = 20;
      // A tab resize makes the indicator measure again after the scroll.
      activeTab.style.height = '34px';

      await waitForBubbleToOverlapActiveTab(bubble, activeTab);
    });

    it('accounts for a scrolled container between the tab list and the active tab inside a rotated card', async () => {
      await render(
        <React.Fragment>
          <style>{STYLED_INDICATOR_CSS}</style>
          <div style={{ transform: 'rotate(25deg)' }}>
            <Tabs.Root value={3}>
              <Tabs.List style={{ display: 'flex', position: 'relative' }}>
                <div
                  data-testid="scroller"
                  style={{ display: 'flex', width: '200px', overflowX: 'auto' }}
                >
                  <Tabs.Tab value={1} style={{ width: '80px', height: '32px', flexShrink: 0 }}>
                    One
                  </Tabs.Tab>
                  <Tabs.Tab value={2} style={{ width: '80px', height: '32px', flexShrink: 0 }}>
                    Two
                  </Tabs.Tab>
                  <Tabs.Tab value={3} style={{ width: '80px', height: '32px', flexShrink: 0 }}>
                    Three
                  </Tabs.Tab>
                </div>
                <Tabs.Indicator data-testid="bubble" />
              </Tabs.List>
            </Tabs.Root>
          </div>
        </React.Fragment>,
      );

      const scroller = screen.getByTestId('scroller');
      const bubble = screen.getByTestId('bubble');
      const activeTab = screen.getAllByRole('tab')[2];

      scroller.scrollLeft = 30;
      // A tab resize makes the indicator measure again after the scroll.
      activeTab.style.width = '84px';

      await waitForBubbleToOverlapActiveTab(bubble, activeTab);
    });

    it('overlays the active tab when an ancestor has a 2D rotation', async () => {
      await renderTransformedTabs({ transform: 'rotate(40deg)' });

      const bubble = screen.getByTestId('bubble');
      const activeTab = screen.getAllByRole('tab')[2];

      await waitForBubbleToOverlapActiveTab(bubble, activeTab);
      expect(bubble).not.toHaveAttribute('hidden');
    });

    it('overlays the active tab when an ancestor has a size-preserving flip', async () => {
      await renderTransformedTabs(
        { transform: 'scaleX(-1)' },
        { display: 'flex', position: 'relative' },
        2,
      );

      const bubble = screen.getByTestId('bubble');
      const activeTab = screen.getAllByRole('tab')[1];

      await waitForBubbleToOverlapActiveTab(bubble, activeTab);
      expect(bubble).not.toHaveAttribute('hidden');
    });

    it('sets transformed offsets relative to the tab list when the list is not the offset parent', async () => {
      await renderTransformedTabs(
        { position: 'relative', transform: 'rotate(40deg)' },
        { display: 'flex', marginLeft: '40px', border: '6px solid black' },
      );

      const bubble = screen.getByTestId('bubble');

      await waitFor(() => {
        const bubbleComputedStyle = window.getComputedStyle(bubble);
        assertSize(bubbleComputedStyle.getPropertyValue('--active-tab-left'), 160);
      });
      await waitFor(() => {
        const bubbleComputedStyle = window.getComputedStyle(bubble);
        assertSize(bubbleComputedStyle.getPropertyValue('--active-tab-top'), 0);
      });

      // The far edges are measured from the same list: its scrollable extent
      // minus the tab's offset and size.
      const tabList = screen.getByRole('tablist');
      const bubbleComputedStyle = window.getComputedStyle(bubble);
      assertSize(
        bubbleComputedStyle.getPropertyValue('--active-tab-right'),
        tabList.scrollWidth - 160 - 80,
      );
      assertSize(
        bubbleComputedStyle.getPropertyValue('--active-tab-bottom'),
        tabList.scrollHeight - 0 - 32,
      );
    });

    it('overlays the active tab in a rotated card when the list has a border and is the offset parent', async () => {
      await renderTransformedTabs(
        { transform: 'rotate(20deg)' },
        { display: 'flex', position: 'relative', border: '6px solid black' },
      );

      const bubble = screen.getByTestId('bubble');
      const activeTab = screen.getAllByRole('tab')[2];

      await waitForBubbleToOverlapActiveTab(bubble, activeTab);
    });

    it('overlays the active tab when an ancestor uses the rotate longhand', async () => {
      await renderTransformedTabs({ rotate: '40deg' });

      const bubble = screen.getByTestId('bubble');
      const activeTab = screen.getAllByRole('tab')[2];

      await waitForBubbleToOverlapActiveTab(bubble, activeTab);
      expect(bubble).not.toHaveAttribute('hidden');
    });

    it('overlays the active tab in a vertical list when an ancestor uses a flipping scale longhand', async () => {
      await renderTransformedTabs(
        { scale: '-1 1' },
        { display: 'flex', flexDirection: 'column', position: 'relative' },
        2,
      );

      const bubble = screen.getByTestId('bubble');
      const activeTab = screen.getAllByRole('tab')[1];

      await waitForBubbleToOverlapActiveTab(bubble, activeTab);
      expect(bubble).not.toHaveAttribute('hidden');
    });

    it('overlays the active tab in a vertical list when an ancestor is mirrored vertically', async () => {
      await renderTransformedTabs(
        { transform: 'scaleY(-1)' },
        { display: 'flex', flexDirection: 'column', position: 'relative' },
        3,
      );

      const bubble = screen.getByTestId('bubble');
      const activeTab = screen.getAllByRole('tab')[2];

      await waitForBubbleToOverlapActiveTab(bubble, activeTab);
      expect(bubble).not.toHaveAttribute('hidden');
    });

    it('overlays the active tab when an ancestor has a 3D rotation', async () => {
      await renderTransformedTabs({ transform: 'perspective(600px) rotateY(35deg)' });

      const bubble = screen.getByTestId('bubble');
      const activeTab = screen.getAllByRole('tab')[2];

      await waitForBubbleToOverlapActiveTab(bubble, activeTab);
      expect(bubble).not.toHaveAttribute('hidden');
    });

    it('follows the active tab when it has its own transform translation', async () => {
      await render(
        <React.Fragment>
          <style>{STYLED_INDICATOR_CSS}</style>
          <Tabs.Root value={3}>
            <Tabs.List style={{ display: 'flex', position: 'relative' }}>
              <Tabs.Tab value={1} style={{ width: '80px', height: '32px' }}>
                One
              </Tabs.Tab>
              <Tabs.Tab value={2} style={{ width: '80px', height: '32px' }}>
                Two
              </Tabs.Tab>
              <Tabs.Tab
                value={3}
                style={{
                  width: '80px',
                  height: '32px',
                  transform: 'translateX(12px) translateY(4px)',
                }}
              >
                Three
              </Tabs.Tab>
              <Tabs.Indicator data-testid="bubble" />
            </Tabs.List>
          </Tabs.Root>
        </React.Fragment>,
      );

      const bubble = screen.getByTestId('bubble');
      const activeTab = screen.getAllByRole('tab')[2];

      await waitForBubbleToOverlapActiveTab(bubble, activeTab);
    });

    it('follows the active tab when it uses the translate longhand', async () => {
      await render(
        <React.Fragment>
          <style>{STYLED_INDICATOR_CSS}</style>
          <Tabs.Root value={3}>
            <Tabs.List style={{ display: 'flex', position: 'relative' }}>
              <Tabs.Tab value={1} style={{ width: '80px', height: '32px' }}>
                One
              </Tabs.Tab>
              <Tabs.Tab value={2} style={{ width: '80px', height: '32px' }}>
                Two
              </Tabs.Tab>
              <Tabs.Tab value={3} style={{ width: '80px', height: '32px', translate: '12px 4px' }}>
                Three
              </Tabs.Tab>
              <Tabs.Indicator data-testid="bubble" />
            </Tabs.List>
          </Tabs.Root>
        </React.Fragment>,
      );

      const bubble = screen.getByTestId('bubble');
      const activeTab = screen.getAllByRole('tab')[2];

      await waitForBubbleToOverlapActiveTab(bubble, activeTab);
    });

    it('follows the active tab when the translate longhand uses percentages', async () => {
      await render(
        <React.Fragment>
          <style>{STYLED_INDICATOR_CSS}</style>
          <Tabs.Root value={3}>
            <Tabs.List style={{ display: 'flex', position: 'relative' }}>
              <Tabs.Tab value={1} style={{ width: '80px', height: '32px' }}>
                One
              </Tabs.Tab>
              <Tabs.Tab value={2} style={{ width: '80px', height: '32px' }}>
                Two
              </Tabs.Tab>
              {/* 50% of 80px = 40px across, 25% of 32px = 8px down. */}
              <Tabs.Tab value={3} style={{ width: '80px', height: '32px', translate: '50% 25%' }}>
                Three
              </Tabs.Tab>
              <Tabs.Indicator data-testid="bubble" />
            </Tabs.List>
          </Tabs.Root>
        </React.Fragment>,
      );

      const bubble = screen.getByTestId('bubble');
      const activeTab = screen.getAllByRole('tab')[2];

      await waitForBubbleToOverlapActiveTab(bubble, activeTab);
    });

    // ----- exact CSS variable values -----

    it('sets sub-pixel-precise CSS variables with no ancestor transform', async () => {
      await render(
        <Tabs.Root value={2}>
          <Tabs.List>
            <Tabs.Tab value={1}>One</Tabs.Tab>
            <Tabs.Tab value={2}>Two</Tabs.Tab>
            <Tabs.Tab value={3}>Three</Tabs.Tab>
            <Tabs.Indicator data-testid="bubble" />
          </Tabs.List>
        </Tabs.Root>,
      );

      const bubble = screen.getByTestId('bubble');
      const activeTab = screen.getAllByRole('tab')[1];
      const tabList = screen.getByRole('tablist');

      await waitFor(() => {
        assertBubblePositionVariables(bubble, tabList, activeTab);
      });
    });

    it('sets sub-pixel-precise CSS variables when an ancestor scales the list up', async () => {
      await render(
        <div style={{ transform: 'scale(1.5)', transformOrigin: 'top left' }}>
          <Tabs.Root value={3}>
            <Tabs.List style={{ display: 'flex' }}>
              <Tabs.Tab value={1}>One</Tabs.Tab>
              <Tabs.Tab value={2}>Two</Tabs.Tab>
              <Tabs.Tab value={3}>Three</Tabs.Tab>
              <Tabs.Indicator data-testid="bubble" />
            </Tabs.List>
          </Tabs.Root>
        </div>,
      );

      const bubble = screen.getByTestId('bubble');
      const activeTab = screen.getAllByRole('tab')[2];
      const tabList = screen.getByRole('tablist');

      await waitFor(() => {
        assertBubblePositionVariables(bubble, tabList, activeTab);
      });
    });

    it('sets exact CSS variables when the list has a border and is the offset parent', async () => {
      await renderTransformedTabs(
        {},
        { display: 'flex', position: 'relative', border: '6px solid black' },
        2,
      );

      const bubble = screen.getByTestId('bubble');
      const activeTab = screen.getAllByRole('tab')[1];
      const tabList = screen.getByRole('tablist');

      await waitFor(() => {
        assertBubblePositionVariables(bubble, tabList, activeTab);
      });
    });

    it('accounts for scroll and border when the tab list is axis-aligned scaled', async () => {
      await render(
        <div style={{ transform: 'scale(1.5)' }}>
          <Tabs.Root value={3}>
            <Tabs.List
              data-testid="tab-list"
              style={{
                width: '240px',
                display: 'flex',
                gap: '8px',
                overflowX: 'auto',
                border: '6px solid black',
                padding: '4px',
              }}
            >
              <Tabs.Tab value={1} style={{ flex: '0 0 120px' }}>
                One
              </Tabs.Tab>
              <Tabs.Tab value={2} style={{ flex: '0 0 120px' }}>
                Two
              </Tabs.Tab>
              <Tabs.Tab value={3} style={{ flex: '0 0 120px' }}>
                Three
              </Tabs.Tab>
              <Tabs.Tab value={4} style={{ flex: '0 0 120px' }}>
                Four
              </Tabs.Tab>
              <Tabs.Tab value={5} style={{ flex: '0 0 120px' }}>
                Five
              </Tabs.Tab>
              <Tabs.Indicator data-testid="bubble" />
            </Tabs.List>
          </Tabs.Root>
        </div>,
      );

      const bubble = screen.getByTestId('bubble');
      const tabList = screen.getByTestId('tab-list');
      const activeTab = screen.getAllByRole('tab')[2];

      tabList.scrollLeft = 80;

      await waitFor(() => {
        assertBubblePositionVariables(bubble, tabList, activeTab);
      });
    });

    it('falls back to offset positions when the tab list is scaled to zero', async () => {
      await render(
        <div style={{ transform: 'scale(0)' }}>
          <Tabs.Root value={2}>
            <Tabs.List
              data-testid="tab-list"
              style={{
                position: 'relative',
                width: '300px',
                display: 'flex',
                overflow: 'hidden',
              }}
            >
              <Tabs.Tab value={1} style={{ width: '100px', flexShrink: 0 }}>
                One
              </Tabs.Tab>
              <Tabs.Tab value={2} style={{ width: '100px', flexShrink: 0 }}>
                Two
              </Tabs.Tab>
              <Tabs.Indicator data-testid="bubble" />
            </Tabs.List>
          </Tabs.Root>
        </div>,
      );

      const bubble = screen.getByTestId('bubble');
      const activeTab = screen.getAllByRole('tab')[1];

      await waitFor(() => {
        const bubbleComputedStyle = window.getComputedStyle(bubble);
        assertSize(bubbleComputedStyle.getPropertyValue('--active-tab-left'), activeTab.offsetLeft);
      });

      const bubbleComputedStyle = window.getComputedStyle(bubble);
      assertSize(bubbleComputedStyle.getPropertyValue('--active-tab-top'), activeTab.offsetTop);
      assertSize(bubbleComputedStyle.getPropertyValue('--active-tab-width'), 100);
      expect(bubble).not.toHaveAttribute('hidden');
    });
  });

  // Pre-hydration paint: the inline script that positions the highlight before
  // the component hydrates.
  describe.skipIf(isJSDOM)('pre-hydration script execution', () => {
    let host: HTMLDivElement;

    afterEach(() => {
      host?.remove();
    });

    function renderServerMarkup({
      hidden = false,
      activeTabStyle = 'width: 100px; height: 40px;',
    } = {}) {
      host = document.createElement('div');
      if (hidden) {
        host.style.display = 'none';
      }
      host.innerHTML =
        '<div role="tablist" style="width: 300px; height: 40px; position: relative;">' +
        `<button data-active style="${activeTabStyle} padding: 0; border: 0;">One</button>` +
        '<button style="width: 100px; height: 40px; padding: 0; border: 0;">Two</button>' +
        '<span hidden></span>' +
        '</div>';
      document.body.appendChild(host);

      const tabsList = host.querySelector<HTMLElement>('[role="tablist"]')!;
      const activeTab = host.querySelector<HTMLElement>('[data-active]')!;
      const indicator = host.querySelector<HTMLElement>('span')!;

      const scriptElement = document.createElement('script');
      scriptElement.textContent = generatedPrehydrationScript;
      // Appending an inline script executes it synchronously with
      // `document.currentScript` set.
      indicator.after(scriptElement);

      return { tabsList, activeTab, indicator };
    }

    it('positions the indicator once a hidden streamed segment becomes visible', async () => {
      const { activeTab, indicator } = renderServerMarkup({ hidden: true });

      expect(indicator).toHaveAttribute('hidden');
      host.style.display = '';

      await waitFor(() => {
        expect(indicator).not.toHaveAttribute('hidden');
      });
      expect(getComputedStyle(indicator).getPropertyValue('--active-tab-width')).toBe(
        `${activeTab.offsetWidth}px`,
      );
    });

    function expectPrehydrationVariables(
      indicator: HTMLElement,
      tabsList: HTMLElement,
      expected: { left: number; top: number; width: number; height: number },
    ) {
      const style = getComputedStyle(indicator);
      const read = (name: string) => parseFloat(style.getPropertyValue(`--active-tab-${name}`));
      expect(Math.abs(read('left') - expected.left)).toBeLessThanOrEqual(1);
      expect(Math.abs(read('top') - expected.top)).toBeLessThanOrEqual(1);
      expect(Math.abs(read('width') - expected.width)).toBeLessThanOrEqual(1);
      expect(Math.abs(read('height') - expected.height)).toBeLessThanOrEqual(1);
      expect(
        Math.abs(read('right') - (tabsList.scrollWidth - expected.left - expected.width)),
      ).toBeLessThanOrEqual(1);
      expect(
        Math.abs(read('bottom') - (tabsList.scrollHeight - expected.top - expected.height)),
      ).toBeLessThanOrEqual(1);
    }

    // The active tab is never the first one, so its offset is non-zero, and the list is
    // wider than all its tabs, so a mirrored paint cannot land on the tab by symmetry.
    // Rows vary the active tab and the list border, so each expects a different offset.
    it.each([
      ['transform', 'rotate(30deg)', 2, 0],
      ['transform', 'scaleX(-1)', 3, 5],
      ['transform', 'perspective(600px) rotateY(35deg)', 2, 5],
      ['rotate', '30deg', 3, 0],
      ['scale', '-1 1', 2, 5],
    ])(
      'places the indicator on the active tab when the container has %s: %s (tab %s, %spx list border)',
      async (property, value, activeValue, border) => {
        host = document.createElement('div');
        host.style.setProperty(property, value);
        const tabs = [1, 2, 3]
          .map(
            (n) =>
              `<button ${n === activeValue ? 'data-active ' : ''}style="width: 100px; height: 40px; padding: 0; border: 0; flex-shrink: 0;">Tab ${n}</button>`,
          )
          .join('');
        host.innerHTML =
          `<div role="tablist" style="display: flex; width: 400px; height: 40px; position: relative; border: ${border}px solid black;">` +
          tabs +
          '<span hidden></span>' +
          '</div>';
        document.body.appendChild(host);

        const tabsList = host.querySelector<HTMLElement>('[role="tablist"]')!;
        const indicator = host.querySelector<HTMLElement>('span')!;

        const scriptElement = document.createElement('script');
        scriptElement.textContent = generatedPrehydrationScript;
        indicator.after(scriptElement);

        await waitFor(() => {
          expect(indicator).not.toHaveAttribute('hidden');
        });
        expectPrehydrationVariables(indicator, tabsList, {
          left: (activeValue - 1) * 100,
          top: 0,
          width: 100,
          height: 40,
        });
      },
    );

    it('accounts for a scrolled container between the tab list and the active tab inside a rotated container', async () => {
      host = document.createElement('div');
      host.style.transform = 'rotate(20deg)';
      host.innerHTML =
        '<div role="tablist" style="display: flex; width: 300px; height: 40px; position: relative;">' +
        '<div style="display: flex; width: 150px; overflow-x: auto;">' +
        '<button style="width: 100px; height: 40px; padding: 0; border: 0; flex-shrink: 0;">One</button>' +
        '<button style="width: 100px; height: 40px; padding: 0; border: 0; flex-shrink: 0;">Two</button>' +
        '<button data-active style="width: 100px; height: 40px; padding: 0; border: 0; flex-shrink: 0;">Three</button>' +
        '</div>' +
        '<span hidden></span>' +
        '</div>';
      document.body.appendChild(host);

      const tabsList = host.querySelector<HTMLElement>('[role="tablist"]')!;
      const scroller = tabsList.firstElementChild as HTMLElement;
      const indicator = host.querySelector<HTMLElement>('span')!;
      scroller.scrollLeft = 60;

      const scriptElement = document.createElement('script');
      scriptElement.textContent = generatedPrehydrationScript;
      indicator.after(scriptElement);

      await waitFor(() => {
        expect(indicator).not.toHaveAttribute('hidden');
      });
      // Tab 3 sits 200px into the wrapper, which is scrolled 60px.
      expectPrehydrationVariables(indicator, tabsList, { left: 140, top: 0, width: 100, height: 40 });
    });

    it('accounts for a scrolled container between the tab list and the active tab', async () => {
      host = document.createElement('div');
      host.innerHTML =
        '<div role="tablist" style="display: flex; width: 300px; height: 40px; position: relative;">' +
        '<div style="display: flex; width: 150px; overflow-x: auto;">' +
        '<button style="width: 100px; height: 40px; padding: 0; border: 0; flex-shrink: 0;">One</button>' +
        '<button data-active style="width: 100px; height: 40px; padding: 0; border: 0; flex-shrink: 0;">Two</button>' +
        '</div>' +
        '<span hidden></span>' +
        '</div>';
      document.body.appendChild(host);

      const tabsList = host.querySelector<HTMLElement>('[role="tablist"]')!;
      const scroller = tabsList.firstElementChild as HTMLElement;
      const activeTab = host.querySelector<HTMLElement>('[data-active]')!;
      const indicator = host.querySelector<HTMLElement>('span')!;
      scroller.scrollLeft = 50;

      const scriptElement = document.createElement('script');
      scriptElement.textContent = generatedPrehydrationScript;
      indicator.after(scriptElement);

      await waitFor(() => {
        expect(indicator).not.toHaveAttribute('hidden');
      });
      const expectedLeft =
        activeTab.getBoundingClientRect().left - tabsList.getBoundingClientRect().left;
      expect(
        Math.abs(parseFloat(getComputedStyle(indicator).getPropertyValue('--active-tab-left')) - expectedLeft),
      ).toBeLessThanOrEqual(1);
    });

    // The list is not positioned, so the tab's own offsets are measured from the
    // rotated container, 40px and the list's 5px border to the left of the list.
    it('places the indicator from the tab list when the list is not the offset parent', async () => {
      host = document.createElement('div');
      host.style.position = 'relative';
      host.style.transform = 'rotate(30deg)';
      host.innerHTML =
        '<div role="tablist" style="display: flex; width: 400px; height: 40px; margin-left: 40px; border: 5px solid black;">' +
        '<button style="width: 100px; height: 40px; padding: 0; border: 0; flex-shrink: 0;">One</button>' +
        '<button data-active style="width: 100px; height: 40px; padding: 0; border: 0; flex-shrink: 0;">Two</button>' +
        '<span hidden></span>' +
        '</div>';
      document.body.appendChild(host);

      const indicator = host.querySelector<HTMLElement>('span')!;

      const scriptElement = document.createElement('script');
      scriptElement.textContent = generatedPrehydrationScript;
      indicator.after(scriptElement);

      await waitFor(() => {
        expect(indicator).not.toHaveAttribute('hidden');
      });
      const indicatorStyle = getComputedStyle(indicator);
      expect(
        Math.abs(parseFloat(indicatorStyle.getPropertyValue('--active-tab-left')) - 100),
      ).toBeLessThanOrEqual(1);
      expect(
        Math.abs(parseFloat(indicatorStyle.getPropertyValue('--active-tab-top')) - 0),
      ).toBeLessThanOrEqual(1);
    });

    it('accounts for a vertically scrolled container between a vertical tab list and the active tab', async () => {
      host = document.createElement('div');
      host.innerHTML =
        '<div role="tablist" aria-orientation="vertical" style="display: flex; width: 100px; height: 120px; position: relative;">' +
        '<div style="display: flex; flex-direction: column; height: 60px; overflow-y: auto;">' +
        '<button style="width: 100px; height: 40px; padding: 0; border: 0; flex-shrink: 0;">One</button>' +
        '<button data-active style="width: 100px; height: 40px; padding: 0; border: 0; flex-shrink: 0;">Two</button>' +
        '</div>' +
        '<span hidden></span>' +
        '</div>';
      document.body.appendChild(host);

      const tabsList = host.querySelector<HTMLElement>('[role="tablist"]')!;
      const scroller = tabsList.firstElementChild as HTMLElement;
      const activeTab = host.querySelector<HTMLElement>('[data-active]')!;
      const indicator = host.querySelector<HTMLElement>('span')!;
      scroller.scrollTop = 15;

      const scriptElement = document.createElement('script');
      scriptElement.textContent = generatedPrehydrationScript;
      indicator.after(scriptElement);

      await waitFor(() => {
        expect(indicator).not.toHaveAttribute('hidden');
      });
      const expectedTop =
        activeTab.getBoundingClientRect().top - tabsList.getBoundingClientRect().top;
      expect(
        Math.abs(parseFloat(getComputedStyle(indicator).getPropertyValue('--active-tab-top')) - expectedTop),
      ).toBeLessThanOrEqual(1);
    });

    it('keeps observing until the active tab is fully measurable', async () => {
      // The tab has width but no height yet (e.g. styles or images still loading).
      const { activeTab, indicator } = renderServerMarkup({
        activeTabStyle: 'width: 100px; height: 0; overflow: hidden;',
      });

      await new Promise((resolve) => {
        setTimeout(resolve, 100);
      });
      expect(indicator).toHaveAttribute('hidden');

      activeTab.style.height = '40px';

      await waitFor(() => {
        expect(indicator).not.toHaveAttribute('hidden');
      });
    });
  });
});
