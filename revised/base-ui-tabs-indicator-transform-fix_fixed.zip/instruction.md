## Task

The highlight behind the active tab in our Tabs component (`Tabs.Indicator`) ends up in the wrong place once the tab strip sits inside a transformed container.
Rotate the card around it, mirror it with a negative scale, or tilt it in 3D with `perspective`, and the highlight lands visibly off the selected tab.
Rotating and mirroring go wrong whether the container uses `transform` or the separate `rotate` and `scale` properties.
On a plain strip it lines up fine.

Please make the highlight stay on the active tab in those cases, and that includes the early highlight painted before hydration (`renderBeforeHydration`).
The `--active-tab-*` values are offsets from the tab list, and they should stay that way under a transform too.

A few setups already work today and have to keep working:

- On a flat strip the variables keep the exact sub-pixel values they get now, and so does a strip whose container only scales it up, borders and the list's own scroll included.
- A list scaled down to nothing still gets the tab's offset position and stays visible.
- When tabs sit inside a horizontally scrolling wrapper within the list, the highlight accounts for how far that wrapper is scrolled whenever it gets positioned.
- On a plain strip, a tab that moves itself with its own `transform` or `translate` (pixel or percentage values) keeps the highlight on it.
- For a tab with no transform of its own, the early highlight still shows up once a hidden streamed segment becomes visible, and once the tab can be measured.

This shouldn't need any new public API.
You'll only see the problem in a real browser, since jsdom doesn't apply CSS transforms.
