## Task

The highlight behind the active tab in our Tabs component (`Tabs.Indicator`) ends up in the wrong place once the tab strip sits inside a transformed container.
Rotate the card around it, mirror it with a negative scale, or tilt it sideways in 3D with a `perspective()` rotation, and the highlight lands visibly off the selected tab.
Rotating and mirroring go wrong whether the container uses `transform` or the separate `rotate` and `scale` properties.
On a plain strip it lines up fine.

Please make the highlight stay on the active tab in those cases, and that includes the early highlight painted before hydration (`renderBeforeHydration`).
The `--active-tab-*` values are offsets from the tab list, and they should stay that way under a transform too.

Whatever works today has to keep working, down to the exact sub-pixel values the hydrated highlight gets on a flat or scaled-up strip, though the early highlight may wait for hydration when the active tab is itself transformed.

This shouldn't need any new public API.
You'll only see the problem in a real browser, since jsdom doesn't apply CSS transforms.
