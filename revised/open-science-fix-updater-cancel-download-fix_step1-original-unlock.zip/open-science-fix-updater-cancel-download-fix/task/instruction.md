## Task

people keep reporting that our updater's Cancel doesn't really cancel. when an
update is downloading and you hit Cancel, or just dismiss the dialog any other
way (the X, clicking the overlay, Escape), the dialog goes away but the download
keeps running in the background. reopen the updater a bit later and it's further
along than where you supposedly stopped it, so it clearly never actually
stopped.

a few folks also hit weirdness when they cancel and then immediately start the
download again: the retry doesn't cleanly restart, or the downloaded file ends
up missing or corrupt.

make Cancel actually abort the in-flight download on both of our update paths,
and make an immediate retry-after-cancel behave correctly. no new third-party
dependency for this.
