import { createHash } from 'node:crypto'
import { EventEmitter } from 'node:events'
import { existsSync } from 'node:fs'
import { mkdtemp, readFile, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import { afterEach, describe, expect, it, vi } from 'vitest'

// A correct cancel aborts the hanging transfer within milliseconds; these cases each complete well
// under a second. Cap every case at a few seconds so a solution that never aborts fails promptly
// instead of letting a case sit on the harness's large outer timeout and stall the whole run — a
// stalled run reads as an infra timeout, not the wrong-answer signal we want. Set in-file so it holds
// regardless of the outer per-case timeout the harness passes.
vi.setConfig({ testTimeout: 20000, hookTimeout: 20000 })

// electron is imported transitively (service.ts pulls app/BrowserWindow/dialog/shell; ipc.ts pulls
// ipcMain). Every case injects its own fakes, so stub the module to keep a real Electron runtime out
// of the test process. The ipcMain stub records every channel `registerUpdateIpcHandlers` wires up
// into REGISTERED_HANDLERS, so the cancel driver below can find the author's cancel command by name
// (see cancelVia). The hoisted map is shared across the mock and the suite.
const REGISTERED_HANDLERS = vi.hoisted(() => new Map<string, (...args: unknown[]) => unknown>())
vi.mock('electron', () => ({
  app: { getVersion: () => '0.0.0', getPath: () => tmpdir(), isPackaged: false },
  BrowserWindow: { getFocusedWindow: () => null, getAllWindows: () => [] },
  dialog: { showSaveDialog: async () => ({ canceled: true, filePath: undefined }) },
  shell: { openPath: async () => '', openExternal: async () => undefined },
  ipcMain: {
    handle: (channel: string, listener: (...args: unknown[]) => unknown) => {
      REGISTERED_HANDLERS.set(channel, listener)
    }
  }
}))

import type { UpdateManifest } from '../../shared/update'
import { ElectronUpdaterStrategy } from './electron-updater-strategy'
import { registerUpdateIpcHandlers } from './ipc'
import { UpdateService } from './service'

// The in-place strategy imports electron-updater at module load; every case here injects a fake
// updater, so stub the module to keep a real Electron runtime out of the test process. The stub also
// exposes a cancellation-token class modelled on electron-updater's real CancellationToken: it extends
// EventEmitter, exposes a readable `cancelled` flag, and EMITS a 'cancel' event when cancelled. The
// fake download body subscribes to that event to reject promptly — exactly as the real AppUpdater
// rejects downloadUpdate() when its token is cancelled. Whether a solution injects a token factory
// (the interface allows it) or constructs `new CancellationToken()` directly, it resolves to this
// class, so a cancel is observable to the fake without the test pinning how the strategy drives it.
vi.mock('electron-updater', () => ({
  autoUpdater: {},
  CancellationToken: class extends EventEmitter {
    cancelled = false
    cancel(): void {
      this.cancelled = true
      this.emit('cancel')
    }
  }
}))

type FakeToken = EventEmitter & { cancelled: boolean; cancel(): void }

// A rejection shaped like electron-updater's cancellation error (name 'CancellationError'). The real
// downloadUpdate rejects with this when its token is cancelled mid-flight; strategies distinguish it
// from a genuine failure either by the error name or by reading token.cancelled.
const cancellationError = (): Error => {
  const err = new Error('cancelled')
  err.name = 'CancellationError'
  return err
}

// Models the real download-in-progress: resolves only if the caller never cancels; rejects promptly
// with a cancellation error the moment the token is cancelled (as the real AppUpdater does). Used by
// cases that start a download and then cancel it — no out-of-band "release" is needed, so a blocking
// cancel() (one that awaits the download's settlement) and a non-blocking cancel() both unwedge here.
const hangUntilCancelled = (token?: FakeToken): Promise<void> =>
  new Promise<void>((_resolve, reject) => {
    if (token?.cancelled) return reject(cancellationError())
    token?.once('cancel', () => reject(cancellationError()))
  })

// Polls `predicate` on microtask/timer boundaries until it holds or the budget elapses, so a correct
// solution settles fast while an incorrect one fails promptly on the budget instead of sitting on the
// outer per-case timeout (which reads as an infra stall, not a wrong-answer signal).
const settleWithin = async (predicate: () => boolean, budgetMs = 500): Promise<boolean> => {
  const deadline = Date.now() + budgetMs
  while (Date.now() < deadline) {
    if (predicate()) return true
    await new Promise((resolve) => setTimeout(resolve, 5))
  }
  return predicate()
}

// --- Name-agnostic cancel driver -----------------------------------------------------------------
// The fix adds a new "cancel the in-flight download" operation to each update strategy, wires it to a
// new renderer->main command channel, and exposes it on the preload bridge. The strategy method name,
// the IPC channel name, and the bridge method name are all author-chosen (task.toml: "naming is free
// ... the method/action names are not contractual"; the rubric accepts "any consistent channel name
// and bridge method name"). So this suite never calls a hardcoded `strategy.cancel()`. Instead it
// drives cancel through the pre-existing `registerUpdateIpcHandlers` seam (which already routes
// getStatus/check/download/apply to the strategy) and resolves the ONE new command channel the fix
// registers by set-difference against the baseline channel set — whatever the author named it. The
// handler delegates to whatever strategy method the author chose, so a `cancel()`/`cancelDownload()`/
// `abort()`/arbitrary-named implementation that is correctly wired passes identically.

// The command channels present on the UNfixed baseline; the fix adds exactly one more for cancel.
const BASELINE_UPDATE_CHANNELS = new Set([
  'update:get-app-info',
  'update:get-status',
  'update:check',
  'update:download',
  'update:apply'
])

// Registers the given strategy's IPC handlers (via the pre-existing, unchanged
// `registerUpdateIpcHandlers(strategy?)` seam — the mocked ipcMain records them), finds the single NEW
// update:* command channel the fix added for cancel (by set-difference against the baseline channel
// set), and invokes it. The handler delegates to whatever strategy method the author chose, so the
// method name is never pinned. If the solution registered no new channel (e.g. it never wired cancel
// through IPC) the driver throws a clear message so the behavioral assertion that follows fails loudly.
const cancelVia = async (strategy: unknown): Promise<unknown> => {
  REGISTERED_HANDLERS.clear()
  // Pass the strategy explicitly so registration binds to this instance (the default would construct a
  // real one). The signature `registerUpdateIpcHandlers(strategy?)` is pre-existing and unchanged.
  ;(registerUpdateIpcHandlers as (s: unknown) => unknown)(strategy)
  const newChannels = [...REGISTERED_HANDLERS.keys()].filter(
    (ch) => ch.startsWith('update:') && !BASELINE_UPDATE_CHANNELS.has(ch)
  )
  if (newChannels.length !== 1) {
    throw new Error(
      `expected exactly one new update:* command channel for cancel, found ${JSON.stringify(newChannels)}`
    )
  }
  const handler = REGISTERED_HANDLERS.get(newChannels[0])!
  return handler()
}

// Minimal manifest body returned over the fake fetch for the manifest URL.
const jsonResponse = (body: unknown): Response =>
  ({ ok: true, status: 200, json: () => Promise.resolve(body) }) as unknown as Response

// A manifest that advertises a newer version with a single mac-arm64 installer on the same host as
// the manifest URL used below, so the manual-download path accepts it.
const downloadManifest = (size: number, sha256: string): UpdateManifest => ({
  version: '0.3.0',
  releaseDate: '',
  notes: '',
  downloads: {
    'mac-arm64': { url: 'https://statics.aipoch.com/releases/0.3.0/installer.dmg', size, sha256 }
  }
})

// A fetch that always fails — stands in for "no manifest reachable" where the in-place strategy's
// best-effort notes hydration must not touch a real network.
const offlineFetch = (): typeof fetch =>
  vi.fn(async () => {
    throw new Error('no network in test')
  }) as unknown as typeof fetch

// A faithful stand-in for electron-updater's autoUpdater. The important subtlety it models is the
// real AppUpdater re-entrancy: while a download is in progress it hands back the SAME live promise
// and ignores the token passed to a fresh call; the promise only clears in a finally once the
// underlying download settles. A retry that simply frees its slot on cancel would re-attach to the
// still-running download instead of starting a genuine new one — so this models that hazard exactly.
// The fake also mirrors the real contract that a cancelled download rejects with a CancellationError
// and fires an 'update-cancelled' event; the default body resolves immediately (a complete download).
class FakeUpdater extends EventEmitter {
  autoDownload = true
  autoInstallOnAppQuit = true
  // Number of genuine underlying download starts — every downloadUpdate call that actually enters the
  // body increments it (not just the first), so a strategy that fails to guard concurrency or that
  // re-starts on retry is observable regardless of the fake's own promise reuse.
  starts = 0
  // The body each download call runs. Default: emit progress + downloaded and resolve. Cases override
  // it to hang until cancelled, to capture the token, or to drive a multi-start retry sequence.
  runDownload: (token?: FakeToken) => Promise<void> = async () => {
    this.emit('download-progress', { percent: 42 })
    this.emit('update-downloaded', { version: '0.3.0' })
  }
  private downloadPromise: Promise<void> | null = null
  checkForUpdates = vi.fn(async () => {
    this.emit('checking-for-update')
    this.emit('update-available', { version: '0.3.0', releaseNotes: 'notes' })
  })
  downloadUpdate = vi.fn((token?: FakeToken): Promise<void> => {
    // Re-entrancy: a call while a prior download is live returns the SAME promise and ignores the new
    // token (exactly the real AppUpdater behavior the retry-drain hazard comes from).
    if (this.downloadPromise != null) return this.downloadPromise
    this.starts += 1
    // When the token is cancelled while this download is live, fire 'update-cancelled' so a strategy
    // that keys its reset off that event (as some do) sees it, mirroring the real updater.
    token?.once('cancel', () => this.emit('update-cancelled'))
    this.downloadPromise = this.runDownload(token).finally(() => {
      this.downloadPromise = null
    })
    return this.downloadPromise
  })
  quitAndInstall = vi.fn()
}

describe('UpdateService cancel/retry (manual-download path)', () => {
  let dir = ''
  afterEach(async () => {
    if (dir) await rm(dir, { recursive: true, force: true })
    dir = ''
  })

  // svc_cancel_aborts: cancelling an in-flight manual download stops the transfer (the hanging fetch
  // errors on abort), returns to a benign "available" state rather than flashing an error, and leaves
  // no partial installer behind. A status-only cancel that never aborts the fetch leaves the download
  // running, so the returned state is not 'available' and/or a partial file survives.
  it('svc_cancel_aborts: cancel aborts the in-flight download, resets to available, leaves no partial file', async () => {
    dir = await mkdtemp(join(tmpdir(), 'svc-'))
    const target = join(dir, 'installer.dmg')
    const manifestForCheck = downloadManifest(100, 'irrelevant')
    let onInstallerFetch: (() => void) | undefined
    const fetched = new Promise<void>((resolve) => (onInstallerFetch = resolve))
    const fetchImpl = ((input: unknown, init?: { signal?: AbortSignal }) => {
      if (String(input).endsWith('version.json')) {
        return Promise.resolve(jsonResponse(manifestForCheck))
      }
      const body = new ReadableStream({
        start(controller) {
          controller.enqueue(new Uint8Array([1, 2, 3]))
          init?.signal?.addEventListener('abort', () =>
            controller.error(new DOMException('The user aborted a request.', 'AbortError'))
          )
        }
      })
      onInstallerFetch?.()
      return Promise.resolve(new Response(body, { status: 200 }))
    }) as unknown as typeof fetch
    const service = new UpdateService({
      fetchImpl,
      platform: 'darwin',
      arch: 'arm64',
      currentVersion: '0.2.0',
      manifestUrl: 'https://statics.aipoch.com/version.json',
      broadcast: vi.fn(),
      promptSavePath: () => Promise.resolve(target)
    })

    await service.check()
    const downloading = service.download()
    await fetched
    const cancelled = (await cancelVia(service)) as { state: string }
    expect(cancelled.state).toBe('available')

    const final = await downloading
    expect(final.state).toBe('available')
    expect(final.error).toBeUndefined()
    // No partial installer survives the cancel. The cleanup rm may land a tick after the download
    // promise settles, so allow a bounded settle window: a solution that removes the partial passes
    // deterministically, while one that never aborts the fetch leaves the file and fails on budget.
    expect(await settleWithin(() => !existsSync(target))).toBe(true)
  })

  // concurrency_guard (manual path): a second download() while one is already running must not spin up
  // a second transfer (which would orphan the first and make cancel unable to stop it). Exactly one
  // installer request is issued no matter how many times download() is called while one is live. The
  // second call is NOT awaited for a returned status: a valid guard may either return the current status
  // or coalesce onto the in-flight download's promise (which settles only when that download does), so
  // awaiting it would pin one guard shape; the observable requirement is the single installer fetch.
  it('concurrency_guard (service): a second download() does not start a second transfer', async () => {
    dir = await mkdtemp(join(tmpdir(), 'svc-'))
    const target = join(dir, 'installer.dmg')
    const manifestForCheck = downloadManifest(100, 'irrelevant')
    let installerFetches = 0
    let onInstallerFetch: (() => void) | undefined
    const fetched = new Promise<void>((resolve) => (onInstallerFetch = resolve))
    const fetchImpl = ((input: unknown, init?: { signal?: AbortSignal }) => {
      if (String(input).endsWith('version.json')) {
        return Promise.resolve(jsonResponse(manifestForCheck))
      }
      installerFetches += 1
      const body = new ReadableStream({
        start(controller) {
          controller.enqueue(new Uint8Array([1, 2, 3]))
          init?.signal?.addEventListener('abort', () =>
            controller.error(new DOMException('The user aborted a request.', 'AbortError'))
          )
        }
      })
      onInstallerFetch?.()
      return Promise.resolve(new Response(body, { status: 200 }))
    }) as unknown as typeof fetch
    const service = new UpdateService({
      fetchImpl,
      platform: 'darwin',
      arch: 'arm64',
      currentVersion: '0.2.0',
      manifestUrl: 'https://statics.aipoch.com/version.json',
      broadcast: vi.fn(),
      promptSavePath: () => Promise.resolve(target)
    })

    await service.check()
    const first = service.download()
    await fetched
    // Fire a second download() while the first is in flight; do not await its result (its shape is free).
    void service.download()
    // Let any (incorrect) second transfer have a chance to start.
    await new Promise((resolve) => setTimeout(resolve, 0))
    expect(installerFetches).toBe(1)

    await cancelVia(service)
    await first
  })

  // svc_same_path_retry: a retry to the SAME destination must not let the cancelled download's partial-
  // file cleanup delete the retry's freshly written installer. The first download hangs; a cancel aborts
  // it (triggering its partial-file rm). An immediate same-destination retry is kicked off while that
  // cleanup is still settling, and only THEN is the first download's stream released so its cleanup rm
  // runs in the same window as the retry's write. The observable requirement is the OUTCOME: the retry
  // completes to 'ready' and its installer file survives on disk with the correct bytes — regardless of
  // HOW the solution sequences the two (awaiting the prior settlement inside cancel, draining inside the
  // retry, or keying cleanup on a generation id). A solution whose retry races the stale rm leaves no
  // file (the exact user-reported "downloaded file ends up missing or corrupt" bug) and fails here.
  it('svc_same_path_retry: a same-path retry survives the cancelled download’s cleanup with correct bytes', async () => {
    dir = await mkdtemp(join(tmpdir(), 'svc-'))
    const target = join(dir, 'installer.dmg')
    const body = Buffer.from('installer-bytes')
    const manifestForCheck = downloadManifest(
      body.byteLength,
      createHash('sha256').update(body).digest('hex')
    )
    let installerFetches = 0
    let onFirstFetch: (() => void) | undefined
    let errorFirstStream: (() => void) | undefined
    const firstFetched = new Promise<void>((resolve) => (onFirstFetch = resolve))
    const fetchImpl = ((input: unknown) => {
      if (String(input).endsWith('version.json')) {
        return Promise.resolve(jsonResponse(manifestForCheck))
      }
      installerFetches += 1
      if (installerFetches === 1) {
        const hanging = new ReadableStream({
          start(controller) {
            controller.enqueue(new Uint8Array([1, 2, 3]))
            errorFirstStream = () =>
              controller.error(new DOMException('The user aborted a request.', 'AbortError'))
          }
        })
        onFirstFetch?.()
        return Promise.resolve(new Response(hanging, { status: 200 }))
      }
      return Promise.resolve(new Response(body, { status: 200 }))
    }) as unknown as typeof fetch
    const service = new UpdateService({
      fetchImpl,
      platform: 'darwin',
      arch: 'arm64',
      currentVersion: '0.2.0',
      manifestUrl: 'https://statics.aipoch.com/version.json',
      broadcast: vi.fn(),
      promptSavePath: () => Promise.resolve(target)
    })

    await service.check()
    const first = service.download()
    await firstFetched
    const cancelled = (await cancelVia(service)) as { state: string }
    expect(cancelled.state).toBe('available')

    // Kick off the same-destination retry while the cancelled download is still settling, then release
    // the first stream so its partial-file cleanup races the retry's write. A correct solution either
    // orders the cleanup before the write or scopes it so it can't touch the retry's file.
    const retry = service.download()
    errorFirstStream?.()
    const status = await retry
    const firstFinal = await first

    // A genuine second download ran and completed.
    expect(installerFetches).toBe(2)
    expect(status.state).toBe('ready')
    // The decisive outcome: the retry's installer survives the cleanup race with the correct bytes.
    expect(existsSync(target)).toBe(true)
    expect(await readFile(target)).toEqual(body)
    expect(firstFinal.error).toBeUndefined()
  })

  // svc_cancel_during_drain: cancel, start a retry, then cancel again while the retry is still settling.
  // The second cancel must abort the retry so it ends in a benign 'available' state and NO download is
  // left completing in the background after the dialog closed — a no-op second cancel would let a hidden
  // download finish. Every installer fetch here hangs until aborted, so the only way the retry settles
  // 'available' is if the second cancel actually reached it; the observable requirement is that outcome
  // (retry 'available', no installer file left on disk), not how many requests the retry issued before
  // being aborted (an eager-drain solution fetches then aborts; a lazy-drain one may never fetch).
  it('svc_cancel_during_drain: a cancel while a retry is settling aborts it — no hidden download completes', async () => {
    dir = await mkdtemp(join(tmpdir(), 'svc-'))
    const target = join(dir, 'installer.dmg')
    const manifestForCheck = downloadManifest(100, 'irrelevant')
    let onFirstFetch: (() => void) | undefined
    const firstFetched = new Promise<void>((resolve) => (onFirstFetch = resolve))
    // Every installer fetch returns a stream that enqueues one chunk then aborts cleanly when its own
    // request signal fires — so a cancel that reaches a download unblocks it, and one that does not
    // leaves it hanging (caught by the per-case timeout as a failure).
    const fetchImpl = ((input: unknown, init?: { signal?: AbortSignal }) => {
      if (String(input).endsWith('version.json')) {
        return Promise.resolve(jsonResponse(manifestForCheck))
      }
      const hanging = new ReadableStream({
        start(controller) {
          controller.enqueue(new Uint8Array([1, 2, 3]))
          init?.signal?.addEventListener('abort', () =>
            controller.error(new DOMException('The user aborted a request.', 'AbortError'))
          )
        }
      })
      onFirstFetch?.()
      return Promise.resolve(new Response(hanging, { status: 200 }))
    }) as unknown as typeof fetch
    const service = new UpdateService({
      fetchImpl,
      platform: 'darwin',
      arch: 'arm64',
      currentVersion: '0.2.0',
      manifestUrl: 'https://statics.aipoch.com/version.json',
      broadcast: vi.fn(),
      promptSavePath: () => Promise.resolve(target)
    })

    await service.check()
    const first = service.download()
    await firstFetched
    expect(((await cancelVia(service)) as { state: string }).state).toBe('available')

    const retry = service.download()
    await new Promise((resolve) => setTimeout(resolve, 0))
    expect(((await cancelVia(service)) as { state: string }).state).toBe('available')

    const status = await retry
    await first
    // The retry was aborted by the second cancel: it ends 'available', never 'ready', and left no
    // completed installer behind.
    expect(status.state).toBe('available')
    expect(existsSync(target)).toBe(false)
  })

  // svc_no_poison: a failure in the pre-download steps (the save-location prompt throwing) surfaces as
  // an error the user can retry from. A later download() must still work — the lifecycle must not stay
  // wedged by the earlier rejection. The first attempt reports the prompt's error; the retry completes.
  it('svc_no_poison: recovers on a later download() after the save prompt throws', async () => {
    dir = await mkdtemp(join(tmpdir(), 'svc-'))
    const target = join(dir, 'installer.dmg')
    const body = Buffer.from('installer-bytes')
    const manifestForCheck = downloadManifest(
      body.byteLength,
      createHash('sha256').update(body).digest('hex')
    )
    const fetchImpl = ((input: unknown) =>
      String(input).endsWith('version.json')
        ? Promise.resolve(jsonResponse(manifestForCheck))
        : Promise.resolve(new Response(body, { status: 200 }))) as unknown as typeof fetch
    let saveCall = 0
    const service = new UpdateService({
      fetchImpl,
      platform: 'darwin',
      arch: 'arm64',
      currentVersion: '0.2.0',
      manifestUrl: 'https://statics.aipoch.com/version.json',
      broadcast: vi.fn(),
      promptSavePath: () =>
        saveCall++ === 0 ? Promise.reject(new Error('dialog failed')) : Promise.resolve(target)
    })

    await service.check()
    const failed = await service.download()
    expect(failed.state).toBe('error')
    expect(failed.error).toBe('dialog failed')

    const retry = await service.download()
    expect(retry.state).toBe('ready')
    expect(retry.localPath).toBe(target)
    expect(existsSync(target)).toBe(true)
  })

  // cancel_noop_when_idle (manual path): cancelling when nothing is downloading is harmless and leaves
  // the "available" state intact. This is a baseline the correct behavior must preserve.
  it('cancel_noop_when_idle (service): cancel is a no-op when nothing is downloading', async () => {
    const manifestForCheck = downloadManifest(5, 'h')
    const fetchImpl = (() =>
      Promise.resolve(jsonResponse(manifestForCheck))) as unknown as typeof fetch
    const service = new UpdateService({
      fetchImpl,
      platform: 'darwin',
      arch: 'arm64',
      currentVersion: '0.2.0',
      manifestUrl: 'https://statics.aipoch.com/version.json',
      broadcast: vi.fn(),
      promptSavePath: () => Promise.resolve(null)
    })

    await service.check()
    const status = (await cancelVia(service)) as { state: string }
    expect(status.state).toBe('available')
  })
})

describe('ElectronUpdaterStrategy cancel/retry (in-place path)', () => {
  // electron_cancel_resets: cancelling an in-flight in-place download aborts the real transfer (the
  // cancellation token the strategy handed to the underlying download reads cancelled and the download
  // rejects) and resets the status to available. The cancelled transfer's rejection must not clobber
  // that reset with an error. A status-only cancel never cancels the token, so the hanging download
  // never rejects and the status never returns to 'available' — it is caught by the per-case timeout.
  it('electron_cancel_resets: cancel aborts the in-flight download and resets to available', async () => {
    const updater = new FakeUpdater()
    let seenToken: FakeToken | undefined
    updater.runDownload = (token) => {
      seenToken = token
      return hangUntilCancelled(token)
    }
    const strategy = new ElectronUpdaterStrategy({
      updater,
      currentVersion: '0.2.0',
      broadcast: vi.fn(),
      fetchImpl: offlineFetch()
    })
    await strategy.check()

    const downloading = strategy.download()
    const cancelled = (await cancelVia(strategy)) as { state: string; error?: string }
    // Cancel reset the user-visible status to available and did not flash an error.
    expect(cancelled.state).toBe('available')
    // The underlying token was actually cancelled (network really stopped), not just the status flipped.
    expect(seenToken?.cancelled).toBe(true)

    // The download settles 'available' (not 'error'); its rejection is swallowed as a user cancel.
    const final = await downloading
    expect(final.state).toBe('available')
    expect(final.error).toBeUndefined()
  })

  // concurrency_guard (in-place path): a second download() while one is in flight must not orphan the
  // first download's cancellation token. A strategy that drops its guard and re-runs download() tracks
  // the SECOND call's token and loses the first — so a later cancel can no longer stop the real (first)
  // transfer, which is the concrete harm. Here two download() calls race; a single cancel must still
  // bring the strategy back to 'available' (it can only do so if it never orphaned the live token). The
  // underlying download also started exactly once. A missing guard leaves the download un-cancellable,
  // so the status never returns to available within the budget and the case fails promptly.
  it('concurrency_guard (electron): a second download() does not orphan the in-flight download', async () => {
    const updater = new FakeUpdater()
    updater.runDownload = (token) => hangUntilCancelled(token)
    const strategy = new ElectronUpdaterStrategy({
      updater,
      currentVersion: '0.2.0',
      broadcast: vi.fn(),
      fetchImpl: offlineFetch()
    })
    await strategy.check()

    // Fire two download() calls; a correct guard either returns the current status or coalesces the
    // second onto the first's promise. Track whether the FIRST download() call ultimately settles —
    // a guard that keeps one live download lets a cancel stop it, so this resolves; a strategy that
    // re-runs and orphans the first download's token cancels the wrong one, leaving the first download
    // running forever (never settles). settled stays false in that case and the case fails on budget.
    let settled = false
    const first = strategy.download().finally(() => {
      settled = true
    })
    void strategy.download()
    // Exactly one genuine underlying download was started despite two download() calls.
    expect(updater.starts).toBe(1)

    // A single cancel must actually stop the live download — only possible if its token was not orphaned.
    void cancelVia(strategy)
    expect(await settleWithin(() => settled)).toBe(true)
    await first.catch(() => undefined)
    // And the user-visible status came back to available.
    expect(strategy.getStatus().state).toBe('available')
  })

  // electron_retry_drain: the underlying auto-updater reuses a single in-flight download operation and
  // ignores a fresh cancel until the prior one settles. So cancel-then-immediately-download-again must
  // let the previous (cancelled) download fully settle before starting a genuine new one. A retry that
  // re-attaches to the still-live operation never starts a second download; one that drains the prior
  // operation first does, so the underlying download body runs twice and the retry reaches ready. The
  // observable outcome (second start happened AND retry is ready) holds whether the strategy drains
  // eagerly (a blocking cancel that settles the prior) or lazily (a drain awaited inside the retry).
  it('electron_retry_drain: cancel then immediate retry starts a genuine second download', async () => {
    const updater = new FakeUpdater()
    updater.runDownload = (token) => {
      // The first start hangs until cancelled; the (drained) retry completes normally.
      if (updater.starts === 1) return hangUntilCancelled(token)
      updater.emit('download-progress', { percent: 55 })
      updater.emit('update-downloaded', { version: '0.3.0' })
      return Promise.resolve()
    }
    const strategy = new ElectronUpdaterStrategy({
      updater,
      currentVersion: '0.2.0',
      broadcast: vi.fn(),
      fetchImpl: offlineFetch()
    })
    await strategy.check()

    const first = strategy.download()
    const cancelled = (await cancelVia(strategy)) as { state: string }
    expect(cancelled.state).toBe('available')

    // The retry must start a genuine SECOND download (not re-attach to the cancelled one) and reach ready.
    const retry = await strategy.download()
    expect(retry.state).toBe('ready')
    expect(updater.starts).toBe(2)

    const firstFinal = await first
    expect(firstFinal.error).toBeUndefined()
  })

  // electron_cancel_during_drain: cancel, retry, then cancel again while the retry is still settling.
  // The second cancel must abort the retry so it ends 'available' and no completed download is surfaced
  // — mirror of svc_cancel_during_drain for the in-place path. The first download hangs until cancelled;
  // a retry that honours the second cancel never reaches 'ready'.
  it('electron_cancel_during_drain: a cancel while a retry is draining aborts it — no download completes', async () => {
    const updater = new FakeUpdater()
    updater.runDownload = (token) => {
      // Every started download hangs until its own token is cancelled; a retry that honours the second
      // cancel rejects as a user cancel and never completes to 'ready'.
      return hangUntilCancelled(token)
    }
    const strategy = new ElectronUpdaterStrategy({
      updater,
      currentVersion: '0.2.0',
      broadcast: vi.fn(),
      fetchImpl: offlineFetch()
    })
    await strategy.check()

    const first = strategy.download()
    expect(((await cancelVia(strategy)) as { state: string }).state).toBe('available')

    const retry = strategy.download()
    await new Promise((resolve) => setTimeout(resolve, 0))
    expect(((await cancelVia(strategy)) as { state: string }).state).toBe('available')

    // The retry ends 'available' (aborted), never 'ready': the second cancel reached it.
    const status = await retry
    expect(status.state).toBe('available')
    await first
  })

  // cancel_noop_when_idle (in-place path): cancelling with nothing downloading is harmless and leaves
  // the available state intact.
  it('cancel_noop_when_idle (electron): cancel is a no-op when nothing is downloading', async () => {
    const updater = new FakeUpdater()
    const strategy = new ElectronUpdaterStrategy({
      updater,
      currentVersion: '0.2.0',
      broadcast: vi.fn(),
      fetchImpl: offlineFetch()
    })
    await strategy.check()
    const status = (await cancelVia(strategy)) as { state: string }
    expect(status.state).toBe('available')
  })
})
