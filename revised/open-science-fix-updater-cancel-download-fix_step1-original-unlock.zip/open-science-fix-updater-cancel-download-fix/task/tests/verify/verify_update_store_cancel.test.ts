// @vitest-environment jsdom
import { beforeEach, describe, expect, it, vi } from 'vitest'

import { useUpdateStore } from './update-store'

// Real-preload-bridge mocks. The bridge test below loads the actual `src/preload/index.ts` and the
// actual `registerUpdateIpcHandlers` from `src/main/update/ipc.ts`, so electron must be stubbed before
// either module graph loads: the preload captures `contextBridge.exposeInMainWorld('api', api)` (so we
// read the real bridge object) and spies `ipcRenderer.invoke` (so we see the exact channel the bridge
// forwards to); `ipcMain.handle` records the channels `registerUpdateIpcHandlers` wires up (so we resolve
// the author's cancel channel by set-difference). electron-updater is stubbed because the ipc module's
// strategy graph imports it at load. The hoisted holders are shared between these mocks and the test.
// The store tests above touch none of these modules, so the stubs are inert for them.
const PRELOAD_MOCKS = vi.hoisted(() => ({
  exposeMock: vi.fn(),
  invokeMock: vi.fn((..._args: unknown[]) =>
    Promise.resolve({ state: 'available', current: '0.2.0' })
  ),
  registeredHandlers: new Map<string, (...args: unknown[]) => unknown>()
}))

vi.mock('electron', () => ({
  contextBridge: { exposeInMainWorld: PRELOAD_MOCKS.exposeMock },
  ipcRenderer: {
    invoke: PRELOAD_MOCKS.invokeMock,
    on: vi.fn(),
    off: vi.fn(),
    send: vi.fn(),
    removeListener: vi.fn()
  },
  ipcMain: {
    handle: (channel: string, listener: (...args: unknown[]) => unknown) => {
      PRELOAD_MOCKS.registeredHandlers.set(channel, listener)
    }
  },
  app: { getVersion: () => '0.0.0', getPath: () => '/tmp', isPackaged: false },
  BrowserWindow: { getFocusedWindow: () => null, getAllWindows: () => [] },
  dialog: { showSaveDialog: async () => ({ canceled: true, filePath: undefined }) },
  shell: { openPath: async () => '', openExternal: async () => undefined }
}))

vi.mock('electron-updater', () => ({
  autoUpdater: {},
  CancellationToken: class {
    cancelled = false
    cancel(): void {
      this.cancelled = true
    }
  }
}))

// The command channels present on the UNfixed baseline; the fix adds exactly one more for cancel.
const BASELINE_UPDATE_CHANNELS = new Set([
  'update:get-app-info',
  'update:get-status',
  'update:check',
  'update:download',
  'update:apply'
])

const resetStore = (): void =>
  useUpdateStore.setState({
    appInfo: null,
    status: { state: 'idle', current: '' },
    isDialogOpen: false
  })

// The preload bridge methods that already exist on the UNfixed baseline. The fix adds one more — the
// cancel-the-download method — whose name the author chooses (task.toml declares naming free; the judge
// rubric accepts "any consistent channel name and bridge method name"). So these tests never reference
// a hardcoded bridge method name: they install a recording bridge whose non-baseline methods are each a
// spy, and identify the cancel method as the single non-baseline bridge method the close path invokes.
const BASELINE_BRIDGE_METHODS = new Set([
  'getAppInfo',
  'getStatus',
  'check',
  'download',
  'apply',
  'onStatus',
  'onProgress'
])

type BridgeCall = { method: string; result: unknown }

// Installs window.api.update as a recording bridge. Baseline listener/command methods are inert spies
// (onStatus/onProgress return a no-op unsubscribe; the command methods resolve a benign status). Any
// OTHER method the store reaches for — the author's cancel method, whatever its name — is lazily created
// as a spy that records the call and resolves `cancelResult`. `calls` captures every non-baseline bridge
// invocation so a test can assert the cancel was invoked exactly once without naming it.
const installRecordingBridge = (cancelResult: unknown): { calls: BridgeCall[] } => {
  const calls: BridgeCall[] = []
  const spies = new Map<string, (...args: unknown[]) => unknown>()
  const base: Record<string, unknown> = {
    getAppInfo: vi.fn(() => Promise.resolve({ name: 'app', version: '0.2.0', copyright: '' })),
    getStatus: vi.fn(() => Promise.resolve({ state: 'idle', current: '0.2.0' })),
    check: vi.fn(() => Promise.resolve({ state: 'available', current: '0.2.0' })),
    download: vi.fn(() => Promise.resolve({ state: 'downloading', current: '0.2.0' })),
    apply: vi.fn(() => Promise.resolve({ state: 'ready', current: '0.2.0' })),
    onStatus: vi.fn(() => () => undefined),
    onProgress: vi.fn(() => () => undefined)
  }
  const update = new Proxy(base, {
    get(target, prop: string) {
      if (prop in target) return target[prop]
      // A non-baseline bridge method (the cancel action). Create/record a spy for it on first access so
      // the store can call it under whatever name the author chose.
      if (!spies.has(prop)) {
        spies.set(
          prop,
          vi.fn((..._args: unknown[]) => {
            calls.push({ method: prop, result: cancelResult })
            return Promise.resolve(cancelResult)
          })
        )
      }
      return spies.get(prop)
    }
  })
  ;(window as unknown as { api: unknown }).api = { update }
  return { calls }
}

describe('useUpdateStore close-dialog cancels the download', () => {
  beforeEach(() => {
    resetStore()
    vi.restoreAllMocks()
  })

  // store_closeDialog_cancels_downloading: closing the dialog while a download is in flight must abort
  // that download through the store's public close path — not just hide the dialog. Observed through the
  // preload bridge: the renderer invokes the main-process cancel method (whatever its name) exactly once,
  // the dialog closes, and the store adopts the reset status the cancel returns. Asserted via the public
  // store surface (closeDialog + the single non-baseline bridge call) so a per-affordance renderer design
  // and any author-chosen bridge method name both pass.
  it('store_closeDialog_cancels_downloading: closeDialog aborts an in-flight download', async () => {
    const { calls } = installRecordingBridge({ state: 'available', current: '0.2.0', latest: '0.3.0' })
    useUpdateStore.setState({
      status: { state: 'downloading', current: '0.2.0', latest: '0.3.0', progress: 40 },
      isDialogOpen: true
    })

    useUpdateStore.getState().closeDialog()
    await Promise.resolve()
    await Promise.resolve()

    // Exactly one non-baseline bridge method (the cancel) was invoked by the close path.
    expect(calls.filter((c) => !BASELINE_BRIDGE_METHODS.has(c.method))).toHaveLength(1)
    expect(useUpdateStore.getState().isDialogOpen).toBe(false)
    expect(useUpdateStore.getState().status.state).toBe('available')
  })

  // store_closeDialog_cancels_unconditional: the 'downloading' broadcast may not have reached the
  // renderer yet when the user clicks Cancel right after Download, so the close path must request a
  // cancel UNCONDITIONALLY rather than gating on the local 'downloading' state — otherwise it misses
  // that pre-broadcast window and leaves the download running (the exact race users hit). Here the
  // local state is still 'available' yet closeDialog must still invoke the cancel bridge method exactly
  // once. A guarded close ("only cancel when we think we're downloading") never calls it and fails here.
  it('store_closeDialog_cancels_unconditional: closeDialog cancels even before the downloading state arrives', async () => {
    const { calls } = installRecordingBridge({ state: 'available', current: '0.2.0' })
    useUpdateStore.setState({
      status: { state: 'available', current: '0.2.0', latest: '0.3.0' },
      isDialogOpen: true
    })

    useUpdateStore.getState().closeDialog()
    await Promise.resolve()
    await Promise.resolve()

    expect(calls.filter((c) => !BASELINE_BRIDGE_METHODS.has(c.method))).toHaveLength(1)
    expect(useUpdateStore.getState().isDialogOpen).toBe(false)
  })
})

describe('preload bridge forwards cancel to the main-process cancel channel', () => {
  // bridge_cancel_forwards_to_main: the store's cancel action is only half the path — it calls a
  // method on window.api.update, and that method must actually cross the renderer->main boundary. This
  // exercises the REAL preload bridge (src/preload/index.ts) and the REAL IPC registration
  // (registerUpdateIpcHandlers), rather than the recording stub the store tests use, so a solution that
  // wires the strategy + store but forgets the preload bridge (a Cancel button that still does nothing
  // from the renderer) fails here. Both the bridge method name and the IPC channel name are
  // author-chosen (task.toml: naming is free; the rubric accepts any consistent channel/bridge name),
  // so neither is hardcoded: the cancel bridge method is the single non-baseline method on the exposed
  // `update` bridge, and the cancel channel is the single new update:* channel registration — resolved
  // at runtime by set-difference. The test then calls the discovered bridge method and asserts it
  // forwards to the discovered channel via ipcRenderer.invoke.
  it('bridge_cancel_forwards_to_main: the preload cancel bridge method invokes the cancel IPC channel', async () => {
    // Load the real IPC registration and preload bridge against the mocked electron above. Take the
    // contextBridge branch of the preload's expose logic (production path with context isolation) so the
    // api object is captured via exposeInMainWorld. Dynamic import so the mocks are in place first.
    Object.defineProperty(process, 'contextIsolated', { value: true, configurable: true })
    const { registerUpdateIpcHandlers } = await import('../../../main/update/ipc')
    await import('../../../preload/index')

    // Capture the real bridge object the preload exposed, and find the ONE new update bridge method the
    // fix added (the cancel action) by set-difference against the baseline bridge surface.
    const exposed = PRELOAD_MOCKS.exposeMock.mock.calls.find((call) => call[0] === 'api')?.[1] as
      | { update?: Record<string, unknown> }
      | undefined
    if (!exposed?.update) throw new Error('preload did not expose an "api.update" bridge')
    const newBridgeMethods = Object.keys(exposed.update).filter(
      (method) => !BASELINE_BRIDGE_METHODS.has(method)
    )
    expect(newBridgeMethods).toHaveLength(1)
    const cancelMethod = exposed.update[newBridgeMethods[0]] as () => Promise<unknown>

    // Resolve the author's cancel IPC channel by registering the real handlers against the mocked
    // ipcMain and taking the single new update:* channel (same set-difference the main verifier uses).
    PRELOAD_MOCKS.registeredHandlers.clear()
    ;(registerUpdateIpcHandlers as (strategy: unknown) => unknown)({})
    const newChannels = [...PRELOAD_MOCKS.registeredHandlers.keys()].filter(
      (channel) => channel.startsWith('update:') && !BASELINE_UPDATE_CHANNELS.has(channel)
    )
    expect(newChannels).toHaveLength(1)
    const cancelChannel = newChannels[0]

    // Call the discovered cancel bridge method and assert it forwarded a real IPC invoke to the cancel
    // channel — the end-to-end renderer->main hop that actually stops the download.
    PRELOAD_MOCKS.invokeMock.mockClear()
    await cancelMethod()
    expect(PRELOAD_MOCKS.invokeMock).toHaveBeenCalledTimes(1)
    expect(PRELOAD_MOCKS.invokeMock.mock.calls[0]?.[0]).toBe(cancelChannel)
  })
})
