## Task

Customers report that a survey can get stuck after their own code throws a single time.
The code is either an expression function they registered with `FunctionFactory`, or a handler on `survey.onValueChanged` or on an element's `onPropertyChanged`.
It throws once and the error reaches them, which is what they expect.
From then on, though, part of the survey stops responding until the page is reloaded.
These are the cases reported so far, each seen after one throw:

- If a custom function in one question's `visibleIf` throws while conditions run, later answers no longer show or hide the other conditional questions.
- If a custom function in a trigger throws, later answers no longer fire the survey's other `setvalue` and `runexpression` triggers.
- If a handler throws while a page shuffles its questions into random order, hiding a question on that page afterward leaves its row showing.
- If a handler throws when a new `rateCount` on a rating question moves its `rateMax`, changing `rateCount` again no longer updates `rateMax`.
- If an `onValueChanged` handler throws while a question with `choicesFromQuestion` picks up new choices from its source, later changes to the source's choices no longer show up in it.
- If an `onValueChanged` handler throws while the "other" comment of a radiogroup is set, later "other" text is no longer stored on the question or as its comment in the survey.
- If a handler throws while a composite question passes values between its inner questions and the survey (an inner answer going up, or `survey.setValue` filling the inner questions), later inner answers no longer reach `survey.data`.

Find out why one throw leaves these parts of the survey dead and fix it.
The error must still reach the caller as it does today, and surveys where nothing throws should work exactly as they do now.
