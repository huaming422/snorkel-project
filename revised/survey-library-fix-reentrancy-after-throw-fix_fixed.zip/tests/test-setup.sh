#!/usr/bin/env bash
# Environment bootstrap for the verifier.
#
# Sourced (not exec'd) by the harbor runner so any env vars set here stay
# live for the verifier subprocess.
#
# survey-core's vitest suite imports the model classes directly from
# `packages/survey-core/src` (the `survey-core` alias in vitest.config.ts
# resolves to the entry under src/), so a src/ edit is visible to the tests
# with NO build step. We therefore only need node_modules present and the
# vitest binary resolvable; we do not rebuild dist/.
#
# The image bakes the full dependency closure at the base commit (npm ci
# ran at build time), so in the offline coding phase this script does no
# network work. The install below is an offline-first safety net with a
# logged online fallback for the (network-enabled) verifier phase only.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/survey-library}"
export REPO_DIR
PKG_DIR="$REPO_DIR/packages/survey-core"
cd "$PKG_DIR"

# node_modules is baked into the image; this is a defensive re-hydrate.
# Offline first (uses the warm npm cache under the image); if something is
# genuinely missing and the network is available, fall back loudly.
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest binary missing - re-hydrating node_modules." >&2
    if npm ci --prefer-offline --no-audit --no-fund > /tmp/setup-node.log 2>&1; then
        echo "test-setup.sh: npm ci (offline-first) succeeded." >&2
    else
        echo "test-setup.sh: offline npm ci failed; retrying online." >&2
        npm ci --no-audit --no-fund > /tmp/setup-node-online.log 2>&1 \
            || { echo "test-setup.sh: npm ci failed:" >&2; tail -80 /tmp/setup-node-online.log >&2; exit 1; }
    fi
fi

# Sanity check: vitest must be resolvable from the package.
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest still missing from node_modules/.bin after install." >&2
    exit 1
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR PKG_DIR=$PKG_DIR vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
