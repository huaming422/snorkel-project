// @ts-nocheck
//
// Customer code (a registered expression function, or an onValueChanged /
// onPropertyChanged handler) throws once while the survey is in the middle of
// an operation. Each case checks that the error reaches the caller and that
// the same kind of operation still works the next time it runs.
//
// Every scenario goes through the public survey-core model API (SurveyModel,
// Question, PageModel) and reads only results a survey author can see:
// question visibility, survey values and data, visible choices, the "other"
// comment and page rows. Nothing here imports a helper from the source tree
// or reads a private field.
//
// The last case runs the same scenarios with nothing thrown and checks the
// ordinary results, plus a few neighbors of them: a 300-question expression
// chain and the value-changed order along a short one, a rows handler that
// randomizes the page again, rateCount trimming and extending rateValues,
// two questions that take their choices from each other, a value-changed
// handler that rewrites the "other" text, a composite value set as a whole,
// and onCreated callbacks of custom and composite question types.

import { describe, test, expect } from "vitest";
import { SurveyModel } from "../src/survey";
import { FunctionFactory } from "../src/functionsfactory";
import { Base } from "../src/base";
import { PageModel } from "../src/page";
import { QuestionRatingModel } from "../src/question_rating";
import { QuestionCheckboxModel } from "../src/question_checkbox";
import { QuestionRadiogroupModel } from "../src/question_radiogroup";
import { ComponentCollection, QuestionCompositeModel, QuestionCustomModel } from "../src/question_custom";
import { QuestionPanelDynamicModel } from "../src/question_paneldynamic";

// A one-shot switch: throws the first time it is checked after arming, then
// disarms, so the very next operation runs clean.
function createThrowOnce(name: string): { arm: () => void, check: () => void } {
  let isArmed = false;
  return {
    arm: (): void => { isArmed = true; },
    check: (): void => {
      if (!isArmed) return;
      isArmed = false;
      throw new Error(name);
    },
  };
}

function registerThrowOnceFunction(name: string): { arm: () => void } {
  const throwOnce = createThrowOnce(name);
  FunctionFactory.Instance.register(name, (): boolean => {
    throwOnce.check();
    return true;
  });
  return throwOnce;
}

function throwOnPropertyChange(obj: Base, propertyName: string, errorText: string): { arm: () => void } {
  const throwOnce = createThrowOnce(errorText);
  obj.onPropertyChanged.add((_, options) => {
    if (options.name === propertyName) throwOnce.check();
  });
  return throwOnce;
}

describe("A single throw from customer code leaves the survey working", () => {
  // --- conditions ---
  test("conditions: after a custom function throws while conditions run, a later value change still re-evaluates visibility", () => {
    const fn = registerThrowOnceFunction("throwOnceInVisibleIf");
    try {
      const survey = new SurveyModel({ elements: [
        { type: "text", name: "q1" },
        { type: "text", name: "q2", visibleIf: "{q1} = 'a'" },
        { type: "text", name: "q3", visibleIf: "throwOnceInVisibleIf({q1})" },
      ] });
      const q2 = survey.getQuestionByName("q2");
      expect(q2.isVisible).toBe(false);
      fn.arm();
      expect(() => survey.setValue("q1", "x")).toThrow("throwOnceInVisibleIf");
      survey.setValue("q1", "a");
      expect(q2.isVisible).toBe(true);
    } finally {
      FunctionFactory.Instance.unregister("throwOnceInVisibleIf");
    }
  });

  // --- triggers ---
  test("triggers: after a custom function throws while triggers run, a later change still fires setvalue and runexpression triggers", () => {
    const fn = registerThrowOnceFunction("throwOnceInTrigger");
    try {
      const survey = new SurveyModel({
        elements: [{ type: "text", name: "q1" }, { type: "text", name: "q2" }, { type: "text", name: "q3" }],
        triggers: [
          { type: "runexpression", expression: "{q1} notempty", runExpression: "throwOnceInTrigger({q1})" },
          { type: "setvalue", expression: "{q1} = 'a'", setToName: "q2", setValue: "done" },
          { type: "runexpression", expression: "{q1} = 'a'", setToName: "q3", runExpression: "{q1} + '!'" },
        ],
      });
      fn.arm();
      expect(() => survey.setValue("q1", "x")).toThrow("throwOnceInTrigger");
      survey.setValue("q1", "a");
      expect(survey.getValue("q2")).toBe("done");
      expect(survey.getValue("q3")).toBe("a!");
    } finally {
      FunctionFactory.Instance.unregister("throwOnceInTrigger");
    }
  });

  // --- random question order ---
  test("randomization: after a property handler throws while a page randomizes, the page still tracks question visibility", () => {
    const survey = new SurveyModel({ pages: [{ name: "p1", elements: [
      { type: "text", name: "q1" }, { type: "text", name: "q2" }, { type: "text", name: "q3" },
    ] }] });
    const page = <PageModel>survey.pages[0];
    const q2 = survey.getQuestionByName("q2");
    const handler = throwOnPropertyChange(page, "rows", "throwOnRows");
    handler.arm();
    expect(() => page.randomizeElements(true)).toThrow("throwOnRows");
    const rowOfQ2 = page.rows.filter(row => row.elements.indexOf(q2) > -1)[0];
    expect(rowOfQ2.visible).toBe(true);
    q2.visible = false;
    expect(rowOfQ2.visible).toBe(false);
  });

  // --- rating rateCount / rateMax ---
  test("rating: after a property handler throws while rateCount moves rateMax, a later rateCount change still moves rateMax", () => {
    const survey = new SurveyModel({ elements: [{ type: "rating", name: "q1", rateMin: 1, rateMax: 5 }] });
    const q1 = <QuestionRatingModel>survey.getQuestionByName("q1");
    const handler = throwOnPropertyChange(q1, "rateMax", "throwOnRateMax");
    handler.arm();
    expect(() => { q1.rateCount = 3; }).toThrow("throwOnRateMax");
    q1.rateCount = 4;
    expect(q1.rateMax).toBe(4);
  });

  // --- choicesFromQuestion ---
  test("carried-forward choices: after a value-changed handler throws while dependent choices update, later source changes still propagate", () => {
    const survey = new SurveyModel({ elements: [
      { type: "checkbox", name: "q1", choices: ["a", "b", "c"] },
      { type: "checkbox", name: "q2", choicesFromQuestion: "q1" },
    ] });
    const q1 = <QuestionCheckboxModel>survey.getQuestionByName("q1");
    const q2 = <QuestionCheckboxModel>survey.getQuestionByName("q2");
    q2.value = ["c"];
    const throwOnce = createThrowOnce("throwOnQ2Change");
    survey.onValueChanged.add((_, options) => {
      if (options.name === "q2") throwOnce.check();
    });
    throwOnce.arm();
    expect(() => { q1.choices = ["a", "b"]; }).toThrow("throwOnQ2Change");
    expect(q2.visibleChoices.map(item => item.value)).toEqual(["a", "b"]);
    q1.choices = ["x"];
    expect(q2.visibleChoices.map(item => item.value)).toEqual(["x"]);
  });

  // --- "other" comment ---
  test("other-item comment: after a value-changed handler throws while the other comment is set, later other values still persist", () => {
    const survey = new SurveyModel({ elements: [{ type: "radiogroup", name: "q1", choices: ["a"], showOtherItem: true }] });
    const q1 = <QuestionRadiogroupModel>survey.getQuestionByName("q1");
    q1.value = "other";
    const throwOnce = createThrowOnce("throwOnComment");
    survey.onValueChanged.add(() => { throwOnce.check(); });
    throwOnce.arm();
    expect(() => { q1.otherValue = "x"; }).toThrow("throwOnComment");
    q1.otherValue = "y";
    expect(q1.otherValue).toBe("y");
    expect(survey.getComment("q1")).toBe("y");
  });

  // --- composite question ---
  test("composite value: after a value-changed handler throws while a composite sets an inner value, later inner values still reach survey.data", () => {
    ComponentCollection.Instance.add({ name: "throwingcomposite", elementsJSON: [{ type: "text", name: "a" }, { type: "text", name: "b" }] });
    try {
      const survey = new SurveyModel({ elements: [{ type: "throwingcomposite", name: "q1" }] });
      const q1 = <QuestionCompositeModel>survey.getQuestionByName("q1");
      const throwOnce = createThrowOnce("throwOnCompositeChange");
      survey.onValueChanged.add(() => { throwOnce.check(); });
      throwOnce.arm();
      expect(() => { q1.contentPanel.getQuestionByName("a").value = 1; }).toThrow("throwOnCompositeChange");
      q1.contentPanel.getQuestionByName("b").value = 2;
      expect(survey.data).toEqual({ q1: { a: 1, b: 2 } });
    } finally {
      ComponentCollection.Instance.clear();
    }
  });

  test("composite value from the survey: after a property handler throws while the survey fills a composite's inner questions, later inner values still reach survey.data", () => {
    ComponentCollection.Instance.add({ name: "fillingcomposite", elementsJSON: [{ type: "text", name: "a" }, { type: "text", name: "b" }] });
    try {
      const survey = new SurveyModel({ elements: [{ type: "fillingcomposite", name: "q1" }] });
      const q1 = <QuestionCompositeModel>survey.getQuestionByName("q1");
      const throwOnce = createThrowOnce("throwOnCompositeFill");
      q1.contentPanel.getQuestionByName("a").onPropertyChanged.add(() => { throwOnce.check(); });
      throwOnce.arm();
      expect(() => survey.setValue("q1", { a: 5 })).toThrow("throwOnCompositeFill");
      q1.contentPanel.getQuestionByName("b").value = 7;
      expect(survey.data).toEqual({ q1: { a: 5, b: 7 } });
    } finally {
      ComponentCollection.Instance.clear();
    }
  });

  // --- nothing thrown ---
  // Runs every scenario once with nothing armed and checks the ordinary
  // results, then checks that an armed call still throws to the caller.
  test("normal operation is unchanged when nothing throws and armed calls still throw", () => {
    // conditions
    {
      const survey = new SurveyModel({ elements: [
        { type: "text", name: "q1" },
        { type: "text", name: "q2", visibleIf: "{q1} = 'a'" },
      ] });
      const q2 = survey.getQuestionByName("q2");
      expect(q2.isVisible).toBe(false);
      survey.setValue("q1", "a");
      expect(q2.isVisible).toBe(true);
    }
    // conditions, a long chain of expression questions
    {
      const elements: Array<any> = [{ type: "text", name: "q0" }];
      for (let i = 1; i <= 300; i++) {
        elements.push({ type: "expression", name: "e" + i, expression: "{" + (i === 1 ? "q0" : "e" + (i - 1)) + "} + 1" });
      }
      const survey = new SurveyModel({ elements });
      survey.setValue("q0", 1);
      expect(survey.getValue("e1")).toBe(2);
      expect(survey.getValue("e300")).toBe(301);
    }
    // conditions, value-changed order along a short chain
    {
      const survey = new SurveyModel({ elements: [
        { type: "text", name: "q0" },
        { type: "expression", name: "e1", expression: "{q0} + 1" },
        { type: "expression", name: "e2", expression: "{e1} + 1" },
        { type: "expression", name: "e3", expression: "{e2} + 1" },
      ] });
      const changedNames: Array<string> = [];
      survey.onValueChanged.add((_, options) => { changedNames.push(options.name); });
      survey.setValue("q0", 1);
      expect(changedNames).toEqual(["e1", "e2", "e3", "q0"]);
      expect(survey.getValue("e3")).toBe(4);
    }
    // triggers
    {
      const survey = new SurveyModel({
        elements: [{ type: "text", name: "q1" }, { type: "text", name: "q2" }, { type: "text", name: "q3" }],
        triggers: [
          { type: "setvalue", expression: "{q1} = 'a'", setToName: "q2", setValue: "done" },
          { type: "runexpression", expression: "{q1} = 'a'", setToName: "q3", runExpression: "{q1} + '!'" },
        ],
      });
      survey.setValue("q1", "a");
      expect(survey.getValue("q2")).toBe("done");
      expect(survey.getValue("q3")).toBe("a!");
    }
    // random question order
    {
      const survey = new SurveyModel({ pages: [{ name: "p1", elements: [
        { type: "text", name: "q1" }, { type: "text", name: "q2" }, { type: "text", name: "q3" },
      ] }] });
      const page = <PageModel>survey.pages[0];
      const q2 = survey.getQuestionByName("q2");
      expect(page.randomizeElements(true)).toBe(true);
      const rowOfQ2 = page.rows.filter(row => row.elements.indexOf(q2) > -1)[0];
      expect(rowOfQ2.visible).toBe(true);
      q2.visible = false;
      expect(rowOfQ2.visible).toBe(false);
    }
    // random question order, a rows handler that randomizes the page again
    {
      const survey = new SurveyModel({ pages: [{ name: "p1", elements: [
        { type: "text", name: "q1" }, { type: "text", name: "q2" }, { type: "text", name: "q3" },
      ] }] });
      const page = <PageModel>survey.pages[0];
      let rowsChangedCount = 0;
      page.onPropertyChanged.add((_, options) => {
        if (options.name !== "rows") return;
        rowsChangedCount++;
        page.randomizeElements(true);
      });
      expect(page.randomizeElements(true)).toBe(true);
      expect(rowsChangedCount).toBe(1);
      expect(page.elements.map(el => el.name).sort()).toEqual(["q1", "q2", "q3"]);
    }
    // rating rateCount / rateMax
    {
      const survey = new SurveyModel({ elements: [{ type: "rating", name: "q1", rateMin: 1, rateMax: 5 }] });
      const q1 = <QuestionRatingModel>survey.getQuestionByName("q1");
      q1.rateCount = 4;
      expect(q1.rateMax).toBe(4);
    }
    // rating rateCount / rateValues
    {
      const survey = new SurveyModel({ elements: [{ type: "rating", name: "q1", rateValues: ["a", "b", "c"] }] });
      const q1 = <QuestionRatingModel>survey.getQuestionByName("q1");
      q1.rateCount = 2;
      expect(q1.rateValues.map(item => item.value)).toEqual(["a", "b"]);
      q1.rateCount = 4;
      expect(q1.rateValues.map(item => item.value)).toEqual(["a", "b", "item3", "item4"]);
    }
    // carried-forward choices
    {
      const survey = new SurveyModel({ elements: [
        { type: "checkbox", name: "q1", choices: ["a", "b", "c"] },
        { type: "checkbox", name: "q2", choicesFromQuestion: "q1" },
      ] });
      const q1 = <QuestionCheckboxModel>survey.getQuestionByName("q1");
      const q2 = <QuestionCheckboxModel>survey.getQuestionByName("q2");
      expect(q2.visibleChoices.map(item => item.value)).toEqual(["a", "b", "c"]);
      q1.choices = ["x", "y"];
      expect(q2.visibleChoices.map(item => item.value)).toEqual(["x", "y"]);
    }
    // carried-forward choices, two questions that name each other as the source
    {
      const survey = new SurveyModel({ elements: [
        { type: "checkbox", name: "q1", choices: ["a", "b"], choicesFromQuestion: "q2" },
        { type: "checkbox", name: "q2", choices: ["c"], choicesFromQuestion: "q1" },
      ] });
      const q1 = <QuestionCheckboxModel>survey.getQuestionByName("q1");
      const q2 = <QuestionCheckboxModel>survey.getQuestionByName("q2");
      q1.choices = ["x", "y"];
      q2.choices = ["z"];
      expect(q1.visibleChoices.map(item => item.value)).toEqual([]);
      expect(q2.visibleChoices.map(item => item.value)).toEqual([]);
    }
    // other-item comment
    {
      const survey = new SurveyModel({ elements: [{ type: "radiogroup", name: "q1", choices: ["a"], showOtherItem: true }] });
      const q1 = <QuestionRadiogroupModel>survey.getQuestionByName("q1");
      q1.value = "other";
      q1.otherValue = "z";
      expect(q1.otherValue).toBe("z");
      expect(survey.getComment("q1")).toBe("z");
    }
    // other-item comment, a value-changed handler that rewrites the other text
    {
      const survey = new SurveyModel({ elements: [{ type: "radiogroup", name: "q1", choices: ["a"], showOtherItem: true }] });
      const q1 = <QuestionRadiogroupModel>survey.getQuestionByName("q1");
      q1.value = "other";
      survey.onValueChanged.add(() => { q1.otherValue = q1.otherValue + "!"; });
      q1.otherValue = "w";
      expect(q1.otherValue).toBe("w");
      expect(survey.getComment("q1")).toBe("w");
    }
    // composite inner value
    {
      ComponentCollection.Instance.add({ name: "normalcomposite", elementsJSON: [{ type: "text", name: "a" }, { type: "text", name: "b" }] });
      try {
        const survey = new SurveyModel({ elements: [{ type: "normalcomposite", name: "q1" }] });
        const q1 = <QuestionCompositeModel>survey.getQuestionByName("q1");
        q1.contentPanel.getQuestionByName("a").value = 1;
        q1.contentPanel.getQuestionByName("b").value = 2;
        expect(survey.data).toEqual({ q1: { a: 1, b: 2 } });
        survey.setValue("q1", { a: 5 });
        expect(q1.contentPanel.getQuestionByName("a").value).toBe(5);
        q1.contentPanel.getQuestionByName("b").value = 7;
        expect(survey.data).toEqual({ q1: { a: 5, b: 7 } });
      } finally {
        ComponentCollection.Instance.clear();
      }
    }
    // composite with an expression question, value set as a whole
    {
      ComponentCollection.Instance.add({
        name: "cornercomposite",
        elementsJSON: [
          { type: "text", name: "color" },
          { type: "text", name: "corner", defaultValue: 4 },
          { type: "expression", name: "radius", expression: "{composite.corner}+\"px\"", visible: false },
        ],
      });
      try {
        const survey = new SurveyModel({ elements: [{ type: "cornercomposite", name: "q1" }] });
        const q1 = <QuestionCompositeModel>survey.getQuestionByName("q1");
        q1.contentPanel.getQuestionByName("color").value = "#f8f8f8";
        let valueChangedCount = 0;
        survey.onValueChanged.add(() => { valueChangedCount++; });
        q1.value = { color: "#ffffff", corner: 6 };
        expect(valueChangedCount).toBe(1);
        expect(survey.data).toEqual({ q1: { color: "#ffffff", corner: 6, radius: "6px" } });
      } finally {
        ComponentCollection.Instance.clear();
      }
    }
    // composite onCreated sets an inner value
    {
      ComponentCollection.Instance.add({
        name: "namecomposite",
        elementsJSON: [{ type: "text", name: "first" }, { type: "text", name: "last" }],
        onCreated(question: QuestionCompositeModel) {
          question.contentPanel.getQuestionByName("first").value = "John";
        },
      });
      try {
        const survey = new SurveyModel({ elements: [{ type: "namecomposite", name: "q" }] });
        const q = <QuestionCompositeModel>survey.getQuestionByName("q");
        expect(q.contentPanel.getQuestionByName("first").value).toBe("John");
        q.contentPanel.getQuestionByName("last").value = "Doe";
        expect(survey.data).toEqual({ q: { first: "John", last: "Doe" } });
      } finally {
        ComponentCollection.Instance.clear();
      }
    }
    // custom question onCreated reads an inner dynamic panel
    {
      ComponentCollection.Instance.add({
        name: "rulescustom",
        questionJSON: { type: "paneldynamic", minPanelCount: 1, templateElements: [{ type: "text", name: "x" }] },
        onCreated(question: QuestionCustomModel) {
          (<QuestionPanelDynamicModel>question.contentQuestion).panels.forEach(p => p.questions.forEach(q => q.allowRootStyle = false));
        },
      });
      try {
        const survey = new SurveyModel({ elements: [{ type: "rulescustom", name: "q" }] });
        const q = <QuestionCustomModel>survey.getQuestionByName("q");
        expect((<QuestionPanelDynamicModel>q.contentQuestion).panelCount).toBe(1);
      } finally {
        ComponentCollection.Instance.clear();
      }
    }
    // an armed throw-once still reaches the caller
    {
      const fn = registerThrowOnceFunction("throwOnceNotSwallowed");
      try {
        const survey = new SurveyModel({ elements: [
          { type: "text", name: "q1" },
          { type: "text", name: "q3", visibleIf: "throwOnceNotSwallowed({q1})" },
        ] });
        fn.arm();
        expect(() => survey.setValue("q1", "x")).toThrow("throwOnceNotSwallowed");
      } finally {
        FunctionFactory.Instance.unregister("throwOnceNotSwallowed");
      }
    }
  });
});
