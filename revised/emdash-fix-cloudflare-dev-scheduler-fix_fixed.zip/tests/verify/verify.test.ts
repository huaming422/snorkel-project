// @ts-nocheck
//
// Scheduled maintenance under local Cloudflare development (`astro dev` with
// the Cloudflare adapter).
//
// Interfaces driven (all exported by packages/core):
//   - createVirtualModulesPlugin() + RESOLVED_VIRTUAL_SCHEDULER_ID: the text of
//     the generated scheduler module for a given adapter, loaded the way the
//     Cloudflare adapter's nested Vite build pass loads it during `astro dev`.
//   - emdash(): its astro:config:setup hook (the routes it injects for a given
//     adapter and command) and its astro:server:setup hook (what the dev host
//     does once the dev server is listening).
//   - runScheduledTasks() / withEmDashRuntime() from src/astro/middleware.ts,
//     the request-free maintenance entry points, replaced by spies.
//   - onRequest() from src/astro/middleware/auth.ts, the auth/CSRF middleware.
//
// Behavior asserted:
//   - The Cloudflare scheduler module exports `createScheduler` as an empty
//     value, in dev and in a production build. Node and the no-adapter case
//     keep the NodeCronScheduler factory in both.
//   - Cloudflare dev gets a maintenance route that Cloudflare build and
//     preview, Node dev and no-adapter dev do not get. Any route name or file
//     works.
//   - Once the dev server is listening, with no page traffic, the dev host
//     POSTs to that route on the server's listening address about once a
//     minute (4 to 10 times in five minutes), keeps going after a failed or
//     refused request, and stops once the server closes. Two listening
//     addresses are used, on ports other than the requested 4321. The request
//     may go through global fetch, node:http or node:https. Node and
//     no-adapter dev servers send no such request.
//   - The route runs maintenance in development and returns a 4xx without
//     running it outside development.
//   - The request the dev host sends gets through the auth/CSRF middleware to
//     the route in development, and in production the middleware or the route
//     refuses it with a 4xx and no maintenance runs.

import http from "node:http";
import https from "node:https";
import { EventEmitter } from "node:events";
import { syncBuiltinESMExports } from "node:module";

import { beforeEach, describe, expect, it, vi } from "vitest";

import { emdash } from "../../../../src/astro/integration/index.js";
import { libsql } from "../../../../src/db/adapters.js";
import { RESOLVED_VIRTUAL_SCHEDULER_ID } from "../../../../src/astro/integration/virtual-modules.js";
import {
	createVirtualModulesPlugin,
	type VitePluginOptions,
} from "../../../../src/astro/integration/vite-config.js";

// Both request-free maintenance entry points count as running maintenance:
// runScheduledTasks() directly, or withEmDashRuntime() with a callback that
// calls the runtime's maintenance methods.
const { maintenanceSpy, withRuntimeSpy } = vi.hoisted(() => {
	const maintenanceSpy = vi.fn(async () => ({ published: [] }));
	const fakeRuntime = {
		runScheduledTasks: maintenanceSpy,
		runScheduledTasksWithStats: maintenanceSpy,
	};
	const withRuntimeSpy = vi.fn(async (run: (runtime: unknown) => unknown) => run(fakeRuntime));
	return { maintenanceSpy, withRuntimeSpy };
});
vi.mock("../../../../src/astro/middleware.js", () => ({
	runScheduledTasks: maintenanceSpy,
	withEmDashRuntime: withRuntimeSpy,
}));

// The auth middleware imports modules that only exist inside Astro. Stub them
// the same way the package's own middleware tests (tests/unit/middleware/) do.
vi.mock("astro:middleware", () => ({ defineMiddleware: (handler: unknown) => handler }));
vi.mock("virtual:emdash/auth", () => ({ authenticate: vi.fn() }));
vi.mock("@emdash-cms/auth", () => ({ hasScope: vi.fn(() => false), TRANSFER_SCOPES: [] }));
vi.mock("@emdash-cms/auth/adapters/kysely", () => ({
	createKyselyAdapter: vi.fn(() => ({ getUserById: vi.fn(), getUserByEmail: vi.fn() })),
}));

// Development and production values for Astro's import.meta.env flags, so a
// gate on DEV, PROD or MODE reads the same environment.
function stubDevEnv(): void {
	vi.stubEnv("DEV", true);
	vi.stubEnv("PROD", false);
	vi.stubEnv("MODE", "development");
}

function stubProdEnv(): void {
	vi.stubEnv("DEV", false);
	vi.stubEnv("PROD", true);
	vi.stubEnv("MODE", "production");
}

// ---------------------------------------------------------------------------
// Generated scheduler module.
// ---------------------------------------------------------------------------

// A Vite plugin hook may be a bare function or a { handler } object.
function callHook<T>(hook: unknown, ...args: unknown[]): T {
	const fn = typeof hook === "function" ? hook : (hook as { handler: unknown }).handler;
	return (fn as (...a: unknown[]) => T)(...args);
}

// Load the scheduler module for an adapter and Astro command. The second
// argument to createVirtualModulesPlugin is the Astro command for plugin
// signatures that take one; a signature without it ignores the extra
// argument. The Cloudflare adapter builds the worker bundle with a nested
// Vite pass that reports `command: "build"` even during `astro dev`, so the
// plugin sees "build" here in both cases.
function schedulerModuleFor(
	adapterName: string | undefined,
	astroCommand: "dev" | "build" = "dev",
): string {
	const options = {
		serializableConfig: {},
		resolvedConfig: {},
		pluginDescriptors: [],
		astroConfig: { adapter: adapterName ? { name: adapterName } : undefined },
	} as unknown as VitePluginOptions;

	const plugin = createVirtualModulesPlugin(options, astroCommand);
	callHook(plugin.configResolved, { command: "build" });
	return callHook<string>(plugin.load, RESOLVED_VIRTUAL_SCHEDULER_ID);
}

// The runtime starts a scheduler only when `createScheduler` is truthy. An
// empty module exports it as null, undefined, false or void 0 (or declares it
// with no value), directly or through an export list, and builds no timer.
function exportsEmptyScheduler(moduleSource: string): boolean {
	const emptyValue =
		/(?:const|let|var)\s+createScheduler\s*(?:=\s*(?:null|undefined|false|void\s+0)\s*)?(?:;|$)/m.test(
			moduleSource,
		);
	const exported =
		/export\s+(?:const|let|var)\s+createScheduler\b/.test(moduleSource) ||
		/export\s*\{[^}]*\bcreateScheduler\b[^}]*\}/.test(moduleSource);
	return emptyValue && exported;
}

function injectsInWorkerTimer(moduleSource: string): boolean {
	const emitsFactory =
		/createScheduler\s*\(/.test(moduleSource) || /NodeCronScheduler/.test(moduleSource);
	return emitsFactory && !exportsEmptyScheduler(moduleSource);
}

// ---------------------------------------------------------------------------
// Injected routes and what runs behind them.
// ---------------------------------------------------------------------------

type AstroCommand = "dev" | "build" | "preview" | "sync";

function astroConfigFor(adapterName: string | undefined) {
	const root = new URL("file:///tmp/emdash-verify/");
	return {
		root,
		srcDir: new URL("src/", root),
		security: {},
		trailingSlash: "ignore",
		adapter: adapterName ? { name: adapterName } : undefined,
		integrations: [{ name: "@astrojs/react", hooks: {} }],
	};
}

function silentLogger() {
	return { debug: vi.fn(), error: vi.fn(), info: vi.fn(), warn: vi.fn() };
}

// Run emdash()'s astro:config:setup hook for an adapter and command and
// collect each injected route's pattern and entrypoint. The config is the
// minimal shape the package's own integration tests use.
function injectedRoutes(
	adapterName: string | undefined,
	command: AstroCommand,
): Array<{ pattern: string; entrypoint: string }> {
	const routes: Array<{ pattern: string; entrypoint: string }> = [];
	const integration = emdash({ database: libsql({ url: "libsql://verify.example.com" }) });
	const setup = integration.hooks["astro:config:setup"];
	if (typeof setup !== "function") throw new Error("emdash() has no astro:config:setup hook");
	callHook(setup, {
		command,
		config: astroConfigFor(adapterName),
		logger: silentLogger(),
		injectRoute: (route: { pattern: string; entrypoint: string }) =>
			routes.push({ pattern: route.pattern, entrypoint: route.entrypoint }),
		addMiddleware: vi.fn(),
		updateConfig: vi.fn(),
	});
	return routes;
}

function injectedRoutePatterns(adapterName: string | undefined, command: AstroCommand): string[] {
	return injectedRoutes(adapterName, command).map((route) => route.pattern);
}

// Routes injected for Cloudflare dev and for none of: the Cloudflare
// production build, Node dev, no-adapter dev.
function cloudflareDevOnlyRoutes(): string[] {
	const cloudflareDev = new Set(injectedRoutePatterns("@astrojs/cloudflare", "dev"));
	const baselines = [
		injectedRoutePatterns("@astrojs/cloudflare", "build"),
		injectedRoutePatterns("@astrojs/node", "dev"),
		injectedRoutePatterns(undefined, "dev"),
	];
	const everElsewhere = new Set(baselines.flat());
	return [...cloudflareDev].filter((pattern) => !everElsewhere.has(pattern));
}

function cloudflareDevRouteEntry(pattern: string): { pattern: string; entrypoint: string } | undefined {
	return injectedRoutes("@astrojs/cloudflare", "dev").find((route) => route.pattern === pattern);
}

// Import a route module from the entrypoint the integration reports. Only the
// TypeScript source exists under test, so a built .mjs/.js path falls back to
// the .ts file next to it, as the integration's resolveRoute() does in dev.
async function loadRouteModule(entrypoint: string): Promise<Record<string, unknown>> {
	const candidates = [entrypoint, entrypoint.replace(/\.(mjs|js)$/, ".ts")];
	for (const candidate of candidates) {
		try {
			return (await import(/* @vite-ignore */ candidate)) as Record<string, unknown>;
		} catch {
			// try next candidate
		}
	}
	throw new Error(`could not import dev-only route entrypoint: ${entrypoint}`);
}

// The handler for a POST: POST itself, or ALL.
function postHandler(mod: Record<string, unknown>): ((ctx: unknown) => unknown) | undefined {
	for (const method of ["POST", "ALL"]) {
		if (typeof mod[method] === "function") return mod[method] as (ctx: unknown) => unknown;
	}
	return undefined;
}

function requestContext(request: Request): unknown {
	return {
		request,
		url: new URL(request.url),
		locals: {},
		params: {},
	};
}

async function loadAuthOnRequest(): Promise<
	(ctx: unknown, next: () => Promise<Response>) => Promise<Response>
> {
	const mod = await import("../../../../src/astro/middleware/auth.js");
	const onRequest = (mod as Record<string, unknown>).onRequest;
	if (typeof onRequest !== "function") {
		throw new Error("auth middleware has no onRequest export");
	}
	return onRequest as (ctx: unknown, next: () => Promise<Response>) => Promise<Response>;
}

function middlewareContext(request: Request): unknown {
	return {
		url: new URL(request.url),
		request,
		locals: { emdash: { db: {}, config: {} } },
		session: {
			get: vi.fn().mockResolvedValue(null),
			set: vi.fn(),
			destroy: vi.fn(),
		},
		redirect: (location: string) =>
			new Response(null, { status: 302, headers: { Location: location } }),
	};
}

function isSuccess(response: Response): boolean {
	return response.status >= 200 && response.status < 300;
}

function isClientRejection(response: Response): boolean {
	return response.status >= 400 && response.status < 500;
}

// ---------------------------------------------------------------------------
// Dev server double and outgoing requests.
// ---------------------------------------------------------------------------

// Astro asks Vite for port 4321. When that port is taken, Vite listens on the
// next free one, so the server config keeps the requested port while
// resolvedUrls and address() give the port the server really listens on. The
// double listens on two different addresses, neither of them the default, so
// an origin written into the code misses at least one of them.
const REQUESTED_PORT = 4321;

type DevListen = { host: string; port: number; address: string };

const DEV_LISTENS: DevListen[] = [
	{ host: "localhost", port: 4987, address: "127.0.0.1" },
	{ host: "127.0.0.1", port: 5236, address: "127.0.0.1" },
];
const DEV_LISTEN = DEV_LISTENS[0]!;

function originOf(listen: DevListen): string {
	return `http://${listen.host}:${listen.port}/`;
}

const DEV_ORIGIN = originOf(DEV_LISTEN);

type RecordedCall = { url: string; method: string; headers: Record<string, string> };

function pathnameOf(url: string): string {
	try {
		return new URL(url).pathname;
	} catch {
		return url;
	}
}

// True when a request URL reaches the listening server: plain HTTP, the
// listening port, and the host from resolvedUrls or the bound address.
function reachesServer(url: string, listen: DevListen): boolean {
	let parsed: URL;
	try {
		parsed = new URL(url);
	} catch {
		return false;
	}
	const hostname = parsed.hostname.replace(/^\[(.*)\]$/, "$1");
	return (
		parsed.protocol === "http:" &&
		parsed.port === String(listen.port) &&
		(hostname === listen.host || hostname === listen.address)
	);
}

function headersToRecord(headers: unknown): Record<string, string> {
	const out: Record<string, string> = {};
	if (!headers) return out;
	if (typeof (headers as Headers).forEach === "function" && !Array.isArray(headers)) {
		(headers as Headers).forEach((value, key) => {
			out[key.toLowerCase()] = String(value);
		});
		return out;
	}
	const entries = Array.isArray(headers)
		? (headers as Array<[string, string]>)
		: Object.entries(headers as Record<string, unknown>);
	for (const [key, value] of entries) out[String(key).toLowerCase()] = String(value);
	return out;
}

// Answers for requests to a watched path: one sent anywhere but the listening
// server fails at the network level, since nothing listens there. Of those
// that reach the server, the first gets a 500, the second fails at the
// network level, every later one gets 204. Any other path gets 204. So a
// heartbeat that stops after one failed request is visible.
function makeOutcomes(watched: Set<string>, listen: DevListen) {
	let watchedCount = 0;
	return (url: string): "500" | "network" | "204" => {
		if (!watched.has(pathnameOf(url))) return "204";
		if (!reachesServer(url, listen)) return "network";
		watchedCount += 1;
		if (watchedCount === 1) return "500";
		if (watchedCount === 2) return "network";
		return "204";
	};
}

// Stand-in for http.request / https.request. Records the call when the
// request is ended and answers without opening a socket. Accepts
// (url[, options][, callback]) and (options[, callback]).
function fakeNodeRequest(calls: RecordedCall[], outcome: (url: string) => string) {
	return (...args: unknown[]) => {
		let url: string | undefined;
		let options: Record<string, unknown> = {};
		let callback: ((res: unknown) => void) | undefined;
		for (const arg of args) {
			if (typeof arg === "string" || arg instanceof URL) url = String(arg);
			else if (typeof arg === "function") callback = arg as (res: unknown) => void;
			else if (arg && typeof arg === "object") options = arg as Record<string, unknown>;
		}
		if (!url) {
			const protocol = (options.protocol as string | undefined) ?? "http:";
			const host = (options.hostname ?? options.host ?? "localhost") as string;
			const port = options.port ? `:${options.port}` : "";
			url = `${protocol}//${host}${port}${(options.path as string | undefined) ?? "/"}`;
		}
		const method = String(options.method ?? "GET").toUpperCase();
		const headers = headersToRecord(options.headers);

		const req = new EventEmitter() as EventEmitter & Record<string, unknown>;
		let ended = false;
		Object.assign(req, {
			write: () => true,
			setHeader: (key: string, value: unknown) => {
				headers[String(key).toLowerCase()] = String(value);
			},
			setTimeout: () => req,
			destroy: () => req,
			abort: () => undefined,
			end: () => {
				if (ended) return req;
				ended = true;
				calls.push({ url: url!, method, headers });
				const result = outcome(url!);
				if (result === "network") {
					queueMicrotask(() => req.emit("error", new Error("connect ECONNREFUSED")));
					return req;
				}
				const status = result === "500" ? 500 : 204;
				const res = new EventEmitter() as EventEmitter & Record<string, unknown>;
				Object.assign(res, {
					statusCode: status,
					statusMessage: status === 500 ? "Internal Server Error" : "No Content",
					headers: {},
					setEncoding: () => res,
					resume: () => res,
					read: () => null,
					[Symbol.asyncIterator]: async function* () {},
				});
				queueMicrotask(() => {
					callback?.(res);
					req.emit("response", res);
					queueMicrotask(() => {
						res.emit("end");
						res.emit("close");
						req.emit("close");
					});
				});
				return req;
			},
		});
		return req;
	};
}

// Run emdash()'s config and server setup hooks for an adapter in `astro dev`
// against a dev server double, with global fetch, http.request and
// https.request recorded. resolvedUrls is null until the server is listening,
// as in Vite, and the config holds the requested port, not the listening one.
// Call start() to fire "listening", advance(ms) to move fake time, close() to
// fire "close", and restore() at the end.
function startDevServer(
	adapterName: string | undefined,
	watched: Set<string>,
	listen: DevListen = DEV_LISTEN,
) {
	vi.useFakeTimers();
	const calls: RecordedCall[] = [];
	const outcome = makeOutcomes(watched, listen);

	const realFetch = globalThis.fetch;
	globalThis.fetch = (async (input: unknown, init?: { method?: string; headers?: unknown }) => {
		const url = input instanceof Request ? input.url : String(input);
		const method = String(init?.method ?? (input instanceof Request ? input.method : "GET")).toUpperCase();
		const headers = headersToRecord(init?.headers ?? (input instanceof Request ? input.headers : undefined));
		calls.push({ url, method, headers });
		const result = outcome(url);
		if (result === "network") throw new TypeError("fetch failed");
		const status = result === "500" ? 500 : 204;
		return {
			ok: status < 300,
			status,
			headers: new Headers(),
			json: async () => ({}),
			text: async () => "",
		};
	}) as unknown as typeof fetch;

	const httpSpy = vi.spyOn(http, "request").mockImplementation(fakeNodeRequest(calls, outcome));
	const httpsSpy = vi.spyOn(https, "request").mockImplementation(fakeNodeRequest(calls, outcome));
	syncBuiltinESMExports();

	const listeners: Record<string, Array<() => void>> = {};
	const httpServer = {
		once(event: string, cb: () => void) {
			(listeners[event] ||= []).push(cb);
			return httpServer;
		},
		on(event: string, cb: () => void) {
			(listeners[event] ||= []).push(cb);
			return httpServer;
		},
		address: () => ({ address: listen.address, port: listen.port, family: "IPv4" }),
	};
	const server = {
		httpServer,
		environments: {},
		config: { base: "/", server: { host: listen.host, port: REQUESTED_PORT } },
		resolvedUrls: null as null | { local: string[]; network: string[] },
	};

	const integration = emdash({ database: libsql({ url: "libsql://verify.example.com" }) });
	const logger = silentLogger();
	callHook(integration.hooks["astro:config:setup"], {
		command: "dev",
		config: astroConfigFor(adapterName),
		logger,
		injectRoute: vi.fn(),
		addMiddleware: vi.fn(),
		updateConfig: vi.fn(),
	});
	const serverSetup = integration.hooks["astro:server:setup"];
	if (typeof serverSetup !== "function") throw new Error("emdash() has no astro:server:setup hook");
	callHook(serverSetup, { server, logger });

	const fire = (event: string) => {
		const subscribers = listeners[event] ?? [];
		listeners[event] = [];
		for (const cb of subscribers) cb();
	};

	return {
		calls,
		start() {
			server.resolvedUrls = { local: [originOf(listen)], network: [] };
			fire("listening");
		},
		advance: (ms: number) => vi.advanceTimersByTimeAsync(ms),
		close() {
			fire("close");
		},
		restore() {
			globalThis.fetch = realFetch;
			httpSpy.mockRestore();
			httpsSpy.mockRestore();
			syncBuiltinESMExports();
			vi.useRealTimers();
		},
	};
}

// Routes the dev server already POSTs to on its own once it is listening.
const BASE_DEV_POSTS = ["/_emdash/api/typegen"];

// POSTs to one of the given paths, sent to any host.
function postsTo(calls: RecordedCall[], paths: Set<string>): RecordedCall[] {
	return calls.filter((call) => call.method === "POST" && paths.has(pathnameOf(call.url)));
}

// POSTs to one of the given paths that reach the listening server.
function postsToServer(
	calls: RecordedCall[],
	paths: Set<string>,
	listen: DevListen,
): RecordedCall[] {
	return postsTo(calls, paths).filter((call) => reachesServer(call.url, listen));
}

// The first POST an idle Cloudflare dev server sends to itself on one of the
// given paths within two minutes, if any.
async function firstHeartbeat(paths: Set<string>): Promise<RecordedCall | undefined> {
	const dev = startDevServer("@astrojs/cloudflare", new Set());
	try {
		dev.start();
		await dev.advance(2 * 60_000);
		return postsToServer(dev.calls, paths, DEV_LISTEN)[0];
	} finally {
		dev.restore();
	}
}

describe("Cloudflare dev scheduled-maintenance driver", () => {
	beforeEach(() => {
		maintenanceSpy.mockClear();
		withRuntimeSpy.mockClear();
	});

	it("exports an empty createScheduler for Cloudflare in dev and in a production build", () => {
		for (const command of ["dev", "build"] as const) {
			const source = schedulerModuleFor("@astrojs/cloudflare", command);
			expect(injectsInWorkerTimer(source)).toBe(false);
			expect(exportsEmptyScheduler(source)).toBe(true);
			expect(source).not.toMatch(/NodeCronScheduler/);
		}
	});

	it("keeps the NodeCronScheduler factory for Node in dev and in a production build", () => {
		for (const command of ["dev", "build"] as const) {
			const source = schedulerModuleFor("@astrojs/node", command);
			expect(injectsInWorkerTimer(source)).toBe(true);
			expect(source).toMatch(/NodeCronScheduler/);
			expect(exportsEmptyScheduler(source)).toBe(false);
		}
	});

	it("keeps the NodeCronScheduler factory when no adapter is configured", () => {
		for (const command of ["dev", "build"] as const) {
			const source = schedulerModuleFor(undefined, command);
			expect(injectsInWorkerTimer(source)).toBe(true);
			expect(exportsEmptyScheduler(source)).toBe(false);
		}
	});

	it("injects a route for Cloudflare dev that no other adapter or build gets", () => {
		expect(cloudflareDevOnlyRoutes().length).toBeGreaterThan(0);
	});

	it("POSTs to that route on the listening server about once a minute while idle, through failures, until the server closes", async () => {
		const devOnlyPatterns = new Set(cloudflareDevOnlyRoutes());
		expect(devOnlyPatterns.size).toBeGreaterThan(0);

		for (const listen of DEV_LISTENS) {
			const dev = startDevServer("@astrojs/cloudflare", devOnlyPatterns, listen);
			try {
				dev.start();
				await dev.advance(5 * 60_000);
				const whileOpen = postsToServer(dev.calls, devOnlyPatterns, listen).length;
				expect(whileOpen, `POSTs to ${originOf(listen)} while open`).toBeGreaterThanOrEqual(4);
				expect(whileOpen, `POSTs to ${originOf(listen)} while open`).toBeLessThanOrEqual(10);

				// After "close", no POST to the route goes anywhere.
				const atClose = postsTo(dev.calls, devOnlyPatterns).length;
				dev.close();
				await dev.advance(5 * 60_000);
				expect(postsTo(dev.calls, devOnlyPatterns).length, "POSTs after close").toBe(atClose);
			} finally {
				dev.restore();
			}
		}
	});

	it("runs maintenance behind that route in development and refuses it outside development", async () => {
		const [pattern] = cloudflareDevOnlyRoutes();
		expect(pattern).toBeTruthy();
		const entry = cloudflareDevRouteEntry(pattern!);
		expect(entry).toBeTruthy();

		const handler = postHandler(await loadRouteModule(entry!.entrypoint));
		expect(typeof handler).toBe("function");

		const url = new URL(pattern!, DEV_ORIGIN).href;

		stubDevEnv();
		let devResponse: Response;
		try {
			devResponse = (await handler!(requestContext(new Request(url, { method: "POST" })))) as Response;
		} finally {
			vi.unstubAllEnvs();
		}
		expect(maintenanceSpy).toHaveBeenCalledTimes(1);
		expect(isSuccess(devResponse)).toBe(true);

		maintenanceSpy.mockClear();
		stubProdEnv();
		try {
			const prodResponse = (await handler!(
				requestContext(new Request(url, { method: "POST" })),
			)) as Response;
			expect(maintenanceSpy).not.toHaveBeenCalled();
			expect(isClientRejection(prodResponse)).toBe(true);
		} finally {
			vi.unstubAllEnvs();
		}
	});

	it("keeps the route and the heartbeat out of Node dev, no-adapter dev and Cloudflare build or preview", async () => {
		// The route the Cloudflare dev heartbeat targets. The dev
		// server already POSTs to the typegen route once it is listening, so
		// that route is not a candidate.
		const candidates = new Set(injectedRoutePatterns("@astrojs/cloudflare", "dev"));
		for (const path of BASE_DEV_POSTS) candidates.delete(path);
		const heartbeat = await firstHeartbeat(candidates);
		expect(heartbeat).toBeTruthy();
		const target = pathnameOf(heartbeat!.url);

		for (const [adapter, command] of [
			["@astrojs/cloudflare", "build"],
			["@astrojs/cloudflare", "preview"],
			["@astrojs/node", "dev"],
			[undefined, "dev"],
		] as const) {
			expect(injectedRoutePatterns(adapter, command)).not.toContain(target);
		}

		for (const adapter of ["@astrojs/node", undefined]) {
			const dev = startDevServer(adapter, new Set());
			try {
				dev.start();
				await dev.advance(5 * 60_000);
				expect(postsTo(dev.calls, new Set([target]))).toHaveLength(0);
			} finally {
				dev.restore();
			}
		}
	});

	it("lets the heartbeat request through auth to the route in development, and runs nothing in production", async () => {
		// The request is the one the dev host sends (its method and headers,
		// with no session cookie). The middleware passes it on to the route
		// handler. In production, the middleware or the handler must refuse it
		// with a 4xx and no maintenance may run.
		const devOnlyPatterns = new Set(cloudflareDevOnlyRoutes());
		expect(devOnlyPatterns.size).toBeGreaterThan(0);
		const heartbeat = await firstHeartbeat(devOnlyPatterns);
		const pattern = heartbeat ? pathnameOf(heartbeat.url) : [...devOnlyPatterns][0]!;
		const headers = heartbeat?.headers ?? {};
		delete headers.cookie;

		const entry = cloudflareDevRouteEntry(pattern);
		expect(entry).toBeTruthy();
		const handler = postHandler(await loadRouteModule(entry!.entrypoint));
		expect(typeof handler).toBe("function");

		const onRequest = await loadAuthOnRequest();
		const url = new URL(pattern, DEV_ORIGIN).href;
		const heartbeatRequest = () => new Request(url, { method: "POST", headers });

		const throughMiddleware = async (): Promise<Response> => {
			const request = heartbeatRequest();
			return onRequest(middlewareContext(request), async () =>
				(await handler!(requestContext(request))) as Response,
			);
		};

		stubDevEnv();
		let devResponse: Response;
		try {
			devResponse = await throughMiddleware();
		} finally {
			vi.unstubAllEnvs();
		}
		expect(isSuccess(devResponse)).toBe(true);
		expect(maintenanceSpy).toHaveBeenCalledTimes(1);

		maintenanceSpy.mockClear();
		stubProdEnv();
		let prodResponse: Response;
		try {
			prodResponse = await throughMiddleware();
		} finally {
			vi.unstubAllEnvs();
		}
		expect(maintenanceSpy).not.toHaveBeenCalled();
		expect(isClientRejection(prodResponse)).toBe(true);
	});
});
