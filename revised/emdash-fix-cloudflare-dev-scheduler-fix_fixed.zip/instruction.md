## Task

Scheduled maintenance stops running when I work locally with `astro dev` on the Cloudflare adapter.
By scheduled maintenance I mean EmDash's recurring work: plugin cron jobs, scheduled publishing and cleanup.
It runs once, right around the first request that boots EmDash, and after that it never runs again that session.
Nothing else looks wrong.
Pages load, nothing crashes and the console stays quiet, so you only find out when a scheduled post never goes live.
The Node dev server runs a maintenance pass about once a minute, even with no traffic at all.
On Cloudflare dev I can leave the server idle for several minutes and not one more pass happens.

The Node and Bun dev servers keep running it on schedule, and so does a deployed Cloudflare site.
Only local Cloudflare dev has the problem.

Please find out why it stops, and make it keep running at that usual once-a-minute pace for the whole local Cloudflare dev session.
One failed pass shouldn't end it either.
When the dev server shuts down or restarts, nothing from the old session should keep firing in the background.
Node and Bun dev, and production builds, should behave exactly as they do now.
Production builds shouldn't gain any new way to trigger maintenance.
