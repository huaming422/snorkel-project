#!/usr/bin/env bash
# Verifier-phase setup.
#
# All dependencies are baked into the image: the Rust toolchain, the cargo
# dependency closure and a pre-warmed target cache. This setup installs
# nothing; it only reports the toolchain and confirms the workspace is present.
set -euo pipefail

echo "[test-setup] Rust version:    $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:   $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Workspace root:  /repo/mise"
echo "[test-setup] CARGO_TARGET_DIR: ${CARGO_TARGET_DIR:-<unset>}"

if [ ! -f /repo/mise/Cargo.toml ]; then
  echo "[test-setup] ERROR: /repo/mise/Cargo.toml not found" >&2
  exit 1
fi

echo "[test-setup] Setup complete."
