#!/usr/bin/env bash
# Validation setup: runs after the user changes are applied, before the stories.
#
# One job: rebuild the CLI binary with those changes. The image already holds
# the dependency closure and a warm target cache, so this is an incremental
# recompile and relink that takes a couple of minutes at most.
#
# No fixtures are staged here: each story builds its own throwaway project
# through the shared harness, so there is nothing on disk to seed. Idempotent:
# re-running just rebuilds.
set -euo pipefail

REPO=/repo/mise
TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
BIN="$TARGET_DIR/debug/mise"

export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="$TARGET_DIR"
export PATH="$CARGO_HOME/bin:$PATH"

echo "validation-setup: rustc=$(rustc --version 2>&1 | head -1)"
echo "validation-setup: cargo=$(cargo --version 2>&1 | head -1)"
echo "validation-setup: target dir=$TARGET_DIR"

# Rebuild the binary with the user changes applied (incremental).
echo "validation-setup: building the CLI binary (incremental)..."
( cd "$REPO" && cargo build --locked -p mise 2>&1 | tail -8 )

test -x "$BIN" || {
    echo "ERROR: binary missing at $BIN after cargo build" >&2
    exit 1
}

# Loud smoke guard: if the binary cannot even report its version, every story
# would fail with the same opaque error, so surface it here instead.
"$BIN" --version >/dev/null || {
    echo "ERROR: '$BIN --version' failed after build" >&2
    exit 1
}
echo "validation-setup: built OK ($("$BIN" --version 2>&1 | head -1))"
echo "validation-setup: done."
