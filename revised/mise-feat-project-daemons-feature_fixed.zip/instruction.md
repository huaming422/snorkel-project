## Task

We want projects to declare the background processes they need, like a dev server or a local Postgres, in a `[daemons]` section of `mise.toml`, with a new `mise daemons` command to list and control them.
mise doesn't supervise them itself, since pitchfork, an external supervisor on PATH, does that job.
It's all experimental, so without experimental mode `mise daemons` refuses to run and the rest of mise ignores `[daemons]`.

## User stories / requirements

- A `[daemons]` entry is a preset shorthand like `postgres = "18"` or `redis = "8"`, a `[daemons.NAME]` block with `run`, or one with `preset`, `version` and optional `port`. Anything else is an error, as is a name unsafe as a directory, URL part or SQL identifier. `mise daemons ls` lists them, also as `--json`.
- A preset daemon's database tool becomes one of the project's managed tools. `mise ls` shows it, and it follows the lockfile rules like other tools, so `[tool_config] locked = true` refuses it when the lockfile has no entry. `mise unuse` won't drop it and says it comes from `[daemons]`.
- `mise env` exports `PGPORT` and `DATABASE_URL` for a PostgreSQL preset and `REDIS_URL` for a Redis one. They use port 5432 or 6379 unless the daemon sets `port`, and each URL carries the daemon's port. A value the user sets in `[env]` wins over the preset's.
- `mise daemons start`, `stop` and `restart` hand the work to pitchfork, for all daemons or just the named ones. They refuse `--group` and unknown names before calling pitchfork. `mise daemons ls` never drives a daemon. With pitchfork older than 2.25.0, start and restart fail naming that version, and nothing gets registered or started.
- A child directory's `mise.toml` adds its daemons to the ones its parent directories declare. When it declares a name a parent already uses, its entry replaces the parent's, including the tool and the exported variables.
