## Task

Projects often need a few processes running while you work on them, like a dev server or a local Postgres.
We want mise to handle that: a project declares these daemons in a `[daemons]` section of its `mise.toml`, and a new `mise daemons` command lists and controls them.

mise shouldn't supervise processes itself.
That job goes to pitchfork, an external supervisor that mise finds on PATH.

Daemon names end up as data directory names, URL parts and SQL identifiers, so only ASCII letters, digits, `.`, `_` and `-` are allowed.
A name also can't be `.`, can't contain `..` or `--`, and can't start or end with `-`.

The whole feature is experimental.
Without experimental mode, `mise daemons` refuses to run and the rest of mise ignores the `[daemons]` section.

## User stories / requirements

- A `[daemons]` entry is a preset shorthand (`postgres = "18"` or `redis = "8"`, where the key picks the preset and the value is the version), a `[daemons.NAME]` block with `run`, or a block with `preset`, `version` and an optional `port`. Anything else is an error. `mise daemons ls` lists them, also as `--json`.
- A preset daemon's database tool becomes one of the project's managed tools. `mise ls` shows it, and it follows the lockfile rules like other tools, so `[tool_config] locked = true` refuses it when the lockfile has no entry. `mise unuse` won't drop it and says it comes from `[daemons]`.
- `mise env` exports `PGPORT` and `DATABASE_URL` for a PostgreSQL preset and `REDIS_URL` for a Redis one. They use port 5432 or 6379 unless the daemon sets `port`, and each URL carries the daemon's port. A value the user sets in `[env]` wins over the preset's.
- `mise daemons start`, `stop` and `restart` hand the work to pitchfork, for all daemons or just the named ones. They refuse `--group` and unknown names before calling pitchfork. `mise daemons ls` never drives a daemon. With pitchfork older than 2.25.0, start and restart fail naming that version, and nothing gets registered or started.
- A child directory's `mise.toml` adds its daemons to the ones its parent directories declare. When it declares a name a parent already uses, its entry replaces the parent's, including the tool and the exported variables.
