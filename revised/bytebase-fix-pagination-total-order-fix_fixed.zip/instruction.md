## Task

Paging through some of our lists is broken.
Rows that exist never show up on any page, and other rows show up on two pages.
The issues list is the worst, mostly My Issues, which pulls issues from every project the user is in.

Nobody is writing anything while this happens.
Walking the same list page by page over data that doesn't change still loses some rows and repeats others.
Loading the whole list in one request looks fine, so it only goes wrong once the list is split into pages.

We've seen the same thing on these lists:
- users, groups, service accounts and workload identities
- access grants, releases and revisions
- projects sorted by title, and databases sorted by project
- issues sorted by create time or update time, and issue search results
- an issue's activity feed

The activity feed has one more problem.
When someone edits an issue and changes several fields at once, each change gets its own entry, and paging through the feed shows those entries out of order.

Please make paging through each of these lists return every row exactly once, even when lots of rows look the same under the list's sort order.
The entries from one edit should come back in the order they were made.
Each list should keep the order it has today: its default order (newest first where that's the default), the order a caller asks for, and relevance order for search results.
