## Task

Chat links should get a small site icon (a favicon) in front of the link text, the way a browser tab shows one.
This is for web links in assistant replies and in the messages people type, and it has to work in the web app, the desktop app and the mobile app.

Privacy is the hard rule.
Someone watching a device's traffic must not be able to tell which sites a conversation links to.
So the app may never request the linked site, and it may not use any outside favicon or icon service either.
Icons come only from the Rakazo API: a new signed-in API call takes a site origin, does the fetching on the server, and returns an image the app can show as is.

On the server, the code that finds and prepares icons should come from a factory that accepts the same fetch and host-lookup hooks the existing safe web fetch takes, plus a clock and its limits (how much it caches, how long requests may wait in the queue).
That way it can run without a real network.
On the client, the shared chat-markdown renderer should get icons from a lookup function the app hands it through React context.
The renderer calls that function with the link's origin and gets back an icon or nothing, plus a flag meaning "busy, ask again later".
The context value may also carry the current API base.

Only http and https links are in scope.

## User stories / requirements

- A signed-in user can ask the API about a site origin and gets either an icon ready to display or a plain "no icon" answer.
  A request without a session is turned away before any icon work starts, and the server-side lookup only ever receives the origin that was asked for.
- If the server is already running as many icon fetches as it allows, a new request gets a quick "busy, try again soon" answer.
  It is not told the site has no icon, it is not left hanging, and the site is not remembered as having no icon.
- The server works out an image's format from its bytes, not the declared content type.
  PNG, JPEG, GIF, WebP and ICO icons are accepted and turned into one small square image.
  A 1x1 tracking pixel, an oversized image, an SVG or other vector, or non-image bytes all give "no icon" instead of an error.
- Sites that serve the old multi-image .ico format get the best, largest image from that file.
  A broken .ico (an entry pointing past the end, a truncated file, or an entry bigger than the 256-pixel limit the format allows) gives "no icon" and never throws.
- Asking again for the same origin reuses the earlier answer, and a site with no icon is remembered just like one with an icon.
  The cache has a size limit and drops the least recently used entries first.
  Simultaneous requests for one origin, even written with and without a trailing slash, share one lookup.
- All server fetching goes through the existing guard against unsafe or internal addresses, sends no cookies or credentials, follows a limited number of redirects, and uses only normal web ports.
  The server reads the home page for a declared icon, falls back to /favicon.ico, and never requests the path a message linked to.
- When a link's text is just its URL, the label shows host and path without the scheme.
  The host is never shortened, and an international host appears in ASCII (punycode) form.
  The path is shown decoded with invisible formatting characters removed, and a very long path is trimmed.
  Author-written link text stays as written.
- The icon is decorative, so screen readers skip it and read only the link text.
  While the icon loads, when the site has none, or when the image fails or turns out to be 1x1, a neutral generic website placeholder shows instead.
  Right-to-left characters in a label cannot reorder the text around the link.
- While a reply is still streaming, no icons are requested; the lookup happens once the reply settles, with the link's origin.
  Links that are not website links (email, phone, in-app or relative, wrapping an image, or unsafe) keep their current look, get no icon and trigger no lookup.
- The client keeps answers for the session.
  A lookup that fails shows the placeholder and is not tried again until several minutes have passed, and a "busy" answer is retried a few times while the link is on screen.
  Switching the app to another API base does not reuse answers from the old one.
- Website links get the icon in all four places chat shows them: assistant replies and typed messages, in both the web and mobile renderers.
  Each passes the link's origin to the app's icon lookup, draws only the image that lookup returns, and sends no request of its own, even when the site has no icon.
- Other chat markdown around web links renders as before, both while streaming and once settled: an email link stays a plain link with no icon, an inline image still shows as an image, and a table still shows as a table.
