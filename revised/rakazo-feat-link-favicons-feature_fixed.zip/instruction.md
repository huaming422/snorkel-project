## Task

Chat links should get a small site icon (a favicon) in front of the link text, the way a browser tab shows one.
This is for web links in assistant replies and in the messages people type, and it has to work in the web app, the desktop app and the mobile app.

Privacy is the hard rule.
Someone watching a device's traffic must not be able to tell which sites a conversation links to.
So the app may never request the linked site, and it may not use any outside favicon or icon service either.
Icons come only from the Rakazo API: a new signed-in API call takes a site origin, does the fetching on the server, and returns an image the app can show as is.

The server side has to be testable without a real network or DNS, the same way the existing safe web fetch is.
Only http and https links are in scope.

## User stories / requirements

- A signed-in user can ask the API about a site origin and gets either an icon ready to display or a plain "no icon" answer.
  A request without a session is turned away before any icon work starts, and the server-side lookup only ever receives the origin that was asked for.
- The server judges an image by its bytes, not its declared type.
  PNG, JPEG, GIF, WebP and ICO icons become one small square image, from an .ico's largest entry.
  A 1x1 pixel, an oversized image, SVG, non-image bytes, or a truncated or out-of-spec .ico (entries too big for the format) give "no icon".
- Fetching uses the existing unsafe-address guard, no credentials, few redirects, web ports only, reading only the home page and icons.
  Answers and misses are cached per origin (trailing slash or not) within a configurable size, evicting least recently used.
  Simultaneous asks share one lookup; a full queue answers "busy" at once, without fetching or caching.
- A URL-only link reads host then path, no scheme: the host whole in punycode, the path decoded, without invisible characters, trimmed when long.
  Author text stays as written.
  The icon is hidden from screen readers, a placeholder covers loading and unusable icons (none, broken, 1x1), and right-to-left text cannot reorder the line.
- Nothing is looked up while a reply streams; once it settles, the link's origin is.
  Non-website links (email, phone, relative, image-wrapping, unsafe) keep their look, with no icon or lookup.
  Answers last the session, separate per API server; a failed lookup is retried only after several minutes, a busy one a few times while shown.
- Website links get the icon in all four places chat shows them: assistant replies and typed messages, in both the web and mobile renderers.
  Each passes the link's origin to the app's icon lookup, draws only the image that lookup returns, and sends no request of its own, even when the site has no icon.
- Other chat markdown around web links renders as before, both while streaming and once settled: an email link stays a plain link with no icon, an inline image still shows as an image, and a table still shows as a table.
