## Task

Chat links should get a small site icon (a favicon) in front of the link text, the way a browser tab shows one.
This is for web links in assistant replies and in the messages people type, and it has to work in the web app, the desktop app and the mobile app.

Privacy is the hard rule.
Someone watching a device's traffic must not be able to tell which sites a conversation links to.
So the app may never request the linked site, and it may not use any outside favicon or icon service either.
Icons come only from the Rakazo API: a new signed-in API call takes a site origin, does the fetching on the server, and returns an image the app can show as is.

On the server, the code that finds and prepares icons should come from a factory that accepts the same fetch and host-lookup hooks the existing safe web fetch takes, plus a clock and its limits (how much it caches, how long requests may wait in the queue).
That way it can run without a real network.
On the client, the shared chat-markdown renderer should get icons from a lookup function the app hands it through React context.
The renderer calls that function with the link's origin and gets back an icon or nothing, plus a flag meaning "busy, ask again later".
The context value may also carry the current API base.

Only http and https links are in scope.

A few details the server side has to get right.
It only ever requests a site's home page, the icon that page declares, and /favicon.ico.
An .ico counts as broken when an entry points past the end of the file, the file is cut short, or an entry is bigger than the 256-pixel limit the format allows.
The icon cache has a size limit, and two asks for one origin written with and without a trailing slash count as the same origin.
A "busy" answer is not a "no icon" answer: that ask fetches nothing and is not remembered.

On the client, answers are kept for the session and kept apart per API base.
While an icon loads, when a site has none, or when the image fails or turns out to be 1x1, a neutral generic website placeholder shows instead.
A lookup that fails is not tried again until several minutes have passed, and a "busy" answer is retried a few times while the link is still on screen.

## User stories / requirements

- A signed-in user can ask the API about a site origin and gets either an icon ready to display or a plain "no icon" answer.
  A request without a session is turned away before any icon work starts, and the server-side lookup only ever receives the origin that was asked for.
- The server works out an image's format from its bytes, not the declared type.
  PNG, JPEG, GIF, WebP and ICO icons become one small square image, and an .ico gives its largest image.
  A 1x1 pixel, an oversized image, an SVG, non-image bytes or a broken .ico give "no icon" without an error.
- Server fetching goes through the existing guard against unsafe or internal addresses, sends no credentials, follows a limited number of redirects and uses only normal web ports.
  Answers are cached per origin, misses included, dropping the least recently used; simultaneous asks share one lookup, and a full queue answers "busy, try again" at once.
- A link whose text is just its URL is labeled host then path, without the scheme.
  The host stays whole, in punycode, while the path is decoded, cleared of invisible characters and trimmed when long.
  Author text stays as written.
  The icon is hidden from screen readers, and right-to-left text cannot reorder the surrounding line.
- No lookup happens while a reply is still streaming; it happens once the reply settles, with the link's origin.
  Links that are not website links (email, phone, in-app or relative, wrapping an image, or unsafe) keep their current look, get no icon and trigger no lookup.
- Website links get the icon in all four places chat shows them: assistant replies and typed messages, in both the web and mobile renderers.
  Each passes the link's origin to the app's icon lookup, draws only the image that lookup returns, and sends no request of its own, even when the site has no icon.
- Other chat markdown around web links renders as before, both while streaming and once settled: an email link stays a plain link with no icon, an inline image still shows as an image, and a table still shows as a table.
