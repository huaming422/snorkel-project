#!/usr/bin/env bash
# validation-setup.sh - environment bootstrap for the story test scripts.
# Idempotent. Sourced/exec'd before the jest(vitest) driver runs each story.
#
# Dependencies are baked into the image: the Dockerfile already ran
# `pnpm install --frozen-lockfile` with the pnpm store warm. Workspace packages
# export their TypeScript src directly (there is no dist build step) and vitest
# loads them through vite at the repo root, so nothing needs compiling here.
# The steps below are guards that only do work if node_modules or the sharp
# binding went missing; they are offline-first with a logged online fallback.

set -e

REPO_DIR="${REPO_DIR:-/repo/rakazo}"
cd "$REPO_DIR"

# Sanity: the toolchain is reachable.
node --version
pnpm --version
npx vitest --version

# The stories never touch a real network, DB, or service. Export the offline
# switches up front so a stray developer .env cannot pull a story onto the
# network (pin-test-env.ts also enforces this inside the suite).
export VERIFY_PROVIDERS=""
export LOG_LEVEL="off"
unset DATABASE_URL REALTIME_DATABASE_URL || true

# 1. Workspace deps. Offline-first against the warm store; fall back to an
#    online frozen install only if the offline path fails, and log loudly.
if [ ! -d "node_modules/.pnpm" ]; then
    echo "[validation-setup] node_modules missing - installing from warm store (offline, frozen)..."
    if ! pnpm install --frozen-lockfile --offline > /tmp/validation-setup-install.log 2>&1; then
        echo "[validation-setup] offline install failed; retrying with network (logged fallback)..." >&2
        tail -20 /tmp/validation-setup-install.log >&2 || true
        pnpm install --frozen-lockfile > /tmp/validation-setup-install-online.log 2>&1 \
            || { tail -40 /tmp/validation-setup-install-online.log >&2; return 1 2>/dev/null || exit 1; }
    fi
fi

# 2. sharp native binding. The shared test harness builds image fixtures with
#    sharp, so its platform binary must exist. Rebuild only if a reinstall
#    erased it. Offline-first (the store already holds the prebuilt binary),
#    online fallback logged.
if ! node -e "require('sharp')" > /tmp/validation-setup-sharp.log 2>&1; then
    echo "[validation-setup] sharp binding missing - rebuilding..." >&2
    tail -10 /tmp/validation-setup-sharp.log >&2 || true
    if ! pnpm --filter @rakazo/adapters rebuild sharp > /tmp/validation-setup-sharp-rebuild.log 2>&1; then
        tail -20 /tmp/validation-setup-sharp-rebuild.log >&2 || true
    fi
fi

# 3. No per-package build is needed. A loud smoke guard that the workspace
#    graph resolves: if this import fails, deps are broken and every story
#    would fail opaquely.
if ! node -e "require.resolve('vitest')" > /tmp/validation-setup-smoke.log 2>&1; then
    echo "[validation-setup] FATAL: vitest not resolvable - workspace deps broken" >&2
    tail -20 /tmp/validation-setup-smoke.log >&2 || true
    return 1 2>/dev/null || exit 1
fi

# Make node_modules/.bin available (vitest, tsc).
export PATH="$REPO_DIR/node_modules/.bin:$PATH"

echo "[validation-setup] ready: $REPO_DIR (node=$(node --version), pnpm=$(pnpm --version))"
