// @vitest-environment node
// @ts-nocheck
//
// Design-token stylesheet sync guard.
//
// The project renders its CSS stylesheet from the TypeScript color palette, so
// the two must match byte for byte. Any drift means the stylesheet was edited by
// hand or left stale after a palette change. This guard checks that invariant
// for whatever palette the repository holds. It never requires, counts or names
// a particular token: adding a token, reusing an existing one or adding none all
// meet it, as long as the stylesheet on disk is exactly what the palette renders.
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";
import { darkTokens, lightTokens, renderTokensCss } from "./index.js";

describe("design-token stylesheet", () => {
  it("keeps the generated stylesheet in sync with the palette", () => {
    const onDisk = readFileSync(fileURLToPath(new URL("./tokens.css", import.meta.url)), "utf8");
    expect(onDisk).toBe(renderTokensCss());
  });

  it("defines the same color entries in both themes", () => {
    // The two themes carry identical token sets; only their values differ.
    expect(new Set(Object.keys(darkTokens))).toEqual(new Set(Object.keys(lightTokens)));
  });
});
