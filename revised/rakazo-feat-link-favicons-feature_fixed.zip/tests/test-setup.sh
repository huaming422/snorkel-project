#!/usr/bin/env bash
# test-setup.sh - environment bootstrap for the test runner.
# Sourced (not exec'd) by the runner so env vars stay alive for vitest.
#
# This script is idempotent. Dependencies are baked into the image: the
# Dockerfile already ran `pnpm install --frozen-lockfile` with the pnpm store
# warm under /opt/cache/pnpm-dev. The steps below are guards that only do work
# if node_modules or the sharp binding went missing; they are offline-first
# with a logged online fallback.

set -e

REPO_DIR="${REPO_DIR:-/repo/rakazo}"
cd "$REPO_DIR"

node --version
pnpm --version

# The rakazo unit suite needs no network, DB, or services:
# pin-test-env.ts (vitest setupFiles) deletes DATABASE_URL and forces fake
# providers. Export the offline switches up front so a stray developer .env
# cannot pull the suite onto the network.
export VERIFY_PROVIDERS=""
export LOG_LEVEL="off"
unset DATABASE_URL REALTIME_DATABASE_URL || true

# 1. Workspace deps. Offline-first against the warm store; fall back to an
#    online frozen install only if the offline path fails, and log loudly.
if [ ! -d "node_modules/.pnpm" ]; then
    echo "[test-setup] node_modules missing - installing from warm store (offline, frozen)..."
    if ! pnpm install --frozen-lockfile --offline > /tmp/test-setup-install.log 2>&1; then
        echo "[test-setup] offline install failed; retrying with network (logged fallback)..." >&2
        tail -20 /tmp/test-setup-install.log >&2 || true
        pnpm install --frozen-lockfile > /tmp/test-setup-install-online.log 2>&1 \
            || { tail -40 /tmp/test-setup-install-online.log >&2; return 1 2>/dev/null || exit 1; }
    fi
fi

# 2. sharp native binding (an existing dependency of the adapters package).
#    Rebuild only if a reinstall erased its platform binary. Offline-first
#    (the store already holds the prebuilt binary), online fallback logged.
if ! node -e "require('sharp')" > /tmp/test-setup-sharp.log 2>&1; then
    echo "[test-setup] sharp binding missing - rebuilding..." >&2
    tail -10 /tmp/test-setup-sharp.log >&2 || true
    if ! pnpm --filter @rakazo/adapters rebuild sharp > /tmp/test-setup-sharp-rebuild.log 2>&1; then
        tail -20 /tmp/test-setup-sharp-rebuild.log >&2 || true
    fi
fi

# 3. Workspace packages export their TypeScript src directly (no dist build
#    step), and vitest loads them through vite at the repo root, so nothing
#    needs compiling here.

# Make node_modules/.bin available (vitest, tsc).
export PATH="$REPO_DIR/node_modules/.bin:$PATH"

echo "[test-setup] ready: $REPO_DIR (node=$(node --version), pnpm=$(pnpm --version))"
