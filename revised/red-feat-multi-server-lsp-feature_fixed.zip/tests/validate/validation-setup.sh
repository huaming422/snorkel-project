#!/usr/bin/env bash
# Validation setup for red-feat-multi-server-lsp.
#
# Sourced (not exec'd) by the validation runner so exported env persists for
# the story's cargo run. This story is pure, in-process config/resolution
# testing: no external servers, databases, fixtures, or network. The only
# job is to pin the toolchain env and warm the crate's build cache so the
# cargo-test run links against the user changes quickly.
set -u

REPO_DIR="${REPO_DIR:-/repo/red}"

# Toolchain env: mirror the image's pinned Rust install (block 3 of the
# Dockerfile). The image baked `cargo build --locked --tests` into
# CARGO_TARGET_DIR, so the rebuild below is incremental.
export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
export PATH="${CARGO_HOME}/bin:${PATH}"

echo "validation-setup: rustc=$(rustc --version 2>&1 | head -1)"
echo "validation-setup: cargo=$(cargo --version 2>&1 | head -1)"

# Warm the build with the user changes applied (incremental). A loud failure
# here surfaces a broken tree before every story fails with the same opaque
# compile error.
cd "$REPO_DIR" || { echo "ERROR: ${REPO_DIR} missing" >&2; return 1 2>/dev/null || exit 1; }
echo "validation-setup: warming crate build (incremental)..."
if cargo build --locked --lib > /tmp/red_validation_build.log 2>&1; then
    echo "validation-setup: crate builds"
else
    echo "validation-setup: WARNING: crate build failed (a broken submission may still be scored by the story):"
    tail -40 /tmp/red_validation_build.log 2>/dev/null || true
fi
mkdir -p /logs/verifier 2>/dev/null || true
cp /tmp/red_validation_build.log /logs/verifier/red_validation_build.log 2>/dev/null || true

echo "validation-setup: done."
return 0 2>/dev/null || true
