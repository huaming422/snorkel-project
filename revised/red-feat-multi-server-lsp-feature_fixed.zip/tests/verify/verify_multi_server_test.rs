// Behavioral checks for documents that more than one language server claims.
//
// Each test builds a real editor on top of the production language-server
// manager and points it at small scripted stdin/stdout servers. The servers are
// stdlib Python programs written to a temp dir and launched through the
// manager's normal launch path, so no real toolchain is needed. Every server
// appends each method it receives to a shared log file, prefixed with its own
// name.
//
// What is checked:
//
//   1. Lifecycle reaches every matching server: open, edit and close of a
//      document two servers claim show up in both servers' logs.
//   2. Pulled diagnostics from two servers are both shown for the file.
//   3. Hover on a two-server document shows one server's text, and the same
//      server's text on every repeat.
//   4. When one of two servers exits, the other server's diagnostics are still
//      shown, read from the editor's displayed set without a new pull.
//   5. Pushed diagnostics from two servers are both shown, and when one server
//      later publishes an empty set, only that server's entries go away.
//   6. Formatting a two-server document applies one server's edit, and the same
//      server's edit on every repeat.
//   7. Completion on a two-server document lists one server's items, and the
//      same server's items on every repeat.
//   8. With an external formatter configured for the language, formatting a
//      two-server document uses the external formatter and sends no
//      formatting request to either server.
//   9. A document only one configured server claims is opened with that server
//      alone, and its diagnostics are shown.
//
// All assertions read what a user of the editor sees or what each server was
// sent: log lines, displayed diagnostic messages, rendered rows and buffer
// text. Which server wins a single-answer feature is not asserted.

use std::collections::{BTreeSet, HashMap};
use std::path::Path;
use std::time::Duration;

use red::{
    agent_tools::{EditorToolCall, EditorToolRequest, LspDiagnosticScope},
    buffer::Buffer,
    config::{
        Config, FormattingProvider, LanguageConfig, LanguageFormatterConfig,
        LanguageServerConfig, LspConfig,
    },
    editor::{Action, Editor, Mode},
    lsp::LspManager,
    test_utils::EditorTestExt,
    theme::Theme,
};

// A minimal LSP server over stdio. It records every inbound method to the log
// file named by $DIAG_EVENTS (prefixed with its own $DIAG_NAME), advertises
// pull-diagnostic support, and answers a diagnostic request with a single
// problem whose message embeds its own name.
const SERVER_PY: &str = r#"import json, os, sys, pathlib
events = pathlib.Path(os.environ["DIAG_EVENTS"]); name = os.environ.get("DIAG_NAME", "srv")
def read():
    headers = {}
    while True:
        line = sys.stdin.buffer.readline()
        if not line:
            return None
        if line in (b"\r\n", b"\n"):
            break
        k, v = line.decode().split(":", 1)
        headers[k.lower()] = v.strip()
    return json.loads(sys.stdin.buffer.read(int(headers["content-length"])))
def send(m):
    b = json.dumps(m).encode()
    sys.stdout.buffer.write(b"Content-Length: %d\r\n\r\n" % len(b) + b)
    sys.stdout.buffer.flush()
def problem():
    return {"range": {"start": {"line": 0, "character": 0}, "end": {"line": 0, "character": 1}},
            "severity": 1, "source": name, "message": name + "-problem"}
while True:
    m = read()
    if m is None:
        break
    method = m.get("method")
    with events.open("a") as o:
        o.write(name + " " + str(method) + "\n")
    if method == "initialize":
        send({"jsonrpc": "2.0", "id": m["id"], "result": {"capabilities": {
            "textDocumentSync": 1,
            "diagnosticProvider": {"interFileDependencies": False, "workspaceDiagnostics": False}}}})
    elif method == "textDocument/diagnostic":
        send({"jsonrpc": "2.0", "id": m["id"], "result": {"kind": "full", "items": [problem()]}})
    elif method == "shutdown":
        send({"jsonrpc": "2.0", "id": m["id"], "result": None})
    elif method == "exit":
        break
    elif "id" in m:
        send({"jsonrpc": "2.0", "id": m["id"], "result": None})
"#;

// A server that advertises hover support in addition to pull diagnostics.
// Returns a hover response whose contents embed the server's own name. With
// "slow-odd" or "slow-even" in $SRV_FEATURES it waits before answering every
// other hover request, so two such servers take turns being the slower one.
const HOVER_SERVER_PY: &str = r#"import json, os, sys, pathlib, time
events = pathlib.Path(os.environ["DIAG_EVENTS"]); name = os.environ.get("DIAG_NAME", "srv")
features = set(f for f in os.environ.get("SRV_FEATURES", "").split(",") if f)
asked = 0
def maybe_wait():
    global asked
    asked += 1
    if ("slow-odd" in features and asked % 2 == 1) or ("slow-even" in features and asked % 2 == 0):
        time.sleep(0.15)
def read():
    headers = {}
    while True:
        line = sys.stdin.buffer.readline()
        if not line:
            return None
        if line in (b"\r\n", b"\n"):
            break
        k, v = line.decode().split(":", 1)
        headers[k.lower()] = v.strip()
    return json.loads(sys.stdin.buffer.read(int(headers["content-length"])))
def send(m):
    b = json.dumps(m).encode()
    sys.stdout.buffer.write(b"Content-Length: %d\r\n\r\n" % len(b) + b)
    sys.stdout.buffer.flush()
def problem():
    return {"range": {"start": {"line": 0, "character": 0}, "end": {"line": 0, "character": 1}},
            "severity": 1, "source": name, "message": name + "-problem"}
while True:
    m = read()
    if m is None:
        break
    method = m.get("method")
    with events.open("a") as o:
        o.write(name + " " + str(method) + "\n")
    if method == "initialize":
        send({"jsonrpc": "2.0", "id": m["id"], "result": {"capabilities": {
            "textDocumentSync": 1,
            "hoverProvider": True,
            "diagnosticProvider": {"interFileDependencies": False, "workspaceDiagnostics": False}}}})
        with events.open("a") as o:
            o.write(name + " initialized\n")
    elif method == "textDocument/hover":
        maybe_wait()
        send({"jsonrpc": "2.0", "id": m["id"], "result": {
            "contents": {"kind": "plaintext", "value": name + "-hover-text"}}})
    elif method == "textDocument/diagnostic":
        send({"jsonrpc": "2.0", "id": m["id"], "result": {"kind": "full", "items": [problem()]}})
    elif method == "shutdown":
        send({"jsonrpc": "2.0", "id": m["id"], "result": None})
    elif method == "exit":
        break
    elif "id" in m:
        send({"jsonrpc": "2.0", "id": m["id"], "result": None})
"#;

// A pull-diagnostic server that exits shortly after answering its first
// diagnostic request. It writes "<name> exited" to the log right before it
// quits, so the test knows the process is gone.
const EXITING_SERVER_PY: &str = r#"import json, os, sys, pathlib, time
events = pathlib.Path(os.environ["DIAG_EVENTS"]); name = os.environ.get("DIAG_NAME", "srv")
def read():
    headers = {}
    while True:
        line = sys.stdin.buffer.readline()
        if not line:
            return None
        if line in (b"\r\n", b"\n"):
            break
        k, v = line.decode().split(":", 1)
        headers[k.lower()] = v.strip()
    return json.loads(sys.stdin.buffer.read(int(headers["content-length"])))
def send(m):
    b = json.dumps(m).encode()
    sys.stdout.buffer.write(b"Content-Length: %d\r\n\r\n" % len(b) + b)
    sys.stdout.buffer.flush()
def problem():
    return {"range": {"start": {"line": 0, "character": 0}, "end": {"line": 0, "character": 1}},
            "severity": 1, "source": name, "message": name + "-problem"}
while True:
    m = read()
    if m is None:
        break
    method = m.get("method")
    with events.open("a") as o:
        o.write(name + " " + str(method) + "\n")
    if method == "initialize":
        send({"jsonrpc": "2.0", "id": m["id"], "result": {"capabilities": {
            "textDocumentSync": 1,
            "diagnosticProvider": {"interFileDependencies": False, "workspaceDiagnostics": False}}}})
    elif method == "textDocument/diagnostic":
        send({"jsonrpc": "2.0", "id": m["id"], "result": {"kind": "full", "items": [problem()]}})
        # Leave the reply in the pipe for a moment, then quit hard.
        time.sleep(1.0)
        with events.open("a") as o:
            o.write(name + " exited\n")
        os._exit(0)
    elif method == "shutdown":
        send({"jsonrpc": "2.0", "id": m["id"], "result": None})
    elif method == "exit":
        break
    elif "id" in m:
        send({"jsonrpc": "2.0", "id": m["id"], "result": None})
"#;

// A server whose features come from $SRV_FEATURES (comma separated):
//   push        publish "<name>-pushed" for the document on open and on change
//   push-clear  on change, publish an empty diagnostic set instead
//   completion  answer completion with one item labeled "<name>_item"
//   formatting  answer formatting with one edit inserting "<name>_" at 0:0
//   slow-odd / slow-even  wait before answering every other completion or
//               formatting request, so two such servers take turns being slower
const FEATURE_SERVER_PY: &str = r#"import json, os, sys, pathlib, time
events = pathlib.Path(os.environ["DIAG_EVENTS"]); name = os.environ.get("DIAG_NAME", "srv")
features = set(f for f in os.environ.get("SRV_FEATURES", "").split(",") if f)
asked = 0
def maybe_wait():
    global asked
    asked += 1
    if ("slow-odd" in features and asked % 2 == 1) or ("slow-even" in features and asked % 2 == 0):
        time.sleep(0.15)
def read():
    headers = {}
    while True:
        line = sys.stdin.buffer.readline()
        if not line:
            return None
        if line in (b"\r\n", b"\n"):
            break
        k, v = line.decode().split(":", 1)
        headers[k.lower()] = v.strip()
    return json.loads(sys.stdin.buffer.read(int(headers["content-length"])))
def send(m):
    b = json.dumps(m).encode()
    sys.stdout.buffer.write(b"Content-Length: %d\r\n\r\n" % len(b) + b)
    sys.stdout.buffer.flush()
def pushed():
    return [{"range": {"start": {"line": 0, "character": 0}, "end": {"line": 0, "character": 1}},
             "severity": 1, "source": name, "message": name + "-pushed"}]
def publish(uri, items):
    send({"jsonrpc": "2.0", "method": "textDocument/publishDiagnostics",
          "params": {"uri": uri, "diagnostics": items}})
while True:
    m = read()
    if m is None:
        break
    method = m.get("method")
    with events.open("a") as o:
        o.write(name + " " + str(method) + "\n")
    if method == "initialize":
        caps = {"textDocumentSync": 1}
        if "completion" in features:
            caps["completionProvider"] = {}
        if "formatting" in features:
            caps["documentFormattingProvider"] = True
        send({"jsonrpc": "2.0", "id": m["id"], "result": {"capabilities": caps}})
    elif method == "textDocument/didOpen" and "push" in features:
        publish(m["params"]["textDocument"]["uri"], pushed())
    elif method == "textDocument/didChange" and "push" in features:
        uri = m["params"]["textDocument"]["uri"]
        publish(uri, [] if "push-clear" in features else pushed())
    elif method == "textDocument/completion":
        maybe_wait()
        send({"jsonrpc": "2.0", "id": m["id"], "result": {
            "isIncomplete": False, "items": [{"label": name + "_item"}]}})
    elif method == "textDocument/formatting":
        maybe_wait()
        send({"jsonrpc": "2.0", "id": m["id"], "result": [{
            "range": {"start": {"line": 0, "character": 0}, "end": {"line": 0, "character": 0}},
            "newText": name + "_"}]})
    elif method == "shutdown":
        send({"jsonrpc": "2.0", "id": m["id"], "result": None})
    elif method == "exit":
        break
    elif "id" in m:
        send({"jsonrpc": "2.0", "id": m["id"], "result": None})
"#;

fn server(script: &str, name: &str, events: &str, exts: &[&str]) -> LanguageServerConfig {
    server_with_features(script, name, events, exts, "")
}

fn server_with_features(
    script: &str,
    name: &str,
    events: &str,
    exts: &[&str],
    features: &str,
) -> LanguageServerConfig {
    let mut env = HashMap::new();
    env.insert("DIAG_EVENTS".to_string(), events.to_string());
    env.insert("DIAG_NAME".to_string(), name.to_string());
    env.insert("SRV_FEATURES".to_string(), features.to_string());
    LanguageServerConfig {
        command: "python3".to_string(),
        args: vec![script.to_string()],
        language_id: "testlang".to_string(),
        file_extensions: exts.iter().map(|e| e.to_string()).collect(),
        filenames: Vec::new(),
        documents: Vec::new(),
        root_markers: Vec::new(),
        env,
        initialization_options: None,
        settings: None,
        workspace_name: None,
    }
}

fn diagnostics_call(path: &str, refresh: bool) -> EditorToolRequest {
    EditorToolRequest {
        session_id: "agent-lsp".into(),
        call: EditorToolCall::LspDiagnostics {
            scope: LspDiagnosticScope::File,
            path: Some(path.to_string()),
            severity: None,
            source: None,
            code: None,
            range: None,
            offset: 0,
            limit: 100,
            expected_generation: None,
            refresh,
            wait_ms: if refresh { 1500 } else { 0 },
        },
    }
}

// Pulls fresh diagnostics for `path` and returns the displayed set.
fn diagnostics_request(path: &str) -> EditorToolRequest {
    diagnostics_call(path, true)
}

// Reads the editor's current displayed set for `path` without asking any
// server for new diagnostics.
fn displayed_diagnostics_request(path: &str) -> EditorToolRequest {
    diagnostics_call(path, false)
}

fn messages(result: &serde_json::Value) -> Vec<String> {
    result["items"]
        .as_array()
        .map(|items| {
            items
                .iter()
                .filter_map(|item| item["message"].as_str().map(str::to_string))
                .collect()
        })
        .unwrap_or_default()
}

fn log_has(events: &Path, name: &str, needle: &str) -> bool {
    std::fs::read_to_string(events)
        .unwrap_or_default()
        .lines()
        .any(|l| l.starts_with(&format!("{name} ")) && l.contains(needle))
}

fn log_text(events: &Path) -> String {
    std::fs::read_to_string(events).unwrap_or_default()
}

// Pumps the editor until every named server has logged `needle`.
async fn wait_for_all(editor: &mut Editor, events: &Path, names: &[&str], needle: &str) -> bool {
    for _ in 0..150 {
        let _ = editor.test_service_background().await;
        tokio::time::sleep(Duration::from_millis(20)).await;
        if names.iter().all(|name| log_has(events, name, needle)) {
            return true;
        }
    }
    false
}

// Gives the editor a little more time to settle after a wait.
async fn pump(editor: &mut Editor, rounds: usize) {
    for _ in 0..rounds {
        let _ = editor.test_service_background().await;
        tokio::time::sleep(Duration::from_millis(20)).await;
    }
}

fn editor_for(dir: &Path, config: Config, file_name: &str) -> Editor {
    let file = dir.join(file_name);
    std::fs::write(&file, "x\n").unwrap();
    let lsp = Box::new(LspManager::new(config.lsp.clone()));
    let mut editor = Editor::test_with_size(
        lsp,
        80,
        24,
        config,
        Theme::default(),
        vec![Buffer::new(
            Some(file.to_string_lossy().into_owned()),
            "x\n".to_string(),
        )],
    )
    .unwrap();
    editor.test_disable_terminal_output();
    editor.test_set_agent_root(dir);
    editor
}

fn lsp_config(servers: Vec<(&str, LanguageServerConfig)>) -> Config {
    let mut config = Config::default();
    config.show_diagnostics = true;
    config.lsp = LspConfig {
        enabled: true,
        format_on_save: false,
        servers: servers
            .into_iter()
            .map(|(name, server)| (name.to_string(), server))
            .collect(),
    };
    config
}

async fn build_two_server_editor(dir: &Path, events: &str, script: &str) -> Editor {
    let config = lsp_config(vec![
        ("alpha", server(script, "alpha", events, &["ts"])),
        ("beta", server(script, "beta", events, &["ts"])),
    ]);
    editor_for(dir, config, "sample.ts")
}

fn rendered_rows(editor: &mut Editor) -> Vec<String> {
    (0..24)
        .filter_map(|y| editor.test_render_row(y).ok())
        .collect()
}

#[tokio::test]
async fn open_document_fans_lifecycle_out_to_every_matching_server() {
    let dir = tempfile::tempdir().unwrap();
    let events = dir.path().join("events.log");
    std::fs::write(&events, "").unwrap();
    let ev = events.display().to_string();
    let script = dir.path().join("server.py");
    std::fs::write(&script, SERVER_PY).unwrap();

    let mut editor =
        build_two_server_editor(dir.path(), &ev, &script.to_string_lossy()).await;
    editor
        .test_ensure_current_buffer_lsp_opened()
        .await
        .unwrap();

    let both_opened = wait_for_all(&mut editor, &events, &["alpha", "beta"], "didOpen").await;
    assert!(
        both_opened,
        "both matching servers must receive the document open notification.\n\
         recorded events:\n{}",
        log_text(&events)
    );

    // An edit reaches both servers.
    editor.test_type_text("y").await.unwrap();
    let both_changed =
        wait_for_all(&mut editor, &events, &["alpha", "beta"], "didChange").await;
    assert!(
        both_changed,
        "both matching servers must receive the document change notification.\n\
         recorded events:\n{}",
        log_text(&events)
    );

    // Closing the document reaches both servers.
    editor
        .test_execute_action(Action::EnterMode(Mode::Normal))
        .await
        .unwrap();
    editor
        .test_execute_action(Action::DeleteBuffer(true))
        .await
        .unwrap();
    let both_closed = wait_for_all(&mut editor, &events, &["alpha", "beta"], "didClose").await;
    assert!(
        both_closed,
        "both matching servers must receive the document close notification.\n\
         recorded events:\n{}",
        log_text(&events)
    );
}

#[tokio::test]
async fn each_servers_diagnostics_stay_independent_in_the_displayed_set() {
    let dir = tempfile::tempdir().unwrap();
    let events = dir.path().join("events.log");
    std::fs::write(&events, "").unwrap();
    let ev = events.display().to_string();
    let script = dir.path().join("server.py");
    std::fs::write(&script, SERVER_PY).unwrap();

    let mut editor =
        build_two_server_editor(dir.path(), &ev, &script.to_string_lossy()).await;
    editor
        .test_ensure_current_buffer_lsp_opened()
        .await
        .unwrap();

    // Wait until both servers have the document open.
    wait_for_all(&mut editor, &events, &["alpha", "beta"], "didOpen").await;

    // Ask for diagnostics, then read the displayed set. Both servers'
    // problems must be listed.
    let mut displayed: Vec<String> = Vec::new();
    for _ in 0..25 {
        let _ = editor.test_execute_action(Action::RefreshDiagnostics).await;
        let result = editor
            .test_run_agent_editor_tool(diagnostics_request("sample.ts"))
            .await
            .unwrap();
        displayed = messages(&result);
        if displayed.iter().any(|m| m.contains("alpha-problem"))
            && displayed.iter().any(|m| m.contains("beta-problem"))
        {
            break;
        }
        tokio::time::sleep(Duration::from_millis(30)).await;
    }

    assert!(
        displayed.iter().any(|m| m.contains("alpha-problem")),
        "the first server's diagnostic is missing from the displayed set. \
         displayed: {displayed:?}"
    );
    assert!(
        displayed.iter().any(|m| m.contains("beta-problem")),
        "the second server's diagnostic is missing from the displayed set. \
         displayed: {displayed:?}"
    );
}

#[tokio::test]
async fn single_answer_feature_returns_one_deterministic_result() {
    // Two servers both advertise hover, each returning text that embeds its own
    // name, and they take turns being the slower one to answer. Triggering
    // hover 20 times must always show the same single server's text, never
    // both and never alternating.
    let dir = tempfile::tempdir().unwrap();
    let events = dir.path().join("events.log");
    std::fs::write(&events, "").unwrap();
    let ev = events.display().to_string();
    let script = dir.path().join("hover_server.py");
    std::fs::write(&script, HOVER_SERVER_PY).unwrap();

    let script = script.to_string_lossy().into_owned();
    let config = lsp_config(vec![
        ("alpha", server_with_features(&script, "alpha", &ev, &["ts"], "slow-odd")),
        ("beta", server_with_features(&script, "beta", &ev, &["ts"], "slow-even")),
    ]);
    let mut editor = editor_for(dir.path(), config, "sample.ts");
    editor.test_ensure_current_buffer_lsp_opened().await.unwrap();

    // Wait for both servers to finish starting and open the document.
    wait_for_all(&mut editor, &events, &["alpha", "beta"], "didOpen").await;
    pump(&mut editor, 10).await;

    let mut observed: Vec<String> = Vec::new();
    for _ in 0..20 {
        // Dismiss any existing dialog before triggering a fresh hover.
        let _ = editor.test_execute_action(Action::CloseDialog).await;
        let _ = editor.test_execute_action(Action::Hover).await;
        let mut got_hover = false;
        for _ in 0..60 {
            let _ = editor.test_service_background().await;
            tokio::time::sleep(Duration::from_millis(20)).await;
            let mut row_text = String::new();
            for row in rendered_rows(&mut editor) {
                if row.contains("hover-text") {
                    row_text = row.trim().to_string();
                    got_hover = true;
                    break;
                }
            }
            if got_hover {
                observed.push(row_text);
                break;
            }
        }
        if !got_hover {
            observed.push(String::new());
        }
    }

    let non_empty: Vec<&String> = observed.iter().filter(|s| !s.is_empty()).collect();
    assert!(
        non_empty.len() >= 15,
        "hover produced a response on only {}/{} tries",
        non_empty.len(),
        observed.len()
    );

    for (i, result) in non_empty.iter().enumerate() {
        let has_alpha = result.contains("alpha-hover-text");
        let has_beta = result.contains("beta-hover-text");
        assert!(
            has_alpha || has_beta,
            "hover result #{i} does not contain either server's text: {result:?}"
        );
        assert!(
            !(has_alpha && has_beta),
            "hover result #{i} contains both servers' text instead of one: {result:?}"
        );
    }

    let first = non_empty[0];
    for (i, result) in non_empty.iter().enumerate().skip(1) {
        assert_eq!(
            *result, first,
            "hover result #{i} differs from the first result. \
             first={first:?}, got={result:?}"
        );
    }
}

#[tokio::test]
async fn surviving_server_diagnostics_persist_after_peer_failure() {
    // alpha stays alive; beta answers one diagnostic pull and then exits.
    // After beta is gone, alpha's diagnostic must still be in the displayed
    // set. The final reads do not pull again, so they show what the editor
    // kept, not a fresh answer from alpha.
    let dir = tempfile::tempdir().unwrap();
    let events = dir.path().join("events.log");
    std::fs::write(&events, "").unwrap();
    let ev = events.display().to_string();

    let alpha_script = dir.path().join("alpha_server.py");
    std::fs::write(&alpha_script, SERVER_PY).unwrap();
    let beta_script = dir.path().join("beta_server.py");
    std::fs::write(&beta_script, EXITING_SERVER_PY).unwrap();

    let config = lsp_config(vec![
        ("alpha", server(&alpha_script.to_string_lossy(), "alpha", &ev, &["ts"])),
        ("beta", server(&beta_script.to_string_lossy(), "beta", &ev, &["ts"])),
    ]);
    let mut editor = editor_for(dir.path(), config, "sample.ts");
    editor.test_ensure_current_buffer_lsp_opened().await.unwrap();

    wait_for_all(&mut editor, &events, &["alpha", "beta"], "didOpen").await;

    // Step 1: pull until both servers' diagnostics are shown.
    let mut both_shown = false;
    let mut diags: Vec<String> = Vec::new();
    for _ in 0..40 {
        let _ = editor.test_execute_action(Action::RefreshDiagnostics).await;
        let result = editor
            .test_run_agent_editor_tool(diagnostics_request("sample.ts"))
            .await
            .unwrap();
        diags = messages(&result);
        if diags.iter().any(|m| m.contains("alpha-problem"))
            && diags.iter().any(|m| m.contains("beta-problem"))
        {
            both_shown = true;
            break;
        }
        tokio::time::sleep(Duration::from_millis(50)).await;
    }
    assert!(
        both_shown,
        "both servers' diagnostics must be shown before one of them exits. \
         displayed: {diags:?}"
    );

    // Step 2: wait for beta's process to exit, then let the editor notice.
    let exited = wait_for_all(&mut editor, &events, &["beta"], "exited").await;
    assert!(
        exited,
        "beta server did not exit.\nrecorded events:\n{}",
        log_text(&events)
    );
    for _ in 0..40 {
        let _ = editor.test_service_background().await;
        tokio::time::sleep(Duration::from_millis(50)).await;
    }

    // Step 3: alpha's diagnostic must still be displayed on every read.
    for i in 0..10 {
        let _ = editor.test_service_background().await;
        let result = editor
            .test_run_agent_editor_tool(displayed_diagnostics_request("sample.ts"))
            .await
            .unwrap();
        let shown = messages(&result);
        assert!(
            shown.iter().any(|m| m.contains("alpha-problem")),
            "alpha's diagnostic is no longer displayed after beta exited \
             (read #{i}). displayed: {shown:?}"
        );
        tokio::time::sleep(Duration::from_millis(30)).await;
    }
}

#[tokio::test]
async fn pushed_diagnostics_from_each_server_stay_independent() {
    // Both servers push their own diagnostic when the document opens. On the
    // next edit, "types" pushes its diagnostic again and "lint" pushes an
    // empty set. Only lint's entry may disappear.
    let dir = tempfile::tempdir().unwrap();
    let events = dir.path().join("events.log");
    std::fs::write(&events, "").unwrap();
    let ev = events.display().to_string();
    let script = dir.path().join("feature_server.py");
    std::fs::write(&script, FEATURE_SERVER_PY).unwrap();
    let script = script.to_string_lossy().into_owned();

    // A root marker in the temp dir makes it each server's workspace, so the
    // pushed reports are for a file inside the server's own workspace.
    std::fs::write(dir.path().join("workspace.root"), "").unwrap();
    let mut types = server_with_features(&script, "types", &ev, &["ts"], "push");
    types.root_markers = vec!["workspace.root".to_string()];
    let mut lint = server_with_features(&script, "lint", &ev, &["ts"], "push,push-clear");
    lint.root_markers = vec!["workspace.root".to_string()];
    let config = lsp_config(vec![("types", types), ("lint", lint)]);
    let mut editor = editor_for(dir.path(), config, "sample.ts");
    editor.test_ensure_current_buffer_lsp_opened().await.unwrap();

    wait_for_all(&mut editor, &events, &["types", "lint"], "didOpen").await;

    let mut shown: Vec<String> = Vec::new();
    for _ in 0..60 {
        let _ = editor.test_service_background().await;
        let result = editor
            .test_run_agent_editor_tool(displayed_diagnostics_request("sample.ts"))
            .await
            .unwrap();
        shown = messages(&result);
        if shown.iter().any(|m| m.contains("types-pushed"))
            && shown.iter().any(|m| m.contains("lint-pushed"))
        {
            break;
        }
        tokio::time::sleep(Duration::from_millis(30)).await;
    }
    assert!(
        shown.iter().any(|m| m.contains("types-pushed")),
        "the first server's pushed diagnostic is missing. displayed: {shown:?}"
    );
    assert!(
        shown.iter().any(|m| m.contains("lint-pushed")),
        "the second server's pushed diagnostic is missing. displayed: {shown:?}"
    );

    // Edit the document: lint now publishes an empty set.
    editor.test_type_text("y").await.unwrap();
    wait_for_all(&mut editor, &events, &["types", "lint"], "didChange").await;

    for _ in 0..60 {
        let _ = editor.test_service_background().await;
        let result = editor
            .test_run_agent_editor_tool(displayed_diagnostics_request("sample.ts"))
            .await
            .unwrap();
        shown = messages(&result);
        if !shown.iter().any(|m| m.contains("lint-pushed")) {
            break;
        }
        tokio::time::sleep(Duration::from_millis(30)).await;
    }
    pump(&mut editor, 10).await;
    let result = editor
        .test_run_agent_editor_tool(displayed_diagnostics_request("sample.ts"))
        .await
        .unwrap();
    shown = messages(&result);
    assert!(
        !shown.iter().any(|m| m.contains("lint-pushed")),
        "a server that published an empty set still has its old diagnostic \
         displayed. displayed: {shown:?}"
    );
    assert!(
        shown.iter().any(|m| m.contains("types-pushed")),
        "one server publishing an empty set removed another server's \
         diagnostic. displayed: {shown:?}"
    );
}

#[tokio::test]
async fn formatting_applies_one_servers_edit_every_time() {
    // Both servers offer formatting; each answers with an edit that inserts
    // its own name at the start of the file; they take turns being the slower
    // one to answer. After each of five formats the file must hold one
    // server's prefix repeated once per format.
    let dir = tempfile::tempdir().unwrap();
    let events = dir.path().join("events.log");
    std::fs::write(&events, "").unwrap();
    let ev = events.display().to_string();
    let script = dir.path().join("feature_server.py");
    std::fs::write(&script, FEATURE_SERVER_PY).unwrap();
    let script = script.to_string_lossy().into_owned();

    let mut config = lsp_config(vec![
        ("north", server_with_features(&script, "north", &ev, &["ts"], "formatting,slow-odd")),
        ("south", server_with_features(&script, "south", &ev, &["ts"], "formatting,slow-even")),
    ]);
    config.formatting.provider = FormattingProvider::Lsp;
    config.formatting.on_save = false;
    let mut editor = editor_for(dir.path(), config, "sample.ts");
    editor.test_ensure_current_buffer_lsp_opened().await.unwrap();

    wait_for_all(&mut editor, &events, &["north", "south"], "didOpen").await;
    pump(&mut editor, 10).await;

    let mut winner: Option<&str> = None;
    for round in 1..=5 {
        let before = editor.test_buffer_contents();
        editor
            .test_execute_action(Action::FormatDocument)
            .await
            .unwrap();
        for _ in 0..100 {
            if editor.test_buffer_contents() != before {
                break;
            }
            let _ = editor.test_service_background().await;
            tokio::time::sleep(Duration::from_millis(20)).await;
        }
        pump(&mut editor, 5).await;
        let contents = editor.test_buffer_contents();
        let matched = ["north", "south"]
            .into_iter()
            .find(|name| contents == format!("{}x\n", format!("{name}_").repeat(round)));
        let Some(name) = matched else {
            panic!(
                "after format #{round} the file should hold one server's edit \
                 applied {round} time(s); got {contents:?}"
            );
        };
        match winner {
            None => winner = Some(name),
            Some(previous) => assert_eq!(
                previous, name,
                "format #{round} used a different server than earlier formats; \
                 got {contents:?}"
            ),
        }
    }
}

#[tokio::test]
async fn completion_lists_one_servers_items_every_time() {
    // Both servers offer completion with one item named after themselves, and
    // they take turns being the slower one to answer. Every completion request
    // must list exactly one server's item, and the same server's item each time.
    let dir = tempfile::tempdir().unwrap();
    let events = dir.path().join("events.log");
    std::fs::write(&events, "").unwrap();
    let ev = events.display().to_string();
    let script = dir.path().join("feature_server.py");
    std::fs::write(&script, FEATURE_SERVER_PY).unwrap();
    let script = script.to_string_lossy().into_owned();

    let config = lsp_config(vec![
        ("east", server_with_features(&script, "east", &ev, &["ts"], "completion,slow-odd")),
        ("west", server_with_features(&script, "west", &ev, &["ts"], "completion,slow-even")),
    ]);
    let mut editor = editor_for(dir.path(), config, "sample.ts");
    editor.test_ensure_current_buffer_lsp_opened().await.unwrap();

    wait_for_all(&mut editor, &events, &["east", "west"], "didOpen").await;
    pump(&mut editor, 10).await;

    let mut observed: Vec<BTreeSet<&str>> = Vec::new();
    for _ in 0..8 {
        let _ = editor.test_execute_action(Action::CloseDialog).await;
        let _ = editor
            .test_execute_action(Action::EnterMode(Mode::Normal))
            .await;
        editor
            .test_execute_action(Action::EnterMode(Mode::Insert))
            .await
            .unwrap();
        editor
            .test_execute_action(Action::SetCursor(0, 0))
            .await
            .unwrap();
        editor
            .test_execute_action(Action::RequestCompletion)
            .await
            .unwrap();
        let mut seen = BTreeSet::new();
        for _ in 0..60 {
            let _ = editor.test_service_background().await;
            tokio::time::sleep(Duration::from_millis(20)).await;
            for row in rendered_rows(&mut editor) {
                for name in ["east", "west"] {
                    if row.contains(&format!("{name}_item")) {
                        seen.insert(name);
                    }
                }
            }
            if !seen.is_empty() {
                // Give a second answer time to arrive before recording.
                pump(&mut editor, 10).await;
                for row in rendered_rows(&mut editor) {
                    for name in ["east", "west"] {
                        if row.contains(&format!("{name}_item")) {
                            seen.insert(name);
                        }
                    }
                }
                break;
            }
        }
        observed.push(seen);
    }

    let answered: Vec<&BTreeSet<&str>> = observed.iter().filter(|s| !s.is_empty()).collect();
    assert!(
        answered.len() >= 6,
        "completion listed a server item on only {}/{} tries",
        answered.len(),
        observed.len()
    );
    for (i, seen) in answered.iter().enumerate() {
        assert_eq!(
            seen.len(),
            1,
            "completion #{i} listed items from more than one server: {seen:?}"
        );
    }
    let first = answered[0];
    for (i, seen) in answered.iter().enumerate().skip(1) {
        assert_eq!(
            *seen, first,
            "completion #{i} listed a different server's item than the first: \
             first={first:?}, got={seen:?}"
        );
    }
}

#[tokio::test]
async fn external_formatter_keeps_precedence_over_every_matching_server() {
    // The language has an external formatter (uppercase via tr) and two
    // servers that both offer formatting. Formatting must use the external
    // formatter and send no formatting request to either server.
    let dir = tempfile::tempdir().unwrap();
    let events = dir.path().join("events.log");
    std::fs::write(&events, "").unwrap();
    let ev = events.display().to_string();
    let script = dir.path().join("feature_server.py");
    std::fs::write(&script, FEATURE_SERVER_PY).unwrap();
    let script = script.to_string_lossy().into_owned();

    let mut config = lsp_config(vec![
        ("left", server_with_features(&script, "left", &ev, &["fmtx"], "formatting")),
        ("right", server_with_features(&script, "right", &ev, &["fmtx"], "formatting")),
    ]);
    config.formatting.on_save = false;
    config.languages.insert(
        "fmtlang".to_string(),
        LanguageConfig {
            extensions: vec!["fmtx".to_string()],
            formatter: Some(LanguageFormatterConfig {
                name: "Upper".to_string(),
                command: "tr".to_string(),
                args: vec!["a-z".to_string(), "A-Z".to_string()],
                root_markers: Vec::new(),
                env: HashMap::new(),
            }),
            ..Default::default()
        },
    );
    let mut editor = editor_for(dir.path(), config, "sample.fmtx");
    editor.test_ensure_current_buffer_lsp_opened().await.unwrap();

    wait_for_all(&mut editor, &events, &["left", "right"], "didOpen").await;
    pump(&mut editor, 10).await;

    editor
        .test_execute_action(Action::FormatDocument)
        .await
        .unwrap();
    pump(&mut editor, 40).await;

    assert_eq!(
        editor.test_buffer_contents(),
        "X\n",
        "formatting should use the external formatter's output"
    );
    let log = log_text(&events);
    assert!(
        !log.lines().any(|l| l.contains("textDocument/formatting")),
        "no language server should be asked to format when an external \
         formatter is configured.\nrecorded events:\n{log}"
    );
}

#[tokio::test]
async fn document_claimed_by_one_server_uses_only_that_server() {
    // "solo" claims .ts and "other" claims .rs. A .ts document is opened with
    // solo alone, and solo's diagnostic is shown.
    let dir = tempfile::tempdir().unwrap();
    let events = dir.path().join("events.log");
    std::fs::write(&events, "").unwrap();
    let ev = events.display().to_string();
    let script = dir.path().join("server.py");
    std::fs::write(&script, SERVER_PY).unwrap();
    let script = script.to_string_lossy().into_owned();

    let config = lsp_config(vec![
        ("solo", server(&script, "solo", &ev, &["ts"])),
        ("other", server(&script, "other", &ev, &["rs"])),
    ]);
    let mut editor = editor_for(dir.path(), config, "sample.ts");
    editor.test_ensure_current_buffer_lsp_opened().await.unwrap();

    let opened = wait_for_all(&mut editor, &events, &["solo"], "didOpen").await;
    assert!(
        opened,
        "the only matching server must receive the open notification.\n\
         recorded events:\n{}",
        log_text(&events)
    );

    let mut shown: Vec<String> = Vec::new();
    for _ in 0..25 {
        let _ = editor.test_execute_action(Action::RefreshDiagnostics).await;
        let result = editor
            .test_run_agent_editor_tool(diagnostics_request("sample.ts"))
            .await
            .unwrap();
        shown = messages(&result);
        if shown.iter().any(|m| m.contains("solo-problem")) {
            break;
        }
        tokio::time::sleep(Duration::from_millis(30)).await;
    }
    assert!(
        shown.iter().any(|m| m.contains("solo-problem")),
        "the matching server's diagnostic is not shown. displayed: {shown:?}"
    );
    assert!(
        !shown.iter().any(|m| m.contains("other-problem")),
        "a server whose selector does not admit the file contributed \
         diagnostics. displayed: {shown:?}"
    );
    assert!(
        !log_has(&events, "other", "didOpen"),
        "a server whose selector does not admit the file was sent the \
         document.\nrecorded events:\n{}",
        log_text(&events)
    );
}
