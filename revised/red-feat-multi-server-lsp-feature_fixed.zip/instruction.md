## Task

When a file matches more than one of the language servers in our config, the editor only ever talks to one of them.
The others get skipped, so you can't run, say, a TypeScript types server and a separate linter on the same file and see what both of them report.
Please make a document use every configured server whose selector admits it.

Here's what that should look like:

- Opening, editing and closing the document reaches every matching server, not just one.
- Diagnostics from all of those servers show up together.
  A server's diagnostics, whether it pushes them or the editor pulls them, only ever replace that same server's earlier ones.
  If one server publishes an empty list, only its own entries go away.
  If one server crashes or exits, the diagnostics from the others stay on screen.
- Hover, completion and formatting can only use one answer.
  For these, the editor should show a single server's result, and the same server's result every time you ask on that document, no matter which server happens to reply first.
- A file that only one server claims should work exactly as it does now, with only that server involved.
- If the file's language has an external (non-LSP) formatter configured, formatting keeps using it and doesn't ask any language server, even when several servers match the file.

You don't need a real TypeScript server, linter or formatter installed to work on this.

## User stories / requirements

- When several configured servers claim a file, the file selects all of them: two servers that list the same extension are both selected, and so are three.
- Each server is matched through its own selector, so when servers claim overlapping but different extensions, a file selects exactly the servers whose selectors accept it, and a file that no selector accepts selects no server.
