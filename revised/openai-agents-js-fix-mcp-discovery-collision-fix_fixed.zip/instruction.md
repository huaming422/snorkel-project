## Task

Deferred hosted MCP servers in `@openai/agents-core` can be called before tool search has loaded them.
If a hosted MCP server is set to defer loading, a call to one of its tools that shows up before tool search loaded that server should fail the run, and usually it does.
It stops failing once the agent also has its own function tools whose names clash with the server.
One case is a local namespace named like the `mcp_`-prefixed group the server's tools come back under in search results.
Another is a local tool named after the server label or that same prefixed name.
When tool search turns up those local tools, a later call to the hosted server goes through as though the server had been loaded, and nothing ever loaded it.
The same thing happens on later turns of a reused session and after run state is saved and resumed, also when the agent's tool list is different on the next turn.

A hosted call should get through only after tool search has loaded that server.
Normal hosted discovery with no clash has to keep working the way it does today, across turns and on resume as well.
A search result that returns the hosted server itself should still count as loading it, even with a clashing local namespace configured.
Don't change caller restrictions, approval interruptions, plain local tool calls or MCP servers that aren't deferred.
Run state saved by older SDK versions still has to load.
All of this reproduces offline with the SDK's scripted test model.
