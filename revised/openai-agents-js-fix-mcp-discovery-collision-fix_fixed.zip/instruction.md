## Task

Deferred hosted MCP servers in `@openai/agents-core` can be called before tool search has found them.
When a hosted MCP server is set to defer loading, a call to one of its tools that comes in before the server was discovered should fail the run, and most of the time it does.
That stops happening once the agent also has local function tools whose names collide with the names the hosted server uses in tool search.
In that setup the deferred hosted call just runs, even though the server was never discovered.
We see the same thing on later turns of a reused session and after run state is saved and resumed, also when the agent's tool list changes between turns.

A deferred hosted call should only get through after the server has really been discovered.
Real discovery of the server should keep working as it does now, with or without a clashing local tool around, across turns and on resume.
If tool search returns the hosted server itself, that counts as discovery too, even when a clashing local namespace is configured.
Caller restrictions, approval interruptions and plain local tool calls should behave as before, and older saved run state should still resume fine.
