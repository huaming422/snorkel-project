## Task

Deferred hosted MCP servers in `@openai/agents-core` can be called before tool search has found them.
When a hosted MCP server is set to defer loading, a call to one of its tools that comes in before tool search found the server should fail the run, and most of the time it does.
That stops happening once the agent also has local function tools whose names collide with the names the hosted server uses in tool search.
In that setup the hosted call is accepted and the run finishes as if the server had been loaded.
We see the same thing on later turns of a reused session and after run state is saved and resumed, also when the agent's tool list changes between turns.

Those calls should keep failing until tool search has found the hosted server.
After that, its deferred calls should work the way they do today, on later turns and after a resume as well.
