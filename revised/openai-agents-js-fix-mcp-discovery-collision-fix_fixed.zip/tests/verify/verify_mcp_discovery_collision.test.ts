// Deferred hosted MCP calls and local tools whose names clash with the server.
//
// Everything goes through the public @openai/agents-core API (Agent, Runner,
// MemorySession, RunState, hostedMcpTool, toolNamespace, tool) and the offline
// ScriptedModel. No internal helper, field or schema constant is referenced.
// Each case looks only at what runner.run() does: whether it resolves or
// rejects, the final output, and the items the session stored. The drivers
// come from the repo's own test/hostedMcpToolSearch.test.ts.
//
// Two groups of cases:
//  - A deferred hosted call is rejected when only clashing local tools were
//    found by tool search (same turn, a reused session, and resumed state).
//  - A deferred hosted call still runs after real hosted discovery, and the
//    caller, approval and saved-state loading paths behave as before.

import { describe, expect, it, vi } from 'vitest';
import { z } from 'zod';
import {
  Agent,
  MemorySession,
  Runner,
  RunState,
  hostedMcpTool,
  tool,
  toolNamespace,
} from '../src';
import { ScriptedModel, assistantMessage } from '../src/testing';
import type * as protocol from '../src/types/protocol';

// --- Drivers (same as test/hostedMcpToolSearch.test.ts) ---------------------

const server = () =>
  hostedMcpTool({
    serverLabel: 'OpenAI_Docs',
    serverUrl: 'https://example.invalid/mcp',
    deferLoading: true,
    requireApproval: 'never',
  });

const searchTool = {
  type: 'hosted_tool',
  name: 'tool_search',
  providerData: { type: 'tool_search' },
} as const;

// A hosted MCP discovery turn for the OpenAI_Docs server.
function discovery(namespace = 'mcp_OpenAI_Docs'): protocol.ModelItem[] {
  return [
    {
      type: 'hosted_tool_call',
      name: 'mcp_list_tools',
      status: 'completed',
      providerData: { type: 'mcp_list_tools', server_label: 'OpenAI_Docs' },
    },
    {
      type: 'tool_search_call',
      id: 'search',
      status: 'completed',
      arguments: { paths: [namespace] },
      providerData: { execution: 'server' },
    },
    {
      type: 'tool_search_output',
      id: 'search_output',
      status: 'completed',
      tools: [
        {
          type: 'namespace',
          name: namespace,
          description: 'Documentation tools',
          tools: [
            {
              type: 'function',
              name: 'search_openai_docs',
              description: 'Search documentation',
              parameters: {
                type: 'object',
                properties: {},
                additionalProperties: false,
              },
              strict: true,
            },
          ],
        },
      ],
      providerData: { execution: 'server' },
    },
  ];
}

// A deferred hosted-MCP tool call for the OpenAI_Docs server.
function call(
  name = 'search_openai_docs',
  type = 'mcp_call',
): protocol.HostedToolCallItem {
  return {
    type: 'hosted_tool_call',
    id: 'call_1',
    name: type,
    status: 'completed',
    output: 'Documentation found.',
    providerData: {
      type,
      id: 'call_1',
      server_label: 'OpenAI_Docs',
      name,
      arguments: '{}',
    },
  };
}

const runner = () => new Runner({ tracingDisabled: true });

// Local namespace spelled like the hosted server's search namespace
// (mcp_<serverLabel>). Finding it through tool search does not load the
// hosted server.
const collidingLocalTools = (execute: () => Promise<string>) =>
  toolNamespace({
    name: 'mcp_OpenAI_Docs',
    description: 'Local documentation',
    tools: [
      tool({
        name: 'search_openai_docs',
        description: 'Local search',
        parameters: z.object({}),
        deferLoading: true,
        execute,
      }),
    ],
  });

describe('deferred hosted MCP discovery collision', () => {
  // Hosted discovery on the first turn loads the server, so the deferred call
  // on the next turn runs and the session stores the mcp_call item.
  it('accepts a deferred hosted call after genuine hosted MCP discovery', async () => {
    const model = new ScriptedModel([
      [...discovery(), assistantMessage('Tools loaded.')],
      [call(), assistantMessage('Done.')],
    ]);
    const agent = new Agent({
      name: 'Docs',
      model,
      tools: [server(), searchTool],
    });
    const session = new MemorySession();
    expect(
      (await runner().run(agent, 'Discover tools.', { session })).finalOutput,
    ).toBe('Tools loaded.');
    expect(
      (await runner().run(agent, 'Search docs.', { session })).finalOutput,
    ).toBe('Done.');
    expect(
      (await session.getItems()).some(
        (item) =>
          item.type === 'hosted_tool_call' &&
          item.providerData?.type === 'mcp_call',
      ),
    ).toBe(true);
    model.assertComplete();
  });

  // Only the clashing local namespace was found, so the hosted server is still
  // not loaded and the later deferred call rejects. Both runner.run() turns
  // share one MemorySession, which covers the cross-turn path too.
  it.each([false, true])(
    'rejects a deferred hosted call when only a colliding user namespace was discovered (stream: %s)',
    async (stream) => {
      const execute = vi.fn(async () => 'local result');
      const localTools = collidingLocalTools(execute);
      const localCall: protocol.FunctionCallItem = {
        type: 'function_call',
        name: 'search_openai_docs',
        namespace: 'mcp_OpenAI_Docs',
        callId: 'local',
        arguments: '{}',
      };
      const model = new ScriptedModel([
        [
          {
            type: 'tool_search_call',
            callId: 'search',
            execution: 'client',
            arguments: { paths: ['mcp_OpenAI_Docs'] },
          } as protocol.ToolSearchCallItem,
        ],
        [localCall],
        [assistantMessage('Local tool called.')],
        [call(), assistantMessage('Done.')],
      ]);
      const agent = new Agent({
        name: 'Docs',
        model,
        tools: [
          ...localTools,
          server(),
          {
            ...searchTool,
            providerData: { type: 'tool_search', execution: 'client' },
          },
        ],
      });
      const session = new MemorySession();
      await runner().run(agent, 'Use local docs.', { session });
      expect(execute).toHaveBeenCalledTimes(1);

      const runHosted = async () => {
        if (stream) {
          const result = await runner().run(agent, 'Use hosted docs.', {
            session,
            stream: true,
          });
          await result.completed;
        } else {
          await runner().run(agent, 'Use hosted docs.', { session });
        }
      };
      await expect(runHosted()).rejects.toThrow(
        /before it was loaded via tool_search/,
      );
      model.assertComplete();
    },
  );

  // A deferred top-level tool named mcp_inventory is found by search on the
  // first turn. The hosted server labeled inventory was never found. After the
  // local tool is removed from the agent, the deferred hosted call on the
  // reused session still rejects.
  it('keeps deferred self-namespace discovery local across session reuse', async () => {
    const execute = vi.fn(async () => 'local');
    const local = tool({
      name: 'mcp_inventory',
      description: 'Local inventory',
      parameters: z.object({}),
      deferLoading: true,
      execute,
    });
    const model = new ScriptedModel([
      [
        {
          type: 'tool_search_output',
          execution: 'server',
          tools: [
            {
              type: 'tool_reference',
              functionName: 'mcp_inventory',
              namespace: 'mcp_inventory',
            },
          ],
        },
        {
          type: 'function_call',
          name: 'mcp_inventory',
          namespace: 'mcp_inventory',
          callId: 'local',
          arguments: '{}',
        },
      ],
      [assistantMessage('Local completed.')],
      [
        {
          type: 'hosted_tool_call',
          name: 'mcp_call',
          providerData: {
            type: 'mcp_call',
            server_label: 'inventory',
            name: 'mcp_inventory',
            arguments: '{}',
          },
        },
      ],
    ]);
    const agent = new Agent({
      name: 'Inventory',
      model,
      tools: [
        local,
        searchTool,
        hostedMcpTool({
          serverLabel: 'inventory',
          serverUrl: 'https://example.invalid/mcp',
          deferLoading: true,
          requireApproval: 'never',
        }),
      ],
    });
    const session = new MemorySession();
    await runner().run(agent, 'Use local inventory.', { session });
    expect(execute).toHaveBeenCalledOnce();
    agent.tools = agent.tools.filter((t) => t !== local);
    await expect(
      runner().run(agent, 'Use hosted inventory.', { session }),
    ).rejects.toThrow(/before it was loaded via tool_search/);
    model.assertComplete();
  });

  // Resume from serialized state. In 'recorded' mode the saved history holds a
  // hosted discovery with no clash, so the deferred call runs. In 'collision'
  // mode the same search result was saved while a clashing local namespace was
  // configured, so it never loaded the server. The resumed agent drops the
  // local tools, and the deferred call still rejects.
  it.each(['recorded', 'collision'] as const)(
    'preserves %s discovery provenance through RunState resume',
    async (mode) => {
      const confirm = tool({
        name: 'confirm',
        description: 'Confirm continuation',
        parameters: z.object({}),
        needsApproval: true,
        execute: async () => 'confirmed',
      });
      const localTools =
        mode === 'collision' ? collidingLocalTools(async () => 'local') : [];
      const agent = new Agent({
        name: 'Docs',
        tools: [server(), searchTool, confirm, ...localTools],
        model: new ScriptedModel([
          [
            ...discovery().slice(1),
            {
              type: 'function_call',
              name: 'confirm',
              callId: 'confirm',
              arguments: '{}',
            },
          ],
        ]),
      });
      const paused = await runner().run(agent, 'Discover tools and confirm.');
      const serialized = await paused.state.toString();

      const replacement = new Agent({
        name: 'Docs',
        tools: [server(), searchTool, confirm],
        model: new ScriptedModel([[call(), assistantMessage('Done.')]]),
      });
      const restored = await RunState.fromString(replacement, serialized);
      restored.approve(restored.getInterruptions()[0]);
      const result = runner().run(replacement, restored);
      if (mode === 'recorded') {
        expect((await result).finalOutput).toBe('Done.');
      } else {
        await expect(result).rejects.toThrow(
          /before it was loaded via tool_search/,
        );
      }
    },
  );

  // A client tool_search over the real server label returns the hosted server
  // itself. That loads it, so the deferred call runs even though a clashing
  // local namespace is configured as well.
  it('accepts explicit MCP discovery despite a colliding user namespace', async () => {
    const mcp = server();
    const model = new ScriptedModel([
      [
        {
          type: 'tool_search_call',
          callId: 'search',
          execution: 'client',
          arguments: { paths: ['OpenAI_Docs'] },
        } as protocol.ToolSearchCallItem,
      ],
      [call(), assistantMessage('Done.')],
    ]);
    const agent = new Agent({
      name: 'Docs',
      model,
      tools: [
        mcp,
        ...collidingLocalTools(async () => 'local'),
        {
          ...searchTool,
          providerData: { type: 'tool_search', execution: 'client' },
        },
      ],
    });
    expect((await runner().run(agent, 'Load hosted docs.')).finalOutput).toBe(
      'Done.',
    );
    model.assertComplete();
  });

  // A local function named exactly like the server label, returned by a
  // server-side search, is not a hosted MCP result. The deferred call rejects.
  it('does not confuse a bare user function with an MCP descriptor', async () => {
    const agent = new Agent({
      name: 'Docs',
      tools: [
        server(),
        tool({
          name: 'OpenAI_Docs',
          description: 'Local lookup',
          parameters: z.object({}),
          deferLoading: true,
          execute: async () => 'local',
        }),
        {
          ...searchTool,
          providerData: { type: 'tool_search', execution: 'server' },
        },
      ],
      model: new ScriptedModel([
        [
          {
            type: 'tool_search_output',
            id: 'search',
            status: 'completed',
            execution: 'server',
            tools: [{ type: 'function', name: 'OpenAI_Docs' }],
          },
          call(),
        ],
      ]),
    });
    await expect(runner().run(agent, 'Search.')).rejects.toThrow(
      /before it was loaded via tool_search/,
    );
  });

  // Caller restrictions and approval interruptions for hosted MCP tools work
  // the same after namespace discovery.
  it('still enforces caller restrictions after namespace discovery', async () => {
    const mcp = server();
    mcp.providerData.allowed_callers = ['programmatic'];
    const model = new ScriptedModel([
      [...discovery().slice(1), call(), assistantMessage('Done.')],
    ]);
    const agent = new Agent({ name: 'Docs', model, tools: [mcp, searchTool] });
    await expect(runner().run(agent, 'Search docs.')).rejects.toThrow(
      /caller direct/,
    );
  });

  it('preserves approval interruptions after namespace discovery', async () => {
    const mcp = server();
    mcp.providerData.require_approval = 'always';
    const model = new ScriptedModel([
      [...discovery(), call('search_openai_docs', 'mcp_approval_request')],
    ]);
    const agent = new Agent({ name: 'Docs', model, tools: [mcp, searchTool] });
    const result = await runner().run(agent, 'Search docs.');
    expect(result.interruptions).toHaveLength(1);
    expect(result.interruptions[0].rawItem).toMatchObject({
      providerData: { server_label: 'OpenAI_Docs', name: 'search_openai_docs' },
    });
  });

  // Run state saved with schema version '1.21' (the version at the base
  // commit) still loads. If the current version moves forward, '1.21' has to
  // stay readable.
  it('loads run state serialized before the schema was bumped', async () => {
    // Build a minimal RunState by pausing a run at an approval interruption.
    const gate = tool({
      name: 'approve_gate',
      description: 'Approval gate for test',
      parameters: z.object({}),
      needsApproval: true,
      execute: async () => 'approved',
    });
    const paused = await runner().run(
      new Agent({
        name: 'Docs',
        model: new ScriptedModel([
          [{ type: 'function_call', name: 'approve_gate', callId: 'g1', arguments: '{}' }],
        ]),
        tools: [gate],
      }),
      'Pause.',
    );
    const serialized = await paused.state.toString();
    // Set $schemaVersion to '1.21' to stand in for state saved by an older
    // SDK. Loading it should not throw.
    const oldState = serialized.replace(/"\$schemaVersion":"[^"]*"/, '"$$schemaVersion":"1.21"');
    const resumeAgent = new Agent({
      name: 'Docs',
      model: new ScriptedModel([]),
      tools: [gate],
    });
    await expect(RunState.fromString(resumeAgent, oldState)).resolves.toBeDefined();
  });
});
