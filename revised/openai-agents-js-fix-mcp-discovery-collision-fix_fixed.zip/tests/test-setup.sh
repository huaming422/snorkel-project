#!/usr/bin/env bash
# Environment setup for the verifier.
#
# The verifier is a vitest test in the @openai/agents-core project. Like the
# package's own tests it imports through `../src`, so vitest picks up src/
# edits without a dist/ rebuild. dist/ is rebuilt anyway because a few
# integration-style tests load the compiled package through Node's module
# resolution. tsc-multi is quick when the source has not changed.
#
# Sourced (not exec'd) by the harbor runner so env vars set here stay live for
# the verifier subprocess.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/openai-agents-js}"
export REPO_DIR
cd "$REPO_DIR"

# The js runner reads verify.toml with tomllib (Python 3.11+) or tomli. The
# runner itself uses the Python 3.12 venv under /opt/tooling, which ships
# tomllib. The system python3 is 3.10 and has neither, so this tries a pinned
# tomli as a fallback. Any failure is ignored, since the verifier network only
# allows the judge host. The redirects sit on the wrapper call so pip stays
# quiet.
TOMLI_PIN="tomli==2.0.1"
_pip_quiet() { python3 -m pip install --quiet "$@"; }
if ! python3 -c "import tomllib" >/dev/null 2>&1 && \
   ! python3 -c "import tomli"   >/dev/null 2>&1; then
    _pip_quiet "$TOMLI_PIN" >/dev/null 2>&1 \
        || _pip_quiet --break-system-packages "$TOMLI_PIN" >/dev/null 2>&1 \
        || true
fi

# vitest has to resolve from the workspace root. The image already installed
# every package, so a missing binary means node_modules is damaged. Reinstall
# from the local store here instead of failing later with "command not found".
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest binary missing from node_modules/.bin/. " \
         "Re-running pnpm install (offline)." >&2
    pnpm install --frozen-lockfile --offline --ignore-scripts
fi

# Rebuild dist/ so it matches any src/ change in agents-core and the packages
# that depend on it. tsc-multi runs directly instead of `pnpm build`, because the
# `prebuild` step rewrites the tracked src/metadata.ts and would dirty the tree.
# dist/ is gitignored, so `git status` stays clean.
echo "test-setup.sh: rebuilding workspace dist/ (tsc-multi)..."
pnpm exec tsc-multi --maxWorkers 1

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
