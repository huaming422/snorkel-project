#!/usr/bin/env bash
# Verifier setup for rippled-fix-mpt-payment-invariants.
#
# Everything the focused C++ test suites need is baked into the image at the
# base commit: GCC 15, Conan 2 + the full dependency graph warm in ~/.conan2,
# CMake/Ninja, and a configured build/ tree with xrpld/xrpl_tests/xrpld_tests
# already compiled. The verifier (next stage) drops its C++ suite(s) into
# src/test/, re-runs cmake --build on the xrpld target, and executes
# `./build/xrpld --unittest=<Suite>`; the incremental rebuild cache-hits every
# dependency and only recompiles the touched suite plus any engine sources
# changed since the image was built. No network is required.
#
# This script performs NO assertion logic - it only ensures the repo is at a
# known-good working directory and is safe to run with the network cut.
set -euo pipefail

REPO_DIR="/repo/rippled"
cd "$REPO_DIR"

echo "[test-setup] rippled-fix-mpt-payment-invariants: build toolchain and Conan"
echo "[test-setup] dependency graph are baked into the image; nothing to install."
