// Behavioral checks for four MPT/DEX/vault payment-engine flows guarded by the
// MPTokensV2 amendment. Each flow is a separate beast::unit_test suite sharing
// the "MPTPaymentInvariants" prefix so a run can report every flow
// independently. Everything is exercised through the pre-existing jtx
// transaction-submission interface; no engine-internal symbol is referenced.
//
// Dropped under src/test/app/ and compiled into the xrpld binary via the
// src/test/*.cpp CONFIGURE_DEPENDS glob; run with
// `xrpld --unittest=MPTPaymentInvariants`.

#include <test/app/invariants/InvariantsBase.h>
#include <test/jtx/Account.h>
#include <test/jtx/CaptureLogs.h>
#include <test/jtx/Env.h>
#include <test/jtx/PathSet.h>
#include <test/jtx/TestHelpers.h>
#include <test/jtx/amount.h>
#include <test/jtx/balance.h>
#include <test/jtx/flags.h>
#include <test/jtx/mpt.h>
#include <test/jtx/offer.h>
#include <test/jtx/paths.h>
#include <test/jtx/pay.h>
#include <test/jtx/sendmax.h>
#include <test/jtx/ter.h>
#include <test/jtx/trust.h>
#include <test/jtx/txflags.h>
#include <test/jtx/vault.h>

#include <xrpl/beast/unit_test/suite.h>
#include <xrpl/protocol/AccountID.h>
#include <xrpl/protocol/Asset.h>
#include <xrpl/protocol/Feature.h>
#include <xrpl/protocol/Indexes.h>
#include <xrpl/protocol/Issue.h>
#include <xrpl/protocol/MPTIssue.h>
#include <xrpl/protocol/SField.h>
#include <xrpl/protocol/STAmount.h>
#include <xrpl/protocol/STObject.h>
#include <xrpl/protocol/STTx.h>
#include <xrpl/protocol/TER.h>
#include <xrpl/protocol/TxFlags.h>
#include <xrpl/protocol/TxFormats.h>
#include <xrpl/protocol/UintTypes.h>
#include <xrpl/protocol/XRPAmount.h>
#include <xrpl/tx/ApplyContext.h>

#include <array>
#include <cstdint>
#include <functional>
#include <memory>
#include <string>

namespace xrpl::test {

//------------------------------------------------------------------------------
// Flow 1: sub-resolution trust-line clawback.
//
// IOU balances keep 16 significant digits. When an amount much smaller than the
// holder's balance is clawed back, the stored balance changes by the rounded
// amount, which can be zero, less, or more than requested. Such a clawback
// succeeds with that rounded change, and a wrong balance change is
// still rejected. Derives from InvariantsBase for the guard case, which puts
// the ledger directly into a state a normal transaction cannot reach.
//------------------------------------------------------------------------------
class MPTPaymentInvariantsClawback_test : public InvariantsBase
{
    void
    testSubResolutionAmount(FeatureBitset features)
    {
        testcase("Sub-resolution clawback amount accepted");
        using namespace test::jtx;

        Account const alice{"alice"};
        Account const bob{"bob"};

        struct Case
        {
            std::uint64_t balanceMantissa;
            int balanceExponent;
            std::uint64_t clawMantissa;
            int clawExponent;
            std::uint64_t afterMantissa;
            int afterExponent;
        };
        std::array const cases{
            // 1e7 - 1e-10 rounds back to 1e7
            Case{
                .balanceMantissa = 10'000'000,
                .balanceExponent = 0,
                .clawMantissa = 1,
                .clawExponent = -10,
                .afterMantissa = 10'000'000,
                .afterExponent = 0,
            },
            // 1234567890.123456 - 0.0000005 rounds back to the balance
            Case{
                .balanceMantissa = 1'234'567'890'123'456,
                .balanceExponent = -6,
                .clawMantissa = 5,
                .clawExponent = -7,
                .afterMantissa = 1'234'567'890'123'456,
                .afterExponent = -6,
            },
            // 0.0000014 removes 0.000001
            Case{
                .balanceMantissa = 1'234'567'890'123'456,
                .balanceExponent = -6,
                .clawMantissa = 14,
                .clawExponent = -7,
                .afterMantissa = 1'234'567'890'123'455,
                .afterExponent = -6,
            },
            // 0.0000016 removes 0.000002
            Case{
                .balanceMantissa = 1'234'567'890'123'456,
                .balanceExponent = -6,
                .clawMantissa = 16,
                .clawExponent = -7,
                .afterMantissa = 1'234'567'890'123'454,
                .afterExponent = -6,
            },
        };

        for (auto const feat : {features, features - featureMPTokensV2})
        {
            for (auto const& c : cases)
            {
                std::string logs;
                {
                    Env env(
                        *this, feat, std::make_unique<CaptureLogs>(&logs));

                    env.fund(XRP(1000), alice, bob);
                    env.close();

                    auto const usd = alice["USD"];

                    env(fset(alice, asfAllowTrustLineClawback));
                    env.close();

                    env.trust(usd(10'000'000'000), bob);
                    env(pay(
                        alice,
                        bob,
                        STAmount{
                            usd.issue(),
                            c.balanceMantissa,
                            c.balanceExponent}));
                    env.close();

                    env(claw(
                            alice,
                            STAmount{
                                Issue{usd.currency, bob.id()},
                                c.clawMantissa,
                                c.clawExponent}),
                        Ter(tesSUCCESS));
                    env.close();

                    BEAST_EXPECT(
                        env.balance(bob, usd).value() ==
                        STAmount(
                            usd.issue(), c.afterMantissa, c.afterExponent));
                }
                // Without the amendment a failed invariant only logs and the
                // transaction still succeeds, so check the logs instead.
                if (!feat[featureMPTokensV2])
                    BEAST_EXPECT(!logs.contains("Invariant failed"));
            }
        }
    }

    void
    testWrongBalanceChangeRejected()
    {
        // Guard: a wrong clawback balance change (the stored balance
        // moves by more than the clamped claw amount) still fails the clawback
        // balance invariant with the amendment enabled.
        testcase("Wrong clawback balance change rejected");
        using namespace test::jtx;

        FeatureBitset const all{jtx::testableAmendments()};

        Env env(*this, all);
        Account const issuer{"issuer"};
        Account const holder{"holder"};
        Account const other{"other"};
        env.fund(XRP(1'000), issuer, holder, other);
        auto const usd = issuer["USD"];
        env.trust(usd(100), holder);
        env(pay(issuer, holder, usd(100)));
        env.close();

        doInvariantCheck(
            std::move(env),
            holder,
            other,
            {{"Invariant failed: trustline clawback balance change is "
              "invalid"}},
            [issuer, usd](
                Account const& holder, Account const&, ApplyContext& ac) {
                auto const sle = ac.view().peek(keylet::trustLine(
                    holder.id(), issuer.id(), usd.currency));
                if (!sle)
                    return false;

                STAmount balance{Issue{usd.currency, issuer.id()}, 80};
                if (holder.id() > issuer.id())
                    balance.negate();
                sle->setFieldAmount(sfBalance, balance);
                ac.view().update(sle);
                return true;
            },
            XRPAmount{},
            STTx{
                ttCLAWBACK,
                [&](STObject& tx) {
                    tx[sfAccount] = issuer.id();
                    tx[sfAmount] = STAmount{Issue{usd.currency, holder.id()}, 10};
                }},
            {tecINVARIANT_FAILED, tefINVARIANT_FAILED});
    }

public:
    void
    run() override
    {
        using namespace test::jtx;
        FeatureBitset const all{jtx::testableAmendments()};
        testSubResolutionAmount(all);
        testWrongBalanceChangeRejected();
    }
};

BEAST_DEFINE_TESTSUITE(MPTPaymentInvariantsClawback, app, xrpl);

//------------------------------------------------------------------------------
// Flow 2: DEX offer-consumption overflow.
//
// A payment crossing an offer whose amounts overflow ends with a partial-payment
// result under the amendment and with an internal error otherwise; either way
// no balances change and the offer stays on the book.
//------------------------------------------------------------------------------
struct MPTPaymentInvariantsOverflow_test : public beast::unit_test::Suite
{
    void
    testConsumeOfferOverflow(FeatureBitset features)
    {
        testcase("Offer-consumption overflow fails cleanly");

        using namespace jtx;

        Account const gw("gateway");
        Account const eurGW("eur_gateway");
        Account const maker("maker");
        Account const alice("alice");
        Account const bob("bob");

        for (auto const& testFeatures : {features, features - featureMPTokensV2})
        {
            Env env(*this, testFeatures);

            auto const withV2 = testFeatures[featureMPTokensV2];

            env.fund(XRP(10'000), gw, eurGW, maker, alice, bob);
            env.close();

            auto const usd = gw["USD"];
            auto const eur = eurGW["EUR"];
            STAmount const usdMax{
                usd.issue(), STAmount::kMaxValue, STAmount::kMaxOffset};
            STAmount const usdIn{usd.issue(), 1, 90};

            env.trust(usdMax, maker, alice);
            env.trust(eur(1'000), maker, bob);
            env.close();

            env(pay(gw, maker, usdMax));
            env(pay(gw, alice, usdIn));
            env(pay(eurGW, maker, eur(100)));
            env(offer(maker, usdIn, eur(100)));
            env.close();

            env(pay(alice, bob, eur(100)),
                Path(~eur),
                Sendmax(usdIn),
                Ter(withV2 ? TER{tecPATH_PARTIAL} : TER{tecINTERNAL}));
            env.close();

            env.require(
                Balance(bob, eur(0)),
                Balance(maker, eur(100)),
                Balance(maker, usdMax),
                Balance(alice, usdIn));
            BEAST_EXPECT(isOffer(env, maker, usdIn, eur(100)));
        }
    }

    void
    run() override
    {
        using namespace jtx;
        testConsumeOfferOverflow(testableAmendments());
    }
};

BEAST_DEFINE_TESTSUITE_PRIO(MPTPaymentInvariantsOverflow, app, xrpl, 1);

//------------------------------------------------------------------------------
// Flow 3: issuer-sourced payment looping through its own MPT.
//
// An issuer paying with its own MPT may not route it back through a book that
// outputs the same MPT; that is a path loop, exactly as it already is for a
// holder.
//------------------------------------------------------------------------------
struct MPTPaymentInvariantsLoop_test : public beast::unit_test::Suite
{
    void
    testIssuerSourceMPTLoop(FeatureBitset features)
    {
        testcase("Issuer-sourced payment looping through its own MPT");

        using namespace jtx;

        Account const gw{"gw"};
        Account const alice{"alice"};
        Account const c1{"c1"};
        Account const e1{"e1"};
        Account const dan{"dan"};

        Env env(*this, features);
        env.fund(XRP(1'000), gw, alice, c1, e1, dan);
        env.close();

        MPT const x = MPTTester(
            {.env = env,
             .issuer = gw,
             .holders = {alice, c1, e1, dan},
             .maxAmt = 100});
        auto const eur = gw["EUR"];
        auto const usd = gw["USD"];
        env(trust(e1, eur(1'000)));
        env(trust(e1, usd(1'000)));
        env(trust(dan, eur(1'000)));
        env(pay(gw, e1, eur(1'000)));
        env(pay(gw, e1, usd(1'000)));
        env(pay(gw, alice, x(10)));
        env.close();

        // Liquidity for every path below, arranged so nothing crosses at
        // creation.
        env(offer(gw, XRP(60), x(30)));    // issuer sells x for XRP
        env(offer(gw, usd(100), x(100)));  // issuer sells x for usd
        env.close();
        env(offer(c1, x(100), XRP(100)));  // buys x for XRP
        env(offer(e1, XRP(70), usd(70)));  // sells usd for XRP
        env(offer(e1, x(100), eur(100)));  // sells eur for x
        env.close();
        BEAST_EXPECT(expectOffers(env, gw, 2));
        BEAST_EXPECT(expectOffers(env, c1, 1));
        BEAST_EXPECT(expectOffers(env, e1, 2));

        auto const flags = Txflags(tfNoRippleDirect | tfPartialPayment);

        // x -> XRP -> x, the issuer's own offer feeds the endpoint
        env(pay(gw, dan, x(100)),
            Sendmax(x(100)),
            Path(~XRP, ~x),
            flags,
            Ter(temBAD_PATH_LOOP));
        // x -> XRP -> x -> eur, the issuer's own offer feeds a third book
        env(pay(gw, dan, eur(100)),
            Sendmax(x(100)),
            Path(~XRP, ~x, ~eur),
            flags,
            Ter(temBAD_PATH_LOOP));
        // x -> XRP -> usd -> x, a limiting book before the issuer's own offer
        env(pay(gw, dan, x(100)),
            Sendmax(x(100)),
            Path(~XRP, ~usd, ~x),
            flags,
            Ter(temBAD_PATH_LOOP));
        // Same loop from a holder is already rejected
        env(pay(alice, dan, x(10)),
            Sendmax(x(10)),
            Path(~XRP, ~x),
            flags,
            Ter(temBAD_PATH_LOOP));
        env.close();

        BEAST_EXPECT(env.balance(gw, x) == x(-10));
        BEAST_EXPECT(env.balance(c1, x) == x(0));
        BEAST_EXPECT(env.balance(dan, x) == x(0));

        // The issuer paying with another asset may still take its own offer
        env(pay(gw, dan, x(50)), Sendmax(usd(50)), Path(~x), flags);
        env.close();
        BEAST_EXPECT(env.balance(dan, x) == x(50));
        BEAST_EXPECT(env.balance(gw, x) == x(-60));
    }

    void
    run() override
    {
        using namespace jtx;
        testIssuerSourceMPTLoop(testableAmendments());
    }
};

BEAST_DEFINE_TESTSUITE_PRIO(MPTPaymentInvariantsLoop, app, xrpl, 1);

//------------------------------------------------------------------------------
// Flow 4: vault shares inherit the freeze/lock of the underlying asset.
//
// A holder individually frozen on a vault's underlying asset can neither move
// vault shares through the DEX nor by direct payment, and no share moves.
// Covered for both an MPT underlying and an IOU underlying, with the frozen
// holder at a strand endpoint and as a mid-path offer owner.
//------------------------------------------------------------------------------
struct MPTPaymentInvariantsVaultShare_test : public beast::unit_test::Suite
{
    void
    testShareDEXEndpointFrozen(
        jtx::Env& env,
        jtx::PrettyAsset const& asset,
        jtx::Account const& owner,
        jtx::Account const& alice,
        jtx::Account const& bob,
        jtx::Account const& carol,
        std::function<void(bool)> const& setAliceFrozen)
    {
        using namespace jtx;

        Vault const vault{env};
        auto [tx, keylet] = vault.create({.owner = owner, .asset = asset});
        env(tx);
        env.close();

        env(vault.deposit(
            {.depositor = alice, .id = keylet.key, .amount = asset(500)}));
        env(vault.deposit(
            {.depositor = bob, .id = keylet.key, .amount = asset(500)}));
        env.close();

        PrettyAsset const shares = MPTIssue(env.le(keylet)->at(sfShareMPTID));
        auto const shareMptID = shares.raw().get<MPTIssue>().getMptID();
        auto const shareBalance = [&](Account const& account) {
            auto const sle = env.le(keylet::mptoken(shareMptID, account));
            return sle ? sle->at(sfMPTAmount) : 0;
        };

        // bob bids XRP for shares and asks more XRP for shares, so that his
        // offers don't cross
        env(offer(bob, shares(1), XRP(1)));
        env(offer(bob, XRP(2), shares(1)));
        env.close();

        setAliceFrozen(true);

        auto const aliceShares = shareBalance(alice);
        auto const bobShares = shareBalance(bob);
        auto const expectUnchanged = [&] {
            BEAST_EXPECT(shareBalance(alice) == aliceShares);
            BEAST_EXPECT(shareBalance(bob) == bobShares);
            BEAST_EXPECT(expectOffers(env, bob, 2));
        };

        // alice sells shares: the first step's source is frozen
        env(pay(alice, carol, XRP(1)),
            Sendmax(shares(1)),
            Path(~XRP),
            Txflags(tfNoRippleDirect),
            Ter{tecPATH_DRY});
        env.close();
        expectUnchanged();

        // carol buys shares for alice: the last step's destination is frozen
        env(pay(carol, alice, shares(1)),
            Sendmax(XRP(2)),
            Path(BookSpec{shares.raw()}),
            Txflags(tfNoRippleDirect),
            Ter{tecPATH_DRY});
        env.close();
        expectUnchanged();

        // Both succeed once alice is unfrozen
        setAliceFrozen(false);

        env(pay(alice, carol, XRP(1)),
            Sendmax(shares(1)),
            Path(~XRP),
            Txflags(tfNoRippleDirect));
        env.close();
        BEAST_EXPECT(shareBalance(bob) == bobShares + 1);

        env(pay(carol, alice, shares(1)),
            Sendmax(XRP(2)),
            Path(BookSpec{shares.raw()}),
            Txflags(tfNoRippleDirect));
        env.close();
        BEAST_EXPECT(shareBalance(alice) == aliceShares);
        BEAST_EXPECT(shareBalance(bob) == bobShares);
        BEAST_EXPECT(expectOffers(env, bob, 0));
    }

    void
    testShareDEXMiddleFrozen(
        jtx::Env& env,
        jtx::PrettyAsset const& asset,
        jtx::Account const& owner,
        jtx::Account const& alice,
        jtx::Account const& bob,
        jtx::Account const& carol,
        std::function<void(bool)> const& setAliceFrozen)
    {
        using namespace jtx;

        Vault const vault{env};
        auto [tx, keylet] = vault.create({.owner = owner, .asset = asset});
        env(tx);
        env.close();

        env(vault.deposit(
            {.depositor = alice, .id = keylet.key, .amount = asset(500)}));
        env(vault.deposit(
            {.depositor = bob, .id = keylet.key, .amount = asset(500)}));
        env.close();

        PrettyAsset const shares = MPTIssue(env.le(keylet)->at(sfShareMPTID));
        auto const shareMptID = shares.raw().get<MPTIssue>().getMptID();
        auto const shareBalance = [&](Account const& account) {
            auto const sle = env.le(keylet::mptoken(shareMptID, account));
            return sle ? sle->at(sfMPTAmount) : 0;
        };

        // alice gives the shares: XRP -> shares (alice) -> asset (bob)
        {
            env(offer(alice, XRP(1), shares(1)));
            env(offer(bob, shares(1), asset(1)));
            env.close();

            setAliceFrozen(true);

            auto const aliceShares = shareBalance(alice);
            auto const bobShares = shareBalance(bob);
            env(pay(carol, owner, asset(1)),
                Sendmax(XRP(1)),
                Path(BookSpec{shares.raw()}, BookSpec{asset.raw()}),
                Txflags(tfNoRippleDirect),
                Ter{tecPATH_PARTIAL});
            env.close();
            BEAST_EXPECT(shareBalance(alice) == aliceShares);
            BEAST_EXPECT(shareBalance(bob) == bobShares);

            setAliceFrozen(false);

            env(pay(carol, owner, asset(1)),
                Sendmax(XRP(1)),
                Path(BookSpec{shares.raw()}, BookSpec{asset.raw()}),
                Txflags(tfNoRippleDirect));
            env.close();
            BEAST_EXPECT(shareBalance(alice) == aliceShares - 1);
            BEAST_EXPECT(shareBalance(bob) == bobShares + 1);
            BEAST_EXPECT(expectOffers(env, alice, 0));
            BEAST_EXPECT(expectOffers(env, bob, 0));
        }

        // alice receives the shares: asset -> shares (bob) -> XRP (alice)
        {
            env(offer(bob, asset(1), shares(1)));
            env(offer(alice, shares(1), XRP(1)));
            env.close();

            setAliceFrozen(true);

            auto const aliceShares = shareBalance(alice);
            auto const bobShares = shareBalance(bob);
            env(pay(owner, carol, XRP(1)),
                Sendmax(asset(1)),
                Path(BookSpec{shares.raw()}, ~XRP),
                Txflags(tfNoRippleDirect),
                Ter{tecPATH_PARTIAL});
            env.close();
            BEAST_EXPECT(shareBalance(alice) == aliceShares);
            BEAST_EXPECT(shareBalance(bob) == bobShares);

            setAliceFrozen(false);

            env(pay(owner, carol, XRP(1)),
                Sendmax(asset(1)),
                Path(BookSpec{shares.raw()}, ~XRP),
                Txflags(tfNoRippleDirect));
            env.close();
            BEAST_EXPECT(shareBalance(alice) == aliceShares + 1);
            BEAST_EXPECT(shareBalance(bob) == bobShares - 1);
            BEAST_EXPECT(expectOffers(env, alice, 0));
            BEAST_EXPECT(expectOffers(env, bob, 0));
        }
    }

    void
    testMPTUnderlying()
    {
        testcase("MPT individually locked: vault share DEX inherits lock");
        using namespace jtx;

        Env env{*this, testableAmendments()};
        Account const issuer{"issuer"};
        Account const owner{"owner"};
        Account const alice{"alice"};
        Account const bob{"bob"};
        Account const carol{"carol"};
        env.fund(XRP(10'000), issuer, owner, alice, bob, carol);
        env.close();

        MPTTester asset{{
            .env = env,
            .issuer = issuer,
            .holders = {owner, alice, bob},
            .flags = tfMPTCanTransfer | tfMPTCanTrade | tfMPTCanLock,
        }};
        env(pay(issuer, owner, asset(1'000)));
        env(pay(issuer, alice, asset(2'000)));
        env(pay(issuer, bob, asset(2'000)));
        env.close();

        auto const setAliceFrozen = [&](bool frozen) {
            asset.set(
                {.holder = alice,
                 .flags = frozen ? tfMPTLock : tfMPTUnlock});
            env.close();
        };
        testShareDEXEndpointFrozen(
            env, asset, owner, alice, bob, carol, setAliceFrozen);
        testShareDEXMiddleFrozen(
            env, asset, owner, alice, bob, carol, setAliceFrozen);
    }

    void
    testIOUUnderlying()
    {
        testcase("IOU individually frozen: vault share DEX inherits freeze");
        using namespace jtx;

        Env env{*this, testableAmendments()};
        Account const issuer{"issuer"};
        Account const owner{"owner"};
        Account const alice{"alice"};
        Account const bob{"bob"};
        Account const carol{"carol"};
        env.fund(XRP(10'000), issuer, owner, alice, bob, carol);
        env.close();

        // Deliver the IOU from a book to a holder
        env(fset(issuer, asfDefaultRipple));
        PrettyAsset const asset = issuer["IOU"];
        env.trust(asset(10'000), owner, alice, bob);
        env(pay(issuer, owner, asset(1'000)));
        env(pay(issuer, alice, asset(2'000)));
        env(pay(issuer, bob, asset(2'000)));
        env.close();

        auto const setAliceFrozen = [&](bool frozen) {
            env(trust(
                issuer,
                asset(0),
                alice,
                frozen ? tfSetFreeze : tfClearFreeze));
            env.close();
        };
        testShareDEXEndpointFrozen(
            env, asset, owner, alice, bob, carol, setAliceFrozen);
        testShareDEXMiddleFrozen(
            env, asset, owner, alice, bob, carol, setAliceFrozen);
    }

    void
    testDirectShareFrozen()
    {
        // A direct vault-share payment under an inherited lock is refused and
        // no share moves.
        testcase("Direct vault-share payment under inherited lock");
        using namespace jtx;

        Env env{*this, testableAmendments()};
        Account const issuer{"issuer"};
        Account const owner{"owner"};
        Account const alice{"alice"};
        Account const bob{"bob"};
        env.fund(XRP(10'000), issuer, owner, alice, bob);
        env.close();

        MPTTester asset{{
            .env = env,
            .issuer = issuer,
            .holders = {owner, alice, bob},
            .flags = tfMPTCanTransfer | tfMPTCanTrade | tfMPTCanLock,
        }};
        env(pay(issuer, owner, asset(1'000)));
        env(pay(issuer, alice, asset(2'000)));
        env(pay(issuer, bob, asset(2'000)));
        env.close();

        Vault const vault{env};
        auto [tx, keylet] = vault.create({.owner = owner, .asset = asset});
        env(tx);
        env.close();

        env(vault.deposit(
            {.depositor = alice, .id = keylet.key, .amount = asset(500)}));
        env(vault.deposit(
            {.depositor = bob, .id = keylet.key, .amount = asset(500)}));
        env.close();

        PrettyAsset const shares = MPTIssue(env.le(keylet)->at(sfShareMPTID));
        auto const shareMptID = shares.raw().get<MPTIssue>().getMptID();
        auto const shareBalance = [&](Account const& account) {
            auto const sle = env.le(keylet::mptoken(shareMptID, account));
            return sle ? sle->at(sfMPTAmount) : 0;
        };

        // alice moves one share to bob while unfrozen
        env(pay(alice, bob, shares(1)));
        env.close();
        BEAST_EXPECT(shareBalance(alice) == 499);
        BEAST_EXPECT(shareBalance(bob) == 501);

        // Freeze alice on the underlying; the direct share payment is now
        // refused with tecPATH_DRY or tecLOCKED, and the balances are
        // unchanged.
        asset.set({.holder = alice, .flags = tfMPTLock});
        env.close();
        env(pay(alice, bob, shares(1)), Ter{std::ignore});
        {
            auto const t = env.ter();
            BEAST_EXPECT(t == tecPATH_DRY || t == tecLOCKED);
        }
        env.close();
        BEAST_EXPECT(shareBalance(alice) == 499);
        BEAST_EXPECT(shareBalance(bob) == 501);
    }

    void
    run() override
    {
        testMPTUnderlying();
        testIOUUnderlying();
        testDirectShareFrozen();
    }
};

BEAST_DEFINE_TESTSUITE_PRIO(MPTPaymentInvariantsVaultShare, app, xrpl, 1);

}  // namespace xrpl::test
