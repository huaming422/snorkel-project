## Task

We're testing the MPT payment work that sits behind the MPTokensV2 amendment, and four kinds of payment are coming out wrong.

First, clawing back a tiny amount from a trust line, say a few millionths of a USD from a balance over a billion, logs a fatal "Invariant failed: trustline clawback balance change is invalid".
The clawback itself was applied correctly, but with MPTokensV2 on it gets thrown out as tecINVARIANT_FAILED.
It should just succeed, with no invariant message, whether the amendment is on or off.

Second, some cross-currency payments through the DEX run into an offer whose amounts overflow partway through crossing, and they don't fail cleanly.
With MPTokensV2 on, that payment should end as tecPATH_PARTIAL, with no balances moved and the offer still sitting on the book.
With the amendment off, it already ends in tecINTERNAL, and that should stay, again with nothing moved and the offer left alone.

Third, an MPT issuer can pay along a DEX path that comes back around to its own MPT, like MPT -> XRP -> MPT.
A holder who tries the same kind of route already gets temBAD_PATH_LOOP, and the issuer should get that same rejection.
The issuer should still be able to pay with some other asset and take its own MPT offer on the way.

Last, vault shares are meant to follow freezes and locks on the vault's underlying asset, but on the DEX they don't.
A holder who is frozen or locked on the underlying, whether it's an MPT or an IOU, can still sell the vault's shares over the DEX, and someone else can buy shares over the DEX and have them delivered to that holder.
Nothing stops either one until a last-resort check at the very end of the transaction, which throws it out as tecINVARIANT_FAILED.
Both should be refused up front with tecPATH_DRY, before anything moves, just as a holder locked on the shares themselves can't move them.
Two related cases already behave and should keep doing so.
A route that only passes through an offer the frozen holder owns ends in tecPATH_PARTIAL with nothing moved.
And when the underlying is an MPT the holder is locked on, a direct share payment from them is refused (tecLOCKED or tecPATH_DRY are both fine there).
Once the holder is unfrozen, those DEX payments should go through again.

Please don't make any of this go away by loosening or switching off the safety invariants.
A clawback that really takes the wrong amount off a balance still has to be rejected.
MPTokensV2 isn't live on the network yet, so anything that needs to behave differently with it on has to stay behind the amendment.
