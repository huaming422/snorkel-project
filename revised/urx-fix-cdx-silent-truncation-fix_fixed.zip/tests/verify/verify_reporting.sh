#!/usr/bin/env bash
# Behavioral verifier - what a user running urx sees after an incomplete crawl.
#
# Builds the urx binary and runs it the way a user would, with one archive
# provider selected per crawl. A local HTTP proxy stands in for arquivo.pt,
# web.archive.org and index.commoncrawl.org: urx reaches it through --proxy and
# --insecure, and the proxy answers each request from a fixed per-domain
# fixture. The checks read the run's stdout and stderr only, so the warning may
# come from any part of the program and may use any wording that says the
# result is incomplete. Graded on exit code.
set -uo pipefail

CRATE_DIR="${CRATE_DIR:-$PWD}"
[ -f "$CRATE_DIR/Cargo.toml" ] || CRATE_DIR="/repo/urx"
cd "$CRATE_DIR" || { echo "verify_reporting: cannot cd to crate dir"; exit 2; }

PY="$(command -v python3 || true)"
[ -n "$PY" ] || PY=/opt/tooling/venv/bin/python
[ -x "$PY" ] || { echo "verify_reporting: no python interpreter found"; exit 2; }
command -v openssl >/dev/null || { echo "verify_reporting: openssl not found"; exit 2; }

if ! cargo build --bin urx --offline >/tmp/verify_reporting_build.log 2>&1; then
    tail -40 /tmp/verify_reporting_build.log
    echo "verify_reporting: FAIL - urx does not build"
    exit 1
fi
BIN="${CARGO_TARGET_DIR:-$CRATE_DIR/target}/debug/urx"
[ -x "$BIN" ] || { echo "verify_reporting: built binary not found at $BIN"; exit 2; }

WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

cat > "$WORK/drive.py" <<'PYEOF'
import os
import re
import socket
import ssl
import subprocess
import sys
import tempfile
import threading
import urllib.parse

BIN, WORK = sys.argv[1], sys.argv[2]

cert, key = os.path.join(WORK, "cert.pem"), os.path.join(WORK, "key.pem")
subprocess.run(
    ["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-days", "2",
     "-subj", "/CN=arquivo.pt", "-keyout", key, "-out", cert],
    check=True, capture_output=True,
)
TLS = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
TLS.load_cert_chain(cert, key)


def capped(host):
    # 100_000 rows, the most arquivo.pt returns for one query, that collapse
    # to 1_000 distinct URLs.
    return "".join('{"url":"http://%s/p%d"}\n' % (host, i % 1000) for i in range(100_000))


def short(host):
    return '{"url":"http://%s/a"}\n{"url":"http://%s/b"}\n' % (host, host)


# Per-crawl fixtures, keyed by archive and domain. Arquivo entries are a body
# served for every request. Common Crawl entries map a page number to a body,
# or to None for a page that answers 503. Wayback entries map the resume key
# a request carries ("" for the first request) to the page served for it.
FIXTURES = {"arquivo": {}, "cc": {}, "wayback": {}}


def read_head(sock, buf):
    while b"\r\n\r\n" not in buf:
        chunk = sock.recv(65536)
        if not chunk:
            return None, b""
        buf += chunk
    head, rest = buf.split(b"\r\n\r\n", 1)
    return head.decode("latin-1"), rest


def answer(target):
    parts = urllib.parse.urlsplit(target)
    path = parts.path.rstrip("/")
    query = urllib.parse.parse_qs(parts.query)
    host = query.get("url", [""])[0].split("/", 1)[0]
    if host.startswith("*."):
        host = host[2:]
    if path == "/wayback/cdx":
        return 200, FIXTURES["arquivo"].get(host, "").encode()
    if path == "/collinfo.json":
        return 200, b'[{"id":"CC-MAIN-2026-17"}]'
    if path == "/CC-MAIN-2026-17-index":
        pages = FIXTURES["cc"].get(host, {})
        if "showNumPages" in query:
            return 200, ('{"pages":%d}' % len(pages)).encode()
        body = pages.get(int(query.get("page", ["0"])[0]), "")
        return (503, b"") if body is None else (200, body.encode())
    if path == "/cdx/search/cdx":
        cursor = FIXTURES["wayback"].get(host, {})
        return 200, cursor.get(query.get("resumeKey", [""])[0], "").encode()
    return 404, b""


def serve_http(sock, buf=b""):
    while True:
        head, buf = read_head(sock, buf)
        if head is None:
            return
        target = head.split("\r\n", 1)[0].split(" ")[1]
        status, body = answer(target)
        reason = {200: "OK", 404: "Not Found"}.get(status, "Service Unavailable")
        sock.sendall(
            b"HTTP/1.1 %d %s\r\nContent-Type: text/plain\r\nContent-Length: %d\r\n\r\n"
            % (status, reason.encode(), len(body)) + body
        )


def handle(conn):
    try:
        head, rest = read_head(conn, b"")
        if head is None:
            return
        method, target = head.split("\r\n", 1)[0].split(" ")[:2]
        if method == "CONNECT":
            conn.sendall(b"HTTP/1.1 200 Connection established\r\n\r\n")
            serve_http(TLS.wrap_socket(conn, server_side=True))
        else:
            status, body = answer(target)
            conn.sendall(
                b"HTTP/1.1 %d X\r\nContent-Length: %d\r\nConnection: close\r\n\r\n"
                % (status, len(body)) + body
            )
    except (OSError, ssl.SSLError):
        pass
    finally:
        conn.close()


listener = socket.socket()
listener.bind(("127.0.0.1", 0))
listener.listen(64)
PORT = listener.getsockname()[1]


def accept_loop():
    while True:
        conn, _ = listener.accept()
        threading.Thread(target=handle, args=(conn,), daemon=True).start()


threading.Thread(target=accept_loop, daemon=True).start()

# A line that tells the user the result may be incomplete, in any wording.
NOTICE = re.compile(
    r"warn|incomplete|partial|truncat|missing|capped|cut off|not complete|may be|fewer",
    re.I,
)

env = {k: v for k, v in os.environ.items() if "proxy" not in k.lower()}
env["NO_COLOR"] = "1"


def crawl(domains, fixtures, extra=(), provider="arquivo"):
    for archive in FIXTURES:
        FIXTURES[archive] = dict(fixtures) if archive == provider else {}
    cmd = [BIN, *domains, "--providers", provider, "--proxy",
           "http://127.0.0.1:%d" % PORT, "--insecure", *extra]
    # A fresh HOME per crawl, so each run starts with an empty result cache.
    run_env = dict(env, HOME=tempfile.mkdtemp(dir=WORK))
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=240,
                       stdin=subprocess.DEVNULL, env=run_env)
    urls = {l.strip() for l in p.stdout.splitlines() if l.strip().startswith("http")}
    notes = [l for l in (p.stdout + "\n" + p.stderr).splitlines()
             if l.strip() and not l.strip().startswith("http") and NOTICE.search(l)]
    return p, urls, notes


def show(p):
    return "exit %s\n--- stdout (head)\n%s\n--- stderr\n%s" % (
        p.returncode, "\n".join(p.stdout.splitlines()[:5]), p.stderr)


def urls_for(host, names):
    return {"http://%s/%s" % (host, n) for n in names}


PAGES = ["p%d" % i for i in range(1000)]
results = []


def case(name, ok, p, why):
    results.append(ok)
    print("CASE %s ... %s" % (name, "ok" if ok else "FAILED"))
    if not ok:
        print("  " + why)
        print(show(p))


# Fixture: example.com returns the 100_000-row page on every request.
# Expected: the 1_000 URLs are listed and the user is told the result may be
# incomplete, with no --verbose or --stats.
p, urls, notes = crawl(["example.com"], {"example.com": capped("example.com")})
case("incomplete_crawl_warns", urls == urls_for("example.com", PAGES) and bool(notes), p,
     "expected the 1000 URLs and a notice that the result may be incomplete")

# Fixture: example.org returns two rows. Expected: exit 0, both URLs listed
# and nothing that reads as an incomplete-result notice.
p, urls, notes = crawl(["example.org"], {"example.org": short("example.org")})
case("complete_crawl_is_quiet", p.returncode == 0 and urls == urls_for("example.org", "ab")
     and not notes, p, "expected exit 0, the two URLs and no notice; notices: %r" % notes)

# Fixture: example.net returns the capped page, run with --verbose.
# Expected: the URLs are listed and the notice is printed.
p, urls, notes = crawl(["example.net"], {"example.net": capped("example.net")}, ["--verbose"])
case("incomplete_crawl_warns_verbose", urls == urls_for("example.net", PAGES) and bool(notes), p,
     "expected the 1000 URLs and a notice under --verbose")

# Fixture: example.org returns the capped page, run with --stream.
# Expected: the URLs are listed and the notice is printed.
p, urls, notes = crawl(["example.org"], {"example.org": capped("example.org")}, ["--stream"])
case("incomplete_crawl_warns_stream", urls == urls_for("example.org", PAGES) and bool(notes), p,
     "expected the 1000 URLs and a notice under --stream")

# Fixture: two domains in one run, example.com capped and example.org complete.
# Expected: all URLs from both are listed and the notice is printed.
p, urls, notes = crawl(["example.com", "example.org"],
                       {"example.com": capped("example.com"), "example.org": short("example.org")})
case("incomplete_domain_among_two_warns",
     urls == urls_for("example.com", PAGES) | urls_for("example.org", "ab") and bool(notes), p,
     "expected the URLs of both domains and a notice")

# Fixture: two domains in one run, both complete. Expected: exit 0, all four
# URLs listed and no notice.
p, urls, notes = crawl(["example.org", "example.net"],
                       {"example.org": short("example.org"), "example.net": short("example.net")})
case("two_complete_domains_are_quiet", p.returncode == 0
     and urls == urls_for("example.org", "ab") | urls_for("example.net", "ab") and not notes, p,
     "expected exit 0, the four URLs and no notice; notices: %r" % notes)


def cc_page(host, name):
    return '{"url":"http://%s/%s"}\n' % (host, name)


# Fixture: Common Crawl reports three pages for example.org, and page 1 answers
# 503 on every request. Expected: the URLs from pages 0 and 2 are listed and
# the notice is printed.
p, urls, notes = crawl(["example.org"], {"example.org": {
    0: cc_page("example.org", "c0"), 1: None, 2: cc_page("example.org", "c2")}}, provider="cc")
case("commoncrawl_gap_warns", urls == urls_for("example.org", ["c0", "c2"]) and bool(notes), p,
     "expected the page 0 and page 2 URLs and a notice")

# Fixture: Common Crawl reports two pages for example.net and both answer.
# Expected: exit 0, both URLs listed and no notice.
p, urls, notes = crawl(["example.net"], {"example.net": {
    0: cc_page("example.net", "c0"), 1: cc_page("example.net", "c1")}}, provider="cc")
case("commoncrawl_complete_is_quiet", p.returncode == 0
     and urls == urls_for("example.net", ["c0", "c1"]) and not notes, p,
     "expected exit 0, the two URLs and no notice; notices: %r" % notes)


def wb_page(host, name, key=None):
    return "http://%s/%s\n" % (host, name) + ("\n%s\n" % key if key else "")


# Fixture: the first Wayback page for example.net hands out key KA, KA hands
# out KB, and KB hands out KA again. Expected: the three URLs are listed and
# the notice is printed.
p, urls, notes = crawl(["example.net"], {"example.net": {
    "": wb_page("example.net", "w0", "KA"), "KA": wb_page("example.net", "wa", "KB"),
    "KB": wb_page("example.net", "wb", "KA")}}, provider="wayback")
case("wayback_cycle_warns", urls == urls_for("example.net", ["w0", "wa", "wb"]) and bool(notes),
     p, "expected the three URLs and a notice")

# Fixture: the first Wayback page for example.com hands out key KA, and KA's
# page has no further key. Expected: exit 0, both URLs listed and no notice.
p, urls, notes = crawl(["example.com"], {"example.com": {
    "": wb_page("example.com", "w0", "KA"), "KA": wb_page("example.com", "wa")}},
    provider="wayback")
case("wayback_complete_is_quiet", p.returncode == 0
     and urls == urls_for("example.com", ["w0", "wa"]) and not notes, p,
     "expected exit 0, the two URLs and no notice; notices: %r" % notes)

print("verify_reporting: %d of %d cases passed" % (sum(results), len(results)))
sys.exit(0 if all(results) else 1)
PYEOF

"$PY" -I "$WORK/drive.py" "$BIN" "$WORK"
RC=$?
if [ "$RC" -ne 0 ]; then
    echo "verify_reporting: FAIL"
    exit 1
fi
echo "verify_reporting: PASS (10 cases)"
exit 0
