#!/usr/bin/env bash
# Behavioral verifier - an incomplete crawl reaches what the user sees.
#
# Same in-crate mechanism as the provider verifiers, applied one layer up:
# append a cfg(test) module to the runner source and drive a real provider
# through process_domains against a mock archive. The crawl runs in a child
# process (the test binary re-invoked on one test) so its stderr can be read
# back: the warning the runner prints and the --stats table. The source is
# restored on exit. Graded on exit code.
set -uo pipefail

CRATE_DIR="${CRATE_DIR:-$PWD}"
[ -f "$CRATE_DIR/Cargo.toml" ] || CRATE_DIR="/repo/urx"
cd "$CRATE_DIR" || { echo "verify_reporting: cannot cd to crate dir"; exit 2; }

SRC="src/runner/mod.rs"
[ -f "$SRC" ] || { echo "verify_reporting: $SRC not found under $CRATE_DIR"; exit 2; }

BAK="$(mktemp)"
cp "$SRC" "$BAK"
trap 'cp -f "$BAK" "$SRC"; rm -f "$BAK"' EXIT

printf '\n' >> "$SRC"
cat >> "$SRC" <<'RUSTEOF'
#[cfg(test)]
mod verify_reporting {
    // Uses only pre-existing pieces: the Arquivo mock seam (with_base_url),
    // build_test_args, the runner's entry point and the --stats printer.
    use super::*;
    use crate::providers::ArquivoProvider;
    use crate::test_support::build_test_args;
    use std::process::Command;

    const CHILD_ENV: &str = "URX_VERIFY_REPORTING_CHILD";

    // Runs one Arquivo crawl of example.com through the runner with verbose
    // output on and progress bars off, then prints the --stats table.
    async fn crawl_and_report(body: String) {
        let mut server = mockito::Server::new_async().await;
        let _mock = server
            .mock("GET", "/wayback/cdx")
            .match_query(mockito::Matcher::Any)
            .with_status(200)
            .with_body(body)
            .expect_at_least(1)
            .create_async()
            .await;

        let mut provider = ArquivoProvider::new();
        provider.with_base_url(server.url());
        let providers: Vec<Box<dyn Provider>> = vec![Box::new(provider)];
        let names = vec!["Arquivo".to_string()];

        let mut args = build_test_args();
        args.silent = false;
        args.verbose = true;
        args.no_progress = true;

        let result = process_domains(
            vec!["example.com".to_string()],
            &args,
            &ProgressManager::new(true),
            &providers,
            &names,
            None,
        )
        .await;
        crate::app::report::print_provider_stats(&result.stats);
    }

    // Child entry points. They do nothing unless the parent test selects them.
    #[tokio::test]
    async fn child_capped_crawl() {
        if std::env::var(CHILD_ENV).as_deref() != Ok("capped") {
            return;
        }
        let mut body = String::with_capacity(4_000_000);
        for i in 0..100_000usize {
            body.push_str(&format!("{{\"url\":\"http://example.com/p{}\"}}\n", i % 1000));
        }
        crawl_and_report(body).await;
    }

    #[tokio::test]
    async fn child_complete_crawl() {
        if std::env::var(CHILD_ENV).as_deref() != Ok("complete") {
            return;
        }
        crawl_and_report(
            "{\"url\":\"http://example.com/a\"}\n{\"url\":\"http://example.com/b\"}\n".to_string(),
        )
        .await;
    }

    // Re-runs this test binary on a single child test and returns its stderr.
    fn run_child(test: &str, mode: &str) -> String {
        let out = Command::new(std::env::current_exe().expect("test binary path"))
            .args([test, "--exact", "--nocapture", "--test-threads=1"])
            .env(CHILD_ENV, mode)
            .output()
            .expect("child run starts");
        let stderr = String::from_utf8_lossy(&out.stderr).into_owned();
        assert!(
            out.status.success(),
            "child run failed\nstdout:\n{}\nstderr:\n{stderr}",
            String::from_utf8_lossy(&out.stdout)
        );
        stderr
    }

    // The Arquivo row of the --stats table as (urls, partial, errors).
    fn stats_row(stderr: &str) -> (usize, usize, usize) {
        let line = stderr
            .lines()
            .map(str::trim)
            .find(|l| l.starts_with("Arquivo"))
            .unwrap_or_else(|| panic!("no Arquivo row in the stats table:\n{stderr}"));
        let cols: Vec<usize> = line
            .split_whitespace()
            .skip(1)
            .take(3)
            .map(|c| c.parse().expect("numeric stats column"))
            .collect();
        (cols[0], cols[1], cols[2])
    }

    // A stderr line that tells the user the example.com result is partial.
    fn partial_warning(stderr: &str) -> Option<&str> {
        stderr.lines().find(|l| {
            let l = l.to_lowercase();
            l.contains("example.com") && l.contains("partial")
        })
    }

    // Fixture: every request returns the same 100_000 rows, which collapse to
    // 1_000 distinct URLs. Expected: the stats row shows 1000 URLs, one partial
    // fetch and no error, and stderr carries a warning that the example.com
    // result is partial.
    #[test]
    fn verify_incomplete_crawl_warns_the_user() {
        let stderr = run_child("runner::verify_reporting::child_capped_crawl", "capped");
        assert_eq!(
            stats_row(&stderr),
            (1000, 1, 0),
            "stats row as (urls, partial, errors)\n{stderr}"
        );
        assert!(
            partial_warning(&stderr).is_some(),
            "the user must see a warning that the example.com result is partial\n{stderr}"
        );
    }

    // Fixture: every request returns the same two rows. Expected: the stats row
    // shows 2 URLs, no partial fetch and no error, and stderr carries no
    // warning.
    #[test]
    fn verify_complete_crawl_prints_no_warning() {
        let stderr = run_child("runner::verify_reporting::child_complete_crawl", "complete");
        assert_eq!(
            stats_row(&stderr),
            (2, 0, 0),
            "stats row as (urls, partial, errors)\n{stderr}"
        );
        assert!(
            partial_warning(&stderr).is_none()
                && !stderr.to_lowercase().contains("warning"),
            "a complete crawl must not print a warning\n{stderr}"
        );
    }
}
RUSTEOF

LOG="$(mktemp)"
cargo test --bin urx --offline verify_reporting -- --test-threads=1 --nocapture >"$LOG" 2>&1
RC=$?
cat "$LOG"
EXPECTED=4
if [ "$RC" -ne 0 ]; then
    echo "verify_reporting: FAIL - cargo test exited $RC"
    rm -f "$LOG"
    exit 1
fi
if ! grep -qE "test result: ok\. ${EXPECTED} passed; 0 failed" "$LOG"; then
    echo "verify_reporting: FAIL - expected exactly ${EXPECTED} passing tests; summary:"
    grep -E "test result:" "$LOG" || echo "  (no test-result summary - zero tests ran?)"
    rm -f "$LOG"
    exit 1
fi
echo "verify_reporting: PASS (${EXPECTED} tests)"
rm -f "$LOG"
exit 0
