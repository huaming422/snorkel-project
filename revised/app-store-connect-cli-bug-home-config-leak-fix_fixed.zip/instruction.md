## Task

We keep `asc` runs away from stored API credentials (CI jobs, agent sessions, quick experiments) by pointing `HOME` at a throwaway directory.
That stops working as soon as the run starts from somewhere inside your real home directory.
During release prep someone ran a local build with a scratch `HOME` from a checkout under their home, and it still read their real stored config.
About 40 authenticated App Store Connect calls went out under their default profile, and nothing on screen hinted that `HOME` had been ignored.

You can see it from any directory under your home, the home directory itself included:

```
cd ~/src/some-app
HOME=$(mktemp -d) ASC_BYPASS_KEYCHAIN=1 asc auth status --output json
```

`storageLocation` comes back as your real `~/.asc/config.json`, the exit code is 0, and stderr is empty.
`HOME=/nonexistent`, which is how a lot of service accounts are set up, gives the same result.

Saving has the same hole.
From a scratch folder under the home, with no git checkout around it, this wrote the new key into the real `~/.asc/config.json`:

```
cd ~/tmp/ci-sandbox
HOME=$(mktemp -d) asc auth login --bypass-keychain --local --skip-validation --name ci --key-id ABC123 --issuer-id <issuer-uuid> --private-key ./AuthKey.p8
```

It printed `Storing credentials in config file at /home/<you>/.asc/config.json`, exited 0 and said nothing on stderr.
`asc ads auth login --local` and `asc storekit auth login --local` do the same.
`asc auth init --local` goes one step further and creates `~/.asc/config.json` when your home only has the `.asc` folder that asc keeps its telemetry and cache files in.

Please don't change which config file gets read or written here.
The lookup order is documented and people may rely on it, so changing it has to go through a proper deprecation later.
For now `asc` should say what is going on: print a warning on stderr that names the config file and the `HOME` it was given.
Stdout and the exit code stay as they are, so `--output json` is still clean JSON.
Print it once per run, not over and over.
This isn't about `auth status` in particular.
Any command that reads the config should warn the same way, the ones that call App Store Connect included, and so should the four `--local` saves above.

The warning is for one case only, your account's own config file being read or written while `HOME` points somewhere else.
When `HOME` is your real home, or `ASC_CONFIG_PATH` picks the file, nothing surprising is going on.
A project's own `.asc/config.json` somewhere below your home is the lookup doing its job, so that stays quiet too.
The same goes for a `--local` save that lands in a project below your home, either a git checkout or a folder with its own `.asc`.
