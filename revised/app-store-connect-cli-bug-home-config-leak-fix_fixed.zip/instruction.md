## Task

We keep `asc` runs away from stored API credentials (CI jobs, agent sessions, quick experiments) by pointing `HOME` at a throwaway directory.
That stops working as soon as the run starts from somewhere inside your real home directory.
During release prep someone ran a local build with a scratch `HOME` from a checkout under their home, and it still read their real stored config.
About 40 authenticated App Store Connect calls went out under their default profile, and nothing on screen hinted that `HOME` had been ignored.

You can see it from any directory under your home, the home directory itself included:

```
cd ~/src/some-app
HOME=$(mktemp -d) ASC_BYPASS_KEYCHAIN=1 asc auth status --output json
```

`storageLocation` comes back as your real `~/.asc/config.json`, the exit code is 0, and stderr is empty.

Please don't change which config file gets picked here.
The lookup order is documented and people may rely on it, so changing it has to go through a proper deprecation later.
For now `asc` should say what is going on: print a warning on stderr that names the config file it is using and the `HOME` it was given.
Stdout and the exit code stay as they are, so `--output json` is still clean JSON.
Print it once per run, not over and over.
This isn't about `auth status` in particular, since any command that reads the config, the ones that call App Store Connect included, should warn the same way.

The warning is for one case only, your account's own stored config ending up in use while `HOME` points somewhere else.
When `HOME` is your real home, or `ASC_CONFIG_PATH` picks the file, nothing surprising is going on.
A project's own `.asc/config.json` somewhere below your home is the lookup doing its job, so that stays quiet too.
