"""Black-box checks for the scratch-HOME config warning.

These tests drive the built ``asc`` binary as a subprocess and never import
repository Go packages:

  * build ``asc`` from the source tree;
  * read the running OS account's home directory from the passwd database
    (``pwd.getpwuid``), independent of ``$HOME``;
  * plant a ``.asc/config.json`` inside that account home;
  * run ``asc`` commands that read the config with ``HOME`` set to a scratch
    directory and ``ASC_BYPASS_KEYCHAIN=1`` (so the config file is read rather
    than the system keychain), capturing stdout and stderr separately.

Interface: the pre-existing ``asc auth status`` and ``asc auth doctor``
commands. Under ``ASC_BYPASS_KEYCHAIN=1`` the status JSON ``.storageLocation``
and the doctor JSON report name the config path in use on stdout; the
scratch-HOME warning is read from stderr.

Checked behavior:
  * Through ``auth status`` and ``auth doctor``, from the account home or any
    directory below it, with a scratch HOME: the account's own config is still
    the one in use, stdout is still JSON (``auth status`` also exits 0), and
    stderr carries one warning naming that config path and the scratch HOME.
    No stderr line is printed twice.
  * ``auth status`` prints the same JSON, and ``auth doctor`` prints the same
    JSON and exits the same way, as the same run with HOME set to the account
    home.
  * ``apps list`` (App Store Connect credentials, read before any request),
    ``ads auth status`` and ``storekit auth status`` (Apple Ads and StoreKit
    credentials, read offline) also warn once with that config path and the
    scratch HOME, and ``builds count`` (default app ID read from the config)
    warns with them too.
  * The same holds for a second OS account run as that account, with its own
    home and config.
  * A HOME that names a directory which does not exist gets the same warning
    from ``auth status`` and ``auth doctor``.
  * No warning when HOME is the account home, when ``ASC_CONFIG_PATH`` is set
    (to a file elsewhere or to the account's own config),
    when the working directory is outside the account home, or when a project
    ``.asc/config.json`` below the account home is the one in use.
  * Saving with ``--local`` (``auth init``, ``auth login``, ``ads auth login``,
    ``storekit auth login``) from the account home or below it, with a scratch
    or missing HOME, still writes the account home's ``.asc/config.json``
    (``auth init`` creates it when only the ``.asc`` folder exists), exits 0,
    prints the same stdout as with HOME set to the account home, and warns
    once on stderr with that path and the HOME. No warning when HOME is the
    account home, or when the save lands in a project below the account home
    (a git checkout, or a folder with its own ``.asc``).
"""

from __future__ import annotations

import json
import os
import pwd
import shutil
import subprocess
import tempfile
import uuid
from pathlib import Path

import pytest

REPO_DIR = Path(f"/repo/{os.environ.get('REPO_NAME', 'App-Store-Connect-CLI')}")

# Documented, pre-existing config layout (config.go: configDirName/configFileName).
CONFIG_SUBDIR = ".asc"
CONFIG_FILENAME = "config.json"

RUN_TIMEOUT = 60
BUILD_TIMEOUT = 600


# --------------------------------------------------------------------------- #
# Build + scene fixtures
# --------------------------------------------------------------------------- #
@pytest.fixture(scope="module")
def asc_binary(tmp_path_factory: pytest.TempPathFactory) -> str:
    """Build the source tree into a throwaway ``asc`` binary.

    CGO stays enabled, as in a normal build of the CLI.
    """
    out_dir = tmp_path_factory.mktemp("asc-bin")
    binary = out_dir / "asc"
    env = dict(os.environ)
    env["CGO_ENABLED"] = "1"
    proc = subprocess.run(
        ["go", "build", "-o", str(binary), "."],
        cwd=str(REPO_DIR),
        env=env,
        capture_output=True,
        text=True,
        timeout=BUILD_TIMEOUT,
        check=False,
    )
    if proc.returncode != 0 or not binary.exists():
        pytest.fail(
            "building the asc binary failed "
            f"(exit {proc.returncode}).\n--- stderr ---\n{proc.stderr[-3000:]}"
        )
    return str(binary)


@pytest.fixture(scope="module")
def account_home() -> str:
    """The running account's home directory, independent of ``$HOME``."""
    return pwd.getpwuid(os.getuid()).pw_dir


@pytest.fixture
def scene(account_home: str):
    """Plant an account-home config and a separate scratch HOME.

    Records whether the account config pre-existed and restores the tree on
    teardown so a real stored config (if any) is left untouched.
    """
    acct_asc = os.path.join(account_home, CONFIG_SUBDIR)
    acct_config = os.path.join(acct_asc, CONFIG_FILENAME)

    created_dir = not os.path.isdir(acct_asc)
    preexisting = os.path.isfile(acct_config)
    backup = None
    if preexisting:
        backup = acct_config + ".verify-backup"
        shutil.copy2(acct_config, backup)
    else:
        os.makedirs(acct_asc, exist_ok=True)
        with open(acct_config, "w", encoding="utf-8") as fh:
            fh.write("{}")

    scratch_root = tempfile.mkdtemp(prefix="asc-scratch-")  # no "home" token in path
    missing_root = tempfile.mkdtemp(prefix="asc-gone-")
    missing_home = os.path.join(missing_root, f"nonexistent-{uuid.uuid4().hex[:8]}")
    nested_root = tempfile.mkdtemp(prefix="asc-verify-work-", dir=account_home)
    nested_cwd = os.path.join(nested_root, "app", "src")
    os.makedirs(nested_cwd, exist_ok=True)

    class Scene:
        pass

    s = Scene()
    s.account_home = account_home
    s.account_config = acct_config
    s.scratch_home = scratch_root
    s.missing_home = missing_home
    s.nested_cwd = nested_cwd

    try:
        yield s
    finally:
        if preexisting and backup is not None:
            shutil.copy2(backup, acct_config)
            os.remove(backup)
        else:
            try:
                os.remove(acct_config)
            except FileNotFoundError:
                pass
            if created_dir:
                shutil.rmtree(acct_asc, ignore_errors=True)
        shutil.rmtree(scratch_root, ignore_errors=True)
        shutil.rmtree(missing_root, ignore_errors=True)
        shutil.rmtree(nested_root, ignore_errors=True)


def _run_status(
    binary: str,
    cwd: str,
    home: str,
    config_path: str | None = None,
    args: tuple[str, ...] = ("auth", "status", "--output", "json"),
    extra_env: dict[str, str] | None = None,
):
    """Run an ``asc`` command (``auth status --output json`` by default).

    Starts from a clean ASC_* environment: keychain bypassed (so the config file
    path is exercised), ``HOME`` overridden, and ``ASC_CONFIG_PATH`` set only
    when a case asks for it. Returns (stdout, stderr, returncode).
    """
    env = {
        "PATH": os.environ.get("PATH", "/usr/local/go/bin:/usr/bin:/bin"),
        "HOME": home,
        "ASC_BYPASS_KEYCHAIN": "1",
    }
    if config_path is not None:
        env["ASC_CONFIG_PATH"] = config_path
    if extra_env:
        env.update(extra_env)
    proc = subprocess.run(
        [binary, *args],
        cwd=cwd,
        env=env,
        capture_output=True,
        text=True,
        timeout=RUN_TIMEOUT,
        check=False,
    )
    return proc.stdout, proc.stderr, proc.returncode


def _warning_lines(stderr: str) -> list[str]:
    """Lines that read as the account-home isolation warning.

    Wording-independent: a stderr line that either reads as a warning
    ("warning" anywhere) or mentions a config file and HOME together. In
    ``--output json`` mode the success path of ``auth status`` writes nothing
    else to stderr, so any such line in a quiet scenario is an unwanted warning,
    whatever its phrasing.
    """
    out = []
    for line in stderr.splitlines():
        low = line.lower()
        if "warning" in low or (CONFIG_FILENAME in low and "home" in low):
            out.append(line)
    return out


# Working directories inside the account home: the home itself and a nested
# project directory below it.
LEAK_CWDS = ["account_home", "nested_cwd"]

# Two commands that read the config, run in every scene. ``auth status`` exits
# 0 in every scene here; ``auth doctor`` exits by its own findings, so its exit
# code is compared with a run under the account HOME instead of fixed. Both
# print JSON on stdout with ``--output json``.
COMMANDS = {
    "status": (("auth", "status", "--output", "json"), True),
    "doctor": (("auth", "doctor", "--output", "json"), False),
}


def _run_cmd(binary: str, command: str, cwd: str, home: str, config_path: str | None = None):
    args, zero_exit = COMMANDS[command]
    stdout, stderr, rc = _run_status(binary, cwd, home, config_path=config_path, args=args)
    if zero_exit:
        assert rc == 0, f"asc {' '.join(args)} exited {rc}; stderr:\n{stderr[-1500:]}"
    try:
        json.loads(stdout)
    except json.JSONDecodeError as exc:
        pytest.fail(
            f"asc {' '.join(args)} did not print JSON on stdout: {exc}\n"
            f"--- stdout ---\n{stdout[-1500:]}\n--- stderr ---\n{stderr[-1500:]}"
        )
    return stdout, stderr, rc


# --------------------------------------------------------------------------- #
# Scratch HOME, working directory inside the account home: warning on stderr
# --------------------------------------------------------------------------- #
# HOME kinds that point away from the account home: an existing scratch
# directory, and a path that does not exist (like ``/nonexistent``).
HOME_KINDS = ["scratch", "missing"]


def _home_for(scene, home_kind: str) -> str:
    return scene.scratch_home if home_kind == "scratch" else scene.missing_home


@pytest.mark.parametrize("home_kind", HOME_KINDS)
@pytest.mark.parametrize("command", sorted(COMMANDS))
@pytest.mark.parametrize("cwd_attr", LEAK_CWDS)
def test_warns_on_account_home_leak(
    asc_binary: str, scene, cwd_attr: str, command: str, home_kind: str
) -> None:
    home = _home_for(scene, home_kind)
    stdout, stderr, _ = _run_cmd(asc_binary, command, cwd=getattr(scene, cwd_attr), home=home)

    warnings = _warning_lines(stderr)
    assert warnings, (
        "expected a warning on stderr naming the config in use and HOME "
        f"when the account-home config is used under a {home_kind} HOME."
        f"\n--- stderr ---\n{stderr!r}"
    )

    assert scene.account_config in stderr, (
        "the warning must name the config path in use "
        f"({scene.account_config!r}).\n--- stderr ---\n{stderr!r}"
    )
    assert home in stderr, (
        "the warning must name the HOME the command was given "
        f"({home!r}).\n--- stderr ---\n{stderr!r}"
    )
    lines = [line.strip() for line in stderr.splitlines() if line.strip()]
    repeated = sorted({line for line in lines if lines.count(line) > 1})
    assert not repeated, (
        "the warning must be printed once per run; these stderr lines "
        f"repeat:\n{repeated!r}\n--- stderr ---\n{stderr!r}"
    )
    if command == "status":
        location = json.loads(stdout).get("storageLocation", "")
        assert os.path.realpath(location) == os.path.realpath(scene.account_config), (
            "the config in use must still be the account-home config "
            f"({scene.account_config!r}); got {location!r}."
        )


@pytest.mark.parametrize("command", sorted(COMMANDS))
@pytest.mark.parametrize("cwd_attr", LEAK_CWDS)
def test_warning_printed_once(asc_binary: str, scene, cwd_attr: str, command: str) -> None:
    # One run prints the warning once, even though each command looks up its
    # config more than once: no non-empty stderr line may appear twice.
    _, stderr, _ = _run_cmd(
        asc_binary, command, cwd=getattr(scene, cwd_attr), home=scene.scratch_home
    )
    assert _warning_lines(stderr), f"no warning on stderr:\n{stderr!r}"

    lines = [line.strip() for line in stderr.splitlines() if line.strip()]
    repeated = sorted({line for line in lines if lines.count(line) > 1})
    assert not repeated, (
        "the warning must be printed once per run; these stderr lines "
        f"repeat:\n{repeated!r}\n--- stderr ---\n{stderr!r}"
    )


# Commands that read credentials through other paths than auth status and
# auth doctor. With the planted config holding no credentials, ``apps list``
# stops with a missing-authentication error before any request, and
# ``ads auth status`` and ``storekit auth status`` list their credentials
# offline (``storekit auth status`` also prints its own unresolved-credentials
# warning). Exit codes are not checked here.
OTHER_COMMANDS = {
    "apps_list": (("apps", "list", "--output", "json"), {}),
    # Apple Ads and StoreKit credentials have their own keychain bypass switches.
    "ads_auth_status": (
        ("ads", "auth", "status", "--output", "json"),
        {"ASC_ADS_BYPASS_KEYCHAIN": "1"},
    ),
    "storekit_auth_status": (
        ("storekit", "auth", "status", "--output", "json"),
        {"ASC_STOREKIT_BYPASS_KEYCHAIN": "1"},
    ),
}


@pytest.mark.parametrize("command", sorted(OTHER_COMMANDS))
@pytest.mark.parametrize("cwd_attr", LEAK_CWDS)
def test_warns_for_other_commands(asc_binary: str, scene, cwd_attr: str, command: str) -> None:
    # stderr must carry one warning naming the config path and the scratch HOME.
    args, extra_env = OTHER_COMMANDS[command]
    _, stderr, _ = _run_status(
        asc_binary, cwd=getattr(scene, cwd_attr), home=scene.scratch_home,
        args=args, extra_env=extra_env,
    )
    assert scene.account_config in stderr and scene.scratch_home in stderr, (
        f"asc {' '.join(args)} must warn and name the config path in use "
        f"({scene.account_config!r}) and the HOME it was given "
        f"({scene.scratch_home!r}).\n--- stderr ---\n{stderr!r}"
    )
    lines = [line.strip() for line in stderr.splitlines() if line.strip()]
    repeated = sorted({line for line in lines if lines.count(line) > 1})
    assert not repeated, (
        "the warning must be printed once per run; these stderr lines "
        f"repeat:\n{repeated!r}\n--- stderr ---\n{stderr!r}"
    )


@pytest.mark.parametrize("cwd_attr", LEAK_CWDS)
def test_warns_for_app_id_lookup(asc_binary: str, scene, cwd_attr: str) -> None:
    # Config is also read for defaults other than credentials. ``builds count``
    # with no --app and no ASC_APP_ID looks for a default app ID in the config,
    # then stops with a usage error before any request. stderr must still name
    # the config path and the scratch HOME. The usage error text is the
    # command's own, so repeated lines are not checked here.
    _, stderr, _ = _run_status(
        asc_binary, cwd=getattr(scene, cwd_attr), home=scene.scratch_home,
        args=("builds", "count"),
    )
    assert scene.account_config in stderr and scene.scratch_home in stderr, (
        "builds count must warn and name the config path in use "
        f"({scene.account_config!r}) and the HOME it was given "
        f"({scene.scratch_home!r}).\n--- stderr ---\n{stderr!r}"
    )


# --------------------------------------------------------------------------- #
# The account-home config stays the one in use, stdout and exit code unchanged
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("cwd_attr", LEAK_CWDS)
def test_selection_unchanged_under_warning(asc_binary: str, scene, cwd_attr: str) -> None:
    stdout, _, _ = _run_cmd(
        asc_binary, "status", cwd=getattr(scene, cwd_attr), home=scene.scratch_home
    )
    location = json.loads(stdout).get("storageLocation", "")
    assert location, f"no storageLocation in output: {stdout[-1500:]!r}"
    assert os.path.realpath(location) == os.path.realpath(scene.account_config), (
        "the config in use must still be the account-home config "
        f"({scene.account_config!r}); got {location!r}."
    )


@pytest.mark.parametrize("cwd_attr", LEAK_CWDS)
def test_status_stdout_unchanged(asc_binary: str, scene, cwd_attr: str) -> None:
    # With the planted config, the auth status JSON depends on nothing that HOME
    # changes here, so the scratch-HOME run prints exactly what the run with
    # HOME set to the account home prints.
    cwd = getattr(scene, cwd_attr)
    leak_out, _, _ = _run_cmd(asc_binary, "status", cwd=cwd, home=scene.scratch_home)
    plain_out, _, _ = _run_cmd(asc_binary, "status", cwd=cwd, home=scene.account_home)
    assert json.loads(leak_out) == json.loads(plain_out), (
        "auth status stdout must not change under a scratch HOME.\n"
        f"--- scratch HOME ---\n{leak_out[-1500:]}\n--- account HOME ---\n{plain_out[-1500:]}"
    )


@pytest.mark.parametrize("cwd_attr", LEAK_CWDS)
def test_doctor_output_unchanged(asc_binary: str, scene, cwd_attr: str) -> None:
    # auth doctor exits by its findings. With the planted config its report
    # depends on nothing that HOME changes here, so the scratch-HOME run prints
    # the same JSON and exits the same way as the run with HOME set to the
    # account home.
    cwd = getattr(scene, cwd_attr)
    leak_out, _, leak_rc = _run_cmd(asc_binary, "doctor", cwd=cwd, home=scene.scratch_home)
    plain_out, _, plain_rc = _run_cmd(asc_binary, "doctor", cwd=cwd, home=scene.account_home)
    assert json.loads(leak_out) == json.loads(plain_out), (
        "auth doctor stdout must not change under a scratch HOME.\n"
        f"--- scratch HOME ---\n{leak_out[-1500:]}\n--- account HOME ---\n{plain_out[-1500:]}"
    )
    assert leak_rc == plain_rc, (
        f"auth doctor exited {leak_rc} under a scratch HOME and {plain_rc} "
        "with HOME set to the account home."
    )


@pytest.mark.parametrize("cwd_attr", LEAK_CWDS)
def test_doctor_inspects_same_config(asc_binary: str, scene, cwd_attr: str) -> None:
    # auth doctor reports the config file it inspected in its JSON report.
    stdout, _, _ = _run_cmd(
        asc_binary, "doctor", cwd=getattr(scene, cwd_attr), home=scene.scratch_home
    )
    assert scene.account_config in stdout, (
        "auth doctor must still inspect the account-home config "
        f"({scene.account_config!r}).\n--- stdout ---\n{stdout[-1500:]}"
    )


# --------------------------------------------------------------------------- #
# A second OS account: the warning names that account's own config
# --------------------------------------------------------------------------- #
def _second_account() -> pwd.struct_passwd:
    """A non-root account with an existing home directory (``dev`` in the image)."""
    try:
        entry = pwd.getpwnam("dev")
        if os.path.isdir(entry.pw_dir):
            return entry
    except KeyError:
        pass
    for entry in pwd.getpwall():
        if entry.pw_uid >= 1000 and entry.pw_uid != os.getuid() and os.path.isdir(entry.pw_dir):
            return entry
    pytest.fail("no second OS account with a home directory to run as")


def test_warns_for_second_account(asc_binary: str) -> None:
    # The same scene under another OS account: its own .asc/config.json, its
    # own scratch HOME, run from a directory below its home as that account.
    if os.getuid() != 0:
        pytest.fail("running a command as a second account needs root")
    acct = _second_account()
    uid, gid, home = acct.pw_uid, acct.pw_gid, acct.pw_dir

    def chown_tree(path: str) -> None:
        os.chown(path, uid, gid)
        for root, dirs, files in os.walk(path):
            for name in dirs + files:
                os.chown(os.path.join(root, name), uid, gid)

    bin_dir = tempfile.mkdtemp(prefix="asc-bin-shared-")
    os.chmod(bin_dir, 0o755)
    binary = os.path.join(bin_dir, "asc")
    shutil.copy2(asc_binary, binary)
    os.chmod(binary, 0o755)

    acct_asc = os.path.join(home, CONFIG_SUBDIR)
    acct_config = os.path.join(acct_asc, CONFIG_FILENAME)
    created_dir = not os.path.isdir(acct_asc)
    backup = None
    if os.path.isfile(acct_config):
        backup = acct_config + ".verify-backup"
        shutil.copy2(acct_config, backup)
    else:
        os.makedirs(acct_asc, exist_ok=True)
        with open(acct_config, "w", encoding="utf-8") as fh:
            fh.write("{}")
        chown_tree(acct_asc)

    scratch = tempfile.mkdtemp(prefix="asc-scratch-")
    chown_tree(scratch)
    work_root = tempfile.mkdtemp(prefix="asc-verify-work-", dir=home)
    work = os.path.join(work_root, "app")
    os.makedirs(work, exist_ok=True)
    chown_tree(work_root)

    try:
        proc = subprocess.run(
            [binary, "auth", "status", "--output", "json"],
            cwd=work,
            env={
                "PATH": os.environ.get("PATH", "/usr/local/go/bin:/usr/bin:/bin"),
                "HOME": scratch,
                "ASC_BYPASS_KEYCHAIN": "1",
            },
            user=uid,
            group=gid,
            extra_groups=[],
            capture_output=True,
            text=True,
            timeout=RUN_TIMEOUT,
            check=False,
        )
        assert proc.returncode == 0, (
            f"auth status as {acct.pw_name} exited {proc.returncode}; "
            f"stderr:\n{proc.stderr[-1500:]}"
        )
        location = json.loads(proc.stdout).get("storageLocation", "")
        assert os.path.realpath(location) == os.path.realpath(acct_config), (
            f"the config in use must be {acct_config!r}; got {location!r}"
        )
        assert acct_config in proc.stderr and scratch in proc.stderr, (
            f"the warning must name {acct_config!r} and the HOME {scratch!r}."
            f"\n--- stderr ---\n{proc.stderr!r}"
        )
    finally:
        if backup is not None:
            shutil.copy2(backup, acct_config)
            os.remove(backup)
        elif created_dir:
            shutil.rmtree(acct_asc, ignore_errors=True)
        else:
            try:
                os.remove(acct_config)
            except FileNotFoundError:
                pass
        shutil.rmtree(work_root, ignore_errors=True)
        shutil.rmtree(scratch, ignore_errors=True)
        shutil.rmtree(bin_dir, ignore_errors=True)


# --------------------------------------------------------------------------- #
# No warning when the account-home config is not used under a scratch HOME
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("command", sorted(COMMANDS))
def test_no_warning_when_home_is_account_home(asc_binary: str, scene, command: str) -> None:
    # (a) HOME is the account home.
    _, stderr, _ = _run_cmd(asc_binary, command, cwd=scene.account_home, home=scene.account_home)
    assert not _warning_lines(stderr), f"unexpected warning:\n{stderr!r}"


@pytest.mark.parametrize("target", ["elsewhere", "account_config"])
@pytest.mark.parametrize("command", sorted(COMMANDS))
def test_no_warning_when_config_path_env_set(asc_binary: str, scene, command: str, target: str) -> None:
    # (b) ASC_CONFIG_PATH names the config explicitly, either a file elsewhere
    # or the account's own config file itself.
    override_root = tempfile.mkdtemp(prefix="asc-override-")
    if target == "account_config":
        override = scene.account_config
    else:
        override = os.path.join(override_root, "missing", CONFIG_FILENAME)
    try:
        _, stderr, _ = _run_cmd(
            asc_binary, command, cwd=scene.account_home, home=scene.scratch_home,
            config_path=override,
        )
        assert not _warning_lines(stderr), f"unexpected warning:\n{stderr!r}"
    finally:
        shutil.rmtree(override_root, ignore_errors=True)


@pytest.mark.parametrize("command", sorted(COMMANDS))
def test_no_warning_outside_account_home(asc_binary: str, scene, command: str) -> None:
    # (c) Working directory outside the account home: the account-home config
    # is not the one in use.
    outside = tempfile.mkdtemp(prefix="asc-outside-")
    # Guard: the scratch dir must not sit under the account home.
    assert os.path.commonpath([outside, scene.account_home]) != scene.account_home
    try:
        _, stderr, _ = _run_cmd(asc_binary, command, cwd=outside, home=scene.scratch_home)
        assert not _warning_lines(stderr), f"unexpected warning:\n{stderr!r}"
    finally:
        shutil.rmtree(outside, ignore_errors=True)


@pytest.mark.parametrize("command", sorted(COMMANDS))
def test_no_warning_when_project_config_wins(asc_binary: str, scene, command: str) -> None:
    # (d) A project .asc/config.json below the account home is the config in
    # use; it is not the account's own config, so no warning.
    proj = os.path.join(scene.account_home, "asc-verify-proj")
    proj_asc = os.path.join(proj, CONFIG_SUBDIR)
    sub = os.path.join(proj, "sub")
    try:
        os.makedirs(proj_asc, exist_ok=True)
        os.makedirs(sub, exist_ok=True)
        with open(os.path.join(proj_asc, CONFIG_FILENAME), "w", encoding="utf-8") as fh:
            fh.write("{}")
        _, stderr, _ = _run_cmd(asc_binary, command, cwd=sub, home=scene.scratch_home)
        assert not _warning_lines(stderr), f"unexpected warning:\n{stderr!r}"
    finally:
        shutil.rmtree(proj, ignore_errors=True)


# --------------------------------------------------------------------------- #
# Saving with --local: the target stays the same, the warning names it
# --------------------------------------------------------------------------- #
ISSUER_ID = "6a1f0c2e-3b4d-4e5f-8a9b-0c1d2e3f4a5b"


def _make_private_key(directory: str) -> str:
    """Write a fresh EC P-256 key in PKCS#8 PEM form, readable by its owner only."""
    path = os.path.join(directory, "AuthKey_VERIFY.p8")
    proc = subprocess.run(
        ["openssl", "genpkey", "-algorithm", "EC", "-pkeyopt", "ec_paramgen_curve:P-256", "-out", path],
        capture_output=True,
        text=True,
        timeout=RUN_TIMEOUT,
        check=False,
    )
    if proc.returncode != 0:
        pytest.fail(f"openssl could not create a test key:\n{proc.stderr[-1500:]}")
    os.chmod(path, 0o600)
    return path


def _local_write_args(command: str, name: str, key_path: str) -> tuple[str, ...]:
    if command == "auth_init":
        return ("auth", "init", "--local")
    if command == "auth_login":
        return (
            "auth", "login", "--bypass-keychain", "--local", "--skip-validation",
            "--name", name, "--key-id", "VERIFYKEY1", "--issuer-id", ISSUER_ID,
            "--private-key", key_path,
        )
    if command == "ads_auth_login":
        return (
            "ads", "auth", "login", "--bypass-keychain", "--local", "--skip-validation",
            "--name", name, "--client-id", "SEARCHADS.verify-client",
            "--team-id", "SEARCHADS.verify-team", "--key-id", "VERIFYKEY2",
            "--private-key", key_path,
        )
    if command == "storekit_auth_login":
        return (
            "storekit", "auth", "login", "--bypass-keychain", "--local", "--skip-validation",
            "--name", name, "--key-id", "VERIFYKEY3", "--issuer-id", ISSUER_ID,
            "--private-key", key_path, "--bundle-id", "com.example.verify",
        )
    raise AssertionError(command)


LOCAL_WRITES = ["auth_init", "auth_login", "ads_auth_login", "storekit_auth_login"]


class LocalWrite:
    """One ``--local`` save in a prepared target.

    ``auth init`` refuses to overwrite, so its target starts as an ``.asc``
    folder with no config file in it; the login commands add a key to an
    existing empty config.
    """

    def __init__(self, command: str, key_dir: str) -> None:
        self.command = command
        self.name = f"verify-{command.replace('_', '-')}-{uuid.uuid4().hex[:6]}"
        self.key_path = _make_private_key(key_dir)

    def prepare(self, target_config: str) -> None:
        os.makedirs(os.path.dirname(target_config), exist_ok=True)
        if self.command == "auth_init":
            if os.path.exists(target_config):
                os.remove(target_config)
        else:
            with open(target_config, "w", encoding="utf-8") as fh:
                fh.write("{}")

    def run(self, binary: str, cwd: str, home: str):
        return _run_status(
            binary, cwd, home,
            args=_local_write_args(self.command, self.name, self.key_path),
        )

    def assert_saved(self, target_config: str, stdout: str, stderr: str, rc: int) -> None:
        assert rc == 0, (
            f"asc {' '.join(_local_write_args(self.command, self.name, self.key_path))} "
            f"exited {rc}.\n--- stdout ---\n{stdout[-1500:]}\n--- stderr ---\n{stderr[-1500:]}"
        )
        assert os.path.isfile(target_config), f"nothing was saved at {target_config!r}"
        with open(target_config, encoding="utf-8") as fh:
            saved = fh.read()
        json.loads(saved)
        if self.command != "auth_init":
            assert self.name in saved, (
                f"the {self.name!r} key was not saved in {target_config!r}:\n{saved[-1500:]}"
            )


@pytest.fixture
def key_dir():
    path = tempfile.mkdtemp(prefix="asc-keys-")
    try:
        yield path
    finally:
        shutil.rmtree(path, ignore_errors=True)


@pytest.mark.parametrize("home_kind", HOME_KINDS)
@pytest.mark.parametrize("command", LOCAL_WRITES)
@pytest.mark.parametrize("cwd_attr", LEAK_CWDS)
def test_local_write_warns_on_account_home(
    asc_binary: str, scene, key_dir: str, cwd_attr: str, command: str, home_kind: str
) -> None:
    # With no project in between, --local saves into the account home's own
    # .asc/config.json. That target is kept, and stderr names it and the HOME
    # once.
    home = _home_for(scene, home_kind)
    write = LocalWrite(command, key_dir)
    write.prepare(scene.account_config)
    stdout, stderr, rc = write.run(asc_binary, getattr(scene, cwd_attr), home)
    write.assert_saved(scene.account_config, stdout, stderr, rc)

    assert scene.account_config in stderr and home in stderr, (
        f"saving with --local ({command}) must warn and name the config path "
        f"({scene.account_config!r}) and the HOME it was given ({home!r})."
        f"\n--- stderr ---\n{stderr!r}"
    )
    lines = [line.strip() for line in stderr.splitlines() if line.strip()]
    repeated = sorted({line for line in lines if lines.count(line) > 1})
    assert not repeated, (
        "the warning must be printed once per run; these stderr lines "
        f"repeat:\n{repeated!r}\n--- stderr ---\n{stderr!r}"
    )


@pytest.mark.parametrize("command", LOCAL_WRITES)
@pytest.mark.parametrize("cwd_attr", LEAK_CWDS)
def test_local_write_stdout_unchanged(
    asc_binary: str, scene, key_dir: str, cwd_attr: str, command: str
) -> None:
    # The same save prints the same stdout under a scratch HOME as with HOME
    # set to the account home.
    write = LocalWrite(command, key_dir)
    cwd = getattr(scene, cwd_attr)
    write.prepare(scene.account_config)
    leak_out, leak_err, leak_rc = write.run(asc_binary, cwd, scene.scratch_home)
    write.assert_saved(scene.account_config, leak_out, leak_err, leak_rc)
    write.prepare(scene.account_config)
    plain_out, plain_err, plain_rc = write.run(asc_binary, cwd, scene.account_home)
    write.assert_saved(scene.account_config, plain_out, plain_err, plain_rc)
    assert leak_out == plain_out, (
        f"{command} stdout must not change under a scratch HOME.\n"
        f"--- scratch HOME ---\n{leak_out[-1500:]}\n--- account HOME ---\n{plain_out[-1500:]}"
    )


@pytest.mark.parametrize("command", LOCAL_WRITES)
def test_local_write_quiet_when_home_is_account_home(
    asc_binary: str, scene, key_dir: str, command: str
) -> None:
    write = LocalWrite(command, key_dir)
    write.prepare(scene.account_config)
    stdout, stderr, rc = write.run(asc_binary, scene.nested_cwd, scene.account_home)
    write.assert_saved(scene.account_config, stdout, stderr, rc)
    assert not _warning_lines(stderr), f"unexpected warning:\n{stderr!r}"


@pytest.mark.parametrize("project_kind", ["git_checkout", "own_asc_folder"])
@pytest.mark.parametrize("command", LOCAL_WRITES)
def test_local_write_quiet_in_project(
    asc_binary: str, scene, key_dir: str, command: str, project_kind: str
) -> None:
    # A project below the account home, either a git checkout or a folder with
    # its own .asc, takes the --local save. The account home's config exists
    # but is not the target, so nothing is printed.
    proj = tempfile.mkdtemp(prefix="asc-verify-proj-", dir=scene.account_home)
    sub = os.path.join(proj, "sub", "dir")
    os.makedirs(sub, exist_ok=True)
    if project_kind == "git_checkout":
        os.makedirs(os.path.join(proj, ".git"), exist_ok=True)
    else:
        os.makedirs(os.path.join(proj, CONFIG_SUBDIR), exist_ok=True)
    target = os.path.join(proj, CONFIG_SUBDIR, CONFIG_FILENAME)
    try:
        # Nothing is planted in the project beyond its marker; the save
        # creates the project's config.json.
        write = LocalWrite(command, key_dir)
        with open(scene.account_config, encoding="utf-8") as fh:
            account_before = fh.read()
        stdout, stderr, rc = write.run(asc_binary, sub, scene.scratch_home)
        write.assert_saved(target, stdout, stderr, rc)
        with open(scene.account_config, encoding="utf-8") as fh:
            assert fh.read() == account_before, "the account home config must not change"
        assert not _warning_lines(stderr), f"unexpected warning:\n{stderr!r}"
    finally:
        shutil.rmtree(proj, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v", "--tb=short"]))
