## Task

A mise task that lists its own `tools` breaks when the only thing starting it is another task's `run` list.
Smallest repro:

```toml
[tasks.child]
tools = { tiny = "1" }
run = "rtx-tiny"

[tasks.parent]
run = [{ task = "child" }]
```

`mise run parent` dies in the child:

```
[child] $ rtx-tiny
sh: 1: rtx-tiny: not found
[child] ERROR task failed
```

The tool is never installed.
`mise run child` works, and so does pulling it in with `depends = ["child"]`.
We also see it with a group entry (`run = [{ tasks = ["a", "b"] }]`) and with a templated name such as `run = [{ task = "{{ env.CHILD }}" }]`.

A task started from a `run` entry should get its tools installed before it starts, like a task run by name or through `depends`.
That includes the tools of anything it `depends` on.
While fixing this, keep the usual flags working for those installs:

- `--skip-tools` still skips them.
- `--jobs` still caps them, so with `--jobs 1` two installs never run at once.
- If a referenced task's tools fail to install, that task must not run and `mise run` exits with an error.
  With `--continue-on-error`, tasks that are already running still get to finish.
