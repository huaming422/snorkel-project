#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
# Prepares the mise e2e harness to run OFFLINE against the working tree.
#
# No assertion logic here. This only builds the current mise binary, with the
# user changes, from the dependencies baked into the image, so the verifier can
# run `mise run` end-to-end. The scenarios themselves live in tests/verify/,
# which also links the tiny plugin and sets MISE_USE_VERSIONS_HOST=0.
cd /repo/mise

# Offline switch for this task's own cargo invocations. Set here, never as image
# ENV (an image-wide cargo offline switch would also break setup steps that need the
# network). The image warmed the full workspace dependency closure at build,
# so an offline build succeeds from the cargo cache.
export CARGO_NET_OFFLINE=true

# Build the mise binary offline-first from the image's warm cache; log an online
# fallback only if the bake was stale. The e2e harness resolves the binary at
# $CARGO_TARGET_DIR/debug/mise, so it must exist and reflect the user changes.
if cargo build --locked --offline -p mise > /tmp/test-setup-build.log 2>&1; then
    echo "[offline-first] mise binary built from warm cargo cache"
elif cargo build --locked -p mise >> /tmp/test-setup-build.log 2>&1; then
    echo "[test-setup] mise binary built online (image bake was stale)"
else
    tail -60 /tmp/test-setup-build.log >&2; exit 1
fi

# Confirm the runnable binary is present for the e2e harness.
test -x "${CARGO_TARGET_DIR:-target}/debug/mise"
