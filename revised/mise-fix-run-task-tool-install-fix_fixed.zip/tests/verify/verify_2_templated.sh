#!/usr/bin/env bash
# A `run` reference whose task name is rendered from an env var gets the named
# task's tool installed too. Exits 0 iff the scenario's assertions pass.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd)"
source "$HERE/scenario_common.sh"
staged="$(prepare_plugins)"
SCENARIO_PLUGIN_DIR="$staged" bash "$HERE/run_scenario.sh" "$HERE/body_templated.sh"
