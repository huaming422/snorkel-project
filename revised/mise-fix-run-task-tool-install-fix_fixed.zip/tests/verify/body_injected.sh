#!/usr/bin/env bash
# Sourced inside the isolated environment (assert helpers already loaded, cwd is
# the isolated workdir). A task with its own `tools` that runs only because a
# parent names it in a `run` entry gets those tools before its command starts.
# Three shapes, each with fresh installs: a single `{ task = ... }` entry, a
# `{ tasks = [...] }` group naming two tasks, and a referenced task that has a
# tool-bearing `depends` of its own. The group and depends runs install two
# tools while other tasks are in flight, so they get a time limit: a run that
# hangs there fails with a clear message instead of at the file timeout. Two
# installs running at the same time can go wrong on only some runs (a hang or a
# panic), so the group case runs eight times, each from fresh installs.

cat <<EOF >mise.toml
[tasks.child]
tools = { tiny = "1" }
run = "rtx-tiny"

[tasks.parent]
run = [{ task = "child" }]
EOF

assert "mise run parent" "rtx-tiny: v1.0.1 args:"

cat <<EOF >mise.toml
[tasks.fmt]
tools = { tiny = "2" }
run = "rtx-tiny"

[tasks.lint]
tools = { dummy = "1.0.0" }
run = "dummy"

[tasks.check]
run = [{ tasks = ["fmt", "lint"] }]
EOF

for round in 1 2 3 4 5 6 7 8; do
  rm -rf "$MISE_DATA_DIR/installs"
  out="$(quiet_assert_succeed "timeout 60 mise run check 2>&1")"
  for want in "rtx-tiny: v2.1.0 args:" "This is Dummy 1.0.0!"; do
    if [[ $out != *"$want"* ]]; then
      fail "round $round: expected '$want' in '$out'"
    fi
  done
done
ok "[mise run check] installed both tools and ran both tasks in 8 rounds"

rm -rf "$MISE_DATA_DIR/installs"
cat <<EOF >mise.toml
[tasks.setup]
tools = { dummy = "2.0.0" }
run = "dummy"

[tasks.build]
depends = ["setup"]
tools = { tiny = "3" }
run = "rtx-tiny"

[tasks.release]
run = [{ task = "build" }]
EOF

assert_contains "timeout 60 mise run release" "This is Dummy 2.0.0!"
assert_contains "timeout 60 mise run release" "rtx-tiny: v3.1.0 args:"
