#!/usr/bin/env bash
# With `--jobs 1`, installs for tasks reached through `run` references never
# overlap. Exits 0 iff the scenario's assertions pass.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd)"
source "$HERE/scenario_common.sh"
staged="$(prepare_plugins)"
SCENARIO_PLUGIN_DIR="$staged" bash "$HERE/run_scenario.sh" "$HERE/body_jobs_bound.sh"
