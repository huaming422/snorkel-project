#!/usr/bin/env bash
# Sourced inside the isolated environment. With `--jobs 1`, two parents named on
# one command line each start a child that needs its own dummy version, and the
# two installs never run at the same time. The staged dummy installer holds a
# lock directory for one second while it installs and leaves an overlap marker
# when it finds the lock already taken. Both children still run. Whether two
# unlimited installs actually collide depends on timing, so the run is repeated
# four times, each from fresh installs.

cat <<EOF >mise.toml
[tasks.install-one]
tools = { dummy = "1.0.0" }
run = "dummy"

[tasks.install-two]
tools = { dummy = "2.0.0" }
run = "dummy"

[tasks.install-one-parent]
run = [{ task = "install-one" }]

[tasks.install-two-parent]
run = [{ task = "install-two" }]
EOF

install_gate="$HOME/install-gate"
for round in 1 2 3 4; do
  rm -rf "$MISE_DATA_DIR/installs" "$install_gate" "$install_gate.overlap"
  out="$(quiet_assert_succeed "DUMMY_INSTALL_GATE_DIR='$install_gate' mise run --jobs 1 install-one-parent ::: install-two-parent 2>&1")"
  for want in "This is Dummy 1.0.0!" "This is Dummy 2.0.0!"; do
    if [[ $out != *"$want"* ]]; then
      fail "round $round: expected '$want' in '$out'"
    fi
  done
  if [[ -e $install_gate.overlap ]]; then
    fail "round $round: two installs ran at the same time under --jobs 1"
  fi
done
ok "both children ran under --jobs 1 with no overlapping installs in 4 rounds"
