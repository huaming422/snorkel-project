#!/usr/bin/env bash
# A task reached only through a `run` reference (single entry, group, or with
# its own `depends`) has its task-local tools installed before it runs.
# Exits 0 iff the scenario's assertions pass.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd)"
source "$HERE/scenario_common.sh"
staged="$(prepare_plugins)"
SCENARIO_PLUGIN_DIR="$staged" bash "$HERE/run_scenario.sh" "$HERE/body_injected.sh"
