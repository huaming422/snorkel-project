#!/usr/bin/env bash
# Sourced inside the isolated environment. When the task name in a `run` entry
# is a template rendered from an env var when the parent runs, the task it
# names still gets its tool installed before it runs.

cat <<EOF >mise.toml
[tasks.templated-child]
tools = { tiny = "2" }
run = "rtx-tiny"

[tasks.templated-parent]
env = { CHILD = "templated-child" }
run = [{ task = "{{ env.CHILD }}" }]
EOF

assert "mise run templated-parent" "rtx-tiny: v2.1.0 args:"
