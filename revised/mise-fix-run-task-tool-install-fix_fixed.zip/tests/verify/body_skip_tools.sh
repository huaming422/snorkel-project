#!/usr/bin/env bash
# Sourced inside the isolated environment. `--skip-tools` also covers a task
# reached only through a `run` reference: the referenced task runs, but its
# declared tool is not installed. The child's command is a plain `echo`, so it
# prints whether or not the tool was installed; the deciding check is that no
# install directory for the child's tool version was created.

cat <<EOF >mise.toml
[tasks.skip-child]
tools = { tiny = "2.0.0" }
run = 'echo skip-child ran'

[tasks.skip-parent]
run = [{ task = "skip-child" }]
EOF

assert "mise run --skip-tools skip-parent" "skip-child ran"
assert_fail "test -d '$MISE_DATA_DIR/installs/tiny/2.0.0'"
