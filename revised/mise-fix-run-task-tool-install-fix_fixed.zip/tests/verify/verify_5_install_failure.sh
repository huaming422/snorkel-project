#!/usr/bin/env bash
# A referenced task whose tool fails to install does not run and fails the
# run; with `--continue-on-error`, a task already running still finishes.
# Exits 0 iff the scenario's assertions pass.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd)"
source "$HERE/scenario_common.sh"
staged="$(prepare_plugins)"
SCENARIO_PLUGIN_DIR="$staged" bash "$HERE/run_scenario.sh" "$HERE/body_install_failure.sh"
