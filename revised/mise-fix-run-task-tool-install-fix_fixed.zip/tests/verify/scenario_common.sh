#!/usr/bin/env bash
# Shared preparation for the verify_*.sh launchers.
#
# Locates the checkout and its freshly built binary, and stages a writable copy
# of the local test plugins. The copy carries one test-only hook appended to
# dummy's installer (see prepare_plugins) that is not in the checkout, so it is
# added here rather than by editing the tree.
set -euo pipefail

export REPO_DIR="${REPO_DIR:-/repo/mise}"

# The built binary the scenarios invoke must exist (tests/test-setup.sh builds
# it from the current tree before any verifier runs). Fail loudly rather than
# silently falling back to a stale or system-wide binary.
_mise_bin="${CARGO_TARGET_DIR:-$REPO_DIR/target}/debug/mise"
if [[ ! -x $_mise_bin ]]; then
  echo "built mise binary not found at $_mise_bin" >&2
  exit 2
fi

# Stage a writable copy of the local test plugins and echo its path. The copy
# lives outside the checkout, so the checkout is never changed and edits under
# test/data cannot remove the install-overlap hook.
prepare_plugins() {
  local staged
  staged="$(mktemp --tmpdir --directory plugins.XXXXXX)"
  cp -a "$REPO_DIR/test/data/plugins/." "$staged/"

  # Test-only hook for seeing two installs run at once: when
  # DUMMY_INSTALL_GATE_DIR is set, the dummy installer takes a lock directory
  # and holds it for one second; an install that finds the lock already taken
  # leaves an overlap marker instead. Only the --jobs scenario sets
  # DUMMY_INSTALL_GATE_DIR, so the hook does nothing in the other scenarios.
  cat >>"$staged/dummy/bin/install" <<'HOOK'

# Test-only check for two installs running at once.
if [ -n "${DUMMY_INSTALL_GATE_DIR:-}" ]; then
    if mkdir "$DUMMY_INSTALL_GATE_DIR" 2>/dev/null; then
        sleep 1
        rmdir "$DUMMY_INSTALL_GATE_DIR"
    else
        touch "$DUMMY_INSTALL_GATE_DIR.overlap"
    fi
fi
HOOK

  printf '%s\n' "$staged"
}
