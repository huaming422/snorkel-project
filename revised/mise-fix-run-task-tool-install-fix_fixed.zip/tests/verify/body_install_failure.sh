#!/usr/bin/env bash
# Sourced inside the isolated environment. A referenced task whose tool cannot
# be installed (the dummy installer rejects "other-dummy") does not run its
# command and makes the whole `mise run` exit non-zero. With
# `--continue-on-error`, a task that is already running when that install fails
# still finishes: the sibling sleeps for two seconds and then prints a marker.
# mise echoes each task's command line before running it, so both markers are
# computed by the shell ("$((...))") and only appear when the command really
# runs, not when its command line is printed.

cat <<'EOF' >mise.toml
[tasks.install-failure]
tools = { dummy = "other-dummy" }
run = "echo child-ran-$((2 + 3))"

[tasks.install-failure-parent]
run = [{ task = "install-failure" }]

[tasks.install-sibling]
run = "sleep 2; echo sibling-done-$((40 + 2))"
EOF

out="$(quiet_assert_fail "mise run install-failure-parent")"
if [[ $out == *child-ran-5* ]]; then
  fail "the task ran its command although its tool failed to install: $out"
fi
ok "[mise run install-failure-parent] fails without running the task's command"

out="$(quiet_assert_fail "mise run --continue-on-error install-failure-parent ::: install-sibling")"
if [[ $out != *sibling-done-42* ]]; then
  fail "expected the sibling to finish and print 'sibling-done-42' in '$out'"
fi
if [[ $out == *child-ran-5* ]]; then
  fail "the task ran its command although its tool failed to install: $out"
fi
ok "[mise run --continue-on-error install-failure-parent ::: install-sibling] fails, sibling finished"
