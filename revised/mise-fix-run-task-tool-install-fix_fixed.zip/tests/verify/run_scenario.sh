#!/usr/bin/env bash
# Isolated-environment runner for one scenario.
#
# This is an adaptation of the repository's own e2e/run_test, trimmed to the
# single-shell (bash) path and pinned to run fully offline against the built
# `mise` binary. Three differences from the repository runner, all needed to run
# the `run`-reference tool scenarios offline:
#
#   1. The local test plugins (tiny, dummy, needs-dummy) are symlinked from a
#      staged copy outside the checkout ($SCENARIO_PLUGIN_DIR, prepared by the
#      calling launcher) rather than from the checkout itself. The repository
#      runner only links dummy and needs-dummy; the run-reference scenarios also
#      need `tiny`, which resolves its versions from a local list-all with no
#      network.
#   2. MISE_USE_VERSIONS_HOST defaults to 0 so version strings like "1" and "2"
#      resolve against the local plugin list-all instead of a remote host.
#   3. The assertion/output helpers are sourced from this directory's vendored
#      copies, keeping the pass/fail logic fixed and outside the editable tree.
#
# Usage: run_scenario.sh <scenario-file>
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd)"
# The checkout. The built binary and (for parity with e2e/run_test) the
# default plugin sources live under here.
ROOT="${REPO_DIR:-/repo/mise}"

# shellcheck source-path=SCRIPTDIR
source "$SCRIPT_DIR/style.sh"

TEST="$1"
if [[ $TEST == /* ]]; then
  TEST_SCRIPT="$TEST"
else
  TEST_SCRIPT="$SCRIPT_DIR/$TEST"
fi

# Staged plugin tree prepared by the caller. Falls back to the
# checkout's own fixtures only if the caller did not stage a copy.
PLUGIN_DIR="${SCENARIO_PLUGIN_DIR:-$ROOT/test/data/plugins}"

setup_isolated_env() {
  TEST_ISOLATED_DIR="$(mktemp --tmpdir --directory "$(basename "$TEST").XXXXXX")"

  TEST_HOME="$TEST_ISOLATED_DIR/home"
  TEST_WORKDIR="$TEST_HOME/workdir"
  TEST_TMPDIR="$TEST_ISOLATED_DIR/tmp"

  MISE_SYSTEM_DIR="$TEST_ISOLATED_DIR/etc/mise"
  MISE_DATA_DIR="$TEST_HOME/.local/share/mise"
  MISE_CACHE_DIR="$TEST_HOME/.cache/mise"
  MISE_CONFIG_DIR="$TEST_HOME/.config/mise"
  MISE_STATE_DIR="$TEST_HOME/.local/state/mise"

  : "${CARGO_HOME:=$HOME/.cargo}"
  : "${RUSTUP_HOME:=$HOME/.rustup}"
}

create_isolated_env() {
  mkdir -p "$TEST_HOME/bin" "$TEST_WORKDIR" "$TEST_TMPDIR" "$MISE_SYSTEM_DIR" \
    "$MISE_DATA_DIR" "$MISE_STATE_DIR" "$MISE_CACHE_DIR" "$MISE_CONFIG_DIR"

  mkdir -p "$MISE_DATA_DIR/plugins"
  # The run-reference scenarios exercise `tiny` (fully offline list-all/install)
  # alongside `dummy`/`needs-dummy`; link all three from the pristine tree.
  ln -s "$PLUGIN_DIR/tiny" "$MISE_DATA_DIR/plugins/tiny"
  ln -s "$PLUGIN_DIR/dummy" "$MISE_DATA_DIR/plugins/dummy"
  ln -s "$PLUGIN_DIR/needs-dummy" "$MISE_DATA_DIR/plugins/needs-dummy"
}

within_isolated_env() {
  (
    cd "$TEST_WORKDIR" &&
      exec env \
        -i \
        - \
        CARGO_HOME="$CARGO_HOME" \
        GIT_AUTHOR_NAME="test" \
        GIT_AUTHOR_EMAIL="test@test.com" \
        GIT_COMMITTER_NAME="test" \
        GIT_COMMITTER_EMAIL="test@test.com" \
        HOME="$TEST_HOME" \
        LANG="${LANG:-C.UTF-8}" \
        MISE_CACHE_DIR="$MISE_CACHE_DIR" \
        MISE_HISTORY_NOTIFY=0 \
        MISE_CACHE_PRUNE_AGE="0" \
        MISE_CONFIG_DIR="$MISE_CONFIG_DIR" \
        MISE_DATA_DIR="$MISE_DATA_DIR" \
        MISE_DEBUG="${MISE_DEBUG:-0}" \
        MISE_EXPERIMENTAL=1 \
        MISE_STATE_DIR="$MISE_STATE_DIR" \
        MISE_SYSTEM_DIR="$MISE_SYSTEM_DIR" \
        MISE_TMP_DIR="$TEST_TMPDIR" \
        MISE_TRUSTED_CONFIG_PATHS="$TEST_ISOLATED_DIR" \
        MISE_USE_VERSIONS_HOST="${MISE_USE_VERSIONS_HOST:-0}" \
        MISE_USE_VERSIONS_HOST_TRACK=0 \
        MISE_YES=1 \
        PATH="${CARGO_TARGET_DIR:-$ROOT/target}/debug:$HOME/mise/bin:$CARGO_HOME/bin:$TEST_HOME/bin:$HOME/.local/bin:/usr/local/bin:/usr/bin:/bin" \
        ROOT="$ROOT" \
        RUSTUP_HOME="$RUSTUP_HOME" \
        RUST_BACKTRACE="${RUST_BACKTRACE:-1}" \
        SHELL="$(type -p bash)" \
        TEST_DIR="$(dirname "$TEST_SCRIPT")" \
        TEST_NAME="$TEST" \
        TEST_ROOT="$SCRIPT_DIR" \
        TEST_SCRIPT="$TEST_SCRIPT" \
        TMPDIR="$TEST_TMPDIR" \
        "$@"
  ) || return $?
}

remove_isolated_env() {
  rm -rf "$TEST_ISOLATED_DIR"
}

run_test() {
  setup_isolated_env
  create_isolated_env

  local status=0
  within_isolated_env bash --noprofile --norc -euo pipefail -c \
    "source \"$SCRIPT_DIR/assert.sh\" && source \"$TEST_SCRIPT\"" || status=$?

  if [[ $status == 0 ]]; then
    remove_isolated_env
  else
    err "scenario $TEST exited with status $status"
    echo "Scenario environment can be examined in $TEST_ISOLATED_DIR" >&2
  fi
  return "$status"
}

run_test
