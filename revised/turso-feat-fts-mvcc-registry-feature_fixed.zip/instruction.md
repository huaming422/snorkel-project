## Task

FTS indexes can't be used in MVCC mode yet.
On a database with `PRAGMA journal_mode='mvcc'`, running `CREATE INDEX docs_fts ON docs USING fts(body)` fails with `index method 'fts' does not support MVCC`.
We want FTS indexes, built with `CREATE INDEX ... USING fts(col)` and searched with `fts_match(col, 'term')`, to work properly in MVCC mode, where writers open transactions with `BEGIN CONCURRENT`.
The FTS index method is still experimental and is switched on at runtime with `DatabaseOpts::with_index_method(true)`.

Keep the work focused on the FTS index method: how it stores its data, and how it handles concurrent transactions through the MVCC layer.
Heads-up: some users already have databases with an FTS index written by an earlier build, and those files have to keep opening.

## User stories / requirements

- Two concurrent transactions that each insert a different row into the same FTS index can both commit, and after both commits every inserted row shows up in `fts_match` results.
  While both are still open, neither one sees the other's uncommitted row.
- Rolling back to a savepoint throws away every FTS index write made since that savepoint was set.
  While one transaction holds a savepoint, with its index writes still pending or already rolled back, another transaction can write to the same index and commit.
- Once a row is deleted, or updated so its text no longer has a term, it stops matching that term.
  This holds inside the transaction that made the change and in every snapshot taken later, and all other rows still match as before.
- A transaction never sees FTS writes that another transaction has not committed.
  A document committed by another transaction shows up for a reader only after the reader takes a new snapshot, never inside a snapshot that started before the commit.
- A database holding an old-format FTS index opens fine with or without MVCC, and its base table and unrelated statements work.
  That format is refused in both journal modes: searches and writes through the index fail with an error saying to drop and recreate it.
  Once recreated, search matches the table's current rows.
- `OPTIMIZE INDEX` on an FTS index does not change what `fts_match` queries return, also when the index holds rows from several transactions and some rows were deleted or updated.
- Search stays quick on a bigger table.
  After about ten thousand rows are loaded in one transaction with multi-row `INSERT` statements of 500 rows each, a few hundred single-word `fts_match` lookups, each run as its own statement, finish within 20 seconds, even in a debug build.
