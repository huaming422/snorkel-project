## Task

FTS indexes can't be used in MVCC mode yet.
On a database with `PRAGMA journal_mode='mvcc'`, running `CREATE INDEX docs_fts ON docs USING fts(body)` fails with `index method 'fts' does not support MVCC`.
We want FTS indexes, built with `CREATE INDEX ... USING fts(col)` and searched with `fts_match(col, 'term')`, to work properly in MVCC mode, where writers open transactions with `BEGIN CONCURRENT`.
The FTS index method is still experimental and is switched on at runtime with `DatabaseOpts::with_index_method(true)`.

Keep the work focused on the FTS index method: how it stores its data, and how it handles concurrent transactions through the MVCC layer.
The requirements below cover concurrent writers on one index, snapshot reads, updates and deletes, savepoint rollback and `OPTIMIZE INDEX`.

Existing databases need care too.
A database that already has an FTS index written by an earlier build must still open with this version.
That old on-disk index format is no longer supported, in MVCC mode or in the normal journal mode, so the old index has to be rebuilt before it can be searched again.

## User stories / requirements

- Two concurrent transactions that each insert a different row into the same FTS index can both commit, and after both commits every inserted row shows up in `fts_match` results.
  While both are still open, neither one sees the other's uncommitted row.
- Rolling back to a savepoint throws away every FTS index write made since that savepoint was set.
  A transaction holding a savepoint, open or already rolled back, does not stop another transaction from writing to the same index at the same time.
- Once a row is deleted, or updated so its text no longer has a term, it stops matching that term.
  This holds inside the transaction that made the change and in every snapshot taken later, and all other rows still match as before.
- A transaction never sees FTS writes that another transaction has not committed.
  A document committed by another transaction shows up for a reader only after the reader takes a new snapshot, never inside a snapshot that started before the commit.
- A database holding an FTS index in the old format opens fine, with or without MVCC, and its base table and unrelated statements keep working.
  Searches and writes that go through the old index fail with an error telling the user to drop the index and create it again.
  Once the index has been dropped and recreated, search matches the table's current rows.
- `OPTIMIZE INDEX` on an FTS index does not change what `fts_match` queries return.
