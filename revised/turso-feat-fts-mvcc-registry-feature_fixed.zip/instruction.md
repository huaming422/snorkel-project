## Task

FTS indexes can't be used in MVCC mode yet.
On a database with `PRAGMA journal_mode='mvcc'`, running `CREATE INDEX docs_fts ON docs USING fts(body)` fails with `index method 'fts' does not support MVCC`.
We want FTS indexes, built with `CREATE INDEX ... USING fts(col)` and searched with `fts_match(col, 'term')`, to work properly in MVCC mode, where writers open transactions with `BEGIN CONCURRENT`.
The FTS index method is still experimental and is switched on at runtime with `DatabaseOpts::with_index_method(true)`.

Keep the work focused on the FTS index method and how it behaves inside transactions.
Heads-up: some users already have databases with an FTS index written by an earlier build, and those files have to keep opening.

## User stories / requirements
- Two concurrent transactions that each insert, delete or update a different row of one FTS index can both commit.
  Each sees its own change at once but not the other's, even once committed, until it starts a new snapshot.
  Afterwards inserted rows match, deleted rows and replaced text don't, and untouched rows still do.
- Rolling back to a savepoint throws away every FTS index write made since that savepoint was set.
  While one transaction holds a savepoint, with its index writes still pending or already rolled back, another transaction can write to the same index and commit.
- A database holding an old-format FTS index opens fine with or without MVCC, and its base table and unrelated statements work.
  That format is refused in both journal modes: searches and writes through the index fail with an error saying to drop and recreate it.
  Once recreated, search matches the table's current rows.
- `OPTIMIZE INDEX` never changes what `fts_match` returns, even over several transactions' rows, deletes and updates.
  It succeeds while another transaction's inserts are pending, and that one still commits.
  If it overlaps a delete or update, one side may fail and retry once the other ends, but deleted rows and replaced text never come back.
- Search stays quick on a bigger table.
  After about ten thousand rows are loaded in one transaction with multi-row `INSERT` statements of 500 rows each, a few hundred single-word `fts_match` lookups, each run as its own statement, finish within 20 seconds, even in a debug build.
- Committed FTS data survives closing and reopening the database, with or without MVCC, including deletes, updates and an `OPTIMIZE INDEX`.
  After reopening, `fts_match` returns the same rows as before and the index keeps accepting writes.
- When a statement fails, the FTS index matches exactly the rows the table kept, with or without MVCC.
  A failed multi-row `INSERT` leaves nothing searchable, `INSERT OR FAIL` keeps the rows before the failing one searchable, and rows a trigger writes into the indexed table are searchable, or gone when the trigger's statement fails.
