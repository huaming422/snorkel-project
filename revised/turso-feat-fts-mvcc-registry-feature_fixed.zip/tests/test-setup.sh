#!/usr/bin/env bash
# Verifier-side setup: runs before the verifier, with network available.
# The image already installed the Rust toolchain, warmed the cargo registry,
# and pre-built the workspace with --all-features at the base commit; this
# re-exports the toolchain onto PATH (each Modal phase starts a fresh shell)
# and confirms the canonical verifier venv is intact.
set -euo pipefail

# Re-export the Rust toolchain. These match the image ENV; the sandbox does
# not inherit Dockerfile RUN-line envs across phases.
export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
export PATH="$CARGO_HOME/bin:$PATH"

# The toolchain must be present (baked by the image).
rustc --version >/dev/null 2>&1 || {
    echo "ERROR: rustc not found on PATH (CARGO_HOME=$CARGO_HOME)" >&2
    exit 1
}
cargo --version >/dev/null 2>&1 || {
    echo "ERROR: cargo not found on PATH" >&2
    exit 1
}

# The canonical verifier interpreter lives in the isolated /opt/tooling venv.
VERIFIER_PYTHON="${VERIFIER_PYTHON:-/opt/tooling/venv/bin/python}"
"$VERIFIER_PYTHON" -c "import pytest" >/dev/null 2>&1 || {
    echo "ERROR: verifier venv missing pytest at $VERIFIER_PYTHON" >&2
    exit 1
}

echo "test-setup: rustc=$(rustc --version), cargo=$(cargo --version | head -1), verifier=$($VERIFIER_PYTHON -V)"
