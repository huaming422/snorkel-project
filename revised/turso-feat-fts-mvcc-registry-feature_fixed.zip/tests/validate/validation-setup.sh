#!/usr/bin/env bash
# Validation-phase setup for turso-feat-fts-mvcc-registry.
#
# Sourced by tests/test.sh AFTER the code changes under test have been applied
# to /repo/turso and BEFORE the test runner writes its cargo-test story
# files. Three jobs:
#
#   1. Give `core_tester` the `serde` (derive) + `serde_json` dev-dependencies
#      that the cargo-test driver's auto-injected `validation_params.rs` helper
#      needs (`use serde::Deserialize; use serde_json::Value;`). `core_tester`
#      does not declare them directly, but both are already fully resolved in
#      the workspace Cargo.lock, so we add them to the manifest AND record them
#      on the `core_tester` lock entry - no network, no version drift.
#   2. Stage the pre-registry FTS fixture database (shipped alongside this
#      script in /tests/validate/) at the stable path the stories read via
#      inputs["fixture_path"]. Stories copy it again to their own temp dir
#      before opening, so this staged copy stays pristine.
#   3. Warm the `core_tester` test build so the first injected story compiles
#      and runs in seconds.
#
# This script is sourced, so it uses `return` (never `exit`) for early outs and
# keeps `set -euo pipefail` scoped to its own body.
set -euo pipefail

# Re-export the Rust toolchain baked by the image (a fresh Modal phase does not
# inherit Dockerfile RUN-line env).
export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
export PATH="$CARGO_HOME/bin:$PATH"

REPO_DIR="${REPO_DIR:-/repo/turso}"
CARGO_TOML="${REPO_DIR}/tests/Cargo.toml"
CARGO_LOCK="${REPO_DIR}/Cargo.lock"

# Directory this script was sourced from (/tests/validate in the image), so we
# can find the fixture that ships beside it.
_SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FIXTURE_SRC="${_SELF_DIR}/fts_pre_registry_v0.8.0-pre.7.db"
FIXTURE_DST_DIR="/tmp/fts_fixtures"
FIXTURE_DST="${FIXTURE_DST_DIR}/fts_pre_registry.db"

echo "validation-setup: rustc=$(rustc --version 2>&1 | head -1), cargo=$(cargo --version 2>&1 | head -1)"

if [ ! -f "$CARGO_TOML" ]; then
    echo "validation-setup: ERROR - $CARGO_TOML not found; cannot wire serde dev-deps." >&2
    return 1
fi

# --------------------------------------------------------------------------
# Step 1a: add serde + serde_json to core_tester's [dev-dependencies].
# Idempotent text edit (preserves the crate's existing dev-deps).
# --------------------------------------------------------------------------
"${VERIFIER_PYTHON:-/opt/tooling/venv/bin/python}" - "$CARGO_TOML" <<'PY'
import sys, pathlib
p = pathlib.Path(sys.argv[1])
text = p.read_text()
lines = text.splitlines(keepends=True)

def has_dep(name: str) -> bool:
    for ln in lines:
        s = ln.strip()
        if s.startswith(f"{name} ") or s.startswith(f"{name}=") or s.startswith(f"{name}."):
            return True
    return False

add_serde = not has_dep("serde")
add_serde_json = not has_dep("serde_json")

if add_serde or add_serde_json:
    # Find the [dev-dependencies] table header; create it if missing.
    hdr = None
    for i, ln in enumerate(lines):
        if ln.strip() == "[dev-dependencies]":
            hdr = i
            break
    inserts = []
    if add_serde:
        inserts.append('serde = { version = "1", features = ["derive"] }\n')
    if add_serde_json:
        inserts.append('serde_json = "1"\n')
    if hdr is None:
        lines += ["\n", "[dev-dependencies]\n", *inserts]
    else:
        lines[hdr + 1:hdr + 1] = inserts
    p.write_text("".join(lines))
    print(f"validation-setup: added {'serde ' if add_serde else ''}"
          f"{'serde_json' if add_serde_json else ''} dev-dep(s) to {p}")
else:
    print(f"validation-setup: serde + serde_json already present in {p}")
PY

# --------------------------------------------------------------------------
# Step 1b: record serde / serde_json on the core_tester Cargo.lock entry so
# the offline build resolves them without regenerating the lockfile. Both are
# already locked elsewhere in the workspace, so no new version is selected.
# --------------------------------------------------------------------------
if [ -f "$CARGO_LOCK" ]; then
"${VERIFIER_PYTHON:-/opt/tooling/venv/bin/python}" - "$CARGO_LOCK" <<'PY'
import sys, pathlib, re
lock = pathlib.Path(sys.argv[1])
content = lock.read_text()

m = re.search(r'(\[\[package\]\]\nname = "core_tester"\n.*?dependencies = \[\n)(.*?)(\n\])',
              content, re.DOTALL)
if m is None:
    print("validation-setup: WARNING - core_tester package/dependencies not found in Cargo.lock")
    sys.exit(0)

head, body, tail = m.group(1), m.group(2), m.group(3)
dep_lines = body.splitlines()
have = {ln.strip().strip(',').strip('"') for ln in dep_lines}

def ins(name):
    if name in have:
        return False
    dep_lines.append(f' "{name}",')
    have.add(name)
    return True

changed = False
changed |= ins("serde")
changed |= ins("serde_json")

if not changed:
    print("validation-setup: core_tester Cargo.lock entry already lists serde + serde_json")
    sys.exit(0)

# Keep the dependency list sorted the way cargo writes it.
dep_lines = sorted(dep_lines, key=lambda s: s.strip().strip(',').strip('"'))
new_body = "\n".join(dep_lines)
new_content = content[:m.start()] + head + new_body + tail + content[m.end():]
import tempfile, os
tmp = lock.with_suffix(".tmp_setup")
tmp.write_text(new_content)
os.replace(tmp, lock)
print("validation-setup: inserted serde + serde_json into core_tester Cargo.lock entry")
PY
else
    echo "validation-setup: WARNING - $CARGO_LOCK not found; relying on manifest resolution."
fi

# --------------------------------------------------------------------------
# Step 2: stage the pre-registry FTS fixture at the stable path the stories
# read. Keep the staged copy read-only-ish (stories copy it again before use).
# --------------------------------------------------------------------------
if [ ! -f "$FIXTURE_SRC" ]; then
    echo "validation-setup: ERROR - fixture not found at $FIXTURE_SRC" >&2
    return 1
fi
mkdir -p "$FIXTURE_DST_DIR"
cp -f "$FIXTURE_SRC" "$FIXTURE_DST"
echo "validation-setup: staged legacy FTS fixture at $FIXTURE_DST ($(wc -c < "$FIXTURE_DST") bytes)"

# --------------------------------------------------------------------------
# Step 3: warm the core_tester test build (incremental on the pre-warmed
# target dir). Loud on failure: a broken build here would make every story
# fail with the same opaque compile error, so surface it now.
# --------------------------------------------------------------------------
echo "validation-setup: warming core_tester test build (incremental)..."
(
    cd "$REPO_DIR"
    cargo build -p core_tester --lib --features fts > /tmp/ssb-val-warm.log 2>&1
) || { echo "validation-setup: ERROR - core_tester build failed:" >&2; tail -80 /tmp/ssb-val-warm.log >&2; return 1; }

echo "validation-setup: done - serde dev-deps wired, fixture staged, build warmed."
