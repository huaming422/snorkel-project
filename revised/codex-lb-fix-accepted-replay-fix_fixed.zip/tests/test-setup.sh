#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
#
# This task's verifiers boot the codex-lb ASGI app in-process and drive its two
# client surfaces (POST /v1/responses SSE bridge + the /backend-api/codex/responses
# WebSocket) with a fake upstream. Everything runs in-memory on a throwaway
# SQLite database that the repo's own conftest creates automatically
# (CODEX_LB_DATABASE_URL defaults to sqlite+aiosqlite:///<tmp>/codex-lb.db). There
# are NO external services to start: no Postgres, no network.
#
# The image baked the full dependency closure at the base commit into /opt/venv
# (uv sync --frozen). This step only confirms the project environment is present
# offline-first and does not fetch anything, so it passes inside
# `docker run --network none`.

# The PythonRunner resolves the repo under /repo/$REPO_NAME and runs the
# verifier with that as its working directory.
export REPO_NAME=codex-lb

cd /repo/codex-lb

# Cut the network for uv so a cache miss fails fast instead of reaching PyPI.
export UV_OFFLINE=1

# Dependencies: offline-first against the image bake, logged online fallback.
if uv sync --frozen --all-extras --group dev --offline > /tmp/test-setup-install.log 2>&1; then
    echo "[offline-first] codex-lb deps satisfied from image bake"
elif { unset UV_OFFLINE; uv sync --frozen --all-extras --group dev; } >> /tmp/test-setup-install.log 2>&1; then
    echo "[test-setup] codex-lb deps installed online (image bake was stale)"
    export UV_OFFLINE=1
else
    echo "[test-setup] dependency install failed:" >&2
    tail -60 /tmp/test-setup-install.log >&2
    exit 1
fi

# No services to start and no data to seed: the checked behavior is
# driven entirely by the injected fake upstream inside each verifier test.
