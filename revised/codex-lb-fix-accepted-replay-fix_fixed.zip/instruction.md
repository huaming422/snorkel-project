## Task

Our codex-lb proxy used to cope with upstream capacity trouble, and lately it doesn't.

Operators keep reporting the same pattern.
A pooled account accepts a request, and the client gets `response.created` and `response.in_progress` back.
Then, before that account has streamed any output, it fails with an overload or "model at capacity" error.
The proxy hands that error straight to the client and the turn is dead, when it should have quietly moved the request to a different account in the pool.

The few retries that do happen don't look right to the client either.
The response seems to begin again, and a second `response.created` shows up in the middle of the stream.

We see this on HTTP streaming calls that the dashboard's HTTP client routing puts on a persistent upstream session, and on direct WebSocket connections.

The retry we want is a narrow one.
If an accepted turn fails for a capacity reason before producing any output, re-send it on another account.
The client should then see one response from start to finish: a single `response.created`, no repeated `response.in_progress`, every event under the response id it got first, and the other account's answer at the end, as though the first account had worked.
Don't re-send a turn that already streamed some output, or one whose failure event reports output items or billed output tokens, because the account has already been charged for it.
Usage-limit, rate-limit and quota errors after acceptance are not capacity problems either, so those also go to the client as they are.

Please work out why these accepted-then-failed requests aren't being retried cleanly, and fix it.
