## Task

In the literature library, the reference detail pane drifts away from the reference that's really open when people open, edit and switch references quickly.
It's all timing-dependent, but these are the cases we keep hitting.

Say I save an edit, close the pane, and open the same reference again (from global search, for example) and get a newer version than the one I saved.
When the old save finishes reading back, it swaps the pane back to the older copy.
A metadata lookup does the same: I start a DOI search, close the pane, reopen the reference after it has changed, go back to Complete metadata, and the old search result turns up there when it arrives.
The pane should stay on what I reopened, and my next Save should go against that version.

Opening a reference from global search or from a reference mention in chat takes a moment to load.
If I click a different reference in the list during that moment, the one I asked for first pops up over the one I just clicked.

If I add a PDF and the reference's metadata changes while the import is still running (I close and reopen it and get a newer version), the finished import puts the old title and fields back in the pane.
The PDF should show up with the current metadata.

When a background metadata job finishes a reference I have open, the list gets the new values but the pane keeps the old ones, so a Save from the pane goes against the stale version.
The pane should move to the new version too.
If the job finished several references on the page and one of them can't be read, none of them update.
The readable ones should still update, and the usual "Literature could not be loaded." error should still show for the one that failed.
If the new version arrives while I'm editing, my draft has to stay exactly as I typed it, and Save should stay off so the draft can't be written over the newer version.
If I'm looking at a metadata lookup preview when a newer version arrives, that preview is out of date and should go away.
The identifier field and Search should keep working, so I can search again and apply the result to the new version.
An update that only adds an attachment and leaves the metadata alone shouldn't drop the preview.

After I save an edit in the pane, the row in the list looks right at first.
If I switch to Inbox and back to All references, the old values are back.

Sometimes a save goes through but reading the reference back afterwards fails.
The pane then says "Literature could not be updated." and the only way out is pressing Save again, which sends the same change against the old version and fails.
It shouldn't say the update failed when it didn't.
Keep what I typed in the form and give me a Retry button that only reads the reference back, without sending the write again.

Any new text on screen needs entries in all eight locale catalogs, like the rest of the library.
