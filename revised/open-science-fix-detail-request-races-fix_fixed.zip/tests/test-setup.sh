#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
# Renderer vitest + i18n check; no services, no data seeding, jsdom only.
cd /repo/open-science

# Keep npm silent and offline. The image layer already baked a complete, valid
# node_modules at the pinned commit (its own `npm ci`), so the verifier needs
# nothing from the registry.
export npm_config_offline=true
export npm_config_update_notifier=false
export npm_config_fund=false
export npm_config_audit=false

# Dependencies are IDEMPOTENT and NON-DESTRUCTIVE. `npm ci` would first delete
# node_modules and then re-run this package's postinstall chain (electron binary
# fetch, prisma generate, electron-builder install-app-deps, native rebuilds),
# every one of which reaches the network and, with egress cut, retries until the
# time budget runs out instead of failing fast. So only restore the tree when a
# code change invalidated it, and always restore WITHOUT
# running scripts. A healthy image bake makes this a no-op.
if [ ! -x node_modules/.bin/vitest ]; then
    echo "[test-setup] vitest missing, restoring deps offline, no scripts" >&2
    npm ci --offline --ignore-scripts > /tmp/test-setup-install.log 2>&1 \
        || { tail -40 /tmp/test-setup-install.log >&2; exit 1; }
fi

echo "[test-setup] ready (vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown))"
