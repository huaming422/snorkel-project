#!/usr/bin/env bash
# All deps (Go toolchain, module cache, prewarmed build cache) are baked into
# the image at the base commit; nothing to fetch or install at verifier time.
set -euo pipefail
echo "[test-setup] no-op for freehire-fix-hh-detail-hydration"
