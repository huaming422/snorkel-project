// Checks for the hh.ru source adapter and the egress tiers it takes part in. These run as
// `package sources` to reach the registry (All), the exported tier entry points and the
// HydratingSource interface. They name no adapter field, constructor or tier-map key, and they
// build their own hh.ru pages in the site's own formats (the HH-Lux-InitialState search state,
// the vacancy page's JobPosting ld+json and the api.hh.ru vacancy JSON).
//
// The hh crawl checks build the registry the way the ingest worker does (All, then the proxy
// tier, then the hosted tier) and run FetchNew for new postings. Every request the hh entry
// makes, through any outgoing transport it holds or through http.DefaultTransport, goes to a
// local page server instead of the internet. That server redirects a vacancy page requested
// through the egress proxy to a CAPTCHA page, and serves every other page normally.
package sources

import (
	"context"
	"encoding/json"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"net/url"
	"path"
	"reflect"
	"strconv"
	"strings"
	"testing"
	"unsafe"
)

const verifyProxyURL = "http://user:pass@proxy.example:8080"

// verifyPosting is one hh.ru vacancy as the search state lists it, plus the description its
// vacancy page carries.
type verifyPosting struct {
	id      int64
	title   string
	company string
	body    string
}

func (p verifyPosting) idString() string { return strconv.FormatInt(p.id, 10) }

// searchPageHTML renders a search page the way hh.ru does: the result list sits in the
// HH-Lux-InitialState template as JSON.
func searchPageHTML(ps []verifyPosting) string {
	vacancies := make([]map[string]any, 0, len(ps))
	for _, p := range ps {
		vacancies = append(vacancies, map[string]any{
			"vacancyId": p.id,
			"name":      p.title,
			"company":   map[string]any{"visibleName": p.company},
			"links":     map[string]any{"desktop": "https://hh.ru/vacancy/" + p.idString()},
		})
	}
	state, _ := json.Marshal(map[string]any{"vacancySearchResult": map[string]any{"vacancies": vacancies}})
	return `<html><body><template style="display:none" id="HH-Lux-InitialState">` +
		string(state) + `</template></body></html>`
}

// vacancyPageHTML renders a vacancy page carrying its description in a JobPosting ld+json block.
func vacancyPageHTML(body string) string {
	ld, _ := json.Marshal(map[string]any{"@type": "JobPosting", "description": body})
	return `<html><body><script type="application/ld+json">` + string(ld) + `</script></body></html>`
}

// vacancyJSON renders a vacancy the way the api.hh.ru vacancy endpoint does, description included.
func vacancyJSON(p verifyPosting) string {
	b, _ := json.Marshal(map[string]any{
		"id":            p.idString(),
		"name":          p.title,
		"description":   p.body,
		"employer":      map[string]any{"name": p.company},
		"alternate_url": "https://hh.ru/vacancy/" + p.idString(),
	})
	return string(b)
}

const captchaPageHTML = `<html><body><form method="post" action="/account/captcha">` +
	`<img src="/captcha/picture"><input name="captchaText"></form></body></html>`

// hhPageServer answers hh.ru search pages, vacancy pages and api.hh.ru vacancy JSON, directly or
// wrapped in the hosted scraping API's envelope. Page 0 of the search lists the postings; later
// pages are empty.
type hhPageServer struct {
	postings []verifyPosting
}

// page returns the body and content type hh.ru serves for target, or ok=false for a page it
// does not have.
func (s *hhPageServer) page(target *url.URL) (body, contentType string, ok bool) {
	const htmlType, jsonType = "text/html; charset=utf-8", "application/json"
	switch {
	case strings.Contains(target.Path, "/search/vacancy"):
		if n, _ := strconv.Atoi(target.Query().Get("page")); n == 0 {
			return searchPageHTML(s.postings), htmlType, true
		}
		return searchPageHTML(nil), htmlType, true
	case strings.HasPrefix(target.Path, "/vacancy/"), strings.HasPrefix(target.Path, "/vacancies/"):
		for _, p := range s.postings {
			if p.idString() != path.Base(target.Path) {
				continue
			}
			if strings.HasPrefix(target.Path, "/vacancies/") {
				return vacancyJSON(p), jsonType, true
			}
			return vacancyPageHTML(p.body), htmlType, true
		}
	case strings.HasPrefix(target.Path, "/account/captcha"):
		return captchaPageHTML, htmlType, true
	}
	return "", "", false
}

// handler serves the pages. When viaProxy is set the caller's requests go through the egress
// proxy, and a vacancy page asked for straight from hh.ru is redirected to the CAPTCHA page.
func (s *hhPageServer) handler(viaProxy bool) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		target, hosted := r.URL, false
		if r.Method == http.MethodPost && strings.HasSuffix(r.URL.Path, "/v1/scrape") {
			var in struct {
				URL string `json:"url"`
			}
			if err := json.NewDecoder(r.Body).Decode(&in); err != nil {
				http.Error(w, err.Error(), http.StatusBadRequest)
				return
			}
			u, err := url.Parse(in.URL)
			if err != nil {
				http.Error(w, err.Error(), http.StatusBadRequest)
				return
			}
			target, hosted = u, true
		}
		if viaProxy && !hosted && strings.HasPrefix(target.Path, "/vacancy/") {
			back := "https://hh.ru" + target.RequestURI()
			http.Redirect(w, r, "https://hh.ru/account/captcha?backurl="+url.QueryEscape(back), http.StatusFound)
			return
		}
		body, contentType, ok := s.page(target)
		if !ok {
			http.NotFound(w, r)
			return
		}
		if hosted {
			env, _ := json.Marshal(map[string]any{
				"success": true,
				"data":    map[string]any{"rawHtml": body, "metadata": map[string]any{"statusCode": 200}},
			})
			body, contentType = string(env), "application/json"
		}
		w.Header().Set("Content-Type", contentType)
		_, _ = io.WriteString(w, body)
	})
}

type ptrKey struct {
	addr uintptr
	typ  reflect.Type
}

// transportsIn returns every outgoing *http.Transport reachable from v, whatever type holds it.
func transportsIn(v any) []*http.Transport {
	transportType := reflect.TypeOf(http.Transport{})
	seen := map[ptrKey]bool{}
	var out []*http.Transport
	var walk func(reflect.Value)
	walk = func(rv reflect.Value) {
		switch rv.Kind() {
		case reflect.Pointer:
			if rv.IsNil() {
				return
			}
			k := ptrKey{rv.Pointer(), rv.Type()}
			if seen[k] {
				return
			}
			seen[k] = true
			if rv.Type().Elem() == transportType {
				out = append(out, (*http.Transport)(unsafe.Pointer(rv.Pointer())))
				return
			}
			walk(rv.Elem())
		case reflect.Interface:
			if !rv.IsNil() {
				walk(rv.Elem())
			}
		case reflect.Struct:
			if rv.Type() == transportType {
				if rv.CanAddr() {
					out = append(out, (*http.Transport)(unsafe.Pointer(rv.UnsafeAddr())))
				}
				return
			}
			for i := 0; i < rv.NumField(); i++ {
				walk(rv.Field(i))
			}
		case reflect.Slice, reflect.Array:
			for i := 0; i < rv.Len(); i++ {
				walk(rv.Index(i))
			}
		case reflect.Map:
			it := rv.MapRange()
			for it.Next() {
				walk(it.Value())
			}
		}
	}
	walk(reflect.ValueOf(v))
	return out
}

// viaEgressProxy reports whether tr sends an hh.ru request through the proxy SOURCES_PROXY_URL
// names.
func viaEgressProxy(tr *http.Transport) bool {
	if tr.Proxy == nil {
		return false
	}
	req, _ := http.NewRequest(http.MethodGet, "https://hh.ru/", nil)
	u, err := tr.Proxy(req)
	want, _ := url.Parse(verifyProxyURL)
	return err == nil && u != nil && u.Host == want.Host
}

// throughEgressProxy reports whether any transport reachable from v goes through the egress proxy.
func throughEgressProxy(v any) bool {
	for _, tr := range transportsIn(v) {
		if viaEgressProxy(tr) {
			return true
		}
	}
	return false
}

// routeTransportsTo makes every transport reachable from v, and http.DefaultTransport, dial a
// local server running server instead of the host a request names. A transport that goes
// through the egress proxy reaches it as a proxied caller. Each transport is put back when the
// test ends.
func routeTransportsTo(t *testing.T, v any, server *hhPageServer) {
	t.Helper()
	direct := httptest.NewServer(server.handler(false))
	t.Cleanup(direct.Close)
	viaProxy := httptest.NewServer(server.handler(true))
	t.Cleanup(viaProxy.Close)

	transports := transportsIn(v)
	if dt, ok := http.DefaultTransport.(*http.Transport); ok {
		transports = append(transports, dt)
	}
	done := map[*http.Transport]bool{}
	for _, tr := range transports {
		if done[tr] {
			continue
		}
		done[tr] = true
		addr := direct.Listener.Addr().String()
		if viaEgressProxy(tr) {
			addr = viaProxy.Listener.Addr().String()
		}
		dial := func(ctx context.Context, _, _ string) (net.Conn, error) {
			var d net.Dialer
			return d.DialContext(ctx, "tcp", addr)
		}
		proxy, dialContext, dialTLSContext := tr.Proxy, tr.DialContext, tr.DialTLSContext
		tr.CloseIdleConnections()
		// The local server speaks plain HTTP, so the TLS dial hands back the plain connection.
		tr.Proxy, tr.DialContext, tr.DialTLSContext = nil, dial, dial
		t.Cleanup(func() {
			tr.CloseIdleConnections()
			tr.Proxy, tr.DialContext, tr.DialTLSContext = proxy, dialContext, dialTLSContext
		})
	}
}

// productionRegistry builds the full registry and applies the proxy tier and then the hosted tier,
// in the order the ingest worker applies them, under whatever egress settings the test has set.
func productionRegistry(t *testing.T) map[string]Source {
	t.Helper()
	registry := All(NewClient())
	if err := ApplyProxyEgress(registry); err != nil {
		t.Fatalf("ApplyProxyEgress: %v", err)
	}
	if err := ApplyFirecrawlEgress(registry); err != nil {
		t.Fatalf("ApplyFirecrawlEgress: %v", err)
	}
	return registry
}

// crawlNewHHPostings builds the registry under the current egress settings, points hh's requests
// at a page server holding postings, runs FetchNew with every posting new, and checks that it
// finished without error and that every posting came back with its own description.
func crawlNewHHPostings(t *testing.T, postings []verifyPosting) {
	t.Helper()
	src, ok := productionRegistry(t)["hh"]
	if !ok || src == nil {
		t.Fatal("hh is missing from the registry")
	}
	hs, ok := src.(HydratingSource)
	if !ok {
		t.Fatalf("hh (%T) no longer hydrates descriptions per posting", src)
	}
	routeTransportsTo(t, src, &hhPageServer{postings: postings})
	jobs, err := hs.FetchNew(context.Background(), CompanyEntry{Board: "96"}, func(string) bool { return false })
	if err != nil {
		t.Fatalf("FetchNew: %v", err)
	}
	got := map[string]string{}
	for _, j := range jobs {
		got[j.ExternalID] = j.Description
	}
	for _, p := range postings {
		want := strings.TrimSuffix(strings.TrimPrefix(p.body, "<p>"), "</p>")
		if !strings.Contains(got[p.idString()], want) {
			t.Errorf("posting %d did not get its description: %q", p.id, got[p.idString()])
		}
	}
}

// TestVerifyHHDetailHydratesInProduction: with the egress proxy and a hosted-tier key both
// configured and every tier applied, a crawl of hh brings in each new posting with its own
// description, while a vacancy page asked for through the egress proxy gets the CAPTCHA page.
func TestVerifyHHDetailHydratesInProduction(t *testing.T) {
	t.Setenv("SOURCES_PROXY_URL", verifyProxyURL)
	t.Setenv("FIRECRAWL_API_KEY", "verify-key")
	crawlNewHHPostings(t, []verifyPosting{
		{4711, "Backend Engineer", "Ozon", "<p>Backend body for 4711.</p>"},
		{5822, "SRE", "Avito", "<p>SRE body for 5822.</p>"},
	})
}

// TestVerifyOtherProvidersKeepTheirEgress: boards that go through the proxy keep going through it,
// and boards that crawl directly stay off it, with and without a hosted-tier key.
func TestVerifyOtherProvidersKeepTheirEgress(t *testing.T) {
	viaProxy := []string{"djinni", "habr_career", "enlizt", "2gis"}
	direct := []string{"greenhouse", "lever", "ashby"}
	for _, key := range []string{"", "verify-key"} {
		t.Run("hosted_key="+key, func(t *testing.T) {
			t.Setenv("SOURCES_PROXY_URL", verifyProxyURL)
			t.Setenv("FIRECRAWL_API_KEY", key)
			registry := productionRegistry(t)
			for _, name := range viaProxy {
				src, ok := registry[name]
				if !ok {
					t.Errorf("%s is missing from the registry", name)
					continue
				}
				if !throughEgressProxy(src) {
					t.Errorf("%s no longer goes through the egress proxy", name)
				}
			}
			for _, name := range direct {
				src, ok := registry[name]
				if !ok {
					t.Errorf("%s is missing from the registry", name)
					continue
				}
				if throughEgressProxy(src) {
					t.Errorf("%s now goes through the egress proxy", name)
				}
			}
		})
	}
}

// TestVerifyHHDevPathHydrates: with neither the egress proxy nor a hosted-tier key set, as on a
// laptop, a crawl of hh brings in each new posting with its own description.
func TestVerifyHHDevPathHydrates(t *testing.T) {
	t.Setenv("SOURCES_PROXY_URL", "")
	t.Setenv("FIRECRAWL_API_KEY", "")
	crawlNewHHPostings(t, []verifyPosting{
		{101, "Go Developer", "Контур", "<p>Full description body for 101.</p>"},
		{202, "Data Engineer", "Сбер", "<p>Full description body for 202.</p>"},
	})
}
