// Checks for the hh.ru source adapter and the egress tiers it takes part in. These run as
// `package sources` to reach the package's own test helpers (hhVac, hhFake) and the exported
// tier entry points. They name no adapter field, constructor or tier-map key.
//
// The routing checks build the registry the way the ingest worker does (All, then the proxy tier,
// then the hosted tier) and look at the outgoing HTTP transports a provider can reach. A transport
// configured with an HTTP proxy is one whose requests go through SOURCES_PROXY_URL. The dev path
// check drives the public FetchNew path with no egress tier applied.
package sources

import (
	"context"
	"io"
	"net/http"
	"net/url"
	"reflect"
	"strings"
	"testing"

	"golang.org/x/net/html"
)

const verifyProxyURL = "http://user:pass@proxy.example:8080"

// egressOf walks everything reachable from v and reports whether it holds an outgoing transport
// that sends requests through an HTTP proxy, and whether it holds one that sends them without a
// proxy. An http.Client with no Transport uses the default one, which counts as unproxied here.
func egressOf(v any) (proxied, unproxied bool) {
	transportType := reflect.TypeOf(http.Transport{})
	clientType := reflect.TypeOf(http.Client{})
	type ptrKey struct {
		addr uintptr
		typ  reflect.Type
	}
	seen := map[ptrKey]bool{}
	var walk func(reflect.Value)
	walk = func(rv reflect.Value) {
		switch rv.Kind() {
		case reflect.Pointer:
			if rv.IsNil() {
				return
			}
			k := ptrKey{rv.Pointer(), rv.Type()}
			if seen[k] {
				return
			}
			seen[k] = true
			walk(rv.Elem())
		case reflect.Interface:
			if !rv.IsNil() {
				walk(rv.Elem())
			}
		case reflect.Struct:
			switch rv.Type() {
			case transportType:
				if rv.FieldByName("Proxy").IsNil() {
					unproxied = true
				} else {
					proxied = true
				}
				return
			case clientType:
				if rv.FieldByName("Transport").IsNil() {
					unproxied = true
					return
				}
			}
			for i := 0; i < rv.NumField(); i++ {
				walk(rv.Field(i))
			}
		case reflect.Slice, reflect.Array:
			for i := 0; i < rv.Len(); i++ {
				walk(rv.Index(i))
			}
		case reflect.Map:
			it := rv.MapRange()
			for it.Next() {
				walk(it.Value())
			}
		}
	}
	walk(reflect.ValueOf(v))
	return proxied, unproxied
}

// productionRegistry builds the full registry and applies the proxy tier and then the hosted tier,
// in the order the ingest worker applies them, under whatever egress settings the test has set.
func productionRegistry(t *testing.T) map[string]Source {
	t.Helper()
	registry := All(NewClient())
	if err := ApplyProxyEgress(registry); err != nil {
		t.Fatalf("ApplyProxyEgress: %v", err)
	}
	if err := ApplyFirecrawlEgress(registry); err != nil {
		t.Fatalf("ApplyFirecrawlEgress: %v", err)
	}
	return registry
}

// assertHHOffProxy checks that hh is still a hydrating source, still has an outgoing transport,
// and that none of the transports it can reach goes through the proxy.
func assertHHOffProxy(t *testing.T, registry map[string]Source) {
	t.Helper()
	src, ok := registry["hh"]
	if !ok || src == nil {
		t.Fatal("hh is missing from the registry")
	}
	if _, ok := src.(HydratingSource); !ok {
		t.Fatalf("hh (%T) no longer hydrates descriptions per posting", src)
	}
	proxied, unproxied := egressOf(src)
	if proxied {
		t.Error("hh sends requests through the shared egress proxy")
	}
	if !unproxied {
		t.Error("hh has no outgoing transport left to fetch its pages with")
	}
}

// TestVerifyHHOffProxyWithProxyConfigured: with the egress proxy configured and no hosted-tier
// key, none of hh's requests go through the proxy.
func TestVerifyHHOffProxyWithProxyConfigured(t *testing.T) {
	t.Setenv("SOURCES_PROXY_URL", verifyProxyURL)
	t.Setenv("FIRECRAWL_API_KEY", "")
	assertHHOffProxy(t, productionRegistry(t))
}

// TestVerifyHHOffProxyWithHostedKey: with the egress proxy and a hosted-tier key both configured,
// none of hh's requests go through the proxy after every tier is applied.
func TestVerifyHHOffProxyWithHostedKey(t *testing.T) {
	t.Setenv("SOURCES_PROXY_URL", verifyProxyURL)
	t.Setenv("FIRECRAWL_API_KEY", "verify-key")
	assertHHOffProxy(t, productionRegistry(t))
}

// TestVerifyOtherProvidersKeepTheirEgress: boards that go through the proxy keep going through it,
// and boards that crawl directly stay off it, with and without a hosted-tier key.
func TestVerifyOtherProvidersKeepTheirEgress(t *testing.T) {
	viaProxy := []string{"djinni", "habr_career", "enlizt", "2gis"}
	direct := []string{"greenhouse", "lever", "ashby"}
	for _, key := range []string{"", "verify-key"} {
		t.Run("hosted_key="+key, func(t *testing.T) {
			t.Setenv("SOURCES_PROXY_URL", verifyProxyURL)
			t.Setenv("FIRECRAWL_API_KEY", key)
			registry := productionRegistry(t)
			for _, name := range viaProxy {
				src, ok := registry[name]
				if !ok {
					t.Errorf("%s is missing from the registry", name)
					continue
				}
				if proxied, _ := egressOf(src); !proxied {
					t.Errorf("%s no longer goes through the egress proxy", name)
				}
			}
			for _, name := range direct {
				src, ok := registry[name]
				if !ok {
					t.Errorf("%s is missing from the registry", name)
					continue
				}
				if proxied, _ := egressOf(src); proxied {
					t.Errorf("%s now goes through the egress proxy", name)
				}
			}
		})
	}
}

// fullHHFake adapts the package's hh recording getter (hhFake, which implements only GetHTML) up to
// the full HTTPClient surface All() expects, so the dev path can be driven through the public
// registry instead of any adapter constructor. Every page the hh crawl reads through GetHTML lands
// on the embedded hhFake and its recorders; the other transport methods are unused by hh and stub
// out.
type fullHHFake struct {
	*hhFake
}

func (fullHHFake) GetJSON(context.Context, string, any) error { return nil }
func (fullHHFake) GetJSONResolved(_ context.Context, u string, _ any) (string, error) {
	return u, nil
}
func (fullHHFake) GetStream(context.Context, string, string, func(io.Reader) error) error {
	return nil
}
func (fullHHFake) GetXML(context.Context, string, any) error { return nil }
func (fullHHFake) GetHTMLResolved(_ context.Context, u string) (*html.Node, string, error) {
	return nil, u, nil
}
func (fullHHFake) GetText(context.Context, string) (string, error) { return "", nil }
func (fullHHFake) GetTextWithHeaders(context.Context, string, map[string]string) (string, error) {
	return "", nil
}
func (fullHHFake) GetLargeText(context.Context, string) (string, error) { return "", nil }
func (fullHHFake) PostJSON(context.Context, string, any, any) error     { return nil }
func (fullHHFake) GetJSONWithHeaders(context.Context, string, map[string]string, any) error {
	return nil
}
func (fullHHFake) PostJSONWithHeaders(context.Context, string, map[string]string, any, any) error {
	return nil
}
func (fullHHFake) PostFormWithHeaders(context.Context, string, map[string]string, url.Values) (*html.Node, error) {
	return nil, nil
}
func (fullHHFake) CookieValue(string, string) string { return "" }

// TestVerifyHHDevPathHydrates: with no egress tier applied, a new posting gets its description
// from its vacancy page, read through the same client the registry was built with.
func TestVerifyHHDevPathHydrates(t *testing.T) {
	v := hhVac(101, "Go Developer", "Контур")
	fake := &hhFake{
		searchByPage: map[int][]hhVacancy{0: {v}},
		detailByID:   map[string]string{"101": "<p>Full description body.</p>"},
	}
	jobs, err := All(fullHHFake{fake})["hh"].(HydratingSource).
		FetchNew(context.Background(), CompanyEntry{Board: "96"}, func(string) bool { return false })
	if err != nil {
		t.Fatalf("FetchNew: %v", err)
	}
	if len(jobs) != 1 {
		t.Fatalf("len(jobs) = %d, want 1", len(jobs))
	}
	if d := jobs[0].Description; !strings.Contains(d, "Full description body") {
		t.Errorf("the description body from the vacancy page is missing: %q", d)
	}
	if len(fake.detailHits) != 1 || fake.detailHits[0] != "101" {
		t.Errorf("the vacancy page was not fetched for the new posting; detail hits = %v", fake.detailHits)
	}
}
