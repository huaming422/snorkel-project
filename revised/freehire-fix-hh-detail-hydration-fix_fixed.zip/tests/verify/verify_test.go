// Checks for the hh.ru source adapter and the egress tiers it takes part in. These run as
// `package sources` to reach the registry (All), the exported tier entry points and the
// HydratingSource and HTTPClient interfaces. They name no adapter field, constructor or tier-map
// key, and they build their own hh.ru pages in the site's own formats (the HH-Lux-InitialState
// search state and the vacancy page's JobPosting ld+json).
//
// The production checks build the registry the way the ingest worker does (All, then the proxy
// tier, then the hosted tier). The hh crawl check then points every HTTP client the hh entry holds
// at an in-process page server, noting for each client whether its own transport went through a
// proxy, and runs FetchNew. The dev path check drives FetchNew with no egress tier applied.
package sources

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"path"
	"reflect"
	"strconv"
	"strings"
	"sync"
	"testing"
	"unsafe"

	"golang.org/x/net/html"
)

const verifyProxyURL = "http://user:pass@proxy.example:8080"

// verifyPosting is one hh.ru vacancy as the search state lists it, plus the description its
// vacancy page carries.
type verifyPosting struct {
	id      int64
	title   string
	company string
	body    string
}

func (p verifyPosting) idString() string { return strconv.FormatInt(p.id, 10) }

// searchPageHTML renders a search page the way hh.ru does: the result list sits in the
// HH-Lux-InitialState template as JSON.
func searchPageHTML(ps []verifyPosting) string {
	vacancies := make([]map[string]any, 0, len(ps))
	for _, p := range ps {
		vacancies = append(vacancies, map[string]any{
			"vacancyId": p.id,
			"name":      p.title,
			"company":   map[string]any{"visibleName": p.company},
			"links":     map[string]any{"desktop": "https://hh.ru/vacancy/" + p.idString()},
		})
	}
	state, _ := json.Marshal(map[string]any{"vacancySearchResult": map[string]any{"vacancies": vacancies}})
	return `<html><body><template style="display:none" id="HH-Lux-InitialState">` +
		string(state) + `</template></body></html>`
}

// vacancyPageHTML renders a vacancy page carrying its description in a JobPosting ld+json block.
func vacancyPageHTML(body string) string {
	ld, _ := json.Marshal(map[string]any{"@type": "JobPosting", "description": body})
	return `<html><body><script type="application/ld+json">` + string(ld) + `</script></body></html>`
}

// hhPageServer answers hh.ru search and vacancy pages, directly or wrapped in the hosted scraping
// API's envelope, and records every page it serves together with whether the client that asked
// for it sends its requests through a proxy. Page 0 of the search lists the postings; later pages
// are empty.
type hhPageServer struct {
	postings []verifyPosting

	mu     sync.Mutex
	served []servedPage
}

type servedPage struct {
	kind    string // "listing" or "detail"
	id      string
	proxied bool
}

func (s *hhPageServer) page(target *url.URL, proxied bool) (string, error) {
	rec := servedPage{proxied: proxied}
	var page string
	switch {
	case strings.Contains(target.Path, "/search/vacancy"):
		rec.kind = "listing"
		if n, _ := strconv.Atoi(target.Query().Get("page")); n == 0 {
			page = searchPageHTML(s.postings)
		} else {
			page = searchPageHTML(nil)
		}
	case strings.HasPrefix(target.Path, "/vacancy/"):
		rec.kind, rec.id = "detail", path.Base(target.Path)
		found := false
		for _, p := range s.postings {
			if p.idString() == rec.id {
				page, found = vacancyPageHTML(p.body), true
			}
		}
		if !found {
			return "", fmt.Errorf("unknown vacancy %s", rec.id)
		}
	default:
		return "", fmt.Errorf("unexpected request %s", target)
	}
	s.mu.Lock()
	s.served = append(s.served, rec)
	s.mu.Unlock()
	return page, nil
}

func (s *hhPageServer) serve(proxied bool, req *http.Request) (*http.Response, error) {
	target, hosted := req.URL, false
	if req.Method == http.MethodPost && strings.HasSuffix(req.URL.Path, "/v1/scrape") {
		var in struct {
			URL string `json:"url"`
		}
		raw, err := io.ReadAll(req.Body)
		if err != nil {
			return nil, err
		}
		if err := json.Unmarshal(raw, &in); err != nil {
			return nil, err
		}
		if target, err = url.Parse(in.URL); err != nil {
			return nil, err
		}
		hosted = true
	}
	page, err := s.page(target, proxied)
	if err != nil {
		return nil, err
	}
	body, contentType := page, "text/html; charset=utf-8"
	if hosted {
		env, _ := json.Marshal(map[string]any{
			"success": true,
			"data":    map[string]any{"rawHtml": page, "metadata": map[string]any{"statusCode": 200}},
		})
		body, contentType = string(env), "application/json"
	}
	return &http.Response{
		StatusCode:    http.StatusOK,
		Status:        "200 OK",
		Header:        http.Header{"Content-Type": {contentType}},
		Body:          io.NopCloser(strings.NewReader(body)),
		ContentLength: int64(len(body)),
		Request:       req,
	}, nil
}

func (s *hhPageServer) detailPages() []servedPage {
	s.mu.Lock()
	defer s.mu.Unlock()
	var out []servedPage
	for _, p := range s.served {
		if p.kind == "detail" {
			out = append(out, p)
		}
	}
	return out
}

type recordingTransport struct {
	server  *hhPageServer
	proxied bool
}

func (t recordingTransport) RoundTrip(req *http.Request) (*http.Response, error) {
	return t.server.serve(t.proxied, req)
}

type ptrKey struct {
	addr uintptr
	typ  reflect.Type
}

// egressOf walks everything reachable from v and reports whether it holds an outgoing transport
// that sends requests through an HTTP proxy, and whether it holds one that sends them without a
// proxy. An http.Client with no Transport uses the default one, which counts as unproxied here.
func egressOf(v any) (proxied, unproxied bool) {
	transportType := reflect.TypeOf(http.Transport{})
	clientType := reflect.TypeOf(http.Client{})
	seen := map[ptrKey]bool{}
	var walk func(reflect.Value)
	walk = func(rv reflect.Value) {
		switch rv.Kind() {
		case reflect.Pointer:
			if rv.IsNil() {
				return
			}
			k := ptrKey{rv.Pointer(), rv.Type()}
			if seen[k] {
				return
			}
			seen[k] = true
			walk(rv.Elem())
		case reflect.Interface:
			if !rv.IsNil() {
				walk(rv.Elem())
			}
		case reflect.Struct:
			switch rv.Type() {
			case transportType:
				if rv.FieldByName("Proxy").IsNil() {
					unproxied = true
				} else {
					proxied = true
				}
				return
			case clientType:
				if rv.FieldByName("Transport").IsNil() {
					unproxied = true
					return
				}
			}
			for i := 0; i < rv.NumField(); i++ {
				walk(rv.Field(i))
			}
		case reflect.Slice, reflect.Array:
			for i := 0; i < rv.Len(); i++ {
				walk(rv.Index(i))
			}
		case reflect.Map:
			it := rv.MapRange()
			for it.Next() {
				walk(it.Value())
			}
		}
	}
	walk(reflect.ValueOf(v))
	return proxied, unproxied
}

// routeClientsTo points every http.Client reachable from v at server, keeping a note of whether
// that client's own transport went through a proxy. No request leaves the process afterwards.
func routeClientsTo(v any, server *hhPageServer) int {
	clientType := reflect.TypeOf(http.Client{})
	seen := map[ptrKey]bool{}
	routed := 0
	swap := func(c *http.Client) {
		proxied := false
		if c.Transport != nil {
			proxied, _ = egressOf(c.Transport)
		}
		c.Transport = recordingTransport{server: server, proxied: proxied}
		routed++
	}
	var walk func(reflect.Value)
	walk = func(rv reflect.Value) {
		switch rv.Kind() {
		case reflect.Pointer:
			if rv.IsNil() {
				return
			}
			k := ptrKey{rv.Pointer(), rv.Type()}
			if seen[k] {
				return
			}
			seen[k] = true
			if rv.Type().Elem() == clientType {
				swap((*http.Client)(unsafe.Pointer(rv.Pointer())))
				return
			}
			walk(rv.Elem())
		case reflect.Interface:
			if !rv.IsNil() {
				walk(rv.Elem())
			}
		case reflect.Struct:
			if rv.Type() == clientType {
				if rv.CanAddr() {
					swap((*http.Client)(unsafe.Pointer(rv.UnsafeAddr())))
				}
				return
			}
			for i := 0; i < rv.NumField(); i++ {
				walk(rv.Field(i))
			}
		case reflect.Slice, reflect.Array:
			for i := 0; i < rv.Len(); i++ {
				walk(rv.Index(i))
			}
		case reflect.Map:
			it := rv.MapRange()
			for it.Next() {
				walk(it.Value())
			}
		}
	}
	walk(reflect.ValueOf(v))
	return routed
}

// productionRegistry builds the full registry and applies the proxy tier and then the hosted tier,
// in the order the ingest worker applies them, under whatever egress settings the test has set.
func productionRegistry(t *testing.T) map[string]Source {
	t.Helper()
	registry := All(NewClient())
	if err := ApplyProxyEgress(registry); err != nil {
		t.Fatalf("ApplyProxyEgress: %v", err)
	}
	if err := ApplyFirecrawlEgress(registry); err != nil {
		t.Fatalf("ApplyFirecrawlEgress: %v", err)
	}
	return registry
}

// assertDescriptions checks that FetchNew finished without error and that every posting came back
// with its own description.
func assertDescriptions(t *testing.T, jobs []Job, err error, postings []verifyPosting) {
	t.Helper()
	if err != nil {
		t.Fatalf("FetchNew: %v", err)
	}
	got := map[string]string{}
	for _, j := range jobs {
		got[j.ExternalID] = j.Description
	}
	for _, p := range postings {
		want := strings.TrimSuffix(strings.TrimPrefix(p.body, "<p>"), "</p>")
		if !strings.Contains(got[p.idString()], want) {
			t.Errorf("posting %d did not get its description: %q", p.id, got[p.idString()])
		}
	}
}

// TestVerifyHHDetailHydratesOffProxyInProduction: with the egress proxy and a hosted-tier key both
// configured, after every tier is applied a crawl of hh hydrates each new posting's description,
// and no vacancy page is fetched through a client that goes through the proxy.
func TestVerifyHHDetailHydratesOffProxyInProduction(t *testing.T) {
	t.Setenv("SOURCES_PROXY_URL", verifyProxyURL)
	t.Setenv("FIRECRAWL_API_KEY", "verify-key")
	src, ok := productionRegistry(t)["hh"]
	if !ok || src == nil {
		t.Fatal("hh is missing from the registry")
	}
	hs, ok := src.(HydratingSource)
	if !ok {
		t.Fatalf("hh (%T) no longer hydrates descriptions per posting", src)
	}
	postings := []verifyPosting{
		{4711, "Backend Engineer", "Ozon", "<p>Backend body for 4711.</p>"},
		{5822, "SRE", "Avito", "<p>SRE body for 5822.</p>"},
	}
	server := &hhPageServer{postings: postings}
	if routeClientsTo(src, server) == 0 {
		t.Fatal("hh holds no HTTP client to fetch its pages with")
	}
	jobs, err := hs.FetchNew(context.Background(), CompanyEntry{Board: "96"}, func(string) bool { return false })
	assertDescriptions(t, jobs, err, postings)
	details := server.detailPages()
	if len(details) == 0 {
		t.Error("no vacancy page was fetched for the new postings")
	}
	for _, p := range details {
		if p.proxied {
			t.Errorf("vacancy page %s was fetched through the egress proxy", p.id)
		}
	}
}

// TestVerifyOtherProvidersKeepTheirEgress: boards that go through the proxy keep going through it,
// and boards that crawl directly stay off it, with and without a hosted-tier key.
func TestVerifyOtherProvidersKeepTheirEgress(t *testing.T) {
	viaProxy := []string{"djinni", "habr_career", "enlizt", "2gis"}
	direct := []string{"greenhouse", "lever", "ashby"}
	for _, key := range []string{"", "verify-key"} {
		t.Run("hosted_key="+key, func(t *testing.T) {
			t.Setenv("SOURCES_PROXY_URL", verifyProxyURL)
			t.Setenv("FIRECRAWL_API_KEY", key)
			registry := productionRegistry(t)
			for _, name := range viaProxy {
				src, ok := registry[name]
				if !ok {
					t.Errorf("%s is missing from the registry", name)
					continue
				}
				if proxied, _ := egressOf(src); !proxied {
					t.Errorf("%s no longer goes through the egress proxy", name)
				}
			}
			for _, name := range direct {
				src, ok := registry[name]
				if !ok {
					t.Errorf("%s is missing from the registry", name)
					continue
				}
				if proxied, _ := egressOf(src); proxied {
					t.Errorf("%s now goes through the egress proxy", name)
				}
			}
		})
	}
}

// devClient is the full HTTPClient All() expects, serving hh pages from an hhPageServer through
// GetHTML. The other transport methods are unused by hh and answer nothing.
type devClient struct {
	server *hhPageServer
}

func (c devClient) GetHTML(ctx context.Context, u string) (*html.Node, error) {
	target, err := url.Parse(u)
	if err != nil {
		return nil, err
	}
	page, err := c.server.page(target, false)
	if err != nil {
		return nil, err
	}
	return html.Parse(strings.NewReader(page))
}

func (devClient) GetJSON(context.Context, string, any) error { return nil }
func (devClient) GetJSONResolved(_ context.Context, u string, _ any) (string, error) {
	return u, nil
}
func (devClient) GetStream(context.Context, string, string, func(io.Reader) error) error {
	return nil
}
func (devClient) GetXML(context.Context, string, any) error { return nil }
func (devClient) GetHTMLResolved(_ context.Context, u string) (*html.Node, string, error) {
	return nil, u, nil
}
func (devClient) GetText(context.Context, string) (string, error) { return "", nil }
func (devClient) GetTextWithHeaders(context.Context, string, map[string]string) (string, error) {
	return "", nil
}
func (devClient) GetLargeText(context.Context, string) (string, error) { return "", nil }
func (devClient) PostJSON(context.Context, string, any, any) error     { return nil }
func (devClient) GetJSONWithHeaders(context.Context, string, map[string]string, any) error {
	return nil
}
func (devClient) PostJSONWithHeaders(context.Context, string, map[string]string, any, any) error {
	return nil
}
func (devClient) PostFormWithHeaders(context.Context, string, map[string]string, url.Values) (*html.Node, error) {
	return nil, nil
}
func (devClient) CookieValue(string, string) string { return "" }

// TestVerifyHHDevPathHydrates: with no egress tier applied, each new posting gets its description
// from its vacancy page, read through the client the registry was built with.
func TestVerifyHHDevPathHydrates(t *testing.T) {
	postings := []verifyPosting{
		{101, "Go Developer", "Контур", "<p>Full description body for 101.</p>"},
		{202, "Data Engineer", "Сбер", "<p>Full description body for 202.</p>"},
	}
	server := &hhPageServer{postings: postings}
	src, ok := All(devClient{server: server})["hh"].(HydratingSource)
	if !ok {
		t.Fatal("hh is missing from the registry or no longer hydrates descriptions per posting")
	}
	jobs, err := src.FetchNew(context.Background(), CompanyEntry{Board: "96"}, func(string) bool { return false })
	assertDescriptions(t, jobs, err, postings)
	if n := len(server.detailPages()); n != len(postings) {
		t.Errorf("vacancy pages fetched = %d, want one per new posting (%d)", n, len(postings))
	}
}
