## Task

freehire ingests postings from a lot of job boards, and hh.ru is one of them.
For hh there are two steps: a crawl of the search pages finds the open vacancies, and then each new vacancy gets its own page fetch to pick up the full description.

In production, a large share of hh postings come in without a description.
Title, company, location and salary are all there, only the body is empty.
The search side looks fine, since roles are found and the postings appear in the catalog.
So the part that comes back empty is the per-vacancy page fetch.

This only happens in production.
If I take one of the postings that came in empty and run the same crawl locally or in dev, it gets its full description.

Can you figure out why hh descriptions go missing in production and fix it, so new hh postings come in with their descriptions again?
The postings that are already empty can stay as they are for now.
