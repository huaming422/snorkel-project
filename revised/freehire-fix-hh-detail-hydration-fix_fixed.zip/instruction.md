## Task

freehire ingests postings from a lot of job boards, and hh.ru is one of them.
For hh there are two steps: a crawl of the search pages finds the open vacancies, and then each new vacancy gets its own page fetch to pick up the full description.

In production, a large share of hh postings come in without a description.
Title, company, location and salary are all there, only the body is empty.
The search side looks fine, since roles are found and the postings appear in the catalog.
So the part that comes back empty is the per-vacancy page fetch.

This only happens in production.
If I take one of the postings that came in empty and run the same crawl locally or in dev, it gets its full description.
Later production runs don't help either, and the postings that came in empty stay that way.

Please find out why hh descriptions go missing in production and fix it, so new hh postings come in with their descriptions again.
Back-filling the postings that are already empty is not part of this change.

In production some boards go out through a shared egress proxy.
It is a single IP, and a few boards that block our own servers can only be reached through it.
After this change, none of hh's requests should go through that proxy.
The boards that use the proxy today must keep using it, and the ones that don't should stay off it.

The local and dev path works today and should behave exactly as it does now.
The other sources are fine and should not change.
