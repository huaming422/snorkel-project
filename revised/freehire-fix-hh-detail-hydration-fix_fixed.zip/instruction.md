## Task

freehire ingests postings from a lot of job boards, and hh.ru is one of them.
For hh there are two steps: a crawl of the search pages finds the open vacancies, and then each new vacancy gets its own page fetch to pick up the full description.

In production, a large share of hh postings come in without a description.
Title, company, location and salary are all there, only the body is empty.
The same postings come through with their descriptions when I crawl them on my laptop.

Can you figure out why hh descriptions go missing in production and fix it, so new hh postings come in with their descriptions again?
No need to back-fill the ones that already came in empty.
