// Behavioral checks for the serialized approval-resume path of
// `@openai/agents-core`. Everything here is driven through the package's
// pre-existing public API plus its published deterministic model double
// (`@openai/agents-core/testing`), no implementation-internal import, no
// reference to any private helper or serialized sub-field by name. The run is
// fully offline: `ScriptedModel` produces the approval interruptions with no
// network.
//
// Each block asserts an OBSERVABLE contract: which tool output becomes the
// resumed final output, what the `Session` ends up holding, and how many times
// the tool mocks / model were invoked. Rejection blocks assert only that *an*
// error is thrown together with the real invariant (no tool ran, the session is
// untouched); error message text is never matched, because a correct solution
// is free to phrase it however it likes.

import { describe, expect, it, vi } from 'vitest';
import { z } from 'zod';

import {
  Agent,
  GuardrailExecutionError,
  MemorySession,
  OutputGuardrailTripwireTriggered,
  RunState,
  ToolGuardrailFunctionOutputFactory,
  Usage,
  defineToolOutputGuardrail,
  handoff,
  run,
  tool,
  toolNamespace,
  type AgentInputItem,
  type Session,
} from '../src';
import {
  ScriptedModel,
  assistantMessage,
  functionCall,
  modelResponse,
} from '../src/testing';

type RunMode = 'non_streamed' | 'streamed';

// An append-only Session that never rewrites history, lets a test read back
// exactly what the resume path chose to persist.
class AppendOnlySession implements Session {
  readonly items: AgentInputItem[] = [];

  async getSessionId(): Promise<string> {
    return 'resume-ownership-append-only-session';
  }

  async getItems(): Promise<AgentInputItem[]> {
    return structuredClone(this.items);
  }

  async addItems(items: AgentInputItem[]): Promise<void> {
    this.items.push(...structuredClone(items));
  }

  async popItem(): Promise<AgentInputItem | undefined> {
    return this.items.pop();
  }

  async clearSession(): Promise<void> {
    this.items.length = 0;
  }
}

describe('serialized approval resume preserves current-response ownership', () => {
  // An auto-executing earlier tool records one accepted result; a later
  // approval-gated tool is the one being resumed. After save-to-string,
  // restore, approve, and resume, the approved tool's own output must be the
  // final output and must be persisted, the earlier accepted output must still
  // be there, and the model must not be re-invoked a spurious extra time.
  it.each<RunMode>(['non_streamed', 'streamed'])(
    'surfaces and persists the approved output after an earlier %s result survives the round trip',
    async (mode) => {
      const historicalExecute = vi.fn(async () => 'accepted earlier result');
      const approvedExecute = vi.fn(async () => 'approved later result');
      const historicalTool = tool({
        name: 'historical_tool',
        description: 'Returns an accepted result before the approval.',
        parameters: z.object({}),
        outputGuardrails: [
          defineToolOutputGuardrail({
            name: 'accepted historical tool guardrail',
            run: async () =>
              ToolGuardrailFunctionOutputFactory.allow(
                'accepted historical guardrail metadata',
              ),
          }),
        ],
        execute: historicalExecute,
      });
      const approvalTool = tool({
        name: 'later_approval_tool',
        description: 'Requires approval after the earlier result.',
        parameters: z.object({}),
        needsApproval: true,
        execute: approvedExecute,
      });
      const model = new ScriptedModel([
        modelResponse({
          output: [
            functionCall('historical_tool', {}, { callId: 'historical-call' }),
          ],
          usage: new Usage(),
        }),
        modelResponse({
          output: [
            functionCall(
              'later_approval_tool',
              {},
              { callId: 'later-approval-call' },
            ),
          ],
          usage: new Usage(),
        }),
      ]);
      const agent = new Agent({
        name: 'Historical result before approval agent',
        model,
        tools: [historicalTool, approvalTool],
        toolUseBehavior: { stopAtToolNames: ['later_approval_tool'] },
        outputGuardrails: [
          {
            name: 'passing approval output guardrail',
            execute: async () => ({
              outputInfo: undefined,
              tripwireTriggered: false,
            }),
          },
        ],
      });
      const session = new MemorySession();
      const runOnce = async (
        input: string | RunState<unknown, typeof agent>,
        useSession = true,
      ) => {
        const options = useSession ? { session } : {};
        if (mode === 'streamed') {
          const result = await run(agent, input, { ...options, stream: true });
          await result.completed;
          return result;
        }
        return run(agent, input, options);
      };

      const first = await runOnce('Run both tools.', false);
      expect(first.interruptions).toHaveLength(1);
      expect(historicalExecute).toHaveBeenCalledTimes(1);
      expect(approvedExecute).not.toHaveBeenCalled();

      const restored = await RunState.fromString(agent, first.state.toString());
      restored.approve(restored.getInterruptions()[0]!);
      const resumed = await runOnce(restored);

      // The output that is surfaced and persisted is the APPROVED tool's own
      // result, never a stale earlier/other output.
      expect(resumed.finalOutput).toBe('approved later result');
      expect(historicalExecute).toHaveBeenCalledTimes(1);
      expect(approvedExecute).toHaveBeenCalledTimes(1);
      // The model is driven exactly twice (earlier call, then the approval
      // call), no spurious extra turn on resume.
      expect(model.calls).toHaveLength(2);

      const stored = JSON.stringify(await session.getItems());
      expect(stored).toContain('accepted earlier result');
      expect(stored).toContain('approved later result');
    },
  );

  // A handoff whose input filter clears the generated prefix means the current
  // response legitimately begins at the very start of the generated items.
  // Positional heuristics break here; the correct resume still surfaces the
  // approved tool output and executes it exactly once.
  it.each<RunMode>(['non_streamed', 'streamed'])(
    'resumes a %s approval after a handoff filter clears the generated prefix',
    async (mode) => {
      const execute = vi.fn(async () => 'handoff approval output');
      const approvalTool = tool({
        name: 'handoff_approval_tool',
        description: 'Requires approval after the handoff.',
        parameters: z.object({}),
        needsApproval: true,
        execute,
      });
      const targetModel = new ScriptedModel([
        modelResponse({
          output: [
            functionCall(
              'handoff_approval_tool',
              {},
              { callId: 'handoff-approval-call' },
            ),
          ],
          usage: new Usage(),
        }),
      ]);
      const targetAgent = new Agent({
        name: 'Filtered handoff approval target',
        model: targetModel,
        tools: [approvalTool],
        toolUseBehavior: 'stop_on_first_tool',
        outputGuardrails: [
          {
            name: 'passing handoff approval guardrail',
            execute: async () => ({
              outputInfo: undefined,
              tripwireTriggered: false,
            }),
          },
        ],
      });
      const filteredHandoff = handoff(targetAgent, {
        inputFilter: ({ runContext }) => ({
          inputHistory: [],
          preHandoffItems: [],
          newItems: [],
          runContext,
        }),
      });
      const sourceModel = new ScriptedModel([
        modelResponse({
          output: [
            functionCall(
              filteredHandoff.toolName,
              {},
              { callId: 'filtered-handoff-call' },
            ),
          ],
          usage: new Usage(),
        }),
      ]);
      const sourceAgent = new Agent({
        name: 'Filtered handoff approval source',
        model: sourceModel,
        handoffs: [filteredHandoff],
      });
      const runOnce = async (
        input: string | RunState<unknown, typeof sourceAgent>,
      ) => {
        if (mode === 'streamed') {
          const result = await run(sourceAgent, input, { stream: true });
          await result.completed;
          return result;
        }
        return run(sourceAgent, input);
      };

      const first = await runOnce('Transfer and request approval.');
      expect(first.interruptions).toHaveLength(1);

      const restored = await RunState.fromString(
        sourceAgent,
        first.state.toString(),
      );
      restored.approve(restored.getInterruptions()[0]!);
      const completed = await runOnce(restored);

      expect(completed.finalOutput).toBe('handoff approval output');
      expect(execute).toHaveBeenCalledTimes(1);
      expect(sourceModel.calls).toHaveLength(1);
      expect(targetModel.calls).toHaveLength(1);
    },
  );

  // A portable (namespaced) two-approval flow. On a clean provable restore the
  // resume completes and surfaces the approved output with a Session and output
  // guardrails enabled. When the restored checkpoint is made genuinely
  // ambiguous, by reordering the last response's items (so the current call no
  // longer resolves to a single occurrence) or by forging a namespace so the
  // recorded call and the live call disagree, the resume must fail closed: no
  // further tool executes, the model is not re-called, and the Session is
  // unchanged. The corruptions mutate pre-existing, repo-owned live structures
  // only; no added serialized field is touched, so any sound mechanism rejects
  // them.
  it.each(
    (['non_streamed', 'streamed'] as const).flatMap((mode) =>
      (['session', 'ambiguous', 'namespace_mismatch'] as const).map(
        (verdict) => ({ mode, verdict }),
      ),
    ),
  )(
    'handles a serialized $mode portable approval with a $verdict outcome',
    async ({ mode, verdict }) => {
      const firstExecute = vi.fn(async () => 'accepted first approval output');
      const secondExecute = vi.fn(
        async () => 'accepted second approval output',
      );
      const firstTool = tool({
        name: 'portable_first_approval_tool',
        description: 'Returns an output after the first approval.',
        parameters: z.object({}),
        needsApproval: true,
        execute: firstExecute,
      });
      const secondTool = tool({
        name: 'portable_second_approval_tool',
        description: 'Returns an output after the second approval.',
        parameters: z.object({}),
        needsApproval: true,
        execute: secondExecute,
      });
      const [namespacedFirstTool, namespacedSecondTool] = toolNamespace({
        name: 'crm',
        description: 'Namespaced approval tools.',
        tools: [firstTool, secondTool],
      });
      const model = new ScriptedModel([
        modelResponse({
          output: [
            functionCall(
              'portable_first_approval_tool',
              {},
              { callId: 'portable-first-call', namespace: 'crm' },
            ),
            functionCall(
              'portable_second_approval_tool',
              {},
              { callId: 'portable-second-call', namespace: 'crm' },
            ),
          ],
          usage: new Usage(),
        }),
      ]);
      const agent = new Agent({
        name: 'Portable serialized approval agent',
        model,
        tools: [namespacedFirstTool, namespacedSecondTool],
        toolUseBehavior: 'stop_on_first_tool',
        outputGuardrails: [
          {
            name: 'passing portable approval guardrail',
            execute: async () => ({
              outputInfo: undefined,
              tripwireTriggered: false,
            }),
          },
        ],
      });
      const session = new AppendOnlySession();
      const runOnce = async (
        input: string | RunState<unknown, typeof agent>,
        resumeSession?: Session,
      ) => {
        const options = resumeSession ? { session: resumeSession } : {};
        if (mode === 'streamed') {
          const result = await run(agent, input, { ...options, stream: true });
          await result.completed;
          return result;
        }
        return run(agent, input, options);
      };

      const first = await runOnce('Approve both portable tools.', session);
      first.state.approve(first.interruptions[0]!);
      const partial = await runOnce(first.state, session);
      const historicalSessionItems = await session.getItems();

      // Double round trip: the live object identity is gone on both restores,
      // so a correct solution must rely on recorded/re-derived provenance, not
      // on the surviving object graph.
      const onceRestored = await RunState.fromString(
        agent,
        partial.state.toString(),
      );
      const restored = await RunState.fromString(
        agent,
        onceRestored.toString(),
      );
      restored.approve(restored.getInterruptions()[0]!);

      if (verdict === 'ambiguous') {
        // Reorder the recorded last response so the current call no longer
        // resolves to a single unambiguous occurrence.
        restored._lastTurnResponse?.output.reverse();
      }
      if (verdict === 'namespace_mismatch') {
        // Forge the recorded call's namespace so it disagrees with the live
        // generated item.
        const responseCall = restored._lastTurnResponse?.output[0];
        if (responseCall?.type === 'function_call') {
          responseCall.namespace = 'billing';
        }
      }

      if (verdict === 'ambiguous' || verdict === 'namespace_mismatch') {
        // Fail closed: an error is thrown (text not asserted, a correct
        // solution may phrase it any way), and nothing observable changed.
        await expect(runOnce(restored)).rejects.toThrow();
        expect(secondExecute).not.toHaveBeenCalled();
        expect(model.calls).toHaveLength(1);
        expect(await session.getItems()).toEqual(historicalSessionItems);
        return;
      }

      // verdict === 'session': a genuinely provable checkpoint with a Session
      // and output guardrails resumes successfully and surfaces the approved
      // output. (Pre-fix this throws a blanket "ownership cannot be proven".)
      const completed = await runOnce(restored, session);
      expect(completed.finalOutput).toBe('accepted second approval output');
      expect(firstExecute).toHaveBeenCalledTimes(1);
      expect(secondExecute).toHaveBeenCalledTimes(1);
      expect(model.calls).toHaveLength(1);

      const stored = await session.getItems();
      for (const callId of ['portable-first-call', 'portable-second-call']) {
        expect(
          stored
            .filter(
              (item) =>
                (item.type === 'function_call' ||
                  item.type === 'function_call_result') &&
                item.callId === callId,
            )
            .map((item) => item.type),
        ).toEqual(['function_call', 'function_call_result']);
      }
    },
  );

  // When an output guardrail throws on resume, the failure must surface as the
  // public GuardrailExecutionError carrying the original cause, and the earlier
  // accepted prefix must stay intact, with no partial Session corruption on the
  // failure path. Driven entirely by the guardrail behavior, with no serialized
  // field mutated.
  it.each<RunMode>(['non_streamed', 'streamed'])(
    'raises GuardrailExecutionError without corrupting the prefix on a %s resume',
    async (mode) => {
      const firstExecute = vi.fn(async () => 'accepted first approval output');
      const secondExecute = vi.fn(
        async () => 'accepted second approval output',
      );
      const guardrailError = new Error('serialized approval guardrail error');
      const firstTool = tool({
        name: 'portable_first_approval_tool',
        description: 'Returns an output after the first approval.',
        parameters: z.object({}),
        needsApproval: true,
        execute: firstExecute,
      });
      const secondTool = tool({
        name: 'portable_second_approval_tool',
        description: 'Returns an output after the second approval.',
        parameters: z.object({}),
        needsApproval: true,
        execute: secondExecute,
      });
      const [namespacedFirstTool, namespacedSecondTool] = toolNamespace({
        name: 'crm',
        description: 'Namespaced approval tools.',
        tools: [firstTool, secondTool],
      });
      const model = new ScriptedModel([
        modelResponse({
          output: [
            functionCall(
              'portable_first_approval_tool',
              {},
              { callId: 'portable-first-call', namespace: 'crm' },
            ),
            functionCall(
              'portable_second_approval_tool',
              {},
              { callId: 'portable-second-call', namespace: 'crm' },
            ),
          ],
          usage: new Usage(),
        }),
      ]);
      const agent = new Agent({
        name: 'Portable approval guardrail error agent',
        model,
        tools: [namespacedFirstTool, namespacedSecondTool],
        toolUseBehavior: 'stop_on_first_tool',
        outputGuardrails: [
          {
            name: 'throwing portable approval guardrail',
            execute: async () => {
              throw guardrailError;
            },
          },
        ],
      });
      const session = new AppendOnlySession();
      const runOnce = async (
        input: string | RunState<unknown, typeof agent>,
        resumeSession?: Session,
      ) => {
        const options = resumeSession ? { session: resumeSession } : {};
        if (mode === 'streamed') {
          const result = await run(agent, input, { ...options, stream: true });
          await result.completed;
          return result;
        }
        return run(agent, input, options);
      };

      const first = await runOnce('Approve both portable tools.', session);
      first.state.approve(first.interruptions[0]!);
      const partial = await runOnce(first.state, session);
      const historicalSessionItems = await session.getItems();
      const onceRestored = await RunState.fromString(
        agent,
        partial.state.toString(),
      );
      const restored = await RunState.fromString(
        agent,
        onceRestored.toString(),
      );
      restored.approve(restored.getInterruptions()[0]!);

      let executionError: GuardrailExecutionError | undefined;
      try {
        await runOnce(restored);
      } catch (error) {
        expect(error).toBeInstanceOf(GuardrailExecutionError);
        executionError = error as GuardrailExecutionError;
      }
      expect(executionError?.error).toBe(guardrailError);
      // The current approval was resolved to the current occurrence (both
      // executes ran), but the earlier accepted history is untouched.
      expect(firstExecute).toHaveBeenCalledTimes(1);
      expect(secondExecute).toHaveBeenCalledTimes(1);
      expect(model.calls).toHaveLength(1);
      expect(await session.getItems()).toEqual(historicalSessionItems);
    },
  );

  // Tripwire variant of the historical-result case. When the output guardrail
  // trips on resume, the approved later output must be withheld from the
  // Session and surface as the public OutputGuardrailTripwireTriggered, while
  // the earlier accepted result stays persisted. The fail-closed behavior is
  // observed through public state and Session contents only.
  it.each<RunMode>(['non_streamed', 'streamed'])(
    'withholds the approved output and keeps the prefix when the %s guardrail trips',
    async (mode) => {
      const historicalExecute = vi.fn(async () => 'accepted earlier result');
      const approvedExecute = vi.fn(async () => 'approved later result');
      const historicalTool = tool({
        name: 'historical_tool',
        description: 'Returns an accepted result before the approval.',
        parameters: z.object({}),
        outputGuardrails: [
          defineToolOutputGuardrail({
            name: 'accepted historical tool guardrail',
            run: async () =>
              ToolGuardrailFunctionOutputFactory.allow(
                'accepted historical guardrail metadata',
              ),
          }),
        ],
        execute: historicalExecute,
      });
      const approvalTool = tool({
        name: 'later_approval_tool',
        description: 'Requires approval after the earlier result.',
        parameters: z.object({}),
        needsApproval: true,
        execute: approvedExecute,
      });
      const model = new ScriptedModel([
        modelResponse({
          output: [
            functionCall('historical_tool', {}, { callId: 'historical-call' }),
          ],
          usage: new Usage(),
        }),
        modelResponse({
          output: [
            functionCall(
              'later_approval_tool',
              {},
              { callId: 'later-approval-call' },
            ),
          ],
          usage: new Usage(),
        }),
      ]);
      const agent = new Agent({
        name: 'Historical result tripwire agent',
        model,
        tools: [historicalTool, approvalTool],
        toolUseBehavior: { stopAtToolNames: ['later_approval_tool'] },
        outputGuardrails: [
          {
            name: 'tripping approval output guardrail',
            execute: async () => ({
              outputInfo: undefined,
              tripwireTriggered: true,
            }),
          },
        ],
      });
      const session = new MemorySession();
      const runOnce = async (
        input: string | RunState<unknown, typeof agent>,
        useSession = true,
      ) => {
        const options = useSession ? { session } : {};
        if (mode === 'streamed') {
          const result = await run(agent, input, { ...options, stream: true });
          await result.completed;
          return result;
        }
        return run(agent, input, options);
      };

      const first = await runOnce('Run both tools.', false);
      expect(first.interruptions).toHaveLength(1);

      const restored = await RunState.fromString(agent, first.state.toString());
      restored.approve(restored.getInterruptions()[0]!);

      let tripwire: OutputGuardrailTripwireTriggered<any> | undefined;
      try {
        await runOnce(restored);
      } catch (error) {
        expect(error).toBeInstanceOf(OutputGuardrailTripwireTriggered);
        tripwire = error as OutputGuardrailTripwireTriggered<any>;
      }
      expect(tripwire).toBeDefined();
      const blockedState = tripwire!.state!;
      // The earlier accepted output is retained on the restored turn's items,
      // while the just-approved output is withheld when the guardrail trips.
      expect(JSON.stringify(blockedState._generatedItems)).toContain(
        'accepted earlier result',
      );
      expect(JSON.stringify(blockedState._generatedItems)).not.toContain(
        'approved later result',
      );
      expect(historicalExecute).toHaveBeenCalledTimes(1);
      expect(approvedExecute).toHaveBeenCalledTimes(1);
      expect(model.calls).toHaveLength(2);
    },
  );

  // A legacy snapshot taken on an older serialization schema version, one that
  // predates any current-response ownership record, must still load and resume
  // correctly, claiming no ownership it does not have. The snapshot's own
  // `$schemaVersion` envelope field is downgraded to a strictly-older supported
  // value read back from the serialized form; no current version literal is
  // typed, and no added sub-field is referenced by shape.
  it.each<RunMode>(['non_streamed', 'streamed'])(
    'still loads and resumes a legacy %s snapshot taken on an older schema version',
    async (mode) => {
      const approvedExecute = vi.fn(async () => 'legacy approved output');
      const approvalTool = tool({
        name: 'legacy_schema_approval_tool',
        description: 'Requires approval on a legacy snapshot.',
        parameters: z.object({}),
        needsApproval: true,
        execute: approvedExecute,
      });
      const model = new ScriptedModel([
        modelResponse({
          output: [
            functionCall(
              'legacy_schema_approval_tool',
              {},
              { callId: 'legacy-schema-call' },
            ),
          ],
          usage: new Usage(),
        }),
        modelResponse({
          output: [assistantMessage('legacy continuation complete')],
          usage: new Usage(),
        }),
      ]);
      const agent = new Agent({
        name: 'Legacy schema approval agent',
        model,
        tools: [approvalTool],
        toolUseBehavior: 'run_llm_again',
      });
      const runOnce = async (
        input: string | RunState<unknown, typeof agent>,
      ) => {
        if (mode === 'streamed') {
          const result = await run(agent, input, { stream: true });
          await result.completed;
          return result;
        }
        return run(agent, input);
      };

      const first = await runOnce('Call the approval tool.');
      expect(first.interruptions).toHaveLength(1);

      // Downgrade the envelope to a strictly-older supported schema version and
      // drop any ownership record a solution may have added, modelling a
      // snapshot produced by an older SDK. Compute the older version from the
      // serialized value itself rather than hardcoding a current literal.
      const serialized = first.state.toJSON() as Record<string, unknown> & {
        $schemaVersion?: string;
      };
      const currentVersion = String(serialized.$schemaVersion ?? '');
      const [major, minor] = currentVersion.split('.').map((n) => Number(n));
      const olderVersion =
        Number.isFinite(major) && Number.isFinite(minor) && minor > 0
          ? `${major}.${minor - 1}`
          : currentVersion;
      serialized.$schemaVersion = olderVersion;
      // A legacy snapshot predates the ownership record; remove any object-
      // valued key that is not part of the pre-fix SerializedRunState schema.
      // Keyed only on being absent from the pre-fix schema — NOT on any
      // solution-chosen field name — so any valid naming/shape is admitted.
      const PRE_FIX_SCHEMA_KEYS = new Set([
        '$schemaVersion',
        'currentTurn',
        'currentAgent',
        'originalInput',
        'pendingInput',
        'modelResponses',
        'context',
        'toolUseTracker',
        'maxTurns',
        'currentAgentSpan',
        'noActiveAgentRun',
        'inputGuardrailResults',
        'outputGuardrailResults',
        'toolInputGuardrailResults',
        'toolOutputGuardrailResults',
        'currentTurnInProgress',
        'currentStep',
        'lastModelResponse',
        'generatedItems',
        'pendingAgentToolRuns',
        'pendingAgentToolRunAliases',
        'lastProcessedResponse',
        'currentTurnPersistedItemCount',
        'currentTurnDeferredSessionItemIndexes',
        'currentTurnBlockedSessionStartIndex',
        'currentTurnExecutedWithSessionBinding',
        'currentTurnSessionInputItems',
        'pendingSessionHistoryTransaction',
        'completedToolInvocations',
        'completedToolInvocationEvidence',
        'ambiguousToolInvocationCallIds',
        'pendingLegacyCompactionSessionItems',
        'conversationId',
        'previousResponseId',
        'reasoningItemIdPolicy',
        'trace',
        'sandbox',
      ]);
      for (const key of Object.keys(serialized)) {
        if (
          !PRE_FIX_SCHEMA_KEYS.has(key) &&
          serialized[key] !== null &&
          typeof serialized[key] === 'object'
        ) {
          delete serialized[key];
        }
      }

      const restored = await RunState.fromString(
        agent,
        JSON.stringify(serialized),
      );
      restored.approve(restored.getInterruptions()[0]!);
      const resumed = await runOnce(restored);

      expect(resumed.finalOutput).toBe('legacy continuation complete');
      expect(approvedExecute).toHaveBeenCalledTimes(1);
    },
  );

  // Approving and resuming the live RunState directly, never going through the
  // string form, must behave exactly as before: the approved output surfaces
  // and persists, and the earlier accepted output is kept. Confirms the change
  // does not regress the non-round-trip path.
  it.each<RunMode>(['non_streamed', 'streamed'])(
    'resumes the in-memory %s approval with no round trip unchanged',
    async (mode) => {
      const historicalExecute = vi.fn(async () => 'accepted earlier result');
      const approvedExecute = vi.fn(async () => 'approved later result');
      const historicalTool = tool({
        name: 'historical_tool',
        description: 'Returns an accepted result before the approval.',
        parameters: z.object({}),
        execute: historicalExecute,
      });
      const approvalTool = tool({
        name: 'later_approval_tool',
        description: 'Requires approval after the earlier result.',
        parameters: z.object({}),
        needsApproval: true,
        execute: approvedExecute,
      });
      const model = new ScriptedModel([
        modelResponse({
          output: [
            functionCall('historical_tool', {}, { callId: 'historical-call' }),
          ],
          usage: new Usage(),
        }),
        modelResponse({
          output: [
            functionCall(
              'later_approval_tool',
              {},
              { callId: 'later-approval-call' },
            ),
          ],
          usage: new Usage(),
        }),
      ]);
      const agent = new Agent({
        name: 'In-memory resume agent',
        model,
        tools: [historicalTool, approvalTool],
        toolUseBehavior: { stopAtToolNames: ['later_approval_tool'] },
        outputGuardrails: [
          {
            name: 'passing in-memory output guardrail',
            execute: async () => ({
              outputInfo: undefined,
              tripwireTriggered: false,
            }),
          },
        ],
      });
      const session = new MemorySession();
      const runOnce = async (
        input: string | RunState<unknown, typeof agent>,
        useSession = true,
      ) => {
        const options = useSession ? { session } : {};
        if (mode === 'streamed') {
          const result = await run(agent, input, { ...options, stream: true });
          await result.completed;
          return result;
        }
        return run(agent, input, options);
      };

      const first = await runOnce('Run both tools.', false);
      expect(first.interruptions).toHaveLength(1);

      // Approve and resume the SAME live state, no toString/fromString.
      first.state.approve(first.interruptions[0]!);
      const resumed = await runOnce(first.state);

      expect(resumed.finalOutput).toBe('approved later result');
      expect(historicalExecute).toHaveBeenCalledTimes(1);
      expect(approvedExecute).toHaveBeenCalledTimes(1);
      const stored = JSON.stringify(await session.getItems());
      expect(stored).toContain('accepted earlier result');
      expect(stored).toContain('approved later result');
    },
  );
});
