## Task

we let a run pause for human approval of a tool call, and you can save that paused run to a string and restore it from the string later to pick up where it left off.

something's off on that restore path. if you save a paused run to a string and then restore it before granting the approval, continuing the run can surface and save the wrong tool's output: a stale result from earlier in the conversation instead of the one that was just approved. sometimes it also drops outputs that were already accepted earlier in the run, and a few restores that should succeed fail outright instead. restore the same paused run from memory without ever going through the string form and everything behaves correctly, so this is specific to the saved-and-restored path.

dig into the run-state save, restore, and resume path and fix it so a restored approval resumes with the right outputs preserved, and leave the public API signatures as they are.
