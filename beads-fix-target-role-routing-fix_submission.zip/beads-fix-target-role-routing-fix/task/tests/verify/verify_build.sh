#!/usr/bin/env bash
# Compile + neighbor-regression gate for the role-routing fix.
#
# The change spans the command layer and two internal packages, so this proves
# the whole touched surface still builds coherently and that the pre-existing
# behavior of the surrounding command / routing / context code is preserved.
# It never references any name the fix may introduce — it builds the module and
# runs the packages' own existing test suites.
set -euo pipefail

export GOFLAGS="${GOFLAGS:--mod=mod}"
export CGO_ENABLED="${CGO_ENABLED:-1}"
export GOTOOLCHAIN="${GOTOOLCHAIN:-local}"
export GOCACHE="${GOCACHE:-/opt/cache/go-build}"
export GOMODCACHE="${GOMODCACHE:-/opt/cache/go}"

cd /repo/beads

# Whole-module compile: catches a fix that breaks the build anywhere, not just
# in the packages it edited. This covers the command binary's own compilation
# (including every file the fix touches there) plus the two internal packages.
# The examples/ directories are their own modules and are excluded by `./...`
# on the root module.
go build ./...

# Neighbor-regression suite: the two internal packages whose role/context
# behavior the fix must leave intact. Both are edited by the change and both run
# hermetically, so a fix that corrects the misroute but regresses their logic
# (role detection, the routing decision, repo-context resolution) fails here.
#
# The command package's own behavioral suite is NOT run here: it boots the full
# bd runtime, which in this sandbox talks to a Dolt server in proxied-server
# mode and needs Docker for its storage-backed cases — neither is available, so
# several of its pre-existing tests fail for reasons unrelated to any routing
# change (flag-reset against a proxied server, the setup-command integration
# wrappers). The command layer's routing behavior that THIS change edits is
# instead exercised directly and hermetically by the companion Go checks (which
# run inside this same package), and its compilation is covered by
# `go build ./...` above.
go test -count=1 \
    ./internal/routing/... \
    ./internal/beads/...

echo "verify_build.sh: module compiles and neighbor suites pass."
