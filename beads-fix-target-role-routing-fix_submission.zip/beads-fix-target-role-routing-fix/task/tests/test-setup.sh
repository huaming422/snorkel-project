#!/usr/bin/env bash
# Sourced by the verifier runner before tests execute. The Go toolchain, the
# module cache (/opt/cache/go), and the build cache (/opt/cache/go-build) are
# all baked into the image at the base commit, so there is nothing to install
# here — this only exports the deterministic Go environment the verifier builds
# under. The agent phase is offline; the full dependency closure is already in
# the image (image/Dockerfile blocks 5 and 7).
set -euo pipefail

cd /repo/beads

export GOFLAGS="-mod=mod"
export CGO_ENABLED="1"
export GOTOOLCHAIN="local"
export GOCACHE="${GOCACHE:-/opt/cache/go-build}"
export GOMODCACHE="${GOMODCACHE:-/opt/cache/go}"
mkdir -p "$GOCACHE" "$GOMODCACHE"

echo "[test-setup] go environment ready for beads-fix-target-role-routing"
