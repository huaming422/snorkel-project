## Task

we've got a routing bug when you point `bd` at a repo other than the one you're sitting in. normally `bd` auto-routes `create`, `list`, and `ready` to the maintainer or contributor planning repo based on that repo's `beads.role`. but when you select a different project explicitly, with `bd -C ../service-x ...` or by exporting `BEADS_DIR` before running, routing still uses the role of the checkout you launched from instead of the one configured in the target.

concretely: a maintainer sitting in a checkout configured as a contributor runs `bd -C ../service-x create ...`, and the issue lands in service-x's CONTRIBUTOR planning repo instead of its MAINTAINER one. the target's own `beads.role` gets ignored the moment the project is chosen explicitly rather than discovered from the current directory.

a repo discovered from the directory you're in routes fine and should stay exactly as it is. we just want explicit selection to honor the selected repo's role. the routing rules themselves are correct; the only thing wrong is which repo's role gets consulted. dig in and fix it.
