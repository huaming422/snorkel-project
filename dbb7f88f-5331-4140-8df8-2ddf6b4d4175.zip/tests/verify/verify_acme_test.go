// Copyright (c) Tailscale Inc & contributors
// SPDX-License-Identifier: BSD-3-Clause

// In-package check that backend shutdown completes during certificate work.
package acme

import (
	"context"
	"os"
	"os/exec"
	"testing"
	"time"

	"tailscale.com/ipn/ipnlocal"
	"tailscale.com/ipn/ipnlocal/ipnlocaltest"
)

// A tracked certificate worker calls back into the backend while shutdown
// proceeds. Both the first and repeated shutdown must return.
func TestShutdownCompletesWithInFlightCertRefresh(t *testing.T) {
	// A deadlocked backend also blocks NewBackend's cleanup and eventually
	// triggers its process-wide watchdog panic. Run that case in a child test
	// process so the parent can report the failed named test deterministically.
	if os.Getenv("SSB_ACME_SHUTDOWN_CHILD") != "1" {
		ctx, cancel := context.WithTimeout(context.Background(), 12*time.Second)
		defer cancel()
		cmd := exec.CommandContext(ctx, os.Args[0], "-test.run=^TestShutdownCompletesWithInFlightCertRefresh$", "-test.v")
		cmd.Env = append(os.Environ(), "SSB_ACME_SHUTDOWN_CHILD=1")
		output, err := cmd.CombinedOutput()
		if ctx.Err() != nil {
			t.Fatalf("certificate shutdown did not finish before child timeout: %s", output)
		}
		if err != nil {
			t.Fatalf("certificate shutdown child failed: %v\n%s", err, output)
		}
		return
	}

	// NewBackend registers b.Shutdown as a t.Cleanup. This check drives
	// Shutdown in the body; once the backend is torn down the cleanup's
	// repeat Shutdown is a safe idempotent no-op (which this check also
	// asserts), so no special no-cleanup constructor is needed.
	b := ipnlocaltest.NewBackend(t)
	b.SetVarRoot(t.TempDir())
	e := extOf(t, b)

	entered := make(chan struct{})
	release := make(chan struct{})

	// Park certificate retrieval until shutdown begins, then call the backend.
	b.ForTest().ConfigureCerts(func(host string) (*ipnlocal.TLSCertKeyPair, error) {
		close(entered)
		<-release
		_ = b.ServeConfig() // acquires the backend's primary lock
		return &ipnlocal.TLSCertKeyPair{}, nil
	})

	// Track the worker through the certificate extension.
	e.Go(func() {
		_, _ = e.getCertPEMWithValidity(context.Background(), b, "node.example.com", 0)
	})

	select {
	case <-entered:
	case <-time.After(5 * time.Second):
		t.Fatal("cert refresh worker never started")
	}

	done := make(chan struct{})
	go func() {
		b.Shutdown()
		b.Shutdown() // idempotent: a repeat call must also return
		close(done)
	}()

	// Release the worker after shutdown starts.
	time.Sleep(100 * time.Millisecond)
	close(release)

	select {
	case <-done:
		// Shutdown returned: teardown did not wedge on the cert machinery.
	case <-time.After(5 * time.Second):
		t.Fatal("LocalBackend.Shutdown did not complete; teardown wedged while stopping the cert refresh machinery")
	}
}
