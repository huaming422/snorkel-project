// Copyright (c) Tailscale Inc & contributors
// SPDX-License-Identifier: BSD-3-Clause

// In-package checks for LocalBackend teardown and SSH availability.
//
// Injected into ipn/ipnlocal as package ipnlocal so it can reach the
// backend lock, owned resources, and SSH connection path.
//
// Certificate activity is checked in verify_acme_test.go.
package ipnlocal

import (
	"context"
	"net"
	"sync/atomic"
	"testing"
	"time"

	"tailscale.com/appc"
	"tailscale.com/feature/buildfeatures"
	"tailscale.com/types/logger"
)

// lockObservingSSHServer records stops and checks whether backend methods
// remain available while its stop callback runs.
type lockObservingSSHServer struct {
	b     *LocalBackend
	t     *testing.T
	calls atomic.Int32
}

func (s *lockObservingSSHServer) HandleSSHConn(net.Conn) error { return nil }
func (s *lockObservingSSHServer) NumActiveConns() int          { return 0 }
func (s *lockObservingSSHServer) OnPolicyChange()              {}

func (s *lockObservingSSHServer) Shutdown() {
	s.calls.Add(1)
	if !s.b.mu.TryLock() {
		s.t.Error("primary lock held while stopping the SSH server")
		return
	}
	s.b.mu.Unlock()
	// Exercise a backend callback during the server stop.
	s.b.NodeKey()
}

// installLockObservingSSHServer attaches the stand-in SSH server under the
// lock, mirroring how real code mutates the field.
func installLockObservingSSHServer(b *LocalBackend, s *lockObservingSSHServer) {
	b.mu.Lock()
	b.sshServer = s
	b.mu.Unlock()
}

// An SSH stop must allow a backend callback to complete.
func TestShutdownReleasesLockBeforeStoppingSSHServer(t *testing.T) {
	b := newTestLocalBackend(t)

	ssh := &lockObservingSSHServer{b: b, t: t}
	installLockObservingSSHServer(b, ssh)

	b.Shutdown()

	if got := ssh.calls.Load(); got != 1 {
		t.Errorf("SSH server shutdown ran %d times; want 1", got)
	}
}

// A live backend serves SSH, while a stopped backend refuses a new connection.
func TestSSHServerDoesNotRestartAfterShutdown(t *testing.T) {
	b := newTestLocalBackend(t)

	var factoryCalls atomic.Int32
	prev := newSSHServer
	newSSHServer = func(logger.Logf, *LocalBackend) (SSHServer, error) {
		factoryCalls.Add(1)
		return &lockObservingSSHServer{b: b, t: t}, nil
	}
	t.Cleanup(func() { newSSHServer = prev })
	if err := b.handleSSHConn(nil); err != nil {
		t.Fatalf("live backend refused SSH connection: %v", err)
	}
	if got := factoryCalls.Load(); got != 1 {
		t.Fatalf("live SSH connection constructed %d servers; want 1", got)
	}

	b.Shutdown()

	err := b.handleSSHConn(nil)
	if got := factoryCalls.Load(); got != 1 {
		t.Errorf("SSH connection after teardown constructed another SSH server (factory called %d times); want 1", got)
	}
	if err == nil {
		t.Error("SSH connection after teardown returned nil error; want a non-nil error refusing the restart")
	}
}

// Repeating shutdown must not stop the same SSH server twice.
func TestShutdownRunsTeardownExactlyOnce(t *testing.T) {
	b := newTestLocalBackend(t)

	ssh := &lockObservingSSHServer{b: b, t: t}
	installLockObservingSSHServer(b, ssh)

	b.Shutdown()
	b.Shutdown()

	if got := ssh.calls.Load(); got != 1 {
		t.Errorf("SSH server shutdown ran %d times across two teardown calls; want 1", got)
	}
}

type shutdownTimer struct{ stops atomic.Int32 }

func (*shutdownTimer) Reset(time.Duration) bool { return true }
func (s *shutdownTimer) Stop() bool {
	s.stops.Add(1)
	return true
}

type shutdownListener struct{ closes atomic.Int32 }

func (*shutdownListener) Accept() (net.Conn, error) { return nil, net.ErrClosed }
func (s *shutdownListener) Close() error {
	s.closes.Add(1)
	return nil
}
func (*shutdownListener) Addr() net.Addr { return &net.TCPAddr{} }

// Existing owned resources must still be released during backend shutdown.
func TestShutdownKeepsOtherTeardown(t *testing.T) {
	b := newTestLocalBackend(t)
	ssh := &lockObservingSSHServer{b: b, t: t}
	installLockObservingSSHServer(b, ssh)
	timer := new(shutdownTimer)
	listener := new(shutdownListener)
	connector := appc.NewAppConnector(appc.Config{Logf: t.Logf, EventBus: b.sys.Bus.Get()})
	connector.UpdateDomains([]string{"before.example"})
	connector.Wait(context.Background())
	if got := connector.Domains().AsSlice(); len(got) != 1 || got[0] != "before.example" {
		t.Fatalf("initial connector update was not applied: %v", got)
	}
	b.mu.Lock()
	b.reconnectTimer = timer
	if buildfeatures.HasPeerAPIServer {
		b.peerAPIListeners = []*peerAPIListener{{ln: listener}}
	}
	b.appConnector = connector
	b.mu.Unlock()

	b.Shutdown()
	if got := timer.stops.Load(); got != 1 {
		t.Errorf("reconnect timer stopped %d times; want 1", got)
	}
	if buildfeatures.HasPeerAPIServer {
		if got := listener.closes.Load(); got != 1 {
			t.Errorf("PeerAPI listener closed %d times; want 1", got)
		}
	}
	connector.UpdateDomains([]string{"after.example"})
	connector.Wait(context.Background())
	if got := connector.Domains().AsSlice(); len(got) != 1 || got[0] != "before.example" {
		t.Errorf("connector accepted update after shutdown: %v", got)
	}
}
