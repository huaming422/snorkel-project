## Task

Red is inconsistent when a command it accepted turns out to have no target. A few of those dead ends stay silent and the rest print a plain info line. Make every case below end in one brief warning that doesn't take focus, and leave what the commands do as it is.

The same goes for the lookups that run through the language server and the plugins. That means a definition request the server answers with nothing, document symbols or references that come back empty, and staging, unstaging or resetting a Git hunk when the cursor isn't on one. While the server is still indexing, the references lookup keeps waiting like it does now and only warns once the final answer is empty.

## User stories / requirements

- Pressing `n` before any search, or searching with `/`, `?` or `n` for text the buffer doesn't contain, shows that warning and the cursor doesn't move.
- A search that passes the last or first line can come back around onto a hit on the far side. Whether it's typed with `/` or `?`, started with `*`, or repeated with `n` or `N`, it still lands on that hit and shows the warning too, so the user can tell it wrapped.
- A motion with nothing to land on keeps the buffer's text and the cursor as they are and shows the warning. That covers `%`, `d%` or `c%` on a line without brackets, and `f`, `t`, `F`, `T`, `df`, `dt` or `dF` with a character the line lacks. The next key starts a new command.
- Jumping back past the oldest jump or forward past the newest shows the warning, with the same text it shows today. So do undoing or redoing with nothing left, moving toward a missing window, and swapping a parameter that has no neighbor on that side.
- Go-to-definition in a buffer with no file behind it shows the warning, and so does line diagnostics on a line without any. The inline comment commands (next, previous, show, dismiss) do the same when the buffer has no comments. None of them stays silent, prints a plain message, or touches the text.
- When the command does have a target, nothing new shows up. A search that hits without wrapping, a motion or operator that lands, and an undo with something to undo work the same as before and show no warning. A plain line that a command prints today stays plain, not a warning.
