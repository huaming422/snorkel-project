#![allow(dead_code, unused_imports)]
//! Scenario code for the stories about commands that find nothing to act on.
//!
//! Every story file calls one `observe_*` function with its case's inputs. The function
//! builds an editor with the repository's own `tests/common` harness and the key bindings
//! of `default_config.toml`, drives it with key presses or `Action`s, and returns what it
//! saw as a map keyed by the story's expected keys.
//!
//! Only the notices published while the case's own command runs are read. `notice` is the
//! severity of the newest of them ("Warning", "Info", "Error", "Success"), or "none" when
//! the command published nothing. `attention` is that notice's attention policy ("Quiet",
//! "IfMissed", "RequiresAcknowledgment") or "none", and `text` is its summary line.
//! `plain_or_error` is "yes" when any notice the command published is a plain Info line or
//! an Error.

use std::collections::BTreeMap;
use std::path::PathBuf;
use std::time::SystemTime;

use crossterm::event::{Event, KeyCode, KeyEvent, KeyModifiers};
use serde_json::Value;

use red::{
    buffer::Buffer,
    config::Config,
    editor::Action,
    notification::{AttentionPolicy, NotificationId, Severity},
};

use crate::common::EditorHarness;

/// What a scenario saw, keyed by the story's expected keys.
pub type Seen = BTreeMap<String, String>;

/// The key bindings red ships with, the same ones `tests/movement.rs` loads.
pub fn key_config() -> Config {
    toml::from_str(include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/default_config.toml"
    )))
    .expect("default_config.toml parses")
}

fn text<'a>(inputs: &'a Value, key: &str) -> &'a str {
    inputs[key]
        .as_str()
        .unwrap_or_else(|| panic!("input `{key}` is missing or isn't a string"))
}

fn number(inputs: &Value, key: &str) -> usize {
    inputs[key]
        .as_u64()
        .unwrap_or_else(|| panic!("input `{key}` is missing or isn't a number")) as usize
}

/// A scratch buffer holding `content`, with the shipped key bindings.
pub fn scratch(content: &str) -> EditorHarness {
    EditorHarness::with_config(Buffer::new(None, content.to_string()), key_config())
}

/// A buffer on a file named `name` in a new temporary directory, so the editor treats it
/// as a file of that language. The directory lives as long as the returned guard.
pub fn on_file(name: &str, content: &str) -> (EditorHarness, tempfile::TempDir) {
    let dir = tempfile::tempdir().expect("temporary directory");
    let path: PathBuf = dir.path().join(name);
    std::fs::write(&path, content).expect("write the fixture file");
    let buffer = Buffer::new(
        Some(path.to_string_lossy().into_owned()),
        content.to_string(),
    );
    (EditorHarness::with_config(buffer, key_config()), dir)
}

pub async fn act(harness: &mut EditorHarness, action: Action) {
    harness
        .execute_action(action)
        .await
        .expect("the editor runs the action");
}

pub async fn press(harness: &mut EditorHarness, code: KeyCode, modifiers: KeyModifiers) {
    harness
        .execute_event(Event::Key(KeyEvent::new(code, modifiers)))
        .await
        .expect("the editor takes the key");
}

/// Types `keys` in the current mode. A newline is Enter.
pub async fn type_keys(harness: &mut EditorHarness, keys: &str) {
    for c in keys.chars() {
        let code = if c == '\n' {
            KeyCode::Enter
        } else {
            KeyCode::Char(c)
        };
        press(harness, code, KeyModifiers::NONE).await;
    }
}

/// Puts the cursor on column `start_x` of line `start_y` from the inputs.
pub async fn place_cursor(harness: &mut EditorHarness, inputs: &Value) {
    let (x, y) = (number(inputs, "start_x"), number(inputs, "start_y"));
    act(harness, Action::SetCursor(x, y)).await;
}

fn severity_name(severity: Severity) -> &'static str {
    match severity {
        Severity::Info => "Info",
        Severity::Success => "Success",
        Severity::Warning => "Warning",
        Severity::Error => "Error",
    }
}

fn attention_name(attention: AttentionPolicy) -> &'static str {
    match attention {
        AttentionPolicy::Quiet => "Quiet",
        AttentionPolicy::IfMissed => "IfMissed",
        AttentionPolicy::RequiresAcknowledgment => "RequiresAcknowledgment",
    }
}

/// The editor's notices as they are now: each record's id, how many times it was published
/// and when it last changed. A notice published later is a record that isn't in the mark,
/// or one whose count or time moved, since a notice published under a key updates its
/// record in place.
pub type NoticeMark = Vec<(NotificationId, u64, SystemTime)>;

pub fn notice_mark(harness: &EditorHarness) -> NoticeMark {
    harness
        .editor
        .notifications()
        .records()
        .map(|record| (record.id, record.occurrences, record.updated_at))
        .collect()
}

/// Severity, attention and summary of each notice published since `mark`, oldest first.
pub fn notices_since(harness: &EditorHarness, mark: &NoticeMark) -> Vec<(String, String, String)> {
    let mut changed: Vec<_> = harness
        .editor
        .notifications()
        .records()
        .filter(|record| !mark.contains(&(record.id, record.occurrences, record.updated_at)))
        .collect();
    changed.sort_by_key(|record| record.updated_at);
    changed
        .into_iter()
        .map(|record| {
            (
                severity_name(record.severity).to_string(),
                attention_name(record.attention).to_string(),
                record.content.summary.clone(),
            )
        })
        .collect()
}

/// Fills `notice`, `attention` and `text` from the newest notice published since `mark`,
/// `plain_or_error` with "yes" when any of them is a plain Info line or an Error, and
/// `all_notices` with every one of them, for the assertion messages.
pub fn read_notices(harness: &EditorHarness, mark: &NoticeMark, seen: &mut Seen) {
    let notices = notices_since(harness, mark);
    let (notice, attention, summary) = notices
        .last()
        .cloned()
        .unwrap_or_else(|| ("none".into(), "none".into(), String::new()));
    seen.insert("notice".into(), notice);
    seen.insert("attention".into(), attention);
    seen.insert("text".into(), summary);
    seen.insert(
        "plain_or_error".into(),
        yes_no(
            notices
                .iter()
                .any(|(severity, _, _)| severity == "Info" || severity == "Error"),
        ),
    );
    seen.insert("all_notices".into(), format!("{notices:?}"));
}

fn read_cursor(harness: &EditorHarness, seen: &mut Seen) {
    let (x, y) = harness.cursor_position();
    seen.insert("cursor_x".into(), x.to_string());
    seen.insert("cursor_y".into(), y.to_string());
}

fn yes_no(value: bool) -> String {
    if value { "yes" } else { "no" }.to_string()
}

// ---------------------------------------------------------------------------
// Stories: a search with nothing to find, and a search that wraps past an end of the
// buffer.

/// Inputs: `content`, `start_x`, `start_y`, `before` and `keys`. The keys in `before`
/// are typed first and aren't read (they set up a search to repeat); the keys in `keys`
/// are the command the case reads. Both are typed in normal mode and a newline is
/// Enter, so `/beta` plus a newline searches forward for "beta" and `?beta` plus a
/// newline searches backward.
/// Keys: `notice`, `attention`, `plain_or_error`, `cursor_x`, `cursor_y`.
pub async fn observe_search(inputs: &Value) -> Seen {
    let mut harness = scratch(text(inputs, "content"));
    place_cursor(&mut harness, inputs).await;
    type_keys(&mut harness, text(inputs, "before")).await;
    let mark = notice_mark(&harness);
    type_keys(&mut harness, text(inputs, "keys")).await;
    let mut seen = Seen::new();
    read_notices(&harness, &mark, &mut seen);
    read_cursor(&harness, &mut seen);
    seen
}

// ---------------------------------------------------------------------------
// Story: an operator or motion whose target isn't there.

/// Inputs: `content`, `start_x`, `start_y`, `keys` (typed in normal mode).
/// Keys: `notice`, `attention`, `plain_or_error`, `buffer`, `cursor_x`, `cursor_y`, `waiting` ("yes" while
/// the editor still waits for more keys of a sequence), and `after_x`: the buffer after
/// one more `x`, which deletes the character under the cursor when it's read as a new
/// command.
pub async fn observe_missing_target(inputs: &Value) -> Seen {
    let mut harness = scratch(text(inputs, "content"));
    place_cursor(&mut harness, inputs).await;
    let mark = notice_mark(&harness);
    type_keys(&mut harness, text(inputs, "keys")).await;
    let mut seen = Seen::new();
    read_notices(&harness, &mark, &mut seen);
    seen.insert("buffer".into(), harness.buffer_contents());
    read_cursor(&harness, &mut seen);
    seen.insert(
        "waiting".into(),
        yes_no(harness.is_waiting_for_key_sequence()),
    );
    type_keys(&mut harness, "x").await;
    seen.insert("after_x".into(), harness.buffer_contents());
    seen
}

// ---------------------------------------------------------------------------
// Story: the ends of the jump list, the edit history, the window layout and the
// syntax objects next to the cursor.

/// Inputs: `content`, and `action`: "jump_back", "jump_forward", "undo", "redo",
/// "window_left", "window_down", or "swap_next_parameter" (on a Rust file whose cursor
/// sits on the last parameter, at `start_x`, `start_y`).
/// Keys: `notice`, `attention`, `plain_or_error`, `text`.
pub async fn observe_boundary(inputs: &Value) -> Seen {
    let action_name = text(inputs, "action");
    let (mut harness, _dir) = if action_name == "swap_next_parameter" {
        let (mut harness, dir) = on_file("lib.rs", text(inputs, "content"));
        place_cursor(&mut harness, inputs).await;
        (harness, Some(dir))
    } else {
        (scratch(text(inputs, "content")), None)
    };
    let action = match action_name {
        "jump_back" => Action::JumpBack,
        "jump_forward" => Action::JumpForward,
        "undo" => Action::Undo,
        "redo" => Action::Redo,
        "window_left" => Action::MoveWindowLeft,
        "window_down" => Action::MoveWindowDown,
        "swap_next_parameter" => Action::SwapNextParameter,
        other => panic!("unknown action {other}"),
    };
    let mark = notice_mark(&harness);
    act(&mut harness, action).await;
    let mut seen = Seen::new();
    read_notices(&harness, &mark, &mut seen);
    seen
}

// ---------------------------------------------------------------------------
// Story: a lookup with nothing to show.

/// Inputs: `content`, and `action`: "go_to_definition", "show_line_diagnostics",
/// "next_inline_comment", "previous_inline_comment", "show_inline_comment" or
/// "dismiss_inline_comment". The buffer has no file, no diagnostics and no inline
/// comments.
/// Keys: `notice`, `attention`, `plain_or_error`, `buffer_kept` ("yes" when the text is what it was).
pub async fn observe_lookup(inputs: &Value) -> Seen {
    let mut harness = scratch(text(inputs, "content"));
    let action = match text(inputs, "action") {
        "go_to_definition" => Action::GoToDefinition,
        "show_line_diagnostics" => Action::ShowLineDiagnostics,
        "next_inline_comment" => Action::NextInlineComment,
        "previous_inline_comment" => Action::PreviousInlineComment,
        "show_inline_comment" => Action::ShowInlineComment,
        "dismiss_inline_comment" => Action::DismissInlineComment,
        other => panic!("unknown action {other}"),
    };
    let before = harness.buffer_contents();
    let mark = notice_mark(&harness);
    act(&mut harness, action).await;
    let mut seen = Seen::new();
    read_notices(&harness, &mark, &mut seen);
    seen.insert(
        "buffer_kept".into(),
        yes_no(harness.buffer_contents() == before),
    );
    seen
}

// ---------------------------------------------------------------------------
// Story: commands that do find their target.

/// Inputs: `content`, `start_x`, `start_y`, `keys` (typed in normal mode; a newline is
/// Enter).
/// Keys: `warned` ("yes" when any notice published while the keys ran is a Warning),
/// `plain_line` ("yes" when any of them is a plain Info line), `buffer`, `cursor_x`,
/// `cursor_y`.
pub async fn observe_success(inputs: &Value) -> Seen {
    let mut harness = scratch(text(inputs, "content"));
    place_cursor(&mut harness, inputs).await;
    let mark = notice_mark(&harness);
    type_keys(&mut harness, text(inputs, "keys")).await;
    let notices = notices_since(&harness, &mark);
    let mut seen = Seen::new();
    seen.insert(
        "warned".into(),
        yes_no(notices.iter().any(|(severity, _, _)| severity == "Warning")),
    );
    seen.insert(
        "plain_line".into(),
        yes_no(notices.iter().any(|(severity, _, _)| severity == "Info")),
    );
    seen.insert("all_notices".into(), format!("{notices:?}"));
    seen.insert("buffer".into(), harness.buffer_contents());
    read_cursor(&harness, &mut seen);
    seen
}
