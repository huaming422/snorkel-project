#!/usr/bin/env bash
# Sourced by tests/test.sh before the tests run (set -euo pipefail inherited).
#
# red is a single-crate Rust project. Its full dependency closure was baked into
# the image when it was built (Dockerfile blocks 5 and 7: `cargo fetch
# --locked` + `cargo build --locked --tests`), so this script only has to bring
# that closure online for `cargo test` and log a cache miss early. There are no
# services to start and no data to seed: the editor is exercised entirely
# in-process through the `red` crate's public test API.

cd /repo/red

# Force cargo offline so a cache miss shows up here instead of reaching for
# crates.io. Everything below has to work with no network.
export CARGO_NET_OFFLINE=true

# Dependencies: offline-first against the image bake, logged online fallback.
# A failure is logged and the script goes on, since it is sourced: an `exit`
# here would end tests/test.sh before any test ran.
if cargo fetch --locked --offline > /tmp/test-setup-fetch.log 2>&1; then
    echo "[offline-first] cargo deps satisfied from image"
elif CARGO_NET_OFFLINE=false cargo fetch --locked >> /tmp/test-setup-fetch.log 2>&1; then
    echo "[test-setup] cargo deps fetched online (image bake was stale)"
else
    echo "[test-setup] cargo fetch failed; the tests that build the crate will fail:" >&2
    tail -40 /tmp/test-setup-fetch.log >&2
fi

# Setup probe: compile the crate and its test targets from the warm target cache, so
# a build problem is logged once here. Offline; no assertion logic. A tree that
# doesn't compile is logged and the script goes on, for the same reason as above.
if cargo build --locked --tests --offline > /tmp/test-setup-build.log 2>&1; then
    echo "[offline-first] test build satisfied from image cache"
else
    echo "[test-setup] offline test build failed; the tests will report the build error:" >&2
    tail -60 /tmp/test-setup-build.log >&2
fi
