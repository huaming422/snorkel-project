// Behavioral checks for lookups whose final answer is empty.
//
// Three groups, all through public interfaces of the red crate:
//   * a definition request that a language server answers with nothing, seen in a
//     detached editor (`DetachedEditorCore`) whose language server is scripted here: the
//     warning marker on the bottom line, no badge for a notice that wants attention, and
//     one notice in the message history;
//   * the lsp_symbols plugin: document symbols and references that come back empty,
//     including a references lookup made while the server is still indexing, and the
//     same two lookups answered with an error;
//   * the git plugin: hunk stage, unstage and reset when the file has no change, and
//     when its change sits on a line the cursor isn't on.
//
// The plugins are loaded into a plugin `Runtime` and talk to the host through
// `ACTION_DISPATCHER`, as in the repository's own runtime tests. A plugin reports an
// outcome by sending host actions, so the actions it sends are run on a fresh editor,
// and what that editor publishes decides. For an empty result the newest notice has to
// be a warning with quiet attention, and none of them may be a plain info line or an
// error. An error reply has to show a plain info line and no warning. The messages'
// wording isn't checked.

use std::collections::{HashMap, VecDeque};
use std::process::Command;
use std::time::{Duration, Instant};

use red::buffer::Buffer;
use red::config::{Config, PluginPermissions};
use red::editor::{Action, DetachedEditorCore, Editor, PluginRequest, ACTION_DISPATCHER};
use red::headless::{InputEvent, KeyCode as SessionKey, KeyKind};
use red::lsp::{
    Diagnostic, InboundMessage, LspClient, LspError, Range, ResponseMessage, ServerCapabilities,
};
use red::notification::{AttentionPolicy, Severity};
use red::plugin::{RequestId, Runtime};
use red::test_utils::EditorTestExt;
use red::theme::Theme;
use serde_json::{json, Value};

// ---------------------------------------------------------------------------
// A language server that answers each definition request with a fixed reply.

#[derive(Default)]
struct ScriptedLsp {
    definition_reply: Option<Value>,
    inbox: VecDeque<(InboundMessage, Option<String>)>,
    next_id: i64,
}

// Same as the repository's MockLsp in tests/common: the editor keeps its client behind
// a trait object that has to be Send and Sync.
unsafe impl Send for ScriptedLsp {}
unsafe impl Sync for ScriptedLsp {}

impl ScriptedLsp {
    fn answering_definitions_with(reply: Value) -> Self {
        Self {
            definition_reply: Some(reply),
            ..Self::default()
        }
    }

    fn request_id(&mut self) -> i64 {
        self.next_id += 1;
        self.next_id
    }
}

#[async_trait::async_trait]
impl LspClient for ScriptedLsp {
    async fn initialize(&mut self) -> Result<(), LspError> {
        Ok(())
    }

    async fn did_open(&mut self, _file: &str, _contents: &str) -> Result<(), LspError> {
        Ok(())
    }

    async fn did_change(&mut self, _file: &str, _contents: String) -> Result<(), LspError> {
        Ok(())
    }

    async fn hover(&mut self, _file: &str, _x: usize, _y: usize) -> Result<i64, LspError> {
        Ok(0)
    }

    async fn goto_definition(
        &mut self,
        _file: &str,
        _x: usize,
        _y: usize,
    ) -> Result<i64, LspError> {
        let id = self.request_id();
        if let Some(reply) = self.definition_reply.clone() {
            self.inbox.push_back((
                InboundMessage::Message(ResponseMessage {
                    id,
                    result: reply,
                    request: None,
                }),
                Some("textDocument/definition".to_string()),
            ));
        }
        Ok(id)
    }

    async fn completion(&mut self, _file: &str, _x: usize, _y: usize) -> Result<i64, LspError> {
        Ok(0)
    }

    async fn format_document(&mut self, _file: &str) -> Result<i64, LspError> {
        Ok(0)
    }

    async fn document_symbols(&mut self, _file: &str) -> Result<i64, LspError> {
        Ok(0)
    }

    async fn code_action(
        &mut self,
        _file: &str,
        _range: Range,
        _diagnostics: Vec<Diagnostic>,
    ) -> Result<i64, LspError> {
        Ok(0)
    }

    async fn signature_help(&mut self, _file: &str, _x: usize, _y: usize) -> Result<i64, LspError> {
        Ok(0)
    }

    async fn rename(
        &mut self,
        _file: &str,
        _x: usize,
        _y: usize,
        _new_name: &str,
    ) -> Result<i64, LspError> {
        Ok(0)
    }

    async fn document_highlight(
        &mut self,
        _file: &str,
        _x: usize,
        _y: usize,
    ) -> Result<i64, LspError> {
        Ok(0)
    }

    async fn document_link(&mut self, _file: &str) -> Result<i64, LspError> {
        Ok(0)
    }

    async fn document_color(&mut self, _file: &str) -> Result<i64, LspError> {
        Ok(0)
    }

    async fn folding_range(&mut self, _file: &str) -> Result<i64, LspError> {
        Ok(0)
    }

    async fn workspace_symbol(&mut self, _query: &str) -> Result<i64, LspError> {
        Ok(0)
    }

    async fn references(
        &mut self,
        _file: &str,
        _x: usize,
        _y: usize,
        _include_declaration: bool,
    ) -> Result<i64, LspError> {
        Ok(0)
    }

    async fn call_hierarchy_prepare(
        &mut self,
        _file: &str,
        _x: usize,
        _y: usize,
    ) -> Result<i64, LspError> {
        Ok(0)
    }

    async fn semantic_tokens_full(&mut self, _file: &str) -> Result<i64, LspError> {
        Ok(0)
    }

    async fn inlay_hint(&mut self, _file: &str, _range: Range) -> Result<i64, LspError> {
        Ok(0)
    }

    async fn send_request(
        &mut self,
        _method: &str,
        _params: Value,
        _: bool,
    ) -> Result<i64, LspError> {
        Ok(0)
    }

    async fn send_notification(
        &mut self,
        _method: &str,
        _params: Value,
        _: bool,
    ) -> Result<(), LspError> {
        Ok(())
    }

    async fn request_completion(
        &mut self,
        _file_uri: &str,
        _line: usize,
        _character: usize,
        _trigger_character: Option<char>,
    ) -> Result<i64, LspError> {
        Ok(0)
    }

    async fn recv_response(
        &mut self,
    ) -> Result<Option<(InboundMessage, Option<String>)>, LspError> {
        Ok(self.inbox.pop_front())
    }

    fn get_server_capabilities(&self) -> Option<&ServerCapabilities> {
        None
    }

    async fn request_diagnostics(&mut self, _file: &str) -> Result<Option<i64>, LspError> {
        Ok(None)
    }

    async fn will_save(&mut self, _file: &str) -> Result<(), LspError> {
        Ok(())
    }

    async fn shutdown(&mut self) -> Result<(), LspError> {
        Ok(())
    }
}

/// Scales a wait by TIMEOUT_MULTIPLIER from the environment, so a slow host gets more time.
fn scaled(base: Duration) -> Duration {
    let factor = std::env::var("TIMEOUT_MULTIPLIER")
        .ok()
        .and_then(|value| value.parse::<f64>().ok())
        .filter(|factor| *factor >= 1.0)
        .unwrap_or(1.0);
    base.mul_f64(factor)
}

// ---------------------------------------------------------------------------
// The editor's view of host actions.

fn severity_name(severity: Severity) -> &'static str {
    match severity {
        Severity::Info => "info",
        Severity::Success => "success",
        Severity::Warning => "warning",
        Severity::Error => "error",
    }
}

fn attention_name(attention: AttentionPolicy) -> &'static str {
    match attention {
        AttentionPolicy::Quiet => "quiet",
        AttentionPolicy::IfMissed => "if-missed",
        AttentionPolicy::RequiresAcknowledgment => "requires-acknowledgment",
    }
}

/// Runs `actions` in order on a fresh editor and returns the notices it published, oldest
/// first, with a line that describes them.
async fn published_by(
    actions: Vec<Action>,
) -> Result<(Vec<(Severity, AttentionPolicy, String)>, String), String> {
    let mut editor = Editor::test_with_size(
        Box::new(ScriptedLsp::default()),
        80,
        24,
        Config::default(),
        Theme::default(),
        vec![Buffer::new(None, String::new())],
    )
    .map_err(|error| format!("could not build an editor: {error}"))?;
    editor.test_disable_terminal_output();
    let mark: Vec<_> = editor
        .notifications()
        .records()
        .map(|record| (record.id, record.occurrences, record.updated_at))
        .collect();
    for action in actions {
        editor
            .test_execute_action(action)
            .await
            .map_err(|error| format!("the editor failed on the plugin's action: {error}"))?;
    }
    let published: Vec<(Severity, AttentionPolicy, String)> = editor
        .notifications()
        .records()
        .filter(|record| !mark.contains(&(record.id, record.occurrences, record.updated_at)))
        .map(|record| {
            (
                record.severity,
                record.attention,
                record.content.summary.clone(),
            )
        })
        .collect();
    let described = published
        .iter()
        .map(|(severity, attention, summary)| {
            format!(
                "{} ({}): {summary}",
                severity_name(*severity),
                attention_name(*attention)
            )
        })
        .collect::<Vec<_>>()
        .join("; ");
    Ok((published, described))
}

/// Runs `actions` in order on a fresh editor and checks what it published: the newest
/// notice is a warning with quiet attention, and no notice is a plain info line or an
/// error.
async fn editor_reports_quiet_warning(actions: Vec<Action>) -> Result<(), String> {
    if actions.is_empty() {
        return Err("the plugin sent no host action for the empty result".to_string());
    }
    let (published, described) = published_by(actions).await?;
    if let Some((_, _, summary)) = published
        .iter()
        .find(|(severity, _, _)| matches!(severity, Severity::Info | Severity::Error))
    {
        return Err(format!(
            "the empty result also showed \"{summary}\" as a plain message or an error; published: {described}"
        ));
    }
    match published.last() {
        Some((Severity::Warning, AttentionPolicy::Quiet, _)) => Ok(()),
        Some(_) => Err(format!(
            "the newest notice isn't a quiet warning; published: {described}"
        )),
        None => Err("the plugin's actions made the editor publish nothing".to_string()),
    }
}

/// Runs `actions` in order on a fresh editor and checks that it showed a plain info line
/// and no warning.
async fn editor_reports_plain_line(actions: Vec<Action>) -> Result<(), String> {
    if actions.is_empty() {
        return Err("the plugin sent no host action for the error reply".to_string());
    }
    let (published, described) = published_by(actions).await?;
    if published
        .iter()
        .any(|(severity, _, _)| matches!(severity, Severity::Warning))
    {
        return Err(format!(
            "the error reply showed as a warning; published: {described}"
        ));
    }
    if !published
        .iter()
        .any(|(severity, _, _)| matches!(severity, Severity::Info))
    {
        return Err(format!(
            "the error reply showed no plain line; published: {described}"
        ));
    }
    Ok(())
}

// ---------------------------------------------------------------------------
// A definition reply with nothing in it.

/// What a detached editor shows after a definition reply: the rendered rows once the reply
/// has been read, the cursor's screen row before and after, and the rows of the message
/// history (`:messages`) opened afterwards.
struct ReplyScreen {
    rows: Vec<String>,
    row_before: usize,
    row_after: usize,
    history: Vec<String>,
}

/// Lets a detached editor idle for `millis` (scaled by TIMEOUT_MULTIPLIER) and returns
/// its rendered rows.
async fn idle_rows(core: &mut DetachedEditorCore, millis: u64) -> Vec<String> {
    let until = Instant::now() + scaled(Duration::from_millis(millis));
    while Instant::now() < until {
        let _ = core.tick().await;
        tokio::time::sleep(Duration::from_millis(25)).await;
    }
    core.snapshot(None)
        .lines
        .into_iter()
        .map(|line| line.text)
        .collect()
}

/// Opens a Rust file in an editor whose language server answers definition requests with
/// `reply`, asks for the definition of `helper` on line 2, detaches the editor and lets it
/// idle so it reads the reply. Then it types `:messages` and Enter to open the history.
async fn definition_reply_screen(reply_for: impl Fn(&str) -> Value) -> ReplyScreen {
    let directory = tempfile::tempdir().expect("tempdir");
    let path = directory.path().join("main.rs");
    let text = "fn main() {\n    helper();\n}\n\nfn helper() {}\n";
    std::fs::write(&path, text).expect("write main.rs");
    let file = path.to_string_lossy().into_owned();
    let config = Config::from_user_toml_with_overrides("", &[]).expect("default user config");
    let lsp = ScriptedLsp::answering_definitions_with(reply_for(&file));
    let mut editor = Editor::test_with_size(
        Box::new(lsp),
        80,
        24,
        config,
        Theme::default(),
        vec![Buffer::new(Some(file.clone()), text.to_string())],
    )
    .expect("editor");
    editor.test_disable_terminal_output();
    editor
        .test_execute_action(Action::SetCursor(4, 1))
        .await
        .expect("cursor on the call");
    editor
        .test_execute_action(Action::GoToDefinition)
        .await
        .expect("definition request");
    let mut core = DetachedEditorCore::new(editor)
        .await
        .expect("detached editor");
    let row_before = core.snapshot(None).cursor.1;
    let rows = idle_rows(&mut core, 1500).await;
    let row_after = core.snapshot(None).cursor.1;
    for c in ":messages\n".chars() {
        let code = if c == '\n' {
            SessionKey::Enter
        } else {
            SessionKey::Character(c)
        };
        let _ = core
            .input(InputEvent::Key {
                code,
                modifiers: Vec::new(),
                key_kind: KeyKind::Press,
            })
            .await;
    }
    let history = idle_rows(&mut core, 300).await;
    ReplyScreen {
        rows,
        row_before,
        row_after,
        history,
    }
}

/// Rows the editor draws with the warning marker in front: a notice of Warning severity
/// shows as "! <summary>" on the bottom line.
fn warning_rows(rows: &[String]) -> Vec<String> {
    rows.iter()
        .filter(|row| row.trim_start().starts_with("! "))
        .cloned()
        .collect()
}

/// Rows with the bottom line's badge for notices that still want the user: "needs
/// attention" for a notice that asks to be acknowledged, "missed" for one that counts as
/// unread until it's shown, or the short "[N]" form of either.
fn badge_rows(rows: &[String]) -> Vec<String> {
    rows.iter()
        .filter(|row| {
            row.contains("needs attention")
                || row.contains(" missed")
                || row.split('[').skip(1).any(|part| {
                    let digits: String = part.chars().take_while(char::is_ascii_digit).collect();
                    !digits.is_empty() && part[digits.len()..].starts_with(']')
                })
        })
        .cloned()
        .collect()
}

/// The number of notices the message history says it keeps ("<n> retained"), if it says.
fn retained_count(history: &[String]) -> Option<usize> {
    history.iter().find_map(|row| {
        let head = row.split(" retained").next()?;
        if head.len() == row.len() {
            return None;
        }
        head.rsplit(|c: char| !c.is_ascii_digit())
            .next()
            .and_then(|n| n.parse().ok())
    })
}

#[tokio::test]
async fn definition_reply_with_nothing_warns() {
    for (label, reply) in [("an empty list", json!([])), ("null", Value::Null)] {
        let screen = definition_reply_screen(|_| reply.clone()).await;
        let rows = &screen.rows;
        assert!(
            !warning_rows(rows).is_empty(),
            "a definition reply of {label} showed no warning; rows: {rows:#?}"
        );
        assert!(
            badge_rows(rows).is_empty(),
            "a definition reply of {label} left a notice that wants attention, either a \
             warning that isn't quiet or a plain line nobody has seen: {:?}",
            badge_rows(rows)
        );
        assert_eq!(
            retained_count(&screen.history),
            Some(1),
            "a definition reply of {label} should leave the warning as the one notice in \
             the message history; history rows: {:#?}",
            screen.history
        );
    }
}

#[tokio::test]
async fn definition_reply_with_a_location_jumps_without_warning() {
    let screen = definition_reply_screen(|file| {
        json!([{
            "uri": format!("file://{file}"),
            "range": {
                "start": { "line": 4, "character": 3 },
                "end": { "line": 4, "character": 9 }
            }
        }])
    })
    .await;
    assert!(
        warning_rows(&screen.rows).is_empty() && badge_rows(&screen.rows).is_empty(),
        "a definition reply with a location showed a notice: {:?}",
        screen.rows.last()
    );
    assert_eq!(
        retained_count(&screen.history).unwrap_or(0),
        0,
        "a definition reply with a location published a notice; history rows: {:#?}",
        screen.history
    );
    assert_ne!(
        screen.row_before, screen.row_after,
        "a definition reply with a location didn't move the cursor; rows: {:#?}",
        screen.rows
    );
}

// ---------------------------------------------------------------------------
// The lsp_symbols plugin.

// Loads `plugins/lsp_symbols.hk` into a fresh runtime and answers its config request,
// the way the repository's runtime tests do (their helper is private to the crate). The
// path is relative to this file once it sits in the crate's tests folder.
async fn load_lsp_symbols(runtime: &mut Runtime) {
    runtime
        .load_plugin("lsp_symbols", include_str!("../plugins/lsp_symbols.hk"))
        .await
        .expect("lsp_symbols plugin should load");
    let config_request_id = match ACTION_DISPATCHER.recv_request() {
        PluginRequest::GetConfig { request_id, .. } => request_id,
        // PluginRequest has no Debug impl in this repository.
        _ => panic!("expected GetConfig on plugin load"),
    };
    runtime
        .resolve_request(
            config_request_id,
            json!({
                "value": {
                    "lsp_symbols": {
                        "icons": { "enabled": true, "overrides": {} }
                    }
                }
            }),
        )
        .await
        .expect("config resolve should succeed");
}

fn empty_symbol_payload() -> Value {
    json!({ "ok": true, "symbols": [] })
}

fn empty_reference_payload() -> Value {
    json!({
        "ok": true,
        "file": "src/main.rs",
        "position": { "line": 0, "character": 0 },
        "references": []
    })
}

// The dispatcher is a process-wide static, so each scenario starts by emptying it.
fn drain_requests() {
    while ACTION_DISPATCHER.try_recv_request().is_some() {}
}

/// Every request the plugin has queued for the host right now.
fn queued_requests() -> Vec<PluginRequest> {
    let mut requests = Vec::new();
    while let Some(request) = ACTION_DISPATCHER.try_recv_request() {
        requests.push(request);
    }
    requests
}

/// The host actions among `requests`, in order.
fn host_actions(requests: Vec<PluginRequest>) -> Vec<Action> {
    requests
        .into_iter()
        .filter_map(|request| match request {
            PluginRequest::Action(action) => Some(action),
            _ => None,
        })
        .collect()
}

async fn notify_progress(runtime: &mut Runtime, kind: &str) {
    runtime
        .notify(
            "lsp:progress",
            json!({
                "token": "index",
                "kind": kind,
                "lsp_client": { "name": "rust_analyzer", "workspace_root": "/repo" },
            }),
        )
        .await
        .expect("progress notification");
}

/// Runs LspReferences and returns the id of the References request it makes.
async fn start_references(runtime: &mut Runtime) -> RequestId {
    runtime
        .execute_command("LspReferences")
        .await
        .expect("LspReferences should dispatch");
    for request in queued_requests() {
        if let PluginRequest::References { request_id, .. } = request {
            return request_id;
        }
    }
    panic!("LspReferences made no References request");
}

#[tokio::test]
async fn plugin_empty_result_warns() {
    // Document symbols: the final result is an empty list.
    {
        drain_requests();
        let mut runtime = Runtime::new();
        load_lsp_symbols(&mut runtime).await;
        runtime
            .execute_command("LspDocumentSymbols")
            .await
            .expect("LspDocumentSymbols should dispatch");
        let request_id = queued_requests()
            .into_iter()
            .find_map(|request| match request {
                PluginRequest::DocumentSymbols { request_id, .. } => Some(request_id),
                _ => None,
            })
            .expect("LspDocumentSymbols made no DocumentSymbols request");
        runtime
            .resolve_request(request_id, empty_symbol_payload())
            .await
            .expect("document-symbols resolve should succeed");
        if let Err(problem) = editor_reports_quiet_warning(host_actions(queued_requests())).await {
            panic!("document symbols with an empty result: {problem}");
        }
    }

    // References: the final result is an empty list.
    {
        drain_requests();
        let mut runtime = Runtime::new();
        load_lsp_symbols(&mut runtime).await;
        let request_id = start_references(&mut runtime).await;
        runtime
            .resolve_request(request_id, empty_reference_payload())
            .await
            .expect("references resolve should succeed");
        if let Err(problem) = editor_reports_quiet_warning(host_actions(queued_requests())).await {
            panic!("references with an empty result: {problem}");
        }
    }
}

#[tokio::test]
async fn references_wait_for_indexing_before_warning() {
    drain_requests();
    let mut runtime = Runtime::new();
    load_lsp_symbols(&mut runtime).await;
    let first_request = start_references(&mut runtime).await;

    // The server starts indexing, and the first answer comes back empty meanwhile.
    notify_progress(&mut runtime, "begin").await;
    runtime
        .resolve_request(first_request, empty_reference_payload())
        .await
        .expect("references resolve should succeed");
    let while_indexing = queued_requests();
    assert!(
        !while_indexing.iter().any(|request| matches!(
            request,
            PluginRequest::Action(_) | PluginRequest::ClosePicker { .. }
        )),
        "an empty references answer that came while the server was indexing ended the lookup \
         instead of waiting for the indexing to finish"
    );

    // Indexing ends, the lookup asks again, and the final answer is empty too.
    notify_progress(&mut runtime, "end").await;
    let retried = queued_requests()
        .into_iter()
        .find_map(|request| match request {
            PluginRequest::References { request_id, .. } => Some(request_id),
            _ => None,
        });
    let Some(second_request) = retried else {
        panic!("the references lookup didn't ask again once the server finished indexing");
    };
    runtime
        .resolve_request(second_request, empty_reference_payload())
        .await
        .expect("references resolve should succeed");
    if let Err(problem) = editor_reports_quiet_warning(host_actions(queued_requests())).await {
        panic!("references with an empty final result after indexing: {problem}");
    }
}

#[tokio::test]
async fn plugin_error_reply_stays_plain() {
    // Document symbols: the server answers with an error.
    {
        drain_requests();
        let mut runtime = Runtime::new();
        load_lsp_symbols(&mut runtime).await;
        runtime
            .execute_command("LspDocumentSymbols")
            .await
            .expect("LspDocumentSymbols should dispatch");
        let request_id = queued_requests()
            .into_iter()
            .find_map(|request| match request {
                PluginRequest::DocumentSymbols { request_id, .. } => Some(request_id),
                _ => None,
            })
            .expect("LspDocumentSymbols made no DocumentSymbols request");
        runtime
            .resolve_request(
                request_id,
                json!({ "ok": false, "error": "the server stopped" }),
            )
            .await
            .expect("document-symbols resolve should succeed");
        if let Err(problem) = editor_reports_plain_line(host_actions(queued_requests())).await {
            panic!("document symbols answered with an error: {problem}");
        }
    }

    // References: the server answers with an error.
    {
        drain_requests();
        let mut runtime = Runtime::new();
        load_lsp_symbols(&mut runtime).await;
        let request_id = start_references(&mut runtime).await;
        runtime
            .resolve_request(
                request_id,
                json!({ "ok": false, "error": "the server stopped" }),
            )
            .await
            .expect("references resolve should succeed");
        if let Err(problem) = editor_reports_plain_line(host_actions(queued_requests())).await {
            panic!("references answered with an error: {problem}");
        }
    }
}

// ---------------------------------------------------------------------------
// The git plugin.

// Relays ready subprocess events back into the plugin as `process:<id>` notifications,
// as the repository's git runtime tests do. The hunk flow runs `git diff` and goes on
// from its output and exit events.
async fn pump_process_events(runtime: &mut Runtime) {
    for event in runtime.poll_process_events() {
        if let Some(process_id) = event
            .get("process_id")
            .and_then(Value::as_str)
            .map(str::to_string)
        {
            runtime
                .notify(&format!("process:{process_id}"), event)
                .await
                .expect("process event relay should succeed");
        }
    }
}

// Loads `plugins/git.hk` and answers its three load requests (cwd, full config, editor
// info), rooted at a real git worktree so the plugin's `git diff` can run.
async fn load_git_plugin(runtime: &mut Runtime, root: &std::path::Path) {
    runtime
        .load_plugin("git", include_str!("../plugins/git.hk"))
        .await
        .expect("git plugin should load");

    let mut cwd_id = None;
    let mut config_id = None;
    let mut info_id = None;
    for _ in 0..3 {
        match ACTION_DISPATCHER.recv_request() {
            PluginRequest::GetConfig { request_id, key } if key.as_deref() == Some("cwd") => {
                cwd_id = Some(request_id);
            }
            PluginRequest::GetConfig {
                request_id,
                key: None,
            } => config_id = Some(request_id),
            PluginRequest::EditorInfo(request_id) => info_id = Some(request_id),
            // PluginRequest has no Debug impl in this repository.
            _ => panic!("unexpected plugin request during git load"),
        }
    }
    runtime
        .resolve_request(
            cwd_id.expect("git plugin should request cwd"),
            json!({ "value": root.display().to_string() }),
        )
        .await
        .expect("cwd resolve should succeed");
    runtime
        .resolve_request(
            config_id.expect("git plugin should request config"),
            json!({ "value": { "executable": "red", "plugin_config": {} } }),
        )
        .await
        .expect("config resolve should succeed");
    runtime
        .resolve_request(
            info_id.expect("git plugin should request editor info"),
            json!({
                "theme": {
                    "style": { "fg": null, "bg": null, "bold": false, "italic": false },
                    "ui_style": {
                        "muted": { "fg": null, "bg": null, "bold": false, "italic": false },
                        "popup_title": { "fg": null, "bg": null, "bold": false, "italic": false }
                    },
                    "colors": {}
                }
            }),
        )
        .await
        .expect("editor info resolve should succeed");
}

fn git(root: &std::path::Path, args: &[&str]) {
    let status = Command::new("git")
        .args(args)
        .current_dir(root)
        .status()
        .expect("run git");
    assert!(status.success(), "git {args:?} failed");
}

/// Runs one hunk command on a committed file with the cursor on its first line, answering the plugin's
/// requests the way the editor would, and returns the host actions it sends once it has
/// sent any.
async fn hunk_command_actions(
    command: &str,
    root: &std::path::Path,
    file: &std::path::Path,
    text: &str,
) -> Vec<Action> {
    drain_requests();
    let mut runtime = Runtime::new_with_permissions(HashMap::from([(
        "git".to_string(),
        PluginPermissions {
            process: vec!["git".to_string()],
        },
    )]));
    load_git_plugin(&mut runtime, root).await;
    runtime
        .execute_command(command)
        .await
        .unwrap_or_else(|error| panic!("{command} should dispatch: {error}"));

    let deadline = Instant::now() + scaled(Duration::from_secs(10));
    let mut actions = Vec::new();
    let mut quiet_since: Option<Instant> = None;
    loop {
        pump_process_events(&mut runtime).await;
        let mut progressed = false;
        while let Some(request) = ACTION_DISPATCHER.try_recv_request() {
            progressed = true;
            match request {
                PluginRequest::GetWindows { request_id } => {
                    runtime
                        .resolve_request(
                            request_id,
                            json!({
                                "windows": [{
                                    "buffer_path": file.display().to_string(),
                                    "buffer_index": 7,
                                    "active": true
                                }]
                            }),
                        )
                        .await
                        .expect("windows resolve");
                }
                PluginRequest::GetSelection { request_id } => {
                    runtime
                        .resolve_request(request_id, Value::Null)
                        .await
                        .expect("selection resolve");
                }
                PluginRequest::GetBufferText { request_id, .. } => {
                    runtime
                        .resolve_request(request_id, json!({ "text": text }))
                        .await
                        .expect("buffer text resolve");
                }
                PluginRequest::GetCursorPosition { request_id } => {
                    runtime
                        .resolve_request(request_id, json!({ "x": 0, "y": 0 }))
                        .await
                        .expect("cursor resolve");
                }
                PluginRequest::Action(action) => actions.push(action),
                _ => {}
            }
        }
        // Once the plugin has sent an action, give it a moment to send any that follow.
        if !actions.is_empty() {
            if progressed {
                quiet_since = Some(Instant::now());
            }
            if quiet_since.is_some_and(|since| since.elapsed() > Duration::from_millis(200)) {
                return actions;
            }
        }
        assert!(
            Instant::now() < deadline,
            "{command} sent no host action in time"
        );
        tokio::time::sleep(Duration::from_millis(10)).await;
    }
}

#[tokio::test]
async fn git_hunk_empty_result_warns() {
    // A committed file of 30 lines, with the cursor on its first line.
    let repository = tempfile::tempdir().expect("tempdir");
    let root = repository.path();
    let file = root.join("tracked.txt");
    git(root, &["init", "-q"]);
    let original = (1..=30)
        .map(|line| {
            format!(
                "line {line}
"
            )
        })
        .collect::<String>();
    std::fs::write(&file, &original).expect("write tracked file");
    git(root, &["add", "tracked.txt"]);
    git(
        root,
        &[
            "-c",
            "user.name=Red Verifier",
            "-c",
            "user.email=red@example.test",
            "commit",
            "-qm",
            "initial",
        ],
    );

    // No change anywhere: no hunk at all.
    for command in ["GitHunkStage", "GitHunkUnstage", "GitHunkReset"] {
        let actions = hunk_command_actions(command, root, &file, &original).await;
        if let Err(problem) = editor_reports_quiet_warning(actions).await {
            panic!("{command} with no change in the file: {problem}");
        }
    }

    // A change on line 30 and the cursor on line 1: there is a hunk, just not under the
    // cursor. Stage and reset see the change in the working tree; unstage sees it once
    // it's staged.
    let changed = original.replace(
        "line 30
",
        "line 30, changed
",
    );
    std::fs::write(&file, &changed).expect("change line 30");
    for command in ["GitHunkStage", "GitHunkReset"] {
        let actions = hunk_command_actions(command, root, &file, &changed).await;
        if let Err(problem) = editor_reports_quiet_warning(actions).await {
            panic!("{command} with a hunk on line 30 and the cursor on line 1: {problem}");
        }
    }
    git(root, &["add", "tracked.txt"]);
    let actions = hunk_command_actions("GitHunkUnstage", root, &file, &changed).await;
    if let Err(problem) = editor_reports_quiet_warning(actions).await {
        panic!("GitHunkUnstage with a staged hunk on line 30 and the cursor on line 1: {problem}");
    }
}
