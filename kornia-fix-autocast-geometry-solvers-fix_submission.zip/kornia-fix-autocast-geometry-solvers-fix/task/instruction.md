## Task

a few of our geometry fitting routines return wrong results when a caller runs them inside a mixed-precision autocast block. this hits the homography, fundamental-matrix, and RANSAC fits of point correspondences.

on plain float32 inputs the result comes back in a lower-precision dtype and drifts noticeably from what the same call returns outside the autocast block. on GPU it's worse: some of these fits crash with a NotImplementedError inside autocast instead of returning anything at all. the exact same fits run outside autocast come back correct.

the fitting math itself is fine, so this isn't about the linear algebra; it's about how these routines behave once a caller's mixed-precision region is in play. dig in and make the fits return the correct result whether or not the caller happens to be inside autocast. one thing not to disturb: these routines can already infer their output shape on meta-device inputs today, and that has to stay true after the fix.
