"""Behavioral checks for the geometry solvers' interaction with a caller's autocast region.

The contract under test: a homography / fundamental-matrix / RANSAC fit run inside a caller's
mixed-precision ``torch.autocast`` region must return the SAME result (same dtype, bit-for-bit the
same values) as the identical call made outside autocast. On the pre-fix code a float32 solve under
``torch.autocast("cpu", dtype=torch.bfloat16)`` comes back in a lower-precision dtype and its values
drift; the checks below compare the inside-autocast result against the outside-autocast result with
``atol=0, rtol=0`` so any drift or dtype change is caught. Merely casting the returned value back to
float32 does not make the two bit-identical (the internal matmuls still ran in low precision), so
that shallow correction does not satisfy these checks.

Everything is tested THROUGH the pre-existing public solver functions (``find_homography_dlt`` and
its variants, ``find_fundamental``, ``RANSAC``, ``find_affine``). The invariant is
independent of how the fix is structured internally, so any structure that keeps the numerical solve
out of the caller's autocast passes.

Fixtures are self-contained: the repository ``conftest.py`` (and its ``device`` / ``dtype``
fixtures) is not in scope when this file is collected from the verify directory. The device is CPU
and every scenario is reproducible with CPU bfloat16/float16 autocast, so no GPU is required. The
scenarios and seeds mirror the repository's own upstream tests so the numbers reproduce exactly.
"""

from __future__ import annotations

import pytest
import torch

from kornia.geometry import RANSAC
from kornia.geometry.epipolar import find_fundamental
from kornia.geometry.homography import (
    find_homography_dlt,
    find_homography_dlt_iterated,
    find_homography_lines_dlt,
    find_homography_lines_dlt_iterated,
)
from kornia.geometry.linalg import transform_points
from kornia.geometry.solvers.affine import find_affine

from testing.base import DYNAMO_UNAVAILABLE_REASON, assert_close, dynamo_is_available
from testing.geometry.create import create_dominant_plane_scene

# The container runs on CPU; CPU bfloat16/float16 autocast reproduces every scenario.
DEVICE = "cpu"
AUTOCAST_DTYPE = torch.bfloat16


def _segments(points: torch.Tensor) -> torch.Tensor:
    """Reshape a flat (B, 2N, 2) point buffer into (B, N, 2, 2) segment endpoints."""
    return points.reshape(points.shape[0], -1, 2, 2)


def _homography_points():
    """Deterministic float32 point correspondences for the DLT homography fits."""
    generator = torch.Generator().manual_seed(0)
    H = torch.tensor([[1.05, 0.03, 4.0], [-0.02, 0.98, 6.0], [1e-4, 2e-5, 1.0]])
    points1 = torch.rand(1, 100, 2, generator=generator) * torch.tensor([600.0, 450.0])
    points2 = transform_points(H[None], points1) + torch.randn(1, 100, 2, generator=generator)
    weights = torch.rand(1, 100, generator=generator)
    return points1, points2, weights


# The six public DLT homography solve variants, as single-call closures.
_HOMOGRAPHY_SOLVES = [
    pytest.param(lambda p1, p2, w: find_homography_dlt(p1[:, :4], p2[:, :4]), id="dlt-4-points"),
    pytest.param(lambda p1, p2, w: find_homography_dlt(p1, p2, w), id="dlt-lu"),
    pytest.param(lambda p1, p2, w: find_homography_dlt(p1, p2, w, solver="svd"), id="dlt-svd"),
    pytest.param(lambda p1, p2, w: find_homography_dlt_iterated(p1, p2, w, 5.0), id="dlt-iterated"),
    pytest.param(lambda p1, p2, w: find_homography_lines_dlt(_segments(p1), _segments(p2)), id="lines-dlt"),
    pytest.param(
        lambda p1, p2, w: find_homography_lines_dlt_iterated(_segments(p1), _segments(p2), w[:, ::2], 5.0),
        id="lines-dlt-iterated",
    ),
]


# --------------------------------------------------------------------------------------------------
# Homography DLT fits are invariant to a caller's autocast region.
# --------------------------------------------------------------------------------------------------
@pytest.mark.parametrize("solve", _HOMOGRAPHY_SOLVES)
def test_homography_autocast_invariant(solve):
    """Each DLT homography variant returns a float32 result bit-identical in and out of autocast."""
    points1, points2, weights = _homography_points()
    expected = solve(points1, points2, weights)
    with torch.autocast(DEVICE, dtype=AUTOCAST_DTYPE):
        actual = solve(points1, points2, weights)
    assert actual.dtype == torch.float32
    assert_close(actual, expected, atol=0, rtol=0)


# --------------------------------------------------------------------------------------------------
# Fundamental-matrix fits are invariant to a caller's autocast region.
# --------------------------------------------------------------------------------------------------
@pytest.mark.parametrize(
    "method, num_points, weighted",
    [("7POINT", 7, False), ("8POINT", 8, False), ("8POINT", 100, False), ("8POINT", 100, True)],
)
def test_fundamental_autocast_invariant(method, num_points, weighted):
    """find_fundamental (7/8-point, weighted and unweighted) is bit-identical in and out of autocast."""
    generator = torch.Generator().manual_seed(0)
    points1 = torch.rand(1, num_points, 2, generator=generator) * torch.tensor([640.0, 480.0])
    points2 = points1 + torch.tensor([30.0, -5.0]) + 4.0 * torch.randn(1, num_points, 2, generator=generator)
    weights = torch.rand(1, num_points, generator=generator) if weighted else None
    expected = find_fundamental(points1, points2, weights, method=method)
    with torch.autocast(DEVICE, dtype=AUTOCAST_DTYPE):
        actual = find_fundamental(points1, points2, weights, method=method)
    assert actual.dtype == torch.float32
    assert_close(actual, expected, atol=0, rtol=0)


# --------------------------------------------------------------------------------------------------
# RANSAC estimates are invariant to a caller's autocast region.
# --------------------------------------------------------------------------------------------------
@pytest.mark.parametrize("model_type", ["homography", "fundamental"])
@pytest.mark.parametrize("local_optimization", ["lm", "dlt"])
def test_ransac_autocast_invariant(model_type, local_optimization):
    """RANSAC's estimate and inlier mask are bit-identical in and out of autocast.

    Noise at half the inlier threshold places many correspondences where a low-precision score would
    flip them, so a bfloat16 solve/score produces a different estimate and inlier set.
    """
    kp1, kp2, _, _, _ = create_dominant_plane_scene(500, 0.9, 0.5, 0, noise=1.0, device=DEVICE)
    results = []
    for enabled in (False, True):
        ransac = RANSAC(model_type, inl_th=2.0, seed=0, local_optimization=local_optimization)
        with torch.autocast(DEVICE, dtype=AUTOCAST_DTYPE, enabled=enabled):
            results.append(ransac(kp1, kp2))
    (expected, expected_inliers), (actual, actual_inliers) = results
    assert actual.dtype == torch.float32
    assert expected_inliers.any()
    assert_close(actual, expected, atol=0, rtol=0)
    assert_close(actual_inliers, expected_inliers, atol=0, rtol=0)


# --------------------------------------------------------------------------------------------------
# Shape inference works on meta-device inputs (regression guard; works on the pre-fix code too).
# --------------------------------------------------------------------------------------------------
def test_meta_device_shape_inference_homography():
    """The DLT homography solvers infer output shape on meta-device inputs without raising."""
    points = torch.empty(2, 8, 2, device="meta")
    weights = torch.empty(2, 8, device="meta")
    segments = points.reshape(2, 4, 2, 2)
    assert find_homography_dlt(points, points).shape == (2, 3, 3)
    assert find_homography_dlt_iterated(points, points, weights).shape == (2, 3, 3)
    assert find_homography_lines_dlt(segments, segments).shape == (2, 3, 3)
    assert find_homography_lines_dlt_iterated(segments, segments, weights[:, :4]).shape == (2, 3, 3)


def test_meta_device_shape_inference_fundamental():
    """find_fundamental infers output shape on meta-device inputs for both methods."""
    points = torch.empty(2, 9, 2, device="meta")
    assert find_fundamental(points, points).shape == (2, 3, 3)
    assert find_fundamental(points[:, :7], points[:, :7], method="7POINT").shape == (2, 3, 3, 3)


# --------------------------------------------------------------------------------------------------
# Meta-device shape inference traces under torch.compile (skipped when compile is unavailable).
# --------------------------------------------------------------------------------------------------
@pytest.mark.skipif(not dynamo_is_available(), reason=DYNAMO_UNAVAILABLE_REASON)
def test_meta_traces_under_compile():
    """find_fundamental traces on meta-device inputs under torch.compile(backend='eager', fullgraph=True).

    Entering autocast on the meta device raises, and under compile that error is surfaced as an
    internal tracing error rather than a catchable exception, so the guard must avoid it for meta.
    """
    torch._dynamo.reset()
    points = torch.empty(2, 9, 2, device="meta")
    compiled = torch.compile(find_fundamental, backend="eager", fullgraph=True)
    assert compiled(points, points).shape == (2, 3, 3)


# --------------------------------------------------------------------------------------------------
# Device-type coverage of the precision guard (supplementary; tolerates any fix structure).
# --------------------------------------------------------------------------------------------------
def _load_autocast_guard():
    """Return the private autocast-disabling context helper if this fix exposes it by that name.

    A fix may instead inline the guard per solver or use a decorator; those structures still pass
    every solver-level check above, so this device-coverage check skips when the named helper is
    absent rather than demanding a particular internal structure.
    """
    try:
        from kornia.core.utils import _autocast_disabled
    except Exception:  # noqa: BLE001 - any import failure means the fix is structured differently
        pytest.skip("this fix does not expose a named autocast-disabling helper; covered by solver-level checks")
    return _autocast_disabled


def test_autocast_guard_disables_enabled_cpu_region():
    """Inside an enabled cpu autocast region the guard turns it off and matmuls run in float32."""
    guard = _load_autocast_guard()
    with torch.autocast("cpu", dtype=torch.bfloat16):
        with guard("cpu"):
            assert not torch.is_autocast_enabled("cpu")
            assert (torch.ones(2, 2) @ torch.ones(2, 2)).dtype == torch.float32
        assert torch.is_autocast_enabled("cpu")
    assert not torch.is_autocast_enabled("cpu")


@pytest.mark.parametrize("device_type", ["cpu", "cuda", "meta"])
def test_autocast_guard_is_noop_when_off(device_type):
    """Outside autocast (and for the meta device) the guard enters nothing."""
    from contextlib import nullcontext

    guard = _load_autocast_guard()
    context = guard(device_type)
    assert isinstance(context, nullcontext)


@pytest.mark.parametrize("device_type", ["xla", "hpu"])
def test_autocast_guard_covers_other_device_types(device_type):
    """The guard disables an enabled autocast region for string device-types such as xla/hpu."""
    guard = _load_autocast_guard()
    with torch.autocast(device_type, dtype=torch.bfloat16), guard(device_type):
        assert not torch.is_autocast_enabled(device_type)


# --------------------------------------------------------------------------------------------------
# Outside autocast the pre-existing solver behavior is unchanged (regression guard).
# --------------------------------------------------------------------------------------------------
def test_regression_homography_dlt_recovers_known_transform():
    """Outside autocast, find_homography_dlt still recovers a known float32 homography."""
    generator = torch.Generator().manual_seed(0)
    H = torch.tensor([[[1.05, 0.03, 4.0], [-0.02, 0.98, 6.0], [1e-4, 2e-5, 1.0]]])
    points1 = torch.rand(1, 50, 2, generator=generator) * torch.tensor([600.0, 450.0])
    points2 = transform_points(H, points1)
    H_fit = find_homography_dlt(points1, points2)
    assert H_fit.shape == (1, 3, 3)
    mapped = transform_points(H_fit, points1)
    assert_close(mapped, points2, atol=1e-2, rtol=1e-2)


def test_regression_fundamental_8point_satisfies_epipolar_constraint():
    """Outside autocast, an 8-point fundamental fit still satisfies x2^T F x1 ~= 0 on clean data."""
    generator = torch.Generator().manual_seed(1)
    H = torch.tensor([[[1.1, 0.02, 3.0], [-0.01, 0.97, 5.0], [2e-4, 1e-5, 1.0]]])
    points1 = torch.rand(1, 60, 2, generator=generator) * torch.tensor([640.0, 480.0])
    points2 = transform_points(H, points1)
    F = find_fundamental(points1, points2, method="8POINT")
    assert F.shape == (1, 3, 3)
    assert F.dtype == torch.float32
    ones = torch.ones(1, points1.shape[1], 1)
    p1h = torch.cat([points1, ones], dim=-1)
    p2h = torch.cat([points2, ones], dim=-1)
    residual = torch.einsum("bni,bij,bnj->bn", p2h, F, p1h)
    assert residual.abs().mean() < 1.0


def test_regression_ransac_homography_float32_runs():
    """Outside autocast, RANSAC still returns a float32 homography with inliers on a plane scene."""
    kp1, kp2, _, _, _ = create_dominant_plane_scene(500, 0.9, 0.5, 0, noise=1.0, device=DEVICE)
    ransac = RANSAC("homography", inl_th=2.0, seed=0, local_optimization="dlt")
    model, inliers = ransac(kp1, kp2)
    assert model.dtype == torch.float32
    assert model.shape == (3, 3)
    assert inliers.any()


def test_regression_find_affine_recovers_known_transform():
    """Outside autocast, find_affine still recovers a known float32 affine transform."""
    generator = torch.Generator().manual_seed(2)
    A = torch.tensor([[[1.2, 0.1, 5.0], [-0.05, 0.9, -3.0]]])
    points1 = torch.rand(1, 10, 2, generator=generator) * torch.tensor([100.0, 100.0])
    ones = torch.ones(1, points1.shape[1], 1)
    points2 = torch.einsum("bij,bnj->bni", A, torch.cat([points1, ones], dim=-1))
    model = find_affine(points1, points2)
    assert model.shape == (1, 3, 3)
    mapped = transform_points(model, points1)
    assert_close(mapped, points2, atol=1e-2, rtol=1e-2)
