#!/usr/bin/env bash
# Test-setup for rtk-fix-ls-arg-parsing. The image pre-fetches the workspace
# deps (`cargo fetch --locked`) and pre-builds the repo + tests at the base
# commit (`cargo build --locked --tests`) with the cargo registry/target cache
# warm, so an edited tree compiles offline. The behavioral verifier
# spawns the compiled `rtk` binary against a scratch directory, so there are no
# services to start and no data to seed here.

set -euo pipefail

cd /repo/rtk

# Offline-first build with a logged online fallback. The warm cache from the
# image makes this a near no-op; the single online retry only matters if the
# change added a dependency already present in the lockfile.
if cargo build --offline --tests > /tmp/rtk-build.log 2>&1; then
    echo "[test-setup] cargo build satisfied offline from the image cache"
else
    echo "[test-setup] offline build incomplete; retrying online once" >&2
    tail -40 /tmp/rtk-build.log >&2 || true
    cargo build --tests
fi

echo "[test-setup] rustc version:  $(rustc --version 2>&1 | head -1)"
echo "[test-setup] cargo version:  $(cargo --version 2>&1 | head -1)"
echo "[test-setup] system ls:      $(ls --version 2>&1 | head -1)"
echo "[test-setup] repo root:      /repo/rtk"
echo "[test-setup] Setup complete."
