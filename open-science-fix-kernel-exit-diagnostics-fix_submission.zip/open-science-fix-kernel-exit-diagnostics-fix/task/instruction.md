## Task

open-science is an Electron desktop app whose notebook feature runs user code in
persistent language kernels, long-lived interpreter subprocesses. With the
protected network sandbox active, each kernel is wrapped by a process sandbox.

Users report that notebook kernels sometimes die the instant they start, most
often when the notebook's working directory is on a non-system drive with the
sandbox active. All the interface shows is "Notebook kernel process exited.", no
exit code and nothing from the interpreter's error output, so there is no telling
whether the interpreter crashed, was missing, or the sandbox blocked it.
A flakier report too: a kernel that has clearly died stays registered as alive,
so the cell never settles and the notebook hangs instead of failing.

Dig in and fix it. When a kernel dies at startup, the surfaced failure should
carry enough to diagnose it, the exit status and the interpreter's error output,
not the bare message. And a dead kernel must not leave the notebook hanging: the
run should settle as a failure promptly, even when something it left behind holds
resources open.
