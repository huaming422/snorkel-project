#!/usr/bin/env bash
#
# Sourced by the validation orchestrator after tests/test-setup.sh, before any
# story's `go test` runs. Re-asserts the Go runtime defensively and warms the
# module cache from the image bake. Idempotent: safe to source repeatedly.
# Offline-first — the story phase runs with the network cut, so resolve from the
# baked closure and only fall back online when the cache was wiped.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/GoModel}"
cd "$REPO_DIR"

# internal/server and internal/core are pure Go; CGO is not required. Pin the
# toolchain to the one installed in the image and read modules from the vendored
# closure only.
export GOTOOLCHAIN=local
export GOFLAGS=-mod=mod
export GOPROXY=off

# Make `go` reachable even if the surrounding environment scrubbed PATH.
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:/root/go/bin:$PATH ;;
esac

# Prefer the warm module cache baked at the base commit (offline); only reach the
# network, with the restriction lifted, if that layer was wiped.
if GOPROXY=off go mod download >/tmp/validation-setup-offline.log 2>&1; then
    echo "[offline-first] go modules satisfied from image bake"
elif GOPROXY= go mod download >>/tmp/validation-setup-offline.log 2>&1; then
    echo "[validation-setup] go modules downloaded online (image bake was stale)"
else
    tail -40 /tmp/validation-setup-offline.log >&2
    exit 1
fi

echo "validation-setup.sh: ready (GOTOOLCHAIN=$GOTOOLCHAIN, GOFLAGS=$GOFLAGS, GOPROXY=$GOPROXY)"
