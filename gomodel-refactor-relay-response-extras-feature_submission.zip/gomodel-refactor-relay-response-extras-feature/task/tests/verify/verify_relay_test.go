// Behavioral checks for the gateway's non-streaming chat completions
// endpoint, driven end to end through the real routed HTTP server against a
// stub upstream. These exercise the observable wire contract only: each test
// POSTs to /v1/chat/completions, lets the gateway route to a real
// OpenAI-compatible provider adapter pointed at an httptest upstream, and
// inspects the JSON the client receives. Nothing here imports any
// member/type/method the change introduces, so any capture mechanism (a side
// field on the typed response, a raw-member map, capture inside the provider
// adapter, or renamed identifiers) is accepted as long as the members the
// gateway does not model come back to the caller.
//
// The provider is registered under a type that is NOT eligible for the
// non-streaming passthrough shortcut, so every request is served through the
// translated path regardless of whether that shortcut still exists — which is
// exactly where the relay must take effect.
package server_test

import (
	"bytes"
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/enterpilot/gomodel/internal/llmclient"
	"github.com/enterpilot/gomodel/internal/providers"
	"github.com/enterpilot/gomodel/internal/providers/groq"
	"github.com/enterpilot/gomodel/internal/server"
)

// probeModel is a real Groq catalog id used purely as request/catalog input.
const probeModel = "llama-3.1-8b-instant"

// chatRequestBody is the minimal well-formed chat request shape clients send.
func chatRequestBody(model string) string {
	return `{"model":"` + model + `","messages":[{"role":"user","content":"Hi"}]}`
}

// newRelayServer wires a server the way production does — a real model
// registry + router in front of a real Groq (OpenAI-compatible) adapter whose
// transport is pointed at the supplied upstream. The upstream answers the
// model-listing probe so registry initialization succeeds, and returns
// chatStatus + chatBody for a chat completion call. Groq's provider type is
// outside the set eligible for the non-streaming passthrough shortcut, so the
// request is served through the translated path.
func newRelayServer(t *testing.T, chatStatus int, chatBody string) *server.Server {
	t.Helper()

	upstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		if strings.HasSuffix(r.URL.Path, "/models") {
			_, _ = io.WriteString(w, `{"object":"list","data":[{"id":"`+probeModel+`","object":"model","owned_by":"groq"}]}`)
			return
		}
		_, _ = io.Copy(io.Discard, r.Body)
		w.WriteHeader(chatStatus)
		_, _ = io.WriteString(w, chatBody)
	}))
	t.Cleanup(upstream.Close)

	provider := groq.NewWithHTTPClient("test-key", upstream.Client(), llmclient.Hooks{})
	provider.SetBaseURL(upstream.URL)

	registry := providers.NewModelRegistry()
	registry.RegisterProviderWithNameAndType(provider, "groq", "groq")
	if err := registry.Initialize(context.Background()); err != nil {
		t.Fatalf("registry initialize: %v", err)
	}

	router, err := providers.NewRouter(registry)
	if err != nil {
		t.Fatalf("new router: %v", err)
	}

	return server.New(router, &server.Config{LogOnlyModelInteractions: true})
}

// postChat drives one chat completion through the routed server and returns the
// recorder.
func postChat(t *testing.T, srv *server.Server, body string) *httptest.ResponseRecorder {
	t.Helper()
	req := httptest.NewRequest(http.MethodPost, "/v1/chat/completions", bytes.NewReader([]byte(body)))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	srv.ServeHTTP(rec, req)
	return rec
}

// decodeObject parses a JSON object, failing the test on malformed output.
func decodeObject(t *testing.T, raw []byte) map[string]json.RawMessage {
	t.Helper()
	var obj map[string]json.RawMessage
	if err := json.Unmarshal(raw, &obj); err != nil {
		t.Fatalf("response body is not a JSON object: %v\nbody=%s", err, string(raw))
	}
	return obj
}

// TestChatCompletionRelaysProviderResponseExtras is the central check: members
// the gateway does not model, at BOTH the top level and inside a choice, reach
// the client; meanwhile the member the gateway does model (provider) keeps the
// gateway's own value over the one the upstream echoed, and the modeled typed
// fields (a choice's finish_reason and the usage totals) survive.
func TestChatCompletionRelaysProviderResponseExtras(t *testing.T) {
	// Upstream reply carries: a top-level member the gateway does not model
	// (citations), a per-choice member it does not model (native_finish_reason),
	// a provider value that disagrees with the one the gateway stamps, and the
	// ordinary modeled fields.
	upstreamBody := `{` +
		`"id":"chatcmpl-extras",` +
		`"object":"chat.completion",` +
		`"model":"` + probeModel + `",` +
		`"provider":"upstream-echoed-value",` +
		`"citations":["https://example.com/a","https://example.com/b"],` +
		`"choices":[{"index":0,"finish_reason":"stop","native_finish_reason":"end_turn",` +
		`"message":{"role":"assistant","content":"Hello!"}}],` +
		`"usage":{"prompt_tokens":5,"completion_tokens":2,"total_tokens":7}` +
		`}`

	srv := newRelayServer(t, http.StatusOK, upstreamBody)
	rec := postChat(t, srv, chatRequestBody(probeModel))

	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, want %d\nbody=%s", rec.Code, http.StatusOK, rec.Body.String())
	}

	top := decodeObject(t, rec.Body.Bytes())

	// Top-level unmodeled member relayed verbatim.
	rawCitations, ok := top["citations"]
	if !ok {
		t.Fatalf("top-level unmodeled member citations missing from client response\nbody=%s", rec.Body.String())
	}
	var citations []string
	if err := json.Unmarshal(rawCitations, &citations); err != nil {
		t.Fatalf("citations not an array of strings: %v", err)
	}
	wantCitations := []string{"https://example.com/a", "https://example.com/b"}
	if len(citations) != len(wantCitations) {
		t.Fatalf("citations = %v, want %v", citations, wantCitations)
	}
	for i := range wantCitations {
		if citations[i] != wantCitations[i] {
			t.Fatalf("citations[%d] = %q, want %q", i, citations[i], wantCitations[i])
		}
	}

	// Modeled member stays authoritative: the gateway-stamped provider wins over
	// the value the upstream echoed under the same key.
	var provider string
	if err := json.Unmarshal(top["provider"], &provider); err != nil {
		t.Fatalf("provider not a string: %v", err)
	}
	if provider == "upstream-echoed-value" {
		t.Fatalf("provider = %q, but the gateway's own value must win over the upstream echo", provider)
	}
	if provider != "groq" {
		t.Fatalf("provider = %q, want the gateway-stamped %q", provider, "groq")
	}

	// Per-choice: unmodeled member relayed, modeled typed fields intact.
	var choices []map[string]json.RawMessage
	if err := json.Unmarshal(top["choices"], &choices); err != nil {
		t.Fatalf("choices not an array of objects: %v", err)
	}
	if len(choices) != 1 {
		t.Fatalf("len(choices) = %d, want 1", len(choices))
	}
	ch := choices[0]

	rawNative, ok := ch["native_finish_reason"]
	if !ok {
		t.Fatalf("per-choice unmodeled member native_finish_reason missing from client response\nbody=%s", rec.Body.String())
	}
	var native string
	if err := json.Unmarshal(rawNative, &native); err != nil {
		t.Fatalf("native_finish_reason not a string: %v", err)
	}
	if native != "end_turn" {
		t.Fatalf("native_finish_reason = %q, want %q", native, "end_turn")
	}

	var finish string
	if err := json.Unmarshal(ch["finish_reason"], &finish); err != nil {
		t.Fatalf("finish_reason not a string: %v", err)
	}
	if finish != "stop" {
		t.Fatalf("finish_reason = %q, want %q (modeled typed field must survive)", finish, "stop")
	}

	var usage struct {
		PromptTokens     int `json:"prompt_tokens"`
		CompletionTokens int `json:"completion_tokens"`
		TotalTokens      int `json:"total_tokens"`
	}
	if err := json.Unmarshal(top["usage"], &usage); err != nil {
		t.Fatalf("usage not an object: %v", err)
	}
	if usage.TotalTokens != 7 || usage.PromptTokens != 5 || usage.CompletionTokens != 2 {
		t.Fatalf("usage = %+v, want prompt=5 completion=2 total=7 (modeled totals must survive)", usage)
	}
}

// knownTopKeys and knownChoiceKeys are the members the gateway models on the
// response and on a choice. Declaring them lets the clean-response check assert
// "no members beyond the modeled set appear" without naming any new member.
var knownTopKeys = map[string]bool{
	"id": true, "object": true, "model": true, "provider": true,
	"system_fingerprint": true, "choices": true, "usage": true, "created": true,
}

var knownChoiceKeys = map[string]bool{
	"message": true, "finish_reason": true, "index": true,
	"logprobs": true, "stop_sequence": true,
}

// TestChatCompletionCleanResponseHasNoUnmodeledKeys confirms that when the
// upstream reply carries no members beyond the modeled ones, the client sees a
// response with no stray keys added, and the ordinary modeled fields are
// returned for a plain bare-model request through the translated path.
func TestChatCompletionCleanResponseHasNoUnmodeledKeys(t *testing.T) {
	upstreamBody := `{` +
		`"id":"chatcmpl-clean",` +
		`"object":"chat.completion",` +
		`"model":"` + probeModel + `",` +
		`"choices":[{"index":0,"finish_reason":"stop",` +
		`"message":{"role":"assistant","content":"Hi there"}}],` +
		`"usage":{"prompt_tokens":3,"completion_tokens":2,"total_tokens":5}` +
		`}`

	srv := newRelayServer(t, http.StatusOK, upstreamBody)
	rec := postChat(t, srv, chatRequestBody(probeModel))

	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, want %d\nbody=%s", rec.Code, http.StatusOK, rec.Body.String())
	}

	top := decodeObject(t, rec.Body.Bytes())
	for k := range top {
		if !knownTopKeys[k] {
			t.Fatalf("unexpected top-level member %q in a response with no extras\nbody=%s", k, rec.Body.String())
		}
	}

	// Modeled fields present.
	for _, k := range []string{"id", "model", "choices", "usage"} {
		if _, ok := top[k]; !ok {
			t.Fatalf("modeled field %q missing\nbody=%s", k, rec.Body.String())
		}
	}

	var choices []map[string]json.RawMessage
	if err := json.Unmarshal(top["choices"], &choices); err != nil {
		t.Fatalf("choices not an array: %v", err)
	}
	if len(choices) != 1 {
		t.Fatalf("len(choices) = %d, want 1", len(choices))
	}
	for k := range choices[0] {
		if !knownChoiceKeys[k] {
			t.Fatalf("unexpected per-choice member %q in a response with no extras\nbody=%s", k, rec.Body.String())
		}
	}
	var msg struct {
		Content string `json:"content"`
	}
	if err := json.Unmarshal(choices[0]["message"], &msg); err != nil {
		t.Fatalf("message not an object: %v", err)
	}
	if msg.Content != "Hi there" {
		t.Fatalf("message content = %q, want %q", msg.Content, "Hi there")
	}
}

// TestChatCompletionToleratesNullUsageAndNullChoice confirms the response
// decoder treats a null usage block and a null choice entry as empty rather
// than erroring: the request still completes with HTTP 200 and the modeled id
// survives. A capture mechanism that mishandles JSON null would turn these into
// a decode error and a non-200 reply.
func TestChatCompletionToleratesNullUsageAndNullChoice(t *testing.T) {
	upstreamBody := `{"id":"chatcmpl-null","object":"chat.completion","model":"` + probeModel + `","choices":[null],"usage":null}`

	srv := newRelayServer(t, http.StatusOK, upstreamBody)
	rec := postChat(t, srv, chatRequestBody(probeModel))

	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, want %d for null usage / null choice entry\nbody=%s", rec.Code, http.StatusOK, rec.Body.String())
	}

	top := decodeObject(t, rec.Body.Bytes())
	var id string
	if err := json.Unmarshal(top["id"], &id); err != nil {
		t.Fatalf("id not a string: %v", err)
	}
	if id != "chatcmpl-null" {
		t.Fatalf("id = %q, want %q", id, "chatcmpl-null")
	}
}

// TestChatCompletionRejectsMalformedUpstreamBody confirms that genuinely
// malformed upstream JSON still surfaces as an error (a non-2xx reply) rather
// than being swallowed into a bogus success. The null-tolerance handling must
// not suppress real decode failures.
func TestChatCompletionRejectsMalformedUpstreamBody(t *testing.T) {
	// Truncated JSON object: a real decode failure, not an absent/null value.
	upstreamBody := `{"id":"chatcmpl-bad","object":"chat.completion","choices":`

	srv := newRelayServer(t, http.StatusOK, upstreamBody)
	rec := postChat(t, srv, chatRequestBody(probeModel))

	if rec.Code == http.StatusOK {
		t.Fatalf("status = %d, want a non-200 error for malformed upstream JSON\nbody=%s", rec.Code, rec.Body.String())
	}
}
