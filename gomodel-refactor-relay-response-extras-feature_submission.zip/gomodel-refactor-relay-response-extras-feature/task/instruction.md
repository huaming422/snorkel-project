## Task

GoModel's chat completions endpoint decodes each upstream reply onto the shape we model and re-encodes it, and along the way it quietly drops any response members we don't have a field for. We want those unmodeled members relayed back to the client instead, both the ones that sit at the top level of the response and the ones inside each choice, so a caller sees what the provider actually returned. The fields we do model stay authoritative: where we set a value for ourselves, like the provider name we stamp onto the reply, our value wins over whatever the upstream echoed under the same key. While you're in here, retire the non-streaming passthrough shortcut that sends a narrow class of requests straight to the client without translation, so every chat completion goes through the normal translated path.

## User stories / requirements

- When an upstream provider returns members the gateway doesn't model, both at the top level and inside a choice, those members come back to the client. The gateway-stamped provider name wins over any upstream echo, modeled fields like finish reason and usage totals stay intact, and a reply with no extras gains no stray keys.
- A chat completion returns a correct successful response whether the client selects a model by bare name, by an alias, or by a provider-qualified `provider/model` selector, now that the passthrough shortcut is gone. Each reply carries its id, model, a choice with message content, and usage.
