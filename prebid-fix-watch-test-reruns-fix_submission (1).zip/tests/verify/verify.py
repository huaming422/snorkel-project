"""Behavioral verification through the actual watch command and task execution."""
import json
import os
from pathlib import Path
import subprocess
import pytest
from watch_probe import observe

ROOT = Path('/repo/' + os.environ.get('REPO_NAME', 'Prebid.js'))
HERE = Path(__file__).resolve().parent

@pytest.fixture(scope='session', params=['selected', 'suite'])
def watch_result(request):
    return observe(request.param)

def check_run(rows, prefix, value, creative, success, count):
    assert len(rows) == 1, 'Expected one execution, observed: ' + json.dumps(rows)
    row = rows[0]
    expected = [{'description': prefix + str(i) + '-' + str(value) + '-' + str(creative), 'success': success} for i in range(count)]
    assert sorted(row['specs'], key=lambda x:x['description']) == expected, json.dumps(row)
    result = row['results']
    assert not result.get('error') and not result.get('disconnected'), json.dumps(row)
    assert result.get('failed') == (0 if success else count), json.dumps(row)
    assert result.get('success') == (count if success else 0), json.dumps(row)

def test_clean_start_executes_current_source(watch_result):
    initial = watch_result['initial']
    assert not initial['error'], initial
    # One run per save is the contract; startup may perform additional valid runs.
    assert initial['runs'], 'No initial browser execution'
    for run in initial['runs']:
        check_run([run], watch_result['prefix'], 101, 101, True, watch_result['spec_count'])

@pytest.mark.parametrize('index,value,creative', [(0,202,101),(1,303,101),(2,42,101),(3,404,101),(4,404,202),(5,404,42),(6,404,303)],
                         ids=['first-save','later-save','failing-source','recovery-save','creative-save','creative-failure','creative-recovery'])
def test_watch_runs_once_with_current_source(watch_result, index, value, creative):
    assert len(watch_result['phases']) > index, json.dumps(watch_result)
    phase = watch_result['phases'][index]
    assert not phase['error'], phase
    check_run(phase['runs'], watch_result['prefix'], value, creative, value >= 100 and creative >= 100, watch_result['spec_count'])

@pytest.mark.parametrize('scenario', [
    {'name':'selected-pass','file':'test/spec/ajax_spec.js'},
    {'name':'selected-build-fails','file':'test/spec/ajax_spec.js','buildExit':23},
    {'name':'full-pass'},
    {'name':'full-build-fails','buildExit':23},
    {'name':'full-karma-fails','karmaExit':17},
    {'name':'full-precompile-fails','precompileFails':True},
    {'name':'selected-karma-fails','file':'test/spec/ajax_spec.js','karmaExit':17},
    {'name':'selected-precompile-fails','file':'test/spec/ajax_spec.js','precompileFails':True},
], ids=lambda case:case['name'])
def test_test_only_execution(scenario):
    script = "const p=require(process.argv[1]);const s=JSON.parse(process.argv[3]);const r=p.runCase(process.argv[2],s);console.log(JSON.stringify(r));p.check(r,s)"
    run = subprocess.run(['node','-e',script,str(HERE/'task-invocation-probe.cjs'),str(ROOT),json.dumps(scenario)],
        capture_output=True,text=True,cwd=ROOT,timeout=60)
    assert run.returncode == 0, run.stdout + '\n' + run.stderr


def test_full_run_preserves_nondev_compilation_and_declarations():
    run = subprocess.run(['node', str(HERE/'task-invocation-probe.cjs'), '--full-build', str(ROOT)],
        capture_output=True, text=True, cwd=ROOT, timeout=240)
    output = Path('/logs/verifier/full-nondev-build.log')
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(run.stdout + '\n' + run.stderr)
    assert run.returncode == 0, run.stdout + '\n' + run.stderr
