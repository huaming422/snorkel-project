"""Behavioral verification through the actual watch command and task execution."""
import json
import os
from pathlib import Path
import subprocess
import pytest
from watch_probe import observe

ROOT = Path('/repo/' + os.environ.get('REPO_NAME', 'Prebid.js'))
HERE = Path(__file__).resolve().parent

@pytest.fixture(scope='session')
def watch_result():
    return observe()

def check_run(rows, prefix, value, success):
    assert len(rows) == 1, 'Expected one execution, observed: ' + json.dumps(rows)
    row = rows[0]
    assert row['specs'] == [{'description': prefix + str(value), 'success': success}], json.dumps(row)
    result = row['results']
    assert not result.get('error') and not result.get('disconnected'), json.dumps(row)
    assert result.get('failed') == (0 if success else 1), json.dumps(row)
    assert result.get('success') == (1 if success else 0), json.dumps(row)

def test_clean_start_executes_current_source(watch_result):
    initial = watch_result['initial']
    assert not initial['error'], initial
    check_run(initial['runs'], watch_result['prefix'], 101, True)

@pytest.mark.parametrize('index,value', [(0,202),(1,303),(2,42),(3,404)],
                         ids=['first-save','later-save','failing-source','recovery-save'])
def test_watch_runs_once_with_current_source(watch_result, index, value):
    assert len(watch_result['phases']) > index, json.dumps(watch_result)
    phase = watch_result['phases'][index]
    assert not phase['error'], phase
    check_run(phase['runs'], watch_result['prefix'], value, value >= 100)

@pytest.mark.parametrize('scenario', [
    {'name':'selected-pass','file':'test/spec/ajax_spec.js'},
    {'name':'selected-build-fails','file':'test/spec/ajax_spec.js','buildExit':23},
    {'name':'full-pass'},
    {'name':'full-build-fails','buildExit':23},
    {'name':'selected-karma-fails','file':'test/spec/ajax_spec.js','karmaExit':17},
    {'name':'selected-precompile-fails','file':'test/spec/ajax_spec.js','precompileFails':True},
], ids=lambda case:case['name'])
def test_test_only_execution(scenario):
    script = "const p=require(process.argv[1]);const s=JSON.parse(process.argv[3]);const r=p.runCase(process.argv[2],s);console.log(JSON.stringify(r));p.check(r,s)"
    run = subprocess.run(['node','-e',script,str(HERE/'task-invocation-probe.cjs'),str(ROOT),json.dumps(scenario)],
        capture_output=True,text=True,cwd=ROOT,timeout=40)
    assert run.returncode == 0, run.stdout + '\n' + run.stderr
