// Record browser runs and compiler activity without changing watch configuration.
const Module = require('module');
const fs = require('fs');
const original = Module._load;
const wrappers = new WeakMap();
let compilerNumber = 0;
function emit(row) {
  fs.appendFileSync(process.env.SUITE_WATCH_EVENTS, JSON.stringify({time:Date.now(), pid:process.pid, ...row}) + '\n');
}
function observeCompiler(compiler) {
  if (compiler.compilers) { compiler.compilers.forEach(observeCompiler); return; }
  const id = process.pid + ':' + (++compilerNumber);
  for (const [hook, kind] of [['invalid','invalid'], ['watchRun','compile-start'], ['run','compile-start'], ['done','compile-done'], ['failed','compile-failed']]) {
    if (compiler.hooks && compiler.hooks[hook]) compiler.hooks[hook].tap('WatchObservation', () => emit({kind, compiler:id}));
  }
}
Module._load = function(name, parent, main) {
  const result = original.apply(this, arguments);
  if (name === 'webpack' && typeof result === 'function') {
    if (!wrappers.has(result)) wrappers.set(result, new Proxy(result, {
      apply(target, receiver, args) {
        const compiler = Reflect.apply(target, receiver, args);
        observeCompiler(compiler);
        return compiler;
      }
    }));
    return wrappers.get(result);
  }
  if (name === 'karma' && !result.__suiteObserver) {
    const Server = result.Server;
    result.Server = class extends Server {
      constructor(config, done) {
        function Observer() {
          // Server run events can be nested when Karma schedules another run.
          // Observe actual browser execution so scheduling never loses results.
          const specs = new Map();
          this.onBrowserStart = browser => {
            specs.set(browser.id, []);
            emit({kind:'run-start', browser:browser.id});
          };
          this.onSpecComplete = (browser, spec) => {
            if (!specs.has(browser.id)) specs.set(browser.id, []);
            specs.get(browser.id).push({description:spec.description, success:spec.success});
          };
          this.onBrowserComplete = browser => {
            emit({kind:'run-complete', browser:browser.id,
              specs:specs.get(browser.id) || [], results:{...browser.lastResult}});
            specs.delete(browser.id);
          };
        }
        Observer.$inject = [];
        config.plugins = [...config.plugins, {'reporter:suiteObserver':['type',Observer]}];
        config.reporters = [...config.reporters, 'suiteObserver'];
        super(config, done);
      }
    };
    result.__suiteObserver = true;
  }
  return result;
};
