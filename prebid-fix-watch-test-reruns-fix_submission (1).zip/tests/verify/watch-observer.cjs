// Observe actual Karma runs without changing the watcher or compiler configuration.
const Module = require('module');
const fs = require('fs');
const original = Module._load;
Module._load = function(name, parent, main) {
  const result = original.apply(this, arguments);
  if (name === 'karma' && !result.__suiteObserver) {
    const Server = result.Server;
    result.Server = class extends Server {
      constructor(config, done) {
        function Observer() {
          let specs = [];
          this.onRunStart = () => { specs = []; };
          this.onSpecComplete = (browser, spec) => { specs.push({description:spec.description, success:spec.success}); };
          this.onRunComplete = (browsers, results) => fs.appendFileSync(process.env.SUITE_WATCH_EVENTS, JSON.stringify({time:Date.now(), specs, results}) + '\n');
        }
        Observer.$inject = [];
        config.plugins = [...config.plugins, {'reporter:suiteObserver':['type',Observer]}];
        config.reporters = [...config.reporters, 'suiteObserver'];
        super(config, done);
      }
    };
    result.__suiteObserver = true;
  }
  return result;
};
