"""Observe real serve-and-test executions after isolated source saves."""
from pathlib import Path
import json, os, signal, subprocess, time, uuid

ROOT = Path('/repo/' + os.environ.get('REPO_NAME', 'Prebid.js'))

def observe():
    output = Path('/logs/verifier/watch')
    output.mkdir(parents=True, exist_ok=True)
    events = output / 'events.jsonl'
    events.unlink(missing_ok=True)
    suffix = uuid.uuid4().hex[:10]
    name = 'suiteLifeWatch' + suffix
    source = ROOT / ('src/' + name + '.js')
    spec = ROOT / ('test/spec/' + name + '_spec.js')
    prefix = 'observed-' + suffix + '-'
    source.write_text('export const value = 101;\n')
    spec.write_text("import {value} from '../../src/" + name + ".js';\n" +
        "describe('watch behavior', function(){it('" + prefix + "'+value,function(){if(value < 100) throw new Error('source test failure');});});\n")
    env = dict(os.environ, SUITE_WATCH_EVENTS=str(events),
        NODE_OPTIONS='--require=' + str(Path(__file__).with_name('watch-observer.cjs')), TEST_CHUNKS='1')
    logfile = (output / 'gulp.log').open('w')
    process = subprocess.Popen(['node', 'node_modules/gulp/bin/gulp.js', 'serve-and-test',
        '--file', str(spec.relative_to(ROOT)), '--modules='], cwd=ROOT, env=env,
        stdout=logfile, stderr=subprocess.STDOUT, start_new_session=True)
    def read():
        if not events.exists(): return []
        lines = events.read_text().splitlines()
        result = []
        for line in lines:
            try: result.append(json.loads(line))
            except json.JSONDecodeError: pass  # a final append may still be in progress
        return result
    def settle(minimum, timeout):
        start = time.monotonic(); changed = start; previous = None
        while time.monotonic() - start < timeout:
            rows = read()
            if len(rows) != previous:
                previous = len(rows); changed = time.monotonic()
            if len(rows) >= minimum and time.monotonic() - changed >= 7:
                return rows, None
            if process.poll() is not None:
                return rows, 'serve-and-test exited with ' + str(process.returncode)
            time.sleep(0.2)
        return read(), 'No settled browser test execution before timeout'
    report = {'prefix': prefix, 'phases': []}
    try:
        rows, error = settle(1, 300)
        report['initial'] = {'runs': rows, 'error': error}
        if not rows or error: return report
        for value in [202, 303, 42, 404]:
            start = len(read())
            source.write_text('export const value = ' + str(value) + ';\n')
            rows, error = settle(start + 1, 60)
            report['phases'].append({'value': value, 'runs': rows[start:], 'error': error})
            if error: break
        return report
    finally:
        if process.poll() is None:
            os.killpg(process.pid, signal.SIGTERM)
            try: process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL); process.wait()
        logfile.close()
        source.unlink(missing_ok=True); spec.unlink(missing_ok=True)
        (output / 'observation.json').write_text(json.dumps(report, indent=2) + '\n')
