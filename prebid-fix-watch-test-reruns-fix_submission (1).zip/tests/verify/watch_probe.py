"""Exercise selected-spec and unselected-suite watch paths in a real browser."""
from pathlib import Path
import json, os, signal, subprocess, time, uuid

ROOT = Path('/repo/' + os.environ.get('REPO_NAME', 'Prebid.js'))
INITIAL_TIMEOUT = 600
SAVE_TIMEOUT = 240
QUIET_SECONDS = 15


def observe(mode):
    output = Path('/logs/verifier/watch') / mode
    output.mkdir(parents=True, exist_ok=True)
    events = output / 'events.jsonl'
    events.unlink(missing_ok=True)
    suffix = uuid.uuid4().hex[:10]
    name = 'watchFixture' + suffix
    source = ROOT / ('src/' + name + '.js')
    specs = [ROOT / ('test/spec/' + name + tag + '_spec.js') for tag in ['A', 'B']]
    prefix = 'observed-' + suffix + '-'
    source.write_text('export const value = 101;\n')
    renderer = ROOT / 'creative/renderers/display/renderer.js'
    renderer_original = renderer.read_text()
    renderer_key = 'watchRenderer' + suffix
    def write_renderer(value):
        renderer.write_text(renderer_original + '\nwindow[' + json.dumps(renderer_key) + '] = ' + str(value) + ';\n')
    write_renderer(101)
    for index, spec in enumerate(specs):
        spec.write_text("import {value} from '../../src/" + name + ".js';\n" +
            "import {RENDERER} from '../../creative-renderers/display.js';\n" +
            "new Function(RENDERER)(); const creative = window[" + json.dumps(renderer_key) + "];\n" +
            "describe('watch behavior', function(){it('" + prefix + str(index) + "-'+value+'-'+creative,function(){if(value < 100 || creative < 100) throw new Error('edited behavior failure');});});\n")
    env = dict(os.environ, SUITE_WATCH_EVENTS=str(events),
        NODE_OPTIONS='--max-old-space-size=4096 --require=' + str(Path(__file__).with_name('watch-observer.cjs')),
        TEST_CHUNKS='1')
    # TEST_PAT is the repository's supported suite filter. No --file is passed
    # for suite mode: collection includes two specs and uses the full-suite path.
    env['TEST_PAT'] = name + '*_spec.js'
    cmd = ['node', 'node_modules/gulp/bin/gulp.js', 'serve-and-test', '--modules=']
    if mode == 'selected': cmd.extend(['--file', str(specs[0].relative_to(ROOT))])
    logfile = (output / 'gulp.log').open('w')
    began = time.monotonic()
    process = subprocess.Popen(cmd, cwd=ROOT, env=env, stdout=logfile,
                               stderr=subprocess.STDOUT, start_new_session=True)
    def read():
        if not events.exists(): return []
        rows = []
        for line in events.read_text().splitlines():
            try: rows.append(json.loads(line))
            except json.JSONDecodeError: pass
        return rows

    def settle(offset, timeout):
        started = time.monotonic(); last_activity = started; previous = 0
        while time.monotonic() - started < timeout:
            rows = read()[offset:]
            if len(rows) != previous:
                previous = len(rows); last_activity = time.monotonic()
            active = set(); browsers = set()
            for row in rows:
                kind = row.get('kind')
                if kind == 'compile-start': active.add(row['compiler'])
                elif kind in ('compile-done', 'compile-failed'): active.discard(row['compiler'])
                elif kind == 'run-start': browsers.add((row['pid'], row['browser']))
                elif kind == 'run-complete': browsers.discard((row['pid'], row['browser']))
            runs = [r for r in rows if r.get('kind') == 'run-complete']
            quiet = time.monotonic() - last_activity
            if runs and not active and not browsers and quiet >= QUIET_SECONDS:
                return {'runs':runs, 'error':None, 'elapsed_seconds':round(time.monotonic()-started,3),
                        'quiet_seconds':round(quiet,3), 'events':len(rows)}
            if process.poll() is not None:
                error = 'watch command exited with ' + str(process.returncode)
                break
            time.sleep(0.2)
        else:
            error = 'observation deadline reached; inspect phase progress and gulp.log before attributing this to the implementation'
        return {'runs':runs, 'error':error, 'elapsed_seconds':round(time.monotonic()-started,3),
                'quiet_seconds':round(quiet,3), 'events':len(rows),
                'active_compilers':sorted(active), 'active_browser_runs':sorted(browsers),
                'last_events':rows[-12:]}

    report = {'mode':mode, 'prefix':prefix, 'spec_count':1 if mode=='selected' else 2,
              'command':cmd, 'test_pattern':env['TEST_PAT'], 'phases':[],
              'limits':{'initial':INITIAL_TIMEOUT,'save':SAVE_TIMEOUT,'quiet':QUIET_SECONDS}}
    try:
        report['initial'] = settle(0, INITIAL_TIMEOUT)
        if report['initial']['error']: return report
        for kind, value, source_value, creative_value in [('source',202,202,101), ('source',303,303,101), ('source',42,42,101), ('source',404,404,101), ('creative',202,404,202), ('creative',42,404,42), ('creative',303,404,303)]:
            offset = len(read())
            if kind == 'source':
                source.write_text('export const value = ' + str(value) + ';\n')
            else:
                write_renderer(value)
            phase = settle(offset, SAVE_TIMEOUT)
            phase.update(kind=kind, value=value, source_value=source_value, creative_value=creative_value)
            compiled = ROOT / ('dist/src/src/' + name + '.js')
            phase['compiled_fixture_exists'] = compiled.exists()
            phase['compiled_fixture_has_value'] = compiled.exists() and str(value) in compiled.read_text()
            report['phases'].append(phase)
            if phase['error']: break
        return report
    finally:
        if process.poll() is None:
            os.killpg(process.pid, signal.SIGTERM)
            try: process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid,signal.SIGKILL); process.wait()
        logfile.close()
        source.unlink(missing_ok=True)
        renderer.write_text(renderer_original)
        for spec in specs: spec.unlink(missing_ok=True)
        report['elapsed_seconds'] = round(time.monotonic()-began,3)
        (output/'observation.json').write_text(json.dumps(report,indent=2)+'\n')
