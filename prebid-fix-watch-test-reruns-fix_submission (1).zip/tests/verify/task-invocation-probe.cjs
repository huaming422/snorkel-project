#!/usr/bin/env node
'use strict';

// Standalone verifier: no gulp.tree(), source-pattern correctness assertions,
// task replacement for test-only/build-logic, or real browser execution.
// runFullBuild additionally executes real non-development precompilation.
const assert = require('node:assert/strict');
const path = require('node:path');
const fs = require('node:fs');
const os = require('node:os');
const Module = require('node:module');
const CONTEXT = 'SUITE_INVOCATION_PROBE';
const {createRequire, syncBuiltinESMExports} = require('node:module');
const cp = require('node:child_process');
const {threadId} = require('node:worker_threads');
const {EventEmitter} = require('node:events');
const {PassThrough} = require('node:stream');
const MARKER = 'TASK_INVOCATION_RESULT=';
const FILE = 'test/spec/ajax_spec.js';
const CASES = [
  {name: 'selected-pass', file: FILE},
  {name: 'selected-build-fails', file: FILE, buildExit: 23},
  {name: 'full-pass'},
  {name: 'full-build-fails', buildExit: 23},
  {name: 'selected-karma-fails', file: FILE, karmaExit: 17},
  {name: 'selected-precompile-fails', file: FILE, precompileFails: true},
  {name: 'full-karma-fails', karmaExit: 17},
  {name: 'full-precompile-fails', precompileFails: true},
];

// Descendants execute their actual coordinator code. Every process writes to one
// ordered journal; a successful child exit alone is never evidence of test work.
function instrument(context) {
  const {root, scenario, journal} = context;
  const record = (kind, details = {}) => fs.appendFileSync(journal,
    JSON.stringify({kind, pid: process.pid, threadId, ancestors: context.ancestors || [], ...details}) + '\n');
  const original = Object.fromEntries(['spawn', 'fork', 'exec', 'execFile',
    'spawnSync', 'execSync', 'execFileSync'].map(key => [key, cp[key]]));

  // Keep installed execa 1.x and helpers.execaTask intact. Undertaker uses
  // end-of-stream to observe this child (stdio must contain three entries);
  // wrappers that return promises also retain Execa's real rejection logic.
  cp.spawn = (command, args = [], options = {}) => {
    if (!Array.isArray(args)) { options = args; args = []; }
    const invocation = [command, ...args].join(' ');
    // Match the executable/argument boundary, not words inside arbitrary code.
    const executable = path.basename(command);
    const shellMocha = ['sh', 'bash'].includes(executable) && args.length === 2 &&
      args[0] === '-c' && args[1] === 'npx mocha "./test/build-logic/**/*_spec.@(js|mjs)"';
    const mocha = executable === 'mocha' ||
      (executable === 'npx' && args[0] === 'mocha');
    if (!shellMocha && (!mocha || !args.some(arg => /(?:^|[\\/])test[\\/]build-logic[\\/]/.test(arg)))) {
      return coordinate('spawn', command, args, options);
    }
    record('build:start', {command: invocation});
    const child = new EventEmitter();
    Object.assign(child, {
      stdin: new PassThrough(), stdout: new PassThrough(), stderr: new PassThrough(),
      killed: false, exitCode: null, signalCode: null,
      kill() { this.killed = true; return true; },
    });
    child.stdio = [child.stdin, child.stdout, child.stderr];
    setImmediate(() => {
      const code = scenario.buildExit || 0;
      record('build:end', {code});
      child.exitCode = code;
      child.stdout.end();
      child.stderr.end();
      child.emit('exit', code, null);
      child.emit('close', code, null);
    });
    return child;
  };
  cp.fork = (modulePath, args = [], options = {}) => {
    if (!Array.isArray(args)) { options = args; args = []; }
    if (path.resolve(root, modulePath) !== path.join(root, 'karmaRunner.js')) {
      return coordinate('fork', modulePath, args, options);
    }
    record('karma:fork');
    const child = new EventEmitter();
    child.send = (options) => {
      record('karma:send', {options: JSON.parse(JSON.stringify(options))});
      setImmediate(() => {
        const code = scenario.karmaExit || 0;
        record('karma:end', {code});
        child.emit('exit', code, null);
        child.emit('close', code, null);
      });
      return true;
    };
    child.kill = () => true;
    return child;
  };
  let sequence = 0;
  function coordinate(method, command, args, options, callback) {
    const id = `${process.pid}:${threadId}:${++sequence}`;
    const childContext = {...context, ancestors: [...(context.ancestors || []), id]};
    const env = {...(options.env || process.env), [CONTEXT]: JSON.stringify(childContext)};
    const preload = `--require ${JSON.stringify(__filename)}`;
    // Place the probe first, including when the caller supplies a fresh env.
    env.NODE_OPTIONS = `${preload} ${env.NODE_OPTIONS || ''}`;
    const opts = {...options, env};
    record('coord:start', {id, method, command, args});
    // exec/execSync take a command string; execFile variants take an argv array.
    const callArgs = method === 'exec' || method === 'execSync' ?
      [command, opts] : [command, args, opts];
    if (method.endsWith('Sync')) {
      try {
        const result = original[method](...callArgs);
        record('coord:end', method === 'spawnSync' ? {
          id, childPid: result.pid, code: result.status,
          error: result.error?.message, signal: result.signal,
        } : {id, code: 0});
        return result;
      } catch (error) {
        record('coord:end', {id, childPid: error.pid, code: error.status ?? null,
          error: error.message, signal: error.signal});
        throw error; // Preserve Node's status, stdout/stderr, and throw semantics.
      }
    }
    // Node's exec delegates through exported execFile. Call the captured leaf
    // directly to avoid intercepting the same launch twice.
    const child = method === 'exec' ?
      original.execFile(command, [], {...opts, shell: opts.shell || true}, callback) :
      original[method](...callArgs, ...(callback ? [callback] : []));
    let ended = false;
    child.once('error', error => {
      record('coord:error', {id, message: error.message});
      if (!child.pid) {
        ended = true;
        record('coord:end', {id, code: null, error: error.message});
      }
    });
    // Exit precedes Gulp/execa completion callbacks and proves Node work settled.
    child.once('exit', (code, signal) => {
      if (!ended) record('coord:end', {id, childPid: child.pid, code, signal});
      ended = true;
    });
    return child;
  }
  cp.execFile = (command, args = [], options = {}, callback) => {
    if (typeof args === 'function') { callback = args; args = []; options = {}; }
    else if (!Array.isArray(args)) { callback = options; options = args; args = []; }
    if (typeof options === 'function') { callback = options; options = {}; }
    return coordinate('execFile', command, args, options, callback);
  };
  for (const method of ['spawnSync', 'execFileSync']) {
    cp[method] = (command, args = [], options = {}) => {
      if (!Array.isArray(args)) { options = args; args = []; }
      return coordinate(method, command, args, options);
    };
  }
  cp.exec = (command, options = {}, callback) => {
    if (typeof options === 'function') { callback = options; options = {}; }
    return coordinate('exec', command, [], options, callback);
  };
  cp.execSync = (command, options = {}) => coordinate('execSync', command, [], options);
  // Keep Node's promisified exec/execFile result shape and .child handle.
  for (const method of ['exec', 'execFile']) {
    cp[method][require('node:util').promisify.custom] = (...args) => {
      let child;
      const promise = new Promise((resolve, reject) => {
        child = cp[method](...args, (error, stdout, stderr) => {
          if (error) reject(Object.assign(error, {stdout, stderr}));
          else resolve({stdout, stderr});
        });
      });
      promise.child = child;
      return promise;
    };
  }
  syncBuiltinESMExports();
  // Lazy interception preserves the coordinator's own argv/setup before imports.
  // Do not replace any test-only or build-logic task registration.
  const originalLoad = Module._load;
  const precompilePath = path.join(root, 'gulp.precompilation.js');
  const patched = new WeakSet();
  Module._load = function(request, parent, isMain) {
    const exported = originalLoad.apply(this, arguments);
    if (Module._resolveFilename(request, parent) === precompilePath && !patched.has(exported)) {
      patched.add(exported);
      if (scenario.realPrecompile) {
        const gulp = createRequire(path.join(root, 'package.json'))('gulp');
        gulp.on('start', event => {
          if (event.name === 'precompile') record('precompile:start');
          if (['ts', 'ts-strict', 'check-declarations'].includes(event.name))
            record('real-task:start', {name: event.name});
        });
        gulp.on('stop', event => {
          if (event.name === 'precompile') record('precompile:end', {failed: false});
          if (['ts', 'ts-strict', 'check-declarations'].includes(event.name))
            record('real-task:end', {name: event.name});
        });
        gulp.on('error', event => {
          if (event.name === 'precompile') record('precompile:end', {failed: true});
        });
        return exported;
      }
      function fakePrecompile(done) {
        record('precompile:start');
        setImmediate(() => {
          record('precompile:end', {failed: !!scenario.precompileFails});
          done(scenario.precompileFails ? new Error('probe-precompile-failure') : undefined);
        });
      }
      exported.precompile = () => fakePrecompile;
      createRequire(path.join(root, 'package.json'))('gulp').task('precompile', fakePrecompile);
    }
    return exported;
  };
  record('process:ready');
  if (context.ancestors?.length) {
    process.once('exit', code => record('process:exit', {code}));
  }
  return {record, restore() {
    Module._load = originalLoad;
    Object.assign(cp, original);
    syncBuiltinESMExports();
  }};
}

async function worker(root, scenario) {
  process.chdir(root);
  process.argv = [process.execPath, path.join(root, 'node_modules/gulp/bin/gulp.js'),
    'test-only', ...(scenario.file ? ['--file', scenario.file] : [])];
  const req = createRequire(path.join(root, 'package.json'));
  const context = JSON.parse(process.env[CONTEXT]);
  const {record, restore} = instrument(context);
  let taskError = null;
  let taskErrorCode = null;
  let setupError = null;
  let gulp;
  const onGulpError = () => {}; // Undertaker emits errors as well as invoking callback.
  try {
    gulp = req('gulp');
    gulp.on('error', onGulpError);
    req('./gulpfile.js');
    await new Promise((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error('Task did not settle within probe budget')), scenario.realPrecompile ? 180000 : 10000);
      gulp.series('test-only')(err => {
        clearTimeout(timeout);
        taskError = err ? String(err.message || err) : null;
        taskErrorCode = err?.code ?? null;
        record('task:end', {error: taskError});
        resolve();
      });
    });
    // Allow pending stand-ins to reveal tasks that returned before completion.
    await new Promise(resolve => setImmediate(resolve));
  } catch (err) {
    setupError = err.stack || String(err);
  } finally {
    if (gulp) gulp.removeListener('error', onGulpError);
    restore();
  }
  return {scenario: scenario.name, taskError, taskErrorCode, setupError};
}

function check(result, scenario) {
  assert.equal(result.setupError, null, `Harness/import error: ${result.setupError}`);
  const events = result.events;
  // Shells and native helpers need not load JavaScript. They run for real, and
  // must settle. Required service traces still come from instrumented Node code;
  // neither a zero exit nor a ready-only child supplies missing test work.
  for (const event of events.filter(event => /^(build|precompile|karma):/.test(event.kind))) {
    assert.ok(events.some(ready => ready.kind === 'process:ready' && ready.pid === event.pid && ready.threadId === event.threadId),
      'service work must be observed in an instrumented process');
  }
  for (const ready of events.filter(event => event.kind === 'process:ready' && event.ancestors.length)) {
    const exits = events.filter(event => event.kind === 'process:exit' && event.pid === ready.pid && event.threadId === ready.threadId);
    assert.equal(exits.length, 1, 'instrumented descendant must finish');
    for (const id of ready.ancestors) {
      const end = events.find(event => event.kind === 'coord:end' && event.id === id);
      assert.ok(end && events.indexOf(exits[0]) < events.indexOf(end),
        'coordinator must await its instrumented descendants');
    }
  }
  for (const start of events.filter(event => event.kind === 'coord:start')) {
    const end = events.filter(event => event.kind === 'coord:end' && event.id === start.id);
    assert.equal(end.length, 1, 'coordinator must finish exactly once');
    // A coordinator may recover from an auxiliary command failure. Genuine
    // build/precompile/Karma failures are asserted below from service events.
  }
  const count = kind => events.filter(event => event.kind === kind).length;
  const index = kind => events.findIndex(event => event.kind === kind);
  const before = (a, b) => assert.ok(index(a) >= 0 && index(a) < index(b), `${a} must complete before ${b}`);
  assert.equal(count('task:end'), 1, 'actual task must settle once');
  assert.equal(events.at(-1).kind, 'task:end', 'task must await all invoked work');
  if (scenario.file) {
    assert.equal(count('build:start'), 0, '--file must not invoke build-logic, even if it would fail');
  } else {
    assert.equal(count('build:start'), 1, 'full invocation must run build-logic');
    assert.equal(count('build:end'), 1);
  }
  if (!scenario.file && scenario.buildExit) {
    assert.ok(result.taskError, 'build failure must propagate through Gulp');
    assert.equal(events.find(event => event.kind === 'build:end').code, 23);
    assert.equal(count('karma:fork'), 0, 'build failure must stop browser tests');
    return;
  }
  assert.equal(count('precompile:start'), 1, 'precompile must execute');
  assert.equal(count('precompile:end'), 1);
  before('precompile:start', 'precompile:end');
  if (scenario.precompileFails) {
    assert.ok(result.taskError, 'observed precompile failure must propagate through Gulp');
    assert.equal(count('karma:fork'), 0, 'precompile failure must stop browser tests');
    return;
  }
  assert.equal(count('karma:fork'), 1, 'must launch the real runKarma path');
  assert.equal(count('karma:send'), 1, 'must dispatch browser test options');
  assert.equal(count('karma:end'), 1);
  before('precompile:end', 'karma:fork');
  before('karma:fork', 'karma:send');
  before('karma:end', 'task:end');
  if (!scenario.file) before('build:end', 'karma:fork');
  const options = events.find(event => event.kind === 'karma:send').options;
  assert.equal(options.file, scenario.file, 'Karma must receive the selected file, or no selection for full suite');
  assert.ok(!options.notest, 'must not request that tests be skipped');
  if (scenario.karmaExit) {
    assert.equal(events.find(event => event.kind === 'karma:end').code, scenario.karmaExit);
    assert.ok(result.taskError, 'observed Karma failure must propagate through Gulp');
  } else {
    assert.equal(result.taskError, null, 'task must succeed');
  }
}

function runCase(root, scenario) {
  root = path.resolve(root);
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'invocation-probe-'));
  const journal = path.join(directory, 'events.jsonl');
  fs.writeFileSync(journal, '');
  let child;
  try {
    child = cp.spawnSync(process.execPath, [__filename, '--worker', root, JSON.stringify(scenario)], {
      encoding: 'utf8', timeout: scenario.realPrecompile ? 200000 : 30000, maxBuffer: 4 * 1024 * 1024,
      detached: true,
      env: {...process.env, [CONTEXT]: JSON.stringify({root, scenario, journal})},
    });
    assert.ifError(child.error);
    assert.equal(child.status, 0, `Probe worker failed: ${child.stderr}\n${child.stdout}`);
    const line = child.stdout.split('\n').find(line => line.startsWith(MARKER));
    assert.ok(line, `No probe result: ${child.stdout}\n${child.stderr}`);
    const events = fs.readFileSync(journal, 'utf8').trim().split('\n').filter(Boolean).map(JSON.parse);
    return {...JSON.parse(line.slice(MARKER.length)), events};
  } finally {
    // Only this case's process group and temporary journal, never shared resources.
    if (child?.pid) {
      try { process.kill(-child.pid, 'SIGKILL'); } catch (error) {
        if (error.code !== 'ESRCH') throw error;
      }
    }
    fs.rmSync(directory, {recursive: true, force: true});
  }
}

// This is separate from the fast failure-injection matrix: no precompile task,
// TypeScript process, declaration checker or file-copy operation is replaced.
function runFullBuild(root) {
  root = path.resolve(root);
  const output = path.join(root, 'dist/src');
  fs.rmSync(output, {recursive: true, force: true});
  const scenario = {name: 'full-real-precompile', realPrecompile: true};
  const result = runCase(root, scenario);
  try { check(result, scenario); }
  catch (error) { error.result = result; throw error; }
  const declarations = [];
  const emitted = path.join(root, '.cache/ts/out');
  function visit(directory) {
    for (const entry of fs.readdirSync(directory, {withFileTypes: true})) {
      const file = path.join(directory, entry.name);
      if (entry.isDirectory()) visit(file);
      else if (entry.name.endsWith('.d.ts')) {
        const relative = path.relative(emitted, file);
        // Ignore stale tsc outputs whose source was removed, matching the public
        // contract without requiring a particular copy helper implementation.
        if (fs.existsSync(path.join(root, relative.replace(/\.d\.ts$/, '.ts')))) {
          assert.ok(fs.existsSync(path.join(output, relative)),
            `emitted declaration missing from full build: ${relative}`);
          assert.ok(fs.statSync(path.join(output, relative)).size > 0,
            `empty declaration in full build: ${relative}`);
          declarations.push(relative);
        }
      }
    }
  }
  assert.ok(fs.existsSync(emitted), 'full build must emit TypeScript declarations');
  visit(emitted);
  assert.ok(declarations.length > 0, 'must check a nonempty emitted declaration surface');
  return {...result, declarations: declarations.sort()};
}

module.exports = {CASES, runCase, check, runFullBuild};
if (require.main !== module && process.env[CONTEXT]) {
  instrument(JSON.parse(process.env[CONTEXT]));
}
if (require.main === module) {
  if (process.argv[2] === '--full-build') {
    try { console.log(JSON.stringify(runFullBuild(process.argv[3] || process.cwd()))); }
    catch (error) { console.error(error.stack); process.exitCode = 1; }
  } else if (process.argv[2] === '--worker') {
    worker(path.resolve(process.argv[3]), JSON.parse(process.argv[4])).then(result => {
      console.log(MARKER + JSON.stringify(result));
    }).catch(err => { console.error(err); process.exitCode = 2; });
  } else {
    const root = path.resolve(process.argv[2] || process.cwd());
    let failed = 0;
    for (const scenario of CASES) {
      let result;
      try {
        result = runCase(root, scenario);
        check(result, scenario);
        console.log(`PASS ${scenario.name}`);
      } catch (err) {
        failed++;
        console.error(`FAIL ${scenario.name}: ${err.message}`);
        if (result) console.error(JSON.stringify(result));
      }
    }
    process.exitCode = failed ? 1 : 0;
  }
}
