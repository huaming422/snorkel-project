#!/usr/bin/env node
'use strict';

// Standalone verifier: no gulp.tree(), source-pattern correctness assertions,
// task replacement for test-only/build-logic, or real browser/build execution.
const assert = require('node:assert/strict');
const path = require('node:path');
const {createRequire, syncBuiltinESMExports} = require('node:module');
const cp = require('node:child_process');
const {EventEmitter} = require('node:events');
const {PassThrough} = require('node:stream');
const MARKER = 'TASK_INVOCATION_RESULT=';
const FILE = 'test/spec/ajax_spec.js';
const CASES = [
  {name: 'selected-pass', file: FILE},
  {name: 'selected-build-fails', file: FILE, buildExit: 23},
  {name: 'full-pass'},
  {name: 'full-build-fails', buildExit: 23},
  {name: 'selected-karma-fails', file: FILE, karmaExit: 17},
  {name: 'selected-precompile-fails', file: FILE, precompileFails: true},
];

async function worker(root, scenario) {
  process.chdir(root);
  // Must precede the first import of gulpHelpers (see argv_spec.mjs).
  process.argv = [process.execPath, path.join(root, 'node_modules/gulp/bin/gulp.js'),
    'test-only', ...(scenario.file ? ['--file', scenario.file] : [])];
  const req = createRequire(path.join(root, 'package.json'));
  const events = [];
  let harnessError;
  const record = (kind, details = {}) => events.push({kind, ...details});
  function unsupported(message) {
    harnessError = message;
    throw new Error(message);
  }
  const original = Object.fromEntries(['spawn', 'fork', 'exec', 'execFile',
    'spawnSync', 'execSync', 'execFileSync'].map(key => [key, cp[key]]));

  // Keep installed execa 1.x and helpers.execaTask intact. Undertaker uses
  // end-of-stream to observe this child (stdio must contain three entries);
  // wrappers that return promises also retain Execa's real rejection logic.
  cp.spawn = (command, args = []) => {
    const invocation = [command, ...args].join(' ');
    if (!/mocha/.test(invocation) || !/test[\\/]build-logic/.test(invocation)) {
      return unsupported(`Unexpected spawn boundary: ${invocation}`);
    }
    record('build:start', {command: invocation});
    const child = new EventEmitter();
    Object.assign(child, {
      stdin: new PassThrough(), stdout: new PassThrough(), stderr: new PassThrough(),
      killed: false, exitCode: null, signalCode: null,
      kill() { this.killed = true; return true; },
    });
    child.stdio = [child.stdin, child.stdout, child.stderr];
    setImmediate(() => {
      const code = scenario.buildExit || 0;
      record('build:end', {code});
      child.exitCode = code;
      child.stdout.end();
      child.stderr.end();
      child.emit('exit', code, null);
      child.emit('close', code, null);
    });
    return child;
  };
  cp.fork = (modulePath) => {
    if (path.resolve(root, modulePath) !== path.join(root, 'karmaRunner.js')) {
      return unsupported(`Unexpected fork boundary: ${modulePath}`);
    }
    record('karma:fork');
    const child = new EventEmitter();
    child.send = (options) => {
      record('karma:send', {options: JSON.parse(JSON.stringify(options))});
      setImmediate(() => {
        const code = scenario.karmaExit || 0;
        record('karma:end', {code});
        child.emit('exit', code, null);
        child.emit('close', code, null);
      });
      return true;
    };
    child.kill = () => true;
    return child;
  };
  // Fail closed: a changed external execution route must not launch real work
  // or silently count as successful verification.
  for (const key of ['exec', 'execFile', 'spawnSync', 'execSync', 'execFileSync']) {
    cp[key] = () => unsupported(`Unsupported child_process.${key} boundary`);
  }
  syncBuiltinESMExports();
  let taskError = null;
  let taskErrorCode = null;
  let setupError = null;
  let gulp;
  let precompilation;
  let oldFactory;
  let oldPrecompile;
  const onGulpError = () => {}; // Undertaker emits errors as well as invoking callback.
  try {
    gulp = req('gulp');
    gulp.on('error', onGulpError);
    // Load the real module and its registrations first. Only the expensive
    // compilation service is replaced, before gulpfile captures its dependency.
    precompilation = req('./gulp.precompilation.js');
    oldFactory = precompilation.precompile;
    oldPrecompile = gulp.task('precompile');
    function fakePrecompile(done) {
      record('precompile:start');
      setImmediate(() => {
        record('precompile:end', {failed: !!scenario.precompileFails});
        done(scenario.precompileFails ? new Error('probe-precompile-failure') : undefined);
      });
    }
    precompilation.precompile = () => fakePrecompile;
    gulp.task('precompile', fakePrecompile);
    req('./gulpfile.js');
    await new Promise((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error('Task did not settle within 10 seconds')), 10000);
      gulp.series('test-only')(err => {
        clearTimeout(timeout);
        taskError = err ? String(err.message || err) : null;
        taskErrorCode = err?.code ?? null;
        record('task:end', {error: taskError});
        resolve();
      });
    });
    // Allow pending stand-ins to reveal tasks that returned before completion.
    await new Promise(resolve => setImmediate(resolve));
  } catch (err) {
    setupError = err.stack || String(err);
  } finally {
    if (oldFactory) precompilation.precompile = oldFactory;
    if (oldPrecompile) gulp.task('precompile', oldPrecompile);
    if (gulp) gulp.removeListener('error', onGulpError);
    Object.assign(cp, original);
    syncBuiltinESMExports();
  }
  return {scenario: scenario.name, events, taskError, taskErrorCode, setupError, harnessError};
}

function check(result, scenario) {
  assert.equal(result.setupError, null, `Harness/import error: ${result.setupError}`);
  assert.ok(!result.harnessError, result.harnessError);
  const events = result.events;
  const count = kind => events.filter(event => event.kind === kind).length;
  const index = kind => events.findIndex(event => event.kind === kind);
  const before = (a, b) => assert.ok(index(a) >= 0 && index(a) < index(b), `${a} must complete before ${b}`);
  assert.equal(count('task:end'), 1, 'actual task must settle once');
  assert.equal(events.at(-1).kind, 'task:end', 'task must await all invoked work');
  if (scenario.file) {
    assert.equal(count('build:start'), 0, '--file must not invoke build-logic, even if it would fail');
  } else {
    assert.equal(count('build:start'), 1, 'full invocation must run build-logic');
    assert.equal(count('build:end'), 1);
  }
  if (!scenario.file && scenario.buildExit) {
    assert.ok(result.taskError, 'build failure must propagate through Gulp');
    assert.equal(events.find(event => event.kind === 'build:end').code, 23);
    assert.equal(count('karma:fork'), 0, 'build failure must stop browser tests');
    return;
  }
  assert.equal(count('precompile:start'), 1, 'precompile must execute');
  assert.equal(count('precompile:end'), 1);
  before('precompile:start', 'precompile:end');
  if (scenario.precompileFails) {
    assert.match(result.taskError || '', /probe-precompile-failure/);
    assert.equal(count('karma:fork'), 0, 'precompile failure must stop browser tests');
    return;
  }
  assert.equal(count('karma:fork'), 1, 'must launch the real runKarma path');
  assert.equal(count('karma:send'), 1, 'must dispatch browser test options');
  assert.equal(count('karma:end'), 1);
  before('precompile:end', 'karma:fork');
  before('karma:fork', 'karma:send');
  before('karma:end', 'task:end');
  if (!scenario.file) before('build:end', 'karma:fork');
  const options = events.find(event => event.kind === 'karma:send').options;
  assert.equal(options.file, scenario.file, 'Karma must receive the selected file, or no selection for full suite');
  assert.ok(!options.notest, 'must not request that tests be skipped');
  if (scenario.karmaExit) {
    assert.match(result.taskError || '', /17/, 'Karma failure must propagate');
  } else {
    assert.equal(result.taskError, null, 'task must succeed');
  }
}

function runCase(root, scenario) {
  const child = cp.spawnSync(process.execPath, [__filename, '--worker', root, JSON.stringify(scenario)], {
    encoding: 'utf8', timeout: 30000, maxBuffer: 4 * 1024 * 1024,
  });
  assert.ifError(child.error);
  assert.equal(child.status, 0, `Probe worker failed: ${child.stderr}\n${child.stdout}`);
  const line = child.stdout.split('\n').find(line => line.startsWith(MARKER));
  assert.ok(line, `No probe result: ${child.stdout}\n${child.stderr}`);
  return JSON.parse(line.slice(MARKER.length));
}

module.exports = {CASES, runCase, check};
if (require.main === module) {
  if (process.argv[2] === '--worker') {
    worker(path.resolve(process.argv[3]), JSON.parse(process.argv[4])).then(result => {
      console.log(MARKER + JSON.stringify(result));
    }).catch(err => { console.error(err); process.exitCode = 2; });
  } else {
    const root = path.resolve(process.argv[2] || process.cwd());
    let failed = 0;
    for (const scenario of CASES) {
      let result;
      try {
        result = runCase(root, scenario);
        check(result, scenario);
        console.log(`PASS ${scenario.name}`);
      } catch (err) {
        failed++;
        console.error(`FAIL ${scenario.name}: ${err.message}`);
        if (result) console.error(JSON.stringify(result));
      }
    }
    process.exitCode = failed ? 1 : 0;
  }
}
