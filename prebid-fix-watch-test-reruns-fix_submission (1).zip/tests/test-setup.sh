#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier (set -euo pipefail inherited).
# The build-logic mocha suite runs in pure Node against the repo's own modules;
# no services, no data seeding. node_modules is baked into the image (§1.2), so
# this is offline-first with a logged online fallback and nothing else.
cd /repo/Prebid.js
export npm_config_offline=true

if npm ci --offline --cache /opt/cache/npm > /tmp/test-setup-install.log 2>&1; then
    echo "[offline-first] deps satisfied from image"
elif npm ci --cache /opt/cache/npm >> /tmp/test-setup-install.log 2>&1; then
    echo "[test-setup] deps installed online (image bake was stale)"
else
    tail -40 /tmp/test-setup-install.log >&2; exit 1
fi
