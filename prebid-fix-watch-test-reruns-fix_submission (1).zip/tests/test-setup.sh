#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier (set -euo pipefail inherited).
# The verifier drives real Karma/Chromium watch runs and Node task probes.
# CHROME_BIN points to the system Chromium baked into the image. Dependencies
# are restored from its npm cache, with a logged online fallback if needed.
cd /repo/Prebid.js
export npm_config_offline=true

if npm ci --offline --cache /opt/cache/npm > /tmp/test-setup-install.log 2>&1; then
    echo "[offline-first] deps satisfied from image"
elif npm ci --offline=false --cache /opt/cache/npm >> /tmp/test-setup-install.log 2>&1; then
    echo "[test-setup] deps installed online (image bake was stale)"
else
    tail -40 /tmp/test-setup-install.log >&2; exit 1
fi
