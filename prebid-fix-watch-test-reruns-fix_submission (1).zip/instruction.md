## Task

Something is wrong with the local test loop. With `gulp serve-and-test` running, saving one source file triggers several runs of the unit suite, and some runs still use the previous version of that file. This happens while iterating on the full suite as well as a selected spec. Please get it back to one run per save using the current source, and make sure later saves still work after a test failure.

`gulp test-only --file <spec>` has also become slower: it runs unrelated build-tooling tests, and a failure there can stop the selected spec from running at all. Keep those unrelated tests out of a selected-spec run. Full runs from a clean checkout should retain their normal coverage, and real compilation or test failures should still be reported.

## General instructions

- The code repo is at /repo/Prebid.js.
- You are inside of a Docker container with no network access. You may not be able to perform all operations you would normally be able to do on a local machine. The project's dependencies and toolchain are already installed and the package manager caches are populated, so build and test with what is in the image; anything that needs to be downloaded will fail rather than hang.
- You are expected to act autonomously as a software engineer to complete tasks you are given.
- Do not stop until you feel you have completed the task and your code changes can be merged.
- You may need to use software engineering skills like analyzing the codebase, researching technologies, running services, analyzing logs, etc. to complete the task. Not all tasks will be solvable by reading source code alone.
