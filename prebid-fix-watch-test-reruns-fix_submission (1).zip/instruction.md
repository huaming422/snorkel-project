## Task

Can you repair the local test workflow? `gulp serve-and-test` should keep unit-test results in sync with what I'm editing, without repeating the suite for one source save.

`gulp test-only --file <spec>` should run the requested spec without other test groups. Full runs from a clean checkout should keep their normal coverage and failure reporting.

## General instructions

- The code repo is at /repo/Prebid.js.
- You are inside of a Docker container with no network access. You may not be able to perform all operations you would normally be able to do on a local machine. The project's dependencies and toolchain are already installed and the package manager caches are populated, so build and test with what is in the image; anything that needs to be downloaded will fail rather than hang.
- You are expected to act autonomously as a software engineer to complete tasks you are given.
- Do not stop until you feel you have completed the task and your code changes can be merged.
- You may need to use software engineering skills like analyzing the codebase, researching technologies, running services, analyzing logs, etc. to complete the task. Not all tasks will be solvable by reading source code alone.
