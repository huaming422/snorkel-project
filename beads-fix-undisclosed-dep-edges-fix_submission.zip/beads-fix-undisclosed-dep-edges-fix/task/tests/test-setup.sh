#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
# All build/run dependencies (Go 1.26.10, CGO toolchain, libicu-dev, and a
# prewarmed Go module + build cache at the base commit) are baked into the
# image by the Dockerfile. This script only brings the baked Go module cache
# online offline-first; there are no services to start and no data to seed
# (the verifier creates its own issues/edges through `bd`).
cd /repo/beads

# Cut the network for Go resolution so a cache miss fails fast here instead of
# silently reaching proxy.golang.org — mirrors the smoke gate's offline fold.
export GOFLAGS=-mod=mod GOPROXY=off GOTOOLCHAIN=local CGO_ENABLED=1

# Dependencies: offline-first against the image bake, logged online fallback.
if GOPROXY=off go mod download > /tmp/test-setup-godl.log 2>&1; then
    echo "[offline-first] go modules satisfied from image cache"
elif GOPROXY= go mod download >> /tmp/test-setup-godl.log 2>&1; then
    echo "[test-setup] go modules downloaded online (image bake was stale)"
else
    tail -40 /tmp/test-setup-godl.log >&2; exit 1
fi

# Per-tier env is NOT exported here: each verifier file selects its own Dolt
# backend through verify.toml's per-file [go.tests.<stem>].env block
# (embedded: BEADS_TEST_EMBEDDED_DOLT=1; proxied: BEADS_TEST_PROXIED_SERVER=1 +
# BEADS_TEST_DOLT_SERVER=local + BEADS_TEST_REQUIRE_DOLT_CONTAINER=1; the pure
# internal/httpapi bijection verifier needs none). Exporting a tier var globally
# here would leak it into the other tiers' go-test processes and cross-wire the
# backend selection.
