// Structural verifier — the wire contract stays internally consistent
// (criterion 6, pass_to_pass).
//
// The `--json` disclosure path is the one surface where a solution may extend a
// SERIALIZED struct: the fix can add a field to the issue-detail body so that
// `bd show --json` stops contradicting itself. internal/httpapi welds that body
// (types.IssueDetails) to its OpenAPI schema with x-go-type, so the generator
// emits a type alias and the compiler never sees the spec's property list — the
// ONLY guard that a struct field and its documented schema property stay in
// one-to-one correspondence is the package's own TestWireTagBijection.
//
// This file re-runs that pre-existing test as the verifier. It is a pass_to_pass
// invariant, deliberately shape-TOLERANT: it pins no field name. A solution that
// adds a `--json` disclosure field under ANY name passes iff it documents that
// field in openapi.v0.yaml too (and vice versa); a solution that discloses only
// through the text/stderr renders adds no serialized field and the bijection
// holds trivially. What it rejects is the one genuinely-worse outcome in this
// corner — a new body field shipped on the wire with no schema entry, or a
// schema property the struct never marshals. Both the fixed and base trees are green here.
//
// TestWireTagBijection and all its helpers (loadSpec, mapAt, resolveRef,
// pinnedSchemas, jsonTagNames, schemaProperties, diff) live in the httpapi test
// package and compile alongside this injected file; the fix touches none of
// them, so this delegates to a stable, pre-existing interface rather than
// re-implementing it. No build tag: internal/httpapi is pure Go.

package httpapi

import "testing"

func TestVerifyWireTagBijection(t *testing.T) {
	// Delegate to the package's own bijection guard. It drives its own t.Run
	// subtests per pinned schema; invoking it here runs the full two-way
	// (Go-tag set == spec-property set) check under this verifier's -run filter.
	TestWireTagBijection(t)
}
