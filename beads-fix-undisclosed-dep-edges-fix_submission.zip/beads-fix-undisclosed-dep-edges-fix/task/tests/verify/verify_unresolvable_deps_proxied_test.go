//go:build cgo

// Behavioral verifier — proxied-server `bd` render path (criterion 3, the
// decisive sub-case).
//
// `bd show` has three text renders. The direct and watch renders share
// displayShowIssueReturn / the direct showCmd body; this one, proxiedRenderIssue
// in show_proxied_server.go, is the route a server-backed repo actually takes
// (usesProxiedServer() returns before any direct-path code) and was the render
// the first cut of the fix missed. A solution that discloses on the direct path
// but not here still ships the original symptom on the route most exposed to
// it, so this file is what makes "every text render" more than the direct one.
//
// It runs WITHOUT docker-in-docker: the test Dolt server comes from the pinned
// local `dolt` CLI (BEADS_TEST_DOLT_SERVER=local — see
// internal/testutil/localdoltserver.go), and BEADS_TEST_REQUIRE_DOLT_CONTAINER=1
// turns an unavailable server into a FATAL rather than a skip, so this lane
// cannot pass green having silently run nothing (which would let an unfixed
// build through the one sub-case that distinguishes it). The verify.toml sets those, plus
// BEADS_TEST_PROXIED_SERVER=1, in this file's per-file env.
//
// Compiles as `package main` against the package's pre-existing proxied test
// helpers (newSharedProxiedProject, bdProxiedCreate, bdProxiedDep,
// bdProxiedRunBuffers, buildEmbeddedBD) — none introduced by the fix.
//
// Wording tolerance: task.toml blesses "different stderr wording". So, as on
// the embedded tier, this asserts the notice's PRESENCE differentially (hidden
// issue vs a no-dependency baseline, with a fully-local negative control)
// rather than matching any phrase, and asserts the stream split (notice on
// stderr, never stdout).

package main

import (
	"strings"
	"testing"
)

func TestVerifyUnresolvableDepsProxied(t *testing.T) {
	requireSharedProxiedServer(t) // FATAL (not skip) when the lane requires the server
	bd := buildEmbeddedBD(t)

	// One project shared by all three issues so they live in the same
	// server-backed database and differ only in their dependency edge.
	p := newSharedProxiedProject(t, bd, "vud")

	hidden := bdProxiedCreate(t, bd, p.dir, "Proxied subject with a cross-repo edge", "--type", "task")
	bdProxiedDep(t, bd, p.dir, "add", hidden.ID, "liveop-kmf", "--type", "blocks")

	blocker := bdProxiedCreate(t, bd, p.dir, "Proxied local blocker", "--type", "task")
	local := bdProxiedCreate(t, bd, p.dir, "Proxied fully-local subject", "--type", "task")
	bdProxiedDep(t, bd, p.dir, "add", local.ID, blocker.ID, "--type", "blocks")

	nodep := bdProxiedCreate(t, bd, p.dir, "Proxied no-dependency subject", "--type", "task")

	hStdout, hStderr := vudProxiedShow(t, bd, p.dir, hidden.ID)
	lStdout, lStderr := vudProxiedShow(t, bd, p.dir, local.ID)
	_, nStderr := vudProxiedShow(t, bd, p.dir, nodep.ID)

	base := vudPxStderrLineSet(nStderr, nodep.ID)
	hiddenExtra := vudPxStderrDelta(vudPxStderrLineSet(hStderr, hidden.ID), base)
	localExtra := vudPxStderrDelta(vudPxStderrLineSet(lStderr, local.ID), base)

	// The hidden edge must produce a stderr notice (lines beyond the
	// no-dependency baseline) on the proxied render specifically.
	if len(hiddenExtra) == 0 {
		t.Errorf("proxied bd show produced no stderr notice for a hidden cross-repo edge\n"+
			"(nothing beyond the no-dependency baseline).\nhidden stderr:\n%s\nbaseline stderr:\n%s",
			hStderr, nStderr)
	}
	// Negative control: a fully-local edge must produce none. Without this, a
	// build that warns unconditionally would pass the assertion above.
	if len(localExtra) != 0 {
		t.Errorf("proxied bd show warned about a fully-local edge (lines beyond baseline): %v\nlocal stderr:\n%s",
			localExtra, lStderr)
	}
	// Same stream-split contract as the direct route: stdout stays unchanged for
	// scripts, so the notice must not appear there.
	hOutNorm := strings.ReplaceAll(hStdout, hidden.ID, "ISSUE")
	for _, line := range hiddenExtra {
		if strings.Contains(hOutNorm, line) {
			t.Errorf("the proxied notice line %q leaked onto stdout, which must stay unchanged:\n%s", line, hStdout)
		}
	}
	// The local dependency must still render on stdout (the proxied render is
	// otherwise intact) — the positive half of the negative control.
	if !strings.Contains(lStdout, blocker.ID) {
		t.Errorf("proxied bd show did not render the local dependency %s on stdout:\n%s", blocker.ID, lStdout)
	}
}

// vudProxiedShow runs a proxied `bd show <id>` with stdout and stderr captured
// separately. bdProxiedRunBuffers already keeps the streams apart (and applies
// the proxied env); this wrapper just fatals on an unexpected command error.
func vudProxiedShow(t *testing.T, bd, dir, id string) (stdout, stderr string) {
	t.Helper()
	out, errOut, err := bdProxiedRunBuffers(t, bd, dir, "show", id)
	if err != nil {
		t.Fatalf("proxied bd show %s failed: %v\nstdout:\n%s\nstderr:\n%s", id, err, out, errOut)
	}
	return out, errOut
}

// vudPxStderrLineSet / vudPxStderrDelta mirror the embedded verifier's helpers.
// They are duplicated here (with a Px suffix) because the Go runner injects and
// runs each verify*_test.go file on its own — this file compiles without the
// embedded one present — and because, even side by side, two files in one
// package cannot both define the same top-level identifier.
//
// vudPxStderrLineSet normalizes a stderr capture to a set of non-empty trimmed
// lines with the subject id replaced by a constant token, so lines differ only
// when their CONTENT differs, not merely because each issue has a distinct id.
func vudPxStderrLineSet(raw, id string) map[string]bool {
	norm := strings.ReplaceAll(raw, id, "ISSUE")
	set := map[string]bool{}
	for _, line := range strings.Split(norm, "\n") {
		if l := strings.TrimSpace(line); l != "" {
			set[l] = true
		}
	}
	return set
}

func vudPxStderrDelta(sub, base map[string]bool) []string {
	var out []string
	for l := range sub {
		if !base[l] {
			out = append(out, l)
		}
	}
	return out
}
