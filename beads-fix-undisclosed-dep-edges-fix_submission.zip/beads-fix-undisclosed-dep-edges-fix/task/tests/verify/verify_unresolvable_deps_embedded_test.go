//go:build cgo

// Behavioral verifier — embedded `bd` production path.
//
// Covers, on the direct (embedded) store that `bd` uses by default
// (usesProxiedServer() is false):
//   - criterion 1: `bd show --json` discloses the counted-but-unlistable edge;
//   - criterion 3 (direct + watch text renders): the notice is on stderr and
//     stdout stays clean, conditional on there actually being a hidden edge;
//   - criterion 4 (pass_to_pass): the real edge stays counted and unlisted,
//     no row is fabricated, and the raw outbound edge is still reachable;
//   - the OBSERVABLE core of criterion 5: a fully-local edge is never reported
//     as unresolvable.
//
// This file is injected into cmd/bd/ by the Go runner and compiles as
// `package main` against the package's pre-existing, committed test helpers
// (buildEmbeddedBD, bdInit, bdCreate, bdDep, bdShowDetails, bdEnv,
// runCommandBuffers). None of those were introduced by the fix.
//
// WHY SHAPE/WORDING TOLERANCE IS LOAD-BEARING. task.toml blesses three JSON
// disclosure shapes (a numeric unresolvable count, a boolean omitted marker +
// count, or a direct SQL count) and explicitly blesses "different stderr
// wording / recovery-pointer phrasing". So this verifier pins NONE of:
//   - a field name (`unresolvable_dependencies`), helper, or struct spelling;
//   - the notice's exact words.
// It asserts only the behavior every blessed alternative shares, discovered
// differentially:
//   - JSON: an issue with one hidden edge gains SOME truthy key that an
//     otherwise-identical issue with one *resolvable* edge does not (counted-
//     but-hidden is distinguishable from "all present", and the marker is
//     ABSENT — not zero/false — when nothing is hidden, because the blessed
//     shapes all use omitempty);
//   - text: an issue with a hidden edge produces stderr lines that an issue
//     with NO dependencies does not; an issue whose only edge is local
//     produces none beyond that no-dependency baseline; and none of those
//     lines appear on stdout.

package main

import (
	"bytes"
	"context"
	"os/exec"
	"strings"
	"testing"
	"time"
)

// vudExternalTargets are the two target shapes issueops.IsExternalDepTarget
// classifies as having "no row in this database": an explicit external:
// reference and a bare id whose prefix names another repo. Both land in
// depends_on_external, the one target column with no foreign key into issues,
// so both are dropped by the listing path while kept by the count path. A fix
// that covers only one leaves the commoner bare-id form silent. These are
// repo-classification facts, not solution choices.
var vudExternalTargets = []struct {
	name   string
	target string
	depTyp string
}{
	{"external_reference", "external:liveop:liveop-kmf", "tracks"},
	{"cross_repo_prefix", "liveop-kmf", "blocks"},
}

func TestVerifyUnresolvableDepsEmbedded(t *testing.T) {
	bd := buildEmbeddedBD(t)
	dir, _, _ := bdInit(t, bd, "--prefix", "ud")

	for _, tc := range vudExternalTargets {
		tc := tc
		t.Run(tc.name, func(t *testing.T) {
			// Three issues that differ ONLY in their dependency edge:
			//   hidden — one cross-repo/external edge (counted, unlistable);
			//   local  — one ordinary local edge (counted AND listable);
			//   nodep  — no edges at all (the text no-notice baseline).
			hidden := bdCreate(t, bd, dir, "Subject "+tc.name, "--type", "task")
			bdDep(t, bd, dir, "add", hidden.ID, tc.target, "--type", tc.depTyp)

			localBlocker := bdCreate(t, bd, dir, "Local blocker "+tc.name, "--type", "task")
			local := bdCreate(t, bd, dir, "Local subject "+tc.name, "--type", "task")
			// Same dependency TYPE as the hidden case, so the only difference
			// between the two issues is whether the one edge's target resolves
			// to a local row — not the edge type. That keeps the truthy-extra-key
			// diff below attributable solely to the disclosure.
			bdDep(t, bd, dir, "add", local.ID, localBlocker.ID, "--type", tc.depTyp)

			nodep := bdCreate(t, bd, dir, "No-dependency subject "+tc.name, "--type", "task")

			hiddenJSON := bdShowDetails(t, bd, dir, hidden.ID)
			localJSON := bdShowDetails(t, bd, dir, local.ID)

			// ---- criterion 4 (pass_to_pass): the real edge is preserved ----
			// Counted but not listed, with no fabricated row. Holds pre- and
			// post-fix; fails a "solution" that zeroes the count or injects a
			// placeholder dependency.
			if n, ok := hiddenJSON["dependency_count"].(float64); !ok || n != 1 {
				t.Fatalf("dependency_count = %v, want 1 — the real edge must stay counted",
					hiddenJSON["dependency_count"])
			}
			if listLen := vudListLen(hiddenJSON["dependencies"]); listLen != 0 {
				t.Fatalf("dependencies listed %d row(s), want 0 — the external target has no row to list and none may be fabricated",
					listLen)
			}

			// ---- criterion 1 (fail_to_pass): JSON discloses the hidden edge ----
			// Both `hidden` and `local` have dependency_count == 1; they differ
			// only in whether that one edge is resolvable. So any TRUTHY key the
			// hidden issue carries and the local one does not is the disclosure,
			// in whatever shape the solution chose — and its absence on `local`
			// is exactly the "absent, not zero, when none" contract. An
			// unfixed build discloses nothing, so it produces no such key and
			// fails here.
			disclosures := vudTruthyExtraKeys(hiddenJSON, localJSON)
			if len(disclosures) == 0 {
				t.Errorf("bd show --json on an issue with a hidden %s edge disclosed nothing that a\n"+
					"single-local-dependency issue lacks — a counted-but-unlistable edge must be\n"+
					"distinguishable from a fully-resolvable one.\nhidden keys: %v\nlocal keys:  %v",
					tc.name, vudSortedKeys(hiddenJSON), vudSortedKeys(localJSON))
			}

			// ---- criterion 3 (direct text render) ----
			hOut, hErr := vudRunShow(t, bd, dir, hidden.ID)
			lOut, lErr := vudRunShow(t, bd, dir, local.ID)
			_, nErr := vudRunShow(t, bd, dir, nodep.ID)
			vudAssertTextNotice(t, "direct bd show", tc.name,
				hErr, hOut, hidden.ID,
				lErr, local.ID,
				nErr, nodep.ID)
			// stdout must still render the issue (the notice is additive, not a
			// replacement of the view).
			if !strings.Contains(hOut, hidden.ID) {
				t.Errorf("direct bd show stdout did not render issue %s:\n%s", hidden.ID, hOut)
			}
			if !strings.Contains(lOut, local.ID) {
				t.Errorf("direct bd show stdout did not render issue %s:\n%s", local.ID, lOut)
			}

			// ---- criterion 3 (watch text render) ----
			// `bd show -w` renders once (the shared displayShowIssueReturn path)
			// and then polls until killed; the initial render — notice and all —
			// completes before the first tick, so a short deadline captures it.
			// The watch banner is stable boilerplate present in every case, so
			// the no-dependency baseline subtracts it out automatically.
			hwOut, hwErr := vudRunWatch(t, bd, dir, hidden.ID)
			lwOut, lwErr := vudRunWatch(t, bd, dir, local.ID)
			_, nwErr := vudRunWatch(t, bd, dir, nodep.ID)
			if !strings.Contains(hwOut, hidden.ID) {
				t.Fatalf("watch (`bd show -w`) never rendered issue %s; cannot assess its notice:\nstdout:\n%s",
					hidden.ID, hwOut)
			}
			vudAssertTextNotice(t, "watch bd show -w", tc.name,
				hwErr, hwOut, hidden.ID,
				lwErr, local.ID,
				nwErr, nodep.ID)
			_ = lwOut

			// ---- criterion 4 (pass_to_pass): raw edge still reachable ----
			// `bd dep list <id> <id>` (duplicate-id form → batchMode, direction
			// "down") routes to the EdgeReader, which keeps far-end-missing
			// edges and renders the stored target on stdout. This proves the
			// edge is real stored data, not a count to be explained away. The
			// target id contains "liveop-kmf" in both shapes.
			rawList := bdDep(t, bd, dir, "list", hidden.ID, hidden.ID)
			if !strings.Contains(rawList, "liveop-kmf") {
				t.Errorf("`bd dep list %s %s` did not surface the raw external edge; the stored edge must stay reachable:\n%s",
					hidden.ID, hidden.ID, rawList)
			}
		})
	}
}

// vudAssertTextNotice enforces criterion 3's contract for one text render,
// wording-free and noise-tolerant. It compares ID-normalized stderr line sets:
// the hidden issue must add lines over the no-dependency baseline (a notice
// fired), the local issue must add none (no false notice on a resolvable edge),
// and none of the hidden issue's extra lines may appear on its stdout (the
// notice is stderr-only; stdout stays script-stable).
func vudAssertTextNotice(
	t *testing.T, render, caseName string,
	hiddenErr, hiddenOut, hiddenID string,
	localErr, localID string,
	baseErr, baseID string,
) {
	t.Helper()
	base := vudStderrLineSet(baseErr, baseID)
	hiddenExtra := vudStderrDelta(vudStderrLineSet(hiddenErr, hiddenID), base)
	localExtra := vudStderrDelta(vudStderrLineSet(localErr, localID), base)

	if len(hiddenExtra) == 0 {
		t.Errorf("[%s/%s] produced no stderr notice for a hidden edge (nothing beyond the\n"+
			"no-dependency baseline).\nhidden stderr:\n%s\nbaseline stderr:\n%s",
			render, caseName, hiddenErr, baseErr)
	}
	if len(localExtra) != 0 {
		t.Errorf("[%s/%s] warned about a fully-local edge (lines beyond baseline): %v\nlocal stderr:\n%s",
			render, caseName, localExtra, localErr)
	}
	// The notice must not have leaked onto stdout.
	outNorm := strings.ReplaceAll(hiddenOut, hiddenID, "ISSUE")
	for _, line := range hiddenExtra {
		if strings.Contains(outNorm, line) {
			t.Errorf("[%s/%s] the stderr notice line %q leaked onto stdout, which must stay unchanged:\n%s",
				render, caseName, line, hiddenOut)
		}
	}
}

// vudListLen returns the element count of a JSON value that may be absent, nil,
// or a list.
func vudListLen(v interface{}) int {
	list, ok := v.([]interface{})
	if !ok {
		return 0
	}
	return len(list)
}

// vudTruthyExtraKeys returns the keys present in a whose value is truthy and
// that are absent from b. The two issues being compared are identical except
// for their one dependency edge, so a truthy key only a has is the disclosure
// — found without naming it, in whatever shape the solution chose.
func vudTruthyExtraKeys(a, b map[string]interface{}) []string {
	var out []string
	for k, v := range a {
		if _, inB := b[k]; inB {
			continue
		}
		if vudTruthy(v) {
			out = append(out, k)
		}
	}
	return out
}

// vudTruthy reports whether a decoded JSON scalar signals "something is here":
// a count >= 1, a boolean true, or a non-empty, non-"0"/"false" string. A JSON
// list or object is not a disclosure scalar and is deliberately not truthy, so
// the ordinary non-empty `dependencies` array is never mistaken for a marker.
func vudTruthy(v interface{}) bool {
	switch t := v.(type) {
	case float64:
		return t >= 1
	case bool:
		return t
	case string:
		s := strings.TrimSpace(t)
		return s != "" && s != "0" && s != "false"
	default:
		return false
	}
}

func vudSortedKeys(m map[string]interface{}) []string {
	out := make([]string, 0, len(m))
	for k := range m {
		out = append(out, k)
	}
	for i := 1; i < len(out); i++ {
		for j := i; j > 0 && out[j-1] > out[j]; j-- {
			out[j-1], out[j] = out[j], out[j-1]
		}
	}
	return out
}

// vudStderrLineSet normalizes a stderr capture into a set of non-empty trimmed
// lines with the subject issue id replaced by a constant token, so lines differ
// between captures only when their CONTENT differs — not merely because each
// issue has a different id. The notice names the subject id (and the recovery
// pointer repeats it); normalizing it keeps the comparison about the message,
// not the identifier.
func vudStderrLineSet(raw, id string) map[string]bool {
	norm := strings.ReplaceAll(raw, id, "ISSUE")
	set := map[string]bool{}
	for _, line := range strings.Split(norm, "\n") {
		if l := strings.TrimSpace(line); l != "" {
			set[l] = true
		}
	}
	return set
}

func vudStderrDelta(sub, base map[string]bool) []string {
	var out []string
	for l := range sub {
		if !base[l] {
			out = append(out, l)
		}
	}
	return out
}

// vudRunShow runs `bd show <id>` keeping stdout and stderr apart. The shared
// bd* helpers merge the two streams; the disclosure contract is stream-split,
// so this verifier needs them separate.
func vudRunShow(t *testing.T, bd, dir, id string) (stdout, stderr string) {
	t.Helper()
	cmd := exec.Command(bd, "show", id)
	cmd.Dir = dir
	cmd.Env = bdEnv(dir)
	outBuf, errBuf, err := runCommandBuffers(t, cmd)
	if err != nil {
		t.Fatalf("bd show %s failed: %v\nstdout:\n%s\nstderr:\n%s", id, err, outBuf.String(), errBuf.String())
	}
	return outBuf.String(), errBuf.String()
}

// vudRunWatch runs `bd show <id> -w`, which renders once and then polls until
// killed, and returns whatever reached stdout/stderr before the deadline. The
// initial render completes synchronously before the first poll tick, so the
// buffers hold it; the kill-induced error is expected and not asserted.
func vudRunWatch(t *testing.T, bd, dir, id string) (stdout, stderr string) {
	t.Helper()
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, bd, "show", id, "-w")
	cmd.Dir = dir
	cmd.Env = bdEnv(dir)
	var out, errOut bytes.Buffer
	cmd.Stdout = &out
	cmd.Stderr = &errOut
	_ = cmd.Run()
	return out.String(), errOut.String()
}
