"""Behavioral verifier for the device-art resolution regression.

The desktop crate rebuilds its device list on every background-agent snapshot,
and each rebuild resolves every connected device's art from disk again. The
behavior under test: a repeated resolve of a device whose art was already
found must be answered without going back to disk, while art that lands after
a miss or is cleared must be reflected after the runtime refresh boundary.

How this is driven
------------------
The art resolver is exercised through its pre-existing, stable public surface:
``AssetResolver::new()`` plus ``resolve`` / ``resolve_registry_model``. ``new()``
reads from the per-user art directory rooted at ``$XDG_DATA_HOME`` (see
``openlogi_core::paths``), so each test points ``$XDG_DATA_HOME`` at its own
temp dir, stages a real index + depot on disk, and observes the resolver's
answers. On Linux, ``/proc/thread-self/io`` reports bytes returned by read calls,
including cached filesystem reads. The repeated-hit checks compare that
counter around a second lookup with unchanged files; no wall-clock timing or
file deletion is needed to establish that the art was not read again.

The crate is a binary (no library target) and the module under test is
private, so the checks are compiled as an in-crate ``#[cfg(test)]`` module
appended to the resolver source for the duration of the run, then removed. The
checks only ever touch the public API; they never name any internal field,
key type, or helper the fix may introduce. The parser selects cases by their
injected module path so solver-authored tests cannot shadow their names.

A regression guard additionally runs the resolver module's own pre-existing
unit suite to catch a fix that changes which art a device resolves to.
"""

from __future__ import annotations

import os
import re
import subprocess
from pathlib import Path

import pytest


def _locate_repo() -> Path:
    """The checkout lives under `/repo`. Its directory name is the upstream
    repo name (`OpenLogi`), but the grading infra may export a differently-cased
    `REPO_NAME`, so resolve defensively: honor an env path that actually exists,
    then the canonical name, then the sole entry under `/repo`.
    """
    env_name = os.environ.get("REPO_NAME")
    if env_name:
        candidate = Path("/repo") / env_name
        if candidate.is_dir():
            return candidate
    canonical = Path("/repo/OpenLogi")
    if canonical.is_dir():
        return canonical
    repo_root = Path("/repo")
    if repo_root.is_dir():
        subdirs = [p for p in repo_root.iterdir() if p.is_dir()]
        if len(subdirs) == 1:
            return subdirs[0]
        # Fall back to a case-insensitive match on the canonical name.
        for p in subdirs:
            if p.name.lower() == "openlogi":
                return p
    return canonical


REPO_DIR = _locate_repo()
CRATE_DIR = REPO_DIR / "crates" / "openlogi-desktop"
# The resolver source the in-crate checks are appended to. It already ends with
# a `#[cfg(test)] mod tests;` declaration for the crate's own suite; the checks
# are added as a second, separately-named inline test module so they compile
# and run under `cargo test -p openlogi-desktop` without disturbing it.
RESOLVER_SRC = CRATE_DIR / "src" / "services" / "assets.rs"

PKG = "openlogi-desktop"
# `cargo test` is scoped to the resolver subsystem: this subtree is pure
# (filesystem + pure logic, no GPUI window / display / network), so it runs on
# a headless host — unlike the full crate suite, which links GPUI's x11/wayland
# backend and is excluded from the project's own Linux test job for that reason.
# The run therefore also exercises the resolver's PRE-EXISTING unit suite, which
# acts as the regression guard (a fix that changes which art a device resolves
# to breaks it).
TEST_FILTER = "services::assets"

# Unique sentinel so the injected block can be located and stripped exactly,
# even if a previous run was interrupted.
BEGIN = "// @@REWARD-MEMO-CHECKS BEGIN@@"
END = "// @@REWARD-MEMO-CHECKS END@@"


# --------------------------------------------------------------------------- #
# The in-crate behavioral checks (native Rust, public API only).
# --------------------------------------------------------------------------- #
#
# Staged on disk per check:
#   $XDG_DATA_HOME/openlogi/assets/index.json          (registry)
#   $XDG_DATA_HOME/openlogi/assets/<depot>/manifest.json
#   $XDG_DATA_HOME/openlogi/assets/<depot>/core_metadata.json
#   $XDG_DATA_HOME/openlogi/assets/<depot>/<render>.png
#
# `AssetResolver::new()` appends `assets/` to `data_dir()` =
# `$XDG_DATA_HOME/openlogi`, so the cache root it reads is exactly that path.
# Each check uses its own temp `$XDG_DATA_HOME` and sets the var at entry; the
# data dir is recomputed on every `data_dir()` call (only the dev/prod profile
# is memoized, and that stays Production here), so a per-check set is safe. The
# checks run single-threaded (`--test-threads=1`) because the env var is
# process-global.
MEMO_CHECKS_RS = r'''
// @@REWARD-MEMO-CHECKS BEGIN@@
#[cfg(test)]
mod reward_memo_checks {
    use super::{AssetResolver, ResolvedAsset};
    use openlogi_core::device::{DeviceModelInfo, DeviceTransports};
    use std::path::{Path, PathBuf};

    // --- fixture helpers (plain filesystem writes + public constructors) --- //

    /// A 24-byte PNG: signature + an `IHDR` chunk carrying only width/height,
    /// which is all the resolver reads to size a render.
    fn png_header(width: u32, height: u32) -> Vec<u8> {
        let mut bytes = vec![0x89, b'P', b'N', b'G', 0x0d, 0x0a, 0x1a, 0x0a];
        bytes.extend_from_slice(&13u32.to_be_bytes());
        bytes.extend_from_slice(b"IHDR");
        bytes.extend_from_slice(&width.to_be_bytes());
        bytes.extend_from_slice(&height.to_be_bytes());
        bytes
    }

    /// Point the per-user art directory at `home` and build a resolver that
    /// reads from it — the same path a production `AssetResolver::new()` takes,
    /// just with the base dir redirected to a test location.
    ///
    /// `set_var` is sound here: each check sets a unique dir at its own entry,
    /// the checks run single-threaded, and nothing else reads the environment
    /// concurrently.
    fn resolver_rooted_at(home: &Path) -> AssetResolver {
        #[expect(
            unsafe_code,
            reason = "redirect the per-user data base to the test dir before the \
                      resolver reads it; single-threaded, no concurrent env access"
        )]
        // SAFETY: the checks are `--test-threads=1`; this is the first thing
        // each check does, before any resolver is built, and no other thread
        // is reading the environment.
        unsafe {
            std::env::set_var("XDG_DATA_HOME", home);
        }
        AssetResolver::new()
    }

    /// The directory the resolver treats as the art cache for `home`.
    fn assets_root(home: &Path) -> PathBuf {
        home.join("openlogi").join("assets")
    }

    /// Write an `index.json` mapping one depot to one device entry.
    ///
    /// `files` lists the depot's registry file names. The standalone lookup,
    /// when a depot ships no manifest, picks its render from this list (the
    /// first known front-render name the depot declares), so a standalone depot
    /// must declare its render here; the HID++ variant path reads its render
    /// from the manifest + disk instead and is unaffected by this list.
    fn write_index(
        root: &Path,
        depot: &str,
        model_id: &str,
        model_ids: &[&str],
        display_name: &str,
        kind: &str,
        files: &[&str],
    ) {
        std::fs::create_dir_all(root).expect("create assets root");
        let ids = model_ids
            .iter()
            .map(|id| format!("{:?}", id))
            .collect::<Vec<_>>()
            .join(",");
        let file_entries = files
            .iter()
            .map(|name| format!(r#"{{"name":{name:?},"sha256":"","bytes":0}}"#))
            .collect::<Vec<_>>()
            .join(",");
        let entry = format!(
            r#"{{"modelId":{model_id:?},"modelIds":[{ids}],"displayName":{display_name:?},"type":{kind:?},"asset_path":"v1/devices/{depot}/","files":[{file_entries}]}}"#
        );
        let index = format!(r#"{{"schema_version":1,"devices":{{{depot:?}:{entry}}}}}"#);
        std::fs::write(root.join("index.json"), index).expect("write index.json");
    }

    /// Stage the MX Master 3S depot: one render per colour variant, each a
    /// distinct width so a mis-keyed memory would be observable. Mirrors the
    /// shape the crate's own resolver suite stages for this depot.
    fn write_variant_depot(root: &Path, variants: &[(u8, u32)]) -> PathBuf {
        let depot = "mx_master_3s";
        let dir = root.join(depot);
        std::fs::create_dir_all(&dir).expect("create depot dir");
        let devices: Vec<String> = variants
            .iter()
            .map(|(ext, _)| {
                format!(
                    r#"{{"modelId":"2b034_ext{ext}","resources":[{{"key":"device_buttons_image","src":"side_ext_{ext}.png"}}]}}"#
                )
            })
            .collect();
        std::fs::write(
            dir.join("manifest.json"),
            format!(r#"{{"devices":[{}]}}"#, devices.join(",")),
        )
        .expect("write manifest");
        std::fs::write(dir.join("core_metadata.json"), r#"{"images":[]}"#)
            .expect("write metadata");
        for (ext, width) in variants {
            std::fs::write(dir.join(format!("side_ext_{ext}.png")), png_header(*width, 10))
                .expect("write render");
        }
        dir
    }

    fn write_index_for_mx_master_3s(root: &Path) {
        write_index(
            root,
            "mx_master_3s",
            "2b043",
            &["2b043", "2b034"],
            "MX Master 3S",
            "mouse",
            // The variant path reads its render from the manifest + disk, so no
            // registry file list is needed for the HID++ lookup.
            &[],
        );
    }

    /// An MX Master 3S reporting bolt pid `b034` with the given variant byte.
    fn mx_master_3s(extended_model_id: u8) -> DeviceModelInfo {
        DeviceModelInfo {
            entity_count: 0,
            serial_number: None,
            unit_id: [0; 4],
            transports: DeviceTransports::default(),
            model_ids: [0xb034, 0, 0],
            extended_model_id,
        }
    }

    fn resolve_mx(resolver: &AssetResolver, ext: u8) -> Option<ResolvedAsset> {
        resolver.resolve(&mx_master_3s(ext), None)
    }

    /// Linux rchar counts bytes returned by read calls even when the kernel
    /// serves them from its page cache. The two adjacent samples calibrate
    /// the counter read itself before measuring a public resolver call.
    fn read_chars() -> u64 {
        let io = std::fs::read_to_string("/proc/thread-self/io").expect("read thread I/O counter");
        io.lines()
            .find_map(|line| line.strip_prefix("rchar:").map(str::trim))
            .expect("rchar counter")
            .parse()
            .expect("numeric rchar counter")
    }

    fn read_chars_during(resolve: impl FnOnce()) -> u64 {
        let first = read_chars();
        let second = read_chars();
        resolve();
        let third = read_chars();
        (third - second).saturating_sub(second - first)
    }

    // --------------------------- the checks ---------------------------- //

    /// Core regression: a repeated resolve of unchanged, already-found art
    /// does not read its manifest, metadata or render again. The files remain
    /// present so a design that detects external changes is also permitted.
    #[test]
    fn found_asset_answered_from_memory_until_replaced() {
        let home = tempfile::tempdir().expect("temp home");
        let root = assets_root(home.path());
        write_index_for_mx_master_3s(&root);
        write_variant_depot(&root, &[(2, 100)]);

        let resolver = resolver_rooted_at(home.path());
        let found = resolve_mx(&resolver, 2).expect("depot is on disk");

        let mut second = None;
        let read_bytes = read_chars_during(|| second = resolve_mx(&resolver, 2));
        assert_eq!(second, Some(found), "a repeated resolve keeps the same art");
        assert!(read_bytes <= 8, "unchanged art was read again: {read_bytes} bytes");
    }

    /// The standalone lookup (keyed by registry model id) is remembered on its
    /// own, mirroring the HID++ case. Fails pre-fix for the same reason.
    #[test]
    fn standalone_asset_answered_from_memory() {
        let home = tempfile::tempdir().expect("temp home");
        let root = assets_root(home.path());
        write_index(
            &root,
            "litra_glow",
            "8c900",
            &[],
            "Litra Glow",
            "ILLUMINATION_LIGHT",
            // No manifest in this depot, so the standalone lookup picks the
            // render from the registry file list.
            &["front.png"],
        );
        let depot = root.join("litra_glow");
        std::fs::create_dir_all(&depot).expect("create depot dir");
        std::fs::write(depot.join("front.png"), png_header(396, 396)).expect("write front");

        let resolver = resolver_rooted_at(home.path());
        let found = resolver
            .resolve_registry_model("8c900")
            .expect("depot is on disk");

        let mut second = None;
        let read_bytes = read_chars_during(|| second = resolver.resolve_registry_model("8c900"));
        assert_eq!(second, Some(found), "a repeated standalone resolve keeps the same art");
        assert!(read_bytes <= 8, "standalone art was read again: {read_bytes} bytes");
    }

    /// Art arriving after a miss is visible after the runtime's settled-sync
    /// invalidation boundary. A resolver may remember a miss until that event,
    /// provided its replacement sees the files that were written.
    #[test]
    fn depot_landing_after_miss_is_found() {
        let home = tempfile::tempdir().expect("temp home");
        let root = assets_root(home.path());
        write_index_for_mx_master_3s(&root);

        let resolver = resolver_rooted_at(home.path());
        assert_eq!(
            resolve_mx(&resolver, 2),
            None,
            "nothing is on disk yet, so the first resolve misses"
        );

        write_variant_depot(&root, &[(2, 100)]);
        let refreshed = resolver_rooted_at(home.path());
        assert!(
            resolve_mx(&refreshed, 2).is_some(),
            "a resolver refreshed after a settled sync must find landed art"
        );
    }

    /// Two colour variants of one depot must each keep resolving to their own
    /// render. A memory keyed on the depot alone would serve one variant the
    /// other's answer. The distinct widths make a collision observable.
    #[test]
    fn colour_variants_remembered_apart() {
        let home = tempfile::tempdir().expect("temp home");
        let root = assets_root(home.path());
        write_index_for_mx_master_3s(&root);
        let dir = write_variant_depot(&root, &[(2, 100), (12, 200)]);

        let resolver = resolver_rooted_at(home.path());
        let graphite = resolve_mx(&resolver, 2).expect("graphite resolves");
        let pale_grey = resolve_mx(&resolver, 12).expect("pale grey resolves");

        assert_eq!(graphite.image_path, dir.join("side_ext_2.png"));
        assert_eq!(pale_grey.image_path, dir.join("side_ext_12.png"));
        assert_eq!(
            (graphite.png_width, pale_grey.png_width),
            (100, 200),
            "each variant must keep its own render, not share one memoized answer"
        );
    }

    /// Invalidation is per-resolver-instance: a resolver built after the depot
    /// is gone must not inherit a prior resolver's memory. This is what makes a
    /// cache-clear / settled-sync (both of which build a new resolver) fall
    /// back immediately instead of serving a stale find. A memory that
    /// survives construction (e.g. a global/static) would return a stale
    /// answer and fail.
    #[test]
    fn replacement_does_not_inherit_prior_memory() {
        let home = tempfile::tempdir().expect("temp home");
        let root = assets_root(home.path());
        write_index_for_mx_master_3s(&root);
        let dir = write_variant_depot(&root, &[(2, 100)]);

        let first = resolver_rooted_at(home.path());
        assert!(resolve_mx(&first, 2).is_some(), "the depot is on disk");

        std::fs::remove_dir_all(&dir).expect("remove the depot");
        let second = resolver_rooted_at(home.path());
        assert_eq!(
            resolve_mx(&second, 2),
            None,
            "a resolver built after the files are gone must fall back, not serve a stale find"
        );
    }
}
// @@REWARD-MEMO-CHECKS END@@
'''


# --------------------------------------------------------------------------- #
# Harness: inject the checks, run cargo, parse, always clean up.
# --------------------------------------------------------------------------- #

_RESULT_LINE = re.compile(
    r"^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed", re.MULTILINE
)
_CASE_LINE = re.compile(r"^test (\S+) \.\.\. (ok|FAILED|ignored)", re.MULTILINE)

# The behavioral checks that must be present and must pass on a correct fix.
EXPECTED_CHECKS = {
    "found_asset_answered_from_memory_until_replaced",
    "standalone_asset_answered_from_memory",
    "depot_landing_after_miss_is_found",
    "colour_variants_remembered_apart",
    "replacement_does_not_inherit_prior_memory",
}


def _strip_injection(text: str) -> str:
    """Remove any previously-injected block (idempotent cleanup)."""
    start = text.find(BEGIN)
    if start == -1:
        return text
    end = text.find(END)
    if end == -1:
        return text[:start].rstrip() + "\n"
    end += len(END)
    cleaned = text[:start].rstrip() + "\n" + text[end:].lstrip("\n")
    return cleaned


@pytest.fixture(scope="module")
def cargo_run() -> dict:
    """Inject the in-crate checks, run them under `cargo test`, then restore
    the source verbatim. Returns parsed per-case results + the summary lines.
    """
    original = RESOLVER_SRC.read_text()
    injected = _strip_injection(original).rstrip() + "\n" + MEMO_CHECKS_RS
    RESOLVER_SRC.write_text(injected)
    try:
        proc = subprocess.run(
            [
                "cargo",
                "test",
                "-p",
                PKG,
                TEST_FILTER,
                "--",
                "--test-threads=1",
            ],
            capture_output=True,
            text=True,
            timeout=1500,
            cwd=str(REPO_DIR),
            check=False,
        )
    finally:
        # Restore the source exactly as it was, whatever happened.
        RESOLVER_SRC.write_text(original)

    combined = proc.stdout + "\n" + proc.stderr
    named_cases = _CASE_LINE.findall(combined)
    cases = {
        name.rsplit("::", 1)[-1]: status
        for name, status in named_cases
        if "::reward_memo_checks::" in name
    }
    return {
        "returncode": proc.returncode,
        "cases": cases,
        "named_cases": named_cases,
        "summaries": _RESULT_LINE.findall(combined),
        "stdout": proc.stdout,
        "stderr": proc.stderr,
    }


def _tail(run: dict) -> str:
    return (
        f"--- cargo exit {run['returncode']} ---\n"
        f"--- last stdout ---\n{run['stdout'][-3000:]}\n"
        f"--- last stderr ---\n{run['stderr'][-2000:]}"
    )


def test_memo_checks_compiled_and_ran(cargo_run: dict) -> None:
    """The in-crate checks compiled and produced per-case results.

    A compile failure (e.g. the agent's edit broke the resolver's public
    surface) surfaces here as zero discovered cases rather than a silent pass.
    """
    missing = EXPECTED_CHECKS - set(cargo_run["cases"])
    assert not missing, (
        f"expected behavioral checks did not run (compile error or name drift): "
        f"{sorted(missing)}\n{_tail(cargo_run)}"
    )


@pytest.mark.parametrize("check", sorted(EXPECTED_CHECKS))
def test_behavioral_check_passes(cargo_run: dict, check: str) -> None:
    """Each memo behavioral check passes — i.e. the fix removes the redundant
    re-resolution while preserving which art each device resolves to."""
    status = cargo_run["cases"].get(check)
    assert status == "ok", (
        f"behavioral check `{check}` did not pass (status={status!r}).\n"
        f"{_tail(cargo_run)}"
    )


def test_resolver_suite_stays_green(cargo_run: dict) -> None:
    """Regression guard: the resolver subsystem's pre-existing unit suite must
    still pass. These tests pin which art each device resolves to (old-schema
    depots, handed variants, standalone lookups, bundle-root precedence); a fix
    that changes resolution output rather than merely removing the redundant
    re-read breaks them.

    Check the existing subsystem tests separately from the injected checks.
    The latter have their own behavioral results and may fail independently.
    """
    assert cargo_run["summaries"], (
        f"no `test result: …` summary lines from cargo test — the subsystem "
        f"likely failed to compile.\n{_tail(cargo_run)}"
    )
    own_cases = [
        (name, status)
        for name, status in cargo_run["named_cases"]
        if name.startswith("services::assets::")
        and "::reward_memo_checks::" not in name
    ]
    assert own_cases, f"expected the resolver subsystem's own tests to run.\n{_tail(cargo_run)}"
    failures = [name for name, status in own_cases if status != "ok"]
    assert not failures, (
        f"resolver-subsystem tests failed: {failures}.\n{_tail(cargo_run)}"
    )


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v", "--tb=short"]))
