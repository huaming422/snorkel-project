## Task

An OpenLogi user notices that ordinary activity, even switching away from the app and back, makes the device cards rebuild. Each background agent snapshot triggers that rebuild. Profiling shows that it reads the art for every connected device from disk again, although the art has not changed. Some device types are affected much more than others, and the repeated work pushes rebuilds beyond the frame budget.

Find and remove the repeated art reads so consecutive rebuilds with unchanged data do not both pay for the same disk work.

Keep the visible result the same for every kind of device, including art on cards and detail headers. Preserve the existing art selection, disk formats, and device registry schema.

Art that arrives after an earlier lookup must appear without restarting OpenLogi, even when a download only partly succeeds. Clearing downloaded art must immediately return the cards to their silhouette or bundled art. A later refresh must restore the downloaded art.
