"""Behavioral verifier for the device-art resolution regression.

The desktop crate rebuilds its device list on every background snapshot,
and each rebuild resolves every connected device's art from disk again. The
behavior under test: a repeated resolve of a device whose art was already
found must be answered without going back to disk, while art that lands after
a miss or is cleared must be reflected after a settled download or cache clear.

How this is driven
------------------
The art resolver is exercised through its pre-existing, stable public surface:
``AssetResolver::new()`` plus ``resolve`` / ``resolve_registry_model``. ``new()``
reads from the per-user art directory rooted at ``$XDG_DATA_HOME`` (see
``openlogi_core::paths``), so each test points ``$XDG_DATA_HOME`` at its own
temp dir, stages a real index + depot on disk, and observes the resolver's
answers. On Linux, ``/proc/self/io`` reports bytes returned by read calls,
including cached filesystem reads. The repeated-hit checks compare that
counter around repeated lookups with unchanged files. The keyboard case also
uses process CPU ticks to detect repeated image decoding without file reads.

The crate is a binary (no library target) and the module under test is
private, so the checks are compiled as an in-crate ``#[cfg(test)]`` module
appended to the resolver source for the duration of the run, then removed. The
checks only ever touch the public API; they never name any internal field,
key type, or helper the fix may introduce. The parser selects cases by their
injected module path so other tests cannot shadow their names.

A separate in-crate GPUI test sends the production runtime's settled-sync and
clear events, then observes the device record before and after each event.
A regression guard also runs the resolver module's pre-existing unit suite.
"""

from __future__ import annotations

import os
import re
import subprocess
from pathlib import Path

import pytest


def _locate_repo() -> Path:
    """The checkout lives under `/repo`. Its directory name is the upstream
    repo name (`OpenLogi`), but the environment may export a differently-cased
    `REPO_NAME`, so resolve defensively: honor an env path that actually exists,
    then the canonical name, then the sole entry under `/repo`.
    """
    env_name = os.environ.get("REPO_NAME")
    if env_name:
        candidate = Path("/repo") / env_name
        if candidate.is_dir():
            return candidate
    canonical = Path("/repo/OpenLogi")
    if canonical.is_dir():
        return canonical
    repo_root = Path("/repo")
    if repo_root.is_dir():
        subdirs = [p for p in repo_root.iterdir() if p.is_dir()]
        if len(subdirs) == 1:
            return subdirs[0]
        # Fall back to a case-insensitive match on the canonical name.
        for p in subdirs:
            if p.name.lower() == "openlogi":
                return p
    return canonical


REPO_DIR = _locate_repo()
CRATE_DIR = REPO_DIR / "crates" / "openlogi-desktop"
# The resolver source the in-crate checks are appended to. It already ends with
# a `#[cfg(test)] mod tests;` declaration for the crate's own suite; the checks
# are added as a second, separately-named inline test module so they compile
# and run under `cargo test -p openlogi-desktop` without disturbing it.
RESOLVER_SRC = CRATE_DIR / "src" / "services" / "assets.rs"
RUNTIME_SRC = CRATE_DIR / "src" / "runtime.rs"

PKG = "openlogi-desktop"
# The resolver test filter also runs its existing unit suite.
TEST_FILTER = "services::assets"

# Unique sentinel so the injected block can be located and stripped exactly,
# even if a previous run was interrupted.
BEGIN = "// @@ASSET-RESOLUTION-CHECKS BEGIN@@"
END = "// @@ASSET-RESOLUTION-CHECKS END@@"
RUNTIME_BEGIN = "// @@ASSET-RUNTIME-CHECKS BEGIN@@"
RUNTIME_END = "// @@ASSET-RUNTIME-CHECKS END@@"


# --------------------------------------------------------------------------- #
# The in-crate behavioral checks (native Rust, public API only).
# --------------------------------------------------------------------------- #
#
# Staged on disk per check:
#   $XDG_DATA_HOME/openlogi/assets/index.json          (registry)
#   $XDG_DATA_HOME/openlogi/assets/<depot>/manifest.json
#   $XDG_DATA_HOME/openlogi/assets/<depot>/core_metadata.json
#   $XDG_DATA_HOME/openlogi/assets/<depot>/<render>.png
#
# `AssetResolver::new()` appends `assets/` to `data_dir()` =
# `$XDG_DATA_HOME/openlogi`, so the cache root it reads is exactly that path.
# Each check uses its own temp `$XDG_DATA_HOME` and sets the var at entry; the
# data dir is recomputed on every `data_dir()` call (only the dev/prod profile
# is memoized, and that stays Production here), so a per-check set is safe. The
# checks run single-threaded (`--test-threads=1`) because the env var is
# process-global.
MEMO_CHECKS_RS = r'''
// @@ASSET-RESOLUTION-CHECKS BEGIN@@
#[cfg(test)]
mod asset_resolution_checks {
    use super::{AssetResolver, ResolvedAsset};
    use openlogi_core::device::{DeviceModelInfo, DeviceTransports};
    use std::path::{Path, PathBuf};

    // --- fixture helpers (plain filesystem writes + public constructors) --- //

    /// A 24-byte PNG: signature + an `IHDR` chunk carrying only width/height,
    /// which is all the resolver reads to size a render.
    fn png_header(width: u32, height: u32) -> Vec<u8> {
        let mut bytes = vec![0x89, b'P', b'N', b'G', 0x0d, 0x0a, 0x1a, 0x0a];
        bytes.extend_from_slice(&13u32.to_be_bytes());
        bytes.extend_from_slice(b"IHDR");
        bytes.extend_from_slice(&width.to_be_bytes());
        bytes.extend_from_slice(&height.to_be_bytes());
        bytes
    }

    /// Point the per-user art directory at `home` and build a resolver that
    /// reads from it — the same path a production `AssetResolver::new()` takes,
    /// just with the base dir redirected to a test location.
    ///
    /// `set_var` is sound here: each check sets a unique dir at its own entry,
    /// the checks run single-threaded, and nothing else reads the environment
    /// concurrently.
    fn resolver_rooted_at(home: &Path) -> AssetResolver {
        #[expect(
            unsafe_code,
            reason = "redirect the per-user data base to the test dir before the \
                      resolver reads it; single-threaded, no concurrent env access"
        )]
        // SAFETY: the checks are `--test-threads=1`; this is the first thing
        // each check does, before any resolver is built, and no other thread
        // is reading the environment.
        unsafe {
            std::env::set_var("XDG_DATA_HOME", home);
        }
        AssetResolver::new()
    }

    /// The directory the resolver treats as the art cache for `home`.
    fn assets_root(home: &Path) -> PathBuf {
        home.join("openlogi").join("assets")
    }

    /// Write an `index.json` mapping one depot to one device entry.
    ///
    /// `files` lists the depot's registry file names. The standalone lookup,
    /// when a depot ships no manifest, picks its render from this list (the
    /// first known front-render name the depot declares), so a standalone depot
    /// must declare its render here; the HID++ variant path reads its render
    /// from the manifest + disk instead and is unaffected by this list.
    fn write_index(
        root: &Path,
        depot: &str,
        model_id: &str,
        model_ids: &[&str],
        display_name: &str,
        kind: &str,
        files: &[&str],
    ) {
        std::fs::create_dir_all(root).expect("create assets root");
        let ids = model_ids
            .iter()
            .map(|id| format!("{:?}", id))
            .collect::<Vec<_>>()
            .join(",");
        let file_entries = files
            .iter()
            .map(|name| format!(r#"{{"name":{name:?},"sha256":"","bytes":0}}"#))
            .collect::<Vec<_>>()
            .join(",");
        let entry = format!(
            r#"{{"modelId":{model_id:?},"modelIds":[{ids}],"displayName":{display_name:?},"type":{kind:?},"asset_path":"v1/devices/{depot}/","files":[{file_entries}]}}"#
        );
        let index = format!(r#"{{"schema_version":1,"devices":{{{depot:?}:{entry}}}}}"#);
        std::fs::write(root.join("index.json"), index).expect("write index.json");
    }

    /// Stage the MX Master 3S depot: one render per colour variant, each a
    /// distinct width so a wrong art choice would be observable. Mirrors the
    /// shape the crate's own resolver suite stages for this depot.
    fn write_variant_depot(root: &Path, variants: &[(u8, u32)]) -> PathBuf {
        let depot = "mx_master_3s";
        let dir = root.join(depot);
        std::fs::create_dir_all(&dir).expect("create depot dir");
        let devices: Vec<String> = variants
            .iter()
            .map(|(ext, _)| {
                format!(
                    r#"{{"modelId":"2b034_ext{ext}","resources":[{{"key":"device_buttons_image","src":"side_ext_{ext}.png"}}]}}"#
                )
            })
            .collect();
        std::fs::write(
            dir.join("manifest.json"),
            format!(r#"{{"devices":[{}]}}"#, devices.join(",")),
        )
        .expect("write manifest");
        std::fs::write(dir.join("core_metadata.json"), r#"{"images":[]}"#)
            .expect("write metadata");
        for (ext, width) in variants {
            std::fs::write(dir.join(format!("side_ext_{ext}.png")), png_header(*width, 10))
                .expect("write render");
        }
        dir
    }

    fn write_index_for_mx_master_3s(root: &Path) {
        write_index(
            root,
            "mx_master_3s",
            "2b043",
            &["2b043", "2b034"],
            "MX Master 3S",
            "mouse",
            // The variant path reads its render from the manifest + disk, so no
            // registry file list is needed for the HID++ lookup.
            &[],
        );
    }

    /// An MX Master 3S reporting bolt pid `b034` with the given variant byte.
    fn mx_master_3s(extended_model_id: u8) -> DeviceModelInfo {
        DeviceModelInfo {
            entity_count: 0,
            serial_number: None,
            unit_id: [0; 4],
            transports: DeviceTransports::default(),
            model_ids: [0xb034, 0, 0],
            extended_model_id,
        }
    }

    fn resolve_mx(resolver: &AssetResolver, ext: u8) -> Option<ResolvedAsset> {
        resolver.resolve(&mx_master_3s(ext), None)
    }

    /// Process rchar counts bytes returned by read calls, including worker
    /// threads and page-cache reads. Adjacent samples calibrate
    /// the counter read itself before measuring a public resolver call.
    fn read_chars() -> u64 {
        let io = std::fs::read_to_string("/proc/self/io").expect("read process I/O counter");
        io.lines()
            .find_map(|line| line.strip_prefix("rchar:").map(str::trim))
            .expect("rchar counter")
            .parse()
            .expect("numeric rchar counter")
    }

    fn cpu_ticks() -> u64 {
        let stat = std::fs::read_to_string("/proc/self/stat").expect("read process CPU time");
        let (_, fields) = stat.rsplit_once(") ").expect("process stat fields");
        let values: Vec<u64> = fields.split_whitespace().skip(11).take(2)
            .map(|value| value.parse().expect("numeric CPU ticks")).collect();
        values[0] + values[1]
    }

    fn minor_faults() -> u64 {
        let stat = std::fs::read_to_string("/proc/self/stat").expect("read process faults");
        let (_, fields) = stat.rsplit_once(") ").expect("process stat fields");
        fields.split_whitespace().nth(7).expect("minor faults").parse().expect("numeric minor faults")
    }

    fn read_work_during(resolve: impl FnOnce()) -> (u64, u64) {
        let first = (read_chars(), minor_faults());
        let second = (read_chars(), minor_faults());
        resolve();
        let third = (read_chars(), minor_faults());
        (
            (third.0 - second.0).saturating_sub(second.0 - first.0),
            (third.1 - second.1).saturating_sub(second.1 - first.1),
        )
    }

    // --------------------------- the checks ---------------------------- //

    /// Core regression: a repeated resolve of unchanged, already-found art
    /// does not read its manifest, metadata or render again. The files remain
    /// present so a design that detects external changes is also permitted.
    #[test]
    fn repeated_found_art_avoids_io() {
        let home = tempfile::tempdir().expect("temp home");
        let root = assets_root(home.path());
        write_index_for_mx_master_3s(&root);
        write_variant_depot(&root, &[(2, 100)]);

        let resolver = resolver_rooted_at(home.path());
        let found = resolve_mx(&resolver, 2).expect("depot is on disk");

        let mut second = None;
        let mut third = None;
        let (read_bytes, page_faults) = read_work_during(|| {
            second = resolve_mx(&resolver, 2);
            third = resolve_mx(&resolver, 2);
            for _ in 0..38 {
                assert_eq!(resolve_mx(&resolver, 2), Some(found.clone()));
            }
        });
        assert_eq!(second, Some(found.clone()), "a repeated resolve keeps the same art");
        assert_eq!(third, Some(found), "another unchanged resolve keeps the same art");
        assert!(read_bytes <= 8, "unchanged art was read again: {read_bytes} bytes");
        assert!(page_faults <= 16, "unchanged art caused repeated mapped-file page faults: {page_faults}");
    }

    /// A repeated standalone lookup keeps its resolved art without another read.
    #[test]
    fn repeated_standalone_art_avoids_io() {
        let home = tempfile::tempdir().expect("temp home");
        let root = assets_root(home.path());
        write_index(
            &root,
            "litra_glow",
            "8c900",
            &[],
            "Litra Glow",
            "ILLUMINATION_LIGHT",
            // No manifest in this depot, so the standalone lookup picks the
            // render from the registry file list.
            &["front.png"],
        );
        let depot = root.join("litra_glow");
        std::fs::create_dir_all(&depot).expect("create depot dir");
        std::fs::write(depot.join("front.png"), png_header(396, 396)).expect("write front");

        let resolver = resolver_rooted_at(home.path());
        let found = resolver
            .resolve_registry_model("8c900")
            .expect("depot is on disk");

        let mut second = None;
        let mut third = None;
        let (read_bytes, page_faults) = read_work_during(|| {
            second = resolver.resolve_registry_model("8c900");
            third = resolver.resolve_registry_model("8c900");
            for _ in 0..38 {
                assert_eq!(resolver.resolve_registry_model("8c900"), Some(found.clone()));
            }
        });
        assert_eq!(second, Some(found.clone()), "a repeated standalone resolve keeps the same art");
        assert_eq!(third, Some(found), "another unchanged standalone resolve keeps the same art");
        assert!(read_bytes <= 8, "standalone art was read again: {read_bytes} bytes");
        assert!(page_faults <= 16, "unchanged standalone art caused repeated mapped-file page faults: {page_faults}");
    }

    /// A one-entry memo misses on every card when two connected devices
    /// alternate. Both answers and the aggregate read work must hold.
    #[test]
    fn alternating_devices_avoid_repeated_io() {
        let home = tempfile::tempdir().expect("temp home");
        let root = assets_root(home.path());
        std::fs::create_dir_all(&root).expect("assets root");
        let index = r#"{"schema_version":1,"devices":{"litra_glow":{"modelId":"8c900","modelIds":[],"displayName":"Litra Glow","type":"ILLUMINATION_LIGHT","asset_path":"v1/devices/litra_glow/","files":[{"name":"front.png","sha256":"","bytes":0}]},"litra_beam":{"modelId":"8c901","modelIds":[],"displayName":"Litra Beam","type":"ILLUMINATION_LIGHT","asset_path":"v1/devices/litra_beam/","files":[{"name":"front.png","sha256":"","bytes":0}]}}}"#;
        std::fs::write(root.join("index.json"), index).expect("index");
        for (depot, width) in [("litra_glow", 396), ("litra_beam", 512)] {
            let dir = root.join(depot);
            std::fs::create_dir_all(&dir).expect("depot");
            std::fs::write(dir.join("front.png"), png_header(width, 396)).expect("render");
        }
        let resolver = resolver_rooted_at(home.path());
        let glow = resolver.resolve_registry_model("8c900").expect("glow art");
        let beam = resolver.resolve_registry_model("8c901").expect("beam art");
        let (read_bytes, page_faults) = read_work_during(|| {
            for _ in 0..40 {
                assert_eq!(resolver.resolve_registry_model("8c900"), Some(glow.clone()));
                assert_eq!(resolver.resolve_registry_model("8c901"), Some(beam.clone()));
            }
        });
        assert!(read_bytes <= 8, "alternating unchanged art was reread: {read_bytes} bytes");
        assert!(page_faults <= 16, "alternating unchanged art caused page faults: {page_faults}");
    }

    #[test]
    fn two_standalone_devices_keep_distinct_art() {
        let home = tempfile::tempdir().expect("temp home");
        let root = assets_root(home.path());
        std::fs::create_dir_all(&root).expect("assets root");
        let index = r#"{"schema_version":1,"devices":{"litra_glow":{"modelId":"8c900","modelIds":[],"displayName":"Litra Glow","type":"ILLUMINATION_LIGHT","asset_path":"v1/devices/litra_glow/","files":[{"name":"front.png","sha256":"","bytes":0}]},"litra_beam":{"modelId":"8c901","modelIds":[],"displayName":"Litra Beam","type":"ILLUMINATION_LIGHT","asset_path":"v1/devices/litra_beam/","files":[{"name":"front.png","sha256":"","bytes":0}]}}}"#;
        std::fs::write(root.join("index.json"), index).expect("index");
        for (depot, width) in [("litra_glow", 396), ("litra_beam", 512)] {
            let dir = root.join(depot);
            std::fs::create_dir_all(&dir).expect("depot");
            std::fs::write(dir.join("front.png"), png_header(width, 396)).expect("render");
        }
        let resolver = resolver_rooted_at(home.path());
        let glow = resolver.resolve_registry_model("8c900").expect("first art");
        let beam = resolver.resolve_registry_model("8c901").expect("second art");
        assert_eq!((glow.png_width, beam.png_width), (396, 512));
        assert_eq!(glow.image_path, root.join("litra_glow/front.png"));
        assert_eq!(beam.image_path, root.join("litra_beam/front.png"));
    }

    #[test]
    fn standalone_and_hid_lookup_keep_distinct_resources() {
        let home = tempfile::tempdir().expect("temp home");
        let root = assets_root(home.path());
        write_index(&root, "mx_master_3s", "2b043", &["2b034"], "MX Master 3S", "mouse", &["front.png"]);
        let dir = write_variant_depot(&root, &[(2, 100)]);
        std::fs::write(dir.join("front.png"), png_header(300, 10)).expect("standalone render");
        let resolver = resolver_rooted_at(home.path());
        let hid = resolve_mx(&resolver, 2).expect("HID art");
        let standalone = resolver.resolve_registry_model("2b043").expect("registry art");
        assert_eq!(hid.image_path, dir.join("side_ext_2.png"));
        assert_eq!(standalone.image_path, dir.join("front.png"));
        assert_eq!((hid.png_width, standalone.png_width), (100, 300));
    }

    #[test]
    fn keyboard_repeat_avoids_disk_work() {
        let home = tempfile::tempdir().expect("temp home");
        let root = assets_root(home.path());
        write_index(&root, "keyboard_fixture", "2b043", &["2b034"], "Keyboard", "keyboard", &[]);
        let dir = root.join("keyboard_fixture");
        std::fs::create_dir_all(&dir).expect("depot");
        std::fs::write(dir.join("manifest.json"), r#"{"devices":[{"modelId":"2b034_ext2","resources":[{"key":"device_buttons_image","src":"side_ext_2.png"}]}]}"#).expect("manifest");
        std::fs::write(dir.join("core_metadata.json"), r#"{"images":[]}"#).expect("metadata");
        let mut render = image::RgbaImage::from_pixel(512, 512, image::Rgba([20, 20, 20, 255]));
        render.put_pixel(256, 256, image::Rgba([0, 0, 0, 0]));
        render.save(dir.join("side_ext_2.png")).expect("render");
        let resolver = resolver_rooted_at(home.path());
        let first = resolve_mx(&resolver, 2).expect("keyboard art");
        assert_eq!(first.image_path, dir.join("side_ext_2.png"));
        assert!(first.glow.is_some(), "keyboard fixture enters the glow decode path");
        let mut second = None;
        let mut third = None;
        let cpu_start = cpu_ticks();
        let (read_bytes, page_faults) = read_work_during(|| {
            second = resolve_mx(&resolver, 2);
            third = resolve_mx(&resolver, 2);
            for _ in 0..38 {
                assert_eq!(resolve_mx(&resolver, 2), Some(first.clone()));
            }
        });
        let repeated_cpu_ticks = cpu_ticks().saturating_sub(cpu_start);
        assert!(repeated_cpu_ticks <= 2, "unchanged keyboard art repeated expensive decoding: {repeated_cpu_ticks} CPU ticks");
        assert_eq!(second, Some(first.clone()));
        assert_eq!(third, Some(first));
        assert!(read_bytes <= 8, "unchanged keyboard art was read again: {read_bytes} bytes");
        assert!(page_faults <= 16, "unchanged keyboard art caused repeated mapped-file page faults: {page_faults}");
    }

    #[test]
    fn legacy_art_format_still_resolves() {
        let home = tempfile::tempdir().expect("temp home");
        let root = assets_root(home.path());
        write_index_for_mx_master_3s(&root);
        let dir = root.join("mx_master_3s");
        std::fs::create_dir_all(&dir).expect("depot");
        std::fs::write(dir.join("metadata.json"), r#"{"images":[]}"#).expect("legacy metadata");
        std::fs::write(dir.join("front.png"), png_header(144, 72)).expect("legacy render");
        let resolver = resolver_rooted_at(home.path());
        let art = resolve_mx(&resolver, 2).expect("legacy art");
        assert_eq!(art.image_path, dir.join("front.png"));
        assert_eq!((art.png_width, art.png_height), (144, 72));
    }

    /// Art arriving after a miss is visible to a refreshed resolver.
    #[test]
    fn depot_landing_after_miss_is_found() {
        let home = tempfile::tempdir().expect("temp home");
        let root = assets_root(home.path());
        write_index_for_mx_master_3s(&root);

        let resolver = resolver_rooted_at(home.path());
        assert_eq!(
            resolve_mx(&resolver, 2),
            None,
            "nothing is on disk yet, so the first resolve misses"
        );

        write_variant_depot(&root, &[(2, 100)]);
        let refreshed = resolver_rooted_at(home.path());
        assert!(
            resolve_mx(&refreshed, 2).is_some(),
            "a refreshed resolver must find landed art"
        );
    }

    /// Two colour variants of one depot must each keep resolving to their own
    /// render. A wrong shared answer would serve one variant the
    /// other's answer. The distinct widths make a collision observable.
    #[test]
    fn colour_variants_remembered_apart() {
        let home = tempfile::tempdir().expect("temp home");
        let root = assets_root(home.path());
        write_index_for_mx_master_3s(&root);
        let dir = write_variant_depot(&root, &[(2, 100), (12, 200)]);

        let resolver = resolver_rooted_at(home.path());
        let graphite = resolve_mx(&resolver, 2).expect("graphite resolves");
        let pale_grey = resolve_mx(&resolver, 12).expect("pale grey resolves");

        assert_eq!(graphite.image_path, dir.join("side_ext_2.png"));
        assert_eq!(pale_grey.image_path, dir.join("side_ext_12.png"));
        assert_eq!(
            (graphite.png_width, pale_grey.png_width),
            (100, 200),
            "each variant must keep its own render, not share one resolved answer"
        );
    }

    /// A fresh lookup after removal returns the visible fallback.
    #[test]
    fn fresh_resolver_observes_removed_art() {
        let home = tempfile::tempdir().expect("temp home");
        let root = assets_root(home.path());
        write_index_for_mx_master_3s(&root);
        let dir = write_variant_depot(&root, &[(2, 100)]);

        let first = resolver_rooted_at(home.path());
        assert!(resolve_mx(&first, 2).is_some(), "the depot is on disk");

        std::fs::remove_dir_all(&dir).expect("remove the depot");
        let second = resolver_rooted_at(home.path());
        assert_eq!(
            resolve_mx(&second, 2),
            None,
            "a resolver built after the files are gone must fall back, not serve a stale find"
        );
    }
}
// @@ASSET-RESOLUTION-CHECKS END@@
'''

# --------------------------------------------------------------------------- #
# Harness: inject the checks, run cargo, parse, always clean up.
# --------------------------------------------------------------------------- #

# This second in-crate module lives beside the production event handlers. It
# observes AppState records, rather than the resolver's storage strategy.
# Constructor and settled-event signatures differ between the pinned base and
# the reference patch; the fixture supplies the matching call at injection
# time without requiring either signature from candidate solutions.
RUNTIME_CHECKS_RS = r'''
// @@ASSET-RUNTIME-CHECKS BEGIN@@
#[cfg(test)]
mod asset_transition_checks {
    use super::*;
    use gpui::{AppContext as _, TestAppContext};
    use openlogi_core::config::Config;
    use openlogi_core::device::{DeviceKind, RawDeviceAddress};
    use std::cell::RefCell;
    use std::rc::Rc;

    fn art_width(cx: &gpui::App) -> Option<u32> {
        AppState::try_read(cx).expect("live app state").devices()[0]
            .asset.as_ref().map(|art| art.png_width)
    }

    fn put_index(root: &std::path::Path) {
        std::fs::create_dir_all(root).expect("asset root");
        std::fs::write(root.join("index.json"),
            r#"{"schema_version":1,"devices":{"litra_glow":{"modelId":"8c900","modelIds":[],"displayName":"Litra Glow","type":"ILLUMINATION_LIGHT","asset_path":"v1/devices/litra_glow/","files":[{"name":"front.png","sha256":"","bytes":0}]}}}"#)
            .expect("index");
    }

    fn put_art(root: &std::path::Path) {
        let depot = root.join("litra_glow");
        std::fs::create_dir_all(&depot).expect("depot");
        let mut png = vec![0x89, b'P', b'N', b'G', 0x0d, 0x0a, 0x1a, 0x0a];
        png.extend_from_slice(&13u32.to_be_bytes());
        png.extend_from_slice(b"IHDR");
        png.extend_from_slice(&396u32.to_be_bytes());
        png.extend_from_slice(&396u32.to_be_bytes());
        std::fs::write(depot.join("front.png"), png).expect("render");
    }

    #[gpui::test]
    fn partial_sync_clear_and_refresh_repaint_live_art(cx: &mut TestAppContext) {
        let home = tempfile::tempdir().expect("temp home");
        #[expect(unsafe_code, reason = "single-threaded test redirects per-user art root")]
        unsafe { std::env::set_var("XDG_DATA_HOME", home.path()); }
        let root = home.path().join("openlogi/assets");
        put_index(&root);
        let device = StandaloneDevice {
            address: RawDeviceAddress {
                vendor_id: 0x046d, product_id: 0xc900,
                usage_page: 0xff43, usage_id: 0x0202,
                identity: "serial:runtime-art-test".into(),
            },
            display_name: "Litra Glow".into(),
            manufacturer: Some("Logi".into()),
            serial_number: Some("runtime-art-test".into()),
            unit_id: [0; 4],
            kind: DeviceKind::Light,
            online: true,
            capabilities: None,
            light_capabilities: None,
            driver_id: "litra".into(),
            registry_model_id: Some("8c900".into()),
        };
        let result = Rc::new(RefCell::new(Vec::new()));
        let collected = result.clone();
        cx.update(|app| {
            let resolver = assets::AssetResolver::new();
            let (commands, _receiver) = tokio::sync::mpsc::unbounded_channel();
            let state = app.new(|_| AppState::with_runtime(
                Config::ephemeral(), &[], &[device.clone()], &resolver, &[],
                ConfigPersistence::MemoryOnly, commands,
            ));
            AppState::set_global(state, app);
            let swr_runtime: Arc<dyn swr_core::Runtime> = Arc::new(GpuiRuntime::new(app));
            let swr = SwrClient::builder()
                .default_options(assets::queries::default_options())
                .build(swr_runtime);
            app.spawn(async move |async_app| {
                let (sync_tx, _sync_rx) = tokio::sync::mpsc::unbounded_channel();
                let mut runtime = __CONSTRUCT_RUNTIME__;
                runtime.standalone = vec![device];
                runtime.refresh_devices(async_app);
                collected.borrow_mut().push(async_app.update(|app| art_width(app)));
                put_art(&root);
                __PARTIAL_SYNC__;
                collected.borrow_mut().push(async_app.update(|app| art_width(app)));
                runtime.on_asset_command(AssetCommand::ClearCache, async_app);
                collected.borrow_mut().push(async_app.update(|app| art_width(app)));
                put_index(&root);
                put_art(&root);
                __SUCCESS_SYNC__;
                collected.borrow_mut().push(async_app.update(|app| art_width(app)));
            }).detach();
        });
        cx.run_until_parked();
        assert_eq!(&*result.borrow(), &[None, Some(396), None, Some(396)],
            "live records must show landed art after a partial failure, fall back on clear, and recover on refresh");
    }
}
// @@ASSET-RUNTIME-CHECKS END@@
'''

_RESULT_LINE = re.compile(
    r"^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed", re.MULTILINE
)
_CASE_LINE = re.compile(r"^test (\S+) \.\.\. (ok|FAILED|ignored)", re.MULTILINE)

# The behavioral checks that must be present and must pass on a correct fix.
EXPECTED_CHECKS = {
    "repeated_found_art_avoids_io",
    "repeated_standalone_art_avoids_io",
    "alternating_devices_avoid_repeated_io",
    "two_standalone_devices_keep_distinct_art",
    "standalone_and_hid_lookup_keep_distinct_resources",
    "keyboard_repeat_avoids_disk_work",
    "legacy_art_format_still_resolves",
    "depot_landing_after_miss_is_found",
    "colour_variants_remembered_apart",
    "fresh_resolver_observes_removed_art",
    "partial_sync_clear_and_refresh_repaint_live_art",
}


def _strip_injection(text: str, begin: str = BEGIN, end_marker: str = END) -> str:
    """Remove any previously-injected block (idempotent cleanup)."""
    start = text.find(begin)
    if start == -1:
        return text
    end = text.find(end_marker)
    if end == -1:
        return text[:start].rstrip() + "\n"
    end += len(end_marker)
    cleaned = text[:start].rstrip() + "\n" + text[end:].lstrip("\n")
    return cleaned


@pytest.fixture(scope="module")
def cargo_run() -> dict:
    """Inject the in-crate checks, run them under `cargo test`, then restore
    the source verbatim. Returns parsed per-case results + the summary lines.
    """
    original = RESOLVER_SRC.read_text()
    runtime_original = RUNTIME_SRC.read_text()
    constructor = re.search(r"fn new\s*\(\s*cams:.*?\)\s*->\s*Self", runtime_original, re.S)
    settled = re.search(r"fn on_sync_finished\s*\(.*?\)", runtime_original, re.S)
    assert constructor and settled, "runtime event API not found"
    has_resolver_arg = "AssetResolver" in constructor.group()
    has_success_arg = settled.group().count(",") > 1
    construct = "Runtime::new(vec![], sync_tx, swr, resolver)" if has_resolver_arg else "Runtime::new(vec![], sync_tx, swr)"
    partial = "runtime.on_sync_finished(false, async_app)" if has_success_arg else "runtime.on_sync_finished(async_app)"
    success = "runtime.on_sync_finished(true, async_app)" if has_success_arg else "runtime.on_sync_finished(async_app)"
    runtime_checks = (RUNTIME_CHECKS_RS
        .replace("__CONSTRUCT_RUNTIME__", construct)
        .replace("__PARTIAL_SYNC__", partial)
        .replace("__SUCCESS_SYNC__", success))
    RESOLVER_SRC.write_text(_strip_injection(original).rstrip() + "\n" + MEMO_CHECKS_RS)
    RUNTIME_SRC.write_text(_strip_injection(runtime_original, RUNTIME_BEGIN, RUNTIME_END).rstrip() + "\n" + runtime_checks)
    try:
        resolver_proc = subprocess.run(
            [
                "cargo",
                "test",
                "-p",
                PKG,
                TEST_FILTER,
                "--",
                "--test-threads=1",
            ],
            capture_output=True,
            text=True,
            timeout=1500,
            cwd=str(REPO_DIR),
            check=False,
        )
        runtime_proc = subprocess.run(
            ["cargo", "test", "-p", PKG, "runtime::asset_transition_checks", "--", "--test-threads=1"],
            capture_output=True, text=True, timeout=1500, cwd=str(REPO_DIR), check=False,
        )
    finally:
        # Restore the source exactly as it was, whatever happened.
        RESOLVER_SRC.write_text(original)
        RUNTIME_SRC.write_text(runtime_original)

    combined = resolver_proc.stdout + "\n" + resolver_proc.stderr + "\n" + runtime_proc.stdout + "\n" + runtime_proc.stderr
    named_cases = _CASE_LINE.findall(combined)
    cases = {
        name.rsplit("::", 1)[-1]: status
        for name, status in named_cases
        if "::asset_resolution_checks::" in name or "::asset_transition_checks::" in name
    }
    return {
        "returncode": (resolver_proc.returncode, runtime_proc.returncode),
        "cases": cases,
        "named_cases": named_cases,
        "summaries": _RESULT_LINE.findall(combined),
        "stdout": resolver_proc.stdout + "\n" + runtime_proc.stdout,
        "stderr": resolver_proc.stderr + "\n" + runtime_proc.stderr,
    }


def _tail(run: dict) -> str:
    return (
        f"--- cargo exit {run['returncode']} ---\n"
        f"--- last stdout ---\n{run['stdout'][-3000:]}\n"
        f"--- last stderr ---\n{run['stderr'][-2000:]}"
    )


def test_art_checks_compiled_and_ran(cargo_run: dict) -> None:
    """The in-crate checks compiled and produced per-case results.

    A compile failure (e.g. a source change broke the resolver's public
    surface) surfaces here as zero discovered cases rather than a silent pass.
    """
    missing = EXPECTED_CHECKS - set(cargo_run["cases"])
    assert not missing, (
        f"expected behavioral checks did not run (compile error or name drift): "
        f"{sorted(missing)}\n{_tail(cargo_run)}"
    )


@pytest.mark.parametrize("check", sorted(EXPECTED_CHECKS))
def test_behavioral_check_passes(cargo_run: dict, check: str) -> None:
    """Each art behavior check passes — i.e. the fix removes the redundant
    re-resolution while preserving which art each device resolves to."""
    status = cargo_run["cases"].get(check)
    assert status == "ok", (
        f"behavioral check `{check}` did not pass (status={status!r}).\n"
        f"{_tail(cargo_run)}"
    )


def test_resolver_suite_stays_green(cargo_run: dict) -> None:
    """Regression guard: the resolver subsystem's pre-existing unit suite must
    still pass. These tests pin which art each device resolves to (old-schema
    depots, handed variants, standalone lookups, bundle-root precedence); a fix
    that changes resolution output rather than merely removing the redundant
    re-read breaks them.

    Check the existing subsystem tests separately from the injected checks.
    The latter have their own behavioral results and may fail independently.
    """
    assert cargo_run["summaries"], (
        f"no `test result: …` summary lines from cargo test — the subsystem "
        f"likely failed to compile.\n{_tail(cargo_run)}"
    )
    own_cases = [
        (name, status)
        for name, status in cargo_run["named_cases"]
        if name.startswith("services::assets::")
        and "::asset_resolution_checks::" not in name
    ]
    required_cases = {
        "resolves_old_schema_depot_on_disk",
        "resolves_depot_whose_metadata_is_only_named_by_the_manifest",
        "resolves_left_handed_lift_for_business_b033_ext6",
        "resolves_standalone_registry_model_without_synthetic_hidpp_info",
        "standalone_registry_lookup_does_not_cross_model_depots",
        "unsafe_standalone_manifest_filename_is_rejected",
        "standalone_resolution_prefers_the_first_read_root",
    }
    observed = {name.rsplit("::", 1)[-1] for name, _ in own_cases}
    assert required_cases <= observed, (
        f"resolver regression cases missing: {sorted(required_cases - observed)}.\n{_tail(cargo_run)}"
    )
    failures = [name for name, status in own_cases if status != "ok"]
    assert not failures, (
        f"resolver-subsystem tests failed: {failures}.\n{_tail(cargo_run)}"
    )


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v", "--tb=short"]))
