#!/usr/bin/env bash
# test-setup.sh — sourced before the verifier runs. Runs with network.
# Pre-builds the openlogi-desktop test target so the verifier's cargo
# invocation doesn't pay the full cold compile inside its own time budget.
# The image (image/Dockerfile block 10) already compiled this test binary at
# the base commit into the shared CARGO_TARGET_DIR, so on an unmodified tree
# this is a near-instant relink; after source edits it recompiles
# only the changed units. The pinned stable toolchain
# (rust-toolchain.toml at /repo/OpenLogi) is already materialized in the image.
set -euo pipefail

cd /repo/OpenLogi

# Pre-warm: build the openlogi-desktop test binary (the crate the verifier
# exercises). Offline-first: the image baked the full dependency closure and
# the compiled test target, so this resolves from the warm cache with no
# network. If a cache entry is somehow missing, retry online once.
if ! cargo test -p openlogi-desktop --no-run --locked --offline > /tmp/test-setup.log 2>&1; then
    echo "offline pre-warm missed the cache; retrying with network" >&2
    cargo test -p openlogi-desktop --no-run --locked > /tmp/test-setup.log 2>&1 \
        || { tail -80 /tmp/test-setup.log >&2; exit 1; }
fi
tail -3 /tmp/test-setup.log || true
