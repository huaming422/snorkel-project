#!/usr/bin/env bash
# Sourced (not exec'd) by the harbor runner so any env vars set here stay live
# for the verifier subprocess.
#
# This repo's internal unit tests run directly against `packages/typegpu/src`
# (the `unplugin-typegpu` vite plugin + the package's own vitest.config.mts
# resolve source without a build, since TEST_BUILT is unset). So the agent's
# edits under src/ are visible to the verifier with no rebuild step.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/TypeGPU}"
export REPO_DIR
cd "$REPO_DIR"

# Sanity check: vitest must be resolvable from the workspace root. A failure
# here points at a corrupted node_modules from the image build — reinstalling
# offline from the warmed pnpm store is cheaper than a confusing "vitest not
# found" later.
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest binary missing from node_modules/.bin/." \
         "Reinstalling from the frozen lockfile." >&2
    pnpm install --frozen-lockfile --offline
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
