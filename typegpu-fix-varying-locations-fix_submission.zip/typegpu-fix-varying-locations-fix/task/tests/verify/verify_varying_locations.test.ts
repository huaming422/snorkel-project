// @ts-nocheck
// Behavioral verifier for typegpu-fix-varying-locations.
//
// Runs in the repo's internal test tier (packages/typegpu/tests/internal), the
// same tier that already exercises the varying-location machinery. It is tested
// THROUGH pre-existing, stable public and internal interfaces only:
//   - tgpu.vertexFn / tgpu.fragmentFn        (describe shader stages)
//   - root.createRenderPipeline              (wire the two stages together)
//   - tgpu.resolve([pipeline])               (read the generated WGSL string)
//   - root.unwrap(pipeline)                  (force resolution / surface throws)
//   - withLocations / matchUpVaryingLocations (pre-existing exported helpers,
//                                             already covered by the repo's own
//                                             internal tests; the fix modifies
//                                             them but did not invent them)
//
// Assertions deliberately key on STABLE SUBSTRINGS of the generated WGSL
// (`@location(n) <name>` occurrences), NOT on byte-exact inline snapshots. For
// thrown errors they assert only that the unfixed behavior is refused: the
// duplicate-collision checks assert a throw with NO message-content constraint,
// and the single cross-stage-mismatch check asserts the two conflicting
// location numbers + the shared key (the one error whose numbers are the
// behavioral signal), never the stage names or exact prose. This admits valid
// alternative implementations that rename internal variables, reorganise the
// assignment loop, or word the error prose differently, while still rejecting
// the unfixed behavior.

import { describe, expect } from 'vitest';
import { it } from 'typegpu-testing-utility';
import { tgpu, d } from 'typegpu';
import { withLocations } from '../../src/core/function/ioSchema.ts';

// Count non-overlapping occurrences of a literal-ish pattern in the WGSL.
function countMatches(code, re) {
  return (code.match(re) ?? []).length;
}

// Invoke `fn`, require that it throws, and return the thrown error's message.
function messageOfThrow(fn) {
  try {
    fn();
  } catch (err) {
    return String(err && err.message !== undefined ? err.message : err);
  }
  throw new Error('expected the call to throw, but it returned normally');
}

describe('varying locations match across stages', () => {
  it('shelled vertex + shelled fragment: shared varyings share a location', ({
    root,
  }) => {
    const vertex = tgpu.vertexFn({
      out: {
        pos: d.builtin.position,
        color: d.vec4f,
        normal: d.location(6, d.vec4f),
      },
    })`/* vertex impl */`;
    const fragment = tgpu.fragmentFn({
      in: { color: d.location(5, d.vec4f), normal: d.vec4f },
      out: d.vec4f,
    })`{ return in.color + in.normal; }`;

    const pipeline = root.createRenderPipeline({
      vertex,
      fragment,
      targets: { format: 'rgba8unorm' },
    });

    const code = tgpu.resolve([pipeline]);
    // Each shared varying appears with the SAME @location on both the
    // vertex-output struct and the fragment-input struct.
    expect(countMatches(code, /@location\(5\) color/g)).toBe(2);
    expect(countMatches(code, /@location\(6\) normal/g)).toBe(2);
  });

  it('shelled vertex + shellless fragment: shared varyings share a location', ({
    root,
  }) => {
    const vertex = tgpu.vertexFn({
      out: {
        pos: d.builtin.position,
        color: d.vec4f,
        normal: d.location(6, d.vec4f),
      },
    })`/* vertex impl */`;

    const pipeline = root.createRenderPipeline({
      vertex,
      fragment: ({ color, normal }) => {
        'use gpu';
        return color + normal;
      },
      targets: { format: 'rgba8unorm' },
    });

    const code = tgpu.resolve([pipeline]);
    expect(countMatches(code, /@location\(6\) normal/g)).toBe(2);
    expect(countMatches(code, /@location\(0\) color/g)).toBe(2);
  });

  it('shellless vertex + shelled fragment: shared varyings share a location', ({
    root,
  }) => {
    const fragment = tgpu.fragmentFn({
      in: { color: d.location(5, d.vec4f), normal: d.vec4f },
      out: d.vec4f,
    })`{ return in.color + in.normal; }`;

    const pipeline = root.createRenderPipeline({
      vertex: () => {
        'use gpu';
        return { $position: d.vec4f(0, 0, 0, 1), color: d.vec4f(1), normal: d.vec4f(1) };
      },
      fragment,
      targets: { format: 'rgba8unorm' },
    });

    const code = tgpu.resolve([pipeline]);
    expect(countMatches(code, /@location\(5\) color/g)).toBe(2);
    // The fragment-in-only / shellless-vertex keys still receive a location on
    // both structs (the auto-assign must span both stages, not just vertex-out).
    expect(countMatches(code, /@location\(0\) normal/g)).toBe(2);
  });

  it('shellless vertex + shelled fragment, reversed key order: locations still line up', ({
    root,
  }) => {
    const fragment = tgpu.fragmentFn({
      in: { color: d.vec4f, normal: d.vec4f },
      out: d.vec4f,
    })`{ return in.color + in.normal; }`;

    const pipeline = root.createRenderPipeline({
      vertex: () => {
        'use gpu';
        return { $position: d.vec4f(0, 0, 0, 1), normal: d.vec4f(1), color: d.vec4f(2) };
      },
      fragment,
      targets: { format: 'rgba8unorm' },
    });

    const code = tgpu.resolve([pipeline]);
    expect(countMatches(code, /@location\(0\) color/g)).toBe(2);
    expect(countMatches(code, /@location\(1\) normal/g)).toBe(2);
  });
});

describe('explicit location 0 is honored', () => {
  it('withLocations keeps an inferred location of 0 instead of auto-numbering it away', () => {
    expect(
      withLocations(
        {
          a: d.vec4f,
          b: d.vec4f,
        },
        { b: 0 },
      ),
    ).toStrictEqual({
      a: d.location(1, d.vec4f),
      b: d.location(0, d.vec4f),
    });
  });

  it('a varying pinned to location 0 survives into the resolved WGSL on both structs', ({
    root,
  }) => {
    const fragment = tgpu.fragmentFn({
      in: { color: d.vec4f, normal: d.location(0, d.vec4f) },
      out: d.vec4f,
    })`{ return in.color + in.normal; }`;

    const pipeline = root.createRenderPipeline({
      vertex: () => {
        'use gpu';
        return { $position: d.vec4f(0, 0, 0, 1), color: d.vec4f(1), normal: d.vec4f(1) };
      },
      fragment,
      targets: { format: 'rgba8unorm' },
    });

    const code = tgpu.resolve([pipeline]);
    expect(countMatches(code, /@location\(0\) normal/g)).toBe(2);
    expect(countMatches(code, /@location\(1\) color/g)).toBe(2);
  });
});

describe('custom locations are reserved before auto-assignment', () => {
  it('an auto-numbered member skips a slot reserved for a later keyed member', () => {
    // `c` is pinned to 1 via the locations map. `a` and `b` are auto-numbered.
    // Without up-front reservation of the map value, `b` would also take 1 and
    // collide with `c`; with reservation it must skip to 2.
    expect(
      withLocations(
        {
          a: d.vec4f,
          b: d.vec4f,
          c: d.vec4f,
        },
        { c: 1 },
      ),
    ).toStrictEqual({
      a: d.location(0, d.vec4f),
      b: d.location(2, d.vec4f),
      c: d.location(1, d.vec4f),
    });
  });
});

describe('a shellless vertex input is numbered from its own attribute layout', () => {
  it('vertex-in uses layout numbering (0) while the shared varying keeps its custom location', ({
    root,
  }) => {
    const vertexLayout = tgpu.vertexLayout(d.arrayOf(d.vec4f));
    const fragment = tgpu.fragmentFn({
      in: { color: d.location(5, d.vec4f) },
      out: d.vec4f,
    })`{ return in.color; }`;

    const pipeline = root.createRenderPipeline({
      attribs: { color: vertexLayout.attrib },
      vertex: ({ color }) => {
        'use gpu';
        return { $position: d.vec4f(), color };
      },
      fragment,
      targets: { format: 'rgba8unorm' },
    });

    const code = tgpu.resolve([pipeline]);
    // The shared varying keeps its custom location 5 on both the vertex-output
    // and fragment-input structs...
    expect(countMatches(code, /@location\(5\) color/g)).toBe(2);
    // ...while the vertex-INPUT struct is numbered from its own attribute
    // layout (location 0), appearing exactly once.
    expect(countMatches(code, /@location\(0\) color/g)).toBe(1);
  });
});

describe('a final duplicate location collision is rejected', () => {
  // These two cases drive the post-assignment duplicate scan that the fix adds.
  // Before the fix, the `locations` map values were neither reserved nor
  // re-checked after assignment, so a member whose final location collides with
  // a map-assigned slot was emitted SILENTLY (two members on the same
  // @location -> invalid WGSL). The fix must refuse any such final collision.
  //
  // We assert only that the collision throws -- not on the error prose -- so an
  // implementation that words its message differently (or reorganises the
  // assignment loop) is still accepted, while the unfixed silent-duplicate
  // behavior is rejected. (The pre-fix explicit-duplicate early check is NOT
  // exercised here: a map-involved collision is the path the fix newly guards.)

  it('an explicit member location that collides with a map-assigned slot throws', () => {
    // `foo` is pinned to 1; the map also assigns `bar` to 1. Both end at
    // location 1 -> must be refused. Unfixed, this is emitted silently.
    expect(() =>
      withLocations(
        { foo: d.location(1, d.vec4f), bar: d.vec4f },
        { bar: 1 },
      ),
    ).toThrow();
  });

  it('two map-assigned members on the same slot throws', () => {
    // The map assigns both `a` and `b` to 2 -> a final collision the fix must
    // refuse. Unfixed, both are emitted at location 2 with no error.
    expect(() =>
      withLocations({ a: d.vec4f, b: d.vec4f }, { a: 2, b: 2 }),
    ).toThrow();
  });
});

describe('a genuine cross-stage location mismatch is rejected', () => {
  it('resolving a pipeline whose shared varying disagrees on location throws', ({
    root,
  }) => {
    const vertexMain = tgpu.vertexFn({
      out: {
        foo: d.vec3f,
        bar: d.location(0, d.vec3f),
      },
    })(() => ({
      foo: d.vec3f(),
      bar: d.vec3f(),
    }));

    const fragmentMain = tgpu.fragmentFn({
      in: {
        bar: d.location(1, d.vec3f),
      },
      out: d.vec4f,
    })(() => d.vec4f());

    const pipeline = root.createRenderPipeline({
      vertex: vertexMain,
      fragment: fragmentMain,
      targets: { format: 'r8unorm' },
    });

    const message = messageOfThrow(() => tgpu.resolve([pipeline]));
    // The error names the offending key and both conflicting location numbers
    // (0 on vertex output, 1 on fragment input). The alternative-implementation
    // contract guarantees the key + both numbers but NOT the stage names, so we
    // do not assert "vertexMain"/"fragmentMain" (that would reject a fair
    // re-wording). The throw itself already separates this from the pre-fix
    // behavior, which only warned and emitted invalid WGSL.
    expect(message).toMatch(/bar/);
    expect(message).toMatch(/\b0\b/);
    expect(message).toMatch(/\b1\b/);
  });
});
