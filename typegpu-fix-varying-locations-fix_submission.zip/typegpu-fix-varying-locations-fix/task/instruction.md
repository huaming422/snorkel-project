## Task

our render pipelines are generating broken shader code. when a vertex function and a fragment function share a named varying, the emitted WGSL sometimes gives that varying one `@location` on the vertex-output side and a different one on the fragment-input side, so the two stages no longer line up and the shader won't link.

same area, a couple more. pinning a varying to an explicit location of 0 sometimes gets ignored, and it lands in some auto-numbered slot instead of staying at 0. and when a vertex output and a fragment input genuinely disagree on a varying's location, we just log a warning and hand back the invalid WGSL anyway; that should fail loudly instead of shipping a shader we know won't link.

it happens with both the templated functions and the `'use gpu'` closure form. this used to hold together; now the locations are plainly unreliable.

can you dig in and make varying-location handling for render pipelines dependable again? it's all in how locations get assigned and matched across the two stages, not the rest of codegen.
