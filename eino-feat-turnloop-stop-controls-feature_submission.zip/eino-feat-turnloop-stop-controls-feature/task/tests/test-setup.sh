# Sourced by the Senior SWE-Bench verifier runner before tests execute.
#
# Inherits the image's Go toolchain (Go 1.23.12) and the module cache warmed in
# the Dockerfile. The adk package is pure Go with no CGO or external services,
# so setup is minimal: export a deterministic toolchain environment and make
# sure the cache dirs exist.
set -euo pipefail

cd /repo/eino

export GOFLAGS="-mod=mod"
export CGO_ENABLED="1"
export GOTOOLCHAIN="local"
export GOMAXPROCS="${GOMAXPROCS:-4}"
export GOMODCACHE="${GOMODCACHE:-/opt/cache/go}"
export GOCACHE="${GOCACHE:-/opt/cache/go-build}"
mkdir -p "$GOMODCACHE" "$GOCACHE"

# Belt-and-suspenders: the image already baked the full module cache at the base
# commit, so resolve offline first (GOPROXY=off); only if that fails fall back to
# a logged online fetch. Normally a warm-cache no-op.
if ! GOPROXY=off go mod download; then
    echo "test-setup.sh: offline module resolution failed; retrying online" >&2
    go mod download || true
fi

echo "test-setup.sh: Go toolchain ready."
