// No-regression concurrency guard for the stop/cleanup path.
//
// This file owns the pass_to_pass half of the concurrency criterion: it drives
// many Push / Stop / Run / Wait calls concurrently on the loop and asserts the
// whole cycle stays coherent and race-free. It is compiled with the race
// detector (the verifier runner invokes `go test -race`, CGO enabled), so any
// data race on the shared stop/cleanup state surfaces here as a failure.
//
// Everything is observed through the PRE-EXISTING, STABLE public surface only
// (NewTurnLoop / TurnLoopConfig / Push / Stop / Wait and the Agent interface).
// It NEVER references task-introduced symbols (the new stop options, the new
// exit-state fields, the late-item accessor) — those are implementation choices
// whose own concurrency safety is exercised end-to-end by the validation
// stories, which also run under -race. This guard therefore passes on an
// unmodified tree and on any correct solution, and fails any change that
// regresses the existing concurrent Push/Stop/Run behaviour into a race.
package adk_test

import (
	"context"
	"sync"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"

	"github.com/cloudwego/eino/adk"
	"github.com/cloudwego/eino/schema"
)

// verifyMockAgent is a minimal self-contained Agent built only on the public
// adk surface, so this external test package never depends on package-internal
// test helpers.
type verifyMockAgent struct {
	name string
}

func (a *verifyMockAgent) Name(_ context.Context) string        { return a.name }
func (a *verifyMockAgent) Description(_ context.Context) string { return "verify mock agent" }

func (a *verifyMockAgent) Run(_ context.Context, _ *adk.AgentInput, _ ...adk.AgentRunOption) *adk.AsyncIterator[*adk.AgentEvent] {
	iter, gen := adk.NewAsyncIteratorPair[*adk.AgentEvent]()
	go func() {
		defer gen.Close()
		gen.Send(&adk.AgentEvent{Output: &adk.AgentOutput{}})
	}()
	return iter
}

// TestVerifyConcurrentStopPushRaceFree drives concurrent producers (Push) and
// stoppers (Stop) against a running loop and asserts the loop terminates
// cleanly. Run under -race it catches any regression that makes the existing
// concurrent stop/cleanup path racy.
func TestVerifyConcurrentStopPushRaceFree(t *testing.T) {
	for iter := 0; iter < 25; iter++ {
		ctx := context.Background()

		loop := adk.NewTurnLoop(adk.TurnLoopConfig[string]{
			GenInput: func(_ context.Context, _ *adk.TurnLoop[string], items []string) (*adk.GenInputResult[string], error) {
				return &adk.GenInputResult[string]{
					Input:    &adk.AgentInput{Messages: []adk.Message{schema.UserMessage(items[0])}},
					Consumed: items,
				}, nil
			},
			PrepareAgent: func(_ context.Context, _ *adk.TurnLoop[string], _ []string) (adk.Agent, error) {
				return &verifyMockAgent{name: "verify"}, nil
			},
			OnAgentEvents: func(_ context.Context, _ *adk.TurnContext[string], events *adk.AsyncIterator[*adk.AgentEvent]) error {
				for {
					if _, ok := events.Next(); !ok {
						break
					}
				}
				return nil
			},
		})

		loop.Run(ctx)

		var wg sync.WaitGroup
		// Concurrent producers.
		for p := 0; p < 4; p++ {
			wg.Add(1)
			go func() {
				defer wg.Done()
				for i := 0; i < 8; i++ {
					loop.Push("item")
				}
			}()
		}
		// Concurrent stoppers.
		for s := 0; s < 3; s++ {
			wg.Add(1)
			go func() {
				defer wg.Done()
				loop.Stop()
			}()
		}
		wg.Wait()

		// Ensure the loop is stopped and the exit state is retrievable without a race.
		loop.Stop()
		done := make(chan struct{})
		go func() {
			loop.Wait()
			close(done)
		}()
		select {
		case <-done:
		case <-time.After(10 * time.Second):
			t.Fatal("loop did not terminate after concurrent Stop/Push")
		}
	}

	assert.True(t, true)
}
