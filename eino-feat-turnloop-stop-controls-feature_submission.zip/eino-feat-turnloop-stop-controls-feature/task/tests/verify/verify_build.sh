#!/usr/bin/env bash
# Compilation + vet gate for the stop/cleanup control extension.
#
# This is the static half of the verifier: it asserts that the package the
# implementation must keep coherent still builds and vets at the task toolchain,
# with CGO enabled (the behavioural half runs the suite under the race detector,
# which requires CGO). It imports no task-introduced names, so it is
# alternative-implementation-safe and passes on an unmodified tree as well as on
# a correct solution (pass_to_pass).
set -euo pipefail

export GOFLAGS="${GOFLAGS:--mod=mod}"
export CGO_ENABLED="${CGO_ENABLED:-1}"
export GOTOOLCHAIN="${GOTOOLCHAIN:-local}"
export GOMODCACHE="${GOMODCACHE:-/opt/cache/go}"
export GOCACHE="${GOCACHE:-/opt/cache/go-build}"

cd /repo/eino

# The feature is a pure in-package change under adk/. Both the package and its
# dependents must stay compilable, and vet must stay clean.
go build ./adk/...
go vet ./adk/
