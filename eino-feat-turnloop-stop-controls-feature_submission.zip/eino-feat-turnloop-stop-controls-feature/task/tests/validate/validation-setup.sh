#!/usr/bin/env bash
# Validation environment setup for the TurnLoop stop-controls feature.
#
# Runs after tests/test-setup.sh has prepared the Go toolchain and before the
# validation agent starts writing its test file. The adk package is pure Go
# with no services; we only re-export the toolchain environment so the go-test
# driver inherits a deterministic configuration.
set -euo pipefail

export GOFLAGS="${GOFLAGS:--mod=mod}"
export CGO_ENABLED="${CGO_ENABLED:-1}"
export GOTOOLCHAIN="${GOTOOLCHAIN:-local}"
export GOMAXPROCS="${GOMAXPROCS:-4}"
export GOMODCACHE="${GOMODCACHE:-/opt/cache/go}"
export GOCACHE="${GOCACHE:-/opt/cache/go-build}"
mkdir -p "$GOMODCACHE" "$GOCACHE"

# Resolve offline first (closure baked at base commit); logged online fallback.
if ! ( cd /repo/eino && GOPROXY=off go mod download ); then
    echo "validation-setup.sh: offline module resolution failed; retrying online" >&2
    ( cd /repo/eino && go mod download ) || true
fi

echo "validation-setup.sh: Go toolchain ready."
