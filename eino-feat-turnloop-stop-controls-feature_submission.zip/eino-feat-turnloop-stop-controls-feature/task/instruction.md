## Task

We want to add a few caller-facing controls to `TurnLoop[T]`'s stop and cleanup
path in the `adk` package: recovering items that were pushed after a loop had
already stopped, reporting on what happened to the checkpoint during cleanup,
stopping a loop without persisting a checkpoint, and tagging a stop with a
business reason.

Concretely, add these to the public surface:

- `WithSkipCheckpoint` and `WithStopCause` as new options for `Stop`.
- `StopCause`, `Checkpointed`, `CheckpointErr`, and `TakeLateItems` on
  `TurnLoopExitState[T]`.
- `StopCause` on `TurnContext[T]`.

The behavior each of these must have is described in the requirements below.

This path is concurrency-sensitive: stops, pushes, and a running agent can all
overlap, so the new behavior has to stay race-free. Everything you need is
already in the repo.

## User stories / requirements

- Given a stopped loop, items pushed after it has already stopped are recoverable: each late push reports that it was not accepted, and the exit state's late-item accessor returns exactly those items in order. The accessor is idempotent — calling it again returns the same items — and once it has been called the loop is sealed, so any further push panics. If the accessor is never called, the late items are dropped and the items handled before the stop still surface normally.
- Given a loop with a checkpoint store, the exit state reports whether a checkpoint save was attempted during cleanup, independently of why the loop exited. A save is reported as attempted even when it fails, and the failure is carried as a separate checkpoint error rather than being folded into the exit reason. No save is attempted when there is no store or when the loop exits because of an error rather than an explicit stop.
- Given a stop that asks to skip checkpoint persistence, the loop saves no checkpoint and reports that none was attempted, and when the store supports deletion any stale checkpoint is removed. The choice is sticky: once any stop on a loop asks to skip, a later stop that omits the request must not re-enable checkpointing.
- Given a stop that carries a business reason, that reason is surfaced on the exit state and, mid-stop, through the per-turn context once the loop's stop signal is observed. When several stops supply a reason, the first non-empty one wins; when no reason is supplied, the surfaced reason is empty.
- Given a checkpoint store that does not support deletion, when a stop would otherwise remove a stale checkpoint the removal is a no-op: the existing checkpoint is left intact and non-nil rather than being corrupted by writing an empty value through the normal save path. When the store does support deletion, the stale checkpoint is removed instead.
