// @ts-nocheck
//
// Pass-to-pass regression guard for the codemod's v1->v2 migration.
//
// Drives the PUBLIC `run(getMigration('v1-to-v2')!, { targetDir })` entry
// point over a realistic v1 source file written to a temp dir, and asserts
// the migration's PRE-EXISTING rewrites still happen: import-path rewriting,
// symbol renames, the McpServer API migration, handler registration, and the
// context-object rewrite. This catches a change that breaks or reorders the
// existing transform pipeline while adding the new completable-nesting
// handling.
//
// It reads no task-introduced symbol and imports no new transform, so any
// valid implementation of the new feature passes: the new transform is just
// one more entry in the ordered list, and none of the assertions below touch
// `completable`. Mirrors the repo's own `test/integration.test.ts`.

import { mkdtempSync, writeFileSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { describe, it, expect, afterEach } from 'vitest';

import { getMigration } from '../src/migrations/index';
import { run } from '../src/runner';

const migration = getMigration('v1-to-v2')!;

let tempDir: string | undefined;

afterEach(() => {
    if (tempDir) {
        rmSync(tempDir, { recursive: true, force: true });
        tempDir = undefined;
    }
});

describe('v1-to-v2 migration pipeline (regression guard)', () => {
    it('still applies the pre-existing transforms to a realistic v1 file', () => {
        tempDir = mkdtempSync(path.join(tmpdir(), 'mcp-codemod-verify-'));
        const input = [
            `import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';`,
            `import { CallToolRequestSchema, ErrorCode } from '@modelcontextprotocol/sdk/types.js';`,
            `import { StreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/streamableHttp.js';`,
            ``,
            `const server = new McpServer({ name: 'test', version: '1.0' });`,
            `const transport = new StreamableHTTPServerTransport({});`,
            ``,
            `server.tool('greet', 'Say hello', { name: z.string() }, async ({ name }, extra) => {`,
            `    const s = extra.signal;`,
            `    return { content: [{ type: 'text', text: name }] };`,
            `});`,
            ``,
            `server.setRequestHandler(CallToolRequestSchema, async (request, extra) => {`,
            `    const id = extra.requestId;`,
            `    return { content: [] };`,
            `});`,
            ``,
            `const code = ErrorCode.InvalidParams;`,
            `const timeout = ErrorCode.RequestTimeout;`,
            ``
        ].join('\n');

        writeFileSync(path.join(tempDir, 'server.ts'), input);

        const result = run(migration, { targetDir: tempDir });

        expect(result.filesChanged).toBe(1);
        expect(result.totalChanges).toBeGreaterThan(0);

        const output = readFileSync(path.join(tempDir, 'server.ts'), 'utf8');

        // Import paths rewritten to v2 packages; no v1 sdk specifier survives.
        expect(output).toContain('@modelcontextprotocol/server');
        expect(output).toContain('@modelcontextprotocol/node');
        expect(output).not.toContain('@modelcontextprotocol/sdk');

        // Symbol renames + body references updated.
        expect(output).toContain('NodeStreamableHTTPServerTransport');
        expect(output).toContain('new NodeStreamableHTTPServerTransport({})');
        expect(output).not.toMatch(/(?<!Node)StreamableHTTPServerTransport/);
        expect(output).toContain('ProtocolErrorCode.InvalidParams');
        expect(output).toContain('SdkErrorCode.RequestTimeout');

        // McpServer API migration.
        expect(output).toContain('registerTool');
        expect(output).not.toMatch(/server\.tool\(/);

        // Handler registration rewritten to the method-string form.
        expect(output).toContain("setRequestHandler('tools/call'");
        expect(output).not.toContain('CallToolRequestSchema');

        // Context-object rewrites.
        expect(output).toContain('ctx.mcpReq.signal');
        expect(output).toContain('ctx.mcpReq.id');
        expect(output).not.toContain('extra');
    }, 120_000);

    it('maintains the critical transform ordering dependencies', () => {
        const ids = migration.transforms.map((t) => t.id);
        // Import rewriting must run before symbol/API transforms, and the
        // mock-paths transform stays last. These invariants pre-exist the new
        // handling; the new transform slots in without disturbing them.
        expect(ids.indexOf('imports')).toBeLessThan(ids.indexOf('symbols'));
        expect(ids.indexOf('symbols')).toBeLessThan(ids.indexOf('removed-apis'));
        expect(ids.indexOf('mcpserver-api')).toBeLessThan(ids.indexOf('context'));
        expect(ids.at(-1)).toBe('mock-paths');
    }, 60_000);
});
