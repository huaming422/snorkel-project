#!/usr/bin/env bash
# test-setup.sh — environment bootstrap for the verifier.
# Sourced (not exec'd) by the harbor verifier runner so env vars and
# anything else stay alive for vitest.
#
# Idempotent. The Dockerfile already pre-installs pnpm deps at the base
# commit; we re-run install as a guard only if an agent erased
# node_modules. The @modelcontextprotocol/codemod vitest suite imports
# transforms straight from src/, so no build step is required.

set -e

REPO_DIR="${REPO_DIR:-/repo/typescript-sdk}"
cd "$REPO_DIR"

node --version
pnpm --version

# Install workspace deps if an agent erased them (no-op otherwise).
if [ ! -d "node_modules/.pnpm" ]; then
    echo "[test-setup] pnpm install (offline, frozen)..."
    pnpm install --frozen-lockfile --ignore-scripts --offline 2>&1 | tail -10
fi

# Make node_modules/.bin available for vitest invocations.
export PATH="$REPO_DIR/node_modules/.bin:$PATH"

echo "[test-setup] ready: $REPO_DIR (node=$(node --version), pnpm=$(pnpm --version))"
