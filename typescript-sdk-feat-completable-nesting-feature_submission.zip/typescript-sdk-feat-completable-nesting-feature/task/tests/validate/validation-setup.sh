#!/usr/bin/env bash
# validation-setup.sh — environment bootstrap for the validation agent's
# story scripts. Runs AFTER tests/test-setup.sh and BEFORE the validation
# orchestrator dispatches the validation agent. Idempotent.
#
# The @modelcontextprotocol/codemod package is pure TypeScript that vitest
# runs straight from src/ (its own suite imports `../src/...`), so there is
# NO build/dist step to guard — unlike workspace packages that must be
# pre-built. This script only (a) confirms the toolchain is reachable,
# (b) replays the offline frozen install if an agent erased node_modules,
# and (c) loudly smoke-checks that the public source entry points the
# stories import through (`run` in src/runner.ts, `getMigration` in
# src/migrations/index.ts) are present, so a missing/renamed entry point
# fails here with a clear message instead of as an opaque vitest import
# error inside every story.

set -e

REPO_DIR="${REPO_DIR:-/repo/typescript-sdk}"
cd "$REPO_DIR"

# Sanity: Node + pnpm + vitest are reachable.
node --version
pnpm --version
npx vitest --version

# Re-install workspace deps if an agent erased them (offline, frozen replay).
if [ ! -d "node_modules/.pnpm" ]; then
    echo "[validation-setup] re-installing pnpm deps (offline, frozen)..."
    pnpm install --frozen-lockfile --ignore-scripts --offline 2>&1 | tail -10
fi

# Make node_modules/.bin available for vitest invocations.
export PATH="$REPO_DIR/node_modules/.bin:$PATH"

# Loud smoke-check: the stories import the codemod's PUBLIC entry points
# straight from src/. Confirm those source files exist before any story runs.
node -e '
const path = require("path");
const fs = require("fs");
const repoDir = process.env.REPO_DIR || "/repo/typescript-sdk";
const base = path.join(repoDir, "packages/codemod/src");
const required = [
  path.join(base, "runner.ts"),
  path.join(base, "migrations/index.ts"),
  path.join(base, "types.ts"),
];
const missing = required.filter((p) => !fs.existsSync(p));
if (missing.length > 0) {
  console.error("[validation-setup] Missing codemod source entry points:", missing.join(", "));
  process.exit(1);
}
console.log("[validation-setup] codemod source entry points OK (runner, migrations/index, types)");
'

echo "[validation-setup] ready: $REPO_DIR (node=$(node --version), pnpm=$(pnpm --version))"
