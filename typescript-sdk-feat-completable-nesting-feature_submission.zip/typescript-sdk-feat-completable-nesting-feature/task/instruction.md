## Task

The codemod package has a gap in its v1-to-v2 migration. `completable()` attaches
tab-completion callbacks to a schema used for prompt arguments and resource-template
variables, and a lot of v1 code writes that schema with the optional wrapper on the inside
of the call. In v2 the way a completable schema combines with an outer optional changed, so
those calls no longer expose their completions once migrated. The migration passes them
through exactly as written, so a server it migrates quietly stops advertising completions
for those arguments.

We want the migration to cover the completable optional-nesting case too. Keep it scoped to
this one concern: inside the codemod package, leaving manifest and package-file handling and
the other transforms alone.

The package already has settled patterns for how a transform is written, registered, and
ordered, and a convention for marking a spot the tool cannot safely finish on its own. Reuse
those.

Check your work with the codemod vitest suite (`pnpm --filter @modelcontextprotocol/codemod
test`); transforms import straight from source, so there is no build step.

## User stories / requirements

- When the migration hits a completable schema written with the optional wrapper on the inside of the call, it rewrites the call so the optional wrapping moves to the outside. The migrated server then keeps advertising completions for that argument instead of silently dropping them once migrated.
- A completable schema that already works under v2 comes through the migration exactly as written, with no edit made to it and no action-required marker left in the code. Over-eagerly rewriting a schema that was already correct would change working code.
- When a completable schema is nested in a way the tool cannot safely rewrite, the migration leaves an action-required marker rather than altering or breaking the call. For the one shape whose fix is unambiguous (a schema whose tail makes it both nullable and optional), the guidance names the concrete corrected form.
- When a completable schema is handed to the call by reference (a named schema defined elsewhere, not inline), the migration cannot see whether it carries the problematic optional wrapper, so it leaves the call as written and adds a single advisory note per file, however many by-reference calls the file contains.
- The optional-nesting rewrite happens as a normal part of running the full v1-to-v2 migration over a project, not only when exercised on its own. A server migrated end to end from the old import path comes out with its import rewritten to the v2 package and the completable call corrected to the optional-outside arrangement.
