## Task

A lot of people install CLIs and runtimes globally with mise and then forget about them, so those tools drift months behind because `mise upgrade` never gets run. I'd like a per-tool `auto_update` option in the global config that tells mise to keep that tool fresh by itself. Right before such a tool starts, whether from a shim or from `mise x`, mise should move it to the newest version its pin allows and then run that. `auto_update = true` turns this on with mise's default check interval, and a duration string such as `"12h"` sets the tool's own.

## User stories / requirements

- Launching an opted-in global tool installs and runs the newest version its pin allows, from a shim or `mise x`. An exact pin never moves, and a second launch inside the interval runs what's there without checking again. An interval under an hour counts as one hour, with a warning that it was raised.
- Opting in only works from the global config. The same setting in a project's or a local config file does nothing, and when a project sets a version of the tool itself, running the tool there leaves that version in place.
- No update check happens while offline, under `--locked`, or during shell `hook-env` evaluation, and the tool still runs as usual.
- If the update fails, mise prints a warning naming the tool and runs the version that's already installed. `mise doctor` then reports that the tool's last update failed, and drops that report once the tool no longer opts in.
- The update leaves the project alone. Inside an activated shell it doesn't see the project's `[env]` and works from the variables the shell had before mise activated. A global lockfile entry for the tool follows the update, a project lockfile stays byte-for-byte the same, and `--no-hooks` keeps the update's hooks off too.
- If a post-install step of one tool's update launches another opted-in tool that's also due, everything still finishes promptly instead of hanging.
- The option can be `true`, `false` or a duration like `"6h"`. Any other value is refused with an error. `mise use -g --tool-option auto_update=…` puts it in the global config, and the option survives when that entry is rewritten later.
