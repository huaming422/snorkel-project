"""Harness plumbing for the subprocess driver: an isolated mise environment.

The stories drive the freshly-built `mise` CLI binary against the repo's local
`dummy` / `needs-dummy` asdf plugins, which work fully offline. Each scenario
needs its own throwaway HOME with its own config / data / state / cache dirs so
that a scenario's first update check is always due and never leaks into the next.
That setup mirrors the repo's own `e2e/run_test` `within_isolated_env` helper and
is pure test plumbing (it is NOT part of the behaviour under test), so it lives
here. Stories import `MiseEnv` and assert on what the CLI prints and installs.

This file exists because every validation_spec.toml requires a test_harness.py
alongside it; stories may import these helpers but need not.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
from pathlib import Path

# The binary is (re)built by validation-setup.sh. The image sets
# CARGO_TARGET_DIR; fall back to the in-tree target dir, then to PATH.
REPO_ROOT = "/repo/mise"
_CARGO_TARGET_DIR = os.environ.get("CARGO_TARGET_DIR", f"{REPO_ROOT}/target")


def _resolve_mise_bin() -> str:
    candidate = os.path.join(_CARGO_TARGET_DIR, "debug", "mise")
    if os.path.exists(candidate):
        return candidate
    found = shutil.which("mise")
    if found:
        return found
    # Return the expected path anyway so the error message is actionable.
    return candidate


MISE_BIN: str = _resolve_mise_bin()

# The two asdf plugins the behavioural tests rely on. Both ship with the repo
# and serve their versions offline. `dummy` offers 1.0.0, 1.1.0, 2.0.0; its
# installed binary prints ``This is Dummy X.Y.Z!``. `needs-dummy` is used by the
# nested-update scenario.
PLUGIN_SOURCES = {
    "dummy": f"{REPO_ROOT}/test/data/plugins/dummy",
    "needs-dummy": f"{REPO_ROOT}/test/data/plugins/needs-dummy",
}


class MiseEnv:
    """A throwaway, fully-isolated mise environment backed by a temp HOME.

    Mirrors ``e2e/run_test``: a private HOME with its own MISE_* dirs, the
    `dummy` / `needs-dummy` plugins symlinked into the data dir, and a minimal
    environment (built from scratch, not inherited) so nothing on the host
    machine (PATH, a stray project config, a leaked variable) changes a
    result. Use it as a context manager::

        with MiseEnv() as env:
            env.set_global_tools('dummy = { version = "1", auto_update = true }')
            env.run("install", "dummy@1.0.0")
            r = env.run("x", "--", "dummy")
            assert "This is Dummy 1.1.0!" in r.stdout
    """

    def __init__(self) -> None:
        self.root = Path(tempfile.mkdtemp(prefix="mise_story_"))
        self.home = self.root / "home"
        self.workdir = self.home / "workdir"
        self.tmpdir = self.root / "tmp"
        self.config_dir = self.home / ".config" / "mise"
        self.data_dir = self.home / ".local" / "share" / "mise"
        self.state_dir = self.home / ".local" / "state" / "mise"
        self.cache_dir = self.home / ".cache" / "mise"
        self.system_dir = self.root / "etc" / "mise"

        for d in (
            self.home,
            self.workdir,
            self.tmpdir,
            self.config_dir,
            self.data_dir,
            self.state_dir,
            self.cache_dir,
            self.system_dir,
            self.home / "bin",
        ):
            d.mkdir(parents=True, exist_ok=True)

        plugins_dir = self.data_dir / "plugins"
        plugins_dir.mkdir(parents=True, exist_ok=True)
        for name, src in PLUGIN_SOURCES.items():
            link = plugins_dir / name
            if not link.exists():
                os.symlink(src, link)

    # -- environment ------------------------------------------------------
    def base_env(self) -> dict[str, str]:
        """A minimal environment for a mise invocation (built from scratch).

        Prepends the directory holding the built binary to PATH so any `mise`
        subprocess mise itself spawns resolves to the same binary. Intentionally
        does NOT inherit the caller's environment, so a scenario controls every
        variable mise sees.
        """
        bin_dir = os.path.dirname(MISE_BIN)
        path = os.pathsep.join(
            [
                bin_dir,
                str(self.home / "bin"),
                "/usr/local/sbin",
                "/usr/local/bin",
                "/usr/sbin",
                "/usr/bin",
                "/sbin",
                "/bin",
            ]
        )
        env = {
            "HOME": str(self.home),
            "PATH": path,
            "TMPDIR": str(self.tmpdir),
            "LANG": "C.UTF-8",
            "LC_ALL": "C.UTF-8",
            "MISE_CONFIG_DIR": str(self.config_dir),
            "MISE_DATA_DIR": str(self.data_dir),
            "MISE_STATE_DIR": str(self.state_dir),
            "MISE_CACHE_DIR": str(self.cache_dir),
            "MISE_SYSTEM_DIR": str(self.system_dir),
            "MISE_TMP_DIR": str(self.tmpdir),
            "MISE_TRUSTED_CONFIG_PATHS": str(self.root),
            "MISE_YES": "1",
            "MISE_EXPERIMENTAL": "1",
            "MISE_USE_VERSIONS_HOST": "0",
            "MISE_HISTORY_NOTIFY": "0",
            # Keep cargo/rustup discoverable for any toolchain-aware codepath.
            "CARGO_HOME": os.environ.get("CARGO_HOME", "/opt/cargo"),
            "RUSTUP_HOME": os.environ.get("RUSTUP_HOME", "/opt/rustup"),
            "CARGO_TARGET_DIR": _CARGO_TARGET_DIR,
        }
        return env

    # -- config helpers ---------------------------------------------------
    def set_global_tools(self, entry: str) -> None:
        """Write a global config whose ``[tools]`` block is *entry*.

        *entry* is one or more lines of TOML that go under ``[tools]`` (e.g.
        ``dummy = { version = "1", auto_update = true }``).
        """
        self.write_global_config(f"[tools]\n{entry}\n")

    def write_global_config(self, text: str) -> None:
        (self.config_dir / "config.toml").write_text(text)

    def read_global_config(self) -> str:
        p = self.config_dir / "config.toml"
        return p.read_text() if p.exists() else ""

    def write_project_file(self, name: str, text: str) -> Path:
        """Write *name* (e.g. ``mise.toml``) into the project working dir."""
        p = self.workdir / name
        p.write_text(text)
        return p

    # -- running mise -----------------------------------------------------
    def run(
        self,
        *args: str,
        extra_env: dict[str, str] | None = None,
        cwd: Path | str | None = None,
        timeout: int = 120,
    ) -> subprocess.CompletedProcess:
        """Run ``mise <args>`` in the isolated env. Never raises on non-zero."""
        env = self.base_env()
        if extra_env:
            env.update(extra_env)
        return subprocess.run(
            [MISE_BIN, *args],
            cwd=str(cwd) if cwd else str(self.workdir),
            env=env,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )

    def run_shell(
        self,
        script: str,
        extra_env: dict[str, str] | None = None,
        cwd: Path | str | None = None,
        timeout: int = 120,
    ) -> subprocess.CompletedProcess:
        """Run a bash snippet in the isolated env with ``mise`` on PATH.

        Used by scenarios that need a real shell (activation / hooks).
        """
        env = self.base_env()
        if extra_env:
            env.update(extra_env)
        return subprocess.run(
            ["bash", "--noprofile", "--norc", "-c", script],
            cwd=str(cwd) if cwd else str(self.workdir),
            env=env,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )

    def run_exe(
        self,
        exe: Path | str,
        *args: str,
        extra_env: dict[str, str] | None = None,
        cwd: Path | str | None = None,
        timeout: int = 120,
    ) -> subprocess.CompletedProcess:
        """Run an arbitrary executable (e.g. a generated shim) in the env."""
        env = self.base_env()
        if extra_env:
            env.update(extra_env)
        return subprocess.run(
            [str(exe), *args],
            cwd=str(cwd) if cwd else str(self.workdir),
            env=env,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )

    # -- observations -----------------------------------------------------
    def installed_versions(self, tool: str = "dummy") -> str:
        """Return the stdout of ``mise ls --installed <tool>``.

        Scenarios check membership (e.g. ``"1.1.0" in env.installed_versions()``)
        to see which versions are on disk without depending on any internal
        state-file layout.
        """
        return self.run("ls", "--installed", tool).stdout

    def reset_dummy(self) -> None:
        """Uninstall every dummy version and install a clean 1.0.0.

        The baseline most scenarios start from: exactly 1.0.0 present, so a
        subsequent in-range update has a newer version (1.1.0) to move to.
        """
        self.run("uninstall", "dummy", "--all")
        self.run("install", "dummy@1.0.0")

    def fresh_cache_dir(self) -> str:
        """Return the path to a brand-new, empty cache directory in this env.

        A few scenarios need a version lookup to actually run against the
        plugin (and, under the plugin's failure switch, actually fail)
        instead of being served from the warm cache that an earlier
        ``install`` / baseline step populated. Pointing ``MISE_CACHE_DIR`` at a
        fresh empty directory for that one invocation forces the cold lookup,
        mirroring how ``e2e/run_test`` isolates a cache-cold check.
        """
        return tempfile.mkdtemp(prefix="mise_cache_", dir=str(self.root))

    # -- lifecycle --------------------------------------------------------
    def cleanup(self) -> None:
        shutil.rmtree(self.root, ignore_errors=True)

    def __enter__(self) -> "MiseEnv":
        return self

    def __exit__(self, *exc: object) -> None:
        self.cleanup()
