## Task

getting complaints from our RTL customers that masked text questions are broken. on phone/pattern, date, numeric, and currency masks, the field segments render in the wrong order in right-to-left surveys (Arabic, Hebrew, Persian), and the caret jumps to the wrong spot while typing, so the field is basically unusable. it's fine in left-to-right surveys.

one thing to watch while you fix that: some masks are themselves written in right-to-left script, where the template's own letters or separators or currency symbols are Arabic or Hebrew. those ones already read correctly right-to-left, so leave them be and don't force them the other way. it's only the masks built out of ordinary left-to-right pieces (like `+1 (999) 999-9999` or `dd/mm/yyyy`) that are coming out reversed.

there's a second one too: respondents on Arabic/Persian keyboards type Arabic-Indic digits into these masked fields and nothing happens. nothing shows in the field and nothing gets stored; the input just vanishes.

dig in and fix both so RTL customers can fill out masked inputs normally.
