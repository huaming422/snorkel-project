// @ts-nocheck
//
// Reward verifier for the RTL masked-input fix. Exercises the behavior purely at
// the survey-core model layer in jsdom, through pre-existing, stable public
// interfaces, exactly as the repo's own packages/survey-core/tests/mask/*.ts
// suites do:
//   - QuestionTextModel.inputStyle (getter)  -> the rendered input style object,
//     the single surface where the direction decision reaches the renderer
//   - InputElementAdapter (createArgs / beforeInputHandler / change event)
//     driving a real <input>, plus getMaskedValue / getUnmaskedValue round-trips
//
// Black-box on purpose: it never imports the helper functions the fix adds and
// never calls the new per-mask direction query by name — the direction decision
// is observed only where it surfaces to the renderer, the pre-existing
// `inputStyle` getter. So an equally valid solution that names or places its
// helpers differently, classifies scripts via a different mechanism, assembles
// the style in one combined builder, or normalizes in a shared util still
// passes. Foreign-digit and script-letter strings are built from code points so
// the file stays plain ASCII.
//
// Scope of the correctness gate (the two reported symptoms, nothing more):
//   1. A masked field hands its value a left-to-right run so the segments keep
//      their order in an RTL survey — observed as `direction: ltr` on inputStyle.
//   2. Arabic-Indic digits typed or pasted into a masked field are accepted,
//      shown and stored as ASCII, on every input path; deletions and non-digit
//      characters are left alone.
// The direction assertions check the specific style keys that matter
// (`direction`, `textAlign`, `width`) rather than the whole object, so a
// solution that also emits a valid extra bidi property (e.g. unicode-bidi) is
// not rejected. The digit-path assertions drive the real input end to end
// through the adapter and read back the element value / stored unmasked value,
// so where a solution places the normalization (adapter boundary vs. a shared
// util vs. inside the mask) does not matter as long as the behavior is right.
//
// The third correctness gate is the content-aware opt-out: a mask whose OWN
// rendered literal/affix/separator text is itself strong-RTL reads naturally
// right to left, so it must NOT be forced into an LTR run (forcing LTR there is
// objectively wrong bidi for a genuinely RTL mask). This separates a correct,
// content-aware decision from a blunt "force LTR on every masked field", which
// would reverse such a mask — so it is asserted here, on the behavior (no forced
// LTR) rather than the whole style object, with a control row proving the same
// masks keep LTR when their literals are not strong-RTL. The rubric also carries
// `strong_rtl_mask_literals_opt_out_of_forced_ltr` as a taste/quality gate; the
// verifier gates on the behavior.

import { InputElementAdapter } from "../../src/mask/input_element_adapter";
import { InputMaskNumeric } from "../../src/mask/mask_numeric";
import { InputMaskPattern } from "../../src/mask/mask_pattern";
import { InputMaskCurrency } from "../../src/mask/mask_currency";
import { InputMaskDateTime } from "../../src/mask/mask_datetime";
import { QuestionTextModel } from "../../src/question_text";

import { describe, test, expect } from "vitest";

// Spell an ASCII digit string with the Arabic-Indic (U+0660) and the extended
// Arabic-Indic (U+06F0) code blocks an Arabic / Persian keyboard produces.
const ai = (text: string): string => text.replace(/[0-9]/g, (d: string) => String.fromCharCode(0x0660 + Number(d)));
const eai = (text: string): string => text.replace(/[0-9]/g, (d: string) => String.fromCharCode(0x06F0 + Number(d)));

// Single strong right-to-left letters from two different RTL scripts (Arabic
// yeh, U+064A; Hebrew alef, U+05D0): a mask whose OWN rendered text carries such
// a letter reads naturally right to left, so it must not be forced into an LTR
// run. Two scripts keep the check on the behavior (any strong-RTL letter), not
// on one script's code block. The Arabic decimal / thousands separators
// (U+066B / U+066C) are numeric-neutral and must NOT suppress the LTR run.
const RTL_LETTER = String.fromCharCode(0x064a);
const HEB_LETTER = String.fromCharCode(0x05d0);
const AR_DECIMAL = String.fromCharCode(0x066b);
const AR_THOUSANDS = String.fromCharCode(0x066c);

// Assert the style keys that carry the fix's decision — width, direction,
// textAlign — without pinning the whole object: any additional valid CSS
// property a solution chooses to emit (e.g. unicode-bidi) is accepted. An
// `undefined` expected value asserts the key is absent.
const expectStyle = (style: any, expected: any, msg: string): void => {
  (["width", "direction", "textAlign"] as const).forEach(key => {
    expect(style[key], msg + " [" + key + "]").toBe(expected[key]);
  });
};

describe("RTL masked input direction", () => {
  // Criterion rtl_direction_ltr (fail_to_pass): a masked question hands its
  // input a left-to-right run, so the mask's field order survives inside an RTL
  // survey. Existing alignment is kept; a question with no mask stays untouched.
  test("inputStyle emits direction ltr for masks with non-RTL literals", () => {
    const q = new QuestionTextModel("q1");
    expectStyle(q.inputStyle, { width: "" }, "no mask: no direction");

    q.maskType = "pattern";
    (q.maskSettings as InputMaskPattern).pattern = "+1 (999) 999-9999";
    expectStyle(q.inputStyle, { width: "", direction: "ltr" }, "pattern with ascii literals");

    q.maskType = "datetime";
    (q.maskSettings as InputMaskDateTime).pattern = "dd/mm/yyyy";
    expectStyle(q.inputStyle, { width: "", direction: "ltr" }, "datetime with latin symbols");

    q.maskType = "numeric";
    expectStyle(q.inputStyle, { width: "", textAlign: "right", direction: "ltr" }, "numeric keeps its right alignment");

    q.maskType = "currency";
    expectStyle(q.inputStyle, { width: "", textAlign: "right", direction: "ltr" }, "currency keeps its right alignment");

    q.inputTextAlignment = "left";
    expectStyle(q.inputStyle, { width: "", textAlign: "left", direction: "ltr" }, "an explicit alignment wins, direction stays");
  });

  // Arabic-Indic digits and the Arabic numeric separators are numeric/neutral,
  // not strong-RTL script letters: a mask that carries them in its own literals
  // still hands its value a left-to-right run. (A classifier that mistook these
  // for strong RTL and dropped the direction would reintroduce the reversal.)
  test("foreign digit literals and arabic numeric separators still emit direction ltr", () => {
    const q = new QuestionTextModel("q1");

    q.maskType = "numeric";
    (q.maskSettings as InputMaskNumeric).decimalSeparator = AR_DECIMAL;
    (q.maskSettings as InputMaskNumeric).thousandsSeparator = AR_THOUSANDS;
    expectStyle(q.inputStyle, { width: "", textAlign: "right", direction: "ltr" }, "arabic numeric separators keep direction ltr");

    q.maskType = "pattern";
    (q.maskSettings as InputMaskPattern).pattern = ai("12") + "-" + eai("34");
    expectStyle(q.inputStyle, { width: "", direction: "ltr" }, "arabic-indic digit literals keep direction ltr");
  });

  // Criterion strong_rtl_mask_literals_opt_out_of_forced_ltr (fail_to_pass): a
  // mask whose OWN rendered literal / affix / separator text is itself strong
  // right-to-left reads naturally right to left, so the field does NOT force an
  // LTR run — its input style omits `direction` (or leaves it `auto`). This is
  // the case that separates a correct, content-aware decision from a blunt
  // "force LTR on every mask", which would reverse a genuinely RTL mask. The
  // assertion is on the behavior (no forced LTR) rather than the whole style
  // object, so a solution that instead emits an explicit `direction: "auto"` or
  // adds another valid bidi property still passes; the control row below shows
  // the same masks keep LTR when their literals are not strong-RTL, so the test
  // is not satisfiable by simply never emitting a direction.
  test("masks whose own literal text is strong-RTL do not force an LTR run", () => {
    const q = new QuestionTextModel("q1");

    // A pattern literal that is a strong-RTL letter (Arabic, then Hebrew).
    q.maskType = "pattern";
    (q.maskSettings as InputMaskPattern).pattern = "999 " + RTL_LETTER + " 999";
    expect((q.inputStyle as any).direction, "pattern with an arabic literal does not force ltr").not.toBe("ltr");
    (q.maskSettings as InputMaskPattern).pattern = "999 " + HEB_LETTER + " 999";
    expect((q.inputStyle as any).direction, "pattern with a hebrew literal does not force ltr").not.toBe("ltr");

    // A numeric mask whose separator is a strong-RTL letter.
    q.maskType = "numeric";
    (q.maskSettings as InputMaskNumeric).decimalSeparator = RTL_LETTER;
    expect((q.inputStyle as any).direction, "numeric with a strong-rtl separator does not force ltr").not.toBe("ltr");

    // A currency mask whose prefix / suffix affix is strong-RTL.
    q.maskType = "currency";
    (q.maskSettings as InputMaskCurrency).prefix = RTL_LETTER;
    (q.maskSettings as InputMaskCurrency).suffix = "";
    expect((q.inputStyle as any).direction, "currency with a strong-rtl prefix does not force ltr").not.toBe("ltr");
    (q.maskSettings as InputMaskCurrency).prefix = "";
    (q.maskSettings as InputMaskCurrency).suffix = HEB_LETTER;
    expect((q.inputStyle as any).direction, "currency with a strong-rtl suffix does not force ltr").not.toBe("ltr");

    // Control: the same mask types, with non-RTL literals, still force LTR — so
    // the opt-out above is a real classification, not a mask type that never
    // emits a direction.
    const control = new QuestionTextModel("q2");
    control.maskType = "pattern";
    (control.maskSettings as InputMaskPattern).pattern = "999 x 999";
    expect((control.inputStyle as any).direction, "pattern with an ascii literal still forces ltr").toBe("ltr");
    control.maskType = "currency";
    (control.maskSettings as InputMaskCurrency).prefix = "$";
    (control.maskSettings as InputMaskCurrency).suffix = "";
    expect((control.inputStyle as any).direction, "currency with a latin prefix still forces ltr").toBe("ltr");
  });
});

describe("Arabic-Indic digit normalization", () => {
  // Criterion arabic_indic_digits (fail_to_pass): Arabic-Indic and extended
  // Arabic-Indic digits typed into a masked field are accepted, displayed as
  // ASCII, and stored as ASCII, on BOTH the per-keystroke insert path and the
  // paste / autofill change fallback; a deletion and non-digit characters pass
  // through unchanged.
  test("the insert path accepts foreign digits across pattern, datetime and numeric", () => {
    const input = document.createElement("input");
    document.body.appendChild(input);
    const type = (text: string) => {
      text.split("").forEach(ch => adapter.beforeInputHandler({ data: ch, inputType: "insertText", target: input, preventDefault: (): void => {} }));
    };

    const pattern = new InputMaskPattern();
    pattern.pattern = "+1 (999) 999-9999";
    let adapter = new InputElementAdapter(pattern, input, "");
    input.focus();
    input.setSelectionRange(0, 0);
    type(ai("555"));
    expect(input.value, "pattern: half typed shows ascii").toBe("+1 (555) ___-____");
    expect(input.selectionStart, "pattern: the caret follows the ascii value").toBe(9);
    type(eai("1234567"));
    expect(input.value, "pattern: complete").toBe("+1 (555) 123-4567");
    expect(pattern.getUnmaskedValue(input.value), "pattern: stored value is ascii").toBe("15551234567");
    adapter.dispose();

    const datetime = new InputMaskDateTime();
    datetime.pattern = "mm/dd/yyyy";
    adapter = new InputElementAdapter(datetime, input, "");
    input.setSelectionRange(0, 0);
    type(ai("12252000"));
    expect(input.value, "datetime: complete").toBe("12/25/2000");
    expect(datetime.getUnmaskedValue(input.value), "datetime: stored iso value").toBe("2000-12-25");
    adapter.dispose();

    const numeric = new InputMaskNumeric();
    adapter = new InputElementAdapter(numeric, input, "");
    input.setSelectionRange(0, 0);
    type(ai("1234.5"));
    expect(input.value, "numeric: grouped").toBe("1,234.5");
    expect(numeric.getUnmaskedValue(input.value), "numeric: stored number").toBe(1234.5);
    adapter.dispose();

    input.remove();
  });

  test("the change fallback normalizes a pasted or autofilled value", () => {
    const input = document.createElement("input");
    const pattern = new InputMaskPattern();
    pattern.pattern = "999-99-99";
    let adapter = new InputElementAdapter(pattern, input, "");
    input.focus();
    input.value = ai("12345") + eai("67");
    input.dispatchEvent(new Event("change"));
    expect(input.value, "pattern via paste").toBe("123-45-67");
    adapter.dispose();

    const datetime = new InputMaskDateTime();
    datetime.pattern = "mm/dd/yyyy";
    adapter = new InputElementAdapter(datetime, input, "");
    input.value = ai("12/25/2000");
    input.dispatchEvent(new Event("change"));
    expect(input.value, "datetime with separators via paste").toBe("12/25/2000");
    adapter.dispose();

    const numeric = new InputMaskNumeric();
    adapter = new InputElementAdapter(numeric, input, "");
    input.value = ai("123456.78");
    input.dispatchEvent(new Event("change"));
    expect(input.value, "numeric via paste").toBe("123,456.78");
    adapter.dispose();

    input.remove();
  });

  // End-to-end through the adapter's real event handler onto a live <input>, so
  // the normalization seam (adapter boundary vs. a shared util vs. inside the
  // mask) is not pinned: a typed foreign digit lands as ASCII, a non-digit
  // keystroke passes through untouched (and is then rejected by the digit mask,
  // leaving the value unchanged), and a backward deletion removes a character.
  test("a deletion removes a character and a non-digit keystroke passes through unchanged", () => {
    const input = document.createElement("input");
    document.body.appendChild(input);
    const pattern = new InputMaskPattern();
    pattern.pattern = "999";
    const adapter = new InputElementAdapter(pattern, input, "");
    const send = (data: string | null, inputType: string) =>
      adapter.beforeInputHandler({ data, inputType, target: input, preventDefault: (): void => {} });

    input.focus();
    input.setSelectionRange(0, 0);

    send(ai("5"), "insertText");
    send(eai("7"), "insertText");
    expect(input.value, "typed foreign digits land as ascii").toBe("57_");

    // A non-digit character is handed through normalization unchanged, then the
    // digit-only mask declines it, so the field is untouched.
    send(RTL_LETTER, "insertText");
    expect(input.value, "a non-digit keystroke does not enter a digit-only field").toBe("57_");

    // A backward deletion (null event data) passes through and removes the
    // character before the caret.
    input.setSelectionRange(2, 2);
    send(null, "deleteContentBackward");
    expect(input.value, "a deletion removes the character before the caret").toBe("5__");

    adapter.dispose();
    input.remove();
  });
});

describe("no regression", () => {
  // Criterion preserve_existing_masking (pass_to_pass): the base masking still
  // round-trips ASCII correctly, numeric / currency keep their right alignment,
  // and removing the mask clears the mask-specific style (no leaked direction on
  // an unmasked input). Holds before and after the fix.
  test("ascii masking still round-trips across mask types", () => {
    const input = document.createElement("input");
    document.body.appendChild(input);
    const type = (text: string) => {
      text.split("").forEach(ch => adapter.beforeInputHandler({ data: ch, inputType: "insertText", target: input, preventDefault: (): void => {} }));
    };

    const pattern = new InputMaskPattern();
    pattern.pattern = "+1 (999) 999-9999";
    let adapter = new InputElementAdapter(pattern, input, "");
    input.focus();
    input.setSelectionRange(0, 0);
    type("5551234567");
    expect(input.value, "pattern ascii").toBe("+1 (555) 123-4567");
    expect(pattern.getUnmaskedValue(input.value), "pattern ascii stored").toBe("15551234567");
    adapter.dispose();

    const numeric = new InputMaskNumeric();
    expect(numeric.getMaskedValue(1234.5), "numeric masked").toBe("1,234.5");
    expect(numeric.getUnmaskedValue("1,234.5"), "numeric unmasked").toBe(1234.5);

    input.remove();
  });

  test("alignment is preserved and removing the mask clears the mask style", () => {
    const q = new QuestionTextModel("q1");

    q.maskType = "numeric";
    expect((q.inputStyle as any).textAlign, "numeric right-aligns").toBe("right");

    q.maskType = "currency";
    expect((q.inputStyle as any).textAlign, "currency right-aligns").toBe("right");

    q.maskType = "none";
    expectStyle(q.inputStyle, { width: "" }, "no mask leaves no direction or alignment");
    expect((q.inputStyle as any).direction, "an unmasked input never gets a forced direction").toBeUndefined();
  });
});
