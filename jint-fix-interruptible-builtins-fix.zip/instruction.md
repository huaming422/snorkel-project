## Task

Jint hosts untrusted JavaScript supplied by users. Embedders set time, statement count, and memory limits so a runaway script can be stopped. Yet a large input to some built-in operations can keep the engine busy for seconds and end in an out-of-memory crash of the host process. The configured limit never gets a chance to stop the operation with a catchable failure.

Investigate and fix this across affected built-ins, including string and array operations, iteration, object enumeration, and collection callbacks. Long operations must remain interruptible under the configured limits. If a requested string result is too large to represent, JavaScript should receive a catchable RangeError even when no execution limit is set. An interruption must not leave the engine in a state that changes the result of a later operation. Preserve the behavior of ordinary small inputs.
