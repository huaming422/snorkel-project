#nullable enable

using System.Collections;
using System.Globalization;
using Jint.Native;
using Jint.Runtime;

namespace Jint.Tests.PublicInterface;

/// <summary>
/// Exercises script access to a bounded host collection through <c>Engine</c>. Positions the collection
/// cannot address behave as absent properties. The contrast cases cover valid positions, named members,
/// dictionary additions, string keys supported by another host, and errors at valid positions.
/// </summary>
public class WrappedCollectionIndexBoundsTests
{
    /// <summary>Keys naming a position a three-element window cannot address, in both spellings.</summary>
    public static IEnumerable<string> UnaddressableIndices => ["3", "'3'", "10", "-1", "'-1'", "'08'", "'+3'"];

    [TestCaseSource(nameof(UnaddressableIndices))]
    public void ReadingAnIndexTheCollectionCannotAddressAnswersUndefined(string key)
    {
        var engine = CreateEngine(out _);

        engine.Evaluate($"x[{key}]").Should().Be(JsValue.Undefined,
            "there is no element at {0}, so a hole reads undefined rather than raising the collection's own exception", key);
    }

    [TestCaseSource(nameof(UnaddressableIndices))]
    public void WritingAnIndexTheCollectionCannotAddressIsTheOrdinarySetRefusal(string key)
    {
        var engine = CreateEngine(out var window);

        engine.Execute($"x[{key}] = 9");
        engine.Evaluate($"Reflect.set(x, {key}, 9)").AsBoolean().Should().BeFalse();

        var thrown = Caught.Exception(() => engine.Execute($"'use strict'; x[{key}] = 9;"));
        thrown.Should().BeOfType<JavaScriptException>("a refused [[Set]] in strict mode is a TypeError");
        ((JavaScriptException) thrown!).Error.Get("name").AsString().Should().Be("TypeError");

        window.Should().Equal(new[] { 1, 2, 3 }, "nothing reached the collection");
    }

    [TestCaseSource(nameof(UnaddressableIndices))]
    public void EveryExistenceLaneAgreesThatSuchAnIndexIsAbsent(string key)
    {
        var engine = CreateEngine(out _);

        engine.Evaluate($"[({key} in x), x.hasOwnProperty({key}), x.propertyIsEnumerable({key}), Object.getOwnPropertyDescriptor(x, {key}) !== undefined].join(',')")
            .AsString().Should().Be("false,false,false,false",
                "{0} is not a position of the collection, so no lane may report it as one", key);
    }

    [TestCaseSource(nameof(UnaddressableIndices))]
    public void DeletingSuchAnIndexSucceedsWithoutTouchingTheCollection(string key)
    {
        var engine = CreateEngine(out var window);

        engine.Evaluate($"delete x[{key}]").AsBoolean().Should().BeTrue("OrdinaryDelete returns true for a property that is not there");
        window.Should().Equal(1, 2, 3);
    }

    /// <summary>
    /// Positions the collection has remain readable, present, and writable from scripts.
    /// </summary>
    [TestCase("0", 1d)]
    [TestCase("'0'", 1d)]
    [TestCase("2", 3d)]
    [TestCase("'2'", 3d)]
    public void APositionTheCollectionHasIsUnaffected(string key, double expected)
    {
        var engine = CreateEngine(out var window);

        engine.Evaluate($"x[{key}]").AsNumber().Should().Be(expected);
        engine.Evaluate($"{key} in x").AsBoolean().Should().BeTrue();
        engine.Evaluate($"x.hasOwnProperty({key})").AsBoolean().Should().BeTrue();

        engine.Execute($"x[{key}] = 9");
        window[int.Parse(key.Trim('\''), CultureInfo.InvariantCulture)].Should().Be(9);
    }

    /// <summary>Named members of the same target remain available to scripts.</summary>
    [Test]
    public void NamedMembersAreUnaffected()
    {
        var engine = CreateEngine(out _);

        engine.Evaluate("x.Count").AsNumber().Should().Be(3);
        engine.Evaluate("x.length").AsNumber().Should().Be(3);
        engine.Evaluate("Array.prototype.join.call(x, '-')").AsString().Should().Be("1-2-3");
    }

    /// <summary>
    /// A dictionary accepts a new integer key and continues to return its existing entry.
    /// </summary>
    [Test]
    public void AnIntegerKeyedDictionaryStillAdds()
    {
        var engine = new Engine(options =>
        {
            options.AllowClr();
            options.Interop.AllowWrite = true;
        });
        var dictionary = new Dictionary<int, string> { [1] = "one" };
        engine.SetValue("x", dictionary);

        engine.Execute("x[99] = 'ninety-nine'");

        dictionary.Should().ContainKey(99).WhoseValue.Should().Be("ninety-nine");
        engine.Evaluate("x[99]").AsString().Should().Be("ninety-nine");
        engine.Evaluate("x[1]").AsString().Should().Be("one");
    }

    /// <summary>
    /// A host with string keys continues to answer for the names it supports, including <c>"3"</c>.
    /// </summary>
    [Test]
    public void AStringKeyedIndexerOnAnArrayLikeTargetStillAnswers()
    {
        var engine = new Engine(options =>
        {
            options.AllowClr();
            options.Interop.AllowWrite = true;
        });
        engine.SetValue("x", new NamedValues { ["3"] = "the third", ["etag"] = "abc" });

        engine.Evaluate("x['3']").AsString().Should().Be("the third");
        engine.Evaluate("x['etag']").AsString().Should().Be("abc");
    }

    /// <summary>
    /// A failure raised while reading a position the collection has still reaches the caller.
    /// </summary>
    [Test]
    public void AGenuineExceptionFromAnInRangePositionIsNotSwallowedToUndefined()
    {
        var engine = new Engine(options =>
        {
            options.AllowClr();
            options.Interop.AllowWrite = true;
        });
        engine.SetValue("x", new FaultyWindow());

        // The neighboring positions return values before the read at position 1 fails.
        engine.Evaluate("x[0]").AsNumber().Should().Be(10);
        engine.Evaluate("x[2]").AsNumber().Should().Be(30);

        var thrown = Caught.Exception(() => engine.Evaluate("x[1]"));
        thrown.Should().NotBeNull(
            "a collection error at a valid position must reach the caller");
    }

    private static Engine CreateEngine(out Window window)
    {
        window = new Window(1, 2, 3);
        var engine = new Engine(options =>
        {
            options.AllowClr();
            options.Interop.AllowWrite = true;
        });
        engine.SetValue("x", window);
        return engine;
    }

    /// <summary>
    /// A bounded collection with a count and integer positions.
    /// </summary>
    public sealed class Window : IReadOnlyCollection<int>
    {
        private readonly List<int> _items;

        public Window(params int[] items) => _items = [.. items];

        public int this[int index] { get => _items[index]; set => _items[index] = value; }

        public int Count => _items.Count;

        public IEnumerator<int> GetEnumerator() => _items.GetEnumerator();

        IEnumerator IEnumerable.GetEnumerator() => _items.GetEnumerator();
    }

    /// <summary>
    /// A bounded collection whose getter raises an error at position 1.
    /// </summary>
    public sealed class FaultyWindow : IReadOnlyCollection<int>
    {
        private readonly int[] _items = [10, 20, 30];

        public int this[int index]
        {
            get => index == 1
                ? throw new ArgumentOutOfRangeException(nameof(index), "the backing store for this position faulted")
                : _items[index];
            set => _items[index] = value;
        }

        public int Count => _items.Length;

        public IEnumerator<int> GetEnumerator() => ((IEnumerable<int>) _items).GetEnumerator();

        IEnumerator IEnumerable.GetEnumerator() => _items.GetEnumerator();
    }

    /// <summary>
    /// A counted host collection whose keys are strings.
    /// </summary>
    public sealed class NamedValues : IReadOnlyCollection<string>
    {
        private readonly Dictionary<string, string> _values = new(StringComparer.Ordinal);

        public string this[string name]
        {
            get => _values.TryGetValue(name, out var value) ? value : string.Empty;
            set => _values[name] = value;
        }

        public int Count => _values.Count;

        public IEnumerator<string> GetEnumerator() => _values.Values.GetEnumerator();

        IEnumerator IEnumerable.GetEnumerator() => _values.Values.GetEnumerator();
    }
}
