## Task

We expose ordinary CLR objects to scripts with interop enabled and writes permitted. One of those objects is a plain bounded collection with a count and an integer indexer.

A script can use a numeric index that this collection cannot address, whether it is beyond the last element, negative, or written as a string such as `"08"` or `"+3"`. On a read or write, the collection's .NET exception escapes from `engine.Evaluate(...)` or `engine.Execute(...)`. Script `try`/`catch` and an embedder catching the engine's script-error type both miss that raw host exception, ending the call. Existence checks also say an unreadable index is present.

Please make those unaddressable indexes act as absent properties without leaking a host exception. A write to one should be refused through the usual script behavior. Keep reads and writes to actual positions working, preserve named members, and leave other host objects free to accept keys they legitimately support.
If the collection itself fails while reading a position it does have, that error should still reach the caller.
