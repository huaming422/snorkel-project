// @ts-nocheck
import { describe, it, expect, beforeEach, afterEach } from "vitest";
import { STATE, CONFIG, resetWorld, place, step } from "../../helpers/sim-world.mjs";
import { getTestCases } from "./validationParams.js";

const SAVE_KEY = "serverSurvivalSave";

beforeEach(() => {
  resetWorld();
  if (globalThis.localStorage) globalThis.localStorage.removeItem(SAVE_KEY);
  if (globalThis.alertCalls) globalThis.alertCalls.length = 0;
});

afterEach(() => {
  if (STATE.animationId) {
    globalThis.cancelAnimationFrame(STATE.animationId);
    STATE.animationId = null;
  }
});

describe("fleet_scales_in_hysteresis", () => {
  const cases = getTestCases();
  it.each(cases)("case %#: $inputs.scenario", ({ inputs, expected }) => {
    const asCfg = CONFIG.services.compute.autoScaling;
    const BASE        = CONFIG.services.compute.capacity;
    const SUSTAIN     = asCfg.scaleUpSustain;     // scale-up window
    const WARMUP      = asCfg.warmupTime;
    const COOLDOWN_UP = asCfg.scaleUpSustain;     // effective gap between consecutive scale-ups
    const COOLDOWN_DN = asCfg.scaleDownSustain;   // effective gap between consecutive scale-downs
    const MIN         = asCfg.minInstances;
    const MAX         = asCfg.maxInstances;
    const HIGH_UTIL   = asCfg.scaleUpThreshold;
    const LOW_UTIL    = asCfg.scaleDownThreshold;
    const MID         = (HIGH_UTIL + LOW_UTIL) / 2;

    const capMult = (svc) => Math.round(svc.getEffectiveCapacity() / BASE);

    // Helper: grow the fleet to a STABLE plateau at the MAX ceiling
    // (all instances ready, no warming happening)
    function growToStablePlateau(svc) {
      // Use scale-up cooldown for growing phase
      const totalFrames = Math.round((SUSTAIN + WARMUP + COOLDOWN_UP) / 0.1) * (MAX + 2);
      for (let f = 0; f < totalFrames; f++) {
        svc.queue = new Array(400).fill({});
        svc.processing = [];
        step(0.1);
      }
    }

    const scenario = inputs.scenario;

    if (scenario === "idle_shrinks_to_min") {
      const svc = place("compute");
      svc.setAutoScaling({ enabled: true });

      growToStablePlateau(svc);
      const grownMult = capMult(svc);
      const grown_over_max = Math.max(0, grownMult - MAX);

      // Drive idle for long enough that (MAX - MIN) scale-downs can complete.
      // Use scaleDownSustain as the relevant cooldown for this phase.
      const idleFrames = Math.round((SUSTAIN + COOLDOWN_DN) / 0.1) * (MAX + 2);
      for (let f = 0; f < idleFrames; f++) {
        svc.queue = [];
        svc.processing = [];
        step(0.1);
      }

      const idle_settle_minus_min = capMult(svc) - MIN;

      if (expected.grown_over_max !== "__skip__") {
        expect(grown_over_max).toBe(expected.grown_over_max);
      }
      if (expected.idle_settle_minus_min !== "__skip__") {
        expect(idle_settle_minus_min).toBe(expected.idle_settle_minus_min);
      }

    } else if (scenario === "dead_band_holds") {
      const svc = place("compute");
      svc.setAutoScaling({ enabled: true });

      growToStablePlateau(svc);
      const entryMult = capMult(svc);

      let minMult = capMult(svc);
      let maxMult = capMult(svc);

      // Hold at MID utilization long enough that any drift would show up.
      // Use the longer of scale-up and scale-down cooldowns for the hold window.
      const holdCooldown = Math.max(COOLDOWN_UP, COOLDOWN_DN);
      const holdFrames = Math.round((SUSTAIN + holdCooldown) / 0.1) * (MAX + 2);

      for (let f = 0; f < holdFrames; f++) {
        const n = Math.round(MID * svc.getEffectiveCapacity() * 2);
        svc.queue = new Array(n).fill({});
        svc.processing = [];
        step(0.1);
        const cm = capMult(svc);
        if (cm < minMult) minMult = cm;
        if (cm > maxMult) maxMult = cm;
      }

      const afterMult  = capMult(svc);
      const band_delta  = afterMult - entryMult;
      const band_spread = maxMult - minMult;

      if (expected.band_delta !== "__skip__") {
        expect(band_delta).toBe(expected.band_delta);
      }
      if (expected.band_spread !== "__skip__") {
        expect(band_spread).toBe(expected.band_spread);
      }

    } else if (scenario === "dip_resets_streak") {
      const svc = place("compute");
      svc.setAutoScaling({ enabled: true });

      // Hot phase 1: just under the sustain window (no scale-out yet)
      const hotFrames = Math.round((SUSTAIN - 0.5) / 0.1);
      for (let f = 0; f < hotFrames; f++) {
        svc.queue = new Array(400).fill({});
        svc.processing = [];
        step(0.1);
      }

      // Dip into the dead band — should reset the scale-up streak
      const dipFrames = Math.round(1.0 / 0.1);
      for (let f = 0; f < dipFrames; f++) {
        const n = Math.round(MID * svc.getEffectiveCapacity() * 2);
        svc.queue = new Array(n).fill({});
        svc.processing = [];
        step(0.1);
      }

      // Hot phase 2: another full (SUSTAIN - 0.5) seconds — still under the window
      for (let f = 0; f < hotFrames; f++) {
        svc.queue = new Array(400).fill({});
        svc.processing = [];
        step(0.1);
      }

      const dip_reset_growth = capMult(svc) - 1;

      if (expected.dip_reset_growth !== "__skip__") {
        expect(dip_reset_growth).toBe(expected.dip_reset_growth);
      }

    } else if (scenario === "min_is_floor") {
      const svc = place("compute");
      svc.setAutoScaling({ enabled: true });

      let minCapMult = capMult(svc);

      // Drive idle for Math.round((SUSTAIN + COOLDOWN_DN)/0.1) * 3 frames
      const idleFrames = Math.round((SUSTAIN + COOLDOWN_DN) / 0.1) * 3;
      for (let f = 0; f < idleFrames; f++) {
        svc.queue = [];
        svc.processing = [];
        step(0.1);
        const cm = capMult(svc);
        if (cm < minCapMult) minCapMult = cm;
      }

      const min_floor_offset = minCapMult - MIN;

      if (expected.min_floor_offset !== "__skip__") {
        expect(min_floor_offset).toBe(expected.min_floor_offset);
      }
    }
  });
});
