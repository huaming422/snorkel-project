// @ts-nocheck
import { describe, it, expect, beforeEach, afterEach } from "vitest";
import { STATE, CONFIG, resetWorld, place, step } from "../../helpers/sim-world.mjs";
import { saveGameState, loadGameState } from "../../../src/persistence/save-load.js";
import { getTestCases } from "./validationParams.js";

const SAVE_KEY = "serverSurvivalSave";

beforeEach(() => {
  resetWorld();
  if (globalThis.localStorage) globalThis.localStorage.removeItem(SAVE_KEY);
  if (globalThis.alertCalls) globalThis.alertCalls.length = 0;
});

afterEach(() => {
  if (STATE.animationId) {
    globalThis.cancelAnimationFrame(STATE.animationId);
    STATE.animationId = null;
  }
});

describe("persistence_round_trip", () => {
  const cases = getTestCases();
  it.each(cases)("case %#: $inputs.scenario", ({ inputs, expected }) => {
    const asCfg       = CONFIG.services.compute.autoScaling;
    const BASE        = CONFIG.services.compute.capacity;
    const SUSTAIN     = asCfg.scaleUpSustain;
    const WARMUP      = asCfg.warmupTime;
    const COOLDOWN    = asCfg.scaleUpSustain;
    const COOLDOWN_DN = asCfg.scaleDownSustain;
    const MAX         = asCfg.maxInstances;

    const capMult = (svc) => Math.round(svc.getEffectiveCapacity() / BASE);

    // Grow fleet to stable plateau under saturated load
    function growToStablePlateau(svc) {
      const totalFrames = Math.round((SUSTAIN + WARMUP + COOLDOWN) / 0.1) * (MAX + 2);
      for (let f = 0; f < totalFrames; f++) {
        svc.queue = new Array(400).fill({});
        svc.processing = [];
        step(0.1);
      }
    }

    // Save-round-trip: save state, wipe world, restore from save
    function roundTrip() {
      saveGameState("browser");
      const j = globalThis.localStorage.getItem(SAVE_KEY);
      resetWorld();
      globalThis.localStorage.setItem(SAVE_KEY, j);
      loadGameState();
      return STATE.services.find(s => s.type === "compute");
    }

    const scenario = inputs.scenario;

    if (scenario === "grown_round_trip") {
      // Grow fleet to stable plateau, save, restore, check size is preserved
      const svc = place("compute");
      svc.setAutoScaling({ enabled: true });
      growToStablePlateau(svc);
      const savedMult = capMult(svc);

      const restored = roundTrip();
      const restored_minus_saved = capMult(restored) - savedMult;
      const restored_over_max    = Math.max(0, capMult(restored) - MAX);

      if (expected.restored_minus_saved !== "__skip__") {
        expect(restored_minus_saved).toBe(expected.restored_minus_saved);
      }
      if (expected.restored_over_max !== "__skip__") {
        expect(restored_over_max).toBe(expected.restored_over_max);
      }

    } else if (scenario === "pre_feature_save") {
      // Save a plain compute node, then strip the auto-scaling fields from the
      // save data to mimic a save written before this feature existed.
      const svc = place("compute");
      saveGameState("browser");
      const j = globalThis.localStorage.getItem(SAVE_KEY);
      const saveData = JSON.parse(j);

      // Delete the auto-scaling object (the field the submission added)
      saveData.services.forEach(s => {
        delete s.autoScale;
      });

      resetWorld();
      globalThis.localStorage.setItem(SAVE_KEY, JSON.stringify(saveData));
      loadGameState();

      const restored = STATE.services.find(s => s.type === "compute");
      const cap_over_base = capMult(restored);

      if (expected.cap_over_base !== "__skip__") {
        expect(cap_over_base).toBe(expected.cap_over_base);
      }

    } else if (scenario === "tamper_clamped") {
      // Grow a little, save, tamper the saved instance count to 999 (far above MAX),
      // reload and verify it is clamped back to the legal ceiling.
      const svc = place("compute");
      svc.setAutoScaling({ enabled: true });

      const growFrames = Math.round((SUSTAIN + WARMUP) / 0.1);
      for (let f = 0; f < growFrames; f++) {
        svc.queue = new Array(400).fill({});
        svc.processing = [];
        step(0.1);
      }

      saveGameState("browser");
      const j = globalThis.localStorage.getItem(SAVE_KEY);
      const saveData = JSON.parse(j);

      // Tamper the stored instance count to a value far above MAX
      saveData.services.forEach(s => {
        if (s.type === "compute" && s.autoScale) {
          s.autoScale.currentInstances = 999;
        }
      });

      resetWorld();
      globalThis.localStorage.setItem(SAVE_KEY, JSON.stringify(saveData));
      loadGameState();

      const restored = STATE.services.find(s => s.type === "compute");
      const restored_over_max = capMult(restored) - MAX;

      if (expected.restored_over_max !== "__skip__") {
        expect(restored_over_max).toBe(expected.restored_over_max);
      }

    } else if (scenario === "warming_not_persisted") {
      // Drive load long enough that a second instance has been booted but is
      // still warming up — then save and reload.
      const svc = place("compute");
      svc.setAutoScaling({ enabled: true });

      // SUSTAIN + WARMUP * 0.6 seconds: instance booted (at SUSTAIN) and still warming
      const warmFrames = Math.round((SUSTAIN + WARMUP * 0.6) / 0.1);
      for (let f = 0; f < warmFrames; f++) {
        svc.queue = new Array(400).fill({});
        svc.processing = [];
        step(0.1);
      }

      // savedReadyMult: the READY capacity at save time (warming instance excluded)
      const savedReadyMult = capMult(svc);

      const restored = roundTrip();

      // Capture the restored capMult RIGHT AFTER reload (before any idle driving)
      const initialRestoredMult = capMult(restored);
      const restored_minus_ready = initialRestoredMult - savedReadyMult;

      // After an idle reload, the warming instance that was mid-warm at save time
      // must NOT resume warmup — the fleet should not gain capacity above initialRestoredMult.
      // Track the maximum capMult seen during the idle window.
      let maxCapMultAfterReload = initialRestoredMult;
      const idleFrames = Math.round((WARMUP + COOLDOWN_DN) / 0.1);
      for (let f = 0; f < idleFrames; f++) {
        restored.queue = [];
        restored.processing = [];
        step(0.1);
        const cm = capMult(restored);
        if (cm > maxCapMultAfterReload) maxCapMultAfterReload = cm;
      }

      // post_reload_growth: did capacity ever GROW above the initial restored level?
      // (positive = warming resumed after reload; 0 = cold boot with no warmup carried over)
      const post_reload_growth = maxCapMultAfterReload - initialRestoredMult;

      if (expected.restored_minus_ready !== "__skip__") {
        expect(restored_minus_ready).toBe(expected.restored_minus_ready);
      }
      if (expected.post_reload_growth !== "__skip__") {
        expect(post_reload_growth).toBe(expected.post_reload_growth);
      }
    }
  });
});
