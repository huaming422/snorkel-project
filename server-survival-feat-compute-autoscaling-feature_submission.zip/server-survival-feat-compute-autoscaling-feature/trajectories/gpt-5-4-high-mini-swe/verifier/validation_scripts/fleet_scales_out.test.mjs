// @ts-nocheck
import { describe, it, expect, beforeEach, afterEach } from "vitest";
import { STATE, CONFIG, resetWorld, place, step } from "../../helpers/sim-world.mjs";
import { getTestCases } from "./validationParams.js";

const SAVE_KEY = "serverSurvivalSave";

beforeEach(() => {
  resetWorld();
  if (globalThis.localStorage) globalThis.localStorage.removeItem(SAVE_KEY);
  if (globalThis.alertCalls) globalThis.alertCalls.length = 0;
});

afterEach(() => {
  if (STATE.animationId) {
    globalThis.cancelAnimationFrame(STATE.animationId);
    STATE.animationId = null;
  }
});

describe("fleet_scales_out", () => {
  const cases = getTestCases();
  it.each(cases)("case %#: $inputs.scenario", ({ inputs, expected }) => {
    // Discover config values from the submission's autoScaling block
    const asCfg = CONFIG.services.compute.autoScaling;
    const BASE = CONFIG.services.compute.capacity;
    const SUSTAIN = asCfg.scaleUpSustain;   // sustained window before scale-out
    const WARMUP  = asCfg.warmupTime;        // per-instance warm-up duration
    // COOLDOWN: after a scale-up, scaleUpTimer resets to 0; next scale-out needs
    // another full SUSTAIN window — so the effective gap equals SUSTAIN.
    const COOLDOWN = asCfg.scaleUpSustain;
    const MAX = asCfg.maxInstances;

    const capMult = (svc) => Math.round(svc.getEffectiveCapacity() / BASE);

    const scenario = inputs.scenario;

    if (scenario === "cold_start_then_ready") {
      // Place a compute node and enable auto-scaling with default config
      const svc = place("compute");
      svc.setAutoScaling({ enabled: true });

      // earlyFrame: SUSTAIN has elapsed (new instance booted) but WARMUP not done yet
      const earlyFrame = Math.round((SUSTAIN + WARMUP / 2) / 0.1);
      // readyFrame: SUSTAIN + full WARMUP have elapsed, new instance fully ready
      const readyFrame = Math.round((SUSTAIN + WARMUP + COOLDOWN / 2) / 0.1);
      const totalFrames = readyFrame + 1;

      let cap_mult_early = null;
      let cap_mult_after_ready = null;

      for (let f = 0; f < totalFrames; f++) {
        svc.queue = new Array(400).fill({});
        svc.processing = [];
        step(0.1);
        // After earlyFrame steps total (f = earlyFrame - 1 is the last 0-indexed step)
        if (f === earlyFrame - 1) {
          cap_mult_early = capMult(svc);
        }
        if (f === readyFrame - 1) {
          cap_mult_after_ready = capMult(svc);
        }
      }

      if (expected.cap_mult_early !== "__skip__") {
        expect(cap_mult_early).toBe(expected.cap_mult_early);
      }
      if (expected.cap_mult_after_ready !== "__skip__") {
        expect(cap_mult_after_ready).toBe(expected.cap_mult_after_ready);
      }

    } else if (scenario === "settle_at_ceiling") {
      const svc = place("compute");
      svc.setAutoScaling({ enabled: true });

      // Run long enough for the fleet to hit MAX and stabilise
      const totalFrames = Math.round((SUSTAIN + WARMUP + COOLDOWN) / 0.1) * (MAX + 2);

      let peakMult = 0;
      let settledMult = 0;

      for (let f = 0; f < totalFrames; f++) {
        svc.queue = new Array(400).fill({});
        svc.processing = [];
        step(0.1);
        const cm = capMult(svc);
        if (cm > peakMult) peakMult = cm;
        settledMult = cm;
      }

      const settle_minus_max = settledMult - MAX;
      const peak_over_max    = Math.max(0, peakMult - MAX);

      if (expected.settle_minus_max !== "__skip__") {
        expect(settle_minus_max).toBe(expected.settle_minus_max);
      }
      if (expected.peak_over_max !== "__skip__") {
        expect(peak_over_max).toBe(expected.peak_over_max);
      }

    } else if (scenario === "warming_is_billed") {
      // Measure single-instance base drain (no auto-scaling)
      resetWorld({ money: 100000 });
      const baseSvc = place("compute");
      STATE.upkeepEnabled = true;
      const moneyBefore1 = STATE.money;
      step(0.1);
      const moneyAfter1 = STATE.money;
      const baseDrain = moneyBefore1 - moneyAfter1;

      // Now measure with auto-scaling enabled; watch billing while capMult is still 1
      resetWorld({ money: 100000 });
      const svc = place("compute");
      svc.setAutoScaling({ enabled: true });
      STATE.upkeepEnabled = true;

      let maxBilledMultWhileCapMult1 = 0;

      for (let f = 0; f < 100000; f++) {
        svc.queue = new Array(400).fill({});
        svc.processing = [];
        const moneyBefore = STATE.money;
        step(0.1);
        const moneyAfter = STATE.money;
        const cm = capMult(svc);

        if (cm === 1) {
          const drain = moneyBefore - moneyAfter;
          const billedMult = Math.round(drain / baseDrain);
          if (billedMult > maxBilledMultWhileCapMult1) {
            maxBilledMultWhileCapMult1 = billedMult;
          }
        } else {
          // capMult rose above 1 — warming has completed
          break;
        }
      }

      // warm_extra_billed: did we ever see billing for more than 1 instance
      // while capacity was still at BASE? Capped at 1 so both 2-instance and
      // 3-instance fleets give the same result (just "yes, extra billing happened").
      const warm_extra_billed = Math.min(1, maxBilledMultWhileCapMult1 - 1);

      if (expected.warm_extra_billed !== "__skip__") {
        expect(warm_extra_billed).toBe(expected.warm_extra_billed);
      }

    } else if (scenario === "cooldown_gates_second_boot") {
      const svc = place("compute");
      svc.setAutoScaling({ enabled: true });

      const riseGameTimes = [];
      let prevCapMult = capMult(svc);

      // Upper bound: enough frames for MAX scale-ups to occur
      const maxFrames = Math.round((SUSTAIN + WARMUP + COOLDOWN) / 0.1) * (MAX + 2) * 10;

      for (let f = 0; f < maxFrames; f++) {
        svc.queue = new Array(400).fill({});
        svc.processing = [];
        step(0.1);
        const cm = capMult(svc);
        if (cm > prevCapMult) {
          riseGameTimes.push(f * 0.1);
          prevCapMult = cm;
        }
        if (riseGameTimes.length >= 2) break;
      }

      const gap = riseGameTimes[1] - riseGameTimes[0];
      // cooldown_slack: how many frames the second rise was EARLIER than COOLDOWN
      // (positive means it violated the cooldown; 0 means gap >= COOLDOWN)
      const cooldown_slack = Math.max(0, Math.round((COOLDOWN - gap) / 0.1));

      if (expected.cooldown_slack !== "__skip__") {
        expect(cooldown_slack).toBe(expected.cooldown_slack);
      }
    }
  });
});
