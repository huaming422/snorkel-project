// @ts-nocheck
import { describe, it, expect, beforeEach, afterEach } from "vitest";
import { STATE, CONFIG, resetWorld, place, step } from "../../helpers/sim-world.mjs";
import { getTestCases } from "./validationParams.js";

const SAVE_KEY = "serverSurvivalSave";

beforeEach(() => {
  resetWorld();
  if (globalThis.localStorage) globalThis.localStorage.removeItem(SAVE_KEY);
  if (globalThis.alertCalls) globalThis.alertCalls.length = 0;
});

afterEach(() => {
  if (STATE.animationId) {
    globalThis.cancelAnimationFrame(STATE.animationId);
    STATE.animationId = null;
  }
});

describe("non_asg_unchanged", () => {
  const cases = getTestCases();
  it.each(cases)("case %#: $inputs.scenario / $inputs.service_type", ({ inputs, expected }) => {
    // Config constants read from submission's autoScaling block
    const asCfg  = CONFIG.services.compute.autoScaling;
    const SUSTAIN = asCfg.scaleUpSustain;
    const WARMUP  = asCfg.warmupTime;
    const COOLDOWN = asCfg.scaleUpSustain;
    const MAX     = asCfg.maxInstances;

    const serviceType = inputs.service_type;
    const scenario    = inputs.scenario;

    // BASE is per the service type under test
    const BASE   = CONFIG.services[serviceType].capacity;
    const capMult = (svc) => Math.round(svc.getEffectiveCapacity() / BASE);

    // --- Place the service and put it into the required scaling state ---
    const svc = place(serviceType);

    if (scenario === "compute_scaling_off") {
      // Enable scaling then disable it — ends with scaling OFF
      svc.setAutoScaling({ enabled: true });
      svc.setAutoScaling({ enabled: false });
    }
    // For "other_type": non-Compute type, do NOT enable scaling.

    // --- Measure unloaded single-instance numbers ---
    svc.queue = new Array(BASE).fill({});
    svc.processing = [];
    const cap_over_base = capMult(svc);
    const load_milli    = Math.round(svc.totalLoad * 1000);

    // --- Prove the service never grows under sustained saturation ---
    const satFrames = Math.round((SUSTAIN + WARMUP + COOLDOWN) / 0.1) * (MAX + 2);
    let grown_under_load_mult = capMult(svc);

    for (let f = 0; f < satFrames; f++) {
      svc.queue = new Array(400).fill({});
      svc.processing = [];
      step(0.1);
      const cm = capMult(svc);
      if (cm > grown_under_load_mult) grown_under_load_mult = cm;
    }

    // All three expected values are always real (no __skip__ in any case)
    expect(cap_over_base).toBe(expected.cap_over_base);
    expect(load_milli).toBe(expected.load_milli);
    expect(grown_under_load_mult).toBe(expected.grown_under_load_mult);
  });
});
