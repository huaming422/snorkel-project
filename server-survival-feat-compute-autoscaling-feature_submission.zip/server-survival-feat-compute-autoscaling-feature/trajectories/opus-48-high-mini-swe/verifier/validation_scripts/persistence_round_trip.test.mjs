// @ts-nocheck
import { describe, test, expect, beforeEach, afterEach } from "vitest";
import { STATE, CONFIG, resetWorld, place, step } from "../../helpers/sim-world.mjs";
import { saveGameState, loadGameState } from "../../../src/persistence/save-load.js";
import { getTestCases } from "./validationParams.js";

beforeEach(() => {
  resetWorld();
  globalThis.localStorage.removeItem("serverSurvivalSave");
});

afterEach(() => {
  // loadGameState() starts the animate rAF loop; cancel it so frames from one
  // test never tick into the next.
  if (STATE.animationId) {
    globalThis.cancelAnimationFrame(STATE.animationId);
    STATE.animationId = null;
  }
});

const SAVE_KEY = "serverSurvivalSave";
const AS = CONFIG.services.compute.autoScaling;

describe("persistence_round_trip", () => {
  const cases = getTestCases();
  test.each(cases)("case %#", ({ inputs, expected }) => {
    resetWorld();

    const BASE     = CONFIG.services.compute.capacity;
    const SUSTAIN  = AS.scaleUpAfter;
    const WARMUP   = AS.warmupTime;
    const COOLDOWN = AS.scaleDownAfter;
    const MAX      = AS.maxInstances;

    const capMult = (s) => Math.round(s.getEffectiveCapacity() / BASE);

    // Helper: grow fleet to stable plateau under saturated load
    function growToStablePlateau(svc) {
      const totalFrames = Math.round((SUSTAIN + WARMUP + COOLDOWN) / 0.1) * (MAX + 2);
      for (let i = 0; i < totalFrames; i++) {
        svc.queue = new Array(400).fill({});
        svc.processing = [];
        step(0.1);
      }
    }

    // Save round-trip helper: save -> reset -> restore.
    // Per spec: saveGameState(); const j = localStorage.getItem(SAVE_KEY);
    // resetWorld(); localStorage.setItem(SAVE_KEY, j); loadGameState()
    function doRoundTrip() {
      saveGameState("browser");
      const j = globalThis.localStorage.getItem(SAVE_KEY);
      resetWorld();
      globalThis.localStorage.setItem(SAVE_KEY, j);
      loadGameState();
      // Cancel the animation loop started by loadGameState so it does not
      // advance service state between our assertions.
      if (STATE.animationId) {
        globalThis.cancelAnimationFrame(STATE.animationId);
        STATE.animationId = null;
      }
    }

    if (inputs.scenario === "grown_round_trip") {
      globalThis.localStorage.removeItem(SAVE_KEY);
      const svc = place("compute");
      svc.autoScaling = true;

      growToStablePlateau(svc);
      const savedMult = capMult(svc);

      doRoundTrip();

      const restored = STATE.services.find((s) => s.type === "compute");

      const restored_minus_saved = capMult(restored) - savedMult;
      const restored_over_max    = Math.max(0, capMult(restored) - MAX);

      if (expected.restored_minus_saved !== "__skip__") {
        expect(restored_minus_saved).toBe(expected.restored_minus_saved);
      }
      if (expected.restored_over_max !== "__skip__") {
        expect(restored_over_max).toBe(expected.restored_over_max);
      }

    } else if (inputs.scenario === "pre_feature_save") {
      globalThis.localStorage.removeItem(SAVE_KEY);
      const svc = place("compute");
      // Save with current state (auto-scaling fields present)
      saveGameState("browser");
      // Parse and strip ALL auto-scaling fields, simulating a save written
      // before the feature existed. The submission added: autoScaling (enabled flag),
      // instances (stored instance count), and warmedInstances.
      const j = globalThis.localStorage.getItem(SAVE_KEY);
      const saveData = JSON.parse(j);
      for (const service of saveData.services) {
        delete service.autoScaling;
        delete service.instances;
        delete service.warmedInstances;
      }
      resetWorld();
      globalThis.localStorage.setItem(SAVE_KEY, JSON.stringify(saveData));
      loadGameState();
      if (STATE.animationId) {
        globalThis.cancelAnimationFrame(STATE.animationId);
        STATE.animationId = null;
      }

      const restored = STATE.services.find((s) => s.type === "compute");
      const cap_over_base = capMult(restored);

      if (expected.cap_over_base !== "__skip__") {
        expect(cap_over_base).toBe(expected.cap_over_base);
      }

    } else if (inputs.scenario === "tamper_clamped") {
      globalThis.localStorage.removeItem(SAVE_KEY);
      const svc = place("compute");
      svc.autoScaling = true;

      // Grow a little under saturated load (one full scale-out cycle is enough)
      const growFrames = Math.round((SUSTAIN + WARMUP + COOLDOWN) / 0.1);
      for (let i = 0; i < growFrames; i++) {
        svc.queue = new Array(400).fill({});
        svc.processing = [];
        step(0.1);
      }

      saveGameState("browser");
      // Tamper: set stored instance count to 999 (far above MAX)
      const j = globalThis.localStorage.getItem(SAVE_KEY);
      const saveData = JSON.parse(j);
      for (const service of saveData.services) {
        if (service.type === "compute") {
          service.instances = 999;
          service.warmedInstances = 999;
        }
      }
      resetWorld();
      globalThis.localStorage.setItem(SAVE_KEY, JSON.stringify(saveData));
      loadGameState();
      if (STATE.animationId) {
        globalThis.cancelAnimationFrame(STATE.animationId);
        STATE.animationId = null;
      }

      const restored = STATE.services.find((s) => s.type === "compute");
      // Step once to allow updateAutoScaling to clamp instances to [min, max].
      step(0.1);

      const restored_over_max = capMult(restored) - MAX;

      if (expected.restored_over_max !== "__skip__") {
        expect(restored_over_max).toBe(expected.restored_over_max);
      }

    } else if (inputs.scenario === "warming_not_persisted") {
      globalThis.localStorage.removeItem(SAVE_KEY);
      const svc = place("compute");
      svc.autoScaling = true;

      // Drive saturated load for SUSTAIN + WARMUP*0.6 seconds.
      // Long enough to boot one instance (still warming) but warmup not yet complete.
      const frames = Math.round((SUSTAIN + WARMUP * 0.6) / 0.1);
      for (let i = 0; i < frames; i++) {
        svc.queue = new Array(400).fill({});
        svc.processing = [];
        step(0.1);
      }

      // savedReadyMult = capMult based on WARMED instances (not total booted)
      const savedReadyMult = capMult(svc);

      doRoundTrip();

      const restored = STATE.services.find((s) => s.type === "compute");
      // capMult immediately after reload (before any additional idle steps)
      const restored_minus_ready = capMult(restored) - savedReadyMult;

      // Drive IDLE load and track the maximum capMult seen after the reload.
      // If the warming instance was NOT persisted (cold boot), capMult should never rise.
      const idleFrames = Math.round((WARMUP + COOLDOWN) / 0.1);
      let maxCapMultAfterReload = capMult(restored);

      for (let i = 0; i < idleFrames; i++) {
        restored.queue = [];
        restored.processing = [];
        step(0.1);
        const cm = capMult(restored);
        if (cm > maxCapMultAfterReload) maxCapMultAfterReload = cm;
      }

      // post_reload_growth: how much did capMult rise above its immediately-post-reload value?
      // spec: (max capMult after reload) - capMult(restored)
      // capMult(restored) is the value right after reload (captured above as restored_minus_ready's base).
      const capMultAtReload = savedReadyMult + restored_minus_ready;
      const post_reload_growth = maxCapMultAfterReload - capMultAtReload;

      if (expected.restored_minus_ready !== "__skip__") {
        expect(restored_minus_ready).toBe(expected.restored_minus_ready);
      }
      if (expected.post_reload_growth !== "__skip__") {
        expect(post_reload_growth).toBe(expected.post_reload_growth);
      }
    }
  });
});
