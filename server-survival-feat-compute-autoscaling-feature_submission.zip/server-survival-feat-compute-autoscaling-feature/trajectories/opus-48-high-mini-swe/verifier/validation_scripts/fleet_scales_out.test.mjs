// @ts-nocheck
import { describe, test, expect, beforeEach } from "vitest";
import { STATE, CONFIG, resetWorld, place, step } from "../../helpers/sim-world.mjs";
import { getTestCases } from "./validationParams.js";

beforeEach(() => resetWorld());

const AS = CONFIG.services.compute.autoScaling;

// CONFIG key mappings (discovered from the patch):
// SUSTAIN  = AS.scaleUpAfter   (3s)  – sustained busy before scale-up
// WARMUP   = AS.warmupTime     (5s)  – new instance warm-up duration
// COOLDOWN = AS.warmupTime     (5s)  – effective min gap between scale-ups (warmup acts as cooldown)
// MIN      = AS.minInstances   (1)
// MAX      = AS.maxInstances   (6)
// HIGH_UTIL= AS.scaleUpLoad    (0.75)
// LOW_UTIL = AS.scaleDownLoad  (0.35)

describe("fleet_scales_out", () => {
  const cases = getTestCases();
  test.each(cases)("case %#", ({ inputs, expected }) => {
    resetWorld();

    const SUSTAIN  = AS.scaleUpAfter;
    const WARMUP   = AS.warmupTime;
    // COOLDOWN: in this implementation, warmup itself gates back-to-back scale-ups.
    // Use scaleDownAfter as a generous "long enough" window for formulas that need a gap.
    const COOLDOWN = AS.scaleDownAfter;
    const MAX      = AS.maxInstances;
    const BASE     = CONFIG.services.compute.capacity;

    const svc = place("compute");
    // Enable auto-scaling by setting the flag directly (discovered from patch)
    svc.autoScaling = true;

    const capMult = (s) => Math.round(s.getEffectiveCapacity() / BASE);

    // saturate helper
    const saturate = () => {
      svc.queue = new Array(400).fill({});
      svc.processing = [];
    };

    if (inputs.scenario === "cold_start_then_ready") {
      const earlyFrame = Math.round((SUSTAIN + WARMUP / 2) / 0.1);
      const readyFrame = Math.round((SUSTAIN + WARMUP + COOLDOWN / 2) / 0.1);

      let cap_mult_early = null;
      let cap_mult_after_ready = null;

      for (let i = 0; i < readyFrame + 1; i++) {
        saturate();
        step(0.1);
        if (i + 1 === earlyFrame) {
          cap_mult_early = capMult(svc);
        }
        if (i + 1 === readyFrame) {
          cap_mult_after_ready = capMult(svc);
        }
      }

      if (expected.cap_mult_early !== "__skip__") {
        expect(cap_mult_early).toBe(expected.cap_mult_early);
      }
      if (expected.cap_mult_after_ready !== "__skip__") {
        expect(cap_mult_after_ready).toBe(expected.cap_mult_after_ready);
      }

    } else if (inputs.scenario === "settle_at_ceiling") {
      const totalFrames = Math.round((SUSTAIN + WARMUP + COOLDOWN) / 0.1) * (MAX + 2);

      let peakMult = 0;
      let settledMult = 0;

      for (let i = 0; i < totalFrames; i++) {
        saturate();
        step(0.1);
        const cm = capMult(svc);
        if (cm > peakMult) peakMult = cm;
        settledMult = cm;
      }

      const settle_minus_max = settledMult - MAX;
      const peak_over_max    = Math.max(0, peakMult - MAX);

      if (expected.settle_minus_max !== "__skip__") {
        expect(settle_minus_max).toBe(expected.settle_minus_max);
      }
      if (expected.peak_over_max !== "__skip__") {
        expect(peak_over_max).toBe(expected.peak_over_max);
      }

    } else if (inputs.scenario === "warming_is_billed") {
      // First measure single-instance per-frame upkeep on a FRESH node (no scaling).
      // Use a separate world so the measurement is clean.
      resetWorld();
      const fresh = place("compute");
      STATE.upkeepEnabled = true;
      const moneyBefore = STATE.money;
      step(0.1);
      const moneyAfter = STATE.money;
      const baseDrain = moneyBefore - moneyAfter;

      // Now measure an auto-scaling node's upkeep while an instance is warming.
      resetWorld();
      const svc2 = place("compute");
      svc2.autoScaling = true;
      STATE.upkeepEnabled = true;

      const capMult2 = (s) => Math.round(s.getEffectiveCapacity() / BASE);
      let maxBilledMult = 1;

      // Upper bound: SUSTAIN + WARMUP + some slack = expected warmup completion + buffer.
      // Scale-up triggers after SUSTAIN, warmup completes after another WARMUP seconds.
      const maxFrames = Math.round((SUSTAIN + WARMUP + 5) / 0.1);
      let frameCount = 0;

      // Drive saturated load until the first capMult rise (warmup completes).
      // Record billedMult for every frame where capMult is still 1 (not yet warmed).
      while (frameCount < maxFrames) {
        const cmBefore = capMult2(svc2);
        if (cmBefore > 1) break;

        const monB = STATE.money;
        svc2.queue = new Array(400).fill({});
        svc2.processing = [];
        step(0.1);
        frameCount++;
        const monA = STATE.money;
        const drain = monB - monA;
        if (baseDrain > 0) {
          const billedMult = Math.round(drain / baseDrain);
          if (billedMult > maxBilledMult) maxBilledMult = billedMult;
        }
      }

      const warm_extra_billed = Math.min(1, maxBilledMult - 1);

      if (expected.warm_extra_billed !== "__skip__") {
        expect(warm_extra_billed).toBe(expected.warm_extra_billed);
      }

    } else if (inputs.scenario === "cooldown_gates_second_boot") {
      const riseTimes = [];
      let prevMult = capMult(svc);
      let frameIndex = 0;

      // After scale-up at SUSTAIN, warmup takes WARMUP seconds -> first rise.
      // After first rise: another SUSTAIN -> second scale-up -> another WARMUP -> second rise.
      // Max time: 2*(SUSTAIN + WARMUP) + buffer. Use generous 10x.
      const maxFrames = Math.round((SUSTAIN + WARMUP) * 2 * 10 / 0.1);

      while (riseTimes.length < 2 && frameIndex < maxFrames) {
        saturate();
        step(0.1);
        frameIndex++;
        const cm = capMult(svc);
        if (cm > prevMult) {
          riseTimes.push(frameIndex * 0.1);
          prevMult = cm;
        }
      }

      const gap = riseTimes[1] - riseTimes[0];
      const cooldown_slack = Math.max(0, Math.round((COOLDOWN - gap) / 0.1));

      if (expected.cooldown_slack !== "__skip__") {
        expect(cooldown_slack).toBe(expected.cooldown_slack);
      }
    }
  });
});
