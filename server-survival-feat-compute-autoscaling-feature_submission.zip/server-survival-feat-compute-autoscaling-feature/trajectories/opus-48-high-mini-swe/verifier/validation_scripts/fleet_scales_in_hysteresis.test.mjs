// @ts-nocheck
import { describe, test, expect, beforeEach } from "vitest";
import { STATE, CONFIG, resetWorld, place, step } from "../../helpers/sim-world.mjs";
import { getTestCases } from "./validationParams.js";

beforeEach(() => resetWorld());

const AS = CONFIG.services.compute.autoScaling;

describe("fleet_scales_in_hysteresis", () => {
  const cases = getTestCases();
  test.each(cases)("case %#", ({ inputs, expected }) => {
    resetWorld();

    const SUSTAIN   = AS.scaleUpAfter;
    const WARMUP    = AS.warmupTime;
    const COOLDOWN  = AS.scaleDownAfter;
    const MIN       = AS.minInstances;
    const MAX       = AS.maxInstances;
    const HIGH_UTIL = AS.scaleUpLoad;
    const LOW_UTIL  = AS.scaleDownLoad;
    const MID       = (HIGH_UTIL + LOW_UTIL) / 2;
    const BASE      = CONFIG.services.compute.capacity;

    const capMult = (s) => Math.round(s.getEffectiveCapacity() / BASE);

    // Helper: grow the fleet to a stable plateau under saturated load.
    // Runs enough frames for the fleet to reach MAX and have all instances warmed.
    function growToStablePlateau(svc) {
      const totalFrames = Math.round((SUSTAIN + WARMUP + COOLDOWN) / 0.1) * (MAX + 2);
      for (let i = 0; i < totalFrames; i++) {
        svc.queue = new Array(400).fill({});
        svc.processing = [];
        step(0.1);
      }
    }

    if (inputs.scenario === "idle_shrinks_to_min") {
      const svc = place("compute");
      svc.autoScaling = true;

      growToStablePlateau(svc);
      const grownMult = capMult(svc);

      // Drive idle load for long enough to scale all the way back down.
      const idleFrames = Math.round((SUSTAIN + COOLDOWN) / 0.1) * (MAX + 2);
      for (let i = 0; i < idleFrames; i++) {
        svc.queue = [];
        svc.processing = [];
        step(0.1);
      }

      const grown_over_max        = Math.max(0, grownMult - MAX);
      const idle_settle_minus_min = capMult(svc) - MIN;

      if (expected.grown_over_max !== "__skip__") {
        expect(grown_over_max).toBe(expected.grown_over_max);
      }
      if (expected.idle_settle_minus_min !== "__skip__") {
        expect(idle_settle_minus_min).toBe(expected.idle_settle_minus_min);
      }

    } else if (inputs.scenario === "dead_band_holds") {
      const svc = place("compute");
      svc.autoScaling = true;

      growToStablePlateau(svc);
      const entryMult = capMult(svc);

      // Hold load at MID utilization (inside the dead band).
      const holdFrames = Math.round((SUSTAIN + COOLDOWN) / 0.1) * (MAX + 2);
      let minMult = entryMult;
      let maxMult = entryMult;

      for (let i = 0; i < holdFrames; i++) {
        const n = Math.round(MID * svc.getEffectiveCapacity() * 2);
        svc.queue = new Array(n).fill({});
        svc.processing = [];
        step(0.1);
        const cm = capMult(svc);
        if (cm < minMult) minMult = cm;
        if (cm > maxMult) maxMult = cm;
      }

      const afterMult  = capMult(svc);
      const band_delta  = afterMult - entryMult;
      const band_spread = maxMult - minMult;

      if (expected.band_delta !== "__skip__") {
        expect(band_delta).toBe(expected.band_delta);
      }
      if (expected.band_spread !== "__skip__") {
        expect(band_spread).toBe(expected.band_spread);
      }

    } else if (inputs.scenario === "dip_resets_streak") {
      const svc = place("compute");
      svc.autoScaling = true;

      // Drive saturated load for just under SUSTAIN so no scale-out triggers.
      const hotFrames = Math.round((SUSTAIN - 0.5) / 0.1);
      for (let i = 0; i < hotFrames; i++) {
        svc.queue = new Array(400).fill({});
        svc.processing = [];
        step(0.1);
      }

      // Dip into the dead band — resets the busy-streak timer.
      const dipFrames = Math.round(1.0 / 0.1);
      for (let i = 0; i < dipFrames; i++) {
        const n = Math.round(MID * svc.getEffectiveCapacity() * 2);
        svc.queue = new Array(n).fill({});
        svc.processing = [];
        step(0.1);
      }

      // Drive saturated load again for just under SUSTAIN — should still not trigger.
      for (let i = 0; i < hotFrames; i++) {
        svc.queue = new Array(400).fill({});
        svc.processing = [];
        step(0.1);
      }

      const dip_reset_growth = capMult(svc) - 1;

      if (expected.dip_reset_growth !== "__skip__") {
        expect(dip_reset_growth).toBe(expected.dip_reset_growth);
      }

    } else if (inputs.scenario === "min_is_floor") {
      const svc = place("compute");
      svc.autoScaling = true;
      // Fresh fleet: already at minimum (1 instance, warmedInstances=1).

      const idleFrames = Math.round((SUSTAIN + COOLDOWN) / 0.1) * 3;
      let minCapMult = capMult(svc);

      for (let i = 0; i < idleFrames; i++) {
        svc.queue = [];
        svc.processing = [];
        step(0.1);
        const cm = capMult(svc);
        if (cm < minCapMult) minCapMult = cm;
      }

      const min_floor_offset = minCapMult - MIN;

      if (expected.min_floor_offset !== "__skip__") {
        expect(min_floor_offset).toBe(expected.min_floor_offset);
      }
    }
  });
});
