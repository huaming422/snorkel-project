// @ts-nocheck
import { describe, test, expect, beforeEach } from "vitest";
import { STATE, CONFIG, resetWorld, place, step } from "../../helpers/sim-world.mjs";
import { getTestCases } from "./validationParams.js";

beforeEach(() => resetWorld());

describe("non_asg_unchanged", () => {
  const cases = getTestCases();
  test.each(cases)("case %#", ({ inputs, expected }) => {
    resetWorld();

    const serviceType = inputs.service_type;
    const BASE = CONFIG.services[serviceType].capacity;

    const AS = CONFIG.services.compute?.autoScaling;
    const SUSTAIN  = AS ? AS.scaleUpAfter   : 3;
    const WARMUP   = AS ? AS.warmupTime     : 5;
    const COOLDOWN = AS ? AS.scaleDownAfter : 6;
    const MAX      = AS ? AS.maxInstances   : 6;

    let svc;

    if (inputs.scenario === "compute_scaling_off") {
      // Place a Compute node, enable scaling, then disable it (the discovered toggle:
      // direct property assignment — the implementation has no separate toggle function).
      svc = place("compute");
      svc.autoScaling = true;   // enable
      svc.autoScaling = false;  // disable — ends with scaling OFF
    } else {
      // "other_type": place the specified non-Compute service type.
      // autoScaling defaults to false; no toggle needed or applicable.
      svc = place(serviceType);
    }

    // Measure static single-instance numbers BEFORE driving any load.
    // Put exactly BASE items in queue and clear processing.
    svc.queue = new Array(BASE).fill({});
    svc.processing = [];

    const cap_over_base = Math.round(svc.getEffectiveCapacity() / BASE);
    const load_milli    = Math.round(svc.totalLoad * 1000);

    // Prove the service never grows under sustained saturation.
    // Drive saturated load for a full scale-out window.
    const totalFrames = Math.round((SUSTAIN + WARMUP + COOLDOWN) / 0.1) * (MAX + 2);
    let grownMax = Math.round(svc.getEffectiveCapacity() / BASE);

    for (let i = 0; i < totalFrames; i++) {
      svc.queue = new Array(400).fill({});
      svc.processing = [];
      step(0.1);
      const cm = Math.round(svc.getEffectiveCapacity() / BASE);
      if (cm > grownMax) grownMax = cm;
    }

    const grown_under_load_mult = grownMax;

    expect(cap_over_base).toBe(expected.cap_over_base);
    expect(load_milli).toBe(expected.load_milli);
    expect(grown_under_load_mult).toBe(expected.grown_under_load_mult);
  });
});
