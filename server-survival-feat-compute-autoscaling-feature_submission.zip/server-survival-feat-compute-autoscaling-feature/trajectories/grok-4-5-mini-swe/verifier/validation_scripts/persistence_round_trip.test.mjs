// @ts-nocheck
import { describe, it, expect, beforeEach } from "vitest";
import { STATE, CONFIG, resetWorld, place, step } from "../../helpers/sim-world.mjs";
import { saveGameState, loadGameState } from "../../../src/persistence/save-load.js";
import { getTestCases } from "./validationParams.js";

const SAVE_KEY = "serverSurvivalSave";

beforeEach(() => {
  resetWorld();
  if (globalThis.localStorage) globalThis.localStorage.removeItem(SAVE_KEY);
});

function enableASG(svc) {
  svc.autoScalingEnabled = true;
  svc.instanceCount = 1;
  svc.instanceWarmups = [0];
  svc.scaleOutTimer = 0;
  svc.scaleInTimer = 0;
  svc.scaleCooldown = 0;
  return svc;
}

function capMult(svc, BASE) {
  return Math.round(svc.getEffectiveCapacity() / BASE);
}

function saturate(svc) {
  svc.queue = new Array(400).fill({});
  svc.processing = [];
}

// Grow a fleet to its stable MAX plateau under saturated load.
function growToStablePlateau(svc, cfg, MAX, BASE) {
  const maxFrames = Math.round((cfg.scaleOutDelay + cfg.warmUpTime + cfg.cooldown) / 0.1) * (MAX + 2);
  let stableCount = 0;
  let lastMult = capMult(svc, BASE);

  for (let f = 0; f < maxFrames; f++) {
    saturate(svc);
    step(0.1);
    const cm = capMult(svc, BASE);
    if (cm === lastMult) {
      stableCount++;
    } else {
      stableCount = 0;
      lastMult = cm;
    }
    if (stableCount >= Math.round((cfg.warmUpTime + cfg.cooldown) / 0.1) && cm === MAX) {
      break;
    }
  }
}

// Perform a save → reset → restore round-trip. Returns the restored service.
function doRoundTrip(savedId) {
  saveGameState("browser");
  const j = globalThis.localStorage.getItem(SAVE_KEY);
  resetWorld();
  globalThis.localStorage.setItem(SAVE_KEY, j);
  loadGameState();
  return STATE.services.find(s => s.id === savedId);
}

describe("persistence_round_trip", () => {
  const cases = getTestCases();

  cases.forEach(({ inputs, expected }) => {
    it(`scenario: ${inputs.scenario}`, () => {
      const cfg = CONFIG.services.compute.autoScaling;
      const BASE = CONFIG.services.compute.capacity;
      const SUSTAIN = cfg.scaleOutDelay;
      const WARMUP = cfg.warmUpTime;
      const COOLDOWN = cfg.cooldown;
      const MAX = cfg.maxInstances;

      if (inputs.scenario === "grown_round_trip") {
        const svc = enableASG(place("compute"));
        const savedId = svc.id;
        growToStablePlateau(svc, cfg, MAX, BASE);
        const savedMult = capMult(svc, BASE);

        const restored = doRoundTrip(savedId);
        const restoredMult = capMult(restored, BASE);

        const restored_minus_saved = restoredMult - savedMult;
        const restored_over_max = Math.max(0, restoredMult - MAX);

        if (expected.restored_minus_saved !== "__skip__") {
          expect(restored_minus_saved).toBe(expected.restored_minus_saved);
        }
        if (expected.restored_over_max !== "__skip__") {
          expect(restored_over_max).toBe(expected.restored_over_max);
        }

      } else if (inputs.scenario === "pre_feature_save") {
        const svc = place("compute");
        const savedId = svc.id;
        saveGameState("browser");

        // Simulate a legacy save: delete the two ASG fields from the saved JSON
        const raw = JSON.parse(globalThis.localStorage.getItem(SAVE_KEY));
        raw.services.forEach(s => {
          delete s.autoScalingEnabled;
          delete s.instanceCount;
        });
        globalThis.localStorage.setItem(SAVE_KEY, JSON.stringify(raw));

        resetWorld();
        loadGameState();

        const restored = STATE.services.find(s => s.id === savedId);
        const cap_over_base = capMult(restored, BASE);

        if (expected.cap_over_base !== "__skip__") {
          expect(cap_over_base).toBe(expected.cap_over_base);
        }

      } else if (inputs.scenario === "tamper_clamped") {
        const svc = enableASG(place("compute"));
        const savedId = svc.id;

        // Grow a little under saturated load
        const growFrames = Math.round((SUSTAIN + WARMUP + COOLDOWN) / 0.1);
        for (let f = 0; f < growFrames; f++) {
          saturate(svc);
          step(0.1);
        }

        saveGameState("browser");

        // Tamper: set instanceCount far above MAX
        const raw = JSON.parse(globalThis.localStorage.getItem(SAVE_KEY));
        const savedSvc = raw.services.find(s => s.id === savedId);
        savedSvc.instanceCount = 999;
        globalThis.localStorage.setItem(SAVE_KEY, JSON.stringify(raw));

        resetWorld();
        loadGameState();

        const restored = STATE.services.find(s => s.id === savedId);
        const restoredMult = capMult(restored, BASE);
        const restored_over_max = restoredMult - MAX;

        if (expected.restored_over_max !== "__skip__") {
          expect(restored_over_max).toBe(expected.restored_over_max);
        }

      } else if (inputs.scenario === "warming_not_persisted") {
        const svc = enableASG(place("compute"));
        const savedId = svc.id;

        // Drive saturated load for SUSTAIN + WARMUP*0.6 seconds:
        // long enough that one instance booted and is still warming
        const warmFrames = Math.round((SUSTAIN + WARMUP * 0.6) / 0.1);
        for (let f = 0; f < warmFrames; f++) {
          saturate(svc);
          step(0.1);
        }

        const savedReadyMult = capMult(svc, BASE);

        const restored = doRoundTrip(savedId);
        const restoredMult = capMult(restored, BASE);

        const restored_minus_ready = restoredMult - savedReadyMult;

        // After reload, drive IDLE load and track max capMult
        const idleFrames = Math.round((WARMUP + COOLDOWN) / 0.1);
        let maxCapMultAfterReload = restoredMult;
        for (let f = 0; f < idleFrames; f++) {
          restored.queue = [];
          restored.processing = [];
          step(0.1);
          const cm = capMult(restored, BASE);
          if (cm > maxCapMultAfterReload) maxCapMultAfterReload = cm;
        }

        const post_reload_growth = maxCapMultAfterReload - restoredMult;

        if (expected.restored_minus_ready !== "__skip__") {
          expect(restored_minus_ready).toBe(expected.restored_minus_ready);
        }
        if (expected.post_reload_growth !== "__skip__") {
          expect(post_reload_growth).toBe(expected.post_reload_growth);
        }
      }
    });
  });
});
