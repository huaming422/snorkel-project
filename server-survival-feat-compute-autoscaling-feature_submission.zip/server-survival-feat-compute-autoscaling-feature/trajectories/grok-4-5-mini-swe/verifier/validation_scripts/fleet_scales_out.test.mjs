// @ts-nocheck
import { describe, it, expect, beforeEach } from "vitest";
import { STATE, CONFIG, resetWorld, place, step } from "../../helpers/sim-world.mjs";
import { getTestCases } from "./validationParams.js";

const SAVE_KEY = "serverSurvivalSave";

beforeEach(() => {
  resetWorld();
  if (globalThis.localStorage) globalThis.localStorage.removeItem(SAVE_KEY);
});

// Enable auto-scaling on a compute node by directly setting the fields
// the submission initializes in the Service constructor.
function enableASG(svc) {
  svc.autoScalingEnabled = true;
  svc.instanceCount = 1;
  svc.instanceWarmups = [0];
  svc.scaleOutTimer = 0;
  svc.scaleInTimer = 0;
  svc.scaleCooldown = 0;
  return svc;
}

function capMult(svc, BASE) {
  return Math.round(svc.getEffectiveCapacity() / BASE);
}

function saturate(svc) {
  svc.queue = new Array(400).fill({});
  svc.processing = [];
}

describe("fleet_scales_out", () => {
  const cases = getTestCases();

  cases.forEach(({ inputs, expected }) => {
    it(`scenario: ${inputs.scenario}`, () => {
      const cfg = CONFIG.services.compute.autoScaling;
      const BASE = CONFIG.services.compute.capacity;
      const SUSTAIN = cfg.scaleOutDelay;
      const WARMUP = cfg.warmUpTime;
      const COOLDOWN = cfg.cooldown;
      const MAX = cfg.maxInstances;

      if (inputs.scenario === "cold_start_then_ready") {
        const svc = enableASG(place("compute"));

        const earlyFrame = Math.round((SUSTAIN + WARMUP / 2) / 0.1);
        const readyFrame = Math.round((SUSTAIN + WARMUP + COOLDOWN / 2) / 0.1);

        let cap_mult_early = null;
        let cap_mult_after_ready = null;

        for (let f = 0; f < readyFrame + 1; f++) {
          saturate(svc);
          step(0.1);
          if (f + 1 === earlyFrame) {
            cap_mult_early = capMult(svc, BASE);
          }
          if (f + 1 === readyFrame) {
            cap_mult_after_ready = capMult(svc, BASE);
          }
        }

        if (expected.cap_mult_early !== "__skip__") {
          expect(cap_mult_early).toBe(expected.cap_mult_early);
        }
        if (expected.cap_mult_after_ready !== "__skip__") {
          expect(cap_mult_after_ready).toBe(expected.cap_mult_after_ready);
        }

      } else if (inputs.scenario === "settle_at_ceiling") {
        const svc = enableASG(place("compute"));
        const totalFrames = Math.round((SUSTAIN + WARMUP + COOLDOWN) / 0.1) * (MAX + 2);

        let peakMult = 1;
        let settledMult = 1;

        for (let f = 0; f < totalFrames; f++) {
          saturate(svc);
          step(0.1);
          const cm = capMult(svc, BASE);
          if (cm > peakMult) peakMult = cm;
          settledMult = cm;
        }

        const settle_minus_max = settledMult - MAX;
        const peak_over_max = Math.max(0, peakMult - MAX);

        if (expected.settle_minus_max !== "__skip__") {
          expect(settle_minus_max).toBe(expected.settle_minus_max);
        }
        if (expected.peak_over_max !== "__skip__") {
          expect(peak_over_max).toBe(expected.peak_over_max);
        }

      } else if (inputs.scenario === "warming_is_billed") {
        // Step 1: measure baseDrain on a plain (non-ASG) compute node
        resetWorld();
        const baseSvc = place("compute");
        STATE.upkeepEnabled = true;
        const moneyBefore0 = STATE.money;
        step(0.1);
        const baseDrain = moneyBefore0 - STATE.money;

        // Step 2: ASG compute node under saturated load
        resetWorld();
        const svc = enableASG(place("compute"));
        STATE.upkeepEnabled = true;

        let maxBilledMult = 1;

        for (let f = 0; f < 10000; f++) {
          saturate(svc);
          const moneyBefore = STATE.money;
          step(0.1);
          const drain = moneyBefore - STATE.money;
          const cm = capMult(svc, BASE);
          if (cm === 1) {
            // Capacity has not yet risen — the new instance is warming
            const billedMult = Math.round(drain / baseDrain);
            if (billedMult > maxBilledMult) maxBilledMult = billedMult;
          } else {
            // Capacity rose: the warming instance is now ready — stop
            break;
          }
        }

        const warm_extra_billed = Math.min(1, maxBilledMult - 1);

        if (expected.warm_extra_billed !== "__skip__") {
          expect(warm_extra_billed).toBe(expected.warm_extra_billed);
        }

      } else if (inputs.scenario === "cooldown_gates_second_boot") {
        const svc = enableASG(place("compute"));

        const rises = [];
        const maxFrames = Math.round((SUSTAIN + WARMUP + COOLDOWN) / 0.1) * (MAX + 2) * 2;
        let prevMult = 1;

        for (let f = 0; f < maxFrames; f++) {
          saturate(svc);
          step(0.1);
          const cm = capMult(svc, BASE);
          if (cm > prevMult) {
            rises.push(f * 0.1);
            prevMult = cm;
          }
          if (rises.length >= 2) break;
        }

        if (rises.length >= 2) {
          const gap = rises[1] - rises[0];
          const cooldown_slack = Math.max(0, Math.round((COOLDOWN - gap) / 0.1));

          if (expected.cooldown_slack !== "__skip__") {
            expect(cooldown_slack).toBe(expected.cooldown_slack);
          }
        } else {
          if (expected.cooldown_slack !== "__skip__") {
            throw new Error(`Expected 2 capMult rises but got ${rises.length}`);
          }
        }
      }
    });
  });
});
