// @ts-nocheck
import { describe, it, expect, beforeEach } from "vitest";
import { STATE, CONFIG, resetWorld, place, step } from "../../helpers/sim-world.mjs";
import { getTestCases } from "./validationParams.js";

const SAVE_KEY = "serverSurvivalSave";

beforeEach(() => {
  resetWorld();
  if (globalThis.localStorage) globalThis.localStorage.removeItem(SAVE_KEY);
});

function enableASG(svc) {
  svc.autoScalingEnabled = true;
  svc.instanceCount = 1;
  svc.instanceWarmups = [0];
  svc.scaleOutTimer = 0;
  svc.scaleInTimer = 0;
  svc.scaleCooldown = 0;
  return svc;
}

function capMult(svc, BASE) {
  return Math.round(svc.getEffectiveCapacity() / BASE);
}

function saturate(svc) {
  svc.queue = new Array(400).fill({});
  svc.processing = [];
}

// Grow a fleet to its stable MAX plateau under continuous saturated load.
// Runs until capMult == MAX and has been stable for enough frames to confirm.
function growToStablePlateau(svc, cfg, MAX, BASE) {
  const maxFrames = Math.round((cfg.scaleOutDelay + cfg.warmUpTime + cfg.cooldown) / 0.1) * (MAX + 2);
  let stableCount = 0;
  let lastMult = capMult(svc, BASE);

  for (let f = 0; f < maxFrames; f++) {
    saturate(svc);
    step(0.1);
    const cm = capMult(svc, BASE);
    if (cm === lastMult) {
      stableCount++;
    } else {
      stableCount = 0;
      lastMult = cm;
    }
    // Break once the fleet is stable at MAX for a full warm-up+cooldown window
    if (stableCount >= Math.round((cfg.warmUpTime + cfg.cooldown) / 0.1) && cm === MAX) {
      break;
    }
  }
}

describe("fleet_scales_in_hysteresis", () => {
  const cases = getTestCases();

  cases.forEach(({ inputs, expected }) => {
    it(`scenario: ${inputs.scenario}`, () => {
      const cfg = CONFIG.services.compute.autoScaling;
      const BASE = CONFIG.services.compute.capacity;
      const SUSTAIN = cfg.scaleOutDelay;
      const WARMUP = cfg.warmUpTime;
      const COOLDOWN = cfg.cooldown;
      const MIN = cfg.minInstances;
      const MAX = cfg.maxInstances;
      const HIGH_UTIL = cfg.scaleOutLoad;
      const LOW_UTIL = cfg.scaleInLoad;
      const MID = (HIGH_UTIL + LOW_UTIL) / 2;

      if (inputs.scenario === "idle_shrinks_to_min") {
        const svc = enableASG(place("compute"));
        growToStablePlateau(svc, cfg, MAX, BASE);
        const grownMult = capMult(svc, BASE);

        // Drive idle load for a long window: enough for MAX→MIN scale-ins
        const idleFrames = Math.round((SUSTAIN + COOLDOWN) / 0.1) * (MAX + 2);
        for (let f = 0; f < idleFrames; f++) {
          svc.queue = [];
          svc.processing = [];
          step(0.1);
        }
        const finalMult = capMult(svc, BASE);

        const grown_over_max = Math.max(0, grownMult - MAX);
        const idle_settle_minus_min = finalMult - MIN;

        if (expected.grown_over_max !== "__skip__") {
          expect(grown_over_max).toBe(expected.grown_over_max);
        }
        if (expected.idle_settle_minus_min !== "__skip__") {
          expect(idle_settle_minus_min).toBe(expected.idle_settle_minus_min);
        }

      } else if (inputs.scenario === "dead_band_holds") {
        const svc = enableASG(place("compute"));
        growToStablePlateau(svc, cfg, MAX, BASE);
        const entryMult = capMult(svc, BASE);

        // Hold load in the middle band: neither scale-in nor scale-out fires
        const holdFrames = Math.round((SUSTAIN + COOLDOWN) / 0.1) * (MAX + 2);
        let minMult = entryMult;
        let maxObsMult = entryMult;
        let afterMult = entryMult;

        for (let f = 0; f < holdFrames; f++) {
          const n = Math.round(MID * svc.getEffectiveCapacity() * 2);
          svc.queue = new Array(n).fill({});
          svc.processing = [];
          step(0.1);
          const cm = capMult(svc, BASE);
          if (cm < minMult) minMult = cm;
          if (cm > maxObsMult) maxObsMult = cm;
          afterMult = cm;
        }

        const band_delta = afterMult - entryMult;
        const band_spread = maxObsMult - minMult;

        if (expected.band_delta !== "__skip__") {
          expect(band_delta).toBe(expected.band_delta);
        }
        if (expected.band_spread !== "__skip__") {
          expect(band_spread).toBe(expected.band_spread);
        }

      } else if (inputs.scenario === "dip_resets_streak") {
        const svc = enableASG(place("compute"));

        // Hot for SUSTAIN-0.5 seconds — does NOT complete the sustain window
        const hotFrames = Math.round((SUSTAIN - 0.5) / 0.1);
        for (let f = 0; f < hotFrames; f++) {
          saturate(svc);
          step(0.1);
        }

        // Dip into the middle band for 1 second — resets the scale-out streak
        const dipFrames = Math.round(1.0 / 0.1);
        for (let f = 0; f < dipFrames; f++) {
          const n = Math.round(MID * svc.getEffectiveCapacity() * 2);
          svc.queue = new Array(n).fill({});
          svc.processing = [];
          step(0.1);
        }

        // Hot again for SUSTAIN-0.5 seconds — again does NOT complete sustain
        for (let f = 0; f < hotFrames; f++) {
          saturate(svc);
          step(0.1);
        }

        const dip_reset_growth = capMult(svc, BASE) - 1;

        if (expected.dip_reset_growth !== "__skip__") {
          expect(dip_reset_growth).toBe(expected.dip_reset_growth);
        }

      } else if (inputs.scenario === "min_is_floor") {
        const svc = enableASG(place("compute"));
        // Fleet starts at MIN (1 instance), idle load
        const totalFrames = Math.round((SUSTAIN + COOLDOWN) / 0.1) * 3;
        let minCapMult = capMult(svc, BASE);

        for (let f = 0; f < totalFrames; f++) {
          svc.queue = [];
          svc.processing = [];
          step(0.1);
          const cm = capMult(svc, BASE);
          if (cm < minCapMult) minCapMult = cm;
        }

        const min_floor_offset = minCapMult - MIN;

        if (expected.min_floor_offset !== "__skip__") {
          expect(min_floor_offset).toBe(expected.min_floor_offset);
        }
      }
    });
  });
});
