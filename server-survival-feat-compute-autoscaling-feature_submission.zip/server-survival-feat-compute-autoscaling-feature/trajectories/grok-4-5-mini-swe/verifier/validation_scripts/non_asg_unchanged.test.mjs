// @ts-nocheck
import { describe, it, expect, beforeEach } from "vitest";
import { STATE, CONFIG, resetWorld, place, step } from "../../helpers/sim-world.mjs";
import { getTestCases } from "./validationParams.js";

const SAVE_KEY = "serverSurvivalSave";

beforeEach(() => {
  resetWorld();
  if (globalThis.localStorage) globalThis.localStorage.removeItem(SAVE_KEY);
});

describe("non_asg_unchanged", () => {
  const cases = getTestCases();

  cases.forEach(({ inputs, expected }) => {
    it(`scenario: ${inputs.scenario}, service_type: ${inputs.service_type}`, () => {
      const cfg = CONFIG.services.compute.autoScaling;
      const SUSTAIN = cfg.scaleOutDelay;
      const WARMUP = cfg.warmUpTime;
      const COOLDOWN = cfg.cooldown;
      const MAX = cfg.maxInstances;

      const serviceType = inputs.service_type;
      const BASE = CONFIG.services[serviceType].capacity;

      let svc;

      if (inputs.scenario === "compute_scaling_off") {
        // Place Compute, enable then disable scaling (toggle twice)
        svc = place("compute");
        // Enable
        svc.autoScalingEnabled = true;
        svc.instanceCount = 1;
        svc.instanceWarmups = [0];
        svc.scaleOutTimer = 0;
        svc.scaleInTimer = 0;
        svc.scaleCooldown = 0;
        // Disable
        svc.autoScalingEnabled = false;
        svc.instanceCount = 1;
        svc.instanceWarmups = [0];
      } else if (inputs.scenario === "other_type") {
        // Place non-Compute service; enabling ASG is a no-op for non-compute
        svc = place(serviceType);
        // Attempt to enable — updateAutoScaling() guards on type === "compute"
        if (typeof svc.autoScalingEnabled !== "undefined") {
          svc.autoScalingEnabled = true;
        }
      }

      // Measure capacity and load with BASE items in queue
      svc.queue = new Array(BASE).fill({});
      svc.processing = [];

      const cap_over_base = Math.round(svc.getEffectiveCapacity() / BASE);
      const load_milli = Math.round(svc.totalLoad * 1000);

      // Drive saturated load for a full scale-out window; track max capMult
      const totalFrames = Math.round((SUSTAIN + WARMUP + COOLDOWN) / 0.1) * (MAX + 2);
      let grown_under_load_mult = 1;

      for (let f = 0; f < totalFrames; f++) {
        svc.queue = new Array(400).fill({});
        svc.processing = [];
        step(0.1);
        const cm = Math.round(svc.getEffectiveCapacity() / BASE);
        if (cm > grown_under_load_mult) grown_under_load_mult = cm;
      }

      expect(cap_over_base).toBe(expected.cap_over_base);
      expect(load_milli).toBe(expected.load_milli);
      expect(grown_under_load_mult).toBe(expected.grown_under_load_mult);
    });
  });
});
