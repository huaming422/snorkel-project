#!/usr/bin/env bash
# test-setup.sh — verifier environment bootstrap for server-survival.
# Sourced (not exec'd) by the harbor verifier runner, so exported env vars
# and PATH changes stay alive for the vitest run. Idempotent.
#
# The image already ran `npm ci` at the task's REPO_SHA with a warm npm
# cache, so this is normally a no-op. We re-install offline-first only if an
# agent erased node_modules along the way. The game has no build step.

set -e

REPO_DIR="${REPO_DIR:-/repo/server-survival}"
cd "$REPO_DIR"

node --version

if [ ! -d node_modules ]; then
    echo "[test-setup] node_modules missing — npm ci (offline cache first)..."
    npm ci --cache /opt/cache/npm --prefer-offline > /tmp/npm-ci.log 2>&1 \
      || { echo "[test-setup] offline npm ci failed; retrying online"; \
           npm ci --cache /opt/cache/npm > /tmp/npm-ci.log 2>&1 \
           || { tail -40 /tmp/npm-ci.log; exit 1; }; }
fi

# Make the local vitest binary reachable.
export PATH="$REPO_DIR/node_modules/.bin:$PATH"

echo "[test-setup] ready: $REPO_DIR (node=$(node --version))"
