#!/usr/bin/env bash
# validation-setup.sh — environment bootstrap for the validation story scripts.
#
# The simulation tests run under vitest's happy-dom environment with a THREE
# stub and an index.html DOM fixture installed by tests/helpers/sim-setup.mjs.
# The driver copies each generated story file to tests/sim/__validation__/,
# which the repo's own vitest projects do NOT glob (they match only the
# single level tests/sim/*.test.mjs). This script writes a dedicated vitest
# config that globs the __validation__ subtree under the same happy-dom
# environment + setup file, so the generated files run with the full sim
# harness. The game is served raw — there is NO build step.

set -e

REPO_DIR="${REPO_DIR:-/repo/server-survival}"
cd "$REPO_DIR"

node --version

# Re-install deps offline-first only if an agent erased node_modules. The
# image already ran `npm ci` at the task SHA with a warm cache.
if [ ! -d node_modules ]; then
    echo "[validation-setup] node_modules missing — npm ci (offline cache first)..."
    npm ci --cache /opt/cache/npm --prefer-offline > /tmp/val-npm-ci.log 2>&1 \
      || { echo "[validation-setup] offline npm ci failed; retrying online"; \
           npm ci --cache /opt/cache/npm > /tmp/val-npm-ci.log 2>&1 \
           || { tail -40 /tmp/val-npm-ci.log; exit 1; }; }
fi

export PATH="$REPO_DIR/node_modules/.bin:$PATH"

# Dedicated validation config: same happy-dom environment and setup file as
# the repo's "sim" project, but globbing the driver's __validation__ drop
# directory (which the repo config's single-level glob misses). Written fresh
# every run so an agent edit to the repo config cannot break validation.
cat > "$REPO_DIR/vitest.validation.mjs" <<'VITEST_CFG'
import { defineConfig } from "vitest/config";

// Validation story runner: the driver copies generated story files to
// tests/sim/__validation__/<id>.test.mjs. The repo's own vitest "sim"
// project globs only tests/sim/*.test.mjs (single level), so those files
// need this config. Same happy-dom environment + THREE/DOM setup file as
// the sim project.
export default defineConfig({
  test: {
    environment: "happy-dom",
    include: ["tests/sim/__validation__/**/*.test.mjs"],
    setupFiles: ["tests/helpers/sim-setup.mjs"],
  },
});
VITEST_CFG

# Loud smoke guard: fail NOW (not mid-story) if the sim harness cannot boot.
# Writes a throwaway test into the real validation dir, runs it through the
# validation config, and removes it. This exercises the exact path the
# driver uses: happy-dom + sim-setup + a relative import of the pre-existing
# sim-world helper.
SMOKE_DIR="$REPO_DIR/tests/sim/__validation__"
mkdir -p "$SMOKE_DIR"
SMOKE_FILE="$SMOKE_DIR/__setup_smoke__.test.mjs"
cat > "$SMOKE_FILE" <<'SMOKE'
import { describe, it, expect } from "vitest";
import { CONFIG, resetWorld, place } from "../../helpers/sim-world.mjs";
describe("validation-setup smoke", () => {
  it("boots the sim harness and places a service", () => {
    resetWorld();
    const svc = place("compute");
    expect(typeof svc.getEffectiveCapacity()).toBe("number");
    expect(CONFIG.services.compute.capacity).toBeGreaterThan(0);
  });
});
SMOKE

smoke_rc=0
npx vitest run "$SMOKE_FILE" --config vitest.validation.mjs --reporter=dot \
  > /tmp/val-smoke.log 2>&1 || smoke_rc=$?
rm -f "$SMOKE_FILE"
if [ "$smoke_rc" -ne 0 ]; then
    echo "[validation-setup] FATAL: sim harness smoke test failed:"
    tail -60 /tmp/val-smoke.log
    exit 1
fi

echo "[validation-setup] ready: $REPO_DIR (node=$(node --version)); sim harness OK"
