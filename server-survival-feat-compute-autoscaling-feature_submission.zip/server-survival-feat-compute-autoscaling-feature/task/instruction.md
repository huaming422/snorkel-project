## Task

We want our Compute nodes to scale themselves. When one is running hot it should bring up extra capacity on its own, and wind that capacity back down once traffic quiets, the way an auto-scaling group does.

Two properties matter while you build this. Freshly added capacity needs a short warm-up before it starts carrying load, and the scaling should stay calm instead of flapping on and off around the busy point.

Keep it to Compute nodes, and no UI work is needed here; the whole change lives in behavior.

## User stories / requirements

- When an auto-scaling Compute fleet stays busy for a while, it brings up another instance. That instance carries no load until it has warmed up, so capacity rises only once it is ready, though the fleet pays for it from boot. However hot it runs, the fleet never grows past its maximum instance count.
- When an auto-scaling Compute fleet goes quiet, it gives back instances over time. Inside a middle band of load it holds its current size steady rather than flapping up and down, and it never shrinks below its minimum instance count.
- A service that is not an auto-scaling Compute node, and a Compute node with auto-scaling switched off, delivers exactly the same capacity and load as it did before this feature existed.
- Saving the game and reloading it brings an auto-scaling fleet back at the size it was running at, with the capacity that size provides. A save made before this feature existed still loads, coming back with auto-scaling off and a single instance.

## General instructions

- The code repo is at /repo/server-survival.
- You are inside of a Docker container with no network access. You may not be able to perform all operations you would normally be able to do on a local machine. The project's dependencies and toolchain are already installed and the package manager caches are populated, so build and test with what is in the image; anything that needs to be downloaded will fail rather than hang.
- You are expected to act autonomously as a software engineer to complete tasks you are given.
- Do not stop until you feel you have completed the task and your code changes can be merged.
- You may need to use software engineering skills like analyzing the codebase, researching technologies, running services, analyzing logs, etc. to complete the task. Not all tasks will be solvable by reading source code alone.
