## Task

we've got a data-access hole in dataset management. a user with no data-access grant on a given table can still read its rows just by being the editor or owner of a dataset that's named after or points near that table. editorship is standing in for actual access to the data.

worse, it survives revocation: an admin can strip every real grant the user has, and they keep reading the table for as long as they can create or edit a dataset referencing it. and it's not one screen, it reproduces through the ordinary dataset workflows, creating a dataset, editing and saving an existing one, and importing one. no ad-hoc SQL needed.

this is a security regression in how these paths authorize access to the tables behind a dataset. figure out why editorship is being accepted as data access and close it, so they require genuine access to the referenced table. don't over-correct: someone who legitimately holds broader database- or schema-level access should still work with datasets as today, and a dataset's own owner must keep exploring their own dataset.
