# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
"""
Behavioral checks for the dataset table-binding authorization contract.

These tests exercise the behavior through the *pre-existing, stable* public
interfaces that users drive -- the dataset create/update/duplicate commands,
the v1 import entry point, the query-backed chart-data processor, and the
central access method's long-standing signature. Each test runs the real
authorization machinery end to end and asserts only the observable allow/deny
outcome; it never passes, imports, or asserts any name that a solution is free
to invent (an opt-out keyword, the param-comparison helpers, the render/param
validation error classes, the per-call-site private helpers).

That keeps the tests agnostic to *how* a solution wires the behavior in -- a
keyword on the central check, a dedicated wrapper, a shared base-command hook,
a mixin, or an inlined comparison all satisfy them equally -- while still
failing any solution that lets dataset editorship substitute for real data
access on the define/repoint paths, or that over-corrects and blocks a
legitimate schema/catalog holder, or that fails open on unreadable params.

Fixtures are deliberately self-contained: when this file is collected from the
``verify/`` directory the repository's own unit-test ``conftest`` is not in
scope, so the app/app-context fixtures and an in-memory session are defined
locally. The app builder and the feature-flag helper are imported from the
repository's stable unit-test support module (they build the same app the rest
of the unit tier uses).

The data-access primitives the check consults -- whether the caller holds a
direct grant, a broader schema/catalog grant, access to the whole connection,
is an editor of a registered dataset, and which datasets are registered for a
table -- are the only things stubbed, so each scenario is a precise "who holds
what" world. Everything downstream (SQL parsing, Jinja rendering, catalog and
schema permission derivation, the engine spec) runs for real.
"""

from __future__ import annotations

import uuid
from contextlib import contextmanager
from types import SimpleNamespace
from typing import Any, Iterator
from unittest.mock import patch

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from tests.unit_tests.conftest import build_app, with_feature_flags

# The application must be constructed before the command modules below are
# imported: their table-mapped models (e.g. the connection model's encrypted
# columns) resolve an application-bound field factory at class-definition time,
# which raises unless an app already exists. The repository's own test tiers get
# this for free because a session-scoped conftest builds the app before any test
# module is collected; collected from this directory that conftest is not in
# scope, so the app is built here, once, at import.
_APP = build_app()

from superset import db, security_manager  # noqa: E402
from superset.commands.dataset.create import CreateDatasetCommand  # noqa: E402
from superset.commands.dataset.duplicate import (  # noqa: E402
    DuplicateDatasetCommand,
)
from superset.commands.dataset.exceptions import (  # noqa: E402
    DatasetAccessDeniedError,
    DatasetDataAccessIsNotAllowed,
    DatasetForbiddenError,
    DatasetInvalidError,
)
from superset.commands.dataset.importers.v1.utils import (  # noqa: E402
    import_dataset,
)
from superset.commands.dataset.update import UpdateDatasetCommand  # noqa: E402
from superset.common.query_context_processor import (  # noqa: E402
    QueryContextProcessor,
)
from superset.connectors.sqla.models import SqlaTable  # noqa: E402
from superset.exceptions import SupersetSecurityException  # noqa: E402
from superset.models.core import Database  # noqa: E402
from superset.utils import json as superset_json  # noqa: E402
from superset.utils.core import DatasourceType  # noqa: E402
# Imported at module top (under the app built above) rather than lazily inside
# the legacy-save test: the view module pulls in engine specs whose class bodies
# call flask-babel's ``_`` at import, which needs the babel extension the built
# app installs -- importing it later under a bare request context would raise.
from superset.views.datasource.views import Datasource as _DatasourceView  # noqa: E402


# --------------------------------------------------------------------------- #
# App / context fixtures (self-contained; conftest is out of scope here).
# --------------------------------------------------------------------------- #
@pytest.fixture(scope="module")
def app() -> Any:
    return _APP


@pytest.fixture(autouse=True)
def app_context(app: Any) -> Iterator[None]:
    with app.app_context():
        yield


# --------------------------------------------------------------------------- #
# Grant "kinds" the access check asks about. These are the long-standing
# permission view-menu names the authorization layer has always used, not
# anything a solution introduces.
# --------------------------------------------------------------------------- #
GRANT_DATASOURCE = "datasource_access"
GRANT_SCHEMA = "schema_access"
GRANT_CATALOG = "catalog_access"

# Connection label used for the real engine-backed database. Deliberately not
# any database name referenced in test SQL -- the behavior must not depend on
# it (the connection label is a renameable display name).
CONN_NAME = "probe_conn"

# A registered dataset for the referenced table whose perm the caller does NOT
# hold -- the "decoy" a would-be attacker could be editor of.
DECOY_PERM = f"[{CONN_NAME}].[public].[orders](id:1)"


# --------------------------------------------------------------------------- #
# Databases. Two real engine-backed connections so URL parsing, engine-spec
# resolution and SQL parsing all run for real:
#   * a SQLite connection (no server catalogs) for the schema fallthrough and
#     the SQL/template paths;
#   * an MSSQL connection (real T-SQL dialect) for the catalog fallthrough,
#     which SQLite cannot model -- mirroring the connection kind the repo's own
#     offline unit tests use to exercise catalogs without a live server.
# The only live-connection call (resolving a query's default schema) is stubbed
# so no server is required.
# --------------------------------------------------------------------------- #
def _sqlite_database() -> Database:
    database = Database(database_name=CONN_NAME, sqlalchemy_uri="sqlite://")
    patch.object(
        database, "get_default_schema_for_query", return_value=None
    ).start()
    return database


def _mssql_database() -> Database:
    database = Database(
        database_name=CONN_NAME,
        sqlalchemy_uri="mssql+pymssql://user:pw@host:1433/abcm",
    )
    patch.object(
        database, "get_default_schema_for_query", return_value=None
    ).start()
    return database


@pytest.fixture(autouse=True)
def _stop_patches() -> Iterator[None]:
    """Ensure every ad-hoc ``patch.object(...).start()`` is torn down."""
    yield
    patch.stopall()


@contextmanager
def access_world(
    *,
    grants: set[str] | None = None,
    grant_view_menus: set[str] | None = None,
    is_editor: bool = False,
    registered_perm: str | None = None,
    database_access: bool = False,
) -> Iterator[None]:
    """Install a 'who holds what' world around the real access check.

    :param grants: permission kinds the caller holds for ANY view-menu
        (e.g. ``{schema_access}``); use this for the simple "holds the kind"
        scenarios.
    :param grant_view_menus: when set, the caller holds a grant only for these
        exact ``(kind == perm) and (view_menu in grant_view_menus)`` pairs --
        used to pin a grant to a specific catalog/schema/dataset perm string.
    :param is_editor: whether the caller is an editor/owner of the registered
        dataset the lookup returns.
    :param registered_perm: perm string of a dataset registered for the
        referenced table (``None`` -> no dataset registered for it).
    :param database_access: whether the caller has access to the whole
        connection (the broadest grant, which short-circuits everything).
    """
    grants = grants or set()
    grant_view_menus = grant_view_menus or set()

    def can_access(permission: str, view_menu: str) -> bool:
        if permission in grants:
            return True
        return bool(grant_view_menus) and view_menu in grant_view_menus

    registered = (
        [SimpleNamespace(perm=registered_perm, sql=None, catalog=None)]
        if registered_perm
        else []
    )

    with (
        patch.object(security_manager, "can_access", side_effect=can_access),
        patch.object(
            security_manager, "can_access_database", return_value=database_access
        ),
        patch.object(security_manager, "can_access_schema", return_value=False),
        patch.object(
            security_manager, "_semantic_layer_grant_allows", return_value=False
        ),
        patch.object(security_manager, "is_editor", return_value=is_editor),
        patch.object(security_manager, "is_admin", return_value=False),
        patch.object(security_manager, "is_guest_user", return_value=False),
        patch.object(
            SqlaTable, "query_datasources_by_name", return_value=registered
        ),
    ):
        yield


def _access_denied(exc: DatasetInvalidError) -> bool:
    """Whether a command's validation failure was a data-access denial."""
    return any(
        isinstance(e, DatasetDataAccessIsNotAllowed) for e in exc._exceptions
    )


# --------------------------------------------------------------------------- #
# Create-command driver. Patches only the DAO lookups that would otherwise hit
# a metadata DB; the access decision underneath is the real one.
# --------------------------------------------------------------------------- #
def _run_create(database: Database, properties: dict[str, Any]) -> None:
    with (
        patch(
            "superset.commands.dataset.create.DatasetDAO.get_database_by_id",
            return_value=database,
        ),
        patch(
            "superset.commands.dataset.create.DatasetDAO.validate_uniqueness",
            return_value=True,
        ),
        patch(
            "superset.commands.dataset.create.DatasetDAO.validate_table_exists",
            return_value=True,
        ),
        patch(
            "superset.commands.dataset.create.populate_subjects",
            return_value=None,
        ),
    ):
        CreateDatasetCommand(properties).validate()


# =========================================================================== #
# crit_editorship_default_preserved  (pass_to_pass)
# Explore-your-own-dataset is preserved: on the datasource= branch (the path
# chart-data takes for a saved TABLE dataset, via query_context= → datasource=
# routing), a dataset editor still passes with no other grant. A solution that
# strips editorship acceptance from the datasource= branch outright (not just
# the define/repoint call sites) would break the owner-explore guarantee.
# =========================================================================== #
def test_editor_passes_on_default_path() -> None:
    # The "explore your own dataset" path runs through raise_for_access with
    # the dataset object itself (the datasource= branch). Chart-data on a saved
    # TABLE dataset routes query_context= → datasource= in the real chart-data
    # path; we exercise the branch directly so the test is not coupled to
    # QueryContextProcessor internals and remains valid for all design shapes
    # (boolean opt-out param, separate wrapper, centralized hook, or wholesale
    # removal from the define/repoint sites — any approach that keeps the
    # datasource= branch accepting editorship by default passes).
    datasource = SimpleNamespace(
        perm=DECOY_PERM,
        sql=None,
        catalog=None,
        type=DatasourceType.TABLE,  # required by raise_for_unsupported_guest_rls
    )
    with access_world(is_editor=True, registered_perm=DECOY_PERM):
        # Must not raise: editorship authorizes exploring your own dataset
        # via the datasource= branch.
        security_manager.raise_for_access(datasource=datasource)


# =========================================================================== #
# crit_strict_vs_editorship_distinct  (fail_to_pass)
# Query-backed chart-data runs a stored query's raw SQL, so editorship of a
# same-named dataset must NOT authorize its tables there.
# =========================================================================== #
def test_editor_denied_on_query_backed_chart_data() -> None:
    database = _sqlite_database()
    stored_query = SimpleNamespace(
        type=DatasourceType.QUERY,
        database=database,
        schema="public",
        catalog=None,
        sql="SELECT * FROM orders",
    )
    query_context = SimpleNamespace(datasource=stored_query, queries=[])
    processor = QueryContextProcessor(query_context)

    with access_world(is_editor=True, registered_perm=DECOY_PERM):
        with pytest.raises(SupersetSecurityException):
            processor.raise_for_access()


# =========================================================================== #
# crit_refusing_editorship_keeps_schema_catalog  (pass_to_pass)
# Refusing editorship must NOT drop the schema / catalog fallthroughs: a
# schema-access (or catalog-access) holder can still define a dataset over the
# table. This rejects the over-restrictive overfix (reusing the strict mode,
# which drops these fallthroughs). Driven through the real create command so
# the command's own call-site choice is what is exercised.
# =========================================================================== #
def test_schema_holder_can_create_physical_dataset() -> None:
    database = _sqlite_database()
    with access_world(grants={GRANT_SCHEMA}):
        # No editorship, no registered dataset -- only the broader grant holds.
        _run_create(
            database, {"database": 1, "table_name": "orders", "schema": "public"}
        )  # must not raise


def test_catalog_holder_can_create_physical_dataset() -> None:
    # SQLite cannot model catalogs; use a real MSSQL connection whose engine
    # spec reports catalog support, exactly as the repo's own offline tests do.
    database = _mssql_database()
    patch.object(database.db_engine_spec, "supports_catalog", True).start()
    catalog_perm = f"[{CONN_NAME}].[other]"
    with access_world(grants=set(), grant_view_menus={catalog_perm}):
        _run_create(
            database,
            {
                "database": 1,
                "table_name": "foo",
                "schema": "dbo",
                "catalog": "other",
            },
        )  # must not raise


# =========================================================================== #
# crit_create_requires_data_access  (fail_to_pass)
# Creating a dataset over a table the caller cannot access is refused even when
# the caller is the editor of a same-named decoy dataset.
# =========================================================================== #
def test_create_refused_for_editor_without_data_access() -> None:
    database = _sqlite_database()
    with access_world(is_editor=True, registered_perm=DECOY_PERM):
        with pytest.raises(DatasetInvalidError) as excinfo:
            _run_create(
                database,
                {"database": 1, "table_name": "orders", "schema": "public"},
            )
    assert _access_denied(excinfo.value)


def test_create_allowed_with_real_data_access() -> None:
    database = _sqlite_database()
    # The caller holds a genuine datasource grant on the registered dataset.
    with access_world(
        grants={GRANT_DATASOURCE}, registered_perm=DECOY_PERM
    ):
        _run_create(
            database, {"database": 1, "table_name": "orders", "schema": "public"}
        )  # must not raise


# =========================================================================== #
# crit_templated_from_authorized  (fail_to_pass)
# A virtual dataset whose SQL is ``SELECT * FROM {{ p }}`` is authorized
# against the table the submitted params actually resolve to, not a default.
# =========================================================================== #
@with_feature_flags(ENABLE_TEMPLATE_PROCESSING=True)
def test_templated_create_refused_when_resolved_table_inaccessible() -> None:
    database = _sqlite_database()
    # No grant anywhere, editor of a decoy: the resolved table is private.
    with access_world(is_editor=True, registered_perm=DECOY_PERM):
        with pytest.raises(DatasetInvalidError) as excinfo:
            _run_create(
                database,
                {
                    "database": 1,
                    "table_name": "report",
                    "schema": "public",
                    "sql": "SELECT * FROM {{ p }}",
                    "template_params": '{"p": "private.secret"}',
                },
            )
    assert _access_denied(excinfo.value)


@with_feature_flags(ENABLE_TEMPLATE_PROCESSING=True)
def test_templated_create_allowed_when_resolved_schema_accessible() -> None:
    database = _sqlite_database()
    # Hold schema access to the schema the params resolve the FROM to.
    schema_perm = f"[{CONN_NAME}].[private]"
    with access_world(grants=set(), grant_view_menus={schema_perm}):
        _run_create(
            database,
            {
                "database": 1,
                "table_name": "report",
                "schema": "public",
                "sql": "SELECT * FROM {{ p }}",
                "template_params": '{"p": "private.secret"}',
            },
        )  # must not raise


# =========================================================================== #
# crit_update_requires_data_access  (fail_to_pass)
# Repointing an existing dataset to an inaccessible table is refused for a user
# who only edits it; a metadata-only save that does not change the binding
# still succeeds.
# =========================================================================== #
def _existing_model(database: Database, **overrides: Any) -> SqlaTable:
    model = SqlaTable(
        table_name="orders",
        schema="public",
        catalog=None,
        database=database,
        sql=None,
        template_params=None,
    )
    for key, value in overrides.items():
        setattr(model, key, value)
    return model


@contextmanager
def _update_world(model: SqlaTable) -> Iterator[None]:
    with (
        patch(
            "superset.commands.dataset.update.DatasetDAO.find_by_id",
            return_value=model,
        ),
        patch.object(security_manager, "raise_for_editorship", return_value=None),
        patch(
            "superset.commands.dataset.update.raise_if_managed_externally",
            return_value=None,
        ),
        patch(
            "superset.commands.dataset.update.compute_subjects",
            return_value=None,
        ),
        patch(
            "superset.commands.dataset.update.DatasetDAO.validate_update_uniqueness",
            return_value=True,
        ),
    ):
        yield


def _run_update(model_id: int, properties: dict[str, Any]) -> None:
    UpdateDatasetCommand(model_id, properties).validate()


def test_update_repoint_schema_refused_for_editor_without_access() -> None:
    database = _sqlite_database()
    model = _existing_model(database)
    with (
        _update_world(model),
        access_world(is_editor=True, registered_perm=DECOY_PERM),
    ):
        with pytest.raises(DatasetInvalidError) as excinfo:
            # Repoint the physical dataset to a different schema.
            _run_update(1, {"schema": "private"})
    assert _access_denied(excinfo.value)


def test_update_metadata_only_save_succeeds_for_editor() -> None:
    database = _sqlite_database()
    model = _existing_model(database, description="old")
    with (
        _update_world(model),
        access_world(is_editor=True, registered_perm=DECOY_PERM),
    ):
        # No binding change -> no data-access re-check -> editor can still save.
        _run_update(1, {"description": "new"})  # must not raise


# --------------------------------------------------------------------------- #
# crit_params_type_sensitive_equiv  (fail_to_pass)
# A params-only change that execution would read differently (a templated FROM
# resolving to another table) re-authorizes the binding; a params echo that
# renders identically does not. Type-sensitive: {"t": 1} vs {"t": true} differ.
# --------------------------------------------------------------------------- #
@with_feature_flags(ENABLE_TEMPLATE_PROCESSING=True)
def test_update_params_only_repoint_refused_for_editor() -> None:
    database = _sqlite_database()
    model = _existing_model(
        database,
        table_name="report",
        sql="SELECT * FROM {{ t }}",
        template_params='{"t": "public.ok"}',
    )
    with (
        _update_world(model),
        access_world(is_editor=True, registered_perm=DECOY_PERM),
    ):
        with pytest.raises(DatasetInvalidError) as excinfo:
            # Same SQL text, new params repoint the FROM to a private table.
            _run_update(1, {"template_params": '{"t": "private.secret"}'})
    assert _access_denied(excinfo.value)


@with_feature_flags(ENABLE_TEMPLATE_PROCESSING=True)
def test_update_params_echo_does_not_block_editor() -> None:
    database = _sqlite_database()
    model = _existing_model(
        database,
        table_name="report",
        sql="SELECT * FROM {{ t }}",
        template_params='{"t": "public.ok"}',
    )
    with (
        _update_world(model),
        access_world(is_editor=True, registered_perm=DECOY_PERM),
    ):
        # Re-sending the same params (reformatted) is not a repoint.
        _run_update(1, {"template_params": '{"t":   "public.ok"}'})  # must not raise


# =========================================================================== #
# non_object_template_params_fail_closed  (fail_to_pass)
# A template_params value that is not a JSON object (e.g. a JSON array or a
# bare scalar) must be rejected as invalid, not silently accepted. A solution
# that passes unreadable params through the access check without validation
# (fail-open) could let a user supply arbitrary Jinja input and still score
# correctness 1.0 — this test makes that gap visible to the reward stack.
# The oracle validates params format in its template_params_equivalent helper
# (fail-closed on unreadable) and surfaces the error through the command's
# DatasetInvalidError aggregate. Any implementation that rejects non-object
# params — whether via a shared helper, inlined JSON type check, or eager
# validation in the command — passes.
# =========================================================================== #
@with_feature_flags(ENABLE_TEMPLATE_PROCESSING=True)
def test_nonobject_template_params_rejected_fail_closed() -> None:
    database = _sqlite_database()
    model = _existing_model(
        database,
        table_name="report",
        sql="SELECT * FROM {{ t }}",
        template_params='{"t": "public.ok"}',
    )
    with (
        _update_world(model),
        access_world(is_editor=True, registered_perm=DECOY_PERM),
    ):
        # A JSON array is not a valid params object: the fix must reject it,
        # never authorize against a guessed or default render (fail closed).
        with pytest.raises((DatasetInvalidError, SupersetSecurityException)):
            _run_update(1, {"template_params": "[1, 2, 3]"})


# =========================================================================== #
# crit (AP6 coverage, surface D): duplicate command.
# Copying a virtual dataset runs the base's stored SQL as the caller's own new
# dataset, so it requires real data access to the tables that SQL reads -- not
# editorship of the base (which the object-level check above accepts). An
# editor of the base with no data access is refused.
# =========================================================================== #
def test_duplicate_refused_for_editor_without_sql_access() -> None:
    database = _sqlite_database()
    base_model = _existing_model(
        database,
        table_name="base_virtual",
        sql="SELECT * FROM orders",
        template_params=None,
    )
    with (
        patch(
            "superset.commands.dataset.duplicate.DatasetDAO.find_by_id",
            return_value=base_model,
        ),
        patch(
            "superset.commands.dataset.duplicate.DatasetDAO.validate_uniqueness",
            return_value=True,
        ),
        access_world(is_editor=True, registered_perm=DECOY_PERM),
    ):
        # A denial here may surface as the forbidden-error this command already
        # raises for base-object access, as the validation-error aggregate the
        # sibling define paths use, or as the raw authorization error -- assert
        # that the copy is refused, not one chosen wrapper class.
        with pytest.raises(
            (
                DatasetAccessDeniedError,
                DatasetInvalidError,
                SupersetSecurityException,
            )
        ):
            DuplicateDatasetCommand(
                {"base_model_id": 1, "table_name": "copy"}
            ).validate()


# =========================================================================== #
# crit_import_requires_data_access_premutation  (fail_to_pass)
# Overwriting a dataset to repoint it to an inaccessible table is refused, and
# the refusal happens against the REQUESTED binding before the stored row is
# mutated. Runs against a real in-memory session so ``import_from_dict`` and the
# pre-mutation ordering are genuinely exercised.
# =========================================================================== #
@contextmanager
def _in_memory_session() -> Iterator[Any]:
    """A real in-memory SQLite session wired where the import code reads it.

    Mirrors the repository's own unit-test session fixture: patch the shared
    ``db.session`` so the import code (and the pre-mutation lookups) see one
    in-memory connection. The physical-table binding check consulted here does
    not read the security manager's own session, so only ``db.session`` needs
    redirecting.
    """
    engine = create_engine("sqlite://")
    session = sessionmaker(bind=engine)()
    session.remove = lambda: None  # flask calls db.session.remove()
    with patch("superset.db.session", session):
        SqlaTable.metadata.create_all(engine)
        yield session


def _import_config(database_id: int, **overrides: Any) -> dict[str, Any]:
    config: dict[str, Any] = {
        "uuid": str(uuid.uuid4()),
        "table_name": "orders",
        "schema": "public",
        "catalog": None,
        "sql": "",
        "database_id": database_id,
        "metrics": [],
        "columns": [],
    }
    config.update(overrides)
    return config


def test_import_overwrite_repoint_refused_without_data_access() -> None:
    with _in_memory_session() as session:
        database = Database(database_name=CONN_NAME, sqlalchemy_uri="sqlite://")
        session.add(database)
        session.flush()
        ds_uuid = str(uuid.uuid4())
        existing = SqlaTable(
            table_name="orders",
            schema="public",
            catalog=None,
            database=database,
            uuid=ds_uuid,
        )
        session.add(existing)
        session.flush()

        config = _import_config(
            database.id, uuid=ds_uuid, schema="private"  # repoint to a new schema
        )
        # can_write granted (reach the binding check) and editor (pass the
        # overwrite permission gate) -- the only thing that can refuse is the
        # table-binding authorization against the REQUESTED (private) schema.
        with access_world(
            grant_view_menus={"Dataset"},  # the can_write("Dataset") gate
            is_editor=True,
            registered_perm=DECOY_PERM,
            database_access=False,
        ):
            # The denial may surface either as the data-access failure this
            # command family raises or as the underlying authorization error it
            # wraps -- assert the refusal, not one chosen wrapper class.
            with pytest.raises((DatasetAccessDeniedError, SupersetSecurityException)):
                import_dataset(config, overwrite=True)

            # The refusal must have fired before the stored row was mutated.
            assert session.get(SqlaTable, existing.id).schema == "public"


# =========================================================================== #
# crit_legacy_save_refuses_editorship  (fail_to_pass)
# The legacy /datasource/save/ endpoint (the deprecated Datasource.save view
# that still backs the Explore "Edit dataset" dialog) also repoints an
# existing dataset. "editing and saving an existing one" (base.md) covers this
# path, so the save must require genuine data access on the target table, not
# editorship of a same-named decoy dataset.
#
# Driven through the public view exactly as the repository's own
# tests/unit_tests/views/datasource/views_test.py does: the Flask-AppBuilder
# permission decorators are peeled off with ``inspect.unwrap`` and the body is
# invoked inside a POST request context carrying the save payload. The access
# decision underneath is the real ``raise_for_access`` running in the
# ``access_world`` -- the only things stubbed are the DAO lookup that would hit
# a metadata DB and the editorship gate the endpoint applies before the
# table-binding check (the caller legitimately owns the dataset being edited).
# That keeps the test agnostic to how a solution threads the fix: a flag on the
# central check, a dedicated wrapper, an inlined comparison, or a shared hook
# all satisfy it, and it never imports a private helper a valid alternative is
# free to rename or inline.
# =========================================================================== #
import inspect as _inspect  # noqa: E402


def _unwrapped_save() -> Any:
    """The underlying ``Datasource.save`` body, past the FAB permission
    decorators (mirrors the repo's own ``inspect.unwrap`` view-test helper)."""
    return _inspect.unwrap(_DatasourceView.save)


def _save_view_self() -> SimpleNamespace:
    """A minimal stand-in for the bound view instance ``save`` runs against."""
    return SimpleNamespace(json_response=lambda data, *a, **k: data)


def test_legacy_save_repoint_refused_for_editor_without_access() -> None:
    """The legacy save endpoint refuses an editor-only repoint to a private table.

    The caller owns the dataset being edited (the editorship gate the endpoint
    runs first is satisfied) but holds no datasource / schema / database grant
    on the schema the save repoints the dataset to. They are an editor of a
    same-named decoy dataset, so a check that still honors editorship on the
    table-binding step would wrongly authorize the move. The save must be
    refused -- surfaced as the forbidden error this endpoint raises or the
    underlying authorization error it wraps -- whatever shape the fix takes.
    """
    with _in_memory_session() as session:
        # Flush so database.id and datasource.database_id are real integers:
        # _authorize_repoint's database-not-found guard returns an error
        # response (not raise) when datasource.database is None, which would
        # silently prevent the access check from firing.
        database = Database(database_name=CONN_NAME, sqlalchemy_uri="sqlite://")
        patch.object(
            database, "get_default_schema_for_query", return_value=None
        ).start()
        session.add(database)
        session.flush()

        datasource = SqlaTable(
            table_name="orders",
            schema="public",
            catalog=None,
            database=database,
            sql=None,
            template_params=None,
        )
        session.add(datasource)
        session.flush()

        payload = {
            "id": datasource.id,
            "type": "table",
            "columns": [],
            "database": {"id": database.id},
            # Repoint the physical dataset to a different, inaccessible schema.
            "table_name": "secret",
            "schema": "private",
        }
        # Run in the built app's context so the real access check's flask-babel
        # message lookup and feature-flag reads resolve, exactly as the
        # repository's own view tests run under the session app.
        with (
            patch(
                "superset.views.datasource.views.DatasourceDAO.get_datasource",
                return_value=datasource,
            ),
            # The caller genuinely owns the dataset being edited: the
            # endpoint's editorship gate passes, isolating the table-binding
            # access decision.
            patch.object(
                security_manager, "raise_for_editorship", return_value=None
            ),
            access_world(is_editor=True, registered_perm=DECOY_PERM),
            _APP.test_request_context(
                "/datasource/save/",
                method="POST",
                data={"data": superset_json.dumps(payload)},
            ),
        ):
            with pytest.raises((DatasetForbiddenError, SupersetSecurityException)):
                _unwrapped_save()(_save_view_self())
