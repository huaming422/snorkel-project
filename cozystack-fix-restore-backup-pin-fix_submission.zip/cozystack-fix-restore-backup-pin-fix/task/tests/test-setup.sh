#!/usr/bin/env bash
# All dependencies the verifier needs are baked into the image:
#   - Go 1.27.1 with the full module + build-cache closure at the base commit
#     (so `go test ./internal/backupcontroller/...` compiles offline),
#   - helm 3.19.0 + the helm-unittest 1.2.1 plugin under /opt/helm (so
#     `helm unittest` renders the postgres chart offline).
# Nothing to install at verifier time.
set -euo pipefail
echo "[test-setup] no-op for cozystack-fix-restore-backup-pin (deps baked into image)"
