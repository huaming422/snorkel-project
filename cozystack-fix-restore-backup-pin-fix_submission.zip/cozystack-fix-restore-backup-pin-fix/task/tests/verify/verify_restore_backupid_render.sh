#!/usr/bin/env bash
#
# Renders the postgres chart and checks that a restore carries its base-backup
# selector into the recovery target of the cnpg.io Cluster it emits. Fails on a
# tree that does not render the selector (the restore then cannot ask for a
# specific base backup, and the barman-cloud plugin picks one from the catalog).
#
# The value the chart reads the selector from is a shape the chart shapes (the
# existing recovery block already renders .Values.bootstrap.recoveryTime onto the
# CNPG field named targetTime — the value key and the CNPG field are not the same
# word), so this verifier does not assume what that value is called. It reads the
# recovery value keys the chart's own template references, takes the one(s) added
# beyond the recovery keys the chart already had, and renders with that key set.
# What it then asserts is the CNPG Cluster's own field: the base-backup selector
# lands at bootstrap.recovery.recoveryTarget.backupID, which is the name the
# cnpg.io Cluster CRD gives it.
#
# Exit codes:
#   0        — the selector reaches recoveryTarget.backupID
#   non-zero — it does not (unfixed tree, or the selector never renders)

set -euo pipefail

REPO="/repo/${REPO_NAME:-cozystack}"
CHART="${REPO}/packages/apps/postgres"
TEMPLATE_DIR="${CHART}/templates"

# A distinctive, timestamp-shaped id that does not collide with the other
# recovery values the render carries (server names, the recovery instant).
BACKUP_ID="20260921T062713"
RECOVERY_TIME="2026-09-22T10:00:00Z"

# Recovery value keys the chart already had before a base-backup selector was
# added. Any bootstrap value key the template references beyond these is the
# chart's chosen name for the selector.
KNOWN_BOOTSTRAP_KEYS=$'enabled\noldName\nserverName\nnewServerName\nrecoveryTime'

if [[ ! -d "${TEMPLATE_DIR}" ]]; then
  echo "render: chart templates not found at ${TEMPLATE_DIR}" >&2
  exit 1
fi

# Every .Values.bootstrap.<key> the chart templates read, minus the keys it
# already had. On an unfixed tree this is empty; once a selector is wired it
# names it. Scans the whole templates tree so a selector routed through a helper
# template is still found.
mapfile -t NEW_KEYS < <(
  grep -rhoE '\.Values\.bootstrap\.[A-Za-z0-9]+' "${TEMPLATE_DIR}" \
    | sed 's/.*\.//' \
    | sort -u \
    | grep -vxF "${KNOWN_BOOTSTRAP_KEYS}" || true
)

# Common inputs for a restore render: a bootstrap.recovery with S3 coordinates.
SET_ARGS=(
  --set-json '_cluster.scheduling={}'
  --set backup.enabled=true
  --set backup.useSystemBucket=false
  --set backup.s3AccessKey=AKIAEXAMPLE
  --set backup.s3SecretKey=s3cr3t
  --set backup.destinationPath=s3://bucket/pg-test/
  --set bootstrap.enabled=true
  --set bootstrap.oldName=pg-test
  --set "bootstrap.recoveryTime=${RECOVERY_TIME}"
)
# Set each newly-wired bootstrap value key to the id; the one that is the
# selector carries it into the render.
for k in "${NEW_KEYS[@]}"; do
  [[ -n "${k}" ]] && SET_ARGS+=(--set "bootstrap.${k}=${BACKUP_ID}")
done

cd "${CHART}"
RENDER="$(helm template pg-test . --namespace tenant-test "${SET_ARGS[@]}")"

# The base-backup selector must reach the cnpg.io Cluster's own recoveryTarget
# field. Scope the search to the recoveryTarget block so an id appearing
# elsewhere cannot stand in for it.
if printf '%s\n' "${RENDER}" \
    | grep -A8 'recoveryTarget:' \
    | grep -qE "backupID:[[:space:]]*\"?${BACKUP_ID}\"?"; then
  echo "ok: restore pins its base backup at recoveryTarget.backupID (${BACKUP_ID})"
  exit 0
fi

echo "fail: the restore did not carry its base backup into recoveryTarget.backupID;" >&2
echo "      the recovery would let the plugin pick a backup from the catalog instead." >&2
if [[ ${#NEW_KEYS[@]} -eq 0 || -z "${NEW_KEYS[*]}" ]]; then
  echo "      (the template references no recovery value key beyond the pre-existing ones.)" >&2
fi
exit 1
