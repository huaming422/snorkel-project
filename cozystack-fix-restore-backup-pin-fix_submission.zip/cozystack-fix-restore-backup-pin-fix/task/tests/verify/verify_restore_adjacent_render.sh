#!/usr/bin/env bash
#
# Renders the postgres chart and checks that the recovery coordinates next to the
# base-backup selector keep rendering: the restored cluster's fresh archive
# prefix, the recovery source prefix, the requested recovery point, and the
# recovery ObjectStore's source path. This holds on the tree before and after the
# selector is added, so it guards the surrounding recovery render against a
# regression.
#
# helm-unittest's -f globs are relative to the chart directory, so this verifier
# writes the suite it carries into a scratch dir inside the chart, runs the
# render there, then removes it — leaving the chart's own tests untouched. The
# suite is written inline (below) so the verifier is self-contained and needs no
# sibling data file at grade time.
#
# The suite asserts only names the chart already owns before this change (the
# plugin/external-cluster serverName the restore render already shapes, the
# requested recovery point, the recovery ObjectStore's source path) and the
# cnpg.io Cluster's own field names — never a base-backup selector key a solution
# gets to choose.
#
# Exit codes:
#   0        — the suite passes
#   non-zero — propagates the helm-unittest failure

set -euo pipefail

REPO="/repo/${REPO_NAME:-cozystack}"
CHART="${REPO}/packages/apps/postgres"

SCRATCH="${CHART}/.sb-verify-adjacent"
cleanup() { rm -rf "${SCRATCH}"; }
trap cleanup EXIT

mkdir -p "${SCRATCH}"
cat > "${SCRATCH}/restore_adjacent_render_test.yaml" <<'EOF'
suite: restore keeps rendering the adjacent recovery coordinates

# The base-backup selector is added alongside the recovery coordinates the chart
# already renders on restore. Those neighbours must keep rendering unchanged: the
# WAL-archive serverName on the restored cluster's plugin (a fresh prefix, so the
# restored cluster does not archive onto its recovery source), the recovery
# source serverName on the external cluster, and the recovery ObjectStore's
# destinationPath. This is a render contract that holds before and after the
# change, so it guards against a regression in the surrounding recovery render.

templates:
  - templates/db.yaml

release:
  name: pg-test
  namespace: tenant-test

set:
  _cluster:
    scheduling: {}
  backup:
    enabled: true
    useSystemBucket: false
    s3AccessKey: AKIAEXAMPLE
    s3SecretKey: s3cr3t
    destinationPath: s3://bucket/pg-test/
    endpointURL: https://s3.example:9000
  bootstrap:
    enabled: true
    oldName: pg-test
    serverName: pg-test
    newServerName: pg-test-restore-deadbeef
    recoveryTime: "2026-09-22T10:00:00Z"

tests:
  - it: "the restored cluster archives under its fresh prefix, recovers from the source prefix, with the recovery point and source path intact"
    asserts:
      # WAL archiver writes to the fresh restore prefix, never the source's.
      - equal:
          path: spec.plugins[0].parameters.serverName
          value: pg-test-restore-deadbeef
        documentSelector:
          path: kind
          value: Cluster
      # Recovery still reads the source prefix.
      - equal:
          path: spec.externalClusters[0].plugin.parameters.serverName
          value: pg-test
        documentSelector:
          path: kind
          value: Cluster
      # The requested recovery point still reaches the recovery target.
      - equal:
          path: spec.bootstrap.recovery.recoveryTarget.targetTime
          value: 2026-09-22T10:00:00Z
        documentSelector:
          path: kind
          value: Cluster
      # The recovery ObjectStore still carries the source S3 coordinates.
      - equal:
          path: spec.configuration.destinationPath
          value: s3://bucket/pg-test/
        documentSelector:
          path: metadata.name
          value: pg-test-recovery
EOF

cd "${CHART}"
exec helm unittest -f ".sb-verify-adjacent/*_test.yaml" .
