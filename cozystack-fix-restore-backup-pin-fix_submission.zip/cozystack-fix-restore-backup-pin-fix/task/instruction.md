## Task

We've been getting reports that restoring a Postgres cluster from a specific backup sometimes brings back the wrong data, not the state that backup actually captured. It's worst on clusters that have been restored at least once before, and point-in-time restores seem the most affected, but we've even seen it on a plain restore from a named backup landing on the wrong one. Restoring a named backup should always recover exactly that backup's data and nothing else. Can you dig in, find the cause, and fix it?
