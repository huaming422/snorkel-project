"""Behavioral checks for the durable-bridge successor-claim fencing fix.

These tests drive the durable-session ownership layer through its public
coordinator surface (``DurableBridgeSessionCoordinator.claim_live_session`` /
``release_live_session``) against an in-process in-memory SQLite engine — the
exact harness the repository's own ``tests/unit/test_durable_bridge_sessions.py``
uses. They assert only on the returned ``DurableBridgeLookup`` and the resulting
row state, never on private attribute names, SQL text, or attribute-write order,
so any fix that produces the correct observable ownership passes regardless of
how it computes the next epoch or issues its write.

The single permitted internal seam is a monkeypatch of
``durable_bridge_repository.sqlite_writer_section``. It is a timing injection —
the repository's own tests use it to force a competing commit between a claim's
read and its write — not a coupling to any reference-chosen symbol: it is the only
deterministic way to interleave a release/claim inside a single-threaded
asyncio test.
"""

from __future__ import annotations

import contextlib
from collections.abc import AsyncIterator, Callable

import pytest
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from app.db.models import Base, HttpBridgeSessionState
from app.modules.proxy.durable_bridge_coordinator import DurableBridgeSessionCoordinator
from app.modules.proxy.durable_bridge_repository import DurableBridgeRepository


@pytest.fixture
async def async_session_factory() -> AsyncIterator[Callable[[], AsyncSession]]:
    """In-memory SQLite engine + session factory, mirroring the repository's own
    unit-test fixture (``expire_on_commit=False`` so snapshots survive commit)."""
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    session_maker = async_sessionmaker(engine, expire_on_commit=False)

    def get_session() -> AsyncSession:
        return session_maker()

    yield get_session

    await engine.dispose()


@pytest.fixture
async def coordinator(
    async_session_factory: Callable[[], AsyncSession],
) -> DurableBridgeSessionCoordinator:
    return DurableBridgeSessionCoordinator(async_session_factory)


async def _claim(
    coordinator: DurableBridgeSessionCoordinator,
    *,
    session_key_value: str,
    instance_id: str,
    account_id: str = "acc-1",
    allow_takeover: bool,
    latest_turn_state: str | None = None,
    latest_response_id: str | None = None,
    owner_process_epoch: str = "test-process",
):
    """Thin wrapper around ``claim_live_session`` with the fixed test arguments
    the durable-bridge unit suite uses, so each test body reads as its scenario."""
    return await coordinator.claim_live_session(
        session_key_kind="session_header",
        session_key_value=session_key_value,
        api_key_id=None,
        instance_id=instance_id,
        owner_process_epoch=owner_process_epoch,
        lease_ttl_seconds=60.0,
        account_id=account_id,
        model="gpt-5.4",
        service_tier=None,
        latest_turn_state=latest_turn_state,
        latest_response_id=latest_response_id,
        allow_takeover=allow_takeover,
    )


async def test_same_owner_reclaim_fences_predecessor(
    coordinator: DurableBridgeSessionCoordinator,
) -> None:
    """A claim of an existing, live, same-owner row advances the owner epoch, and
    a later release carrying the OLD epoch is fenced out (no-ops), leaving the row
    ACTIVE and owned by the successor.

    Claims arrive only from a successor in-memory session (a reused session
    renews instead of claiming), so a live same-owner row means the predecessor
    local session is retiring concurrently. If the reclaim kept the epoch, the
    predecessor's fenced release would still match after the successor's claim and
    close the row out from under it.
    """
    claimed = await _claim(
        coordinator,
        session_key_value="sid-fence",
        instance_id="instance-a",
        allow_takeover=True,
        latest_turn_state="http_turn_1",
        latest_response_id="resp_1",
    )

    successor = await _claim(
        coordinator,
        session_key_value="sid-fence",
        instance_id="instance-a",
        allow_takeover=True,
        latest_turn_state="http_turn_2",
        latest_response_id="resp_2",
    )

    assert successor.session_id == claimed.session_id
    assert successor.owner_epoch == claimed.owner_epoch + 1, (
        "A same-owner reclaim must advance the owner epoch so the predecessor's "
        f"fenced release no-ops; got epoch {successor.owner_epoch}, expected "
        f"{claimed.owner_epoch + 1}."
    )

    # The predecessor's release carries the OLD epoch: it must be fenced out,
    # leaving the successor's claim live and owned.
    released = await coordinator.release_live_session(
        session_id=claimed.session_id,
        instance_id="instance-a",
        owner_epoch=claimed.owner_epoch,
        draining=False,
    )
    assert released is not None
    assert released.owner_instance_id == "instance-a", (
        "The stale-epoch release must be fenced, leaving the successor as owner; "
        f"got owner {released.owner_instance_id!r}."
    )
    assert released.state == HttpBridgeSessionState.ACTIVE, (
        f"The row must stay ACTIVE after the fenced release; got {released.state!r}."
    )
    assert released.owner_epoch == successor.owner_epoch


async def test_release_mid_claim_authoritative_write(
    coordinator: DurableBridgeSessionCoordinator,
    async_session_factory: Callable[[], AsyncSession],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When the retiring predecessor's fenced release commits between the
    successor claim's SELECT and its write, the claim's committed and returned
    state must still be authoritative: ACTIVE, owned by the claimant, advanced
    epoch — never a closed, ownerless row.

    SQLite's ``with_for_update`` is a no-op, so the release can land mid-claim. A
    write that only mutates ORM attributes lets the interleaved release's
    ``owner=None, state=CLOSED`` survive into the committed/returned snapshot.
    """
    predecessor = await _claim(
        coordinator,
        session_key_value="sid-race",
        instance_id="instance-a",
        allow_takeover=True,
        latest_turn_state="http_turn_1",
        latest_response_id="resp_1",
    )

    import app.modules.proxy.durable_bridge_repository as repository_module

    real_writer_section = repository_module.sqlite_writer_section
    release_injected = False

    @contextlib.asynccontextmanager
    async def writer_section_with_interleaved_release():
        nonlocal release_injected
        if not release_injected:
            release_injected = True
            # The predecessor's fenced release lands exactly between the
            # successor claim's SELECT and its write.
            async with async_session_factory() as release_session:
                await DurableBridgeRepository(release_session).release_session(
                    session_id=predecessor.session_id,
                    instance_id="instance-a",
                    owner_epoch=predecessor.owner_epoch,
                    draining=False,
                )
        async with real_writer_section():
            yield

    monkeypatch.setattr(
        repository_module, "sqlite_writer_section", writer_section_with_interleaved_release
    )

    successor = await _claim(
        coordinator,
        session_key_value="sid-race",
        instance_id="instance-a",
        allow_takeover=False,
    )

    assert release_injected is True, "the interleaved release must have been injected"
    assert successor.session_id == predecessor.session_id
    assert successor.owner_instance_id == "instance-a", (
        "The claim's write must be authoritative over the interleaved release; "
        f"got owner {successor.owner_instance_id!r} (a None/closed owner means the "
        "release survived into the claim's result)."
    )
    assert successor.state == HttpBridgeSessionState.ACTIVE, (
        f"The claimed row must be ACTIVE, not closed by the interleaved release; "
        f"got {successor.state!r}."
    )
    assert successor.owner_epoch == predecessor.owner_epoch + 1


async def test_concurrent_successor_claims_serialize_on_epoch_cas(
    coordinator: DurableBridgeSessionCoordinator,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Two successor claims that both read the same epoch serialize on a
    compare-and-set: exactly one wins per round, the loser re-reads fresh state
    and lands on a distinct, strictly-higher epoch. No two claimants return the
    same ``owner_epoch`` for the same row.
    """
    predecessor = await _claim(
        coordinator,
        session_key_value="sid-cas",
        instance_id="instance-a",
        allow_takeover=True,
    )

    import app.modules.proxy.durable_bridge_repository as repository_module

    real_writer_section = repository_module.sqlite_writer_section
    competitor_epochs: list[int] = []
    injected = False

    @contextlib.asynccontextmanager
    async def writer_section_with_competing_claim():
        nonlocal injected
        if not injected:
            injected = True
            # A competing successor claim commits between this claim's SELECT
            # and its guarded write.
            competitor = await _claim(
                coordinator,
                session_key_value="sid-cas",
                instance_id="instance-a",
                allow_takeover=False,
            )
            competitor_epochs.append(competitor.owner_epoch)
        async with real_writer_section():
            yield

    monkeypatch.setattr(
        repository_module, "sqlite_writer_section", writer_section_with_competing_claim
    )

    raced = await _claim(
        coordinator,
        session_key_value="sid-cas",
        instance_id="instance-a",
        allow_takeover=False,
    )

    assert competitor_epochs == [predecessor.owner_epoch + 1], (
        "The competing claim should have taken the next epoch; got "
        f"{competitor_epochs!r}."
    )
    assert raced.owner_instance_id == "instance-a"
    assert raced.owner_epoch == competitor_epochs[0] + 1, (
        "The raced claim must lose the compare-and-set, re-read fresh state, and "
        f"land on a distinct higher epoch; got {raced.owner_epoch}, expected "
        f"{competitor_epochs[0] + 1}. Two claimants sharing an epoch means the "
        "write did not serialize on the epoch read."
    )


async def test_cas_loser_keeps_hands_off_foreign_lease(
    coordinator: DurableBridgeSessionCoordinator,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A claim that entered with takeover permission (decided against a pre-claim
    lookup of a released row) but then lost the race to a foreign owner must NOT
    reuse that stale permission to steal the winner's live lease: it fails closed
    and reports the foreign winner as the current owner.

    This guards against a naive 'always advance the epoch / always take over on
    retry' fix that re-takes a live foreign row.
    """
    released = await _claim(
        coordinator,
        session_key_value="sid-foreign-cas",
        instance_id="instance-old",
        allow_takeover=True,
    )
    # The previous owner releases: both recovering replicas legitimately see a
    # takeover-eligible row at the moment they decide.
    await coordinator.release_live_session(
        session_id=released.session_id,
        instance_id="instance-old",
        owner_epoch=released.owner_epoch,
        draining=False,
    )

    import app.modules.proxy.durable_bridge_repository as repository_module

    real_writer_section = repository_module.sqlite_writer_section
    injected = False
    winner_epoch: list[int] = []

    @contextlib.asynccontextmanager
    async def writer_section_with_foreign_winner():
        nonlocal injected
        if not injected:
            injected = True
            winner = await _claim(
                coordinator,
                session_key_value="sid-foreign-cas",
                instance_id="instance-b",
                allow_takeover=True,
            )
            winner_epoch.append(winner.owner_epoch)
        async with real_writer_section():
            yield

    monkeypatch.setattr(
        repository_module, "sqlite_writer_section", writer_section_with_foreign_winner
    )

    loser = await _claim(
        coordinator,
        session_key_value="sid-foreign-cas",
        instance_id="instance-a",
        allow_takeover=True,
    )

    assert winner_epoch, "the foreign winner must have claimed first"
    assert loser.owner_instance_id == "instance-b", (
        "The losing claimant must report the foreign winner as owner instead of "
        f"stealing the live lease; got owner {loser.owner_instance_id!r}."
    )
    assert loser.owner_epoch == winner_epoch[0]
    assert loser.state == HttpBridgeSessionState.ACTIVE


async def test_foreign_claim_still_rejected(
    coordinator: DurableBridgeSessionCoordinator,
) -> None:
    """Behavior-preservation guard: a non-takeover claim against a live,
    unexpired, foreign-owned row still fails closed — it returns the current
    owner rather than stealing the row.

    Passes on both the pre-change and fixed trees; it exists so a fix that
    over-broadens the epoch advance or takeover path (e.g. returns unconditional
    success, or drops the ownership check) is caught.
    """
    owner = await _claim(
        coordinator,
        session_key_value="sid-foreign-live",
        instance_id="instance-a",
        allow_takeover=True,
        latest_turn_state="http_turn_1",
        latest_response_id="resp_1",
    )
    assert owner.owner_instance_id == "instance-a"

    rejected = await _claim(
        coordinator,
        session_key_value="sid-foreign-live",
        instance_id="instance-b",
        allow_takeover=False,
    )

    assert rejected.owner_instance_id == "instance-a", (
        "A non-takeover claim against a live foreign owner must return the "
        f"existing owner, not take the row; got {rejected.owner_instance_id!r}."
    )
    assert rejected.state == HttpBridgeSessionState.ACTIVE
    assert rejected.owner_epoch == owner.owner_epoch, (
        "The live foreign owner's epoch must be unchanged by a rejected claim; "
        f"got {rejected.owner_epoch}, expected {owner.owner_epoch}."
    )
