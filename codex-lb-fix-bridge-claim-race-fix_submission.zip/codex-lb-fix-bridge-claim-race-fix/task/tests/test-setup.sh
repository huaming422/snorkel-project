#!/usr/bin/env bash
# Setup for the codex-lb-fix-bridge-claim-race verifier.
#
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
# The image already baked codex-lb's full dependency closure at the base commit
# into /opt/venv (uv sync --frozen --all-extras --group dev), including
# aiosqlite / pytest / pytest-asyncio — everything the durable-bridge unit tests
# need. This step only brings those baked deps online offline-first and verifies
# the interpreter is usable; there are NO external services (the verifier drives
# the durable-session layer against an in-process in-memory SQLite engine).

cd /repo/codex-lb

# Fail fast on a cache miss instead of reaching for a registry: the smoke gate's
# offline fold sources this script inside `docker run --network none`.
export UV_OFFLINE=1

# Dependencies only — NEVER rebuild the project itself here. The verifier imports
# the repository's `app` package from the live working tree (the pytest child runs
# with cwd=/repo/codex-lb, so `python -m pytest` puts the tree on sys.path and the
# agent's committed source is what gets imported). Re-installing the project would
# force uv to build the codex-lb wheel from that mutated tree via its build backend
# (hatchling), which is not in the offline cache during the network-disabled verify
# phase — that build failure, not any test outcome, is what aborts the verifier.
# `--no-install-project` syncs the baked dependency closure (satisfied from the
# image cache) while leaving the project to be imported live.
if uv sync --frozen --no-install-project --all-extras --group dev > /tmp/test-setup-install.log 2>&1; then
    echo "[offline-first] deps satisfied from image"
elif { unset UV_OFFLINE; uv sync --frozen --no-install-project --all-extras --group dev; } >> /tmp/test-setup-install.log 2>&1; then
    echo "[test-setup] deps installed online (image bake was stale)"
else
    tail -40 /tmp/test-setup-install.log >&2; exit 1
fi

# Loud smoke guard: the repo interpreter must import the durable-bridge surface the
# verifier drives, offline, from the live tree. A failure here is a setup fault
# (surfaced now) rather than a mis-scored test later.
/opt/venv/bin/python -c "import aiosqlite, sqlalchemy, pytest_asyncio; import app.modules.proxy.durable_bridge_coordinator" \
    || { echo "[test-setup] repo interpreter cannot import durable-bridge deps/surface" >&2; exit 1; }

export REPO_NAME=codex-lb
