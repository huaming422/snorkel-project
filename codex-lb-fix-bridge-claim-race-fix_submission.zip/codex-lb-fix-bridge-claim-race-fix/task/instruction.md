## Task

a small, intermittent fraction of chat ("responses") requests are failing with a 409, error code `bridge_instance_mismatch`. it's flaky: rare, clustered in time, and a plain retry of the same request goes straight through.

what's odd is it happens on single-instance deployments. there's no second replica for session ownership to mismatch against, so it shouldn't be able to happen at all. the failures line up with reconnecting a long-lived session: an upstream connection closes cleanly and the very next request reattaches to that same session.

dig in, find the root cause, and stop these 409s from happening on a single instance.
