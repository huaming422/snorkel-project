## Task

We've been shaking out the MPT payment work (the flows behind the MPTokensV2 amendment) and a handful of MPT, DEX, and vault payments are coming out wrong.

A trust-line clawback for an amount much smaller than the holder's balance blows up with a fatal "invariant failed", even though the clawback itself went through fine. Some cross-currency DEX payments fall over with an internal error instead of failing cleanly when an offer's amounts overflow mid-crossing. A token issuer can push a payment through the DEX that loops back to its own token, which holders already aren't allowed to do. And a holder frozen on a vault's underlying asset can still move that vault's shares, through the DEX or by direct payment; the freeze only gets caught by a last-resort check instead of stopping the payment up front.

Dig into the payment engine and fix these. Don't reach for loosening or switching off the safety invariants to make the symptoms disappear. MPTokensV2 isn't live yet, so any behavior that should differ depending on whether it's enabled has to stay gated on it.
