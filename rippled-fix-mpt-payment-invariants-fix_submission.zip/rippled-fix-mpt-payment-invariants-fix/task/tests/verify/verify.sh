#!/usr/bin/env bash
#
# Behavioral verifier for the four MPT/DEX/vault payment-engine flows.
#
# Mechanism: this repo's tests compile into the server binary, so the only
# way to exercise the engine through its public transaction-submission
# interface is to add a beast::unit_test suite and rebuild. This script drops
# the sibling suite file into the repo's test tree, rebuilds the server
# target (the src/test/*.cpp glob is CONFIGURE_DEPENDS, so the new file is
# picked up automatically), then runs each flow's suite on its own and reports
# a per-flow pass/fail line. Exit 0 iff every flow passes.
#
# The runner invokes this with cwd = the repo dir (/repo/rippled). The suite
# source ships beside this script under /tests/verify/.
#
# Exit codes:
#   0        — every flow suite passed
#   non-zero — build failed, or at least one flow suite failed

set -uo pipefail

REPO="/repo/rippled"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SUITE_SRC="${SCRIPT_DIR}/MPTPaymentInvariants_test.cpp"
SUITE_DST="${REPO}/src/test/app/MPTPaymentInvariants_test.cpp"
BIN="${REPO}/build/xrpld"

# Each flow is its own suite; all four must pass.
SUITES=(
    MPTPaymentInvariantsClawback
    MPTPaymentInvariantsOverflow
    MPTPaymentInvariantsLoop
    MPTPaymentInvariantsVaultShare
)

cd "$REPO" || { echo "FAIL: repo dir $REPO missing"; exit 1; }

if [ ! -f "$SUITE_SRC" ]; then
    echo "FAIL: suite source $SUITE_SRC missing"
    exit 1
fi

# Size the build to the cgroup, same rule test.sh uses, so a big host does not
# launch hundreds of compile jobs under a small memory cap.
_nproc="$(nproc 2>/dev/null || echo 4)"
_mem_max="$(cat /sys/fs/cgroup/memory.max 2>/dev/null || echo max)"
if [ "$_mem_max" = "max" ] || [ -z "$_mem_max" ]; then
    JOBS="$_nproc"
else
    JOBS=$(( _mem_max / 2147483648 ))
    [ "$JOBS" -lt 1 ] && JOBS=1
    [ "$JOBS" -gt "$_nproc" ] && JOBS="$_nproc"
fi

echo "Placing suite source and rebuilding server target (jobs=${JOBS})..."
cp "$SUITE_SRC" "$SUITE_DST"

BUILD_LOG="$(mktemp)"
if ! cmake --build build --target xrpld --parallel "$JOBS" > "$BUILD_LOG" 2>&1; then
    echo "FAIL: build did not complete"
    tail -120 "$BUILD_LOG"
    exit 1
fi
if [ ! -x "$BIN" ]; then
    echo "FAIL: server binary $BIN not built"
    exit 1
fi
echo "Build OK."

overall=0
for suite in "${SUITES[@]}"; do
    LOG="$(mktemp)"
    if "$BIN" --unittest="$suite" --unittest-jobs 1 > "$LOG" 2>&1; then
        echo "PASS: ${suite}"
    else
        echo "FAIL: ${suite}"
        tail -60 "$LOG"
        overall=1
    fi
done

if [ "$overall" -eq 0 ]; then
    echo "PASS: all MPT payment-invariant flows verified"
fi
exit "$overall"
