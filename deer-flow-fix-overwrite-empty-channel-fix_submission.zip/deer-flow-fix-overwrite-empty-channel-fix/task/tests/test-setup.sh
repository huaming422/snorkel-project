#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
# Runs with the network cut during the smoke gate's offline fold, so everything
# below must be satisfiable from the image bake.

# The grading harness resolves the repository working tree from REPO_NAME
# (/repo/$REPO_NAME) for both the agent-diff capture and the verifier's cwd;
# export it so both land on /repo/deer-flow.
export REPO_NAME=deer-flow

cd /repo/deer-flow/backend

# Make a cache miss fail fast instead of retrying against a dead network.
export UV_OFFLINE=1

# Dependencies were baked into /opt/venv at the base commit (image block 10).
# Re-assert from the image's warm uv cache offline-first; log a (normally
# unreachable) online fallback so a stale bake is visible rather than silent.
if uv sync --frozen --group dev --offline > /tmp/test-setup-install.log 2>&1; then
    echo "[offline-first] uv sync satisfied from image"
elif uv sync --frozen --group dev >> /tmp/test-setup-install.log 2>&1; then
    echo "[test-setup] uv sync installed online (image bake was stale)"
else
    tail -40 /tmp/test-setup-install.log >&2; exit 1
fi

# No services to start and no data to seed: the bug reproduces entirely
# in-process through the FastAPI thread routes driven with real in-memory
# savers (see the verifier). No assertion logic here.
