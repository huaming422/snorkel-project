"""Behavioral checks for the fork / never-written-field storage corruption.

Everything here is exercised through pre-existing, stable surfaces: the
FastAPI thread routes (``POST /api/threads/{id}/branches``,
``POST`` / ``GET /api/threads/{id}/state``) driven with real in-memory savers
and the real ``CheckpointStateAccessor``, plus the pre-existing third-party
``BinaryOperatorAggregate`` reducer channel the symptom reproduces at. No
symbol introduced by a candidate fix is imported or asserted on, so the
checks stay neutral about HOW the storage path is corrected (a reducer-channel
fix, a write-side unwrap in the route helpers, a custom channel subclass, or
any equivalent) as long as the stored value a fresh fork / never-written field
ends up with is the plain, directly-usable payload instead of a wrapper that
the next reader cannot subscript.

The wiring (stub-authed app + real resolution path + a fake chat model so no
network model is needed) mirrors the repository's own thread-router tests;
these are pre-existing test fixtures, not anything a fix introduces.
"""

from __future__ import annotations

import asyncio
import operator
import sys
from typing import Annotated, NotRequired, TypedDict
from unittest.mock import MagicMock
from uuid import uuid4

# ``app`` is imported from the backend source tree (the repo runs its suite
# with ``PYTHONPATH=.`` from ``backend/``); ``deerflow`` resolves from the
# installed workspace package. Mirror the repository conftest's sys.path seed
# and its break of a production circular import so the route module imports in
# isolation exactly as the repo's own router tests do.
_BACKEND = "/repo/deer-flow/backend"
_BACKEND_TESTS = "/repo/deer-flow/backend/tests"
for _p in (_BACKEND_TESTS, _BACKEND):
    if _p not in sys.path:
        sys.path.insert(0, _p)

_executor_mock = MagicMock()
_executor_mock.SubagentExecutor = MagicMock
_executor_mock.SubagentResult = MagicMock
_executor_mock.SubagentStatus = MagicMock
_executor_mock.MAX_CONCURRENT_SUBAGENTS = 3
_executor_mock.get_background_task_result = MagicMock()
sys.modules.setdefault("deerflow.subagents.executor", _executor_mock)

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from langchain_core.messages import AIMessage, HumanMessage
from langgraph.channels.binop import BinaryOperatorAggregate
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.errors import InvalidUpdateError
from langgraph.store.memory import InMemoryStore
from langgraph.types import Overwrite

from _router_auth_helpers import make_authed_test_app
from app.gateway import services as gateway_services
from app.gateway.routers import threads
from deerflow.agents.thread_state import get_thread_state_schema
from deerflow.persistence.thread_meta.memory import THREADS_NS, MemoryThreadMetaStore
from deerflow.runtime.checkpoint_state import CheckpointStateAccessor

MODES = ["full", "delta"]


# --------------------------------------------------------------------------- #
# Test infrastructure (ported from the repository's thread-router tests).      #
# --------------------------------------------------------------------------- #
class _PermissiveThreadMetaStore(MemoryThreadMetaStore):
    """Memory store that skips user-id filtering so one fixed app user works."""

    async def _get_owned_record(self, thread_id, user_id, method_name):  # type: ignore[override]
        item = await self._store.aget(THREADS_NS, thread_id)
        return dict(item.value) if item is not None else None

    async def check_access(self, thread_id, user_id, *, require_existing=False):  # type: ignore[override]
        item = await self._store.aget(THREADS_NS, thread_id)
        if item is None:
            return not require_existing
        return True

    async def create(self, thread_id, *, assistant_id=None, user_id=None, display_name=None, metadata=None):  # type: ignore[override]
        return await super().create(thread_id, assistant_id=assistant_id, user_id=None, display_name=display_name, metadata=metadata)

    async def search(self, *, metadata=None, status=None, limit=100, offset=0, user_id=None):  # type: ignore[override]
        return await super().search(metadata=metadata, status=status, limit=limit, offset=offset, user_id=None)


class _ThreadTestRunManager:
    async def list_by_thread(self, _thread_id: str, *, user_id=None, limit: int = 100) -> list:
        return []

    def reserve_thread_operation(self, _thread_id: str, **_kwargs):
        from contextlib import asynccontextmanager

        @asynccontextmanager
        async def _cm():
            yield

        return _cm()


def _build_thread_app() -> tuple[FastAPI, InMemoryStore, InMemorySaver]:
    app = make_authed_test_app()
    store = InMemoryStore()
    checkpointer = InMemorySaver()
    app.state.store = store
    app.state.checkpointer = checkpointer
    app.state.run_manager = _ThreadTestRunManager()
    app.state.thread_store = _PermissiveThreadMetaStore(store)
    app.include_router(threads.router)
    return app, store, checkpointer


def _wire_extension_agent(monkeypatch, app, checkpointer, mode):
    """Keep the real resolution path live; stub only infra context + factory."""
    from langchain.agents import create_agent
    from langchain.agents.middleware import AgentMiddleware
    from langchain_core.language_models.fake_chat_models import FakeMessagesListChatModel
    from types import SimpleNamespace

    class ExtensionState(TypedDict):
        ext_list: NotRequired[Annotated[list[str], operator.add]]

    class ExtensionMiddleware(AgentMiddleware):
        state_schema = ExtensionState

    app.state.checkpoint_channel_mode = mode
    model = FakeMessagesListChatModel(responses=[AIMessage(content="ok")])

    def custom_factory(*, config=None):
        return create_agent(model, middleware=[ExtensionMiddleware()], state_schema=get_thread_state_schema(mode))

    def default_factory(*, config=None):
        return create_agent(model, state_schema=get_thread_state_schema(mode))

    def selective_factory(assistant_id):
        return custom_factory if assistant_id == "extension-agent" else default_factory

    ctx = SimpleNamespace(checkpointer=checkpointer, store=None, checkpoint_channel_mode=mode, app_config=None)
    monkeypatch.setattr(gateway_services, "get_run_context", lambda _request: ctx)
    monkeypatch.setattr(gateway_services, "resolve_agent_factory", selective_factory)
    monkeypatch.setattr(threads, "build_checkpoint_state_accessor", gateway_services.build_checkpoint_state_accessor)
    monkeypatch.setattr(threads, "build_checkpoint_state_mutation_accessor", gateway_services.build_checkpoint_state_mutation_accessor)
    monkeypatch.setattr(threads, "build_thread_checkpoint_state_accessor", gateway_services.build_thread_checkpoint_state_accessor)
    monkeypatch.setattr(threads, "build_thread_checkpoint_state_mutation_accessor", gateway_services.build_thread_checkpoint_state_mutation_accessor)
    return custom_factory


async def _seed_union_channel_source(checkpointer, custom_factory, mode, source_thread_id):
    """Seed a completed turn plus the per-thread fields a fresh fork starts without."""
    accessor = CheckpointStateAccessor.bind(custom_factory(), checkpointer, mode=mode)
    config = {"configurable": {"thread_id": source_thread_id, "checkpoint_ns": ""}}
    await accessor.aupdate(
        config,
        {"messages": [HumanMessage(id="h1", content="question")], "goal": {"objective": "ship the fix"}},
        as_node="model",
    )
    await accessor.aupdate(
        config,
        {
            "messages": [AIMessage(id="a1", content="answer")],
            "todos": [{"content": "write tests", "status": "pending"}],
            "sandbox": {"sandbox_id": "local:parent-thread"},
            "thread_data": {"workspace_path": "/parent/workspace"},
        },
        as_node="model",
    )


async def _seed_extension_source(checkpointer, custom_factory, mode, source_thread_id):
    """Seed a completed turn with a non-identity extension reducer channel."""
    accessor = CheckpointStateAccessor.bind(custom_factory(), checkpointer, mode=mode)
    config = {"configurable": {"thread_id": source_thread_id, "checkpoint_ns": ""}}
    await accessor.aupdate(
        config,
        {"messages": [HumanMessage(id="h1", content="question")], "ext_list": ["merged"]},
        as_node="model",
    )
    await accessor.aupdate(
        config,
        {"messages": [AIMessage(id="a1", content="answer")], "ext_list": ["payload"]},
        as_node="model",
    )


def _materialize(checkpointer, custom_factory, mode, thread_id):
    async def _run():
        accessor = CheckpointStateAccessor.bind(custom_factory(), checkpointer, mode=mode)
        snapshot = await accessor.aget({"configurable": {"thread_id": thread_id, "checkpoint_ns": ""}})
        return snapshot.values

    return asyncio.run(_run())


def _branch_union_channel_thread(monkeypatch, mode):
    app, _store, checkpointer = _build_thread_app()
    custom_factory = _wire_extension_agent(monkeypatch, app, checkpointer, mode)
    source_thread_id = f"union-branch-source-{mode}"

    with TestClient(app) as client:
        created = client.post(
            "/api/threads",
            json={"thread_id": source_thread_id, "metadata": {}, "assistant_id": "extension-agent"},
        )
        assert created.status_code == 200, created.text

        asyncio.run(_seed_union_channel_source(checkpointer, custom_factory, mode, source_thread_id))

        branch_response = client.post(
            f"/api/threads/{source_thread_id}/branches",
            json={"message_id": "a1", "message_ids": ["a1"]},
        )
        assert branch_response.status_code == 200, branch_response.text
        branch_thread_id = branch_response.json()["thread_id"]

    return _materialize(checkpointer, custom_factory, mode, branch_thread_id)


# --------------------------------------------------------------------------- #
# Primary route-level behavior checks (alternative-safe).                      #
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("mode", MODES)
def test_branch_copies_union_channels_as_plain_values(monkeypatch, mode) -> None:
    """A fork's copied per-thread fields are plain values the next reader can use."""
    branch_values = _branch_union_channel_thread(monkeypatch, mode)

    # The exact read that detonates for a corrupted fork: subscripting the value.
    assert branch_values["goal"]["objective"] == "ship the fix"
    assert branch_values["todos"] == [{"content": "write tests", "status": "pending"}]
    assert not any(isinstance(value, Overwrite) for value in branch_values.values())


@pytest.mark.parametrize("mode", MODES)
def test_branch_does_not_inherit_thread_scoped_channels(monkeypatch, mode) -> None:
    """A fork stands up its own sandbox/thread_data rather than the parent's."""
    branch_values = _branch_union_channel_thread(monkeypatch, mode)

    assert branch_values.get("sandbox") is None
    assert branch_values.get("thread_data") is None


@pytest.mark.parametrize("mode", MODES)
def test_update_state_overwrite_into_never_written_channel(monkeypatch, mode) -> None:
    """Writing a field a thread never wrote stores a plain, readable value."""
    app, _store, checkpointer = _build_thread_app()
    custom_factory = _wire_extension_agent(monkeypatch, app, checkpointer, mode)
    source_thread_id = f"never-written-goal-{mode}"

    with TestClient(app) as client:
        created = client.post(
            "/api/threads",
            json={"thread_id": source_thread_id, "metadata": {}, "assistant_id": "extension-agent"},
        )
        assert created.status_code == 200, created.text

        asyncio.run(_seed_extension_source(checkpointer, custom_factory, mode, source_thread_id))

        update_response = client.post(
            f"/api/threads/{source_thread_id}/state",
            json={"values": {"goal": {"objective": "finish"}}},
        )
        assert update_response.status_code == 200, update_response.text
        assert update_response.json()["values"]["goal"] == {"objective": "finish"}

        read_response = client.get(f"/api/threads/{source_thread_id}/state")
        assert read_response.status_code == 200, read_response.text
        assert read_response.json()["values"]["goal"] == {"objective": "finish"}


# --------------------------------------------------------------------------- #
# Already-working paths must keep working (regression guard).                   #
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("mode", MODES)
def test_extension_reducer_channel_survives_state_and_branch(monkeypatch, mode) -> None:
    """A non-identity middleware reducer channel still round-trips state + branch."""
    app, _store, checkpointer = _build_thread_app()
    custom_factory = _wire_extension_agent(monkeypatch, app, checkpointer, mode)
    source_thread_id = f"extension-survival-{mode}"

    with TestClient(app) as client:
        created = client.post(
            "/api/threads",
            json={"thread_id": source_thread_id, "metadata": {}, "assistant_id": "extension-agent"},
        )
        assert created.status_code == 200, created.text

        asyncio.run(_seed_extension_source(checkpointer, custom_factory, mode, source_thread_id))

        read_response = client.get(f"/api/threads/{source_thread_id}/state")
        assert read_response.status_code == 200, read_response.text
        assert read_response.json()["values"]["ext_list"] == ["merged", "payload"]

        update_response = client.post(
            f"/api/threads/{source_thread_id}/state",
            json={"values": {"ext_list": ["replaced"]}},
        )
        assert update_response.status_code == 200, update_response.text
        assert update_response.json()["values"]["ext_list"] == ["replaced"]

        branch_response = client.post(
            f"/api/threads/{source_thread_id}/branches",
            json={"message_id": "a1", "message_ids": ["a1"]},
        )
        assert branch_response.status_code == 200, branch_response.text
        branch_thread_id = branch_response.json()["thread_id"]

    branch_values = _materialize(checkpointer, custom_factory, mode, branch_thread_id)
    assert branch_values["ext_list"] == ["replaced"]
    assert [message.id for message in branch_values["messages"]] == ["h1", "a1"]


# --------------------------------------------------------------------------- #
# Reducer-channel semantics preserved (supplementary; alternative-safe).        #
# --------------------------------------------------------------------------- #
def _replace(existing, new):
    return new


def _empty_union_channel() -> BinaryOperatorAggregate:
    """A channel shaped like the per-thread fields: Union type, starts empty."""
    channel = BinaryOperatorAggregate(dict | None, _replace)
    channel.key = "verify-probe"
    return channel


def _channel_unwraps_first_write() -> bool:
    """Does a first replace-style write into an empty channel store the plain value?

    True when the storage fix lives at the reducer-channel layer; False when it
    lives on the write side (the channel class is left untouched, and the
    route-level checks above carry the behavioral signal instead).
    """
    channel = _empty_union_channel()
    channel.update([Overwrite({"probe": True})])
    try:
        stored = channel.get()
    except Exception:
        return False
    return not isinstance(stored, Overwrite)


def test_populated_channel_and_plain_reduce_path_preserved() -> None:
    """A populated-channel replace and a plain first write still behave normally."""
    channel = _empty_union_channel()
    channel.update([{"sandbox_id": "old"}])
    channel.update([Overwrite({"sandbox_id": "new"})])
    assert channel.get() == {"sandbox_id": "new"}

    fresh = _empty_union_channel()
    fresh.update([{"sandbox_id": "first"}])
    assert fresh.get() == {"sandbox_id": "first"}
    fresh.update([{"sandbox_id": "second"}])
    assert fresh.get() == {"sandbox_id": "second"}


def test_first_write_overwrite_preserves_batch_semantics() -> None:
    """When the channel-layer unwraps a first Overwrite, upstream batch rules hold.

    Only asserted for a channel-layer fix (a write-side fix leaves the class
    untouched, so there is nothing to preserve here and the route checks cover
    the behavior). For a channel-layer fix: a later plain value in the same
    batch is skipped, and a second replace marker is rejected.
    """
    if not _channel_unwraps_first_write():
        pytest.skip("storage fix is not at the reducer-channel layer; covered by route checks")

    kept = _empty_union_channel()
    kept.update([Overwrite({"sandbox_id": "kept"}), {"sandbox_id": "ignored"}])
    assert kept.get() == {"sandbox_id": "kept"}

    doubled = _empty_union_channel()
    with pytest.raises(InvalidUpdateError):
        doubled.update([Overwrite({"sandbox_id": "a"}), Overwrite({"sandbox_id": "b"})])
