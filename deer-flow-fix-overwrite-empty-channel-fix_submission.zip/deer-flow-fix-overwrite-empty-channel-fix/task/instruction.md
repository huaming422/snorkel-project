## Task

forking a conversation off an earlier turn and then using any sandbox-backed tool crashes the run with `TypeError: 'Overwrite' object is not subscriptable`. the parent conversation is totally fine; only the forks hit this, and they hit it reliably the moment a sandbox tool runs. we're also seeing the same kind of crash when a thread field (say the thread goal) gets written onto a thread that never had that field set before. branching used to work, so dig in and fix it.
