"""Behavioral test for the nested-type reuse regression.

Drives the code generator through its two PRE-EXISTING public entrypoints and
observes the GENERATED OUTPUT plus the RUNTIME TYPE IDENTITY of generated-vs-
native instances. No implementation-side helper, private symbol, or internal
marker shape is imported — every check is purely behavioral.

Entrypoints under test (both stable, both pre-date this fix):
  * CLI  — ``datamodel_code_generator.__main__.main([...])`` with
           ``--input-model <module>:<Model> --input-model-ref-strategy <s>``.
  * API  — ``datamodel_code_generator.input_model.load_model_schema(...)``
           feeding ``datamodel_code_generator.generate(...)``.

The observable contract (see instructions): when the generator is asked to
*reuse* the types of an existing Python module, a field whose type lives
*inside another class* must end up referencing the ORIGINAL runtime type, so a
generated instance's field type IS the native instance's field type. The buggy
behavior loses that identity (it stands a flattened copy in, or emits a
reference that cannot even import). The plain regenerate-everything mode
legitimately builds fresh local types and must keep doing so.

Why identity-and-round-trip rather than golden source text: the reference can
be spelled several equally-correct ways (qualified owner path, aliased import,
short module-level import where one exists). All that matters behaviorally is
that the reused type is the same runtime object and real data round-trips
through both models. Asserting a specific spelling would reject correct
alternatives; asserting identity rejects exactly the broken ones.

Fixtures here are authored fresh for this test (the upstream fixtures are
absent at the project's starting commit); they only exercise the public behavior.
"""

from __future__ import annotations

import importlib
import importlib.util
import shutil
import sys
from pathlib import Path
from typing import Any

import pytest

# ---------------------------------------------------------------------------
# Public-interface imports (all pre-existing, stable surfaces).
# ---------------------------------------------------------------------------
from datamodel_code_generator import DataModelType, InputFileType, generate
from datamodel_code_generator.__main__ import Exit, main
from datamodel_code_generator.enums import InputModelRefStrategy
from datamodel_code_generator.format import Formatter
from datamodel_code_generator.input_model import load_model_schema

# A unique top-level package name for the authored fixtures so the dotted
# ``module:Model`` import paths the generator needs resolve cleanly.
_FIXTURE_PKG = "nrv_fixtures"


# ---------------------------------------------------------------------------
# Fresh fixture source.
#
# ``nested`` and ``other`` exercise the regression itself: their reusable types
# live INSIDE a class, and the module refuses to surface those leaves at module
# top level — so the only correct reference is one that walks the owning class,
# and the buggy module-level reference cannot resolve at all (it either imports
# nothing or stands a fresh copy in, both of which these checks catch).
#
# ``export`` and ``hostile`` are the fallback/precedence guards: there a short
# module-level name for the leaf genuinely exists (and, for ``hostile``, the
# qualified owner walk is actively sabotaged), so the already-working short
# reference must keep working and identity must be preserved on BOTH the base
# and fixed code. They prove the fix is a safe addition, not a regression.
# ---------------------------------------------------------------------------

# Nested types whose owners are *classes*. The module-level ``__getattr__``
# raises for the leaf short-names, so a reference that tries to reach a leaf at
# module top level fails outright — the reference must go through the owner.
_MODULE_NESTED = '''\
"""Native nested types whose owners are classes, not modules."""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from pydantic import BaseModel


class Base(BaseModel):
    inherited: int = 1


class Holder:
    class Leaf(Base):
        amount: int

    class Deep:
        class Core(BaseModel):
            label: str

    class Flavor(str, Enum):
        ONE = "one"
        TWO = "two"

    @dataclass
    class Tally:
        count: int

    class Branch(BaseModel):
        value: int
        child: "Holder.Branch | None" = None


class Document(BaseModel):
    leaf: Holder.Leaf
    core: Holder.Deep.Core
    flavor: Holder.Flavor
    tally: Holder.Tally
    branch: Holder.Branch
    note: str | None = None


Holder.Branch.model_rebuild()


def __getattr__(name):
    # The nested leaves are reachable through their owners, never the module.
    if name in {"Leaf", "Core", "Flavor", "Tally", "Branch"}:
        raise RuntimeError("nested types must be reached through their owners")
    raise AttributeError(name)
'''

# A second, independent module reusing the SAME owner and leaf class names, so a
# correct fix must keep the two distinct (per-module disambiguation), not
# collapse them into one.
_MODULE_OTHER = '''\
"""A second module with the same owner and nested class names."""
from __future__ import annotations

from pydantic import BaseModel


class Holder:
    class Leaf(BaseModel):
        label: str


class OtherDoc(BaseModel):
    leaf: Holder.Leaf
'''

# A nested leaf that is ALSO re-exported at module level under its short name.
# The short module-level reference already works and must keep working — the
# owner-qualified path must not displace a genuine module-level export.
_MODULE_EXPORT = '''\
"""A nested leaf that is also re-exported at module level."""
from __future__ import annotations

from pydantic import BaseModel


class Box:
    class Item(BaseModel):
        value: int


# Re-export the nested leaf at module level under its short name.
Item = Box.Item


class ExportRoot(BaseModel):
    child: Item
'''

# An owner whose metaclass raises on qualified attribute access, while the leaf
# is still reachable at module level under a short name. The qualified owner
# walk MUST fail gracefully and fall back to the working short reference —
# never raise, never emit something broken.
_MODULE_HOSTILE = '''\
"""An owner that rejects qualified lookup; the short export still works."""
from __future__ import annotations

from pydantic import BaseModel


class RaisingMeta(type):
    def __getattribute__(cls, name):
        if name == "Secret":
            raise RuntimeError("qualified lookup is unavailable")
        return super().__getattribute__(name)


class Guard(metaclass=RaisingMeta):
    class Secret(BaseModel):
        value: int


# The leaf is still reachable at module level under a short name.
Secret = Guard.__dict__["Secret"]


class HostileRoot(BaseModel):
    child: Secret
'''


# Per-case metadata. ``sources`` are ``module:Model`` pairs (module stem only;
# the package prefix is added at runtime). ``payloads`` is one JSON-ish payload
# per source model. ``identity_fields`` are attribute paths checked as
# ``type(generated.<path>) is type(native.<path>)``; ``reuse_all_only`` adds
# paths only meaningful under reuse-all (a pydantic dataclass is regenerated
# under reuse-foreign because it is a different type family).
_NESTED_PAYLOAD = {
    "leaf": {"amount": 1},
    "core": {"label": "a"},
    "flavor": "one",
    "tally": {"count": 2},
    "branch": {"value": 3, "child": {"value": 4}},
}

CASES: dict[str, dict[str, Any]] = {
    "nested": {
        "sources": ["nested:Document"],
        "payloads": [_NESTED_PAYLOAD],
        "identity_fields": ["leaf", "core", "flavor", "branch.child"],
        "reuse_all_only_identity_fields": ["tally"],
    },
    "multiple": {
        # Two modules sharing owner/leaf names; both must stay distinct and
        # both must preserve identity.
        "sources": ["nested:Document", "other:OtherDoc"],
        "payloads": [_NESTED_PAYLOAD, {"leaf": {"label": "b"}}],
        "identity_fields": ["leaf"],
        "reuse_all_only_identity_fields": [],
    },
    "export": {
        "sources": ["export:ExportRoot"],
        "payloads": [{"child": {"value": 1}}],
        "identity_fields": ["child"],
        "reuse_all_only_identity_fields": [],
    },
    "hostile": {
        "sources": ["hostile:HostileRoot"],
        "payloads": [{"child": {"value": 1}}],
        "identity_fields": ["child"],
        "reuse_all_only_identity_fields": [],
    },
}

# Cases where the reused leaf has NO working module-level name — the regression
# bites here (starting code loses identity; the fix restores it).
_REGRESSION_CASES = ["nested", "multiple"]
# Cases where a short module-level name genuinely exists — identity holds with
# and without the fix; these guard the safe-fallback / export-precedence paths
# against an over-eager fix.
_FALLBACK_CASES = ["export", "hostile"]

_ENTRYPOINTS = ["cli", "api"]


# ---------------------------------------------------------------------------
# Fixture package lifecycle.
# ---------------------------------------------------------------------------
@pytest.fixture(scope="session")
def fixture_pkg(tmp_path_factory: pytest.TempPathFactory):
    """Materialize the fresh fixture package and put it on sys.path.

    Yields the dotted package name; models are referenced as
    ``<pkg>.<module>:<Model>``.
    """
    root = tmp_path_factory.mktemp("nrv_root")
    pkg_dir = root / _FIXTURE_PKG
    pkg_dir.mkdir()
    (pkg_dir / "__init__.py").write_text("")
    (pkg_dir / "nested.py").write_text(_MODULE_NESTED)
    (pkg_dir / "other.py").write_text(_MODULE_OTHER)
    (pkg_dir / "export.py").write_text(_MODULE_EXPORT)
    (pkg_dir / "hostile.py").write_text(_MODULE_HOSTILE)

    sys.path.insert(0, str(root))
    # Eagerly import so the modules are live for the native-vs-generated compare.
    for mod in ("nested", "other", "export", "hostile"):
        importlib.import_module(f"{_FIXTURE_PKG}.{mod}")
    yield _FIXTURE_PKG
    for name in [n for n in list(sys.modules) if n == _FIXTURE_PKG or n.startswith(_FIXTURE_PKG + ".")]:
        sys.modules.pop(name, None)
    if str(root) in sys.path:
        sys.path.remove(str(root))
    shutil.rmtree(root, ignore_errors=True)


def _resolve(attr_path: str, obj: Any) -> Any:
    for part in attr_path.split("."):
        obj = getattr(obj, part)
    return obj


def _dotted_sources(pkg: str, sources: list[str]) -> list[str]:
    out = []
    for src in sources:
        module, model = src.split(":")
        out.append(f"{pkg}.{module}:{model}")
    return out


def _generate_output(entrypoint: str, dotted: list[str], strategy: str, out_path: Path) -> None:
    """Drive the generator through the requested public entrypoint."""
    if entrypoint == "cli":
        args: list[str] = []
        for path in dotted:
            args += ["--input-model", path]
        args += [
            "--output",
            str(out_path),
            "--input-model-ref-strategy",
            strategy,
            "--disable-timestamp",
            "--formatters",
            "black",
            "isort",
        ]
        rc = main(args)
        assert rc == Exit.OK, f"CLI main() exited {rc!r} for strategy={strategy}"
    else:
        # Public API path: load the merged schema from the Python import paths
        # (this is where the reuse strategy records its reference markers), then
        # drive generate() with plain config kwargs (GenerateConfigDict).
        schema = load_model_schema(
            dotted,
            InputFileType.JsonSchema,
            InputModelRefStrategy(strategy),
            DataModelType.PydanticV2BaseModel,
        )
        generate(
            schema,
            input_file_type=InputFileType.JsonSchema,
            output=out_path,
            output_model_type=DataModelType.PydanticV2BaseModel,
            disable_timestamp=True,
            formatters=[Formatter.BLACK, Formatter.ISORT],
        )
    assert out_path.exists() and out_path.read_text().strip(), "generator produced no output"


def _load_generated(out_path: Path, module_name: str):
    """Import a generated module in isolation and return (module, previous)."""
    spec = importlib.util.spec_from_file_location(module_name, out_path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    previous = sys.modules.get(module_name)
    sys.modules[module_name] = module
    try:
        spec.loader.exec_module(module)
    except Exception:
        sys.modules.pop(module_name, None)
        if previous is not None:
            sys.modules[module_name] = previous
        raise
    return module, previous


def _unload_generated(module_name: str, previous) -> None:
    if previous is None:
        sys.modules.pop(module_name, None)
    else:
        sys.modules[module_name] = previous


def _assert_reuse_behavior(
    fixture_pkg: str, case: str, strategy: str, entrypoint: str, out_path: Path
) -> None:
    """Generate under a reuse strategy and assert identity + round-trip.

    Shared by the regression cases and the fallback cases — the behavioral
    contract is identical; only whether the starting code can satisfy it differs.
    """
    spec = CASES[case]
    dotted = _dotted_sources(fixture_pkg, spec["sources"])
    _generate_output(entrypoint, dotted, strategy, out_path)

    module_name = f"nrv_out_{case}_{strategy}_{entrypoint}".replace("-", "_")
    module, previous = _load_generated(out_path, module_name)
    try:
        for src, payload in zip(spec["sources"], spec["payloads"], strict=True):
            mod_stem, model_name = src.split(":")
            native_module = importlib.import_module(f"{fixture_pkg}.{mod_stem}")
            native_model = getattr(native_module, model_name)
            generated_model = getattr(module, model_name)

            native = native_model.model_validate(payload)
            generated = generated_model.model_validate(payload)

            assert list(generated_model.model_fields) == list(native_model.model_fields)
            assert generated.model_dump(mode="json", exclude_unset=True) == native.model_dump(
                mode="json", exclude_unset=True
            )

            identity_fields = list(spec["identity_fields"])
            if strategy == "reuse-all":
                identity_fields += spec["reuse_all_only_identity_fields"]
            for attr_path in identity_fields:
                gen_val = _resolve(attr_path, generated)
                nat_val = _resolve(attr_path, native)
                assert type(gen_val) is type(nat_val), (
                    f"reused type identity lost for {model_name}.{attr_path} under "
                    f"{strategy}/{entrypoint}: {type(gen_val)!r} is not {type(nat_val)!r}"
                )
    finally:
        _unload_generated(module_name, previous)


# ---------------------------------------------------------------------------
# Core contract: reused class-nested types keep their runtime identity. Covers
# qualified-through-owner referencing, runtime identity across every nested kind
# (model/enum/dataclass/deep/self-ref), strict same-object resolution, and the
# dynamic/cross-module-collision scenarios. The starting code loses identity
# here (it emits short module-level references that cannot resolve).
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("entrypoint", _ENTRYPOINTS)
@pytest.mark.parametrize("strategy", ["reuse-all", "reuse-foreign"])
@pytest.mark.parametrize("case", _REGRESSION_CASES)
def test_nested_reuse_runtime_identity(
    tmp_path: Path, fixture_pkg: str, entrypoint: str, strategy: str, case: str
) -> None:
    """Reused nested types keep original runtime identity and round-trip."""
    _assert_reuse_behavior(fixture_pkg, case, strategy, entrypoint, tmp_path / "output.py")


# ---------------------------------------------------------------------------
# Guard: where a working short module-level name exists, it must keep working
# (safe fallback + module-export precedence) — identity holds with and without
# the fix. A change that crashes on a hostile owner, or that displaces a genuine
# module-level export in favor of the owner path, breaks these.
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("entrypoint", _ENTRYPOINTS)
@pytest.mark.parametrize("strategy", ["reuse-all", "reuse-foreign"])
@pytest.mark.parametrize("case", _FALLBACK_CASES)
def test_reuse_module_level_export_preserved(
    tmp_path: Path, fixture_pkg: str, entrypoint: str, strategy: str, case: str
) -> None:
    """A nested leaf with a working short name keeps round-tripping + identity."""
    _assert_reuse_behavior(fixture_pkg, case, strategy, entrypoint, tmp_path / "output.py")


# ---------------------------------------------------------------------------
# Guard: regenerate-all legitimately flattens and must stay unchanged. A change
# that "always references the owner" would wrongly touch this path.
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("entrypoint", _ENTRYPOINTS)
def test_regenerate_all_unchanged(tmp_path: Path, fixture_pkg: str, entrypoint: str) -> None:
    """regenerate-all flattens nested types into fresh, DISTINCT local classes."""
    spec = CASES["nested"]
    dotted = _dotted_sources(fixture_pkg, spec["sources"])
    out_path = tmp_path / "output.py"
    _generate_output(entrypoint, dotted, "regenerate-all", out_path)
    source = out_path.read_text()

    # Flattened: fresh local class bodies exist (the nested leaves are rebuilt).
    assert "class Leaf(" in source or "class Core(" in source, (
        f"regenerate-all should flatten nested types into local classes:\n{source}"
    )

    module_name = f"nrv_regen_{entrypoint}"
    module, previous = _load_generated(out_path, module_name)
    try:
        native_module = importlib.import_module(f"{fixture_pkg}.nested")
        native_model = native_module.Document
        generated_model = module.Document

        native = native_model.model_validate(_NESTED_PAYLOAD)
        generated = generated_model.model_validate(_NESTED_PAYLOAD)
        assert generated.model_dump(mode="json", exclude_unset=True) == native.model_dump(
            mode="json", exclude_unset=True
        )
        # Regenerate-all builds DISTINCT types — the opposite of reuse identity.
        for attr_path in spec["identity_fields"]:
            gen_val = _resolve(attr_path, generated)
            nat_val = _resolve(attr_path, native)
            assert type(gen_val) is not type(nat_val), (
                f"regenerate-all unexpectedly reused identity for Document.{attr_path}"
            )
    finally:
        _unload_generated(module_name, previous)
