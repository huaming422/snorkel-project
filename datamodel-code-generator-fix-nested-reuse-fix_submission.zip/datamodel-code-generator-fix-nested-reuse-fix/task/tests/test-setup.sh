#!/usr/bin/env bash
# test-setup.sh — sourced before the verifier runs.
#
# The image bakes the full dependency closure at the base commit into the
# uv-managed project environment at /opt/venv (block 10 ran
# `uv sync --frozen --all-extras --group dev --group test`), so pytest, black,
# isort, and the datamodel_code_generator package itself are already importable.
# The project is installed editable (a .pth entry pointing at the live /repo
# tree), so any source the agent changed is already picked up — no reinstall is
# needed for the verifier to see the fix.
#
# We deliberately do NOT re-run `uv sync` here. The project's build backend
# derives its version from git, so the agent's commit invalidates uv's cached
# build of the root project; a resync would then try to rebuild it from the
# backend, which needs packages that are not in the offline cache and so aborts
# before the verifier can run. The agent phase is offline, so it cannot have
# added any dependency that the baked closure is missing. We only confirm the
# environment is importable and fail loudly if it is not.
set -euo pipefail

cd /repo/datamodel-code-generator
export REPO_NAME=datamodel-code-generator
export VIRTUAL_ENV=/opt/venv
export UV_PROJECT_ENVIRONMENT=/opt/venv
export PATH="/opt/venv/bin:${PATH}"
export UV_OFFLINE=1

/opt/venv/bin/python -c "import datamodel_code_generator; from datamodel_code_generator.input_model import load_model_schema; print('datamodel-code-generator test env ready')"
