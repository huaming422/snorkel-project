## Task

when we point the generator at an existing python module and ask it to reuse the types already defined there, top-level types come through fine: the generated models reference the originals. but if a type to reuse lives nested inside another class (an inner class, a nested enum, a nested dataclass), it regresses. instead of pointing back at the original, the generator declares a fresh local copy. so the generated models no longer share the original runtime types, and real instances stop round-tripping through them.

only shows up on the reuse path; regenerating everything from scratch is unaffected. dig in, figure out why nested reused types lose their identity, and fix it so they keep it.
