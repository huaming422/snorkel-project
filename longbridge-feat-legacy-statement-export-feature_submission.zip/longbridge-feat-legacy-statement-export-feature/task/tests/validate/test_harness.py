"""Shared harness for the longbridge-feat-legacy-statement-export validation stories.

Every story drives the compiled `longbridge` CLI binary (built by
validation-setup.sh from the agent's edits) against a local mock HTTP server,
fully offline. This module is framework plumbing ONLY — it does not encode any
behavior the solution is free to choose. Each story's test file (written by the
validation agent) imports these helpers, stages the canned responses its
scenario needs, runs the binary, and asserts on the result.

Why a local mock suffices (all three facts are pre-existing repo behavior, not
reference-introduced):

  1. Endpoint redirect. `src/openapi/context.rs` has a debug-build branch:
     when LONGBRIDGE_HTTP_URL is set non-empty (and LONGBRIDGE_ENV != "staging"),
     BOTH the brokerage SDK's HttpClient AND the repo's own `http_client()`
     (the one the new PDF endpoints call) are pointed at that base URL. The
     binary must therefore be a DEBUG build (the image pre-warms one). The
     in-tree test `send_quote_cmd_hits_endpoint_with_tracking_headers` uses the
     same trick against a 127.0.0.1 socket.
  2. Offline auth. `init_contexts()` needs a stored token at
     ~/.longbridge/openapi/cli-auth, but `secure_storage::read_payload` accepts
     a PLAINTEXT JSON token (no `LB1` magic header -> legacy branch). We write
     one.
  3. No network refresh / no region probe. `auth::refresh_if_expired()` returns
     early when expires_at > now (we use a far-future value), and
     `region::refresh_region_cache()` returns early when LONGBRIDGE_REGION is
     set (we set "global"). So zero outbound network happens.

OWNERSHIP of the shapes encoded here (Phase 2.5 artifact-schema ownership):

  * Token file layout, env vars, far-future expires_at -> HARNESS-OWNED test
    fixtures (the solution never reads or defines them). Safe to encode.
  * The *brokerage-SDK* statement endpoints the non-PDF path uses
    (`statement list` -> GET /v1/statement/list; `statement export` ->
    GET /v1/statement/download then a plain GET of the returned url) and the
    `{code,message,data}` success envelope -> REPO/SDK-OWNED (the agent calls
    fixed SDK methods `ctx.statements()` / `ctx.statement_download_url()`; it
    does not choose these paths). Safe to encode as the mock's defaults.
  * The *PDF* endpoints and their request/response field names are
    IMPLEMENTATION-OWNED — the agent authors raw `http_client().request(...)`
    calls and the structs they deserialize. So the mock routes PDF requests by
    a coarse path marker ("pdf" in the path) and the response BODY is supplied
    per-test by the validation agent after reading the submitted patch. The
    harness does NOT hardcode the PDF path spelling, query-param names, or
    response field names. See `MockStatementServer.set_pdf_list` /
    `set_pdf_download` and the per-story prose.

The mock also records every request (method + path + query) so a story can
assert, e.g., that a 2025-only `statement list` made ZERO PDF-list calls.
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

REPO_DIR = "/repo/longbridge-terminal"

# ---------------------------------------------------------------------------
# Binary discovery (debug build — the override branch is cfg!(debug_assertions))
# ---------------------------------------------------------------------------

# validation-setup.sh writes the resolved absolute path here so the harness
# never has to guess the CARGO_TARGET_DIR. Fallbacks cover a plain in-repo
# build and the image's out-of-tree target dir.
_BIN_PATH_FILE = "/tmp/longbridge_bin_path"
_BIN_FALLBACKS = (
    "/opt/cache/cargo-target/debug/longbridge",
    f"{REPO_DIR}/target/debug/longbridge",
)


def longbridge_bin() -> str:
    """Absolute path to the freshly built debug `longbridge` binary."""
    try:
        p = Path(_BIN_PATH_FILE).read_text(encoding="utf-8").strip()
        if p and Path(p).is_file():
            return p
    except OSError:
        pass
    for cand in _BIN_FALLBACKS:
        if Path(cand).is_file():
            return cand
    raise AssertionError(
        "longbridge debug binary not found. validation-setup.sh should have "
        f"built it and written its path to {_BIN_PATH_FILE}. Checked: "
        f"{_BIN_FALLBACKS}"
    )


# ---------------------------------------------------------------------------
# Offline auth token
# ---------------------------------------------------------------------------

# Far in the future (year 2100) so refresh_if_expired() returns early: zero
# network. Harness-owned fixture.
_FAR_FUTURE_EXPIRES_AT = 4102444800


def seed_token(home: str | os.PathLike[str]) -> None:
    """Write a plaintext-JSON auth token under HOME so init_contexts() loads it offline.

    `secure_storage::read_payload` treats a file NOT starting with the `LB1`
    magic bytes as plaintext JSON. Fields mirror the legacy token shape
    (client_id, access_token, refresh_token, expires_at, logged_in_at).
    """
    token_dir = Path(home) / ".longbridge" / "openapi"
    token_dir.mkdir(parents=True, exist_ok=True)
    token = {
        "client_id": "test-client",
        "access_token": "test-access-token",
        "refresh_token": "test-refresh-token",
        "expires_at": _FAR_FUTURE_EXPIRES_AT,
        "logged_in_at": 1600000000,
    }
    (token_dir / "cli-auth").write_text(json.dumps(token), encoding="utf-8")


# ---------------------------------------------------------------------------
# Mock HTTP server
# ---------------------------------------------------------------------------


def _envelope(data: object) -> bytes:
    """Wrap `data` in the brokerage SDK success envelope: {code:0,message:"",data:...}."""
    return json.dumps({"code": 0, "message": "", "data": data}).encode("utf-8")


class MockStatementServer:
    """A local HTTP server that answers the statement endpoints the CLI calls.

    Start it with `with MockStatementServer() as mock:` then point the CLI at
    `mock.base_url` via LONGBRIDGE_HTTP_URL (see `run_cli`). Configure responses
    before running the CLI:

      * REPO/SDK-owned (safe defaults, overridable):
          - set_statement_list(entries): answers GET /v1/statement/list with
            {"list": [{"dt": <int>, "file_key": <str>}, ...]}.
          - set_download_body(body, status=200, content_type=...): answers the
            SDK's GET /v1/statement/download with a presigned url that points
            back at this mock, and serves `body` (the statement document, an
            XML error page, a %PDF blob, an empty body, ...) at that url.

      * IMPLEMENTATION-owned (no default — the validation agent supplies the
        body shape after reading the submitted patch):
          - set_pdf_list(raw_data): the value placed under the envelope's
            "data" for any request whose path contains "pdf" and "list".
          - set_pdf_download(raw_data): same, for a path containing "pdf" and
            "download". The presigned url in the body should be
            mock.file_url(name) if you want the mock to also serve the PDF
            bytes; `set_file(name, blob, content_type=...)` registers those bytes.

    Every request is recorded in `mock.requests` as a dict
    {"method","path","query"} for assertions such as "no PDF-list call".
    """

    def __init__(self) -> None:
        self.requests: list[dict] = []
        self._lock = threading.Lock()
        # repo/SDK-owned response slots
        self._statement_list: list[dict] = []
        self._download_body: bytes = b""
        self._download_status: int = 200
        self._download_content_type: str = "application/json"
        # implementation-owned response slots (set by the story)
        self._pdf_list_data: object | None = None
        self._pdf_download_data: object | None = None
        # arbitrary file bodies served at /file/<name>
        self._files: dict[str, tuple[bytes, str]] = {}
        self._server: ThreadingHTTPServer | None = None
        self._thread: threading.Thread | None = None

    # -- configuration (repo/SDK-owned) ------------------------------------

    def set_statement_list(self, entries: list[dict]) -> None:
        """entries: list of {"dt": int, "file_key": str} for GET /v1/statement/list."""
        self._statement_list = entries

    def set_download_body(
        self,
        body: bytes | str,
        status: int = 200,
        content_type: str = "application/json",
    ) -> None:
        """Body served at the presigned download url (statement JSON / XML error / %PDF / empty)."""
        self._download_body = body.encode("utf-8") if isinstance(body, str) else body
        self._download_status = status
        self._download_content_type = content_type

    # -- configuration (implementation-owned: body shape from the patch) ---

    def set_pdf_list(self, data: object) -> None:
        """Value placed under the success envelope's `data` for the PDF-list endpoint."""
        self._pdf_list_data = data

    def set_pdf_download(self, data: object) -> None:
        """Value placed under the success envelope's `data` for the PDF-download endpoint."""
        self._pdf_download_data = data

    def set_file(self, name: str, body: bytes | str, content_type: str = "application/octet-stream") -> None:
        """Register raw bytes served at `file_url(name)` (e.g. the actual PDF blob)."""
        self._files[name] = (
            body.encode("utf-8") if isinstance(body, str) else body,
            content_type,
        )

    # -- urls --------------------------------------------------------------

    @property
    def base_url(self) -> str:
        assert self._server is not None, "server not started"
        host, port = self._server.server_address[:2]
        return f"http://127.0.0.1:{port}"

    def file_url(self, name: str) -> str:
        """A presigned-style url on this mock that serves bytes registered via set_file."""
        return f"{self.base_url}/file/{name}"

    # -- request log -------------------------------------------------------

    def _record(self, method: str, path: str, query: dict) -> None:
        with self._lock:
            self.requests.append({"method": method, "path": path, "query": query})

    def paths(self) -> list[str]:
        with self._lock:
            return [r["path"] for r in self.requests]

    def count_matching(self, *needles: str) -> int:
        """Number of recorded requests whose path contains ALL given substrings (case-insensitive)."""
        with self._lock:
            return sum(
                1
                for r in self.requests
                if all(n.lower() in r["path"].lower() for n in needles)
            )

    # -- lifecycle ---------------------------------------------------------

    def __enter__(self) -> "MockStatementServer":
        harness = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *_args):  # silence default stderr logging
                pass

            def _send(self, status: int, body: bytes, content_type: str) -> None:
                self.send_response(status)
                self.send_header("Content-Type", content_type)
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def do_GET(self):  # noqa: N802
                parsed = urlparse(self.path)
                path = parsed.path
                query = {k: v[0] for k, v in parse_qs(parsed.query).items()}
                harness._record("GET", path, query)
                lower = path.lower()

                # Raw file bodies (presigned download targets).
                if lower.startswith("/file/"):
                    name = path[len("/file/"):]
                    if name in harness._files:
                        # A file registered via set_file() is an explicit blob
                        # with its own content type; serve it 200 OK regardless
                        # of _download_status (which only governs the default
                        # statement-body else-branch below, e.g. a 404 error page).
                        body, ct = harness._files[name]
                        self._send(200, body, ct)
                    else:
                        self._send(
                            harness._download_status,
                            harness._download_body,
                            harness._download_content_type,
                        )
                    return

                # PDF endpoints (implementation-owned shapes). Routed by markers
                # so the exact path spelling the agent chose does not matter.
                if "pdf" in lower and "list" in lower:
                    data = harness._pdf_list_data
                    self._send(200, _envelope(data if data is not None else {}),
                               "application/json")
                    return
                if "pdf" in lower and "download" in lower:
                    data = harness._pdf_download_data
                    self._send(200, _envelope(data if data is not None else {}),
                               "application/json")
                    return

                # Brokerage-SDK statement list (repo-owned path).
                if "statement" in lower and "list" in lower:
                    self._send(200, _envelope({"list": harness._statement_list}),
                               "application/json")
                    return

                # Brokerage-SDK download-url resolver (repo-owned path): hand
                # back a presigned url on this mock so the CLI's second-hop GET
                # fetches the configured body.
                if "statement" in lower and "download" in lower:
                    url = harness.file_url("statement-body")
                    self._send(200, _envelope({"url": url}), "application/json")
                    return

                # Anything else: empty success envelope (keeps background
                # SDK chatter from erroring).
                self._send(200, _envelope({}), "application/json")

            # Some SDK calls may POST; treat identically for recording + 200.
            def do_POST(self):  # noqa: N802
                self.do_GET()

        self._server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)
        self._thread.start()
        # NOTE: do NOT pre-register "statement-body" in _files here. The SDK
        # download-url resolver hands back file_url("statement-body"); the
        # /file/ handler serves the CURRENT _download_body via its else-branch
        # when "statement-body" is absent from _files, so a set_download_body()
        # call made after `with MockStatementServer()` is honored. Registering
        # it here would freeze the body at its initial (empty) value.
        return self

    def __exit__(self, *_exc) -> None:
        if self._server is not None:
            self._server.shutdown()
            self._server.server_close()
        if self._thread is not None:
            self._thread.join(timeout=5)


# ---------------------------------------------------------------------------
# CLI runner
# ---------------------------------------------------------------------------


def merged_env(mock: MockStatementServer, home: str | os.PathLike[str]) -> dict:
    """Environment that redirects the CLI at the mock, offline, in the test region.

    LONGBRIDGE_HTTP_URL  -> the debug-build override branch (SDK + http_client).
    LONGBRIDGE_REGION=global -> refresh_region_cache() returns early (no probe).
    LONGBRIDGE_ENV is deliberately UNSET so the staging branch does not fire and
      the plain override branch handles the redirect.
    HOME -> where seed_token() wrote the plaintext token.
    """
    env = {**os.environ}
    env["HOME"] = str(home)
    env["LONGBRIDGE_HTTP_URL"] = mock.base_url
    env["LONGBRIDGE_REGION"] = "global"
    env.pop("LONGBRIDGE_ENV", None)
    env["CARGO_NET_OFFLINE"] = "true"
    return env


def run_cli(
    args: list[str],
    mock: MockStatementServer,
    home: str | os.PathLike[str],
    cwd: str | os.PathLike[str] | None = None,
    timeout: int = 60,
) -> subprocess.CompletedProcess:
    """Run `longbridge <args>` against the mock, offline. Returns CompletedProcess.

    `home` must already have a token (call seed_token(home) first). `cwd`
    defaults to `home` so files the CLI writes to the current directory land in
    the per-test sandbox.
    """
    cmd = [longbridge_bin()] + args
    return subprocess.run(
        cmd,
        cwd=str(cwd) if cwd is not None else str(home),
        env=merged_env(mock, home),
        capture_output=True,
        text=True,
        timeout=timeout,
        check=False,
    )


# ---------------------------------------------------------------------------
# Small helpers the stories reuse
# ---------------------------------------------------------------------------


def combined_output(proc: subprocess.CompletedProcess) -> str:
    """stdout + stderr concatenated (the CLI prints errors to stderr)."""
    return (proc.stdout or "") + (proc.stderr or "")


def try_parse_json(text: str) -> object | None:
    """Best-effort: parse the largest JSON object/array in `text`, else None.

    `--format json` output may be preceded by log lines on stderr; stdout is
    usually clean JSON, but this tolerates a leading/trailing banner.
    """
    text = text.strip()
    if not text:
        return None
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    m = re.search(r"(\{.*\}|\[.*\])", text, re.DOTALL)
    if m:
        try:
            return json.loads(m.group(1))
        except json.JSONDecodeError:
            return None
    return None
