#!/usr/bin/env bash
# Validation setup: runs after the agent applies its edits, before the
# validation stories execute. One job: build the `longbridge` CLI binary from
# the agent's edits and record its absolute path for the harness.
#
# The binary MUST be a DEBUG build: the LONGBRIDGE_HTTP_URL redirect the stories
# rely on lives in a `cfg!(debug_assertions)` branch in src/openapi/context.rs,
# so a release build would ignore the override and try to reach the live API
# (and fail, offline). `cargo build` (no --release) is a debug build.
#
# Incremental: image/Dockerfile block 7 pre-warmed a debug
# `cargo build --locked --tests` into CARGO_TARGET_DIR at the base commit, so
# only the touched crate recompiles + relinks here (seconds to a couple of
# minutes). Fully offline — the dependency closure is baked into CARGO_HOME.
set -euo pipefail

REPO=/repo/longbridge-terminal

# Match image/Dockerfile's ENV block; default defensively.
export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
export PATH="$CARGO_HOME/bin:$PATH"
export CARGO_NET_OFFLINE=true

echo "validation-setup: rustc=$(rustc --version 2>&1 | head -1)"
echo "validation-setup: cargo=$(cargo --version 2>&1 | head -1)"
echo "validation-setup: CARGO_TARGET_DIR=$CARGO_TARGET_DIR"

# Build the debug binary with the agent's edits applied (incremental).
echo "validation-setup: building longbridge (debug, incremental)..."
( cd "$REPO" && cargo build --locked --bin longbridge > /tmp/validation_build.log 2>&1 ) || {
    echo "ERROR: cargo build failed; last 80 lines:" >&2
    tail -80 /tmp/validation_build.log >&2
    exit 1
}

# Resolve the binary path and record it for the harness. Prefer the configured
# target dir; fall back to the in-repo default.
BIN=""
for cand in "$CARGO_TARGET_DIR/debug/longbridge" "$REPO/target/debug/longbridge"; do
    if [ -x "$cand" ]; then BIN="$cand"; break; fi
done
if [ -z "$BIN" ]; then
    echo "ERROR: longbridge debug binary not found after build" >&2
    echo "Searched: $CARGO_TARGET_DIR/debug/longbridge, $REPO/target/debug/longbridge" >&2
    exit 1
fi
printf '%s\n' "$BIN" > /tmp/longbridge_bin_path

# Loud smoke guard: if the binary cannot even print --version, every story would
# fail with the same opaque error — surface it here instead.
if ! "$BIN" --version >/dev/null 2>&1; then
    echo "ERROR: '$BIN --version' failed; the built binary is not runnable" >&2
    "$BIN" --version || true
    exit 1
fi

echo "validation-setup: built $BIN ($("$BIN" --version 2>&1 | head -1))"
echo "validation-setup: done."
