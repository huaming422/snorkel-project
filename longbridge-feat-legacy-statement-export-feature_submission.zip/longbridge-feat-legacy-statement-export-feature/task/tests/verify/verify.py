"""Structural verifier (compile gate) for longbridge-feat-legacy-statement-export.

The behavioral checking for this task lives entirely in the validation
suite: every statement-era behavior (legacy flatten, null-section tolerance,
PDF windowing, PDF export, legible download errors, --section precedence) is
observable only by running the compiled `longbridge` binary against a local
mock HTTP server. The hard logic is private to the single binary crate
(`longbridge`, from `src/main.rs`); there is no library target to link
against, and naming the private helpers would couple the reward to one
decomposition an agent is free to change.

So this verifier is a minimal `cargo build` compile gate over the crate: it
catches an agent edit that type-checks in isolation but no longer builds (a
missing match arm after extending an exhaustive enum, a broken module wiring,
a borrow/lifetime mismatch) before the validation phase wastes time building a
doomed binary. It maps to task.toml criterion #8 (structural_verifier,
pass_to_pass).

Deliberately implementation-agnostic:
  - no grep for reference symbols / new module names / new types,
  - no `cargo test` (so it is insensitive to which unit tests the agent kept),
  - `cargo build`, NOT `cargo clippy`. The merged PR fixed a *pre-existing*
    clippy `question_mark` error in src/cli/agent/client.rs that is outside
    this task's curated scope; since the crate sets `[lints.clippy] all = deny`,
    a clippy-deny gate would fail on the reference tree itself (a pass_to_pass
    violation). criterion #8 explicitly hedges "`cargo build --locked`
    (equivalently `cargo check`)" for this reason. A build gate does not
    evaluate `[lints.clippy]`, so it passes on the reference and still rejects any
    edit that breaks the crate.
"""

from __future__ import annotations

import os
import subprocess
import textwrap


# Repository directory inside the task container (see image/Dockerfile:
# WORKDIR /repo/longbridge-terminal).
REPO_DIR = "/repo/longbridge-terminal"

# `cargo build --locked` builds the single binary crate. --locked keeps the
# lockfile authoritative (no silent dependency drift during the offline agent
# phase). The default (debug) profile matches the profile the image pre-warms
# (image/Dockerfile block 7: `cargo build --locked --tests`), so the
# incremental relink here is fast. The binary name is `longbridge`; `cargo
# build` without `--bin` builds every target in the crate, which is the
# broadest compile check.
BUILD_CMD = ["cargo", "build", "--locked"]

# 12 minutes. A warm incremental build after the agent's edits is seconds to a
# couple of minutes; this is slack for a cold Modal sandbox. Well inside the
# 900 s verifier budget (the validation stories are the heavier half).
BUILD_TIMEOUT_SEC = 720


def test_crate_compiles() -> None:
    """The crate must still `cargo build --locked` cleanly after the agent's edits.

    Runs `cargo build --locked` in /repo/longbridge-terminal. On failure, dumps
    the last 200 lines of stdout + stderr so the compile error is visible in the
    verifier log.
    """
    env = {**os.environ}
    # The image sets these; default them defensively so the verifier is robust
    # to a stripped env. Match image/Dockerfile's ENV block.
    env.setdefault("CARGO_HOME", "/opt/cargo")
    env.setdefault("RUSTUP_HOME", "/opt/rustup")
    env.setdefault("CARGO_TARGET_DIR", "/opt/cache/cargo-target")
    env["PATH"] = f"{env['CARGO_HOME']}/bin:" + env.get("PATH", "")
    # Offline: the agent phase has no network; fail fast on a cache miss rather
    # than hang. The full dependency closure is baked into CARGO_HOME at the
    # base commit.
    env.setdefault("CARGO_NET_OFFLINE", "true")

    result = subprocess.run(
        BUILD_CMD,
        cwd=REPO_DIR,
        capture_output=True,
        text=True,
        timeout=BUILD_TIMEOUT_SEC,
        env=env,
        check=False,
    )

    if result.returncode == 0:
        return

    def _tail(text: str, n: int = 200) -> str:
        return "\n".join(text.splitlines()[-n:])

    msg = textwrap.dedent(
        f"""\
        `cargo build --locked` failed (exit {result.returncode}).
        The agent's edits left the `longbridge` crate unable to build. Common
        causes:
          - Missing match arm after extending an exhaustive enum
          - Missing/renamed module not wired into its parent `mod.rs`
          - Signature mismatch between a helper and its callers
          - Borrow-checker / lifetime mismatch in the new code
          - A new dependency not present in the offline cargo cache

        --- cargo build stdout (last 200 lines) ---
        {_tail(result.stdout)}

        --- cargo build stderr (last 200 lines) ---
        {_tail(result.stderr)}
        """
    )
    raise AssertionError(msg)
