#!/usr/bin/env bash
# Per-trial setup for longbridge-feat-legacy-statement-export.
#
# No services to start and no data to seed: the task exercises the compiled
# `longbridge` CLI against a local mock HTTP server that each validation story
# spins up itself, so there is nothing to provision here. The image already
# carries the full dependency closure (cargo registry warm + workspace
# prebuilt at the base commit in image/Dockerfile block 7), so the agent's
# first `cargo build` / `cargo test` is incremental and runs with the network
# cut.
#
# Make an offline cache miss fail fast instead of hanging on a dead network
# during the agent phase (agent_offline = true). CARGO_NET_OFFLINE scopes this
# to the task's own cargo invocations; it is not baked image-wide so harbor's
# `uv tool install` of the agent harness (run while the network is still up at
# trial prep) is unaffected.
set -euo pipefail

export CARGO_NET_OFFLINE=true

echo "[test-setup] Rust:   $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo:  $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Repo:   /repo/longbridge-terminal"
echo "[test-setup] Setup complete."
