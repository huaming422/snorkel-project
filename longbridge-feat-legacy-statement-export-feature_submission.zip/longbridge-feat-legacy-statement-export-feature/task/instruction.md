## Task

You're extending the `longbridge statement` command, our Rust CLI client's piece that lists an account's statements and exports a chosen one, so it works across the full statement history, not just the current era. Today it only handles the current format, so older periods come out wrong or don't appear at all.

Statements fall into a few eras: the oldest are structured data in an earlier layout, a stretch of middle periods exist only as password-protected PDFs with no structured file behind them, and recent periods use the current layout and already work.

Both subcommands are in scope. `statement list` must account for the PDF-only periods, and `statement export` must handle every era, including the older layout and the PDFs. A download that returns something other than the expected data should be explained clearly rather than surfacing an opaque low-level error.

The PDF unlock rule is user-facing: the last 4 digits of the mobile number plus the last 4 characters of the account-opening ID, keeping only letters and digits and uppercasing. Mobile ending `12345678` with ID `123456(X)` gives `5678456X`.

## User stories / requirements

- Exporting a statement in the older structured layout produces its actual tabular contents rather than empty tables, as markdown on stdout, as JSON under `--format json`, and as CSV files with `-o`. Values older statements carry differently, such as a balance's currency, still appear.
- A download returning something other than statement data, such as an error page or empty body, yields the HTTP status, content type, a short body excerpt, and a hint the period may be PDF-only, rather than a raw parser error. An empty `--file-key` tells the user to pick an entry from `statement list`.
- Exporting with a single `--section` and an `-o` path writes just that section to the given file path rather than treating the path as a directory, and that explicit choice takes effect instead of being overridden. A statement whose empty sections carry no rows still exports successfully.
- Listing statements over a window that reaches into the era available only as PDFs shows those periods alongside the structured ones, with a column marking each entry as structured data or PDF. A window that stays entirely within the recent era is listed exactly as before.
- Exporting a PDF-format period downloads and saves the PDF, honoring `-o` as a directory or file path and otherwise writing to the current directory under the document's own name, and prints the rule for unlocking it. Under `--format json`, the output reports the saved file, its identifier, and the password rule.
