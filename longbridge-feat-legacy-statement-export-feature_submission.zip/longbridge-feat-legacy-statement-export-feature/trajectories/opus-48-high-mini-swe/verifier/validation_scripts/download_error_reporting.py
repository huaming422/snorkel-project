import sys
sys.path.insert(0, "/tests/validate")

import tempfile
from test_harness import MockStatementServer, seed_token, run_cli, combined_output


def test_download_error_reporting(inputs, expected):
    """inputs and expected are injected automatically — one call per test case."""
    with tempfile.TemporaryDirectory() as home:
        seed_token(home)
        with MockStatementServer() as mock:
            file_key = inputs["file_key"]

            # Stage bad download unless file_key is empty (empty key doesn't hit network)
            if file_key.strip():
                body = inputs["body"]
                status = inputs["status"]
                content_type = inputs["content_type"]
                mock.set_download_body(body, status=status, content_type=content_type)

            proc = run_cli(
                ["statement", "export", "--file-key", file_key],
                mock, home, cwd=home
            )
            out = combined_output(proc)
            low = out.lower()

            # EXPECTED: (result.returncode != 0) equals expected["failed"]
            assert (proc.returncode != 0) == expected["failed"], \
                f"expected failed={expected['failed']}, got returncode={proc.returncode}, output: {out}"

            # EXPECTED: all(tok.lower() in low for tok in expected["must_contain"]) is True
            assert all(tok.lower() in low for tok in expected["must_contain"]), \
                f"Some required tokens missing from output. must_contain={expected['must_contain']}, low={low}"

            # EXPECTED: when expected["mentions_pdf_hint"] is not "__skip__",
            #   ("pdf" in low) equals expected["mentions_pdf_hint"]
            if expected["mentions_pdf_hint"] != "__skip__":
                assert ("pdf" in low) == expected["mentions_pdf_hint"], \
                    f"expected mentions_pdf_hint={expected['mentions_pdf_hint']}, 'pdf' in low={('pdf' in low)}, low={low}"
