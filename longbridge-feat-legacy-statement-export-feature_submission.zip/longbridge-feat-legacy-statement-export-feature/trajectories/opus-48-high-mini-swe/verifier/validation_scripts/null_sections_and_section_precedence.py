import sys
sys.path.insert(0, "/tests/validate")

import json
import os
import tempfile
from pathlib import Path
from test_harness import MockStatementServer, seed_token, run_cli, combined_output

# PascalCase keys match the CommonStatementContent serde rename_all = "PascalCase".
# Asset.Currency and Asset.Total map to asset.currency / asset.total, making
# is_empty() return False so from_download_value returns immediately.
CURRENT_DOC_BASE = {"Asset": {"Currency": "HKD", "Total": "123"}}

FILE_KEY = "/statement_data/data/lb/1/202401/current.json"


def test_null_sections_and_section_precedence(inputs, expected):
    """inputs and expected are injected automatically — one call per test case."""
    with tempfile.TemporaryDirectory() as home:
        seed_token(home)
        with MockStatementServer() as mock:
            case = inputs["case"]

            if case == "explicit_section_to_file":
                # Body: current-era PascalCase document with Asset section data.
                # The CLI should extract just the "asset" section and write it to
                # the given -o path (single section + explicit path → file, not dir).
                body = json.dumps(CURRENT_DOC_BASE)
                mock.set_download_body(body, content_type="application/json")

                target = os.path.join(home, "asset.csv")
                proc = run_cli(
                    ["statement", "export", "--file-key", FILE_KEY,
                     "--section", "asset", "-o", target],
                    mock, home, cwd=home
                )
                out = combined_output(proc)

                # EXPECTED: (result.returncode == 0) equals expected["ok"]
                assert (proc.returncode == 0) == expected["ok"], \
                    f"expected ok={expected['ok']}, got returncode={proc.returncode}, output: {out}"

                # EXPECTED: (os.path.isfile(target)) equals expected["target_is_file"]
                assert (os.path.isfile(target)) == expected["target_is_file"], \
                    f"expected target_is_file={expected['target_is_file']}, isfile={os.path.isfile(target)}, out={out}"

                # EXPECTED: (os.path.isdir(target)) equals expected["target_is_dir"]
                assert (os.path.isdir(target)) == expected["target_is_dir"], \
                    f"expected target_is_dir={expected['target_is_dir']}, isdir={os.path.isdir(target)}"

                # EXPECTED: ("HKD" in Path(target).read_text()) equals expected["section_written"]
                if os.path.isfile(target):
                    section_written = "HKD" in Path(target).read_text()
                else:
                    section_written = False
                assert section_written == expected["section_written"], \
                    f"expected section_written={expected['section_written']}, got={section_written}, out={out}"

            elif case == "null_sections_export_ok":
                # Body: some sections carry JSON null (real-world APIs sometimes return
                # null for empty arrays). The implementation should handle this gracefully:
                # not crash with "invalid type: null", and still render the non-null sections.
                body = json.dumps({
                    "Asset": {"Currency": "HKD"},
                    "Interests": None,
                    "FundTradeSums": None
                })
                mock.set_download_body(body, content_type="application/json")

                proc = run_cli(
                    ["statement", "export", "--file-key", FILE_KEY],
                    mock, home, cwd=home
                )
                out = combined_output(proc)

                # EXPECTED: (result.returncode == 0) equals expected["ok"]
                assert (proc.returncode == 0) == expected["ok"], \
                    f"expected ok={expected['ok']}, got returncode={proc.returncode}, output: {out}"

                # EXPECTED: ("invalid type: null" in out) equals expected["null_type_error_leaked"]
                assert ("invalid type: null" in out) == expected["null_type_error_leaked"], \
                    f"expected null_type_error_leaked={expected['null_type_error_leaked']}, " \
                    f"got={'invalid type: null' in out}, out={out}"

                # EXPECTED: ("HKD" in out) equals expected["asset_rendered"]
                assert ("HKD" in out) == expected["asset_rendered"], \
                    f"expected asset_rendered={expected['asset_rendered']}, " \
                    f"got={'HKD' in out}, out={out}"
