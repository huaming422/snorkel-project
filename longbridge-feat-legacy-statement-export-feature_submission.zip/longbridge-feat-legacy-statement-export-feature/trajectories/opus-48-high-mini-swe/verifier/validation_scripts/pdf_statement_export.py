import sys
sys.path.insert(0, "/tests/validate")

import json
import os
import tempfile
from pathlib import Path
from test_harness import MockStatementServer, seed_token, run_cli, combined_output, try_parse_json


def has_pw_rule(text):
    """Check if text contains password/unlock guidance (presence floor).

    The actual rule string contains the worked example '5678456X' (uppercase).
    We search case-insensitively.
    """
    low = text.lower()
    # The worked example '5678456X' in the rule is the strongest single signal.
    return ("5678456x" in low) or ("password" in low) or ("unlock" in low)


def test_pdf_statement_export(inputs, expected):
    """inputs and expected are injected automatically — one call per test case."""
    with tempfile.TemporaryDirectory() as home:
        seed_token(home)
        with MockStatementServer() as mock:
            # The CLI path for PDF:
            #   1. ctx.statement_download_url() → SDK calls GET /v1/statement/download
            #      → mock returns {"url": file_url("statement-body")}  (rule 5)
            #   2. reqwest::Client::new().get(&resp.url) → GET /file/statement-body
            #      → mock serves _download_body (rule 1, else-branch: "statement-body"
            #        not in _files, so falls through to _download_body)
            #
            # Therefore set_download_body(pdf_bytes) is the correct hook. The
            # "the-pdf" file and set_pdf_download are registered for completeness
            # but are NOT reached by the current implementation; the direct GET
            # always goes through _download_body.
            pdf_bytes = b"%PDF-1.4 fake pdf bytes for testing"
            mock.set_download_body(pdf_bytes, content_type="application/pdf")
            # Register a named file in case any branch checks /file/the-pdf:
            mock.set_file("the-pdf", pdf_bytes, content_type="application/pdf")
            # set_pdf_download is harmless; the CLI does not call the pdf-download
            # endpoint (no "pdf" in /v1/statement/download), but we set it anyway
            # in case an alternate impl does use it:
            mock.set_pdf_download({"url": mock.file_url("the-pdf"), "cache_key": "CK123"})

            case = inputs["case"]
            file_key = inputs["file_key"]

            if case == "default_cwd":
                # No -o: PDF saved to CWD (home).
                # Filename derived from download URL path segment: "statement-body.pdf"
                # (the mock URL /file/statement-body has no .pdf suffix, so the code appends one).
                proc = run_cli(
                    ["statement", "export", "--file-key", file_key],
                    mock, home, cwd=home
                )
                out = combined_output(proc)
                pdfs = sorted(Path(home).glob("*.pdf"))

                # EXPECTED: (result.returncode == 0) equals expected["ok"]
                assert (proc.returncode == 0) == expected["ok"], \
                    f"expected ok={expected['ok']}, got returncode={proc.returncode}, output: {out}"

                # EXPECTED: (len(pdfs) >= 1) equals expected["pdf_saved"]
                assert (len(pdfs) >= 1) == expected["pdf_saved"], \
                    f"expected pdf_saved={expected['pdf_saved']}, found pdfs={pdfs}, output: {out}"

                # EXPECTED: expected["pdf_bytes_written"] equals bool(pdfs and pdfs[0].read_bytes().startswith(b"%PDF"))
                actual_pdf_bytes_written = bool(pdfs and pdfs[0].read_bytes().startswith(b"%PDF"))
                assert expected["pdf_bytes_written"] == actual_pdf_bytes_written, \
                    f"expected pdf_bytes_written={expected['pdf_bytes_written']}, got={actual_pdf_bytes_written}"

                # EXPECTED: has_pw_rule(out) equals expected["password_rule_present"]
                assert has_pw_rule(out) == expected["password_rule_present"], \
                    f"expected password_rule_present={expected['password_rule_present']}, " \
                    f"has_pw_rule={has_pw_rule(out)}, out={out}"

            elif case == "output_dir":
                # -o outdir/ (trailing separator): PDF saved inside outdir.
                # pdf_output_path sees ends_with('/') → is_dir=True → outdir/statement-body.pdf.
                # export_pdf calls create_dir_all(outdir) before writing.
                outdir = os.path.join(home, "out")
                proc = run_cli(
                    ["statement", "export", "--file-key", file_key, "-o", outdir + os.sep],
                    mock, home, cwd=home
                )
                out = combined_output(proc)
                pdfs = sorted(Path(outdir).glob("*.pdf")) if os.path.isdir(outdir) else []

                # EXPECTED: (result.returncode == 0) equals expected["ok"]
                assert (proc.returncode == 0) == expected["ok"], \
                    f"expected ok={expected['ok']}, got returncode={proc.returncode}, output: {out}"

                # EXPECTED: (len(pdfs) >= 1) equals expected["pdf_saved"]
                assert (len(pdfs) >= 1) == expected["pdf_saved"], \
                    f"expected pdf_saved={expected['pdf_saved']}, found pdfs={pdfs}, output: {out}"

                # EXPECTED: expected["pdf_bytes_written"] equals bool(pdfs and pdfs[0].read_bytes().startswith(b"%PDF"))
                actual_pdf_bytes_written = bool(pdfs and pdfs[0].read_bytes().startswith(b"%PDF"))
                assert expected["pdf_bytes_written"] == actual_pdf_bytes_written, \
                    f"expected pdf_bytes_written={expected['pdf_bytes_written']}, got={actual_pdf_bytes_written}"

                # EXPECTED: has_pw_rule(out) equals expected["password_rule_present"]
                assert has_pw_rule(out) == expected["password_rule_present"], \
                    f"expected password_rule_present={expected['password_rule_present']}, " \
                    f"has_pw_rule={has_pw_rule(out)}, out={out}"

            elif case == "json_output":
                # --format json: export_pdf emits JSON with file/file_key/format/password_rule.
                # JSON shape (from export_pdf):
                #   {"file": "<path>.pdf", "file_key": "<key>", "format": "pdf",
                #    "password_rule": "<long string containing 5678456X>"}
                proc = run_cli(
                    ["--format", "json", "statement", "export", "--file-key", file_key],
                    mock, home, cwd=home
                )
                doc = try_parse_json(proc.stdout)
                if doc is None:
                    doc = {}
                blob = json.dumps(doc)

                # EXPECTED: (result.returncode == 0) equals expected["ok"]
                assert (proc.returncode == 0) == expected["ok"], \
                    f"expected ok={expected['ok']}, got returncode={proc.returncode}, " \
                    f"output: {combined_output(proc)}"

                # EXPECTED: (".pdf" in blob) equals expected["json_reports_file"]
                # The JSON "file" field will contain "statement-body.pdf".
                assert (".pdf" in blob) == expected["json_reports_file"], \
                    f"expected json_reports_file={expected['json_reports_file']}, " \
                    f"'.pdf' in blob={('.pdf' in blob)}, blob={blob}"

                # EXPECTED: (("CK123" in blob) or (inputs["file_key"] in blob)) equals expected["json_reports_cache_key"]
                # The JSON "file_key" field carries the original file_key argument;
                # "CK123" would come from a separate PDF-download endpoint which the
                # current implementation does not call — so we accept either signal.
                reports_cache_key = ("CK123" in blob) or (inputs["file_key"] in blob)
                assert reports_cache_key == expected["json_reports_cache_key"], \
                    f"expected json_reports_cache_key={expected['json_reports_cache_key']}, " \
                    f"got={reports_cache_key}, blob={blob}"

                # EXPECTED: has_pw_rule(blob) equals expected["json_reports_password_rule"]
                # The "password_rule" field in the JSON contains the worked example.
                assert has_pw_rule(blob) == expected["json_reports_password_rule"], \
                    f"expected json_reports_password_rule={expected['json_reports_password_rule']}, " \
                    f"has_pw_rule={has_pw_rule(blob)}, blob={blob}"
