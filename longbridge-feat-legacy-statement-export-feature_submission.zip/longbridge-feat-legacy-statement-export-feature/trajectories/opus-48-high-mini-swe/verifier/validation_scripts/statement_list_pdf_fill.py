import sys
sys.path.insert(0, "/tests/validate")

import json
import tempfile
from test_harness import MockStatementServer, seed_token, run_cli, combined_output


def test_statement_list_pdf_fill(inputs, expected):
    """inputs and expected are injected automatically — one call per test case."""
    with tempfile.TemporaryDirectory() as home:
        seed_token(home)
        with MockStatementServer() as mock:
            # Stage the structured list
            structured_list = json.loads(inputs["structured_json"])
            mock.set_statement_list(structured_list)

            # Stage PDF list if requested
            if inputs["stage_pdf"]:
                mock.set_pdf_list({"items": [
                    {"display_name": "2024.03", "key": "*a*202403*stmt-202403.pdf", "cache_key": ""},
                    {"display_name": "2024.05", "key": "*a*202405*stmt-202405.pdf", "cache_key": ""},
                ]})

            proc = run_cli(
                ["statement", "list", "--type", "monthly",
                 "--start-date", inputs["start_date"],
                 "--limit", str(inputs["limit"])],
                mock, home, cwd=home
            )
            out = combined_output(proc)

            # EXPECTED: (result.returncode == 0) equals expected["ok"]
            assert (proc.returncode == 0) == expected["ok"], \
                f"expected ok={expected['ok']}, got returncode={proc.returncode}, output: {out}"

            # EXPECTED: ("202403" in out) equals expected["period_202403_listed"]
            assert ("202403" in out) == expected["period_202403_listed"], \
                f"expected period_202403_listed={expected['period_202403_listed']}, '202403' in out={('202403' in out)}, out={out}"

            # EXPECTED: ("202408" in out) equals expected["period_202408_listed"]
            assert ("202408" in out) == expected["period_202408_listed"], \
                f"expected period_202408_listed={expected['period_202408_listed']}, '202408' in out={('202408' in out)}, out={out}"

            # EXPECTED: (out.count("pdf") >= expected["min_pdf_rows"]) is True
            assert out.count("pdf") >= expected["min_pdf_rows"], \
                f"expected >= {expected['min_pdf_rows']} occurrences of 'pdf' in out, got {out.count('pdf')}, out={out}"

            # EXPECTED: with n = mock.count_matching("pdf", "list"),
            #   both expected["min_pdf_list_calls"] <= n and n <= expected["max_pdf_list_calls"] hold
            n = mock.count_matching("pdf", "list")
            assert expected["min_pdf_list_calls"] <= n, \
                f"expected min_pdf_list_calls={expected['min_pdf_list_calls']} <= n={n}"
            assert n <= expected["max_pdf_list_calls"], \
                f"expected n={n} <= max_pdf_list_calls={expected['max_pdf_list_calls']}"
