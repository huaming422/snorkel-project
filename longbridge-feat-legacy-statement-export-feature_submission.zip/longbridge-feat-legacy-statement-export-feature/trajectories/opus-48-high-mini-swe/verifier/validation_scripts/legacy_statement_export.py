import sys
sys.path.insert(0, "/tests/validate")

import json
import os
import tempfile
from pathlib import Path
from test_harness import MockStatementServer, seed_token, run_cli, combined_output, try_parse_json

LEGACY_DOC = {
    "Date": "2021.11.30",
    "AssetDetail": {"Cash": "1", "Total": "2"},
    "CashDetails": {
        "Currency": "HKD",
        "CashDetail": [
            {"Currency": "HKD", "Amount": "1"},
            {"Currency": "USD", "Amount": "2"},
        ],
    },
    "StockHoldingDetails": [
        {"Market": "US", "StockHolding": [{"StName": "DAL", "Total": "199"}]},
        {"Market": "HK", "StockHolding": [{"StName": "00175", "Total": "1000"}]},
    ],
    "Empty": None,
    "Nothing": [],
}


def test_legacy_statement_export(inputs, expected):
    """inputs and expected are injected automatically — one call per test case."""
    with tempfile.TemporaryDirectory() as home:
        seed_token(home)
        with MockStatementServer() as mock:
            mock.set_download_body(json.dumps(LEGACY_DOC), content_type="application/json")
            file_key = inputs["file_key"]
            case = inputs["case"]

            if case == "markdown":
                proc = run_cli(
                    ["statement", "export", "--file-key", file_key],
                    mock, home, cwd=home
                )
                out = combined_output(proc)

                assert (proc.returncode == 0) == expected["ok"], \
                    f"expected ok={expected['ok']}, got returncode={proc.returncode}, output: {out}"
                assert ("Market" in out) == expected["holdings_has_market_column"], \
                    f"expected holdings_has_market_column={expected['holdings_has_market_column']}, out={out}"
                assert expected["holdings_rows_present"] == all(name in out for name in ["DAL", "199", "00175", "1000"]), \
                    f"expected holdings_rows_present={expected['holdings_rows_present']}, out={out}"
                assert ("HKD" in out) == expected["currency_present"], \
                    f"expected currency_present={expected['currency_present']}, out={out}"
                assert ("USD" in out) == expected["second_currency_present"], \
                    f"expected second_currency_present={expected['second_currency_present']}, out={out}"

            elif case == "json":
                proc = run_cli(
                    ["--format", "json", "statement", "export", "--file-key", file_key],
                    mock, home, cwd=home
                )
                doc = try_parse_json(proc.stdout)
                if doc is None:
                    doc = {}
                blob = json.dumps(doc)

                assert (proc.returncode == 0) == expected["ok"], \
                    f"expected ok={expected['ok']}, got returncode={proc.returncode}, output: {combined_output(proc)}"
                assert (doc not in (None, {}, [])) == expected["json_nonempty"], \
                    f"expected json_nonempty={expected['json_nonempty']}, doc={doc}"
                assert expected["json_has_holdings_data"] == all(tok in blob for tok in ["DAL", "00175", "199", "1000"]), \
                    f"expected json_has_holdings_data={expected['json_has_holdings_data']}, blob={blob}"
                assert ("HKD" in blob) == expected["json_has_currency"], \
                    f"expected json_has_currency={expected['json_has_currency']}, blob={blob}"

            elif case == "csv_dir":
                outdir = os.path.join(home, "csvout")
                proc = run_cli(
                    ["statement", "export", "--file-key", file_key, "-o", outdir],
                    mock, home, cwd=home
                )
                out = combined_output(proc)

                # Collect CSVs from the output directory (may not exist if proc failed)
                if os.path.isdir(outdir):
                    csvs = sorted(p.name for p in Path(outdir).glob("*.csv"))
                    blob = "".join(Path(outdir).joinpath(n).read_text() for n in csvs)
                else:
                    csvs = []
                    blob = ""

                assert (proc.returncode == 0) == expected["ok"], \
                    f"expected ok={expected['ok']}, got returncode={proc.returncode}, output: {out}"
                assert len(csvs) >= expected["min_csv_files"], \
                    f"expected >= {expected['min_csv_files']} CSV files, got {len(csvs)}: {csvs}"
                assert expected["csv_has_holdings_rows"] == all(tok in blob for tok in ["DAL", "199", "00175", "1000"]), \
                    f"expected csv_has_holdings_rows={expected['csv_has_holdings_rows']}, blob={blob}"
                assert ("HKD" in blob) == expected["csv_has_currency"], \
                    f"expected csv_has_currency={expected['csv_has_currency']}, blob={blob}"
