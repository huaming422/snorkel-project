import sys
sys.path.insert(0, "/tests/validate")

import tempfile
from test_harness import MockStatementServer, seed_token, run_cli, combined_output


def test_download_error_reporting(inputs, expected):
    file_key = inputs["file_key"]

    with tempfile.TemporaryDirectory() as home:
        seed_token(home)
        with MockStatementServer() as mock:
            # Stage the bad download body if file_key is not empty
            if file_key.strip():
                mock.set_download_body(
                    inputs["body"],
                    status=inputs["status"],
                    content_type=inputs["content_type"],
                )

            proc = run_cli(
                ["statement", "export", "--file-key", file_key],
                mock, home, cwd=home,
            )
            out = combined_output(proc)
            low = out.lower()

            assert (proc.returncode != 0) == expected["failed"], \
                f"returncode={proc.returncode}, expected failed={expected['failed']}, out={out}"

            for tok in expected["must_contain"]:
                assert tok.lower() in low, \
                    f"Expected token '{tok}' (lowercased) not found in output (lowercased). out={out}"

            if expected["mentions_pdf_hint"] != "__skip__":
                assert ("pdf" in low) == expected["mentions_pdf_hint"], \
                    f"'pdf' in low={('pdf' in low)}, expected mentions_pdf_hint={expected['mentions_pdf_hint']}, out={out}"
