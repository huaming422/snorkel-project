import sys
sys.path.insert(0, "/tests/validate")

import json
import os
import tempfile
from pathlib import Path
from test_harness import MockStatementServer, seed_token, run_cli, combined_output

CURRENT_DOC_BASE = {"Asset": {"Currency": "HKD", "Total": "123"}}


def test_null_sections_and_section_precedence(inputs, expected):
    case = inputs["case"]

    with tempfile.TemporaryDirectory() as home:
        seed_token(home)
        with MockStatementServer() as mock:

            if case == "explicit_section_to_file":
                body = json.dumps(CURRENT_DOC_BASE)
                mock.set_download_body(body, content_type="application/json")
                target = os.path.join(home, "asset.csv")
                proc = run_cli(
                    ["statement", "export", "--file-key", "KEY", "--section", "asset", "-o", target],
                    mock, home, cwd=home,
                )
                out = combined_output(proc)

                assert (proc.returncode == 0) == expected["ok"], \
                    f"returncode={proc.returncode}, expected ok={expected['ok']}, out={out}"
                assert os.path.isfile(target) == expected["target_is_file"], \
                    f"isfile(target)={os.path.isfile(target)}, expected={expected['target_is_file']}, out={out}"
                assert os.path.isdir(target) == expected["target_is_dir"], \
                    f"isdir(target)={os.path.isdir(target)}, expected={expected['target_is_dir']}"
                if os.path.isfile(target):
                    content = Path(target).read_text()
                    section_written = "HKD" in content
                else:
                    section_written = False
                assert section_written == expected["section_written"], \
                    f"section_written={section_written}, expected={expected['section_written']}, target exists={os.path.isfile(target)}"
                # __skip__ keys
                _ = expected["null_type_error_leaked"]
                _ = expected["asset_rendered"]

            elif case == "null_sections_export_ok":
                body = json.dumps({
                    "Asset": {"Currency": "HKD"},
                    "Interests": None,
                    "FundTradeSums": None,
                })
                mock.set_download_body(body, content_type="application/json")
                proc = run_cli(
                    ["statement", "export", "--file-key", "KEY"],
                    mock, home, cwd=home,
                )
                out = combined_output(proc)

                assert (proc.returncode == 0) == expected["ok"], \
                    f"returncode={proc.returncode}, expected ok={expected['ok']}, out={out}"
                assert ("invalid type: null" in out) == expected["null_type_error_leaked"], \
                    f"'invalid type: null' in out={('invalid type: null' in out)}, expected={expected['null_type_error_leaked']}, out={out}"
                assert ("HKD" in out) == expected["asset_rendered"], \
                    f"'HKD' in out={('HKD' in out)}, expected={expected['asset_rendered']}, out={out}"
                # __skip__ keys
                _ = expected["target_is_file"]
                _ = expected["target_is_dir"]
                _ = expected["section_written"]

            else:
                raise ValueError(f"Unknown case: {case}")
