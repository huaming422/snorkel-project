import sys
sys.path.insert(0, "/tests/validate")

import json
import os
import tempfile
from pathlib import Path
from test_harness import MockStatementServer, seed_token, run_cli, combined_output, try_parse_json


def has_pw_rule(text):
    low = text.lower()
    return ("5678456x" in low) or ("password" in low) or ("unlock" in low)


def test_pdf_statement_export(inputs, expected):
    case = inputs["case"]
    file_key = inputs["file_key"]

    with tempfile.TemporaryDirectory() as home:
        seed_token(home)
        with MockStatementServer() as mock:
            # Register the PDF bytes and set up the PDF download endpoint.
            # Per the procedure: stage set_file + set_pdf_download (reference design).
            # Also set_download_body for the SDK fallback path (this implementation uses
            # statement_download_url which the mock resolves to file_url("statement-body")).
            mock.set_file("the-pdf", b"%PDF-1.4 fake pdf bytes", content_type="application/pdf")
            mock.set_pdf_download({"url": mock.file_url("the-pdf"), "cache_key": "CK123"})
            mock.set_download_body(b"%PDF-1.4 fake pdf bytes", content_type="application/pdf")

            if case == "default_cwd":
                proc = run_cli(
                    ["statement", "export", "--file-key", file_key],
                    mock, home, cwd=home,
                )
                out = combined_output(proc)
                pdfs = sorted(Path(home).glob("*.pdf"))

                assert (proc.returncode == 0) == expected["ok"], \
                    f"returncode={proc.returncode}, expected ok={expected['ok']}, out={out}"
                assert (len(pdfs) >= 1) == expected["pdf_saved"], \
                    f"len(pdfs)={len(pdfs)}, expected pdf_saved={expected['pdf_saved']}, out={out}, files={list(Path(home).iterdir())}"
                assert expected["pdf_bytes_written"] == bool(pdfs and pdfs[0].read_bytes().startswith(b"%PDF")), \
                    f"pdf_bytes check failed, pdfs={pdfs}"
                assert has_pw_rule(out) == expected["password_rule_present"], \
                    f"has_pw_rule={has_pw_rule(out)}, expected={expected['password_rule_present']}, out={out}"
                # __skip__ keys for other cases
                _ = expected["json_reports_file"]
                _ = expected["json_reports_cache_key"]
                _ = expected["json_reports_password_rule"]

            elif case == "output_dir":
                outdir = os.path.join(home, "out")
                proc = run_cli(
                    ["statement", "export", "--file-key", file_key, "-o", outdir + os.sep],
                    mock, home, cwd=home,
                )
                out = combined_output(proc)
                pdfs = sorted(Path(outdir).glob("*.pdf")) if Path(outdir).exists() else []

                assert (proc.returncode == 0) == expected["ok"], \
                    f"returncode={proc.returncode}, expected ok={expected['ok']}, out={out}"
                assert (len(pdfs) >= 1) == expected["pdf_saved"], \
                    f"len(pdfs)={len(pdfs)}, expected pdf_saved={expected['pdf_saved']}, out={out}, outdir_contents={list(Path(outdir).iterdir()) if Path(outdir).exists() else 'dir not created'}"
                assert expected["pdf_bytes_written"] == bool(pdfs and pdfs[0].read_bytes().startswith(b"%PDF")), \
                    f"pdf_bytes check failed, pdfs={pdfs}"
                assert has_pw_rule(out) == expected["password_rule_present"], \
                    f"has_pw_rule={has_pw_rule(out)}, expected={expected['password_rule_present']}, out={out}"
                # __skip__ keys
                _ = expected["json_reports_file"]
                _ = expected["json_reports_cache_key"]
                _ = expected["json_reports_password_rule"]

            elif case == "json_output":
                proc = run_cli(
                    ["--format", "json", "statement", "export", "--file-key", file_key],
                    mock, home, cwd=home,
                )
                doc = try_parse_json(proc.stdout) or {}
                blob = json.dumps(doc)
                out = combined_output(proc)

                assert (proc.returncode == 0) == expected["ok"], \
                    f"returncode={proc.returncode}, expected ok={expected['ok']}, out={out}"
                assert (".pdf" in blob) == expected["json_reports_file"], \
                    f"'.pdf' in blob={('.pdf' in blob)}, expected={expected['json_reports_file']}, blob={blob}"
                assert (("CK123" in blob) or (file_key in blob)) == expected["json_reports_cache_key"], \
                    f"cache_key check: 'CK123' in blob={('CK123' in blob)}, file_key in blob={file_key in blob}, expected={expected['json_reports_cache_key']}, blob={blob}"
                assert has_pw_rule(blob) == expected["json_reports_password_rule"], \
                    f"has_pw_rule(blob)={has_pw_rule(blob)}, expected={expected['json_reports_password_rule']}, blob={blob}"
                # __skip__ keys
                _ = expected["pdf_saved"]
                _ = expected["pdf_bytes_written"]
                _ = expected["password_rule_present"]

            else:
                raise ValueError(f"Unknown case: {case}")
