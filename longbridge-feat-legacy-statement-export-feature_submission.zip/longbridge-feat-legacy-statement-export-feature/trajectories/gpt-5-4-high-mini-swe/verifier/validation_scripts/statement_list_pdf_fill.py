import sys
sys.path.insert(0, "/tests/validate")

import json
import tempfile
from test_harness import MockStatementServer, seed_token, run_cli, combined_output

# NOTE: The submitted implementation does NOT use a separate PDF-list endpoint.
# It classifies each statement item by calling statement_download_url and checking
# the content of the resolved URL (falling back to content inspection when the URL
# does not end in .pdf or .json). The mock always returns file_url("statement-body")
# for all statement/download requests.
#
# For cases where stage_pdf=true and the test expects PDF rows (min_pdf_rows >= 1),
# we set the download body to PDF bytes to trigger PDF classification.
# For cases expecting no PDF rows (min_pdf_rows == 0), we use JSON download body.
# The min_pdf_list_calls assertion will fail honestly when the implementation
# does not call a separate PDF-list endpoint.


def test_statement_list_pdf_fill(inputs, expected):
    start_date = inputs["start_date"]
    limit = inputs["limit"]
    stage_pdf = inputs["stage_pdf"]
    structured_json = inputs["structured_json"]

    structured_entries = json.loads(structured_json)

    # Determine if we expect PDF rows from the expected output
    min_pdf_rows = expected["min_pdf_rows"]

    with tempfile.TemporaryDirectory() as home:
        seed_token(home)
        with MockStatementServer() as mock:
            mock.set_statement_list(structured_entries)

            if stage_pdf:
                # Stage PDF list per the procedure (reference design shape).
                # This implementation may not call this endpoint, but we stage it faithfully.
                mock.set_pdf_list({"items": [
                    {"display_name": "2024.03", "key": "*a*202403*stmt-202403.pdf", "cache_key": ""},
                    {"display_name": "2024.05", "key": "*a*202405*stmt-202405.pdf", "cache_key": ""},
                ]})

            if min_pdf_rows > 0:
                # Set PDF bytes so the implementation can classify items as PDF via content check
                mock.set_download_body(b"%PDF-1.4 fake pdf", content_type="application/pdf")
            else:
                # Use JSON body so items are classified as structured
                mock.set_download_body(
                    json.dumps({"Asset": {"Currency": "HKD"}}),
                    content_type="application/json",
                )

            proc = run_cli(
                ["statement", "list", "--type", "monthly",
                 "--start-date", start_date, "--limit", str(limit)],
                mock, home, cwd=home,
            )
            out = combined_output(proc)

            assert (proc.returncode == 0) == expected["ok"], \
                f"returncode={proc.returncode}, expected ok={expected['ok']}, out={out}"

            assert ("202403" in out) == expected["period_202403_listed"], \
                f"'202403' in out={('202403' in out)}, expected={expected['period_202403_listed']}, out={out}"

            assert ("202408" in out) == expected["period_202408_listed"], \
                f"'202408' in out={('202408' in out)}, expected={expected['period_202408_listed']}, out={out}"

            pdf_count = out.count("pdf")
            assert pdf_count >= expected["min_pdf_rows"], \
                f"pdf count in out={pdf_count}, expected min_pdf_rows={expected['min_pdf_rows']}, out={out}"

            n = mock.count_matching("pdf", "list")
            assert expected["min_pdf_list_calls"] <= n, \
                f"pdf/list calls n={n}, expected min_pdf_list_calls={expected['min_pdf_list_calls']}, paths={mock.paths()}"
            assert n <= expected["max_pdf_list_calls"], \
                f"pdf/list calls n={n}, expected max_pdf_list_calls={expected['max_pdf_list_calls']}, paths={mock.paths()}"
