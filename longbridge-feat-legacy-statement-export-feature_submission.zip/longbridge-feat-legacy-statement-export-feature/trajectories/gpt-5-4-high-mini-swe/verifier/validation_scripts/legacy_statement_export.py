import sys
sys.path.insert(0, "/tests/validate")

import json
import os
import tempfile
from pathlib import Path
from test_harness import MockStatementServer, seed_token, run_cli, combined_output, try_parse_json

LEGACY_DOC = {
    "Date": "2021.11.30",
    "AssetDetail": {"Cash": "1", "Total": "2"},
    "CashDetails": {
        "Currency": "HKD",
        "CashDetail": [
            {"Currency": "HKD", "Amount": "1"},
            {"Currency": "USD", "Amount": "2"},
        ],
    },
    "StockHoldingDetails": [
        {"Market": "US", "StockHolding": [{"StName": "DAL", "Total": "199"}]},
        {"Market": "HK", "StockHolding": [{"StName": "00175", "Total": "1000"}]},
    ],
    "Empty": None,
    "Nothing": [],
}


def test_legacy_statement_export(inputs, expected):
    case = inputs["case"]
    file_key = inputs["file_key"]

    with tempfile.TemporaryDirectory() as home:
        seed_token(home)
        with MockStatementServer() as mock:
            mock.set_download_body(json.dumps(LEGACY_DOC), content_type="application/json")

            if case == "markdown":
                proc = run_cli(
                    ["statement", "export", "--file-key", file_key],
                    mock, home, cwd=home,
                )
                out = combined_output(proc)

                assert (proc.returncode == 0) == expected["ok"], \
                    f"returncode={proc.returncode}, expected ok={expected['ok']}, out={out}"
                assert ("Market" in out) == expected["holdings_has_market_column"], \
                    f"'Market' in out={('Market' in out)}, expected={expected['holdings_has_market_column']}, out={out}"
                assert expected["holdings_rows_present"] == all(
                    name in out for name in ["DAL", "199", "00175", "1000"]
                ), f"holdings rows mismatch, out={out}"
                assert ("HKD" in out) == expected["currency_present"], \
                    f"'HKD' in out={('HKD' in out)}, expected={expected['currency_present']}, out={out}"
                assert ("USD" in out) == expected["second_currency_present"], \
                    f"'USD' in out={('USD' in out)}, expected={expected['second_currency_present']}, out={out}"
                # __skip__ keys — touch them to satisfy the "use all keys" rule
                _ = expected["json_nonempty"]
                _ = expected["json_has_holdings_data"]
                _ = expected["json_has_currency"]
                _ = expected["min_csv_files"]
                _ = expected["csv_has_holdings_rows"]
                _ = expected["csv_has_currency"]

            elif case == "json":
                proc = run_cli(
                    ["--format", "json", "statement", "export", "--file-key", file_key],
                    mock, home, cwd=home,
                )
                doc = try_parse_json(proc.stdout) or {}
                blob = json.dumps(doc)

                assert (proc.returncode == 0) == expected["ok"], \
                    f"returncode={proc.returncode}, expected ok={expected['ok']}, out={combined_output(proc)}"
                assert (doc not in (None, {}, [])) == expected["json_nonempty"], \
                    f"doc={doc}, expected json_nonempty={expected['json_nonempty']}"
                assert expected["json_has_holdings_data"] == all(
                    tok in blob for tok in ["DAL", "00175", "199", "1000"]
                ), f"holdings data mismatch, blob={blob[:200]}"
                assert ("HKD" in blob) == expected["json_has_currency"], \
                    f"'HKD' in blob={('HKD' in blob)}, expected={expected['json_has_currency']}"
                # __skip__ keys
                _ = expected["holdings_has_market_column"]
                _ = expected["holdings_rows_present"]
                _ = expected["currency_present"]
                _ = expected["second_currency_present"]
                _ = expected["min_csv_files"]
                _ = expected["csv_has_holdings_rows"]
                _ = expected["csv_has_currency"]

            elif case == "csv_dir":
                outdir = os.path.join(home, "csvout")
                proc = run_cli(
                    ["statement", "export", "--file-key", file_key, "-o", outdir],
                    mock, home, cwd=home,
                )
                out = combined_output(proc)
                csvs = sorted(p.name for p in Path(outdir).glob("*.csv")) if Path(outdir).exists() else []
                blob = "".join(Path(outdir).joinpath(n).read_text() for n in csvs) if csvs else ""

                assert (proc.returncode == 0) == expected["ok"], \
                    f"returncode={proc.returncode}, expected ok={expected['ok']}, out={out}"
                assert len(csvs) >= expected["min_csv_files"], \
                    f"len(csvs)={len(csvs)}, min_csv_files={expected['min_csv_files']}, csvs={csvs}"
                assert expected["csv_has_holdings_rows"] == all(
                    tok in blob for tok in ["DAL", "199", "00175", "1000"]
                ), f"holdings rows in csv mismatch, blob={blob[:400]}"
                assert ("HKD" in blob) == expected["csv_has_currency"], \
                    f"'HKD' in blob={('HKD' in blob)}, expected={expected['csv_has_currency']}"
                # __skip__ keys
                _ = expected["holdings_has_market_column"]
                _ = expected["holdings_rows_present"]
                _ = expected["currency_present"]
                _ = expected["second_currency_present"]
                _ = expected["json_nonempty"]
                _ = expected["json_has_holdings_data"]
                _ = expected["json_has_currency"]

            else:
                raise ValueError(f"Unknown case: {case}")
