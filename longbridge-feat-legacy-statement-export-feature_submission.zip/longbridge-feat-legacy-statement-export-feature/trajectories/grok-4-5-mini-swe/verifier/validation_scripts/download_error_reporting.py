import sys
sys.path.insert(0, "/tests/validate")

import json
import os
import tempfile
from test_harness import MockStatementServer, seed_token, run_cli, combined_output, try_parse_json


def test_download_error_reporting(inputs, expected):
    file_key = inputs["file_key"]
    body = inputs["body"]
    status = inputs["status"]
    content_type = inputs["content_type"]

    with tempfile.TemporaryDirectory() as home:
        seed_token(home)
        with MockStatementServer() as mock:
            # Only stage a download body when there IS a file key to resolve
            # AND the body is not the sentinel "__skip__" value.
            # When file_key is empty, the CLI bails before any network call.
            # When body is "__skip__", there is nothing to stage.
            if file_key and body != "__skip__":
                mock.set_download_body(body, status=status, content_type=content_type)

            proc = run_cli(
                ["statement", "export", "--file-key", file_key],
                mock, home, cwd=home
            )
            out = combined_output(proc)
            low = out.lower()

            assert (proc.returncode != 0) == expected["failed"], \
                f"Expected (returncode != 0) == {expected['failed']}, got returncode={proc.returncode}. Output: {out}"

            must_contain = expected["must_contain"]
            for tok in must_contain:
                assert tok.lower() in low, \
                    f"Expected token {tok!r} (case-insensitive) in output. Output: {out}"

            if expected["mentions_pdf_hint"] != "__skip__":
                assert ("pdf" in low) == expected["mentions_pdf_hint"], \
                    f"Expected 'pdf' in output to be {expected['mentions_pdf_hint']}. Output: {out}"
