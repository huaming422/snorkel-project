import sys
sys.path.insert(0, "/tests/validate")

import json
import os
import tempfile
from pathlib import Path
from test_harness import MockStatementServer, seed_token, run_cli, combined_output, try_parse_json

SKIP = "__skip__"


def has_pw_rule(text):
    low = text.lower()
    # The worked example is the strongest single signal, but any
    # password/unlock guidance satisfies the presence floor.
    return ("5678456x" in low) or ("password" in low) or ("unlock" in low)


def test_pdf_statement_export(inputs, expected):
    case = inputs["case"]
    file_key = inputs["file_key"]

    with tempfile.TemporaryDirectory() as home:
        seed_token(home)
        with MockStatementServer() as mock:
            # The implementation uses statement_download_url -> set_download_body path.
            # Set the download body to real PDF bytes so is_pdf_download() detects it.
            mock.set_download_body(
                b"%PDF-1.4 fake pdf bytes",
                content_type="application/pdf"
            )
            # Also stage set_pdf_download in case the implementation uses a separate PDF path
            # (harmless if not used).
            mock.set_file("the-pdf", b"%PDF-1.4 fake pdf bytes", content_type="application/pdf")
            mock.set_pdf_download({"url": mock.file_url("the-pdf"), "cache_key": "CK123"})

            if case == "default_cwd":
                proc = run_cli(
                    ["statement", "export", "--file-key", file_key],
                    mock, home, cwd=home
                )
                out = combined_output(proc)
                pdfs = sorted(Path(home).glob("*.pdf"))

                assert (proc.returncode == 0) == expected["ok"], \
                    f"Expected returncode==0 to be {expected['ok']}, got returncode={proc.returncode}. Output: {out}"

                if expected["pdf_saved"] != SKIP:
                    assert (len(pdfs) >= 1) == expected["pdf_saved"], \
                        f"Expected pdf_saved={expected['pdf_saved']}, got {len(pdfs)} pdfs. Output: {out}"

                if expected["pdf_bytes_written"] != SKIP:
                    assert expected["pdf_bytes_written"] == bool(pdfs and pdfs[0].read_bytes().startswith(b"%PDF")), \
                        f"Expected pdf_bytes_written={expected['pdf_bytes_written']}. pdfs={pdfs}. Output: {out}"

                if expected["password_rule_present"] != SKIP:
                    assert has_pw_rule(out) == expected["password_rule_present"], \
                        f"Expected password_rule_present={expected['password_rule_present']}. Output: {out}"

                # json_reports_file, json_reports_cache_key, json_reports_password_rule
                # are __skip__ for this case.

            elif case == "output_dir":
                outdir = os.path.join(home, "out")
                proc = run_cli(
                    ["statement", "export", "--file-key", file_key, "-o", outdir + os.sep],
                    mock, home, cwd=home
                )
                out = combined_output(proc)
                pdfs = sorted(Path(outdir).glob("*.pdf")) if os.path.isdir(outdir) else []

                assert (proc.returncode == 0) == expected["ok"], \
                    f"Expected returncode==0 to be {expected['ok']}, got returncode={proc.returncode}. Output: {out}"

                if expected["pdf_saved"] != SKIP:
                    assert (len(pdfs) >= 1) == expected["pdf_saved"], \
                        f"Expected pdf_saved={expected['pdf_saved']}, got {len(pdfs)} pdfs in {outdir}. Output: {out}"

                if expected["pdf_bytes_written"] != SKIP:
                    assert expected["pdf_bytes_written"] == bool(pdfs and pdfs[0].read_bytes().startswith(b"%PDF")), \
                        f"Expected pdf_bytes_written={expected['pdf_bytes_written']}. pdfs={pdfs}. Output: {out}"

                if expected["password_rule_present"] != SKIP:
                    assert has_pw_rule(out) == expected["password_rule_present"], \
                        f"Expected password_rule_present={expected['password_rule_present']}. Output: {out}"

                # json_reports_file, json_reports_cache_key, json_reports_password_rule
                # are __skip__ for this case.

            elif case == "json_output":
                proc = run_cli(
                    ["--format", "json", "statement", "export", "--file-key", file_key],
                    mock, home, cwd=home
                )
                out = combined_output(proc)
                doc = try_parse_json(proc.stdout) or {}
                blob = json.dumps(doc)

                assert (proc.returncode == 0) == expected["ok"], \
                    f"Expected returncode==0 to be {expected['ok']}, got returncode={proc.returncode}. Output: {out}"

                if expected["json_reports_file"] != SKIP:
                    assert (".pdf" in blob) == expected["json_reports_file"], \
                        f"Expected json_reports_file={expected['json_reports_file']}. blob={blob}"

                if expected["json_reports_cache_key"] != SKIP:
                    assert (("CK123" in blob) or (file_key in blob)) == expected["json_reports_cache_key"], \
                        f"Expected json_reports_cache_key={expected['json_reports_cache_key']}. blob={blob}"

                if expected["json_reports_password_rule"] != SKIP:
                    assert has_pw_rule(blob) == expected["json_reports_password_rule"], \
                        f"Expected json_reports_password_rule={expected['json_reports_password_rule']}. blob={blob}"

                # pdf_saved, pdf_bytes_written, password_rule_present are __skip__ for this case.

            else:
                raise ValueError(f"Unknown case: {case}")
