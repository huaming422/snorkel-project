import sys
sys.path.insert(0, "/tests/validate")

import json
import os
import tempfile
from test_harness import MockStatementServer, seed_token, run_cli, combined_output, try_parse_json


def test_statement_list_pdf_fill(inputs, expected):
    start_date = inputs["start_date"]
    limit = inputs["limit"]
    stage_pdf = inputs["stage_pdf"]
    structured_items = json.loads(inputs["structured_json"])

    with tempfile.TemporaryDirectory() as home:
        seed_token(home)
        with MockStatementServer() as mock:
            mock.set_statement_list(structured_items)

            if stage_pdf:
                # Stage the PDF list response. The field names here follow the
                # reference design (items/display_name/key/cache_key). The
                # submitted implementation uses classify_list_item() on the
                # structured list items themselves (file_key ending in .pdf or
                # format field = "pdf") rather than a separate PDF-list endpoint.
                # The staging is harmless whether or not the implementation uses it.
                mock.set_pdf_list({"items": [
                    {"display_name": "2024.03", "key": "*a*202403*stmt-202403.pdf", "cache_key": ""},
                    {"display_name": "2024.05", "key": "*a*202405*stmt-202405.pdf", "cache_key": ""},
                ]})

            proc = run_cli(
                ["statement", "list", "--type", "monthly",
                 "--start-date", start_date, "--limit", str(limit)],
                mock, home, cwd=home
            )
            out = combined_output(proc)

            assert (proc.returncode == 0) == expected["ok"], \
                f"Expected returncode==0 to be {expected['ok']}, got returncode={proc.returncode}. Output: {out}"

            assert ("202403" in out) == expected["period_202403_listed"], \
                f"Expected '202403' in out == {expected['period_202403_listed']}. Output: {out}"

            assert ("202408" in out) == expected["period_202408_listed"], \
                f"Expected '202408' in out == {expected['period_202408_listed']}. Output: {out}"

            assert out.count("pdf") >= expected["min_pdf_rows"], \
                f"Expected at least {expected['min_pdf_rows']} occurrences of 'pdf' in output. Got {out.count('pdf')}. Output: {out}"

            n = mock.count_matching("pdf", "list")
            assert expected["min_pdf_list_calls"] <= n, \
                f"Expected min_pdf_list_calls={expected['min_pdf_list_calls']}, got n={n}"
            assert n <= expected["max_pdf_list_calls"], \
                f"Expected max_pdf_list_calls={expected['max_pdf_list_calls']}, got n={n}"
