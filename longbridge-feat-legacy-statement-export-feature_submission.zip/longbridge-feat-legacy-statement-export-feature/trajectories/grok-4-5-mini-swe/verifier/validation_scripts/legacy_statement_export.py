import sys
sys.path.insert(0, "/tests/validate")

import json
import os
import tempfile
from pathlib import Path
from test_harness import MockStatementServer, seed_token, run_cli, combined_output, try_parse_json

LEGACY_DOC = {
    "Date": "2021.11.30",
    "AssetDetail": {"Cash": "1", "Total": "2"},
    "CashDetails": {
        "Currency": "HKD",
        "CashDetail": [
            {"Currency": "HKD", "Amount": "1"},
            {"Currency": "USD", "Amount": "2"},
        ],
    },
    "StockHoldingDetails": [
        {"Market": "US", "StockHolding": [{"StName": "DAL", "Total": "199"}]},
        {"Market": "HK", "StockHolding": [{"StName": "00175", "Total": "1000"}]},
    ],
    "Empty": None,
    "Nothing": [],
}

SKIP = "__skip__"


def test_legacy_statement_export(inputs, expected):
    case = inputs["case"]
    file_key = inputs["file_key"]

    with tempfile.TemporaryDirectory() as home:
        seed_token(home)
        with MockStatementServer() as mock:
            mock.set_download_body(json.dumps(LEGACY_DOC), content_type="application/json")

            if case == "markdown":
                proc = run_cli(
                    ["statement", "export", "--file-key", file_key],
                    mock, home, cwd=home
                )
                out = combined_output(proc)

                assert (proc.returncode == 0) == expected["ok"], \
                    f"Expected returncode==0 to be {expected['ok']}, got returncode={proc.returncode}. Output: {out}"

                if expected["holdings_has_market_column"] != SKIP:
                    assert ("Market" in out) == expected["holdings_has_market_column"], \
                        f"Expected 'Market' in out == {expected['holdings_has_market_column']}. Output: {out}"

                if expected["holdings_rows_present"] != SKIP:
                    assert expected["holdings_rows_present"] == all(name in out for name in ["DAL", "199", "00175", "1000"]), \
                        f"Expected holdings_rows_present={expected['holdings_rows_present']}. Out: {out}"

                if expected["currency_present"] != SKIP:
                    assert ("HKD" in out) == expected["currency_present"], \
                        f"Expected 'HKD' in out == {expected['currency_present']}. Output: {out}"

                if expected["second_currency_present"] != SKIP:
                    assert ("USD" in out) == expected["second_currency_present"], \
                        f"Expected 'USD' in out == {expected['second_currency_present']}. Output: {out}"

                # json_nonempty, json_has_holdings_data, json_has_currency,
                # min_csv_files, csv_has_holdings_rows, csv_has_currency
                # are all "__skip__" for this case — no assertions needed.

            elif case == "json":
                proc = run_cli(
                    ["--format", "json", "statement", "export", "--file-key", file_key],
                    mock, home, cwd=home
                )
                doc = try_parse_json(proc.stdout) or {}
                blob = json.dumps(doc)

                assert (proc.returncode == 0) == expected["ok"], \
                    f"Expected returncode==0 to be {expected['ok']}, got returncode={proc.returncode}. Output: {combined_output(proc)}"

                if expected["json_nonempty"] != SKIP:
                    assert (doc not in (None, {}, [])) == expected["json_nonempty"], \
                        f"Expected json_nonempty={expected['json_nonempty']}. doc={doc}"

                if expected["json_has_holdings_data"] != SKIP:
                    assert expected["json_has_holdings_data"] == all(tok in blob for tok in ["DAL", "00175", "199", "1000"]), \
                        f"Expected json_has_holdings_data={expected['json_has_holdings_data']}. blob={blob[:500]}"

                if expected["json_has_currency"] != SKIP:
                    assert ("HKD" in blob) == expected["json_has_currency"], \
                        f"Expected 'HKD' in blob == {expected['json_has_currency']}. blob={blob[:500]}"

                # holdings_has_market_column, holdings_rows_present, currency_present,
                # second_currency_present, min_csv_files, csv_has_holdings_rows,
                # csv_has_currency are all "__skip__" for this case.

            elif case == "csv_dir":
                outdir = os.path.join(home, "csvout")
                proc = run_cli(
                    ["statement", "export", "--file-key", file_key, "-o", outdir],
                    mock, home, cwd=home
                )
                out = combined_output(proc)

                csvs = sorted(p.name for p in Path(outdir).glob("*.csv")) if os.path.isdir(outdir) else []
                blob = "".join(Path(outdir).joinpath(n).read_text() for n in csvs) if csvs else ""

                assert (proc.returncode == 0) == expected["ok"], \
                    f"Expected returncode==0 to be {expected['ok']}, got returncode={proc.returncode}. Output: {out}"

                if expected["min_csv_files"] != SKIP:
                    assert len(csvs) >= expected["min_csv_files"], \
                        f"Expected at least {expected['min_csv_files']} CSV files, got {len(csvs)}: {csvs}"

                if expected["csv_has_holdings_rows"] != SKIP:
                    assert expected["csv_has_holdings_rows"] == all(tok in blob for tok in ["DAL", "199", "00175", "1000"]), \
                        f"Expected csv_has_holdings_rows={expected['csv_has_holdings_rows']}. blob={blob[:500]}"

                if expected["csv_has_currency"] != SKIP:
                    assert ("HKD" in blob) == expected["csv_has_currency"], \
                        f"Expected 'HKD' in blob == {expected['csv_has_currency']}. blob={blob[:500]}"

                # holdings_has_market_column, holdings_rows_present, currency_present,
                # second_currency_present, json_nonempty, json_has_holdings_data,
                # json_has_currency are all "__skip__" for this case.

            else:
                raise ValueError(f"Unknown case: {case}")
