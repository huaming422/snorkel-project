import sys
sys.path.insert(0, "/tests/validate")

import json
import os
import tempfile
from pathlib import Path
from test_harness import MockStatementServer, seed_token, run_cli, combined_output, try_parse_json

CURRENT_DOC_BASE = {"Asset": {"Currency": "HKD", "Total": "123"}}
SKIP = "__skip__"


def test_null_sections_and_section_precedence(inputs, expected):
    case = inputs["case"]

    with tempfile.TemporaryDirectory() as home:
        seed_token(home)
        with MockStatementServer() as mock:

            if case == "explicit_section_to_file":
                body = json.dumps(CURRENT_DOC_BASE)
                mock.set_download_body(body, content_type="application/json")

                target = os.path.join(home, "asset.csv")
                proc = run_cli(
                    ["statement", "export", "--file-key", "KEY", "--section", "asset", "-o", target],
                    mock, home, cwd=home
                )
                out = combined_output(proc)

                assert (proc.returncode == 0) == expected["ok"], \
                    f"Expected returncode==0 to be {expected['ok']}, returncode={proc.returncode}. Output: {out}"

                if expected["target_is_file"] != SKIP:
                    assert os.path.isfile(target) == expected["target_is_file"], \
                        f"Expected target_is_file={expected['target_is_file']}, got isfile={os.path.isfile(target)}. Output: {out}"

                if expected["target_is_dir"] != SKIP:
                    assert os.path.isdir(target) == expected["target_is_dir"], \
                        f"Expected target_is_dir={expected['target_is_dir']}, got isdir={os.path.isdir(target)}. Output: {out}"

                if expected["section_written"] != SKIP:
                    if os.path.isfile(target):
                        section_content = Path(target).read_text()
                        section_written = "HKD" in section_content
                    else:
                        section_written = False
                    assert section_written == expected["section_written"], \
                        f"Expected section_written={expected['section_written']}, got {section_written}. Output: {out}"

                # null_type_error_leaked and asset_rendered are __skip__ for this case.

            elif case == "null_sections_export_ok":
                body = json.dumps({
                    "Asset": {"Currency": "HKD"},
                    "Interests": None,
                    "FundTradeSums": None,
                })
                mock.set_download_body(body, content_type="application/json")

                proc = run_cli(
                    ["statement", "export", "--file-key", "KEY"],
                    mock, home, cwd=home
                )
                out = combined_output(proc)

                assert (proc.returncode == 0) == expected["ok"], \
                    f"Expected returncode==0 to be {expected['ok']}, returncode={proc.returncode}. Output: {out}"

                if expected["null_type_error_leaked"] != SKIP:
                    assert ("invalid type: null" in out) == expected["null_type_error_leaked"], \
                        f"Expected null_type_error_leaked={expected['null_type_error_leaked']}. Output: {out}"

                if expected["asset_rendered"] != SKIP:
                    assert ("HKD" in out) == expected["asset_rendered"], \
                        f"Expected asset_rendered={expected['asset_rendered']}. Output: {out}"

                # target_is_file, target_is_dir, section_written are __skip__ for this case.

            else:
                raise ValueError(f"Unknown case: {case}")
