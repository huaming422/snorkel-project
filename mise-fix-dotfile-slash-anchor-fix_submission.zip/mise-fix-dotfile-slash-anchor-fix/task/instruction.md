## Task

hey, when I track a config dir with mise's dotfiles history, my include/exclude
filters get silently ignored if I write the pattern with a leading slash. an
exclude like `/cache` still ends up capturing that dir, and an include like
`/rules/*.md` grabs nothing even though those files are right there. the exact
same patterns without the leading slash work fine. I'd expect a leading slash to
anchor to the tracked dir's root like it does in a `.gitignore`. nothing errors
out, it just quietly does the wrong thing. can you dig in and fix it?
