#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier (set -euo pipefail inherited).
# Rust task: the full workspace dependency closure and test-binary build cache
# were baked at the base commit (image step 7). Grade time is offline; fail fast
# on any cache miss instead of reaching for a dead network.
cd /repo/mise

# Offline switch, set right after cd so a cache miss fails fast rather than
# hanging against a cut network. Baked deps come from the warmed CARGO_HOME /
# CARGO_TARGET_DIR in the image.
export CARGO_NET_OFFLINE=true

# Dependencies: offline-first against the image bake, logged online fallback.
# At the base commit the committed Cargo.lock is consistent for the full
# workspace (verified at authoring: `cargo tree --locked -p mise` resolves), so
# the offline fetch is a no-op cache hit; the fallback only fires if the bake
# was somehow incomplete.
if cargo fetch --locked --offline > /tmp/test-setup-fetch.log 2>&1; then
    echo "[offline-first] cargo deps satisfied from image"
elif cargo fetch --locked >> /tmp/test-setup-fetch.log 2>&1; then
    echo "[test-setup] cargo deps fetched online (image bake was stale)"
else
    tail -40 /tmp/test-setup-fetch.log >&2; exit 1
fi

# No services to start and no data to seed: the dotfiles history subsystem is
# exercised entirely in-process by the injected integration test, which drives
# the compiled `mise` binary against a self-contained temp HOME / MISE_* layout.
# The history git repository is created by `mise dot save` itself; `git` is
# installed in the image (apt block). No assertion logic here.
