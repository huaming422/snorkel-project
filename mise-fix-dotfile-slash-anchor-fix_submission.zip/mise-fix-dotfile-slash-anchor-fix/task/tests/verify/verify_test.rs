//! Behavioral verifier for mise-fix-dotfile-slash-anchor.
//!
//! Drives the compiled `mise` binary (`CARGO_BIN_EXE_mise`) through the stable
//! public `mise dot save` CLI — the only legitimate consumer of the dotfiles
//! history matcher, which lives in `pub(crate)` modules of a binary crate with
//! no lib target. Each test builds an isolated HOME + MISE_* world under a fresh
//! tempdir, writes a `[dotfiles]` entry and a file tree under `~/.codex`, runs
//! `mise dot save`, and asserts on the real history git repo at
//! `$MISE_STATE_DIR/history/repo.git` (captured files land under
//! `home/.codex/<rel>`), exactly as the repo's own e2e/cli/test_dotfiles_*
//! scripts do. No internal symbols are imported.

use std::fs;
use std::path::{Path, PathBuf};
use std::process::Command;

/// An isolated HOME + MISE_* world under a fresh tempdir. The tempdir handle
/// keeps it alive for assertions; every `mise` subcommand runs against it with
/// the same e2e-style non-interactive, offline-trusting env.
struct World {
    _dir: tempfile::TempDir,
    root: PathBuf,
    home: PathBuf,
    config_dir: PathBuf,
    state_dir: PathBuf,
    /// The tracked entry's file tree lives here (`~/.codex`).
    codex: PathBuf,
    path_var: String,
}

/// Build the directory tree for one isolated world.
fn world() -> World {
    let dir = tempfile::tempdir().expect("create tempdir");
    let root = dir.path().to_path_buf();
    let home = root.join("home");
    let config_dir = home.join(".config/mise");
    let state_dir = home.join(".local/state/mise");
    for d in [
        &config_dir,
        &home.join(".local/share/mise"),
        &state_dir,
        &home.join(".cache/mise"),
        &root.join("etc/mise"),
        &root.join("tmp"),
    ] {
        fs::create_dir_all(d).expect("create mise dir");
    }
    let codex = home.join(".codex");
    fs::create_dir_all(&codex).expect("create codex dir");
    let path_var = std::env::var("PATH").unwrap_or_default();
    World {
        _dir: dir,
        root,
        home,
        config_dir,
        state_dir,
        codex,
        path_var,
    }
}

impl World {
    /// The dotfiles history bare git repo.
    fn repo(&self) -> PathBuf {
        self.state_dir.join("history/repo.git")
    }

    /// Run `mise <args>` against this world, mirroring e2e/run_test's isolated,
    /// non-interactive, offline-trusting env.
    fn mise(&self, args: &[&str]) -> std::process::Output {
        Command::new(env!("CARGO_BIN_EXE_mise"))
            .args(args)
            .env_clear()
            .env("PATH", &self.path_var)
            .env("HOME", &self.home)
            .env("MISE_CONFIG_DIR", &self.config_dir)
            .env("MISE_DATA_DIR", self.home.join(".local/share/mise"))
            .env("MISE_STATE_DIR", &self.state_dir)
            .env("MISE_CACHE_DIR", self.home.join(".cache/mise"))
            .env("MISE_SYSTEM_DIR", self.root.join("etc/mise"))
            .env("MISE_TMP_DIR", self.root.join("tmp"))
            .env("MISE_EXPERIMENTAL", "1")
            .env("MISE_YES", "1")
            .env("MISE_HISTORY_NOTIFY", "0")
            .env("MISE_USE_VERSIONS_HOST_TRACK", "0")
            .env("MISE_TRUSTED_CONFIG_PATHS", &self.root)
            .env("GIT_AUTHOR_NAME", "test")
            .env("GIT_AUTHOR_EMAIL", "test@test.com")
            .env("GIT_COMMITTER_NAME", "test")
            .env("GIT_COMMITTER_EMAIL", "test@test.com")
            .output()
            .expect("spawn mise")
    }
}

/// A saved world: the tempdir keeps the isolated HOME alive for assertions, and
/// `repo` points at the dotfiles history bare git repo.
struct Saved {
    _world: World,
    repo: PathBuf,
}

/// Write `config` to `$MISE_CONFIG_DIR/config.toml`, lay out `files`
/// (path relative to `~/.codex` -> contents) under a fresh isolated HOME, run
/// `mise dot save`, assert it exits 0, and return the world for assertions.
fn run_save(config: &str, files: &[(&str, &str)]) -> Saved {
    let world = world();
    for (rel, contents) in files {
        let path = world.codex.join(rel);
        fs::create_dir_all(path.parent().expect("file has parent")).expect("create tree dir");
        fs::write(&path, contents).expect("write tracked file");
    }
    fs::write(world.config_dir.join("config.toml"), config).expect("write config.toml");

    let output = world.mise(&["dot", "save"]);
    assert!(
        output.status.success(),
        "`mise dot save` should exit 0; status={:?}\nstdout={}\nstderr={}",
        output.status,
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr),
    );

    let repo = world.repo();
    Saved {
        _world: world,
        repo,
    }
}

/// True iff `home/.codex/<rel>` exists in the history repo's HEAD tree.
fn captured(repo: &Path, rel: &str) -> bool {
    let spec = format!("HEAD:home/.codex/{rel}");
    Command::new("git")
        .arg(format!("--git-dir={}", repo.display()))
        .args(["cat-file", "-e", &spec])
        .output()
        .expect("spawn git cat-file")
        .status
        .success()
}

/// Run a git plumbing command against `repo`, assert it exits 0, and return its
/// trimmed stdout. Used to read and rewrite the history repo directly, the same
/// way the real history subsystem talks to it.
fn git(repo: &Path, args: &[&str]) -> String {
    let out = Command::new("git")
        .arg(format!("--git-dir={}", repo.display()))
        .args(args)
        .output()
        .unwrap_or_else(|e| panic!("spawn git {args:?}: {e}"));
    assert!(
        out.status.success(),
        "git {args:?} should exit 0; status={:?}\nstdout={}\nstderr={}",
        out.status,
        String::from_utf8_lossy(&out.stdout),
        String::from_utf8_lossy(&out.stderr),
    );
    String::from_utf8_lossy(&out.stdout).trim().to_string()
}

/// Rewrite the single-commit history so its recorded matcher version reads as
/// `older` instead of whatever wrote it, as if an older client had saved the
/// checkpoint. The matcher a checkpoint was read with travels as a commit-message
/// trailer line (`Mise-History-Matcher: <n>`); re-commit the identical tree with
/// that line forced to `older`, repoint the branch, and drop the local index so
/// the next history command rebuilds its record straight from git. No internal
/// symbols are touched — only the repo's own on-disk format.
fn rewrite_matcher_version(world: &World, older: u32) {
    let repo = world.repo();
    let tree = git(&repo, &["rev-parse", "HEAD^{tree}"]);
    let body = git(&repo, &["log", "--format=%B", "-1"]);
    let mut rewritten = String::new();
    let mut replaced = false;
    for line in body.lines() {
        if let Some(_n) = line.strip_prefix("Mise-History-Matcher: ") {
            rewritten.push_str(&format!("Mise-History-Matcher: {older}"));
            replaced = true;
        } else {
            rewritten.push_str(line);
        }
        rewritten.push('\n');
    }
    assert!(
        replaced,
        "checkpoint commit should carry a `Mise-History-Matcher:` trailer to rewrite; \
         message was:\n{body}"
    );
    // commit-tree reads the message on stdin; the saved history is a single root
    // commit, so there is no parent to carry.
    let new_commit = {
        let mut child = Command::new("git")
            .arg(format!("--git-dir={}", repo.display()))
            .args(["commit-tree", &tree])
            .stdin(std::process::Stdio::piped())
            .stdout(std::process::Stdio::piped())
            .env("GIT_AUTHOR_NAME", "test")
            .env("GIT_AUTHOR_EMAIL", "test@test.com")
            .env("GIT_COMMITTER_NAME", "test")
            .env("GIT_COMMITTER_EMAIL", "test@test.com")
            .spawn()
            .expect("spawn git commit-tree");
        use std::io::Write;
        child
            .stdin
            .take()
            .expect("commit-tree stdin")
            .write_all(rewritten.as_bytes())
            .expect("write commit message");
        let out = child.wait_with_output().expect("wait git commit-tree");
        assert!(out.status.success(), "git commit-tree should exit 0");
        String::from_utf8_lossy(&out.stdout).trim().to_string()
    };
    let head_ref = git(&repo, &["symbolic-ref", "HEAD"]);
    git(&repo, &["update-ref", &head_ref, &new_commit]);
    // Force the history index to be rebuilt from the rewritten git state on the
    // next command, rather than trusting the record cached under the old commit.
    let _ = fs::remove_dir_all(world.state_dir.join("history/index"));
    assert_eq!(
        git(&repo, &["log", "--format=%B", "-1"])
            .lines()
            .find_map(|l| l.strip_prefix("Mise-History-Matcher: "))
            .map(str::to_string),
        Some(older.to_string()),
        "trailer rewrite should have taken effect"
    );
}

/// crit_exclude_root (fail_to_pass): a leading-slash exclude anchors to the
/// entry root — `/cache` keeps a top-level `cache/` out of history but leaves a
/// nested `app/cache/` captured. Pre-fix the rooted pattern matches nothing, so
/// the top-level cache is wrongly captured.
#[test]
fn exclude_leading_slash_anchors_to_root() {
    let saved = run_save(
        "[dotfiles]\n\"~/.codex\" = { mode = \"track\", exclude = [\"/cache\"] }\n",
        &[
            ("config.toml", "model = \"x\"\n"),
            ("cache/x", "top-level cache\n"),
            ("app/cache/y", "nested cache\n"),
        ],
    );
    assert!(
        captured(&saved.repo, "config.toml"),
        "config.toml should be captured (sanity: a save happened)"
    );
    assert!(
        !captured(&saved.repo, "cache/x"),
        "top-level cache/ must be excluded by the rooted `/cache` pattern"
    );
    assert!(
        captured(&saved.repo, "app/cache/y"),
        "a nested app/cache/ must NOT be excluded by the rooted `/cache` pattern"
    );
}

/// crit_include_root (fail_to_pass): a leading-slash include selects files —
/// `/rules/*.md` captures the markdown directly under `rules/`, selecting
/// exactly what `rules/*.md` would. Pre-fix the rooted include matches nothing,
/// so nothing is captured.
#[test]
fn include_leading_slash_selects() {
    let saved = run_save(
        "[dotfiles]\n\"~/.codex\" = { mode = \"track\", include = [\"/rules/*.md\"] }\n",
        &[
            ("rules/one.md", "always test\n"),
            ("telemetry.json", "noise\n"),
        ],
    );
    assert!(
        captured(&saved.repo, "rules/one.md"),
        "rules/one.md must be selected by the rooted `/rules/*.md` include"
    );
    assert!(
        !captured(&saved.repo, "telemetry.json"),
        "a file the include list does not name must not be captured"
    );
}

/// crit_pruner_agrees (fail_to_pass): the directory-walk pruner must agree with
/// selection for a rooted include that reaches into a subtree — `/rules/**`
/// captures a nested `rules/deep/two.md`. A fix that patches the matcher but not
/// the pruner prunes the subtree and fails this.
#[test]
fn rooted_include_reaches_into_subdir() {
    let saved = run_save(
        "[dotfiles]\n\"~/.codex\" = { mode = \"track\", include = [\"/rules/**\"] }\n",
        &[
            ("rules/one.md", "top rule\n"),
            ("rules/deep/two.md", "nested rule\n"),
        ],
    );
    assert!(
        captured(&saved.repo, "rules/one.md"),
        "rules/one.md must be selected by `/rules/**`"
    );
    assert!(
        captured(&saved.repo, "rules/deep/two.md"),
        "a nested file under a rooted `/rules/**` include must be captured \
         (the walk pruner must descend into the subtree)"
    );
}

/// crit_star_stops_at_slash (fail_to_pass): `*` does not cross `/` in a rooted
/// pattern — `/rules/*.md` selects `rules/one.md` but NOT `rules/deep/two.md`
/// (gitignore semantics), rather than the deprecated `*`-crosses-`/` behavior.
#[test]
fn rooted_star_stops_at_slash() {
    let saved = run_save(
        "[dotfiles]\n\"~/.codex\" = { mode = \"track\", include = [\"/rules/*.md\"] }\n",
        &[
            ("rules/one.md", "top rule\n"),
            ("rules/deep/two.md", "nested rule\n"),
        ],
    );
    assert!(
        captured(&saved.repo, "rules/one.md"),
        "rules/one.md must be selected by `/rules/*.md`"
    );
    assert!(
        !captured(&saved.repo, "rules/deep/two.md"),
        "`*` must stop at `/`: `/rules/*.md` must not reach into rules/deep/"
    );
}

/// crit_bare_slash_and_unrooted (pass_to_pass): unrooted patterns keep matching
/// at any depth (`cache` without a slash still drops `app/cache`), and a bare
/// `/` names the entry itself and matches nothing (no crash, no over-prune).
/// Both hold identically before and after the fix.
#[test]
fn unrooted_and_bare_slash_unchanged() {
    // Unrooted `cache` still matches at any depth: both the top-level and the
    // nested cache dirs are dropped.
    let unrooted = run_save(
        "[dotfiles]\n\"~/.codex\" = { mode = \"track\", exclude = [\"cache\"] }\n",
        &[
            ("config.toml", "model = \"x\"\n"),
            ("cache/x", "top-level cache\n"),
            ("app/cache/y", "nested cache\n"),
        ],
    );
    assert!(
        captured(&unrooted.repo, "config.toml"),
        "config.toml should be captured (sanity: a save happened)"
    );
    assert!(
        !captured(&unrooted.repo, "cache/x"),
        "unrooted `cache` must still drop a top-level cache/"
    );
    assert!(
        !captured(&unrooted.repo, "app/cache/y"),
        "unrooted `cache` must still drop a nested app/cache/ at any depth"
    );

    // A bare `/` names the entry itself and matches nothing: it excludes
    // nothing, so everything is captured, and the save does not crash.
    let bare = run_save(
        "[dotfiles]\n\"~/.codex\" = { mode = \"track\", exclude = [\"/\"] }\n",
        &[
            ("config.toml", "model = \"x\"\n"),
            ("cache/x", "top-level cache\n"),
        ],
    );
    assert!(
        captured(&bare.repo, "config.toml"),
        "a bare `/` exclude matches nothing, so config.toml is captured"
    );
    assert!(
        captured(&bare.repo, "cache/x"),
        "a bare `/` exclude matches nothing, so cache/x is captured"
    );
}

/// True iff `path` exists on disk (a plain file).
fn exists(path: &Path) -> bool {
    path.is_file()
}

/// crit_replay_rooted_include_rollback_safe (fail_to_pass): once a rooted
/// include selects files, a rollback onto an OLDER checkpoint — written when the
/// same rooted pattern selected nothing — must not delete the now-selected live
/// files. The older matcher never captured them, so they are not "covered but
/// absent"; replay has to distrust that checkpoint and leave them alone.
///
/// This exercises the senior rollback-safety nuance end to end through the CLI:
///   1. a rooted `include` captures a file now (fails on an unfixed matcher that
///      reads a leading slash as matching nothing — the nop baseline);
///   2. the checkpoint is made to read as an older-matcher one (its own
///      on-disk `Mise-History-Matcher` trailer is rewritten down a version),
///      standing in for a checkpoint an older mise actually wrote, which no
///      single run can mint on its own;
///   3. a file the rooted include now selects, but the old checkpoint never
///      held, appears live;
///   4. `mise dot rollback --to latest --all` must LEAVE that live file in
///      place. A fix that anchors the matcher/pruner but never bumps the matcher
///      version or distrusts the older checkpoint for a rooted include treats
///      the file as covered-but-absent and DELETES it — this asserts it does
///      not.
#[test]
fn rooted_include_legacy_rollback_preserves_live_file() {
    let world = world();
    // config.toml is present at save; rules/one.md is not yet.
    fs::write(world.codex.join("config.toml"), "model = \"x\"\n").expect("write config.toml");
    fs::write(
        world.config_dir.join("config.toml"),
        "[dotfiles]\n\"~/.codex\" = { mode = \"track\", include = [\"/config.toml\", \"/rules/*.md\"] }\n",
    )
    .expect("write mise config");

    let save = world.mise(&["dot", "save"]);
    assert!(
        save.status.success(),
        "`mise dot save` should exit 0; stdout={}\nstderr={}",
        String::from_utf8_lossy(&save.stdout),
        String::from_utf8_lossy(&save.stderr),
    );

    // (1) baseline gate: the rooted include must actually capture config.toml.
    // An unfixed matcher reads `/config.toml` as matching nothing, captures an
    // empty checkpoint, and fails right here.
    let repo = world.repo();
    assert!(
        captured(&repo, "config.toml"),
        "a rooted `/config.toml` include must capture config.toml \
         (an unfixed leading-slash matcher captures nothing)"
    );

    // (2) make the saved checkpoint read as one an older matcher wrote.
    rewrite_matcher_version(&world, 1);

    // (3) a file the rooted include now selects, that the old checkpoint never
    // captured, appears live on disk.
    let rules = world.codex.join("rules");
    fs::create_dir_all(&rules).expect("create rules dir");
    let live = rules.join("one.md");
    fs::write(&live, "live rule the old checkpoint never held\n").expect("write live file");

    // (4) roll the entry back onto that older checkpoint. The live file must
    // survive: the old checkpoint never covered it, so replay cannot call it
    // absent and delete it.
    let roll = world.mise(&["dot", "rollback", "--to", "latest", "--all", "--yes"]);
    assert!(
        roll.status.success(),
        "`mise dot rollback` should exit 0; stdout={}\nstderr={}",
        String::from_utf8_lossy(&roll.stdout),
        String::from_utf8_lossy(&roll.stderr),
    );
    assert!(
        exists(&live),
        "rolling back onto an older-matcher checkpoint whose entry has a rooted \
         include must NOT delete a live file that checkpoint never captured \
         (replay must distrust it); rollback output:\nstdout={}\nstderr={}",
        String::from_utf8_lossy(&roll.stdout),
        String::from_utf8_lossy(&roll.stderr),
    );
}
