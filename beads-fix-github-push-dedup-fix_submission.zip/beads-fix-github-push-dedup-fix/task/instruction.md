## Task

our github sync keeps draining the shared API rate limit on routine syncs, and i think something's wrong. if i run a push-only sync and then immediately run it again without touching anything locally, the second run still fires a write for every single issue, so a no-op re-sync ends up costing as much as a full push. an unchanged re-sync should be basically free, a handful of calls at most. can you dig into why repeated pushes keep re-sending every issue and make an unchanged sync cheap?
