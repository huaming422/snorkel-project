"""Behavioural tests for the HTTP-bridge cooldown session-lifecycle fix.

The defect: the bridge opens or selects an upstream WebSocket session BEFORE
the hard-key retry circuit decides admission. A request the cooldown turns away
returns its rejection but leaves a never-dispatched socket in the reuse pool;
the next half-open probe picks that dead socket back up and strikes the circuit
again, so the rejection storm never settles. A second, subtler requirement: the
cooldown is allowed to let exactly one probe through, and that admitted probe is
invisible between the moment it passes the admission gate and the moment it
registers at dispatch. A sibling request suppressed in that same window must not
tear the shared session out from under the admitted probe (which would surface
as a 502 "is retiring").

The correct behaviour, stated at the bridge's own stable interfaces:

  * A cooldown-suppressed request on a session no other turn owns leaves that
    session retired (``upstream_control.retire_after_drain`` set) and no longer
    offered for reuse, with the socket closed through the bounded drain path.
  * A cooldown-suppressed request on a session another turn owns — a registered
    admission waiter, or a concurrently-admitted probe still short of its
    dispatch registration — leaves the session untouched and the admitted probe
    reaches dispatch instead of being fenced off.
  * Both pre-dispatch suppression sites behave this way: the late submit
    suppression and the startup-continuity cooldown terminal path.

These tests drive and observe ONLY pre-existing, stable symbols that no
reasonable fix renames:

  * drive: ``ProxyService._submit_http_bridge_request`` /
    ``_submit_http_bridge_request_with_handoff`` and
    ``_stream_http_bridge_session_events``;
  * observe: ``session.upstream_control.retire_after_drain`` /
    ``reconnect_requested`` / ``upstream_close_attempted``,
    ``_http_bridge_session_reusable_for_request``, and the
    ``_retire_http_bridge_after_drain_if_ready`` /
    ``_close_http_bridge_session_bounded`` drain boundary;
  * suppress: the hard-key retry circuit, driven into cooldown through its own
    public state (``_http_bridge_retry_circuits`` +
    ``_HTTPBridgeRetryCircuitState``), exactly as the repo's own bridge suite
    does.

No assertion depends on HOW a fix marks ownership of the in-flight admitted
turn (a flag, a counter, a set of request ids) — only on the observable
outcome. The concurrency test registers a real admitted probe through the
actual submit path, so it rejects an over-aggressive fix that retires the
shared session unconditionally without presupposing any particular bookkeeping.

Fixtures and factories are self-contained because the repo's test conftest is
not in scope when this file is collected from /tests/verify/; they mirror the
repo's ``tests/unit/test_proxy_http_bridge.py`` helpers (``_make_bridge_session``,
the request-state construction, and the two autouse stubs) so any correct fix
passes regardless of how it organises the change.
"""

from __future__ import annotations

import asyncio
import os
import re
import subprocess
import sys
import time
from collections import deque
from contextlib import nullcontext
from types import SimpleNamespace
from typing import Any, cast

import anyio
import pytest

from app.core.clients.proxy import ProxyResponseError
from app.core.clients.proxy_websocket import UpstreamWebSocket
from app.core.errors import HTTP_BRIDGE_EVENTLESS_TIMEOUT_CODE
from app.core.utils.request_id import reset_request_scope_id, set_request_scope_id
from app.db.models import AccountStatus
from app.modules.proxy import service as proxy_service
from app.modules.proxy._service.http_bridge import helpers as http_bridge_helpers_module
from app.modules.proxy._service.http_bridge import retry_circuit as http_bridge_retry_circuit_module
from app.modules.proxy._service.http_bridge import streaming as http_bridge_streaming_module
from unittest.mock import AsyncMock

# Where the project environment lives at grade time (see tests/test-setup.sh).
REPO_DIR = os.environ.get("REPO_DIR", "/repo/codex-lb")

# The pre-existing bridge unit suite that the regression guard replays.
BRIDGE_SUITE = "tests/unit/test_proxy_http_bridge.py"

# The regression guard replays the slice of that module that exercises the
# behaviour this change actually touches — the session submit/dispatch lifecycle,
# idle-lease handling, and the retire/drain/close machinery — and asserts it is
# unchanged. It is a keyword selection rather than a whole-module replay for a
# concrete reason: a sizeable part of this module is not hermetic when the file
# is collected on its own. Several tests in the file-account affinity and
# dead-owner-recovery area call persistence helpers without requesting any
# schema-provisioning fixture, so they only succeed when an earlier-ordered
# sibling has already materialised the relational schema on the shared
# session-scoped engine; collected in isolation they fail with a missing-table
# error on the UNCHANGED base tree (reproduced deterministically). A second
# cluster — the poison/quarantine cooldown-TTL tests — pins behaviour against the
# live wall clock and is timing-sensitive under load. None of those areas is in
# the path this change edits, so holding the fix to their isolated-replay outcome
# would reject correct work for reasons unrelated to it. The keyword filter keeps
# every test on the changed path (submit, dispatch, retire, drain, idle, lease,
# reuse/reusable, detach, admission, precreated, handoff, cooldown) and drops the
# non-hermetic clusters; it selects the same stable set on both the base tree and
# the fixed tree, so a real behaviour change on the touched path still fails it.
REGRESSION_KEEP_KEYWORDS = (
    "submit or dispatch or retire or drain or idle or reusable or reuse "
    "or detach or lease or admission or precreated or handoff or cooldown"
)
REGRESSION_DROP_KEYWORDS = (
    "file_pin or file_affinity or file_account or owner_misses or stale_cached "
    "or anchor_planning or quarantine or poison or dead_owner or _ttl or recovery"
)
REGRESSION_K_EXPR = f"({REGRESSION_KEEP_KEYWORDS}) and not ({REGRESSION_DROP_KEYWORDS})"

# How long the retire/close drain path may run before we treat it as hung.
_SUITE_TIMEOUT_SEC = 420


# --------------------------------------------------------------------------- #
# Autouse stubs — mirror the repo bridge suite's module-level autouse fixtures
# so these tests are independent of the dashboard settings cache and the
# durable recovery-attempt schema.
# --------------------------------------------------------------------------- #
@pytest.fixture(autouse=True)
def _share_proxy_dashboard_settings(monkeypatch: pytest.MonkeyPatch) -> None:
    class _SettingsCache:
        async def get(self) -> object:
            return proxy_service.get_settings()

    monkeypatch.setattr(proxy_service, "get_settings_cache", lambda: _SettingsCache())


@pytest.fixture(autouse=True)
def _stub_recovery_attempt_lookup(monkeypatch: pytest.MonkeyPatch) -> None:
    from app.modules.proxy.durable_bridge_coordinator import DurableBridgeSessionCoordinator

    monkeypatch.setattr(
        DurableBridgeSessionCoordinator,
        "lookup_recovery_attempt",
        AsyncMock(return_value=None),
    )


# --------------------------------------------------------------------------- #
# Factories — self-contained copies of the repo bridge suite helpers.
# --------------------------------------------------------------------------- #
def _make_app_settings(**overrides: Any) -> Any:
    from app.core.config.settings import Settings

    return Settings(http_responses_session_bridge_enabled=True, **overrides)


def _make_bridge_session(*, key_value: str = "bridge-test") -> Any:
    session_key = proxy_service._HTTPBridgeSessionKey("session_header", key_value, None)
    return proxy_service._HTTPBridgeSession(
        key=session_key,
        headers={"x-codex-session-id": key_value},
        affinity=proxy_service._AffinityPolicy(
            key=key_value,
            kind=proxy_service.StickySessionKind.CODEX_SESSION,
        ),
        request_model="gpt-5.2",
        account=cast(
            Any,
            SimpleNamespace(
                id="acc-bridge",
                chatgpt_account_id="workspace-bridge",
                status=AccountStatus.ACTIVE,
                plan_type="plus",
            ),
        ),
        upstream=cast(UpstreamWebSocket, SimpleNamespace(close=AsyncMock())),
        upstream_control=proxy_service._WebSocketUpstreamControl(),
        pending_requests=deque(),
        pending_lock=anyio.Lock(),
        response_create_gate=asyncio.Semaphore(1),
        queued_request_count=0,
        last_used_at=1.0,
        idle_ttl_seconds=120.0,
    )


def _arm_cooldown(service: Any, session: Any, *, cooldown_until_offset: float = 60.0) -> None:
    """Drive the hard-key retry circuit into cooldown for this session's key.

    Uses the circuit's own public state object, exactly as the repo bridge
    suite does. A positive offset leaves the cooldown active; a negative offset
    makes it already expired (so the first admission claims the half-open
    probe) for the concurrency scenario.
    """
    now = time.monotonic()
    cast(Any, service)._http_bridge_retry_circuits[session.key] = (
        http_bridge_retry_circuit_module._HTTPBridgeRetryCircuitState(
            consecutive_failures=2,
            cooldown_until=now + cooldown_until_offset,
            last_detail="stream_idle_timeout",
            last_touched_monotonic=now,
        )
    )
    service._durable_bridge = SimpleNamespace(lookup_retry_circuit=AsyncMock(return_value=None))


def _make_submit_request_state(request_id: str) -> Any:
    return proxy_service._WebSocketRequestState(
        request_id=request_id,
        model="gpt-5.6-luna",
        service_tier=None,
        reasoning_effort=None,
        api_key_reservation=None,
        started_at=time.monotonic(),
        transport="http",
        awaiting_response_created=True,
        request_text='{"type":"response.create","input":"hello"}',
    )


def _make_startup_request_state(request_id: str, session_id: str) -> Any:
    return proxy_service._WebSocketRequestState(
        request_id=request_id,
        model="gpt-5.6",
        service_tier=None,
        reasoning_effort=None,
        api_key_reservation=None,
        started_at=time.monotonic(),
        event_queue=asyncio.Queue(),
        transport="http",
        session_id=session_id,
        hard_continuity_anchor=True,
    )


def _reusable(session: Any) -> bool:
    return http_bridge_helpers_module._http_bridge_session_reusable_for_request(
        session=session,
        key=session.key,
        incoming_turn_state=None,
        previous_response_id=None,
    )


# --------------------------------------------------------------------------- #
# Late submit suppression on an unowned session -> session retired, not reusable.
# --------------------------------------------------------------------------- #
@pytest.mark.asyncio
async def test_submit_cooldown_suppression_retires_unowned_session() -> None:
    service = proxy_service.ProxyService(cast(Any, nullcontext()))
    session = _make_bridge_session(key_value="bridge-submit-cooldown-retires")
    _arm_cooldown(service, session)
    # Stub only the bounded-close leaf so the real ownership gate runs end to
    # end; this test asserts the retirement DECISION (the session is flagged
    # and no longer reusable), independent of how any fix structures the drain.
    close_bounded = AsyncMock()
    service._close_http_bridge_session_bounded = close_bounded
    request_state = _make_submit_request_state("req-submit-cooldown-retires")

    with pytest.raises(ProxyResponseError) as exc_info:
        await service._submit_http_bridge_request_with_handoff(
            session,
            request_state=request_state,
            text_data=request_state.request_text or "",
            queue_limit=8,
            request_scope_id="scope-submit-cooldown-retires",
            owned_unanchored_handoff=False,
        )

    # The rejection contract itself is unchanged.
    assert exc_info.value.status_code == 503
    assert exc_info.value.payload["error"]["code"] == "upstream_request_timeout"
    # The never-dispatched session is flagged for retirement by the real
    # ownership gate, so the next request cannot pick its socket back up.
    assert session.upstream_control.reconnect_requested is True
    assert session.upstream_control.retire_after_drain is True
    assert _reusable(session) is False


@pytest.mark.asyncio
async def test_submit_cooldown_suppression_closes_idle_undispatched_socket() -> None:
    # With nothing stubbed on the drain path, the real retirement must run end
    # to end: the socket is closed through the bounded close instead of being
    # left in the reuse pool.
    service = proxy_service.ProxyService(cast(Any, nullcontext()))
    session = _make_bridge_session(key_value="bridge-submit-cooldown-closes-idle")
    _arm_cooldown(service, session)
    close_bounded = AsyncMock()
    service._close_http_bridge_session_bounded = close_bounded
    request_state = _make_submit_request_state("req-submit-cooldown-closes-idle")

    with pytest.raises(ProxyResponseError) as exc_info:
        await service._submit_http_bridge_request_with_handoff(
            session,
            request_state=request_state,
            text_data=request_state.request_text or "",
            queue_limit=8,
            request_scope_id="scope-submit-cooldown-closes-idle",
            owned_unanchored_handoff=False,
        )

    assert exc_info.value.status_code == 503
    assert exc_info.value.payload["error"]["code"] == "upstream_request_timeout"
    assert session.upstream_close_attempted is True
    assert session.queued_request_count == 0
    assert len(session.pending_requests) == 0
    close_bounded.assert_awaited_once_with(session, reason="retire_after_drain")


# --------------------------------------------------------------------------- #
# Suppression must spare a session another turn owns.
# --------------------------------------------------------------------------- #
@pytest.mark.asyncio
async def test_submit_cooldown_suppression_spares_session_with_registered_waiter() -> None:
    # A registered admission waiter (the pre-existing ownership signal every
    # drain path already honours) means another turn owns the session; a
    # suppressed sibling must not retire or close it.
    service = proxy_service.ProxyService(cast(Any, nullcontext()))
    session = _make_bridge_session(key_value="bridge-cooldown-foreign-waiter")
    _arm_cooldown(service, session)
    close_bounded = AsyncMock()
    service._close_http_bridge_session_bounded = close_bounded
    session.admission_waiter_count = 1
    request_state = _make_submit_request_state("req-cooldown-foreign-waiter")

    token = set_request_scope_id("scope-cooldown-foreign-waiter")
    try:
        with pytest.raises(ProxyResponseError) as exc_info:
            await service._submit_http_bridge_request(
                session,
                request_state=request_state,
                text_data=request_state.request_text or "",
                queue_limit=8,
            )
    finally:
        reset_request_scope_id(token)

    assert exc_info.value.status_code == 503
    assert exc_info.value.payload["error"]["code"] == "upstream_request_timeout"
    assert session.upstream_control.reconnect_requested is False
    assert session.upstream_control.retire_after_drain is False
    assert _reusable(session) is True
    close_bounded.assert_not_awaited()
    # The owning turn's registration is left intact; the suppressed sibling
    # only ever accounts for its own.
    assert session.admission_waiter_count == 1


@pytest.mark.asyncio
async def test_submit_cooldown_suppression_spares_concurrently_admitted_probe(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # Two submits race on one shared session at cooldown expiry. Probe A claims
    # the half-open lease inside the admission gate and parks there; sibling B
    # then runs to completion, is suppressed by A's lease, and must NOT retire
    # the shared session — A owns it from before its dispatch registration, so A
    # must still reach dispatch instead of being fenced off with "is retiring".
    #
    # This asserts the observable outcome only; it never presupposes how a fix
    # marks A's ownership. An over-aggressive fix that retires unconditionally
    # fails here because A would be torn off its own session.
    service = proxy_service.ProxyService(cast(Any, nullcontext()))
    session = _make_bridge_session(key_value="bridge-cooldown-probe-race")
    _arm_cooldown(service, session, cooldown_until_offset=-1.0)
    close_bounded = AsyncMock()
    service._close_http_bridge_session_bounded = close_bounded

    real_gate = service._http_bridge_precreated_retry_allowed
    probe_in_gate = asyncio.Event()
    suppressed_done = asyncio.Event()
    gate_calls = 0
    probe_claimed_leases: list[float] = []

    async def gate(target: Any, **kwargs: Any) -> bool:
        nonlocal gate_calls
        gate_calls += 1
        allowed = await real_gate(target, **kwargs)
        if gate_calls == 1:
            # Probe A: lease claimed, decision made, still inside the gate.
            probe_claimed_leases.extend(kwargs.get("claimed_lease_out") or [])
            probe_in_gate.set()
            await suppressed_done.wait()
        return allowed

    monkeypatch.setattr(service, "_http_bridge_precreated_retry_allowed", gate)
    monkeypatch.setattr(service, "_http_bridge_fair_share_threshold_pct", AsyncMock(return_value=0))
    # Reaching this pre-existing dispatch-registration step proves the admitted
    # probe was never fenced off its own session.
    monkeypatch.setattr(
        service,
        "_ensure_http_bridge_session_stream_lease_locked",
        AsyncMock(side_effect=RuntimeError("probe reached dispatch registration")),
    )
    probe_state = _make_submit_request_state("req-cooldown-probe")
    suppressed_state = _make_submit_request_state("req-cooldown-suppressed")

    async def run_probe() -> None:
        token = set_request_scope_id("scope-cooldown-probe")
        try:
            await service._submit_http_bridge_request(
                session,
                request_state=probe_state,
                text_data=probe_state.request_text or "",
                queue_limit=8,
            )
        finally:
            reset_request_scope_id(token)

    async def run_suppressed() -> None:
        await probe_in_gate.wait()
        token = set_request_scope_id("scope-cooldown-suppressed")
        try:
            await service._submit_http_bridge_request(
                session,
                request_state=suppressed_state,
                text_data=suppressed_state.request_text or "",
                queue_limit=8,
            )
        finally:
            reset_request_scope_id(token)
            suppressed_done.set()

    probe_result, suppressed_result = await asyncio.gather(
        run_probe(), run_suppressed(), return_exceptions=True
    )

    # The sibling was turned away by the cooldown...
    assert isinstance(suppressed_result, ProxyResponseError)
    assert suppressed_result.status_code == 503
    assert suppressed_result.payload["error"]["code"] == "upstream_request_timeout"
    # ...and the admitted probe still reached dispatch on its own session.
    assert isinstance(probe_result, RuntimeError)
    assert str(probe_result) == "probe reached dispatch registration"
    assert len(probe_claimed_leases) == 1
    # The shared session was never retired, closed, or made unreusable by the
    # suppressed sibling.
    assert session.upstream_control.reconnect_requested is False
    assert session.upstream_control.retire_after_drain is False
    assert session.upstream_close_attempted is False
    close_bounded.assert_not_awaited()
    assert _reusable(session) is True


# --------------------------------------------------------------------------- #
# The startup-continuity cooldown terminal path behaves the same way.
# --------------------------------------------------------------------------- #
@pytest.mark.asyncio
async def test_startup_cooldown_terminal_retires_unowned_session(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    service = proxy_service.ProxyService(cast(Any, nullcontext()))
    session = _make_bridge_session(key_value="sid-startup-cooldown-retires")
    request_state = _make_startup_request_state(
        "req-startup-cooldown-retires", "turn-state-startup-retires"
    )
    submit = AsyncMock()
    # Stub only the bounded-close leaf; the real ownership gate runs, so this
    # asserts the retirement decision rather than a particular drain wiring.
    close_bounded = AsyncMock()
    monkeypatch.setattr(
        proxy_service,
        "get_settings",
        lambda: _make_app_settings(
            http_responses_session_bridge_ambiguous_continuation_recovery_mode="server_anchored_replay_once",
        ),
    )
    monkeypatch.setattr(
        service, "_http_bridge_precreated_retry_cooldown_seconds", AsyncMock(return_value=30.0)
    )
    monkeypatch.setattr(service, "_submit_http_bridge_request", submit)
    monkeypatch.setattr(service, "_close_http_bridge_session_bounded", close_bounded)
    monkeypatch.setattr(http_bridge_streaming_module.asyncio, "sleep", AsyncMock())

    with pytest.raises(ProxyResponseError) as exc_info:
        async for _ in service._stream_http_bridge_session_events(
            session,
            request_state=request_state,
            text_data='{"type":"response.create"}',
            queue_limit=8,
            propagate_http_errors=True,
            downstream_turn_state="turn-state-startup-retires",
        ):
            pass

    assert exc_info.value.status_code == 503
    assert exc_info.value.payload["error"]["code"] == HTTP_BRIDGE_EVENTLESS_TIMEOUT_CODE
    submit.assert_not_awaited()
    # A session opened on the startup-continuity path is not left reusable.
    assert session.upstream_control.reconnect_requested is True
    assert session.upstream_control.retire_after_drain is True
    close_bounded.assert_awaited_once_with(session, reason="retire_after_drain")
    assert _reusable(session) is False


@pytest.mark.asyncio
async def test_startup_cooldown_terminal_spares_session_with_registered_waiter(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    service = proxy_service.ProxyService(cast(Any, nullcontext()))
    session = _make_bridge_session(key_value="sid-startup-cooldown-owned")
    session.admission_waiter_count = 1
    request_state = _make_startup_request_state(
        "req-startup-cooldown-owned", "turn-state-startup-owned"
    )
    submit = AsyncMock()
    close_bounded = AsyncMock()
    monkeypatch.setattr(
        proxy_service,
        "get_settings",
        lambda: _make_app_settings(
            http_responses_session_bridge_ambiguous_continuation_recovery_mode="server_anchored_replay_once",
        ),
    )
    monkeypatch.setattr(
        service, "_http_bridge_precreated_retry_cooldown_seconds", AsyncMock(return_value=30.0)
    )
    monkeypatch.setattr(service, "_submit_http_bridge_request", submit)
    monkeypatch.setattr(service, "_close_http_bridge_session_bounded", close_bounded)
    monkeypatch.setattr(http_bridge_streaming_module.asyncio, "sleep", AsyncMock())

    with pytest.raises(ProxyResponseError) as exc_info:
        async for _ in service._stream_http_bridge_session_events(
            session,
            request_state=request_state,
            text_data='{"type":"response.create"}',
            queue_limit=8,
            propagate_http_errors=True,
            downstream_turn_state="turn-state-startup-owned",
        ):
            pass

    assert exc_info.value.status_code == 503
    assert exc_info.value.payload["error"]["code"] == HTTP_BRIDGE_EVENTLESS_TIMEOUT_CODE
    submit.assert_not_awaited()
    # The owned session is left alone for its owner's lifecycle to govern: not
    # flagged for retirement and its socket not closed.
    assert session.upstream_control.reconnect_requested is False
    assert session.upstream_control.retire_after_drain is False
    close_bounded.assert_not_awaited()
    assert session.admission_waiter_count == 1


# --------------------------------------------------------------------------- #
# Regression guard: the pre-existing HTTP bridge unit suite still passes.
# --------------------------------------------------------------------------- #
def test_existing_http_bridge_unit_suite_still_passes() -> None:
    """Replay the changed-path slice of the bridge unit suite; nothing regressed.

    Normal submit/dispatch, idle-lease, and drain-retirement semantics must be
    unchanged. Runs in the project environment via a subprocess so the suite
    collects its own conftest and fixtures. The keyword filter (see
    REGRESSION_K_EXPR) restricts the replay to the behaviour this change touches
    and excludes the module's non-hermetic clusters.
    """
    cmd = [
        sys.executable,
        "-m",
        "pytest",
        BRIDGE_SUITE,
        "-k",
        REGRESSION_K_EXPR,
        "-p",
        "no:cacheprovider",
        "-q",
        "--no-header",
        "-o",
        "addopts=",
    ]
    proc = subprocess.run(
        cmd,
        cwd=REPO_DIR,
        capture_output=True,
        text=True,
        timeout=_SUITE_TIMEOUT_SEC,
    )

    assert proc.returncode == 0, (
        "The changed-path slice of the HTTP bridge unit suite regressed.\n"
        f"command: {' '.join(cmd)}\n"
        f"exit code: {proc.returncode}\n"
        f"--- stdout (tail) ---\n{proc.stdout[-4000:]}\n"
        f"--- stderr (tail) ---\n{proc.stderr[-2000:]}"
    )

    # Guard against a vacuous pass: the filter must keep a substantial slice of
    # the changed-path tests, not silently collapse to zero (e.g. if an upstream
    # rename ever stops the keywords from matching). The base tree selects well
    # over a hundred tests here; require a conservative floor.
    passed_match = re.search(r"(\d+) passed", proc.stdout)
    n_passed = int(passed_match.group(1)) if passed_match else 0
    assert n_passed >= 150, (
        "The regression slice collected far fewer tests than expected "
        f"({n_passed} passed); the keyword filter may no longer match the "
        "changed-path tests.\n"
        f"--- stdout (tail) ---\n{proc.stdout[-4000:]}"
    )
