#!/bin/bash
# Setup for the codex-lb-fix-suppressed-session-reuse verifier.
#
# The bug is a pure in-process asyncio concurrency defect in the HTTP bridge
# session lifecycle: no network, no database, no external service is needed to
# reproduce or verify it. The image bakes the full base-commit dependency closure
# into /opt/venv during the build, with the project installed EDITABLE (a .pth
# entry pointing at /repo/codex-lb). So the agent's source edits to the checkout
# are reflected live in that interpreter with no rebuild of the project — nothing
# here needs to compile codex-lb.
#
# A `uv sync` cannot be the gate: the project builds with hatchling and exposes
# dynamic metadata, so uv must build the project just to read it; the image's
# cache deliberately omits the editable build artifact (anti-leak purge) and the
# grade phase has no network, so any sync that touches the project fails offline.
# We therefore run the dependency sync BEST-EFFORT (it is a no-op on the warm
# venv and is allowed to fail), and make the real gate a loud import of the
# verifier's entry points against the already-complete /opt/venv.

set -euo pipefail

REPO_DIR="/repo/codex-lb"
export REPO_NAME=codex-lb
PY=/opt/venv/bin/python

cd "$REPO_DIR"

# Best-effort refresh of third-party dependencies (warm in the image cache) WITHOUT
# touching the project build. Non-fatal: the baked editable venv is already complete,
# so a failure here (e.g. offline, no cached wheel for a dep the agent added) must not
# block grading. Offline-first, network fallback logged. Both attempts are the SAME
# sync command (offline, then online) — one logical sync, not two.
uv sync --frozen --offline --no-install-project --all-extras --group dev > /tmp/verifier-setup.log 2>&1 || { echo "offline sync incomplete; retrying with network (logged)" >> /tmp/verifier-setup.log; uv sync --frozen --no-install-project --all-extras --group dev >> /tmp/verifier-setup.log 2>&1; } || echo "dependency sync skipped; relying on the baked /opt/venv (logged)" >> /tmp/verifier-setup.log

# Hard gate: the verifier interpreter must be able to import the repo package it
# grades. This fails loudly if the editable venv is somehow broken, instead of
# letting pytest collapse to an opaque collection error later.
"$PY" - <<'PY'
import importlib
for mod in (
    "app.modules.proxy.service",
    "app.modules.proxy._service.http_bridge.request_submit",
    "app.modules.proxy._service.http_bridge.streaming",
    "app.modules.proxy._service.support",
):
    importlib.import_module(mod)
print("codex-lb verifier env ready")
PY
