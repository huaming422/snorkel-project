## Task

Operators running the proxy under sustained load are hitting a self-sustaining
rejection storm. Once the upstream retry circuit trips into a cooldown, incoming
requests keep failing long after the upstream has recovered; instead of settling
as soon as the cooldown passes, the rejections feed themselves and the storm gets
stuck on, rejecting traffic that should be getting through. On top of that, every
so often a request the cooldown is supposed to let through gets rejected anyway
with an "is retiring" error, so even the one retry the system means to permit
gets killed.

Quiet periods look fine; this only shows up under concurrent load. The cooldown
policy itself (when it trips, how long it lasts) is correct, so leave that alone.
The trouble is on the proxy side, in how it manages the lifecycle of its pooled
upstream sessions around a cooldown. Dig in there and fix it, without cutting off
a request that is genuinely allowed to proceed while a cooldown is still in
effect. All of this reproduces in-process; no live upstream is needed.
