#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier runs (inherits set -euo pipefail).
# Everything the verifier needs is baked into the image at build time (Go
# toolchain, the full module cache, and a warm go-build cache at the base
# commit). This script only confirms the module graph is satisfied from the
# image cache with the network cut; it installs nothing.
cd /repo/tailscale

# Fail fast on a cache miss instead of reaching for a dead network.
export GOFLAGS=-mod=mod GOPROXY=off

if go mod download > /tmp/test-setup-godl.log 2>&1; then
    echo "[offline-first] go module graph satisfied from image cache"
else
    echo "[test-setup] go mod download failed offline:" >&2
    tail -40 /tmp/test-setup-godl.log >&2
    exit 1
fi
