// Copyright (c) Tailscale Inc & contributors
// SPDX-License-Identifier: BSD-3-Clause

// In-package behavioral checks for the SSH-server half of LocalBackend
// teardown coordination.
//
// Injected into ipn/ipnlocal as package ipnlocal so it can reach the
// unexported teardown seams it drives: the primary lock, the sshServer
// field, and the lazy SSH init. The package has no TestMain, so this
// file compiles and runs with a plain `go test` alongside the package's
// existing in-package tests.
//
// The certificate-refresh half of the same teardown contract is checked
// separately in verify_acme_test.go (package acme), which drives the
// real cert machinery rather than a replaced test hook.
package ipnlocal

import (
	"net"
	"sync/atomic"
	"testing"

	"tailscale.com/types/logger"
)

// lockObservingSSHServer is a stand-in SSHServer whose Shutdown records how
// many times it was called, checks that the backend's primary lock is NOT held
// when it runs (a non-blocking TryLock must succeed), and then calls a backend
// method that needs that lock. If teardown stops the SSH server while still
// holding the lock, the TryLock fails and the follow-up lock-taking call would
// block, so the stand-in reports the held lock instead of calling it.
//
// b.sshServer is an owned field with no alternative unlocked-drain path, so
// detaching it under the lock and stopping it after the lock is released is the
// only non-deadlocking shape; asserting the lock is free when Shutdown runs
// does not pin an incidental mechanism choice.
type lockObservingSSHServer struct {
	b     *LocalBackend
	t     *testing.T
	calls atomic.Int32
}

func (s *lockObservingSSHServer) HandleSSHConn(net.Conn) error { return nil }
func (s *lockObservingSSHServer) NumActiveConns() int          { return 0 }
func (s *lockObservingSSHServer) OnPolicyChange()              {}

func (s *lockObservingSSHServer) Shutdown() {
	s.calls.Add(1)
	if !s.b.mu.TryLock() {
		s.t.Error("primary lock held while stopping the SSH server")
		return
	}
	s.b.mu.Unlock()
	// Exercise a backend method that takes the primary lock; this would wedge
	// if teardown were still holding it.
	s.b.NodeKey()
}

// installLockObservingSSHServer attaches the stand-in SSH server under the
// lock, mirroring how real code mutates the field.
func installLockObservingSSHServer(b *LocalBackend, s *lockObservingSSHServer) {
	b.mu.Lock()
	b.sshServer = s
	b.mu.Unlock()
}

// C1 (fail_to_pass), SSH half: the SSH server stop must run without the primary
// lock held, so an SSH-session goroutine that needs the lock can finish and
// teardown does not deadlock. Pre-fix the stop runs under the lock, so the
// stand-in observes the held lock and fails; the fix releases the lock before
// the stop. (The cert-refresh half of this criterion is checked in
// verify_acme_test.go against the real cert machinery.)
func TestShutdownReleasesLockBeforeStoppingSSHServer(t *testing.T) {
	b := newTestLocalBackend(t)

	ssh := &lockObservingSSHServer{b: b, t: t}
	installLockObservingSSHServer(b, ssh)

	b.Shutdown()

	if got := ssh.calls.Load(); got != 1 {
		t.Errorf("SSH server shutdown ran %d times; want 1", got)
	}
}

// C2 (fail_to_pass), restart gate: once teardown has begun, the SSH server must
// not be lazily re-created; the lazy init refuses and hands back an error rather
// than constructing a fresh server. Pre-fix it restarts, so this fails; the fix
// gates it. This gate also catches the broader "released the lock but did not
// gate restart" shortcut — a fix that moves the stops out of the lock without
// refusing post-shutdown restart leaves this path re-arming.
//
// The assertion is behavioral, not error-identity based: it installs a factory
// (the same seam the real ssh/tailssh package registers via RegisterNewSSHServer)
// that records every call, then checks that a post-shutdown lazy init (a) never
// invokes the factory — no live server is constructed after teardown — and (b)
// returns a non-nil error. A gated implementation refuses before reaching the
// factory, so the factory stays untouched regardless of which error value it
// hands back; an ungated implementation falls through and constructs a new
// server, tripping the factory counter.
func TestSSHServerDoesNotRestartAfterShutdown(t *testing.T) {
	b := newTestLocalBackend(t)

	var factoryCalls atomic.Int32
	prev := newSSHServer
	newSSHServer = func(logger.Logf, *LocalBackend) (SSHServer, error) {
		factoryCalls.Add(1)
		return &lockObservingSSHServer{b: b, t: t}, nil
	}
	t.Cleanup(func() { newSSHServer = prev })

	b.Shutdown()

	_, err := b.sshServerOrInit()
	if got := factoryCalls.Load(); got != 0 {
		t.Errorf("lazy SSH init after teardown constructed a new SSH server (factory called %d times); want 0", got)
	}
	if err == nil {
		t.Error("lazy SSH init after teardown returned nil error; want a non-nil error refusing the restart")
	}
}

// C3 (fail_to_pass), SSH half: teardown is idempotent — calling the entry point
// more than once runs the real teardown body exactly once, so the SSH server is
// stopped exactly once. The stand-in again asserts the lock is free, so this
// fails pre-fix (teardown holds the lock during the stop); the exactly-once
// count additionally rejects a fix that drops the guard and re-runs the body
// (which would stop the SSH server twice). (The cert-refresh half of the
// idempotency criterion is checked in verify_acme_test.go.)
func TestShutdownRunsTeardownExactlyOnce(t *testing.T) {
	b := newTestLocalBackend(t)

	ssh := &lockObservingSSHServer{b: b, t: t}
	installLockObservingSSHServer(b, ssh)

	b.Shutdown()
	b.Shutdown()

	if got := ssh.calls.Load(); got != 1 {
		t.Errorf("SSH server shutdown ran %d times across two teardown calls; want 1", got)
	}
}
