## Task

we're getting occasional reports that shutting down the node-agent backend just never comes back. you ask it to stop and instead of tearing down and returning, the whole thing wedges partway through teardown and the process never exits.

it's intermittent and clearly timing-dependent, and most stops are clean. the ones that hang seem to line up with the node having had its TLS/ACME certificate-refresh machinery running, and/or live SSH sessions still in flight at the moment the stop comes in. once it's stuck it stays stuck; it never unwedges itself.

the trouble is in how the backend coordinates its own teardown with the sub-components it owns, not in the networking or engine layers underneath it.

dig into why teardown hangs under those conditions and fix it so stopping the backend always completes.
