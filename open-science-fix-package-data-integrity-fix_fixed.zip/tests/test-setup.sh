#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier (set -euo pipefail inherited).
#
# This is an in-process TypeScript/vitest task: there are no services to start and
# no data to seed. The verifier drives the Specialist package + Marketplace
# main-process classes directly against real temp storage dirs it creates itself.
# All this script does is make the baked npm dependency closure usable offline and
# confirm the vitest binary resolves.

cd /repo/open-science

# Fail fast instead of reaching a registry: the image already ran `npm ci` at the
# base commit, so node_modules (including esbuild, fflate and vitest) is present.
export npm_config_offline=true

# Dependencies: offline-first against the image bake, logged online fallback.
# node_modules is baked, so the offline path is normally a fast no-op verification.
if npm ci --prefer-offline --offline --cache /opt/cache/npm > /tmp/test-setup-install.log 2>&1; then
    echo "[offline-first] npm deps satisfied from image bake"
elif { unset npm_config_offline; npm ci --prefer-offline --cache /opt/cache/npm; } >> /tmp/test-setup-install.log 2>&1; then
    echo "[test-setup] npm deps installed online (image bake was stale)"
    export npm_config_offline=true
else
    echo "[test-setup] npm install failed:" >&2
    tail -40 /tmp/test-setup-install.log >&2
    exit 1
fi

# harbor's js runner parses verify.toml via tomllib (Python 3.11+) or tomli.
# If the system python3 has neither, verify.toml is silently dropped and the
# runner falls back to a default that does not know this repo uses vitest.
# Install tomli defensively; never hard-fail (offline-safe, best-effort).
if ! python3 -c "import tomllib" &>/dev/null && \
   ! python3 -c "import tomli"   &>/dev/null; then
    python3 -m pip install --quiet 'tomli==2.0.1' &>/dev/null \
        || python3 -m pip install --break-system-packages --quiet 'tomli==2.0.1' &>/dev/null \
        || true
fi

# Sanity check: vitest must be resolvable from the repo root. A failure here points
# at a corrupted node_modules; bail now rather than hit a confusing "command not
# found" mid-verifier.
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest binary missing from node_modules/.bin/. Re-running npm ci." >&2
    npm ci --prefer-offline
fi

echo "test-setup.sh: ready. node=$(node --version 2>/dev/null) vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
