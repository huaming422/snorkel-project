## Task

Users keep losing or mangling on-disk data around Specialist packages and the Marketplace. The reports we have so far:

- An install or import that gets cut off partway can leave the user without a Skill that had nothing to do with that package.
- Installing a package that ships a Skill the user already has can wipe out what is in that Skill's folder, changes made in the Skill editor included.
- When a Marketplace install runs into trouble while tidying up after itself, the app no longer knows which Skills it switched off or that the install ever happened, and retrying recovery doesn't put that back.
- If a connector or Skill shown on the review screen goes away or changes before the user clicks install, the install goes ahead anyway.
- Export misbehaves in both directions. A Specialist with one broken Skill can't be exported even when that Skill is left out, and an export that does go through can write a file that drops a Skill on re-import, or that carries the version a Skill had before the user edited it.
- A pending-recovery entry in the Marketplace data can disappear or lose detail after some unrelated background refresh, mostly when the file is partly damaged or was written by a newer build.

All of this is per-user state kept in files on disk. None of it should cost anyone their data.
