## Task

With opa run --watch, my edits to policies and data on disk show up on the running server, but the --config-file is only read when the process starts. If I edit it on a running server to add a label or turn on decision logging, nothing happens until I restart OPA.

I'd like --watch to pick up changes to that file as well, on the running server, no restart. Whatever can safely change while it runs gets applied and the rest gets refused. If an edit is refused, none of it lands; the server carries on exactly as it was before that edit.

Services are part of this. If I move a service to another URL or rotate its credentials, the bundles and decision logs that use that service move to the new connection, even when their own sections of the file are unchanged.

I check the result through GET /v1/config and the server log.

## User stories / requirements

- I add a label, turn on console decision logging, or move an existing service to a new URL in the config file of a running server. Each change shows up in GET /v1/config within a few seconds, without a restart.
- In one edit I add a label and change something that only matters at start-up: a server setting, the storage backend, the persistence directory, the default decision or distributed tracing. The whole edit is refused: GET /v1/config shows neither change, and my next valid edit still goes through.
- Labels can be added but not changed. Changing the value of an existing label or deleting one gets the edit refused; the old labels stay, and adding a new label afterwards works.
- Console decision logging is running and I delete the decision_logs section. That edit is refused too, and decision logging carries on with its old settings.
- After a refused edit I put the file back exactly as it was. The original configuration is back in effect and the next edit reloads normally.
- My tooling sometimes empties the file before writing the new contents, and sometimes writes a new file next to it and renames it over the old one. Either way only the finished file takes effect; the server never acts on an empty one.
- When the server gets its configuration through discovery, editing the local file changes nothing on the running server, and the log says the config file isn't being reloaded because discovery is in use.
