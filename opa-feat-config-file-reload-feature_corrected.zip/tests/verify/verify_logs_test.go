// Copyright 2026 The OPA Authors.  All rights reserved.
// Use of this source code is governed by an Apache2
// license that can be found in the LICENSE file.

// This verifier is the decision-log counterpart of verify_test.go. The same
// hot-reload behavior the bundle downloader has to get right applies to the
// decision-log uploader: when the operator repoints a service at a new URL
// while the decision_logs block itself is byte-for-byte unchanged, the running
// uploader has to start posting to the new endpoint. The uploader caches the
// rest client its buffer was built with, so a reload that only diffs the
// plugin's own config would keep posting to the old endpoint.
//
// It drives ONLY the pre-existing, stable public surface of the logs plugin:
//   - plugins.New / Manager.Reconfigure  (register services on the manager)
//   - logs.ParseConfig / logs.New        (build the plugin + its buffer)
//   - Plugin.Start                       (start the uploader loop)
//   - Plugin.Log                         (enqueue a decision)
//   - Plugin.Trigger                     (manual upload)
//   - Plugin.Reconfigure                 (the interface reconfigure hook)
// and observes which HTTP endpoint the upload actually reaches via two counting
// httptest servers. It never references any symbol introduced by the change
// (no new runtime reload functions, no new plugin fields or helpers), and it
// lives in the external `logs_test` package so it cannot touch unexported
// internals.
//
// All helper names carry a `_logsvcrepickup` suffix so the file composes with
// the package's existing *_test.go files without colliding.

package logs_test

import (
	"context"
	"fmt"
	"net/http"
	"net/http/httptest"
	"sync/atomic"
	"testing"

	"github.com/open-policy-agent/opa/v1/config"
	"github.com/open-policy-agent/opa/v1/plugins"
	logsplugin "github.com/open-policy-agent/opa/v1/plugins/logs"
	"github.com/open-policy-agent/opa/v1/server"
	inmem "github.com/open-policy-agent/opa/v1/storage/inmem/test"
)

// countingLogServer_logsvcrepickup answers every upload with 200 OK and records
// how many upload requests it received, so we can tell which endpoint the
// uploader actually posted to.
func countingLogServer_logsvcrepickup(t *testing.T) (*httptest.Server, *atomic.Int64) {
	t.Helper()
	var hits atomic.Int64
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		hits.Add(1)
		w.WriteHeader(http.StatusOK)
	}))
	t.Cleanup(ts.Close)
	return ts, &hits
}

func logServicesJSON_logsvcrepickup(url string) []byte {
	return []byte(fmt.Sprintf(`{"acme": {"url": %q}}`, url))
}

// newLogsPlugin_logsvcrepickup builds a manager pointed at `url`, a
// manually-triggered decision-log uploader served by service "acme", and starts
// the plugin so its buffer (and the client it caches) is live. Returns the
// plugin, the manager, and the logs config for later reconfigure calls.
func newLogsPlugin_logsvcrepickup(t *testing.T, url string) (*logsplugin.Plugin, *plugins.Manager, *logsplugin.Config) {
	t.Helper()

	manager, err := plugins.New(nil, "test-instance-id", inmem.New())
	if err != nil {
		t.Fatalf("new manager: %v", err)
	}
	if err := manager.Reconfigure(&config.Config{Services: logServicesJSON_logsvcrepickup(url)}); err != nil {
		t.Fatalf("configure manager with first service: %v", err)
	}

	cfg, err := logsplugin.ParseConfig([]byte(`{"service": "acme"}`), manager.Services(), nil)
	if err != nil {
		t.Fatalf("parse logs config: %v", err)
	}
	// Manual trigger: the uploader does no background polling, so the only
	// uploads are the ones we drive with Trigger below.
	trigger := plugins.TriggerManual
	cfg.Reporting.Trigger = &trigger

	plugin := logsplugin.New(cfg, manager)
	t.Cleanup(func() { plugin.Stop(context.Background()) })

	if err := plugin.Start(context.Background()); err != nil {
		t.Fatalf("start plugin: %v", err)
	}

	return plugin, manager, cfg
}

// logAndFlush_logsvcrepickup enqueues one decision and drives a manual upload.
func logAndFlush_logsvcrepickup(t *testing.T, plugin *logsplugin.Plugin, decisionID string) {
	t.Helper()
	if err := plugin.Log(context.Background(), &server.Info{DecisionID: decisionID, Path: "svcrepickup/allow"}); err != nil {
		t.Fatalf("log decision %q: %v", decisionID, err)
	}
	if err := plugin.Trigger(context.Background()); err != nil {
		t.Fatalf("trigger upload for decision %q: %v", decisionID, err)
	}
}

// TestLogsServiceRepointReachesNewEndpoint_logsvcrepickup is the behavior under
// test: after the manager is reconfigured to move service "acme" to a second
// URL and the plugin is reconfigured with its SAME decision_logs config, a
// manual upload must reach the second endpoint, not the first.
func TestLogsServiceRepointReachesNewEndpoint_logsvcrepickup(t *testing.T) {
	first, firstHits := countingLogServer_logsvcrepickup(t)
	second, secondHits := countingLogServer_logsvcrepickup(t)

	plugin, manager, cfg := newLogsPlugin_logsvcrepickup(t, first.URL)

	// Baseline: the upload reaches the first endpoint.
	logAndFlush_logsvcrepickup(t, plugin, "d1")
	if firstHits.Load() == 0 {
		t.Fatalf("expected the first endpoint to receive the upload before the repoint, got first=%d second=%d",
			firstHits.Load(), secondHits.Load())
	}
	baselineFirst := firstHits.Load()
	baselineSecond := secondHits.Load()

	// Repoint service "acme" to the second endpoint. The plugin's own
	// decision_logs config is unchanged; only the service moved.
	if err := manager.Reconfigure(&config.Config{Services: logServicesJSON_logsvcrepickup(second.URL)}); err != nil {
		t.Fatalf("reconfigure manager to second service: %v", err)
	}
	plugin.Reconfigure(context.Background(), cfg)

	// The next upload must now reach the second endpoint, and the first endpoint
	// must not be touched again.
	logAndFlush_logsvcrepickup(t, plugin, "d2")
	if secondHits.Load() <= baselineSecond {
		t.Errorf("expected the upload to move to the second endpoint after the service was repointed, "+
			"got first=%d second=%d (baseline second=%d)",
			firstHits.Load(), secondHits.Load(), baselineSecond)
	}
	if firstHits.Load() != baselineFirst {
		t.Errorf("expected the first endpoint to stop receiving uploads after the repoint, "+
			"got first=%d (baseline first=%d)", firstHits.Load(), baselineFirst)
	}
}

// TestUnchangedLogsServiceDoesNotForceRebuild_logsvcrepickup is the converse
// guard: re-registering the SAME service URL and reconfiguring with the SAME
// decision_logs config must keep the uploader working against the same single
// endpoint. A spurious rebuild on a true no-op reconfigure would tear down and
// re-create the buffer the uploader is draining, so an implementation that
// rebuilds unconditionally is not correct. We prove the uploader stays live
// behaviorally: after an unchanged reconfigure the next upload still reaches the
// same single endpoint (no second endpoint exists to leak to).
func TestUnchangedLogsServiceDoesNotForceRebuild_logsvcrepickup(t *testing.T) {
	only, onlyHits := countingLogServer_logsvcrepickup(t)

	plugin, manager, cfg := newLogsPlugin_logsvcrepickup(t, only.URL)

	logAndFlush_logsvcrepickup(t, plugin, "d1")
	afterFirst := onlyHits.Load()
	if afterFirst == 0 {
		t.Fatalf("expected the endpoint to receive the upload at least once, got %d", afterFirst)
	}

	// Re-register the identical service URL and reconfigure with the identical
	// decision_logs config: nothing material changed.
	if err := manager.Reconfigure(&config.Config{Services: logServicesJSON_logsvcrepickup(only.URL)}); err != nil {
		t.Fatalf("reconfigure manager with same service: %v", err)
	}
	plugin.Reconfigure(context.Background(), cfg)

	// The uploader is still live and still reaches the same endpoint.
	logAndFlush_logsvcrepickup(t, plugin, "d2")
	if onlyHits.Load() <= afterFirst {
		t.Errorf("expected the uploader to keep working against the same endpoint after a no-op reconfigure, "+
			"got hits before=%d after=%d", afterFirst, onlyHits.Load())
	}
}

// tokenLogServer_logsvcrepickup answers every upload with 200 OK and records
// the Authorization header of the most recent upload.
func tokenLogServer_logsvcrepickup(t *testing.T) (*httptest.Server, *atomic.Value) {
	t.Helper()
	var last atomic.Value
	last.Store("")
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		last.Store(r.Header.Get("Authorization"))
		w.WriteHeader(http.StatusOK)
	}))
	t.Cleanup(ts.Close)
	return ts, &last
}

func tokenLogServicesJSON_logsvcrepickup(url, token string) []byte {
	return []byte(fmt.Sprintf(`{"acme": {"url": %q, "credentials": {"bearer": {"token": %q}}}}`, url, token))
}

// TestLogsServiceTokenRotationReachesUploader_logsvcrepickup: service "acme"
// keeps its URL and only its bearer token changes; the decision_logs config is
// the same. The next upload must carry the new token.
func TestLogsServiceTokenRotationReachesUploader_logsvcrepickup(t *testing.T) {
	srv, last := tokenLogServer_logsvcrepickup(t)

	manager, err := plugins.New(nil, "test-instance-id", inmem.New())
	if err != nil {
		t.Fatalf("new manager: %v", err)
	}
	if err := manager.Reconfigure(&config.Config{Services: tokenLogServicesJSON_logsvcrepickup(srv.URL, "old-token-7f3a")}); err != nil {
		t.Fatalf("configure manager: %v", err)
	}
	cfg, err := logsplugin.ParseConfig([]byte(`{"service": "acme"}`), manager.Services(), nil)
	if err != nil {
		t.Fatalf("parse logs config: %v", err)
	}
	trigger := plugins.TriggerManual
	cfg.Reporting.Trigger = &trigger
	plugin := logsplugin.New(cfg, manager)
	t.Cleanup(func() { plugin.Stop(context.Background()) })
	if err := plugin.Start(context.Background()); err != nil {
		t.Fatalf("start plugin: %v", err)
	}

	logAndFlush_logsvcrepickup(t, plugin, "t1")
	if got := last.Load().(string); got != "Bearer old-token-7f3a" {
		t.Fatalf("expected the first upload to carry the first token, got Authorization %q", got)
	}

	if err := manager.Reconfigure(&config.Config{Services: tokenLogServicesJSON_logsvcrepickup(srv.URL, "new-token-c91e")}); err != nil {
		t.Fatalf("reconfigure manager with rotated token: %v", err)
	}
	plugin.Reconfigure(context.Background(), cfg)

	logAndFlush_logsvcrepickup(t, plugin, "t2")
	if got := last.Load().(string); got != "Bearer new-token-c91e" {
		t.Errorf("expected the upload after the rotation to carry the new token, got Authorization %q", got)
	}
}
