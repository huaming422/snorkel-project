// @ts-nocheck
//
// Behavioural checks for the remote-compute host details read path, driven
// through the pre-existing ComputeHostProfileOwner boundary (the same public
// seam the repo's own owner + concurrency suites construct directly).
//
// Four groups:
//  1. getDetails (repository double) — a read hands back the exact persisted
//     document (empty before the first save) alongside the untouched resource
//     observations, and carries no synthesized-document marker.
//  1b. shared read contract (renderer handler over a real owner + repository
//     double) — the renderer-facing read goes through the same contract: the
//     first read is the true (empty) document, a save off that baseline lands on
//     the first attempt, the reply carries no synthesized-document marker, and
//     the resource observations stay reachable on their own channel.
//  2. read-then-save round trip (real in-memory SQLite) — a host that has
//     observations but no saved document can be read and then saved on the very
//     first attempt through the normal workflow.
//  3. guarded-save / append invariants (real in-memory SQLite, regression
//     guard) — concurrent saves still conflict, concurrent appends both survive,
//     and the length ceiling is re-checked after a competing write. These hold
//     before and after the change and must stay green.

import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

vi.mock('electron', () => ({
  ipcMain: { handle: () => undefined },
  BrowserWindow: { getAllWindows: () => [] },
  shell: { showItemInFolder: () => undefined },
  app: {
    isPackaged: false,
    getAppPath: () => process.cwd(),
    getPath: (key?: string) => {
      if (key === 'home') return process.env.OPEN_SCIENCE_STORAGE_ROOT ?? tmpdir()
      return tmpdir()
    }
  }
}))

import type { ComputeHost } from '../../shared/compute'
import type { ComputeConnectionBrokerAcquirer } from './connection-broker'
import { ComputeHostProfileOwner } from './compute-host-profile-owner'
import { createComputeHandlers } from './ipc'
import { createProjectDbClient, migrateApplicationDatabase } from '../projects/prisma-client'
import { ComputeHostRepository } from './repository'

// ---------------------------------------------------------------------------
// Helpers mirrored from the repo's own owner-seam suite (not shipped with the
// task, so re-created here).
// ---------------------------------------------------------------------------

const sampleHost = (overrides: Partial<ComputeHost> = {}): ComputeHost => ({
  id: 'host-1',
  providerId: 'ssh:biowulf',
  displayName: 'biowulf',
  shape: 'direct_ssh',
  sshAlias: 'biowulf',
  sshOverrides: undefined,
  scratchRoot: undefined,
  scratchPinned: false,
  concurrencyLimit: undefined,
  probeResult: undefined,
  detailsDoc: '',
  detailsUpdatedAt: undefined,
  detailsUpdatedBy: undefined,
  createdAt: 1,
  updatedAt: 1,
  ...overrides
})

const makeFakeRunner = (result: unknown): ComputeConnectionBrokerAcquirer => ({
  acquire: vi.fn(async () => ({
    run: vi.fn(async () => result),
    upload: vi.fn(async () => undefined),
    download: vi.fn(async () => ({
      exitCode: 0,
      stderr: '',
      timedOut: false,
      bytesWritten: 0,
      exceeded: false
    }))
  }))
})

const makeRepo = (host: ComputeHost | null = sampleHost()) => {
  const updateDetails = vi.fn(() => Promise.resolve(true))
  const repo = {
    get: vi.fn(() => Promise.resolve(host)),
    list: vi.fn(() => Promise.resolve([])),
    create: vi.fn(),
    delete: vi.fn(),
    updateProbeResult: vi.fn(() => Promise.resolve(true)),
    updateDetails,
    updateScratchPinned: vi.fn(() => Promise.resolve()),
    clearScratchRoot: vi.fn(() => Promise.resolve()),
    updateConcurrencyLimit: vi.fn(() => Promise.resolve())
  } as unknown as ComputeHostRepository
  return { repo, updateDetails }
}

const fakeRunner = makeFakeRunner({
  exitCode: 0,
  stdout: '',
  stderr: '',
  timedOut: false,
  truncated: false
})

// A successful probe snapshot: observations exist, but no document was saved.
const okProbe = {
  ok: true as const,
  probedAt: '2026-01-01T00:00:00Z',
  exitCode: 0,
  errorTail: null,
  authenticationRevision: 1,
  cpus: 64,
  memMib: 256000,
  gpus: [{ type: 'A100 80GB', count: 2 }],
  detectedScheduler: 'slurm' as const
}

// ---------------------------------------------------------------------------
// 1. A read returns the persisted document, and only the document + probe.
// ---------------------------------------------------------------------------

describe('getDetails returns the persisted document', () => {
  it('hands back the empty document before the first save, with no synthesized resource text', async () => {
    const { repo } = makeRepo(sampleHost({ detailsDoc: '', probeResult: okProbe }))
    const owner = new ComputeHostProfileOwner(fakeRunner, repo)

    const details = await owner.getDetails('ssh:biowulf')

    // The read is the exact persisted document — empty, never a synthesized
    // "## Resources" summary built from the observations.
    expect(details.doc).toBe('')
  })

  it('keeps the probe observations available alongside the document read', async () => {
    const { repo } = makeRepo(sampleHost({ detailsDoc: '', probeResult: okProbe }))
    const owner = new ComputeHostProfileOwner(fakeRunner, repo)

    const details = await owner.getDetails('ssh:biowulf')

    // Resource observations are not dropped or merged into the document — they
    // remain reachable, unchanged, as their own structured channel.
    expect(details.probeResult).toEqual(okProbe)
  })

  it('does not mark the read with the retired synthesized-document flag', async () => {
    const { repo } = makeRepo(sampleHost({ detailsDoc: '', probeResult: okProbe }))
    const owner = new ComputeHostProfileOwner(fakeRunner, repo)

    const details = await owner.getDetails('ssh:biowulf')

    // Once the read is always the persisted document, the boolean that marked a
    // reply as synthesized has no meaning and is gone from the shared shape —
    // not retained as a vestigial always-false field every consumer still sees.
    expect('isSkeleton' in details).toBe(false)
  })

  it('hands back a saved document verbatim alongside the untouched observations', async () => {
    const { repo } = makeRepo(
      sampleHost({ detailsDoc: 'Use the long queue.', probeResult: okProbe })
    )
    const owner = new ComputeHostProfileOwner(fakeRunner, repo)

    const details = await owner.getDetails('ssh:biowulf')

    expect(details.doc).toBe('Use the long queue.')
    expect(details.probeResult).toEqual(okProbe)
  })
})

// ---------------------------------------------------------------------------
// 1b. The read answer is consistent across the whole shared read contract.
//
// The details read crosses several layers that all share one contract (the
// main-process owner boundary, the renderer handler built by
// createComputeHandlers, and every downstream consumer). This drives the
// renderer handler end-to-end against a real owner+service so the check is
// behavioural — type annotations are erased at build time, so a layer that
// still advertises the retired flag in its types but has dropped it from the
// runtime value would (correctly) pass, and one that still carries the flag at
// runtime anywhere on the read path fails. The full read→save→read round trip
// must work off the true persisted document.
// ---------------------------------------------------------------------------

describe('the shared read contract hands back the persisted document', () => {
  // A probed host that has never had its document saved — resource
  // observations exist, the saved document is still empty.
  const makeProbedHost = (): ComputeHost =>
    sampleHost({
      detailsDoc: '',
      probeResult: {
        ok: true,
        probedAt: '2026-01-01T00:00:00Z',
        exitCode: 0,
        errorTail: null,
        authenticationRevision: 1,
        cpus: 128,
        detectedScheduler: 'slurm'
      } as ComputeHost['probeResult']
    })

  // Build the renderer handlers over a repository double whose guarded update
  // only lands when the handed-back baseline matches the stored document — the
  // same optimistic guard the production repository enforces.
  const handlersFor = (host: ComputeHost) =>
    createComputeHandlers(
      {
        get: async () => host,
        updateDetails: async (
          _providerId: string,
          text: string,
          _author: string,
          hostId: string,
          oldText: string
        ) => {
          if (host.id !== hostId || host.detailsDoc !== oldText) return false
          host.detailsDoc = text
          return true
        }
      } as unknown as ComputeHostRepository
    )

  it('reads the empty document first, saves off that baseline, and reads it back', async () => {
    const host = makeProbedHost()
    const handlers = handlersFor(host)

    // First read before any save: the true persisted document is empty.
    const initial = await handlers.detailsGet(host.providerId)
    expect(initial.doc).toBe('')

    // Saving off that just-read baseline succeeds on the first attempt — the
    // guard matches because the baseline is the real stored document.
    const instructions = 'Use direct SSH. Do not submit scheduler jobs unless asked.'
    await handlers.detailsSave(host.providerId, instructions, initial.doc, 'user')

    // The next read reflects exactly what was saved.
    expect((await handlers.detailsGet(host.providerId)).doc).toBe(instructions)
  })

  it('does not expose the retired synthesized-document flag on the handler read', async () => {
    const host = makeProbedHost()
    const handlers = handlersFor(host)

    const initial = await handlers.detailsGet(host.providerId)

    // The renderer-facing read must not carry the boolean that marked a reply
    // as synthesized — it is gone from the shared contract, not relayed as a
    // vestigial always-false field the renderer still has to reason about.
    expect('isSkeleton' in initial).toBe(false)
  })

  it('keeps probe resource observations reachable on their own channel', async () => {
    const host = makeProbedHost()
    const handlers = handlersFor(host)

    // The resource observations are not lost by the contract change: the host
    // read still surfaces the probe result with its resource fields intact.
    const probe = (await handlers.get(host.providerId))?.probeResult
    expect(probe).toMatchObject({ cpus: 128, detectedScheduler: 'slurm' })
  })
})

// ---------------------------------------------------------------------------
// 2. The normal read-then-save round trip succeeds on the first save.
// ---------------------------------------------------------------------------

describe('read-then-save round trip (real SQLite)', () => {
  let root: string
  let client: ReturnType<typeof createProjectDbClient>
  let repository: ComputeHostRepository

  beforeEach(async () => {
    root = await mkdtemp(join(tmpdir(), 'details-roundtrip-'))
    client = createProjectDbClient(root)
    await migrateApplicationDatabase(client)
    repository = new ComputeHostRepository(async () => client)
  })

  afterEach(async () => {
    await client?.$disconnect()
    if (root) await rm(root, { recursive: true, force: true })
  })

  const owner = (): ComputeHostProfileOwner =>
    new ComputeHostProfileOwner(
      { acquire: async () => ({ run: vi.fn() }) } as unknown as ComputeConnectionBrokerAcquirer,
      repository
    )

  it('saves on the first try for a host that has a probe and no saved document', async () => {
    // A host registered with no details, then probed so it carries resource
    // observations but still has an empty saved document.
    const host = await repository.create({ sshAlias: 'biowulf', detailsDoc: '' })
    expect(
      await repository.updateProbeResult(host.providerId, okProbe, 'scheduler_cluster', host.id)
    ).toBe(true)

    const service = owner()

    // Normal workflow: read the current details, then save them straight back
    // using what the read handed us as the baseline.
    const { doc } = await service.getDetails(host.providerId)
    await expect(
      service.replaceDetails(host.providerId, {
        text: 'Prefer the long partition.',
        oldText: doc,
        author: 'user'
      })
    ).resolves.toBeUndefined()

    // The text actually landed.
    expect((await repository.get(host.providerId))?.detailsDoc).toBe('Prefer the long partition.')
  })
})

// ---------------------------------------------------------------------------
// 3. Guarded-save / append invariants — regression guard (hold before & after).
// ---------------------------------------------------------------------------

describe('guarded-save and append invariants are preserved (real SQLite)', () => {
  let root: string
  let client: ReturnType<typeof createProjectDbClient>
  let repository: ComputeHostRepository
  const providerId = 'ssh:cluster'

  beforeEach(async () => {
    root = await mkdtemp(join(tmpdir(), 'details-cas-'))
    client = createProjectDbClient(root)
    await migrateApplicationDatabase(client)
    repository = new ComputeHostRepository(async () => client)
    await repository.create({ sshAlias: 'cluster', detailsDoc: 'base' })
  })

  afterEach(async () => {
    await client?.$disconnect()
    if (root) await rm(root, { recursive: true, force: true })
  })

  const owner = (): ComputeHostProfileOwner =>
    new ComputeHostProfileOwner(
      { acquire: async () => ({ run: vi.fn() }) } as unknown as ComputeConnectionBrokerAcquirer,
      repository
    )

  // Hold the first two public reads until both writers share one DB snapshot, so
  // the two saves genuinely race against the same baseline.
  const synchronizeReads = (): void => {
    const get = repository.get.bind(repository)
    let arrivals = 0
    let release!: () => void
    const ready = new Promise<void>((resolve) => {
      release = resolve
    })
    vi.spyOn(repository, 'get').mockImplementation(async (id) => {
      const host = await get(id)
      if (++arrivals <= 2) {
        if (arrivals === 2) release()
        await ready
      }
      return host
    })
  }

  it('rejects one of two simultaneous replacements with a conflict', async () => {
    synchronizeReads()
    const service = owner()
    const results = await Promise.allSettled(
      ['first', 'second'].map((text) =>
        service.replaceDetails(providerId, { text, oldText: 'base', author: 'user' })
      )
    )
    expect(results.filter((r) => r.status === 'fulfilled')).toHaveLength(1)
    expect(results.find((r) => r.status === 'rejected')).toMatchObject({
      reason: expect.objectContaining({ message: expect.stringMatching(/conflict|old_text/i) })
    })
  })

  it('preserves both simultaneous appends', async () => {
    synchronizeReads()
    const service = owner()
    await Promise.all(
      ['first', 'second'].map((text) => service.appendDetails(providerId, { text, author: 'agent' }))
    )
    expect((await repository.get(providerId))?.detailsDoc.split('\n').sort()).toEqual([
      'base',
      'first',
      'second'
    ])
  })

  it('re-checks the length ceiling after a competing append', async () => {
    await client.computeHost.update({
      where: { providerId },
      data: { detailsDoc: 'x'.repeat(32760) }
    })
    synchronizeReads()
    const service = owner()
    const results = await Promise.allSettled(
      ['first', 'second'].map((text) => service.appendDetails(providerId, { text, author: 'agent' }))
    )
    expect(results.filter((r) => r.status === 'fulfilled')).toHaveLength(1)
    expect(results.find((r) => r.status === 'rejected')).toMatchObject({
      reason: expect.objectContaining({ message: expect.stringContaining('32768') })
    })
  })
})
