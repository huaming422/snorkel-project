## Task

saving the Details / instructions document on a remote compute host fails on the first save, but only after a resource probe has been run against that host. the pattern: add a host, run a probe against it, then try to save that host's details. the save gets rejected as though the document had changed underneath you, even though nobody ever edited a saved document for that host. this used to work; you could save straight away.

it reproduces through the normal flow, and it isn't just the Settings UI. the agent-facing compute API reads the same host details, so an agent that reads a host's details and then saves them hits the same rejection.

this is specifically about the details / instructions document and its save path. SSH connectivity, authentication, scratch paths, and the probe mechanism itself are all out of scope, and the resource observations still need to be available afterward. dig into why that first save is being rejected and fix it so a normal read-then-save works.
