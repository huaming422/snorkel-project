#!/usr/bin/env bash
# Verifier-time setup. Everything both verifiers need is already baked into the
# image:
#   - Go: toolchain (1.26.4), warm module + build cache, and the cl100k_base
#     BPE table under ragflow_deps/ (the title-cap and token hard-cap tests
#     count tokens through the real tokenizer, which loads that table from
#     disk).
#   - Python: the canonical verifier venv at /opt/tooling/venv (VERIFIER_PYTHON),
#     with pytest. verify.py loads the title chunker and every repo module it
#     imports from the repo's own files, replacing only what needs the running
#     service, its models or packages that venv lacks, so ragflow's own Python
#     dependencies are not needed.
# Nothing to install at verifier time.
set -euo pipefail
echo "[test-setup] no-op for ragflow-fix-chunk-preview-positions (deps baked into image)"
