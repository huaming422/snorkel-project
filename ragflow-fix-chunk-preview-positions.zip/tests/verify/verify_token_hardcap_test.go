package chunker

// Behavioral verifier for the TokenChunker hard cap on the Go side (the
// General pipeline): a single paragraph longer than chunk_token_size is split
// into several chunks.
//
// Each test runs the exported TokenChunker component (NewTokenChunker +
// Invoke) on one JSON item, the way the parser hands a paragraph over. The
// paragraph has no delimiter, so it reaches the chunker as one unit and only
// the hard cap splits it. It carries a three-row page-region matrix that
// starts near the bottom of page 1 and runs onto page 2, plus the details the
// first piece carries (parent reference, layout, page number). The checks:
//   - every piece carries a non-empty region whose rows sit inside the source
//     rows, the first piece reaching the top of the paragraph and the last its
//     bottom, every source row reached by some piece (the whole matrix on
//     every piece passes, and so does each piece's own share of it);
//   - every piece keeps the paragraph's other details, as the first one does;
//   - the split itself is unchanged (a guard that holds before and after the
//     change).
//
// Tokens are counted by the real tokenizer (the image bakes its BPE table).
// Self-contained: its helpers carry a vtk prefix so they cannot collide with
// the package's or a solution's own test helpers.

import (
	"context"
	"encoding/json"
	"fmt"
	"math"
	"strings"
	"testing"

	"ragflow/internal/tokenizer"
)

const (
	vtkSize = 32
	vtkTol  = 1.0
)

// vtkSourceRows is [page, left, right, top, bottom] per row, in reading order.
var vtkSourceRows = [][]float64{
	{1, 72, 540, 520, 760},
	{2, 72, 540, 40, 210},
	{2, 72, 540, 220, 330},
}

// vtkParagraph is one paragraph with no "\n", "!" or "?" in it, several times
// chunk_token_size long.
func vtkParagraph() string {
	parts := make([]string, 0, 12)
	for i := 0; i < 12; i++ {
		parts = append(parts, fmt.Sprintf("Gauge %02d on the east levee read higher than the week before, so the crew logged it twice.", i))
	}
	return strings.Join(parts, " ")
}

func vtkItem() map[string]any {
	return map[string]any{
		"text":           vtkParagraph(),
		"doc_type_kwd":   "text",
		"_pdf_positions": vtkSourceRows,
		"mom":            "levee-report-sec-2",
		"layout":         "text",
		"page_number":    1,
	}
}

func vtkInvoke(t *testing.T, items []map[string]any) []map[string]any {
	t.Helper()
	comp, err := NewTokenChunker(map[string]any{
		"delimiter_mode":   "delimiter",
		"delimiters":       []string{"\n"},
		"chunk_token_size": vtkSize,
	})
	if err != nil {
		t.Fatalf("NewTokenChunker: %v", err)
	}
	out, err := comp.Invoke(context.Background(), nil, map[string]any{
		"name":          "levee.pdf",
		"output_format": "json",
		"json":          items,
	})
	if err != nil {
		t.Fatalf("TokenChunker.Invoke: %v", err)
	}
	if msg, _ := out["_ERROR"].(string); msg != "" {
		t.Fatalf("TokenChunker error payload: %s", msg)
	}
	chunks, _ := out["chunks"].([]map[string]any)
	return chunks
}

// vtkRowsOf reads a position value whatever its in-memory shape
// ([][]float64, raw JSON, or a generic decoded slice).
func vtkRowsOf(v any) ([][]float64, bool) {
	if v == nil {
		return nil, false
	}
	var raw []byte
	switch x := v.(type) {
	case [][]float64:
		return x, true
	case json.RawMessage:
		raw = x
	case []byte:
		raw = x
	case string:
		raw = []byte(x)
	default:
		b, err := json.Marshal(x)
		if err != nil {
			return nil, false
		}
		raw = b
	}
	var rows [][]float64
	if err := json.Unmarshal(raw, &rows); err != nil {
		return nil, false
	}
	return rows, true
}

func vtkInside(r []float64, src [][]float64) bool {
	if len(r) < 5 || r[4] < r[3] {
		return false
	}
	for _, s := range src {
		if r[0] == s[0] && r[1] >= s[1]-vtkTol && r[2] <= s[2]+vtkTol &&
			r[3] >= s[3]-vtkTol && r[4] <= s[4]+vtkTol {
			return true
		}
	}
	return false
}

// vtkJSON normalises a detail value so 1, 1.0 and json.Number("1") compare equal.
func vtkJSON(v any) string {
	b, err := json.Marshal(v)
	if err != nil {
		return fmt.Sprintf("%#v", v)
	}
	var generic any
	if err := json.Unmarshal(b, &generic); err != nil {
		return string(b)
	}
	out, _ := json.Marshal(generic)
	return string(out)
}

// TestVerifyTokenHardcap_SplitParagraphPiecesKeepRegion: every piece of the
// split paragraph carries a page region inside the paragraph's own.
func TestVerifyTokenHardcap_SplitParagraphPiecesKeepRegion(t *testing.T) {
	chunks := vtkInvoke(t, []map[string]any{vtkItem()})
	if len(chunks) < 3 {
		t.Fatalf("want the over-size paragraph split into 3 or more chunks, got %d", len(chunks))
	}
	first, last := vtkSourceRows[0], vtkSourceRows[len(vtkSourceRows)-1]
	reached := make([]bool, len(vtkSourceRows))
	for i, ck := range chunks {
		rows, ok := vtkRowsOf(ck["_pdf_positions"])
		if !ok || len(rows) == 0 {
			t.Errorf("piece %d of %d carries no page region (%#v), so it gets no preview and no highlight",
				i, len(chunks), ck["_pdf_positions"])
			continue
		}
		startsParagraph, endsParagraph := false, false
		for _, r := range rows {
			if !vtkInside(r, vtkSourceRows) {
				t.Errorf("piece %d region row %v is not inside any row of the source paragraph %v", i, r, vtkSourceRows)
				continue
			}
			for j, s := range vtkSourceRows {
				if r[0] == s[0] && r[3] < s[4] && r[4] > s[3] {
					reached[j] = true
				}
			}
			if r[0] == first[0] && math.Abs(r[3]-first[3]) <= vtkTol {
				startsParagraph = true
			}
			if r[0] == last[0] && math.Abs(r[4]-last[4]) <= vtkTol {
				endsParagraph = true
			}
		}
		if i == 0 && !startsParagraph {
			t.Errorf("the first piece's region %v does not reach the top of the paragraph %v", rows, first)
		}
		if i == len(chunks)-1 && !endsParagraph {
			t.Errorf("the last piece's region %v does not reach the bottom of the paragraph %v", rows, last)
		}
	}
	for j, ok := range reached {
		if !ok {
			t.Errorf("no piece points at source row %v", vtkSourceRows[j])
		}
	}
}

// TestVerifyTokenHardcap_SplitParagraphPiecesKeepDetails: apart from its text
// and its region, every piece keeps the details the paragraph came with, the
// same way the first piece does.
func TestVerifyTokenHardcap_SplitParagraphPiecesKeepDetails(t *testing.T) {
	item := vtkItem()
	chunks := vtkInvoke(t, []map[string]any{item})
	if len(chunks) < 3 {
		t.Fatalf("want the over-size paragraph split into 3 or more chunks, got %d", len(chunks))
	}
	for i, ck := range chunks {
		for _, key := range []string{"mom", "layout", "page_number"} {
			if got, want := vtkJSON(ck[key]), vtkJSON(item[key]); got != want {
				t.Errorf("piece %d of %d: %s = %s, want %s like the paragraph it came from", i, len(chunks), key, got, want)
			}
		}
	}
}

// TestVerifyTokenHardcap_SplitInvariantsPreserved guards the split itself,
// before and after the change alike: the pieces joined reproduce the
// paragraph, every piece is within chunk_token_size, and a table item is never
// split.
func TestVerifyTokenHardcap_SplitInvariantsPreserved(t *testing.T) {
	if tokenizer.NumTokensFromString("gauge reading") <= 0 {
		t.Fatalf("the tokenizer counted no tokens; its BPE table is missing")
	}
	item := vtkItem()
	chunks := vtkInvoke(t, []map[string]any{item})
	if len(chunks) < 3 {
		t.Fatalf("want 3 or more chunks, got %d", len(chunks))
	}
	var joined strings.Builder
	for i, ck := range chunks {
		text, _ := ck["text"].(string)
		joined.WriteString(text)
		if n := tokenizer.NumTokensFromString(text); n > vtkSize {
			t.Errorf("piece %d has %d tokens, over chunk_token_size %d", i, n, vtkSize)
		}
	}
	if want := item["text"].(string); joined.String() != want {
		t.Errorf("the pieces joined do not reproduce the paragraph:\n got=%q\nwant=%q", joined.String(), want)
	}

	table := strings.Repeat("col ", 100)
	tables := vtkInvoke(t, []map[string]any{{"text": table, "doc_type_kwd": "table"}})
	if len(tables) != 1 {
		t.Fatalf("a table item must stay whole, got %d chunks", len(tables))
	}
	if got, _ := tables[0]["text"].(string); !strings.Contains(got, strings.TrimSpace(table)) {
		t.Errorf("the table text changed:\n got=%q\nwant it to contain=%q", got, strings.TrimSpace(table))
	}
}
