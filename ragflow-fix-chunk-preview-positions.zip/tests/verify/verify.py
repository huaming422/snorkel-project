"""Behavioral verifier for the Python title chunker's cap split.

Runs the repo's TitleChunker component (hierarchy for the book pipeline, group
for the paper pipeline) through its invoke() on a passage longer than
chunk_token_cap and reads the chunks it emits. The passage arrives the way the
parser writes it: one three-row page-region matrix, under both "positions" and
"_pdf_positions", that starts near the bottom of page 1 and runs onto page 2.
The chunker crops each preview from the matrix a chunk carries and turns the
same matrix into the chunk's highlight fields (position_int), so the checks read
position_int:
  - region: every piece carries a non-empty region whose rows sit inside the
    passage's outline on their page (the box the passage's rows on that page
    span), the first piece reaches the top of the passage, the last piece its
    bottom, and every source row is reached by some piece;
  - stretch: laid end to end in reading order, the source rows form one
    stretch of height H, and a piece holding the share [a, b) of the passage's
    text (by character count) owns [a*H, b*H) of it. Within 5% of H both ways,
    the piece's region must cover that stretch and stay inside it. A box that
    spans two rows of one page counts as the stretch it spans, the gap between
    the rows adding nothing;
  - guards: the pieces joined reproduce the passage, every piece stays within
    the cap, and a table chunk is never split.

Module loading. Every repo module on the chunker's import path loads from the
repo's files as they stand, and so does any repo module those files import.
Only what cannot load without the running service, its models or packages the
verifier venv lacks is replaced:
  - agent.*, the agent component runtime: agent.component.base becomes a small
    ComponentBase / ComponentParamBase that keeps outputs on the parameter
    object as the real one does and skips the parameter check (the fixtures use
    a cap below the production minimum); the rest of agent.* is inert;
  - common.settings (storage, database and search connectors), deepdoc.vision
    (OCR and layout models), rag.nlp.rag_tokenizer (the Infinity tokenizer) and
    rag.prompts (the LLM prompt stack): inert placeholders;
  - third-party packages the venv lacks (PIL, pdfplumber, chardet, ...): inert
    placeholders, for imports the repo's own modules make;
  - common.token_utils loads from the repo with its two token counters set to
    one token per character, the counter the fixtures are sized by (the repo's
    own in-tree test counts the same way); its tiktoken cache points at a
    scratch directory, so nothing is written into the repo.
Package files that only register or re-export their submodules (rag.flow,
rag.flow.chunker, deepdoc, deepdoc.parser) are not run; the modules under them
still load from the repo. Runs on the verifier venv's Python 3.12 + pytest.
"""

import asyncio
import builtins
import importlib
import importlib.abc
import importlib.machinery
import importlib.util
import os
import sys
import tempfile
import types
from contextlib import contextmanager
from pathlib import Path

import pytest


def _repo_root() -> Path:
    """Resolve the ragflow repo root inside the task container.

    The Python runner runs pytest with cwd set to the repo dir; prefer that
    when it looks like the repo, else fall back to the known container path.
    """
    candidates = []
    env_root = os.environ.get("REPO_DIR") or os.environ.get("REPO_ROOT")
    if env_root:
        candidates.append(Path(env_root))
    candidates.append(Path.cwd())
    candidates.append(Path("/repo/ragflow"))
    for cand in candidates:
        if (cand / "rag" / "flow" / "chunker" / "title_chunker" / "common.py").is_file():
            return cand
    # Last resort: the documented container path (lets the import error be loud).
    return Path("/repo/ragflow")


# Repo modules that need the running service or its models (module docstring).
_REPLACED = ("agent", "common.settings", "deepdoc.vision", "rag.nlp.rag_tokenizer", "rag.prompts")
# Package files that only register or re-export submodules: opened, not run.
_HUBS = {"rag.flow", "rag.flow.chunker", "deepdoc", "deepdoc.parser"}


class _Inert:
    """Stands in for anything a replaced module or a missing package provides."""

    def __init__(self, name):
        object.__setattr__(self, "_inert_name", name)

    def __getattr__(self, attr):
        if attr.startswith("__") and attr.endswith("__"):
            raise AttributeError(attr)
        return _Inert(f"{self._inert_name}.{attr}")

    def __call__(self, *args, **kwargs):
        if len(args) == 1 and not kwargs and callable(args[0]):
            return args[0]  # used as a decorator: leave the decorated object alone
        return _Inert(f"{self._inert_name}()")

    def __mro_entries__(self, bases):
        return (object,)

    def __iter__(self):
        return iter(())

    def __bool__(self):
        return False

    def __repr__(self):
        return f"<inert {self._inert_name}>"


def _inert_getattr(name):
    def __getattr__(attr):
        if attr.startswith("__") and attr.endswith("__"):
            raise AttributeError(attr)
        return _Inert(f"{name}.{attr}")

    return __getattr__


def _inert_module(name):
    module = types.ModuleType(name)
    module.__path__ = []
    module.__getattr__ = _inert_getattr(name)
    return module


def _component_base_module():
    """agent.component.base: the part of the agent runtime rag.flow.base needs."""
    module = types.ModuleType("agent.component.base")

    class ComponentParamBase:
        def __init__(self):
            self.inputs = {}
            self.outputs = {}
            self.exception_method = None
            self.exception_default_value = None

        def check(self):
            return None

        @staticmethod
        def check_empty(param, description):
            return None

        @staticmethod
        def check_positive_integer(param, description):
            return None

        @staticmethod
        def check_valid_value(param, description, valid_values):
            return None

        @staticmethod
        def check_decimal_float(param, description):
            return None

        @staticmethod
        def check_nonnegative_number(param, description):
            return None

    class ComponentBase:
        def __init__(self, canvas, id, param):
            self._canvas = canvas
            self._id = id
            self._param = param

        def output(self, var_nm=None):
            if var_nm:
                return self._param.outputs.get(var_nm, {}).get("value", "")
            return {k: o.get("value") for k, o in self._param.outputs.items()}

        def set_output(self, key, value):
            self._param.outputs.setdefault(key, {"value": None})["value"] = value

        def get_exception_default_value(self):
            return ""

        def set_exception_default_value(self):
            self.set_output("result", "")

    module.ComponentBase = ComponentBase
    module.ComponentParamBase = ComponentParamBase
    module.__getattr__ = _inert_getattr("agent.component.base")
    return module


def _count_tokens(text):
    return len(text or "")


def _truncate(text, max_len):
    return (text or "")[:max_len]


_SCRATCH = []


def _scratch_dir():
    if not _SCRATCH:
        _SCRATCH.append(tempfile.mkdtemp(prefix="verify-tiktoken-"))
    return _SCRATCH[0]


class _Loader:
    """Loads repo modules from their files; serves the replacements above."""

    def __init__(self, root: Path):
        self.root = root
        self.created = []
        self.missing = {}
        self.scratch = _scratch_dir()
        self.builtins = dict(vars(builtins))
        self.builtins["__import__"] = self._import

    # Which top-level names are the repo's own packages.
    def is_repo(self, top):
        if top in sys.stdlib_module_names:
            return False
        base = self.root / top
        return (base / "__init__.py").is_file() or (base.is_dir() and any(base.glob("*.py"))) or (self.root / f"{top}.py").is_file()

    def is_missing(self, top):
        if top not in self.missing:
            self.missing[top] = not self.is_repo(top) and top not in sys.modules and importlib.util.find_spec(top) is None
        return self.missing[top]

    def register(self, name, module):
        self.created.append((name, sys.modules.get(name)))
        sys.modules[name] = module
        parent, _, leaf = name.rpartition(".")
        if parent and parent in sys.modules:
            setattr(sys.modules[parent], leaf, module)
        return module

    def _inert_chain(self, name, fromlist):
        parts = name.split(".")
        for i in range(1, len(parts) + 1):
            sub = ".".join(parts[:i])
            if sub not in sys.modules:
                self.register(sub, _inert_module(sub))
        return sys.modules[name] if fromlist else sys.modules[parts[0]]

    def _import(self, name, globals=None, locals=None, fromlist=(), level=0):
        # Only the repo's own modules import through here (their __builtins__).
        if level == 0 and self.is_missing(name.partition(".")[0]):
            return self._inert_chain(name, fromlist)
        return builtins.__import__(name, globals, locals, fromlist, level)

    def exec_repo_module(self, module, loader):
        module.__dict__["__builtins__"] = self.builtins
        if module.__name__ != "common.token_utils":
            loader.exec_source(module)
            return
        # Point the tiktoken cache at a scratch dir holding a link to the
        # repo's bundled BPE table, so the module copies nothing into the repo
        # and never fetches the table. Without the bundled table the module's
        # encoder cannot load offline, and only the two counters are provided.
        bundled = self.root / "ragflow_deps" / "cl100k_base.tiktoken"
        if bundled.is_file():
            deps = Path(self.scratch) / "ragflow_deps"
            deps.mkdir(exist_ok=True)
            link = deps / "cl100k_base.tiktoken"
            if not link.exists():
                link.symlink_to(bundled)
            saved = {k: os.environ.get(k) for k in ("RAG_PROJECT_BASE", "TIKTOKEN_CACHE_DIR")}
            os.environ["RAG_PROJECT_BASE"] = self.scratch
            try:
                loader.exec_source(module)
            except Exception as exc:  # the encoder could not load; the counters below still apply
                module.__dict__["_verify_load_error"] = repr(exc)
            finally:
                for key, value in saved.items():
                    if value is None:
                        os.environ.pop(key, None)
                    else:
                        os.environ[key] = value
        module.num_tokens_from_string = _count_tokens
        module.truncate = _truncate


class _RepoSourceLoader(importlib.machinery.SourceFileLoader):
    def __init__(self, owner, fullname, path):
        super().__init__(fullname, path)
        self.owner = owner

    def exec_source(self, module):
        super().exec_module(module)

    def exec_module(self, module):
        self.owner.exec_repo_module(module, self)


class _ReadyLoader(importlib.abc.Loader):
    """Serves a module built in memory (a replacement, or a package left unrun)."""

    def __init__(self, factory):
        self.factory = factory

    def create_module(self, spec):
        return self.factory(spec)

    def exec_module(self, module):
        return None


class _RepoFinder(importlib.abc.MetaPathFinder):
    def __init__(self, owner):
        self.owner = owner

    def find_spec(self, fullname, path=None, target=None):
        owner = self.owner
        if not owner.is_repo(fullname.partition(".")[0]):
            return None
        if fullname == "agent.component.base":
            return importlib.util.spec_from_loader(fullname, _ReadyLoader(lambda spec: _component_base_module()))
        if any(fullname == r or fullname.startswith(r + ".") for r in _REPLACED):
            spec = importlib.util.spec_from_loader(fullname, _ReadyLoader(lambda spec: _inert_module(spec.name)), is_package=True)
            return spec
        base = owner.root.joinpath(*fullname.split("."))
        init = base / "__init__.py"
        if base.is_dir() and (fullname in _HUBS or not init.is_file()):
            def _package(spec, where=str(base)):
                module = types.ModuleType(spec.name)
                module.__path__ = [where]
                return module

            spec = importlib.util.spec_from_loader(fullname, _ReadyLoader(_package), is_package=True)
            spec.submodule_search_locations = [str(base)]
            return spec
        if init.is_file():
            return importlib.util.spec_from_file_location(
                fullname, init, loader=_RepoSourceLoader(owner, fullname, str(init)), submodule_search_locations=[str(base)]
            )
        source = base.with_suffix(".py")
        if source.is_file():
            return importlib.util.spec_from_file_location(fullname, source, loader=_RepoSourceLoader(owner, fullname, str(source)))
        return None


@contextmanager
def _repo_modules():
    """Import repo modules as described in the module docstring; undo it after."""
    root = _repo_root()
    owner = _Loader(root)
    finder = _RepoFinder(owner)
    before = set(sys.modules)
    saved_paths = list(sys.path)
    saved_bytecode = sys.dont_write_bytecode
    sys.dont_write_bytecode = True
    sys.meta_path.insert(0, finder)
    try:
        yield importlib.import_module
    finally:
        sys.meta_path.remove(finder)
        sys.dont_write_bytecode = saved_bytecode
        sys.path[:] = saved_paths
        for name in set(sys.modules) - before:
            module = sys.modules.get(name)
            spec = getattr(module, "__spec__", None)
            origin = getattr(spec, "origin", None) or ""
            if isinstance(getattr(spec, "loader", None), (_RepoSourceLoader, _ReadyLoader)) or origin.startswith(str(root)):
                sys.modules.pop(name, None)
        for name, original in reversed(owner.created):
            if original is None:
                sys.modules.pop(name, None)
            else:
                sys.modules[name] = original


def _run(method, items, **params):
    """Run the TitleChunker component on one JSON payload; return its chunks."""
    with _repo_modules() as load:
        common_module = load("rag.flow.chunker.title_chunker.common")
        component_module = load("rag.flow.chunker.title_chunker.title_chunker")
        param = common_module.TitleChunkerParam()
        param.method = method
        param.chunk_token_cap = params.pop("chunk_token_cap", 512)
        for key, value in params.items():
            setattr(param, key, value)
        canvas = types.SimpleNamespace(_doc_id="doc", _tenant_id="tenant")
        chunker = component_module.TitleChunker(canvas, "TitleChunker:cap", param)
        asyncio.run(chunker.invoke(name="cap-test", output_format="json", json=items))
        error = chunker.output("_ERROR")
        assert not error, f"the TitleChunker component reported an error: {error}"
        return chunker.output("chunks") or []


# [page, left, right, top, bottom] per row, in reading order: one passage that
# starts near the bottom of page 1 and runs onto page 2.
SOURCE_ROWS = [[1, 72, 540, 520, 760], [2, 72, 540, 40, 210], [2, 72, 540, 220, 330]]
_TOL = 1.0


def _pdf_item(text):
    """A text item as the parser writes it: the same rows under both keys."""
    return {
        "text": text,
        "doc_type_kwd": "text",
        "positions": [list(row) for row in SOURCE_ROWS],
        "_pdf_positions": [list(row) for row in SOURCE_ROWS],
    }


def _inside(row, source_rows):
    """True when a region row lies inside the passage's outline on its page:
    the box the source rows on that page span."""
    if not isinstance(row, (list, tuple)) or len(row) < 5 or row[4] < row[3]:
        return False
    page = [src for src in source_rows if src[0] == row[0]]
    if not page:
        return False
    return (
        row[1] >= min(src[1] for src in page) - _TOL
        and row[2] <= max(src[2] for src in page) + _TOL
        and row[3] >= min(src[3] for src in page) - _TOL
        and row[4] <= max(src[4] for src in page) + _TOL
    )


def _check_piece_regions(chunks, source_rows):
    """The region rule from the module docstring, on the emitted position_int."""
    assert len(chunks) >= 3, f"expected the over-cap passage to split into 3 or more pieces, got {len(chunks)}"
    first, last = source_rows[0], source_rows[-1]
    reached = [False] * len(source_rows)
    for i, ck in enumerate(chunks):
        rows = ck.get("position_int") or []
        assert rows, f"piece {i} of {len(chunks)} carries no page region, so it gets no preview and no highlight"
        for row in rows:
            assert _inside(row, source_rows), f"piece {i} region row {row!r} is not inside the source passage {source_rows!r}"
            for j, src in enumerate(source_rows):
                if row[0] == src[0] and row[3] < src[4] and row[4] > src[3]:
                    reached[j] = True
        if i == 0:
            assert any(row[0] == first[0] and abs(row[3] - first[3]) <= _TOL for row in rows), (
                f"the first piece's region {rows!r} does not reach the top of the passage {first!r}"
            )
        if i == len(chunks) - 1:
            assert any(row[0] == last[0] and abs(row[4] - last[4]) <= _TOL for row in rows), (
                f"the last piece's region {rows!r} does not reach the bottom of the passage {last!r}"
            )
    missing = [src for src, ok in zip(source_rows, reached) if not ok]
    assert not missing, f"no piece points at source row(s) {missing!r}"


@pytest.mark.parametrize(
    "method,extra",
    [("hierarchy", {}), ("group", {"hierarchy": 0})],
    ids=["hierarchy", "group"],
)
def test_every_subchunk_keeps_a_page_region(method, extra):
    """Every cap-split piece keeps a page region inside its passage.

    A piece that reaches the preview pass without coordinates is skipped, so
    it gets no preview image and no highlight.
    """
    body = "。".join(f"S{i:02d}" for i in range(18)) + "。"  # 72 characters, cap 20 -> 4 pieces
    chunks = _run(method, [_pdf_item(body)], levels=[], chunk_token_cap=20, **extra)
    _check_piece_regions(chunks, SOURCE_ROWS)


_STRETCH_TOL = 0.05  # of the passage's stacked height


def _stack(page, y, source_rows):
    """Place a height y on a page onto the passage's stacked height (source rows
    laid end to end in reading order); a y in the gap between two rows of the
    page lands on the boundary between them."""
    off, end = 0.0, None
    for src in source_rows:
        if src[0] == page:
            if y <= src[3]:
                return off
            if y <= src[4]:
                return off + (y - src[3])
            end = off + src[4] - src[3]
        off += src[4] - src[3]
    return off if end is None else end


def _stacked_span(row, source_rows):
    """Place a region row on the passage's stacked height; None when it is not
    inside the passage's outline on its page."""
    if not _inside(row, source_rows):
        return None
    return _stack(row[0], row[3], source_rows), _stack(row[0], row[4], source_rows)


def _uncovered(spans, lo, hi):
    """How much of [lo, hi) the spans leave out."""
    if hi <= lo:
        return 0.0
    gap, at = 0.0, lo
    for start, end in sorted(spans):
        if end <= at:
            continue
        if start > at:
            gap += min(start, hi) - at
        at = max(at, end)
        if at >= hi:
            return gap
    return gap + (hi - at)


def _check_own_stretch(chunks, source_rows):
    """The stretch rule from the module docstring, on the emitted position_int."""
    assert len(chunks) >= 4, f"expected the over-cap passage to split into 4 or more pieces, got {len(chunks)}"
    height = sum(src[4] - src[3] for src in source_rows)
    lens = [len(ck.get("text") or "") for ck in chunks]
    total = float(sum(lens))
    tol, cum = _STRETCH_TOL * height, 0.0
    for i, ck in enumerate(chunks):
        want0, want1 = cum / total * height, (cum + lens[i]) / total * height
        cum += lens[i]
        rows = ck.get("position_int") or []
        assert rows, f"piece {i} of {len(chunks)} carries no page region"
        spans = []
        for row in rows:
            span = _stacked_span(row, source_rows)
            assert span is not None, f"piece {i} region row {row!r} is not inside the source passage {source_rows!r}"
            assert span[0] >= want0 - tol and span[1] <= want1 + tol, (
                f"piece {i} shows {span[0]:.0f}-{span[1]:.0f} of the passage's {height:.0f} stacked points; "
                f"its own text sits at {want0:.0f}-{want1:.0f}"
            )
            spans.append(span)
        miss = _uncovered(spans, want0 + tol, want1 - tol)
        assert miss <= 0.5, f"piece {i} leaves {miss:.0f} points of its own stretch {want0:.0f}-{want1:.0f} out of its region {rows!r}"


@pytest.mark.parametrize(
    "method,extra",
    [("hierarchy", {}), ("group", {"hierarchy": 0})],
    ids=["hierarchy", "group"],
)
def test_every_subchunk_shows_its_own_stretch(method, extra):
    """Each cap-split piece shows just the stretch of the passage its own text
    takes up, in reading order, not the whole passage."""
    body = "。".join(f"S{i:02d}" for i in range(16)) + "。"  # 64 characters, cap 20 -> 20, 20, 20, 5
    chunks = _run(method, [_pdf_item(body)], levels=[], chunk_token_cap=20, **extra)
    _check_own_stretch(chunks, SOURCE_ROWS)


def test_split_is_lossless_and_respects_cap():
    """Guard: the concatenated sub-chunk text reproduces the source exactly and
    every sub-chunk stays within the cap."""
    body = "。".join(f"S{i:02d}" for i in range(12)) + "。"
    items = [{"text": body, "doc_type_kwd": "text"}]
    chunks = _run("hierarchy", items, levels=[], chunk_token_cap=20)

    assert len(chunks) > 1, "expected the oversized chunk to split into >1 sub-chunk"
    for ck in chunks:
        assert len(ck["text"] or "") <= 20, f"sub-chunk exceeds cap: {ck['text']!r}"
    assert "".join(ck["text"] for ck in chunks).rstrip("\n") == body, "split is not lossless"


def test_non_text_chunk_is_atomic():
    """Guard: a table chunk stays one chunk with its text unchanged, whatever
    its size."""
    big_table = "x" * 200
    items = [{"text": big_table, "doc_type_kwd": "table"}]
    chunks = _run("hierarchy", items, levels=[], chunk_token_cap=20)

    assert len(chunks) == 1, "a non-text chunk must stay atomic"
    assert chunks[0]["doc_type_kwd"] == "table"
    assert chunks[0]["text"] == big_table
