"""Behavioral verifier for the Python title-chunker cap split.

Runs the title chunker strategies (hierarchy for the book pipeline, group for
the paper pipeline) end to end on a passage longer than chunk_token_cap and
reads the emitted chunks. The passage carries a three-row page-region matrix
that starts near the bottom of page 1 and runs onto page 2. Every emitted piece
must carry a non-empty region whose rows sit inside the source rows, the first
piece reaching the top of the passage and the last its bottom, with every
source row reached by some piece. Every piece carrying the whole source region
passes, and so does each piece carrying its own share of it (a vertical slice,
or a subset of the rows).

Self-contained: it installs lightweight stubs for the repo's heavy imports (the
same technique the repo's own in-tree test uses) and drives the chunker through
its invoke() entry, so it runs on a bare Python 3.12 + pytest with no repo
dependency closure. It imports no solution-specific symbols and asserts only on
the chunks the chunker emits.
"""

import asyncio
import importlib
import importlib.util
import os
import sys
import types
from contextlib import contextmanager
from pathlib import Path

import pytest


def _repo_root() -> Path:
    """Resolve the ragflow repo root inside the task container.

    The Python runner runs pytest with cwd set to the repo dir; prefer that
    when it looks like the repo, else fall back to the known container path.
    """
    candidates = []
    env_root = os.environ.get("REPO_DIR") or os.environ.get("REPO_ROOT")
    if env_root:
        candidates.append(Path(env_root))
    candidates.append(Path.cwd())
    candidates.append(Path("/repo/ragflow"))
    for cand in candidates:
        if (cand / "rag" / "flow" / "chunker" / "title_chunker" / "common.py").is_file():
            return cand
    # Last resort: the documented container path (lets the import error be loud).
    return Path("/repo/ragflow")


@contextmanager
def _load_title_chunker_with_stubs():
    root = _repo_root()
    original_modules = {}

    def _install(name: str, module: types.ModuleType):
        original_modules.setdefault(name, sys.modules.get(name))
        sys.modules[name] = module

    try:
        rag_pkg = types.ModuleType("rag")
        rag_pkg.__path__ = [str(root / "rag")]
        _install("rag", rag_pkg)

        rag_flow_pkg = types.ModuleType("rag.flow")
        rag_flow_pkg.__package__ = "rag"
        rag_flow_pkg.__path__ = [str(root / "rag" / "flow")]
        _install("rag.flow", rag_flow_pkg)

        rag_flow_chunker_pkg = types.ModuleType("rag.flow.chunker")
        rag_flow_chunker_pkg.__package__ = "rag.flow"
        rag_flow_chunker_pkg.__path__ = [str(root / "rag" / "flow" / "chunker")]
        _install("rag.flow.chunker", rag_flow_chunker_pkg)

        rag_flow_parser_pkg = types.ModuleType("rag.flow.parser")
        rag_flow_parser_pkg.__package__ = "rag.flow"
        rag_flow_parser_pkg.__path__ = [str(root / "rag" / "flow" / "parser")]
        _install("rag.flow.parser", rag_flow_parser_pkg)

        common_pkg = types.ModuleType("common")
        common_pkg.__path__ = [str(root / "common")]
        _install("common", common_pkg)

        common_float_utils = types.ModuleType("common.float_utils")
        common_float_utils.normalize_overlapped_percent = lambda value: value
        _install("common.float_utils", common_float_utils)

        # Deterministic tokenizer: 1 token per character. ``truncate`` mirrors
        # token_utils.truncate semantics (prefix bounded by max_len tokens).
        common_token_utils = types.ModuleType("common.token_utils")
        common_token_utils.num_tokens_from_string = lambda text: len(text or "")
        common_token_utils.truncate = lambda text, max_len: (text or "")[:max_len]
        _install("common.token_utils", common_token_utils)

        rag_nlp = types.ModuleType("rag.nlp")
        rag_nlp.naive_merge = lambda *args, **kwargs: []
        rag_nlp.not_bullet = lambda text: False
        rag_nlp.not_title = lambda text: True
        _install("rag.nlp", rag_nlp)

        deepdoc_pkg = types.ModuleType("deepdoc")
        deepdoc_pkg.__path__ = [str(root / "deepdoc")]
        _install("deepdoc", deepdoc_pkg)

        deepdoc_parser_pkg = types.ModuleType("deepdoc.parser")
        deepdoc_parser_pkg.__path__ = [str(root / "deepdoc" / "parser")]
        _install("deepdoc.parser", deepdoc_parser_pkg)

        class _RAGFlowPdfParser:
            @staticmethod
            def remove_tag(text):
                return text

            @staticmethod
            def extract_positions(tag):
                return []

        deepdoc_pdf_parser = types.ModuleType("deepdoc.parser.pdf_parser")
        deepdoc_pdf_parser.RAGFlowPdfParser = _RAGFlowPdfParser
        _install("deepdoc.parser.pdf_parser", deepdoc_pdf_parser)

        deepdoc_parser_utils = types.ModuleType("deepdoc.parser.utils")
        deepdoc_parser_utils.extract_pdf_outlines = lambda *args, **kwargs: []
        _install("deepdoc.parser.utils", deepdoc_parser_utils)

        class ProcessParamBase:
            def __init__(self):
                pass

            def check_valid_value(self, value, msg, allowed):
                if value not in allowed:
                    raise ValueError(msg)

            def check_positive_integer(self, value, msg):
                if not (isinstance(value, int) and value > 0):
                    raise ValueError(msg)

            def check_decimal_float(self, value, msg):
                pass

            def check_nonnegative_number(self, value, msg):
                pass

            def check_empty(self, value, msg):
                pass

        class ProcessBase:
            def __init__(self, _pipeline, _id, param):
                self._pipeline = _pipeline
                self._id = _id
                self._param = param
                self._outputs = {}
                self.callback = lambda *_args, **_kwargs: None

            def set_output(self, key, value):
                self._outputs[key] = value

        rag_flow_base = types.ModuleType("rag.flow.base")
        rag_flow_base.ProcessBase = ProcessBase
        rag_flow_base.ProcessParamBase = ProcessParamBase
        _install("rag.flow.base", rag_flow_base)

        pdf_chunk_metadata = types.ModuleType("rag.flow.parser.pdf_chunk_metadata")
        pdf_chunk_metadata.PDF_POSITIONS_KEY = "pdf_positions"
        pdf_chunk_metadata.extract_pdf_positions = lambda _item: []
        pdf_chunk_metadata.merge_pdf_positions = lambda _records: []
        pdf_chunk_metadata.finalize_pdf_chunk = lambda chunk: chunk

        async def _noop_restore(*_a, **_k):
            return None

        pdf_chunk_metadata.restore_pdf_text_previews = _noop_restore
        _install("rag.flow.parser.pdf_chunk_metadata", pdf_chunk_metadata)

        common_spec = importlib.util.spec_from_file_location(
            "rag.flow.chunker.title_chunker.common",
            root / "rag" / "flow" / "chunker" / "title_chunker" / "common.py",
        )
        common_module = importlib.util.module_from_spec(common_spec)
        _install("rag.flow.chunker.title_chunker.common", common_module)
        common_spec.loader.exec_module(common_module)

        hierarchy_spec = importlib.util.spec_from_file_location(
            "rag.flow.chunker.title_chunker.hierarchy_chunker",
            root / "rag" / "flow" / "chunker" / "title_chunker" / "hierarchy_chunker.py",
        )
        hierarchy_module = importlib.util.module_from_spec(hierarchy_spec)
        _install("rag.flow.chunker.title_chunker.hierarchy_chunker", hierarchy_module)
        hierarchy_spec.loader.exec_module(hierarchy_module)

        group_spec = importlib.util.spec_from_file_location(
            "rag.flow.chunker.title_chunker.group_chunker",
            root / "rag" / "flow" / "chunker" / "title_chunker" / "group_chunker.py",
        )
        group_module = importlib.util.module_from_spec(group_spec)
        _install("rag.flow.chunker.title_chunker.group_chunker", group_module)
        group_spec.loader.exec_module(group_module)

        yield common_module, hierarchy_module, group_module
    finally:
        for module_name, original in original_modules.items():
            if original is None:
                sys.modules.pop(module_name, None)
            else:
                sys.modules[module_name] = original


# Faithful page-region helpers: map the source `positions`/`pdf_positions`
# payload onto `position_int` the way the real metadata pass does, so the
# end-to-end pipeline assertion sees what the on-demand preview pass would read.
def _real_extract_pdf_positions(item):
    if not isinstance(item, dict):
        return []
    positions = item.get("pdf_positions")
    if isinstance(positions, list):
        return [list(p) for p in positions]
    positions = item.get("positions")
    if isinstance(positions, list):
        return [list(p) for p in positions]
    return []


def _real_merge_pdf_positions(records):
    merged = []
    for rec in records or []:
        if not isinstance(rec, dict):
            continue
        for pos in rec.get("pdf_positions") or []:
            if isinstance(pos, (list, tuple)) and len(pos) >= 5:
                merged.append([pos[0], pos[1], pos[2], pos[3], pos[4]])
    seen = set()
    out = []
    for pos in merged:
        key = tuple(pos[:5])
        if key not in seen:
            seen.add(key)
            out.append(pos)
    return out


def _real_finalize_pdf_chunk(chunk):
    positions = _real_extract_pdf_positions(chunk)
    if positions:
        chunk["position_int"] = [list(p) for p in positions]
        chunk.pop("pdf_positions", None)
    return chunk


def _run(method, from_upstream, **param_kwargs):
    with _load_title_chunker_with_stubs() as (common_module, hierarchy_module, group_module):
        if param_kwargs.pop("faithful_positions", False):
            common_module.extract_pdf_positions = _real_extract_pdf_positions
            common_module.merge_pdf_positions = _real_merge_pdf_positions
            common_module.finalize_pdf_chunk = _real_finalize_pdf_chunk

        param = common_module.TitleChunkerParam()
        param.method = method
        param.chunk_token_cap = param_kwargs.pop("chunk_token_cap", 512)
        for key, value in param_kwargs.items():
            setattr(param, key, value)

        process = common_module.ProcessBase(None, "title_chunker", param)
        process._canvas = types.SimpleNamespace(_doc_id="doc", _tenant_id="tenant")
        process._outputs = {}

        if method == "hierarchy":
            chunker = hierarchy_module.HierarchyTitleChunker(process, from_upstream)
        else:
            chunker = group_module.GroupTitleChunker(process, from_upstream)
        asyncio.run(chunker.invoke())
        return process._outputs.get("chunks", [])


def _json_upstream(items, output_format="json"):
    return types.SimpleNamespace(
        output_format=output_format,
        json_result=items if output_format == "json" else None,
        markdown_result=None,
        text_result=None,
        html_result=None,
        chunks=None if output_format == "json" else items,
        file=None,
        name="cap-test",
    )


# [page, left, right, top, bottom] per row, in reading order: one passage that
# starts near the bottom of page 1 and runs onto page 2.
SOURCE_ROWS = [[1, 72, 540, 520, 760], [2, 72, 540, 40, 210], [2, 72, 540, 220, 330]]
_TOL = 1.0


def _inside(row, source_rows):
    if not isinstance(row, (list, tuple)) or len(row) < 5 or row[4] < row[3]:
        return False
    return any(
        row[0] == src[0]
        and row[1] >= src[1] - _TOL
        and row[2] <= src[2] + _TOL
        and row[3] >= src[3] - _TOL
        and row[4] <= src[4] + _TOL
        for src in source_rows
    )


def _check_piece_regions(chunks, source_rows):
    """The region rule from the module docstring, on the emitted position_int."""
    assert len(chunks) >= 3, f"expected the over-cap passage to split into 3 or more pieces, got {len(chunks)}"
    first, last = source_rows[0], source_rows[-1]
    reached = [False] * len(source_rows)
    for i, ck in enumerate(chunks):
        rows = ck.get("position_int") or []
        assert rows, f"piece {i} of {len(chunks)} carries no page region, so it gets no preview and no highlight"
        for row in rows:
            assert _inside(row, source_rows), f"piece {i} region row {row!r} is not inside any row of the source passage {source_rows!r}"
            for j, src in enumerate(source_rows):
                if row[0] == src[0] and row[3] < src[4] and row[4] > src[3]:
                    reached[j] = True
        if i == 0:
            assert any(row[0] == first[0] and abs(row[3] - first[3]) <= _TOL for row in rows), (
                f"the first piece's region {rows!r} does not reach the top of the passage {first!r}"
            )
        if i == len(chunks) - 1:
            assert any(row[0] == last[0] and abs(row[4] - last[4]) <= _TOL for row in rows), (
                f"the last piece's region {rows!r} does not reach the bottom of the passage {last!r}"
            )
    missing = [src for src, ok in zip(source_rows, reached) if not ok]
    assert not missing, f"no piece points at source row(s) {missing!r}"


@pytest.mark.parametrize(
    "method,extra",
    [("hierarchy", {}), ("group", {"hierarchy": 0})],
    ids=["hierarchy", "group"],
)
def test_every_subchunk_keeps_a_page_region(method, extra):
    """Every cap-split piece keeps a page region inside its passage.

    A piece that reaches the preview pass without coordinates is skipped, so
    it gets no preview image and no highlight.
    """
    body = "。".join(f"S{i:02d}" for i in range(18)) + "。"  # 72 characters, cap 20 -> 4 pieces
    items = [{"text": body, "doc_type_kwd": "text", "positions": SOURCE_ROWS}]
    chunks = _run(
        method,
        _json_upstream(items),
        levels=[],
        chunk_token_cap=20,
        faithful_positions=True,
        **extra,
    )
    _check_piece_regions(chunks, SOURCE_ROWS)


def test_split_is_lossless_and_respects_cap():
    """Guard: the split itself is unchanged — the concatenated sub-chunk text
    reproduces the source exactly and every sub-chunk stays within the cap.

    It holds before and after the change, so whatever restores the page
    regions must leave the sentence/boundary splitting alone.
    """
    body = "。".join(f"S{i:02d}" for i in range(12)) + "。"
    items = [{"text": body, "doc_type_kwd": "text"}]
    chunks = _run("hierarchy", _json_upstream(items), levels=[], chunk_token_cap=20)

    assert len(chunks) > 1, "expected the oversized chunk to split into >1 sub-chunk"
    for ck in chunks:
        assert len(ck["text"] or "") <= 20, f"sub-chunk exceeds cap: {ck['text']!r}"
    assert "".join(ck["text"] for ck in chunks).rstrip("\n") == body, "split is not lossless"


def test_non_text_chunk_is_atomic():
    """Guard: table/image chunks are atomic and never split, regardless of size.

    It holds before and after the change.
    """
    big_table = "x" * 200
    items = [{"text": big_table, "doc_type_kwd": "table"}]
    chunks = _run("hierarchy", _json_upstream(items), levels=[], chunk_token_cap=20)

    assert len(chunks) == 1, "a non-text chunk must stay atomic"
    assert chunks[0]["doc_type_kwd"] == "table"
    assert chunks[0]["text"] == big_table
