package chunker

// Behavioral verifier for the title-family cap split on the Go side (the
// TitleChunker component behind the built-in book and paper pipelines).
//
// Each test runs the exported TitleChunker component (NewTitleChunker +
// Invoke, the entry the pipelines use) on one passage longer than
// chunk_token_cap. The passage carries a three-row page-region matrix that
// starts near the bottom of page 1 and runs onto page 2. The on-demand preview
// crop and the highlight index read only that matrix, so the checks look at
// what each resulting piece carries:
//   - a non-empty region, so the piece is cropped and highlighted at all;
//   - every row inside one of the source rows (same page, inside its box), so
//     no piece points outside the passage it came from;
//   - the first piece reaching the top of the passage and the last piece
//     reaching its bottom, and every source row reached by some piece.
// Every piece carrying the whole source matrix passes, and so does each piece
// carrying its own share of it (a vertical slice, or a subset of the rows).
//
// Tokens are counted by the real tokenizer (the image bakes its BPE table), so
// the cap is the production minimum of 128. Self-contained: it builds its own
// fixtures, and its helpers carry a vtc prefix so they cannot collide with the
// package's or a solution's own test helpers.

import (
	"context"
	"encoding/json"
	"fmt"
	"math"
	"strings"
	"testing"

	"ragflow/internal/tokenizer"
)

const (
	vtcCap = 128
	vtcTol = 1.0
)

// vtcSourceRows is [page, left, right, top, bottom] per row, in reading order.
var vtcSourceRows = [][]float64{
	{1, 72, 540, 520, 760},
	{2, 72, 540, 40, 210},
	{2, 72, 540, 220, 330},
}

// vtcBody is one passage of 30 distinct sentences, several times the cap.
func vtcBody() string {
	parts := make([]string, 0, 30)
	for i := 0; i < 30; i++ {
		parts = append(parts, fmt.Sprintf("Survey note %02d records how the field team measured the north bank after the spring flood.", i))
	}
	return strings.Join(parts, " ")
}

func vtcInvoke(t *testing.T, method string, capTokens int, item map[string]any) []map[string]any {
	t.Helper()
	params := map[string]any{
		"method":          method,
		"levels":          []any{[]any{"^# "}},
		"chunk_token_cap": capTokens,
	}
	if method == "hierarchy" {
		params["hierarchy"] = 1
	}
	comp, err := NewTitleChunker(params)
	if err != nil {
		t.Fatalf("NewTitleChunker(%s): %v", method, err)
	}
	out, err := comp.Invoke(context.Background(), nil, map[string]any{
		"name":          "survey.pdf",
		"output_format": "json",
		"json":          []map[string]any{item},
	})
	if err != nil {
		t.Fatalf("TitleChunker(%s).Invoke: %v", method, err)
	}
	if msg, _ := out["_ERROR"].(string); msg != "" {
		t.Fatalf("TitleChunker(%s) error payload: %s", method, msg)
	}
	chunks, _ := out["chunks"].([]map[string]any)
	return chunks
}

// vtcRowsOf reads a position value whatever its in-memory shape
// ([][]float64, raw JSON, or a generic decoded slice).
func vtcRowsOf(v any) ([][]float64, bool) {
	if v == nil {
		return nil, false
	}
	var raw []byte
	switch x := v.(type) {
	case [][]float64:
		return x, true
	case json.RawMessage:
		raw = x
	case []byte:
		raw = x
	case string:
		raw = []byte(x)
	default:
		b, err := json.Marshal(x)
		if err != nil {
			return nil, false
		}
		raw = b
	}
	var rows [][]float64
	if err := json.Unmarshal(raw, &rows); err != nil {
		return nil, false
	}
	return rows, true
}

func vtcInside(r []float64, src [][]float64) bool {
	if len(r) < 5 || r[4] < r[3] {
		return false
	}
	for _, s := range src {
		if r[0] == s[0] && r[1] >= s[1]-vtcTol && r[2] <= s[2]+vtcTol &&
			r[3] >= s[3]-vtcTol && r[4] <= s[4]+vtcTol {
			return true
		}
	}
	return false
}

// vtcCheckRegions applies the region rule (file header) to the pieces of one
// passage under one position key.
func vtcCheckRegions(t *testing.T, label string, chunks []map[string]any, key string, src [][]float64) {
	t.Helper()
	if len(chunks) < 3 {
		t.Fatalf("%s: want the over-cap passage split into 3 or more pieces, got %d", label, len(chunks))
	}
	first, last := src[0], src[len(src)-1]
	reached := make([]bool, len(src))
	for i, ck := range chunks {
		rows, ok := vtcRowsOf(ck[key])
		if !ok || len(rows) == 0 {
			t.Errorf("%s: piece %d of %d carries no page region under %q (%#v), so it gets no preview and no highlight",
				label, i, len(chunks), key, ck[key])
			continue
		}
		startsPassage, endsPassage := false, false
		for _, r := range rows {
			if !vtcInside(r, src) {
				t.Errorf("%s: piece %d region row %v is not inside any row of the source passage %v", label, i, r, src)
				continue
			}
			for j, s := range src {
				if r[0] == s[0] && r[3] < s[4] && r[4] > s[3] {
					reached[j] = true
				}
			}
			if r[0] == first[0] && math.Abs(r[3]-first[3]) <= vtcTol {
				startsPassage = true
			}
			if r[0] == last[0] && math.Abs(r[4]-last[4]) <= vtcTol {
				endsPassage = true
			}
		}
		if i == 0 && !startsPassage {
			t.Errorf("%s: the first piece's region %v does not reach the top of the passage %v", label, rows, first)
		}
		if i == len(chunks)-1 && !endsPassage {
			t.Errorf("%s: the last piece's region %v does not reach the bottom of the passage %v", label, rows, last)
		}
	}
	for j, ok := range reached {
		if !ok {
			t.Errorf("%s: no piece points at source row %v", label, src[j])
		}
	}
}

// TestVerifyTitleCap_HierarchyPiecesKeepRegion: the book pipeline's method
// (hierarchy), positions under the "positions" key.
func TestVerifyTitleCap_HierarchyPiecesKeepRegion(t *testing.T) {
	item := map[string]any{"text": vtcBody(), "doc_type_kwd": "text", "positions": vtcSourceRows}
	chunks := vtcInvoke(t, "hierarchy", vtcCap, item)
	vtcCheckRegions(t, "hierarchy", chunks, "positions", vtcSourceRows)
}

// TestVerifyTitleCap_GroupPiecesKeepRegion: the paper pipeline's method
// (group), positions under the "_pdf_positions" key.
func TestVerifyTitleCap_GroupPiecesKeepRegion(t *testing.T) {
	item := map[string]any{"text": vtcBody(), "doc_type_kwd": "text", "_pdf_positions": vtcSourceRows}
	chunks := vtcInvoke(t, "group", vtcCap, item)
	vtcCheckRegions(t, "group", chunks, "_pdf_positions", vtcSourceRows)
}

// TestVerifyTitleCap_SplitKeepsTextAndCap guards the split itself, before
// and after the change alike: the pieces joined reproduce the passage
// the uncapped chunker emits, and every piece stays within the cap.
func TestVerifyTitleCap_SplitKeepsTextAndCap(t *testing.T) {
	if tokenizer.NumTokensFromString("survey note") <= 0 {
		t.Fatalf("the tokenizer counted no tokens; its BPE table is missing")
	}
	for _, method := range []string{"hierarchy", "group"} {
		item := map[string]any{"text": vtcBody(), "doc_type_kwd": "text", "positions": vtcSourceRows}
		whole := vtcInvoke(t, method, 0, item)
		if len(whole) != 1 {
			t.Fatalf("%s: with the cap off, want 1 chunk, got %d", method, len(whole))
		}
		want, _ := whole[0]["text"].(string)
		pieces := vtcInvoke(t, method, vtcCap, item)
		if len(pieces) < 3 {
			t.Fatalf("%s: want 3 or more pieces under cap %d, got %d", method, vtcCap, len(pieces))
		}
		var joined strings.Builder
		for i, ck := range pieces {
			text, _ := ck["text"].(string)
			joined.WriteString(text)
			if n := tokenizer.NumTokensFromString(text); n > vtcCap {
				t.Errorf("%s: piece %d has %d tokens, over the cap of %d", method, i, n, vtcCap)
			}
		}
		if joined.String() != want {
			t.Errorf("%s: the pieces joined do not reproduce the passage:\n got=%q\nwant=%q", method, joined.String(), want)
		}
	}
}
