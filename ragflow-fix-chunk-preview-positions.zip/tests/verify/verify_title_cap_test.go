package chunker

// Behavioral verifier for the title-family cap split on the Go side (the
// TitleChunker component behind the built-in book and paper pipelines).
//
// Each test runs the exported TitleChunker component (NewTitleChunker +
// Invoke, the entry the pipelines use) on one passage longer than
// chunk_token_cap. The passage arrives the way the PDF parser writes an item:
// one three-row page-region matrix under both "_pdf_positions" and
// "positions", starting near the bottom of page 1 and running onto page 2.
// Two readers use the matrices a piece carries: the preview crop reads
// _pdf_positions, or positions when the piece has no _pdf_positions, and the
// highlight index is built from positions alone. Every region and stretch
// check runs on both readings:
//   - region: the piece carries a non-empty region, every row inside the
//     passage's outline on its page (the box the passage's rows on that page
//     span), the first piece reaching the top of the passage and the last its
//     bottom, and every source row reached by some piece;
//   - stretch (*ShowOwnStretch): laid end to end in reading order, the source
//     rows form one stretch of height H, and a piece holding the share [a, b)
//     of the passage's text (by rune count) owns [a*H, b*H) of it. Within 5% of
//     H both ways, the piece's region must cover that stretch and stay inside
//     it. A box that spans two rows of one page counts as the stretch it spans,
//     the gap between the rows adding nothing.
// The guard checks that the pieces joined reproduce the passage the uncapped
// chunker emits and that every piece stays within the cap.
//
// Tokens are counted by the real tokenizer (the image bakes its BPE table), so
// the cap is the production minimum of 128. Self-contained: it builds its own
// fixtures, and its helpers carry a vtc prefix to keep clear of other names in
// the package.

import (
	"context"
	"encoding/json"
	"fmt"
	"math"
	"sort"
	"strings"
	"testing"
	"unicode/utf8"

	"ragflow/internal/tokenizer"
)

const (
	vtcCap = 128
	vtcTol = 1.0
)

// vtcSourceRows is [page, left, right, top, bottom] per row, in reading order.
var vtcSourceRows = [][]float64{
	{1, 72, 540, 520, 760},
	{2, 72, 540, 40, 210},
	{2, 72, 540, 220, 330},
}

// vtcMatrix is a fresh copy of the source rows.
func vtcMatrix() [][]float64 {
	m := make([][]float64, len(vtcSourceRows))
	for i, r := range vtcSourceRows {
		m[i] = append([]float64(nil), r...)
	}
	return m
}

// vtcItem is one text item as the PDF parser writes it: the same matrix under
// both position keys.
func vtcItem(text string) map[string]any {
	m := vtcMatrix()
	return map[string]any{"text": text, "doc_type_kwd": "text", "_pdf_positions": m, "positions": m}
}

// vtcBody is one passage of 30 distinct sentences, several times the cap.
func vtcBody() string {
	parts := make([]string, 0, 30)
	for i := 0; i < 30; i++ {
		parts = append(parts, fmt.Sprintf("Survey note %02d records how the field team measured the north bank after the spring flood.", i))
	}
	return strings.Join(parts, " ")
}

func vtcInvoke(t *testing.T, method string, capTokens int, item map[string]any) []map[string]any {
	t.Helper()
	params := map[string]any{
		"method":          method,
		"levels":          []any{[]any{"^# "}},
		"chunk_token_cap": capTokens,
	}
	if method == "hierarchy" {
		params["hierarchy"] = 1
	}
	comp, err := NewTitleChunker(params)
	if err != nil {
		t.Fatalf("NewTitleChunker(%s): %v", method, err)
	}
	out, err := comp.Invoke(context.Background(), nil, map[string]any{
		"name":          "survey.pdf",
		"output_format": "json",
		"json":          []map[string]any{item},
	})
	if err != nil {
		t.Fatalf("TitleChunker(%s).Invoke: %v", method, err)
	}
	if msg, _ := out["_ERROR"].(string); msg != "" {
		t.Fatalf("TitleChunker(%s) error payload: %s", method, msg)
	}
	chunks, _ := out["chunks"].([]map[string]any)
	return chunks
}

// vtcRowsOf reads a position value whatever its in-memory shape
// ([][]float64, raw JSON, or a generic decoded slice).
func vtcRowsOf(v any) ([][]float64, bool) {
	if v == nil {
		return nil, false
	}
	var raw []byte
	switch x := v.(type) {
	case [][]float64:
		return x, true
	case json.RawMessage:
		raw = x
	case []byte:
		raw = x
	case string:
		raw = []byte(x)
	default:
		b, err := json.Marshal(x)
		if err != nil {
			return nil, false
		}
		raw = b
	}
	var rows [][]float64
	if err := json.Unmarshal(raw, &rows); err != nil {
		return nil, false
	}
	return rows, true
}

// vtcReading is one reader of the matrices a piece carries.
type vtcReading struct {
	name string
	rows func(ck map[string]any) ([][]float64, bool)
}

// vtcReadings: the preview crop reads _pdf_positions, or positions when the
// piece has no _pdf_positions (cropImageChunks); the highlight index reads
// positions alone (processChunkPositions).
var vtcReadings = []vtcReading{
	{"preview", func(ck map[string]any) ([][]float64, bool) {
		if v, ok := ck["_pdf_positions"]; ok {
			return vtcRowsOf(v)
		}
		return vtcRowsOf(ck["positions"])
	}},
	{"highlight", func(ck map[string]any) ([][]float64, bool) {
		return vtcRowsOf(ck["positions"])
	}},
}

// vtcInside reports whether a region row lies inside the passage's outline on
// its page: the box the source rows on that page span.
func vtcInside(r []float64, src [][]float64) bool {
	if len(r) < 5 || r[4] < r[3] {
		return false
	}
	found := false
	var left, right, top, bottom float64
	for _, s := range src {
		if s[0] != r[0] {
			continue
		}
		if !found {
			left, right, top, bottom, found = s[1], s[2], s[3], s[4], true
			continue
		}
		left, right = math.Min(left, s[1]), math.Max(right, s[2])
		top, bottom = math.Min(top, s[3]), math.Max(bottom, s[4])
	}
	return found && r[1] >= left-vtcTol && r[2] <= right+vtcTol && r[3] >= top-vtcTol && r[4] <= bottom+vtcTol
}

// vtcCheckRegions applies the region rule (file header) to the pieces of one
// passage under one reading.
func vtcCheckRegions(t *testing.T, label string, chunks []map[string]any, rd vtcReading, src [][]float64) {
	t.Helper()
	if len(chunks) < 3 {
		t.Fatalf("%s: want the over-cap passage split into 3 or more pieces, got %d", label, len(chunks))
	}
	first, last := src[0], src[len(src)-1]
	reached := make([]bool, len(src))
	for i, ck := range chunks {
		rows, ok := rd.rows(ck)
		if !ok || len(rows) == 0 {
			t.Errorf("%s %s: piece %d of %d carries no page region (_pdf_positions %#v, positions %#v)",
				label, rd.name, i, len(chunks), ck["_pdf_positions"], ck["positions"])
			continue
		}
		startsPassage, endsPassage := false, false
		for _, r := range rows {
			if !vtcInside(r, src) {
				t.Errorf("%s %s: piece %d region row %v is not inside the source passage %v", label, rd.name, i, r, src)
				continue
			}
			for j, s := range src {
				if r[0] == s[0] && r[3] < s[4] && r[4] > s[3] {
					reached[j] = true
				}
			}
			if r[0] == first[0] && math.Abs(r[3]-first[3]) <= vtcTol {
				startsPassage = true
			}
			if r[0] == last[0] && math.Abs(r[4]-last[4]) <= vtcTol {
				endsPassage = true
			}
		}
		if i == 0 && !startsPassage {
			t.Errorf("%s %s: the first piece's region %v does not reach the top of the passage %v", label, rd.name, rows, first)
		}
		if i == len(chunks)-1 && !endsPassage {
			t.Errorf("%s %s: the last piece's region %v does not reach the bottom of the passage %v", label, rd.name, rows, last)
		}
	}
	for j, ok := range reached {
		if !ok {
			t.Errorf("%s %s: no piece points at source row %v", label, rd.name, src[j])
		}
	}
}

// TestVerifyTitleCap_HierarchyPiecesKeepRegion: the book pipeline's method
// (hierarchy); every piece's preview and highlight regions follow the region
// rule.
func TestVerifyTitleCap_HierarchyPiecesKeepRegion(t *testing.T) {
	chunks := vtcInvoke(t, "hierarchy", vtcCap, vtcItem(vtcBody()))
	for _, rd := range vtcReadings {
		vtcCheckRegions(t, "hierarchy", chunks, rd, vtcSourceRows)
	}
}

// TestVerifyTitleCap_GroupPiecesKeepRegion: the same for the paper pipeline's
// method (group).
func TestVerifyTitleCap_GroupPiecesKeepRegion(t *testing.T) {
	chunks := vtcInvoke(t, "group", vtcCap, vtcItem(vtcBody()))
	for _, rd := range vtcReadings {
		vtcCheckRegions(t, "group", chunks, rd, vtcSourceRows)
	}
}

// TestVerifyTitleCap_SplitKeepsTextAndCap guards the split itself: the pieces
// joined reproduce the passage the uncapped chunker emits, and every piece
// stays within the cap.
func TestVerifyTitleCap_SplitKeepsTextAndCap(t *testing.T) {
	if tokenizer.NumTokensFromString("survey note") <= 0 {
		t.Fatalf("the tokenizer counted no tokens; its BPE table is missing")
	}
	for _, method := range []string{"hierarchy", "group"} {
		item := map[string]any{"text": vtcBody(), "doc_type_kwd": "text", "positions": vtcMatrix()}
		whole := vtcInvoke(t, method, 0, item)
		if len(whole) != 1 {
			t.Fatalf("%s: with the cap off, want 1 chunk, got %d", method, len(whole))
		}
		want, _ := whole[0]["text"].(string)
		pieces := vtcInvoke(t, method, vtcCap, item)
		if len(pieces) < 3 {
			t.Fatalf("%s: want 3 or more pieces under cap %d, got %d", method, vtcCap, len(pieces))
		}
		var joined strings.Builder
		for i, ck := range pieces {
			text, _ := ck["text"].(string)
			joined.WriteString(text)
			if n := tokenizer.NumTokensFromString(text); n > vtcCap {
				t.Errorf("%s: piece %d has %d tokens, over the cap of %d", method, i, n, vtcCap)
			}
		}
		if joined.String() != want {
			t.Errorf("%s: the pieces joined do not reproduce the passage:\n got=%q\nwant=%q", method, joined.String(), want)
		}
	}
}

// vtcStretchTol is the margin of the stretch tests, as a share of the
// passage's stacked height.
const vtcStretchTol = 0.05

// vtcStretchBody is one passage of 29 distinct sentences: under the cap it
// splits into four full pieces and a one-sentence last piece.
func vtcStretchBody() string {
	parts := make([]string, 0, 29)
	for i := 0; i < 29; i++ {
		parts = append(parts, fmt.Sprintf("Survey note %02d records how the field team measured the north bank after the spring flood.", i))
	}
	return strings.Join(parts, " ")
}

// vtcStack places a height y on page page onto the passage's stacked height:
// the source rows laid end to end in reading order. A y in the gap between two
// rows of the page lands on the boundary between them.
func vtcStack(page, y float64, src [][]float64) float64 {
	off, end := 0.0, -1.0
	for _, s := range src {
		if s[0] == page {
			if y <= s[3] {
				return off
			}
			if y <= s[4] {
				return off + (y - s[3])
			}
			end = off + s[4] - s[3]
		}
		off += s[4] - s[3]
	}
	if end >= 0 {
		return end
	}
	return off
}

// vtcSpan places a region row on the passage's stacked height. ok is false
// when the row is not inside the passage's outline on its page.
func vtcSpan(r []float64, src [][]float64) (lo, hi float64, ok bool) {
	if !vtcInside(r, src) {
		return 0, 0, false
	}
	return vtcStack(r[0], r[3], src), vtcStack(r[0], r[4], src), true
}

// vtcUncovered is how much of [lo, hi) the spans leave out.
func vtcUncovered(spans [][2]float64, lo, hi float64) float64 {
	if hi <= lo {
		return 0
	}
	sort.Slice(spans, func(i, j int) bool { return spans[i][0] < spans[j][0] })
	gap, at := 0.0, lo
	for _, sp := range spans {
		if sp[1] <= at {
			continue
		}
		if sp[0] > at {
			gap += math.Min(sp[0], hi) - at
		}
		at = math.Max(at, sp[1])
		if at >= hi {
			return gap
		}
	}
	return gap + (hi - at)
}

// vtcCheckOwnStretch applies the stretch rule (file header) to the pieces of
// one passage under one reading.
func vtcCheckOwnStretch(t *testing.T, label string, chunks []map[string]any, rd vtcReading, src [][]float64) {
	t.Helper()
	if len(chunks) < 4 {
		t.Fatalf("%s: want the over-cap passage split into 4 or more pieces, got %d", label, len(chunks))
	}
	height := 0.0
	for _, s := range src {
		height += s[4] - s[3]
	}
	lens, total := make([]float64, len(chunks)), 0.0
	for i, ck := range chunks {
		text, _ := ck["text"].(string)
		lens[i] = float64(utf8.RuneCountInString(text))
		total += lens[i]
	}
	tol, cum := vtcStretchTol*height, 0.0
	for i, ck := range chunks {
		want0, want1 := cum/total*height, (cum+lens[i])/total*height
		cum += lens[i]
		rows, ok := rd.rows(ck)
		if !ok || len(rows) == 0 {
			t.Errorf("%s %s: piece %d of %d carries no page region", label, rd.name, i, len(chunks))
			continue
		}
		spans := make([][2]float64, 0, len(rows))
		for _, r := range rows {
			lo, hi, ok := vtcSpan(r, src)
			if !ok {
				t.Errorf("%s %s: piece %d region row %v is not inside the source passage %v", label, rd.name, i, r, src)
				continue
			}
			if lo < want0-tol || hi > want1+tol {
				t.Errorf("%s %s: piece %d shows %.0f-%.0f of the passage's %.0f stacked points; its own text sits at %.0f-%.0f",
					label, rd.name, i, lo, hi, height, want0, want1)
			}
			spans = append(spans, [2]float64{lo, hi})
		}
		if miss := vtcUncovered(spans, want0+tol, want1-tol); miss > 0.5 {
			t.Errorf("%s %s: piece %d leaves %.0f points of its own stretch %.0f-%.0f out of its region %v",
				label, rd.name, i, miss, want0, want1, rows)
		}
	}
}

// TestVerifyTitleCap_HierarchyPiecesShowOwnStretch: each piece of a book-style
// (hierarchy) split shows, in its preview and in its highlight, just the
// stretch of the passage its own text takes up, in reading order.
func TestVerifyTitleCap_HierarchyPiecesShowOwnStretch(t *testing.T) {
	chunks := vtcInvoke(t, "hierarchy", vtcCap, vtcItem(vtcStretchBody()))
	for _, rd := range vtcReadings {
		vtcCheckOwnStretch(t, "hierarchy", chunks, rd, vtcSourceRows)
	}
}

// TestVerifyTitleCap_GroupPiecesShowOwnStretch: the same for a paper-style
// (group) split.
func TestVerifyTitleCap_GroupPiecesShowOwnStretch(t *testing.T) {
	chunks := vtcInvoke(t, "group", vtcCap, vtcItem(vtcStretchBody()))
	for _, rd := range vtcReadings {
		vtcCheckOwnStretch(t, "group", chunks, rd, vtcSourceRows)
	}
}
