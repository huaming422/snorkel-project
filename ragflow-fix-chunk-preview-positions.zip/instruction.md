## Task

We parse PDFs with the built-in book and paper methods and with our own ingestion pipelines that use the Title Chunker. A passage too long for one chunk comes out as several chunks in a row, and only the first of them has a page thumbnail in the chunk list. The ones after it have none, and clicking them doesn't jump to or highlight anything in the document, although their text is right. We run the hybrid deployment, and this happens on both the Go ingestor and the Python task executors. On the Go ingestor, the General method does the same when a single paragraph is long enough to be split.

Every piece should get its thumbnail and highlight back, showing the part of the document it came from, and should otherwise keep the same details as the first piece. Leave the chunk text as it is.
