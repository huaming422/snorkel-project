//! Export-time validation of serde shapes that cannot round-trip.
//!
//! Every test drives the public export surface that already exists in the
//! crate and reads nothing else:
//!
//!   * `specta_typescript::Typescript::default().export(&types, specta_serde::Format)`
//!     returns `Err` for a type whose serde attributes describe a shape serde
//!     cannot (de)serialize, and `Ok` otherwise.
//!   * `specta_serde::PhasesFormat` is the split serialize/deserialize variant.
//!     It is used where a shape is only live in one direction.
//!
//! The tests register plain derived types and look only at `Result::is_ok`,
//! `Result::is_err` and the `Display` text of the returned error. A rejection
//! is checked by a substring a user would read in the message: the word
//! "flatten", the existing "Unsupported serde attribute" wording, a field
//! path, or a type name. No module, function or error variant from the fix
//! is named anywhere in this file.

use std::collections::HashMap;
use std::marker::PhantomData;

use serde::{Deserialize, Serialize};
use specta::{Type, Types};
use specta_typescript::Typescript;

// A named-field struct is the canonical flattenable shape; reused as the valid
// inner payload throughout.
#[derive(Type, Serialize, Deserialize, Clone)]
#[specta(collect = false)]
struct Addr {
    id: i32,
}

// ---------------------------------------------------------------------------
// Flatten target validation: rejected shapes (sequence / tuple / scalar).
// ---------------------------------------------------------------------------

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenSeq {
    head: i32,
    #[serde(flatten)]
    extra: Vec<u8>,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenTuple {
    head: i32,
    #[serde(flatten)]
    extra: (u8, u8),
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenScalar {
    head: i32,
    #[serde(flatten)]
    extra: u32,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct PairPayload(i32, i32);

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenTupleStruct {
    head: i32,
    #[serde(flatten)]
    extra: PairPayload,
}

// A flattened field inside an enum variant's named fields is a field like any
// other; serde applies the same runtime rule to it.
#[derive(Type, Serialize)]
#[specta(collect = false)]
#[allow(dead_code)]
enum VariantFlattenSeq {
    Payload {
        head: i32,
        #[serde(flatten)]
        extra: Vec<u8>,
    },
}

#[test]
fn flatten_of_sequence_is_rejected() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<FlattenSeq>(),
            specta_serde::Format,
        )
        .expect_err("a flattened sequence cannot round-trip and must be rejected at export");
    let msg = err.to_string();
    assert!(msg.contains("flatten"), "error should mention flatten: {msg}");
    assert!(
        msg.contains(".extra"),
        "error should point at the offending field path: {msg}"
    );
}

#[test]
fn flatten_of_tuple_is_rejected() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<FlattenTuple>(),
            specta_serde::Format,
        )
        .expect_err("a flattened tuple serializes as a sequence and must be rejected");
    assert!(
        err.to_string().contains("flatten"),
        "unexpected error: {err}"
    );
}

#[test]
fn flatten_of_scalar_is_rejected() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<FlattenScalar>(),
            specta_serde::Format,
        )
        .expect_err("a flattened scalar cannot merge into the surrounding map");
    assert!(
        err.to_string().contains("flatten"),
        "unexpected error: {err}"
    );
}

#[test]
fn flatten_of_tuple_struct_is_rejected() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<FlattenTupleStruct>(),
            specta_serde::Format,
        )
        .expect_err("a tuple struct serializes as a sequence and must be rejected when flattened");
    assert!(
        err.to_string().contains("flatten"),
        "unexpected error: {err}"
    );
}

#[test]
fn flatten_of_sequence_in_enum_variant_is_rejected() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<VariantFlattenSeq>(),
            specta_serde::Format,
        )
        .expect_err("a flattened sequence inside a variant's named fields cannot round-trip either");
    let msg = err.to_string();
    assert!(msg.contains("flatten"), "error should mention flatten: {msg}");
    assert!(
        msg.contains("extra"),
        "error should point at the offending field: {msg}"
    );
}

// ---------------------------------------------------------------------------
// Flatten target validation: accepted shapes (struct / Option / map / enums).
// serde flattens each of these at runtime, so export must keep succeeding.
// ---------------------------------------------------------------------------

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenNamedStruct {
    head: i32,
    #[serde(flatten)]
    extra: Addr,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenOptionStruct {
    head: i32,
    #[serde(flatten)]
    extra: Option<Addr>,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenMap {
    head: i32,
    #[serde(flatten)]
    extra: HashMap<String, String>,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
#[serde(untagged)]
enum UntaggedBody {
    L { a: i32 },
    #[allow(dead_code)]
    R { b: i32 },
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenUntaggedEnum {
    head: i32,
    #[serde(flatten)]
    extra: UntaggedBody,
}

// The catch-all pattern: an untagged enum whose variants mix objects with
// scalars and sequences, the way `serde_json::Value` does. Only the active
// variant matters at runtime, so the static check keeps accepting the enum.
#[derive(Type, Serialize)]
#[specta(collect = false)]
#[serde(untagged)]
#[allow(dead_code)]
enum CatchAllBody {
    Text(String),
    Items(Vec<i32>),
    Fields { a: i32 },
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenCatchAllEnum {
    head: i32,
    #[serde(flatten)]
    extra: CatchAllBody,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
enum ExternalBody {
    A { x: i32 },
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenExternalEnum {
    head: i32,
    #[serde(flatten)]
    extra: ExternalBody,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
#[serde(tag = "k")]
enum InternalBody {
    A { x: i32 },
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenInternalEnum {
    head: i32,
    #[serde(flatten)]
    extra: InternalBody,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
#[serde(tag = "k", content = "c")]
enum AdjacentBody {
    A { x: i32 },
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenAdjacentEnum {
    head: i32,
    #[serde(flatten)]
    extra: AdjacentBody,
}

fn assert_exports_ok<T: Type>(context: &str) {
    Typescript::default()
        .export(&Types::default().register::<T>(), specta_serde::Format)
        .unwrap_or_else(|err| panic!("{context} should export cleanly, got: {err}"));
}

#[test]
fn flatten_of_named_struct_is_accepted() {
    assert_exports_ok::<FlattenNamedStruct>("flatten of a named struct");
}

#[test]
fn flatten_of_option_struct_is_accepted() {
    assert_exports_ok::<FlattenOptionStruct>("flatten of an Option<struct>");
}

#[test]
fn flatten_of_map_is_accepted() {
    assert_exports_ok::<FlattenMap>("flatten of a map");
}

#[test]
fn flatten_of_untagged_enum_is_accepted() {
    assert_exports_ok::<FlattenUntaggedEnum>("flatten of an untagged enum");
}

#[test]
fn flatten_of_untagged_enum_with_non_object_variants_is_accepted() {
    assert_exports_ok::<FlattenCatchAllEnum>(
        "flatten of an untagged enum that mixes object, scalar and sequence variants",
    );
}

#[test]
fn flatten_of_external_enum_is_accepted() {
    assert_exports_ok::<FlattenExternalEnum>("flatten of an externally tagged enum");
}

#[test]
fn flatten_of_internal_enum_is_accepted() {
    assert_exports_ok::<FlattenInternalEnum>("flatten of an internally tagged enum");
}

#[test]
fn flatten_of_adjacent_enum_is_accepted() {
    assert_exports_ok::<FlattenAdjacentEnum>("flatten of an adjacently tagged enum");
}

// ---------------------------------------------------------------------------
// Codec attribute on an unnamed (tuple/newtype) struct field.
// ---------------------------------------------------------------------------

mod wire_codec {
    use serde::{Deserialize, Deserializer, Serializer};

    pub fn serialize<S>(value: &u32, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        serializer.collect_str(value)
    }

    pub fn deserialize<'de, D>(deserializer: D) -> Result<u32, D::Error>
    where
        D: Deserializer<'de>,
    {
        String::deserialize(deserializer)?
            .parse()
            .map_err(serde::de::Error::custom)
    }
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct NewtypeCodecNoOverride(#[serde(with = "wire_codec")] u32);

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct NewtypeCodecWithOverride(
    #[specta(type = String)]
    #[serde(with = "wire_codec")]
    u32,
);

#[test]
fn codec_on_newtype_field_without_override_is_rejected() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<NewtypeCodecNoOverride>(),
            specta_serde::Format,
        )
        .expect_err(
            "a codec that changes the wire type on an unnamed field must be rejected unless the \
             field carries a type override, just like a named-struct field already is",
        );
    assert!(
        err.to_string().contains("Unsupported serde attribute"),
        "unexpected error: {err}"
    );
}

#[test]
fn codec_on_newtype_field_with_override_is_accepted() {
    let ts = Typescript::default()
        .export(
            &Types::default().register::<NewtypeCodecWithOverride>(),
            specta_serde::Format,
        )
        .expect("a type override satisfies the codec guard");
    assert!(
        ts.contains("string"),
        "the override type should be exported, got: {ts}"
    );
}

// A codec on an unnamed field after a skipped field is still rejected: the
// skip does not let the codec slip through the guard. Only the rejection is
// checked here; which index the message reports for the field is left open.
#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct NewtypeCodecAfterSkipped(#[serde(skip)] u32, #[serde(with = "wire_codec")] u32);

#[test]
fn codec_on_newtype_field_after_a_skipped_field_is_rejected() {
    Typescript::default()
        .export(
            &Types::default().register::<NewtypeCodecAfterSkipped>(),
            specta_serde::Format,
        )
        .expect_err("the codec field is still rejected after a skipped field");
}

// ---------------------------------------------------------------------------
// Misattributed error: an untagged enum nested in an internally tagged enum.
// The reported error must name the inner type and its variant, not blame the
// outer container for a variant it does not have.
// ---------------------------------------------------------------------------

#[derive(Type, Serialize)]
#[specta(collect = false)]
#[serde(untagged)]
enum PrimPayload {
    P(u32),
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
#[serde(tag = "k")]
enum TaggedOuter {
    X(PrimPayload),
}

#[test]
fn nested_untagged_enum_error_names_the_inner_type() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<TaggedOuter>(),
            specta_serde::Format,
        )
        .expect_err("an untagged scalar payload cannot be merged with an internal tag");
    let msg = err.to_string();
    assert!(
        msg.contains("PrimPayload"),
        "error should name the inner untagged type, not only the outer enum: {msg}"
    );
    assert!(
        msg.contains("variant 'P'"),
        "error should name the inner enum's variant, not a variant of the outer enum: {msg}"
    );
}

// ---------------------------------------------------------------------------
// Wire-shape fidelity: newtype delegation, generic substitution, transparent
// nesting, conversion/phase liveness, skip liveness, and termination.
// ---------------------------------------------------------------------------

// A single-field tuple struct is a newtype: serde delegates straight to the
// inner value, so flattening it is exactly as valid as flattening that value.
#[derive(Type, Serialize)]
#[specta(collect = false)]
struct NewtypeOfStruct(Addr);

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct NewtypeOfScalar(u32);

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenNewtypeStruct {
    head: i32,
    #[serde(flatten)]
    extra: NewtypeOfStruct,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenNewtypeScalar {
    head: i32,
    #[serde(flatten)]
    extra: NewtypeOfScalar,
}

#[test]
fn flatten_of_newtype_around_struct_is_accepted() {
    assert_exports_ok::<FlattenNewtypeStruct>("flatten of a newtype wrapping a struct");
}

#[test]
fn flatten_of_newtype_around_scalar_is_rejected() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<FlattenNewtypeScalar>(),
            specta_serde::Format,
        )
        .expect_err("newtype delegation exposes the scalar, which serde cannot flatten");
    assert!(
        err.to_string().contains("flatten"),
        "unexpected error: {err}"
    );
}

// A reference to a generic type carries concrete arguments, so the flatten
// target's real shape is knowable and must be substituted in.
#[derive(Type, Serialize)]
#[specta(collect = false)]
struct GenericNewtype<T>(T);

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenGenericSeq {
    head: i32,
    #[serde(flatten)]
    extra: GenericNewtype<Vec<u8>>,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenGenericStruct {
    head: i32,
    #[serde(flatten)]
    extra: GenericNewtype<Addr>,
}

#[test]
fn flatten_of_generic_newtype_over_sequence_is_rejected() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<FlattenGenericSeq>(),
            specta_serde::Format,
        )
        .expect_err("the concrete argument is a sequence, so the flatten target is a sequence");
    assert!(
        err.to_string().contains("flatten"),
        "unexpected error: {err}"
    );
}

#[test]
fn flatten_of_generic_newtype_over_struct_is_accepted() {
    assert_exports_ok::<FlattenGenericStruct>("flatten of a generic newtype over a struct");
}

// The same syntactic generic reference reached under two different outer
// instantiations in one walk must be validated against each; walk order must
// not let a good instantiation mask a bad one.
#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenGenericField<T> {
    head: i32,
    #[serde(flatten)]
    body: T,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct OuterOf<T> {
    inner: FlattenGenericField<T>,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct TwoSubstitutionsGoodFirst {
    good: OuterOf<Addr>,
    bad: OuterOf<Vec<u8>>,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct TwoSubstitutionsBadFirst {
    bad: OuterOf<Vec<u8>>,
    good: OuterOf<Addr>,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct TwoSubstitutionsGoodOnly {
    good: OuterOf<Addr>,
}

#[test]
fn flatten_generic_reached_under_two_substitutions_rejects_the_bad_one() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<TwoSubstitutionsGoodFirst>(),
            specta_serde::Format,
        )
        .expect_err("the struct instantiation seen first must not mask the sequence one");
    assert!(
        err.to_string().contains("flatten"),
        "unexpected error: {err}"
    );

    let err = Typescript::default()
        .export(
            &Types::default().register::<TwoSubstitutionsBadFirst>(),
            specta_serde::Format,
        )
        .expect_err("the sequence instantiation must be rejected regardless of walk order");
    assert!(
        err.to_string().contains("flatten"),
        "unexpected error: {err}"
    );
}

#[test]
fn flatten_generic_reached_under_one_good_substitution_is_accepted() {
    assert_exports_ok::<TwoSubstitutionsGoodOnly>("flatten of a generic under one struct arg");
}

// The flattened type is itself a generic reference whose argument is a
// placeholder of the enclosing definition, so the real shape is only known
// from the instantiation one level up.
#[derive(Type, Serialize)]
#[specta(collect = false)]
struct Holder<T> {
    head: i32,
    #[serde(flatten)]
    body: GenericNewtype<T>,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct HolderOfStruct {
    h: Holder<Addr>,
}

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct HolderOfSeq {
    h: Holder<Vec<u8>>,
}

#[test]
fn flatten_of_generic_argument_passed_through_an_enclosing_generic_is_rejected_for_sequence() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<HolderOfSeq>(),
            specta_serde::Format,
        )
        .expect_err("the argument written one level up is a sequence");
    assert!(
        err.to_string().contains("flatten"),
        "unexpected error: {err}"
    );
}

#[test]
fn flatten_of_generic_argument_passed_through_an_enclosing_generic_is_accepted_for_struct() {
    assert_exports_ok::<HolderOfStruct>("flatten of a generic newtype whose argument comes from the enclosing generic");
}

// Transparent wrappers delegate straight through; nested ones still resolve to
// the innermost real shape.
#[derive(Type, Serialize)]
#[specta(collect = false)]
#[serde(transparent)]
struct TransparentInner(Vec<u8>);

#[derive(Type, Serialize)]
#[specta(collect = false)]
#[serde(transparent)]
struct TransparentOuter(TransparentInner);

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenTransparentSeq {
    head: i32,
    #[serde(flatten)]
    extra: TransparentOuter,
}

#[test]
fn flatten_of_nested_transparent_wrappers_around_sequence_is_rejected() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<FlattenTransparentSeq>(),
            specta_serde::Format,
        )
        .expect_err("transparent wrappers still resolve to a sequence");
    assert!(
        err.to_string().contains("flatten"),
        "unexpected error: {err}"
    );
}

// Conversion attributes replace the declared shape with a wire shape per
// direction. A one-directional conversion leaves the opposite direction on the
// raw declared shape, which must still be checked.
#[derive(Type, Serialize, Deserialize, Clone)]
#[specta(collect = false)]
struct ConversionWire {
    id: String,
}

#[derive(Type, Serialize, Deserialize, Clone)]
#[specta(collect = false)]
#[serde(into = "ConversionWire")]
struct IntoOnlyScalar(u32);

impl From<IntoOnlyScalar> for ConversionWire {
    fn from(value: IntoOnlyScalar) -> Self {
        Self {
            id: value.0.to_string(),
        }
    }
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenIntoOnly {
    head: i32,
    #[serde(flatten)]
    extra: IntoOnlyScalar,
}

#[test]
fn flatten_of_into_only_conversion_checks_the_raw_deserialize_shape() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<FlattenIntoOnly>(),
            specta_serde::PhasesFormat,
        )
        .expect_err("serialize uses a struct wire, but deserialize uses the raw scalar newtype");
    assert!(
        err.to_string().contains("flatten"),
        "unexpected error: {err}"
    );
}

// A container conversion on an enum replaces the enum's own wire shape in the
// direction the conversion applies to, so the enum's usual acceptance does not
// carry over when the target is a sequence.
#[derive(Type, Serialize, Deserialize, Clone)]
#[specta(collect = false)]
#[serde(into = "ConversionWire")]
#[allow(dead_code)]
enum IntoStructEnum {
    A { x: i32 },
}

impl From<IntoStructEnum> for ConversionWire {
    fn from(value: IntoStructEnum) -> Self {
        match value {
            IntoStructEnum::A { x } => Self { id: x.to_string() },
        }
    }
}

#[derive(Type, Serialize, Deserialize, Clone)]
#[specta(collect = false)]
#[serde(into = "Vec<u8>")]
#[allow(dead_code)]
enum IntoSeqEnum {
    A { x: i32 },
}

impl From<IntoSeqEnum> for Vec<u8> {
    fn from(value: IntoSeqEnum) -> Self {
        match value {
            IntoSeqEnum::A { x } => x.to_le_bytes().to_vec(),
        }
    }
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenIntoStructEnum {
    head: i32,
    #[serde(flatten)]
    extra: IntoStructEnum,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenIntoSeqEnum {
    head: i32,
    #[serde(flatten)]
    extra: IntoSeqEnum,
}

#[test]
fn flatten_of_enum_converted_into_a_sequence_is_rejected() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<FlattenIntoSeqEnum>(),
            specta_serde::PhasesFormat,
        )
        .expect_err("the serialize wire of the enum is a sequence");
    assert!(
        err.to_string().contains("flatten"),
        "unexpected error: {err}"
    );
}

#[test]
fn flatten_of_enum_converted_into_a_struct_is_accepted() {
    Typescript::default()
        .export(
            &Types::default().register::<FlattenIntoStructEnum>(),
            specta_serde::PhasesFormat,
        )
        .expect("the serialize wire is a struct and the deserialize side is the enum itself");
}

// An explicit phase override holds both phase shapes; the live phase must be
// looked inside rather than trusting the wrapper.
#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenPhasedSeq {
    head: i32,
    #[serde(flatten)]
    #[specta(type = specta_serde::Phased<Vec<String>, Addr>)]
    extra: HashMap<String, String>,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenPhasedMap {
    head: i32,
    #[serde(flatten)]
    #[specta(type = specta_serde::Phased<HashMap<String, String>, Addr>)]
    extra: HashMap<String, String>,
}

#[test]
fn flatten_of_phased_override_with_a_sequence_phase_is_rejected() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<FlattenPhasedSeq>(),
            specta_serde::PhasesFormat,
        )
        .expect_err("the serialize phase is a sequence, which cannot be flattened");
    assert!(
        err.to_string().contains("flatten"),
        "unexpected error: {err}"
    );
}

#[test]
fn flatten_of_phased_override_with_map_and_struct_phases_is_accepted() {
    Typescript::default()
        .export(
            &Types::default().register::<FlattenPhasedMap>(),
            specta_serde::PhasesFormat,
        )
        .expect("both phases are map/struct shaped, so the flatten is valid both ways");
}

// Skip liveness: a field skipped in a direction never flattens in that
// direction, so its shape there is irrelevant and must not be rejected.
#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenOneSidedSkipSeq {
    head: i32,
    #[serde(flatten, skip_serializing, default)]
    extra: Vec<u8>,
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenBothSidedSkipSeq {
    head: i32,
    #[serde(flatten, skip_serializing, skip_deserializing, default)]
    extra: Vec<u8>,
}

// The serialize phase of the override is a sequence, but the field is skipped
// on serialize, so that sequence never reaches the wire. The deserialize phase
// is a struct and is live.
#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenDeadSerializeSeq {
    head: i32,
    #[serde(flatten, skip_serializing, default)]
    #[specta(type = specta_serde::Phased<Vec<String>, Addr>)]
    extra: HashMap<String, String>,
}

// The mirror image: the deserialize phase is a sequence but the field is
// skipped on deserialize, so only the struct-shaped serialize phase is live.
#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
struct FlattenDeadDeserializeSeq {
    head: i32,
    #[serde(flatten, skip_deserializing, default)]
    #[specta(type = specta_serde::Phased<Addr, Vec<String>>)]
    extra: HashMap<String, String>,
}

#[test]
fn flatten_of_one_sided_skip_is_rejected_on_its_live_direction() {
    // The field is skipped only on serialize, so the deserialize phase still
    // flattens a live sequence and the split formatter must reject it there.
    let err = Typescript::default()
        .export(
            &Types::default().register::<FlattenOneSidedSkipSeq>(),
            specta_serde::PhasesFormat,
        )
        .expect_err("the deserialize phase flattens a live sequence");
    assert!(
        err.to_string().contains("flatten"),
        "unexpected error: {err}"
    );
}

#[test]
fn one_sided_skip_dead_direction_is_not_required_flattenable() {
    // Each type carries a sequence only in the phase its skip removes, so the
    // split export sees a struct in every live direction and must succeed.
    Typescript::default()
        .export(
            &Types::default().register::<FlattenDeadSerializeSeq>(),
            specta_serde::PhasesFormat,
        )
        .expect("the serialize phase never renders the skip-serializing sequence");

    Typescript::default()
        .export(
            &Types::default().register::<FlattenDeadDeserializeSeq>(),
            specta_serde::PhasesFormat,
        )
        .expect("the deserialize phase never renders the skip-deserializing sequence");
}

// A one-sided skip on the enclosing variant removes every field of that
// variant from the skipped direction, so the override's sequence side is
// only live when the skip is on the other direction.
#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
#[allow(dead_code)]
enum VariantSkipSerializeSeq {
    #[serde(skip_serializing)]
    Load {
        head: i32,
        #[serde(flatten)]
        #[specta(type = specta_serde::Phased<Vec<String>, Addr>)]
        extra: HashMap<String, String>,
    },
    Other {
        x: i32,
    },
}

#[derive(Type, Serialize, Deserialize)]
#[specta(collect = false)]
#[allow(dead_code)]
enum VariantSkipDeserializeSeq {
    #[serde(skip_deserializing)]
    Load {
        head: i32,
        #[serde(flatten)]
        #[specta(type = specta_serde::Phased<Vec<String>, Addr>)]
        extra: HashMap<String, String>,
    },
    Other {
        x: i32,
    },
}

#[test]
fn variant_skipped_on_serialize_does_not_require_its_serialize_shape_flattenable() {
    Typescript::default()
        .export(
            &Types::default().register::<VariantSkipSerializeSeq>(),
            specta_serde::PhasesFormat,
        )
        .expect("the variant never serializes, so only the struct-shaped deserialize side is live");
}

#[test]
fn variant_skipped_on_deserialize_still_rejects_its_live_serialize_sequence() {
    let err = Typescript::default()
        .export(
            &Types::default().register::<VariantSkipDeserializeSeq>(),
            specta_serde::PhasesFormat,
        )
        .expect_err("the variant still serializes, and its serialize side is a sequence");
    assert!(
        err.to_string().contains("flatten"),
        "unexpected error: {err}"
    );
}

#[test]
fn flatten_of_fully_skipped_sequence_is_accepted() {
    assert_exports_ok::<FlattenBothSidedSkipSeq>("flatten of a sequence skipped in both directions");
}

// Termination: resolving a self-recursive generic flatten target must not hang.
#[derive(Type, Serialize)]
#[specta(collect = false)]
struct SelfRecursiveGeneric<T>(Box<SelfRecursiveGeneric<T>>, PhantomData<T>);

#[derive(Type, Serialize)]
#[specta(collect = false)]
struct FlattenSelfRecursiveGeneric {
    head: i32,
    #[serde(flatten)]
    extra: SelfRecursiveGeneric<Addr>,
}

/// Runs `f` on a worker thread and panics if it does not finish in `timeout`,
/// so an export that recurses forever shows up as a failed test instead of a
/// hung process.
fn with_timeout<T: Send + 'static>(
    timeout: std::time::Duration,
    f: impl FnOnce() -> T + Send + 'static,
) -> T {
    let (tx, rx) = std::sync::mpsc::channel();
    std::thread::spawn(move || {
        let _ = tx.send(f());
    });
    rx.recv_timeout(timeout)
        .expect("export did not finish in time, most likely unbounded recursion")
}

#[test]
fn flatten_of_self_recursive_generic_terminates() {
    // Only termination is asserted here. Whether this shape is accepted or
    // rejected is not part of the contract; finishing is.
    let _ = with_timeout(std::time::Duration::from_secs(10), || {
        Typescript::default().export(
            &Types::default().register::<FlattenSelfRecursiveGeneric>(),
            specta_serde::Format,
        )
    });
}
