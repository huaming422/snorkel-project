## Task

specta-serde is supposed to catch, at export time, any type whose serde attributes describe something serde cannot round-trip, so people hear about it when they export instead of when a value blows up at runtime.
A few shapes get through.
They export `Ok` through `specta_typescript::Typescript::default().export(&types, specta_serde::Format)` and through the split `specta_serde::PhasesFormat`, and they should come back as `Err`.

- `#[serde(flatten)]` on a field whose value is a sequence, a tuple or a scalar on the wire exports fine, then serde_json fails at runtime with "can only flatten structs and maps".
  A `Vec<_>`, a tuple or a plain integer are the obvious cases, but the declared type of the field is not the thing to judge.
  What matters is the shape serde ends up with on the wire, which is not always what the declaration suggests, and the split format sees each direction on its own.
  The shapes serde does flatten have to keep exporting, so maps, structs, `Option` of those and enums, untagged catch-all ones like `serde_json::Value` included, stay valid however they are reached.
  The error should say the flatten is the problem and name the field.

- `#[serde(with = ...)]`, `serialize_with` or `deserialize_with` on a tuple struct or newtype struct field is accepted silently and the pre-codec type gets exported.
  The same attribute on a named struct field is already rejected unless the field carries a `#[specta(type = ...)]` override, and unnamed fields should get the same treatment.

- An untagged enum nested inside an internally tagged enum is rejected, which is right, but the error names the outer enum and blames it for a variant that only exists on the inner one.
  The message should point at the inner type and its own variant.

Nothing that exports and round-trips today may start failing, and recursive types still have to export without hanging.
