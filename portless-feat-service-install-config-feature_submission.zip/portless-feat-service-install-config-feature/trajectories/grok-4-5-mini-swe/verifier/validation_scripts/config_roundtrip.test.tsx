// @ts-nocheck
import { afterEach, beforeEach, describe, it, expect, vi } from "vitest";
import { handleService } from "../service.js";

import { getTestCases } from "./validationParams";

vi.mock("node:fs", async (importOriginal) => {
  const mod = await importOriginal();
  return {
    ...mod,
    chmodSync: vi.fn(),
    existsSync: vi.fn(),
    mkdirSync: vi.fn(),
    readFileSync: vi.fn(),
    rmSync: vi.fn(),
    writeFileSync: vi.fn(),
  };
});
vi.mock("../certs.js", () => ({
  ensureCerts: vi.fn(() => ({
    certPath: "/fake/server.pem",
    keyPath: "/fake/server-key.pem",
    caPath: "/fake/ca.pem",
    caGenerated: false,
  })),
  isCATrusted: vi.fn(() => true),
  trustCA: vi.fn(() => ({ trusted: true })),
}));
vi.mock("../utils.js", () => ({ fixOwnership: vi.fn() }));
vi.mock("../mdns.js", () => ({ isMdnsSupported: vi.fn(() => ({ supported: true })) }));
vi.mock("../cli-utils.js", async (importOriginal) => {
  const mod = await importOriginal();
  return { ...mod, discoverState: vi.fn(mod.discoverState), isProxyRunning: vi.fn(mod.isProxyRunning) };
});

const { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } = await import("node:fs");
const { discoverState, isProxyRunning } = await import("../cli-utils.js");

function installMemoryFs() {
  const store = new Map();
  vi.mocked(writeFileSync).mockImplementation((p, data) => { store.set(String(p), String(data)); });
  vi.mocked(readFileSync).mockImplementation((p) => {
    const key = String(p);
    if (store.has(key)) return store.get(key);
    const err = new Error(`ENOENT: ${key}`); err.code = "ENOENT"; throw err;
  });
  vi.mocked(existsSync).mockImplementation((p) => store.has(String(p)));
  vi.mocked(mkdirSync).mockReturnValue(undefined);
  return store;
}

function setPlatform(platform) { Object.defineProperty(process, "platform", { configurable: true, value: platform }); }
function setGetuid(uid) { Object.defineProperty(process, "getuid", { configurable: true, value: () => uid }); }

const originalPlatform = process.platform;
const originalGetuid = process.getuid;

afterEach(() => {
  Object.defineProperty(process, "platform", { configurable: true, value: originalPlatform });
  Object.defineProperty(process, "getuid", { configurable: true, value: originalGetuid });
  vi.restoreAllMocks();
});

describe("config_roundtrip", () => {
  const cases = getTestCases();
  it.each(cases)("case $#", async ({ inputs, expected }) => {
    installMemoryFs();
    setPlatform("linux");
    setGetuid(0);

    const runner = vi.fn(() => ({ status: 0, stdout: "", stderr: "" }));
    const exitSpy = vi.spyOn(process, "exit").mockImplementation(() => { throw new Error("process.exit"); });
    const logSpy = vi.spyOn(console, "log").mockImplementation(() => {});
    const errorSpy = vi.spyOn(console, "error").mockImplementation(() => {});

    // Save env keys and set inputs.env
    const envKeys = Object.keys(inputs.env || {});
    const savedEnv: Record<string, string | undefined> = {};
    for (const key of envKeys) {
      savedEnv[key] = process.env[key];
      process.env[key] = inputs.env[key];
    }

    try {
      // Step 1: Install
      await handleService(inputs.install_args, { entryScript: "/fake/cli.js", runner });

      // Step 2: Run status (reset logSpy to capture only status output)
      logSpy.mockClear();
      await handleService(["service", "status"], { entryScript: "/fake/cli.js", runner });

      // Step 3: Capture status output
      const output = logSpy.mock.calls.map((c) => c.join(" ")).join("\n");

      // Assert proxy port appears in output
      expect(output).toContain(String(expected.proxy_port));

      // Assert HTTPS enabled status
      // The implementation prints "HTTPS: yes" or "HTTPS: no"
      if (expected.https_enabled) {
        expect(output).toMatch(/HTTPS:\s*yes/i);
      } else {
        expect(output).toMatch(/HTTPS:\s*no/i);
      }

      // Assert TLD appears in output
      expect(output).toContain(String(expected.tld));

      // Assert wildcard enabled status
      // printServiceStatus only prints "  Wildcard: yes" when useWildcard is true; no line when false.
      if (expected.wildcard_enabled) {
        // Must match the exact rendering from printServiceStatus: "Wildcard: yes"
        expect(output).toMatch(/Wildcard:\s*yes/i);
      } else {
        // When wildcard is false, "Wildcard: yes" must NOT appear in output
        expect(output).not.toMatch(/Wildcard:\s*yes/i);
      }

      // Assert LAN mode
      // printServiceStatus only prints "  LAN mode: ..." when lanMode is true; no line when false.
      if (expected.lan_mode) {
        expect(output).toMatch(/LAN mode/i);
      } else {
        // When LAN mode is false, no "LAN mode" line should appear
        expect(output).not.toMatch(/LAN mode/i);
      }

      // Assert LAN IP if not skipped
      if (expected.lan_ip !== "__skip__") {
        expect(output).toContain(String(expected.lan_ip));
      }

      // Assert state_dir if not skipped
      if (expected.state_dir !== "__skip__") {
        expect(output).toContain(String(expected.state_dir));
      }

    } finally {
      // Restore env
      for (const key of envKeys) {
        if (savedEnv[key] === undefined) {
          delete process.env[key];
        } else {
          process.env[key] = savedEnv[key];
        }
      }
    }
  });
});
