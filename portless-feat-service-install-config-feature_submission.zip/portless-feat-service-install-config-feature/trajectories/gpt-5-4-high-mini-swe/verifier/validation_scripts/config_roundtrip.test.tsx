// @ts-nocheck
import { afterEach, beforeEach, describe, it, expect, vi } from "vitest";
import { handleService } from "../service.js";

import { getTestCases } from "./validationParams";

vi.mock("node:fs", async (importOriginal) => {
  const mod = await importOriginal();
  return {
    ...mod,
    chmodSync: vi.fn(),
    existsSync: vi.fn(),
    mkdirSync: vi.fn(),
    readFileSync: vi.fn(),
    rmSync: vi.fn(),
    writeFileSync: vi.fn(),
  };
});
vi.mock("../certs.js", () => ({
  ensureCerts: vi.fn(() => ({
    certPath: "/fake/server.pem",
    keyPath: "/fake/server-key.pem",
    caPath: "/fake/ca.pem",
    caGenerated: false,
  })),
  isCATrusted: vi.fn(() => true),
  trustCA: vi.fn(() => ({ trusted: true })),
}));
vi.mock("../utils.js", () => ({ fixOwnership: vi.fn() }));
vi.mock("../mdns.js", () => ({ isMdnsSupported: vi.fn(() => ({ supported: true })) }));
vi.mock("../cli-utils.js", async (importOriginal) => {
  const mod = await importOriginal();
  return { ...mod, discoverState: vi.fn(mod.discoverState), isProxyRunning: vi.fn(mod.isProxyRunning) };
});

const { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } = await import("node:fs");
const { discoverState, isProxyRunning } = await import("../cli-utils.js");

// Per-test: a shared in-memory store so writeFileSync and readFileSync/existsSync
// see the SAME bytes — this is the install→status round trip.
function installMemoryFs() {
  const store = new Map();
  vi.mocked(writeFileSync).mockImplementation((p, data) => { store.set(String(p), String(data)); });
  vi.mocked(readFileSync).mockImplementation((p) => {
    const key = String(p);
    if (store.has(key)) return store.get(key);
    const err = new Error(`ENOENT: ${key}`); err.code = "ENOENT"; throw err;
  });
  vi.mocked(existsSync).mockImplementation((p) => store.has(String(p)));
  vi.mocked(mkdirSync).mockReturnValue(undefined);
  return store;
}

function setPlatform(platform) { Object.defineProperty(process, "platform", { configurable: true, value: platform }); }
function setGetuid(uid) { Object.defineProperty(process, "getuid", { configurable: true, value: () => uid }); }

const originalPlatform = process.platform;
const originalGetuid = process.getuid;

describe("config_roundtrip", () => {
  const cases = getTestCases();
  it.each(cases)("case $#", async ({ inputs, expected }) => {
    // Setup platform & uid
    setPlatform("linux");
    setGetuid(0);

    // Setup in-memory FS
    installMemoryFs();

    // Setup runner to handle systemctl calls for status
    const runner = vi.fn((command, args) => {
      if (command === "systemctl" && args && args.join(" ") === "is-enabled portless.service") {
        return { status: 0, stdout: "enabled", stderr: "" };
      }
      if (command === "systemctl" && args && args.join(" ") === "is-active portless.service") {
        return { status: 0, stdout: "active", stderr: "" };
      }
      return { status: 0, stdout: "", stderr: "" };
    });

    const exitSpy = vi.spyOn(process, "exit").mockImplementation(() => { throw new Error("process.exit"); });
    const logSpy = vi.spyOn(console, "log").mockImplementation(() => {});
    const errorSpy = vi.spyOn(console, "error").mockImplementation(() => {});

    // Save and set env
    const envKeys = Object.keys(inputs.env || {});
    const savedEnv = {};
    for (const key of envKeys) {
      savedEnv[key] = process.env[key];
      process.env[key] = inputs.env[key];
    }

    try {
      // 1. Install
      await handleService(inputs.install_args, { entryScript: "/fake/cli.js", runner });

      // Reset log spy between install and status so we only capture status output
      logSpy.mockClear();

      // 2. Status
      await handleService(["service", "status"], { entryScript: "/fake/cli.js", runner });

      // 3. Capture output
      const output = logSpy.mock.calls.map((c) => c.join(" ")).join("\n");

      // Assert proxy port
      expect(output).toContain(expected.proxy_port);

      // Assert HTTPS enabled
      if (expected.https_enabled) {
        expect(output).toContain("HTTPS: on");
      } else {
        expect(output).toContain("HTTPS: off");
      }

      // Assert TLD appears in output
      expect(output).toContain(expected.tld);

      // Assert wildcard enabled
      if (expected.wildcard_enabled) {
        expect(output).toContain("Wildcard routing: on");
      } else {
        expect(output).toContain("Wildcard routing: off");
      }

      // Assert LAN mode
      if (expected.lan_mode) {
        expect(output).toContain("LAN");
      } else {
        // Not in LAN mode - mode line should not indicate LAN
        expect(output).not.toContain("LAN (.local");
      }

      // Assert LAN IP (if not __skip__)
      if (expected.lan_ip !== "__skip__") {
        expect(output).toContain(expected.lan_ip);
      }

      // Assert state dir (if not __skip__)
      if (expected.state_dir !== "__skip__") {
        expect(output).toContain(expected.state_dir);
      }
    } finally {
      // Restore env
      for (const key of envKeys) {
        if (savedEnv[key] === undefined) {
          delete process.env[key];
        } else {
          process.env[key] = savedEnv[key];
        }
      }
      exitSpy.mockRestore();
      logSpy.mockRestore();
      errorSpy.mockRestore();
      // Restore platform and getuid
      Object.defineProperty(process, "platform", { configurable: true, value: originalPlatform });
      Object.defineProperty(process, "getuid", { configurable: true, value: originalGetuid });
      vi.mocked(writeFileSync).mockReset();
      vi.mocked(readFileSync).mockReset();
      vi.mocked(existsSync).mockReset();
      vi.mocked(mkdirSync).mockReset();
    }
  });
});
