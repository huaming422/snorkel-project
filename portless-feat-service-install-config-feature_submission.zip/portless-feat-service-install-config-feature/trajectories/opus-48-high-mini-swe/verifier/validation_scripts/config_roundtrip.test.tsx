// @ts-nocheck
import { afterEach, beforeEach, describe, it, expect, vi } from "vitest";
import { handleService } from "../service.js";

import { getTestCases } from "./validationParams";

vi.mock("node:fs", async (importOriginal) => {
  const mod = await importOriginal();
  return {
    ...mod,
    chmodSync: vi.fn(),
    existsSync: vi.fn(),
    mkdirSync: vi.fn(),
    readFileSync: vi.fn(),
    rmSync: vi.fn(),
    writeFileSync: vi.fn(),
  };
});
vi.mock("../certs.js", () => ({
  ensureCerts: vi.fn(() => ({
    certPath: "/fake/server.pem",
    keyPath: "/fake/server-key.pem",
    caPath: "/fake/ca.pem",
    caGenerated: false,
  })),
  isCATrusted: vi.fn(() => true),
  trustCA: vi.fn(() => ({ trusted: true })),
}));
vi.mock("../utils.js", () => ({ fixOwnership: vi.fn() }));
vi.mock("../mdns.js", () => ({ isMdnsSupported: vi.fn(() => ({ supported: true })) }));
vi.mock("../cli-utils.js", async (importOriginal) => {
  const mod = await importOriginal();
  return { ...mod, discoverState: vi.fn(mod.discoverState), isProxyRunning: vi.fn(mod.isProxyRunning) };
});

const { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } = await import("node:fs");
const { discoverState, isProxyRunning } = await import("../cli-utils.js");

function installMemoryFs() {
  const store = new Map();
  vi.mocked(writeFileSync).mockImplementation((p, data) => { store.set(String(p), String(data)); });
  vi.mocked(readFileSync).mockImplementation((p) => {
    const key = String(p);
    if (store.has(key)) return store.get(key);
    const err = new Error(`ENOENT: ${key}`); err.code = "ENOENT"; throw err;
  });
  vi.mocked(existsSync).mockImplementation((p) => store.has(String(p)));
  vi.mocked(mkdirSync).mockReturnValue(undefined);
  return store;
}

function setPlatform(platform) { Object.defineProperty(process, "platform", { configurable: true, value: platform }); }
function setGetuid(uid) { Object.defineProperty(process, "getuid", { configurable: true, value: () => uid }); }

const originalPlatform = process.platform;
const originalGetuid = process.getuid;

afterEach(() => {
  Object.defineProperty(process, "platform", { configurable: true, value: originalPlatform });
  Object.defineProperty(process, "getuid", { configurable: true, value: originalGetuid });
  vi.clearAllMocks();
});

describe("config_roundtrip", () => {
  const cases = getTestCases();
  it.each(cases)("case $#", async ({ inputs, expected }) => {
    installMemoryFs();
    setPlatform("linux");
    setGetuid(0);

    vi.mocked(isProxyRunning).mockResolvedValue(false);

    const runner = vi.fn(() => ({ status: 0, stdout: "", stderr: "" }));
    const exitSpy = vi.spyOn(process, "exit").mockImplementation(() => { throw new Error("process.exit"); });
    const logSpy = vi.spyOn(console, "log").mockImplementation(() => {});
    const errorSpy = vi.spyOn(console, "error").mockImplementation(() => {});

    // Save and set env vars
    const envKeys = Object.keys(inputs.env || {});
    const savedEnv: Record<string, string | undefined> = {};
    for (const key of envKeys) {
      savedEnv[key] = process.env[key];
      process.env[key] = inputs.env[key];
    }

    try {
      // Step 1: Install
      await handleService(inputs.install_args, { entryScript: "/fake/cli.js", runner });

      // Step 2: Status — reset logSpy calls first so we only capture status output
      logSpy.mockClear();

      await handleService(["service", "status"], { entryScript: "/fake/cli.js", runner });

      // Step 3: Capture output
      const output = logSpy.mock.calls.map((c) => c.join(" ")).join("\n");

      // Assert proxy port
      expect(output).toContain(String(expected.proxy_port));

      // Assert HTTPS enabled/disabled
      // The patch prints: Protocol: HTTPS or Protocol: HTTP
      if (expected.https_enabled === true) {
        expect(output).toContain("HTTPS");
      } else {
        // Should say HTTP but NOT HTTPS for the Protocol line
        // Look for "Protocol: HTTP" without HTTPS
        expect(output).toMatch(/Protocol:\s+HTTP(?!S)/);
      }

      // Assert TLD
      expect(output).toContain(expected.tld);

      // Assert wildcard enabled/disabled
      // The patch prints: Wildcard: on  or  Wildcard: off
      if (expected.wildcard_enabled === true) {
        expect(output).toContain("Wildcard: on");
      } else {
        expect(output).toContain("Wildcard: off");
      }

      // Assert LAN mode
      // The patch prints: Mode: LAN  or  Mode: local
      if (expected.lan_mode === true) {
        expect(output).toContain("Mode: LAN");
      } else {
        expect(output).toContain("Mode: local");
      }

      // Assert LAN IP if not skipped
      if (expected.lan_ip !== "__skip__") {
        expect(output).toContain(String(expected.lan_ip));
      }

      // Assert state dir if not skipped
      if (expected.state_dir !== "__skip__") {
        expect(output).toContain(String(expected.state_dir));
      }
    } finally {
      // Restore env vars
      for (const key of envKeys) {
        if (savedEnv[key] === undefined) {
          delete process.env[key];
        } else {
          process.env[key] = savedEnv[key];
        }
      }
      exitSpy.mockRestore();
      logSpy.mockRestore();
      errorSpy.mockRestore();
    }
  });
});
