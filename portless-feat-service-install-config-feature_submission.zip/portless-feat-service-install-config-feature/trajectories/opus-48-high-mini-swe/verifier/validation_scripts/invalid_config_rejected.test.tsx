// @ts-nocheck
import { afterEach, beforeEach, describe, it, expect, vi } from "vitest";
import { handleService } from "../service.js";

import { getTestCases } from "./validationParams";

vi.mock("node:fs", async (importOriginal) => {
  const mod = await importOriginal();
  return {
    ...mod,
    chmodSync: vi.fn(),
    existsSync: vi.fn(),
    mkdirSync: vi.fn(),
    readFileSync: vi.fn(),
    rmSync: vi.fn(),
    writeFileSync: vi.fn(),
  };
});
vi.mock("../certs.js", () => ({
  ensureCerts: vi.fn(() => ({
    certPath: "/fake/server.pem",
    keyPath: "/fake/server-key.pem",
    caPath: "/fake/ca.pem",
    caGenerated: false,
  })),
  isCATrusted: vi.fn(() => true),
  trustCA: vi.fn(() => ({ trusted: true })),
}));
vi.mock("../utils.js", () => ({ fixOwnership: vi.fn() }));
vi.mock("../mdns.js", () => ({ isMdnsSupported: vi.fn(() => ({ supported: true })) }));
vi.mock("../cli-utils.js", async (importOriginal) => {
  const mod = await importOriginal();
  return { ...mod, discoverState: vi.fn(mod.discoverState), isProxyRunning: vi.fn(mod.isProxyRunning) };
});

const { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } = await import("node:fs");
const { discoverState, isProxyRunning } = await import("../cli-utils.js");

function installMemoryFs() {
  const store = new Map();
  vi.mocked(writeFileSync).mockImplementation((p, data) => { store.set(String(p), String(data)); });
  vi.mocked(readFileSync).mockImplementation((p) => {
    const key = String(p);
    if (store.has(key)) return store.get(key);
    const err = new Error(`ENOENT: ${key}`); err.code = "ENOENT"; throw err;
  });
  vi.mocked(existsSync).mockImplementation((p) => store.has(String(p)));
  vi.mocked(mkdirSync).mockReturnValue(undefined);
  return store;
}

function setPlatform(platform) { Object.defineProperty(process, "platform", { configurable: true, value: platform }); }
function setGetuid(uid) { Object.defineProperty(process, "getuid", { configurable: true, value: () => uid }); }

const originalPlatform = process.platform;
const originalGetuid = process.getuid;

afterEach(() => {
  Object.defineProperty(process, "platform", { configurable: true, value: originalPlatform });
  Object.defineProperty(process, "getuid", { configurable: true, value: originalGetuid });
  vi.clearAllMocks();
});

describe("invalid_config_rejected", () => {
  const cases = getTestCases();
  it.each(cases)("case $#", async ({ inputs, expected }) => {
    installMemoryFs();
    setPlatform("linux");
    setGetuid(0);

    vi.mocked(isProxyRunning).mockResolvedValue(false);

    const runner = vi.fn(() => ({ status: 0, stdout: "", stderr: "" }));
    const exitSpy = vi.spyOn(process, "exit").mockImplementation(() => { throw new Error("process.exit"); });
    const logSpy = vi.spyOn(console, "log").mockImplementation(() => {});
    const errorSpy = vi.spyOn(console, "error").mockImplementation(() => {});

    // Save and set env vars
    const envKeys = Object.keys(inputs.env || {});
    const savedEnv: Record<string, string | undefined> = {};
    for (const key of envKeys) {
      savedEnv[key] = process.env[key];
      process.env[key] = inputs.env[key];
    }

    try {
      if (inputs.mode === "reject_install") {
        // Attempt install, expect it to throw (process.exit called)
        await expect(
          handleService(inputs.install_args, { entryScript: "/fake/cli.js", runner })
        ).rejects.toThrow("process.exit");

        // EXPECTED: expected.rejected is true — exitSpy was called with 1
        expect(expected.rejected).toBe(true);
        expect(exitSpy).toHaveBeenCalledWith(1);

        // EXPECTED: expected.no_service_file is true — writeFileSync was NOT called
        expect(expected.no_service_file).toBe(true);
        expect(vi.mocked(writeFileSync)).not.toHaveBeenCalled();

        // EXPECTED: expected.problem_keyword appears in error output (case-insensitive)
        const errorOutput = errorSpy.mock.calls.map((c) => c.join(" ")).join("\n").toLowerCase();
        expect(errorOutput).toContain(String(expected.problem_keyword).toLowerCase());

      } else if (inputs.mode === "uninstall_ok") {
        // Run uninstall with invalid env in place
        await handleService(inputs.install_args, { entryScript: "/fake/cli.js", runner });

        // EXPECTED: expected.rejected is false — exitSpy was NOT called
        expect(expected.rejected).toBe(false);
        expect(exitSpy).not.toHaveBeenCalled();

        // EXPECTED: expected.uninstall_disable_cmd is true — runner invoked with systemctl disable
        expect(expected.uninstall_disable_cmd).toBe(true);
        // Check that runner was called with systemctl disable --now portless.service
        const runnerCalls = runner.mock.calls;
        const disableCall = runnerCalls.find(
          (call) =>
            call[0] === "systemctl" &&
            Array.isArray(call[1]) &&
            call[1].includes("disable") &&
            call[1].includes("--now") &&
            call[1].some((arg) => arg.includes("portless"))
        );
        expect(disableCall).toBeDefined();
      }
    } finally {
      // Restore env vars
      for (const key of envKeys) {
        if (savedEnv[key] === undefined) {
          delete process.env[key];
        } else {
          process.env[key] = savedEnv[key];
        }
      }
      exitSpy.mockRestore();
      logSpy.mockRestore();
      errorSpy.mockRestore();
    }
  });
});
