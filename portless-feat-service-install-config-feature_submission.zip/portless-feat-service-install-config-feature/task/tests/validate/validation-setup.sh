#!/usr/bin/env bash
# Environment bootstrap for the validation story scripts. Idempotent.
#
# The portless validation stories import runtime modules from source
# (e.g. `import { handleService } from "../service.js"`, which vitest resolves
# to ../service.ts). No dist build is required — vitest runs against the
# package's TypeScript sources directly — so this script only ensures the
# workspace's node_modules are present and the toolchain is reachable.

set -e

REPO_DIR="${REPO_DIR:-/repo/portless}"
cd "$REPO_DIR"

# Sanity: Node + pnpm + vitest are reachable.
node --version
pnpm --version
npx vitest --version

# Re-install workspace deps if missing. The image bakes the full dependency
# closure with a warm pnpm store at the base commit, so the normal path is an
# offline no-op replay; the online fallback fires only if node_modules was
# wiped (e.g. an agent reinstall) and the store is cold.
if [ ! -d "node_modules/.pnpm" ]; then
    echo "[validation-setup] pnpm install (offline, frozen)..."
    if ! pnpm install --frozen-lockfile --ignore-scripts --offline 2>&1 | tail -10; then
        echo "[validation-setup] offline install failed; retrying with network..."
        pnpm install --frozen-lockfile --ignore-scripts 2>&1 | tail -10
    fi
fi

export PATH="$REPO_DIR/node_modules/.bin:$PATH"

echo "[validation-setup] ready: $REPO_DIR (node=$(node --version), pnpm=$(pnpm --version))"
