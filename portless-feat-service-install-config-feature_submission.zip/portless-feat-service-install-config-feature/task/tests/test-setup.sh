#!/usr/bin/env bash
# Sourced (not exec'd) by the verifier runner so env vars stay alive for
# vitest. Idempotent.
#
# The portless package's vitest suite imports runtime modules from source
# (e.g. `import { handleService } from "./service.js"`, which vitest resolves
# to ./service.ts). No dist build is required to run the focused service
# tests, so this script only needs the workspace's node_modules present.

set -e

REPO_DIR="${REPO_DIR:-/repo/portless}"
cd "$REPO_DIR"

node --version
pnpm --version

# Install workspace deps if missing. The image bakes the full dependency
# closure with a warm pnpm store at the base commit, so the normal path is a
# no-op offline replay; the online fallback only fires if node_modules was
# wiped (e.g. an agent reinstall) and the store is cold.
if [ ! -d "node_modules/.pnpm" ]; then
    echo "[test-setup] pnpm install (offline, frozen)..."
    if ! pnpm install --frozen-lockfile --ignore-scripts --offline 2>&1 | tail -10; then
        echo "[test-setup] offline install failed; retrying with network..."
        pnpm install --frozen-lockfile --ignore-scripts 2>&1 | tail -10
    fi
fi

# Make pnpm bin and node_modules/.bin available.
export PATH="$REPO_DIR/node_modules/.bin:$PATH"

echo "[test-setup] ready: $REPO_DIR (node=$(node --version), pnpm=$(pnpm --version))"
