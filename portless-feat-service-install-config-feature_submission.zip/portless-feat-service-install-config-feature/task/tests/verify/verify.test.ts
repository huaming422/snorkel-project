// @ts-nocheck
//
// Behavioral verifier for the "configurable service install" feature.
//
// Everything is driven through the package's pre-existing, stable public entry
// point `handleService(args, { entryScript, runner })` — the same interface the
// CLI dispatches `service install | uninstall | status` to, and the same one
// the package's own tests exercise. We assert only on observable effects: the
// injected command `runner`'s calls, the mocked filesystem writes, the process
// exit code, and the text `service status` prints. No implementation-internal
// helper, type, or field name is imported, so every valid implementation shape (a
// shared config type or inlined parsing; command-only, env-only, or both
// persistence channels; any serialization that round-trips) passes.
//
// Five guards:
//   - lan_requires_mdns   (fail_to_pass): a LAN install is refused, and nothing
//     is written, on a platform that cannot publish over mDNS.
//   - stop_old_and_new_port (fail_to_pass): changing the service port stops the
//     proxy running on the old port, not only the new one. The old port is seeded
//     through both a live-state probe and a prior service file, so either
//     discovery mechanism satisfies the guard.
//   - bakes_config_into_service_file (fail_to_pass): a non-default port is
//     persisted into a bootable channel of the service — the launched command or
//     a PORTLESS_PORT env entry — not only a status-only sidecar.
//   - status_reads_config_from_service_file (fail_to_pass): status reports the
//     configuration the installed service actually boots with, recovered from the
//     persisted service file, NOT re-derived from the caller's ambient
//     environment. The install-time PORTLESS_* env is cleared before status runs
//     (the post-reboot reality), so an implementation that reads config back from
//     process.env at status time reports stale defaults and fails.
//   - default_install_443 (pass_to_pass): a plain `service install` still runs
//     HTTPS on 443 and status still reports "Proxy on 443" — regression guard.
//
// The node:fs / certs / utils / mdns / cli-utils mocks mirror the package's own
// service.test.ts: filesystem effects and the mDNS/discovery collaborators are
// stubbed so the install path is observable without touching the real OS.

import os from "node:os";
import path from "node:path";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { handleService } from "./service.js";

vi.mock("node:fs", async (importOriginal) => {
  const mod = await importOriginal<typeof import("node:fs")>();
  return {
    ...mod,
    chmodSync: vi.fn(),
    existsSync: vi.fn(mod.existsSync),
    mkdirSync: vi.fn(),
    readFileSync: vi.fn(mod.readFileSync),
    rmSync: vi.fn(),
    writeFileSync: vi.fn(),
  };
});

vi.mock("./certs.js", () => ({
  ensureCerts: vi.fn(() => ({
    certPath: "/fake/server.pem",
    keyPath: "/fake/server-key.pem",
    caPath: "/fake/ca.pem",
    caGenerated: false,
  })),
  isCATrusted: vi.fn(() => true),
  trustCA: vi.fn(() => ({ trusted: true })),
}));

vi.mock("./utils.js", () => ({
  fixOwnership: vi.fn(),
}));

vi.mock("./mdns.js", () => ({
  isMdnsSupported: vi.fn(() => ({ supported: true })),
}));

vi.mock("./cli-utils.js", async (importOriginal) => {
  const mod = await importOriginal<typeof import("./cli-utils.js")>();
  return {
    ...mod,
    discoverState: vi.fn(mod.discoverState),
    isProxyRunning: vi.fn(mod.isProxyRunning),
  };
});

const { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } = await import("node:fs");
const { isMdnsSupported } = await import("./mdns.js");
const { discoverState, isProxyRunning } = await import("./cli-utils.js");
const actualCliUtils = await vi.importActual<typeof import("./cli-utils.js")>("./cli-utils.js");
const actualFs = await vi.importActual<typeof import("node:fs")>("node:fs");

const originalPlatform = process.platform;
const originalGetuid = process.getuid;

function setPlatform(platform: NodeJS.Platform): void {
  Object.defineProperty(process, "platform", { configurable: true, value: platform });
}

function setGetuid(uid: number): void {
  Object.defineProperty(process, "getuid", { configurable: true, value: () => uid });
}

afterEach(() => {
  Object.defineProperty(process, "platform", { configurable: true, value: originalPlatform });
  Object.defineProperty(process, "getuid", { configurable: true, value: originalGetuid });
  vi.mocked(existsSync).mockRestore();
  vi.mocked(mkdirSync).mockRestore();
  vi.mocked(readFileSync).mockRestore();
  vi.mocked(rmSync).mockRestore();
  vi.mocked(writeFileSync).mockRestore();
  vi.mocked(isMdnsSupported).mockReturnValue({ supported: true });
  vi.mocked(discoverState).mockReset();
  vi.mocked(discoverState).mockImplementation(actualCliUtils.discoverState);
  vi.mocked(isProxyRunning).mockReset();
  vi.mocked(isProxyRunning).mockImplementation(actualCliUtils.isProxyRunning);
});

describe("portless service install — configurable", () => {
  let exitSpy: ReturnType<typeof vi.spyOn>;
  let logSpy: ReturnType<typeof vi.spyOn>;
  let errorSpy: ReturnType<typeof vi.spyOn>;

  beforeEach(() => {
    exitSpy = vi.spyOn(process, "exit").mockImplementation(() => {
      throw new Error("process.exit");
    });
    logSpy = vi.spyOn(console, "log").mockImplementation(() => {});
    errorSpy = vi.spyOn(console, "error").mockImplementation(() => {});
  });

  afterEach(() => {
    exitSpy.mockRestore();
    logSpy.mockRestore();
    errorSpy.mockRestore();
  });

  // fail_to_pass — a LAN-mode install must be refused, writing nothing, on a
  // platform that cannot publish over mDNS. On the pre-fix code the --lan option
  // is unknown/ignored and a default service gets installed anyway.
  it("lan_requires_mdns: refuses a LAN install and writes nothing when mDNS is unsupported", async () => {
    setPlatform("win32");
    vi.mocked(isMdnsSupported).mockReturnValue({
      supported: false,
      reason: "mDNS publishing is not supported on this platform",
    });
    const runner = vi.fn(() => ({ status: 0, stdout: "", stderr: "" }));

    await expect(
      handleService(["service", "install", "--lan"], {
        entryScript: "/fake/cli.js",
        runner,
      })
    ).rejects.toThrow("process.exit");

    expect(exitSpy).toHaveBeenCalledWith(1);
    expect(runner).not.toHaveBeenCalled();
    expect(mkdirSync).not.toHaveBeenCalled();
    expect(writeFileSync).not.toHaveBeenCalled();
    // An error was surfaced naming the offending feature. We assert only that
    // the rejection mentions either LAN (public CLI vocabulary) or mDNS (the
    // underlying capability) — both name the problem; the exact phrasing is a
    // solution choice, so pinning a single token would be unfair coupling.
    const output = errorSpy.mock.calls.map((c: unknown[]) => c.join(" ")).join("\n");
    expect(errorSpy).toHaveBeenCalled();
    expect(/lan|mdns/i.test(output)).toBe(true);
  });

  // fail_to_pass — when the install port differs from the proxy that is already
  // installed/running on the old port, BOTH the old port and the new target
  // port get a `proxy stop`. On the pre-fix code only the fixed 443 port is ever
  // stopped, so the old proxy is orphaned.
  //
  // How the install discovers the old port is a solution choice, so BOTH viable
  // channels are seeded: a live-state probe (`discoverState()`/`isProxyRunning()`)
  // AND a prior installed service file on the (in-memory) filesystem that bakes
  // the old port into both its command and its env block. An implementation that
  // reads the old port from either source satisfies the guard. We assert the set
  // of stopped ports CONTAINS the old and new ports (not an exact ordered array),
  // so the discovery mechanism and stop ordering stay the agent's choice.
  it("stop_old_and_new_port: stops the discovered old port and the new install port", async () => {
    setPlatform("linux");
    setGetuid(0);
    const oldPort = 19000;
    const newPort = 19001;

    // Channel A: live-state discovery reports the old proxy running.
    vi.mocked(discoverState).mockResolvedValue({
      dir: "/tmp/portless-service-current-test",
      port: oldPort,
      tls: true,
      tld: "localhost",
      lanMode: false,
      lanIp: null,
    });
    vi.mocked(isProxyRunning).mockImplementation(async (port) => port === oldPort);

    // Channel B: a prior installed systemd unit already baked the old port, so a
    // service-file reader can recover it too. A shared in-memory store backs the
    // fs mocks; it is pre-seeded with a unit that carries the old port in both a
    // `--port` command arg and a `PORTLESS_PORT` env line, and still services the
    // read of /etc/passwd (resolveUserContext) from the real fs.
    const unitPath = "/etc/systemd/system/portless.service";
    // Seed Channel B in the repo's real systemdEscape format (service.ts:241-256):
    //   Environment lines: `Environment=KEY="quoted_value"` (only the VALUE is quoted)
    //   ExecStart: each ARGUMENT token is individually double-quoted and joined with spaces
    // Both the `--port` command arg and the PORTLESS_PORT env line carry the old port
    // so either discovery mechanism (ExecStart argv-parse or Environment-parse) satisfies
    // the guard. Format matches exactly what buildSystemdUnit + systemdEscape() produce.
    function sdQuote(s: string): string { return `"${s.replace(/\\/g, "\\\\").replace(/"/g, '\\"')}"`; }
    const seededUnit = [
      "[Unit]",
      "[Service]",
      `Environment=PORTLESS_STATE_DIR=${sdQuote("/var/lib/portless")}`,
      `Environment=PORTLESS_PORT=${sdQuote(String(oldPort))}`,
      `ExecStart=${[process.execPath, "/fake/cli.js", "proxy", "start", "--port", String(oldPort)].map(sdQuote).join(" ")}`,
      "",
    ].join("\n");
    // Channel C: a JSON sidecar at stateDir/service.config.json — seeds implementations
    // that persist config as JSON rather than reading the service unit file. The stateDir
    // on linux when running as root (getuid=0, homedir=/root) is /root/.portless, matching
    // what defaultStateDir("linux", os.homedir()) produces in the test container.
    const sidecarPath = path.join(os.homedir(), ".portless", "service.config.json");
    const sidecarJson = JSON.stringify({ port: oldPort });
    const store = new Map<string, string>([[unitPath, seededUnit], [sidecarPath, sidecarJson]]);
    vi.mocked(writeFileSync).mockImplementation((p: unknown, data: unknown) => {
      store.set(String(p), String(data));
    });
    vi.mocked(readFileSync).mockImplementation(((p: unknown, ...rest: unknown[]) => {
      const key = String(p);
      if (store.has(key)) return store.get(key) as string;
      return (actualFs.readFileSync as (...a: unknown[]) => unknown)(p, ...rest);
    }) as typeof readFileSync);
    vi.mocked(existsSync).mockImplementation(((p: unknown) => {
      const key = String(p);
      if (store.has(key)) return true;
      return (actualFs.existsSync as (p: unknown) => boolean)(p);
    }) as typeof existsSync);

    const runner = vi.fn((_: string, _args: string[]) => ({
      status: 0,
      stdout: "",
      stderr: "",
    }));

    await handleService(["service", "install", "--port", newPort.toString()], {
      entryScript: "/fake/cli.js",
      runner,
    });

    const stopPorts = new Set(
      runner.mock.calls
        .filter(
          ([command, args]) =>
            command === process.execPath &&
            args[0] === "/fake/cli.js" &&
            args[1] === "proxy" &&
            args[2] === "stop"
        )
        .flatMap(([, args]) => args.filter((a: string) => a === oldPort.toString() || a === newPort.toString()))
    );
    expect(stopPorts).toContain(oldPort.toString());
    expect(stopPorts).toContain(newPort.toString());
  });

  // fail_to_pass — a non-default install must persist the chosen port into a
  // channel the service actually boots from: either the launched proxy command
  // (`--port 9999` on the ExecStart line) or a `PORTLESS_PORT` entry the service
  // environment carries into that command. Either channel is accepted; what the
  // guard rejects is persisting the port nowhere the booted proxy can read it
  // (e.g. only in a status sidecar), which would make status lie after a reboot.
  // On the pre-fix code the --port option is ignored and the unit always targets
  // 443, so neither channel carries 9999.
  it("bakes_config_into_service_file: a non-default port is written into a bootable channel", async () => {
    setPlatform("linux");
    setGetuid(0);
    const targetPort = 9999;
    vi.mocked(existsSync).mockReturnValue(false);
    vi.mocked(discoverState).mockResolvedValue({
      dir: "/tmp/portless-service-bake-test",
      port: targetPort,
      tls: true,
      tld: "localhost",
      lanMode: false,
      lanIp: null,
    });
    vi.mocked(isProxyRunning).mockResolvedValue(false);
    const runner = vi.fn((_: string, _args: string[]) => ({
      status: 0,
      stdout: "",
      stderr: "",
    }));

    await handleService(["service", "install", "--port", targetPort.toString()], {
      entryScript: "/fake/cli.js",
      runner,
    });

    // The install wrote the systemd unit to the repo-owned unit path.
    const unitWrite = vi
      .mocked(writeFileSync)
      .mock.calls.find(([file]) => file === "/etc/systemd/system/portless.service");
    expect(unitWrite).toBeDefined();
    const unit = String(unitWrite![1]);

    // Only the boot-time lines count: the launched command (ExecStart=) and the
    // service environment (Environment=). The port must appear in one of them.
    const bootLines = unit
      .split("\n")
      .filter((line) => line.startsWith("ExecStart=") || line.startsWith("Environment="));
    const execStart = bootLines.find((line) => line.startsWith("ExecStart="));
    const envLines = bootLines.filter((line) => line.startsWith("Environment="));

    // Parse the ExecStart argv by stripping the repo's per-token systemd quoting:
    // systemdEscape() wraps every arg in double-quotes → `"--port" "9999"`.
    // Split on whitespace, strip surrounding quotes from each token, then test
    // for a --port/-p flag immediately followed by targetPort in the argv list.
    const inCommand = (() => {
      if (execStart === undefined) return false;
      const raw = execStart.slice("ExecStart=".length);
      const argv = raw.match(/"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'|\S+/g) ?? [];
      const tokens = argv.map((t) => t.replace(/^["']|["']$/g, "").replace(/\\(.)/g, "$1"));
      for (let i = 0; i < tokens.length - 1; i++) {
        if ((tokens[i] === "--port" || tokens[i] === "-p") && tokens[i + 1] === String(targetPort)) {
          return true;
        }
      }
      return false;
    })();
    const inEnv = envLines.some((line) => new RegExp(`PORTLESS_PORT[="']*${targetPort}(\\b|["'])`).test(line));
    expect(inCommand || inEnv).toBe(true);
  });

  // fail_to_pass — status must report the configuration the installed service
  // actually boots with, recovered from the persisted service file — NOT
  // re-derived from the caller's ambient environment. This is the post-reboot
  // reality the feature promises: the shell that runs `service status` after a
  // restart has none of the PORTLESS_* vars that were present at install time.
  //
  // The install is driven with a non-default port/TLD/wildcard (through flags)
  // and a custom state directory (through PORTLESS_STATE_DIR, the pre-existing
  // surface). Every PORTLESS_* var is then CLEARED before status runs, so the
  // only place the chosen configuration still lives is the service file the
  // install wrote. A shared in-memory store backs the fs mocks so that
  // write-then-read round trip is observable. An implementation that reads its
  // config back from the file reports the installed values; one that re-reads
  // process.env (or falls back to spec defaults) at status time reports the
  // stale defaults (443 / localhost / default state dir) and fails. On the
  // pre-fix code status ignores the install options entirely and prints the
  // fixed 443 output, so it fails here too.
  //
  // How each field is labelled is a solution choice, so we assert only that the
  // unambiguous VALUE tokens — the chosen port, TLD, and state directory —
  // appear in the status output, never a fixed label string.
  it("status_reads_config_from_service_file: status reports the installed config after the install-time env is cleared", async () => {
    setPlatform("linux");
    setGetuid(0);
    const customPort = 8080;
    const customTld = "proxytest";
    const customStateDir = "/srv/portless-coldread";

    // Shared in-memory store: the install writes the service file here and status
    // reads it back from here. How the chosen config is encoded in the file is a
    // solution choice; the store accepts whatever the install writes and hands it
    // back to status as-is.
    const store = new Map<string, string>();
    vi.mocked(writeFileSync).mockImplementation((p: unknown, data: unknown) => {
      store.set(String(p), String(data));
    });
    vi.mocked(readFileSync).mockImplementation(((p: unknown, ...rest: unknown[]) => {
      const key = String(p);
      if (store.has(key)) return store.get(key) as string;
      return (actualFs.readFileSync as (...a: unknown[]) => unknown)(p, ...rest);
    }) as typeof readFileSync);
    vi.mocked(existsSync).mockImplementation(((p: unknown) => {
      const key = String(p);
      if (store.has(key)) return true;
      return (actualFs.existsSync as (p: unknown) => boolean)(p);
    }) as typeof existsSync);
    vi.mocked(discoverState).mockResolvedValue({
      dir: customStateDir,
      port: customPort,
      tls: false,
      tld: customTld,
      lanMode: false,
      lanIp: null,
    });
    vi.mocked(isProxyRunning).mockResolvedValue(false);
    const runner = vi.fn((_: string, _args: string[]) => ({
      status: 0,
      stdout: "",
      stderr: "",
    }));

    // The custom state directory is supplied through the pre-existing
    // PORTLESS_STATE_DIR surface (the same one `proxy start` honours), so the
    // guard does not depend on any particular new flag name the implementation
    // might choose for it.
    const portlessEnvKeys = [
      "PORTLESS_STATE_DIR",
      "PORTLESS_PORT",
      "PORTLESS_HTTPS",
      "PORTLESS_LAN",
      "PORTLESS_LAN_IP",
      "PORTLESS_TLD",
      "PORTLESS_WILDCARD",
      "PORTLESS_CERT",
      "PORTLESS_KEY",
    ];
    const savedEnv: Record<string, string | undefined> = {};
    for (const key of portlessEnvKeys) savedEnv[key] = process.env[key];

    try {
      process.env.PORTLESS_STATE_DIR = customStateDir;
      await handleService(
        ["service", "install", "--port", String(customPort), "--no-tls", "--tld", customTld, "--wildcard"],
        { entryScript: "/fake/cli.js", runner }
      );

      // Post-reboot reality: the status shell carries none of the install-time
      // PORTLESS_* vars. The configuration now lives only in the service file.
      for (const key of portlessEnvKeys) delete process.env[key];

      logSpy.mockClear();
      await handleService(["service", "status"], {
        entryScript: "/fake/cli.js",
        runner,
      });
    } finally {
      for (const key of portlessEnvKeys) {
        if (savedEnv[key] === undefined) delete process.env[key];
        else process.env[key] = savedEnv[key];
      }
    }

    const output = logSpy.mock.calls.map((c: unknown[]) => c.join(" ")).join("\n");
    // The chosen port, TLD, and state directory were recovered from the service
    // file, not re-derived from the (now empty) environment or the spec defaults.
    // An implementation that reads config back from process.env at status time
    // reports the stale default state directory here and fails the last assertion.
    expect(output).toContain(String(customPort));
    expect(output).toContain(customTld);
    expect(output).toContain(customStateDir);
  });

  // pass_to_pass — a plain `service install` with no options still installs the
  // HTTPS proxy on 443 and status still reports "Proxy on 443". Passes on both
  // pre- and post-fix code: a backward-compatibility regression guard.
  it("default_install_443: a bare install still targets 443 and status reports it", async () => {
    setPlatform("linux");
    setGetuid(0);
    // Wire an in-memory round-trip store so install→status exercises the real
    // file read-back path. The contract is: a bare install bakes the default
    // port (443) into the service file and status reads it back and reports it.
    // How the port is encoded in the file is a solution choice — the store
    // accepts whatever the agent writes and hands it back to status as-is.
    const store443 = new Map<string, string>();
    vi.mocked(writeFileSync).mockImplementation((p: unknown, data: unknown) => {
      store443.set(String(p), String(data));
    });
    vi.mocked(readFileSync).mockImplementation(((p: unknown, ...rest: unknown[]) => {
      const key = String(p);
      if (store443.has(key)) return store443.get(key) as string;
      return (actualFs.readFileSync as (...a: unknown[]) => unknown)(p, ...rest);
    }) as typeof readFileSync);
    vi.mocked(existsSync).mockImplementation(((p: unknown) => {
      const key = String(p);
      if (store443.has(key)) return true;
      return (actualFs.existsSync as (p: unknown) => boolean)(p);
    }) as typeof existsSync);
    vi.mocked(discoverState).mockResolvedValue({
      dir: "/tmp/portless-service-default-test",
      port: 443,
      tls: true,
      tld: "localhost",
      lanMode: false,
      lanIp: null,
    });
    vi.mocked(isProxyRunning).mockResolvedValue(false);
    const runner = vi.fn((_: string, _args: string[]) => ({
      status: 0,
      stdout: "",
      stderr: "",
    }));

    await handleService(["service", "install"], {
      entryScript: "/fake/cli.js",
      runner,
    });

    // A service file was written to the (repo-owned, pre-existing) systemd unit
    // path. We assert ONLY that the install persisted a unit there — never the
    // unit's contents, because how the chosen port is persisted (as a `--port`
    // flag on the launched command, as a `PORTLESS_*` Environment= line, or
    // both) is a solution choice. The port value is read back behaviorally via
    // `service status` below.
    const unitWrite = vi
      .mocked(writeFileSync)
      .mock.calls.find(([file]) => file === "/etc/systemd/system/portless.service");
    expect(unitWrite).toBeDefined();

    // The install stops the proxy on 443.
    const stopCalls = runner.mock.calls.filter(
      ([command, args]) =>
        command === process.execPath &&
        args[0] === "/fake/cli.js" &&
        args[1] === "proxy" &&
        args[2] === "stop"
    );
    const stoppedPorts = new Set(stopCalls.flatMap(([, args]) => args.filter((a: string) => /^\d+$/.test(a))));
    expect(stoppedPorts).toContain("443");

    // And status reports the default port value (443). Any reasonable rendering
    // that includes "443" in its output satisfies the guard.
    await handleService(["service", "status"], {
      entryScript: "/fake/cli.js",
      runner,
    });
    const output = logSpy.mock.calls.map((c: unknown[]) => c.join(" ")).join("\n");
    expect(output).toContain("443");
  });
});
