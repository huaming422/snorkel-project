## Task

Right now `portless service install` always installs the proxy with the built-in defaults: HTTPS on port 443 with `.localhost` names. `proxy start` already accepts a full set of options (a custom port, HTTPS on or off, LAN mode with a pinned LAN IP, a custom TLD, wildcard routing, a custom certificate and key, a custom state directory) plus the matching `PORTLESS_*` environment variables, but none of that carries into the installed service.

Let `service install` take those same options: the flags `proxy start` already accepts (`--port`, `--https`/`--no-tls`, `--lan`, `--ip`, `--tld`, `--wildcard`, `--cert` and `--key`) together with their matching `PORTLESS_*` environment variables (for example `PORTLESS_STATE_DIR` for a custom state directory). Bake the chosen configuration into the startup service, so the proxy comes up with it on every boot instead of only for the current session. `service status` should then report the configuration the installed service is actually running with, rather than assuming the defaults. A bare `service install` with no options should still install that same default.

LAN mode needs the platform to advertise LAN names over mDNS, so a `--lan` install where mDNS is unsupported should be rejected before any service file is written.

Re-installing changes a service that is already there: when the port changes, stop the proxy on the old port as well as the new one, so switching ports does not orphan the previous proxy.

## User stories / requirements

- Installing the service with a specific set of options (a custom port, HTTPS off, a custom TLD, wildcard on, a custom state directory) and then checking status reports those same values back. A LAN-mode install with a pinned LAN IP shows up as LAN mode with that IP.
- Installing with an unusable configuration (a certificate without its matching key, an out-of-range port, or a malformed TLD) fails with an error naming the problem and leaves no service file behind. Uninstalling still works even with invalid proxy settings in the environment.
