#!/usr/bin/env bash
# Environment bootstrap for the verifier. Sourced (not exec'd) so env vars set
# here stay live for the verifier subprocess. The image already baked the full
# locked dependency closure at the base commit (npm ci --ignore-scripts) and
# built @librechat/data-provider, @librechat/data-schemas and @librechat/api,
# so this script fetches nothing — it only rebuilds the workspace packages so an
# agent edit under packages/api/src is reflected in the dist/ that the api/
# strategy suite resolves through jest.requireActual('@librechat/api').

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/LibreChat}"
export REPO_DIR
cd "$REPO_DIR"

# Fail a cache miss fast instead of hanging on a dead network: the agent phase
# and the offline fold run with no network, and every dependency is already in
# node_modules, so npm should never reach out. Scoped to this shell only.
export npm_config_offline=true
export npm_config_audit=false
export npm_config_fund=false

# The api/ strategy suite mocks @librechat/api but pulls the real package
# exports via jest.requireActual('@librechat/api'), which resolves the
# package's built dist/. The packages/api suite imports ./oidc and ./env from source (babel-jest
# transpiles TS directly). So an edit can land in two places: source for
# packages/api, and dist for api/. Rebuild the three workspace packages in
# dependency order (data-provider -> data-schemas -> api) so both suites observe
# a consistent, up-to-date tree. These builds compile local TypeScript only and
# need no network.
echo "test-setup.sh: rebuilding workspace packages (data-provider, data-schemas, api)..."
npm run build:data-provider > /tmp/pkg-build.log 2>&1 || { tail -60 /tmp/pkg-build.log; exit 1; }
npm run build:data-schemas >> /tmp/pkg-build.log 2>&1 || { tail -60 /tmp/pkg-build.log; exit 1; }
npm run build:api          >> /tmp/pkg-build.log 2>&1 || { tail -60 /tmp/pkg-build.log; exit 1; }

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR node=$(node --version)"
