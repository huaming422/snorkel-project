// Strategy-surface checks for the OpenID bearer verify path.
//
// Interface under test: `openIdJwtLogin(openIdConfig)` from
// api/strategies/openIdJwtStrategy.js, a pre-existing export. We drive its
// captured passport-jwt verify callback (same technique the repo's own suite
// uses) and assert only on the observable result: what lands in
// `user.federatedTokens.access_token`. No internal helper is imported or named.
//
// The `@librechat/api` mock spreads the real built module and overrides only the
// collaborators that need stubbing (user lookup, cache, proxy), so any export
// added to that package is still available to the strategy.

const { SystemRoles } = require('librechat-data-provider');

let capturedVerifyCallback;

jest.mock('passport-jwt', () => ({
  Strategy: jest.fn((opts, verifyCallback) => {
    capturedVerifyCallback = verifyCallback;
    return { name: 'jwt' };
  }),
  ExtractJwt: {
    fromAuthHeaderAsBearerToken: jest.fn(() => 'mock-extractor'),
  },
}));
jest.mock('jwks-rsa', () => ({
  passportJwtSecret: jest.fn(() => 'mock-secret-provider'),
}));
jest.mock('https-proxy-agent', () => ({
  HttpsProxyAgent: jest.fn(),
}));

const mockGetTenantId = jest.fn();
const mockRunAsSystem = jest.fn((callback) => callback());
jest.mock('@librechat/data-schemas', () => ({
  logger: { info: jest.fn(), warn: jest.fn(), debug: jest.fn(), error: jest.fn() },
  getTenantId: mockGetTenantId,
  runAsSystem: mockRunAsSystem,
}));

// Spread the real package, then stub only the collaborators this surface needs.
jest.mock('@librechat/api', () => {
  const actual = jest.requireActual('@librechat/api');
  return {
    ...actual,
    isEnabled: jest.fn(() => false),
    findOpenIDUser: jest.fn(),
    getOpenIdIssuer: jest.fn(() => 'https://issuer.example.com'),
    buildAuthUserDocCacheKey: jest.fn(() => 'auth-user-doc-key'),
    getAuthUserDocCacheMode: jest.fn(() => 'off'),
    getCachedAuthUserDoc: jest.fn(),
    getValidOpenIdReuseUserId: jest.fn(),
    invalidateCachedAuthUserDoc: jest.fn(),
    setCachedAuthUserDoc: jest.fn(),
    getHttpsProxyAgent: jest.fn(() => undefined),
    math: jest.fn((val, fallback) => fallback),
  };
});
jest.mock('~/models', () => ({
  findUser: jest.fn(),
  updateUser: jest.fn(),
  isAgentTriggerPrincipalActive: jest.fn(() => true),
}));
jest.mock('~/server/services/Files/strategies', () => ({
  getStrategyFunctions: jest.fn(() => ({
    saveBuffer: jest.fn().mockResolvedValue('/fake/path/to/avatar.png'),
  })),
}));
jest.mock('~/server/services/Config', () => ({
  getAppConfig: jest.fn().mockResolvedValue({}),
}));
const mockAuthUserDocCacheStore = {
  get: jest.fn(),
  set: jest.fn(),
  delete: jest.fn(),
};
jest.mock('~/cache/getLogStores', () => jest.fn(() => mockAuthUserDocCacheStore));

const { findOpenIDUser } = require('@librechat/api');
const openIdJwtLogin = require('./openIdJwtStrategy');
const { updateUser } = require('~/models');

const mockOpenIdConfig = {
  serverMetadata: () => ({
    issuer: 'https://issuer.example.com',
    jwks_uri: 'https://example.com/.well-known/jwks.json',
  }),
};

const baseUser = {
  _id: { toString: () => 'user-abc' },
  role: SystemRoles.USER,
  provider: 'openid',
};

const payload = {
  sub: 'oidc-123',
  email: 'test@example.com',
  iss: 'https://issuer.example.com',
  exp: 9999999999,
};

const encodeSegment = (value) => Buffer.from(JSON.stringify(value)).toString('base64');
const makeJwt = (claims, header = { alg: 'RS256' }) =>
  `${encodeSegment(header)}.${encodeSegment(claims)}.signature`;

// Apply env around strategy construction: the configured audience set is read
// when `openIdJwtLogin` is called, and the captured callback closes over it.
function withEnv(env, callback) {
  const previous = Object.fromEntries(Object.keys(env).map((key) => [key, process.env[key]]));
  Object.entries(env).forEach(([key, value]) => {
    if (value === undefined) {
      delete process.env[key];
      return;
    }
    process.env[key] = value;
  });
  try {
    return callback();
  } finally {
    Object.entries(previous).forEach(([key, value]) => {
      if (value === undefined) {
        delete process.env[key];
        return;
      }
      process.env[key] = value;
    });
  }
}

async function invokeVerify(req, verifyPayload) {
  return new Promise((resolve, reject) => {
    capturedVerifyCallback(req, verifyPayload, (err, user, info) => {
      if (err) {
        return reject(err);
      }
      resolve({ user, info });
    });
  });
}

const resourceEnv = { OPENID_CLIENT_ID: 'client-id', OPENID_AUDIENCE: 'api://resource-app' };

// No stored access token: the strategy reads the inbound bearer as its only
// candidate, so the reuse decision is exactly what each case probes.
function reuseRequest(authorizationToken) {
  return {
    headers: {
      authorization: `Bearer ${authorizationToken}`,
      cookie: 'openid_id_token=cookie-id; refreshToken=cookie-refresh',
    },
  };
}

beforeEach(() => {
  jest.clearAllMocks();
  mockGetTenantId.mockReturnValue(undefined);
  mockRunAsSystem.mockImplementation((callback) => callback());
  findOpenIDUser.mockResolvedValue({ user: { ...baseUser }, error: null, migration: false });
  updateUser.mockResolvedValue({});
  openIdJwtLogin(mockOpenIdConfig);
});

describe('OpenID bearer reuse: refusing a non-access-token bearer', () => {
  it('leaves the stored access token unset when the inbound bearer is an ID token for the client id', async () => {
    withEnv(resourceEnv, () => openIdJwtLogin(mockOpenIdConfig));

    const claims = { ...payload, aud: 'client-id', nonce: 'n-0S6_WzA2Mj', tid: 'tenant-1' };
    const { user } = await invokeVerify(reuseRequest(makeJwt(claims)), claims);

    expect(user.federatedTokens.access_token).toBeUndefined();
    expect(user.federatedTokens.id_token).toBe('cookie-id');
  });

  it('leaves it unset for a multi-audience ID token that also names a configured resource', async () => {
    withEnv(resourceEnv, () => openIdJwtLogin(mockOpenIdConfig));

    const claims = { ...payload, aud: ['client-id', 'api://resource-app'], nonce: 'n-0S6' };
    const { user } = await invokeVerify(reuseRequest(makeJwt(claims)), claims);

    expect(user.federatedTokens.access_token).toBeUndefined();
  });

  it('leaves it unset for an ID token carrying a provider-mapped scope claim', async () => {
    withEnv(resourceEnv, () => openIdJwtLogin(mockOpenIdConfig));

    const claims = { ...payload, aud: 'client-id', scope: 'openid email profile' };
    const { user } = await invokeVerify(reuseRequest(makeJwt(claims)), claims);

    expect(user.federatedTokens.access_token).toBeUndefined();
  });

  it('leaves it unset when an ID-token-binding hash claim is present despite a resource audience', async () => {
    withEnv(resourceEnv, () => openIdJwtLogin(mockOpenIdConfig));

    const claims = { ...payload, aud: 'api://resource-app', scp: 'User.Read', at_hash: 'HK6E_P6Dh8Y93mRN' };
    const { user } = await invokeVerify(reuseRequest(makeJwt(claims)), claims);

    expect(user.federatedTokens.access_token).toBeUndefined();
  });

  it('leaves it unset when no client id is configured and only a scope corroborates', async () => {
    withEnv({ OPENID_CLIENT_ID: undefined, OPENID_AUDIENCE: 'api://resource-app' }, () =>
      openIdJwtLogin(mockOpenIdConfig),
    );

    const claims = { ...payload, aud: 'api://resource-app', scp: 'User.Read' };
    const { user } = await invokeVerify(reuseRequest(makeJwt(claims)), claims);

    expect(user.federatedTokens.access_token).toBeUndefined();
  });

  it('leaves it unset for an ID token when only the client id is configured', async () => {
    withEnv({ OPENID_CLIENT_ID: 'client-id', OPENID_AUDIENCE: undefined }, () =>
      openIdJwtLogin(mockOpenIdConfig),
    );

    const claims = { ...payload, aud: 'client-id', scope: 'openid profile', nonce: 'n-1' };
    const { user } = await invokeVerify(reuseRequest(makeJwt(claims)), claims);

    expect(user.federatedTokens.access_token).toBeUndefined();
    expect(user.federatedTokens.id_token).toBe('cookie-id');
  });

  it('leaves it unset when a c_hash claim is present despite a resource audience', async () => {
    withEnv(resourceEnv, () => openIdJwtLogin(mockOpenIdConfig));

    const claims = { ...payload, aud: 'api://resource-app', scp: 'User.Read', c_hash: 'LDktKdoQak3P' };
    const { user } = await invokeVerify(reuseRequest(makeJwt(claims)), claims);

    expect(user.federatedTokens.access_token).toBeUndefined();
  });

  it('leaves it unset when a hash claim is present even with the access-token header type', async () => {
    withEnv(resourceEnv, () => openIdJwtLogin(mockOpenIdConfig));

    const claims = { ...payload, aud: 'api://resource-app', at_hash: 'HK6E_P6Dh8Y93mRN' };
    const rawToken = makeJwt(claims, { alg: 'RS256', typ: 'at+jwt' });
    const { user } = await invokeVerify(reuseRequest(rawToken), claims);

    expect(user.federatedTokens.access_token).toBeUndefined();
  });
});

describe('OpenID bearer reuse: accepting a genuine access-token bearer', () => {
  it('reuses a bearer whose header declares the RFC 9068 access-token media type', async () => {
    withEnv(resourceEnv, () => openIdJwtLogin(mockOpenIdConfig));

    const rawToken = makeJwt(payload, { alg: 'RS256', typ: 'at+JWT' });
    const { user } = await invokeVerify(reuseRequest(rawToken), payload);

    expect(user.federatedTokens.access_token).toBe(rawToken);
  });

  it('reuses a bearer whose audience names a configured resource (guards the extra-audience deployment)', async () => {
    withEnv(resourceEnv, () => openIdJwtLogin(mockOpenIdConfig));

    const claims = { ...payload, aud: 'api://resource-app' };
    const rawToken = makeJwt(claims);
    const { user } = await invokeVerify(reuseRequest(rawToken), claims);

    expect(user.federatedTokens.access_token).toBe(rawToken);
  });

  it('reuses a bearer whose header uses the long application/at+jwt form', async () => {
    withEnv(resourceEnv, () => openIdJwtLogin(mockOpenIdConfig));

    const claims = { ...payload, aud: 'client-id' };
    const rawToken = makeJwt(claims, { alg: 'RS256', typ: 'Application/AT+JWT' });
    const { user } = await invokeVerify(reuseRequest(rawToken), claims);

    expect(user.federatedTokens.access_token).toBe(rawToken);
  });

  it('reuses an at+jwt bearer when no client id is configured', async () => {
    withEnv({ OPENID_CLIENT_ID: undefined, OPENID_AUDIENCE: 'api://resource-app' }, () =>
      openIdJwtLogin(mockOpenIdConfig),
    );

    const claims = { ...payload, aud: 'api://resource-app' };
    const rawToken = makeJwt(claims, { alg: 'RS256', typ: 'at+jwt' });
    const { user } = await invokeVerify(reuseRequest(rawToken), claims);

    expect(user.federatedTokens.access_token).toBe(rawToken);
  });

  it('reuses a bearer naming any entry of a comma-separated audience list', async () => {
    withEnv({ OPENID_CLIENT_ID: 'client-id', OPENID_AUDIENCE: 'api://other-app, api://resource-app' }, () =>
      openIdJwtLogin(mockOpenIdConfig),
    );

    const claims = { ...payload, aud: ['api://resource-app', 'api://unlisted'] };
    const rawToken = makeJwt(claims);
    const { user } = await invokeVerify(reuseRequest(rawToken), claims);

    expect(user.federatedTokens.access_token).toBe(rawToken);
  });
});

describe('OpenID bearer reuse: happy path untouched', () => {
  it('keeps reusing a genuinely stored access token regardless of the inbound bearer shape', async () => {
    withEnv(resourceEnv, () => openIdJwtLogin(mockOpenIdConfig));

    const req = {
      headers: { authorization: `Bearer ${makeJwt({ ...payload, aud: 'client-id' })}` },
      session: {
        openidTokens: {
          accessToken: 'session-access',
          idToken: 'session-id',
          refreshToken: 'session-refresh',
        },
      },
    };

    const { user } = await invokeVerify(req, payload);

    expect(user.federatedTokens.access_token).toBe('session-access');
  });

  it('keeps a stored cookie access token over an inbound access-token bearer', async () => {
    withEnv(resourceEnv, () => openIdJwtLogin(mockOpenIdConfig));

    const claims = { ...payload, aud: 'api://resource-app' };
    const req = {
      headers: {
        authorization: `Bearer ${makeJwt(claims, { alg: 'RS256', typ: 'at+jwt' })}`,
        cookie: 'openid_access_token=cookie-access; openid_id_token=cookie-id; refreshToken=cookie-refresh',
      },
    };

    const { user } = await invokeVerify(req, claims);

    expect(user.federatedTokens.access_token).toBe('cookie-access');
  });
});
