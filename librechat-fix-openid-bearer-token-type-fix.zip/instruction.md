## Task

On Microsoft Entra (Azure AD) OpenID setups, agent actions and MCP tool calls sometimes die with `AADSTS240002 - Input id_token cannot be used as 'assertion'`. Other users finish signing in and are immediately asked to sign in again. We only see it on servers that don't keep sessions in a persistent store, and it started recently.

If no access token is saved for the user, the server may use the request's bearer token as the access token only when that bearer is recognizably an access token. An ID token gets through the same audience validation, so passing it says nothing about the token type. Rules for the bearer:

- The bearer counts as an access token when its JWT header `typ` is the RFC 9068 access token type (`at+jwt` or `application/at+jwt`, any letter case).
- Without that header type, the audience decides. With `OPENID_CLIENT_ID` set, a bearer whose `aud` leaves out the client id and names one of the `OPENID_AUDIENCE` entries counts. If `aud` contains the client id, the bearer is not used, even when `aud` also lists a configured resource or the token carries a `scope` or `scp` claim. This holds with or without `OPENID_AUDIENCE` configured.
- A bearer that carries an `at_hash` or `c_hash` claim is never used, whatever its audience or scopes say.
- With no `OPENID_CLIENT_ID` configured, only the RFC 9068 header type qualifies.
- A bearer that doesn't qualify leaves the user with no access token for that request. It is not stored as one.
- An access token already saved for the user wins over the bearer, whatever the bearer looks like.

For a user who has a valid ID token but no usable access token, MCP and action headers resolve like this:

- `{{LIBRECHAT_OPENID_ID_TOKEN}}` becomes the ID token as long as the ID token itself hasn't expired. Once it has, the placeholder fails with the re-authentication error.
- `{{LIBRECHAT_OPENID_ACCESS_TOKEN}}` and `{{LIBRECHAT_OPENID_TOKEN}}` fail with the existing re-authentication error, which names the placeholder.
- Identity placeholders such as `{{LIBRECHAT_OPENID_USER_ID}}` are not filled in. They are left as literal text in the header.
