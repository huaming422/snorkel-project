#!/usr/bin/env bash
# Test-setup for turso-fix-stale-overflow-cells. The image pre-warms the cargo
# dependency + compile closure for turso_core (lib + tests) at the pre-fix base
# commit. The verifier applies its reproduction harness and runs two focused
# turso_core lib tests. No services to start, no data to seed, nothing to
# install (the oracle introduces no new crates).

set -euo pipefail

echo "[test-setup] Rust version:    $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:   $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Workspace root:  /repo/turso"
echo "[test-setup] Crate under test: turso_core (core/)"
echo "[test-setup] Setup complete."
