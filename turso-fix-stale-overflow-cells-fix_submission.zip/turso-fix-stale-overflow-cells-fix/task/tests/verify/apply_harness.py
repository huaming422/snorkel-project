#!/usr/bin/env python3
"""
apply_harness.py - turso-fix-stale-overflow-cells reward harness installer.

Installs the deterministic reproduction scaffolding (yield-injection plumbing +
the two regression tests) onto the AGENT'S SOLVED checkout of turso_core, so the
verifier can run the two named lib tests against the agent's fix.

WHY A PROGRAMMATIC INSTALLER (not `git apply`):
  The two regression tests live INSIDE core/storage/btree.rs's `mod tests` and
  reference crate-private internals, so they cannot be an external integration
  test. The scaffolding (a cfg-gated yield point, cursor fields, wiring, and the
  test module additions) is DELIBERATELY excluded from the agent's checkout. The
  reference fix edits the `impl Drop for BTreeCursor` region, which sits right next
  to one scaffolding block (`impl ProvidesYieldContext`), so a context-based
  `git apply` would fail on many valid solutions. Instead we insert each block
  relative to STABLE anchor lines that every correct fix preserves, and we make
  every edit idempotent and verified.

All inserted code is gated behind `#[cfg(any(test, injected_yields))]`; under
`cargo test` the `test` cfg activates it with no extra feature flag. None of this
is the agent's responsibility; it is pure test scaffolding.

Exit non-zero (loudly) if any anchor is missing or ambiguous, or if a block is
already present in a conflicting form - a silent mis-apply must never downgrade
to a vacuous pass.
"""
import sys
from pathlib import Path

REPO = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("/repo/turso")
BTREE = REPO / "core/storage/btree.rs"
EXECUTE = REPO / "core/vdbe/execute.rs"


def die(msg):
    print(f"[apply_harness] FATAL: {msg}", file=sys.stderr)
    sys.exit(3)


def insert_after(text, anchor, block, *, what):
    """Insert block immediately after the (unique) anchor line's end."""
    n = text.count(anchor)
    if n == 0:
        die(f"anchor for {what} not found: {anchor!r}")
    if n > 1:
        die(f"anchor for {what} is ambiguous ({n} matches): {anchor!r}")
    idx = text.index(anchor) + len(anchor)
    return text[:idx] + block + text[idx:]


def insert_before(text, anchor, block, *, what):
    n = text.count(anchor)
    if n == 0:
        die(f"anchor for {what} not found: {anchor!r}")
    if n > 1:
        die(f"anchor for {what} is ambiguous ({n} matches): {anchor!r}")
    idx = text.index(anchor)
    return text[:idx] + block + text[idx:]


def replace_once(text, old, new, *, what):
    n = text.count(old)
    if n == 0:
        die(f"replacement target for {what} not found")
    if n > 1:
        die(f"replacement target for {what} is ambiguous ({n} matches)")
    return text.replace(old, new, 1)


def already(text, marker, *, what):
    if marker in text:
        die(f"{what} already present in checkout (marker {marker!r}) - the agent "
            f"must not add the yield-injection scaffolding; it is reward-only.")


# ---- scaffolding blocks (verbatim from PR #7711 reproduction hunks) ----
B_IMPORTS = "#[cfg(any(test, injected_yields))]\nuse crate::mvcc::yield_hooks::{ProvidesYieldContext, YieldContext, YieldPointMarker};\nuse crate::mvcc::yield_points::inject_io_yield;"
B_YIELDMARKER = "#[cfg(any(test, injected_yields))]\n#[derive(Debug, Clone, Copy)]\n#[repr(u8)]\npub(crate) enum BTreeWriteYieldPoint {\n    AfterInsertOverflowCellBeforeBalance,\n}\n\n#[cfg(any(test, injected_yields))]\nconst BTREE_WRITE_YIELD_FAMILY: u64 = 0x4254_5245_5752_4954;\n\n#[cfg(any(test, injected_yields))]\nimpl YieldPointMarker for BTreeWriteYieldPoint {\n    const POINT_COUNT: u8 = 1;\n\n    fn ordinal(self) -> u8 {\n        self as u8\n    }\n}"
B_STRUCTFIELDS = "    #[cfg(any(test, injected_yields))]\n    yield_injector: Option<Arc<dyn crate::mvcc::yield_points::YieldInjector>>,\n    #[cfg(any(test, injected_yields))]\n    yield_instance_id: u64,"
B_INITIALIZERS = "            #[cfg(any(test, injected_yields))]\n            yield_injector: None,\n            #[cfg(any(test, injected_yields))]\n            yield_instance_id: 0,"
B_INSTALL = "    #[cfg(any(test, injected_yields))]\n    pub(crate) fn install_yield_context(&mut self, connection: &crate::Connection) {\n        self.yield_injector = connection.yield_injector();\n        self.yield_instance_id = connection.next_yield_instance_id();\n    }"
B_INJECT = "                        inject_io_yield!(\n                            self,\n                            BTreeWriteYieldPoint::AfterInsertOverflowCellBeforeBalance\n                        );"
B_PROVIDES = "#[cfg(any(test, injected_yields))]\nimpl ProvidesYieldContext for BTreeCursor {\n    fn yield_context(&self) -> YieldContext {\n        YieldContext::new(\n            self.yield_injector.clone(),\n            None,\n            self.yield_instance_id,\n            BTREE_WRITE_YIELD_FAMILY ^ self.root_page as u64,\n        )\n    }\n}"
B_TESTUSE_MVCC = "        mvcc::{\n            yield_hooks::YieldPointMarker,\n            yield_points::{YieldInjector, YieldPoint},\n        },"
B_STDIMPORT_NEW = "    use std::{\n        mem::transmute,\n        ops::Deref,\n        sync::{\n            atomic::{AtomicBool, Ordering},\n            Arc,\n        },\n    };"
B_INJECTOR = "    #[derive(Debug)]\n    struct TargetedYieldInjector {\n        point: YieldPoint,\n        selection_key: u64,\n        fired: AtomicBool,\n    }\n\n    impl TargetedYieldInjector {\n        fn new(point: YieldPoint, selection_key: u64) -> Arc<Self> {\n            Arc::new(Self {\n                point,\n                selection_key,\n                fired: AtomicBool::new(false),\n            })\n        }\n\n        fn fired(&self) -> bool {\n            self.fired.load(Ordering::Acquire)\n        }\n    }\n\n    impl YieldInjector for TargetedYieldInjector {\n        fn should_yield(&self, _instance_id: u64, selection_key: u64, point: YieldPoint) -> bool {\n            point == self.point\n                && selection_key == self.selection_key\n                && !self.fired.swap(true, Ordering::AcqRel)\n        }\n    }\n\n    fn btree_write_selection_key(root_page: i64) -> u64 {\n        BTREE_WRITE_YIELD_FAMILY ^ root_page as u64\n    }\n\n    fn query_single_i64(conn: &Arc<Connection>, sql: &str) -> i64 {\n        let mut stmt = conn.prepare(sql).unwrap();\n        match stmt.step().unwrap() {\n            StepResult::Row => stmt.row().unwrap().get::<i64>(0).unwrap(),\n            other => panic!(\"expected a row, got {other:?}\"),\n        }\n    }\n\n    fn query_single_text(conn: &Arc<Connection>, sql: &str) -> String {\n        let mut stmt = conn.prepare(sql).unwrap();\n        match stmt.step().unwrap() {\n            StepResult::Row => stmt.row().unwrap().get::<String>(0).unwrap(),\n            other => panic!(\"expected a row, got {other:?}\"),\n        }\n    }"
B_TESTS = "    #[test]\n    fn wal_reuses_freelist_leaf_after_abandoned_overflowing_insert() {\n        #[allow(clippy::arc_with_non_send_sync)]\n        let io: Arc<dyn IO> = Arc::new(MemoryIO::new());\n        let db = Database::open_file(io, \"freelist-stale-overflow.db\").unwrap();\n        let conn = db.connect().unwrap();\n\n        conn.execute(\"PRAGMA journal_mode = WAL\").unwrap();\n        conn.execute(\n            \"CREATE TABLE red_rain_308 (\n                slow_desk_238 INTEGER NOT NULL,\n                quiet_tree_398 TEXT NOT NULL,\n                smart_dog_422 REAL UNIQUE,\n                new_hill_140 TEXT,\n                light_door_957 REAL,\n                wild_dog_803 TEXT NOT NULL,\n                new_flower_28 BLOB,\n                old_fish_931 TEXT PRIMARY KEY\n            )\",\n        )\n        .unwrap();\n        conn.execute(\n            \"CREATE TABLE full_fish_194 (\n                brave_star_722 TEXT PRIMARY KEY,\n                hot_star_957 NUMERIC,\n                empty_chair_834 REAL\n            )\",\n        )\n        .unwrap();\n\n        conn.execute(\n            \"INSERT INTO red_rain_308 (\n                slow_desk_238, quiet_tree_398, smart_dog_422, new_hill_140,\n                light_door_957, wild_dog_803, new_flower_28, old_fish_931\n            ) VALUES (\n                1, 'seed', 0.24, 'seed', 1.0, 'seed', zeroblob(3600), 'existing_unique'\n            )\",\n        )\n        .unwrap();\n        for id in 2..260 {\n            conn.execute(format!(\n                \"INSERT INTO red_rain_308 (\n                    slow_desk_238, quiet_tree_398, smart_dog_422, new_hill_140,\n                    light_door_957, wild_dog_803, new_flower_28, old_fish_931\n                ) VALUES (\n                    {id}, 'quiet_tree_{id}', {id}.0, 'new_hill_{id}',\n                    1.5, 'wild_dog_{id}', zeroblob(3600), 'seed_{id}'\n                )\"\n            ))\n            .unwrap();\n        }\n\n        conn.execute(\"BEGIN\").unwrap();\n        conn.execute(\"DELETE FROM red_rain_308 WHERE old_fish_931 = 'seed_2'\")\n            .unwrap();\n        conn.execute(\"SAVEPOINT sp_91\").unwrap();\n        conn.execute(\n            \"INSERT INTO full_fish_194 (brave_star_722, hot_star_957, empty_chair_834)\n             VALUES ('sweet_fish_597', 328, 7.71)\",\n        )\n        .unwrap();\n\n        let red_rain_root_page = query_single_i64(\n            &conn,\n            \"SELECT rootpage FROM sqlite_schema\n             WHERE type = 'table' AND name = 'red_rain_308'\",\n        );\n        let injector = TargetedYieldInjector::new(\n            BTreeWriteYieldPoint::AfterInsertOverflowCellBeforeBalance.point(),\n            btree_write_selection_key(red_rain_root_page),\n        );\n        conn.set_yield_injector(Some(injector.clone()));\n        let mut abandoned = conn\n            .prepare(\n                \"INSERT INTO red_rain_308 (\n                    slow_desk_238, quiet_tree_398, smart_dog_422, new_hill_140,\n                    light_door_957, wild_dog_803, new_flower_28, old_fish_931\n                ) VALUES (\n                    926, 'dry_hill_411', 9.24, 'blue_hill_65',\n                    7.50, 'happy_moon_474', zeroblob(7200), 'smart_rock_113'\n                )\",\n            )\n            .unwrap();\n        assert!(matches!(abandoned.step().unwrap(), StepResult::Yield));\n        assert!(injector.fired());\n        abandoned.reset().unwrap();\n        drop(abandoned);\n        conn.set_yield_injector(None);\n\n        conn.execute(\"DELETE FROM red_rain_308 WHERE slow_desk_238 BETWEEN 2 AND 240\")\n            .unwrap();\n        conn.execute(\"RELEASE sp_91\").unwrap();\n\n        assert!(conn\n            .execute(\n                \"INSERT INTO red_rain_308 (\n                    slow_desk_238, quiet_tree_398, smart_dog_422, new_hill_140,\n                    light_door_957, wild_dog_803, new_flower_28, old_fish_931\n                ) VALUES (\n                    927, 'dry_hill_412', 0.24, 'blue_hill_66',\n                    7.50, 'happy_moon_475', x'736f66745f73746f6e655f313732', 'smart_rock_114'\n                )\"\n            )\n            .is_err());\n\n        for id in 300..420 {\n            conn.execute(format!(\n                \"INSERT INTO red_rain_308 (\n                    slow_desk_238, quiet_tree_398, smart_dog_422, new_hill_140,\n                    light_door_957, wild_dog_803, new_flower_28, old_fish_931\n                ) VALUES (\n                    {id}, 'quiet_tree_{id}', {id}.0, 'new_hill_{id}',\n                    1.5, 'wild_dog_{id}', zeroblob(3600), 'reuse_{id}'\n                )\"\n            ))\n            .unwrap();\n        }\n\n        conn.execute(\"ROLLBACK\").unwrap();\n        assert_eq!(query_single_text(&conn, \"PRAGMA integrity_check\"), \"ok\");\n    }\n\n    #[test]\n    fn wal_overflowing_insert_resumes_after_yield_before_balance() {\n        #[allow(clippy::arc_with_non_send_sync)]\n        let io: Arc<dyn IO> = Arc::new(MemoryIO::new());\n        let db = Database::open_file(io, \"resume-overflow-yield.db\").unwrap();\n        let conn = db.connect().unwrap();\n\n        conn.execute(\"PRAGMA journal_mode = WAL\").unwrap();\n        conn.execute(\n            \"CREATE TABLE red_rain_308 (\n                slow_desk_238 INTEGER NOT NULL,\n                quiet_tree_398 TEXT NOT NULL,\n                smart_dog_422 REAL UNIQUE,\n                new_hill_140 TEXT,\n                light_door_957 REAL,\n                wild_dog_803 TEXT NOT NULL,\n                new_flower_28 BLOB,\n                old_fish_931 TEXT PRIMARY KEY\n            )\",\n        )\n        .unwrap();\n\n        for id in 1..260 {\n            conn.execute(format!(\n                \"INSERT INTO red_rain_308 (\n                    slow_desk_238, quiet_tree_398, smart_dog_422, new_hill_140,\n                    light_door_957, wild_dog_803, new_flower_28, old_fish_931\n                ) VALUES (\n                    {id}, 'quiet_tree_{id}', {id}.0, 'new_hill_{id}',\n                    1.5, 'wild_dog_{id}', zeroblob(3600), 'seed_{id}'\n                )\"\n            ))\n            .unwrap();\n        }\n\n        let red_rain_root_page = query_single_i64(\n            &conn,\n            \"SELECT rootpage FROM sqlite_schema\n             WHERE type = 'table' AND name = 'red_rain_308'\",\n        );\n        let injector = TargetedYieldInjector::new(\n            BTreeWriteYieldPoint::AfterInsertOverflowCellBeforeBalance.point(),\n            btree_write_selection_key(red_rain_root_page),\n        );\n        conn.set_yield_injector(Some(injector.clone()));\n        let mut stmt = conn\n            .prepare(\n                \"INSERT INTO red_rain_308 (\n                    slow_desk_238, quiet_tree_398, smart_dog_422, new_hill_140,\n                    light_door_957, wild_dog_803, new_flower_28, old_fish_931\n                ) VALUES (\n                    926, 'dry_hill_411', 9.24, 'blue_hill_65',\n                    7.50, 'happy_moon_474', zeroblob(7200), 'smart_rock_113'\n                )\",\n            )\n            .unwrap();\n\n        assert!(matches!(stmt.step().unwrap(), StepResult::Yield));\n        assert!(injector.fired());\n        assert!(matches!(stmt.step().unwrap(), StepResult::Done));\n        drop(stmt);\n        conn.set_yield_injector(None);\n\n        assert_eq!(\n            query_single_i64(\n                &conn,\n                \"SELECT COUNT(*) FROM red_rain_308 WHERE old_fish_931 = 'smart_rock_113'\",\n            ),\n            1\n        );\n        assert_eq!(query_single_text(&conn, \"PRAGMA integrity_check\"), \"ok\");\n    }\n\n    #[test]\n    fn freelist_page_reuse_clears_overflow_cells() {\n        // Behavioral reuse round-trip: a page returned from the freelist must\n        // have empty overflow_cells.  The test exercises the `free_page(None,\n        // id)` path: the caller drops its PageRef before freeing, so the pager\n        // re-reads the page from its own cache.  A correct fix must clear\n        // overflow_cells at or before the freelist-pop site — inside free_page\n        // unconditionally, or at the freelist leaf/trunk reuse site — so the\n        // page comes back clean from allocate_page().\n        //\n        // A Drop-only fix (clearing only when a BTreeCursor is dropped) has no\n        // effect here: no cursor is involved.  A VDBE-layer rollback fix also\n        // does not satisfy this interface: the property being tested is\n        // \"any page handed back from the freelist arrives clean\", anchored at\n        // the pager allocate_page() boundary, not at a higher SQL/VDBE layer.\n        let (pager, _root_page, _, _) = empty_btree();\n        let page = run_until_done(|| pager.allocate_page(), pager.deref()).unwrap();\n        btree_init_page(&page, PageType::TableLeaf, 0, pager.usable_space());\n\n        // Inject stale overflow_cells directly -- no cursor involved.\n        let page_id = page.get().id;\n        {\n            let contents = page.get_contents();\n            contents.overflow_cells.push(OverflowCell {\n                index: 0,\n                payload: std::pin::Pin::new(vec![0xBEu8; 48]),\n            });\n            assert!(\n                !contents.overflow_cells.is_empty(),\n                \"test setup: overflow_cells must be non-empty before free\"\n            );\n        }\n\n        // Drop the caller's reference.  Only the pager's page cache holds the\n        // page now.  free_page(None, id) re-reads the page from cache via the\n        // None branch and must clear overflow_cells unconditionally.\n        drop(page);\n        run_until_done(\n            || pager.free_page(None, page_id),\n            pager.deref(),\n        )\n        .unwrap();\n\n        // Re-allocate.  The freelist must hand back a page with empty\n        // overflow_cells.  Any correct fix that clears at free_page or at\n        // the freelist-pop site satisfies this.\n        let reused = run_until_done(|| pager.allocate_page(), pager.deref()).unwrap();\n        assert_eq!(\n            reused.get().id,\n            page_id,\n            \"allocate_page must return the freed page for the reuse round-trip to be valid\"\n        );\n        assert!(\n            reused.get_contents().overflow_cells.is_empty(),\n            \"allocate_page must return a page with empty overflow_cells (freelist reuse round-trip)\"\n        );\n    }"

E_HELPER = "#[inline]\nfn btree_cursor_with_yield_context(\n    cursor: Box<BTreeCursor>,\n    connection: &Arc<Connection>,\n) -> Box<BTreeCursor> {\n    #[cfg(any(test, injected_yields))]\n    {\n        let mut cursor = cursor;\n        cursor.install_yield_context(connection);\n        cursor\n    }\n    #[cfg(not(any(test, injected_yields)))]\n    {\n        let _ = connection;\n        cursor\n    }\n}"
E_STDIMPORT_OLD = "    use std::{mem::transmute, ops::Deref, sync::Arc};"
E_CALL1_OLD = "            let btree_cursor = Box::new(BTreeCursor::new_index(\n                pager,\n                maybe_transform_root_page_to_positive(mv_store.as_ref(), root_page),\n                index.as_ref(),\n                num_columns,\n            )?);"
E_CALL1_NEW = "            let btree_cursor = btree_cursor_with_yield_context(\n                Box::new(BTreeCursor::new_index(\n                    pager,\n                    maybe_transform_root_page_to_positive(mv_store.as_ref(), root_page),\n                    index.as_ref(),\n                    num_columns,\n                )?),\n                &program.connection,\n            );"
E_MATCH_OLD = "            let btree_cursor: Box<dyn CursorTrait> = match cursor_type {\n                CursorType::BTreeTable(table_rc) if !table_rc.has_rowid => {\n                    Box::new(BTreeCursor::new_without_rowid_table(\n                        pager,\n                        maybe_transform_root_page_to_positive(mv_store.as_ref(), root_page),\n                        table_rc.as_ref(),\n                        num_columns,\n                    ))\n                }\n                _ => Box::new(BTreeCursor::new_table(\n                    pager,\n                    maybe_transform_root_page_to_positive(mv_store.as_ref(), root_page),\n                    num_columns,\n                )),\n            };"
E_MATCH_NEW = "            let btree_cursor: Box<dyn CursorTrait> = match cursor_type {\n                CursorType::BTreeTable(table_rc) if !table_rc.has_rowid => {\n                    btree_cursor_with_yield_context(\n                        Box::new(BTreeCursor::new_without_rowid_table(\n                            pager,\n                            maybe_transform_root_page_to_positive(mv_store.as_ref(), root_page),\n                            table_rc.as_ref(),\n                            num_columns,\n                        )),\n                        &program.connection,\n                    )\n                }\n                _ => btree_cursor_with_yield_context(\n                    Box::new(BTreeCursor::new_table(\n                        pager,\n                        maybe_transform_root_page_to_positive(mv_store.as_ref(), root_page),\n                        num_columns,\n                    )),\n                    &program.connection,\n                ),\n            };"


def patch_btree():
    if not BTREE.is_file():
        die(f"missing {BTREE}")
    t = BTREE.read_text()

    # Guard: scaffolding must be reward-only, never already in the agent checkout.
    already(t, "BTreeWriteYieldPoint", what="yield-point marker")
    already(t, "install_yield_context", what="yield-context installer")
    already(t, "TargetedYieldInjector", what="test injector")
    already(t, "wal_reuses_freelist_leaf_after_abandoned_overflowing_insert",
            what="F2P regression test")
    already(t, "freelist_page_reuse_clears_overflow_cells",
            what="freelist-reuse unit test")

    # Site 1: imports - after the `#[cfg(test)] use crate::alloc::TursoIteratorExt;`
    a_imports = "#[cfg(test)]\nuse crate::alloc::TursoIteratorExt;"
    t = insert_after(t, a_imports, "\n" + B_IMPORTS, what="btree imports")

    # Site 2: yield-point marker - before the sibling `struct ReadPayloadOverflow {`
    a_rpo = "struct ReadPayloadOverflow {"
    t = insert_before(t, a_rpo, B_YIELDMARKER + "\n\n", what="yield-point marker")

    # Site 3: BTreeCursor struct fields - after the `did_register` field decl
    a_field = "    did_register: crate::sync::atomic::AtomicBool,"
    t = insert_after(t, a_field, "\n" + B_STRUCTFIELDS, what="cursor fields")

    # Site 4a: initializers - after the `did_register: ...::new(false),` initializer
    a_init = "            did_register: crate::sync::atomic::AtomicBool::new(false),"
    t = insert_after(t, a_init, "\n" + B_INITIALIZERS, what="cursor initializers")

    # Site 4b: install_yield_context method - before `pub fn new_table(`
    a_newtable = "    pub fn new_table(pager: Arc<Pager>, root_page: i64, num_columns: usize) -> Self {"
    t = insert_before(t, a_newtable, B_INSTALL + "\n\n", what="install_yield_context")

    # Site 5: the inject call - after the unique insert-path save_context whose
    # preceding assert says "during insert" (NOT the overwrite one).
    a_inject = ('turso_assert!(matches!(self.balance_state.sub_state, BalanceSubState::Start), '
                '"no balancing operation should be in progress during insert", '
                '{ "state": self.state, "sub_state": self.balance_state.sub_state });\n'
                '                        // If we balance, we must save the cursor position and seek to it later.\n'
                '                        self.save_context(CursorContext::seek_eq_only(bkey));')
    t = insert_after(t, a_inject, "\n" + B_INJECT, what="inject_io_yield call")

    # Site 6: ProvidesYieldContext impl - before `impl Drop for BTreeCursor {`.
    # The agent's fix lives inside Drop and/or a new `impl BTreeCursor` block; this
    # anchor (the Drop header) is preserved by every correct fix.
    a_drop = "impl Drop for BTreeCursor {"
    t = insert_before(t, a_drop, B_PROVIDES + "\n\n", what="ProvidesYieldContext impl")

    # Site 8a: test-module mvcc use - after the `io::{Buffer, MemoryIO, OpenFlags, IO},`
    # line inside `mod tests`.
    a_testio = "        io::{Buffer, MemoryIO, OpenFlags, IO},"
    t = insert_after(t, a_testio, "\n" + B_TESTUSE_MVCC, what="test-module mvcc use")

    # Site 8b: widen std import in mod tests
    t = replace_once(t, E_STDIMPORT_OLD, B_STDIMPORT_NEW, what="test-module std import")

    # Site 8c: TargetedYieldInjector + helpers - after the test-module
    # `use super::{btree_init_page, ...};` line.
    a_supers = "    use super::{btree_init_page, defragment_page, drop_cell, insert_into_cell};"
    t = insert_after(t, a_supers, "\n\n" + B_INJECTOR, what="test injector + helpers")

    # Site 8d: the two #[test] fns - before `fn ensure_cell(`
    a_ensure = "    fn ensure_cell(page: &mut PageContent, cell_idx: usize, payload: &Vec<u8>) {"
    t = insert_before(t, a_ensure, B_TESTS + "\n\n", what="regression tests")

    BTREE.write_text(t)
    print("[apply_harness] btree.rs scaffolding installed")


def patch_execute():
    if not EXECUTE.is_file():
        die(f"missing {EXECUTE}")
    t = EXECUTE.read_text()
    already(t, "btree_cursor_with_yield_context", what="execute wiring helper")

    # helper fn - after `use crate::storage::btree::{BTreeCursor, BTreeKey};`
    a_use = "use crate::storage::btree::{BTreeCursor, BTreeKey};"
    t = insert_after(t, a_use, "\n\n" + E_HELPER, what="execute helper fn")

    # call site 1 (index cursor)
    t = replace_once(t, E_CALL1_OLD, E_CALL1_NEW, what="op_open_write index cursor")
    # call sites 2+3 (table / without-rowid match)
    t = replace_once(t, E_MATCH_OLD, E_MATCH_NEW, what="op_open_write table cursors")

    EXECUTE.write_text(t)
    print("[apply_harness] execute.rs wiring installed")


def main():
    patch_btree()
    patch_execute()
    # Post-conditions: every scaffolding symbol the tests need must now be present.
    bt = BTREE.read_text()
    ex = EXECUTE.read_text()
    required = [
        (bt, "BTreeWriteYieldPoint"),
        (bt, "AfterInsertOverflowCellBeforeBalance"),
        (bt, "install_yield_context"),
        (bt, "impl ProvidesYieldContext for BTreeCursor"),
        (bt, "inject_io_yield!"),
        (bt, "struct TargetedYieldInjector"),
        (bt, "fn wal_reuses_freelist_leaf_after_abandoned_overflowing_insert"),
        (bt, "fn wal_overflowing_insert_resumes_after_yield_before_balance"),
        (bt, "fn freelist_page_reuse_clears_overflow_cells"),
        (ex, "fn btree_cursor_with_yield_context"),
    ]
    for hay, needle in required:
        if needle not in hay:
            die(f"post-apply check failed: missing {needle!r}")
    print("[apply_harness] all scaffolding present; OK")


if __name__ == "__main__":
    main()
