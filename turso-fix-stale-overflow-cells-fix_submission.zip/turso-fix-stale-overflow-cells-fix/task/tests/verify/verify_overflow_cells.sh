#!/usr/bin/env bash
#
# Behavioral verifier for turso-fix-stale-overflow-cells.
#
# Correctness == 1.0 requires ALL THREE regression tests to pass against the
# agent's fix:
#   * F2P  wal_reuses_freelist_leaf_after_abandoned_overflowing_insert
#          On the UNFIXED engine an abandoned overflowing insert leaves stale
#          page-local overflow-cell scratch that rides a freed-then-reused WAL
#          leaf page into later writes, tripping a balancing assertion /
#          corrupting the tree so the final PRAGMA integrity_check != "ok".
#          Passes only once the fix clears that scratch on every path.
#   * P2P  wal_overflowing_insert_resumes_after_yield_before_balance
#          An insert that yields mid-balance and then legitimately RESUMES must
#          still complete and persist its row. Fails if a candidate "fix" clears
#          overflow cells too eagerly (e.g. on every yield / for a live cursor)
#          and thereby breaks suspend/resume.
#   * RR   freelist_page_reuse_clears_overflow_cells
#          Behavioral reuse round-trip: a page returned from allocate_page()
#          must have empty overflow_cells. Exercises the pager's free_page(None)
#          path so that any fix that clears at or before the freelist-pop site
#          passes (unconditional free_page clear, ReuseFreelistLeaf clear, etc.)
#          while a Drop-only fix fails because no BTreeCursor is involved.
#
# All three tests live INSIDE core/storage/btree.rs's `mod tests` and reference
# crate-private internals plus a cfg-gated yield-injection framework that is
# deliberately excluded from the agent's checkout. apply_harness.py installs that
# scaffolding (yield point + cursor wiring + the three tests) onto the agent's
# SOLVED repo via stable anchors, disjoint from the fix sites, so it composes
# with any correct solution. See apply_harness.py for the rationale.
#
# Exit 0 iff ALL THREE named tests are reported `... ok` by cargo. Any panic,
# compile error, a scaffolding block already present in the agent checkout, or
# any test failing to run is a non-zero exit (correctness 0.0 / invalid trial).

set -euo pipefail

REPO="${REPO_DIR:-/repo/turso}"
CRATE_DIR="$REPO/core"
HARNESS="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/apply_harness.py"

echo "[verify] repo=$REPO"
echo "[verify] rustc=$(rustc --version 2>&1 | head -1)"

# ---- 1. install the reproduction scaffolding onto the agent's solved tree ----
# apply_harness.py fails loudly (exit 3) if any anchor is missing/ambiguous, or
# if the agent already added any scaffolding symbol (which would mean the task
# leaked, not that the bug was fixed).
python3 "$HARNESS" "$REPO"

# ---- 2. run exactly the two named lib tests, single-threaded, deterministic ----
# `cargo test <name>` is a substring filter: a filter matching ZERO tests exits 0
# ("running 0 tests"), a false pass. We therefore capture output and assert each
# expected test is individually reported `ok` AND that the summary reports no
# failures and a nonzero number of tests run.
TEST_LOG="$(mktemp)"
trap 'rm -f "$TEST_LOG"' EXIT

set +e
cargo test \
  --locked \
  -p turso_core \
  --lib \
  --manifest-path "$CRATE_DIR/Cargo.toml" \
  -- \
  --test-threads=1 \
  --exact \
  storage::btree::tests::wal_reuses_freelist_leaf_after_abandoned_overflowing_insert \
  storage::btree::tests::wal_overflowing_insert_resumes_after_yield_before_balance \
  storage::btree::tests::freelist_page_reuse_clears_overflow_cells \
  2>&1 | tee "$TEST_LOG"
CARGO_STATUS=${PIPESTATUS[0]}
set -e

echo "[verify] cargo exit status: $CARGO_STATUS"

# ---- 3. hard checks: both tests must have RUN and PASSED ----
fail() { echo "[verify] FAIL: $1" >&2; exit 1; }

[ "$CARGO_STATUS" -eq 0 ] || fail "cargo test returned non-zero ($CARGO_STATUS) (compile error, panic, or test failure)"

grep -qE 'test storage::btree::tests::wal_reuses_freelist_leaf_after_abandoned_overflowing_insert \.\.\. ok' "$TEST_LOG" \
  || fail "F2P test did not report ok (missing, panicked, or failed)"
grep -qE 'test storage::btree::tests::wal_overflowing_insert_resumes_after_yield_before_balance \.\.\. ok' "$TEST_LOG" \
  || fail "P2P test did not report ok (missing, panicked, or failed)"
grep -qE 'test storage::btree::tests::freelist_page_reuse_clears_overflow_cells \.\.\. ok' "$TEST_LOG" \
  || fail "freelist reuse test did not report ok (free_page must clear overflow_cells so allocate_page returns a clean page)"

# Guard against a vacuous "0 tests" / "0 passed" summary and any reported failure.
grep -qE 'test result: ok\. [1-9][0-9]* passed; 0 failed' "$TEST_LOG" \
  || fail "cargo summary did not show a nonzero passed count with 0 failed"

echo "[verify] PASS: all three regression tests passed"
exit 0
