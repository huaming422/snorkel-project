//! Behavioural verifier for rspack-perf-dedup-path-lists.
//!
//! Exercises the per-module-factorization dependency path lists ONLY through
//! the pre-existing, signature-stable public surface of `rspack_core`:
//!
//!   * `FactorizeInfo::new(diagnostics, related_dep_ids, file_dependencies,
//!     context_dependencies, missing_dependencies)` — unchanged signature; it
//!     still accepts three `InternedPathSet`s.
//!   * `FactorizeInfo::{file_dependencies, context_dependencies,
//!     missing_dependencies}` — each still returns `&[InternedPath]`.
//!   * `FactorizeInfo::{is_success, diagnostics, related_dep_ids,
//!     owner_dep_id}` — metadata accessors.
//!   * `rspack_cacheable::{to_bytes, from_bytes}` with a `&()` context — the
//!     persisted-cache round-trip.
//!
//! No symbol introduced by a solution is named or imported: the inputs are
//! built from the pre-existing `rspack_paths::{InternedPath, InternedPathSet}`
//! and `rspack_core::DependencyId`, and the observable property asserted is
//! pointer identity of the slice an accessor returns a view into, plus content
//! preservation. Any content-dedup representation — a dedicated list type,
//! `Arc<[InternedPath]>` behind a content-keyed map, a hash-cons table, a
//! differently-named helper, or no standalone type at all — shares one backing
//! buffer between equal lists and so satisfies these assertions; a storage
//! that keeps one private copy per factorization does not.
//!
//! The backing buffer of a list is process-global and content-keyed, so each
//! test uses its own distinctive, non-empty (>= 2 element) path strings: an
//! empty list has no element buffer to compare, and reusing content across
//! tests would let one test's live handle mask another's reclamation.

use rspack_cacheable::{from_bytes, to_bytes};
use rspack_core::{DependencyId, FactorizeInfo};
use rspack_paths::{InternedPath, InternedPathSet};

/// Builds a path set from string literals, inserting in the given order. Two
/// clones of one set iterate identically, so two factorizations built from
/// clones receive identically ordered lists and a content-dedup storage maps
/// them to one buffer.
fn path_set(paths: &[&str]) -> InternedPathSet {
    let mut set = InternedPathSet::default();
    for p in paths {
        set.insert(InternedPath::from(*p));
    }
    set
}

/// A single non-empty related-dependency id — `new` requires at least one.
fn deps() -> Vec<DependencyId> {
    vec![DependencyId::from(1u32)]
}

/// Builds a `FactorizeInfo` with the three dependency sets and no diagnostics.
fn info(
    file: InternedPathSet,
    context: InternedPathSet,
    missing: InternedPathSet,
) -> FactorizeInfo {
    FactorizeInfo::new(Vec::new(), deps(), file, context, missing)
}

/// Whether two accessor slices are views into the same element buffer.
fn same_buffer(a: &[InternedPath], b: &[InternedPath]) -> bool {
    std::ptr::eq(a.as_ptr(), b.as_ptr())
}

// --- equal content shares one backing buffer (the core behavioral check) ---

#[test]
fn equal_file_lists_share_allocation() {
    let set = path_set(&["/share/file/a.js", "/share/file/b.js"]);
    let a = info(set.clone(), InternedPathSet::default(), InternedPathSet::default());
    let b = info(set, InternedPathSet::default(), InternedPathSet::default());

    assert_eq!(a.file_dependencies().len(), 2);
    assert_eq!(b.file_dependencies().len(), 2);
    assert!(
        same_buffer(a.file_dependencies(), b.file_dependencies()),
        "two factorizations with identical non-empty file path lists must share \
         one backing buffer; distinct pointers mean each kept its own copy",
    );
}

#[test]
fn context_and_missing_lists_share() {
    let ctx = path_set(&["/share/ctx/one", "/share/ctx/two", "/share/ctx/three"]);
    let miss = path_set(&["/share/miss/x", "/share/miss/y"]);
    let a = info(InternedPathSet::default(), ctx.clone(), miss.clone());
    let b = info(InternedPathSet::default(), ctx, miss);

    assert!(
        same_buffer(a.context_dependencies(), b.context_dependencies()),
        "equal context dependency lists must share one backing buffer",
    );
    assert!(
        same_buffer(a.missing_dependencies(), b.missing_dependencies()),
        "equal missing dependency lists must share one backing buffer",
    );
}

#[test]
fn different_file_lists_are_distinct() {
    // Guards a storage that collapses every list regardless of content:
    // different content must keep its own buffer.
    let a = info(
        path_set(&["/distinct/a1.js", "/distinct/a2.js"]),
        InternedPathSet::default(),
        InternedPathSet::default(),
    );
    let b = info(
        path_set(&["/distinct/b1.js", "/distinct/b2.js", "/distinct/b3.js"]),
        InternedPathSet::default(),
        InternedPathSet::default(),
    );

    assert!(
        !same_buffer(a.file_dependencies(), b.file_dependencies()),
        "file path lists with different contents must not share a buffer",
    );
}

// --- storage reclaimed on last-handle drop; recreated equal lists re-share ---

#[test]
fn drop_then_recreate_reshares() {
    let content = ["/reclaim/first", "/reclaim/second"];
    // Hold the only handles to this content, then release them.
    let first = info(
        path_set(&content),
        InternedPathSet::default(),
        InternedPathSet::default(),
    );
    assert_eq!(first.file_dependencies().len(), 2);
    drop(first);

    // Rebuild the same content twice: the two live factorizations must share,
    // which requires a freed buffer to be re-created and re-shared rather than
    // leaving a dead entry that never re-dedupes.
    let second = info(
        path_set(&content),
        InternedPathSet::default(),
        InternedPathSet::default(),
    );
    let third = info(
        path_set(&content),
        InternedPathSet::default(),
        InternedPathSet::default(),
    );
    assert!(
        same_buffer(second.file_dependencies(), third.file_dependencies()),
        "re-created equal lists must re-share one buffer after the previous \
         list's last handle dropped",
    );
}

// --- accessor + metadata contents preserved ---

#[test]
fn accessor_contents_preserved() {
    let file = path_set(&["/keep/file/a", "/keep/file/b"]);
    let ctx = path_set(&["/keep/ctx/a"]);
    let miss = path_set(&["/keep/miss/a", "/keep/miss/b", "/keep/miss/c"]);
    let info = FactorizeInfo::new(
        Vec::new(),
        vec![DependencyId::from(7u32), DependencyId::from(9u32)],
        file.clone(),
        ctx.clone(),
        miss.clone(),
    );

    // Each accessor returns exactly the inserted paths (compared as sets, since
    // the ordered list is derived from an unordered input set).
    let as_set = |s: &[InternedPath]| -> InternedPathSet { s.iter().cloned().collect() };
    assert_eq!(as_set(info.file_dependencies()), file);
    assert_eq!(as_set(info.context_dependencies()), ctx);
    assert_eq!(as_set(info.missing_dependencies()), miss);

    // Metadata accessors echo their inputs and reflect the empty-diagnostics
    // success state.
    assert!(info.is_success(), "no diagnostics means a successful factorization");
    assert!(info.diagnostics().is_empty());
    assert_eq!(info.related_dep_ids(), &[DependencyId::from(7u32), DependencyId::from(9u32)]);
    assert_eq!(info.owner_dep_id(), DependencyId::from(7u32));
}

// --- persisted-cache serialize -> deserialize preserves contents ---

#[test]
fn cacheable_roundtrip_preserves_contents() {
    let file = path_set(&["/cache/file/a", "/cache/file/b"]);
    let ctx = path_set(&["/cache/ctx/a", "/cache/ctx/b"]);
    let miss = path_set(&["/cache/miss/a"]);
    let original = info(file.clone(), ctx.clone(), miss.clone());

    let bytes = to_bytes(&original, &()).expect("factorization info should serialize");
    let restored: FactorizeInfo =
        from_bytes(&bytes, &()).expect("factorization info should deserialize");

    let as_set = |s: &[InternedPath]| -> InternedPathSet { s.iter().cloned().collect() };
    assert_eq!(as_set(restored.file_dependencies()), file);
    assert_eq!(as_set(restored.context_dependencies()), ctx);
    assert_eq!(as_set(restored.missing_dependencies()), miss);
}
