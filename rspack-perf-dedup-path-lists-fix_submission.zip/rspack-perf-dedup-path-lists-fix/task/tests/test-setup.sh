#!/usr/bin/env bash
# No services to start and no data to seed: the image pre-warms the cargo
# registry and target dir at the base commit, and the verifier is a
# self-contained Rust integration test compiled against the agent's tree.
# The agent phase is offline (agent_offline = true); everything the focused
# tests need is already baked into the image.
set -euo pipefail

echo "[test-setup] Rust version:   $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:  $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Workspace root: /repo/rspack"
echo "[test-setup] Setup complete."
