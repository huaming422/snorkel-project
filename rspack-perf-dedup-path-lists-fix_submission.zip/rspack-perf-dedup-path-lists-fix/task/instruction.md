## Task

we're getting reports from operators bundling big projects that rspack holds onto far more memory than the work warrants. on large production builds peak resident RAM runs hundreds of megabytes higher than we'd expect for the amount being bundled. small builds look fine; it only shows up at scale, on big projects and long builds.

dig in, find where that memory is going, and cut the waste.

this is purely a memory optimization: the build has to produce exactly the same output and behave identically. only the footprint should come down.
