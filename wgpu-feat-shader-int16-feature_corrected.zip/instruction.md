## Task

naga has no 16-bit integer types yet. I'd like `i16`, `u16` and their vectors (`vec2<i16>` and so on) to work in WGSL and make it through every output we have: WGSL, GLSL, HLSL, Metal and SPIR-V. That includes converting a 16-bit shader to any of them with the `naga` command-line tool.

Every backend should write the target language's real 16-bit type instead of widening the value to 32 bits, and what it emits has to be valid for that target. For SPIR-V that includes narrow constants: a negative `i16` constant keeps its sign in the literal word, and a large `u16` one doesn't pick one up. `glslangValidator` and `spirv-val` are installed in the image if you want to check the GLSL and SPIR-V.

16-bit atomics and 16-bit immediates are invalid, so the validator should reject them.

Out of scope: vertex and texture formats with 16-bit components, HLSL padding for struct members under 4 bytes, a suffix for writing 16-bit literals (people write `i16(5)` or `u16(5)`), switching on an `i16`/`u16` value, the bit built-ins (`countOneBits`, `extractBits` and the rest) on 16-bit values, and reporting the feature from the GL/GLES device. Keep the change inside naga.

## User stories / requirements

- If a shader never says `enable wgpu_int16;`, any `i16` or `u16` in it is a parse error. With the directive, validation reports a missing capability until 16-bit integer support is turned on in the validator; once it is, 16-bit scalars and vectors pass.
- SPIR-V output for a shader that writes an `i16` or `u16` into a storage buffer has a 16-bit `OpTypeInt` and declares the `Int16` and `StorageBuffer16BitAccess` capabilities.
- Metal output declares 16-bit values as `short`/`ushort`. Metal promotes 16-bit arithmetic to `int`, and the output still has to be valid MSL when an `i16` is negated or when 16-bit arithmetic, signed or unsigned, is bitcast to the other 16-bit type.
- For HLSL I get `int16_t`/`uint16_t`, and a bitcast from `i16` to `u16` or back comes out as HLSL that's legal for 16-bit operands.
- GLSL output keeps a 16-bit storage buffer member 16 bits wide, declared with `int16_t` or `uint16_t`.
- When I write a 16-bit module back out as WGSL, it still has `enable wgpu_int16;` and it parses.
- 16-bit constant arithmetic gets folded at compile time. Index a fixed-size array with a `u16` built from constants and an index inside the array validates, while one past the end comes back as out of bounds.
