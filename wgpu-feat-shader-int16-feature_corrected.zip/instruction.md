## Task

naga has no 16-bit integer types yet. I'd like `i16`, `u16` and their vectors (`vec2<i16>` and so on) to work in WGSL and make it through every output we have: WGSL, GLSL, HLSL, Metal and SPIR-V.

Every backend should write the target language's real 16-bit type instead of widening the value to 32 bits, and what it emits has to be valid for that target. For SPIR-V that includes narrow constants: a negative `i16` constant keeps its sign in the literal word, and a large `u16` one doesn't pick one up.

16-bit atomics and 16-bit immediates are invalid, so the validator should reject them.

Out of scope: vertex and texture formats with 16-bit components, HLSL padding for struct members under 4 bytes, a suffix for writing 16-bit literals (people write `i16(5)` or `u16(5)`), switching on an `i16`/`u16` value, and reporting the feature from the GL/GLES device. Keep the change inside naga.

## User stories / requirements

- Using `i16` or `u16` in a shader that never says `enable wgpu_int16;` is a parse error. Once the directive is there, validating the module still reports a missing capability until 16-bit integer support is switched on in the validator; after that, 16-bit scalars and vectors validate fine.
- SPIR-V output for a shader that writes an `i16` or `u16` into a storage buffer has a 16-bit `OpTypeInt` and declares the `Int16` and `StorageBuffer16BitAccess` capabilities.
- Metal output declares 16-bit values as `short`/`ushort`. Metal promotes 16-bit arithmetic to `int`, and the output still has to be valid MSL when an `i16` is negated or when 16-bit arithmetic, signed or unsigned, is bitcast to the other 16-bit type.
- HLSL output uses `int16_t`/`uint16_t`, and bitcasting an `i16` to `u16` or back produces HLSL that is legal for 16-bit operands.
- GLSL output keeps a 16-bit storage buffer member 16 bits wide, declared with `int16_t` or `uint16_t`.
- Writing a 16-bit module back out as WGSL keeps `enable wgpu_int16;`, and that output parses again.
- 16-bit constant arithmetic is folded while compiling. If I index a fixed-size array with a `u16` computed from constants, an index inside the array validates and one past the end is reported as out of bounds.
