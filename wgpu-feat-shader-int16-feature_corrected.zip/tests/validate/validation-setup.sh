#!/usr/bin/env bash
# Validation setup: runs after the agent's edits are in place and BEFORE the
# pre-validation integrity checkpoint is taken, so any edit this script makes to
# the workspace is attributed to setup, not to the validation agent.
#
# Two jobs:
#   1. Make the cargo-test harness buildable. The test driver auto-injects a
#      small params helper that pulls its inputs from JSON, so it needs both
#      `serde` and `serde_json` as dev-dependencies of the crate under test.
#      The crate already dev-depends on `serde`; `serde_json` is a workspace
#      dependency (present in the lockfile and the warm offline cache) but is
#      not yet listed under this crate's [dev-dependencies]. Add it. The edit is
#      idempotent and offline.
#   2. Loud smoke guard: confirm the toolchain is reachable and the crate under
#      test still builds with the agent's edits applied. If it does not, every
#      story would otherwise fail with the same opaque compile error — surface
#      it here instead.
set -uo pipefail

export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
export PATH="$CARGO_HOME/bin:$PATH"
export RUSTUP_TOOLCHAIN="${RUSTUP_TOOLCHAIN:-1.93}"

REPO="${REPO:-/repo/wgpu}"
MANIFEST="$REPO/naga/Cargo.toml"

echo "validation-setup: rustc=$(rustc --version 2>&1 | head -1)"
echo "validation-setup: cargo=$(cargo --version 2>&1 | head -1)"

if [ ! -f "$MANIFEST" ]; then
    echo "validation-setup: ERROR manifest not found at $MANIFEST" >&2
    exit 1
fi

# --- Step 1: ensure serde_json is a dev-dependency of the crate under test. ---
# Insert the line immediately after the [dev-dependencies] header so it lands
# inside that table regardless of what follows. Guarded so re-runs are no-ops.
if grep -qE '^\s*serde_json\b' "$MANIFEST"; then
    echo "validation-setup: serde_json already present in $MANIFEST"
else
    if ! grep -qE '^\[dev-dependencies\]' "$MANIFEST"; then
        echo "validation-setup: ERROR no [dev-dependencies] table in $MANIFEST" >&2
        exit 1
    fi
    # Use a temp file so a partial awk run can't corrupt the manifest.
    tmp="$(mktemp)"
    awk '
        /^\[dev-dependencies\]/ && !done {
            print
            print "serde_json.workspace = true"
            done = 1
            next
        }
        { print }
    ' "$MANIFEST" > "$tmp" && mv "$tmp" "$MANIFEST"
    if grep -qE '^\s*serde_json\.workspace = true' "$MANIFEST"; then
        echo "validation-setup: added serde_json.workspace = true to $MANIFEST"
    else
        echo "validation-setup: ERROR failed to add serde_json dev-dependency" >&2
        exit 1
    fi
fi

# --- Step 2: loud smoke guard. ------------------------------------------------
# Build the crate (incremental — the warm cache means only touched crates
# recompile) with the feature set the stories use. A clean build here means the
# stories start from a compilable tree.
echo "validation-setup: cargo build -p naga (stories' feature set, offline)..."
if ! ( cd "$REPO" && cargo build --offline -p naga \
        --manifest-path naga/Cargo.toml \
        --features wgsl-in,spv-out,msl-out,hlsl-out,glsl-out,wgsl-out 2>&1 | tail -20 ); then
    echo "validation-setup: ERROR crate under test failed to build after edits" >&2
    exit 1
fi

# NOTE: this script is *sourced* by test.sh (`source validation-setup.sh`), so
# it must fall off the end rather than call `exit` on the success path — an
# `exit` here would terminate test.sh itself before the stories and the reward
# aggregation run. The error paths above use `exit 1` deliberately: a broken
# setup is a fatal, invalid-trial condition.
echo "validation-setup: done"
