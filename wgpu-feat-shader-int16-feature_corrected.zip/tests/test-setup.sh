#!/usr/bin/env bash
# Verifier-side setup: runs before the verifier, with the model-gateway
# allowlist available. The image already installed the Rust toolchain, warmed the
# cargo registry, and compiled the workspace (CARGO_TARGET_DIR is warm). This
# script only re-exports the toolchain env (each phase starts a fresh shell) and
# confirms the canonical verifier venv is present. No dependency resolution
# happens here: the build and test phase runs offline and the closure is already baked.
set -euo pipefail

# Re-export the Rust toolchain paths exactly as the image's Dockerfile set them.
export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
export PATH="$CARGO_HOME/bin:$PATH"
# The image pinned the toolchain; keep it pinned here too.
export RUSTUP_TOOLCHAIN="${RUSTUP_TOOLCHAIN:-1.93}"

# Sanity check: the toolchain must be present (baked into the image).
rustc --version >/dev/null 2>&1 || {
    echo "ERROR: rustc not found on PATH (CARGO_HOME=$CARGO_HOME)" >&2
    exit 1
}
cargo --version >/dev/null 2>&1 || {
    echo "ERROR: cargo not found on PATH" >&2
    exit 1
}

# The verifier infrastructure runs under the canonical isolated venv.
VERIFIER_PYTHON="${VERIFIER_PYTHON:-/opt/tooling/venv/bin/python}"
"$VERIFIER_PYTHON" -c "import pytest" >/dev/null 2>&1 || {
    echo "ERROR: verifier venv missing pytest at $VERIFIER_PYTHON" >&2
    exit 1
}

echo "test-setup: rustc=$(rustc --version), cargo=$(cargo --version | head -1), verifier_python=$VERIFIER_PYTHON"
