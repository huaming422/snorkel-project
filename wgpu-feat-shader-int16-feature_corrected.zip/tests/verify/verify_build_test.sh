#!/usr/bin/env bash
# Build guard: the naga crate must still compile and its test binaries must
# still link. The crate compiles cleanly to begin with, so this check succeeds
# whether or not the 16-bit work is present; it only catches a tree that no
# longer builds.
#
# cwd is the repository root. The toolchain environment is already exported by
# the setup script.
set -uo pipefail

export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
export PATH="$CARGO_HOME/bin:$PATH"
export RUSTUP_TOOLCHAIN="${RUSTUP_TOOLCHAIN:-1.93}"

MANIFEST="naga/Cargo.toml"

echo "verify_build: cargo build -p naga"
if ! cargo build --offline -p naga --manifest-path "$MANIFEST"; then
    echo "verify_build: cargo build -p naga failed" >&2
    exit 1
fi

echo "verify_build: cargo test -p naga --no-run (feature set used by the checks)"
if ! cargo test --offline -p naga --no-run --manifest-path "$MANIFEST" \
        --features wgsl-in,spv-out,msl-out,hlsl-out,glsl-out,wgsl-out; then
    echo "verify_build: cargo test --no-run failed" >&2
    exit 1
fi

echo "verify_build: ok"
exit 0
