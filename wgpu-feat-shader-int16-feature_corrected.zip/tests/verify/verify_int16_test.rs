// Behavioral checks for 16-bit integer handling. Most drive naga's public
// front-end and validator APIs and assert on returned error variants; one reads
// the constants out of the emitted SPIR-V word stream. When a tree does not
// understand 16-bit integers, the `enable wgpu_int16;` directive and the
// `i16`/`u16` types are unknown, `parse_str` returns an error, and the
// `.expect(...)` in each helper panics so the test fails.
//
// Capabilities::all() is used so the tests never name the feature's own
// capability flag; they assert observable behaviour, not an internal constant.

use naga::front::wgsl::parse_str;
use naga::valid::{Capabilities, Validator, ValidationFlags};

/// Parse `src` and validate it with every capability enabled, returning the
/// validation error. Panics (failing the test) if parsing fails or if
/// validation unexpectedly succeeds.
#[track_caller]
fn validation_error(src: &str) -> naga::valid::ValidationError {
    let module = parse_str(src).expect("source should parse");
    Validator::new(ValidationFlags::all(), Capabilities::all())
        .validate(&module)
        .expect_err("module should fail validation")
        .into_inner()
}

/// A 16-bit atomic is not a legal atomic payload: the atomic-width check must
/// reject a 2-byte scalar rather than accept it. Both the unsigned and signed
/// forms are rejected with an invalid-atomic-width type error carrying the
/// 2-byte width.
#[test]
fn atomic_16bit_rejected() {
    for src in [
        "enable wgpu_int16; @group(0) @binding(0) var<storage, read_write> a: atomic<u16>;",
        "enable wgpu_int16; @group(0) @binding(0) var<storage, read_write> a: atomic<i16>;",
    ] {
        let err = validation_error(src);
        assert!(
            matches!(
                err,
                naga::valid::ValidationError::Type {
                    source: naga::valid::TypeError::InvalidAtomicWidth(_, 2),
                    ..
                }
            ),
            "expected an invalid-atomic-width rejection for a 2-byte atomic, got: {err:?}",
        );
    }
}

/// A 16-bit scalar is not a legal immediate (push-constant) payload: a global
/// in the immediate address space whose type is or contains a 16-bit scalar is
/// rejected with an invalid-scalar immediate error. Scalar, vector, and
/// struct-member forms are all rejected.
#[test]
fn immediate_16bit_rejected() {
    for src in [
        "enable wgpu_int16; var<immediate> input: i16;",
        "enable wgpu_int16; var<immediate> input: u16;",
        "enable wgpu_int16; var<immediate> input: vec2<i16>;",
        "enable wgpu_int16; struct S { a: u16 }; var<immediate> input: S;",
    ] {
        let err = validation_error(src);
        assert!(
            matches!(
                err,
                naga::valid::ValidationError::GlobalVariable {
                    source: naga::valid::GlobalVariableError::InvalidImmediateType(
                        naga::valid::ImmediateError::InvalidScalar(_),
                    ),
                    ..
                }
            ),
            "expected an invalid-scalar immediate rejection for a 16-bit immediate, got: {err:?}",
        );
    }
}

/// Emit SPIR-V for `src` and return every `OpConstant` literal word whose
/// result type is a 16-bit `OpTypeInt` with the given signedness.
#[track_caller]
fn spirv_16bit_constant_words(src: &str, signed: u32) -> Vec<u32> {
    let module = parse_str(src).expect("source should parse");
    let info = Validator::new(ValidationFlags::all(), Capabilities::all())
        .validate(&module)
        .expect("module should validate");
    let words = naga::back::spv::write_vec(
        &module,
        &info,
        &naga::back::spv::Options::default(),
        None,
    )
    .expect("SPIR-V generation should succeed");

    const OP_TYPE_INT: u32 = 21;
    const OP_CONSTANT: u32 = 43;
    let mut types = Vec::new();
    let mut constants = Vec::new();
    let mut i = 5; // skip the module header
    while i < words.len() {
        let count = (words[i] >> 16) as usize;
        let opcode = words[i] & 0xffff;
        assert!(count > 0 && i + count <= words.len(), "malformed SPIR-V word stream");
        let operands = &words[i + 1..i + count];
        if opcode == OP_TYPE_INT && operands[1] == 16 && operands[2] == signed {
            types.push(operands[0]);
        }
        if opcode == OP_CONSTANT {
            constants.push((operands[0], operands[2]));
        }
        i += count;
    }
    assert!(!types.is_empty(), "no 16-bit OpTypeInt was emitted");
    constants
        .into_iter()
        .filter(|(ty, _)| types.contains(ty))
        .map(|(_, word)| word)
        .collect()
}

/// A narrow integer constant is stored in one 32-bit literal word. The SPIR-V
/// spec requires the high-order bits of that word to be the sign extension for
/// a signed type and zero for an unsigned one, so a negative i16 keeps its
/// sign and a large u16 does not gain one.
#[test]
fn spirv_16bit_constants_extend_per_signedness() {
    let signed = spirv_16bit_constant_words(
        "enable wgpu_int16;\n@group(0) @binding(0) var<storage, read_write> out: i16;\n@compute @workgroup_size(1) fn main() { out = i16(-5); }",
        1,
    );
    assert!(
        signed.contains(&(-5i32 as u32)),
        "expected the i16 constant -5 as the word 0xFFFFFFFB, got words {signed:#x?}",
    );
    assert!(
        !signed.contains(&0xFFFB),
        "the i16 constant -5 has no high-order sign bits: {signed:#x?}",
    );

    let unsigned = spirv_16bit_constant_words(
        "enable wgpu_int16;\n@group(0) @binding(0) var<storage, read_write> out: u16;\n@compute @workgroup_size(1) fn main() { out = u16(65531); }",
        0,
    );
    assert!(
        unsigned.contains(&0xFFFB),
        "expected the u16 constant 65531 as the word 0x0000FFFB, got words {unsigned:#x?}",
    );
}
