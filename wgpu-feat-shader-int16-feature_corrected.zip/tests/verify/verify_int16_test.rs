// Behavioral checks for 16-bit integer handling. Two drive naga's public
// front-end and validator APIs and assert on returned error variants; one reads
// the constants out of the emitted SPIR-V word stream; one compiles generated
// GLSL with glslangValidator; one reads the generated Metal for 16-bit division
// and remainder; one runs every backend over a set of 16-bit shaders and checks
// the SPIR-V with spirv-val. When a tree does not
// understand 16-bit integers, the `enable wgpu_int16;` directive and the
// `i16`/`u16` types are unknown, `parse_str` returns an error, and the
// `.expect(...)` in each helper panics so the test fails.
//
// Capabilities::all() is used so the tests never name the feature's own
// capability flag; they assert observable behaviour, not an internal constant.

use naga::front::wgsl::parse_str;
use naga::valid::{Capabilities, Validator, ValidationFlags};

/// Parse `src` and validate it with every capability enabled, returning the
/// validation error. Panics (failing the test) if parsing fails or if
/// validation unexpectedly succeeds.
#[track_caller]
fn validation_error(src: &str) -> naga::valid::ValidationError {
    let module = parse_str(src).expect("source should parse");
    Validator::new(ValidationFlags::all(), Capabilities::all())
        .validate(&module)
        .expect_err("module should fail validation")
        .into_inner()
}

/// Parse `src` and validate it with every capability enabled. Panics (failing
/// the test) with the validation error if the module is refused.
fn validates(src: &str) {
    let module = parse_str(src).expect("source should parse");
    if let Err(err) = Validator::new(ValidationFlags::all(), Capabilities::all()).validate(&module) {
        panic!("expected this module to validate:\n{src}\ngot: {:?}", err.into_inner());
    }
}

/// A 16-bit atomic is not a legal atomic payload: the atomic-width check must
/// reject a 2-byte scalar rather than accept it. Both the unsigned and signed
/// forms are rejected with an invalid-atomic-width type error carrying the
/// 2-byte width, while 32- and 64-bit atomics, one beside a 16-bit struct
/// member included, still validate.
#[test]
fn atomic_16bit_rejected() {
    for src in [
        "enable wgpu_int16; @group(0) @binding(0) var<storage, read_write> a: atomic<u16>;",
        "enable wgpu_int16; @group(0) @binding(0) var<storage, read_write> a: atomic<i16>;",
    ] {
        let err = validation_error(src);
        assert!(
            matches!(
                err,
                naga::valid::ValidationError::Type {
                    source: naga::valid::TypeError::InvalidAtomicWidth(_, 2),
                    ..
                }
            ),
            "expected an invalid-atomic-width rejection for a 2-byte atomic, got: {err:?}",
        );
    }
    for src in [
        "enable wgpu_int16; @group(0) @binding(0) var<storage, read_write> a: atomic<u32>;",
        "enable wgpu_int16; @group(0) @binding(0) var<storage, read_write> a: atomic<i32>;",
        "enable wgpu_int16; @group(0) @binding(0) var<storage, read_write> a: atomic<u64>;",
        "enable wgpu_int16; struct S { n: atomic<u32>, h: u16 }; @group(0) @binding(0) var<storage, read_write> s: S;",
    ] {
        validates(src);
    }
}

/// A 16-bit scalar is not a legal immediate (push-constant) payload: a global
/// in the immediate address space whose type is or contains a 16-bit scalar is
/// rejected with an invalid-scalar immediate error. Scalar, vector, and
/// struct-member forms are all rejected, while 32-bit immediates still
/// validate.
#[test]
fn immediate_16bit_rejected() {
    for src in [
        "enable wgpu_int16; var<immediate> input: i16;",
        "enable wgpu_int16; var<immediate> input: u16;",
        "enable wgpu_int16; var<immediate> input: vec2<i16>;",
        "enable wgpu_int16; struct S { a: u16 }; var<immediate> input: S;",
    ] {
        let err = validation_error(src);
        assert!(
            matches!(
                err,
                naga::valid::ValidationError::GlobalVariable {
                    source: naga::valid::GlobalVariableError::InvalidImmediateType(
                        naga::valid::ImmediateError::InvalidScalar(_),
                    ),
                    ..
                }
            ),
            "expected an invalid-scalar immediate rejection for a 16-bit immediate, got: {err:?}",
        );
    }
    for src in [
        "enable wgpu_int16; var<immediate> input: u32;",
        "enable wgpu_int16; var<immediate> input: vec2<i32>;",
        "enable wgpu_int16; struct S { a: u32, b: f32 }; var<immediate> input: S;",
    ] {
        validates(src);
    }
}

/// Emit SPIR-V for `src` and return every `OpConstant` literal word whose
/// result type is a 16-bit `OpTypeInt` with the given signedness.
#[track_caller]
fn spirv_16bit_constant_words(src: &str, signed: u32) -> Vec<u32> {
    let module = parse_str(src).expect("source should parse");
    let info = Validator::new(ValidationFlags::all(), Capabilities::all())
        .validate(&module)
        .expect("module should validate");
    let words = naga::back::spv::write_vec(
        &module,
        &info,
        &naga::back::spv::Options::default(),
        None,
    )
    .expect("SPIR-V generation should succeed");

    const OP_TYPE_INT: u32 = 21;
    const OP_CONSTANT: u32 = 43;
    let mut types = Vec::new();
    let mut constants = Vec::new();
    let mut i = 5; // skip the module header
    while i < words.len() {
        let count = (words[i] >> 16) as usize;
        let opcode = words[i] & 0xffff;
        assert!(count > 0 && i + count <= words.len(), "malformed SPIR-V word stream");
        let operands = &words[i + 1..i + count];
        if opcode == OP_TYPE_INT && operands[1] == 16 && operands[2] == signed {
            types.push(operands[0]);
        }
        if opcode == OP_CONSTANT {
            constants.push((operands[0], operands[2]));
        }
        i += count;
    }
    assert!(!types.is_empty(), "no 16-bit OpTypeInt was emitted");
    constants
        .into_iter()
        .filter(|(ty, _)| types.contains(ty))
        .map(|(_, word)| word)
        .collect()
}

/// A narrow integer constant is stored in one 32-bit literal word. The SPIR-V
/// spec requires the high-order bits of that word to be the sign extension for
/// a signed type and zero for an unsigned one, so a negative i16 keeps its
/// sign and a large u16 does not gain one.
#[test]
fn spirv_16bit_constants_extend_per_signedness() {
    let signed = spirv_16bit_constant_words(
        "enable wgpu_int16;\n@group(0) @binding(0) var<storage, read_write> out: i16;\n@compute @workgroup_size(1) fn main() { out = i16(-5); }",
        1,
    );
    assert!(
        signed.contains(&(-5i32 as u32)),
        "expected the i16 constant -5 as the word 0xFFFFFFFB, got words {signed:#x?}",
    );
    assert!(
        !signed.contains(&0xFFFB),
        "the i16 constant -5 has no high-order sign bits: {signed:#x?}",
    );

    let unsigned = spirv_16bit_constant_words(
        "enable wgpu_int16;\n@group(0) @binding(0) var<storage, read_write> out: u16;\n@compute @workgroup_size(1) fn main() { out = u16(65531); }",
        0,
    );
    assert!(
        unsigned.contains(&0xFFFB),
        "expected the u16 constant 65531 as the word 0x0000FFFB, got words {unsigned:#x?}",
    );
}

/// Parse and validate `src` with every capability enabled.
#[track_caller]
fn module_and_info(src: &str) -> (naga::Module, naga::valid::ModuleInfo) {
    let module = parse_str(src).expect("source should parse");
    let info = Validator::new(ValidationFlags::all(), Capabilities::all())
        .validate(&module)
        .expect("module should validate");
    (module, info)
}

/// 16-bit shaders whose output every backend has to handle.
const SHADERS_16BIT: &[(&str, &str)] = &[
    ("store u16", "enable wgpu_int16;\n@group(0) @binding(0) var<storage, read_write> out: u16;\n@compute @workgroup_size(1) fn main() { out = u16(7); }"),
    ("store i16", "enable wgpu_int16;\n@group(0) @binding(0) var<storage, read_write> out: i16;\n@compute @workgroup_size(1) fn main() { out = i16(-7); }"),
    ("vector arithmetic", "enable wgpu_int16;\n@group(0) @binding(0) var<storage, read_write> out: vec2<i16>;\n@compute @workgroup_size(1) fn main() { out = out * vec2<i16>(i16(3), i16(-2)) + vec2<i16>(i16(1)); }"),
    ("negation", "enable wgpu_int16;\n@group(0) @binding(0) var<storage, read> a: i16;\n@group(0) @binding(1) var<storage, read_write> out: i16;\n@compute @workgroup_size(1) fn main() { out = -a; }"),
    ("bitcast i16 sum to u16", "enable wgpu_int16;\n@group(0) @binding(0) var<storage, read> a: i16;\n@group(0) @binding(1) var<storage, read_write> out: u16;\n@compute @workgroup_size(1) fn main() { out = bitcast<u16>(a + a); }"),
    ("bitcast u16 difference to i16", "enable wgpu_int16;\n@group(0) @binding(0) var<storage, read> a: u16;\n@group(0) @binding(1) var<storage, read> b: u16;\n@group(0) @binding(2) var<storage, read_write> out: i16;\n@compute @workgroup_size(1) fn main() { out = bitcast<i16>(a - b); }"),
    ("bitcast vectors", "enable wgpu_int16;\n@group(0) @binding(0) var<storage, read> a: vec2<u16>;\n@group(0) @binding(1) var<storage, read_write> out: vec2<i16>;\n@group(0) @binding(2) var<storage, read_write> o2: u16;\n@compute @workgroup_size(1) fn main() { out = bitcast<vec2<i16>>(a - a.yx); o2 = bitcast<u16>(out.x); }"),
    ("i16 division and remainder", "enable wgpu_int16;\n@group(0) @binding(0) var<storage, read> a: i16;\n@group(0) @binding(1) var<storage, read> b: i16;\n@group(0) @binding(2) var<storage, read_write> out: i16;\n@compute @workgroup_size(1) fn main() { out = a / b + a % b; }"),
    ("u16 division and remainder", "enable wgpu_int16;\n@group(0) @binding(0) var<storage, read> a: u16;\n@group(0) @binding(1) var<storage, read> b: u16;\n@group(0) @binding(2) var<storage, read_write> out: u16;\n@compute @workgroup_size(1) fn main() { out = a / b + a % b; }"),
    ("vector division and remainder", "enable wgpu_int16;\n@group(0) @binding(0) var<storage, read> a: vec2<i16>;\n@group(0) @binding(1) var<storage, read> b: vec2<u16>;\n@group(0) @binding(2) var<storage, read_write> out: vec2<i16>;\n@group(0) @binding(3) var<storage, read_write> out2: vec2<u16>;\n@compute @workgroup_size(1) fn main() { out = a / a + a % a; out2 = b / b + b % b; }"),
    ("comparison and select", "enable wgpu_int16;\n@group(0) @binding(0) var<storage, read> a: i16;\n@group(0) @binding(1) var<storage, read_write> out: i16;\n@compute @workgroup_size(1) fn main() { out = select(a, i16(-1), a < i16(0)); }"),
    ("shifts and bit operations", "enable wgpu_int16;\n@group(0) @binding(0) var<storage, read> a: u16;\n@group(0) @binding(1) var<storage, read_write> out: u16;\n@compute @workgroup_size(1) fn main() { out = ((a << 2u) | (a >> 1u)) ^ (~a & u16(255)); }"),
    ("conversions to and from 32 bits", "enable wgpu_int16;\n@group(0) @binding(0) var<storage, read_write> o32: i32;\n@group(0) @binding(1) var<storage, read_write> o16: u16;\n@compute @workgroup_size(1) fn main() { o16 = u16(o32); o32 = i32(o16) + 1; }"),
    ("16-bit temporaries only", "enable wgpu_int16;\n@group(0) @binding(0) var<storage, read_write> o: i32;\n@compute @workgroup_size(1) fn main() { let t = i16(o) * i16(3); o = i32(t); }"),
    ("struct and array members", "enable wgpu_int16;\nstruct S { a: i16, b: vec2<u16>, c: array<u16, 4> }\n@group(0) @binding(0) var<storage, read_write> s: S;\n@compute @workgroup_size(1) fn main() { s.c[u16(1)] = s.b.x + u16(s.a); }"),
    ("float to 16-bit", "enable wgpu_int16;\n@group(0) @binding(0) var<storage, read> f: vec2<f32>;\n@group(0) @binding(1) var<storage, read_write> o: i16;\n@group(0) @binding(2) var<storage, read_write> u: vec2<u16>;\n@compute @workgroup_size(1) fn main() { o = i16(f.x); u = vec2<u16>(f); }"),
    ("16-bit to float", "enable wgpu_int16;\n@group(0) @binding(0) var<storage, read> a: i16;\n@group(0) @binding(1) var<storage, read_write> f: f32;\n@compute @workgroup_size(1) fn main() { f = f32(a) + f32(u16(a)); }"),
    ("workgroup variable", "enable wgpu_int16;\nvar<workgroup> w: i16;\n@group(0) @binding(0) var<storage, read_write> o: i16;\n@compute @workgroup_size(1) fn main() { w = o; workgroupBarrier(); o = w; }"),
    ("function arguments and loop", "enable wgpu_int16;\nfn scale(x: i16, y: i16) -> i16 { return x * y; }\n@group(0) @binding(0) var<storage, read_write> o: i16;\n@compute @workgroup_size(1) fn main() { var i = i16(0); loop { if i >= o { break; } i = i + i16(1); } o = scale(i, i16(3)); }"),
    ("uniform members", "enable wgpu_int16;\nstruct U { x: i16, y: i16, z: vec2<u16> }\n@group(0) @binding(0) var<uniform> un: U;\n@group(0) @binding(1) var<storage, read_write> o: u16;\n@compute @workgroup_size(1) fn main() { o = u16(un.x + un.y) + un.z.y; }"),
    ("runtime-sized array", "enable wgpu_int16;\n@group(0) @binding(0) var<storage, read> ra: array<u16>;\n@group(0) @binding(1) var<storage, read_write> o: u16;\n@compute @workgroup_size(1) fn main() { o = ra[1] + u16(arrayLength(&ra)); }"),
    ("abs min max clamp", "enable wgpu_int16;\n@group(0) @binding(0) var<storage, read> a: i16;\n@group(0) @binding(1) var<storage, read> b: vec2<u16>;\n@group(0) @binding(2) var<storage, read_write> o: i16;\n@group(0) @binding(3) var<storage, read_write> o2: vec2<u16>;\n@compute @workgroup_size(1) fn main() { o = abs(a) + min(a, i16(3)) + max(a, i16(-3)) + clamp(a, i16(-9), i16(9)) + sign(a); o2 = min(b, b.yx) + max(b, vec2<u16>(u16(2))); }"),
    ("dot product", "enable wgpu_int16;\n@group(0) @binding(0) var<storage, read> a: vec2<i16>;\n@group(0) @binding(1) var<storage, read_write> o: i16;\n@compute @workgroup_size(1) fn main() { o = dot(a, vec2<i16>(i16(2), i16(-1))); }"),
    ("folded constants", "enable wgpu_int16;\n@group(0) @binding(0) var<storage, read_write> o: i16;\n@group(0) @binding(1) var<storage, read_write> u: u16;\n@compute @workgroup_size(1) fn main() { const c = -i16(5) * i16(3) - i16(7) / i16(2) + ~i16(5); const d = ~u16(5) % u16(7); o = c; u = d; }"),
    ("16-bit member never read", "enable wgpu_int16;\nstruct S { a: u32, b: i16 }\n@group(0) @binding(0) var<storage, read> s: S;\n@group(0) @binding(1) var<storage, read_write> o: u32;\n@compute @workgroup_size(1) fn main() { o = s.a; }"),
    ("integer literals for 16-bit types", "enable wgpu_int16;\n@group(0) @binding(0) var<storage, read_write> o: i16;\n@compute @workgroup_size(1) fn main() { let x: i16 = 5; var y = vec2<i16>(1, -2); o = x + y.y; }"),
];

/// f16 and f64 converted to 16-bit integers, with the targets that can write
/// each float type at all.
const WIDER_FLOATS_TO_16BIT: &[(&str, &str, &[&str])] = &[
    ("f16 to 16-bit", "enable f16;\nenable wgpu_int16;\n@group(0) @binding(0) var<storage, read> h: vec2<f16>;\n@group(0) @binding(1) var<storage, read_write> o: i16;\n@group(0) @binding(2) var<storage, read_write> u: vec2<u16>;\n@compute @workgroup_size(1) fn main() { o = i16(h.x); u = vec2<u16>(h); }", &["SPIR-V", "Metal", "HLSL", "WGSL"]),
    ("f64 to 16-bit", "enable wgpu_int16;\n@group(0) @binding(0) var<storage, read> d: f64;\n@group(0) @binding(1) var<storage, read_write> o: i16;\n@group(0) @binding(2) var<storage, read_write> u: u16;\n@compute @workgroup_size(1) fn main() { o = i16(d); u = u16(d); }", &["SPIR-V", "HLSL", "WGSL"]),
];

/// Write GLSL for `module` with the given options.
#[track_caller]
fn glsl_source(
    name: &str,
    module: &naga::Module,
    info: &naga::valid::ModuleInfo,
    options: &naga::back::glsl::Options,
) -> String {
    let pipeline_options = naga::back::glsl::PipelineOptions {
        shader_stage: naga::ShaderStage::Compute,
        entry_point: "main".to_string(),
        multiview: None,
    };
    let mut out = String::new();
    let mut writer = naga::back::glsl::Writer::new(
        &mut out,
        module,
        info,
        options,
        &pipeline_options,
        naga::proc::BoundsCheckPolicies::default(),
    )
    .unwrap_or_else(|e| panic!("{name}: GLSL writer setup failed: {e:?}"));
    writer
        .write()
        .unwrap_or_else(|e| panic!("{name}: GLSL generation failed: {e:?}"));
    out
}

/// glslang accepts the 16-bit integer literal suffixes (`7s`, `7us`) only for
/// desktop profiles, while GL_EXT_shader_explicit_arithmetic_types also defines
/// them for ESSL. Rewrite each suffixed literal as the matching constructor call
/// so an ES shader is judged on everything else.
fn rewrite_16bit_suffixes(src: &str) -> String {
    let b = src.as_bytes();
    let ident = |c: u8| c.is_ascii_alphanumeric() || c == b'_';
    let mut out = String::new();
    let mut i = 0;
    while i < b.len() {
        if b[i].is_ascii_digit() && (i == 0 || !(ident(b[i - 1]) || b[i - 1] == b'.')) {
            let mut j = i;
            while j < b.len() && (b[j].is_ascii_hexdigit() || b[j] == b'x' || b[j] == b'X') {
                j += 1;
            }
            let digits = &src[i..j];
            let mut k = j;
            let unsigned = k < b.len() && (b[k] == b'u' || b[k] == b'U');
            if unsigned {
                k += 1;
            }
            let short = k < b.len() && (b[k] == b's' || b[k] == b'S');
            if short && !(k + 1 < b.len() && ident(b[k + 1])) {
                if unsigned {
                    out.push_str(&format!("uint16_t({digits}u)"));
                } else {
                    out.push_str(&format!("int16_t({digits})"));
                }
                i = k + 1;
                continue;
            }
            out.push_str(&src[i..j]);
            i = j;
            continue;
        }
        out.push(b[i] as char);
        i += 1;
    }
    out
}

/// Compile a compute shader with glslang's reference compiler; return its log
/// on failure.
fn glslang_compile(name: &str, source: &str) -> Result<(), String> {
    static COUNTER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
    let n = COUNTER.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
    let path = std::env::temp_dir().join(format!("int16_{}_{n}.comp", std::process::id()));
    std::fs::write(&path, source).expect("write the shader to a temporary file");
    let output = std::process::Command::new("glslangValidator")
        .arg("-S")
        .arg("comp")
        .arg(&path)
        .output()
        .unwrap_or_else(|e| panic!("{name}: could not run glslangValidator: {e}"));
    let _ = std::fs::remove_file(&path);
    if output.status.success() {
        Ok(())
    } else {
        Err(format!(
            "{}{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        ))
    }
}

/// GLSL written for 16-bit shaders compiles with glslang, both for the default
/// target (GLSL ES 3.10) and for desktop GLSL 4.50.
#[test]
fn glsl_16bit_output_compiles() {
    let mut failures = Vec::new();
    for (name, src) in SHADERS_16BIT {
        let (module, info) = module_and_info(src);
        let targets = [
            ("default", true, naga::back::glsl::Options::default()),
            (
                "desktop 450",
                false,
                naga::back::glsl::Options {
                    version: naga::back::glsl::Version::Desktop(450),
                    ..Default::default()
                },
            ),
        ];
        for (target, es, options) in targets {
            let source = glsl_source(name, &module, &info, &options);
            let checked = if es {
                rewrite_16bit_suffixes(&source)
            } else {
                source.clone()
            };
            if let Err(log) = glslang_compile(name, &checked) {
                failures.push(format!("{name} ({target}):\n{log}\n{source}"));
            }
        }
    }
    assert!(failures.is_empty(), "GLSL rejected by glslang:\n{}", failures.join("\n"));
}

/// Split C-like source into tokens: identifiers, numbers (with any suffix
/// letters), and single punctuation characters.
fn c_tokens(src: &str) -> Vec<String> {
    let mut tokens = Vec::new();
    let chars: Vec<char> = src.chars().collect();
    let mut i = 0;
    while i < chars.len() {
        let c = chars[i];
        if c.is_whitespace() {
            i += 1;
        } else if c == '/' && chars.get(i + 1) == Some(&'/') {
            while i < chars.len() && chars[i] != '\n' {
                i += 1;
            }
        } else if c.is_alphanumeric() || c == '_' {
            let start = i;
            while i < chars.len() && (chars[i].is_alphanumeric() || chars[i] == '_') {
                i += 1;
            }
            tokens.push(chars[start..i].iter().collect());
        } else {
            tokens.push(c.to_string());
            i += 1;
        }
    }
    tokens
}

fn is_16bit_type(token: &str) -> bool {
    matches!(
        token,
        "short" | "short2" | "short3" | "short4" | "ushort" | "ushort2" | "ushort3" | "ushort4"
    )
}

/// Arguments of the call whose opening parenthesis is at `open`, split at
/// top-level commas.
fn call_arguments(tokens: &[String], open: usize) -> Vec<Vec<String>> {
    let mut args = vec![Vec::new()];
    let mut depth = 0;
    for t in &tokens[open..] {
        match t.as_str() {
            "(" | "[" | "{" => {
                depth += 1;
                if depth == 1 {
                    continue;
                }
            }
            ")" | "]" | "}" => {
                depth -= 1;
                if depth == 0 {
                    break;
                }
            }
            "," if depth == 1 => {
                args.push(Vec::new());
                continue;
            }
            _ => {}
        }
        args.last_mut().unwrap().push(t.clone());
    }
    args
}

/// Every `select` call in `msl` that pairs a 16-bit variable with an untyped
/// integer literal. Variables are matched to their declarations (parameters
/// and locals) within the same top-level function.
fn mixed_16bit_selects(msl: &str) -> Vec<String> {
    let tokens = c_tokens(msl);
    let mut found = Vec::new();
    let mut start = 0;
    let mut depth = 0;
    let mut functions = Vec::new();
    for (i, t) in tokens.iter().enumerate() {
        match t.as_str() {
            "{" => depth += 1,
            "}" => {
                depth -= 1;
                if depth == 0 {
                    functions.push(&tokens[start..=i]);
                    start = i + 1;
                }
            }
            ";" if depth == 0 => start = i + 1,
            _ => {}
        }
    }
    for f in functions {
        let mut vars = Vec::new();
        for (i, t) in f.iter().enumerate() {
            if !is_16bit_type(t) {
                continue;
            }
            let mut j = i + 1;
            while j < f.len() && matches!(f[j].as_str(), "const" | "&" | "*") {
                j += 1;
            }
            let declares = j + 1 < f.len()
                && f[j].chars().next().is_some_and(|c| c.is_alphabetic() || c == '_')
                && matches!(f[j + 1].as_str(), "," | ")" | "=" | ";" | "[");
            if declares {
                vars.push(f[j].clone());
            }
        }
        let literal = |arg: &[String]| {
            let a: Vec<&str> = arg.iter().map(String::as_str).collect();
            let a = match a.as_slice() {
                ["-", rest @ ..] => rest,
                other => other,
            };
            a.len() == 1 && a[0].chars().next().is_some_and(|c| c.is_ascii_digit())
        };
        let variable = |arg: &[String]| {
            let mut a: Vec<&str> = arg.iter().map(String::as_str).collect();
            while a.len() > 2 && a[0] == "(" && a[a.len() - 1] == ")" {
                a = a[1..a.len() - 1].to_vec();
            }
            a.len() == 1 && vars.iter().any(|v| v == a[0])
        };
        for (i, t) in f.iter().enumerate() {
            if t == "select" && f.get(i + 1).is_some_and(|n| n == "(") {
                let args = call_arguments(f, i + 1);
                if args.len() >= 2
                    && ((literal(&args[0]) && variable(&args[1]))
                        || (variable(&args[0]) && literal(&args[1])))
                {
                    found.push(format!("select({}, {}, ...)", args[0].join(" "), args[1].join(" ")));
                }
            }
        }
    }
    found
}

/// Metal output for 16-bit division and remainder is generated, declares the
/// 16-bit types, and never hands Metal's `select` a 16-bit value next to an
/// untyped integer literal (no overload matches that pair).
#[test]
fn metal_16bit_division_and_remainder() {
    for (name, src) in SHADERS_16BIT
        .iter()
        .filter(|(name, _)| name.contains("division"))
    {
        let (module, info) = module_and_info(src);
        let (msl, _) = naga::back::msl::write_string(
            &module,
            &info,
            &naga::back::msl::Options::default(),
            &naga::back::msl::PipelineOptions::default(),
        )
        .unwrap_or_else(|e| panic!("{name}: Metal generation failed: {e:?}"));
        let unsigned = name.starts_with('u');
        assert!(
            c_tokens(&msl)
                .iter()
                .any(|t| is_16bit_type(t) && t.starts_with('u') == unsigned),
            "{name}: no 16-bit Metal type in the output:\n{msl}",
        );
        let mixed = mixed_16bit_selects(&msl);
        assert!(
            mixed.is_empty(),
            "{name}: select pairs a 16-bit value with an untyped literal: {mixed:?}\n{msl}",
        );
    }
}

/// Validate a SPIR-V module with spirv-val from SPIRV-Tools; return its log on
/// failure.
fn spirv_val(name: &str, words: &[u32]) -> Result<(), String> {
    static COUNTER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
    let n = COUNTER.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
    let path = std::env::temp_dir().join(format!("int16_{}_{n}.spv", std::process::id()));
    let bytes: Vec<u8> = words.iter().flat_map(|w| w.to_le_bytes()).collect();
    std::fs::write(&path, bytes).expect("write the module to a temporary file");
    let output = std::process::Command::new("spirv-val")
        .arg("--target-env")
        .arg("vulkan1.1")
        .arg(&path)
        .output()
        .unwrap_or_else(|e| panic!("{name}: could not run spirv-val: {e}"));
    let _ = std::fs::remove_file(&path);
    if output.status.success() {
        Ok(())
    } else {
        Err(format!(
            "{}{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        ))
    }
}

/// Parentheses in `src` open and close in order.
fn parentheses_balance(src: &str) -> bool {
    let mut depth = 0i64;
    for c in src.chars() {
        match c {
            '(' => depth += 1,
            ')' => {
                depth -= 1;
                if depth < 0 {
                    return false;
                }
            }
            _ => {}
        }
    }
    depth == 0
}

/// Run a backend, turning a panic inside it into an error that names it.
fn without_panic<T>(f: impl FnOnce() -> T) -> Result<T, String> {
    std::panic::catch_unwind(std::panic::AssertUnwindSafe(f)).map_err(|payload| {
        let message = payload
            .downcast_ref::<String>()
            .cloned()
            .or_else(|| payload.downcast_ref::<&str>().map(|s| s.to_string()))
            .unwrap_or_default();
        format!("panicked: {message}")
    })
}

/// Every 16-bit shader goes through every backend, and the f16 and f64 ones
/// through the backends that write those floats. Each target first validates
/// the module with the capabilities that backend reports as supported, as the
/// naga command-line tool does before writing it. Then the SPIR-V passes
/// spirv-val, Metal and HLSL are generated with balanced parentheses, and the
/// WGSL keeps `enable wgpu_int16;` and parses and validates again.
#[test]
fn every_backend_writes_16bit_shaders() {
    let every: &[&str] = &["SPIR-V", "Metal", "HLSL", "GLSL", "WGSL"];
    let shaders = SHADERS_16BIT
        .iter()
        .map(|&(name, src)| (name, src, every))
        .chain(WIDER_FLOATS_TO_16BIT.iter().copied());
    let mut failures = Vec::new();
    for (name, src, wanted) in shaders {
        let (module, info) = match without_panic(|| module_and_info(src)) {
            Ok(loaded) => loaded,
            Err(e) => {
                failures.push(format!("{name}: {e}"));
                continue;
            }
        };
        let targets = [
            ("SPIR-V", naga::back::spv::supported_capabilities()),
            ("Metal", naga::back::msl::supported_capabilities()),
            ("HLSL", naga::back::hlsl::supported_capabilities()),
            ("GLSL", naga::back::glsl::supported_capabilities()),
            ("WGSL", naga::back::wgsl::supported_capabilities()),
        ];
        for (target, capabilities) in targets.into_iter().filter(|(t, _)| wanted.contains(t)) {
            if let Err(e) = Validator::new(ValidationFlags::all(), capabilities).validate(&module) {
                failures.push(format!(
                    "{name} ({target}): refused by the capabilities the backend reports: {:?}",
                    e.as_inner()
                ));
            }
        }

        if wanted.contains(&"SPIR-V") {
            let spv_options = naga::back::spv::Options {
                lang_version: (1, 3),
                ..Default::default()
            };
            match without_panic(|| naga::back::spv::write_vec(&module, &info, &spv_options, None)) {
                Ok(Ok(words)) => {
                    if let Err(log) = spirv_val(name, &words) {
                        failures.push(format!("{name} (SPIR-V): {log}"));
                    }
                }
                Ok(Err(e)) => failures.push(format!("{name} (SPIR-V): generation failed: {e:?}")),
                Err(e) => failures.push(format!("{name} (SPIR-V): {e}")),
            }
        }

        if wanted.contains(&"Metal") {
            let metal = without_panic(|| {
                naga::back::msl::write_string(
                    &module,
                    &info,
                    &naga::back::msl::Options::default(),
                    &naga::back::msl::PipelineOptions::default(),
                )
                .map(|(msl, _)| msl)
                .map_err(|e| format!("generation failed: {e:?}"))
            })
            .and_then(|r| r);
            match metal {
                Ok(msl) if !parentheses_balance(&msl) => {
                    failures.push(format!("{name} (Metal): unbalanced parentheses:\n{msl}"))
                }
                Ok(_) => {}
                Err(e) => failures.push(format!("{name} (Metal): {e}")),
            }
        }

        if wanted.contains(&"HLSL") {
            let hlsl_options = naga::back::hlsl::Options {
                shader_model: naga::back::hlsl::ShaderModel::V6_2,
                ..Default::default()
            };
            let pipeline_options = naga::back::hlsl::PipelineOptions::default();
            let hlsl = without_panic(|| {
                let mut hlsl = String::new();
                naga::back::hlsl::Writer::new(&mut hlsl, &hlsl_options, &pipeline_options)
                    .write(&module, &info, None)
                    .map(|_| ())
                    .map_err(|e| format!("generation failed: {e:?}"))?;
                Ok(hlsl)
            })
            .and_then(|r| r);
            match hlsl {
                Ok(hlsl) if !parentheses_balance(&hlsl) => {
                    failures.push(format!("{name} (HLSL): unbalanced parentheses:\n{hlsl}"))
                }
                Ok(_) => {}
                Err(e) => failures.push(format!("{name} (HLSL): {e}")),
            }
        }

        if wanted.contains(&"WGSL") {
            let wgsl = without_panic(|| {
                naga::back::wgsl::write_string(&module, &info, naga::back::wgsl::WriterFlags::empty())
                    .map_err(|e| format!("generation failed: {e:?}"))
            })
            .and_then(|r| r);
            match wgsl {
                Ok(wgsl) => {
                    let again = parse_str(&wgsl).map_err(|e| e.emit_to_string(&wgsl)).and_then(|m| {
                        Validator::new(ValidationFlags::all(), Capabilities::all())
                            .validate(&m)
                            .map(|_| ())
                            .map_err(|e| format!("{e:?}"))
                    });
                    if !wgsl.contains("enable wgpu_int16;") {
                        failures.push(format!("{name} (WGSL): no enable wgpu_int16;\n{wgsl}"));
                    } else if let Err(e) = again {
                        failures.push(format!("{name} (WGSL): output does not load again: {e}\n{wgsl}"));
                    }
                }
                Err(e) => failures.push(format!("{name} (WGSL): {e}")),
            }
        }
    }
    assert!(failures.is_empty(), "backend output rejected:\n{}", failures.join("\n"));
}
