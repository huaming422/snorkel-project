#!/usr/bin/env bash
# Sourced by tests/test.sh before the tests run (set -euo pipefail inherited).
# The image already holds the full module and build cache for the base commit
# (Dockerfile blocks 5/7), so modules resolve from that cache first and the
# test build needs nothing from the network.
cd /repo/coredns

export GOFLAGS=-mod=mod
export GOTOOLCHAIN=local

# Offline-first module resolution against the image's module cache; logged
# online fallback only if the bake was somehow incomplete.
if GOPROXY=off go mod download > /tmp/test-setup-godl.log 2>&1; then
    echo "[offline-first] go modules satisfied from image cache"
elif go mod download >> /tmp/test-setup-godl.log 2>&1; then
    echo "[test-setup] go modules downloaded online (image cache was stale)"
else
    tail -40 /tmp/test-setup-godl.log >&2
    exit 1
fi
