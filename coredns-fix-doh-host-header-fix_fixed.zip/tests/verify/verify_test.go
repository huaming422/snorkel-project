// Tests for the HTTP host value the forward plugin sends to DNS-over-HTTPS
// (https://) upstreams.
//
// Each test builds forwarders from Corefile stanzas with parseForward and uses
// them the way the running server does: queries go through (*Forward).ServeDNS
// and upstream probes through the health checker each stanza set up. The HTTP
// client and TLS config a stanza produces are used as they are. Each upstream
// presents a certificate for its tls_servername, trusted through the stanza's
// own `tls <ca>` option, so the TLS handshake is the real one.
//
// The test package is `forward` (matching the existing forward tests) so the
// controller-based construction path used by the real server is exercised.

package forward

import (
	"context"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/pem"
	"math/big"
	"net"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"path/filepath"
	"sync"
	"testing"
	"time"

	"github.com/coredns/caddy"
	"github.com/coredns/coredns/plugin/pkg/dnstest"
	"github.com/coredns/coredns/plugin/pkg/doh"
	"github.com/coredns/coredns/plugin/test"

	"github.com/miekg/dns"
)

// verifyDoHUpstream starts a DoH endpoint that speaks HTTP/2 and HTTP/1.1 over
// TLS with a certificate valid for serverName (when set) and for the loopback
// addresses, and writes that certificate to a PEM file a stanza can trust with
// `tls <file>`. It answers every query whatever host the client presented and
// records the HTTP host value of the most recent request.
func verifyDoHUpstream(t *testing.T, serverName string) (upstream, caFile string, lastHost func() string) {
	t.Helper()

	key, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		t.Fatalf("generate upstream key: %v", err)
	}
	tmpl := &x509.Certificate{
		SerialNumber:          big.NewInt(1),
		Subject:               pkix.Name{CommonName: "verify-doh-upstream"},
		NotBefore:             time.Now().Add(-time.Hour),
		NotAfter:              time.Now().Add(24 * time.Hour),
		KeyUsage:              x509.KeyUsageDigitalSignature | x509.KeyUsageCertSign,
		ExtKeyUsage:           []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
		BasicConstraintsValid: true,
		IsCA:                  true,
		IPAddresses:           []net.IP{net.IPv4(127, 0, 0, 1), net.IPv6loopback},
	}
	if serverName != "" {
		tmpl.DNSNames = []string{serverName}
	}
	der, err := x509.CreateCertificate(rand.Reader, tmpl, tmpl, &key.PublicKey, key)
	if err != nil {
		t.Fatalf("create upstream certificate: %v", err)
	}
	caFile = filepath.Join(t.TempDir(), "upstream-ca.pem")
	if err := os.WriteFile(caFile, pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: der}), 0o600); err != nil {
		t.Fatalf("write upstream CA file: %v", err)
	}

	var mu sync.Mutex
	var seen string

	s := httptest.NewUnstartedServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		mu.Lock()
		seen = r.Host
		mu.Unlock()

		msg, err := doh.RequestToMsg(r)
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}

		ret := new(dns.Msg)
		reply := ret.SetReply(msg)
		if len(msg.Question) > 0 && msg.Question[0].Qtype == dns.TypeA {
			reply.Answer = append(reply.Answer, test.A(msg.Question[0].Name+" IN A 127.0.0.1"))
		}

		buf, err := reply.Pack()
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		w.Header().Set("Content-Type", doh.MimeType)
		w.Write(buf)
	}))
	s.EnableHTTP2 = true
	s.TLS = &tls.Config{
		Certificates: []tls.Certificate{{Certificate: [][]byte{der}, PrivateKey: key}},
		NextProtos:   []string{"h2", "http/1.1"},
	}
	s.StartTLS()
	t.Cleanup(s.Close)

	return s.URL, caFile, func() string {
		mu.Lock()
		defer mu.Unlock()
		return seen
	}
}

// verifyForwarder builds a forwarder from a stanza that trusts the upstream's
// certificate through the `tls` option, plus any extra block options.
func verifyForwarder(t *testing.T, upstream, caFile string, options ...string) *Forward {
	t.Helper()

	corefile := "forward . " + upstream + " {\n\ttls " + caFile + "\n"
	for _, o := range options {
		corefile += "\t" + o + "\n"
	}
	corefile += "}"

	fs, err := parseForward(caddy.NewTestController("dns", corefile))
	if err != nil {
		t.Fatalf("Failed to create forwarder from %q: %s", corefile, err)
	}
	return fs[0]
}

// verifyDoHBlock describes one forward block: its doh_method and its
// tls_servername.
type verifyDoHBlock struct {
	method     string
	serverName string
}

// verifyForwarders starts one upstream and builds one forwarder per block,
// all of them before any is used, and returns the forwarders together with
// each upstream's recorded host.
func verifyForwarders(t *testing.T, blocks []verifyDoHBlock) ([]*Forward, []func() string) {
	t.Helper()

	fwds := make([]*Forward, len(blocks))
	hosts := make([]func() string, len(blocks))
	for i, b := range blocks {
		upstream, caFile, lastHost := verifyDoHUpstream(t, b.serverName)
		fwds[i] = verifyForwarder(t, upstream, caFile, "tls_servername "+b.serverName, "doh_method "+b.method)
		hosts[i] = lastHost
	}
	return fwds, hosts
}

// verifyQuery sends an A query through the whole plugin and checks the answer.
func verifyQuery(t *testing.T, f *Forward) {
	t.Helper()

	m := new(dns.Msg)
	m.SetQuestion("example.org.", dns.TypeA)
	rec := dnstest.NewRecorder(&test.ResponseWriter{})

	if _, err := f.ServeDNS(context.TODO(), rec, m); err != nil {
		t.Fatalf("Expected to receive reply, but didn't: %v", err)
	}
	if rec.Msg == nil || len(rec.Msg.Answer) == 0 {
		t.Fatalf("Expected an answer in the reply, got %v", rec.Msg)
	}
	if x := rec.Msg.Answer[0].Header().Name; x != "example.org." {
		t.Fatalf("Expected answer for %q, got %q", "example.org.", x)
	}
}

// verifyHostOnly returns the host part of an HTTP host value without an
// optional trailing ":port". The host value may carry the authority's port, so
// an upstream on a non-default port can see "name:port" while one on 443 sees
// the bare name. Comparing only the host part accepts both forms.
func verifyHostOnly(h string) string {
	if host, _, err := net.SplitHostPort(h); err == nil {
		return host
	}
	return h
}

// TestDoHAuthorityUsesServerName sends a query through each of two forwarders,
// each with its own upstream and tls_servername, one using the default
// doh_method (POST) and one using GET. Each upstream must see its own
// forwarder's server name as the request's HTTP host value. Both forwarders
// are set up before either one is used.
func TestDoHAuthorityUsesServerName(t *testing.T) {
	blocks := []verifyDoHBlock{
		{http.MethodPost, "dns.example.net"},
		{http.MethodGet, "doh.example.org"},
	}
	fwds, hosts := verifyForwarders(t, blocks)
	for _, f := range fwds {
		f.OnStartup()
		t.Cleanup(func() { f.OnShutdown() })
	}

	for i, b := range blocks {
		t.Run(b.method, func(t *testing.T) {
			verifyQuery(t, fwds[i])

			if got := verifyHostOnly(hosts[i]()); got != b.serverName {
				t.Fatalf("doh_method %s: outbound DoH request presented host %q, want the configured server name %q", b.method, hosts[i](), b.serverName)
			}
		})
	}
}

// TestDoHHealthAuthority sets up two forwarders, each with its own upstream and
// tls_servername, then runs each one's upstream health check through the
// health checker its stanza set up. Each upstream must see its own forwarder's
// server name as the probe's HTTP host value. Both forwarders are set up
// before either probe runs.
func TestDoHHealthAuthority(t *testing.T) {
	blocks := []verifyDoHBlock{
		{http.MethodPost, "probe.example.com"},
		{http.MethodGet, "check.example.org"},
	}
	fwds, hosts := verifyForwarders(t, blocks)

	for i, b := range blocks {
		t.Run(b.serverName, func(t *testing.T) {
			p := fwds[i].proxies[0]
			if err := p.GetHealthchecker().Check(p); err != nil {
				t.Fatalf("health probe failed: %v", err)
			}

			if got := verifyHostOnly(hosts[i]()); got != b.serverName {
				t.Fatalf("health probe presented host %q, want the configured server name %q", hosts[i](), b.serverName)
			}
		})
	}
}

// TestDoHForwardingStillAnswers checks that an HTTPS upstream configured
// without tls_servername still answers a query and sees its own address as the
// request's HTTP host value.
func TestDoHForwardingStillAnswers(t *testing.T) {
	upstream, caFile, lastHost := verifyDoHUpstream(t, "")
	f := verifyForwarder(t, upstream, caFile)
	f.OnStartup()
	defer f.OnShutdown()

	verifyQuery(t, f)

	u, err := url.Parse(upstream)
	if err != nil {
		t.Fatalf("parse upstream URL %q: %v", upstream, err)
	}
	if got := verifyHostOnly(lastHost()); got != u.Hostname() {
		t.Fatalf("outbound DoH request presented host %q, want the upstream address %q", lastHost(), u.Hostname())
	}
}
