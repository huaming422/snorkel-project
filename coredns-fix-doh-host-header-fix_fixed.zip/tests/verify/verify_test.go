// Behavioral checks for DNS-over-HTTPS (https://) upstream forwarding.
//
// Every test builds the forwarder from a Corefile stanza with parseForward and
// then uses it the way the running server does: queries go through
// (*Forward).ServeDNS and the upstream probe through the health checker the
// stanza set up. The tests never swap the HTTP client or the TLS config the
// stanza produced. Each upstream presents a certificate for the configured
// tls_servername, trusted through the stanza's own `tls <ca>` option, so the
// handshake is the real one and the only thing asserted is the HTTP host value
// the upstream receives (the HTTP/2 :authority, or Host on HTTP/1.1). Nothing
// here names a helper, field, setter, or file that a particular fix might
// introduce, so any design that makes the outbound requests carry the
// configured server name passes.
//
// The test package is `forward` (matching the existing forward tests) so the
// controller-based construction path used by the real server is exercised.

package forward

import (
	"context"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/pem"
	"math/big"
	"net"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"path/filepath"
	"sync"
	"testing"
	"time"

	"github.com/coredns/caddy"
	"github.com/coredns/coredns/plugin/pkg/dnstest"
	"github.com/coredns/coredns/plugin/pkg/doh"
	"github.com/coredns/coredns/plugin/test"

	"github.com/miekg/dns"
)

// verifyDoHUpstream starts a DoH endpoint that speaks HTTP/2 and HTTP/1.1 over
// TLS with a certificate valid for serverName (when set) and for the loopback
// addresses, and writes that certificate to a PEM file a stanza can trust with
// `tls <file>`. It answers every query whatever host the client presented, the
// way a permissive public resolver does, and records the HTTP host value of
// the most recent request: that is the only way to tell what the client sent.
func verifyDoHUpstream(t *testing.T, serverName string) (upstream, caFile string, lastHost func() string) {
	t.Helper()

	key, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		t.Fatalf("generate upstream key: %v", err)
	}
	tmpl := &x509.Certificate{
		SerialNumber:          big.NewInt(1),
		Subject:               pkix.Name{CommonName: "verify-doh-upstream"},
		NotBefore:             time.Now().Add(-time.Hour),
		NotAfter:              time.Now().Add(24 * time.Hour),
		KeyUsage:              x509.KeyUsageDigitalSignature | x509.KeyUsageCertSign,
		ExtKeyUsage:           []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
		BasicConstraintsValid: true,
		IsCA:                  true,
		IPAddresses:           []net.IP{net.IPv4(127, 0, 0, 1), net.IPv6loopback},
	}
	if serverName != "" {
		tmpl.DNSNames = []string{serverName}
	}
	der, err := x509.CreateCertificate(rand.Reader, tmpl, tmpl, &key.PublicKey, key)
	if err != nil {
		t.Fatalf("create upstream certificate: %v", err)
	}
	caFile = filepath.Join(t.TempDir(), "upstream-ca.pem")
	if err := os.WriteFile(caFile, pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: der}), 0o600); err != nil {
		t.Fatalf("write upstream CA file: %v", err)
	}

	var mu sync.Mutex
	var seen string

	s := httptest.NewUnstartedServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		mu.Lock()
		seen = r.Host
		mu.Unlock()

		msg, err := doh.RequestToMsg(r)
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}

		ret := new(dns.Msg)
		reply := ret.SetReply(msg)
		if len(msg.Question) > 0 && msg.Question[0].Qtype == dns.TypeA {
			reply.Answer = append(reply.Answer, test.A(msg.Question[0].Name+" IN A 127.0.0.1"))
		}

		buf, err := reply.Pack()
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		w.Header().Set("Content-Type", doh.MimeType)
		w.Write(buf)
	}))
	s.EnableHTTP2 = true
	s.TLS = &tls.Config{
		Certificates: []tls.Certificate{{Certificate: [][]byte{der}, PrivateKey: key}},
		NextProtos:   []string{"h2", "http/1.1"},
	}
	s.StartTLS()
	t.Cleanup(s.Close)

	return s.URL, caFile, func() string {
		mu.Lock()
		defer mu.Unlock()
		return seen
	}
}

// verifyForwarder builds a forwarder from a stanza that trusts the upstream's
// certificate through the `tls` option, as an operator with a privately issued
// upstream certificate would configure it, plus any extra block options.
func verifyForwarder(t *testing.T, upstream, caFile string, options ...string) *Forward {
	t.Helper()

	corefile := "forward . " + upstream + " {\n\ttls " + caFile + "\n"
	for _, o := range options {
		corefile += "\t" + o + "\n"
	}
	corefile += "}"

	fs, err := parseForward(caddy.NewTestController("dns", corefile))
	if err != nil {
		t.Fatalf("Failed to create forwarder from %q: %s", corefile, err)
	}
	return fs[0]
}

// verifyQuery sends an A query through the whole plugin and checks the answer.
func verifyQuery(t *testing.T, f *Forward) {
	t.Helper()

	m := new(dns.Msg)
	m.SetQuestion("example.org.", dns.TypeA)
	rec := dnstest.NewRecorder(&test.ResponseWriter{})

	if _, err := f.ServeDNS(context.TODO(), rec, m); err != nil {
		t.Fatalf("Expected to receive reply, but didn't: %v", err)
	}
	if rec.Msg == nil || len(rec.Msg.Answer) == 0 {
		t.Fatalf("Expected an answer in the reply, got %v", rec.Msg)
	}
	if x := rec.Msg.Answer[0].Header().Name; x != "example.org." {
		t.Fatalf("Expected answer for %q, got %q", "example.org.", x)
	}
}

// verifyHostOnly returns the host portion of an HTTP host value, discarding an
// optional trailing ":port". The host value may carry the authority's port, so
// an upstream reached on a non-default port can legitimately see "name:port";
// against a real 443 upstream the same implementation sends the bare name.
// Comparing on the host alone accepts both forms while still rejecting an IP
// literal or an empty host.
func verifyHostOnly(h string) string {
	if host, _, err := net.SplitHostPort(h); err == nil {
		return host
	}
	return h
}

// TestDoHAuthorityUsesServerName drives queries end-to-end through two
// forwarders, each with its own upstream and tls_servername, one using the
// default doh_method (POST) and one using GET. Each upstream must see its own
// configured server name as the request's HTTP host value, not the IP:port
// from the upstream URL. Both forwarders are configured before either sends a
// query, so a request has to carry its own stanza's name rather than whichever
// stanza was parsed last. An implementation that plumbs the value through the
// lower layers but never populates it when the upstream is wired up still
// sends the IP:port here and fails.
func TestDoHAuthorityUsesServerName(t *testing.T) {
	cases := []struct {
		method     string
		serverName string
	}{
		{http.MethodPost, "dns.example.net"},
		{http.MethodGet, "doh.example.org"},
	}

	fwds := make([]*Forward, len(cases))
	hosts := make([]func() string, len(cases))
	for i, tc := range cases {
		upstream, caFile, lastHost := verifyDoHUpstream(t, tc.serverName)
		f := verifyForwarder(t, upstream, caFile, "tls_servername "+tc.serverName, "doh_method "+tc.method)
		f.OnStartup()
		t.Cleanup(func() { f.OnShutdown() })
		fwds[i], hosts[i] = f, lastHost
	}

	for i, tc := range cases {
		t.Run(tc.method, func(t *testing.T) {
			verifyQuery(t, fwds[i])

			if got := verifyHostOnly(hosts[i]()); got != tc.serverName {
				t.Fatalf("doh_method %s: outbound DoH request presented host %q, want the configured server name %q", tc.method, hosts[i](), tc.serverName)
			}
		})
	}
}

// TestDoHHealthAuthority runs the upstream health probe (a separate code path
// from the query path) through the health checker the stanza set up, and
// asserts that it, too, presents the configured server name as the outbound
// request's HTTP host value. A fix that only covers the query path fails here.
func TestDoHHealthAuthority(t *testing.T) {
	const serverName = "probe.example.com"

	upstream, caFile, lastHost := verifyDoHUpstream(t, serverName)
	f := verifyForwarder(t, upstream, caFile, "tls_servername "+serverName)
	p := f.proxies[0]

	if err := p.GetHealthchecker().Check(p); err != nil {
		t.Fatalf("health probe failed: %v", err)
	}

	if got := verifyHostOnly(lastHost()); got != serverName {
		t.Fatalf("health probe presented host %q, want the configured server name %q", lastHost(), serverName)
	}
}

// TestDoHForwardingStillAnswers guards the existing success path: an HTTPS
// upstream configured without tls_servername must still answer a normal query,
// and the request must still be addressed to the upstream itself, since there
// is no other name to present. This holds both before and after the fix.
func TestDoHForwardingStillAnswers(t *testing.T) {
	upstream, caFile, lastHost := verifyDoHUpstream(t, "")
	f := verifyForwarder(t, upstream, caFile)
	f.OnStartup()
	defer f.OnShutdown()

	verifyQuery(t, f)

	u, err := url.Parse(upstream)
	if err != nil {
		t.Fatalf("parse upstream URL %q: %v", upstream, err)
	}
	if got := verifyHostOnly(lastHost()); got != u.Hostname() {
		t.Fatalf("outbound DoH request presented host %q, want the upstream address %q", lastHost(), u.Hostname())
	}
}
