## Task

GitHub rate-limits anonymous API calls hard, so installs of GitHub-hosted tools in CI and Docker builds without a token fail every so often. The calls that matter here fetch a release and its assets.

We run a shared versions host that caches this data. It serves a release at https://mise-versions.jdx.dev/api/github/repos/OWNER/REPO/releases/TAG as JSON in the same shape as GitHub's release object. TAG can be latest; the answer then carries whatever concrete tag the host currently considers latest, the same way GitHub's own /releases/latest never echoes back the literal word "latest".

Signature and attestation verification is out of scope.

## User stories / requirements

- When a tool backed by a public GitHub repo is installed or its latest version is looked up, and the shared versions host can serve its release metadata, mise gets the metadata from the versions host: the first request for that release's metadata goes to the versions host, not to the public GitHub API.
- mise still falls back to the public API when the versions host can't produce the metadata, whether that's a 404, a 429, or any other failure, and the install finishes cleanly with no error or warning reaching the user.
- When the metadata from the versions host can't be used, either because its download URLs don't belong to the project being installed (a different host, owner, repo or release) or because the release has no downloadable assets, mise doesn't trust it: it discards that response and falls back to the GitHub API.
- mise discards a versions-host release whose tag doesn't match the one requested, and resolves through the GitHub API instead.
- For a tool resolved against a non-public GitHub API host, GitHub Enterprise or any other custom API base, mise skips the versions host entirely and talks to the configured host directly, just as before.
- mise leaves the versions host alone for release metadata whenever it's turned off by setting, or mise itself is offline or in prefer-offline mode.
- When a fully pinned exact version (such as a three-part X.Y.Z) of a public GitHub-backed tool is requested, mise confirms it with a single release lookup instead of fetching the full release list. That lookup goes to the versions host first, like any other release lookup. If it finds nothing, resolution falls through to the normal path, so a pin can still match a longer newest tag.
