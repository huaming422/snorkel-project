"""Behavioral verifier for qdrant-fix-reinit-removed-peer.

This bug lives in the cluster-recovery path, so it is only observable by running
real qdrant nodes and driving them over their stable public surface:

  * the ``qdrant`` binary CLI (``--reinit``, ``--bootstrap``, ``--uri``),
  * the HTTP API (``GET /readyz``, ``GET /cluster``,
    ``DELETE /cluster/peer/{id}``, ``PUT /collections/{name}``),
  * the persisted ``storage/raft_state.json`` on-disk format.

All three are pre-existing and stable (they predate this task's base commit);
none is invented by the fix. The verifier therefore couples to none of the fix's
internal Rust symbols or files — a valid solution may restructure or rename any
of them and still pass, because the only thing asserted here is the externally
observable behaviour: a re-initialized node boots without panicking, reaches
``/readyz``, leads its own single-voter cluster, can seed a fresh peer with
correct membership, and does not block readiness on a foreign address.

Rather than import the repository's own ``tests/consensus_tests`` package (which
would couple the shared verifier interpreter to repo test code and pull in its
heavy gRPC/qdrant-client deps), this file re-implements the handful of helpers it
needs inline, using only ``requests`` + the standard library — both available in
the verifier venv. The helpers are deliberately faithful to the repo's own
``consensus_tests/utils.py`` (process spawn with the same ``QDRANT__…`` env vars,
the same ``/cluster`` and ``/readyz`` wrappers, the same ``raft_state.json``
layout) so the scenarios exercise exactly the interface the project itself tests
through — only the transport code is duplicated, never any fix internals.

Each scenario asserts concrete observable values — HTTP 200 on ``/readyz``, the
integer cluster size from ``/cluster``, the leader id, the raft commit index —
never an internal symbol name and never a log substring as a pass/fail gate. The
"removed all voters" panic text is never matched; what separates a broken binary
from a correct one is always process liveness and ``/readyz`` reaching 200.
"""

from __future__ import annotations

import json
import os
import pathlib
import shutil
import socket
import time
from contextlib import closing
from subprocess import Popen
from typing import Callable, Optional

import pytest
import requests

# The compiled binary and the stock config live in the task repo. The binary
# location honors CARGO_TARGET_DIR (the image builds into a shared, pre-warmed
# target dir); tests/test-setup.sh also bridges a repo-local ./target symlink,
# so both resolutions work.
REPO_DIR = pathlib.Path("/repo/qdrant")
CONFIG_DIR = REPO_DIR / "config"


def _qdrant_exec() -> str:
    target_dir = os.environ.get("CARGO_TARGET_DIR", str(REPO_DIR / "target"))
    candidates = [
        pathlib.Path(target_dir) / "debug" / "qdrant",
        REPO_DIR / "target" / "debug" / "qdrant",
    ]
    for cand in candidates:
        if cand.exists():
            return str(cand)
    # Fall back to the repo-local path; the ensuing spawn error names it clearly.
    return str(REPO_DIR / "target" / "debug" / "qdrant")


WAIT_TIME_SEC = 30
RETRY_INTERVAL_SEC = 0.2

# Cluster convergence under reinit (process spawn + consensus election + a fresh
# peer bootstrap) is heavier than a steady-state query, so the readiness /
# membership waits get more headroom than the repo's 30s default. These bound how
# long we wait for an *expected* condition; a genuinely broken (panicking /
# hanging) node never satisfies it and the wait raises, failing the test.
READY_TIMEOUT = 90
CLUSTER_TIMEOUT = 90

N_PEERS = 2


# --- process management -----------------------------------------------------

class PeerProcess:
    def __init__(self, proc: Popen, http_port: int, grpc_port: int, p2p_port: int):
        self.proc = proc
        self.http_port = http_port
        self.grpc_port = grpc_port
        self.p2p_port = p2p_port
        self.pid = proc.pid

    def kill(self) -> None:
        self.proc.kill()
        self.proc.wait()


# Tracks spawned peers so the autouse fixture can reap any that leak out of a
# test (e.g. after an assertion failure mid-scenario).
_processes: list[PeerProcess] = []


@pytest.fixture(autouse=True)
def _reap_processes():
    # Reap anything left over from a previous test before starting a new one.
    while _processes:
        p = _processes.pop()
        try:
            p.kill()
        except Exception:
            pass
    yield
    while _processes:
        p = _processes.pop()
        try:
            p.kill()
        except Exception:
            pass


def _free_port() -> int:
    with closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as s:
        s.bind(("", 0))
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        return s.getsockname()[1]


def _free_port_triple() -> int:
    """Return a base port P such that P, P+1, P+2 are all free right now."""
    for _ in range(200):
        base = _free_port()
        ok = True
        socks = []
        try:
            for off in (0, 1, 2):
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                try:
                    s.bind(("", base + off))
                    socks.append(s)
                except OSError:
                    ok = False
                    break
            if ok:
                return base
        finally:
            for s in socks:
                s.close()
    raise RuntimeError("could not allocate a free contiguous port triple")


def _uri(port: int) -> str:
    return f"http://127.0.0.1:{port}"


def _peer_env(p2p_port: int, grpc_port: int, http_port: int) -> dict:
    env = os.environ.copy()
    env["QDRANT__CLUSTER__ENABLED"] = "true"
    env["QDRANT__CLUSTER__P2P__PORT"] = str(p2p_port)
    env["QDRANT__SERVICE__HTTP_PORT"] = str(http_port)
    env["QDRANT__SERVICE__GRPC_PORT"] = str(grpc_port)
    env["QDRANT__LOG_LEVEL"] = "INFO,raft::raft=info"
    return env


def _make_peer_folder(base_path: pathlib.Path, peer_number: int) -> pathlib.Path:
    peer_dir = base_path / f"peer{peer_number}"
    peer_dir.mkdir()
    shutil.copytree(CONFIG_DIR, peer_dir / "config")
    return peer_dir


def _start_first_peer(peer_dir: pathlib.Path, log_file: str, reinit: bool = False):
    base_port = _free_port_triple()
    p2p_port, grpc_port, http_port = base_port, base_port + 1, base_port + 2
    bootstrap_uri = _uri(p2p_port)
    args = [_qdrant_exec(), "--uri", bootstrap_uri]
    if reinit:
        args.append("--reinit")
    log = open(peer_dir / log_file, "w")
    proc = Popen(args, env=_peer_env(p2p_port, grpc_port, http_port), cwd=peer_dir, stdout=log, stderr=log)
    _processes.append(PeerProcess(proc, http_port, grpc_port, p2p_port))
    return _uri(http_port), bootstrap_uri


def _start_peer(peer_dir: pathlib.Path, log_file: str, bootstrap_uri: str, reinit: bool = False) -> str:
    base_port = _free_port_triple()
    p2p_port, grpc_port, http_port = base_port, base_port + 1, base_port + 2
    this_uri = _uri(p2p_port)
    args = [_qdrant_exec(), "--bootstrap", bootstrap_uri, "--uri", this_uri]
    if reinit:
        args.append("--reinit")
    log = open(peer_dir / log_file, "w")
    proc = Popen(args, env=_peer_env(p2p_port, grpc_port, http_port), cwd=peer_dir, stdout=log, stderr=log)
    _processes.append(PeerProcess(proc, http_port, grpc_port, p2p_port))
    return _uri(http_port)


# --- HTTP wrappers (pre-existing public API) --------------------------------

def _get_cluster_info(uri: str) -> dict:
    r = requests.get(f"{uri}/cluster", timeout=10)
    assert r.status_code == 200, f"GET {uri}/cluster -> {r.status_code}: {r.text}"
    return r.json()["result"]


def _peer_is_online(uri: str) -> bool:
    try:
        return requests.get(f"{uri}/readyz", timeout=10).status_code == 200
    except requests.exceptions.RequestException:
        return False


def _leader_is_defined(uri: str) -> bool:
    try:
        return _get_cluster_info(uri)["raft_info"]["leader"] is not None
    except (requests.exceptions.RequestException, AssertionError, KeyError):
        return False


def _get_leader(uri: str) -> Optional[int]:
    return _get_cluster_info(uri)["raft_info"]["leader"]


def _check_leader(uri: str, expected_leader) -> bool:
    try:
        return _get_cluster_info(uri)["raft_info"]["leader"] == expected_leader
    except (requests.exceptions.RequestException, AssertionError, KeyError):
        return False


def _cluster_size(uri: str) -> int:
    return len(_get_cluster_info(uri)["peers"])


def _check_cluster_size(uri: str, expected_size: int) -> bool:
    try:
        return _cluster_size(uri) == expected_size
    except (requests.exceptions.RequestException, AssertionError, KeyError):
        return False


def _wait_for(condition: Callable[..., bool], *args, timeout: float = WAIT_TIME_SEC) -> None:
    start = time.time()
    while not condition(*args):
        if time.time() - start > timeout:
            raise AssertionError(
                f"timed out after {timeout}s waiting for {getattr(condition, '__name__', condition)}"
            )
        time.sleep(RETRY_INTERVAL_SEC)


def _wait_for_peer_online(uri: str, timeout: float = READY_TIMEOUT) -> None:
    _wait_for(_peer_is_online, uri, timeout=timeout)


def _start_cluster(tmp_path: pathlib.Path, num_peers: int):
    peer_dirs = [_make_peer_folder(tmp_path, i) for i in range(num_peers)]
    peer_api_uris = []
    bootstrap_api_uri, bootstrap_uri = _start_first_peer(peer_dirs[0], "peer_0.log")
    peer_api_uris.append(bootstrap_api_uri)
    _wait_for(_check_cluster_size, bootstrap_api_uri, 1, timeout=CLUSTER_TIMEOUT)
    _wait_for(_leader_is_defined, bootstrap_api_uri, timeout=CLUSTER_TIMEOUT)
    leader = _get_leader(bootstrap_api_uri)
    for i in range(1, num_peers):
        peer_api_uris.append(_start_peer(peer_dirs[i], f"peer_{i}.log", bootstrap_uri))
    # Wait for all peers to see the full, consistent cluster with one leader.
    for uri in peer_api_uris:
        _wait_for(_check_cluster_size, uri, num_peers, timeout=CLUSTER_TIMEOUT)
        _wait_for(_check_leader, uri, leader, timeout=CLUSTER_TIMEOUT)
    return peer_api_uris, peer_dirs, bootstrap_uri


# --- scenario helpers -------------------------------------------------------

def _remove_peer_and_stop(peer_api_uris, peer_dirs, idx):
    """Gracefully remove peer ``idx`` from consensus, then stop its process.

    In a 2-node cluster the removal can only commit once the removed peer itself
    acks it, which guarantees the self-removal conf-change lands in that peer's
    own persisted log before we stop it — reproducing the removed-then-recovered
    state an operator hits. Returns the removed peer's id and data dir.
    """
    removed_peer_id = _get_cluster_info(peer_api_uris[idx])["peer_id"]
    removed_peer_dir = peer_dirs[idx]
    keep_uri = peer_api_uris[1 - idx]

    res = requests.delete(f"{keep_uri}/cluster/peer/{removed_peer_id}?timeout=60", timeout=70)
    assert res.status_code == 200, f"graceful peer removal failed: HTTP {res.status_code} {res.text}"

    # The surviving peer is now a single-node cluster, which also confirms the
    # removal committed (and was therefore persisted on the removed peer).
    _wait_for(_check_cluster_size, keep_uri, 1, timeout=CLUSTER_TIMEOUT)

    # Stop the removed peer (its own consensus already stopped on self-removal).
    for p in list(_processes):
        if p.http_port == int(peer_api_uris[idx].rsplit(":", 1)[1]):
            p.kill()
            _processes.remove(p)
            break
    return removed_peer_id, removed_peer_dir


def _inject_pre_apply_state(removed_peer_dir, first_peer_id, foreign_uri):
    """Deterministically recreate the kill-before-apply race on disk.

    Simulates the removed peer being killed after the self-removal conf-change
    committed (guaranteed in its log) but before it applied any of the old
    cluster's log: the address book still names the old peer, the persisted
    founding-voter pointer still points at it, nothing is applied, and the
    persisted commit index is reset. Written through the pre-existing
    ``raft_state.json`` format the repo's own tests manipulate — we only
    reproduce a reachable on-disk state, we assert nothing about its internal
    field semantics. ``--reinit`` must still recover cleanly from it.
    """
    raft_state_path = removed_peer_dir / "storage" / "raft_state.json"
    raft_state = json.loads(raft_state_path.read_text())
    raft_state["peer_address_by_id"][str(first_peer_id)] = foreign_uri
    raft_state["first_voter"] = first_peer_id
    raft_state["apply_progress_queue"] = None
    raft_state["state"]["hard_state"]["commit"] = 0
    raft_state_path.write_text(json.dumps(raft_state))


def _stop_last_peer():
    p = _processes.pop()
    p.kill()


# --- tests ------------------------------------------------------------------

def test_reinit_removed_peer_recovers(tmp_path: pathlib.Path):
    """A removed peer, re-initialized reusing its data dir, boots and self-leads.

    Reproduces the startup-panic symptom: the removed peer's log carries a
    committed self-removal entry; ``--reinit`` resets membership to a single
    voter (itself). If the stale entry is replayed on top of that reset config,
    consensus initialization panics and the node never comes up. The fix must let
    it boot cleanly and lead its own single-voter cluster.

    To make the replay deterministic, reproduce the kill-before-apply state on
    disk (committed self-removal present, nothing applied, commit index reset)
    exactly as the upstream reproduction does — otherwise a graceful removal may
    happen to apply the entry first and the panic would not fire reliably.

    Separates broken from correct behaviorally: on an unfixed binary ``/readyz``
    never returns 200 (the process panics on startup), so the readiness wait
    times out.
    """
    peer_api_uris, peer_dirs, bootstrap_uri = _start_cluster(tmp_path, N_PEERS)

    first_peer_id = _get_cluster_info(peer_api_uris[0])["peer_id"]
    _removed_id, removed_peer_dir = _remove_peer_and_stop(peer_api_uris, peer_dirs, 1)

    _inject_pre_apply_state(removed_peer_dir, first_peer_id, bootstrap_uri)

    reinit_api_uri, _reinit_bootstrap_uri = _start_first_peer(
        removed_peer_dir, "removed_peer_reinit.log", reinit=True,
    )

    # Reaching /readyz already proves consensus initialized without the panic.
    _wait_for_peer_online(reinit_api_uri)
    _wait_for(_leader_is_defined, reinit_api_uri, timeout=CLUSTER_TIMEOUT)

    # It founded a fresh single-voter cluster: the old peer must not be a member.
    assert _check_cluster_size(reinit_api_uri, 1), (
        "re-initialized removed peer did not come up as a single-voter cluster; "
        f"cluster info: {_get_cluster_info(reinit_api_uri)}"
    )
    assert str(first_peer_id) not in _get_cluster_info(reinit_api_uri)["peers"], (
        "old cluster peer leaked into the re-initialized peer's membership"
    )


def test_reinit_removed_peer_seeds_fresh_peer(tmp_path: pathlib.Path):
    """A re-initialized removed peer can still seed a brand-new bootstrapping peer.

    Injects the kill-before-apply on-disk state (stale foreign address + stale
    founding-voter pointer + reset commit) BEFORE reinit, then reinitializes and
    bootstraps a fresh peer onto the re-initialized cluster. A blunt fix that
    clears the whole log stops the startup panic but then has no snapshot anchor
    to seed a joiner; a fix that fails to reset the founding-voter pointer seeds
    the joiner with the OLD cluster's voter, corrupting its membership so it
    never goes ready. The correct fix keeps the commit-index entry as a snapshot
    anchor AND founds a clean single-voter identity.

    Separates broken from correct behaviorally: the joining peer must reach
    ``/readyz`` and observe the re-initialized peer's leader, with that peer's own
    cluster still size 1 and the joiner's membership free of the old peer.
    """
    peer_api_uris, peer_dirs, bootstrap_uri = _start_cluster(tmp_path, N_PEERS)

    first_peer_id = _get_cluster_info(peer_api_uris[0])["peer_id"]
    _removed_id, removed_peer_dir = _remove_peer_and_stop(peer_api_uris, peer_dirs, 1)

    _inject_pre_apply_state(removed_peer_dir, first_peer_id, bootstrap_uri)

    reinit_api_uri, reinit_bootstrap_uri = _start_first_peer(
        removed_peer_dir, "removed_peer_reinit.log", reinit=True,
    )
    _wait_for_peer_online(reinit_api_uri)
    _wait_for(_leader_is_defined, reinit_api_uri, timeout=CLUSTER_TIMEOUT)
    leader = _get_leader(reinit_api_uri)

    assert _check_cluster_size(reinit_api_uri, 1), (
        "re-initialized peer kept the old cluster's peer in its membership; "
        f"cluster info: {_get_cluster_info(reinit_api_uri)}"
    )

    # Seed a fresh peer onto it: requires the re-initialized peer to still serve
    # a snapshot (the retained commit-index entry is the anchor).
    new_peer_dir = _make_peer_folder(tmp_path, N_PEERS)
    new_peer_uri = _start_peer(new_peer_dir, "new_peer.log", reinit_bootstrap_uri)

    # The joiner must come up ready (a corrupted voter set would hang /readyz).
    _wait_for_peer_online(new_peer_uri)
    _wait_for(_check_leader, new_peer_uri, leader, timeout=CLUSTER_TIMEOUT)

    new_peer_members = _get_cluster_info(new_peer_uri)["peers"]
    assert str(first_peer_id) not in new_peer_members, (
        "fresh joiner inherited the old cluster's peer in its voter set; "
        f"joiner membership: {new_peer_members}"
    )


def test_reinit_peer_readyz_ignores_foreign_address(tmp_path: pathlib.Path):
    """/readyz must not wait on an address-book peer outside current membership.

    The persisted address book can hold addresses of peers that are not part of
    this peer's consensus. If readiness treats every address-book entry as a
    cluster member, it waits for this peer to reach the FOREIGN peer's commit
    index, which its own single-voter consensus never reaches, so ``/readyz``
    hangs forever. It must key readiness off actual membership instead.

    We reinit a removed peer (which prunes the book), stop it, inject the old
    first peer's address on a plain restart path (membership stays this peer
    only), push the old cluster's commit well ahead, then restart WITHOUT
    ``--reinit``. The peer must go ready while its own commit index stays behind
    the old cluster's — proving readiness ignores the foreign address.
    """
    peer_api_uris, peer_dirs, bootstrap_uri = _start_cluster(tmp_path, N_PEERS)

    first_peer_id = _get_cluster_info(peer_api_uris[0])["peer_id"]
    _removed_id, removed_peer_dir = _remove_peer_and_stop(peer_api_uris, peer_dirs, 1)

    reinit_api_uri, _reinit_bootstrap_uri = _start_first_peer(
        removed_peer_dir, "removed_peer_reinit.log", reinit=True,
    )
    _wait_for_peer_online(reinit_api_uri)

    # Stop it again so we can inject the stale foreign address on disk.
    _stop_last_peer()

    raft_state_path = removed_peer_dir / "storage" / "raft_state.json"
    raft_state = json.loads(raft_state_path.read_text())
    raft_state["peer_address_by_id"][str(first_peer_id)] = bootstrap_uri
    raft_state_path.write_text(json.dumps(raft_state))

    # Push the old (now single-node) cluster's commit index well ahead of
    # anything the single-voter peer has. Each collection creation commits
    # several consensus entries.
    for i in range(3):
        res = requests.put(
            f"{peer_api_uris[0]}/collections/ahead_{i}?timeout=60",
            json={"vectors": {"size": 4, "distance": "Dot"}},
            timeout=70,
        )
        assert res.status_code == 200, f"seeding old-cluster commit failed: HTTP {res.status_code} {res.text}"
    old_commit = _get_cluster_info(peer_api_uris[0])["raft_info"]["commit"]

    # Restart the single-voter peer (no --reinit), old first peer still alive at
    # the injected address. Its own consensus can never reach old_commit, so
    # /readyz must not depend on it.
    restart_api_uri, _restart_bootstrap_uri = _start_first_peer(
        removed_peer_dir, "removed_peer_restart.log",
    )
    _wait_for_peer_online(restart_api_uri)

    # The readiness race is only meaningful while this peer's own commit stays
    # behind the old cluster's — assert the setup actually created that gap.
    restart_commit = _get_cluster_info(restart_api_uri)["raft_info"]["commit"]
    assert restart_commit < old_commit, (
        "test setup invalid: single-voter peer's commit "
        f"({restart_commit}) is not behind the old cluster's ({old_commit}); "
        "the /readyz-vs-foreign-commit race was not exercised"
    )


def test_reinit_healthy_cluster_still_works(tmp_path: pathlib.Path):
    """Regression guard: re-initializing a healthy cluster still reconverges.

    pass_to_pass — must hold on BOTH the unfixed and fixed binary. The fix
    changes the INTERMEDIATE membership of a healthy first-peer ``--reinit`` (the
    founding node transiently drops old addresses), so this test asserts only the
    FINAL converged state, which is invariant across the fix: after the first
    peer re-initializes and the other peer re-joins with ``--reinit``, the cluster
    settles into a consistent two-node cluster with a single agreed leader. No
    intermediate cluster-size assertion is made (that value differs pre- vs
    post-fix and is covered by the fail_to_pass cases).
    """
    _peer_api_uris, peer_dirs, _bootstrap_uri = _start_cluster(tmp_path, N_PEERS)

    # Stop all peers, keep their data dirs.
    while _processes:
        _processes.pop().kill()

    # Re-initialize the first peer, then re-join the rest with --reinit.
    restarted_uris = []
    bootstrap_api_uri, new_bootstrap_uri = _start_first_peer(
        peer_dirs[0], "peer_0_restarted.log", reinit=True,
    )
    restarted_uris.append(bootstrap_api_uri)
    _wait_for_peer_online(bootstrap_api_uri)
    _wait_for(_leader_is_defined, bootstrap_api_uri, timeout=CLUSTER_TIMEOUT)

    for i in range(1, len(peer_dirs)):
        restarted_uris.append(
            _start_peer(peer_dirs[i], f"peer_{i}_restarted.log", new_bootstrap_uri, reinit=True)
        )

    # Final converged state (invariant pre/post fix): every peer is online, all
    # agree on one leader, and the cluster is the full two-node size.
    for uri in restarted_uris:
        _wait_for_peer_online(uri)
    leader = _get_leader(bootstrap_api_uri)
    for uri in restarted_uris:
        _wait_for(_check_cluster_size, uri, N_PEERS, timeout=CLUSTER_TIMEOUT)
        _wait_for(_check_leader, uri, leader, timeout=CLUSTER_TIMEOUT)
