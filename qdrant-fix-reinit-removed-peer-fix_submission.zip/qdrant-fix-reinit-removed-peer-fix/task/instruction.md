## Task

we've hit a bad disaster-recovery bug. when we deliberately remove a node from the cluster and later bring it back as a fresh single-node cluster with the re-init recovery flag, reusing its old data directory, it panics on startup every time and never comes up.

sometimes it does boot, but then it never goes ready: `/readyz` just hangs forever, even though the node looks healthy from the outside and is happily leading its own single-node cluster with consensus running. and a brand-new node that joins one of these re-initialized clusters comes up with the wrong cluster membership, still carrying a peer from the old cluster, and that joiner never goes ready either.

this is a recovery path we need to be able to trust. dig into why re-initializing a previously-removed node is broken and make it come back cleanly: able to lead its own cluster and seed fresh peers that join it.
