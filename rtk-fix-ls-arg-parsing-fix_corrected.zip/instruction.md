## Task

We keep getting reports that `rtk ls` reads its arguments differently from plain `ls`, so people type what they'd type for `ls` and get a different answer back. Please make `rtk ls` understand its arguments the way the `ls` it runs does (GNU `ls` on Linux, BSD `ls` on macOS), so the files it lists and the exit status match. Everything below was seen on Linux.

Some of what's been reported:

- `rtk ls -- -al` in a folder holding a file named `-al` lists everything in the folder rather than that one file.
- The value that belongs to an option gets treated as something else. An ignore pattern given after a folder name is tried as a path, and a pattern that starts with a dash gets read as more options, so hidden files can show up.
- Long options are only half supported. `--format long` with a space isn't treated like `--format=long`, and the shortened spellings `ls` accepts don't work. `ls` lets you cut a long option name or its value word down to any prefix that still picks out one choice, so `--form=lon` means `--format=long`. A prefix that fits more than one choice is an error in `ls`, and it should stay one.
- rtk prints file sizes its own way, so an option that only changes how `ls` formats sizes shouldn't change what rtk shows, short or long spelling alike. Right now `--human-readable` makes a 1 KiB file come out as `1B`.
- Ending the line with an option still waiting for its value gives a different exit status from `ls`. Bad input like that, or a value handed to an option that takes none, should fail with the same status `ls` uses.

Only `rtk ls` is affected. Its output format and the other subcommands are fine as they are.
