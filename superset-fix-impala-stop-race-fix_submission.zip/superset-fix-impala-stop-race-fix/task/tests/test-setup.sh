#!/usr/bin/env bash
# test-setup.sh — runs once before the verifier.
#
# The reproduction lives entirely in Superset's pure-python unit-test tier
# (pytest tests/unit_tests/...). It needs NO Postgres/Redis and NO live Impala
# coordinator: every test mocks the impyla cursor / db session. impyla itself is
# baked into the project venv at image build (the tests importorskip it) so the
# Impala-specific cases run instead of skipping.
#
# The complete dependency closure (requirements/development.txt + the impala
# optional driver) is baked into /repo/superset/.venv at image build, and the
# agent phase runs with no network, so nothing new can have been introduced that
# the baked venv does not already carry. The offline re-sync below is therefore a
# best-effort no-op that only picks up an edit to an already-cached pin; it must
# never be able to fail the trial, and there is deliberately no network fallback
# (the verifier sandbox has none). The import smoke-test is the real gate.

set -euo pipefail

REPO=/repo/superset
cd "$REPO"

# Best-effort offline dep refresh against the baked uv cache. Non-fatal: a miss
# here just means the baked venv stands as-is (which is already correct for the
# reproduction). UV_OFFLINE is scoped here (not image-wide) so harbor's own
# `uv tool install` at trial prep is unaffected.
echo "[test-setup] refreshing project venv (offline, best-effort)"
export UV_CACHE_DIR=/opt/uv-cache
if UV_OFFLINE=1 uv pip install --python "$REPO/.venv/bin/python" \
        -r requirements/development.txt 'impyla==0.24.0' > /tmp/setup-deps.log 2>&1; then
    echo "[test-setup] offline dep refresh OK"
else
    echo "[test-setup] offline refresh skipped (baked venv stands); see /tmp/setup-deps.log" >&2
fi

# Smoke-check the import chain used by the reproduction tests. This is the hard
# gate: if the baked venv is genuinely missing something the tests import, fail
# loudly here rather than silently skipping.
#
# Superset's ORM model classes evaluate ``encrypted_field_factory.create(...)``
# in their class bodies, which raises "App not initialized yet" unless an app has
# been built and initialized first. The verifier's own conftest performs that
# bootstrap at import time; the smoke-test mirrors it so it exercises the SAME
# import path the verifier takes (a bare interpreter would fail on app-init, not
# on a missing dependency, and would misreport a healthy baked venv as broken).
echo "[test-setup] smoke-testing imports"
"$REPO/.venv/bin/python" - <<'PY'
import os

# The optional Impala driver is the only thing the baked venv could genuinely be
# missing; check it first and plainly.
import impala.hiveserver2  # noqa: F401  (baked optional driver)

# Build and initialize an app before importing any ORM model module.
from superset.app import SupersetApp
from superset.extensions import appbuilder
from superset.initialization import SupersetAppInitializer

app = SupersetApp(__name__)
app.config.from_object("superset.config")
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite://"
app.config["WTF_CSRF_ENABLED"] = False
app.config["PREVENT_UNSAFE_DB_CONNECTIONS"] = False
app.config["TESTING"] = True
app.config["RATELIMIT_ENABLED"] = False
app.config["CACHE_CONFIG"] = {}
app.config["DATA_CACHE_CONFIG"] = {}
app.config["SERVER_NAME"] = "example.com"
app.config["APPLICATION_ROOT"] = "/"
app.config["PREFERRED_URL_SCHEME"] = "http"
appbuilder.baseviews = []
SupersetAppInitializer(app).init_app()

from superset.db_engine_specs.impala import ImpalaEngineSpec  # noqa: F401,E402
from superset.sql_lab import cancel_query  # noqa: F401,E402
from superset.sql.execution.executor import SQLExecutor  # noqa: F401,E402

print("[test-setup] imports OK")
PY

echo "[test-setup] done"
