# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

"""
Self-contained fixtures for the behavioral verifier.

This verifier is collected from its own directory, outside the repository's
``tests/`` tree, so the repository's ``tests/unit_tests/conftest.py`` and
``tests/unit_tests/sql/execution/conftest.py`` are NOT on the collection path.
The fixtures the behavioral scenarios depend on are therefore transcribed here,
mirroring the ones the repository's own suite uses:

- ``app`` / ``app_context`` — a real application instance over in-memory SQLite,
  built exactly as the repository's unit-test suite builds it (needed so engine
  specs and models resolve configuration through ``current_app``).
- ``db_session`` — patches the database session reference held by the executor
  and the Celery execution module to a mock, so unit scenarios never touch a
  real metadata database.
- ``mock_query`` / ``mock_database`` — lightweight model stand-ins for the
  Celery finalization scenario.
- ``database`` — a real lightweight model instance used by the finished-status
  scenario.
- ``managed_session`` / ``managed_session_factory`` / ``session_engine`` — an
  in-memory session wired as the global session, used by the cross-session
  isolation scenario (which overrides ``session_engine`` with a file-backed one).
"""

from __future__ import annotations

import importlib
import os
from collections.abc import Callable, Iterator
from typing import Any

import pytest
from pytest_mock import MockerFixture
from sqlalchemy import create_engine
from sqlalchemy.engine import Engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.orm.session import Session

from superset.app import SupersetApp
from superset.extensions import appbuilder
from superset.initialization import SupersetAppInitializer


def _build_app() -> SupersetApp:
    """Build and fully initialize a real application over in-memory SQLite.

    Built the same way the repository's unit-test suite builds it: load the
    default config, force the test-safe overrides, then run the full app
    initializer so engine specs, models, and views resolve configuration
    through ``current_app``.
    """
    app = SupersetApp(__name__)

    app.config.from_object("superset.config")
    app.config["SQLALCHEMY_DATABASE_URI"] = (
        os.environ.get("SUPERSET__SQLALCHEMY_DATABASE_URI") or "sqlite://"
    )
    app.config["WTF_CSRF_ENABLED"] = False
    app.config["PREVENT_UNSAFE_DB_CONNECTIONS"] = False
    app.config["TESTING"] = True
    app.config["RATELIMIT_ENABLED"] = False
    app.config["CACHE_CONFIG"] = {}
    app.config["DATA_CACHE_CONFIG"] = {}
    app.config["SERVER_NAME"] = "example.com"
    app.config["APPLICATION_ROOT"] = "/"
    app.config["PREFERRED_URL_SCHEME"] = "http"

    # ``appbuilder`` is a singleton and won't rebuild its routes when the app is
    # constructed more than once; clear the registered views so the initializer
    # can run again cleanly.
    appbuilder.baseviews = []

    SupersetAppInitializer(app).init_app()

    # Reload base views so error handlers are applied to this app instance.
    with app.app_context():
        import superset.views.base

        importlib.reload(superset.views.base)

    return app


# Build and initialize the application AT IMPORT TIME, before importing any
# module that defines ORM model classes. Superset's model classes evaluate
# ``encrypted_field_factory.create(...)`` in their class bodies (e.g.
# ``superset.models.core.Database``), which raises ``App not initialized yet``
# unless ``init_app`` has already run on an app. This verifier is collected from
# its own directory, so the repository's root ``tests/conftest.py`` -- which
# performs exactly this import-time app bootstrap via
# ``tests.integration_tests.test_app`` -- is NOT on the collection path. We
# reproduce that bootstrap here so the model imports below (and the test
# module's own top-level ``superset.*`` imports, which pytest performs after
# this conftest) resolve against an initialized factory.
_APP = _build_app()

from superset.common.db_query_status import (  # noqa: E402
    QueryStatus as QueryStatusEnum,
)
from superset.models.core import Database  # noqa: E402


@pytest.fixture(scope="module")
def app() -> Iterator[SupersetApp]:
    """Yield the import-time-initialized application instance."""
    yield _APP


@pytest.fixture(autouse=True)
def app_context(app: SupersetApp) -> Iterator[None]:
    """Push an application context around every test."""
    with app.app_context():
        yield


@pytest.fixture(autouse=True)
def db_session(mocker: MockerFixture) -> Any:
    """Mock the session reference the executor and Celery module hold.

    Mirrors the repository's own autouse session mock for SQL-execution tests so
    the unit scenarios never reach a real metadata database. The cross-session
    isolation scenario patches the global ``superset.db.session`` separately to a
    live session, which this fixture does not touch.
    """
    mock_session = mocker.MagicMock()
    mocker.patch("superset.sql.execution.executor.db.session", mock_session)
    mocker.patch("superset.sql.execution.celery_task.db.session", mock_session)
    return mock_session


@pytest.fixture
def mock_query() -> Any:
    """A lightweight Query stand-in for the Celery finalization scenario."""
    from unittest.mock import MagicMock

    query = MagicMock()
    query.id = 123
    query.database_id = 1
    query.sql = "SELECT * FROM users"
    query.status = QueryStatusEnum.PENDING
    query.error_message = None
    query.progress = 0
    query.end_time = None
    query.start_running_time = None
    query.executed_sql = None
    query.tmp_table_name = None
    query.catalog = None
    query.schema = "public"
    query.extra = {}
    query.set_extra_json_key = MagicMock()
    query.results_key = None
    query.select_as_cta = False
    query.rows = 0
    query.limit = None
    query.to_dict = MagicMock(return_value={"id": 123})
    query.database = MagicMock()
    query.database.db_engine_spec.extract_errors.return_value = []
    query.database.unique_name = "test_db"
    query.database.cache_timeout = 300
    return query


@pytest.fixture
def mock_database() -> Any:
    """A lightweight Database stand-in for the Celery finalization scenario."""
    from unittest.mock import MagicMock

    database = MagicMock()
    database.id = 1
    database.unique_name = "test_db"
    database.cache_timeout = 300
    database.sqlalchemy_uri = "postgresql://localhost/test"
    database.db_engine_spec = MagicMock()
    database.db_engine_spec.engine = "postgresql"
    database.db_engine_spec.run_multiple_statements_as_one = False
    database.db_engine_spec.allows_sql_comments = True
    database.db_engine_spec.extract_errors = MagicMock(return_value=[])
    database.db_engine_spec.execute_with_cursor = MagicMock()
    database.db_engine_spec.get_cancel_query_id = MagicMock(return_value=None)
    database.db_engine_spec.patch = MagicMock()
    database.db_engine_spec.fetch_data = MagicMock(return_value=[])
    database.db_engine_spec.is_autocommit = MagicMock(return_value=False)
    database.mutate_sql_based_on_config = MagicMock(side_effect=lambda sql, **kw: sql)
    return database


@pytest.fixture
def database() -> Database:
    """A real lightweight Database instance (sqlite backend)."""
    return Database(
        id=1,
        database_name="test_db",
        sqlalchemy_uri="sqlite://",
        allow_dml=False,
    )


@pytest.fixture
def session_engine() -> Engine:
    """The engine behind ``managed_session``; a module may override it."""
    return create_engine("sqlite://")


@pytest.fixture
def managed_session_factory(
    mocker: MockerFixture, session_engine: Engine
) -> Callable[[], Session]:
    """Build an in-memory session and wire it as the global session."""
    engine = session_engine

    def factory() -> Session:
        session_cls = sessionmaker(bind=engine)
        in_memory_session = session_cls()
        # Flask calls ``db.session.remove()``; make it a no-op on this session.
        in_memory_session.remove = lambda: None  # type: ignore[assignment]
        mocker.patch("superset.db.session", in_memory_session)
        return in_memory_session

    return factory


@pytest.fixture
def managed_session(
    managed_session_factory: Callable[[], Session],
) -> Session:
    return managed_session_factory()
