# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

"""
Behavioral verifier for the Impala SQL Lab stop race.

Background. Pressing Stop on a running (or admission-queued) Impala query in SQL
Lab must actually stop the run. A worker polls the live operation; a separate
stop request mutates the same metadata row. When the stop is routed to the
coordinator's HTTP cancel while a worker is still polling, that HTTP cancel
invalidates the operation handle the worker holds, so the run fails with an
"unknown query handle" error instead of ending stopped. The correct behavior
routes a SQL Lab stop to the live cursor (cancel the operation on the next poll)
and keeps the coordinator HTTP cancel for callers that have no polling loop
(chart and MCP cancellation). Two neighbouring hazards ride the same path: a
query that finishes while the stop is being prepared must keep its real terminal
status (not be overwritten with STOPPED), and a stopped cursor must be finalized
as STOPPED rather than mistaken for a finished result.

What this file asserts — and why at this level. The behavior is observed through
pre-existing, stable public entry points, the same seams the project's own
reproduction drives, because no higher-level interface exposes this race in a
runnable unit test without a live Impala coordinator:

  - ``superset.sql_lab.cancel_query`` and
    ``superset.sql.execution.executor.SQLExecutor._cancel_query`` — the two stop
    callers;
  - ``ImpalaEngineSpec.handle_cursor`` — the worker poll loop;
  - ``superset.sql.execution.celery_task`` — the execution finalization path.

The tests couple only to those names plus pre-existing public constants
(``QUERY_CANCEL_KEY`` / ``QUERY_EARLY_CANCEL_KEY`` / ``QUERY_DISPATCHED_KEY`` from
``superset.constants``) and the ``QueryStatus`` enum. They assert the OBSERVABLE
outcome — no coordinator HTTP POST for a SQL Lab stop, the live operation
cancelled, a finished status preserved, a stopped cursor finalized STOPPED — so
any correct fix passes regardless of how it names or structures the internals
(the exact flag-set expression, whether the finished-status set is a module
constant / tuple / inline literal / predicate, whether the read-transaction
reset uses commit / rollback / expire). No internal-only symbol introduced by
the fix is imported or asserted.

Fixtures are self-contained in ``conftest.py`` beside this file, because the
project's test ``conftest.py`` is not on the collection path from here.
"""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, Mock, patch

import pytest
from flask import Flask
from pytest_mock import MockerFixture
from sqlalchemy import create_engine, event, update
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session

from superset.constants import (
    QUERY_CANCEL_KEY,
    QUERY_DISPATCHED_KEY,
    QUERY_EARLY_CANCEL_KEY,
)
from superset.db_engine_specs.impala import ImpalaEngineSpec
from superset.sql.execution import celery_task
from superset.sql.execution.executor import SQLExecutor
from superset.sql_lab import cancel_query
from superset.utils.core import QueryStatus

CANCEL_ID = "0123456789abcdef:fedcba9876543210"


# =============================================================================
# Criterion 1 — a SQL Lab stop of a running query with a published handle is
# carried out on the live cursor, never through the coordinator HTTP cancel.
# =============================================================================
@pytest.mark.parametrize("use_executor", [False, True])
def test_impala_stop_uses_live_cursor(use_executor: bool) -> None:
    """Stopping a running Impala query whose cancel handle is already published
    cancels it through the live cursor only.

    An HTTP cancel would invalidate the handle the worker is still polling and
    fail the run; the stop must instead flag the operation so the next poll
    cancels it. Driven through both stop callers (``cancel_query`` and
    ``SQLExecutor._cancel_query``), then through ``handle_cursor``.
    """
    app = Flask(__name__)
    app.config["DB_POLL_INTERVAL_SECONDS"] = {"impala": 0}
    query = MagicMock(
        id=1,
        extra={QUERY_CANCEL_KEY: CANCEL_ID, QUERY_DISPATCHED_KEY: True},
        status="running",
        progress=0,
    )
    query.database.db_engine_spec = ImpalaEngineSpec
    query.database.url_object.host = "impala.example.com"

    def set_extra_json_key(key: str, value: bool) -> None:
        query.extra[key] = value

    query.set_extra_json_key.side_effect = set_extra_json_key

    with (
        app.app_context(),
        patch("superset.db_engine_specs.impala.db") as db,
        patch("superset.db_engine_specs.impala.requests.post") as post,
    ):
        # Preparing the stop must not itself cancel through the coordinator and
        # must not commit a second time.
        if use_executor:
            assert SQLExecutor._cancel_query(query.database, query)
        else:
            assert cancel_query(query)
        db.session.commit.assert_not_called()

        cursor = Mock()
        cursor.status.return_value = "RUNNING_STATE"
        ImpalaEngineSpec.handle_cursor(cursor, query)

    # The stop was routed to the live cursor: the early-cancel flag is set, no
    # HTTP cancel was issued, and the operation was cancelled and closed.
    assert query.extra[QUERY_EARLY_CANCEL_KEY] is True
    post.assert_not_called()
    cursor.cancel_operation.assert_called_once_with()
    cursor.close_operation.assert_called_once_with()
    cursor.close.assert_called_once_with()


# =============================================================================
# Criterion 2 — a stop that finds the query already finished during stop-prep
# does not cancel and does not overwrite the terminal status.
# =============================================================================
@pytest.mark.parametrize("caller", ["executor", "sql_lab"])
@pytest.mark.parametrize("finished_status", ["success", "failed", "timed_out"])
def test_stop_preserves_finished_status(
    mocker: MockerFixture,
    database: Any,
    finished_status: str,
    caller: str,
) -> None:
    """A query that reached a finished status while the stop was being prepared
    is not cancelled, and its terminal status is kept.

    ``prepare_cancel_query`` is made to observe the query finishing; the stop
    caller must then return False and perform no engine cancellation. Both stop
    callers are exercised — the executor's ``_cancel_query`` and SQL Lab's
    ``cancel_query`` (the stop path the query DAO drives) — because each guards
    the terminal status independently.
    """
    mock_query = MagicMock()
    mock_query.status = QueryStatus.RUNNING
    mock_query.extra = {QUERY_CANCEL_KEY: CANCEL_ID}
    mock_query.database = database

    def finish(query: MagicMock) -> None:
        query.status = QueryStatus(finished_status)

    mocker.patch.object(
        database.db_engine_spec, "has_implicit_cancel", return_value=False
    )
    mocker.patch.object(
        database.db_engine_spec, "prepare_cancel_query", side_effect=finish
    )
    cancel_mock = mocker.patch.object(
        database.db_engine_spec, "cancel_query", return_value=True
    )
    get_engine = mocker.patch.object(database, "get_sqla_engine")

    if caller == "executor":
        result = SQLExecutor._cancel_query(database, mock_query)
    else:
        result = cancel_query(mock_query)

    assert result is False
    assert mock_query.status == QueryStatus(finished_status)
    cancel_mock.assert_not_called()
    get_engine.assert_not_called()


# =============================================================================
# Criterion 3 — a stopped impyla cursor on the Celery path is finalized STOPPED,
# not SUCCESS, including when the stop arrived via the executor cancel path.
# =============================================================================
@pytest.mark.parametrize("stop_intent", ["executor", "early", "status"])
def test_celery_stopped_not_success(
    mocker: MockerFixture,
    mock_query: Any,
    mock_database: Any,
    stop_intent: str,
) -> None:
    """A stop seen while the Celery worker polls an Impala operation finalizes
    the query as STOPPED.

    A cancelled impyla cursor clears ``cursor.description``, which previously
    looked like a finished DML result and was finalized SUCCESS. The stop intent
    is applied three ways — via the executor stop caller, via the early-cancel
    flag, and via a committed STOPPED status — and all must end STOPPED.
    """
    impyla = pytest.importorskip("impala.hiveserver2")

    mock_query.sql = "SELECT 1"
    mock_query.database = mock_database
    mock_database.db_engine_spec = ImpalaEngineSpec
    mock_query.extra = {QUERY_CANCEL_KEY: CANCEL_ID}
    mock_query.set_extra_json_key.side_effect = lambda key, value: (
        mock_query.extra.update({key: value})
    )
    cursor = impyla.HiveServer2Cursor(MagicMock())
    operation = MagicMock(has_result_set=True)

    def execute_async(sql: str) -> None:
        cursor._last_operation = operation
        cursor._last_operation_active = True

    def stop_before_poll() -> str:
        if stop_intent == "executor":
            assert SQLExecutor._cancel_query(mock_database, mock_query)
        elif stop_intent == "early":
            mock_query.extra[QUERY_EARLY_CANCEL_KEY] = True
        else:
            mock_query.status = QueryStatus.STOPPED
        return "RUNNING_STATE"

    operation.get_status.side_effect = stop_before_poll
    mocker.patch.object(cursor, "execute_async", side_effect=execute_async)
    connection = mock_database.get_raw_connection.return_value.__enter__.return_value
    connection.cursor.return_value = cursor
    mocker.patch.object(ImpalaEngineSpec, "get_cancel_query_id", return_value=None)
    mocker.patch(
        "superset.sql.execution.celery_task._get_query", return_value=mock_query
    )
    finalize = mocker.spy(celery_task, "_finalize_successful_query")
    store = mocker.patch("superset.sql.execution.celery_task._store_results_in_backend")
    mocker.patch("superset.sql.execution.celery_task.results_backend", MagicMock())
    post = mocker.patch("superset.db_engine_specs.impala.requests.post")

    payload = celery_task._execute_sql_statements(123, "SELECT 1", None)

    operation.cancel.assert_called_once_with()
    operation.close.assert_called_once_with()
    assert cursor.description is None
    assert payload is not None
    assert payload["status"] == QueryStatus.STOPPED
    assert mock_query.status == QueryStatus.STOPPED
    connection.commit.assert_not_called()
    finalize.assert_not_called()
    store.assert_not_called()
    post.assert_not_called()


# =============================================================================
# Criterion 4 — handle_cursor observes a STOPPED committed by another session
# between polls under a repeatable-read snapshot (it ends its read transaction
# before refreshing).
# =============================================================================
@pytest.fixture
def iso_session_engine(tmp_path: Path) -> Iterator[Engine]:
    # A short busy timeout turns a leaked write lock into a fast failure.
    engine = create_engine(
        f"sqlite:///{tmp_path / 'metadata.db'}", connect_args={"timeout": 1}
    )
    yield engine
    engine.dispose()


@pytest.fixture
def iso_snapshot_engine(iso_session_engine: Engine) -> Iterator[Engine]:
    """An engine whose transactions keep the snapshot of their first read until
    they end, standing in for a repeatable-read worker: WAL plus explicit BEGIN.
    """
    engine = create_engine(iso_session_engine.url, connect_args={"timeout": 1})

    @event.listens_for(engine, "connect")
    def connect(dbapi_connection: Any, _: Any) -> None:
        # Let SQLAlchemy own transaction boundaries so SELECTs run inside them.
        dbapi_connection.isolation_level = None
        dbapi_connection.execute("PRAGMA journal_mode=WAL")

    @event.listens_for(engine, "begin")
    def begin(connection: Any) -> None:
        connection.exec_driver_sql("BEGIN")

    yield engine
    engine.dispose()


@pytest.fixture
def iso_query_id(iso_session_engine: Engine) -> int:
    from superset.models.core import Database
    from superset.models.sql_lab import Query

    Query.metadata.create_all(iso_session_engine)  # pylint: disable=no-member
    database = Database(database_name="my_database", sqlalchemy_uri="sqlite://")
    query = Query(
        client_id="foo",
        database=database,
        sql="select * from bar",
        status=QueryStatus.RUNNING,
        extra_json=f'{{"{QUERY_CANCEL_KEY}": "{CANCEL_ID}"}}',
    )
    with Session(iso_session_engine) as seed:
        seed.add_all([database, query])
        seed.commit()
        return query.id


def _worker_commits(engine: Engine, query_id: int, **values: Any) -> None:
    """Commit a write from another connection, as the SQL Lab worker would."""
    from superset.models.sql_lab import Query

    with Session(engine) as worker:
        worker.execute(update(Query).where(Query.id == query_id).values(**values))
        worker.commit()


def test_handle_cursor_sees_committed_stop(
    mocker: MockerFixture,
    iso_session_engine: Engine,
    iso_snapshot_engine: Engine,
    iso_query_id: int,
) -> None:
    """A poll sees a STOPPED committed by another request after the worker's
    snapshot was taken, and cancels the live operation.

    The worker's open transaction holds its earlier snapshot, so unless the poll
    loop ends that transaction before refreshing, the committed STOPPED is never
    observed and the operation is never cancelled.
    """
    from superset.models.sql_lab import Query

    app = Flask(__name__)
    app.config["DB_POLL_INTERVAL_SECONDS"] = {"impala": 0}
    worker = Session(iso_snapshot_engine)
    mocker.patch("superset.db.session", worker)
    query = worker.query(Query).filter_by(id=iso_query_id).one()

    # Another request commits the stop after the worker has taken its snapshot.
    _worker_commits(iso_session_engine, iso_query_id, status=QueryStatus.STOPPED)
    worker.refresh(query)
    assert query.status == QueryStatus.RUNNING

    cursor = Mock()
    cursor.status.side_effect = ["RUNNING_STATE", "FINISHED_STATE"]
    cursor.get_log.return_value = ""
    with app.app_context():
        ImpalaEngineSpec.handle_cursor(cursor, query)

    cursor.cancel_operation.assert_called_once_with()
    cursor.close_operation.assert_called_once_with()
    worker.close()
