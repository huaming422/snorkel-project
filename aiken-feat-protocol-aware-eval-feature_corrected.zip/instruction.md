## Task

`uplc` can be told which Plutus language version a script targets, but not which Cardano protocol era it runs under. The ledger changes how some builtins behave and how they are costed from one era to the next, so a script evaluated with the right language version can still come back with a different execution budget than it really has on chain.

We need to evaluate a program under an explicit protocol major version and get that era's semantics and costs, both for a single program and for phase-two transaction evaluation, for all three Plutus languages. Add this next to what is there: the language-only entry points keep their signatures and their results. Everything stays inside the `uplc` crate, and the crate and its existing tests still have to build and pass.

The ledger facts you will need: Chang is protocol major version 9 and Van Rossem is 11, and PlutusV3 exists only from Chang on. Before Chang, `multiplyInteger`'s CPU cost grows with the sum of the two argument sizes rather than their product. From Van Rossem on, a string's memory size is its UTF-8 length in bytes divided by four and rounded up (an empty string is 0), instead of its character count. The PlutusV3 cost vector under Van Rossem is longer than today's: it keeps every existing entry where it is and appends entries for builtins this repo cannot run yet.

## User stories / requirements

- Evaluating under an explicit protocol major version picks that era's builtin costing, so the same program and cost model can cost differently before and after Chang. A protocol whose rules match today's gives exactly the result of evaluating by language version alone.
- Under Van Rossem, a PlutusV3 cost vector longer than today's still costs every builtin whose entries it carries, while a vector that stops short of a builtin's entries leaves it at the unavailable cost, so running it fails.
- From Van Rossem on, a string is sized by its UTF-8 bytes in four-byte words instead of by its characters, so text with multi-byte characters costs differently than it did before.
