## Task

We've had reports from semidefinite program users that cvxpy's symmetric matrix factorization breaks on some low rank inputs. Full rank, well conditioned matrices still work; the failures involve rank deficient positive and negative semidefinite matrices.

One valid PSD example, `[[1, 1, 0], [1, 1, 0], [0, 0, 1]]`, can raise "Cholesky factorization failed". On other low rank inputs the routine returns a factor, but multiplying it back out does not recover the input.

Please fix the factorization for low rank PSD and NSD inputs while keeping genuinely indefinite matrices rejected.
