#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier runs (set -euo pipefail inherited).
#
# cvxpy is installed editable (`pip install -e .`) into /opt/project-venv at
# image-build time, so Python source edits are picked up
# live — no reinstall needed. The C++ extension (_cvxcore) is prebuilt and the
# current utility code is Python, so those edits need no recompile.
#
# Everything the verifier needs (cvxpy + its solver/dependency closure + pytest)
# is baked into /opt/project-venv at build time, so this step is offline-first:
# a cache miss must fail fast instead of reaching for a registry.
cd /repo/cvxpy

# Offline switches: make any accidental resolution fail fast rather than hang
# against the cut network (the offline fold sources this with --network none).
export UV_OFFLINE=1
export PIP_NO_INDEX=1

# The project interpreter that carries cvxpy + pytest. The verifier's
# verify.toml points its pytest command at this same interpreter.
PROJECT_PY=/opt/project-venv/bin/python

# Sanity: confirm the project interpreter can import cvxpy and pytest offline.
# If this fails the image bake was incomplete — surface it loudly here rather
# than as a confusing collection error inside pytest.
if "${PROJECT_PY}" -c "import cvxpy, pytest" > /tmp/test-setup-import.log 2>&1; then
    echo "[offline-first] cvxpy + pytest import OK from project venv"
else
    echo "[test-setup] project venv import failed:" >&2
    cat /tmp/test-setup-import.log >&2
    exit 1
fi
