## Task

when someone merges a pull request, the details view for that PR flips to merged right away, but the sidebar badge stays stuck on open and the thread won't settle for up to about a minute before it sorts itself out on its own. it's timing-dependent and only turns up while someone's actually looking at a PR that just merged, so the two views sit disagreeing for a while. when you're watching a PR you just merged, the badge and the thread should catch up promptly instead of waiting out that lag. can you dig in and fix it?
