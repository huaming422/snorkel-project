// @ts-nocheck
//
// Behavioural verifier for the JSONC comment-loss fix (rulesync PR #2854).
//
// Everything here is exercised through the gateway's pre-existing, stable
// public surface — `applySharedConfigPatch`, `parseSharedConfig`,
// `stringifySharedConfig` — and through the four reader classes' public
// constructors / `validate()` methods. None of these signatures change in the
// fix. We deliberately do NOT import any newly-added serialize function or
// internal helper (`applyJsoncObjectEdits`, `removeJsoncProperty`,
// `detectJsoncFormattingOptions`, …) or budget constant: those are one valid
// decomposition, not a contract (the task allows many alternative valid fixes).
// The verifier observes the returned file TEXT and what it parses back to, so
// any edit-preserving implementation — one function or fifteen helpers, English
// names or not, any safe set of fallback triggers — passes.
//
// How each criterion separates a correct fix from the unfixed baseline:
//   - The unfixed baseline's `applySharedConfigPatch` ends in
//     `JSON.stringify(doc, null, 2)` for every JSONC file, so comments, blank
//     lines, key order and indentation are rebuilt from the parsed value, which
//     carries none of them. An identical-content rewrite still reformats the file.
//   - A correct fix writes a JSONC document back as edits against the existing
//     text, leaving untouched spans — comments included — byte-identical, and an
//     identical-content regenerate byte-for-byte unchanged.
//   Criteria 1–4 and 8 below fail on the unfixed baseline and pass on a correct
//   fix. Criteria 5–7, 9, 10 are correctness / liveness / scope guards that must
//   hold on BOTH trees (they guard against crashes, over-broadening to
//   YAML/TOML, and hangs).
//
// All file keys (".vscode/mcp.json", "opencode.json", "kilo.json",
// ".config/goose/config.yaml"), feature names ("mcp"/"permissions"/"rules"),
// owned key names ("servers"/"mcp"/"tools"/"permission"/"instructions"/
// "extensions") and formats ("jsonc"/"yaml") are repo-owned stable facts read
// off `SHARED_CONFIG_OWNERSHIP` in the base tree — never solution choices.
//
// Fallback-routing note: `.vscode/mcp.json` declares invalidRootPolicy:"error"
// + jsoncParseErrors:"error", so an unparsable/non-object file there THROWS
// rather than whole-doc-rewriting. The whole-document-fallback criteria (5, 6)
// therefore use `opencode.json` / `kilo.json`, which declare no error policies.

import { describe, it, expect } from "vitest";

import {
  applySharedConfigPatch,
  parseSharedConfig,
  stringifySharedConfig,
} from "./shared-config-gateway.js";
import { CopilotMcp } from "../mcp/copilot-mcp.js";
import { KiloMcp } from "../mcp/kilo-mcp.js";
import { OpencodeMcp } from "../mcp/opencode-mcp.js";
import { OpencodePermissions } from "../permissions/opencode-permissions.js";

// A tolerant "does this reader accept this content?" probe. It constructs the
// reader (validate:false so the base ToolMcp ctor does not auto-validate) and
// calls validate() — wrapping BOTH in one try/catch. A base reader throws from
// validate()'s bare JSON.parse on a comment (Kilo/Opencode have no try/catch
// there); a reader whose constructor parses strictly can throw on genuinely
// malformed input. Either throw, or a {success:false}, reads as `false`; only a
// clean construct + validate().success === true reads as `true`. This keeps the
// malformed-input guard from erroring the test when a strict ctor rejects it.
function validatesContent(
  Cls: new (p: {
    relativeDirPath: string;
    relativeFilePath: string;
    fileContent: string;
    validate: boolean;
  }) => { validate: () => { success: boolean } },
  relativeFilePath: string,
  fileContent: string,
): boolean {
  try {
    const reader = new Cls({
      relativeDirPath: ".",
      relativeFilePath,
      fileContent,
      validate: false,
    });
    return reader.validate().success === true;
  } catch {
    return false;
  }
}

// ---------------------------------------------------------------------------
// Criterion 1 (fail_to_pass): comments survive a value-changing regenerate.
// ---------------------------------------------------------------------------
describe("comments survive a regenerate that changes a value", () => {
  it("keeps the top-of-file comment on .vscode/mcp.json and still writes the new servers", () => {
    const existingContent = [
      "// For more info, visit https://aka.ms/vscode-add-mcp",
      "{",
      '  "servers": {',
      '    "old": { "type": "stdio", "command": "old-bin" }',
      "  }",
      "}",
      "",
    ].join("\n");

    const result = applySharedConfigPatch({
      fileKey: ".vscode/mcp.json",
      feature: "mcp",
      existingContent,
      patch: { servers: { fresh: { type: "stdio", command: "fresh-bin" } } },
    });

    // The hand-written comment is still there.
    expect(result).toContain("// For more info, visit https://aka.ms/vscode-add-mcp");
    // And the merged document is what the file now states.
    expect(parseSharedConfig({ format: "jsonc", fileContent: result })).toEqual({
      servers: { fresh: { type: "stdio", command: "fresh-bin" } },
    });
  });

  it("also preserves comments on a second JSONC file key (opencode.json), defeating a single-file special-case", () => {
    // A solution that only special-cases .vscode/mcp.json would pass the case
    // above but strip this one. opencode.json is a distinct jsonc-format managed
    // file (feature `mcp` owns `mcp`/`tools`); the fix must preserve its comments
    // too, so comment-preservation is file-general, not file-specific.
    const existingContent = [
      "{",
      "  // the project's MCP servers",
      '  "mcp": {',
      '    "old": { "type": "local", "command": ["old-bin"] }',
      "  }",
      "}",
      "",
    ].join("\n");

    const result = applySharedConfigPatch({
      fileKey: "opencode.json",
      feature: "mcp",
      existingContent,
      patch: { mcp: { fresh: { type: "local", command: ["fresh-bin"] } } },
    });

    expect(result).toContain("// the project's MCP servers");
    expect(parseSharedConfig({ format: "jsonc", fileContent: result }).mcp).toEqual({
      fresh: { type: "local", command: ["fresh-bin"] },
    });
  });
});

// ---------------------------------------------------------------------------
// Criterion 2 (fail_to_pass): a no-op regenerate returns byte-identical text.
// ---------------------------------------------------------------------------
describe("a regenerate that computes identical content is byte-for-byte unchanged", () => {
  it("returns existingContent exactly when the patch yields the same servers", () => {
    const existingContent = [
      "// hand-written header",
      "{",
      "",
      '  // the primary server',
      '  "servers": {',
      '    "primary": { "type": "stdio", "command": "serve" }',
      "  }",
      "}",
      "",
    ].join("\n");

    const result = applySharedConfigPatch({
      fileKey: ".vscode/mcp.json",
      feature: "mcp",
      existingContent,
      // Same value the file already states → nothing to change.
      patch: { servers: { primary: { type: "stdio", command: "serve" } } },
    });

    expect(result).toBe(existingContent);
  });
});

// ---------------------------------------------------------------------------
// Criterion 3 (fail_to_pass): a one-key change deep in a nested object leaves
// sibling keys and their comments untouched.
// ---------------------------------------------------------------------------
describe("a nested one-key change leaves sibling keys and their comments intact", () => {
  it("rewrites only the changed server, preserving the untouched sibling's comment and bytes", () => {
    const existingContent = [
      "{",
      '  "servers": {',
      "    // alpha is the untouched sibling",
      '    "alpha": { "type": "stdio", "command": "alpha-bin" },',
      "    // beta will change",
      '    "beta": { "type": "stdio", "command": "beta-old" }',
      "  }",
      "}",
      "",
    ].join("\n");

    const result = applySharedConfigPatch({
      fileKey: ".vscode/mcp.json",
      feature: "mcp",
      existingContent,
      patch: {
        servers: {
          alpha: { type: "stdio", command: "alpha-bin" }, // unchanged
          beta: { type: "stdio", command: "beta-new" }, // changed
        },
      },
    });

    // Both comments survive.
    expect(result).toContain("// alpha is the untouched sibling");
    expect(result).toContain("// beta will change");
    // The untouched sibling's exact source line is preserved byte-for-byte.
    expect(result).toContain('    "alpha": { "type": "stdio", "command": "alpha-bin" },');
    // The change landed.
    const parsed = parseSharedConfig({ format: "jsonc", fileContent: result });
    expect(parsed.servers.alpha).toEqual({ type: "stdio", command: "alpha-bin" });
    expect(parsed.servers.beta).toEqual({ type: "stdio", command: "beta-new" });
  });
});

// ---------------------------------------------------------------------------
// Criterion 4 (fail_to_pass): inserted/changed regions match the file's own
// indentation (space width / tabs) and line ending (LF/CRLF).
// ---------------------------------------------------------------------------
describe("edits match the file's own indentation and line ending", () => {
  it("preserves 4-space indentation on untouched lines and does not reflow them to 2 spaces", () => {
    // 4-space indent unit. `command` sits at depth 3 → 12 spaces.
    const existingContent = [
      "{",
      '    "servers": {',
      '        "alpha": {',
      '            "type": "stdio",',
      '            "command": "alpha-bin"',
      "        },",
      '        "beta": {',
      '            "type": "stdio",',
      '            "command": "beta-old"',
      "        }",
      "    }",
      "}",
      "",
    ].join("\n");

    const result = applySharedConfigPatch({
      fileKey: ".vscode/mcp.json",
      feature: "mcp",
      existingContent,
      patch: {
        servers: {
          alpha: { type: "stdio", command: "alpha-bin" }, // unchanged
          beta: { type: "stdio", command: "beta-new" }, // changed
        },
      },
    });

    // The untouched alpha block keeps its 4-space-derived indentation (12 spaces
    // before `command`). Newline-anchored so the assertion targets the line's
    // actual indentation, not a substring of a deeper-indented line. Base reflows
    // the whole file to 2-space indent (6 spaces here), so this exact line start
    // is absent on base.
    expect(result).toContain('\n            "command": "alpha-bin"');
    expect(parseSharedConfig({ format: "jsonc", fileContent: result }).servers.beta.command).toBe(
      "beta-new",
    );
  });

  it("preserves tab indentation on untouched lines", () => {
    const existingContent = [
      "{",
      '\t"servers": {',
      '\t\t"alpha": {',
      '\t\t\t"type": "stdio",',
      '\t\t\t"command": "alpha-bin"',
      "\t\t},",
      '\t\t"beta": {',
      '\t\t\t"type": "stdio",',
      '\t\t\t"command": "beta-old"',
      "\t\t}",
      "\t}",
      "}",
      "",
    ].join("\n");

    const result = applySharedConfigPatch({
      fileKey: ".vscode/mcp.json",
      feature: "mcp",
      existingContent,
      patch: {
        servers: {
          alpha: { type: "stdio", command: "alpha-bin" },
          beta: { type: "stdio", command: "beta-new" },
        },
      },
    });

    // Untouched alpha line keeps its tab indentation (base would use spaces).
    expect(result).toContain('\n\t\t\t"command": "alpha-bin"');
    expect(parseSharedConfig({ format: "jsonc", fileContent: result }).servers.beta.command).toBe(
      "beta-new",
    );
  });

  it("keeps CRLF line endings when a value changes", () => {
    const existingContent =
      [
        "// crlf file",
        "{",
        '  "servers": {',
        '    "primary": { "type": "stdio", "command": "old-bin" }',
        "  }",
        "}",
      ].join("\r\n") + "\r\n";

    const result = applySharedConfigPatch({
      fileKey: ".vscode/mcp.json",
      feature: "mcp",
      existingContent,
      patch: { servers: { primary: { type: "stdio", command: "new-bin" } } },
    });

    // Untouched structure keeps its CRLF endings; base emits LF-only output.
    expect(result).toContain("\r\n");
    expect(result).toContain("// crlf file");
    expect(parseSharedConfig({ format: "jsonc", fileContent: result }).servers.primary.command).toBe(
      "new-bin",
    );
  });
});

// ---------------------------------------------------------------------------
// Criterion 5 (fail_to_pass): unparsable / non-object-root / empty JSONC falls
// back to the whole-document writer (no crash, correct merged content).
// Uses opencode.json (no error policies) so these inputs route to fallback
// rather than throwing.
// ---------------------------------------------------------------------------
describe("unparsable / non-object / empty JSONC falls back to the whole-document writer", () => {
  const patch = { mcp: { srv: { type: "local", command: ["run"] } } };

  // The whole-document output of a KNOWN-empty document is unambiguous: parsing
  // "" yields {}, merge applies the patch's owned keys, and stringify is
  // deterministic. We compare against that only for the empty case, where the
  // merged document is certain. For non-object / unparsable inputs the merged
  // base is uncertain in detail (tolerant parse of garbage), so we assert the
  // robust observable contract instead: no throw, and the file ends up stating
  // exactly the merged `mcp`. Base, which edit-rewrites, would also produce
  // whole-doc here (it never had an edit path), so these are liveness/scope
  // guards that must simply hold on both trees without crashing.
  const wholeDoc = (document) => stringifySharedConfig({ format: "jsonc", document });

  it("empty content → whole-document output of the merged document", () => {
    const result = applySharedConfigPatch({
      fileKey: "opencode.json",
      feature: "mcp",
      existingContent: "   \n  ",
      patch,
    });
    expect(result).toBe(wholeDoc({ mcp: patch.mcp }));
  });

  it("non-object root (array) → no throw, file states the merged mcp", () => {
    const result = applySharedConfigPatch({
      fileKey: "opencode.json",
      feature: "mcp",
      existingContent: "[1, 2, 3]",
      patch,
    });
    const parsed = parseSharedConfig({ format: "jsonc", fileContent: result });
    expect(parsed.mcp).toEqual(patch.mcp);
    // The array content is gone — it was not merged into an object document.
    expect(Array.isArray(parsed)).toBe(false);
  });

  it("unparsable content → no throw, file states the merged mcp", () => {
    const result = applySharedConfigPatch({
      fileKey: "opencode.json",
      feature: "mcp",
      existingContent: '{ "mcp": { "oops" ',
      patch,
    });
    const parsed = parseSharedConfig({ format: "jsonc", fileContent: result });
    expect(parsed.mcp).toEqual(patch.mcp);
  });
});

// ---------------------------------------------------------------------------
// Criterion 6 (fail_to_pass): a prototype-pollution key, or a key stated twice,
// routes to the whole-document rewrite and drops the pollution key.
// ---------------------------------------------------------------------------
describe("pollution-key / duplicate-key documents fall back and drop pollution keys", () => {
  it("drops a root-level __proto__ and writes the whole document", () => {
    const existingContent = [
      "{",
      '  "mcp": { "existing": { "type": "local", "command": ["old"] } },',
      '  "__proto__": { "polluted": true }',
      "}",
      "",
    ].join("\n");

    const result = applySharedConfigPatch({
      fileKey: "opencode.json",
      feature: "mcp",
      existingContent,
      patch: { mcp: { fresh: { type: "local", command: ["new"] } } },
    });

    expect(result).not.toContain("__proto__");
    expect(result).not.toContain("polluted");
    const parsed = parseSharedConfig({ format: "jsonc", fileContent: result });
    expect(parsed.mcp).toEqual({ fresh: { type: "local", command: ["new"] } });
    expect(Object.prototype.hasOwnProperty.call(parsed, "polluted")).toBe(false);
  });

  it("resolves a duplicated (unmanaged) key last-wins via the whole-document writer", () => {
    // `theme` is an unmanaged key (the mcp feature owns only mcp/tools), stated
    // twice. An edit-based write against the first occurrence would leave a dead
    // second copy; the whole-document fallback re-serializes the parsed document,
    // so exactly one `theme` survives with the last-wins value. Base, which
    // always whole-rewrites, behaves the same here — this is a crash/scope guard.
    const existingContent = [
      "{",
      '  "mcp": { "existing": { "type": "local", "command": ["old"] } },',
      '  "theme": "light",',
      '  "theme": "dark"',
      "}",
      "",
    ].join("\n");

    const result = applySharedConfigPatch({
      fileKey: "opencode.json",
      feature: "mcp",
      existingContent,
      patch: { mcp: { fresh: { type: "local", command: ["new"] } } },
    });

    // No crash; the surviving document is valid JSONC with the managed mcp
    // replaced and a single, last-wins unmanaged `theme`.
    const parsed = parseSharedConfig({ format: "jsonc", fileContent: result });
    expect(parsed.mcp).toEqual({ fresh: { type: "local", command: ["new"] } });
    expect(parsed.theme).toBe("dark");
    // Exactly one occurrence of the key survived re-serialization.
    expect(result.match(/"theme"/g) ?? []).toHaveLength(1);
  });
});

// ---------------------------------------------------------------------------
// Criterion 7 (fail_to_pass): a huge / heavily-changing document does not take
// the writer into quadratic time — it completes quickly and returns correct
// content (guards against an edit path with no size cutoff that hangs generate).
// ---------------------------------------------------------------------------
describe("a huge, heavily-changing JSONC document completes quickly", () => {
  it("writes ~2000 fully-changed servers well under the timeout, with correct content", () => {
    const COUNT = 2000;
    const base: Record<string, unknown> = {};
    const next: Record<string, unknown> = {};
    for (let i = 0; i < COUNT; i += 1) {
      base[`srv${i}`] = { type: "local", command: [`old-${i}`] };
      next[`srv${i}`] = { type: "local", command: [`new-${i}`] };
    }
    const existingContent = JSON.stringify({ mcp: base }, null, 2);

    const started = Date.now();
    const result = applySharedConfigPatch({
      fileKey: "opencode.json",
      feature: "mcp",
      existingContent,
      patch: { mcp: next },
    });
    const elapsedMs = Date.now() - started;

    // Anti-hang guard: a correct fix resolves this in milliseconds via the size
    // cutoff; any non-pathological implementation is far under this bound.
    expect(elapsedMs).toBeLessThan(120_000);

    const parsed = parseSharedConfig({ format: "jsonc", fileContent: result });
    expect(Object.keys(parsed.mcp)).toHaveLength(COUNT);
    expect(parsed.mcp.srv0.command).toEqual(["new-0"]);
    expect(parsed.mcp[`srv${COUNT - 1}`].command).toEqual([`new-${COUNT - 1}`]);
  });
});

// ---------------------------------------------------------------------------
// Criterion 8 (fail_to_pass): the readers of the now-comment-bearing files
// accept comments (parse as JSONC), while genuinely malformed content still
// errors. CopilotMcp parses in its constructor; the other three in validate().
// ---------------------------------------------------------------------------
describe("readers accept JSONC comments but still reject malformed content", () => {
  const commentedCopilot = [
    "// For more info, visit https://aka.ms/vscode-add-mcp",
    "{",
    '  "servers": { "s": { "type": "stdio", "command": "c" } }',
    "}",
  ].join("\n");

  it("CopilotMcp constructs from commented content (base JSON.parse would throw)", () => {
    expect(
      () =>
        new CopilotMcp({
          relativeDirPath: ".vscode",
          relativeFilePath: "mcp.json",
          fileContent: commentedCopilot,
          validate: false,
        }),
    ).not.toThrow();
  });

  it("CopilotMcp still throws on genuinely malformed content", () => {
    expect(
      () =>
        new CopilotMcp({
          relativeDirPath: ".vscode",
          relativeFilePath: "mcp.json",
          fileContent: '{ "servers": { "s": ',
          validate: false,
        }),
    ).toThrow();
  });

  it("KiloMcp accepts commented content and rejects malformed", () => {
    expect(validatesContent(KiloMcp, "kilo.jsonc", '{ /* kilo config */ "mcp": {} }')).toBe(true);
    expect(validatesContent(KiloMcp, "kilo.jsonc", "{ not valid ")).toBe(false);
  });

  it("OpencodeMcp accepts commented content and rejects malformed", () => {
    expect(validatesContent(OpencodeMcp, "opencode.jsonc", '{ /* opencode */ "mcp": {} }')).toBe(
      true,
    );
    expect(validatesContent(OpencodeMcp, "opencode.jsonc", '{ "mcp": ')).toBe(false);
  });

  it("OpencodePermissions accepts commented content and rejects malformed", () => {
    expect(
      validatesContent(
        OpencodePermissions,
        "opencode.jsonc",
        '{ // perms\n "permission": { "bash": "ask" } }',
      ),
    ).toBe(true);
    expect(validatesContent(OpencodePermissions, "opencode.jsonc", '{ "permission": ')).toBe(false);
  });
});

// ---------------------------------------------------------------------------
// Criterion 9 (pass_to_pass): non-JSONC formats are unchanged — still whole-doc
// re-serialized, so scope was not over-broadened to YAML/TOML. Holds on BOTH
// trees (YAML never preserved comments by design).
// ---------------------------------------------------------------------------
describe("non-JSONC formats stay whole-document re-serialized", () => {
  it("a YAML file is re-serialized whole (its comment is not preserved)", () => {
    const existingContent = ["# my goose config", "extensions:", "  old:", "    type: stdio", ""].join(
      "\n",
    );

    const result = applySharedConfigPatch({
      fileKey: ".config/goose/config.yaml",
      feature: "mcp",
      existingContent,
      patch: { extensions: { fresh: { type: "stdio" } } },
    });

    // Whole-document YAML output of the merged doc — no comment retention.
    expect(result).toBe(
      stringifySharedConfig({ format: "yaml", document: { extensions: { fresh: { type: "stdio" } } } }),
    );
    expect(result).not.toContain("# my goose config");
  });
});

// ---------------------------------------------------------------------------
// Criterion 10 (pass_to_pass): pre-existing shared-config / reader behaviour is
// not regressed. These hold on BOTH trees via the stable interface.
// ---------------------------------------------------------------------------
describe("pre-existing behaviour is not regressed", () => {
  it("parseSharedConfig still treats empty/whitespace as an empty document in every format", () => {
    expect(parseSharedConfig({ format: "jsonc", fileContent: "" })).toEqual({});
    expect(parseSharedConfig({ format: "json", fileContent: "  \n" })).toEqual({});
    expect(parseSharedConfig({ format: "yaml", fileContent: "" })).toEqual({});
  });

  it("a plain (comment-free) JSON merge still produces the merged document", () => {
    const existingContent = '{\n  "servers": {\n    "a": { "type": "stdio", "command": "a" }\n  }\n}\n';
    const result = applySharedConfigPatch({
      fileKey: ".vscode/mcp.json",
      feature: "mcp",
      existingContent,
      patch: { servers: { b: { type: "stdio", command: "b" } } },
    });
    expect(parseSharedConfig({ format: "jsonc", fileContent: result })).toEqual({
      servers: { b: { type: "stdio", command: "b" } },
    });
  });

  it("a comment-free reader file still validates", () => {
    expect(validatesContent(OpencodeMcp, "opencode.json", '{ "mcp": {} }')).toBe(true);
  });
});
