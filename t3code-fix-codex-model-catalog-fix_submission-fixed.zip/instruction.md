## Task

The Ultrafast option on GPT-6.1 Sol keeps vanishing from the Codex picker on accounts that have it.
Refreshing the provider restores it, it lasts a few minutes, then it disappears again.
While it's missing, threads set to Ultrafast quietly run on Standard or Fast instead.
We see it more when other Codex clients run on the same machine, like the plain `codex` CLI.

A few things about Codex matter here, and none of them show up anywhere in this repo.
- The backend builds the model catalog for whatever client identity the app-server reports.
- Ultrafast is only offered to app clients like T3 Code, never to the plain CLI identity `codex_cli_rs`.
- A new `codex app-server` reports `codex_cli_rs` unless `CODEX_INTERNAL_ORIGINATOR_OVERRIDE` is set in the environment it was spawned with.
- All Codex clients on a machine share one catalog cache at `$CODEX_HOME/models_cache.json`, stamped with a `fetched_at` time.
- `model/list` answers from that cache while it's under five minutes old.
- A freshly started app-server refreshes that cache online shortly after launch.

Entitled accounts should keep seeing Ultrafast, and threads should stay on the tier they were set to.
This has to hold for every Codex app-server T3 Code starts.
If someone already put `CODEX_INTERNAL_ORIGINATOR_OVERRIDE` in the environment T3 Code passes to Codex, their value wins.
Don't hardcode Ultrafast or slip extra tiers into the published list.
If the backend stops offering a tier to an account, the picker should stop showing it too.
