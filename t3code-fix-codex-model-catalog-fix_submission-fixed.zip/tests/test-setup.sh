#!/usr/bin/env bash
# test-setup.sh - environment bootstrap for the verifier.
#
# t3code is a pnpm workspace monorepo. Workspace packages export their
# `src/*.ts` directly (the `import` export condition points at source), so
# there is no build step. A `.ts` change under apps/server is picked up as soon
# as the file is saved, and the verifier imports it straight from source.
# Nothing gets rebuilt here.
#
# The suite runs through vite-plus (`vp test run`), not plain vitest. The repo
# patches `@effect/vitest` to import from `vite-plus/test`, and node_modules/.bin
# only has `vp`, with no `vitest` binary. That is why verify.py calls
# `node_modules/.bin/vp test run ...` directly.
#
# The test runner sources this file (it does not exec it), so any env vars set
# here stay visible to the verifier subprocess.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/t3code}"
export REPO_DIR
cd "$REPO_DIR"

# verify.py only needs the standard library from the tooling venv
# (/opt/tooling/venv, Python 3.12), so there is nothing to install here.

# Sanity check: the vite-plus runner has to resolve from the workspace root.
# If it doesn't, node_modules is broken, so stop here with a clear message
# rather than a confusing "vp: not found" later in the verifier.
if ! [ -x node_modules/.bin/vp ]; then
    echo "test-setup.sh: vite-plus (vp) binary missing from node_modules/.bin/. " \
         "The image build is corrupt." >&2
    exit 1
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR vp=$(node_modules/.bin/vp --version 2>/dev/null || echo unknown)"
