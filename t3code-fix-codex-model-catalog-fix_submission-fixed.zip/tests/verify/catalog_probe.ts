import * as NodeServices from "@effect/platform-node/NodeServices";
import { assert, it } from "@effect/vitest";
import { CodexSettings, ProviderSessionId, ThreadId } from "@t3tools/contracts";
import * as ProviderAdapter from "@t3tools/provider-core/server/ProviderAdapter";
import * as ProviderEventLoggers from "@t3tools/provider-core/server/ProviderEventLoggers";
import * as DateTime from "effect/DateTime";
import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as Path from "effect/Path";
import * as PlatformError from "effect/PlatformError";
import { ChildProcess, ChildProcessSpawner } from "effect/process";
import * as Schema from "effect/Schema";

import * as CodexAdapterV2 from "../orchestration-v2/Adapters/CodexAdapterV2.ts";
import { checkCodexProviderStatus } from "./CodexProvider.ts";

/**
 * Stand-in for Codex 0.162's app-server catalog behavior:
 * - `model/list` answers from `CODEX_HOME/models_cache.json` while it is under
 *   five minutes old. A missing or older cache is fetched again on the spot.
 * - A startup refresh runs before `initialize`, so it uses the client identity
 *   set at spawn (the override env var, else the plain CLI's `codex_cli_rs`).
 * - The backend grants Ultrafast only to entitled accounts on app clients.
 */
const FAKE_CODEX_APP_SERVER = String.raw`#!/usr/bin/env node
const fs = require("node:fs");
const path = require("node:path");
const readline = require("node:readline");
const cachePath = path.join(process.env.CODEX_HOME, "models_cache.json");
const originator = process.env.CODEX_INTERNAL_ORIGINATOR_OVERRIDE ?? "codex_cli_rs";
const ultrafast = process.env.FAKE_ULTRAFAST_ENTITLED === "1" && originator !== "codex_cli_rs";
const model = (tiers) => ({
  id: "gpt-6.1-sol", model: "gpt-6.1-sol", displayName: "GPT-6.1 Sol", description: "",
  hidden: false, isDefault: true, defaultReasoningEffort: "high",
  supportedReasoningEfforts: [{ reasoningEffort: "high", description: "" }],
  serviceTiers: tiers.map((id) => ({ id, name: id, description: "" })),
});
const fetchCatalog = () => {
  const catalog = { fetched_at: new Date().toISOString(), models: [model(ultrafast ? ["priority", "ultrafast"] : ["priority"])] };
  fs.writeFileSync(cachePath, JSON.stringify(catalog));
  return catalog;
};
const freshCache = () => {
  try {
    const catalog = JSON.parse(fs.readFileSync(cachePath, "utf8"));
    return Date.now() - Date.parse(catalog.fetched_at) < 5 * 60 * 1000 ? catalog : undefined;
  } catch {
    return undefined;
  }
};
setTimeout(fetchCatalog, 300);
const write = (message) => process.stdout.write(JSON.stringify(message) + "\n");
readline.createInterface({ input: process.stdin }).on("line", (line) => {
  const { id, method } = JSON.parse(line);
  if (id === undefined) return;
  if (method === "initialize") {
    write({ id, result: { userAgent: "codex/0.162.0", codexHome: process.env.CODEX_HOME, platformFamily: "unix", platformOs: "macos" } });
  } else if (method === "account/read") {
    write({ id, result: { account: { type: "chatgpt", email: "test@example.com", planType: "promax" }, requiresOpenaiAuth: false } });
  } else if (method === "skills/list") {
    write({ id, result: { data: [] } });
  } else if (method === "model/list") {
    write({ id, result: { data: (freshCache() ?? fetchCatalog()).models, nextCursor: null } });
  } else {
    write({ id, error: { code: -32601, message: "unsupported" } });
  }
});
`;

const decodeCodexSettings = Schema.decodeSync(CodexSettings);

/**
 * Drive the published catalog end-to-end: spawn the fake app-server, seed a
 * fresh (1-minute-old) catalog into the shared cache before the probe, run the
 * probe, and return the `gpt-6.1-sol` service-tier option ids.
 *
 * @param entitled whether the account is entitled to the fast tier
 * @param seedTiers the tiers already sitting in the shared cache when the probe
 *   starts (a write left by some other client on the machine)
 * @param clientIdentityOverride when set, passed explicitly so the test can
 *   check that a caller-supplied value takes precedence over the default
 */
const solServiceTiers = Effect.fn("solServiceTiers")(function* (options: {
  readonly entitled: boolean;
  readonly seedTiers: ReadonlyArray<string>;
  readonly clientIdentityOverride?: string;
}) {
  const fs = yield* FileSystem.FileSystem;
  const path = yield* Path.Path;
  const dir = yield* fs.makeTempDirectoryScoped({ prefix: "t3-codex-catalog-" });
  const binaryPath = path.join(dir, "codex");
  yield* fs.writeFileString(binaryPath, FAKE_CODEX_APP_SERVER);
  yield* fs.chmod(binaryPath, 0o755);
  // A fresh cache already written by another client on the machine; the probe
  // sees it first and must not simply publish it.
  yield* fs.writeFileString(
    path.join(dir, "models_cache.json"),
    JSON.stringify({
      fetched_at: DateTime.formatIso(DateTime.subtract(yield* DateTime.now, { minutes: 1 })),
      models: [
        {
          id: "gpt-6.1-sol",
          model: "gpt-6.1-sol",
          displayName: "GPT-6.1 Sol",
          description: "",
          hidden: false,
          isDefault: true,
          defaultReasoningEffort: "high",
          supportedReasoningEfforts: [{ reasoningEffort: "high", description: "" }],
          serviceTiers: options.seedTiers.map((id) => ({ id, name: id, description: "" })),
        },
      ],
    }),
  );

  const { CODEX_INTERNAL_ORIGINATOR_OVERRIDE: _ambient, ...inherited } = process.env;
  const environment = {
    ...inherited,
    FAKE_ULTRAFAST_ENTITLED: options.entitled ? "1" : "0",
    ...(options.clientIdentityOverride === undefined
      ? {}
      : { CODEX_INTERNAL_ORIGINATOR_OVERRIDE: options.clientIdentityOverride }),
  };
  const provider = yield* checkCodexProviderStatus(
    decodeCodexSettings({ binaryPath, homePath: dir }),
    undefined,
    environment,
  );
  const serviceTier = provider.models
    .find((model) => model.slug === "gpt-6.1-sol")
    ?.capabilities?.optionDescriptors?.find((descriptor) => descriptor.id === "serviceTier");
  return serviceTier?.type === "select" ? serviceTier.options.map((option) => option.id) : [];
});

it.layer(NodeServices.layer, { excludeTestServices: true })("Codex catalog discovery", (it) => {
  it.effect("keeps Ultrafast when another Codex client wrote the shared catalog cache", () =>
    Effect.gen(function* () {
      assert.deepStrictEqual(
        yield* solServiceTiers({ entitled: true, seedTiers: ["priority"] }),
        ["default", "priority", "ultrafast"],
      );
    }).pipe(Effect.scoped),
  );

  it.effect("drops Ultrafast once the account is no longer entitled to it", () =>
    Effect.gen(function* () {
      assert.deepStrictEqual(
        yield* solServiceTiers({ entitled: false, seedTiers: ["priority", "ultrafast"] }),
        ["default", "priority"],
      );
    }).pipe(Effect.scoped),
  );

  it.effect("lets a caller-supplied client identity take precedence over the default", () =>
    Effect.gen(function* () {
      // Entitled account, but the caller forces the plain-CLI identity, which the
      // backend does not grant Ultrafast to; a stale entitled catalog is already
      // cached. Honoring the caller's value yields the non-Ultrafast catalog.
      assert.deepStrictEqual(
        yield* solServiceTiers({
          entitled: true,
          seedTiers: ["priority", "ultrafast"],
          clientIdentityOverride: "codex_cli_rs",
        }),
        ["default", "priority"],
      );
    }).pipe(Effect.scoped),
  );

  it.effect("sessions spawn the app-server under a non-CLI client identity", () =>
    Effect.gen(function* () {
      // Threads that open a session spawn their own app-server through
      // `layerAppServerClientFactory`, a separate spawn site from the probe. If
      // that site starts the app-server under the plain-CLI identity, the
      // session's own startup fetch re-poisons the shared catalog cache and the
      // tier flickers again. Capture the environment the session hands to the
      // spawner and assert the originator it asks for is NOT the plain CLI's.
      let spawnedEnv: NodeJS.ProcessEnv | undefined;
      const spawner = ChildProcessSpawner.make((command) => {
        if (ChildProcess.isStandardCommand(command)) {
          spawnedEnv = command.options.env;
        }
        // Fail the spawn immediately: the env is already captured and there is no
        // real `codex` binary to launch.
        return Effect.fail(
          PlatformError.systemError({ _tag: "NotFound", module: "ChildProcess", method: "spawn" }),
        );
      });

      const factory = yield* CodexAdapterV2.CodexAppServerClientFactory.pipe(
        Effect.provide(CodexAdapterV2.layerAppServerClientFactory),
        Effect.provideService(ChildProcessSpawner.ChildProcessSpawner, spawner),
        Effect.provideService(
          ProviderEventLoggers.ProviderEventLoggers,
          ProviderEventLoggers.NoOpProviderEventLoggers,
        ),
      );

      yield* factory
        .open({
          instanceId: CodexAdapterV2.CODEX_DEFAULT_INSTANCE_ID,
          threadId: ThreadId.make("thread-session-originator"),
          providerSessionId: ProviderSessionId.make("provider-session-originator"),
          runtimePolicy: ProviderAdapter.ProviderAdapterV2RuntimePolicy.make({
            runtimeMode: "full-access",
            interactionMode: "default",
            cwd: "/workspace",
          }),
          settings: decodeCodexSettings({}),
          environment: {},
        })
        .pipe(Effect.scoped, Effect.exit);

      const originator = spawnedEnv?.CODEX_INTERNAL_ORIGINATOR_OVERRIDE;
      assert.isDefined(
        originator,
        "the session spawn must name a client originator so its startup catalog fetch is tailored to this client",
      );
      assert.notStrictEqual(
        originator,
        "codex_cli_rs",
        "the session spawn must not start the app-server under the plain-CLI identity, which the backend does not grant the fast tier",
      );
    }).pipe(Effect.scoped),
  );
});
