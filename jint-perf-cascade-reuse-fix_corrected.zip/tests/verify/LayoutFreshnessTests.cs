using Jint.Browser;
using Jint.Browser.Runtime;

namespace Jint.Tests.Browser.AdminForm;

// Each test reads a box through the page's JavaScript, edits the page in the same script turn, and
// reads the box again. The second read has to show the edit.
public class LayoutFreshnessTests
{
    private const int Row = 16;

    // A button hidden by a class is read, the root element is given a width in ch, and the button is
    // read again. Both reads give a height of 0 and the page reports no errors.
    [Test]
    public async Task AHiddenButtonStaysHiddenAfterTheRootGetsAWidthInCh()
    {
        await using var browser = new global::Jint.Browser.Browser();
        var page = await browser.NewPageAsync();
        await page.SetContentAsync("<style>.gone { display: none }</style><button class='gone' id='target'>Save</button>");

        (await page.EvaluateAsync<string>(
            """
            (() => {
              const target = document.getElementById('target');
              const before = target.getBoundingClientRect().height;
              document.documentElement.style.width = '20ch';
              return before + ',' + target.getBoundingClientRect().height;
            })()
            """)).Should().Be("0,0");
        page.Errors.Should().BeEmpty();
    }

    // Each edit hides the button. The read before it gives the button's 16px row and the read after
    // it gives 0.
    [TestCase("target.classList.add('gone')")]
    [TestCase("target.style.display = 'none'")]
    [TestCase("target.hidden = true")]
    [TestCase("document.body.setAttribute('data-hide', '')")]
    [TestCase("document.querySelector('style').textContent = '.target { display: none }'")]
    [TestCase("document.styleSheets[0].insertRule('.target { display: none }', 0)")]
    [TestCase("document.styleSheets[0].cssRules[0].selectorText = '.target'")]
    [TestCase("document.getElementById('trigger').addEventListener('focus', () => target.style.display = 'none'); document.getElementById('trigger').focus()")]
    [TestCase("document.getElementById('trigger').checked = true")]
    [TestCase("document.getElementById('hidden-parent').appendChild(target)")]
    public async Task EverySameTurnEditIsVisibleToTheNextQuery(string mutation)
    {
        await using var browser = new global::Jint.Browser.Browser();
        var page = await browser.NewPageAsync();
        await page.SetContentAsync(
            """
            <style>
              .unmatched { display: none }
              .gone, [data-hide] .target, input:focus ~ .target, input:checked ~ .target { display: none }
            </style>
            <input id="trigger" type="checkbox"><button id="target" class="target">Save</button>
            <div id="hidden-parent" hidden></div>
            """);

        (await page.EvaluateAsync<string>(
            $$"""
            (() => {
              const target = document.getElementById('target');
              const before = target.getBoundingClientRect().height;
              {{mutation}};
              return before + ',' + target.getBoundingClientRect().height;
            })()
            """)).Should().Be("16,0");
        page.Errors.Should().BeEmpty();
    }

    // Deleting the rule that hides the button gives it a row on the next read, and narrowing the
    // viewport under a media rule takes one row away.
    [Test]
    public async Task RuleDeletionAndViewportChangesAreVisibleToTheNextQuery()
    {
        await using var browser = new global::Jint.Browser.Browser();
        var page = await browser.NewPageAsync();
        await page.SetContentAsync(
            """
            <style>
              button { display: none }
              @media (max-width: 600px) { button { display: none } }
            </style>
            <button id="target">Save</button>
            """);

        (await page.EvaluateAsync<string>(
            """
            (() => {
              const target = document.getElementById('target');
              const before = target.getBoundingClientRect().height;
              document.styleSheets[0].deleteRule(0);
              return before + ',' + target.getBoundingClientRect().height;
            })()
            """)).Should().Be("0,16");

        (await page.RunOnLoopAsync(engine =>
        {
            var runtime = PageRuntime.Find(engine)!;
            var before = runtime.Layout.Current().Count;
            runtime.SetViewport(new Viewport(400, 800));
            return before - runtime.Layout.Current().Count;
        })).Should().Be(1);
        page.Errors.Should().BeEmpty();
    }

    // The same kind of edit for a list item that carries no attributes and is reached only through
    // its ancestors: the read before gives its 16px row and the read after gives 0.
    [TestCase("document.querySelector('nav').className = 'closed'")]
    [TestCase("document.styleSheets[0].insertRule('nav li { display: none }', 0)")]
    [TestCase("document.querySelector('style').textContent += ' nav > ul > li { display: none }'")]
    public async Task AnEditHidesAListItemThatHasNoAttributes(string mutation)
    {
        await using var browser = new global::Jint.Browser.Browser();
        var page = await browser.NewPageAsync();
        await page.SetContentAsync("<style>.closed li { display: none }</style><nav><ul><li>Home</li></ul></nav>");

        (await page.EvaluateAsync<string>(
            $$"""
            (() => {
              const item = document.querySelector('nav li');
              const before = item.getBoundingClientRect().height;
              {{mutation}};
              return before + ',' + item.getBoundingClientRect().height;
            })()
            """)).Should().Be("16,0");
        page.Errors.Should().BeEmpty();
    }
}
