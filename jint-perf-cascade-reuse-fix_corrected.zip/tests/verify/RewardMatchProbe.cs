#nullable enable

using AngleSharp;
using AngleSharp.Css;
using AngleSharp.Css.Dom;
using AngleSharp.Dom;
using AngleSharp.Text;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Threading;

namespace Jint.Tests.Browser.Reward;

/// <summary>
/// Delegates every <see cref="ICssDefaultStyleSheetProvider"/> member to a wrapped
/// provider and hands out a wrapped default sheet whose rules increment a shared
/// counter inside TryMatch, or inside Match when a caller matches through the rule's
/// selector directly.
/// </summary>
public sealed class MatchCountingDefaults : ICssDefaultStyleSheetProvider
{
    private readonly ICssDefaultStyleSheetProvider _inner;
    private readonly Counter _counter = new();

    private ICssStyleSheet? _cachedInner;
    private ICssStyleSheet? _cachedWrapper;

    public MatchCountingDefaults(ICssDefaultStyleSheetProvider inner)
    {
        _inner = inner ?? throw new ArgumentNullException(nameof(inner));
    }

    /// <summary>
    /// Total number of match passes (TryMatch on a rule, or Match on its selector) across
    /// every rule handed out by this provider.
    /// </summary>
    public long Matches => _counter.Value;

    /// <summary>
    /// Resets the match counter to 0.
    /// </summary>
    public void Reset() => _counter.Reset();

    public ICssStyleSheet Default
    {
        get
        {
            var current = _inner.Default;

            // Rebuild the wrapper only if the underlying sheet instance changed.
            if (_cachedWrapper is null || !ReferenceEquals(_cachedInner, current))
            {
                _cachedInner = current;
                _cachedWrapper = new CountingStyleSheet(current, _counter);
            }

            return _cachedWrapper;
        }
    }

    public void SetDefault(ICssStyleSheet? sheet) => _inner.SetDefault(sheet);

    public void SetDefault(String source) => _inner.SetDefault(source);

    public void AppendDefault(String source) => _inner.AppendDefault(source);

    /// <summary>
    /// Holds the shared match count by reference.
    /// </summary>
    private sealed class Counter
    {
        private long _value;

        public long Value => Interlocked.Read(ref _value);

        public void Increment() => Interlocked.Increment(ref _value);

        public void Reset() => Interlocked.Exchange(ref _value, 0);
    }

    /// <summary>
    /// Wraps an <see cref="ICssRule"/>; style rules are wrapped so TryMatch is counted.
    /// Every other rule kind (grouping rules such as media/supports, and leaf rules) is
    /// returned unchanged so the consumer's own type switch keeps seeing the concrete
    /// runtime type it expects. Match passes against top-level style rules are what the
    /// test compares, and they are counted on both sides of the comparison, so any passes
    /// nested inside an unwrapped grouping rule are simply excluded symmetrically.
    /// </summary>
    private static ICssRule Wrap(ICssRule rule, Counter counter)
    {
        if (rule is ICssStyleRule styleRule)
        {
            return new CountingStyleRule(styleRule, counter);
        }

        return rule;
    }

    /// <summary>
    /// Delegates every sheet member to the wrapped sheet, except Rules which returns a
    /// wrapping rule list.
    /// </summary>
    private sealed class CountingStyleSheet : ICssStyleSheet
    {
        private readonly ICssStyleSheet _inner;
        private readonly Counter _counter;
        private ICssRuleList? _rules;

        public CountingStyleSheet(ICssStyleSheet inner, Counter counter)
        {
            _inner = inner;
            _counter = counter;
        }

        // IStyleSheet
        public String Type => _inner.Type;

        public String Href => _inner.Href;

        public IElement OwnerNode => _inner.OwnerNode;

        public String Title => _inner.Title;

        public IMediaList Media => _inner.Media;

        public Boolean IsDisabled
        {
            get => _inner.IsDisabled;
            set => _inner.IsDisabled = value;
        }

        public IBrowsingContext Context => _inner.Context;

        public TextSource Source => _inner.Source;

        public void SetOwner(IElement element) => _inner.SetOwner(element);

        public String LocateNamespace(String prefix) => _inner.LocateNamespace(prefix);

        // IStyleFormattable
        public void ToCss(TextWriter writer, IStyleFormatter formatter) => _inner.ToCss(writer, formatter);

        // ICssStyleSheet
        public ICssRule OwnerRule => _inner.OwnerRule;

        public ICssRuleList Rules => _rules ??= new CountingRuleList(_inner.Rules, _counter);

        public ICssStyleSheet Parent => _inner.Parent;

        public Int32 Insert(String rule, Int32 index) => _inner.Insert(rule, index);

        public void RemoveAt(Int32 index) => _inner.RemoveAt(index);

        public void SetOwner(ICssRule rule) => _inner.SetOwner(rule);

        public void SetParent(ICssStyleSheet parent) => _inner.SetParent(parent);
    }

    /// <summary>
    /// Delegates list members to the wrapped rule list and wraps each rule it returns.
    /// </summary>
    private sealed class CountingRuleList : ICssRuleList
    {
        private readonly ICssRuleList _inner;
        private readonly Counter _counter;

        public CountingRuleList(ICssRuleList inner, Counter counter)
        {
            _inner = inner;
            _counter = counter;
        }

        public ICssRule this[Int32 index] => Wrap(_inner[index], _counter);

        public Int32 Length => _inner.Length;

        public IEnumerator<ICssRule> GetEnumerator()
        {
            foreach (var rule in _inner)
            {
                yield return Wrap(rule, _counter);
            }
        }

        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
    }

    /// <summary>
    /// Delegates every rule member to the wrapped style rule; increments the match
    /// counter before delegating TryMatch, hands out a counting selector, and wraps the
    /// nested Rules list. TryMatch delegates to the wrapped rule, which matches through
    /// its own selector, so one pass is never counted twice.
    /// </summary>
    private sealed class CountingStyleRule : ICssStyleRule
    {
        private readonly ICssStyleRule _inner;
        private readonly Counter _counter;
        private ICssRuleList? _rules;
        private ISelector? _selector;

        public CountingStyleRule(ICssStyleRule inner, Counter counter)
        {
            _inner = inner;
            _counter = counter;
        }

        // ICssRule
        public CssRuleType Type => _inner.Type;

        public String CssText
        {
            get => _inner.CssText;
            set => _inner.CssText = value;
        }

        public ICssRule Parent => _inner.Parent;

        public ICssStyleSheet Owner => _inner.Owner;

        public void SetParent(ICssRule rule) => _inner.SetParent(rule);

        public void SetOwner(ICssStyleSheet sheet) => _inner.SetOwner(sheet);

        // IStyleFormattable
        public void ToCss(TextWriter writer, IStyleFormatter formatter) => _inner.ToCss(writer, formatter);

        // ICssStyleRule
        public String SelectorText
        {
            get => _inner.SelectorText;
            set => _inner.SelectorText = value;
        }

        public ICssStyleDeclaration Style => _inner.Style;

        public ISelector Selector => _selector ??= new CountingSelector(_inner.Selector, _counter);

        public Boolean TryMatch(IElement element, IElement? scope, out Priority specificity)
        {
            _counter.Increment();
            return _inner.TryMatch(element, scope, out specificity);
        }

        public ICssRuleList Rules => _rules ??= new CountingRuleList(_inner.Rules, _counter);
    }

    /// <summary>
    /// Delegates every selector member to the wrapped selector; increments the match
    /// counter before delegating Match.
    /// </summary>
    private sealed class CountingSelector : ISelector
    {
        private readonly ISelector _inner;
        private readonly Counter _counter;

        public CountingSelector(ISelector inner, Counter counter)
        {
            _inner = inner;
            _counter = counter;
        }

        public String Text => _inner.Text;

        public Priority Specificity => _inner.Specificity;

        public void Accept(ISelectorVisitor visitor) => _inner.Accept(visitor);

        public Boolean Match(IElement element, IElement? scope)
        {
            _counter.Increment();
            return _inner.Match(element, scope);
        }
    }
}
