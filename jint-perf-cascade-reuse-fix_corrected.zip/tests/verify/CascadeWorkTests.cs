using AngleSharp;
using AngleSharp.Css;
using AngleSharp.Css.Dom;
using AngleSharp.Css.RenderTree;
using AngleSharp.Dom;
using Jint.Browser.Accessibility;
using Jint.Browser.Layout;

namespace Jint.Tests.Browser.AdminForm;

// Counts taken while FlatLayout.Of lays out a page: how many times the default stylesheet is read,
// and how many selector match passes run on that sheet's rules and on the page's own rules. No
// clock is read.
public class CascadeWorkTests
{
    // Lays out a page whose button sits three divs deep (six rendered elements), hides the button,
    // and lays it out again. The first layout reads the default sheet at most three times, the
    // second at most three more, and the second drops the button's row.
    [Test]
    public async Task EachQueryReadsTheDefaultSheetAFewTimesRatherThanOncePerElement()
    {
        using var seed = BrowsingContext.New(Configuration.Default.WithCss());
        var provider = new CountingProvider(seed.GetService<ICssDefaultStyleSheetProvider>()!);
        using var context = BrowsingContext.New(Configuration.Default.WithCss().With(provider));
        using var document = await context.OpenAsync(response => response.Content(
            "<div><div><div><button>Save</button></div></div></div>"));
        var visibility = new ElementVisibility(useComputedStyle: true);
        provider.Reads = 0;

        FlatLayout.Of(document, visibility, 1280, 720, 0).Count.Should().Be(6);
        var firstQueryReads = provider.Reads;
        firstQueryReads.Should().BeLessThanOrEqualTo(3, "one layout reads the default sheet at most three times");

        document.QuerySelector("button")!.SetAttribute("hidden", "");
        FlatLayout.Of(document, visibility, 1280, 720, 0).Count.Should().Be(5);
        (provider.Reads - firstQueryReads).Should().BeLessThanOrEqualTo(3,
            "the next layout reads it at most three more times");
    }

    // Lays out a page 40 levels deep once and counts the match passes on the default sheet's rules
    // and, separately, on the rules of the page's own style element. Then counts both again while
    // each element's declarations are asked for one element at a time. For each kind of sheet the
    // layout's count must be under a quarter of the one-at-a-time count. The page's root declares a
    // custom property whose value is the word inherit, the innermost button takes display: inherit,
    // and a plain span beside it is hidden by a child rule; the layout has a row for the html and
    // body elements, the 40 divs and the button, and none for the span.
    [Test]
    public async Task AWholeDocumentQueryMatchesFarFewerSelectorsThanResolvingEachElementSeparately()
    {
        using var seed = BrowsingContext.New(Configuration.Default.WithCss());
        var defaults = new MatchCountingDefaults(seed.GetService<ICssDefaultStyleSheetProvider>()!);
        var pageSheets = new MatchCountingPageSheets(seed.GetService<IStylingService>()!);
        using var context = BrowsingContext.New(
            Configuration.Default.WithCss().With(defaults).WithOnly<IStylingService>(pageSheets));
        const int depth = 40;
        using var document = await context.OpenAsync(response => response.Content(
            "<style>:root{--colour:red;--token:inherit} div{color:var(--colour)} .leaf{display:inherit}"
            + " div > span{display:none}</style>"
            + string.Concat(Enumerable.Repeat("<div>", depth))
            + "<button class=\"leaf\">Save</button><span>Draft</span>"
            + string.Concat(Enumerable.Repeat("</div>", depth))));
        var visibility = new ElementVisibility(useComputedStyle: true);
        var styles = document.DefaultView!.GetStyleCollection(new DefaultRenderDevice());
        var elements = document.All.OfType<IElement>().ToArray();

        defaults.Reset();
        pageSheets.Reset();
        var rows = FlatLayout.Of(document, visibility, 1280, 720, 0);
        var defaultQueryWork = defaults.Matches;
        var pageQueryWork = pageSheets.Matches;

        defaults.Reset();
        pageSheets.Reset();
        foreach (var element in elements)
        {
            styles.ComputeDeclarations(element);
        }

        var defaultPerElementWork = defaults.Matches;
        var pagePerElementWork = pageSheets.Matches;

        rows.Count.Should().Be(depth + 3, "html, body, the divs and the button each get a row and the span none");
        defaultQueryWork.Should().BeGreaterThan(0, "the layout runs match passes on the default sheet");
        pageQueryWork.Should().BeGreaterThan(0, "the layout runs match passes on the page's own rules");
        defaultPerElementWork.Should().BeGreaterThan(defaultQueryWork * 4,
            "on the default sheet, one layout of the page stays under a quarter of the one-at-a-time count");
        pagePerElementWork.Should().BeGreaterThan(pageQueryWork * 4,
            "on the page's own rules, one layout of the page stays under a quarter of the one-at-a-time count");
    }

    private sealed class CountingProvider(ICssDefaultStyleSheetProvider inner) : ICssDefaultStyleSheetProvider
    {
        internal int Reads { get; set; }

        public ICssStyleSheet Default
        {
            get
            {
                Reads++;
                return inner.Default;
            }
        }

        public void SetDefault(ICssStyleSheet? sheet) => inner.SetDefault(sheet);
        public void SetDefault(string source) => inner.SetDefault(source);
        public void AppendDefault(string source) => inner.AppendDefault(source);
    }
}
