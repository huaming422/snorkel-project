#!/usr/bin/env bash
# Checks the changes since the recorded base checkpoint: product code stays inside the Jint.Browser
# project and no package reference is added. cwd is the repo. Test projects, the repo's perf project,
# docs and solution files are ignored. Prints a PASS or FAIL line per check and exits nonzero on any
# FAIL.
set -uo pipefail

REPO="${REPO_DIR:-$PWD}"
if [ ! -d "$REPO/.git" ] && [ -d "/repo/${REPO_NAME:-jint}/.git" ]; then
    REPO="/repo/${REPO_NAME:-jint}"
fi
cd "$REPO" || { echo "INFRA: repo dir missing" >&2; exit 2; }

BASE_REF_FILE=/var/lib/devcontainer_base_ref
if [ ! -f "$BASE_REF_FILE" ]; then
    echo "INFRA: base checkpoint file absent at $BASE_REF_FILE" >&2
    exit 2
fi
BASE_REF="$(cat "$BASE_REF_FILE")"
if ! git cat-file -e "${BASE_REF}^{commit}" 2>/dev/null; then
    echo "INFRA: base checkpoint $BASE_REF not resolvable" >&2
    exit 2
fi

# Files changed, added or removed since the checkpoint, including the working tree. Drop anything
# ephemeral: build output and the temporary test folder verify.sh creates (it removes the folder on
# exit, but the two scripts could overlap if their order ever changes).
RAW="$(
    { git diff --name-only "$BASE_REF" -- 2>/dev/null; git ls-files --others --exclude-standard 2>/dev/null; } \
        | sed '/^$/d' \
        | grep -Ev '(^|/)(bin|obj)/' \
        | grep -Ev '(^|/)_adminformtests/' \
        | sort -u
)"

status=0

# 1. Product code must stay within the browser subsystem's own project. Test projects, the
#    perf project, docs and solution files are ignored.
OUT_OF_SCOPE=""
while IFS= read -r f; do
    [ -z "$f" ] && continue
    case "$f" in
        Jint.Browser/*) : ;;                              # the browser project itself
        *Tests*/*|*.Tests/*|Jint.Benchmark/*) : ;;        # test and perf projects
        docs/*|*.md|*.sln|*.slnx|*.DotSettings|.github/*) : ;;  # docs / solution / tooling metadata
        *) OUT_OF_SCOPE="${OUT_OF_SCOPE}${f}"$'\n' ;;
    esac
done <<< "$RAW"
OUT_OF_SCOPE="$(printf '%s' "$OUT_OF_SCOPE" | sed '/^$/d')"
if [ -n "$OUT_OF_SCOPE" ]; then
    echo "FAIL: product changes reach outside the browser subsystem:"
    printf '  %s\n' $OUT_OF_SCOPE
    status=1
else
    echo "PASS: all product changes confined to the browser subsystem"
fi

# 2. No new third-party dependency anywhere (central package management keeps versions in one props
#    file; a project could also carry a bare reference). A line that introduces a package coordinate
#    not present at the checkpoint is a violation.
dep_added=0
while IFS= read -r f; do
    [ -z "$f" ] && continue
    case "$f" in
        *Directory.Packages.props|*.csproj|*Directory.Build.props)
            added="$(git diff "$BASE_REF" -- "$f" 2>/dev/null \
                | grep -E '^\+' | grep -v '^\+\+\+' \
                | grep -Ei 'PackageReference|PackageVersion|PackageDownload' || true)"
            if [ -n "$added" ]; then
                echo "FAIL: new package dependency introduced in $f:"
                printf '  %s\n' "$added"
                dep_added=1
            fi
            ;;
    esac
done <<< "$RAW"
if [ "$dep_added" -eq 0 ]; then
    echo "PASS: no new package dependency"
else
    status=1
fi

exit "$status"
