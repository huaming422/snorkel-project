#!/usr/bin/env bash
# Copies the NUnit files next to this script into a temporary folder inside the repo's browser test
# project, builds it and runs only those tests on net10.0. The tests read counts and values through
# the page's JavaScript, the automation client and AngleSharp's interfaces; none reads a clock.
# Exits with dotnet test's status, so 0 means every test passed.
set -uo pipefail

REPO="${REPO_DIR:-$PWD}"
if [ ! -d "$REPO/Jint.Tests.Browser" ]; then
    REPO="/repo/${REPO_NAME:-jint}"
fi
PROJECT_DIR="$REPO/Jint.Tests.Browser"
PROJECT="$PROJECT_DIR/Jint.Tests.Browser.csproj"

if [ ! -f "$PROJECT" ]; then
    echo "INFRA: browser test project not found at $PROJECT" >&2
    exit 2
fi

# The NUnit source files live next to this script (*.cs). They are copied into the test project
# only for this run and removed on the way out.
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if ! ls "$HERE"/*.cs >/dev/null 2>&1; then
    echo "INFRA: no test source files found next to the verifier at $HERE" >&2
    exit 2
fi

# Copy the tests into a fresh folder so nothing in the project tree is overwritten, and remove it
# on the way out whether the run passes, fails or is interrupted.
DROP="$PROJECT_DIR/_adminformtests"
cleanup() { rm -rf "$DROP"; }
trap cleanup EXIT
rm -rf "$DROP"
mkdir -p "$DROP"
cp "$HERE"/*.cs "$DROP"/ || { echo "INFRA: could not stage test files" >&2; exit 2; }

export DOTNET_CLI_TELEMETRY_OPTOUT=1
export DOTNET_NOLOGO=1
export DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1

# net10.0 only (the project multi-targets). The filter runs only the copied tests, so the suite's
# tests that need the internet never run.
cd "$REPO" || { echo "INFRA: repo dir missing" >&2; exit 2; }

echo "Running the admin form tests from $DROP ..."
dotnet test "$PROJECT" \
    --framework net10.0 \
    --no-restore \
    --nologo \
    --filter "FullyQualifiedName~Jint.Tests.Browser.AdminForm" \
    -- NUnit.DefaultTimeout=120000
status=$?

echo "dotnet test exit status: $status"
exit "$status"
