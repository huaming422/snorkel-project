using Jint.Browser;
using Jint.DevTools;
using Jint.Tests.Browser.Navigation;
using PuppeteerSharp;
using PageContextOptions = Jint.Browser.BrowserContextOptions;

namespace Jint.Tests.Browser.AdminForm;

// Opens the admin settings page from a loopback origin through a Puppeteer client connected to
// the browser's DevTools endpoint, and clicks Save with an actionability-checked click. Expects one
// POST to the same URL, the "Settings saved" marker on the page that comes back, and no page
// errors. The client attaches to the running endpoint, so no browser is downloaded and nothing
// leaves the container.
[NonParallelizable]
public class SaveClickTests
{
    private static readonly TimeSpan Bound = TimeSpan.FromSeconds(120);

    [Test]
    public async Task AnActionabilityCheckedSaveClickSubmitsOnePostAndReadsTheSuccessMarker()
    {
        using var origin = new LoopbackServer();
        origin.Map(
            "/admin-settings",
            request => LoopbackResponse.Html(AdminSettingsDocument.Create(saved: request.Method == "POST")));

        await using var pages = new global::Jint.Browser.Browser();
        var context = await pages.NewContextAsync(new PageContextOptions { UrlFilter = origin.Owns });

        await using var protocol = new DevToolsServer();
        await protocol.AddBrowser(pages);
        await protocol.StartAsync();

        await using var client = await Puppeteer.ConnectAsync(new ConnectOptions
        {
            BrowserWSEndpoint = protocol.BrowserWebSocketUrl,
        }).WaitAsync(Bound);

        var page = await client.NewPageAsync().WaitAsync(Bound);
        await page.GoToAsync(origin.Url("/admin-settings")).WaitAsync(Bound);

        // The form is long, so the submit control starts below the fold. Bring it into view
        // through the page's own scrollIntoView() and then
        // issue a plain actionability-checked click on the element handle, with no Force and no
        // extended timeout. This mirrors the repo's own connect-over-endpoint click test, which
        // resolves a handle and clicks it rather than driving a raw coordinate event.
        var button = await page.QuerySelectorAsync(".btn.save").WaitAsync(Bound);
        await button.EvaluateFunctionAsync("element => element.scrollIntoView()").WaitAsync(Bound);

        // The click submits the form, which posts to the same URL and loads the response as the
        // new document. Arm the navigation wait before the click so the success marker is read
        // from the post-submit document, not the one still on screen when the click fires.
        await Task.WhenAll(
            page.WaitForNavigationAsync(),
            button.ClickAsync()).WaitAsync(Bound);

        page.Url.Should().Be(origin.Url("/admin-settings"));
        (await page.EvaluateExpressionAsync<string>("document.querySelector('#saved') ? document.querySelector('#saved').textContent : ''")
            .WaitAsync(Bound))
            .Should().Be("Settings saved");
        origin.Received.Count(request => request.Method == "POST").Should().Be(1);

        foreach (var hostContext in pages.Contexts)
        {
            foreach (var hostPage in hostContext.Pages)
            {
                hostPage.Errors.Should().BeEmpty();
            }
        }

        client.Disconnect();
        await context.CloseAsync();
    }
}
