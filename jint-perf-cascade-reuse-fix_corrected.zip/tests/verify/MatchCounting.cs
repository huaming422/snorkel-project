#nullable enable

using AngleSharp;
using AngleSharp.Css;
using AngleSharp.Css.Dom;
using AngleSharp.Dom;
using AngleSharp.Io;
using AngleSharp.Text;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace Jint.Tests.Browser.AdminForm;

/// <summary>
/// Delegates every <see cref="ICssDefaultStyleSheetProvider"/> member to a wrapped
/// provider and hands out a wrapped default sheet whose rules increment a shared
/// counter inside TryMatch, or inside Match when a caller matches through the rule's
/// selector directly.
/// </summary>
public sealed class MatchCountingDefaults : ICssDefaultStyleSheetProvider
{
    private readonly ICssDefaultStyleSheetProvider _inner;
    private readonly MatchCounter _counter = new();

    private ICssStyleSheet? _cachedInner;
    private ICssStyleSheet? _cachedWrapper;

    public MatchCountingDefaults(ICssDefaultStyleSheetProvider inner)
    {
        _inner = inner ?? throw new ArgumentNullException(nameof(inner));
    }

    /// <summary>
    /// Total number of match passes (TryMatch on a rule, or Match on its selector) across
    /// every rule handed out by this provider.
    /// </summary>
    public long Matches => _counter.Value;

    /// <summary>
    /// Resets the match counter to 0.
    /// </summary>
    public void Reset() => _counter.Reset();

    public ICssStyleSheet Default
    {
        get
        {
            var current = _inner.Default;

            // Rebuild the wrapper only if the underlying sheet instance changed.
            if (_cachedWrapper is null || !ReferenceEquals(_cachedInner, current))
            {
                _cachedInner = current;
                _cachedWrapper = new CountingStyleSheet(current, _counter);
            }

            return _cachedWrapper;
        }
    }

    public void SetDefault(ICssStyleSheet? sheet) => _inner.SetDefault(sheet);

    public void SetDefault(String source) => _inner.SetDefault(source);

    public void AppendDefault(String source) => _inner.AppendDefault(source);
}

/// <summary>
/// Delegates to a wrapped styling service and hands each style sheet it parses (the page's own
/// style elements) back wrapped, so match passes on the page's rules increment a counter of their
/// own.
/// </summary>
public sealed class MatchCountingPageSheets : IStylingService
{
    private readonly IStylingService _inner;
    private readonly MatchCounter _counter = new();

    public MatchCountingPageSheets(IStylingService inner)
    {
        _inner = inner ?? throw new ArgumentNullException(nameof(inner));
    }

    /// <summary>
    /// Total number of match passes across every rule of every sheet this service parsed.
    /// </summary>
    public long Matches => _counter.Value;

    /// <summary>
    /// Resets the match counter to 0.
    /// </summary>
    public void Reset() => _counter.Reset();

    public Boolean SupportsType(String mimeType) => _inner.SupportsType(mimeType);

    public async Task<IStyleSheet> ParseStylesheetAsync(IResponse response, StyleOptions options, CancellationToken cancel)
    {
        var sheet = await _inner.ParseStylesheetAsync(response, options, cancel).ConfigureAwait(false);
        return sheet is ICssStyleSheet css ? new CountingStyleSheet(css, _counter) : sheet;
    }
}

/// <summary>
/// Holds the shared match count by reference.
/// </summary>
internal sealed class MatchCounter
{
    private long _value;

    public long Value => Interlocked.Read(ref _value);

    public void Increment() => Interlocked.Increment(ref _value);

    public void Reset() => Interlocked.Exchange(ref _value, 0);
}

/// <summary>
/// Wraps style rules so their match passes are counted; every other rule kind (media and supports
/// groups, leaf rules) is handed back unchanged. Passes inside an unwrapped group are not counted,
/// on either side of a comparison.
/// </summary>
internal static class MatchCountingRules
{
    internal static ICssRule Wrap(ICssRule rule, MatchCounter counter)
    {
        if (rule is ICssStyleRule styleRule)
        {
            return new CountingStyleRule(styleRule, counter);
        }

        return rule;
    }
}

/// <summary>
/// Delegates every sheet member to the wrapped sheet, except Rules which returns a
/// wrapping rule list.
/// </summary>
internal sealed class CountingStyleSheet : ICssStyleSheet
{
    private readonly ICssStyleSheet _inner;
    private readonly MatchCounter _counter;
    private ICssRuleList? _rules;

    public CountingStyleSheet(ICssStyleSheet inner, MatchCounter counter)
    {
        _inner = inner;
        _counter = counter;
    }

    // IStyleSheet
    public String Type => _inner.Type;

    public String Href => _inner.Href;

    public IElement OwnerNode => _inner.OwnerNode;

    public String Title => _inner.Title;

    public IMediaList Media => _inner.Media;

    public Boolean IsDisabled
    {
        get => _inner.IsDisabled;
        set => _inner.IsDisabled = value;
    }

    public IBrowsingContext Context => _inner.Context;

    public TextSource Source => _inner.Source;

    public void SetOwner(IElement element) => _inner.SetOwner(element);

    public String LocateNamespace(String prefix) => _inner.LocateNamespace(prefix);

    // IStyleFormattable
    public void ToCss(TextWriter writer, IStyleFormatter formatter) => _inner.ToCss(writer, formatter);

    // ICssStyleSheet
    public ICssRule OwnerRule => _inner.OwnerRule;

    public ICssRuleList Rules => _rules ??= new CountingRuleList(_inner.Rules, _counter);

    public ICssStyleSheet Parent => _inner.Parent;

    public Int32 Insert(String rule, Int32 index) => _inner.Insert(rule, index);

    public void RemoveAt(Int32 index) => _inner.RemoveAt(index);

    public void SetOwner(ICssRule rule) => _inner.SetOwner(rule);

    public void SetParent(ICssStyleSheet parent) => _inner.SetParent(parent);
}

/// <summary>
/// Delegates list members to the wrapped rule list and wraps each rule it returns.
/// </summary>
internal sealed class CountingRuleList : ICssRuleList
{
    private readonly ICssRuleList _inner;
    private readonly MatchCounter _counter;

    public CountingRuleList(ICssRuleList inner, MatchCounter counter)
    {
        _inner = inner;
        _counter = counter;
    }

    public ICssRule this[Int32 index] => MatchCountingRules.Wrap(_inner[index], _counter);

    public Int32 Length => _inner.Length;

    public IEnumerator<ICssRule> GetEnumerator()
    {
        foreach (var rule in _inner)
        {
            yield return MatchCountingRules.Wrap(rule, _counter);
        }
    }

    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}

/// <summary>
/// Delegates every rule member to the wrapped style rule; increments the match
/// counter before delegating TryMatch, hands out a counting selector, and wraps the
/// nested Rules list. TryMatch delegates to the wrapped rule, which matches through
/// its own selector, so one pass is never counted twice.
/// </summary>
internal sealed class CountingStyleRule : ICssStyleRule
{
    private readonly ICssStyleRule _inner;
    private readonly MatchCounter _counter;
    private ICssRuleList? _rules;
    private ISelector? _selector;

    public CountingStyleRule(ICssStyleRule inner, MatchCounter counter)
    {
        _inner = inner;
        _counter = counter;
    }

    // ICssRule
    public CssRuleType Type => _inner.Type;

    public String CssText
    {
        get => _inner.CssText;
        set => _inner.CssText = value;
    }

    public ICssRule Parent => _inner.Parent;

    public ICssStyleSheet Owner => _inner.Owner;

    public void SetParent(ICssRule rule) => _inner.SetParent(rule);

    public void SetOwner(ICssStyleSheet sheet) => _inner.SetOwner(sheet);

    // IStyleFormattable
    public void ToCss(TextWriter writer, IStyleFormatter formatter) => _inner.ToCss(writer, formatter);

    // ICssStyleRule
    public String SelectorText
    {
        get => _inner.SelectorText;
        set => _inner.SelectorText = value;
    }

    public ICssStyleDeclaration Style => _inner.Style;

    public ISelector Selector => _selector ??= new CountingSelector(_inner.Selector, _counter);

    public Boolean TryMatch(IElement element, IElement? scope, out Priority specificity)
    {
        _counter.Increment();
        return _inner.TryMatch(element, scope, out specificity);
    }

    public ICssRuleList Rules => _rules ??= new CountingRuleList(_inner.Rules, _counter);
}

/// <summary>
/// Delegates every selector member to the wrapped selector; increments the match
/// counter before delegating Match.
/// </summary>
internal sealed class CountingSelector : ISelector
{
    private readonly ISelector _inner;
    private readonly MatchCounter _counter;

    public CountingSelector(ISelector inner, MatchCounter counter)
    {
        _inner = inner;
        _counter = counter;
    }

    public String Text => _inner.Text;

    public Priority Specificity => _inner.Specificity;

    public void Accept(ISelectorVisitor visitor) => _inner.Accept(visitor);

    public Boolean Match(IElement element, IElement? scope)
    {
        _counter.Increment();
        return _inner.Match(element, scope);
    }
}
