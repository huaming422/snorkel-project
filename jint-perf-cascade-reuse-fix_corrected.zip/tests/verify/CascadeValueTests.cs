using Jint.Browser;

namespace Jint.Tests.Browser.AdminForm;

// Each test loads a small page and reads one element's display from getComputedStyle and its height
// from getBoundingClientRect, as "display|height". A display of none gives a height of 0 and any
// other display gives the 16px row.
public class CascadeValueTests
{
    private const int Row = 16;

    // var() taken from the nearest ancestor that declares it, !important over a more specific
    // selector, and a matching media rule.
    [TestCase(
        "<style>:root{--d:block} .wrap{--d:none} #t{display:var(--d)}</style>"
        + "<div class='wrap'><button id='t'>Save</button></div>",
        "none|0",
        TestName = "CustomPropertyComesFromTheNearestDeclaringAncestor")]
    [TestCase(
        "<style>:root{--d:none} .wrap{--d:block} #t{display:var(--d)}</style>"
        + "<div class='wrap'><button id='t'>Save</button></div>",
        "block|16",
        TestName = "ACloserCustomPropertyDeclarationWins")]
    [TestCase(
        "<style>.t{display:block} #t{display:none} .t{display:block!important}</style>"
        + "<button id='t' class='t'>Save</button>",
        "block|16",
        TestName = "ImportanceBeatsAHigherSpecificitySelector")]
    [TestCase(
        "<style>#t{display:none} @media (min-width:1px){#t{display:block}}</style>"
        + "<button id='t'>Save</button>",
        "block|16",
        TestName = "AMatchingMediaRuleIsHonoured")]
    public async Task TheRenderingPathAndComputedStylePathAgreeOnAResolvedDisplay(string markup, string expected)
    {
        await using var browser = new global::Jint.Browser.Browser();
        var page = await browser.NewPageAsync();
        await page.SetContentAsync(markup);

        (await page.EvaluateAsync<string>(
            """
            (() => {
              const t = document.getElementById('t');
              const display = getComputedStyle(t).display;
              const height = t.getBoundingClientRect().height;
              return display + '|' + height;
            })()
            """)).Should().Be(expected);
        page.Errors.Should().BeEmpty();
    }

    // display: inherit takes the parent's display; with a parent that declares no display it takes
    // the nearest ancestor's, here a div whose rules also give it a width in ch. A root custom
    // property whose value is the word inherit leaves an element with its own display.
    [TestCase(
        "<style>.parent{display:block} #t{display:inherit}</style>"
        + "<div class='parent'><button id='t'>Save</button></div>",
        "block|16",
        TestName = "ExplicitInheritTakesARenderedAncestorValue")]
    [TestCase(
        "<style>.parent{display:none} #t{display:inherit}</style>"
        + "<div class='parent'><button id='t'>Save</button></div>",
        "none|0",
        TestName = "ExplicitInheritTakesAHiddenAncestorValue")]
    [TestCase(
        "<style>.outer{display:none;width:20ch}</style>"
        + "<div class='outer'><span><b id='t' style='display:inherit'>Save</b></span></div>",
        "none|0",
        TestName = "ExplicitInheritReachesPastAParentThatDeclaresNoDisplay")]
    [TestCase(
        "<style>:root{--token:inherit} #t{display:block}</style>"
        + "<button id='t'>Save</button>",
        "block|16",
        TestName = "ALiteralInheritTokenDoesNotSuppressUnrelatedElements")]
    public async Task ExplicitInheritResolvesAgainstTheAncestorOnBothPaths(string markup, string expected)
    {
        await using var browser = new global::Jint.Browser.Browser();
        var page = await browser.NewPageAsync();
        await page.SetContentAsync(markup);

        (await page.EvaluateAsync<string>(
            """
            (() => {
              const t = document.getElementById('t');
              const display = getComputedStyle(t).display;
              const height = t.getBoundingClientRect().height;
              return display + '|' + height;
            })()
            """)).Should().Be(expected);
        page.Errors.Should().BeEmpty();
    }

    // Elements that carry no attributes, styled only by rules that reach them through their ancestors.
    [TestCase(
        "<style>nav li{display:none}</style><nav><ul><li>Home</li></ul></nav>",
        "nav li",
        "none|0",
        TestName = "ADescendantRuleHidesAListItemWithNoAttributes")]
    [TestCase(
        "<style>.menu > ul > li{display:none}</style><div class='menu'><ul><li>Home</li></ul></div>",
        ".menu li",
        "none|0",
        TestName = "AChildRuleUnderAClassedAncestorHidesAPlainListItem")]
    [TestCase(
        "<style>section div span{display:none}</style><section><div><div><span>Deep</span></div></div></section>",
        "section span",
        "none|0",
        TestName = "ARuleThreeLevelsUpHidesAPlainSpan")]
    [TestCase(
        "<style>nav li{display:none} nav li:last-child{display:block}</style><nav><ul><li>Home</li><li>Admin</li></ul></nav>",
        "nav li:last-child",
        "block|16",
        TestName = "ALaterRuleShowsTheLastPlainListItem")]
    public async Task ElementsWithoutAttributesTakeTheirAncestorsRules(string markup, string selector, string expected)
    {
        await using var browser = new global::Jint.Browser.Browser();
        var page = await browser.NewPageAsync();
        await page.SetContentAsync(markup);

        (await page.EvaluateAsync<string>(
            $$"""
            (() => {
              const t = document.querySelector('{{selector}}');
              const display = getComputedStyle(t).display;
              const height = t.getBoundingClientRect().height;
              return display + '|' + height;
            })()
            """)).Should().Be(expected);
        page.Errors.Should().BeEmpty();
    }
}
