using Jint.Browser;

namespace Jint.Tests.Browser.Reward;

// Value-correctness of the geometry query, observed only through the page's own JavaScript surface.
// Two independent paths resolve an element's display: the rendering/geometry answer
// (getBoundingClientRect) and the per-element computed-style answer (getComputedStyle). They must
// agree, and both must reflect a correctly-resolved cascade: custom-property values taken from the
// nearest declaring ancestor, importance beating specificity, media state honoured, and explicit
// `inherit` taking the ancestor value even on a property that does not normally inherit. No
// subsystem type is named; everything is driven through the page.
public class RewardCascadeValueTests
{
    private const int Row = 16;

    // The rendering path and the computed-style path must return the same display decision, and it
    // must be the correctly-cascaded one. A reused cascade that resolved a child's var(), importance
    // or media state from the wrong declarations would make the two paths disagree or return the
    // wrong value. "display|height": a non-none display renders a 16px row; `none` renders nothing.
    [TestCase(
        "<style>:root{--d:block} .wrap{--d:none} #t{display:var(--d)}</style>"
        + "<div class='wrap'><button id='t'>Save</button></div>",
        "none|0",
        TestName = "CustomPropertyComesFromTheNearestDeclaringAncestor")]
    [TestCase(
        "<style>:root{--d:none} .wrap{--d:block} #t{display:var(--d)}</style>"
        + "<div class='wrap'><button id='t'>Save</button></div>",
        "block|16",
        TestName = "ACloserCustomPropertyDeclarationWins")]
    [TestCase(
        "<style>.t{display:block} #t{display:none} .t{display:block!important}</style>"
        + "<button id='t' class='t'>Save</button>",
        "block|16",
        TestName = "ImportanceBeatsAHigherSpecificitySelector")]
    [TestCase(
        "<style>#t{display:none} @media (min-width:1px){#t{display:block}}</style>"
        + "<button id='t'>Save</button>",
        "block|16",
        TestName = "AMatchingMediaRuleIsHonoured")]
    public async Task TheRenderingPathAndComputedStylePathAgreeOnAResolvedDisplay(string markup, string expected)
    {
        await using var browser = new global::Jint.Browser.Browser();
        var page = await browser.NewPageAsync();
        await page.SetContentAsync(markup);

        (await page.EvaluateAsync<string>(
            """
            (() => {
              const t = document.getElementById('t');
              const display = getComputedStyle(t).display;
              const height = t.getBoundingClientRect().height;
              return display + '|' + height;
            })()
            """)).Should().Be(expected);
        page.Errors.Should().BeEmpty();
    }

    // Explicit `inherit` on a property that does not normally inherit must still take the ancestor's
    // value; and a custom-property token whose literal text is `inherit` must not push unrelated
    // elements through that fallback. Both paths must agree on the outcome.
    [TestCase(
        "<style>.parent{display:block} #t{display:inherit}</style>"
        + "<div class='parent'><button id='t'>Save</button></div>",
        "block|16",
        TestName = "ExplicitInheritTakesARenderedAncestorValue")]
    [TestCase(
        "<style>.parent{display:none} #t{display:inherit}</style>"
        + "<div class='parent'><button id='t'>Save</button></div>",
        "none|0",
        TestName = "ExplicitInheritTakesAHiddenAncestorValue")]
    [TestCase(
        "<style>:root{--token:inherit} #t{display:block}</style>"
        + "<button id='t'>Save</button>",
        "block|16",
        TestName = "ALiteralInheritTokenDoesNotSuppressUnrelatedElements")]
    public async Task ExplicitInheritResolvesAgainstTheAncestorOnBothPaths(string markup, string expected)
    {
        await using var browser = new global::Jint.Browser.Browser();
        var page = await browser.NewPageAsync();
        await page.SetContentAsync(markup);

        (await page.EvaluateAsync<string>(
            """
            (() => {
              const t = document.getElementById('t');
              const display = getComputedStyle(t).display;
              const height = t.getBoundingClientRect().height;
              return display + '|' + height;
            })()
            """)).Should().Be(expected);
        page.Errors.Should().BeEmpty();
    }
}
