#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier (set -euo pipefail inherited).
# Brings the baked NuGet closure online for the focused net10.0 test run.
cd /repo/jint

# Offline switch right after cd: a cache miss must fail fast instead of
# reaching nuget.org. The image warmed /opt/cache/nuget at the base commit;
# the fix adds no package, so an offline restore covers both the starting tree
# and any correct solution.
export DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_NOLOGO=1 DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1
export NUGET_PACKAGES=/opt/cache/nuget

# Dependencies: offline-first against the image bake, logged online fallback.
if dotnet restore Jint.Tests.Browser/Jint.Tests.Browser.csproj --source /opt/cache/nuget > /tmp/test-setup-restore.log 2>&1; then
    echo "[offline-first] NuGet restore satisfied from image cache"
elif dotnet restore Jint.Tests.Browser/Jint.Tests.Browser.csproj >> /tmp/test-setup-restore.log 2>&1; then
    echo "[test-setup] NuGet restored online (image bake was stale)"
else
    tail -40 /tmp/test-setup-restore.log >&2; exit 1
fi

# No services to start and no bug-triggering data to seed: the reproduction is a
# synthetic in-process document built by the verifier's own fixtures. No
# assertion logic here.
