## Task

Driving a big admin form that the server renders in full, over Jint.Browser's remote automation link, has become slow. An actionability-checked click on the form's Save button takes several seconds, even though it works: the click lands, the form posts once to the same URL and the page shows its success message. Small pages are fine. On copies of the admin page grown with deeper markup and more CSS, the time per click climbs well ahead of the page's size. I'd like a click's cost to grow only in proportion to the page.
