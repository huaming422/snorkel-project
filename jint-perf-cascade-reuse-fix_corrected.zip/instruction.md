## Task

Driving a big admin form that the server renders in full, over Jint.Browser's remote automation link, has become slow. An actionability-checked click on the form's Save button takes several seconds, even though it works: the click lands, the form posts once to the same URL and the page shows its success message. Small pages are fine; the big admin pages, with deep markup and a lot of CSS, are the slow ones. I'd like that click to be quick again.
