// Integration test for selector_scoped_matching story
// Tests that resolve_documents scopes membership by each server's own selector
// cargo_package = "."

use std::collections::HashMap;
use red::config::{LspConfig, LanguageServerConfig};
use red::lsp::LspManager;

fn make_server(name: &str, extensions: &[&str]) -> LanguageServerConfig {
    LanguageServerConfig {
        command: String::new(),
        args: Vec::new(),
        language_id: name.to_string(),
        file_extensions: extensions.iter().map(|e| e.to_string()).collect(),
        filenames: Vec::new(),
        documents: Vec::new(),
        root_markers: Vec::new(),
        env: HashMap::new(),
        initialization_options: None,
        settings: None,
        workspace_name: None,
    }
}

#[test]
fn test_selector_scoped_matching_case0() {
    // inputs: servers = [alpha/ts, beta/ts+rs, gamma/rs], probe = "sample.rs"
    // expected: matched_servers = ["beta", "gamma"], match_count = 2

    let servers = HashMap::from([
        ("alpha".to_string(), make_server("alpha", &["ts"])),
        ("beta".to_string(), make_server("beta", &["ts", "rs"])),
        ("gamma".to_string(), make_server("gamma", &["rs"])),
    ]);

    let config = LspConfig {
        enabled: true,
        format_on_save: false,
        servers,
    };

    let manager = LspManager::new(config);
    let probe = "sample.rs";
    let results = manager.resolve_documents(probe);

    let match_count = results.len();
    let mut matched_servers: Vec<String> = results
        .into_iter()
        .map(|doc| doc.server_name)
        .collect();
    matched_servers.sort();

    let expected_matched_servers: Vec<String> = vec!["beta".to_string(), "gamma".to_string()];
    let expected_match_count: usize = 2;

    assert_eq!(
        match_count, expected_match_count,
        "case 0: match_count mismatch: got {}, expected {}",
        match_count, expected_match_count
    );
    assert_eq!(
        matched_servers, expected_matched_servers,
        "case 0: matched_servers mismatch: got {:?}, expected {:?}",
        matched_servers, expected_matched_servers
    );
}

#[test]
fn test_selector_scoped_matching_case1() {
    // inputs: servers = [alpha/ts, beta/ts+rs, gamma/rs], probe = "sample.ts"
    // expected: matched_servers = ["alpha", "beta"], match_count = 2

    let servers = HashMap::from([
        ("alpha".to_string(), make_server("alpha", &["ts"])),
        ("beta".to_string(), make_server("beta", &["ts", "rs"])),
        ("gamma".to_string(), make_server("gamma", &["rs"])),
    ]);

    let config = LspConfig {
        enabled: true,
        format_on_save: false,
        servers,
    };

    let manager = LspManager::new(config);
    let probe = "sample.ts";
    let results = manager.resolve_documents(probe);

    let match_count = results.len();
    let mut matched_servers: Vec<String> = results
        .into_iter()
        .map(|doc| doc.server_name)
        .collect();
    matched_servers.sort();

    let expected_matched_servers: Vec<String> = vec!["alpha".to_string(), "beta".to_string()];
    let expected_match_count: usize = 2;

    assert_eq!(
        match_count, expected_match_count,
        "case 1: match_count mismatch: got {}, expected {}",
        match_count, expected_match_count
    );
    assert_eq!(
        matched_servers, expected_matched_servers,
        "case 1: matched_servers mismatch: got {:?}, expected {:?}",
        matched_servers, expected_matched_servers
    );
}

#[test]
fn test_selector_scoped_matching_case2() {
    // inputs: servers = [alpha/ts, beta/ts+rs, gamma/rs], probe = "sample.py"
    // expected: matched_servers = [], match_count = 0

    let servers = HashMap::from([
        ("alpha".to_string(), make_server("alpha", &["ts"])),
        ("beta".to_string(), make_server("beta", &["ts", "rs"])),
        ("gamma".to_string(), make_server("gamma", &["rs"])),
    ]);

    let config = LspConfig {
        enabled: true,
        format_on_save: false,
        servers,
    };

    let manager = LspManager::new(config);
    let probe = "sample.py";
    let results = manager.resolve_documents(probe);

    let match_count = results.len();
    let mut matched_servers: Vec<String> = results
        .into_iter()
        .map(|doc| doc.server_name)
        .collect();
    matched_servers.sort();

    let expected_matched_servers: Vec<String> = vec![];
    let expected_match_count: usize = 0;

    assert_eq!(
        match_count, expected_match_count,
        "case 2: match_count mismatch: got {}, expected {}",
        match_count, expected_match_count
    );
    assert_eq!(
        matched_servers, expected_matched_servers,
        "case 2: matched_servers mismatch: got {:?}, expected {:?}",
        matched_servers, expected_matched_servers
    );
}
