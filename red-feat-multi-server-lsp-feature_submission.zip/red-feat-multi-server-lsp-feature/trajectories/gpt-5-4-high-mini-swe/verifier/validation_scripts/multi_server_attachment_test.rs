// Integration test for multi_server_attachment story
// Tests that resolve_documents returns ALL matching servers for a document
// cargo_package = "."

use std::collections::HashMap;
use red::config::{LspConfig, LanguageServerConfig};
use red::lsp::LspManager;

fn make_server(name: &str, extensions: &[&str]) -> LanguageServerConfig {
    LanguageServerConfig {
        command: String::new(),
        args: Vec::new(),
        language_id: name.to_string(),
        file_extensions: extensions.iter().map(|e| e.to_string()).collect(),
        filenames: Vec::new(),
        documents: Vec::new(),
        root_markers: Vec::new(),
        env: HashMap::new(),
        initialization_options: None,
        settings: None,
        workspace_name: None,
    }
}

#[test]
fn test_multi_server_attachment_case0() {
    // inputs: servers = [alpha/ts, beta/ts, gamma/rs], probe = "sample.ts"
    // expected: matched_servers = ["alpha", "beta"], match_count = 2

    let servers = HashMap::from([
        ("alpha".to_string(), make_server("alpha", &["ts"])),
        ("beta".to_string(), make_server("beta", &["ts"])),
        ("gamma".to_string(), make_server("gamma", &["rs"])),
    ]);

    let config = LspConfig {
        enabled: true,
        format_on_save: false,
        servers,
    };

    let manager = LspManager::new(config);
    let probe = "sample.ts";
    let results = manager.resolve_documents(probe);

    let match_count = results.len();
    let mut matched_servers: Vec<String> = results
        .into_iter()
        .map(|doc| doc.server_name)
        .collect();
    matched_servers.sort();

    let expected_matched_servers: Vec<String> = vec!["alpha".to_string(), "beta".to_string()];
    let expected_match_count: usize = 2;

    assert_eq!(
        match_count, expected_match_count,
        "case 0: match_count mismatch: got {}, expected {}",
        match_count, expected_match_count
    );
    assert_eq!(
        matched_servers, expected_matched_servers,
        "case 0: matched_servers mismatch: got {:?}, expected {:?}",
        matched_servers, expected_matched_servers
    );
}

#[test]
fn test_multi_server_attachment_case1() {
    // inputs: servers = [alpha/ts, beta/ts, gamma/ts], probe = "sample.ts"
    // expected: matched_servers = ["alpha", "beta", "gamma"], match_count = 3

    let servers = HashMap::from([
        ("alpha".to_string(), make_server("alpha", &["ts"])),
        ("beta".to_string(), make_server("beta", &["ts"])),
        ("gamma".to_string(), make_server("gamma", &["ts"])),
    ]);

    let config = LspConfig {
        enabled: true,
        format_on_save: false,
        servers,
    };

    let manager = LspManager::new(config);
    let probe = "sample.ts";
    let results = manager.resolve_documents(probe);

    let match_count = results.len();
    let mut matched_servers: Vec<String> = results
        .into_iter()
        .map(|doc| doc.server_name)
        .collect();
    matched_servers.sort();

    let expected_matched_servers: Vec<String> = vec![
        "alpha".to_string(),
        "beta".to_string(),
        "gamma".to_string(),
    ];
    let expected_match_count: usize = 3;

    assert_eq!(
        match_count, expected_match_count,
        "case 1: match_count mismatch: got {}, expected {}",
        match_count, expected_match_count
    );
    assert_eq!(
        matched_servers, expected_matched_servers,
        "case 1: matched_servers mismatch: got {:?}, expected {:?}",
        matched_servers, expected_matched_servers
    );
}
