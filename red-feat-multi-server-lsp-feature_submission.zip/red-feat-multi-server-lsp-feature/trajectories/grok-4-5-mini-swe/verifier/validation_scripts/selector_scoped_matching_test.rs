use std::collections::HashMap;
use red::config::{LspConfig, LanguageServerConfig};
use red::lsp::LspManager;

fn make_server(extensions: &[&str]) -> LanguageServerConfig {
    LanguageServerConfig {
        command: String::new(),
        args: Vec::new(),
        language_id: "testlang".to_string(),
        file_extensions: extensions.iter().map(|e| e.to_string()).collect(),
        filenames: Vec::new(),
        documents: Vec::new(),
        root_markers: Vec::new(),
        env: HashMap::new(),
        initialization_options: None,
        settings: None,
        workspace_name: None,
    }
}

// Case 1: alpha=["ts"], beta=["ts","rs"], gamma=["rs"]; probe="sample.rs"
// Expected: matched_servers = ["beta", "gamma"], match_count = 2
#[test]
fn test_scoped_rs_probe() {
    let manager = LspManager::new(LspConfig {
        enabled: true,
        format_on_save: false,
        servers: HashMap::from([
            ("alpha".to_string(), make_server(&["ts"])),
            ("beta".to_string(),  make_server(&["ts", "rs"])),
            ("gamma".to_string(), make_server(&["rs"])),
        ]),
    });

    let documents = manager.resolve_documents("sample.rs");
    let mut keys: Vec<String> = documents.iter().map(|d| d.server_name.clone()).collect();
    keys.sort();

    let expected_servers: Vec<String> = vec!["beta".to_string(), "gamma".to_string()];
    let expected_count: usize = 2;

    assert_eq!(
        keys, expected_servers,
        "Case 1 (rs probe): matched_servers mismatch"
    );
    assert_eq!(
        documents.len(), expected_count,
        "Case 1 (rs probe): match_count mismatch"
    );
}

// Case 2: alpha=["ts"], beta=["ts","rs"], gamma=["rs"]; probe="sample.ts"
// Expected: matched_servers = ["alpha", "beta"], match_count = 2
#[test]
fn test_scoped_ts_probe() {
    let manager = LspManager::new(LspConfig {
        enabled: true,
        format_on_save: false,
        servers: HashMap::from([
            ("alpha".to_string(), make_server(&["ts"])),
            ("beta".to_string(),  make_server(&["ts", "rs"])),
            ("gamma".to_string(), make_server(&["rs"])),
        ]),
    });

    let documents = manager.resolve_documents("sample.ts");
    let mut keys: Vec<String> = documents.iter().map(|d| d.server_name.clone()).collect();
    keys.sort();

    let expected_servers: Vec<String> = vec!["alpha".to_string(), "beta".to_string()];
    let expected_count: usize = 2;

    assert_eq!(
        keys, expected_servers,
        "Case 2 (ts probe): matched_servers mismatch"
    );
    assert_eq!(
        documents.len(), expected_count,
        "Case 2 (ts probe): match_count mismatch"
    );
}

// Case 3: alpha=["ts"], beta=["ts","rs"], gamma=["rs"]; probe="sample.py"
// Expected: matched_servers = [], match_count = 0
#[test]
fn test_scoped_no_match_probe() {
    let manager = LspManager::new(LspConfig {
        enabled: true,
        format_on_save: false,
        servers: HashMap::from([
            ("alpha".to_string(), make_server(&["ts"])),
            ("beta".to_string(),  make_server(&["ts", "rs"])),
            ("gamma".to_string(), make_server(&["rs"])),
        ]),
    });

    let documents = manager.resolve_documents("sample.py");
    let mut keys: Vec<String> = documents.iter().map(|d| d.server_name.clone()).collect();
    keys.sort();

    let expected_servers: Vec<String> = vec![];
    let expected_count: usize = 0;

    assert_eq!(
        keys, expected_servers,
        "Case 3 (py probe, no match): matched_servers mismatch"
    );
    assert_eq!(
        documents.len(), expected_count,
        "Case 3 (py probe, no match): match_count mismatch"
    );
}
