use std::collections::HashMap;
use red::config::{LspConfig, LanguageServerConfig};
use red::lsp::LspManager;

fn make_server(extensions: &[&str]) -> LanguageServerConfig {
    LanguageServerConfig {
        command: String::new(),
        args: Vec::new(),
        language_id: "testlang".to_string(),
        file_extensions: extensions.iter().map(|e| e.to_string()).collect(),
        filenames: Vec::new(),
        documents: Vec::new(),
        root_markers: Vec::new(),
        env: HashMap::new(),
        initialization_options: None,
        settings: None,
        workspace_name: None,
    }
}

// Case 1: two servers claim "ts", one claims "rs"; probe is "sample.ts"
// Expected: matched_servers = ["alpha", "beta"], match_count = 2
#[test]
fn test_multi_server_two_ts_servers() {
    let manager = LspManager::new(LspConfig {
        enabled: true,
        format_on_save: false,
        servers: HashMap::from([
            ("alpha".to_string(), make_server(&["ts"])),
            ("beta".to_string(),  make_server(&["ts"])),
            ("gamma".to_string(), make_server(&["rs"])),
        ]),
    });

    let documents = manager.resolve_documents("sample.ts");
    let mut keys: Vec<String> = documents.iter().map(|d| d.server_name.clone()).collect();
    keys.sort();

    let expected_servers: Vec<String> = vec!["alpha".to_string(), "beta".to_string()];
    let expected_count: usize = 2;

    assert_eq!(
        keys, expected_servers,
        "Case 1: matched_servers mismatch: got {:?}, want {:?}",
        keys, expected_servers
    );
    assert_eq!(
        documents.len(), expected_count,
        "Case 1: match_count mismatch: got {}, want {}",
        documents.len(), expected_count
    );
}

// Case 2: three servers all claim "ts"; probe is "sample.ts"
// Expected: matched_servers = ["alpha", "beta", "gamma"], match_count = 3
#[test]
fn test_multi_server_three_ts_servers() {
    let manager = LspManager::new(LspConfig {
        enabled: true,
        format_on_save: false,
        servers: HashMap::from([
            ("alpha".to_string(), make_server(&["ts"])),
            ("beta".to_string(),  make_server(&["ts"])),
            ("gamma".to_string(), make_server(&["ts"])),
        ]),
    });

    let documents = manager.resolve_documents("sample.ts");
    let mut keys: Vec<String> = documents.iter().map(|d| d.server_name.clone()).collect();
    keys.sort();

    let expected_servers: Vec<String> = vec!["alpha".to_string(), "beta".to_string(), "gamma".to_string()];
    let expected_count: usize = 3;

    assert_eq!(
        keys, expected_servers,
        "Case 2: matched_servers mismatch: got {:?}, want {:?}",
        keys, expected_servers
    );
    assert_eq!(
        documents.len(), expected_count,
        "Case 2: match_count mismatch: got {}, want {}",
        documents.len(), expected_count
    );
}
