use std::collections::HashMap;
use red::config::{LspConfig, LanguageServerConfig};
use red::lsp::LspManager;

fn make_server(name: &str, extensions: &[&str]) -> LanguageServerConfig {
    LanguageServerConfig {
        command: String::new(),
        args: Vec::new(),
        language_id: name.to_string(),
        file_extensions: extensions.iter().map(|e| e.to_string()).collect(),
        filenames: Vec::new(),
        documents: Vec::new(),
        root_markers: Vec::new(),
        env: HashMap::new(),
        initialization_options: None,
        settings: None,
        workspace_name: None,
    }
}

#[test]
fn test_multi_server_attachment() {
    // Test case 1: Two servers claim "ts", one claims "rs", probe is "sample.ts"
    // expected: matched_servers = ["alpha", "beta"], match_count = 2
    {
        let servers = vec![
            ("alpha".to_string(), make_server("alpha", &["ts"])),
            ("beta".to_string(), make_server("beta", &["ts"])),
            ("gamma".to_string(), make_server("gamma", &["rs"])),
        ];
        let manager = LspManager::new(LspConfig {
            enabled: true,
            format_on_save: false,
            servers: servers.into_iter().collect::<HashMap<_, _>>(),
        });

        let probe = "sample.ts";
        let resolved = manager.resolve_documents(probe);
        let match_count = resolved.len();
        let mut matched_servers: Vec<String> = resolved
            .into_iter()
            .map(|doc| doc.server_name)
            .collect();
        matched_servers.sort();

        let expected_matched_servers = vec!["alpha".to_string(), "beta".to_string()];
        let expected_match_count: usize = 2;

        assert_eq!(
            matched_servers, expected_matched_servers,
            "case 1: matched_servers mismatch for probe '{}': got {:?}, expected {:?}",
            probe, matched_servers, expected_matched_servers
        );
        assert_eq!(
            match_count, expected_match_count,
            "case 1: match_count mismatch for probe '{}': got {}, expected {}",
            probe, match_count, expected_match_count
        );
    }

    // Test case 2: Three servers all claim "ts", probe is "sample.ts"
    // expected: matched_servers = ["alpha", "beta", "gamma"], match_count = 3
    {
        let servers = vec![
            ("alpha".to_string(), make_server("alpha", &["ts"])),
            ("beta".to_string(), make_server("beta", &["ts"])),
            ("gamma".to_string(), make_server("gamma", &["ts"])),
        ];
        let manager = LspManager::new(LspConfig {
            enabled: true,
            format_on_save: false,
            servers: servers.into_iter().collect::<HashMap<_, _>>(),
        });

        let probe = "sample.ts";
        let resolved = manager.resolve_documents(probe);
        let match_count = resolved.len();
        let mut matched_servers: Vec<String> = resolved
            .into_iter()
            .map(|doc| doc.server_name)
            .collect();
        matched_servers.sort();

        let expected_matched_servers = vec!["alpha".to_string(), "beta".to_string(), "gamma".to_string()];
        let expected_match_count: usize = 3;

        assert_eq!(
            matched_servers, expected_matched_servers,
            "case 2: matched_servers mismatch for probe '{}': got {:?}, expected {:?}",
            probe, matched_servers, expected_matched_servers
        );
        assert_eq!(
            match_count, expected_match_count,
            "case 2: match_count mismatch for probe '{}': got {}, expected {}",
            probe, match_count, expected_match_count
        );
    }
}
