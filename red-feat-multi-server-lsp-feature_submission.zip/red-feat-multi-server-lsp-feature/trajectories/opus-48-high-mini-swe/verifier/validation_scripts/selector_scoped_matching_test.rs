use std::collections::HashMap;
use red::config::{LspConfig, LanguageServerConfig};
use red::lsp::LspManager;

fn make_server(name: &str, extensions: &[&str]) -> LanguageServerConfig {
    LanguageServerConfig {
        command: String::new(),
        args: Vec::new(),
        language_id: name.to_string(),
        file_extensions: extensions.iter().map(|e| e.to_string()).collect(),
        filenames: Vec::new(),
        documents: Vec::new(),
        root_markers: Vec::new(),
        env: HashMap::new(),
        initialization_options: None,
        settings: None,
        workspace_name: None,
    }
}

#[test]
fn test_selector_scoped_matching() {
    // All three test cases share the same server configuration:
    // alpha claims ["ts"], beta claims ["ts", "rs"], gamma claims ["rs"]

    // Test case 1: probe = "sample.rs"
    // expected: matched_servers = ["beta", "gamma"], match_count = 2
    {
        let servers = vec![
            ("alpha".to_string(), make_server("alpha", &["ts"])),
            ("beta".to_string(), make_server("beta", &["ts", "rs"])),
            ("gamma".to_string(), make_server("gamma", &["rs"])),
        ];
        let manager = LspManager::new(LspConfig {
            enabled: true,
            format_on_save: false,
            servers: servers.into_iter().collect::<HashMap<_, _>>(),
        });

        let probe = "sample.rs";
        let resolved = manager.resolve_documents(probe);
        let match_count = resolved.len();
        let mut matched_servers: Vec<String> = resolved
            .into_iter()
            .map(|doc| doc.server_name)
            .collect();
        matched_servers.sort();

        let expected_matched_servers = vec!["beta".to_string(), "gamma".to_string()];
        let expected_match_count: usize = 2;

        assert_eq!(
            matched_servers, expected_matched_servers,
            "case 1: matched_servers mismatch for probe '{}': got {:?}, expected {:?}",
            probe, matched_servers, expected_matched_servers
        );
        assert_eq!(
            match_count, expected_match_count,
            "case 1: match_count mismatch for probe '{}': got {}, expected {}",
            probe, match_count, expected_match_count
        );
    }

    // Test case 2: probe = "sample.ts"
    // expected: matched_servers = ["alpha", "beta"], match_count = 2
    {
        let servers = vec![
            ("alpha".to_string(), make_server("alpha", &["ts"])),
            ("beta".to_string(), make_server("beta", &["ts", "rs"])),
            ("gamma".to_string(), make_server("gamma", &["rs"])),
        ];
        let manager = LspManager::new(LspConfig {
            enabled: true,
            format_on_save: false,
            servers: servers.into_iter().collect::<HashMap<_, _>>(),
        });

        let probe = "sample.ts";
        let resolved = manager.resolve_documents(probe);
        let match_count = resolved.len();
        let mut matched_servers: Vec<String> = resolved
            .into_iter()
            .map(|doc| doc.server_name)
            .collect();
        matched_servers.sort();

        let expected_matched_servers = vec!["alpha".to_string(), "beta".to_string()];
        let expected_match_count: usize = 2;

        assert_eq!(
            matched_servers, expected_matched_servers,
            "case 2: matched_servers mismatch for probe '{}': got {:?}, expected {:?}",
            probe, matched_servers, expected_matched_servers
        );
        assert_eq!(
            match_count, expected_match_count,
            "case 2: match_count mismatch for probe '{}': got {}, expected {}",
            probe, match_count, expected_match_count
        );
    }

    // Test case 3: probe = "sample.py"
    // expected: matched_servers = [], match_count = 0
    {
        let servers = vec![
            ("alpha".to_string(), make_server("alpha", &["ts"])),
            ("beta".to_string(), make_server("beta", &["ts", "rs"])),
            ("gamma".to_string(), make_server("gamma", &["rs"])),
        ];
        let manager = LspManager::new(LspConfig {
            enabled: true,
            format_on_save: false,
            servers: servers.into_iter().collect::<HashMap<_, _>>(),
        });

        let probe = "sample.py";
        let resolved = manager.resolve_documents(probe);
        let match_count = resolved.len();
        let mut matched_servers: Vec<String> = resolved
            .into_iter()
            .map(|doc| doc.server_name)
            .collect();
        matched_servers.sort();

        let expected_matched_servers: Vec<String> = vec![];
        let expected_match_count: usize = 0;

        assert_eq!(
            matched_servers, expected_matched_servers,
            "case 3: matched_servers mismatch for probe '{}': got {:?}, expected {:?}",
            probe, matched_servers, expected_matched_servers
        );
        assert_eq!(
            match_count, expected_match_count,
            "case 3: match_count mismatch for probe '{}': got {}, expected {}",
            probe, match_count, expected_match_count
        );
    }
}
