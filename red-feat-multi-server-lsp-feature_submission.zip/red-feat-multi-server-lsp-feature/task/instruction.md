## Task

Right now an open document only ever talks to a single language server. When a
file matches more than one of our configured servers we pick one and ignore the
rest. We want a document to use every configured server whose selector matches
it, so a TypeScript file could be served at once by a types server and a separate
linter and combine what both offer.

Two things have to hold while we do this. The features that can only use a single
response, like hover, completion, and formatting, still need to come back with
one deterministic result rather than whatever answers first. And each server's
diagnostics have to stay independent, so one server's trouble can't corrupt or
wipe out another's.

Documents that match only one server, and the existing precedence of the external
non-LSP formatter, should keep behaving exactly as they do today.

You can exercise all of this in-process with the editor's existing scripted mock
language-server support. There's no need to install or run a real TypeScript
server, linter, or formatter binary.

## User stories / requirements

- When a document's configuration matches more than one language server, the document selects every matching server rather than just one, so two servers that both claim a file are both selected, and three that all claim it are all selected.
- Server selection is scoped per document selector: when configured servers claim overlapping but different sets of file types, a document selects exactly the servers whose selectors admit it and no others, and a document no selector admits selects none.
