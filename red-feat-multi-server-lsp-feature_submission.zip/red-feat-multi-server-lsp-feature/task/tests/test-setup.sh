#!/usr/bin/env bash
# Verifier-side setup: runs before the reward stage's verifiers (and inside the
# offline fold under `docker run --network none`). The image already installed
# the Rust toolchain, warmed the cargo registry at the base commit, and
# pre-built the workspace + tests; this just re-exports the toolchain paths and
# forces cargo offline so a cache miss fails fast instead of hanging on a dead
# network.
set -euo pipefail

# The Modal sandbox starts a fresh shell per phase, so the Dockerfile's ENV
# lines are not inherited — re-export the environment image's toolchain paths.
export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
export RUSTUP_TOOLCHAIN="${RUSTUP_TOOLCHAIN:-1.99.0}"
export PATH="$CARGO_HOME/bin:$PATH"

# Dependency closure is baked at the base commit; never reach for the network.
export CARGO_NET_OFFLINE=true

# Sanity check: the toolchain must be present.
rustc --version >/dev/null 2>&1 || {
    echo "ERROR: rustc not found on PATH (CARGO_HOME=$CARGO_HOME)" >&2
    exit 1
}
cargo --version >/dev/null 2>&1 || {
    echo "ERROR: cargo not found on PATH" >&2
    exit 1
}

echo "test-setup: rustc=$(rustc --version), cargo=$(cargo --version | head -1)"
