#!/usr/bin/env bash
# Single-server regression guard for red-feat-multi-server-lsp.
#
# Runs the crate's pre-existing single-server language-subsystem integration
# suites with the submission's edits applied and requires them to stay green.
# These suites cover single-server document lifecycle, the editor's formatting
# action and its precedence relative to the external non-LSP formatter, and
# save/format behavior — all of which a correct multi-server change must leave
# intact. A green run also proves the crate + test tree still compile.
#
# Exit 0 => all targeted suites passed. Any compile error or test failure in
# these suites exits non-zero and fails the guard.
set -uo pipefail

REPO_DIR="${REPO_DIR:-/repo/red}"

# Mirror the image's pinned Rust toolchain env (Dockerfile block 3). The image
# baked `cargo build --locked --tests`, so this run is incremental.
export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
export PATH="${CARGO_HOME}/bin:${PATH}"

cd "$REPO_DIR" || { echo "ERROR: ${REPO_DIR} missing" >&2; exit 1; }

echo "regression-guard: rustc=$(rustc --version 2>&1 | head -1)"
echo "regression-guard: cargo=$(cargo --version 2>&1 | head -1)"
echo "regression-guard: running single-server language-subsystem suites..."

# Run the two pre-existing single-server LSP integration binaries. --locked
# keeps the dependency graph pinned; a single test thread keeps the editor's
# scripted-mock timing deterministic.
cargo test --locked --test lsp_lazy --test lsp_save -- --test-threads=1
status=$?

if [ "$status" -eq 0 ]; then
    echo "regression-guard: PASS — single-server suites green."
else
    echo "regression-guard: FAIL — single-server suites did not pass (exit ${status})." >&2
fi
exit "$status"
