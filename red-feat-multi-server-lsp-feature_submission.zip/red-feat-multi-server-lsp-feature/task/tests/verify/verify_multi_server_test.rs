// Behavioral f2p verifier for the multi-attachment language-server change.
//
// Drives a real editor backed by the production language-server manager wired
// to TWO scripted stdin/stdout language servers that both claim the same file
// extension. Everything is in-process: the two "servers" are tiny stdlib
// Python programs this test writes to a temp dir and launches through the
// manager's normal launch path, so no real toolchain is required.
//
// Four editor-observable outcomes are asserted:
//
//   1. Lifecycle fan-out — opening a document that two configured servers both
//      claim makes BOTH servers receive the open notification (each server
//      records the methods it saw to a shared log file). A change that only
//      resolves-to-all but still drives the lifecycle through a single server
//      leaves the second server with no open notification and fails here.
//
//   2. Per-server diagnostic independence — with both servers attached and each
//      publishing its OWN distinct diagnostic for the file, the editor's
//      displayed diagnostic set is the union of both servers' diagnostics. A
//      change that keys diagnostics by document URI alone (one producer per
//      file) lets the second server's publish overwrite the first, so only one
//      message survives and this fails. Diagnostics are observed through the
//      editor's own diagnostic-read surface by their messages, never by any
//      producer-key symbol or storage shape, so any ownership representation
//      that keeps the two sets independent passes.
//
//   3. Single-answer determinism — a single-result feature (hover) on a
//      document matched by two servers returns exactly ONE server's response,
//      and the same server's response on every repeated call. A naive
//      implementation that broadcasts the request to all servers and takes
//      whatever arrives first produces a non-deterministic result that varies
//      across calls; this test catches that by repeating the hover 20 times and
//      asserting the result is always identical and always from exactly one
//      server. Which server answers is not asserted — any deterministic single-
//      pick design passes.
//
//   4. Failure isolation — when one attached server fails (exits), only that
//      server's diagnostics are removed from the editor's displayed set; the
//      surviving server's diagnostics must remain. A "clear all diagnostics on
//      server failure" implementation removes both servers' diagnostics and
//      fails this test.
//
// All assertions are on outcomes a user of the editor can see (which servers a
// document talks to; which diagnostics are shown; what hover text appears), not
// on internal types, method names, or storage chosen by the implementation.

use std::collections::HashMap;
use std::time::Duration;

use red::{
    agent_tools::{EditorToolCall, EditorToolRequest, LspDiagnosticScope},
    buffer::Buffer,
    config::{Config, LanguageServerConfig, LspConfig},
    editor::{Action, Editor},
    lsp::LspManager,
    test_utils::EditorTestExt,
    theme::Theme,
};

// A minimal LSP server over stdio. It records every inbound method to the log
// file named by $DIAG_EVENTS (prefixed with its own $DIAG_NAME), advertises
// pull-diagnostic support, and answers a diagnostic request with a single
// problem whose message embeds its own name — so the two servers' diagnostics
// are distinguishable in the editor's merged set.
const SERVER_PY: &str = r#"import json, os, sys, pathlib
events = pathlib.Path(os.environ["DIAG_EVENTS"]); name = os.environ.get("DIAG_NAME", "srv")
def read():
    headers = {}
    while True:
        line = sys.stdin.buffer.readline()
        if not line:
            return None
        if line in (b"\r\n", b"\n"):
            break
        k, v = line.decode().split(":", 1)
        headers[k.lower()] = v.strip()
    return json.loads(sys.stdin.buffer.read(int(headers["content-length"])))
def send(m):
    b = json.dumps(m).encode()
    sys.stdout.buffer.write(b"Content-Length: %d\r\n\r\n" % len(b) + b)
    sys.stdout.buffer.flush()
def problem():
    return {"range": {"start": {"line": 0, "character": 0}, "end": {"line": 0, "character": 1}},
            "severity": 1, "source": name, "message": name + "-problem"}
while True:
    m = read()
    if m is None:
        break
    method = m.get("method")
    with events.open("a") as o:
        o.write(name + " " + str(method) + "\n")
    if method == "initialize":
        send({"jsonrpc": "2.0", "id": m["id"], "result": {"capabilities": {
            "textDocumentSync": 1,
            "diagnosticProvider": {"interFileDependencies": False, "workspaceDiagnostics": False}}}})
    elif method == "textDocument/diagnostic":
        send({"jsonrpc": "2.0", "id": m["id"], "result": {"kind": "full", "items": [problem()]}})
    elif method == "shutdown":
        send({"jsonrpc": "2.0", "id": m["id"], "result": None})
    elif method == "exit":
        break
    elif "id" in m:
        send({"jsonrpc": "2.0", "id": m["id"], "result": None})
"#;

// A server that advertises hover support in addition to pull diagnostics.
// Returns a hover response whose contents embed the server's own name so the
// two servers' hover payloads are distinguishable in the rendered output.
// Also records events and returns its own diagnostic on a diagnostic request.
const HOVER_SERVER_PY: &str = r#"import json, os, sys, pathlib
events = pathlib.Path(os.environ["DIAG_EVENTS"]); name = os.environ.get("DIAG_NAME", "srv")
def read():
    headers = {}
    while True:
        line = sys.stdin.buffer.readline()
        if not line:
            return None
        if line in (b"\r\n", b"\n"):
            break
        k, v = line.decode().split(":", 1)
        headers[k.lower()] = v.strip()
    return json.loads(sys.stdin.buffer.read(int(headers["content-length"])))
def send(m):
    b = json.dumps(m).encode()
    sys.stdout.buffer.write(b"Content-Length: %d\r\n\r\n" % len(b) + b)
    sys.stdout.buffer.flush()
def problem():
    return {"range": {"start": {"line": 0, "character": 0}, "end": {"line": 0, "character": 1}},
            "severity": 1, "source": name, "message": name + "-problem"}
while True:
    m = read()
    if m is None:
        break
    method = m.get("method")
    with events.open("a") as o:
        o.write(name + " " + str(method) + "\n")
    if method == "initialize":
        send({"jsonrpc": "2.0", "id": m["id"], "result": {"capabilities": {
            "textDocumentSync": 1,
            "hoverProvider": True,
            "diagnosticProvider": {"interFileDependencies": False, "workspaceDiagnostics": False}}}})
        with events.open("a") as o:
            o.write(name + " initialized\n")
    elif method == "textDocument/hover":
        send({"jsonrpc": "2.0", "id": m["id"], "result": {
            "contents": {"kind": "plaintext", "value": name + "-hover-text"}}})
    elif method == "textDocument/diagnostic":
        send({"jsonrpc": "2.0", "id": m["id"], "result": {"kind": "full", "items": [problem()]}})
    elif method == "shutdown":
        send({"jsonrpc": "2.0", "id": m["id"], "result": None})
    elif method == "exit":
        break
    elif "id" in m:
        send({"jsonrpc": "2.0", "id": m["id"], "result": None})
"#;

// A server that exits after publishing its first diagnostic response.
// Used for the failure-isolation test: one server exits mid-session; the
// surviving server's diagnostic must remain in the editor's displayed set.
const EXITING_SERVER_PY: &str = r#"import json, os, sys, pathlib
events = pathlib.Path(os.environ["DIAG_EVENTS"]); name = os.environ.get("DIAG_NAME", "srv")
def read():
    headers = {}
    while True:
        line = sys.stdin.buffer.readline()
        if not line:
            return None
        if line in (b"\r\n", b"\n"):
            break
        k, v = line.decode().split(":", 1)
        headers[k.lower()] = v.strip()
    return json.loads(sys.stdin.buffer.read(int(headers["content-length"])))
def send(m):
    b = json.dumps(m).encode()
    sys.stdout.buffer.write(b"Content-Length: %d\r\n\r\n" % len(b) + b)
    sys.stdout.buffer.flush()
def problem():
    return {"range": {"start": {"line": 0, "character": 0}, "end": {"line": 0, "character": 1}},
            "severity": 1, "source": name, "message": name + "-problem"}
diag_sent = False
while True:
    m = read()
    if m is None:
        break
    method = m.get("method")
    with events.open("a") as o:
        o.write(name + " " + str(method) + "\n")
    if method == "initialize":
        send({"jsonrpc": "2.0", "id": m["id"], "result": {"capabilities": {
            "textDocumentSync": 1,
            "diagnosticProvider": {"interFileDependencies": False, "workspaceDiagnostics": False}}}})
        with events.open("a") as o:
            o.write(name + " initialized\n")
    elif method == "textDocument/diagnostic":
        send({"jsonrpc": "2.0", "id": m["id"], "result": {"kind": "full", "items": [problem()]}})
        if not diag_sent:
            diag_sent = True
            # Exit after the first diagnostic response to simulate a server crash.
            # Give the Rust process a moment to read the response from the pipe
            # before we close, then exit hard without running Python cleanup.
            import time; time.sleep(3.0)
            os._exit(0)
    elif method == "shutdown":
        send({"jsonrpc": "2.0", "id": m["id"], "result": None})
    elif method == "exit":
        break
    elif "id" in m:
        send({"jsonrpc": "2.0", "id": m["id"], "result": None})
"#;

fn server(script: &str, name: &str, events: &str, exts: &[&str]) -> LanguageServerConfig {
    let mut env = HashMap::new();
    env.insert("DIAG_EVENTS".to_string(), events.to_string());
    env.insert("DIAG_NAME".to_string(), name.to_string());
    LanguageServerConfig {
        command: "python3".to_string(),
        args: vec![script.to_string()],
        language_id: "testlang".to_string(),
        file_extensions: exts.iter().map(|e| e.to_string()).collect(),
        filenames: Vec::new(),
        documents: Vec::new(),
        root_markers: Vec::new(),
        env,
        initialization_options: None,
        settings: None,
        workspace_name: None,
    }
}

fn diagnostics_request(path: &str) -> EditorToolRequest {
    EditorToolRequest {
        session_id: "agent-lsp".into(),
        call: EditorToolCall::LspDiagnostics {
            scope: LspDiagnosticScope::File,
            path: Some(path.to_string()),
            severity: None,
            source: None,
            code: None,
            range: None,
            offset: 0,
            limit: 100,
            expected_generation: None,
            refresh: true,
            wait_ms: 1500,
        },
    }
}

fn messages(result: &serde_json::Value) -> Vec<String> {
    result["items"]
        .as_array()
        .map(|items| {
            items
                .iter()
                .filter_map(|item| item["message"].as_str().map(str::to_string))
                .collect()
        })
        .unwrap_or_default()
}

async fn build_two_server_editor(
    dir: &std::path::Path,
    events: &str,
    script: &str,
) -> Editor {
    let mut config = Config::default();
    config.show_diagnostics = true;
    config.lsp = LspConfig {
        enabled: true,
        format_on_save: false,
        // "alpha" sorts before "beta"; both claim the same extension.
        servers: HashMap::from([
            ("alpha".to_string(), server(script, "alpha", events, &["ts"])),
            ("beta".to_string(), server(script, "beta", events, &["ts"])),
        ]),
    };
    let file = dir.join("sample.ts");
    std::fs::write(&file, "x\n").unwrap();
    let lsp = Box::new(LspManager::new(config.lsp.clone()));
    let mut editor = Editor::test_with_size(
        lsp,
        80,
        24,
        config,
        Theme::default(),
        vec![Buffer::new(
            Some(file.to_string_lossy().into_owned()),
            "x\n".to_string(),
        )],
    )
    .unwrap();
    editor.test_disable_terminal_output();
    editor.test_set_agent_root(dir);
    editor
}

#[tokio::test]
async fn open_document_fans_lifecycle_out_to_every_matching_server() {
    let dir = tempfile::tempdir().unwrap();
    let events = dir.path().join("events.log");
    std::fs::write(&events, "").unwrap();
    let ev = events.display().to_string();
    let script = dir.path().join("server.py");
    std::fs::write(&script, SERVER_PY).unwrap();

    let mut editor =
        build_two_server_editor(dir.path(), &ev, &script.to_string_lossy()).await;
    editor
        .test_ensure_current_buffer_lsp_opened()
        .await
        .unwrap();

    // Let both servers start and process the open notification.
    let mut both_opened = false;
    for _ in 0..80 {
        let _ = editor.test_service_background().await;
        tokio::time::sleep(Duration::from_millis(20)).await;
        let log = std::fs::read_to_string(&events).unwrap_or_default();
        let alpha = log
            .lines()
            .any(|l| l.starts_with("alpha ") && l.contains("didOpen"));
        let beta = log
            .lines()
            .any(|l| l.starts_with("beta ") && l.contains("didOpen"));
        if alpha && beta {
            both_opened = true;
            break;
        }
    }

    let log = std::fs::read_to_string(&events).unwrap_or_default();
    assert!(
        both_opened,
        "both matching servers must receive the document open notification; \
         only one did, so lifecycle did not fan out to every attached server.\n\
         recorded events:\n{log}"
    );
}

#[tokio::test]
async fn each_servers_diagnostics_stay_independent_in_the_displayed_set() {
    let dir = tempfile::tempdir().unwrap();
    let events = dir.path().join("events.log");
    std::fs::write(&events, "").unwrap();
    let ev = events.display().to_string();
    let script = dir.path().join("server.py");
    std::fs::write(&script, SERVER_PY).unwrap();

    let mut editor =
        build_two_server_editor(dir.path(), &ev, &script.to_string_lossy()).await;
    editor
        .test_ensure_current_buffer_lsp_opened()
        .await
        .unwrap();

    // Wait until both servers have received the didOpen notification so each
    // server is active before diagnostics are requested.
    for _ in 0..80 {
        let _ = editor.test_service_background().await;
        tokio::time::sleep(Duration::from_millis(20)).await;
        let log = std::fs::read_to_string(&events).unwrap_or_default();
        let alpha_open = log.lines().any(|l| l.starts_with("alpha ") && l.contains("didOpen"));
        let beta_open = log.lines().any(|l| l.starts_with("beta ") && l.contains("didOpen"));
        if alpha_open && beta_open {
            break;
        }
    }

    // Ask every attached server for diagnostics, then read the displayed set.
    // A correct per-server ownership model keeps BOTH servers' problems; a
    // single-producer-per-URI model lets the second publish overwrite the
    // first, leaving only one.
    let mut displayed: Vec<String> = Vec::new();
    for _ in 0..25 {
        let _ = editor.test_execute_action(Action::RefreshDiagnostics).await;
        let result = editor
            .test_run_agent_editor_tool(diagnostics_request("sample.ts"))
            .await
            .unwrap();
        displayed = messages(&result);
        if displayed.iter().any(|m| m.contains("alpha-problem"))
            && displayed.iter().any(|m| m.contains("beta-problem"))
        {
            break;
        }
        tokio::time::sleep(Duration::from_millis(30)).await;
    }

    assert!(
        displayed.iter().any(|m| m.contains("alpha-problem")),
        "the first server's diagnostic is missing from the displayed set — \
         another server's publish overwrote it instead of being kept \
         independent. displayed: {displayed:?}"
    );
    assert!(
        displayed.iter().any(|m| m.contains("beta-problem")),
        "the second server's diagnostic is missing from the displayed set — \
         another server's publish overwrote it instead of being kept \
         independent. displayed: {displayed:?}"
    );
}

#[tokio::test]
async fn single_answer_feature_returns_one_deterministic_result() {
    // Two servers both advertising hover capability, each returning a DISTINCT
    // hover payload that embeds the server's own name. Triggering hover 20 times
    // under identical conditions must always produce the same single-server
    // result — never a merge/concatenation of both, and never alternating between
    // the two.
    //
    // A naive "fan the request to all servers, take whatever arrives first"
    // implementation produces a non-deterministic result that will vary across
    // repeated calls (race between alpha and beta responses). A correct
    // implementation routes the request to exactly one deterministic server and
    // always returns that server's payload. Which server is chosen is not
    // asserted — any deterministic single-pick design passes.
    let dir = tempfile::tempdir().unwrap();
    let events = dir.path().join("events.log");
    std::fs::write(&events, "").unwrap();
    let ev = events.display().to_string();
    let script = dir.path().join("hover_server.py");
    std::fs::write(&script, HOVER_SERVER_PY).unwrap();

    // Build editor with two hover-capable servers.
    let mut config = Config::default();
    config.show_diagnostics = true;
    config.lsp = LspConfig {
        enabled: true,
        format_on_save: false,
        servers: HashMap::from([
            ("alpha".to_string(), server(&script.to_string_lossy(), "alpha", &ev, &["ts"])),
            ("beta".to_string(),  server(&script.to_string_lossy(), "beta",  &ev, &["ts"])),
        ]),
    };
    let file = dir.path().join("sample.ts");
    std::fs::write(&file, "x\n").unwrap();
    let lsp = Box::new(LspManager::new(config.lsp.clone()));
    let mut editor = Editor::test_with_size(
        lsp,
        80,
        24,
        config,
        Theme::default(),
        vec![Buffer::new(
            Some(file.to_string_lossy().into_owned()),
            "x\n".to_string(),
        )],
    )
    .unwrap();
    editor.test_disable_terminal_output();
    editor.test_set_agent_root(dir.path());

    editor.test_ensure_current_buffer_lsp_opened().await.unwrap();

    // Wait for both servers to initialize so both advertise hover capability.
    for _ in 0..80 {
        let _ = editor.test_service_background().await;
        tokio::time::sleep(Duration::from_millis(20)).await;
        let log = std::fs::read_to_string(&events).unwrap_or_default();
        if log.contains("alpha initialized") && log.contains("beta initialized") {
            break;
        }
    }

    // Trigger hover 20 times, collecting the rendered rows each time.
    // The hover dialog appears in the editor frame; we read the rows to
    // find which server's payload is shown.
    let mut observed: Vec<String> = Vec::new();
    for _ in 0..20 {
        // Dismiss any existing dialog before triggering a fresh hover.
        let _ = editor.test_execute_action(Action::CloseDialog).await;
        // Trigger hover and pump the background loop until a response arrives.
        let _ = editor.test_execute_action(Action::Hover).await;
        let mut got_hover = false;
        for _ in 0..60 {
            let _ = editor.test_service_background().await;
            tokio::time::sleep(Duration::from_millis(20)).await;
            // Check all rendered rows for hover text from either server.
            let mut row_text = String::new();
            for y in 0..24 {
                if let Ok(row) = editor.test_render_row(y) {
                    if row.contains("hover-text") {
                        row_text = row.trim().to_string();
                        got_hover = true;
                        break;
                    }
                }
            }
            if got_hover {
                observed.push(row_text);
                break;
            }
        }
        if !got_hover {
            // No hover response yet; record absence so we notice if hover never fires.
            observed.push(String::new());
        }
    }

    // Filter out any empty observations (hover may not fire on every trigger if
    // the dialog is already open — allow up to 5 missed observations).
    let non_empty: Vec<&String> = observed.iter().filter(|s| !s.is_empty()).collect();
    assert!(
        non_empty.len() >= 15,
        "hover produced a response on only {}/{} tries — the server is not responding to hover requests",
        non_empty.len(),
        observed.len()
    );

    // Each observed result must come from exactly one server (alpha XOR beta),
    // never from both (concatenation/merge would contain both substrings).
    for (i, result) in non_empty.iter().enumerate() {
        let has_alpha = result.contains("alpha-hover-text");
        let has_beta  = result.contains("beta-hover-text");
        assert!(
            has_alpha || has_beta,
            "hover result #{i} does not contain either server's payload — \
             the result is empty or unrecognised: {result:?}"
        );
        assert!(
            !(has_alpha && has_beta),
            "hover result #{i} contains BOTH servers' payloads — \
             the implementation is merging or concatenating single-answer \
             results instead of routing to one deterministic server: {result:?}"
        );
    }

    // All non-empty results must be identical — the same server's payload
    // every time. A broadcast-and-take-first-responder implementation will
    // alternate between alpha and beta across calls.
    let first = non_empty[0];
    for (i, result) in non_empty.iter().enumerate().skip(1) {
        assert_eq!(
            *result, first,
            "hover result #{i} differs from the first result — the implementation \
             is returning a non-deterministic answer (different server each call). \
             first={first:?}, got={result:?}"
        );
    }
}

#[tokio::test]
async fn surviving_server_diagnostics_persist_after_peer_failure() {
    // When one attached server fails (exits), only that server's diagnostics
    // are removed from the editor's displayed set. The surviving server's
    // diagnostics must remain — a "clear all diagnostics on server failure"
    // implementation would remove both servers' diagnostics and fail this test.
    //
    // Setup: alpha uses the standard server (stays alive throughout); beta uses
    // a self-exiting server that quits after publishing its first diagnostic.
    // After both servers have published and beta has exited, the editor must
    // still show alpha's diagnostic.
    let dir = tempfile::tempdir().unwrap();
    let events = dir.path().join("events.log");
    std::fs::write(&events, "").unwrap();
    let ev = events.display().to_string();

    // alpha: the long-lived server.
    let alpha_script = dir.path().join("alpha_server.py");
    std::fs::write(&alpha_script, SERVER_PY).unwrap();
    // beta: exits after publishing its first diagnostic.
    let beta_script = dir.path().join("beta_server.py");
    std::fs::write(&beta_script, EXITING_SERVER_PY).unwrap();

    let mut config = Config::default();
    config.show_diagnostics = true;
    config.lsp = LspConfig {
        enabled: true,
        format_on_save: false,
        servers: HashMap::from([
            ("alpha".to_string(), server(&alpha_script.to_string_lossy(), "alpha", &ev, &["ts"])),
            ("beta".to_string(),  server(&beta_script.to_string_lossy(), "beta",  &ev, &["ts"])),
        ]),
    };
    let file = dir.path().join("sample.ts");
    std::fs::write(&file, "x\n").unwrap();
    let lsp = Box::new(LspManager::new(config.lsp.clone()));
    let mut editor = Editor::test_with_size(
        lsp,
        80,
        24,
        config,
        Theme::default(),
        vec![Buffer::new(
            Some(file.to_string_lossy().into_owned()),
            "x\n".to_string(),
        )],
    )
    .unwrap();
    editor.test_disable_terminal_output();
    editor.test_set_agent_root(dir.path());

    editor.test_ensure_current_buffer_lsp_opened().await.unwrap();

    // Wait for both servers to have received the open notification. Both scripts
    // log every inbound method, so checking for "textDocument/didOpen" in each
    // server's log proves the editor has opened the document with that server.
    for _ in 0..80 {
        let _ = editor.test_service_background().await;
        tokio::time::sleep(Duration::from_millis(20)).await;
        let log = std::fs::read_to_string(&events).unwrap_or_default();
        let alpha_opened = log.lines().any(|l| l.starts_with("alpha ") && l.contains("didOpen"));
        let beta_opened = log.lines().any(|l| l.starts_with("beta ") && l.contains("didOpen"));
        if alpha_opened && beta_opened {
            break;
        }
    }

    // Step 1: Pump diagnostics until both servers have published (beta exits
    // after its first diagnostic response, so beta-problem appearing confirms
    // beta ran and then exited).
    let mut beta_published = false;
    let file_path_str = file.to_string_lossy().into_owned();
    let file_name = file.file_name().unwrap().to_string_lossy().into_owned();
    for _ in 0..40 {
        let _ = editor.test_execute_action(Action::RefreshDiagnostics).await;
        let result = editor
            .test_run_agent_editor_tool(diagnostics_request(&file_name))
            .await
            .unwrap();
        let diags = messages(&result);
        if diags.iter().any(|m| m.contains("beta-problem")) {
            beta_published = true;
            break;
        }
        tokio::time::sleep(Duration::from_millis(50)).await;
    }
    assert!(
        beta_published,
        "beta server never published its diagnostic — the test could not \
         proceed to observe post-failure isolation"
    );

    // Step 2: Give the editor time to detect that beta has exited. The manager
    // will detect the closed pipe on the next background poll and should remove
    // beta's diagnostics from the displayed set.
    tokio::time::sleep(Duration::from_millis(200)).await;
    for _ in 0..40 {
        let _ = editor.test_service_background().await;
        tokio::time::sleep(Duration::from_millis(50)).await;
    }

    // Step 3: After beta failure, alpha's diagnostic must still be present.
    // We poll a few more times to let any failure-handling settle.
    let mut alpha_still_shown = false;
    for _ in 0..20 {
        let _ = editor.test_execute_action(Action::RefreshDiagnostics).await;
        let result = editor
            .test_run_agent_editor_tool(diagnostics_request(&file_name))
            .await
            .unwrap();
        let diags = messages(&result);
        if diags.iter().any(|m| m.contains("alpha-problem")) {
            alpha_still_shown = true;
            break;
        }
        tokio::time::sleep(Duration::from_millis(50)).await;
    }

    assert!(
        alpha_still_shown,
        "alpha's diagnostic disappeared after beta server exited — \
         the implementation is clearing ALL diagnostics on a server failure \
         instead of removing only the failed server's diagnostics. \
         A correct implementation should drop only beta's diagnostics and \
         keep alpha's independent set."
    );

    // The file path variable must be used to silence an unused-variable warning.
    let _ = file_path_str;
}
