## Task

When lage runs inside GitHub Actions, the console output is a flat wall of text. Each package's task logs don't collapse into expandable groups, and build failures aren't surfaced as GitHub's inline error annotations. We already give runs this CI-native treatment on Azure Pipelines, and we want the equivalent for GitHub Actions: grouped logs and error annotations in GitHub's own format, kicking in automatically when a run is executing inside GitHub Actions. GitHub's log-grouping and annotation syntax is specified in their workflow-commands documentation. The work is additive on the GitHub side.

## User stories / requirements

- When a run executes inside GitHub Actions, lage produces its GitHub Actions-native grouped console output on its own, with no flag required; when a run executes inside Azure Pipelines instead, it produces the Azure output. If the environment looks like both CI systems at once, the GitHub Actions output wins.
- In the GitHub Actions output, each package's task logs are wrapped in a collapsible group labeled with the package, task, final status, and how long it took, closing after the task's lines. The lines inside read as lage's existing grouped output. With grouping off, the same lines appear inline with no group markers.
- When a run ends with a failure, the GitHub Actions output finishes with a collapsible summary section that is explicitly closed, and each failed task is reported as a GitHub error annotation: a titled annotation naming the package and task, followed by that task's captured failure log lines.
- The GitHub Actions output can also be requested by name, under both a short and a long alias. Those names appear in lage's list of supported reporters, so asking for a reporter that doesn't exist reports them among the valid choices.
- Selecting and running the Azure Pipelines output continues to behave exactly as it does today, in both what gets chosen and what gets written.
