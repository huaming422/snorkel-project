#!/usr/bin/env bash
# test-setup.sh — environment bootstrap for the verifier / validation agent.
# Sourced (not exec'd) by the harbor verifier runner so env vars and anything
# else stay alive for the subsequent jest runs.
#
# Idempotent. The image already materializes node_modules at the base commit
# via `yarn install --immutable` (image Dockerfile step 7); we re-run it as a
# guard only if an agent erased node_modules. The oracle (PR 1028) touches no
# manifest or lockfile, so the base-commit install is the complete closure —
# there is nothing extra to fetch here.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/lage}"
cd "$REPO_DIR"

node --version

# Restore workspace deps if an agent removed them (offline-first against the
# image bake, logged online fallback). `--immutable` is yarn 4's frozen-lockfile.
if [ ! -d "node_modules" ] || [ ! -d "node_modules/memory-streams" ]; then
    echo "[test-setup] node_modules missing — restoring deps offline..."
    if YARN_ENABLE_NETWORK=false yarn install --immutable > /tmp/yarn-install.log 2>&1; then
        echo "[offline-first] yarn install satisfied from image cache"
    else
        echo "[test-setup] offline install failed; retrying with network (fallback)"
        tail -40 /tmp/yarn-install.log || true
        yarn install --immutable
    fi
fi

# Quick sanity check that the reporters test toolchain is present.
test -f node_modules/memory-streams/package.json \
    || { echo "[test-setup] ERROR: memory-streams not installed" >&2; exit 1; }

echo "[test-setup] ready: ${REPO_DIR}"
