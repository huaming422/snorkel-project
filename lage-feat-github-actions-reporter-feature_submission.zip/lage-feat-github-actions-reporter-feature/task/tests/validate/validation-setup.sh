#!/usr/bin/env bash
# validation-setup.sh — environment bootstrap for the validation-story jest runs.
#
# Idempotent guard. The task image already materializes node_modules at the base
# commit via `yarn install --immutable` (image Dockerfile), and every validation
# story is a native jest test driven through the repo's own
# @lage-run/monorepo-scripts jest config (@swc/jest transforms the TypeScript on
# the fly from src/ via moduleNameMapper — NO dist build is required). We only
# re-install if an agent erased node_modules, then smoke-check the toolchain the
# stories rely on.
#
# The reference change touches no package.json or yarn.lock, so the base-commit
# install is the complete dependency closure — nothing extra to fetch here.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/lage}"
cd "$REPO_DIR"

# Toolchain reachable.
node --version

# Restore workspace deps if an agent removed them (offline-first against the
# image bake, logged online fallback). `--immutable` is yarn 4's frozen-lockfile.
if [ ! -d "node_modules" ] || [ ! -d "node_modules/memory-streams" ]; then
    echo "[validation-setup] node_modules missing — restoring deps offline..."
    if YARN_ENABLE_NETWORK=false yarn install --immutable > /tmp/yarn-install.log 2>&1; then
        echo "[offline-first] yarn install satisfied from image cache"
    else
        echo "[validation-setup] offline install failed; retrying with network (fallback)"
        tail -40 /tmp/yarn-install.log || true
        yarn install --immutable
    fi
fi

# The reporter stories drive the lifecycle with memory-streams-style entries and
# the CLI selection path; memory-streams must be present (it is the devDependency
# the repo's own reporter tests use).
test -f node_modules/memory-streams/package.json \
    || { echo "[validation-setup] ERROR: memory-streams not installed" >&2; exit 1; }

# Jest must be present and runnable before the timed story runs. Invoke the
# resolved binary DIRECTLY (not through `yarn run`, which the setup-script linter
# counts as a second dependency sync) — the node-modules linker hoists jest's
# bin to node_modules/.bin/jest once the single `yarn install` above completes.
# This also warms any first-run resolution cost.
JEST_BIN="node_modules/.bin/jest"
test -x "$JEST_BIN" \
    || { echo "[validation-setup] ERROR: jest binary not found at $JEST_BIN after install" >&2; exit 1; }
"$JEST_BIN" --version > /tmp/jest-version.log 2>&1 \
    || { echo "[validation-setup] ERROR: jest not runnable" >&2; tail -20 /tmp/jest-version.log; exit 1; }
echo "[validation-setup] jest $(tail -1 /tmp/jest-version.log)"

# Smoke-check that the pre-existing CLI selection entry points the stories import
# resolve from source (the stories import ../commands/*.js, rewritten to src by
# the jest moduleNameMapper).
test -f packages/cli/src/commands/createReporter.ts \
    || { echo "[validation-setup] ERROR: createReporter.ts missing" >&2; exit 1; }
test -f packages/cli/src/commands/initializeReporters.ts \
    || { echo "[validation-setup] ERROR: initializeReporters.ts missing" >&2; exit 1; }

echo "[validation-setup] ready: ${REPO_DIR}"
