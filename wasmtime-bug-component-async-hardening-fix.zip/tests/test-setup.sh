#!/usr/bin/env bash
# Pre-warm the integration-test build so the verifier reuses the compiled
# target dir instead of paying a cold compile. The image already baked the
# dependency closure and a no-run build of the root crate's integration target
# at the authoring commit, so this is incremental: it recompiles only the
# crates the solving agent actually edited, then compiles any new code the
# verifier adds.
set -euo pipefail

cd /repo/wasmtime

# Build (but do not run) the root crate's integration targets. Offline-first:
# every dependency is already vendored in CARGO_HOME from the image build, so
# this needs no network. --locked keeps the resolver honest against the baked
# Cargo.lock.
#
# Two targets are warmed:
#  * `all`  — the bulk of the dev-dependency graph (the runtime under test with
#    its full dev feature set, plus the async executor and combinator crates).
#  * `wast` — additionally compiles the text-format driver crate, which the
#    reward's standalone target links but `all` does not, so the verifier's own
#    compile stays short.
cargo test --no-run --locked --test all
cargo test --no-run --locked --test wast

echo "test-setup: integration-test binaries compiled"
