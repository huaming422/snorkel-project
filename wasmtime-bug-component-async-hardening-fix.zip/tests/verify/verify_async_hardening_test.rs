// Behavioral checks for the component-model async runtime hardening work.
//
// Everything here drives the pre-existing public `wasmtime::component` API
// (plus the public `wasmtime_wast` text-format driver) rather than any
// runtime-internal helper, so the checks stay agnostic to how the three
// fixes are actually implemented. In particular the zero-length check never
// inspects the return *type* of the direct-buffer accessors — it only drives
// the whole component and asserts the call does not abort the host.
//
// This file is compiled and run as a standalone integration-test binary
// against the root package (whose dev-dependencies already enable the
// component-model async surface and the text-format driver), so no extra
// crate features are required.

use std::future::{self, Future};
use std::mem;
use std::pin::{Pin, pin};
use std::task::{Context, Poll, Waker};

use wasmtime::component::{
    Component, Destination, Instance, Linker, Source, StreamConsumer, StreamProducer, StreamReader,
    StreamResult, TypedFunc, VecBuffer,
};
use wasmtime::{Config, Engine, Result, Store, StoreContextMut, Trap};
use wasmtime_wast::{Async, SpectestConfig, WastContext};

// ---------------------------------------------------------------------------
// Behavior: zero-length stream reads and writes are no-ops
//
// A zero-length stream read and a zero-length stream write whose guest pointer
// is out of range must complete as no-ops instead of aborting the host. The
// guest issues both a zero-length `stream.read` and a zero-length
// `stream.write` at address 0xFFFFFF (far past the one-page linear memory),
// and the host-side producer/consumer poke the direct-buffer accessors for
// both the destination (write) and source (read) directions. Before the fix
// either direction aborts the process.
// ---------------------------------------------------------------------------

#[tokio::test]
#[cfg_attr(miri, ignore)]
async fn zero_length_reads_and_writes() -> Result<()> {
    let engine = Engine::default();
    let component = Component::new(
        &engine,
        r#"
        (component
            (core module $libc (memory (export "mem") 1))
            (core instance $libc (instantiate $libc))

            (core module $a
                (import "" "stream.new" (func $stream.new (result i64)))
                (import "" "stream.read" (func $stream.read (param i32 i32 i32) (result i32)))
                (import "" "stream.write" (func $stream.write (param i32 i32 i32) (result i32)))
                (import "" "waitable-set.new" (func $waitable-set.new (result i32)))
                (import "" "waitable.join" (func $waitable.join (param i32 i32)))
                (import "" "task.return" (func $task.return (param i32)))

                (func (export "a") (param $stream i32) (result i32)
                    (local $set i32)
                    (local $tmp i64)
                    (local $stream-writer i32)
                    (local $stream-reader i32)
                    (local $ret i32)

                    (local.set $ret (call $stream.read (local.get $stream) (i32.const 0xFFFFFF) (i32.const 0)))
                    (if (i32.ne (local.get $ret) (i32.const 1 (; DROPPED ;))) (then unreachable))

                    (local.set $tmp (call $stream.new))
                    (local.set $stream-writer (i32.wrap_i64 (i64.shr_u (local.get $tmp) (i64.const 32))))
                    (local.set $stream-reader (i32.wrap_i64 (local.get $tmp)))

                    (call $task.return (local.get $stream-reader))

                    (local.set $ret (call $stream.write (local.get $stream-writer) (i32.const 0xFFFFFF) (i32.const 0)))
                    (if (i32.ne (local.get $ret) (i32.const -1 (; BLOCKED ;))) (then unreachable))

                    (local.set $set (call $waitable-set.new))
                    (call $waitable.join (local.get $stream-writer) (local.get $set))
                    (i32.or (i32.const 2 (; WAIT ;)) (i32.shl (local.get $set) (i32.const 4)))
                )

                (func (export "a-callback") (param i32 i32 i32) (result i32)
                    (i32.const 0 (; EXIT ;))
                )
            )

            (type $stream (stream u8))
            (canon stream.new $stream (core func $stream.new))
            (canon stream.read $stream async (memory (core memory $libc "mem")) (core func $stream.read))
            (canon stream.write $stream async (memory (core memory $libc "mem")) (core func $stream.write))
            (canon waitable-set.new (core func $waitable-set.new))
            (canon waitable.join (core func $waitable.join))
            (canon task.return (result $stream) (core func $task.return))

            (core instance $a (instantiate $a
                (with "" (instance
                    (export "stream.new" (func $stream.new))
                    (export "stream.read" (func $stream.read))
                    (export "stream.write" (func $stream.write))
                    (export "waitable-set.new" (func $waitable-set.new))
                    (export "waitable.join" (func $waitable.join))
                    (export "task.return" (func $task.return))
                ))
            ))

            (func (export "a") async (param "stream" $stream) (result $stream)
                (canon lift (core func $a "a") async (callback (core func $a "a-callback")))
            )
        )
    "#,
    )?;
    let mut store = Store::new(&engine, ());
    let instance = Linker::new(&engine)
        .instantiate_async(&mut store, &component)
        .await?;
    let func =
        instance.get_typed_func::<(StreamReader<u8>,), (StreamReader<u8>,)>(&mut store, "a")?;

    struct Producer;

    impl StreamProducer<()> for Producer {
        type Item = u8;
        type Buffer = Option<u8>;

        fn poll_produce<'a>(
            self: Pin<&mut Self>,
            _cx: &mut Context<'_>,
            store: StoreContextMut<'a, ()>,
            destination: Destination<'a, u8, Option<u8>>,
            _finish: bool,
        ) -> Poll<Result<StreamResult>> {
            // Drive the write-side direct buffer for a zero-length, out-of-range
            // transfer. This used to abort the host; we only care that it does
            // not, so the accessor result is deliberately discarded (which also
            // keeps this agnostic to whether the accessor is fallible).
            let _ = destination.as_direct(store, 1).remaining();
            Poll::Ready(Ok(StreamResult::Dropped))
        }
    }

    struct Consumer;

    impl StreamConsumer<()> for Consumer {
        type Item = u8;

        fn poll_consume(
            self: Pin<&mut Self>,
            _cx: &mut Context<'_>,
            store: StoreContextMut<()>,
            source: Source<'_, u8>,
            _finish: bool,
        ) -> Poll<Result<StreamResult>> {
            // Drive the read-side direct buffer for the same zero-length,
            // out-of-range case.
            let _ = source.as_direct(store).remaining();
            Poll::Ready(Ok(StreamResult::Dropped))
        }
    }

    let input = StreamReader::<u8>::new(&mut store, Producer)?;
    store
        .run_concurrent(async |accessor| {
            let (output,) = func.call_concurrent(accessor, (input,)).await?;

            accessor.with(|access| output.pipe(access, Consumer))?;

            future::poll_fn(|cx| accessor.poll_no_interesting_tasks(cx)).await;

            Ok(())
        })
        .await?
}

// ---------------------------------------------------------------------------
// Behavior: dropping a queued async call must not panic the host
//
// Dropping the future returned by an async component call after the call has
// been admitted to a run queue (released from backpressure) but before it has
// executed must not abort the host. The call must instead fail safely.
//
// Three windows are exercised:
//  * `cancel_not_started`           — drop while the task sits in the run queue
//  * `drop_call_async_with_queued_start` — queued behind a trapping callback
//  * `drop_call_async_while_switch_pending` — dropped while the event loop has
//    yielded to the executor mid-guest-call (the switch-item window)
// All three abort the host before the fix.
// ---------------------------------------------------------------------------

#[tokio::test]
#[cfg_attr(miri, ignore)]
async fn cancel_not_started() -> Result<()> {
    let engine = Engine::default();
    let component = Component::new(
        &engine,
        r#"
        (component
            (import "a" (func $a))
            (core func $a (canon lower (func $a)))

            (core module $a
                (import "" "a" (func $a))
                (import "" "task.return" (func $task.return))
                (func (export "a") (result i32)
                    (call $a)
                    (call $task.return)
                    (i32.const 0 (; EXIT ;))
                )

                (func (export "a-callback") (param i32 i32 i32) (result i32)
                    unreachable
                )
            )
            (canon task.return (core func $task.return))
            (core instance $a (instantiate $a
                (with "" (instance
                    (export "a" (func $a))
                    (export "task.return" (func $task.return))
                ))
            ))
            (func (export "a") async (canon lift (core func $a "a") async (callback (core func $a "a-callback"))))
        )
    "#,
    )?;
    let mut store = Store::new(&engine, ());
    let mut linker = Linker::new(&engine);
    linker.root().func_wrap_async("a", move |_, ()| {
        Box::new(async move {
            for _ in 0..5 {
                tokio::task::yield_now().await;
            }

            Ok(())
        })
    })?;

    let instance = linker.instantiate_async(&mut store, &component).await?;
    let func = instance.get_typed_func::<(), ()>(&mut store, "a")?;

    // Start a call, which pushes a work item on the high-priority task queue.
    func.start_call_concurrent(&mut store, ())?;

    // Start and poll a second async call once, which pushes another work item
    // on the queue and then tries to drain it. The first call reaches our host
    // function, which yields back to us here. We then drop the second call's
    // future while it is still waiting in the queue, un-started. Before the fix
    // this aborts the host.
    let mut call = pin!(func.call_async(&mut store, ()));
    assert!(
        call.as_mut()
            .poll(&mut Context::from_waker(Waker::noop()))
            .is_pending()
    );
    drop(call);
    Ok(())
}

#[tokio::test]
#[cfg_attr(miri, ignore)]
async fn drop_call_async_with_queued_start() -> Result<()> {
    let mut config = Config::new();
    config.wasm_component_model_async(true);
    let engine = Engine::new(&config)?;

    let component = Component::new(
        &engine,
        r#"
(component
  (type $f (future))
  (core func $future.new (canon future.new $f))
  (core func $future.read (canon future.read $f async))
  (core func $future.write (canon future.write $f async))
  (core func $new (canon waitable-set.new))
  (core func $join (canon waitable.join))
  (core func $task-return (canon task.return))
  (core module $m
    (import "" "future.new" (func $future.new (result i64)))
    (import "" "future.read" (func $future.read (param i32 i32) (result i32)))
    (import "" "future.write" (func $future.write (param i32 i32) (result i32)))
    (import "" "new" (func $new (result i32)))
    (import "" "join" (func $join (param i32 i32)))
    (import "" "task-return" (func $task-return))
    (func (export "a") (result i32)
      (local $t i64) (local $r i32) (local $w i32) (local $s i32)
      (call $task-return)
      (local.set $t (call $future.new))
      (local.set $r (i32.wrap_i64 (local.get $t)))
      (local.set $w (i32.wrap_i64 (i64.shr_u (local.get $t) (i64.const 32))))
      (drop (call $future.read (local.get $r) (i32.const 0)))
      (local.set $s (call $new))
      (call $join (local.get $r) (local.get $s))
      (drop (call $future.write (local.get $w) (i32.const 0)))
      ;; WAIT on a set which already has a ready event, queueing a callback
      ;; invocation in the event loop.
      (i32.or (i32.const 2) (i32.shl (local.get $s) (i32.const 4))))
    (func (export "cb") (param i32 i32 i32) (result i32) unreachable)
    (func (export "b") (result i32)
      (call $task-return)
      (i32.const 0)))
  (core instance $i (instantiate $m (with "" (instance
    (export "future.new" (func $future.new))
    (export "future.read" (func $future.read))
    (export "future.write" (func $future.write))
    (export "new" (func $new))
    (export "join" (func $join))
    (export "task-return" (func $task-return))))))
  (func (export "a") async (canon lift (core func $i "a") async (callback (core func $i "cb"))))
  (func (export "b") async (canon lift (core func $i "b") async (callback (core func $i "cb"))))
)
        "#,
    )?;

    let mut store = Store::new(&engine, ());
    let linker = Linker::new(&engine);
    let instance = linker.instantiate_async(&mut store, &component).await?;
    let a = instance.get_typed_func::<(), ()>(&mut store, "a")?;
    let b = instance.get_typed_func::<(), ()>(&mut store, "b")?;
    a.call_async(&mut store, ()).await?;

    // The start of `b` is queued behind the pending callback for `a`, which
    // traps, so `b` never starts and its task is cancelled when the future
    // returned by `call_async` is dropped. The call must surface the trap
    // cleanly rather than aborting the host.
    let err = b.call_async(&mut store, ()).await.unwrap_err();
    assert_eq!(
        err.downcast_ref::<Trap>(),
        Some(&Trap::UnreachableCodeReached)
    );

    Ok(())
}

/// A component whose export `loop` calls `B`, which calls `C`, which calls
/// `D`, `n` times, all callback-lifted: each core function makes its async
/// calls in a loop within a single activation. It also exports `D`'s export
/// as `nop`.
const NESTED_CALLBACK_CALLS: &str = r#"(component
    (component $D
        (core func $task.return (canon task.return))
        (core module $m
            (import "" "task.return" (func $task.return))
            (func (export "f") (result i32)
                (call $task.return)
                (i32.const 0 (; EXIT ;)))
            (func (export "cb") (param i32 i32 i32) (result i32) unreachable))
        (core instance $i (instantiate $m
            (with "" (instance (export "task.return" (func $task.return))))))
        (func (export "f") async
            (canon lift (core func $i "f") async (callback (core func $i "cb"))))
    )
    (component $Caller
        (import "next" (func $next async))
        (core func $next (canon lower (func $next) async))
        (core func $task.return (canon task.return))
        (core module $m
            (import "" "next" (func $next (result i32)))
            (import "" "task.return" (func $task.return))
            (func (export "f") (param $n i32) (result i32)
                (loop $l
                    (if (i32.ne (call $next) (i32.const 2 (; RETURNED ;)))
                        (then unreachable))
                    (local.tee $n (i32.sub (local.get $n) (i32.const 1)))
                    br_if $l)
                (call $task.return)
                (i32.const 0 (; EXIT ;)))
            (func (export "cb") (param i32 i32 i32) (result i32) unreachable))
        (core instance $i (instantiate $m (with "" (instance
            (export "next" (func $next))
            (export "task.return" (func $task.return))))))
        (func (export "f") async (param "n" u32)
            (canon lift (core func $i "f") async (callback (core func $i "cb"))))
    )
    (component $Once
        (import "next" (func $next async (param "n" u32)))
        (core func $next (canon lower (func $next) async))
        (core func $task.return (canon task.return))
        (core module $m
            (import "" "next" (func $next (param i32) (result i32)))
            (import "" "task.return" (func $task.return))
            (func (export "f") (result i32)
                (if (i32.ne (call $next (i32.const 1)) (i32.const 2 (; RETURNED ;)))
                    (then unreachable))
                (call $task.return)
                (i32.const 0 (; EXIT ;)))
            (func (export "cb") (param i32 i32 i32) (result i32) unreachable))
        (core instance $i (instantiate $m (with "" (instance
            (export "next" (func $next))
            (export "task.return" (func $task.return))))))
        (func (export "f") async
            (canon lift (core func $i "f") async (callback (core func $i "cb"))))
    )
    (instance $d (instantiate $D))
    (instance $c (instantiate $Caller (with "next" (func $d "f"))))
    (instance $b (instantiate $Once (with "next" (func $c "f"))))
    (instance $a (instantiate $Caller (with "next" (func $b "f"))))
    (export "loop" (func $a "f"))
    (export "nop" (func $d "f"))
)"#;

/// A component exporting `nop`, an async callback-lifted export which returns
/// immediately.
const NOP: &str = r#"(component
    (core func $task.return (canon task.return))
    (core module $m
        (import "" "task.return" (func $task.return))
        (func (export "nop") (result i32)
            (call $task.return)
            (i32.const 0 (; EXIT ;)))
        (func (export "cb") (param i32 i32 i32) (result i32) unreachable))
    (core instance $i (instantiate $m
        (with "" (instance (export "task.return" (func $task.return))))))
    (func (export "nop") async
        (canon lift (core func $i "nop") async (callback (core func $i "cb"))))
)"#;

async fn instantiate_nested_calls(
    engine: &Engine,
    linker: &Linker<()>,
    other: &str,
) -> Result<(Store<()>, TypedFunc<(u32,), ()>, TypedFunc<(), ()>, Instance)> {
    let mut store = Store::new(engine, ());
    let nested = Component::new(engine, NESTED_CALLBACK_CALLS)?;
    let nested = Linker::new(engine)
        .instantiate_async(&mut store, &nested)
        .await?;
    let lp = nested.get_typed_func::<(u32,), ()>(&mut store, "loop")?;
    let nop = nested.get_typed_func::<(), ()>(&mut store, "nop")?;
    let other = Component::new(engine, other)?;
    let other = linker.instantiate_async(&mut store, &other).await?;
    Ok((store, lp, nop, other))
}

#[tokio::test]
#[cfg_attr(miri, ignore)]
async fn drop_call_async_while_switch_pending() -> Result<()> {
    use futures::FutureExt as _;

    let engine = Engine::new(Config::new().wasm_component_model_async(true))?;
    let linker = Linker::new(&engine);
    let mut dropped = 0;
    // Enough rounds that the event loop yields to the executor partway through
    // one of them, landing a dropped-but-queued call in the switch window.
    for n in [32, 64, 128, 256] {
        let (mut store, lp, nop, _) = instantiate_nested_calls(&engine, &linker, NOP).await?;
        drop(lp.start_call_concurrent(&mut store, (n,))?);
        if nop.call_async(&mut store, ()).now_or_never().is_some() {
            continue;
        }
        dropped += 1;
        // Dropping the queued-but-not-started call in the switch window must make
        // the next call fail cleanly instead of aborting the host. Assert the
        // clean failure (an error surfaces and we reach this line without an
        // abort) but deliberately do NOT pin the error text: the two valid
        // resolutions of this issue can word the surfaced error differently, and
        // the invariant under test is "fails cleanly, no host abort", not the
        // message.
        let _err = nop.call_async(&mut store, ()).await.unwrap_err();
    }
    assert!(dropped > 0);
    Ok(())
}

// ---------------------------------------------------------------------------
// Behavior: result lowering must block guest re-entry
//
// While the host lowers results across the canonical ABI, the guest must not
// be able to re-enter and call imports/intrinsics. The text below reaches the
// guest-callable `realloc` from every lowering path that matters — including
// lowering the results of a stream/future read and returning the string from
// `error-context.debug-message` — and in each case `realloc` tries to call a
// host import, which must trap ("cannot leave component instance"). The
// parameter-lowering paths at the top guard against a regression on the path
// that was already correct.
//
// This runs through the public text-format driver, which builds its own
// executor internally, so it is a plain `#[test]` rather than an async test.
// ---------------------------------------------------------------------------

const REALLOC_MAY_LEAVE_WAST: &str = r#"
;; host -> guest: lowering params into a sync-lifted export.
(component
  (import "host-return-two" (func $h (result u32)))
  (core func $h (canon lower (func $h)))
  (core module $Libc
    (import "" "h" (func $h (result i32)))
    (memory (export "mem") 1)
    (func (export "realloc") (param i32 i32 i32 i32) (result i32)
      (drop (call $h)) (i32.const 0)))
  (core instance $libc (instantiate $Libc (with "" (instance (export "h" (func $h))))))
  (core module $M (func (export "f") (param i32 i32)))
  (core instance $m (instantiate $M))
  (func (export "f") (param "s" string)
    (canon lift (core func $m "f")
      (memory (core memory $libc "mem")) (realloc (core func $libc "realloc"))))
)
(assert_trap (invoke "f" (str.const "x")) "cannot leave component instance")

;; host -> guest: lowering params into an async-lifted export.
(component
  (import "host-return-two" (func $h (result u32)))
  (core func $h (canon lower (func $h)))
  (core module $Libc
    (import "" "h" (func $h (result i32)))
    (memory (export "mem") 1)
    (func (export "realloc") (param i32 i32 i32 i32) (result i32)
      (drop (call $h)) (i32.const 0)))
  (core instance $libc (instantiate $Libc (with "" (instance (export "h" (func $h))))))
  (core module $M
    (func (export "f") (param i32 i32) (result i32) unreachable)
    (func (export "cb") (param i32 i32 i32) (result i32) unreachable))
  (core instance $m (instantiate $M))
  (func (export "f") async (param "s" string)
    (canon lift (core func $m "f") async (callback (core func $m "cb"))
      (memory (core memory $libc "mem")) (realloc (core func $libc "realloc"))))
)
(assert_trap (invoke "f" (str.const "x")) "cannot leave component instance")

;; host import -> guest: lowering a host function's results.
(component
  (import "host-return-two" (func $h (result u32)))
  (import "host" (instance $host (export "return-hi" (func (result string)))))
  (alias export $host "return-hi" (func $hi))
  (core func $h (canon lower (func $h)))
  (core module $Libc
    (import "" "h" (func $h (result i32)))
    (memory (export "mem") 1)
    (func (export "realloc") (param i32 i32 i32 i32) (result i32)
      (drop (call $h)) (i32.const 0)))
  (core instance $libc (instantiate $Libc (with "" (instance (export "h" (func $h))))))
  (core func $hi (canon lower (func $hi)
    (memory (core memory $libc "mem")) (realloc (core func $libc "realloc"))))
  (core module $M
    (import "" "hi" (func $hi (param i32)))
    (func (export "run") (call $hi (i32.const 8))))
  (core instance $m (instantiate $M (with "" (instance (export "hi" (func $hi))))))
  (func (export "run") (canon lift (core func $m "run")))
)
(assert_trap (invoke "run") "cannot leave component instance")

;; guest -> guest: copying a `future<string>` value into the reader. The writer
;; writes first, so the reader's `future.read` completes immediately.
(component
  (import "host-return-two" (func $h (result u32)))
  (component $C
    (import "host-return-two" (func $h (result u32)))
    (type $FT (future string))
    (core func $h (canon lower (func $h)))
    (core module $Libc
      (import "" "h" (func $h (result i32)))
      (memory (export "mem") 1)
      (func (export "realloc") (param i32 i32 i32 i32) (result i32)
        (drop (call $h)) (i32.const 0)))
    (core instance $libc (instantiate $Libc (with "" (instance (export "h" (func $h))))))
    (core func $future.read (canon future.read $FT async
      (memory (core memory $libc "mem")) (realloc (core func $libc "realloc"))))
    (core module $M
      (import "" "future.read" (func $future.read (param i32 i32) (result i32)))
      (func (export "read") (param i32) (drop (call $future.read (local.get 0) (i32.const 8)))))
    (core instance $m (instantiate $M (with "" (instance
      (export "future.read" (func $future.read))))))
    (func (export "read") (param "f" (future string)) (canon lift (core func $m "read")))
  )
  (component $D
    (import "read" (func $read (param "f" (future string))))
    (type $FT (future string))
    (core module $Mem
      (memory (export "mem") 1)
      (data (i32.const 4) "\01")) ;; string at 0: ptr = 0, len = 1
    (core instance $mem (instantiate $Mem))
    (core func $read (canon lower (func $read)))
    (core func $future.new (canon future.new $FT))
    (core func $future.write (canon future.write $FT async (memory (core memory $mem "mem"))))
    (core module $M
      (import "" "read" (func $read (param i32)))
      (import "" "future.new" (func $future.new (result i64)))
      (import "" "future.write" (func $future.write (param i32 i32) (result i32)))
      (func (export "run")
        (drop (call $future.new)) ;; readable = 1, writable = 2
        (drop (call $future.write (i32.const 2) (i32.const 0)))
        (call $read (i32.const 1))))
    (core instance $m (instantiate $M (with "" (instance
      (export "read" (func $read))
      (export "future.new" (func $future.new))
      (export "future.write" (func $future.write))))))
    (func (export "run") (canon lift (core func $m "run")))
  )
  (instance $c (instantiate $C (with "host-return-two" (func $h))))
  (instance $d (instantiate $D (with "read" (func $c "read"))))
  (export "run" (func $d "run"))
)
(assert_trap (invoke "run") "cannot leave component instance")

;; guest -> guest: copying a `stream<string>` element into the reader. The
;; writer writes first, so the reader's `stream.read` completes immediately.
(component
  (import "host-return-two" (func $h (result u32)))
  (component $C
    (import "host-return-two" (func $h (result u32)))
    (type $ST (stream string))
    (core func $h (canon lower (func $h)))
    (core module $Libc
      (import "" "h" (func $h (result i32)))
      (memory (export "mem") 1)
      (func (export "realloc") (param i32 i32 i32 i32) (result i32)
        (drop (call $h)) (i32.const 0)))
    (core instance $libc (instantiate $Libc (with "" (instance (export "h" (func $h))))))
    (core func $stream.read (canon stream.read $ST async
      (memory (core memory $libc "mem")) (realloc (core func $libc "realloc"))))
    (core module $M
      (import "" "stream.read" (func $stream.read (param i32 i32 i32) (result i32)))
      (func (export "read") (param i32)
        (drop (call $stream.read (local.get 0) (i32.const 8) (i32.const 1)))))
    (core instance $m (instantiate $M (with "" (instance
      (export "stream.read" (func $stream.read))))))
    (func (export "read") (param "s" (stream string)) (canon lift (core func $m "read")))
  )
  (component $D
    (import "read" (func $read (param "s" (stream string))))
    (type $ST (stream string))
    (core module $Mem
      (memory (export "mem") 1)
      (data (i32.const 4) "\01")) ;; string at 0: ptr = 0, len = 1
    (core instance $mem (instantiate $Mem))
    (core func $read (canon lower (func $read)))
    (core func $stream.new (canon stream.new $ST))
    (core func $stream.write (canon stream.write $ST async (memory (core memory $mem "mem"))))
    (core module $M
      (import "" "read" (func $read (param i32)))
      (import "" "stream.new" (func $stream.new (result i64)))
      (import "" "stream.write" (func $stream.write (param i32 i32 i32) (result i32)))
      (func (export "run")
        (drop (call $stream.new)) ;; readable = 1, writable = 2
        (drop (call $stream.write (i32.const 2) (i32.const 0) (i32.const 1)))
        (call $read (i32.const 1))))
    (core instance $m (instantiate $M (with "" (instance
      (export "read" (func $read))
      (export "stream.new" (func $stream.new))
      (export "stream.write" (func $stream.write))))))
    (func (export "run") (canon lift (core func $m "run")))
  )
  (instance $c (instantiate $C (with "host-return-two" (func $h))))
  (instance $d (instantiate $D (with "read" (func $c "read"))))
  (export "run" (func $d "run"))
)
(assert_trap (invoke "run") "cannot leave component instance")

;; `error-context.debug-message`: lowering the message string into the caller.
(component
  (import "host-return-two" (func $h (result u32)))
  (core func $h (canon lower (func $h)))
  (core module $Libc
    (import "" "h" (func $h (result i32)))
    (memory (export "mem") 1)
    (func (export "realloc") (param i32 i32 i32 i32) (result i32)
      (drop (call $h)) (i32.const 0)))
  (core instance $libc (instantiate $Libc (with "" (instance (export "h" (func $h))))))
  (core func $error-context.new (canon error-context.new (memory (core memory $libc "mem"))))
  (core func $error-context.debug-message (canon error-context.debug-message
    (memory (core memory $libc "mem")) (realloc (core func $libc "realloc"))))
  (core module $M
    (import "" "error-context.new" (func $error-context.new (param i32 i32) (result i32)))
    (import "" "error-context.debug-message" (func $error-context.debug-message (param i32 i32)))
    (func (export "run")
      (call $error-context.debug-message
        (call $error-context.new (i32.const 0) (i32.const 1))
        (i32.const 8))))
  (core instance $m (instantiate $M (with "" (instance
    (export "error-context.new" (func $error-context.new))
    (export "error-context.debug-message" (func $error-context.debug-message))))))
  (func (export "run") (canon lift (core func $m "run")))
)
(assert_trap (invoke "run") "cannot leave component instance")
"#;

#[test]
#[cfg_attr(miri, ignore)]
fn realloc_may_leave_traps() -> Result<()> {
    // Mirror the feature configuration the text-format directives at the top of
    // the companion suite file request: component-model async, error-context,
    // and multi-memory, plus the reference-types implied by async.
    let mut cfg = Config::new();
    cfg.wasm_multi_memory(true);
    cfg.wasm_reference_types(true);
    cfg.wasm_threads(true);
    cfg.shared_memory(true);
    cfg.wasm_component_model(true);
    cfg.wasm_component_model_async(true);
    cfg.wasm_component_model_error_context(true);
    let engine = Engine::new(&cfg)?;

    let mut ctx = WastContext::new(&engine, Async::Yes, |_store| {});
    ctx.generate_dwarf(true);
    ctx.register_spectest(&SpectestConfig {
        use_shared_memory: true,
        suppress_prints: true,
    })?;
    ctx.register_wasmtime()?;
    ctx.run_wast(
        "realloc-may-leave.wast",
        REALLOC_MAY_LEAVE_WAST.as_bytes(),
    )
}

// ---------------------------------------------------------------------------
// Behavior: pre-existing normal async stream + call paths stay intact
//
// Normal (non-zero-length) stream reads/writes and ordinary awaited async
// calls must keep working. A one-byte value is streamed host -> guest ->
// host through the public stream API, and a plain async call is awaited to
// completion. These behaviors are unrelated to the three fixes and must not
// regress.
// ---------------------------------------------------------------------------

#[tokio::test]
#[cfg_attr(miri, ignore)]
async fn normal_stream_round_trip_still_works() -> Result<()> {
    let mut config = Config::new();
    config.wasm_component_model_async(true);
    let engine = Engine::new(&config)?;

    // A producer that buffers three bytes on its first poll, then ends. It
    // never touches the direct-buffer accessor, so it is agnostic to that
    // accessor's return shape.
    struct ThreeBytes(usize);
    impl StreamProducer<()> for ThreeBytes {
        type Item = u8;
        type Buffer = VecBuffer<u8>;
        fn poll_produce<'a>(
            mut self: Pin<&mut Self>,
            _cx: &mut Context<'_>,
            _store: StoreContextMut<'a, ()>,
            mut destination: Destination<'a, u8, VecBuffer<u8>>,
            _finish: bool,
        ) -> Poll<Result<StreamResult>> {
            self.0 += 1;
            if self.0 == 1 {
                destination.set_buffer(vec![1u8, 2, 3].into());
                Poll::Ready(Ok(StreamResult::Completed))
            } else {
                Poll::Ready(Ok(StreamResult::Dropped))
            }
        }
    }

    // A consumer that takes everything it is given via the signature-stable
    // `read` entry point and reports the final tally when it is dropped.
    struct Taker {
        taken: Vec<u8>,
        done: Option<tokio::sync::oneshot::Sender<Vec<u8>>>,
    }
    impl Drop for Taker {
        fn drop(&mut self) {
            if let Some(tx) = self.done.take() {
                let _ = tx.send(mem::take(&mut self.taken));
            }
        }
    }
    impl StreamConsumer<()> for Taker {
        type Item = u8;
        fn poll_consume(
            mut self: Pin<&mut Self>,
            _cx: &mut Context<'_>,
            mut store: StoreContextMut<()>,
            mut source: Source<'_, u8>,
            _finish: bool,
        ) -> Poll<Result<StreamResult>> {
            let mut buf = Vec::<u8>::with_capacity(16);
            source.read(&mut store, &mut buf)?;
            self.taken.extend(buf);
            Poll::Ready(Ok(StreamResult::Completed))
        }
    }

    let mut store = Store::new(&engine, ());
    let reader = StreamReader::<u8>::new(&mut store, ThreeBytes(0))?;
    let (tx, rx) = tokio::sync::oneshot::channel();
    reader.pipe(
        &mut store,
        Taker {
            taken: Vec::new(),
            done: Some(tx),
        },
    )?;
    let taken = store.run_concurrent(async |_| rx.await).await??;
    assert_eq!(taken, vec![1u8, 2, 3]);
    Ok(())
}

#[tokio::test]
#[cfg_attr(miri, ignore)]
async fn normal_async_call_awaits_to_completion() -> Result<()> {
    let engine = Engine::default();
    let component = Component::new(
        &engine,
        r#"
        (component
            (core module $m
                (import "" "task.return" (func $task.return))
                (func (export "f") (result i32)
                    (call $task.return)
                    (i32.const 0 (; EXIT ;)))
                (func (export "cb") (param i32 i32 i32) (result i32) unreachable))
            (canon task.return (core func $task.return))
            (core instance $i (instantiate $m
                (with "" (instance (export "task.return" (func $task.return))))))
            (func (export "f") async (canon lift (core func $i "f") async (callback (core func $i "cb"))))
        )
    "#,
    )?;
    let mut store = Store::new(&engine, ());
    let instance = Linker::new(&engine)
        .instantiate_async(&mut store, &component)
        .await?;
    let func = instance.get_typed_func::<(), ()>(&mut store, "f")?;
    func.call_async(&mut store, ()).await?;
    Ok(())
}
