## Task

The component model's async runtime has three failures reachable through normal
guest and embedder activity. Please investigate and correct each one.

A component stream or future can make the host panic on a read or write of zero
items if the guest supplies a pointer outside linear memory. Since no bytes move,
that operation should complete without accessing the pointer. An embedder can
also trigger a host panic by dropping an async component call's future after
the call has been scheduled, including after backpressure releases it, but
before the call runs. This needs to be safe throughout that interval.

Finally, some paths that return results allow guest code to re-enter the
component while the host is lowering those results. Re-entry must remain
forbidden until that lowering is finished.
