"""
Story: story_plot_alignment_browser
Test that plot_alignment works under the jupyterlite_notebook backend and
produces a figure whose drawn-object count reflects per-color merging.
"""
import numpy as np
import mne
from mne.viz import set_3d_backend, plot_alignment, Figure3D


def _get_actors_sequence(plotter):
    """Return a list of actor entries from the plotter.

    The submitted backend stores actors at plotter.renderer.actors (a
    _RendererActors dict subclass). Access it directly to avoid misleading
    fallthrough if a future implementation exposes a different actors attribute
    at plotter.actors.
    """
    actors = plotter.renderer.actors

    # Normalize to a list
    if hasattr(actors, 'values') and callable(actors.values):
        return list(actors.values())
    return list(actors)


def test_plot_alignment_browser(inputs, expected):
    """Test plot_alignment under the jupyterlite_notebook backend."""
    # Step 1: select the browser backend
    set_3d_backend("jupyterlite_notebook")

    # Step 2: build synthetic MEG Info
    n = inputs["n_channels"]
    info = mne.create_info(
        [f"MEG{i:03d}" for i in range(1, n + 1)], 1000.0, "mag"
    )
    rng = np.random.default_rng(0)
    for ch in info["chs"]:
        ch["loc"] = np.concatenate(
            [rng.standard_normal(3) * 0.05, np.eye(3).ravel()[:9]]
        )

    # Step 3: build per-channel color array with distinct_colors distinct colors
    palette = rng.random((inputs["distinct_colors"], 4))
    colors = np.array(
        [palette[i % inputs["distinct_colors"]] for i in range(n)]
    )

    # Step 4: draw the alignment figure
    fig = plot_alignment(
        info, meg=["sensors"], eeg=False, dig=False,
        coord_frame="meg", sensor_colors=dict(meg=colors),
    )

    # Correctness: plot_alignment must return a real Figure3D object
    assert isinstance(fig, Figure3D), (
        f"Expected a Figure3D instance, got {type(fig)}"
    )

    # Step 5: count drawn objects
    entries = _get_actors_sequence(fig.plotter)

    n_actors = len(entries)
    assert n_actors == expected["n_actors"], (
        f"Expected {expected['n_actors']} drawn objects (per-color merge), got {n_actors}"
    )
