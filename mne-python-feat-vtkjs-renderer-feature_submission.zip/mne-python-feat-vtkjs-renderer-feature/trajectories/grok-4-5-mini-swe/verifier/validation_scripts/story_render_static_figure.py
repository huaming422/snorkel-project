"""
Story: story_render_static_figure
Test that the jupyterlite_notebook backend renders a mesh and optionally a sphere,
that the drawn geometry is preserved, and that the camera orientation can be set
and read back.
"""
import numpy as np
from mne.viz import set_3d_backend, get_3d_backend
from mne.viz.backends.renderer import _get_renderer, set_3d_view
from mne.transforms import _cart_to_sph


def _read_camera_azel(plotter):
    """Read azimuth and elevation (degrees) from the plotter's camera_position.

    The submitted backend stores the camera in plotter._camera and exposes it
    via plotter.camera_position. We recover azimuth/elevation by inverting the
    spherical-to-Cartesian conversion that _set_3d_view uses internally.
    """
    position = np.array(plotter.camera_position[0], float)
    fp = np.array(plotter.camera_position[1], float)
    vec = np.atleast_2d(position - fp)
    _, phi, theta = _cart_to_sph(vec)[0]
    az = float(np.rad2deg(phi))
    el = float(np.rad2deg(theta))
    return az, el


def _get_actors_sequence(plotter):
    """Return a list of actor entries from the plotter.

    The submitted backend stores actors at plotter.renderer.actors (a
    _RendererActors dict subclass). Access it directly to avoid misleading
    fallthrough if a future implementation exposes a different actors attribute
    at plotter.actors.
    """
    actors = plotter.renderer.actors

    # Normalize to a list
    if hasattr(actors, 'values') and callable(actors.values):
        return list(actors.values())
    return list(actors)


def test_render_static_figure(inputs, expected):
    """Test the jupyterlite_notebook backend renders a static figure correctly."""
    # Step 1: set and verify backend
    set_3d_backend("jupyterlite_notebook")
    assert get_3d_backend() == "jupyterlite_notebook", (
        f"Expected backend 'jupyterlite_notebook', got '{get_3d_backend()}'"
    )

    # Step 2: build mesh inputs
    RR = np.array(inputs["mesh_points"], dtype=float)  # (N, 3)
    TRIS = np.array(inputs["triangles"], dtype=int)    # (M, 3)

    # Step 3: create renderer
    rend = _get_renderer(bgcolor="white", size=(300, 300))

    # Step 4: draw the mesh
    rend.mesh(
        x=RR[:, 0], y=RR[:, 1], z=RR[:, 2],
        triangles=TRIS,
        color="red",
    )

    # Step 5: optionally draw sphere
    if inputs["draw_sphere"]:
        rend.sphere(center=np.array([[0.5, 0.5, 0.5]]), color="blue", scale=0.1)

    # Step 6: read drawn-object collection and normalize to sequence of entries
    entries = _get_actors_sequence(rend.plotter)

    n_actors = len(entries)
    assert n_actors == expected["n_actors"], (
        f"Expected {expected['n_actors']} drawn objects, got {n_actors}"
    )

    # Step 7: first drawn object's geometry
    first_entry = entries[0]
    # Each entry is an _Actor dataclass with a .mesh attribute
    # (or a dict with a "mesh" key — handle both)
    if isinstance(first_entry, dict):
        mesh0 = first_entry["mesh"]
    else:
        mesh0 = first_entry.mesh

    pts = np.asarray(mesh0.points)

    assert len(pts) == expected["mesh_point_count"], (
        f"Expected mesh_point_count={expected['mesh_point_count']}, got {len(pts)}"
    )

    # Correctness: vertices must match input exactly
    assert np.allclose(pts, RR), (
        f"Mesh points do not match input.\nExpected:\n{RR}\nGot:\n{pts}"
    )

    # Step 8a: set camera via set_camera and read back
    rend.set_camera(azimuth=inputs["azimuth"], elevation=inputs["elevation"])
    az, el = _read_camera_azel(rend.plotter)

    assert np.isclose(az, expected["camera_azimuth"], atol=1e-3), (
        f"camera_azimuth: expected {expected['camera_azimuth']}, got {az}"
    )
    assert np.isclose(el, expected["camera_elevation"], atol=1e-3), (
        f"camera_elevation: expected {expected['camera_elevation']}, got {el}"
    )

    # Step 8b: use set_3d_view and assert the camera reads back correctly
    set_3d_view(rend.scene(), azimuth=inputs["azimuth2"], elevation=inputs["elevation2"])
    az2, el2 = _read_camera_azel(rend.plotter)

    assert np.isclose(az2, inputs["azimuth2"], atol=1e-3), (
        f"After set_3d_view: camera_azimuth: expected {inputs['azimuth2']}, got {az2}"
    )
    assert np.isclose(el2, inputs["elevation2"], atol=1e-3), (
        f"After set_3d_view: camera_elevation: expected {inputs['elevation2']}, got {el2}"
    )
