import numpy as np
import mne
from mne.viz import set_3d_backend, plot_alignment, Figure3D


def test_plot_alignment_browser(inputs, expected):
    """Test that plot_alignment runs under the jupyterlite_notebook backend."""
    # Step 1: Set the backend.
    set_3d_backend("jupyterlite_notebook")

    # Step 2: Build a small synthetic MEG Info.
    n = inputs["n_channels"]
    info = mne.create_info(
        [f"MEG{i:03d}" for i in range(1, n + 1)], 1000.0, "mag"
    )
    rng = np.random.default_rng(0)
    for ch in info["chs"]:
        ch["loc"] = np.concatenate(
            [rng.standard_normal(3) * 0.05, np.eye(3).ravel()[:9]]
        )

    # Step 3: Build per-channel color array with distinct_colors distinct colors.
    palette = rng.random((inputs["distinct_colors"], 4))
    colors = np.array(
        [palette[i % inputs["distinct_colors"]] for i in range(n)]
    )

    # Step 4: Draw the alignment figure through the public API.
    fig = plot_alignment(
        info, meg=["sensors"], eeg=False, dig=False,
        coord_frame="meg", sensor_colors=dict(meg=colors),
    )

    # Correctness assertion: plot_alignment returns a real Figure3D instance.
    assert isinstance(fig, Figure3D), (
        f"Expected a Figure3D instance, got {type(fig)}"
    )

    # Step 5: Count the drawn objects in fig.objects (a plain list of
    # _JupyterliteObject instances, as the patch stores them on JupyterliteFigure).
    entries = list(fig.objects)

    assert len(entries) == expected["n_actors"], (
        f"Expected {expected['n_actors']} drawn objects, got {len(entries)}"
    )
