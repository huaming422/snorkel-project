import numpy as np
from mne.viz import set_3d_backend, get_3d_backend
from mne.viz.backends.renderer import _get_renderer, set_3d_view


def test_render_static_figure(inputs, expected):
    """Test that the jupyterlite_notebook backend draws a static scene correctly."""
    # Step 1: Set the backend and confirm it was selected.
    set_3d_backend("jupyterlite_notebook")
    assert get_3d_backend() == "jupyterlite_notebook", (
        f"Expected backend 'jupyterlite_notebook' but got '{get_3d_backend()}'"
    )

    # Step 2: Build input mesh from inputs.
    RR = np.array(inputs["mesh_points"], dtype=float)  # (N, 3)
    TRIS = np.array(inputs["triangles"], dtype=int)

    # Step 3: Create the renderer.
    rend = _get_renderer(bgcolor="white", size=(300, 300))

    # Step 4: Draw the mesh.
    rend.mesh(x=RR[:, 0], y=RR[:, 1], z=RR[:, 2], triangles=TRIS, color="red")

    # Step 5: Optionally draw a sphere.
    if inputs["draw_sphere"]:
        rend.sphere(center=np.array([[0.5, 0.5, 0.5]]), color="blue", scale=0.1)

    # Step 6: Read the drawn-object collection from rend.figure.objects (a plain list
    # of _JupyterliteObject instances, as defined by the patch).
    entries = list(rend.figure.objects)

    assert len(entries) == expected["n_actors"], (
        f"Expected {expected['n_actors']} drawn objects, got {len(entries)}"
    )

    # Step 7: Check the first drawn object's geometry.
    # _JupyterliteObject stores the vertex array directly as .vertices (a numpy array).
    pts = np.asarray(entries[0].vertices)

    assert len(pts) == expected["mesh_point_count"], (
        f"Expected {expected['mesh_point_count']} mesh points, got {len(pts)}"
    )
    assert np.allclose(pts, RR), (
        f"Mesh points do not match input: got {pts}, expected {RR}"
    )

    # Step 8a: Set camera via rend.set_camera and read back azimuth/elevation.
    rend.set_camera(azimuth=inputs["azimuth"], elevation=inputs["elevation"])
    cam = rend.get_camera()
    az = cam[2]
    el = cam[3]

    assert np.isclose(az, expected["camera_azimuth"], atol=1e-3), (
        f"Expected camera azimuth {expected['camera_azimuth']}, got {az}"
    )
    assert np.isclose(el, expected["camera_elevation"], atol=1e-3), (
        f"Expected camera elevation {expected['camera_elevation']}, got {el}"
    )

    # Step 8b: Orient via set_3d_view and verify read-back.
    set_3d_view(rend.scene(), azimuth=inputs["azimuth2"], elevation=inputs["elevation2"])
    cam2 = rend.get_camera()
    az2 = cam2[2]
    el2 = cam2[3]

    assert np.isclose(az2, inputs["azimuth2"], atol=1e-3), (
        f"Expected azimuth2 {inputs['azimuth2']} after set_3d_view, got {az2}"
    )
    assert np.isclose(el2, inputs["elevation2"], atol=1e-3), (
        f"Expected elevation2 {inputs['elevation2']} after set_3d_view, got {el2}"
    )
