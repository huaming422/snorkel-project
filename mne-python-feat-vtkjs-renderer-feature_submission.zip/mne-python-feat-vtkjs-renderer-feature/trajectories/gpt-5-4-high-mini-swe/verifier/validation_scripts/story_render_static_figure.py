import numpy as np
from mne.viz import set_3d_backend, get_3d_backend
from mne.viz.backends.renderer import _get_renderer, set_3d_view


def test_render_static_figure(inputs, expected):
    """Test that the jupyterlite_notebook backend renders a static scene correctly."""
    # Step 1: Select the backend and verify it's active
    set_3d_backend("jupyterlite_notebook")
    assert get_3d_backend() == "jupyterlite_notebook", (
        f"Expected backend 'jupyterlite_notebook', got '{get_3d_backend()}'"
    )

    # Step 2: Build input mesh
    RR = np.array(inputs["mesh_points"], dtype=float)  # (N, 3)
    TRIS = np.array(inputs["triangles"], dtype=int)    # (M, 3)

    # Step 3: Create renderer
    rend = _get_renderer(bgcolor="white", size=(300, 300))

    # Step 4: Draw the mesh
    rend.mesh(x=RR[:, 0], y=RR[:, 1], z=RR[:, 2], triangles=TRIS, color="red")

    # Step 5: Optionally draw a sphere
    if inputs["draw_sphere"]:
        rend.sphere(center=np.array([[0.5, 0.5, 0.5]]), color="blue", scale=0.1)

    # Step 6: Read the drawn-object collection via the procedure-specified surface:
    # figure.plotter.actors (normalize list or name-keyed dict to a sequence)
    actors = rend.plotter.actors
    actors_seq = list(actors.values()) if hasattr(actors, 'values') else list(actors)

    n_actors = len(actors_seq)
    assert n_actors == expected["n_actors"], (
        f"Expected {expected['n_actors']} drawn objects, got {n_actors}"
    )

    # Step 7: Take the FIRST drawn object and verify its points.
    # Each entry carries the drawn geometry under a "mesh" key whose .points
    # is the vertex array (as specified in the procedure).
    first_entry = actors_seq[0]
    pts = np.asarray(first_entry['mesh'].points, dtype=float)

    assert len(pts) == expected["mesh_point_count"], (
        f"Expected {expected['mesh_point_count']} mesh points, got {len(pts)}"
    )

    # Correctness check: the mesh points match what was supplied
    assert np.allclose(pts, RR), (
        f"Mesh points don't match input. Got:\n{pts}\nExpected:\n{RR}"
    )

    # Step 8a: Set camera via rend.set_camera and read back
    rend.set_camera(azimuth=inputs["azimuth"], elevation=inputs["elevation"])
    # get_camera() returns (roll, distance, azimuth, elevation, focalpoint)
    cam = rend.get_camera()
    az = cam[2]
    el = cam[3]

    assert np.isclose(az, expected["camera_azimuth"], atol=1e-3), (
        f"camera_azimuth: expected {expected['camera_azimuth']}, got {az}"
    )
    assert np.isclose(el, expected["camera_elevation"], atol=1e-3), (
        f"camera_elevation: expected {expected['camera_elevation']}, got {el}"
    )

    # Step 8b: set_3d_view orients the same figure correctly
    set_3d_view(rend.scene(), azimuth=inputs["azimuth2"], elevation=inputs["elevation2"])
    cam2 = rend.get_camera()
    az2 = cam2[2]
    el2 = cam2[3]

    assert np.isclose(az2, inputs["azimuth2"], atol=1e-3), (
        f"After set_3d_view, azimuth: expected {inputs['azimuth2']}, got {az2}"
    )
    assert np.isclose(el2, inputs["elevation2"], atol=1e-3), (
        f"After set_3d_view, elevation: expected {inputs['elevation2']}, got {el2}"
    )
