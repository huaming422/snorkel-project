import numpy as np
import mne
from mne.viz import set_3d_backend, plot_alignment
from mne.viz.backends._abstract import Figure3D


def test_plot_alignment_browser(inputs, expected):
    """Test that plot_alignment works under the jupyterlite_notebook backend."""
    # Step 1: Select the backend
    set_3d_backend("jupyterlite_notebook")

    # Step 2: Build a small synthetic MEG Info
    n = inputs["n_channels"]
    info = mne.create_info(
        [f"MEG{i:03d}" for i in range(1, n + 1)], 1000.0, "mag"
    )
    rng = np.random.default_rng(0)
    for ch in info["chs"]:
        ch["loc"] = np.concatenate(
            [rng.standard_normal(3) * 0.05, np.eye(3).ravel()[:9]]
        )

    # Step 3: Build per-channel color array with distinct_colors distinct RGBA rows
    palette = rng.random((inputs["distinct_colors"], 4))
    colors = np.array(
        [palette[i % inputs["distinct_colors"]] for i in range(n)]
    )

    # Step 4: Draw the alignment figure through the public API
    fig = plot_alignment(
        info, meg=["sensors"], eeg=False, dig=False,
        coord_frame="meg", sensor_colors=dict(meg=colors),
    )

    # Correctness check: the result is a real Figure3D object
    assert isinstance(fig, Figure3D), (
        f"plot_alignment should return a Figure3D instance, got {type(fig)}"
    )

    # Step 5: Count drawn objects in fig.plotter.actors
    # (normalize list or name-keyed dict to a sequence first)
    actors = fig.plotter.actors
    actors_seq = list(actors.values()) if hasattr(actors, 'values') else list(actors)

    n_actors = len(actors_seq)
    assert n_actors == expected["n_actors"], (
        f"Expected {expected['n_actors']} drawn objects (one per distinct color), "
        f"got {n_actors}"
    )
