## Task

Our 3D figures (sensor alignment, source estimates, field maps) render through a backend that wraps VTK, which has no WebAssembly build, so none of them draw in the JupyterLite/Pyodide browser kernel the documentation's notebooks run on.

We want a new 3D renderer backend, selectable by name as `jupyterlite_notebook`, that draws through a browser-capable rendering library instead of VTK. It should cover the primitives those figures use: meshes, surfaces, spheres, tubes, and glyphs (arrows, cones, cylinders).

The geometry and coordinate-frame math already lives in numpy; keep it there and let the backend take over only the final drawing step. Exactness matters, since an inexact transform still renders a believable picture.

The interactive time viewer, scalar colormaps, contours, scalar bars and legends, subplots, and in-kernel screenshots are out of scope and should be rejected cleanly. The backend also has to draw with no VTK installed, and automatic selection should still pick a VTK backend on a desktop that merely has the browser library.

Scope is the renderer backend plus the numpy changes it needs; the wider JupyterLite documentation wiring is out.

## User stories / requirements

- Selecting the new browser backend and drawing a static scene of a mesh and a sphere yields a figure whose scene data comes through intact: the mesh points, the triangle faces, and the camera orientation all match what was set. Setting the view by azimuth and elevation orients the scene like the desktop backend does.
- The public sensor-alignment 3D plot runs under the new backend on a small dataset and builds a complete figure. Since the browser renderer can't color instances individually, instances sharing a color merge into one solid object, so the count of drawn objects reflects that merge rather than one per instance.
