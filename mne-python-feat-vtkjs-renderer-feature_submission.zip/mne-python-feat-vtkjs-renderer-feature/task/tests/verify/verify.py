"""Behavioral verifier for the browser-capable 3D renderer backend.

Every test drives MNE's *pre-existing, stable* public 3D surface:
``mne.viz.set_3d_backend`` / ``mne.viz.backends.renderer._get_renderer`` and the
``_AbstractRenderer`` method contract (mesh/surface/sphere/tube/quiver3d/
instanced_mesh/text2d/contour/.../set_camera). Geometry is read back through
stable library observables — the drawn ``PolyData.points`` / ``.faces`` and each
drawn object's ``mesh``/``color``/``opacity`` — and the camera through whatever
stable read-back surface the backend exposes.

The renderer's drawn-object collection (``plotter.actors``) may be either a
list (the raw browser-library convention) or a name-keyed dict (the desktop
PyVista convention); every accessor here reads it shape-agnostically so a
solution that picks either still passes. Likewise the camera is read back
through whatever stable surface the backend exposes — the ``get_camera`` method
if it has one, otherwise the backend module's own view-reader — rather than
pinning one of them.

No implementation-internal symbol is imported or named: not the backend module
filename, not any private helper, renderer class, or the browser scene-dict. A
valid solution that organizes any of those differently still passes: the
assertions are on observable geometry and behavior, not on names or locations.
In particular no assertion pins how the backend computes glyph orientation
internally — orientation is checked only through the drawn ``quiver3d``
geometry, which turns a glyph onto each direction including the antiparallel
``-x`` case.

The ``jupyterlite_notebook`` backend name is the maintainer-dictated public API
(the ``set_3d_backend`` argument stated in the task); asserting on it is fair.
"""

import numpy as np
import pytest
from numpy.testing import assert_allclose

from mne.viz.backends import renderer as _renderer_mod
from mne.viz.backends.renderer import set_3d_backend

BACKEND = "jupyterlite_notebook"

# A unit square split into two triangles — a minimal mesh whose points and
# faces are trivial to check. These are harness-owned test fixtures.
_RR = np.array([[0, 0, 0], [1, 0, 0], [1, 1, 0], [0, 1, 0]], float)
_TRIS = np.array([[0, 1, 2], [0, 2, 3]])


@pytest.fixture
def lite():
    """Select the browser backend and hand back a fresh renderer.

    On unmodified code ``set_3d_backend('jupyterlite_notebook')`` raises
    ``ValueError`` (the name is unregistered), so every test that needs a
    renderer fails before the backend exists — the fail-to-pass gate we want.
    """
    saved = (_renderer_mod.MNE_3D_BACKEND, _renderer_mod.backend)
    try:
        set_3d_backend(BACKEND)
        yield _renderer_mod._get_renderer(bgcolor="white")
    finally:
        try:
            _renderer_mod.backend._close_all()
        except Exception:
            pass
        _renderer_mod.MNE_3D_BACKEND, _renderer_mod.backend = saved


def _actors(rend):
    """The drawn-object collection as a list, accepting either container shape.

    A browser backend may expose ``plotter.actors`` as a plain list (the raw
    drawing-library convention) or as a name-keyed dict (the desktop PyVista
    convention). Either is a defensible design choice, so read both the same
    way: the ordered sequence of drawn-object entries.
    """
    actors = rend.plotter.actors
    if hasattr(actors, "values") and not isinstance(actors, (list, tuple)):
        return list(actors.values())
    return list(actors)


def _actor_mesh_points(rend):
    """Points of the most recently added drawn object's mesh."""
    return np.asarray(_actors(rend)[-1]["mesh"].points)


def _read_view(rend):
    """Read back ``(azimuth, elevation)`` through whatever stable surface exists.

    The ``_AbstractRenderer`` contract names ``set_camera`` but not a camera
    *reader*; backends expose the read either as a ``get_camera`` method whose
    ``[2:4]`` slice is ``(azimuth, elevation)``, or as the backend module's own
    ``_get_3d_view(figure)`` function with the same slice. Try the method, then
    the module surface, so neither design is pinned.
    """
    getter = getattr(rend, "get_camera", None)
    if callable(getter):
        az, el = getter()[2:4]
        return float(az), float(el)
    view = _renderer_mod.backend._get_3d_view(rend.scene())
    return float(view[2]), float(view[3])


# -- 1. backend loads and draws without VTK -----------------------------------
def test_backend_loads_and_draws(lite):
    """jupyterlite_notebook selects a working renderer that draws a mesh."""
    _, mesh = lite.mesh(*_RR.T, _TRIS, color="red", opacity=0.5)
    # it actually drew something (one actor) and kept the input geometry
    assert len(_actors(lite)) == 1
    assert_allclose(np.asarray(mesh.points), _RR, atol=1e-6)


# -- 5. the flat VTK cell array both backends draw from -----------------------
def test_mesh_faces_flat_cell_array(lite):
    """Drawn mesh carries the (3,i,j,k) flat cell array; empty stays empty."""
    _, mesh = lite.mesh(*_RR.T, _TRIS, color="red")
    # pyvista_js PolyData.faces is the flat cell array [3,i,j,k, 3,i,j,k, ...]
    assert np.asarray(mesh.faces).ravel().tolist() == [3, 0, 1, 2, 3, 0, 2, 3]
    # an empty surface draws nothing rather than raising
    _, empty = lite.mesh(
        np.zeros(0), np.zeros(0), np.zeros(0), np.zeros((0, 3), int), color="red"
    )
    assert np.asarray(empty.faces).size == 0
    assert np.asarray(empty.points).shape == (0, 3)


# -- 6. primitives draw the geometry PyVista would, sized identically ---------
def test_primitives_sized_like_pyvista(lite):
    """sphere scales a radius-0.5 template / uses radius as-is; tube spans & defaults white."""
    # sphere: scale sizes a radius-0.5 sphere; an explicit radius is used as-is
    for kwargs, want in ((dict(scale=0.1), 0.05), (dict(scale=1, radius=0.02), 0.02)):
        lite.sphere(np.array([[1.0, 0.0, 0.0]]), "green", **kwargs)
        pts = _actor_mesh_points(lite) - [1.0, 0.0, 0.0]
        assert np.linalg.norm(pts, axis=1).max() == pytest.approx(want, abs=1e-6)
    # tube: spans origin->destination, stretched along its axis, radius kept,
    # default color white (gray would vanish into plot_alignment's background)
    _, tube = lite.tube([[0.0, 0, 0]] * 2, [[1.0, 0, 0], [0, 2.0, 0]], radius=0.01)
    first, second = np.asarray(tube.points).reshape(2, -1, 3)
    assert (first[:, 0].max(), second[:, 1].max()) == pytest.approx((1.0, 2.0))
    assert np.linalg.norm(first[:, 1:], axis=1).max() == pytest.approx(0.01, abs=1e-6)
    actor = _actors(lite)[-1]
    assert tuple(actor["color"]) == (1.0, 1.0, 1.0)
    assert actor["opacity"] == pytest.approx(1.0)


# -- 7. glyph templates match VTK sources and orient onto direction -----------
@pytest.mark.parametrize(
    "mode, span, radius",
    [
        ("arrow", (0.0, 1.0), 0.1),
        ("cone", (0.0, 1.0), 0.15),
        ("cylinder", (-0.5, 0.5), 0.15),
        ("sphere", (-0.5, 0.5), 0.5),
    ],
)
def test_glyph_geometry_and_orientation(lite, mode, span, radius):
    """Each glyph's cross radius matches, and directional glyphs turn onto +x/+y/-x."""
    dirs = np.array([[1, 0, 0], [0, 1, 0], [-1, 0, 0]], float)  # incl antiparallel -x
    sizes = np.array([1.0, 2.0, 2.0])
    _, mesh = lite.quiver3d(
        *np.zeros((3, 3)),
        *dirs.T,
        color="red",
        scale=2.0,
        mode=mode,
        scale_mode="scalar",
        scalars=sizes / 2,
    )
    for pts, d, size in zip(np.asarray(mesh.points).reshape(3, -1, 3), dirs, sizes):
        along = pts @ d
        across = np.linalg.norm(pts - np.outer(along, d), axis=1)
        # the cross-axis radius sizes every glyph, directional or not
        assert across.max() == pytest.approx(radius * size, abs=1e-5)
        if mode != "sphere":
            # a sphere is isotropic, so its along-axis extent carries no
            # orientation and equals the radius already checked above (and its
            # exact value along one axis is a tessellation detail). For the
            # directional glyphs the along-axis span is the orientation signal:
            # it must land on the requested direction, including the
            # antiparallel -x case a naive rotation gets backwards.
            assert (along.min(), along.max()) == pytest.approx(
                np.array(span) * size, abs=1e-5
            )


# -- 8. instanced_mesh: merge per color, fold alpha, single cloud -------------
def test_instanced_mesh_merge_and_cloud(lite):
    """Instances sharing a color merge into one drawn object; alpha folds into opacity."""
    positions = np.array([[0.0, 0, 0], [1.0, 0, 0], [2.0, 0, 0]])
    colors = np.array([[1.0, 0, 0, 0.25], [0, 1.0, 0, 1.0], [1.0, 0, 0, 0.25]])
    quats = np.zeros((3, 3))  # identity, MNE's (x, y, z) convention
    _, cloud = lite.instanced_mesh(_RR, _TRIS, positions, quats, colors, opacity=0.5)
    # Two distinct colors over three instances -> two drawn objects (the two red
    # instances merged), read through the drawn-object collection rather than the
    # return value so any grouping that produces the right objects passes. Each
    # object's per-instance alpha folds into its opacity (0.25 * 0.5 = 0.125).
    got = {tuple(a["color"]): a["opacity"] for a in _actors(lite)}
    assert got == pytest.approx({(1.0, 0.0, 0.0): 0.125, (0.0, 1.0, 0.0): 0.5})
    # the point cloud handed back carries one point per instance (the anchor
    # plot_alignment writes channel names onto)
    assert_allclose(np.asarray(cloud.points), positions)


# -- 9. browser-impossible operations raise NotImplementedError ---------------
def test_unsupported_operations_refuse(lite):
    """The operations base.md lists as out of scope each refuse cleanly.

    Only the operations the task states are out of scope are required to refuse:
    contours, scalar bars, legends, subplots, and in-kernel screenshots. Each
    must raise a clean ``NotImplementedError`` rather than silently drawing
    something misleading; the exact wording is the backend's choice (its
    informativeness is judged in the rubric, not pinned here). Operations the
    task does *not* declare out of scope (e.g. 2D projection or text
    justification) are the solution's call and are not asserted here.
    """
    surf = dict(rr=np.zeros((3, 3)), tris=np.array([[0, 1, 2]]))
    cases = [
        lambda: lite.contour(surface=surf, scalars=np.zeros(3), contours=[0.5], kind="line"),
        lambda: lite.scalarbar(source=None, title="bar"),
        lambda: lite.legend(labels=[]),
        lambda: lite.subplot(0, 0),
    ]
    for call in cases:
        with pytest.raises(NotImplementedError):
            call()
    # the module-level screenshot entry point refuses too
    with pytest.raises(NotImplementedError):
        _renderer_mod.backend._take_3d_screenshot(lite.scene())


# -- 10. camera round-trips azimuth/elevation ---------------------------------
def test_camera_round_trip(lite):
    """set_camera / set_3d_view orient the scene; the view reads back what was set."""
    # set both angles explicitly so the round-trip never depends on an
    # implementation-specific default for the angle left unset
    lite.set_camera(azimuth=180.0, elevation=90.0)
    assert _read_view(lite) == pytest.approx((180.0, 90.0))
    # the module-level view setter orients the same figure; setting one angle
    # keeps the other
    _renderer_mod.set_3d_view(lite.scene(), elevation=45.0)
    assert _read_view(lite) == pytest.approx((180.0, 45.0))
    _renderer_mod.set_3d_view(lite.scene(), azimuth=90.0)
    assert _read_view(lite) == pytest.approx((90.0, 45.0))


# -- 11. automatic selection never picks the browser backend ------------------
def test_auto_selection_excludes_browser():
    """jupyterlite is selectable only explicitly; auto-selection never reaches it."""
    saved = (_renderer_mod.MNE_3D_BACKEND, _renderer_mod.backend)
    try:
        # explicit selection works (before the fix: name unregistered -> ValueError)
        set_3d_backend(BACKEND)
        assert _renderer_mod.get_3d_backend() == BACKEND
        # but with nothing chosen, automatic fallback must NOT land on it. On this
        # image the VTK desktop backends cannot import, so a solution that left the
        # browser backend in the auto-fallback set would wrongly select it here.
        _renderer_mod.MNE_3D_BACKEND = None
        auto = _renderer_mod.get_3d_backend()  # None if nothing desktop loads
        assert auto != BACKEND
    finally:
        try:
            _renderer_mod.backend._close_all()
        except Exception:
            pass
        _renderer_mod.MNE_3D_BACKEND, _renderer_mod.backend = saved
