## Task

on a stacked bar chart we have two options that interact badly. "Split stack by" takes a second dimension and breaks each x-axis cluster into several side-by-side stacks. "Only Total" drops the per-segment labels and instead shows a single total value on top of each stack.

turn both on at the same time and only one total label shows up for the whole x-axis cluster, not one per stack group. each split stack should be carrying its own total on top. with "Split stack by" switched off, "Only Total" labels every stack correctly, so it's specifically the combination that's broken.

dig in and fix it so every stack group in a cluster gets its own total label.
