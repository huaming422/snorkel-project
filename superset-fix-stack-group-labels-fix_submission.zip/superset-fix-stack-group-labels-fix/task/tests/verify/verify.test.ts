/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

// @ts-nocheck
//
// Behavioural verifier for the stacked-bar split-stack total-label defect.
//
// Every assertion drives the plugin's default-export props-transform
// (`transformProps` from Timeseries/transformProps.ts) and reads only its
// OBSERVABLE output: each `echartOptions.series[].stack` group key and the
// string each `series[].label.formatter({ value, dataIndex, seriesIndex })`
// returns. These are the same surfaces the plugin's own unit suite inspects,
// so any internally-different-but-behaviourally-correct implementation passes:
// the per-group mapping can be a null-proto object, a Map or prefixed keys;
// the non-split default group can use any sentinel; the label-map offset can
// be computed inline or in a helper, under any identifier naming. Nothing
// here imports an implementation-introduced symbol or asserts an internal name.
//
// The chart-props fixture builders below mirror the plugin's existing
// test/Timeseries helpers (shared createEchartsTimeseriesTestChartProps plus a
// local query-data builder) so the relative imports resolve exactly as the
// in-repo Timeseries suite's do when this file runs from test/Timeseries.

import {
  ChartDataResponseResult,
  DataRecord,
  SqlaFormData,
} from '@superset-ui/core';
import { GenericDataType } from '@apache-superset/core/common';
import transformProps from '../../src/Timeseries/transformProps';
import {
  EchartsTimeseriesChartProps,
  EchartsTimeseriesFormData,
} from '../../src/types';
import { StackControlsValue } from '../../src/constants';
import { DEFAULT_FORM_DATA } from '../../src/Timeseries/constants';
import { createEchartsTimeseriesTestChartProps } from '../helpers';
import { BASE_TIMESTAMP } from './helpers';

// Minimal, fully-typed-at-runtime query-data builder: fills the required
// ChartDataResponseResult fields and lets a test override colnames / coltypes /
// label_map, which is what the multi-metric / multi-groupby scenarios need.
function createTestQueryData(
  data: unknown[],
  overrides?: Partial<ChartDataResponseResult> & {
    label_map?: Record<string, string[]>;
  },
): ChartDataResponseResult {
  return {
    annotation_data: null,
    cache_key: null,
    cache_timeout: null,
    cached_dttm: null,
    queried_dttm: null,
    data: data as DataRecord[],
    colnames: [],
    coltypes: [],
    error: null,
    is_cached: false,
    query: '',
    rowcount: data.length,
    sql_rowcount: data.length,
    stacktrace: null,
    status: 'success',
    from_dttm: null,
    to_dttm: null,
    label_map: {},
    ...overrides,
  } as ChartDataResponseResult;
}

// createEchartsTimeseriesTestChartProps expects defaultQueriesData as an array;
// merge the scenario's formData over the plugin defaults and build the props.
function makeChartProps(
  formData: Partial<EchartsTimeseriesFormData>,
  queriesData: ChartDataResponseResult[],
): EchartsTimeseriesChartProps {
  return createEchartsTimeseriesTestChartProps<
    EchartsTimeseriesFormData,
    EchartsTimeseriesChartProps
  >({
    defaultFormData: { ...DEFAULT_FORM_DATA, ...formData },
    defaultVizType: 'my_viz',
    defaultQueriesData: queriesData,
  });
}

const baseFormData: SqlaFormData = {
  colorScheme: 'bnbColors',
  datasource: '3__table',
  granularity_sqla: 'ds',
  metric: 'sum__num',
  groupby: ['foo', 'bar'],
  viz_type: 'my_viz',
};

type SeriesLike = {
  name?: string;
  stack?: string;
  data: unknown[];
  label: { formatter: (params: unknown) => string };
};

function getSeries(
  chartProps: EchartsTimeseriesChartProps,
): SeriesLike[] {
  return transformProps(chartProps).echartOptions.series as SeriesLike[];
}

describe('split-stack total labels verifier', () => {
  // ------------------------------------------------------------------
  // crit_multimetric_offset + crit_per_group_total_labels + crit_stack_assignment
  //
  // Two metrics, two group-by columns, split dimension = the SECOND group-by.
  // The split dimension must be resolved at the correct label-map offset:
  // series split by their region value (East/West), NOT by the first group-by
  // (dept). Each region group's total label shows that region's own sum
  // (10+20=30, 100+200=300); the other series in the group render ''.
  // A missing/wrong offset splits by dept -> totals 110/220, or a single label.
  // ------------------------------------------------------------------
  test('assigns stack by the configured split dimension and labels each group with its own total (multi-metric, multi-groupby)', () => {
    const multiMetricFormData: Partial<EchartsTimeseriesFormData> = {
      viz_type: 'my_viz',
      colorScheme: 'bnbColors',
      datasource: '3__table',
      granularity_sqla: 'ds',
      metrics: ['sales', 'profit'],
      groupby: ['dept', 'region'],
      stackDimension: 'region',
      stack: StackControlsValue.Stack,
      onlyTotal: true,
      showValue: true,
    };

    const multiMetricQueriesData: ChartDataResponseResult[] = [
      createTestQueryData(
        [
          {
            __timestamp: BASE_TIMESTAMP,
            'sales, HR, East': 10,
            'profit, Sales, East': 20,
            'sales, HR, West': 100,
            'profit, Sales, West': 200,
          },
        ],
        {
          colnames: [
            '__timestamp',
            'sales, HR, East',
            'profit, Sales, East',
            'sales, HR, West',
            'profit, Sales, West',
          ],
          coltypes: [
            GenericDataType.Temporal,
            GenericDataType.Numeric,
            GenericDataType.Numeric,
            GenericDataType.Numeric,
            GenericDataType.Numeric,
          ],
          label_map: {
            'sales, HR, East': ['sales', 'HR', 'East'],
            'profit, Sales, East': ['profit', 'Sales', 'East'],
            'sales, HR, West': ['sales', 'HR', 'West'],
            'profit, Sales, West': ['profit', 'Sales', 'West'],
          },
        },
      ),
    ];

    const series = getSeries(
      makeChartProps(multiMetricFormData, multiMetricQueriesData),
    );

    const eastSeries = series.filter(s => s.name?.includes('East'));
    const westSeries = series.filter(s => s.name?.includes('West'));

    expect(eastSeries).toHaveLength(2);
    expect(westSeries).toHaveLength(2);

    // Stack assignment keyed by the split dimension's value, not by 'dept'.
    eastSeries.forEach(s => expect(s.stack).toBe('East'));
    westSeries.forEach(s => expect(s.stack).toBe('West'));

    // Each group's topmost series carries that group's own total; the other
    // series in the group renders an empty label.
    const eastLabels = eastSeries.map(s =>
      s.label.formatter({
        value: s.data[0],
        dataIndex: 0,
        seriesIndex: series.indexOf(s),
      }),
    );
    expect(eastLabels).toContain('30');
    expect(eastLabels).toContain('');

    const westLabels = westSeries.map(s =>
      s.label.formatter({
        value: s.data[0],
        dataIndex: 0,
        seriesIndex: series.indexOf(s),
      }),
    );
    expect(westLabels).toContain('300');
    expect(westLabels).toContain('');

    // Guard against the dept-split failure mode explicitly: no group total
    // should equal a dept-group sum (HR=110, Sales=220).
    expect(eastLabels).not.toContain('110');
    expect(eastLabels).not.toContain('220');
    expect(westLabels).not.toContain('110');
    expect(westLabels).not.toContain('220');
  });

  // ------------------------------------------------------------------
  // crit_stack_assignment — at least two distinct stack groups, one per value.
  // ------------------------------------------------------------------
  test('produces one distinct stack group per split-dimension value', () => {
    const stackDimensionFormData: Partial<EchartsTimeseriesFormData> = {
      ...(baseFormData as EchartsTimeseriesFormData),
      x_axis: 'region',
      metric: ['count', 'revenue'],
      metrics: ['count', 'revenue'],
      groupby: ['region', 'size'],
      stack: StackControlsValue.Stack,
      stackDimension: 'size',
      showValue: true,
      onlyTotal: true,
    };

    const stackDimensionData: ChartDataResponseResult[] = [
      createTestQueryData(
        [
          {
            __timestamp: 1609459200000,
            'count, East, Large': 10,
            'revenue, East, Large': 100,
            'count, East, Small': 5,
            'revenue, East, Small': 50,
            'count, West, Large': 8,
            'revenue, West, Large': 80,
            'count, West, Small': 4,
            'revenue, West, Small': 40,
          },
        ],
        {
          colnames: [
            '__timestamp',
            'count, East, Large',
            'revenue, East, Large',
            'count, East, Small',
            'revenue, East, Small',
            'count, West, Large',
            'revenue, West, Large',
            'count, West, Small',
            'revenue, West, Small',
          ],
          coltypes: [
            GenericDataType.Temporal,
            GenericDataType.Numeric,
            GenericDataType.Numeric,
            GenericDataType.Numeric,
            GenericDataType.Numeric,
            GenericDataType.Numeric,
            GenericDataType.Numeric,
            GenericDataType.Numeric,
          ],
          label_map: {
            'count, East, Large': ['count', 'East', 'Large'],
            'revenue, East, Large': ['revenue', 'East', 'Large'],
            'count, East, Small': ['count', 'East', 'Small'],
            'revenue, East, Small': ['revenue', 'East', 'Small'],
            'count, West, Large': ['count', 'West', 'Large'],
            'revenue, West, Large': ['revenue', 'West', 'Large'],
            'count, West, Small': ['count', 'West', 'Small'],
            'revenue, West, Small': ['revenue', 'West', 'Small'],
          },
        },
      ),
    ];

    const series = getSeries(
      makeChartProps(stackDimensionFormData, stackDimensionData),
    );

    const stackedSeries = series.filter(s => s.stack !== undefined);
    expect(stackedSeries.length).toBeGreaterThan(0);

    const stackKeys = new Set(stackedSeries.map(s => s.stack));
    expect(stackKeys.has('Large')).toBe(true);
    expect(stackKeys.has('Small')).toBe(true);
    expect(stackKeys.size).toBeGreaterThanOrEqual(2);
  });

  // ------------------------------------------------------------------
  // crit_stale_dimension_safe — split dimension configured but not in groupby:
  // must not throw; degrades to single-group labeling.
  // ------------------------------------------------------------------
  test('degrades gracefully when the split dimension is stale (not among group-by columns)', () => {
    const staleFormData: Partial<EchartsTimeseriesFormData> = {
      viz_type: 'my_viz',
      colorScheme: 'bnbColors',
      datasource: '3__table',
      granularity_sqla: 'ds',
      metrics: ['sales', 'profit'],
      groupby: ['dept'],
      stackDimension: 'removed_dimension',
      stack: StackControlsValue.Stack,
      onlyTotal: true,
      showValue: true,
    };

    const staleQueriesData: ChartDataResponseResult[] = [
      createTestQueryData(
        [
          {
            __timestamp: BASE_TIMESTAMP,
            'sales, HR': 10,
            'profit, Sales': 20,
          },
        ],
        {
          colnames: ['__timestamp', 'sales, HR', 'profit, Sales'],
          coltypes: [
            GenericDataType.Temporal,
            GenericDataType.Numeric,
            GenericDataType.Numeric,
          ],
          label_map: {
            'sales, HR': ['sales', 'HR'],
            'profit, Sales': ['profit', 'Sales'],
          },
        },
      ),
    ];

    const chartProps = makeChartProps(staleFormData, staleQueriesData);

    expect(() => transformProps(chartProps)).not.toThrow();

    // Still renders a (single-group) total label — not vacuous.
    const series = getSeries(chartProps);
    const labels = series.map(s =>
      s.label.formatter({
        value: s.data[0],
        dataIndex: 0,
        seriesIndex: series.indexOf(s),
      }),
    );
    // The single group's total is 10 + 20 = 30; exactly one series shows it.
    expect(labels).toContain('30');
  });

  // ------------------------------------------------------------------
  // crit_proto_safe — split-dimension values equal to prototype property
  // names must become their own stack groups with correct totals, not corrupt
  // the per-group mapping.
  // ------------------------------------------------------------------
  test('handles split-dimension values matching prototype property names', () => {
    const protoFormData: Partial<EchartsTimeseriesFormData> = {
      viz_type: 'my_viz',
      colorScheme: 'bnbColors',
      datasource: '3__table',
      granularity_sqla: 'ds',
      metrics: ['sales', 'profit'],
      groupby: ['category', 'region'],
      stackDimension: 'category',
      stack: StackControlsValue.Stack,
      onlyTotal: true,
      showValue: true,
    };

    const protoQueriesData: ChartDataResponseResult[] = [
      createTestQueryData(
        [
          {
            __timestamp: BASE_TIMESTAMP,
            'sales, __proto__, East': 50,
            'profit, constructor, East': 60,
          },
        ],
        {
          colnames: [
            '__timestamp',
            'sales, __proto__, East',
            'profit, constructor, East',
          ],
          coltypes: [
            GenericDataType.Temporal,
            GenericDataType.Numeric,
            GenericDataType.Numeric,
          ],
          label_map: {
            'sales, __proto__, East': ['sales', '__proto__', 'East'],
            'profit, constructor, East': ['profit', 'constructor', 'East'],
          },
        },
      ),
    ];

    const series = getSeries(makeChartProps(protoFormData, protoQueriesData));

    expect(series).toHaveLength(2);
    const protoSeries = series.find(s => s.name?.includes('__proto__'));
    const ctorSeries = series.find(s => s.name?.includes('constructor'));

    expect(protoSeries).toBeDefined();
    expect(ctorSeries).toBeDefined();

    expect(protoSeries!.stack).toBe('__proto__');
    expect(ctorSeries!.stack).toBe('constructor');

    const protoLabel = protoSeries!.label.formatter({
      value: protoSeries!.data[0],
      dataIndex: 0,
      seriesIndex: series.indexOf(protoSeries!),
    });
    expect(protoLabel).toBe('50');

    const ctorLabel = ctorSeries!.label.formatter({
      value: ctorSeries!.data[0],
      dataIndex: 0,
      seriesIndex: series.indexOf(ctorSeries!),
    });
    expect(ctorLabel).toBe('60');
  });

  // ------------------------------------------------------------------
  // crit_backward_compat_single_group (pass_to_pass regression guard) —
  // a plain stacked onlyTotal chart with NO split dimension still renders
  // exactly one total label per x position.
  // ------------------------------------------------------------------
  test('keeps one total label per x position for non-split stacked onlyTotal charts', () => {
    const noSplitFormData: Partial<EchartsTimeseriesFormData> = {
      viz_type: 'my_viz',
      colorScheme: 'bnbColors',
      datasource: '3__table',
      granularity_sqla: 'ds',
      metric: 'sum__num',
      groupby: ['city'],
      stack: StackControlsValue.Stack,
      onlyTotal: true,
      showValue: true,
    };

    const noSplitQueriesData: ChartDataResponseResult[] = [
      createTestQueryData(
        [
          {
            __timestamp: BASE_TIMESTAMP,
            'San Francisco': 1,
            'New York': 2,
          },
          {
            __timestamp: BASE_TIMESTAMP + 300000000,
            'San Francisco': 3,
            'New York': 4,
          },
        ],
        {
          colnames: ['__timestamp', 'San Francisco', 'New York'],
          coltypes: [
            GenericDataType.Temporal,
            GenericDataType.Numeric,
            GenericDataType.Numeric,
          ],
          label_map: {
            'San Francisco': ['San Francisco'],
            'New York': ['New York'],
          },
        },
      ),
    ];

    const series = getSeries(
      makeChartProps(noSplitFormData, noSplitQueriesData),
    );

    // No split dimension => every series shares a single stack group (the
    // split-dimension value never overrides the base stack id), so there is
    // one group, not several.
    expect(new Set(series.map(s => s.stack)).size).toBe(1);

    // For each x position, exactly one series renders a non-empty total label.
    [0, 1].forEach(dataIndex => {
      const labels = series.map(s =>
        s.label.formatter({
          value: s.data[dataIndex],
          dataIndex,
          seriesIndex: series.indexOf(s),
        }),
      );
      const nonEmpty = labels.filter(l => l !== '');
      expect(nonEmpty).toHaveLength(1);
    });

    // The one label at each position is the stack total across both series
    // (1+2=3 at position 0, 3+4=7 at position 1).
    const labelsAt0 = series.map(s =>
      s.label.formatter({ value: s.data[0], dataIndex: 0, seriesIndex: series.indexOf(s) }),
    );
    expect(labelsAt0).toContain('3');
    const labelsAt1 = series.map(s =>
      s.label.formatter({ value: s.data[1], dataIndex: 1, seriesIndex: series.indexOf(s) }),
    );
    expect(labelsAt1).toContain('7');
  });
});
