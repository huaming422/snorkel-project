#!/usr/bin/env bash
# Environment bootstrap for the verifier. Sourced (not exec'd) so any env vars
# set here stay live for the verifier subprocess that runs the jest verifier.
#
# This task exercises ONLY the React/TypeScript frontend (the
# plugin-chart-echarts props-transform) via jest. There is no backend,
# database, or service to bring up.
#
# The image BAKES the full frontend dependency closure at the base commit
# (npm ci into node_modules) for the offline agent phase, so there is nothing
# to install here: node_modules is already present and the verifier phase has
# no npm-registry access (allowlist = model gateway only). This script just
# verifies the baked install is intact and reports readiness.

set -e
set -o pipefail

# Non-login shells may start with a minimal PATH; bake in the standard set so
# node/npx (installed under /usr/local by the image) are always reachable.
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin${PATH:+:$PATH}"

REPO_DIR="${REPO_DIR:-/repo/superset}"
export REPO_DIR
FRONTEND_DIR="${REPO_DIR}/superset-frontend"

cd "$FRONTEND_DIR"

# The baked node_modules must contain the jest binary. If it is missing the
# image build is corrupt — fail loudly rather than attempting a doomed offline
# reinstall (the verifier phase cannot reach the npm registry).
if ! [ -x node_modules/.bin/jest ]; then
    echo "test-setup.sh: FATAL — node_modules/.bin/jest is missing from" \
         "$FRONTEND_DIR. The image did not bake the frontend dependency" \
         "closure; rebuild the image." >&2
    exit 1
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR node=$(node --version)" \
     "jest=$(node_modules/.bin/jest --version 2>/dev/null || echo unknown)"
