//go:build integration

// Behavioral checks for the second tier of GET /api/v1/jobs/find — the step that
// resolves a job page URL to the catalog posting stored under it, exercised through
// the pre-existing DB query (*Queries).FindOpenJobByURL. The normalization and the
// open/dedup gate are SQL behaviors, so every case runs against the baked PostgreSQL
// via testdb.Pool. Each top-level function maps to one task criterion; a self-prefixed
// (vrfy*) set of helpers keeps this file independent of the repo's own test fixtures,
// which the injected package may compile alongside.
//
// Run with: go test -tags=integration ./internal/db/
package db

import (
	"context"
	"encoding/json"
	"errors"
	"strings"
	"testing"

	"github.com/strelov1/freehire/internal/testdb"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

// vrfyInsert creates one open posting (duplicate_of NULL, closed_at NULL,
// last_seen_at default now()) storing the given detail URL and slug; returns its id.
func vrfyInsert(t *testing.T, pool *pgxpool.Pool, source, extID, url, slug string) int64 {
	t.Helper()
	var id int64
	err := pool.QueryRow(context.Background(),
		`INSERT INTO jobs (source, external_id, url, title, public_slug)
		 VALUES ($1, $2, $3, $4, $5) RETURNING id`,
		source, extID, url, "A Role", slug).Scan(&id)
	if err != nil {
		t.Fatalf("seed posting %s: %v", extID, err)
	}
	return id
}

// vrfyMarkDuplicate points one row at another as the group representative.
func vrfyMarkDuplicate(t *testing.T, pool *pgxpool.Pool, dupID, canonicalID int64) {
	t.Helper()
	if _, err := pool.Exec(context.Background(),
		"UPDATE jobs SET duplicate_of = $1 WHERE id = $2", canonicalID, dupID); err != nil {
		t.Fatalf("mark %d duplicate of %d: %v", dupID, canonicalID, err)
	}
}

// vrfyClose stamps closed_at so the row is no longer an open posting.
func vrfyClose(t *testing.T, pool *pgxpool.Pool, id int64) {
	t.Helper()
	if _, err := pool.Exec(context.Background(),
		"UPDATE jobs SET closed_at = now() WHERE id = $1", id); err != nil {
		t.Fatalf("close %d: %v", id, err)
	}
}

// vrfyAge pushes a row's last_seen_at back so recency ordering is controllable.
func vrfyAge(t *testing.T, pool *pgxpool.Pool, id int64, interval string) {
	t.Helper()
	if _, err := pool.Exec(context.Background(),
		"UPDATE jobs SET last_seen_at = now() - $1::interval WHERE id = $2", interval, id); err != nil {
		t.Fatalf("age %d: %v", id, err)
	}
}

func vrfyFind(t *testing.T, q *Queries, url string) (string, error) {
	t.Helper()
	return q.FindOpenJobByURL(context.Background(), url)
}

const (
	vrfyPageURL  = "https://jobs.ashbyhq.com/truelogic/c6d2719d"
	vrfyOtherURL = "https://jobs.ashbyhq.com/truelogic/ef27e902"
)

// A page URL belonging to an open duplicate posting must resolve to the posting it
// duplicates — the merged twin the candidate is standing on is a vacancy the catalog
// holds, so answering "not carried" is the reported symptom. (dup_resolves_to_canonical)
func TestVerifyDupResolvesToCanonical(t *testing.T) {
	pool := testdb.Pool(t)
	q := New(pool)

	canonicalID := vrfyInsert(t, pool, "ashby", "truelogic:canonical", vrfyOtherURL, "slug-canonical")
	dupID := vrfyInsert(t, pool, "ashby", "truelogic:dup", vrfyPageURL, "slug-duplicate")
	vrfyMarkDuplicate(t, pool, dupID, canonicalID)

	slug, err := vrfyFind(t, q, vrfyPageURL)
	if err != nil {
		t.Fatalf("duplicate page resolved to an error: %v", err)
	}
	if slug != "slug-canonical" {
		t.Errorf("duplicate page resolved to %q, want the canonical posting's slug %q", slug, "slug-canonical")
	}
}

// A duplicate whose representative has since closed must fall back to its OWN slug: it
// is still open, and reporting nothing would hide a live vacancy. This case also rejects
// an INNER-JOIN / no-fallback resolution, which drops the row entirely here.
// (closed_canonical_fallback)
func TestVerifyClosedCanonicalFallback(t *testing.T) {
	pool := testdb.Pool(t)
	q := New(pool)

	canonicalID := vrfyInsert(t, pool, "ashby", "truelogic:canonical", vrfyOtherURL, "slug-canonical")
	dupID := vrfyInsert(t, pool, "ashby", "truelogic:dup", vrfyPageURL, "slug-duplicate")
	vrfyMarkDuplicate(t, pool, dupID, canonicalID)
	vrfyClose(t, pool, canonicalID)

	slug, err := vrfyFind(t, q, vrfyPageURL)
	if err != nil {
		t.Fatalf("duplicate of a closed representative resolved to an error: %v", err)
	}
	if slug != "slug-duplicate" {
		t.Errorf("resolved to %q, want the duplicate's own slug %q (its representative is closed)", slug, "slug-duplicate")
	}
}

// A closed posting's URL and a genuinely unknown URL must both resolve to nothing: the
// widening to duplicates must not start matching closed rows or fabricating matches.
// (closed_and_unknown_unresolved)
func TestVerifyClosedAndUnknownUnresolved(t *testing.T) {
	pool := testdb.Pool(t)
	q := New(pool)

	closedID := vrfyInsert(t, pool, "ashby", "truelogic:closed", vrfyPageURL, "slug-closed")
	vrfyClose(t, pool, closedID)

	if slug, err := vrfyFind(t, q, vrfyPageURL); !errors.Is(err, pgx.ErrNoRows) {
		t.Errorf("closed posting resolved to %q (err %v), want no row", slug, err)
	}

	if slug, err := vrfyFind(t, q, "https://example.test/careers/unheard-of"); !errors.Is(err, pgx.ErrNoRows) {
		t.Errorf("unknown page resolved to %q (err %v), want no row", slug, err)
	}
}

// Cosmetic URL variants of the same posting still resolve to it, and two open canonical
// rows on one URL resolve to the most-recently-seen one. The widening must not regress
// normalization or the recency tiebreak. (normalization_and_recency_preserved)
func TestVerifyNormalizationAndRecencyPreserved(t *testing.T) {
	pool := testdb.Pool(t)
	q := New(pool)

	t.Run("cosmetic variants still resolve", func(t *testing.T) {
		vrfyInsert(t, pool, "ashby", "truelogic:noise", vrfyPageURL, "slug-noise")
		for _, requested := range []string{
			vrfyPageURL,
			vrfyPageURL + "?utm_source=freehire.me",
			"http://jobs.ashbyhq.com/truelogic/c6d2719d",
			"https://www.jobs.ashbyhq.com/truelogic/c6d2719d/",
			vrfyPageURL + "#apply",
		} {
			slug, err := vrfyFind(t, q, requested)
			if err != nil {
				t.Errorf("variant %q resolved to an error: %v", requested, err)
				continue
			}
			if slug != "slug-noise" {
				t.Errorf("variant %q resolved to %q, want the seeded posting %q", requested, slug, "slug-noise")
			}
		}
	})

	t.Run("most recently seen canonical wins", func(t *testing.T) {
		if _, err := pool.Exec(context.Background(), "TRUNCATE jobs RESTART IDENTITY CASCADE"); err != nil {
			t.Fatalf("reset: %v", err)
		}
		staleID := vrfyInsert(t, pool, "ashby", "truelogic:stale", vrfyPageURL, "slug-stale")
		vrfyInsert(t, pool, "greenhouse", "truelogic:fresh", vrfyPageURL, "slug-fresh")
		vrfyAge(t, pool, staleID, "10 days")

		slug, err := vrfyFind(t, q, vrfyPageURL)
		if err != nil {
			t.Fatalf("two open rows on one URL resolved to an error: %v", err)
		}
		if slug != "slug-fresh" {
			t.Errorf("resolved to %q, want the most recently seen posting %q", slug, "slug-fresh")
		}
	})
}

// The lookup must ride an expression index over the normalized URL rather than
// sequentially scanning the jobs table. With seqscan disabled, EXPLAIN the generated
// query itself and assert the plan (a) does not fall back to a Seq Scan on jobs and
// (b) rides an index whose definition is the normalized-URL expression. The pre-fix
// canonical-only index cannot serve the widened lookup — it is scoped to rows the
// widened query no longer filters on, so with seqscan off the planner must seq-scan
// and this fails — while any valid widened index (partial or not, any name, any
// dedup-scoped predicate) passes: correctness is carried by the query, so this gate
// only guards the no-seqscan property, not the index's shape. (uses_expression_index)
func TestVerifyUsesExpressionIndex(t *testing.T) {
	pool := testdb.Pool(t)
	ctx := context.Background()

	vrfyInsert(t, pool, "ashby", "truelogic:plan", vrfyPageURL, "slug-plan")

	// A single pooled session: the planner hint and the EXPLAIN must share one connection.
	conn, err := pool.Acquire(ctx)
	if err != nil {
		t.Fatalf("acquire connection: %v", err)
	}
	defer conn.Release()

	if _, err := conn.Exec(ctx, "SET enable_seqscan = off"); err != nil {
		t.Fatalf("disable seqscan: %v", err)
	}

	// EXPLAIN the generated query constant itself, not a copy — a copy would keep
	// passing after the real query drifted from any index.
	var planJSON []byte
	if err := conn.QueryRow(ctx, "EXPLAIN (FORMAT JSON) "+findOpenJobByURL, vrfyPageURL).Scan(&planJSON); err != nil {
		t.Fatalf("explain generated query: %v", err)
	}

	var plan []map[string]any
	if err := json.Unmarshal(planJSON, &plan); err != nil {
		t.Fatalf("parse plan JSON: %v", err)
	}

	// With seqscan disabled, a plan that still sequentially scans the jobs table is the
	// pre-fix state: the only normalized-URL index is 0042's canonical-only partial
	// index, whose predicate the widened query no longer implies, so the planner cannot
	// use it and falls back to a seq scan. Any valid widened index removes that fallback.
	for _, entry := range plan {
		if vrfyHasSeqScanOnJobs(entry) {
			t.Fatalf("with enable_seqscan=off the lookup still sequentially scans the jobs table "+
				"— no usable normalized-URL index serves the widened query:\n%s", planJSON)
		}
	}

	used := map[string]bool{}
	for _, entry := range plan {
		vrfyCollectIndexNames(entry, used)
	}
	if len(used) == 0 {
		t.Fatalf("plan uses no index at all:\n%s", planJSON)
	}

	// At least one index the plan chose must be an expression index over the normalized
	// URL. The predicate shape is the agent's call — a non-partial index, a
	// `WHERE closed_at IS NULL` partial, or a `... OR duplicate_of IS NOT NULL` partial
	// all qualify — so the definition is read only for the normalize_job_url expression,
	// never for its dedup scoping. Correctness is carried by the query itself; this gate
	// only confirms the hot lookup rides an index rather than scanning.
	for name := range used {
		var def string
		if err := conn.QueryRow(ctx,
			"SELECT indexdef FROM pg_indexes WHERE schemaname = 'public' AND indexname = $1", name).Scan(&def); err != nil {
			if errors.Is(err, pgx.ErrNoRows) {
				continue
			}
			t.Fatalf("read definition of index %q: %v", name, err)
		}
		if strings.Contains(def, "normalize_job_url") {
			return
		}
	}

	defs := make([]string, 0, len(used))
	for name := range used {
		defs = append(defs, name)
	}
	t.Errorf("lookup does not ride a normalized-URL expression index; indexes used: %v\nplan:\n%s",
		defs, planJSON)
}

// vrfyHasSeqScanOnJobs reports whether any node in an EXPLAIN (FORMAT JSON) plan tree
// is a sequential scan over the jobs table, at any depth.
func vrfyHasSeqScanOnJobs(node any) bool {
	switch n := node.(type) {
	case map[string]any:
		if nt, _ := n["Node Type"].(string); nt == "Seq Scan" {
			if rel, _ := n["Relation Name"].(string); rel == "jobs" {
				return true
			}
		}
		for _, v := range n {
			if vrfyHasSeqScanOnJobs(v) {
				return true
			}
		}
	case []any:
		for _, v := range n {
			if vrfyHasSeqScanOnJobs(v) {
				return true
			}
		}
	}
	return false
}

// vrfyCollectIndexNames walks an EXPLAIN (FORMAT JSON) plan tree collecting every
// "Index Name" the planner reports, at any depth.
func vrfyCollectIndexNames(node any, out map[string]bool) {
	switch n := node.(type) {
	case map[string]any:
		if name, ok := n["Index Name"].(string); ok && name != "" {
			out[name] = true
		}
		for _, v := range n {
			vrfyCollectIndexNames(v, out)
		}
	case []any:
		for _, v := range n {
			vrfyCollectIndexNames(v, out)
		}
	}
}
