## Task

freehire ships a browser extension whose side panel, while a candidate reads a job
posting on a company careers site or a job board, tells them whether freehire
carries that same vacancy and links to freehire's own page for it.

Users keep reporting this: the panel says "freehire doesn't have this posting" for
a vacancy freehire clearly does carry. The match card for that exact role is right
there on the page behind the panel, and searching freehire directly finds it, so
the panel is simply wrong. Support sees it on roughly one in five job pages, always
on postings freehire has previously recognised as the same vacancy as another it
already had: roles published through more than one channel, which freehire folds
together so they show once.

Find out why the check misses these pages and make it recognise them, pointing the
candidate at the right freehire page. Pages freehire genuinely does not carry must
still come back as not carried. An integration test suite runs this lookup against
a real database; use it to reproduce and verify.
