## Task

Broker mode inside the sandbox can't finish a lone `lark-cli ...` call. With nothing piped in, redirected or fed by a heredoc, the call blocks for good, or until something outside gives up on it. Calls that get input through a pipe, heredoc or file work.

The pipe side has a worse problem. When the program feeding `lark-cli` stalls partway and dies later on, whatever it managed to write goes to the broker as if that were the whole request, and it gets run.

Fix both. A call with no input should run on empty input and return its normal result. A pipe that stays open and goes quiet, whether nothing has come through yet or it stopped partway, gets a non-zero exit and an error about the input within a couple of minutes, and nothing reaches the broker. A producer that takes a moment to start, or pauses between writes, still gets through. One that's very late can be refused, but the call never runs without its input. Stdin that can't be read at all gets refused the same way; today that turns into empty input and the call runs.

Everything else about how the sandbox runs commands stays as it is.
