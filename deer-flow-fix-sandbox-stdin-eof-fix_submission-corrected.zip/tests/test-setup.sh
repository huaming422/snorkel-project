#!/usr/bin/env bash
# test-setup.sh: sourced before the checks run.
#
# The DeerFlow backend dependency closure is baked into /opt/venv at image build
# time (Dockerfile block 10, `uv sync --frozen --group dev`). This script makes that
# venv active and prints whether the two modules the checks import load cleanly. A
# tree that doesn't import still goes on to the checks, which then report it.
set -euo pipefail

cd /repo/deer-flow/backend

# The checks may be started with a clean env, so set PATH and VIRTUAL_ENV explicitly
# rather than relying on inheritance.
export VIRTUAL_ENV=/opt/venv
export PATH="/opt/venv/bin:${PATH}"

# The repo's test suite imports first-party packages from these roots
# (deerflow.* lives under packages/harness; extension-api is a sibling
# package). conftest.py also wires sys.path, but exporting PYTHONPATH keeps
# a bare `pytest` invocation working regardless of entry point.
export PYTHONPATH=".:packages/harness:packages/extension-api"

if python -c "
from deerflow.community.aio_sandbox import aio_sandbox
from deerflow.integrations.lark_broker import (
    BrokerConfig, run_lark_cli, serve, LARK_CLI_BROKER_SHIM_SCRIPT,
)
assert isinstance(LARK_CLI_BROKER_SHIM_SCRIPT, str) and LARK_CLI_BROKER_SHIM_SCRIPT
"; then
    echo 'deer-flow sandbox/broker test env ready'
else
    echo 'deer-flow sandbox/broker modules did not import; going on to the checks' >&2
fi
