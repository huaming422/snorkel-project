"""Behavioral checks for how sandbox commands receive standard input in broker mode.

The sandbox runs a command through two transports. The persistent terminal
transport hands the command a pseudo-terminal as its input. The fresh
per-invocation transport hands it a pipe that stays open for the whole run.

These tests drive three public surfaces:

  * the ``bash`` tool in broker mode, running on a real ``AioSandbox``.
  * ``AioSandbox.execute_command`` / ``execute_command_in_scope``. In both of these
    the two transport callables are replaced by local subprocesses that model each
    transport's input channel: a pseudo-terminal, or a pipe nobody writes to and
    nobody closes.
  * the ``lark-cli`` launcher and shim from ``install_shim``, run as subprocesses
    against a loopback broker from ``serve(BrokerConfig(...))`` whose stand-in CLI
    writes down every call it receives.

Fixtures are self-contained because the backend suite's own ``tests/conftest.py``
is not in scope when this file is collected from the verifier directory.
"""

from __future__ import annotations

import json
import os
import re
import shlex
import subprocess
import sys
import textwrap
import threading
import time
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

# The backend suite's conftest registers a stand-in for this leaf module to break a
# circular import in the package __init__ chain (``deerflow.subagents.__init__`` ->
# ``.executor`` -> ... -> back to ``deerflow.subagents.executor``). The two modules
# under test can pull that chain in, so the same guard is repeated here.
if "deerflow.subagents.executor" not in sys.modules:
    _executor_stub = MagicMock()
    _executor_stub.SubagentExecutor = MagicMock
    _executor_stub.SubagentResult = MagicMock
    _executor_stub.SubagentStatus = MagicMock
    _executor_stub.MAX_CONCURRENT_SUBAGENTS = 3
    _executor_stub.get_background_task_result = MagicMock()
    sys.modules["deerflow.subagents.executor"] = _executor_stub


def _scaled(seconds: float) -> float:
    """Stretch a time limit on slow hosts. Pacing of the input stays as written."""
    try:
        multiplier = float(os.environ.get("TIMEOUT_MULTIPLIER") or 1)
    except ValueError:
        multiplier = 1.0
    return seconds * max(1.0, multiplier)


# How long a command that has what it needs gets to come back.
RETURN_LIMIT_SECONDS = _scaled(30)
# How long a command fed by a quiet pipe gets before it has to give up. The task
# text allows a couple of minutes.
GIVE_UP_LIMIT_SECONDS = _scaled(180)
# A producer this late to send its first byte has to be either waited for or
# refused, and never run without its input.
LATE_PRODUCER_SECONDS = _scaled(6)
# A producer this late is ordinary: a short script starting up, for one.
SHORT_START_SECONDS = 1.0
# A slow producer pauses this long between writes.
SLOW_GAP_SECONDS = 1.0
# It keeps writing past the five minutes the task text names.
KEEPS_COMING_SECONDS = 5 * 60 + 20
# About 730 KB, which still fits the broker's 1 MiB request limit once encoded.
LARGE_INPUT = "document body\n" * 52000

pytestmark = pytest.mark.skipif(
    os.name == "nt",
    reason="exercises the POSIX sandbox shell transports and '#!' broker scripts",
)


# --- AioSandbox transport modeling ---


@pytest.fixture()
def sandbox():
    """An ``AioSandbox`` whose SDK client is mocked (the backend suite's fixture)."""
    with patch("deerflow.community.aio_sandbox.aio_sandbox.AioSandboxClient"):
        from deerflow.community.aio_sandbox.aio_sandbox import AioSandbox

        return AioSandbox(id="test-sandbox", base_url="http://localhost:8080")


def _run_modeled(command, env, *, shell, terminal):
    """Run ``command`` with the input channel its transport gives it.

    ``terminal=True`` is a pseudo-terminal that stays open for the whole run. Otherwise
    it's a pipe nobody writes to and nobody closes. ``communicate()`` isn't used on that
    pipe, since closing it would change what's modeled.
    """
    terminal_fds = None
    stdin = subprocess.PIPE
    if terminal:
        import pty

        terminal_fds = pty.openpty()
        stdin = terminal_fds[1]
    proc = subprocess.Popen(
        [shell, "-c", command],
        stdin=stdin,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env={**os.environ, **(env or {})},
    )
    try:
        proc.wait(timeout=RETURN_LIMIT_SECONDS)
        stdout = proc.stdout.read().decode()
        stderr = proc.stderr.read().decode()
        return SimpleNamespace(
            data=SimpleNamespace(output=stdout, stdout=stdout, stderr=stderr, exit_code=proc.returncode)
        )
    finally:
        if proc.poll() is None:
            proc.kill()
        proc.communicate()
        if terminal_fds:
            for fd in terminal_fds:
                os.close(fd)


def _model_transports(sandbox, shell="/bin/sh"):
    # bash_exec takes the keyword arguments the SDK's BashClient.exec takes.
    def bash_exec(
        *,
        command,
        session_id=None,
        exec_dir=None,
        env=None,
        async_mode=None,
        timeout=None,
        hard_timeout=None,
        max_output_length=None,
        request_options=None,
    ):
        return _run_modeled(command, env, shell=shell, terminal=False)

    def shell_exec_command(*, command, **_kwargs):
        return _run_modeled(command, None, shell=shell, terminal=True)

    sandbox._client.bash.exec = bash_exec
    sandbox._client.shell.exec_command = shell_exec_command


@pytest.fixture()
def bash_tool_run(sandbox, monkeypatch, tmp_path):
    """Run a command through the bash tool on the sandbox, in broker mode."""
    from deerflow.integrations import lark_cli as lark_cli_module
    from deerflow.sandbox import tools

    (tmp_path / "virtual" / "workspace").mkdir(parents=True)
    monkeypatch.setattr(lark_cli_module, "sandbox_lark_broker_active", lambda *_args, **_kwargs: True)
    monkeypatch.setattr(tools, "VIRTUAL_PATH_PREFIX", str(tmp_path / "virtual"))
    monkeypatch.setattr(tools, "ensure_sandbox_initialized", lambda _runtime: sandbox)
    monkeypatch.setattr(tools, "ensure_thread_directories_exist", lambda _runtime: None)
    runtime = SimpleNamespace(state={"sandbox": {"sandbox_id": "aio:test"}}, context={"thread_id": "t1"}, config={})

    def run(command):
        return tools.bash_tool.func(runtime=runtime, description="run", command=command)

    return run


def _drive(sandbox, command, execution_path, *, env_extra=None, tool_run=None):
    """Drive ``command`` through one of the public execution entry points."""
    from deerflow.integrations.lark_broker import LARK_BROKER_URL_ENV

    if execution_path == "tool":
        # The bash tool sends a command that names lark-cli down the broker path.
        return tool_run(f"# lark-cli\n{command}")
    if execution_path == "env":
        env = {LARK_BROKER_URL_ENV: "http://127.0.0.1:8788"}
        if env_extra:
            env.update(env_extra)
        return sandbox.execute_command(command, env=env)
    if execution_path == "scope":
        return sandbox.execute_command_in_scope(command, scope_id="subagent")
    return sandbox.execute_command(command)


@pytest.mark.parametrize(
    ("input_kind", "execution_path"),
    [
        ("terminal", "shell"),
        ("terminal", "scope"),
        *[(kind, path) for kind in ("pipeline", "heredoc", "file") for path in ("shell", "scope", "env", "tool")],
    ],
)
def test_command_input_arrives_intact(sandbox, bash_tool_run, tmp_path, input_kind, execution_path):
    """A reader on the persistent transport sees a terminal, and pipe, heredoc and
    file input arrive byte for byte on every path."""
    reader = (
        f"{shlex.quote(sys.executable)} -c "
        "'import sys; print(\"tty\" if sys.stdin.isatty() else repr(sys.stdin.read()))'"
    )
    expected = "tty\n"
    command = reader
    if input_kind == "pipeline":
        command = f"printf 'pipeline input' | {reader}"
        expected = "'pipeline input'\n"
    elif input_kind == "heredoc":
        command = f"{reader} <<'INPUT'\nheredoc input\nINPUT"
        expected = "'heredoc input\\n'\n"
    elif input_kind == "file":
        input_file = tmp_path / "input with spaces.txt"
        input_file.write_text("file input", encoding="utf-8")
        command = f"{reader} < {shlex.quote(str(input_file))}"
        expected = "'file input'\n"

    _model_transports(sandbox)

    assert _drive(sandbox, command, execution_path, tool_run=bash_tool_run) == expected


@pytest.mark.parametrize("execution_path", ["shell", "scope", "env", "tool"])
@pytest.mark.parametrize(
    "command",
    [
        pytest.param("printf '[%s]' one two" + "\\", id="trailing_backslash_arg"),
        pytest.param("printf '%s-%s' a b" + "\\", id="trailing_backslash_after_args"),
    ],
)
def test_trailing_backslash_command_runs_like_the_unmodified_command(sandbox, bash_tool_run, execution_path, command):
    """A command ending in an unquoted backslash prints what bash prints for it when
    run on its own."""
    baseline = subprocess.run(
        ["/bin/bash", "-c", command],
        stdin=subprocess.DEVNULL,
        capture_output=True,
        timeout=_scaled(5),
    ).stdout.decode()

    _model_transports(sandbox, shell="/bin/bash")

    result = _drive(sandbox, command, execution_path, env_extra={"REQUEST_VALUE": "present"}, tool_run=bash_tool_run)
    assert result == baseline


@pytest.mark.parametrize("execution_path", ["shell", "scope", "env", "tool"])
@pytest.mark.parametrize(
    ("command", "expected", "exit_code"),
    [
        pytest.param(
            "shopt -s extglob\ncase test.py in *.@(py|sh)) printf extglob-ok;; esac",
            "extglob-ok",
            0,
            id="enable_extglob",
        ),
        pytest.param(
            "shopt -s expand_aliases\nalias project_status='printf alias-ok'\nproject_status",
            "alias-ok",
            0,
            id="define_alias",
        ),
        pytest.param("false | true\nprintf '%s' \"${PIPESTATUS[*]}\"", "1 0", 0, id="pipeline_status"),
        pytest.param("trap 'printf error-trap' ERR\nfalse", "error-trap", 1, id="error_trap"),
    ],
)
def test_bash_parsing_and_status_preserved(sandbox, bash_tool_run, execution_path, command, expected, exit_code):
    """Multi-line scripts that set shell options, define aliases, read ``PIPESTATUS``
    or set an ``ERR`` trap print what bash prints for them."""

    _model_transports(sandbox, shell="/bin/bash")

    result = _drive(sandbox, command, execution_path, env_extra={"REQUEST_VALUE": "present"}, tool_run=bash_tool_run)
    assert result == expected + (f"\nExit Code: {exit_code}" if exit_code else "")


def test_persistent_shell_preserves_session_state(sandbox, tmp_path):
    """Commands sent to the persistent transport share one session: working directory,
    exported variables, exit status, ``PIPESTATUS``, an ``ERR`` trap and the terminal's
    open input all carry across calls.
    """
    commands: list[str] = []

    def record_command(command, **_kwargs):
        commands.append(command)
        return SimpleNamespace(
            data=SimpleNamespace(output="ok", stdout="ok", stderr="", exit_code=0)
        )

    sandbox._client.shell.exec_command = record_command

    sandbox.execute_command(f"cd {shlex.quote(str(tmp_path))}; export SESSION_VALUE=preserved")
    sandbox.execute_command('printf "%s\\n" "$PWD" "$SESSION_VALUE"; exit 7')
    completed = subprocess.run(
        ["/bin/sh", "-c", "\n".join(commands)], input=b"", capture_output=True, timeout=_scaled(5)
    )
    assert completed.returncode == 7
    assert completed.stdout.decode().splitlines() == [str(tmp_path), "preserved"]

    commands.clear()
    sandbox.execute_command("false | true")
    sandbox.execute_command('printf "%s" "${PIPESTATUS[*]}"')
    completed = subprocess.run(
        ["/bin/bash", "-c", "\n".join(commands)], input=b"", capture_output=True, timeout=_scaled(5)
    )
    assert completed.returncode == 0
    assert completed.stdout == b"1 0"

    commands.clear()
    sandbox.execute_command("trap 'printf error-trap' ERR")
    sandbox.execute_command("false")
    completed = subprocess.run(
        ["/bin/bash", "-c", "\n".join(commands)], input=b"", capture_output=True, timeout=_scaled(5)
    )
    assert completed.returncode == 1
    assert completed.stdout == b"error-trap"

    commands.clear()
    sandbox.execute_command("true")
    completed = subprocess.run(
        ["/bin/sh", "-c", commands[0] + '\nread session_input; printf "%s" "$session_input"'],
        input=b"session still open\n",
        capture_output=True,
        timeout=_scaled(5),
    )
    assert completed.returncode == 0
    assert completed.stdout == b"session still open"


# --- broker and lark-cli modeling ---


def _fake_lark_cli(tmp_path: Path, calls_file: Path) -> str:
    """A stand-in broker CLI that writes down each call and echoes it."""
    script = tmp_path / "fake-lark-cli"
    script.write_text(
        textwrap.dedent(
            f"""\
            #!/usr/bin/env python3
            import json, sys
            record = json.dumps({{"argv": sys.argv[1:], "stdin": sys.stdin.read()}})
            with open({str(calls_file)!r}, "a", encoding="utf-8") as calls:
                calls.write(record + "\\n")
            print(record)
            """
        ),
        encoding="utf-8",
    )
    script.chmod(0o755)
    return str(script)


@pytest.fixture()
def broker(tmp_path: Path):
    """A loopback broker on an ephemeral port, and a way to read the calls it ran."""
    from deerflow.integrations.lark_broker import BrokerConfig, serve

    calls_file = tmp_path / "broker-calls.jsonl"
    config = BrokerConfig(
        lark_cli_path=_fake_lark_cli(tmp_path, calls_file),
        config_dir="/broker/only/config",
        data_dir="/broker/only/data",
        port=0,
    )
    server = serve(config)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()

    def calls() -> list[dict]:
        if not calls_file.exists():
            return []
        return [json.loads(line) for line in calls_file.read_text(encoding="utf-8").splitlines()]

    host, port = server.server_address[0], server.server_address[1]
    try:
        yield SimpleNamespace(url=f"http://{host}:{port}", calls=calls)
    finally:
        server.shutdown()
        thread.join(timeout=5)


@pytest.fixture()
def lark_cli(tmp_path: Path) -> Path:
    """The launcher and shim, laid out the way the broker image's init step does."""
    from deerflow.integrations.lark_broker import install_shim

    return Path(install_shim(str(tmp_path / "lark-runtime")))


def _cli_env(broker) -> dict:
    from deerflow.integrations.lark_broker import LARK_BROKER_PYTHON_ENV, LARK_BROKER_URL_ENV

    return {**os.environ, LARK_BROKER_URL_ENV: broker.url, LARK_BROKER_PYTHON_ENV: sys.executable}


@pytest.fixture()
def broker_mode(bash_tool_run, lark_cli, broker, monkeypatch):
    """The bash tool in broker mode, with its overlay pointed at this test's broker."""
    from deerflow.integrations import lark_cli as lark_cli_module
    from deerflow.integrations.lark_broker import LARK_BROKER_PYTHON_ENV

    monkeypatch.setattr(lark_cli_module, "LARK_CLI_SANDBOX_RUNTIME_DIR", str(lark_cli.parent.parent))
    monkeypatch.setattr(lark_cli_module, "LARK_BROKER_SANDBOX_URL", broker.url)
    monkeypatch.setenv(LARK_BROKER_PYTHON_ENV, sys.executable)
    return SimpleNamespace(run=bash_tool_run, calls=broker.calls)


def _reply_and_calls(result: str, broker) -> dict:
    assert "Exit Code" not in result, result
    try:
        reply = json.loads(result.splitlines()[0])
    except (IndexError, ValueError):
        pytest.fail(f"lark-cli didn't come back with the broker's reply: {result!r}")
    assert broker.calls() == [reply]
    return reply


def test_bare_lark_cli_returns_the_brokers_reply(sandbox, broker_mode):
    """A plain ``lark-cli`` through the bash tool runs with no input and comes back."""
    _model_transports(sandbox)

    reply = _reply_and_calls(broker_mode.run("lark-cli auth status"), broker_mode)
    assert reply == {"argv": ["auth", "status"], "stdin": ""}


@pytest.mark.parametrize(
    ("form", "expected"),
    [
        pytest.param("printf 'explicit input' | lark-cli docs +fetch", "explicit input", id="pipe"),
        pytest.param("lark-cli docs +fetch <<'INPUT'\nexplicit input\nINPUT", "explicit input\n", id="heredoc"),
        pytest.param("lark-cli docs +fetch < {file}", "explicit input", id="file"),
    ],
)
def test_lark_cli_with_explicit_input_forwards_it(sandbox, broker_mode, tmp_path, form, expected):
    """Pipe, heredoc and file input through the bash tool reach the broker."""
    input_file = tmp_path / "input with spaces.txt"
    input_file.write_text("explicit input", encoding="utf-8")
    _model_transports(sandbox)

    reply = _reply_and_calls(broker_mode.run(form.format(file=shlex.quote(str(input_file)))), broker_mode)
    assert reply == {"argv": ["docs", "+fetch"], "stdin": expected}


def test_lark_cli_at_a_terminal_needs_no_input(broker, lark_cli):
    """``lark-cli`` started directly on a pseudo-terminal runs with no input."""
    import pty

    master, slave = pty.openpty()
    try:
        completed = subprocess.run(
            [str(lark_cli), "auth", "status"],
            stdin=slave,
            capture_output=True,
            env=_cli_env(broker),
            timeout=RETURN_LIMIT_SECONDS,
        )
    finally:
        os.close(slave)
        os.close(master)
    assert completed.returncode == 0, completed.stderr
    assert json.loads(completed.stdout)["stdin"] == ""


def _start_with_open_pipe(lark_cli, env, *args):
    return subprocess.Popen(
        [str(lark_cli), *(args or ("auth", "status"))],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )


def _send_and_close(proc, data):
    try:
        proc.stdin.write(data)
        proc.stdin.close()
    except BrokenPipeError:
        pass


def _finish(proc, limit):
    """Wait for ``proc`` and return (returncode, stdout, stderr), or fail on a hang."""
    try:
        proc.wait(timeout=limit)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait()
        pytest.fail(f"lark-cli was still running after {limit:.0f}s")
    finally:
        try:
            proc.stdin.close()
        except (BrokenPipeError, ValueError):
            pass
    return proc.returncode, proc.stdout.read(), proc.stderr.read()


def _assert_refused(returncode, stdout, stderr, broker):
    assert returncode != 0, stderr
    assert stdout == b""
    assert re.search(rb"stdin|input", stderr, re.IGNORECASE), stderr
    assert broker.calls() == []


def test_open_pipe_with_nothing_on_it_is_refused(broker, lark_cli):
    """A pipe that stays open and never carries a byte gets a non-zero exit and an
    error about the input, and the broker runs nothing."""
    proc = _start_with_open_pipe(lark_cli, _cli_env(broker))
    _assert_refused(*_finish(proc, GIVE_UP_LIMIT_SECONDS), broker)


def test_producer_that_stalls_partway_is_refused(broker, lark_cli):
    """A pipe that carries one chunk and then goes quiet without closing gets a
    non-zero exit and an error about the input, and the broker runs nothing."""
    proc = _start_with_open_pipe(lark_cli, _cli_env(broker))
    proc.stdin.write(b"first-chunk")
    proc.stdin.flush()
    _assert_refused(*_finish(proc, GIVE_UP_LIMIT_SECONDS), broker)


def test_producer_that_starts_late_never_runs_without_its_input(broker, lark_cli):
    """A producer whose first byte comes after a long silence is either waited for
    or refused, and the broker never runs the command without that input."""
    proc = _start_with_open_pipe(lark_cli, _cli_env(broker))
    try:
        proc.wait(timeout=LATE_PRODUCER_SECONDS)
    except subprocess.TimeoutExpired:
        _send_and_close(proc, b"late-input")
    returncode, stdout, stderr = _finish(proc, GIVE_UP_LIMIT_SECONDS)
    if returncode == 0:
        assert json.loads(stdout)["stdin"] == "late-input"
        assert broker.calls() == [{"argv": ["auth", "status"], "stdin": "late-input"}]
    else:
        _assert_refused(returncode, stdout, stderr, broker)


def test_producer_with_a_short_start_up_is_forwarded(broker, lark_cli):
    """A producer that sends its input a second after the command starts gets all of
    it through."""
    proc = _start_with_open_pipe(lark_cli, _cli_env(broker))
    time.sleep(SHORT_START_SECONDS)
    _send_and_close(proc, b"short-start-input")
    returncode, stdout, stderr = _finish(proc, RETURN_LIMIT_SECONDS)
    assert returncode == 0, stderr
    assert json.loads(stdout)["stdin"] == "short-start-input"


def test_closed_stdin_counts_as_no_input(broker, lark_cli):
    """A call started with fd 0 closed runs with no input and comes back."""
    completed = subprocess.run(
        ["/bin/sh", "-c", f"exec 0<&-; exec {shlex.quote(str(lark_cli))} auth status"],
        capture_output=True,
        env=_cli_env(broker),
        timeout=RETURN_LIMIT_SECONDS,
    )
    assert completed.returncode == 0, completed.stderr
    assert json.loads(completed.stdout)["stdin"] == ""


def test_input_that_cannot_be_read_is_refused(broker, lark_cli):
    """A standard input that's open but fails on read gets a non-zero exit and an error
    about the input, and the broker runs nothing."""
    with open(os.devnull, "wb") as write_only:
        completed = subprocess.run(
            [str(lark_cli), "auth", "status"],
            stdin=write_only,
            capture_output=True,
            env=_cli_env(broker),
            timeout=RETURN_LIMIT_SECONDS,
        )
    _assert_refused(completed.returncode, completed.stdout, completed.stderr, broker)


def _connected_pair():
    import socket

    listener = socket.create_server(("127.0.0.1", 0))
    client = socket.create_connection(listener.getsockname())
    peer, _ = listener.accept()
    listener.close()
    return client, peer


def _reset(peer):
    import socket
    import struct

    peer.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER, struct.pack("ii", 1, 0))
    peer.close()


def _reset_shows_up_as_a_read_error():
    """Linux reports a peer's reset after a chunk as ECONNRESET on the next read."""
    client, peer = _connected_pair()
    try:
        peer.sendall(b"x")
        client.settimeout(_scaled(5))
        client.recv(1)
        _reset(peer)
        try:
            client.recv(1)
        except ConnectionResetError:
            return True
        return False
    finally:
        client.close()


def test_input_that_fails_partway_is_refused(broker, lark_cli):
    """A socket stdin whose other end sends one chunk and then resets the connection gets
    a non-zero exit and an error about the input, and the broker runs nothing."""
    import fcntl
    import struct
    import termios

    if not _reset_shows_up_as_a_read_error():
        pytest.skip("this host reports a peer's reset as end of input, so no read can fail here")
    client, peer = _connected_pair()
    try:
        proc = subprocess.Popen(
            [str(lark_cli), "auth", "status"],
            stdin=client.fileno(),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=_cli_env(broker),
        )
        peer.sendall(b"first-chunk")
        # Reset once lark-cli has taken the chunk off the socket, so a later read fails.
        deadline = time.monotonic() + RETURN_LIMIT_SECONDS
        time.sleep(0.05)
        while time.monotonic() < deadline and proc.poll() is None:
            unread = struct.unpack("i", fcntl.ioctl(client.fileno(), termios.FIONREAD, b"\0" * 4))[0]
            if unread == 0:
                break
            time.sleep(0.01)
    finally:
        _reset(peer)
    try:
        proc.wait(timeout=RETURN_LIMIT_SECONDS)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait()
        pytest.fail(f"lark-cli was still running after {RETURN_LIMIT_SECONDS:.0f}s")
    finally:
        client.close()
    _assert_refused(proc.returncode, proc.stdout.read(), proc.stderr.read(), broker)


@pytest.mark.parametrize(
    "contents",
    [
        pytest.param("streamed-input", id="short"),
        pytest.param(LARGE_INPUT, id="large"),
    ],
)
def test_piped_input_is_forwarded(broker, lark_cli, contents):
    """Input on a pipe that ends reaches the broker intact."""
    completed = subprocess.run(
        [str(lark_cli), "docs", "+fetch"],
        input=contents.encode(),
        capture_output=True,
        env=_cli_env(broker),
        timeout=RETURN_LIMIT_SECONDS,
    )
    assert completed.returncode == 0, completed.stderr
    assert json.loads(completed.stdout.decode())["stdin"] == contents


def test_slow_input_that_keeps_coming_is_forwarded(broker, lark_cli):
    """A producer that pauses a second between writes and keeps going for over five
    minutes gets all of it through."""
    pieces = [f"piece-{index};".encode() for index in range(int(KEEPS_COMING_SECONDS / SLOW_GAP_SECONDS))]
    proc = _start_with_open_pipe(lark_cli, _cli_env(broker), "docs", "+fetch")
    try:
        for piece in pieces:
            proc.stdin.write(piece)
            proc.stdin.flush()
            time.sleep(SLOW_GAP_SECONDS)
        proc.stdin.close()
    except BrokenPipeError:
        pass
    returncode, stdout, stderr = _finish(proc, RETURN_LIMIT_SECONDS)
    assert returncode == 0, stderr
    assert json.loads(stdout.decode())["stdin"] == b"".join(pieces).decode()


def test_large_file_input_is_preserved(broker, lark_cli, tmp_path):
    """A large file redirect reaches the broker in full."""
    input_file = tmp_path / "input.txt"
    input_file.write_text(LARGE_INPUT, encoding="utf-8")
    with input_file.open("rb") as stdin:
        completed = subprocess.run(
            [str(lark_cli), "docs", "+fetch"],
            stdin=stdin,
            capture_output=True,
            env=_cli_env(broker),
            timeout=RETURN_LIMIT_SECONDS,
        )
    assert completed.returncode == 0, completed.stderr
    assert json.loads(completed.stdout)["stdin"] == LARGE_INPUT
