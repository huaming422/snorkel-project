## Task

Right now when we evaluate a program we can only tell the evaluator which Plutus language version to use. That is not enough: the ledger's builtin semantics and cost model also shift from one Cardano protocol era to the next, and we have no way to say which era a run is happening under. Same language version, different era, and the execution budget we report back can be off.

We want to be able to evaluate a program under an explicitly chosen Cardano protocol major version, so a run follows the behavior and costs of the selected ledger era. This is an addition alongside what we already have: the existing language-only evaluation entry points stay exactly as they are, same signatures and same results, for callers that do not care about the protocol.

Keep all of this inside the `uplc` crate, leave the existing public API untouched, and make sure the crate still builds.

## User stories / requirements

- Evaluating a program under an explicitly chosen protocol major version selects the builtin semantics for that ledger era, so the same program and input cost model produce an era-correct execution budget. A protocol from before the semantics-changing eras yields the same result as evaluating by language version alone.
- Given a full, longer cost-model vector for the newest Plutus language under the newest protocol era, evaluation uses those extended cost entries so the newer builtins are costed. A shorter vector leaves those newer builtins uncosted and falls back to the pre-existing unavailable-cost behavior.
- Under the newest protocol era, string values are costed by their UTF-8 byte size rather than their character count, so multi-byte text costs differently from the same number of ASCII characters.
- Under the newer semantics, constructing a byte string from an integer first argument rejects an out-of-range value as an error, where the older semantics instead reduce that value modulo 256.
