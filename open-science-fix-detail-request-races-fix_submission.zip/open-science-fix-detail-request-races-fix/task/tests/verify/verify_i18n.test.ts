// Source->catalog completeness guard for the literature modules, scoped and
// copy-agnostic. It mirrors the repo's own missing-translation guard
// (src/renderer/src/i18n/resources.test.ts) but only over the literature
// directory, so it stays well inside the verifier wall-clock budget and does
// not re-run the 190+ unrelated catalog assertions.
//
// Why copy-agnostic: English IS the key (the catalog has no `en` entry; a key
// is its English source text). Any new recovery string an acceptable solution
// introduces becomes a new t() literal here. This guard discovers whatever
// literals the literature source actually contains and asserts each one
// resolves in all eight locale catalogs — it never hardcodes a specific
// sentence, so it accepts any wording the solver chooses while still failing a
// solution that adds a user-visible string to only some locales (or none).
//
// Extraction is deliberately regex-only. The literature modules use plain
// t('literal'), ternary t(cond ? 'a' : 'b'), and count-plural calls exclusively
// (no <Trans>, no `ns:` overrides, no lookup-table keys, no aliased
// useTranslation bindings), so the TypeScript-compiler-based helpers the full
// guard needs for the rest of the app are unnecessary here. The file runs
// copied into src/renderer/src/pages/literature, so __dirname is that directory.
import { readdirSync, readFileSync } from 'node:fs'
import { join } from 'node:path'

import { describe, expect, it } from 'vitest'

const LITERATURE_DIR = __dirname
const LOCALES_DIR = join(__dirname, '..', '..', '..', '..', 'shared', 'i18n', 'locales')
const LOCALES = ['de', 'es', 'fr', 'ja', 'ko', 'ru', 'zh-Hans', 'zh-Hant'] as const
type Locale = (typeof LOCALES)[number]

// Plural categories each locale's CLDR rules require (matches the repo guard).
const REQUIRED_PLURAL_CATEGORIES: Record<Locale, readonly string[]> = {
  de: ['one', 'other'],
  es: ['one', 'many', 'other'],
  fr: ['one', 'many', 'other'],
  ja: ['other'],
  ko: ['other'],
  ru: ['one', 'few', 'many', 'other'],
  'zh-Hans': ['other'],
  'zh-Hant': ['other']
}

type Catalog = Record<string, string>
type CallSite = { key: string; plural: boolean; context: string | null; file: string }

const loadCatalog = (locale: Locale): Catalog => {
  const raw = JSON.parse(readFileSync(join(LOCALES_DIR, `${locale}.json`), 'utf8')) as {
    common?: Catalog
    renderer?: Catalog
  }
  return { ...(raw.common ?? {}), ...(raw.renderer ?? {}) }
}

// A line that is entirely a comment holds no code; dropping those keeps a
// semantic path quoted in a comment from being read as a call site.
const codeOnly = (source: string): string =>
  source
    .split('\n')
    .filter((line) => !/^\s*(?:\/\/|\/?\*)/.test(line))
    .join('\n')

// Consume one quoted string starting at the opening quote, honouring escapes.
const readStringLiteral = (
  source: string,
  start: number
): { value: string; end: number } | null => {
  const quote = source[start]
  if (quote !== '"' && quote !== "'") return null
  let value = ''
  for (let i = start + 1; i < source.length; i += 1) {
    const char = source[i]
    if (char === '\\') {
      const next = source[i + 1]
      value += next === 'n' ? '\n' : next === 't' ? '\t' : next
      i += 1
      continue
    }
    if (char === quote) return { value, end: i }
    if (char === '\n') return null
    value += char
  }
  return null
}

const skipSpace = (source: string, start: number): number => {
  let i = start
  while (i < source.length && /\s/.test(source[i])) i += 1
  return i
}

// Walk to the end of a call's first argument: the top-level comma, or the
// closing paren when there is only one argument.
const firstArgumentEnd = (source: string, start: number): number => {
  let depth = 0
  for (let i = start; i < source.length; i += 1) {
    const char = source[i]
    if (char === '"' || char === "'" || char === '`') {
      const literal = readStringLiteral(source, i)
      i = literal ? literal.end : i
      continue
    }
    if (char === '(' || char === '[' || char === '{') depth += 1
    else if (char === ')' || char === ']' || char === '}') {
      if (depth === 0) return i
      depth -= 1
    } else if (char === ',' && depth === 0) return i
  }
  return source.length
}

// Both branches of a ternary first argument render, so both are keys.
const ternaryBranchKeys = (argument: string): string[] => {
  let depth = 0
  let branching = false
  const keys: string[] = []
  for (let i = 0; i < argument.length; i += 1) {
    const char = argument[i]
    if (char === '"' || char === "'") {
      const literal = readStringLiteral(argument, i)
      if (!literal) continue
      keys.push(literal.value)
      i = literal.end
      continue
    }
    if (char === '(' || char === '[' || char === '{') depth += 1
    else if (char === ')' || char === ']' || char === '}') depth -= 1
    else if (char === '?' && depth === 0 && argument[i + 1] !== '.') branching = true
  }
  return branching ? keys : []
}

// Every literal (or ternary-literal) t(...) call. Identifiers that merely end in
// `t` are skipped by the preceding-character guard.
const tCallSites = (source: string): Omit<CallSite, 'file'>[] => {
  const callee = 't'
  const sites: Omit<CallSite, 'file'>[] = []
  for (let i = 0; i < source.length - callee.length; i += 1) {
    if (source.slice(i, i + callee.length + 1) !== `${callee}(`) continue
    if (/[A-Za-z0-9_$.]/.test(source[i - 1] ?? '')) continue
    const argumentStart = skipSpace(source, i + callee.length + 1)
    const literal = readStringLiteral(source, argumentStart)
    const argumentEnd = literal ? literal.end : firstArgumentEnd(source, argumentStart) - 1
    const keys = literal
      ? [literal.value]
      : ternaryBranchKeys(source.slice(argumentStart, argumentEnd + 1))
    if (keys.length === 0) continue
    const tail = source.slice(argumentEnd + 1, argumentEnd + 401)
    const close = tail.indexOf(')')
    const options = close === -1 ? tail : tail.slice(0, close + 1)
    const plural = /\bcount\b/.test(options)
    const context = /\bcontext\s*:\s*['"]([^'"]+)['"]/.exec(options)?.[1] ?? null
    for (const key of keys) sites.push({ key, plural, context })
  }
  return sites
}

const resolvesIn = (
  entries: Catalog,
  { key, plural, context }: CallSite,
  pluralCategories: readonly string[]
): boolean => {
  if (context) {
    if (plural) {
      return pluralCategories.every(
        (category) => entries[`${key}_${context}_${category}`] !== undefined
      )
    }
    return entries[`${key}_${context}`] !== undefined
  }
  if (plural) return pluralCategories.every((c) => entries[`${key}_${c}`] !== undefined)
  return entries[key] !== undefined
}

const literatureSourceFiles = (): string[] =>
  readdirSync(LITERATURE_DIR, { withFileTypes: true })
    .filter((entry) => entry.isFile())
    .map((entry) => entry.name)
    .filter((name) => /\.tsx?$/.test(name))
    // Tests assert on resolved copy, so a literal surviving only in a test file
    // is still not a shipped call site; exclude every test (including this one).
    .filter((name) => !/\.(test|render\.test)\.tsx?$/.test(name))

describe('literature i18n source->catalog completeness', () => {
  const sites: CallSite[] = literatureSourceFiles().flatMap((file) => {
    const source = codeOnly(readFileSync(join(LITERATURE_DIR, file), 'utf8'))
    return tCallSites(source)
      .filter((site) => /[A-Za-z]/.test(site.key))
      .map((site) => ({ ...site, file }))
  })

  // Guard against a silently-empty scan: a broken extractor would otherwise
  // report a clean bill of health for every locale. The literature modules
  // carry hundreds of call sites.
  it('finds literature translation call sites', () => {
    expect(sites.length).toBeGreaterThan(200)
  })

  it.each(LOCALES)('every literature t() literal resolves in the %s catalog', (locale) => {
    const entries = loadCatalog(locale)
    const untranslated = sites
      .filter((site) => !resolvesIn(entries, site, REQUIRED_PLURAL_CATEGORIES[locale]))
      .map((site) => `${site.file}: ${JSON.stringify(site.key)}`)
    expect(untranslated).toEqual([])
  })
})
