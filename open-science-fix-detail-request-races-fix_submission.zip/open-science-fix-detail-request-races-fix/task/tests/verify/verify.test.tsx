// @vitest-environment jsdom
// Renderer integration verifier for detail-request / snapshot consistency.
// Runs copied into src/renderer/src/pages/literature (test_parent), so the
// relative shared/ imports and the `@/` alias resolve exactly as they do for
// the module under test. Every assertion goes THROUGH the rendered page and the
// window.api mock boundary: the test observes rendered output and which api
// calls were made, never the page's private bookkeeping. Recovery affordances
// are located by role + a lenient name regex because their exact wording is a
// solution choice; the behavioral contract is the api-call SHAPE (a read `get`
// versus a second `transact`) and the fixture data that flows back to the pane.
import { act, cleanup, fireEvent, render, screen, waitFor, within } from '@testing-library/react'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

import type {
  LiteratureCatalogSearchPage,
  LiteratureCatalogSearchRequest,
  LiteratureInboxCandidateView,
  LiteratureItemInput,
  LiteratureItemView
} from '../../../../shared/literature'
import type { Project } from '../../../../shared/projects'
import { useNavigationStore } from '@/stores/navigation-store'
import type { PreviewFileItem } from '@/stores/preview-workbench-store'
import { createInitialProjectState, useProjectStore } from '@/stores/project-store'
import { createInitialTagState, useTagStore } from '@/stores/tag-store'
import { LiteratureLibraryPage } from './LiteratureLibraryPage'

if (!Element.prototype.scrollIntoView) {
  Element.prototype.scrollIntoView = (): void => undefined
}
if (!Element.prototype.hasPointerCapture) {
  Element.prototype.hasPointerCapture = (): boolean => false
  Element.prototype.setPointerCapture = (): void => undefined
  Element.prototype.releasePointerCapture = (): void => undefined
}

const { extractLiteraturePdfDraft, completeLiteraturePdfDraft, filePreviewRenderCount } =
  vi.hoisted(() => ({
    extractLiteraturePdfDraft: vi.fn(),
    completeLiteraturePdfDraft: vi.fn(),
    filePreviewRenderCount: { value: 0 }
  }))

vi.mock('./literature-pdf-metadata', () => ({
  extractLiteraturePdfDraft,
  completeLiteraturePdfDraft
}))

vi.mock('../workspace/FilePreviewDialog', () => ({
  FilePreviewDialog: ({
    item,
    allowReadingContext,
    onReadWithAgent,
    onClose
  }: {
    item?: PreviewFileItem
    allowReadingContext?: boolean
    onReadWithAgent?: (item: PreviewFileItem) => void
    onClose: () => void
  }) => {
    filePreviewRenderCount.value += 1
    return item ? (
      <div
        data-testid="literature-pdf-preview"
        data-allow-reading-context={String(allowReadingContext)}
      >
        {`${item.title} · ${item.path}`}
        <button type="button" onClick={() => onClose()}>
          Close PDF
        </button>
        {onReadWithAgent ? (
          <button type="button" onClick={() => onReadWithAgent(item)}>
            Read with agent
          </button>
        ) : null}
      </div>
    ) : null
  }
}))

const inboxPage: LiteratureCatalogSearchPage = {
  entries: [
    {
      id: 'candidate-1',
      state: 'pending',
      candidate: {
        item: {
          itemType: 'journalArticle',
          title: 'Corrective Retrieval Augmented Generation',
          abstract: 'A corrective retrieval method.',
          issuedText: '2024',
          issuedYear: 2024,
          containerTitle: 'arXiv',
          shortTitle: '',
          language: 'en',
          rights: '',
          url: '',
          extra: '',
          typeFields: {},
          creators: [
            {
              nameMode: 'person',
              givenName: 'Shi-Qi',
              familyName: 'Yan',
              creatorType: 'author'
            }
          ],
          identifiers: [{ scheme: 'doi', value: '10.0000/example', isPrimary: true }]
        },
        source: {
          provider: 'Agent search',
          sourceUrl: 'https://example.test/paper',
          rawMetadata: {}
        },
        origin: { kind: 'agent', projectId: 'project-1', sessionId: 'session-1' }
      },
      createdAt: 1,
      updatedAt: 1
    }
  ]
}

const libraryItem: LiteratureItemView = {
  id: 'item-1',
  item: (inboxPage.entries[0] as LiteratureInboxCandidateView).candidate.item,
  attachments: [],
  projectIds: [],
  collectionIds: [],
  metadataRevision: 1,
  createdAt: 1,
  updatedAt: 1
}

const createLibraryItemWithPdf = (): LiteratureItemView => ({
  ...libraryItem,
  attachments: [
    {
      id: 'attachment-1',
      kind: 'fullText',
      title: '',
      sortOrder: 0,
      versions: [
        {
          id: 'version-1',
          versionNumber: 1,
          filename: 'paper.pdf',
          contentType: 'application/pdf',
          sizeBytes: 8,
          checksum: 'a'.repeat(64),
          createdAt: 2
        }
      ],
      createdAt: 2,
      updatedAt: 2
    }
  ]
})

const openMenu = async (trigger: Element): Promise<void> => {
  act(() => {
    trigger.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }))
  })
  await act(async () => {
    await Promise.resolve()
  })
}

const openReferenceDetail = async (trigger: Element): Promise<HTMLElement> => {
  fireEvent.click(trigger)
  const dialog = screen.getByRole('dialog')
  await waitFor(() => expect(within(dialog).queryByRole('status')).toBeNull())
  return dialog
}

describe('LiteratureLibraryPage detail request consistency', () => {
  const search = vi.fn()
  const get = vi.fn()
  const formatReferences = vi.fn()
  const citationStyles = vi.fn()
  const completeMetadata = vi.fn()
  const fullText = vi.fn()
  const importRecords = vi.fn()
  const transact = vi.fn().mockResolvedValue({ kind: 'item', id: 'item-1', state: 'present' })
  const importPdf = vi.fn()
  const stageLocalFile = vi.fn()
  const claimLocalFile = vi.fn().mockResolvedValue(undefined)
  const deleteUpload = vi.fn().mockResolvedValue(undefined)
  const filterPdfContextCandidates = vi.fn()
  const createProjectApi = vi.fn()
  const startPdfReadingConversation = vi.fn()
  const startPdfReadingConversations = vi.fn(() => true)
  const startLiteratureReviewConversation = vi.fn(() => true)
  const saveBlobFile = vi.fn()

  beforeEach(() => {
    search.mockReset()
    get.mockReset()
    transact.mockReset().mockResolvedValue({ kind: 'item', id: 'item-1', state: 'present' })
    window.localStorage.clear()
    window.sessionStorage.clear()
    useNavigationStore.setState({
      view: 'library',
      activeProjectId: undefined,
      pendingLiteratureItemId: undefined,
      pendingLiteratureProjectId: undefined,
      pendingLiteratureCollectionId: undefined,
      startPdfReadingConversation,
      startPdfReadingConversations,
      startLiteratureReviewConversation
    })
    useProjectStore.setState({
      ...createInitialProjectState(),
      projects: [
        {
          id: 'project-1',
          name: 'Retrieval research',
          description: '',
          isExample: false,
          createdAt: 1,
          updatedAt: 1
        }
      ],
      isLoaded: true
    })
    useTagStore.setState({
      ...createInitialTagState(),
      status: 'ready',
      revision: 1,
      tags: [
        {
          id: 'tag-favorite',
          systemKey: 'favorite',
          createdAt: 1,
          updatedAt: 1
        }
      ],
      assignments: [
        {
          tagId: 'tag-favorite',
          resourceType: 'literature.item',
          resourceId: libraryItem.id,
          createdAt: 1
        }
      ]
    })
    search.mockImplementation((request: { scope: string }) =>
      Promise.resolve(request.scope === 'inbox' ? inboxPage : { entries: [] })
    )
    filterPdfContextCandidates.mockImplementation(
      (request: { sources: readonly { sourceKind: string; sourceVersionId: string }[] }) =>
        Promise.resolve({ sources: request.sources, pendingAttachmentIds: [] })
    )
    createProjectApi.mockResolvedValue({
      id: 'reading-project',
      name: 'Reading project',
      description: '',
      agentContext: '',
      isExample: false,
      createdAt: 2,
      updatedAt: 2
    } satisfies Project)
    startPdfReadingConversation.mockReturnValue(true)
    saveBlobFile.mockResolvedValue({ saved: true, filePath: '/tmp/references.bib' })
    get.mockResolvedValue(undefined)
    formatReferences.mockResolvedValue({
      references: [
        {
          itemId: libraryItem.id,
          inText: '(Yan, 2024)',
          reference: 'Yan, S.-Q. (2024). Corrective Retrieval Augmented Generation.'
        }
      ],
      exports: {
        bibtex: '@article{item-1, title = {Corrective Retrieval Augmented Generation}}',
        ris: 'TY  - JOUR\nTI  - Corrective Retrieval Augmented Generation\nER  -'
      }
    })
    citationStyles.mockResolvedValue({
      styles: [
        { id: 'apa', title: 'APA Style 7th edition', source: 'built-in' },
        { id: 'mla', title: 'Modern Language Association 9th edition', source: 'built-in' },
        { id: 'vancouver', title: 'Vancouver', source: 'built-in' }
      ]
    })
    importRecords.mockImplementation((request: { mode: 'commit' | 'preview' }) =>
      Promise.resolve({
        format: 'bibtex',
        items: [libraryItem.item],
        entries: [
          {
            index: 0,
            title: libraryItem.item.title,
            status: 'ready',
            warnings: [],
            item: libraryItem.item
          }
        ],
        errors: [],
        truncated: false,
        scannedEntries: 1,
        ...(request.mode === 'commit'
          ? { imported: { itemIds: [libraryItem.id], createdCount: 1, reusedCount: 0 } }
          : {})
      })
    )
    completeLiteraturePdfDraft.mockImplementation(async (draft: LiteratureItemInput) => draft)
    extractLiteraturePdfDraft.mockImplementation((_file: File, fallback: LiteratureItemInput) =>
      Promise.resolve(fallback)
    )
    completeMetadata.mockImplementation((request: { mode: 'commit' | 'preview' }) => {
      const completedItem = {
        ...libraryItem,
        metadataRevision: request.mode === 'commit' ? 2 : 1,
        item: {
          ...libraryItem.item,
          containerTitle: 'Journal of Retrieval',
          typeFields: { volume: '12', issue: '3', pages: '44-58' }
        }
      }
      return Promise.resolve({
        mode: request.mode,
        provider: 'crossref',
        sourceUrl: 'https://api.crossref.org/works/10.0000%2Fexample',
        item: completedItem,
        filled: [
          { field: 'journal', value: 'Journal of Retrieval' },
          { field: 'volume', value: '12' },
          { field: 'issue', value: '3' },
          { field: 'pages', value: '44-58' }
        ],
        conflicts:
          request.mode === 'preview'
            ? [
                {
                  field: 'title',
                  currentValue: 'Corrective Retrieval Augmented Generation',
                  value: 'Corrective RAG'
                }
              ]
            : []
      })
    })
    Object.defineProperty(navigator, 'clipboard', {
      configurable: true,
      value: { writeText: vi.fn().mockResolvedValue(undefined) }
    })
    Object.defineProperty(window, 'api', {
      configurable: true,
      value: {
        platform: 'darwin',
        saveBlobFile,
        literature: {
          lookupMetadata: vi.fn(async () => libraryItem.item),
          jobs: vi.fn(async () => ({ jobs: [], summaries: [] })),
          search: async (request: LiteratureCatalogSearchRequest) => {
            const page = await search(request)
            if (!request.allItemIds || page.itemIds) return page
            const entries = [...page.entries]
            let nextOffset = page.nextOffset
            while (nextOffset !== undefined) {
              const next = await search({ ...request, offset: nextOffset })
              entries.push(...next.entries)
              nextOffset = next.nextOffset
            }
            return {
              entries: [],
              itemIds: entries.map((entry) => entry.id),
              totalCount: entries.length
            }
          },
          transact,
          get,
          completeMetadata,
          fullText: (request: { mode: string }) =>
            request.mode === 'transfer' ? Promise.resolve({ mode: 'transfer' }) : fullText(request),
          citationStyles,
          formatDocument: vi.fn(),
          formatReferences,
          importPdf,
          importRecords
        },
        uploads: {
          stageLocalFile,
          claimLocalFile,
          deleteUpload,
          finalizeSession: vi.fn(),
          beginTransfer: vi.fn(),
          appendTransfer: vi.fn(),
          getTransferStatus: vi.fn(),
          finishTransfer: vi.fn(),
          abortTransfer: vi.fn()
        } as unknown as Window['api']['uploads'],
        sessions: {
          filterPdfContextCandidates
        } as unknown as Window['api']['sessions'],
        projects: {
          create: createProjectApi
        } as unknown as Window['api']['projects'],
        tags: {
          snapshot: vi.fn().mockResolvedValue({
            revision: 1,
            tags: [
              {
                id: 'tag-favorite',
                systemKey: 'favorite',
                createdAt: 1,
                updatedAt: 1
              }
            ],
            assignments: [
              {
                tagId: 'tag-favorite',
                resourceType: 'literature.item',
                resourceId: libraryItem.id,
                createdAt: 1
              }
            ]
          }),
          create: vi.fn(),
          update: vi.fn(),
          delete: vi.fn(),
          reorder: vi.fn(),
          setAssignment: vi.fn(),
          onChanged: vi.fn(() => () => undefined)
        } as unknown as Window['api']['tags']
      } satisfies Partial<Window['api']>
    })
  })

  afterEach(() => {
    cleanup()
    vi.clearAllMocks()
    transact.mockReset().mockResolvedValue({ kind: 'item', id: 'item-1', state: 'present' })
    vi.unstubAllGlobals()
  })

  // --- test-local helpers (mirror the production harness) ---------------------
  const deferred = <T,>(): { promise: Promise<T>; resolve: (value: T) => void } => {
    let resolve!: (value: T) => void
    const promise = new Promise<T>((done) => {
      resolve = done
    })
    return { promise, resolve }
  }
  const version = (revision: number, title: string): LiteratureItemView => ({
    ...libraryItem,
    metadataRevision: revision,
    item: { ...libraryItem.item, title }
  })
  const showLibrary = async (): Promise<void> => {
    search.mockImplementation(async (request: LiteratureCatalogSearchRequest) => ({
      entries: request.scope === 'library' ? [libraryItem] : []
    }))
    render(<LiteratureLibraryPage />)
    fireEvent.click(screen.getByRole('button', { name: 'All references' }))
    await screen.findByText(libraryItem.item.title)
  }
  const editDetail = async (): Promise<void> => {
    await openMenu(screen.getByRole('button', { name: 'More actions' }))
    fireEvent.click(screen.getByRole('menuitem', { name: 'Edit metadata' }))
  }
  const closeDetail = (): void => {
    fireEvent.click(within(screen.getByRole('dialog')).getByRole('button', { name: 'Close' }))
  }
  const detailHeading = (): string =>
    within(screen.getByRole('dialog')).getByRole('heading', { level: 2 }).textContent ?? ''
  // The recovery affordance's label is a solution choice, so it is located by a
  // lenient name regex rather than pinned; when no dedicated control is rendered
  // the legacy UI exposes only Save, and the behavioral contract (a read, not a
  // second write) is asserted on the api-call shape either way, which keeps the
  // assertion on observable behavior rather than on any chosen wording.
  const recoveryOrSave = (): HTMLElement =>
    (screen.queryByRole('button', { name: /retry|reload/i }) ??
      screen.getByRole('button', { name: 'Save' })) as HTMLElement

  // stale_write_rejected: a save readback that resolves after the user reopened a
  // newer version of the reference must not overwrite the newer opening.
  it('stale_write_rejected', async () => {
    await showLibrary()
    await openReferenceDetail(screen.getByText(libraryItem.item.title))
    await editDetail()
    const oldRead = deferred<LiteratureItemView>()
    get.mockReturnValueOnce(oldRead.promise)
    fireEvent.change(screen.getByLabelText('Title'), { target: { value: 'Saved version two' } })
    fireEvent.click(screen.getByRole('button', { name: 'Save' }))
    await waitFor(() => expect(get).toHaveBeenCalledTimes(1))
    closeDetail()
    get.mockResolvedValueOnce(version(3, 'Latest version three'))
    act(() => useNavigationStore.getState().openLiteratureItem(libraryItem.id, 'user'))
    await screen.findByRole('heading', { name: 'Latest version three' })
    await act(async () => oldRead.resolve(version(2, 'Saved version two')))
    expect(detailHeading()).toBe('Latest version three')
    // The next save must target the revision the user is actually looking at.
    await editDetail()
    get.mockResolvedValue(version(4, 'Latest version three'))
    fireEvent.click(screen.getByRole('button', { name: 'Save' }))
    await waitFor(() =>
      expect(transact).toHaveBeenLastCalledWith(
        expect.objectContaining({ expectedMetadataRevision: 3 })
      )
    )
  })

  // save_refreshes_cache: after an inline save the library row shows the new
  // value when the user returns to the cached page — no stale row, no silent
  // restore of the old title.
  it('save_refreshes_cache', async () => {
    await showLibrary()
    await openReferenceDetail(screen.getByText(libraryItem.item.title))
    await editDetail()
    const updated = version(2, 'Saved cache title')
    get.mockResolvedValue(updated)
    fireEvent.change(screen.getByLabelText('Title'), { target: { value: updated.item.title } })
    fireEvent.click(screen.getByRole('button', { name: 'Save' }))
    await screen.findByRole('heading', { name: updated.item.title })
    closeDetail()
    expect(screen.getByText(updated.item.title)).not.toBeNull()
    search.mockImplementation(async (request: LiteratureCatalogSearchRequest) => ({
      entries: request.scope === 'library' ? [updated] : []
    }))
    fireEvent.click(screen.getByRole('button', { name: 'Inbox' }))
    await act(async () => {})
    fireEvent.click(screen.getByRole('button', { name: 'All references' }))
    await act(async () => {})
    expect(
      document.querySelector('[data-slot="literature-table-scroll"]')!.textContent
    ).toContain(updated.item.title)
  })

  // background_publish_current: a completed background metadata job publishes to
  // the open detail and the library list by item identity + revision.
  it('background_publish_current', async () => {
    const summary = {
      id: 'detail-background-job',
      mode: 'metadata' as const,
      phase: 'apply' as const,
      state: 'running' as const,
      total: 1,
      checked: 1,
      ready: 0,
      done: 0,
      failed: 0,
      createdAt: 1,
      updatedAt: 1,
      completedItemIds: [] as string[]
    }
    vi.mocked(window.api.literature.jobs).mockResolvedValue({ jobs: [], summaries: [summary] })
    await showLibrary()
    await screen.findByRole('button', { name: 'Background tasks' })
    await openReferenceDetail(screen.getByText(libraryItem.item.title))
    get.mockResolvedValue(version(2, 'Background updated title'))
    vi.mocked(window.api.literature.jobs).mockResolvedValue({
      jobs: [],
      summaries: [{ ...summary, state: 'completed', done: 1, completedItemIds: [libraryItem.id] }]
    })
    await act(async () => window.dispatchEvent(new Event('literature-jobs-changed')))
    await waitFor(() =>
      expect(
        document.querySelector('[data-slot="literature-table-scroll"]')!.textContent
      ).toContain('Background updated title')
    )
    expect(detailHeading()).toBe('Background updated title')
    await editDetail()
    fireEvent.click(screen.getByRole('button', { name: 'Save' }))
    await waitFor(() =>
      expect(transact).toHaveBeenCalledWith(
        expect.objectContaining({ expectedMetadataRevision: 2 })
      )
    )
  })

  // partial_background_read: when one completed item cannot be read, the readable
  // items still publish (Promise.allSettled), and the error surface still shows.
  it('partial_background_read', async () => {
    const summary = {
      id: 'partial-read-job',
      mode: 'metadata' as const,
      phase: 'apply' as const,
      state: 'running' as const,
      total: 2,
      checked: 2,
      ready: 0,
      done: 0,
      failed: 0,
      createdAt: 1,
      updatedAt: 1,
      completedItemIds: [] as string[]
    }
    vi.mocked(window.api.literature.jobs).mockResolvedValue({ jobs: [], summaries: [summary] })
    await showLibrary()
    await screen.findByRole('button', { name: 'Background tasks' })
    await openReferenceDetail(screen.getByText(libraryItem.item.title))
    get.mockImplementation(async (id: string) => {
      if (id === libraryItem.id) return version(2, 'Successful background update')
      throw new Error('The other reference cannot be read')
    })
    vi.mocked(window.api.literature.jobs).mockResolvedValue({
      jobs: [],
      summaries: [
        {
          ...summary,
          state: 'completed',
          done: 2,
          completedItemIds: [libraryItem.id, 'unavailable-item']
        }
      ]
    })
    await act(async () => window.dispatchEvent(new Event('literature-jobs-changed')))
    // Both reads are attempted (Promise.allSettled), and the readable item still
    // publishes. Settle on the published outcome (harness fixture text, not
    // solution copy) so the heading/table assertions never race the read chain.
    await waitFor(() =>
      expect(
        document.querySelector('[data-slot="literature-table-scroll"]')!.textContent
      ).toContain('Successful background update')
    )
    expect(get).toHaveBeenCalledTimes(2)
    expect(detailHeading()).toBe('Successful background update')
    closeDetail()
    // The failed sibling still raises the existing error surface.
    expect(screen.queryByText('Literature could not be loaded.')).not.toBeNull()
  })

  // draft_retained_on_external_change: a background metadata refresh arriving
  // mid-edit keeps the user's draft and blocks saving until an explicit action.
  it('draft_retained_on_external_change', async () => {
    const summary = {
      id: 'edit-job',
      mode: 'metadata' as const,
      phase: 'apply' as const,
      state: 'running' as const,
      total: 1,
      checked: 1,
      ready: 0,
      done: 0,
      failed: 0,
      createdAt: 1,
      updatedAt: 1,
      completedItemIds: [] as string[]
    }
    vi.mocked(window.api.literature.jobs).mockResolvedValue({ jobs: [], summaries: [summary] })
    await showLibrary()
    await screen.findByRole('button', { name: 'Background tasks' })
    await openReferenceDetail(screen.getByText(libraryItem.item.title))
    await editDetail()
    const title = screen.getByLabelText('Title')
    fireEvent.change(title, { target: { value: 'Work in progress' } })
    get.mockResolvedValue(version(2, 'Background result'))
    vi.mocked(window.api.literature.jobs).mockResolvedValue({
      jobs: [],
      summaries: [{ ...summary, state: 'completed', done: 1, completedItemIds: [libraryItem.id] }]
    })
    await act(async () => window.dispatchEvent(new Event('literature-jobs-changed')))
    // Saving becoming blocked is the observable settle point of the external
    // change (the behavioral stand-in for the recovery banner, whose wording is
    // a solution choice). Waiting on it here avoids racing the async read chain;
    // a solution that silently clobbers the draft never blocks Save and times
    // out instead.
    await waitFor(() =>
      expect((screen.getByRole('button', { name: 'Save' }) as HTMLButtonElement).disabled).toBe(
        true
      )
    )
    // The in-progress draft survives verbatim — same input node, same value —
    // and no write was attempted.
    expect(screen.getByLabelText('Title')).toBe(title)
    expect((title as HTMLInputElement).value).toBe('Work in progress')
    expect(transact).not.toHaveBeenCalled()
  })

  // recovery_is_read_only: a committed save whose readback failed keeps the
  // submitted fields and offers a read-only recovery (a `get`, never a second
  // `transact` against the obsolete revision).
  it('recovery_is_read_only', async () => {
    await showLibrary()
    await openReferenceDetail(screen.getByText(libraryItem.item.title))
    await editDetail()
    let actualRevision = 1
    transact.mockImplementation(async (command) => {
      if (command.expectedMetadataRevision !== actualRevision) throw new Error('Metadata changed')
      actualRevision += 1
      return { kind: 'item', id: libraryItem.id, state: 'present' }
    })
    get.mockRejectedValueOnce(new Error('Read temporarily unavailable'))
    fireEvent.change(screen.getByLabelText('Title'), { target: { value: 'Committed draft' } })
    fireEvent.click(screen.getByRole('button', { name: 'Save' }))
    await waitFor(() => {
      expect(actualRevision).toBe(2)
      expect(get).toHaveBeenCalledTimes(1)
      expect((screen.getByLabelText('Title') as HTMLInputElement).value).toBe('Committed draft')
      expect(screen.getByRole('alert')).not.toBeNull()
    })
    get.mockResolvedValue(version(2, 'Committed draft'))
    fireEvent.click(recoveryOrSave())
    await act(async () => {})
    // The write was acknowledged once; recovery must only re-read.
    expect(transact).toHaveBeenCalledTimes(1)
    await waitFor(() => expect(get).toHaveBeenCalledTimes(2))
    expect(await screen.findByRole('heading', { name: 'Committed draft' })).not.toBeNull()
    expect(transact).toHaveBeenCalledTimes(1)
  })

  // revision_clears_preview_keeps_identifier: a metadata-revision change clears
  // obsolete previews/lookup results but keeps the identifier input + Search; a
  // same-revision attachment update preserves the preview.
  it('revision_clears_preview_keeps_identifier', async () => {
    const summary = {
      id: 'preview-update-job',
      mode: 'metadata' as const,
      phase: 'apply' as const,
      state: 'running' as const,
      total: 1,
      checked: 1,
      ready: 0,
      done: 0,
      failed: 0,
      createdAt: 1,
      updatedAt: 1,
      completedItemIds: [] as string[]
    }
    vi.mocked(window.api.literature.jobs).mockResolvedValue({ jobs: [], summaries: [summary] })
    await showLibrary()
    await screen.findByRole('button', { name: 'Background tasks' })
    await openReferenceDetail(screen.getByText(libraryItem.item.title))
    await openMenu(screen.getByRole('button', { name: 'More actions' }))
    fireEvent.click(screen.getByRole('menuitem', { name: 'Complete metadata' }))
    fireEvent.click(screen.getByRole('button', { name: 'Search' }))
    await screen.findByRole('button', { name: 'Apply metadata' })
    // A newer revision from the background clears the stale preview but keeps the
    // identifier input usable (Search still enabled).
    get.mockResolvedValue(version(2, 'Background revision two'))
    vi.mocked(window.api.literature.jobs).mockResolvedValue({
      jobs: [],
      summaries: [{ ...summary, state: 'completed', done: 1, completedItemIds: [libraryItem.id] }]
    })
    await act(async () => window.dispatchEvent(new Event('literature-jobs-changed')))
    await waitFor(() => expect(get).toHaveBeenCalledTimes(1))
    expect(screen.queryByRole('button', { name: 'Apply metadata' })).toBeNull()
    expect(screen.queryByText('Journal of Retrieval')).toBeNull()
    expect(screen.getByRole('button', { name: 'Search' })).toHaveProperty('disabled', false)
    // A fresh lookup commits against the NEW revision. The preview must carry at
    // least one filled field, because the commit affordance only renders when the
    // review proposes a change (filled or overwrite) — an empty review offers
    // nothing to apply.
    completeMetadata.mockResolvedValueOnce({
      mode: 'preview',
      provider: 'crossref',
      sourceUrl: 'https://example.test',
      item: version(2, 'Background revision two'),
      reviewToken: 'fresh-review',
      filled: [{ field: 'journal', value: 'Journal of Retrieval' }],
      conflicts: []
    })
    fireEvent.click(screen.getByRole('button', { name: 'Search' }))
    fireEvent.click(await screen.findByRole('button', { name: 'Apply metadata' }))
    await waitFor(() =>
      expect(completeMetadata).toHaveBeenLastCalledWith(
        expect.objectContaining({
          mode: 'commit',
          expectedMetadataRevision: 2,
          reviewToken: 'fresh-review'
        })
      )
    )
  })

  // A same-revision attachment update must NOT clear a visible preview.
  it('revision_clears_preview_keeps_identifier same-revision attachment preserves preview', async () => {
    const summary = {
      id: 'attachment-preview-job',
      mode: 'full-text' as const,
      phase: 'apply' as const,
      state: 'running' as const,
      total: 1,
      checked: 1,
      ready: 0,
      done: 0,
      failed: 0,
      createdAt: 1,
      updatedAt: 1,
      completedItemIds: [] as string[]
    }
    vi.mocked(window.api.literature.jobs).mockResolvedValue({ jobs: [], summaries: [summary] })
    await showLibrary()
    await screen.findByRole('button', { name: 'Background tasks' })
    await openReferenceDetail(screen.getByText(libraryItem.item.title))
    await openMenu(screen.getByRole('button', { name: 'More actions' }))
    fireEvent.click(screen.getByRole('menuitem', { name: 'Complete metadata' }))
    fireEvent.click(screen.getByRole('button', { name: 'Search' }))
    await screen.findByRole('button', { name: 'Apply metadata' })
    get.mockResolvedValue(createLibraryItemWithPdf())
    vi.mocked(window.api.literature.jobs).mockResolvedValue({
      jobs: [],
      summaries: [{ ...summary, state: 'completed', done: 1, completedItemIds: [libraryItem.id] }]
    })
    await act(async () => window.dispatchEvent(new Event('literature-jobs-changed')))
    await waitFor(() => expect(get).toHaveBeenCalledTimes(1))
    expect(screen.getByRole('button', { name: 'Apply metadata' })).toHaveProperty('disabled', false)
    expect(screen.getByText('Journal of Retrieval')).not.toBeNull()
  })

  // link_load_respects_selection: a pending linked-reference read must not
  // replace a reference the user selected more recently.
  it('link_load_respects_selection', async () => {
    const second = { ...version(1, 'Manually selected reference'), id: 'item-2' }
    search.mockImplementation(async (request: LiteratureCatalogSearchRequest) => ({
      entries: request.scope === 'library' ? [libraryItem, second] : []
    }))
    const pending = deferred<LiteratureItemView>()
    get.mockReturnValueOnce(pending.promise)
    useNavigationStore.getState().openLiteratureItem(libraryItem.id, 'user')
    render(<LiteratureLibraryPage />)
    await waitFor(() => expect(get).toHaveBeenCalledWith(libraryItem.id))
    await openReferenceDetail(await screen.findByText(second.item.title))
    expect(screen.getByRole('heading', { name: second.item.title })).not.toBeNull()
    await act(async () => pending.resolve(libraryItem))
    expect(detailHeading()).toBe(second.item.title)
  })

  // pdf_import_rereads: a completed PDF import re-reads the current item before
  // publishing attachments, and does not resurrect a stale opening.
  it('pdf_import_rereads', async () => {
    await showLibrary()
    await openReferenceDetail(screen.getByText(libraryItem.item.title))
    stageLocalFile.mockResolvedValue({
      id: 'upload-1',
      sessionId: '.pending',
      name: 'paper.pdf',
      originalName: 'paper.pdf',
      path: '/managed/paper.pdf',
      mimeType: 'application/pdf',
      size: 8
    })
    const pending = deferred<{ item: LiteratureItemView }>()
    importPdf.mockReturnValueOnce(pending.promise)
    fireEvent.change(screen.getByLabelText('Add PDF'), {
      target: { files: [new File(['%PDF-1.7'], 'paper.pdf', { type: 'application/pdf' })] }
    })
    await waitFor(() => expect(importPdf).toHaveBeenCalledTimes(1))
    closeDetail()
    const latest = version(3, 'Latest metadata before attachment')
    get.mockResolvedValueOnce(latest)
    act(() => useNavigationStore.getState().openLiteratureItem(libraryItem.id, 'user'))
    await screen.findByRole('heading', { name: latest.item.title })
    const withPdf = createLibraryItemWithPdf()
    get.mockResolvedValue({ ...latest, attachments: withPdf.attachments })
    await act(async () => pending.resolve({ item: withPdf }))
    await waitFor(() =>
      expect(
        within(screen.getByRole('dialog')).queryByRole('button', { name: 'Preview paper.pdf' })
      ).not.toBeNull()
    )
    // The reread republished to the CURRENT opening: its title, not the import's.
    expect(detailHeading()).toBe(latest.item.title)
    expect(importPdf).toHaveBeenCalledTimes(1)
    expect(get).toHaveBeenCalledTimes(2)
  })
})
