// Behavioral verifier for dalfox-fix-verified-evidence-tiers.
//
// Every scenario runs a real scan through the public entry point
// `dalfox::cmd::scan::run_scan` against an in-process axum server that reflects
// the `q` query parameter through one page shape, then reads the `"type"` field
// of the emitted findings ("V" = DOM-verified, "R" = reflected, "I" = info).
// Nothing private to the scanner is imported, so any internal restructuring is
// fine as long as the reported tiers come out right.
//
// Scan markers (`dlx`/`xld` + 8 hex digits) embed a per-process random nonce,
// so no marker text is hardcoded here; each scenario relies only on the
// scanner's own consistency within one run.
//
// `base_scan_args()` mirrors the repo's `tests/scan_run_paths_test.rs`, then
// `scan_args_for` tunes it to one query param, mining/AST/WAF-probe skipped, one
// worker, one encoder and `deep_scan` off, so first-hit-per-param dedup keeps the
// result to a single finding per param and the tier assertion is stable.

use dalfox::cmd::scan::{ScanArgs, run_scan};

use std::collections::HashMap;
use std::path::PathBuf;
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::{SystemTime, UNIX_EPOCH};

use axum::Router;
use axum::extract::{Query, State};
use axum::response::Html;
use axum::routing::get;
use tokio::net::TcpListener;

/// `run_scan` resets a process-wide request counter on entry, so overlapping
/// scans in the same process race. The runner already forces
/// `--test-threads=1`, but this lock keeps the suite correct under a plain
/// `cargo test` as well.
static SCAN_LOCK: tokio::sync::Mutex<()> = tokio::sync::Mutex::const_new(());

/// Copy of `base_scan_args()` from `tests/scan_run_paths_test.rs`, the repo's
/// own self-contained scan integration test.
fn base_scan_args() -> ScanArgs {
    ScanArgs {
        insecure: Some(true),
        detect_outdated_libs: false,
        input_type: "url".to_string(),
        format: "json".to_string(),
        output: None,
        include_request: false,
        include_response: false,
        include_all: false,
        no_color: false,
        silence: true,
        dry_run: false,
        stream_findings: false,
        poc_type: "plain".to_string(),
        limit: None,
        limit_result_type: "all".to_string(),
        only_poc: vec![],
        baseline: None,
        param: vec![],
        data: None,
        headers: vec![],
        cookies: vec![],
        method: "GET".to_string(),
        user_agent: None,
        cookie_from_raw: None,
        session_check: None,
        session_check_url: None,
        include_url: vec![],
        exclude_url: vec![],
        ignore_param: vec![],
        out_of_scope: vec![],
        out_of_scope_file: None,
        only_discovery: false,
        skip_discovery: false,
        skip_reflection_header: false,
        skip_reflection_cookie: false,
        skip_reflection_path: false,
        mining_dict_word: None,
        remote_wordlists: vec![],
        skip_mining: false,
        skip_mining_dict: false,
        skip_mining_dom: false,
        timeout: 10,
        scan_timeout: 0,
        delay: 0,
        proxy: None,
        follow_redirects: false,
        ignore_return: vec![],
        workers: 10,
        max_concurrent_targets: 10,
        max_targets_per_host: 100,
        encoders: vec!["url".to_string(), "html".to_string()],
        remote_payloads: vec![],
        custom_blind_xss_payload: None,
        blind_callback_url: None,
        oob: Default::default(),
        custom_payload: None,
        only_custom_payload: false,
        inject_marker: None,
        custom_alert_value: "1".to_string(),
        custom_alert_type: "none".to_string(),
        skip_xss_scanning: false,
        deep_scan: false,
        sxss: false,
        sxss_url: None,
        sxss_method: "GET".to_string(),
        sxss_retries: 3,
        skip_ast_analysis: false,
        analyze_external_js: false,
        hpp: false,
        waf_bypass: "off".to_string(),
        skip_waf_probe: true,
        force_waf: None,
        waf_evasion: false,
        rate_limit: 0,
        retries: 0,
        retry_delay: 1000,
        waf_min_confidence: 0.0,
        targets: vec![],
        max_payloads_per_param: 0,
        ..Default::default()
    }
}

/// Single-finding recipe on top of `base_scan_args()`: scan one explicitly
/// provided query param with discovery/mining/AST/WAF-probe noise suppressed,
/// one worker, one encoder, and `deep_scan` off so the first-hit-per-param dedup
/// collapses the result to a single finding per param.
fn scan_args_for(target: &str, output: &str) -> ScanArgs {
    let mut args = base_scan_args();
    args.targets = vec![target.to_string()];
    args.output = Some(output.to_string());
    args.skip_mining = true;
    args.skip_mining_dict = true;
    args.skip_mining_dom = true;
    args.skip_ast_analysis = true;
    args.skip_waf_probe = true;
    args.workers = 1;
    args.deep_scan = false;
    args.encoders = vec!["url".to_string()];
    args.silence = true;
    args
}

fn unique_output_path() -> PathBuf {
    static COUNTER: AtomicU64 = AtomicU64::new(0);
    let nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("system time")
        .as_nanos();
    let n = COUNTER.fetch_add(1, Ordering::Relaxed);
    let mut path = std::env::temp_dir();
    path.push(format!(
        "dalfox-verify-{}-{}-{}.json",
        std::process::id(),
        nanos,
        n
    ));
    path
}

/// Server reflection shape. Takes the raw query value, returns the full HTML
/// page body the mock server serves.
type PageFn = fn(&str) -> String;

async fn reflect_handler(
    State(page): State<PageFn>,
    Query(params): Query<HashMap<String, String>>,
) -> Html<String> {
    let input = params.get("q").cloned().unwrap_or_default();
    Html(page(&input))
}

/// Stand up a local axum server whose single `/` route reflects the `q` param
/// through `page`. Returns the base URL and a handle the caller aborts.
async fn spawn_server(page: PageFn) -> (String, tokio::task::JoinHandle<()>) {
    let app = Router::new().route("/", get(reflect_handler)).with_state(page);
    let listener = TcpListener::bind("127.0.0.1:0").await.expect("bind");
    let addr = listener.local_addr().expect("addr");
    let handle = tokio::spawn(async move {
        let _ = axum::serve(listener, app).await;
    });
    (format!("http://{}/", addr), handle)
}

/// Run one scan against `page`, returning the emitted findings array.
async fn scan_findings(page: PageFn) -> Vec<serde_json::Value> {
    let _guard = SCAN_LOCK.lock().await;
    let (base, handle) = spawn_server(page).await;
    let output = unique_output_path();
    let target = format!("{}?q=1", base);
    let args = scan_args_for(&target, &output.to_string_lossy());

    run_scan(&args).await;
    handle.abort();

    let content = std::fs::read_to_string(&output).expect("scan output file should exist");
    let _ = std::fs::remove_file(&output);
    let parsed: serde_json::Value =
        serde_json::from_str(&content).expect("scan output should be valid JSON");
    parsed["findings"]
        .as_array()
        .cloned()
        .unwrap_or_default()
}

fn has_verified(findings: &[serde_json::Value]) -> bool {
    findings
        .iter()
        .any(|f| f.get("type").and_then(|t| t.as_str()) == Some("V"))
}

fn type_summary(findings: &[serde_json::Value]) -> Vec<String> {
    findings
        .iter()
        .map(|f| {
            f.get("type")
                .and_then(|t| t.as_str())
                .unwrap_or("?")
                .to_string()
        })
        .collect()
}

/// HTML-escape the three characters that would let a tag form.
fn escape_angles(input: &str) -> String {
    input
        .replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
}

/// Upper-case the first character of the reflected value, leave the rest alone
/// (`ucfirst` / `capitalize` style template filters).
fn capitalize_first(input: &str) -> String {
    let mut chars = input.chars();
    match chars.next() {
        Some(c) => c.to_ascii_uppercase().to_string() + chars.as_str(),
        None => String::new(),
    }
}

// ── Reflection shapes ─────────────────────────────────────────────────────

/// The input lands inside a pre-existing *double-quoted* `style` attribute
/// value, inside a single-quoted `url('…')`; angle brackets are HTML-encoded so
/// no tag can form. A quote breakout that opens an `on*=` handler and then an
/// `id=`/`class=` marker ends up with the handler absorbed into the style value
/// while the marker still tokenizes onto the live `<p>`: a marker on an element
/// that executes nothing.
fn page_swallowed_handler(input: &str) -> String {
    format!(
        "<html><body><p style=\"background-image: url('{}')\">text</p></body></html>",
        escape_angles(input)
    )
}

/// Same swallow, different host: a visible text `<input>` whose double-quoted
/// `placeholder` wraps the input in single quotes. The element is rendered and
/// interactive, so only the swallowed handler, not the element kind, keeps this
/// below the verified tier.
fn page_swallowed_handler_text_input(input: &str) -> String {
    format!(
        "<html><body><form><input type=\"text\" name=\"s\" placeholder=\"Search for '{}'\"></form></body></html>",
        escape_angles(input)
    )
}

/// The input lands in a double-quoted `value` attribute of a text input, angle
/// brackets encoded. A quote breakout closes the value, so the injected on*
/// handler and the marker both land as real attributes of the live input and
/// the handler fires when the user hovers it.
fn page_attribute_breakout(input: &str) -> String {
    format!(
        "<html><body><form><input type=\"text\" name=\"s\" value=\"{}\"></form></body></html>",
        escape_angles(input)
    )
}

/// The input is reflected into the body with only its first character
/// upper-cased. Every special character comes back raw, and a breakout tag such
/// as `<svg onload=alert(1)>` starts with `<`, so it lands with its handler
/// unchanged and runs.
fn page_first_letter_upper(input: &str) -> String {
    format!(
        "<html><body><div>{}</div></body></html>",
        capitalize_first(input)
    )
}

/// Same case change, but angle brackets are HTML-encoded too, so no tag can
/// form and nothing injected can execute. The input is still visibly reflected.
fn page_first_letter_upper_no_breakout(input: &str) -> String {
    format!(
        "<html><body><div>{}</div></body></html>",
        escape_angles(&capitalize_first(input))
    )
}

/// Input reflected raw into a plain body, so a genuine `<svg onload=…>` breakout
/// forms a real executing element carrying both its handler and its marker.
fn page_raw_body(input: &str) -> String {
    format!("<html><body><div>{}</div></body></html>", input)
}

/// Ordinary reflecting page: the input is echoed into page text.
fn page_basic_reflection(input: &str) -> String {
    format!(
        "<html><body><h1>Results</h1><p>You searched for: {}</p></body></html>",
        input
    )
}

/// JS-sink tokens and executable-URL protocols the scanner recognizes.
/// `page_structural_marker` neutralizes exactly these so that no payload carrying
/// an executable sink can reach tier V, leaving a sinkless structural marker as
/// the only DOM-verifiable route. (A drift in the scanner's vocabulary would at
/// worst let one extra payload through, which does not weaken that assertion.)
const SINK_TOKENS: &[&str] = &[
    "alert",
    "prompt",
    "confirm",
    "print",
    "eval",
    "setTimeout",
    "setInterval",
    "Function",
    "writeln",
    "write",
    "insertAdjacentHTML",
    "setHTMLUnsafe",
    "parseHTMLUnsafe",
    "innerHTML",
    "outerHTML",
    "srcdoc",
    "javascript:",
    "vbscript:",
    "data:text/html",
    "location",
    "href",
];

/// Case-insensitively blunt the first byte of every executable-sink token in the
/// reflected input, iterating to a fixed point. Tag/attribute/marker structure is
/// otherwise preserved, so a reflected payload that lands a `class=`/`id=` marker
/// on a real element with no surviving executable sink still parses into that
/// element.
fn defang_sinks(input: &str) -> String {
    let mut s = input.to_string();
    loop {
        let lower = s.to_ascii_lowercase();
        let mut hit: Option<usize> = None;
        for tok in SINK_TOKENS {
            if let Some(p) = lower.find(&tok.to_ascii_lowercase()) {
                hit = Some(match hit {
                    Some(h) => h.min(p),
                    None => p,
                });
            }
        }
        match hit {
            // Tokens are ASCII, so byte index `p` is a char boundary.
            Some(p) => {
                let mut v = s.into_bytes();
                v[p] = b'_';
                s = String::from_utf8(v).expect("ASCII edit preserves UTF-8");
            }
            None => break,
        }
    }
    s
}

/// Structural-marker context: the input is reflected into a plain body, but
/// every executable-sink token is neutralized first, so no payload's
/// handler/script/url survives as a sink. A payload that still tokenizes its
/// `class=`/`id=` marker onto a real element therefore DOM-verifies purely on
/// presence-only structural evidence (base-href / DOM-clobbering style markers).
fn page_structural_marker(input: &str) -> String {
    format!(
        "<html><head></head><body><div>{}</div></body></html>",
        defang_sinks(input)
    )
}

// ── Scenarios ─────────────────────────────────────────────────────────────

/// A handler swallowed into a pre-existing quoted attribute value is not
/// DOM-verified. The input is still reflected, so a finding exists; it just
/// is not "V".
#[tokio::test]
async fn swallowed_handler_injection_not_dom_verified() {
    let findings = scan_findings(page_swallowed_handler).await;
    assert!(
        !findings.is_empty(),
        "the input is reflected, so the scan should still report a finding (just not V); \
         got no findings at all"
    );
    assert!(
        !has_verified(&findings),
        "the injected on*-handler is absorbed into the pre-existing quoted style value and \
         never fires, so no finding may be tier V; got types {:?}",
        type_summary(&findings)
    );
}

/// Same swallow on a rendered, interactive element (a text input's
/// placeholder): still reported, still not "V".
#[tokio::test]
async fn swallowed_handler_on_text_input_not_dom_verified() {
    let findings = scan_findings(page_swallowed_handler_text_input).await;
    assert!(
        !findings.is_empty(),
        "the input is reflected into the placeholder, so the scan should still report a \
         finding (just not V); got no findings at all"
    );
    assert!(
        !has_verified(&findings),
        "the injected on*-handler is absorbed into the pre-existing quoted placeholder value \
         and never fires, even though the input element itself is rendered; no finding may be \
         tier V; got types {:?}",
        type_summary(&findings)
    );
}

/// An attribute breakout whose on* handler lands on the live element next to
/// the marker stays DOM-verified: the handler is there and fires.
#[tokio::test]
async fn attribute_breakout_with_live_handler_still_dom_verified() {
    let findings = scan_findings(page_attribute_breakout).await;
    assert!(
        has_verified(&findings),
        "the quote breakout closes the value and the injected on*-handler lands on the live \
         input next to the marker, so it fires; the finding must stay tier V; got types {:?}",
        type_summary(&findings)
    );
}

/// When the server only changes the letter case of the reflection and a
/// breakout tag still lands and runs, the finding reaches DOM-verified instead
/// of being muted to a weak tier.
#[tokio::test]
async fn casefold_reflection_reaches_dom_verified() {
    let findings = scan_findings(page_first_letter_upper).await;
    assert!(
        has_verified(&findings),
        "every special char reflects raw and only the first letter of the value is \
         upper-cased, so a breakout tag lands untouched and executes; the finding must reach \
         tier V; got types {:?}",
        type_summary(&findings)
    );
}

/// The same case change with angle brackets encoded: the input is reflected but
/// nothing injected can execute, so the finding stays below "V".
#[tokio::test]
async fn casefold_reflection_without_breakout_stays_below_dom_verified() {
    let findings = scan_findings(page_first_letter_upper_no_breakout).await;
    assert!(
        !has_verified(&findings),
        "with angle brackets encoded no tag forms and no handler runs, so a case-changed \
         reflection alone must not be tier V; got types {:?}",
        type_summary(&findings)
    );
}

/// A genuine breakout that forms a real executing element with its handler
/// intact stays DOM-verified.
#[tokio::test]
async fn genuine_breakout_still_dom_verified() {
    let findings = scan_findings(page_raw_body).await;
    assert!(
        has_verified(&findings),
        "a real breakout forming an executing element with a surviving sink must stay tier V; \
         got types {:?}",
        type_summary(&findings)
    );
}

/// An ordinary reflecting page still produces a finding.
#[tokio::test]
async fn basic_reflection_still_detected() {
    let findings = scan_findings(page_basic_reflection).await;
    assert!(
        !findings.is_empty(),
        "an ordinary reflected input must still yield at least one finding; got none"
    );
}

/// A sinkless *structural* marker keeps its presence-only DOM evidence and
/// stays tier V. No executable sink survives in the reflection, so the only
/// route to V is the marker-presence path. Together with
/// `genuine_breakout_still_dom_verified` this pins both edges of the
/// marker-evidence decision.
#[tokio::test]
async fn structural_marker_still_dom_verified() {
    let findings = scan_findings(page_structural_marker).await;
    assert!(
        has_verified(&findings),
        "a reflected payload that lands its class/id marker on a real element must stay tier V \
         on structural (presence-only) evidence even when no executable sink survives; \
         got types {:?}",
        type_summary(&findings)
    );
}
