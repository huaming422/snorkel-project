#!/usr/bin/env bash
# test-setup.sh — sourced by tests/test.sh before the verifier runs
# (set -euo pipefail inherited). Must run with the network cut: the smoke
# gate's offline fold sources this inside `docker run --network none`.
#
# The verifier is a native Rust integration test (verify*_test.rs) that the
# Rust runner injects into the dalfox crate's tests/ dir and runs with
# `cargo test --test …`. That test compiles the crate + an in-process axum
# mock server and runs full scans via `dalfox::cmd::scan::run_scan`. This
# script warms the build so the verifier's first `cargo test` is incremental.
set -euo pipefail

cd /repo/dalfox

# Offline switch right after cd so a cache miss fails fast instead of
# reaching for crates.io. The image baked the full dependency closure at the
# base commit (cargo fetch --locked && cargo build --locked --tests).
export CARGO_NET_OFFLINE=true

# Offline-first build of the crate + its tests against the image's warm
# cargo cache, with a logged online fallback if the bake was stale. Check
# each exit status directly — never pipe to `tail` (that masks the status).
if cargo build --locked --offline --tests > /tmp/test-setup-build.log 2>&1; then
    echo "[offline-first] crate + tests built from image cargo cache"
elif cargo build --locked --tests >> /tmp/test-setup-build.log 2>&1; then
    echo "[test-setup] crate + tests built online (image bake was stale)"
else
    # Log and carry on: the Rust runner reports a crate that doesn't compile
    # as failed tests, so the verifier and the aggregation still run.
    echo "[test-setup] crate + tests failed to build, last 60 lines:" >&2
    tail -60 /tmp/test-setup-build.log >&2
fi

# No services to start and no data to seed: the behavioral mock server runs
# in-process inside the Rust verifier itself. No verifier-only packages to
# install — the whole verifier is native Rust.
