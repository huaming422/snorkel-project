## Task

Re-opening the PoC URLs from a scan showed reflected XSS tiers that are wrong in both directions.

Some findings come back as [V] DOM verification successful and opening the PoC does nothing, the injected handler never fires. The input is reflected on those pages, so the finding should stay in the results, just not as verified. Where the injected handler does fire, [V] is right and should stay.

Pages that change the letter case of what they echo get the opposite. They come back as [R] or with no finding at all, even where a breakout tag typed by hand lands and runs.

Fix both so the tier of each finding matches what the injected payload does in the browser.
