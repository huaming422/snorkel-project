//! Behavioral checks that asking a wrapped tool for its own help through rtk
//! shows the tool's help — exercised end to end through the compiled `rtk`
//! binary, never by importing internal functions.
//!
//! The binary is driven exactly as a user's shell would drive it: `rtk <tool>
//! <args>` spawned directly (no shell), with its tracking database and tee
//! spool redirected into this test's scratch directory by `common::rtk_command`.
//! Each case is differential — rtk's answer is compared against what the native
//! tool answers in the same isolated environment — so the checks describe
//! observable behavior and stay agnostic to how the fix is structured (which
//! helper releases the flag, which seam guards the output, what the detection
//! predicate is named).
//!
//! Two independent failure modes are covered, because the symptom has two
//! halves: rtk must not answer the flag itself (its own usage is recognisable
//! by the `Usage: rtk` line), and once the flag reaches the tool rtk's
//! compact-output filters must not swallow the page the tool printed. A
//! length-only check is deliberately avoided for the positive path: content is
//! anchored on the tool's own first substantial line so a long page from the
//! wrong subcommand cannot pass, and a near-empty filtered summary cannot
//! either.
//!
//! Tools that are not installed are skipped rather than failed, so the suite
//! runs against whatever the image carries. `cargo` is the toolchain and is
//! always present; it anchors the positive path.

mod common;

use std::path::{Path, PathBuf};
use std::process::Command;

/// First directory on PATH that holds an executable named `tool`, or `None`.
fn on_path(tool: &str) -> Option<PathBuf> {
    let paths = std::env::var_os("PATH")?;
    std::env::split_paths(&paths)
        .map(|d| d.join(tool))
        .find(|p| p.is_file())
}

/// The first line long enough to identify the page — `Compile a local
/// package`, `GIT-LOG(1)`. A page from the wrong subcommand fails to match
/// this where a length check would pass.
fn first_substantial_line(text: &str) -> &str {
    text.lines()
        .map(str::trim_end)
        .find(|l| l.trim().len() > 8)
        .unwrap_or("")
}

/// rtk names the program from argv[0]; its own usage block starts `Usage: rtk`.
fn is_rtk_usage(text: &str) -> bool {
    text.contains("Usage: rtk")
}

struct Output {
    text: String,
    code: i32,
}

/// Run `cmd args`, folding stdout then stderr into one string. `LC_ALL=C` and a
/// pinned width keep a translated or terminal-sensitive page comparable on both
/// sides.
fn finish(mut cmd: Command, args: &[&str], label: &str) -> Output {
    let out = cmd
        .args(args)
        .env("LC_ALL", "C")
        .env("MANWIDTH", "80")
        .env("COLUMNS", "80")
        .output()
        .unwrap_or_else(|e| panic!("spawn {label}: {e}"));
    let mut text = String::from_utf8_lossy(&out.stdout).into_owned();
    text.push_str(&String::from_utf8_lossy(&out.stderr));
    Output {
        text,
        code: out.status.code().unwrap_or(-1),
    }
}

/// The native tool, in the same isolated environment an rtk child gets.
fn run_native(program: &Path, args: &[&str]) -> Output {
    let label = program.display().to_string();
    finish(common::native_command(&label), args, &label)
}

/// rtk, isolated to this test's scratch directory.
fn run_rtk(args: &[&str]) -> Output {
    finish(common::rtk_command(), args, "rtk")
}

/// Criterion: a wrapped tool's own help reaches the tool in full.
///
/// `rtk cargo build --help` must answer with cargo's help page — not rtk's own
/// usage, and not a near-empty compact summary. The positive anchor is content
/// (cargo's first substantial line) plus a floor on length, so both halves of
/// the bug are caught: answering the flag with rtk usage, and letting the
/// filter eat the page down to its one-line summary.
#[test]
fn a_wrapped_tools_own_help_reaches_the_tool() {
    let cargo = on_path("cargo").expect("cargo is the toolchain and must be on PATH");

    let mine = run_rtk(&["cargo", "build", "--help"]);
    let native = run_native(&cargo, &["build", "--help"]);

    assert!(
        !is_rtk_usage(&mine.text),
        "rtk cargo build --help answered with rtk's own usage:\n{}",
        &mine.text[..mine.text.len().min(400)]
    );
    assert_eq!(
        mine.code, native.code,
        "rtk cargo build --help exit code drifted from cargo's"
    );
    let anchor = first_substantial_line(&native.text);
    assert!(
        !anchor.is_empty() && mine.text.contains(anchor),
        "rtk cargo build --help does not contain cargo's own first line {anchor:?}; \
         got {} bytes:\n{}",
        mine.text.len(),
        &mine.text[..mine.text.len().min(400)]
    );
    assert!(
        mine.text.len() * 2 >= native.text.len(),
        "rtk cargo build --help returned {} bytes of cargo's {} — the help page \
         was filtered away",
        mine.text.len(),
        native.text.len()
    );

    // git carries no manpages in the minimized image, so its `log --help` is a
    // short notice rather than a full page; the observable contract there is
    // only that the request reaches git (git's own words, git's own exit code)
    // instead of being answered with rtk's usage or an empty summary.
    if let Some(git) = on_path("git") {
        let repo = common::temp_git_repo();
        let mut rtk_cmd = common::rtk_command();
        rtk_cmd.current_dir(repo.path()).arg("git");
        let gmine = finish(rtk_cmd, &["log", "--help"], "rtk");

        let mut git_cmd = Command::new(&git);
        common::isolate_git(&mut git_cmd);
        git_cmd.current_dir(repo.path());
        let gnative = finish(git_cmd, &["log", "--help"], "git");

        assert!(
            !is_rtk_usage(&gmine.text),
            "rtk git log --help answered with rtk's own usage:\n{}",
            &gmine.text[..gmine.text.len().min(400)]
        );
        assert_eq!(
            gmine.code, gnative.code,
            "rtk git log --help exit code drifted from git's"
        );
        // The minimized image carries no manpages, so git answers `log --help`
        // with a short notice rather than a full page; its exact wording is
        // environment-dependent, so the robust contract is only that rtk
        // reaches git — its answer is at least half the size of git's own, not
        // compressed down to rtk's ~one-line compact summary (the half-fix where
        // the flag reaches git but the output filter still eats it).
        assert!(
            gmine.text.len() * 2 >= gnative.text.len(),
            "rtk git log --help returned {} bytes of git's {} — git's answer was \
             filtered away instead of reaching the user",
            gmine.text.len(),
            gnative.text.len()
        );
    }
}

/// Criterion: `-h` keeps its non-help meaning for tools that spell something
/// else with it.
///
/// For grep, `-h` is `--no-filename`: the output must be grep's matches, byte
/// for byte, with the filename dropped — never a help page. For `ls`/`tree`,
/// `-h` is a human-readable size: rtk keeps filtering the listing, so its
/// answer must differ from the tool's raw `-h` output and must not be empty. A
/// fix that over-releases `-h` and starts treating it as help regresses here.
#[cfg(unix)]
#[test]
fn dash_h_keeps_its_non_help_meaning() {
    // grep -h: the reported bug, end to end.
    if let Some(grep) = on_path("grep") {
        let dir = tempfile::tempdir().expect("tempdir");
        let a = dir.path().join("a.txt");
        let b = dir.path().join("b.txt");
        std::fs::write(&a, "alpha\nbeta\n").expect("write a");
        std::fs::write(&b, "alpha\ngamma\n").expect("write b");
        let (a, b) = (
            a.to_string_lossy().into_owned(),
            b.to_string_lossy().into_owned(),
        );

        for flags in [
            vec!["-h", "alpha", &a, &b],
            vec!["alpha", "-h", &a, &b],
            vec!["-h", "-n", "alpha", &a, &b],
        ] {
            let mine = run_rtk(&[&["grep"], flags.as_slice()].concat());
            let native = run_native(&grep, &flags);
            assert!(
                !is_rtk_usage(&mine.text),
                "rtk grep {} answered with rtk's usage instead of searching",
                flags.join(" ")
            );
            assert_eq!(
                mine.text,
                native.text,
                "rtk grep {} diverged from grep (-h must stay --no-filename)",
                flags.join(" ")
            );
            assert_eq!(mine.code, native.code, "exit code for grep {}", flags.join(" "));
        }
    } else {
        eprintln!("skipped: grep not installed");
    }

    // ls -h / tree -h: a human-readable size, still filtered by rtk — not help,
    // not passed through raw.
    let dir = tempfile::tempdir().expect("tempdir");
    std::fs::write(dir.path().join("one.txt"), "x\n").expect("write");
    std::fs::write(dir.path().join("two.txt"), "y\n").expect("write");
    let path = dir.path().to_string_lossy().into_owned();
    for tool in ["ls", "tree"] {
        let Some(native) = on_path(tool) else {
            continue;
        };
        let mine = run_rtk(&[tool, "-h", &path]);
        let raw = run_native(&native, &["-h", &path]);
        assert!(
            !is_rtk_usage(&mine.text),
            "rtk {tool} -h answered with rtk's usage instead of a listing"
        );
        assert!(
            !mine.text.is_empty(),
            "rtk {tool} -h produced nothing"
        );
        assert_ne!(
            mine.text, raw.text,
            "rtk {tool} -h passed the tool's output through unfiltered; is `-h` \
             still treated as a size flag rather than help?"
        );
    }
}

/// Criterion: a flag that carries a value is not a usage request.
///
/// When a caller's value happens to spell a help token, the tool must still
/// search for / consume it, not print usage. `grep -e --help FILE` searches for
/// the literal `--help`; `grep -- --version FILE` searches for `--version`. rtk
/// must forward these untouched, byte for byte.
#[cfg(unix)]
#[test]
fn a_caller_value_that_spells_a_help_token_is_not_a_request() {
    let Some(grep) = on_path("grep") else {
        eprintln!("skipped: grep not installed");
        return;
    };
    let dir = tempfile::tempdir().expect("tempdir");
    let file = dir.path().join("flags.txt");
    std::fs::write(&file, "use --help for usage\nplain\nuse --version here\n").expect("write");
    let f = file.to_string_lossy().into_owned();

    for args in [
        vec!["-e", "--help", &f],
        vec!["--", "--version", &f],
        vec!["-F", "--", "--help", &f],
    ] {
        let mine = run_rtk(&[&["grep"], args.as_slice()].concat());
        let native = run_native(&grep, &args);
        assert!(
            !is_rtk_usage(&mine.text),
            "rtk grep {} answered with rtk's usage instead of searching for the value",
            args.join(" ")
        );
        assert_eq!(
            mine.text,
            native.text,
            "rtk grep {} searched differently from grep — a value was misread as a help request",
            args.join(" ")
        );
        assert_eq!(mine.code, native.code, "exit code for grep {}", args.join(" "));
    }
}

/// Criterion: a tool that forwards past `--` has the post-`--` region
/// rescanned.
///
/// `cargo test -- --help` sends `--help` to the compiled test binary, whose
/// usage (libtest's) must come through rtk in full; a non-forwarding tool keeps
/// `--help` after `--` as a literal (`grep -- --help` searches for it). The
/// cargo half is exercised in a throwaway no-dependency crate so the build is
/// cheap and offline.
#[test]
fn a_forwarding_tool_rescans_past_the_double_dash() {
    // grep half: `--` makes `--help` a literal pattern, never a usage request.
    if let Some(grep) = on_path("grep") {
        let dir = tempfile::tempdir().expect("tempdir");
        let file = dir.path().join("hay.txt");
        std::fs::write(&file, "a --help b\nc\n").expect("write");
        let f = file.to_string_lossy().into_owned();
        let mine = run_rtk(&["grep", "--", "--help", &f]);
        let native = run_native(&grep, &["--", "--help", &f]);
        assert!(
            !is_rtk_usage(&mine.text),
            "rtk grep -- --help answered with rtk's usage instead of searching"
        );
        assert_eq!(
            mine.text, native.text,
            "rtk grep -- --help diverged — a literal pattern was misread as help"
        );
    }

    // cargo half: the post-`--` `--help` reaches libtest and its usage survives.
    let Some(cargo) = on_path("cargo") else {
        eprintln!("skipped: cargo not on PATH");
        return;
    };
    let dir = tempfile::tempdir().expect("tempdir");
    std::fs::write(
        dir.path().join("Cargo.toml"),
        "[package]\nname = \"probe\"\nversion = \"0.0.0\"\nedition = \"2021\"\n\n[lib]\npath = \"lib.rs\"\n",
    )
    .expect("write Cargo.toml");
    std::fs::write(
        dir.path().join("lib.rs"),
        "#[test]\nfn noop() {}\n",
    )
    .expect("write lib.rs");

    let native = {
        let mut c = common::native_command(&cargo.display().to_string());
        c.current_dir(dir.path());
        finish(c, &["test", "--", "--help"], "cargo")
    };
    // If the throwaway build cannot produce libtest's usage here (no toolchain
    // for an offline no-dep crate, say), there is nothing to compare against —
    // skip rather than fail on an environment limitation.
    if !native.text.contains("--test-threads") {
        eprintln!(
            "skipped: native `cargo test -- --help` did not yield libtest usage:\n{}",
            &native.text[..native.text.len().min(300)]
        );
        return;
    }

    let mine = {
        let mut c = common::rtk_command();
        c.current_dir(dir.path()).arg("cargo");
        finish(c, &["test", "--", "--help"], "rtk")
    };
    assert!(
        !is_rtk_usage(&mine.text),
        "rtk cargo test -- --help answered with rtk's own usage:\n{}",
        &mine.text[..mine.text.len().min(400)]
    );
    assert!(
        mine.text.contains("--test-threads"),
        "rtk cargo test -- --help did not forward libtest's usage past `--`; \
         got {} bytes:\n{}",
        mine.text.len(),
        &mine.text[..mine.text.len().min(400)]
    );
}

/// Criterion: rtk's own commands and `rtk help <wrapper>` still render rtk's
/// usage.
///
/// Releasing meta flags everywhere would satisfy every passthrough check above
/// and leave no way to read rtk's own usage. rtk's own and composite commands,
/// and `rtk help <wrapper>`, must keep answering with rtk's usage.
#[test]
fn rtks_own_commands_keep_their_help() {
    for args in [
        vec!["--help"],
        vec!["-h"],
        vec!["init", "--help"],
        vec!["gain", "--help"],
        vec!["help", "grep"],
    ] {
        let out = run_rtk(&args);
        assert!(
            is_rtk_usage(&out.text),
            "rtk {} should render rtk's own usage, got:\n{}",
            args.join(" "),
            &out.text[..out.text.len().min(400)]
        );
    }
}
