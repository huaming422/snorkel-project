#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier (set -euo pipefail inherited).
# rtk is a Rust/cargo repo. The image baked the full dependency + build closure
# at the base commit (cargo fetch --locked && cargo build --locked --tests), so
# grading is offline: a cache miss must fail fast, not reach for a registry.
cd /repo/rtk

# Offline switch: here, not image ENV (§1.5 — an image-wide uv/cargo offline
# switch would break harbor's `uv tool install` of the agent harness at prep).
export CARGO_NET_OFFLINE=true

# Dependencies: offline-first against the image bake, logged online fallback.
if cargo fetch --locked --offline > /tmp/test-setup-fetch.log 2>&1; then
    echo "[offline-first] cargo deps satisfied from image"
elif cargo fetch --locked >> /tmp/test-setup-fetch.log 2>&1; then
    echo "[test-setup] cargo deps fetched online (image bake was stale)"
else
    tail -40 /tmp/test-setup-fetch.log >&2; exit 1
fi

# No services to seed and no verifier-only packages beyond the canonical
# /opt/tooling venv. The verifier builds and drives the rtk binary itself.
