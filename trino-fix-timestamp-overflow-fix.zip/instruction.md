## Task

Timestamp arithmetic misbehaves near the ends of the supported range, for `timestamp` and `timestamp with time zone` at every precision.

`date_add` on a `timestamp`, and adding or subtracting an interval, can return a wrong timestamp when the real result is past the end of the range: `SELECT date_add('month', 1, TIMESTAMP '294246-12-10 04:00:54.775999')` returns `-290308-12-21 19:59:05.224383`. Whenever the result can't be represented they should fail with `NUMERIC_VALUE_OUT_OF_RANGE`, and whenever it can they should return it, right up to either end of the range. The one exception is a `date_add` month, quarter or year count in the billions: today that is rejected as `INVALID_FUNCTION_ARGUMENT`, and either code is fine there.

Subtracting two timestamps can give the wrong interval even when the right one is representable. `TIMESTAMP '294247-01-10 04:00:54.775807' - TIMESTAMP '1970-01-01 00:00:00.000000'` gives `-106751991 04:00:54.775` instead of `106751991 04:00:54.776`. At precision 7 and above, a difference within a picosecond of half a millisecond can also land on the wrong millisecond. The result should be the exact difference rounded to the nearest millisecond, a half rounding up toward positive (so -0.5 ms gives 0).

Plugins need the same limits through the SPI: `LongTimestampWithTimeZone` should refuse epoch millis, or epoch seconds, that `timestamp with time zone` can't store, and `getPreviousValue`/`getNextValue` on that type should return nothing at the ends of the range rather than a value it can't store.
