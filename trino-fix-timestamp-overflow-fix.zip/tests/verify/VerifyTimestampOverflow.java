/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.trino.verify;

import io.trino.Session;
import io.trino.spi.type.LongTimestampWithTimeZone;
import io.trino.spi.type.Type;
import io.trino.sql.query.QueryAssertions;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import java.util.Optional;

import static io.trino.spi.StandardErrorCode.INVALID_FUNCTION_ARGUMENT;
import static io.trino.spi.StandardErrorCode.NUMERIC_VALUE_OUT_OF_RANGE;
import static io.trino.spi.function.OperatorType.ADD;
import static io.trino.spi.function.OperatorType.SUBTRACT;
import static io.trino.spi.type.TimeZoneKey.UTC_KEY;
import static io.trino.spi.type.TimestampWithTimeZoneType.createTimestampWithTimeZoneType;
import static io.trino.spi.type.Timestamps.PICOSECONDS_PER_MILLISECOND;
import static io.trino.testing.TestingSession.DEFAULT_TIME_ZONE_KEY;
import static io.trino.testing.TestingSession.testSessionBuilder;
import static io.trino.testing.assertions.TrinoExceptionAssert.assertTrinoExceptionThrownBy;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.TestInstance.Lifecycle.PER_CLASS;

/**
 * Timestamp arithmetic at the far ends of the supported range, checked through
 * the SQL scalar/operator layer ({@link QueryAssertions}) and the public
 * {@code LongTimestampWithTimeZone} and {@code Type} SPI.
 *
 * verify.py maps each @Test method onto one pytest test.
 */
@TestInstance(PER_CLASS)
public class VerifyTimestampOverflow
{
    // largest and smallest epoch millis a timestamp with time zone can store
    private static final long MAX_TZ_EPOCH_MILLIS = (1L << 51) - 1;
    private static final long MIN_TZ_EPOCH_MILLIS = -(1L << 51);

    private QueryAssertions assertions;

    @BeforeAll
    public void init()
    {
        // Same session timezone the repo's own TestTimestamp uses, so the plain-
        // timestamp expected literals below reproduce exactly.
        Session session = testSessionBuilder()
                .setTimeZoneKey(DEFAULT_TIME_ZONE_KEY)
                .build();
        assertions = new QueryAssertions(session);
    }

    @AfterAll
    public void teardown()
    {
        assertions.close();
        assertions = null;
    }

    /**
     * date_add on a timestamp returns the shifted value when it is representable
     * and fails with NUMERIC_VALUE_OUT_OF_RANGE when it is not, at precision 6
     * and below and at precision 7 and above.
     */
    @Test
    public void test0DateAddOverflow()
    {
        // the largest representable result still comes back
        assertThat(assertions.expression("date_add('millisecond', 9223372036854775, TIMESTAMP '1970-01-01 00:00:00.000807')"))
                .matches("TIMESTAMP '294247-01-10 04:00:54.775807'");

        // one microsecond past the top of the range
        assertTrinoExceptionThrownBy(assertions.expression("date_add('millisecond', 9223372036854775, TIMESTAMP '1970-01-01 00:00:00.000808')")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);

        // a result inside the last millisecond above the bottom of the range still comes back
        // (no literal parses there, so check it by shifting back), at precision 6 and precision 12
        assertThat(assertions.expression("date_add('millisecond', 9223372036854776, date_add('millisecond', -9223372036854776, TIMESTAMP '1970-01-01 00:00:00.000500'))"))
                .matches("TIMESTAMP '1970-01-01 00:00:00.000500'");
        assertThat(assertions.expression("date_add('millisecond', 9223372036854776, date_add('millisecond', -9223372036854776, TIMESTAMP '1970-01-01 00:00:00.000500000001'))"))
                .matches("TIMESTAMP '1970-01-01 00:00:00.000500000001'");

        // month unit, precision 6 and precision 12
        assertTrinoExceptionThrownBy(assertions.expression("date_add('month', 1, TIMESTAMP '294246-12-10 04:00:54.775999')")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
        assertTrinoExceptionThrownBy(assertions.expression("date_add('month', 1, TIMESTAMP '294246-12-10 04:00:54.775999999999')")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);

        // a very large day shift, precision 0 and precision 12
        String days = Long.toString(30L * 24 * 60 * 60 * 1000);
        assertTrinoExceptionThrownBy(assertions.expression("date_add('day', " + days + ", TIMESTAMP '0001-01-01 00:00:00')")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
        assertTrinoExceptionThrownBy(assertions.expression("date_add('day', " + days + ", TIMESTAMP '0001-01-01 00:00:00.000000000000')")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);

        // one month below a value near the bottom of the range
        String minTimestamp = "date_add('millisecond', -9223372036854775, TIMESTAMP '1970-01-01 00:00:00.000000')";
        assertTrinoExceptionThrownBy(assertions.expression("date_add('month', -1, " + minTimestamp + ")")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
    }

    /**
     * timestamp +/- INTERVAL (DAY TO SECOND and YEAR TO MONTH, precision 6 and
     * precision 12, both operand orders) returns the value when it is
     * representable and fails with NUMERIC_VALUE_OUT_OF_RANGE when it is not.
     */
    @Test
    public void test1IntervalAddOverflow()
    {
        // YEAR TO MONTH: representable result, then one microsecond over
        assertThat(assertions.operator(ADD, "TIMESTAMP '294246-12-10 04:00:54.775807'", "INTERVAL '1' month"))
                .matches("TIMESTAMP '294247-01-10 04:00:54.775807'");
        assertTrinoExceptionThrownBy(assertions.operator(ADD, "TIMESTAMP '294246-12-10 04:00:54.775808'", "INTERVAL '1' month")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
        assertTrinoExceptionThrownBy(assertions.operator(ADD, "TIMESTAMP '294246-12-10 04:00:54.775808000000'", "INTERVAL '1' month")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
        assertTrinoExceptionThrownBy(assertions.operator(ADD, "INTERVAL '1' month", "TIMESTAMP '294246-12-10 04:00:54.775808'")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);

        // DAY TO SECOND: representable result, then one second over
        assertThat(assertions.operator(ADD, "TIMESTAMP '294247-01-10 04:00:53.775807'", "INTERVAL '1' second"))
                .matches("TIMESTAMP '294247-01-10 04:00:54.775807'");
        assertTrinoExceptionThrownBy(assertions.operator(ADD, "TIMESTAMP '294247-01-10 04:00:54.775807'", "INTERVAL '1' second")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
        assertTrinoExceptionThrownBy(assertions.operator(ADD, "INTERVAL '1' second", "TIMESTAMP '294247-01-10 04:00:54.775807000000'")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);

        // an interval too large to express in microseconds
        assertTrinoExceptionThrownBy(assertions.expression("a + b")
                .binding("a", "TIMESTAMP '2020-05-01 12:34:56'")
                .binding("b", "INTERVAL '1' SECOND * 9223372036854775")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
        assertTrinoExceptionThrownBy(assertions.expression("a - b")
                .binding("a", "TIMESTAMP '2020-05-01 12:34:56'")
                .binding("b", "INTERVAL '1' SECOND * 9223372036854775")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);

        // results inside the last millisecond above the bottom of the range still come back
        // (no literal parses there, so check them by shifting back)
        assertThat(assertions.expression("(a - b) + b")
                .binding("a", "TIMESTAMP '1970-01-01 00:00:00.000500'")
                .binding("b", "INTERVAL '0.001' SECOND * 9223372036854776"))
                .matches("TIMESTAMP '1970-01-01 00:00:00.000500'");
        assertThat(assertions.expression("(a - b) + b")
                .binding("a", "TIMESTAMP '1970-01-01 00:00:00.000500000001'")
                .binding("b", "INTERVAL '0.001' SECOND * 9223372036854776"))
                .matches("TIMESTAMP '1970-01-01 00:00:00.000500000001'");
        assertThat(assertions.expression("((a - b) + INTERVAL '1' month - INTERVAL '1' month) + b")
                .binding("a", "TIMESTAMP '1970-01-01 00:00:00.000500'")
                .binding("b", "INTERVAL '0.001' SECOND * 9223372036854776"))
                .matches("TIMESTAMP '1970-01-01 00:00:00.000500'");

        // a month or a second below a value near the bottom of the range
        String minTimestamp = "date_add('millisecond', -9223372036854775, TIMESTAMP '1970-01-01 00:00:00.000000')";
        assertTrinoExceptionThrownBy(assertions.operator(SUBTRACT, minTimestamp, "INTERVAL '1' month")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
        assertTrinoExceptionThrownBy(assertions.operator(SUBTRACT, minTimestamp, "INTERVAL '1' second")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
    }

    /**
     * timestamp - timestamp returns the right DAY TO SECOND interval when the
     * difference is representable, even across almost the whole range.
     */
    @Test
    public void test2TimestampMinusTimestampRepresentable()
    {
        assertThat(assertions.operator(SUBTRACT, "TIMESTAMP '294247-01-10 04:00:54.775807'", "TIMESTAMP '1970-01-01 00:00:00.000000'"))
                .matches("INTERVAL '106751991 04:00:54.776' DAY TO SECOND");
        assertThat(assertions.operator(SUBTRACT, "TIMESTAMP '1970-01-01 00:00:00.000000'", "TIMESTAMP '294247-01-10 04:00:54.775807'"))
                .matches("INTERVAL '-106751991 04:00:54.776' DAY TO SECOND");
        // precision 12 operands, same difference
        assertThat(assertions.operator(SUBTRACT, "TIMESTAMP '294247-01-10 04:00:54.775807000000'", "TIMESTAMP '1970-01-01 00:00:00.000000000000'"))
                .matches("INTERVAL '106751991 04:00:54.776' DAY TO SECOND");

        // the top of the range minus a value near the bottom: the difference in microseconds does not fit in a long
        String nearMin = "date_add('millisecond', -9223372036854775, TIMESTAMP '1970-01-01 00:00:00.000000')";
        assertThat(assertions.operator(SUBTRACT, "TIMESTAMP '294247-01-10 04:00:54.775807'", nearMin))
                .matches("INTERVAL '213503982 08:01:49.551' DAY TO SECOND");
        assertThat(assertions.operator(SUBTRACT, nearMin, "TIMESTAMP '294247-01-10 04:00:54.775807'"))
                .matches("INTERVAL '-213503982 08:01:49.551' DAY TO SECOND");
        String nearMinPrecision12 = "date_add('millisecond', -9223372036854775, TIMESTAMP '1970-01-01 00:00:00.000000000000')";
        assertThat(assertions.operator(SUBTRACT, "TIMESTAMP '294247-01-10 04:00:54.775807000000'", nearMinPrecision12))
                .matches("INTERVAL '213503982 08:01:49.551' DAY TO SECOND");
    }

    /**
     * timestamp - timestamp rounds the exact difference to the nearest
     * millisecond, an exact half rounding up (toward positive). At precision 7
     * and above the sub-microsecond digits take part in that rounding.
     */
    @Test
    public void test3PicosTiebreak()
    {
        // precision 6: a positive half rounds up to 1 ms, a negative half rounds up to 0 ms
        assertThat(assertions.operator(SUBTRACT, "TIMESTAMP '1970-01-01 00:00:00.000500'", "TIMESTAMP '1970-01-01 00:00:00.000000'"))
                .matches("INTERVAL '0 00:00:00.001' DAY TO SECOND");
        assertThat(assertions.operator(SUBTRACT, "TIMESTAMP '1970-01-01 00:00:00.000499'", "TIMESTAMP '1970-01-01 00:00:00.000000'"))
                .matches("INTERVAL '0 00:00:00.000' DAY TO SECOND");
        assertThat(assertions.operator(SUBTRACT, "TIMESTAMP '1970-01-01 00:00:00.000000'", "TIMESTAMP '1970-01-01 00:00:00.000500'"))
                .matches("INTERVAL '0 00:00:00.000' DAY TO SECOND");
        assertThat(assertions.operator(SUBTRACT, "TIMESTAMP '1970-01-01 00:00:00.000000'", "TIMESTAMP '1970-01-01 00:00:00.000501'"))
                .matches("INTERVAL '-0 00:00:00.001' DAY TO SECOND");

        // precision 12: one picosecond on either side of the half decides the result
        assertThat(assertions.operator(SUBTRACT, "TIMESTAMP '1970-01-01 00:00:00.000500000000'", "TIMESTAMP '1970-01-01 00:00:00.000000000000'"))
                .matches("INTERVAL '0 00:00:00.001' DAY TO SECOND");
        assertThat(assertions.operator(SUBTRACT, "TIMESTAMP '1970-01-01 00:00:00.000500000000'", "TIMESTAMP '1970-01-01 00:00:00.000000000001'"))
                .matches("INTERVAL '0 00:00:00.000' DAY TO SECOND");
        assertThat(assertions.operator(SUBTRACT, "TIMESTAMP '1970-01-01 00:00:00.000000000000'", "TIMESTAMP '1970-01-01 00:00:00.000500000000'"))
                .matches("INTERVAL '0 00:00:00.000' DAY TO SECOND");
        assertThat(assertions.operator(SUBTRACT, "TIMESTAMP '1970-01-01 00:00:00.000000000000'", "TIMESTAMP '1970-01-01 00:00:00.000500000001'"))
                .matches("INTERVAL '-0 00:00:00.001' DAY TO SECOND");
    }

    /**
     * timestamp with time zone +/- INTERVAL returns the value up to either end
     * of the range the type can store and fails with NUMERIC_VALUE_OUT_OF_RANGE
     * past it, at precision 3 and precision 7.
     */
    @Test
    public void test4TimestampTzIntervalOverflow()
    {
        // representable results that land exactly on the largest and smallest storable value
        assertThat(assertions.operator(ADD, "TIMESTAMP '73326-09-11 20:14:44.247 UTC'", "INTERVAL '1' second"))
                .matches("TIMESTAMP '73326-09-11 20:14:45.247 UTC'");
        assertThat(assertions.operator(ADD, "TIMESTAMP '73326-09-11 20:14:44.2470000 UTC'", "INTERVAL '1' second"))
                .matches("TIMESTAMP '73326-09-11 20:14:45.2470000 UTC'");
        assertThat(assertions.operator(SUBTRACT, "TIMESTAMP '-69387-04-22 03:45:15.752 UTC'", "INTERVAL '1' second"))
                .matches("TIMESTAMP '-69387-04-22 03:45:14.752 UTC'");
        assertThat(assertions.operator(SUBTRACT, "TIMESTAMP '-69387-04-22 03:45:15.7520000 UTC'", "INTERVAL '1' second"))
                .matches("TIMESTAMP '-69387-04-22 03:45:14.7520000 UTC'");

        // past the largest storable value
        assertTrinoExceptionThrownBy(assertions.operator(ADD, "TIMESTAMP '73326-09-11 20:14:45.247 UTC'", "INTERVAL '1' second")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
        assertTrinoExceptionThrownBy(assertions.operator(ADD, "TIMESTAMP '73326-09-11 20:14:45.2470000 UTC'", "INTERVAL '1' second")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
        assertTrinoExceptionThrownBy(assertions.operator(ADD, "TIMESTAMP '73326-09-11 20:14:45.247 UTC'", "INTERVAL '1' month")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
        assertTrinoExceptionThrownBy(assertions.operator(ADD, "TIMESTAMP '73326-09-11 20:14:45.2470000 UTC'", "INTERVAL '1' month")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
        assertTrinoExceptionThrownBy(assertions.operator(ADD, "INTERVAL '1' second", "TIMESTAMP '73326-09-11 20:14:45.2470000 UTC'")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
        assertTrinoExceptionThrownBy(assertions.operator(ADD, "INTERVAL '1' month", "TIMESTAMP '73326-09-11 20:14:45.2470000 UTC'")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
        assertTrinoExceptionThrownBy(assertions.operator(SUBTRACT, "TIMESTAMP '73326-09-11 20:14:45.247 UTC'", "INTERVAL '-1' second")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
        assertTrinoExceptionThrownBy(assertions.operator(SUBTRACT, "TIMESTAMP '73326-09-11 20:14:45.2470000 UTC'", "INTERVAL '-1' month")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);

        // below the smallest storable value
        assertTrinoExceptionThrownBy(assertions.operator(SUBTRACT, "TIMESTAMP '-69387-04-22 03:45:14.752 UTC'", "INTERVAL '1' second")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
        assertTrinoExceptionThrownBy(assertions.operator(SUBTRACT, "TIMESTAMP '-69387-04-22 03:45:14.7520000 UTC'", "INTERVAL '1' second")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
        assertTrinoExceptionThrownBy(assertions.operator(SUBTRACT, "TIMESTAMP '-69387-04-22 03:45:14.752 UTC'", "INTERVAL '1' month")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
        assertTrinoExceptionThrownBy(assertions.operator(SUBTRACT, "TIMESTAMP '-69387-04-22 03:45:14.7520000 UTC'", "INTERVAL '1' month")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
    }

    /**
     * getPreviousValue/getNextValue on timestamp with time zone step inside the
     * storable range and return empty at its ends, at precision 6 and 9.
     */
    @Test
    public void test5TimestampTzRangeEndpoints()
    {
        // precision 6: one step is 1_000_000 picoseconds
        Type typeMicros = createTimestampWithTimeZoneType(6);
        LongTimestampWithTimeZone minValue = LongTimestampWithTimeZone.fromEpochMillisAndFraction(MIN_TZ_EPOCH_MILLIS, 0, UTC_KEY);
        LongTimestampWithTimeZone nextToMinValue = LongTimestampWithTimeZone.fromEpochMillisAndFraction(MIN_TZ_EPOCH_MILLIS, 1_000_000, UTC_KEY);
        LongTimestampWithTimeZone previousToMaxValue = LongTimestampWithTimeZone.fromEpochMillisAndFraction(MAX_TZ_EPOCH_MILLIS, 998_000_000, UTC_KEY);
        LongTimestampWithTimeZone maxValue = LongTimestampWithTimeZone.fromEpochMillisAndFraction(MAX_TZ_EPOCH_MILLIS, 999_000_000, UTC_KEY);

        assertThat(typeMicros.getPreviousValue(minValue)).isEqualTo(Optional.empty());
        assertThat(typeMicros.getNextValue(maxValue)).isEqualTo(Optional.empty());
        assertThat(typeMicros.getPreviousValue(nextToMinValue)).isEqualTo(Optional.of(minValue));
        assertThat(typeMicros.getNextValue(previousToMaxValue)).isEqualTo(Optional.of(maxValue));

        // precision 9: one step is 1_000 picoseconds
        int step = 1_000;
        Type typeNanos = createTimestampWithTimeZoneType(9);
        assertThat(typeNanos.getPreviousValue(LongTimestampWithTimeZone.fromEpochMillisAndFraction(MIN_TZ_EPOCH_MILLIS, 0, UTC_KEY)))
                .isEqualTo(Optional.empty());
        assertThat(typeNanos.getNextValue(LongTimestampWithTimeZone.fromEpochMillisAndFraction(MAX_TZ_EPOCH_MILLIS, (int) (PICOSECONDS_PER_MILLISECOND - step), UTC_KEY)))
                .isEqualTo(Optional.empty());
        assertThat(typeNanos.getPreviousValue(LongTimestampWithTimeZone.fromEpochMillisAndFraction(MIN_TZ_EPOCH_MILLIS, step, UTC_KEY)))
                .isEqualTo(Optional.of(LongTimestampWithTimeZone.fromEpochMillisAndFraction(MIN_TZ_EPOCH_MILLIS, 0, UTC_KEY)));
        assertThat(typeNanos.getNextValue(LongTimestampWithTimeZone.fromEpochMillisAndFraction(MAX_TZ_EPOCH_MILLIS, (int) (PICOSECONDS_PER_MILLISECOND - 2 * step), UTC_KEY)))
                .isEqualTo(Optional.of(LongTimestampWithTimeZone.fromEpochMillisAndFraction(MAX_TZ_EPOCH_MILLIS, (int) (PICOSECONDS_PER_MILLISECOND - step), UTC_KEY)));
    }

    /**
     * In-range timestamp arithmetic keeps returning the same results.
     */
    @Test
    public void test6InRangeRegression()
    {
        // ordinary date_add
        assertThat(assertions.expression("date_add('millisecond', 1, TIMESTAMP '2020-05-10 12:34:56.111')"))
                .matches("TIMESTAMP '2020-05-10 12:34:56.112'");
        assertThat(assertions.expression("date_add('day', 1, TIMESTAMP '2020-05-10 12:34:56')"))
                .matches("TIMESTAMP '2020-05-11 12:34:56'");
        assertThat(assertions.expression("date_add('month', 1, TIMESTAMP '2020-05-10 12:34:56')"))
                .matches("TIMESTAMP '2020-06-10 12:34:56'");

        // ordinary interval add / subtract
        assertThat(assertions.operator(ADD, "INTERVAL '3' year", "TIMESTAMP '2001-1-22 03:04:05.321'"))
                .matches("TIMESTAMP '2004-01-22 03:04:05.321'");
        assertThat(assertions.operator(SUBTRACT, "TIMESTAMP '2001-1-22 03:04:05.321'", "INTERVAL '3' month"))
                .matches("TIMESTAMP '2000-10-22 03:04:05.321'");

        // ordinary timestamp - timestamp, precision 3 and precision 12
        assertThat(assertions.operator(SUBTRACT, "TIMESTAMP '2016-03-29 03:04:05.321'", "TIMESTAMP '2017-03-30 14:15:16.432'"))
                .matches("INTERVAL '-366 11:11:11.111' DAY TO SECOND");
        assertThat(assertions.operator(SUBTRACT, "TIMESTAMP '2017-03-30 14:15:16.432987654321'", "TIMESTAMP '2016-03-29 03:04:05.321000000000'"))
                .matches("INTERVAL '366 11:11:11.112' DAY TO SECOND");

        // ordinary timestamp with time zone interval arithmetic, precision 3 and precision 7
        assertThat(assertions.operator(ADD, "INTERVAL '3' month", "TIMESTAMP '2001-1-22 03:04:05.321 +05:09'"))
                .matches("TIMESTAMP '2001-04-22 03:04:05.321 +05:09'");
        assertThat(assertions.operator(ADD, "TIMESTAMP '2001-1-22 03:04:05.3210000 +05:09'", "INTERVAL '1' day"))
                .matches("TIMESTAMP '2001-01-23 03:04:05.3210000 +05:09'");
    }

    /**
     * LongTimestampWithTimeZone refuses epoch millis or seconds that the type
     * cannot store, and still builds the values at the very ends of the range.
     */
    @Test
    public void test7TimestampTzConstructionRange()
    {
        assertThatCode(() -> LongTimestampWithTimeZone.fromEpochMillisAndFraction(MAX_TZ_EPOCH_MILLIS, 999_999_999, UTC_KEY))
                .doesNotThrowAnyException();
        assertThatCode(() -> LongTimestampWithTimeZone.fromEpochMillisAndFraction(MIN_TZ_EPOCH_MILLIS, 0, UTC_KEY))
                .doesNotThrowAnyException();
        assertThat(LongTimestampWithTimeZone.fromEpochSecondsAndFraction(MAX_TZ_EPOCH_MILLIS / 1000, 247_000_000_000L, UTC_KEY))
                .isEqualTo(LongTimestampWithTimeZone.fromEpochMillisAndFraction(MAX_TZ_EPOCH_MILLIS, 0, UTC_KEY));

        assertThatThrownBy(() -> LongTimestampWithTimeZone.fromEpochMillisAndFraction(MAX_TZ_EPOCH_MILLIS + 1, 0, UTC_KEY))
                .isInstanceOf(RuntimeException.class);
        assertThatThrownBy(() -> LongTimestampWithTimeZone.fromEpochMillisAndFraction(MIN_TZ_EPOCH_MILLIS - 1, 0, UTC_KEY))
                .isInstanceOf(RuntimeException.class);
        assertThatThrownBy(() -> LongTimestampWithTimeZone.fromEpochSecondsAndFraction(MAX_TZ_EPOCH_MILLIS / 1000 + 1, 0, UTC_KEY))
                .isInstanceOf(RuntimeException.class);
        // 2^61 seconds is 2^64 * 125 milliseconds: the millis wrap around to exactly 0
        assertThatThrownBy(() -> LongTimestampWithTimeZone.fromEpochSecondsAndFraction(1L << 61, 0, UTC_KEY))
                .isInstanceOf(RuntimeException.class);
    }

    /**
     * An amount date_add cannot apply at all fails with a numeric-range or an
     * invalid-argument error, never a generic one.
     */
    @Test
    public void test8DateAddAmountTooLarge()
    {
        assertTrinoExceptionThrownBy(assertions.expression("date_add('month', 9223372036854775807, TIMESTAMP '2020-05-10 12:34:56')")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE, INVALID_FUNCTION_ARGUMENT);
        assertTrinoExceptionThrownBy(assertions.expression("date_add('month', 9223372036854775807, TIMESTAMP '2020-05-10 12:34:56.000000000000')")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE, INVALID_FUNCTION_ARGUMENT);
        String years = Long.toString(30L * 24 * 60 * 60 * 1000);
        assertTrinoExceptionThrownBy(assertions.expression("date_add('year', " + years + ", TIMESTAMP '0001-01-01 00:00:00')")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE, INVALID_FUNCTION_ARGUMENT);
    }
}
