"""Behavioral verifier for timestamp arithmetic at the ends of the range.

The behavior is observable through Trino's SQL scalar/operator layer and the
public timestamp-with-time-zone SPI. There is no native Java/JUnit runner here,
so this Python wrapper injects a JUnit 5 test class
(``VerifyTimestampOverflow.java``, shipped alongside this file) into
trino-main's test source tree, runs it through the repo's own Maven/surefire
config, and maps each ``@Test`` method's result onto one pytest test.

The repo's stock timestamp tests are not used; this file checks the cases
directly.

The build runs in two Maven steps instead of one reactor spanning both
modules, because source changes may live in trino-spi as well as trino-main
and trino-main must compile against the current trino-spi rather than the
installed jar. A single ``-pl core/trino-spi,core/trino-main test`` reactor
cannot do this: the parent POM hardcodes ``failIfNoTests`` so the ``-Dtest=``
filter matching nothing in trino-spi bans the whole reactor ("No tests were
executed!") before trino-main ever runs. Instead we (1) ``install`` trino-spi
with ``-DskipTests`` so its fresh jar is in the local repo, then (2) run the
injected test in trino-main, which now compiles and links against that jar.

This file imports no repository Python (there is none); it uses only the
standard library plus a ``mvn`` subprocess, so it runs correctly under the
shared verifier interpreter with no ``[pytest] command`` override.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# Layout / configuration
# ---------------------------------------------------------------------------

REPO_NAME = os.environ.get("REPO_NAME", "trino")
REPO_DIR = Path(f"/repo/{REPO_NAME}")
if not REPO_DIR.is_dir():
    REPO_DIR = Path("/repo/trino")

# The JUnit test class ships next to this file and is copied into trino-main's
# test tree under a fresh package that cannot collide with existing tests.
JAVA_SRC = Path(__file__).resolve().parent / "VerifyTimestampOverflow.java"
TEST_FQN = "io.trino.verify.VerifyTimestampOverflow"
TEST_PKG_DIR = Path("core/trino-main/src/test/java/io/trino/verify")
TEST_CLASS_FILE = TEST_PKG_DIR / "VerifyTimestampOverflow.java"
SUREFIRE_REPORT = Path(
    "core/trino-main/target/surefire-reports/TEST-io.trino.verify.VerifyTimestampOverflow.xml"
)

LOGS_DIR = Path("/logs/verifier")
MVN_LOG = LOGS_DIR / "verify_mvn.log"

# Leave headroom under task.toml [verifier] timeout_sec = 2400 and the pytest
# timeout in verify.toml (2300). The runner kills at pytest-timeout + 30.
MVN_TIMEOUT_SEC = 2100

# (JUnit method name, description). The method names match @Test methods in
# VerifyTimestampOverflow.java exactly.
METHODS = [
    ("test0DateAddOverflow", "date_add out of range fails with NUMERIC_VALUE_OUT_OF_RANGE, representable returns the value"),
    ("test1IntervalAddOverflow", "timestamp +/- INTERVAL out of range fails, representable returns the value"),
    ("test2TimestampMinusTimestampRepresentable", "timestamp - timestamp representable difference is correct"),
    ("test3PicosTiebreak", "timestamp - timestamp rounds the exact difference, sub-microsecond digits included"),
    ("test4TimestampTzIntervalOverflow", "timestamp with time zone +/- INTERVAL fails past either end, returns the value up to it"),
    ("test5TimestampTzRangeEndpoints", "timestamp with time zone previous/next value stays inside the storable range"),
    ("test6InRangeRegression", "in-range arithmetic unchanged"),
    ("test7TimestampTzConstructionRange", "LongTimestampWithTimeZone refuses millis or seconds outside the storable range"),
    ("test8DateAddAmountTooLarge", "date_add amount far past the range fails with NUMERIC_VALUE_OUT_OF_RANGE"),
]


# ---------------------------------------------------------------------------
# One Maven run, shared across every test
# ---------------------------------------------------------------------------


def _run_maven_once() -> dict[str, tuple[bool, str]]:
    """Inject the JUnit test, run it offline through the repo's surefire, and
    return ``{method_name: (passed, detail)}``.

    On any failure to produce a surefire report (compile error in the source
    tree, Maven failure, timeout) every test is reported as failed with the
    Maven tail as detail, never silently skipped.
    """
    LOGS_DIR.mkdir(parents=True, exist_ok=True)
    abs_pkg_dir = REPO_DIR / TEST_PKG_DIR
    abs_class_file = REPO_DIR / TEST_CLASS_FILE
    abs_report = REPO_DIR / SUREFIRE_REPORT

    def _all_failed(detail: str) -> dict[str, tuple[bool, str]]:
        return {name: (False, detail[:200]) for name, _ in METHODS}

    if not JAVA_SRC.is_file():
        return _all_failed(f"missing injected test source: {JAVA_SRC}")

    try:
        # Fresh package dir; remove any stale report for a clean parse.
        abs_pkg_dir.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(JAVA_SRC, abs_class_file)
        if abs_report.exists():
            abs_report.unlink()

        # Step 1: install the current SPI module so trino-main
        # compiles against the fresh jar. -DskipTests avoids the empty-module
        # surefire trap; the install itself fails loudly on a broken SPI patch.
        install_cmd = [
            "mvn", "-o", "-B",
            "-pl", "core/trino-spi",
            "install",
            "-DskipTests",
            "-Dair.check.skip-all=true",
        ]
        # Step 2: run the injected test in trino-main only.
        test_cmd = [
            "mvn", "-o", "-B",
            "-pl", "core/trino-main",
            "test",
            f"-Dtest={TEST_FQN}",
            "-DfailIfNoTests=false",
            "-Dair.check.skip-all=true",
        ]

        import time

        deadline = time.monotonic() + MVN_TIMEOUT_SEC
        log_parts: list[str] = []

        def _run(cmd: list[str], label: str) -> subprocess.CompletedProcess | None:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return None
            proc = subprocess.run(
                cmd,
                cwd=str(REPO_DIR),
                capture_output=True,
                text=True,
                timeout=remaining,
                check=False,
            )
            combined = (proc.stdout or "") + "\n" + (proc.stderr or "")
            log_parts.append(f"===== {label}: {' '.join(cmd)} =====\n{combined}")
            return proc

        try:
            install_proc = _run(install_cmd, "install trino-spi")
            if install_proc is None:
                MVN_LOG.write_text("\n".join(log_parts))
                return _all_failed(f"mvn install timed out after {MVN_TIMEOUT_SEC}s")
            if install_proc.returncode != 0:
                MVN_LOG.write_text("\n".join(log_parts))
                tail = "\n".join("\n".join(log_parts).splitlines()[-40:])
                return _all_failed(
                    f"trino-spi install failed (exit {install_proc.returncode}); tail:\n{tail}"
                )

            test_proc = _run(test_cmd, "test trino-main")
            if test_proc is None:
                MVN_LOG.write_text("\n".join(log_parts))
                return _all_failed(f"mvn test timed out after {MVN_TIMEOUT_SEC}s")
        except subprocess.TimeoutExpired:
            MVN_LOG.write_text("\n".join(log_parts))
            return _all_failed(f"mvn timed out after {MVN_TIMEOUT_SEC}s")

        combined_all = "\n".join(log_parts)
        MVN_LOG.write_text(combined_all)
        mvn_tail = "\n".join(combined_all.splitlines()[-40:])

        if not abs_report.exists():
            return _all_failed(
                f"no surefire report (mvn exit {test_proc.returncode}); tail:\n{mvn_tail}"
            )

        return _parse_report(abs_report, mvn_tail)
    finally:
        # Always remove the injected test so the repo is left untouched.
        shutil.rmtree(abs_pkg_dir, ignore_errors=True)


def _parse_report(report_path: Path, mvn_tail: str) -> dict[str, tuple[bool, str]]:
    """Parse the surefire XML into ``{method_name: (passed, detail)}``."""
    results: dict[str, tuple[bool, str]] = {}
    try:
        root = ET.parse(str(report_path)).getroot()  # noqa: S314
    except ET.ParseError as exc:
        return {name: (False, f"unparseable surefire report: {exc}") for name, _ in METHODS}

    for tc in root.findall("testcase"):
        name = tc.get("name", "")
        failure = tc.find("failure")
        error = tc.find("error")
        skipped = tc.find("skipped")
        if failure is not None:
            detail = (failure.get("message") or failure.text or "assertion failed") or ""
            results[name] = (False, detail[:200])
        elif error is not None:
            detail = (error.get("message") or error.text or "errored") or ""
            results[name] = (False, detail[:200])
        elif skipped is not None:
            results[name] = (False, "test was skipped")
        else:
            results[name] = (True, "")

    # Any expected method absent from the report counts as failed.
    for name, _ in METHODS:
        if name not in results:
            results[name] = (False, f"method not found in surefire report; mvn tail:\n{mvn_tail}"[:200])
    return results


@pytest.fixture(scope="module")
def maven_results() -> dict[str, tuple[bool, str]]:
    return _run_maven_once()


# ---------------------------------------------------------------------------
# One pytest test per JUnit method; every one must pass
# ---------------------------------------------------------------------------


def _check(maven_results: dict[str, tuple[bool, str]], method: str) -> None:
    passed, detail = maven_results.get(method, (False, "no result"))
    assert passed, f"{method} failed: {detail}"


def test_0_date_add_overflow(maven_results):
    """date_add on a timestamp returns the shifted value when it is
    representable and fails with NUMERIC_VALUE_OUT_OF_RANGE when it is not, at
    every precision."""
    _check(maven_results, "test0DateAddOverflow")


def test_1_interval_add_overflow(maven_results):
    """timestamp +/- INTERVAL (DAY TO SECOND and YEAR TO MONTH, precision 6 and
    12) returns the value when it is representable and fails with
    NUMERIC_VALUE_OUT_OF_RANGE when it is not."""
    _check(maven_results, "test1IntervalAddOverflow")


def test_2_timestamp_minus_timestamp_representable(maven_results):
    """timestamp - timestamp returns the right DAY TO SECOND interval whenever
    that interval is representable."""
    _check(maven_results, "test2TimestampMinusTimestampRepresentable")


def test_3_picos_tiebreak(maven_results):
    """timestamp - timestamp rounds the exact difference to the millisecond,
    sub-microsecond digits included."""
    _check(maven_results, "test3PicosTiebreak")


def test_4_timestamp_tz_interval_overflow(maven_results):
    """timestamp with time zone +/- INTERVAL returns the value up to either end
    of the storable range and fails with NUMERIC_VALUE_OUT_OF_RANGE past it."""
    _check(maven_results, "test4TimestampTzIntervalOverflow")


def test_5_timestamp_tz_range_endpoints(maven_results):
    """getPreviousValue/getNextValue on timestamp with time zone stay inside
    the storable range and return empty at its ends."""
    _check(maven_results, "test5TimestampTzRangeEndpoints")


def test_6_in_range_regression(maven_results):
    """In-range timestamp arithmetic keeps returning the same results."""
    _check(maven_results, "test6InRangeRegression")


def test_7_timestamp_tz_construction_range(maven_results):
    """LongTimestampWithTimeZone refuses epoch millis or seconds outside the
    storable range and still builds the values at its ends."""
    _check(maven_results, "test7TimestampTzConstructionRange")


def test_8_date_add_amount_too_large(maven_results):
    """A date_add amount far past the range fails with
    NUMERIC_VALUE_OUT_OF_RANGE."""
    _check(maven_results, "test8DateAddAmountTooLarge")
