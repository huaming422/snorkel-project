## Task

`bd` stores workspace settings in the git-tracked `.beads/config.yaml`. Operators have found that dotted settings such as `sync.remote` and `dolt.host` sometimes do not stick, especially in a new workspace whose config file is empty or contains only comments.

After `bd` records one of these values, a read of the same key returns nothing and commands behave as though it was never configured. Once the file reaches this state, later reads stay wrong. An unset can also report success while the old value remains active, leaving a sync remote in use after an operator removes it.

Repair the config read, write, and unset behavior so these settings remain consistent through repeated changes. Keep unrelated parts of the tracked file intact; other tools may share it.
