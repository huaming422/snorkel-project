# Structural check over the concrete scenario sources.
#
# This file imports NO repository package code. It parses the scenario source
# tree with the standard-library parser and inspects call expressions only.
# It runs under the shared grading interpreter (no repo venv needed) because it
# touches nothing but the standard library and the source files on disk.
#
# What it checks: the concrete scenario sources must assemble their work from a
# resolved, filtered selection rather than pulling example rows straight out of
# the shared store. The store exposes a small, long-standing set of row-reading
# methods; a concrete scenario calling any of them directly is bypassing the
# resolved selection. We assert there are no such direct calls anywhere under
# the concrete-scenario package.
#
# This is phrased entirely over names that already exist in the pre-change
# codebase (long-standing store methods) and over the pre-existing source
# layout. It asserts the ABSENCE of those direct calls; it does not reference,
# import, or depend on any name introduced by a solution.

import ast
from pathlib import Path

# Long-standing row-reading methods on the shared store. A concrete scenario
# that calls any of these directly is reading rows itself instead of building
# from the resolved selection. These are pre-existing names; we forbid their
# use as direct call targets in the concrete-scenario tree.
_DIRECT_ROW_READ_METHODS = frozenset(
    {
        "get_seeds",
        "get_seeds_async",
        "get_seed_groups",
        "get_seed_groups_async",
    }
)

# Pre-existing source location of the concrete scenarios, relative to the repo
# root (the verifier runs with the repo root as its working directory). This is
# the repo-owned package layout, not anything a solution introduces.
_CONCRETE_SCENARIOS_DIR = Path("pyrit/scenario/scenarios")


def _offending_calls(source: str) -> list[tuple[int, str]]:
    """Return (lineno, method) for each direct call to a forbidden row-read method.

    Only attribute-style calls are flagged (``something.get_seeds_async(...)``),
    which is exactly how rows are read from the shared store instance. Method
    *definitions* and bare attribute references that are never called are not
    flagged.
    """
    tree = ast.parse(source)
    hits: list[tuple[int, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        func = node.func
        if isinstance(func, ast.Attribute) and func.attr in _DIRECT_ROW_READ_METHODS:
            hits.append((node.lineno, func.attr))
    return hits


def test_concrete_scenarios_do_not_read_rows_directly() -> None:
    scenarios_dir = _CONCRETE_SCENARIOS_DIR
    assert scenarios_dir.is_dir(), (
        f"expected concrete-scenario source tree at {scenarios_dir.resolve()} "
        "(run from the repository root)"
    )

    source_files = sorted(scenarios_dir.rglob("*.py"))
    assert source_files, f"no scenario source files found under {scenarios_dir.resolve()}"

    offenders: dict[str, list[tuple[int, str]]] = {}
    for path in source_files:
        hits = _offending_calls(path.read_text(encoding="utf-8"))
        if hits:
            offenders[str(path)] = hits

    assert not offenders, (
        "concrete scenarios must build their work from the resolved, filtered "
        "selection, not by reading rows directly from the shared store; found "
        "direct row-read calls:\n"
        + "\n".join(
            f"  {path}:{lineno} -> .{method}()"
            for path, hits in sorted(offenders.items())
            for lineno, method in hits
        )
    )
