#!/usr/bin/env bash
# Container setup for verifiers. This file is `source`d (not executed as a
# subprocess) so the exported PATH/VIRTUAL_ENV persist into the verifier
# process. The image bakes the full dependency closure at the base commit into
# /opt/venv (uv sync --frozen --all-extras --group dev), so on a normal trial
# this is offline-first: the sync is a fast no-op with no downloads. The
# verifier phase runs with network, so an online fallback is logged, not fatal.
set -u

REPO=/repo/pyrit
cd "$REPO" || { echo "test-setup: $REPO missing" >&2; return 1 2>/dev/null || exit 1; }

export PATH="/usr/local/bin:$PATH"                 # uv
export VIRTUAL_ENV=/opt/venv
export UV_PROJECT_ENVIRONMENT=/opt/venv
export PATH="/opt/venv/bin:$PATH"

# Keep the HarmBench seed cache the image pre-warmed under dbdata/ reachable so
# any dataset resolution reads from disk, not the network.
export DB_DATA_PATH="${DB_DATA_PATH:-$REPO/dbdata}"

# Offline-first: the baked venv already satisfies the lockfile at the base commit,
# so this re-link of the editable project after the agent's edits needs no network.
# --frozen pins to uv.lock; --offline forbids any fetch (the closure is baked).
uv sync --frozen --all-extras --group dev --offline 2>&1 | tail -3 \
    || echo "test-setup: WARNING dependency re-link failed" >&2

# Sanity: the public models and scenario surface must import cleanly before any
# verifier runs.
python -c "import pyrit.models; import pyrit.scenario.core.scenario; import pyrit.backend.main; import pyrit.cli._cli_args" \
    && echo "test-setup: pyrit importable" \
    || echo "test-setup: WARNING pyrit import failed" >&2
