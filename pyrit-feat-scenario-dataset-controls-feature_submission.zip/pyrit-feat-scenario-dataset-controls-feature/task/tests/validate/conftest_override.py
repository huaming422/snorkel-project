"""Validation conftest override for the scenario dataset-controls task.

The pytest validation driver auto-loads this file as a pytest plugin (see
``src/python/ssb_lib/drivers/pytest_driver.py``), so everything defined here is
visible to the per-story test files the driver runs. The driver does NOT enable
pytest-asyncio's auto mode for the generated tests, so the fixtures below are
SYNCHRONOUS and run any async work internally through a fresh event loop
(``run_async`` helper). Each test case calls a fixture and asserts on the
returned plain-data dict.

WHAT THIS HARNESS OWNS (and only this):
  - A clean, in-memory framework store for each test, stood up through the
    framework's own PUBLIC initializer. This is a pure test fixture — a
    harness-owned concern — so the harness may encode it. It imports only
    long-standing, pre-change public symbols:
      * ``initialize_pyrit_async`` + the in-memory selector constant, the
        framework's documented way to bring up an isolated in-memory store,
      * ``CentralMemory``, the long-standing accessor for the active store.
  - A tiny ``run_async`` helper so synchronous driver tests can drive the
    framework's async API.
  - A ``seed_store`` helper to pre-populate example rows via the long-standing
    public store method, for the "reuse already-present data" case.

WHAT THIS HARNESS DELIBERATELY DOES NOT OWN:
  - It constructs NO request/options/settings objects and names NO
    selection-mode / fetch-policy tokens, capability-field names, override
    argument keys, estimate field names, or REST routes. Those shapes are
    defined by the submitted implementation; the validation agent constructs
    and reads them in each story's generated test by mirroring the submitted
    patch. The harness only provides an isolated store and a way to run async
    code, both through pre-existing public interfaces — so any correct
    implementation passes regardless of its internal layout, class names, or
    field choices.
"""

from __future__ import annotations

import asyncio
import warnings
from typing import Any, Awaitable, Callable

import pytest

# Pre-existing, implementation-agnostic public entrypoints only.
# - initialize_pyrit_async / IN_MEMORY: the framework's documented way to bring
#   up an isolated in-memory store (pyrit/setup/initialization.py, present long
#   before this change).
# - CentralMemory: the long-standing accessor for the active store.
from pyrit.setup.initialization import IN_MEMORY, initialize_pyrit_async
from pyrit.memory import CentralMemory


def _run(coro: Awaitable[Any]) -> Any:
    """Run an awaitable to completion on a fresh event loop.

    A fresh loop per call keeps each synchronous driver test independent and
    avoids cross-test loop reuse issues with the async store engine.
    """
    loop = asyncio.new_event_loop()
    try:
        asyncio.set_event_loop(loop)
        return loop.run_until_complete(coro)
    finally:
        asyncio.set_event_loop(None)
        loop.close()


@pytest.fixture
def run_async() -> Callable[[Awaitable[Any]], Any]:
    """Return a callable that runs an awaitable to completion.

    Usage in a generated test:
        result = run_async(scenario.get_run_size_estimate_async())
    """
    return _run


@pytest.fixture
def fresh_memory() -> Callable[[], Any]:
    """Return a callable that stands up a clean in-memory store and returns it.

    Each call brings up a brand-new isolated in-memory store through the
    framework's own public initializer (no default endpoints/targets are loaded,
    so the bring-up is fully offline) and returns the active store instance. Call
    it once at the start of a test before constructing or driving any scenario.
    """

    def _bring_up() -> Any:
        # Bring up the framework's in-memory store through its own public
        # initializer (no default endpoints/targets, so this is fully offline).
        # The store is a process-level singleton, so repeated calls return the
        # same instance; each test keeps its reads and writes isolated by using a
        # distinct dataset name (every store query here is name-scoped), which
        # needs no teardown and keeps bring-up fast.
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            _run(initialize_pyrit_async(IN_MEMORY, load_defaults=False, silent=True))
        return CentralMemory.get_memory_instance()

    return _bring_up


@pytest.fixture
def seed_store(run_async) -> Callable[..., int]:
    """Return a callable that writes example rows into the active store.

    ``seed_store(dataset_name, values)`` stores one example row per string in
    ``values`` under ``dataset_name`` using the long-standing public store
    method, and returns the number of rows written. Use it to pre-populate
    already-present (including hand-edited) data.
    """

    def _seed(dataset_name: str, values: list[str]) -> int:
        from pyrit.models import SeedObjective

        memory = CentralMemory.get_memory_instance()
        seeds = [SeedObjective(value=v, dataset_name=dataset_name) for v in values]
        run_async(memory.add_seeds_to_memory_async(seeds=seeds, added_by="validation"))
        return len(seeds)

    return _seed
