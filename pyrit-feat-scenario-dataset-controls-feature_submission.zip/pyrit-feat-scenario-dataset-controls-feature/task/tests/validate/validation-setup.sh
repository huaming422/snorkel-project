#!/usr/bin/env bash
# validation-setup.sh — runs once before the validation agent starts.
#
# The task image bakes the full dependency closure at the base commit into the
# project venv at /opt/venv (uv sync --frozen --all-extras --group dev). This
# script re-links the editable project after the agent's edits so the submitted
# source is what the stories import, then smoke-imports the pre-existing public
# symbols the stories and the harness rely on. The validate phase has network,
# so the sync is offline-first (a fast no-op on a normal trial) with a logged
# online fallback.

set -euo pipefail

REPO=/repo/pyrit
cd "$REPO"

export PATH="/usr/local/bin:$PATH"          # uv
export VIRTUAL_ENV=/opt/venv
export UV_PROJECT_ENVIRONMENT=/opt/venv
export PATH="/opt/venv/bin:$PATH"

# Keep the pre-warmed seed cache reachable so any dataset resolution reads from
# disk rather than the network.
export DB_DATA_PATH="${DB_DATA_PATH:-$REPO/dbdata}"

# Re-link the editable project against the submitted source. --frozen pins to
# the committed lockfile; --offline is tried first (the closure is baked), with
# a logged online fallback because the validate phase has network.
if ! uv sync --frozen --all-extras --group dev --offline > /tmp/validate-sync.log 2>&1; then
    echo "validation-setup: offline re-link failed; retrying online" >&2
    uv sync --frozen --all-extras --group dev > /tmp/validate-sync.log 2>&1 \
        || { tail -50 /tmp/validate-sync.log >&2; exit 1; }
fi

# Loud smoke guard: fail fast if the environment cannot import the pre-existing
# public surface the stories and harness drive. These are all long-standing
# symbols present before this change — the in-memory store initializer, the
# store accessor, the scenario base and configuration types, the concrete
# scenarios the capability stories use, the REST app + test client, and both
# CLI parse entrypoints. No implementation-introduced name is imported here.
python - <<'PY'
from pyrit.setup.initialization import IN_MEMORY, initialize_pyrit_async
from pyrit.memory import CentralMemory
from pyrit.models import SeedObjective
from pyrit.scenario import DatasetAttackConfiguration, DatasetSource, Scenario
from pyrit.scenario.scenarios.garak.figstep import FigStep
from pyrit.scenario.scenarios.garak.api_key import ApiKey
from pyrit.scenario.scenarios.garak.encoding import Encoding
from pyrit.scenario.scenarios.garak.exploitation import Exploitation
from pyrit.scenario.scenarios.garak.package_hallucination import PackageHallucination
from pyrit.backend.main import app
from fastapi.testclient import TestClient
from pyrit.cli.pyrit_scan import parse_args, _build_run_request
from pyrit.cli._cli_args import parse_run_arguments
print("validation-setup: pyrit public surface importable")
PY
