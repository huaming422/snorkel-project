#!/usr/bin/env bash
#
# Sourced (not exec'd, so exported env sticks) before the Go verifier runs.
# The image already baked the complete module+build cache at the base commit
# (Dockerfile block 7: `go mod download` + `go build ./...` + `go test -run '^$'`
# offline-ready), so there is NOTHING to install here. This script only
# re-asserts the offline Go switches and the toolchain PATH so a freshly-spawned
# shell that didn't inherit the image ENV, or one whose environment was changed,
# still runs the tests offline and fails fast on a cache miss instead of
# reaching the network.

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/beads}"
cd "$REPO_DIR"

# Offline switches: -mod=mod lets `go test` resolve from the warm module cache
# without rewriting go.mod/go.sum; GOPROXY=off turns any cache miss into an
# immediate error instead of a network fetch (the tests run without network).
export GOFLAGS=-mod=mod
export GOPROXY=off

# The verifier compiles CGO-linked packages (embedded Dolt); the image exports
# CGO_ENABLED=1 — repeat it defensively for a scrubbed shell.
export CGO_ENABLED=1

# Make `go` resolvable even when the harness scrubs PATH.
case ":$PATH:" in
    *":/usr/local/go/bin:"*) ;;
    *) export PATH=/usr/local/go/bin:/root/go/bin:$PATH ;;
esac

echo "test-setup.sh: ready (GOFLAGS=$GOFLAGS, GOPROXY=$GOPROXY, CGO_ENABLED=$CGO_ENABLED)"
