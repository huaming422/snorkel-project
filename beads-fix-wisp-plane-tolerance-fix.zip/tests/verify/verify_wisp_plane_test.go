//go:build cgo

package embeddeddolt_test

import (
	"fmt"
	"sort"
	"strings"
	"testing"

	"github.com/steveyegge/beads/internal/storage/domain/db"
	"github.com/steveyegge/beads/internal/storage/embeddeddolt"
	"github.com/steveyegge/beads/internal/types"
)

// These tests run the real embedded store. Each one seeds a durable issue and
// an ephemeral wisp, both labelled and commented, then renames one table away
// to stand in for a drifted or partially migrated clone, and asks the store
// for its totals the way bd count, bd ready and bd search --counts do.

const vfLabel = "hot"

type vfStore struct {
	te *testEnv
	t  *testing.T
}

func vfOpen(t *testing.T, prefix, renamed string) *vfStore {
	t.Helper()
	te := newTestEnv(t, prefix)
	ctx := t.Context()
	for _, is := range []*types.Issue{
		{ID: prefix + "-issue", Title: "durable bead", Status: types.StatusOpen, Priority: 2, IssueType: types.TypeTask},
		{ID: prefix + "-wisp", Title: "ephemeral bead", Status: types.StatusOpen, Priority: 2, IssueType: types.TypeTask, Ephemeral: true},
	} {
		if err := te.store.CreateIssue(ctx, is, "tester"); err != nil {
			t.Fatalf("CreateIssue %s: %v", is.ID, err)
		}
		if err := te.store.AddLabel(ctx, is.ID, vfLabel, "tester"); err != nil {
			t.Fatalf("AddLabel %s: %v", is.ID, err)
		}
		if err := te.store.AddComment(ctx, is.ID, "tester", "note"); err != nil {
			t.Fatalf("AddComment %s: %v", is.ID, err)
		}
	}
	if renamed != "" {
		te.exec(t, ctx, "RENAME TABLE "+renamed+" TO "+renamed+"_renamed_away")
	}
	return &vfStore{te: te, t: t}
}

func vfIDs[T any](items []T, id func(T) string) string {
	out := make([]string, 0, len(items))
	for _, it := range items {
		out = append(out, id(it))
	}
	sort.Strings(out)
	return strings.Join(out, ",")
}

func vfCountsIDs(items []*types.IssueWithCounts) string {
	return vfIDs(items, func(i *types.IssueWithCounts) string { return i.ID })
}

func vfIssueIDs(items []*types.Issue) string {
	return vfIDs(items, func(i *types.Issue) string { return i.ID })
}

// vfRead is one way of asking the store for a total or a counted page. answer
// renders what came back so a mismatch shows the number the caller would see.
type vfRead struct {
	name   string
	answer func(s *vfStore) (string, error)
}

func vfEphemeral() *bool { b := true; return &b }

var (
	vfCount = vfRead{"count", func(s *vfStore) (string, error) {
		n, err := s.te.store.CountIssues(s.t.Context(), "", types.IssueFilter{})
		return fmt.Sprint(n), err
	}}
	vfCountLabel = vfRead{"count with label", func(s *vfStore) (string, error) {
		n, err := s.te.store.CountIssues(s.t.Context(), "", types.IssueFilter{Labels: []string{vfLabel}})
		return fmt.Sprint(n), err
	}}
	vfCountEphemeralLabel = vfRead{"count ephemeral with label", func(s *vfStore) (string, error) {
		n, err := s.te.store.CountIssues(s.t.Context(), "", types.IssueFilter{Ephemeral: vfEphemeral(), Labels: []string{vfLabel}})
		return fmt.Sprint(n), err
	}}
	vfByStatus = vfRead{"count by status", func(s *vfStore) (string, error) {
		m, err := s.te.store.CountIssuesByGroup(s.t.Context(), types.IssueFilter{}, "status")
		return fmt.Sprint(m), err
	}}
	vfByLabel = vfRead{"count by label", func(s *vfStore) (string, error) {
		m, err := s.te.store.CountIssuesByGroup(s.t.Context(), types.IssueFilter{}, "label")
		return fmt.Sprint(m), err
	}}
	vfByLabelEphemeral = vfRead{"count ephemeral by label", func(s *vfStore) (string, error) {
		m, err := s.te.store.CountIssuesByGroup(s.t.Context(), types.IssueFilter{Ephemeral: vfEphemeral()}, "label")
		return fmt.Sprint(m), err
	}}
	vfCountAnyLabel = vfRead{"count with any label", func(s *vfStore) (string, error) {
		n, err := s.te.store.CountIssues(s.t.Context(), "", types.IssueFilter{LabelsAny: []string{vfLabel, "cold"}})
		return fmt.Sprint(n), err
	}}
	vfCountLabelPattern = vfRead{"count with label pattern", func(s *vfStore) (string, error) {
		n, err := s.te.store.CountIssues(s.t.Context(), "", types.IssueFilter{LabelPattern: "h*"})
		return fmt.Sprint(n), err
	}}
	vfByStatusAnyLabel = vfRead{"count by status with any label", func(s *vfStore) (string, error) {
		m, err := s.te.store.CountIssuesByGroup(s.t.Context(), types.IssueFilter{LabelsAny: []string{vfLabel, "cold"}}, "status")
		return fmt.Sprint(m), err
	}}
	vfCountReadyAnyLabel = vfRead{"ready total with any label", func(s *vfStore) (string, error) {
		n, err := s.te.store.CountReadyWork(s.t.Context(), types.WorkFilter{IncludeEphemeral: true, LabelsAny: []string{vfLabel, "cold"}})
		return fmt.Sprint(n), err
	}}
	// Leaving out children makes the counts read the dependency tables.
	vfCountNoParent = vfRead{"count without children", func(s *vfStore) (string, error) {
		n, err := s.te.store.CountIssues(s.t.Context(), "", types.IssueFilter{NoParent: true})
		return fmt.Sprint(n), err
	}}
	vfCountEphemeralNoParent = vfRead{"count ephemeral without children", func(s *vfStore) (string, error) {
		n, err := s.te.store.CountIssues(s.t.Context(), "", types.IssueFilter{Ephemeral: vfEphemeral(), NoParent: true})
		return fmt.Sprint(n), err
	}}
	vfByStatusNoParent = vfRead{"count by status without children", func(s *vfStore) (string, error) {
		m, err := s.te.store.CountIssuesByGroup(s.t.Context(), types.IssueFilter{NoParent: true}, "status")
		return fmt.Sprint(m), err
	}}
	vfSearchCounts = vfRead{"search with counts", func(s *vfStore) (string, error) {
		got, err := s.te.store.SearchIssuesWithCounts(s.t.Context(), "", types.IssueFilter{})
		return vfCountsIDs(got), err
	}}
	vfSearchCountsEphemeral = vfRead{"search ephemeral with counts", func(s *vfStore) (string, error) {
		got, err := s.te.store.SearchIssuesWithCounts(s.t.Context(), "", types.IssueFilter{Ephemeral: vfEphemeral()})
		return vfCountsIDs(got), err
	}}
	vfReady = vfRead{"ready", func(s *vfStore) (string, error) {
		got, err := s.te.store.GetReadyWork(s.t.Context(), types.WorkFilter{IncludeEphemeral: true})
		return vfIssueIDs(got), err
	}}
	vfReadyLabel = vfRead{"ready with label", func(s *vfStore) (string, error) {
		got, err := s.te.store.GetReadyWork(s.t.Context(), types.WorkFilter{IncludeEphemeral: true, Labels: []string{vfLabel}})
		return vfIssueIDs(got), err
	}}
	vfReadyLabelLimit = vfRead{"ready with label and limit", func(s *vfStore) (string, error) {
		got, err := s.te.store.GetReadyWork(s.t.Context(), types.WorkFilter{IncludeEphemeral: true, Labels: []string{vfLabel}, Limit: 5})
		return vfIssueIDs(got), err
	}}
	vfReadyCounts = vfRead{"ready with counts", func(s *vfStore) (string, error) {
		got, err := s.te.store.GetReadyWorkWithCounts(s.t.Context(), types.WorkFilter{IncludeEphemeral: true})
		return vfCountsIDs(got), err
	}}
	vfCountReady = vfRead{"ready total", func(s *vfStore) (string, error) {
		n, err := s.te.store.CountReadyWork(s.t.Context(), types.WorkFilter{IncludeEphemeral: true})
		return fmt.Sprint(n), err
	}}
	vfCountReadyLabel = vfRead{"ready total with label", func(s *vfStore) (string, error) {
		n, err := s.te.store.CountReadyWork(s.t.Context(), types.WorkFilter{IncludeEphemeral: true, Labels: []string{vfLabel}})
		return fmt.Sprint(n), err
	}}
	// The server-backed stack reads the same tables through the domain
	// repository; these are driven over a raw connection to the same files.
	vfRepoSearchCounts = vfRead{"repository search with counts", func(s *vfStore) (string, error) {
		conn, cleanup, err := embeddeddolt.OpenSQL(s.t.Context(), s.te.dataDir, s.te.database, "main")
		if err != nil {
			s.t.Fatalf("OpenSQL: %v", err)
		}
		defer cleanup()
		page, err := db.NewIssueSQLRepository(conn).SearchAcrossIssuesAndWispsWithCounts(s.t.Context(), "", types.IssueFilter{})
		return vfCountsIDs(page.Items), err
	}}
	vfRepoReady = vfRead{"repository ready", func(s *vfStore) (string, error) {
		conn, cleanup, err := embeddeddolt.OpenSQL(s.t.Context(), s.te.dataDir, s.te.database, "main")
		if err != nil {
			s.t.Fatalf("OpenSQL: %v", err)
		}
		defer cleanup()
		page, err := db.NewIssueSQLRepository(conn).GetReadyWork(s.t.Context(), types.WorkFilter{IncludeEphemeral: true})
		return vfIssueIDs(page.Items), err
	}}
	vfRepoReadyCounts = vfRead{"repository ready with counts", func(s *vfStore) (string, error) {
		conn, cleanup, err := embeddeddolt.OpenSQL(s.t.Context(), s.te.dataDir, s.te.database, "main")
		if err != nil {
			s.t.Fatalf("OpenSQL: %v", err)
		}
		defer cleanup()
		page, err := db.NewIssueSQLRepository(conn).GetReadyWorkWithCounts(s.t.Context(), types.WorkFilter{IncludeEphemeral: true})
		return vfCountsIDs(page.Items), err
	}}
)

// TestBrokenWispPlaneIsReported: the wisp tables are there and hold a live
// row, but a table their reads also need is gone. Answering with the durable
// side alone and no error is the understated total operators saw.
func TestBrokenWispPlaneIsReported(t *testing.T) {
	cases := []struct {
		renamed string
		reads   []vfRead
	}{
		{"wisp_labels", []vfRead{
			vfCountLabel, vfCountEphemeralLabel, vfByLabel, vfByLabelEphemeral,
			vfCountAnyLabel, vfCountLabelPattern, vfByStatusAnyLabel, vfCountReadyAnyLabel,
			vfSearchCounts, vfSearchCountsEphemeral,
			vfReady, vfReadyLabel, vfReadyLabelLimit, vfReadyCounts, vfCountReadyLabel,
			vfRepoSearchCounts, vfRepoReady, vfRepoReadyCounts,
		}},
		{"wisp_comments", []vfRead{
			vfSearchCounts, vfSearchCountsEphemeral, vfReadyCounts, vfRepoSearchCounts, vfRepoReadyCounts,
		}},
	}
	for _, tc := range cases {
		for _, r := range tc.reads {
			t.Run(tc.renamed+"/"+r.name, func(t *testing.T) {
				s := vfOpen(t, "bw", tc.renamed)
				s.te.assertRowExists(t, t.Context(), "wisps", "bw-wisp")
				got, err := r.answer(s)
				if err == nil {
					t.Fatalf("%s answered %q with no error while %s is missing", r.name, got, tc.renamed)
				}
			})
		}
	}
}

var vfAllReads = []vfRead{
	vfCount, vfCountLabel, vfCountEphemeralLabel, vfByStatus, vfByLabel, vfByLabelEphemeral,
	vfCountNoParent, vfCountEphemeralNoParent, vfByStatusNoParent,
	vfCountAnyLabel, vfCountLabelPattern, vfByStatusAnyLabel, vfCountReadyAnyLabel,
	vfSearchCounts, vfSearchCountsEphemeral,
	vfReady, vfReadyLabel, vfReadyLabelLimit, vfReadyCounts, vfCountReady, vfCountReadyLabel,
	vfRepoSearchCounts, vfRepoReady, vfRepoReadyCounts,
}

// vfExpect runs every read against a fresh store with renamed taken away and
// compares each answer with want (an empty want entry only requires no error).
func vfExpect(t *testing.T, prefix, renamed string, want map[string]string) {
	t.Helper()
	for _, r := range vfAllReads {
		t.Run(r.name, func(t *testing.T) {
			s := vfOpen(t, prefix, renamed)
			got, err := r.answer(s)
			if err != nil {
				t.Fatalf("%s failed: %v", r.name, err)
			}
			if w, ok := want[r.name]; ok && got != w {
				t.Fatalf("%s = %q, want %q", r.name, got, w)
			}
		})
	}
}

// TestHealthyWispPlaneStillMerged: an intact database counts both sides.
func TestHealthyWispPlaneStillMerged(t *testing.T) {
	both := "hw-issue,hw-wisp"
	vfExpect(t, "hw", "", map[string]string{
		"count":                            "2",
		"count with label":                 "2",
		"count ephemeral with label":       "1",
		"count by status":                  "map[open:2]",
		"count by label":                   "map[hot:2]",
		"count ephemeral by label":         "map[hot:1]",
		"count without children":           "2",
		"count ephemeral without children": "1",
		"count by status without children": "map[open:2]",
		"count with any label":             "2",
		"count with label pattern":         "2",
		"count by status with any label":   "map[open:2]",
		"ready total with any label":       "2",
		"search with counts":               both,
		"search ephemeral with counts":     "hw-wisp",
		"ready":                            both,
		"ready with label":                 both,
		"ready with label and limit":       both,
		"ready with counts":                both,
		"ready total":                      "2",
		"ready total with label":           "2",
		"repository search with counts":    both,
	})
}

// TestNoWispPlaneCountsDurableOnly: a database with no wisps table has no
// wisps to add, and every read answers with the durable side.
func TestNoWispPlaneCountsDurableOnly(t *testing.T) {
	vfExpect(t, "nw", "wisps", map[string]string{
		"count":                            "1",
		"count with label":                 "1",
		"count ephemeral with label":       "0",
		"count by status":                  "map[open:1]",
		"count by label":                   "map[hot:1]",
		"count ephemeral by label":         "map[]",
		"count without children":           "1",
		"count ephemeral without children": "0",
		"count by status without children": "map[open:1]",
		"count with any label":             "1",
		"count with label pattern":         "1",
		"count by status with any label":   "map[open:1]",
		"ready total with any label":       "1",
		"search with counts":               "nw-issue",
		"search ephemeral with counts":     "",
		"ready":                            "nw-issue",
		"ready with label":                 "nw-issue",
		"ready with label and limit":       "nw-issue",
		"ready with counts":                "nw-issue",
		"ready total":                      "1",
		"ready total with label":           "1",
		"repository search with counts":    "nw-issue",
	})
}

// TestNoWispDependenciesStillAnswers: wisp dependencies are optional, so a
// clone without that table keeps answering every read without an error.
func TestNoWispDependenciesStillAnswers(t *testing.T) {
	vfExpect(t, "nd", "wisp_dependencies", map[string]string{
		"count":            "2",
		"count with label": "2",
		"count by status":  "map[open:2]",
		"count by label":   "map[hot:2]",
	})
}

// TestReadyTotalMatchesReadyList: the ready total is documented as the length
// of the ready-with-counts list for the same filter, on every database shape.
func TestReadyTotalMatchesReadyList(t *testing.T) {
	for _, renamed := range []string{"", "wisps", "wisp_dependencies"} {
		name := renamed
		if name == "" {
			name = "intact"
		}
		t.Run(name, func(t *testing.T) {
			s := vfOpen(t, "rt", renamed)
			for _, labels := range [][]string{nil, {vfLabel}} {
				filter := types.WorkFilter{IncludeEphemeral: true, Labels: labels}
				list, err := s.te.store.GetReadyWorkWithCounts(t.Context(), filter)
				if err != nil {
					t.Fatalf("ready with counts %v: %v", labels, err)
				}
				n, err := s.te.store.CountReadyWork(t.Context(), filter)
				if err != nil {
					t.Fatalf("ready total %v: %v", labels, err)
				}
				if n != len(list) {
					t.Fatalf("labels %v: ready total %d, ready list has %d (%s)", labels, n, len(list), vfCountsIDs(list))
				}
			}
		})
	}
}

// TestOtherWispFailuresStillReported: a wisps table that is present but
// unreadable for another reason is not "no wisps" either.
func TestOtherWispFailuresStillReported(t *testing.T) {
	for _, r := range []vfRead{vfByStatus, vfSearchCounts, vfReady, vfReadyCounts, vfCountReady, vfRepoSearchCounts, vfRepoReady, vfRepoReadyCounts} {
		t.Run(r.name, func(t *testing.T) {
			s := vfOpen(t, "uw", "")
			s.te.exec(t, t.Context(), "ALTER TABLE wisps RENAME COLUMN status TO status_renamed_away")
			if got, err := r.answer(s); err == nil {
				t.Fatalf("%s answered %q with no error over an unreadable wisps table", r.name, got)
			}
		})
	}
}
