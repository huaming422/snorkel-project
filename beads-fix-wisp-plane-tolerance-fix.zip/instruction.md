## Task

Some beads clones report work totals that are too low. `bd count` (plain or with `--by-<field>`), `bd search --counts` and `bd ready` leave ephemeral wisp items out. There's no warning or error, the number is just wrong.

We have only reproduced it on clones whose schema drifted or was half migrated. Healthy clones report the right totals.

On a clone that is broken like that we'd rather the command fail than print a short total. Older repos that never had wisps should keep working as they do today. Don't regress anything else.
