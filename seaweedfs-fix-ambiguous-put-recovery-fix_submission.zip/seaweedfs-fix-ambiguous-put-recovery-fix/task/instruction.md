## Task

we run the s3 gateway in front of our filer and we've started losing objects. it's not every upload. some writes get routed to a per-key owner filer so a read right after the write sees it, and the trouble only shows up on one of those routed writes when the outcome comes back ambiguous: the gateway doesn't get a clean response and can't tell whether the write actually landed, so it goes into recovery. after one of those recoveries an object a client had successfully stored sometimes just isn't there anymore, or comes back with the wrong contents. the ordinary clean-write path looks totally fine.

whatever the fix turns out to be, keep it inside the gateway's write and recovery logic. the on-wire s3 behaviour clients depend on and the entry format the filer stores both stay exactly as they are today. can you dig in and fix it?
