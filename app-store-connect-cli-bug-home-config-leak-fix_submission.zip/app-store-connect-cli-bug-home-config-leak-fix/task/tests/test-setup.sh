#!/usr/bin/env bash
# Sourced by tests/test.sh before the verifier (set -euo pipefail inherited).
# The image baked the full Go dependency closure and build cache at the base
# commit; the oracle introduces only the Go standard library (os/user), so in
# the normal case there is nothing to fetch. Resolve modules offline first so a
# warm image never touches the network; fall back to an online fetch (test.sh
# runs with network) only if the offline resolution misses, and log either way.
cd /repo/App-Store-Connect-CLI
export GOFLAGS=-mod=mod

if GOPROXY=off go mod download > /tmp/test-setup-godl.log 2>&1; then
    echo "[offline-first] go modules satisfied from image cache"
else
    echo "[offline-first] cache miss; retrying go mod download online" >&2
    tail -40 /tmp/test-setup-godl.log >&2
    if go mod download > /tmp/test-setup-godl-online.log 2>&1; then
        echo "[online-fallback] go modules fetched from proxy"
    else
        echo "[test-setup] go mod download failed offline and online" >&2
        tail -40 /tmp/test-setup-godl-online.log >&2
        exit 1
    fi
fi
