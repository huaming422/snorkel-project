"""Black-box checks for the HOME-override config-isolation issue.

These tests drive the built ``asc`` binary as a subprocess and never import
repository Go packages. The whole scene is reproduced at the process level:

  * build ``asc`` from the submitted source tree;
  * discover the running OS account's home directory from the passwd database
    (``pwd.getpwuid``), independent of ``$HOME`` — mirroring how a correct fix
    must determine the account home;
  * plant a ``.asc/config.json`` inside that account home;
  * run ``asc auth status --output json`` with an overridden ``HOME`` and
    ``ASC_BYPASS_KEYCHAIN=1`` (so the file path is exercised rather than the
    system keychain), capturing stdout and stderr separately.

The config resolution order is: ``ASC_CONFIG_PATH`` (absolute) wins; otherwise
the nearest ``.asc/config.json`` found by walking up from the working directory;
otherwise ``$HOME/.asc/config.json``. Only the third step consults ``HOME``, so
when the working directory sits inside the account home the upward search reaches
the account's stored config even though ``HOME`` points elsewhere.

Interface: the pre-existing, stable ``asc auth status`` command. Under
``ASC_BYPASS_KEYCHAIN=1`` its JSON ``.storageLocation`` reports the resolved
config path on stdout; the isolation warning (when present) is written to the
process's stderr.

Observable classifications:
  * C1 (regression check, fails before the fix): a meaningful warning reaches
    stderr in the leak scenario.
  * C2 (invariant, holds before and after): the selected config is unchanged.
  * C3 (invariant, holds before and after): no warning in the safe scenarios
    (HOME is the account home; an explicit config-path override is set; the
    working directory is outside the account home; a nearer project config wins).

The "HOME is a symlink resolving to the account home" edge is NOT exercised
here: ``asc auth status`` lists credentials through a secure-open guard that
refuses a symlinked HOME path component and exits non-zero before config
resolution runs, so that edge is not observable at this command boundary. Its
"treat a symlinked HOME as the account home" nuance is carried by the judge
criterion instead.
"""

from __future__ import annotations

import json
import os
import pwd
import shutil
import subprocess
import tempfile
from pathlib import Path

import pytest

REPO_DIR = Path(f"/repo/{os.environ.get('REPO_NAME', 'App-Store-Connect-CLI')}")

# Documented, pre-existing config layout (config.go: configDirName/configFileName).
CONFIG_SUBDIR = ".asc"
CONFIG_FILENAME = "config.json"

RUN_TIMEOUT = 60
BUILD_TIMEOUT = 600


# --------------------------------------------------------------------------- #
# Build + scene fixtures
# --------------------------------------------------------------------------- #
@pytest.fixture(scope="module")
def asc_binary(tmp_path_factory: pytest.TempPathFactory) -> str:
    """Build the submitted source into a throwaway ``asc`` binary.

    CGO stays enabled so the account-home lookup via ``os/user`` resolves the
    passwd home (as in production) rather than reading ``$HOME``.
    """
    out_dir = tmp_path_factory.mktemp("asc-bin")
    binary = out_dir / "asc"
    env = dict(os.environ)
    env["CGO_ENABLED"] = "1"
    proc = subprocess.run(
        ["go", "build", "-o", str(binary), "."],
        cwd=str(REPO_DIR),
        env=env,
        capture_output=True,
        text=True,
        timeout=BUILD_TIMEOUT,
        check=False,
    )
    if proc.returncode != 0 or not binary.exists():
        pytest.fail(
            "building the asc binary failed "
            f"(exit {proc.returncode}).\n--- stderr ---\n{proc.stderr[-3000:]}"
        )
    return str(binary)


@pytest.fixture(scope="module")
def account_home() -> str:
    """The running account's home directory, independent of ``$HOME``."""
    return pwd.getpwuid(os.getuid()).pw_dir


@pytest.fixture
def scene(account_home: str):
    """Plant an account-home config and a separate scratch HOME.

    Records whether the account config pre-existed and restores the tree on
    teardown so a real stored config (if any) is left untouched.
    """
    acct_asc = os.path.join(account_home, CONFIG_SUBDIR)
    acct_config = os.path.join(acct_asc, CONFIG_FILENAME)

    created_dir = not os.path.isdir(acct_asc)
    preexisting = os.path.isfile(acct_config)
    backup = None
    if preexisting:
        backup = acct_config + ".verify-backup"
        shutil.copy2(acct_config, backup)
    else:
        os.makedirs(acct_asc, exist_ok=True)
        with open(acct_config, "w", encoding="utf-8") as fh:
            fh.write("{}")

    scratch_root = tempfile.mkdtemp(prefix="asc-scratch-")  # no "home" token in path

    class Scene:
        pass

    s = Scene()
    s.account_home = account_home
    s.account_config = acct_config
    s.scratch_home = scratch_root

    try:
        yield s
    finally:
        if preexisting and backup is not None:
            shutil.copy2(backup, acct_config)
            os.remove(backup)
        else:
            try:
                os.remove(acct_config)
            except FileNotFoundError:
                pass
            if created_dir:
                shutil.rmtree(acct_asc, ignore_errors=True)
        shutil.rmtree(scratch_root, ignore_errors=True)


def _run_status(binary: str, cwd: str, home: str, config_path: str | None = None):
    """Run ``asc auth status --output json`` with a controlled environment.

    Starts from a clean ASC_* environment: keychain bypassed (so the config file
    path is exercised), ``HOME`` overridden, and ``ASC_CONFIG_PATH`` set only
    when a case asks for it. Returns (stdout, stderr, returncode).
    """
    env = {
        "PATH": os.environ.get("PATH", "/usr/local/go/bin:/usr/bin:/bin"),
        "HOME": home,
        "ASC_BYPASS_KEYCHAIN": "1",
    }
    if config_path is not None:
        env["ASC_CONFIG_PATH"] = config_path
    proc = subprocess.run(
        [binary, "auth", "status", "--output", "json"],
        cwd=cwd,
        env=env,
        capture_output=True,
        text=True,
        timeout=RUN_TIMEOUT,
        check=False,
    )
    return proc.stdout, proc.stderr, proc.returncode


def _warning_lines(stderr: str) -> list[str]:
    """Lines that read as the account-home isolation warning.

    Wording-independent signal: a stderr line that either reads as a warning
    ("warning" anywhere) or references a config file and the HOME directory
    together. In ``--output json`` mode the command's success path writes nothing
    to stderr, so a correct fix emits such a line only in the leak scenario; the
    safe scenarios leave stderr free of it. Broad enough to also catch an
    over-correction that warns in a scenario it should not, regardless of its
    exact phrasing.
    """
    out = []
    for line in stderr.splitlines():
        low = line.lower()
        if "warning" in low or (CONFIG_FILENAME in low and "home" in low):
            out.append(line)
    return out


# --------------------------------------------------------------------------- #
# C1 — the leak scenario surfaces a meaningful warning (fails before the fix)
# --------------------------------------------------------------------------- #
def test_warns_on_account_home_leak(asc_binary: str, scene) -> None:
    stdout, stderr, rc = _run_status(
        asc_binary, cwd=scene.account_home, home=scene.scratch_home
    )

    assert rc == 0, f"auth status exited {rc}; stderr:\n{stderr[-1500:]}"

    warnings = _warning_lines(stderr)
    assert warnings, (
        "expected a warning on stderr naming the selected config and HOME "
        "when the upward search reaches the account-home config under an "
        f"overridden HOME.\n--- stderr ---\n{stderr!r}"
    )

    assert scene.account_config in stderr, (
        "the warning must name the selected config path "
        f"({scene.account_config!r}).\n--- stderr ---\n{stderr!r}"
    )
    assert scene.scratch_home in stderr, (
        "the warning must surface the overridden HOME "
        f"({scene.scratch_home!r}).\n--- stderr ---\n{stderr!r}"
    )


# --------------------------------------------------------------------------- #
# C2 — the fix only warns; the selected config is unchanged
# --------------------------------------------------------------------------- #
def test_selection_unchanged_under_warning(asc_binary: str, scene) -> None:
    stdout, stderr, rc = _run_status(
        asc_binary, cwd=scene.account_home, home=scene.scratch_home
    )
    assert rc == 0, f"auth status exited {rc}; stderr:\n{stderr[-1500:]}"

    try:
        payload = json.loads(stdout)
    except json.JSONDecodeError as exc:
        pytest.fail(f"auth status did not emit JSON: {exc}\n--- stdout ---\n{stdout[-1500:]}")

    location = payload.get("storageLocation", "")
    assert location, f"no storageLocation in output: {payload!r}"
    assert os.path.realpath(location) == os.path.realpath(scene.account_config), (
        "the selected config must still be the account-home config "
        f"({scene.account_config!r}); got {location!r}. Skipping the account "
        "file when HOME differs is a breaking change to the documented "
        "resolution order."
    )


# --------------------------------------------------------------------------- #
# C3 — no warning in the safe scenarios (over-broad warn conditions rejected)
# --------------------------------------------------------------------------- #
def test_no_warning_when_home_is_account_home(asc_binary: str, scene) -> None:
    # (a) HOME is the account home: local and global resolve to the same file.
    _, stderr, rc = _run_status(
        asc_binary, cwd=scene.account_home, home=scene.account_home
    )
    assert rc == 0, f"exited {rc}; stderr:\n{stderr[-1500:]}"
    assert not _warning_lines(stderr), f"unexpected warning:\n{stderr!r}"


def test_no_warning_when_config_path_env_set(asc_binary: str, scene) -> None:
    # (b) An explicit config-path override short-circuits before the upward search.
    override_root = tempfile.mkdtemp(prefix="asc-override-")
    override = os.path.join(override_root, "missing", CONFIG_FILENAME)
    try:
        _, stderr, rc = _run_status(
            asc_binary, cwd=scene.account_home, home=scene.scratch_home,
            config_path=override,
        )
        assert rc == 0, f"exited {rc}; stderr:\n{stderr[-1500:]}"
        assert not _warning_lines(stderr), f"unexpected warning:\n{stderr!r}"
    finally:
        shutil.rmtree(override_root, ignore_errors=True)


def test_no_warning_outside_account_home(asc_binary: str, scene) -> None:
    # (c) Working directory outside the account home: upward search finds no
    # local config, so the account file is never selected.
    outside = tempfile.mkdtemp(prefix="asc-outside-")
    # Guard: the scratch dir must not sit under the account home.
    assert os.path.commonpath([outside, scene.account_home]) != scene.account_home
    try:
        _, stderr, rc = _run_status(asc_binary, cwd=outside, home=scene.scratch_home)
        assert rc == 0, f"exited {rc}; stderr:\n{stderr[-1500:]}"
        assert not _warning_lines(stderr), f"unexpected warning:\n{stderr!r}"
    finally:
        shutil.rmtree(outside, ignore_errors=True)


def test_no_warning_when_project_config_wins(asc_binary: str, scene) -> None:
    # (d) A nearer project .asc/config.json inside the account home wins the
    # upward search; it is not the account-home config, so no warning.
    proj = os.path.join(scene.account_home, "asc-verify-proj")
    proj_asc = os.path.join(proj, CONFIG_SUBDIR)
    sub = os.path.join(proj, "sub")
    try:
        os.makedirs(proj_asc, exist_ok=True)
        os.makedirs(sub, exist_ok=True)
        with open(os.path.join(proj_asc, CONFIG_FILENAME), "w", encoding="utf-8") as fh:
            fh.write("{}")
        _, stderr, rc = _run_status(asc_binary, cwd=sub, home=scene.scratch_home)
        assert rc == 0, f"exited {rc}; stderr:\n{stderr[-1500:]}"
        assert not _warning_lines(stderr), f"unexpected warning:\n{stderr!r}"
    finally:
        shutil.rmtree(proj, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v", "--tb=short"]))
