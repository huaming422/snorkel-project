## Task

we run this database in MVCC journal mode (`PRAGMA journal_mode = 'mvcc'`), and rollback-heavy workloads slowly degrade a long-running process.

first: a worker opens a transaction, updates one hot row, rolls back, and repeats on that key. the committed value never changes and reads stay correct, but reads of that key get steadily slower the longer it runs. the slowdown tracks the rollback count, not the committed data.

second: a client retries a schema change by rolling it back and trying again, like `BEGIN; CREATE INDEX ...; ROLLBACK` after a timeout. each failed attempt grows the footprint by about one index's worth of data and never gives it back. nothing here commits or checkpoints, so only a restart reclaims the space.

results stay correct throughout; this is cost and memory piling up behind aborted transactions. dig into the MVCC rollback path and how an aborting transaction unwinds its changes, and fix it so a rollback-heavy workload stays flat over time. leave committed data and anything other committed transactions created untouched; keep SQL semantics and the public API unchanged.
