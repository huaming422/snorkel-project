#!/usr/bin/env bash
# Test-setup for turso-perf-rollback-version-reclaim.
#
# The image bakes the full dependency closure at the base commit and pre-builds
# the workspace (`cargo fetch --locked` + `cargo build --locked --workspace
# --lib --tests`), so the verifier's integration test compiles against a warm
# cache. The oracle introduces no new dependency, so there is nothing to fetch
# here. No services to start, no data to seed.
#
# Scope this cargo invocation to offline so a verifier cycle fails fast on a
# cache miss instead of retrying against a (possibly cut) network. This export
# is local to the task's own cargo; it does not affect harbor's harness install.

set -euo pipefail

export CARGO_NET_OFFLINE=true

echo "[test-setup] Rust version:    $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:   $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Workspace root:  /repo/turso"
echo "[test-setup] CARGO_NET_OFFLINE=${CARGO_NET_OFFLINE}"
echo "[test-setup] Setup complete."
