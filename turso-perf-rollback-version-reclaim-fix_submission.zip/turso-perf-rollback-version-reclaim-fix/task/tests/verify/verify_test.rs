//! Behavioral checks for reclamation on transaction abort in MVCC journal mode.
//!
//! These tests drive the engine only through its stable public surface:
//! `Database::open_file` + `Connection::execute(SQL)` to run the workloads, and
//! the `MvStore` behind `Database::get_mv_store()` (its `rows` / `index_rows`
//! maps and the `live_version_count_approx` / `drop_unused_row_versions`
//! counters) to observe what an aborting transaction leaves behind. They make
//! no reference to how abort handling is implemented, so any implementation
//! that reaches the same observable in-memory state passes.
//!
//! Background reclamation is turned off for every test
//! (`mvcc_checkpoint_threshold = -1`, `mvcc_gc_threshold = -1`) so that what is
//! measured is the abort path's own reclamation, not a later sweep.

use std::sync::Arc;
use turso_core::mvcc::database::SQLITE_SCHEMA_MVCC_TABLE_ID;
use turso_core::{Database, MemoryIO, SqliteDialect};

/// In-memory database in MVCC journal mode with background reclamation disabled.
/// Mirrors the engine's own public-API construction path.
fn mvcc_db() -> (Arc<Database>, Arc<turso_core::Connection>) {
    let io = Arc::new(MemoryIO::new());
    let db = Database::open_file(io, ":memory:", Arc::new(SqliteDialect)).unwrap();
    let conn = db.connect().unwrap();
    conn.execute("PRAGMA journal_mode = 'mvcc'").unwrap();
    conn.execute("PRAGMA mvcc_checkpoint_threshold = -1").unwrap();
    conn.execute("PRAGMA mvcc_gc_threshold = -1").unwrap();
    (db, conn)
}

/// Repeatedly touching one committed key inside a transaction and aborting must
/// not let that key's version chain grow: after many aborted modifications the
/// chain holds only the committed version, and a manual unused-version sweep
/// finds nothing to reclaim. (Before the fix, each aborted modification lingers
/// in the chain, so reads of the key rescan an ever-growing history.)
#[test]
fn rollback_removes_aborted_versions_immediately() {
    let (db, conn) = mvcc_db();
    let store = db.get_mv_store().clone().unwrap();

    conn.execute("CREATE TABLE t(id INTEGER PRIMARY KEY, v TEXT)")
        .unwrap();
    conn.execute("INSERT INTO t VALUES (1, 'committed')").unwrap();

    // Sum the version-chain lengths of all user-table rows (ignore the schema
    // table). Exactly one committed row exists, with a single committed version.
    let data_versions = || -> usize {
        store
            .rows
            .iter()
            .filter(|e| e.key().table_id != SQLITE_SCHEMA_MVCC_TABLE_ID)
            .map(|e| e.value().read().len())
            .sum()
    };
    let data_rows = || -> usize {
        store
            .rows
            .iter()
            .filter(|e| e.key().table_id != SQLITE_SCHEMA_MVCC_TABLE_ID)
            .count()
    };

    assert_eq!(data_rows(), 1, "exactly one committed user row");
    assert_eq!(data_versions(), 1, "committed row starts with one version");

    for _ in 0..100 {
        conn.execute("BEGIN").unwrap();
        conn.execute("UPDATE t SET v = 'aborted' WHERE id = 1")
            .unwrap();
        conn.execute("ROLLBACK").unwrap();
    }

    assert_eq!(
        data_rows(),
        1,
        "aborted modifications must not add user rows"
    );
    assert_eq!(
        data_versions(),
        1,
        "chain holds only the committed version; aborted versions were removed at abort time"
    );
    assert_eq!(
        store.drop_unused_row_versions(),
        0,
        "nothing is left for a later sweep to reclaim"
    );
}

/// The live-version counter must reflect only live committed versions and must
/// not be inflated by work that was aborted. After many aborted modifications of
/// one key the counter is unchanged from its post-commit baseline.
#[test]
fn rollback_live_count_not_inflated() {
    let (db, conn) = mvcc_db();
    let store = db.get_mv_store().clone().unwrap();

    conn.execute("CREATE TABLE t(id INTEGER PRIMARY KEY, v TEXT)")
        .unwrap();
    conn.execute("INSERT INTO t VALUES (1, 'committed')").unwrap();

    let baseline = store.live_version_count_approx();

    for _ in 0..100 {
        conn.execute("BEGIN").unwrap();
        conn.execute("UPDATE t SET v = 'aborted' WHERE id = 1")
            .unwrap();
        conn.execute("ROLLBACK").unwrap();
    }

    assert_eq!(
        store.live_version_count_approx(),
        baseline,
        "aborted work must not inflate the live-version count"
    );
}

/// A table or index that a transaction creates and then aborts must leave no
/// trace in the engine's in-memory maps: the index-map count and the index /
/// table slot counts return to their pre-transaction baseline after each abort.
/// (Before the fix, each aborted `CREATE INDEX` leaks a full set of index slots
/// plus its map, and an aborted `CREATE TABLE … INSERT` leaks its row slots,
/// since nothing short of a commit or checkpoint reclaims them.)
#[test]
fn rollback_reclaims_created_btree_maps() {
    let (db, conn) = mvcc_db();
    let store = db.get_mv_store().clone().unwrap();

    conn.execute("CREATE TABLE t(id INTEGER PRIMARY KEY, v TEXT)")
        .unwrap();
    conn.execute("BEGIN").unwrap();
    for i in 0..100 {
        conn.execute(format!("INSERT INTO t VALUES ({i}, 'v{i}')"))
            .unwrap();
    }
    conn.execute("COMMIT").unwrap();

    let index_slots = || -> usize {
        store.index_rows.iter().map(|index| index.value().len()).sum()
    };
    let table_slots = || -> usize {
        store
            .rows
            .iter()
            .filter(|entry| entry.key().table_id != SQLITE_SCHEMA_MVCC_TABLE_ID)
            .count()
    };

    let index_maps_before = store.index_rows.len();
    let index_slots_before = index_slots();
    let table_slots_before = table_slots();

    // A retried CREATE INDEX gets a fresh index id every attempt. Mid-transaction
    // the slots exist (the work happened); after abort they are gone again.
    for _ in 0..5 {
        conn.execute("BEGIN").unwrap();
        conn.execute("CREATE INDEX idx_v ON t(v)").unwrap();
        assert_eq!(
            index_slots(),
            index_slots_before + 100,
            "index build populated its slots inside the transaction"
        );
        conn.execute("ROLLBACK").unwrap();
        assert_eq!(
            store.index_rows.len(),
            index_maps_before,
            "aborted index map must be gone"
        );
        assert_eq!(
            index_slots(),
            index_slots_before,
            "aborted index slots must be reclaimed"
        );
    }

    // The same for a table created and filled in the aborted transaction.
    conn.execute("BEGIN").unwrap();
    conn.execute("CREATE TABLE u(id INTEGER PRIMARY KEY, v TEXT)")
        .unwrap();
    for i in 0..50 {
        conn.execute(format!("INSERT INTO u VALUES ({i}, 'u{i}')"))
            .unwrap();
    }
    assert_eq!(
        table_slots(),
        table_slots_before + 50,
        "new table rows exist inside the transaction"
    );
    conn.execute("ROLLBACK").unwrap();
    assert_eq!(
        table_slots(),
        table_slots_before,
        "aborted table's row slots must be reclaimed"
    );
}

/// Reclamation is scoped to what the aborting transaction created: a committed
/// index keeps its map and its slots. Guards against an over-eager fix that
/// drops created-object maps on every abort regardless of ownership.
#[test]
fn committed_btree_survives_rollback_reclaim() {
    let (db, conn) = mvcc_db();
    let store = db.get_mv_store().clone().unwrap();

    conn.execute("CREATE TABLE t(id INTEGER PRIMARY KEY, v TEXT)")
        .unwrap();
    conn.execute("BEGIN").unwrap();
    for i in 0..100 {
        conn.execute(format!("INSERT INTO t VALUES ({i}, 'v{i}')"))
            .unwrap();
    }
    conn.execute("COMMIT").unwrap();

    let index_slots = || -> usize {
        store.index_rows.iter().map(|index| index.value().len()).sum()
    };

    let index_maps_before = store.index_rows.len();
    let index_slots_before = index_slots();

    // Exercise an abort first, so the committed index below must survive a path
    // that also performed reclamation.
    conn.execute("BEGIN").unwrap();
    conn.execute("CREATE INDEX idx_tmp ON t(v)").unwrap();
    conn.execute("ROLLBACK").unwrap();
    assert_eq!(store.index_rows.len(), index_maps_before);
    assert_eq!(index_slots(), index_slots_before);

    // A committed index keeps its map and one slot per indexed row.
    conn.execute("CREATE INDEX idx_keep ON t(v)").unwrap();
    assert_eq!(
        store.index_rows.len(),
        index_maps_before + 1,
        "committed index adds exactly one map"
    );
    assert_eq!(
        index_slots(),
        index_slots_before + 100,
        "committed index keeps a slot per indexed row"
    );
}
