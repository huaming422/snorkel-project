import { describe, expect, it, vi } from 'vitest';
import { z } from 'zod';
import { Agent } from '../src/agent';
import { ModelBehaviorError } from '../src/errors';
import type { ModelResponse } from '../src/model';
import { Runner } from '../src/run';
import { tool } from '../src/tool';
import type * as protocol from '../src/types/protocol';
import { Usage } from '../src/usage';
import { FakeModel, fakeModelMessage } from './stubs';

// Build a single scripted model turn. Mirrors the helper the package's own
// suites use so the scripted calls look exactly like provider output.
function response(output: protocol.ModelItem[]): ModelResponse {
  return { output, usage: new Usage() };
}

function functionCall(
  callId: string,
  name: string,
  args: Record<string, unknown>,
): protocol.FunctionCallItem {
  return {
    type: 'function_call',
    callId,
    name,
    status: 'completed',
    arguments: JSON.stringify(args),
  };
}

// The behavior under test is observed only through the public run()/RunState
// surface: whether a tool body executes, with which arguments, and whether the
// run proceeds as if a decision were inherited. Nothing here reaches into how a
// solution records which invocation a per-call decision belongs to — any
// binding that keeps a decision tied to the call it was made for satisfies
// these.
describe('tool approval and committed-result binding by invocation', () => {
  // A tool is approved once at a given call ID; on resume the model reuses that
  // same call ID for a DIFFERENT invocation (changed arguments). The
  // differently-argued invocation must not run on the first one's approval. A
  // correct run may re-ask for approval (surfacing a fresh interruption) or
  // refuse outright, but it must never silently execute the changed call. When
  // the approval is keyed by the call ID alone, the changed call executes
  // without asking — which this test forbids.
  it('does not run an approved tool again when a different invocation reuses the approved call id', async () => {
    const execute = vi.fn(async ({ value }: { value: string }) => value);
    const approvalTool = tool({
      name: 'approval_tool',
      description: 'Requires per-call approval before running.',
      parameters: z.object({ value: z.string() }),
      needsApproval: true,
      execute,
    });
    const siblingExecute = vi.fn(async () => 'sibling');
    const siblingTool = tool({
      name: 'sibling_tool',
      description: 'Accompanies the reused invocation in the same turn.',
      parameters: z.object({}),
      execute: siblingExecute,
    });
    const callId = 'reused-approved-call';
    const model = new FakeModel([
      response([functionCall(callId, approvalTool.name, { value: 'safe' })]),
      response([
        functionCall(callId, approvalTool.name, { value: 'changed' }),
        functionCall('sibling-call', siblingTool.name, {}),
      ]),
      response([fakeModelMessage('done')]),
    ]);
    const agent = new Agent({
      name: 'ChangedArgumentsAgent',
      model,
      tools: [approvalTool, siblingTool],
    });
    const runner = new Runner();

    const interrupted = await runner.run(agent, 'start');
    expect(interrupted.interruptions).toHaveLength(1);
    interrupted.state.approve(interrupted.interruptions[0]);

    const outcome = await runner.run(agent, interrupted.state).then(
      (result) => ({ ok: true as const, result }),
      (error) => ({ ok: false as const, error }),
    );

    const executedValues = execute.mock.calls.map((call) => call[0]?.value);
    // The approved invocation may run; the differently-argued one must not.
    expect(executedValues).not.toContain('changed');
    expect(executedValues.filter((value) => value === 'safe')).toHaveLength(1);
    // The run must not silently complete as if the reused ID were authorized:
    // either it refused, or it stopped to ask about the new invocation.
    if (outcome.ok) {
      expect(outcome.result.interruptions.length).toBeGreaterThan(0);
    } else {
      expect(outcome.error).toBeInstanceOf(ModelBehaviorError);
    }
  });

  // The same invocation, re-emitted after its output was committed — same tool,
  // same semantic arguments (here with the argument keys in a different order) —
  // must still be recognized as the same call: the tool runs exactly once and
  // the committed result is reused. A solution that refused every reused ID
  // would re-run or error here, which this test forbids.
  it('reuses a committed result for an exact replay of the same invocation', async () => {
    const execute = vi.fn(async (_args: { first: number; second: number }) => {
      return 'committed';
    });
    const approvalTool = tool({
      name: 'replay_tool',
      description: 'Requires approval; its committed result is replayable.',
      parameters: z.object({ first: z.number(), second: z.number() }),
      needsApproval: true,
      execute,
    });
    const callId = 'exact-replay-call';
    const model = new FakeModel([
      response([
        functionCall(callId, approvalTool.name, { first: 1, second: 2 }),
      ]),
      response([
        functionCall(callId, approvalTool.name, { second: 2, first: 1 }),
      ]),
      response([fakeModelMessage('done')]),
    ]);
    const agent = new Agent({
      name: 'ExactReplayAgent',
      model,
      tools: [approvalTool],
    });
    const runner = new Runner();

    const interrupted = await runner.run(agent, 'start');
    expect(interrupted.interruptions).toHaveLength(1);
    interrupted.state.approve(interrupted.interruptions[0]);
    const result = await runner.run(agent, interrupted.state);

    expect(result.finalOutput).toBe('done');
    expect(execute).toHaveBeenCalledTimes(1);
  });

  // A lone approval-gated call that nobody else reuses must keep working:
  // approve once, resume, run once, complete normally.
  it('runs an ordinary approved invocation exactly once on resume', async () => {
    const execute = vi.fn(async ({ value }: { value: string }) => value);
    const approvalTool = tool({
      name: 'single_approval_tool',
      description: 'Requires approval before running once.',
      parameters: z.object({ value: z.string() }),
      needsApproval: true,
      execute,
    });
    const model = new FakeModel([
      response([
        functionCall('single-call', approvalTool.name, { value: 'ok' }),
      ]),
      response([fakeModelMessage('done')]),
    ]);
    const agent = new Agent({
      name: 'SingleApprovalAgent',
      model,
      tools: [approvalTool],
    });
    const runner = new Runner();

    const interrupted = await runner.run(agent, 'start');
    expect(interrupted.interruptions).toHaveLength(1);
    interrupted.state.approve(interrupted.interruptions[0]);
    const result = await runner.run(agent, interrupted.state);

    expect(result.finalOutput).toBe('done');
    expect(execute).toHaveBeenCalledTimes(1);
    expect(execute.mock.calls[0][0]).toEqual({ value: 'ok' });
  });
});
