import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import { STATE } from "../../src/state.js";
import { resetWorld, place, connect } from "../helpers/sim-world.mjs";
import {
  metricsTick,
  resetMetrics,
  getServiceMetrics,
} from "../../src/core/metrics.js";
import { renderMetricsPanel } from "../../src/ui/metrics-panel.js";
import { calculateFailChanceBasedOnLoad } from "../../src/core/actions.js";
import { Request } from "../../src/entities/Request.js";
import {
  buildReferenceBoard,
  frame,
  mulberry32,
  REFERENCE_MIX,
  SEEDS,
} from "../helpers/reference-board.mjs";

const CAPACITY = 0.5;

const RED = 0xff0000;
const ORANGE = 0xffaa00;
const YELLOW = 0xffff00;
const GREEN = 0x00ff00;

function pinLoad(service, value) {
  Object.defineProperty(service, "totalLoad", {
    get: () => value,
    configurable: true,
  });
  Object.defineProperty(service, "smoothedLoad", {
    value,
    writable: true,
    configurable: true,
  });
}

function ringColorAt(value) {
  resetWorld({ gameMode: "survival" });
  const s = place("compute");
  pinLoad(s, value);
  for (let i = 0; i < 40; i++) s.update(0.5);
  return s.loadRing.material.color.getHex();
}

function runBoard(rps, seed, seconds = 40) {
  resetWorld({ money: 1e9, gameMode: "survival" });
  vi.spyOn(Math, "random").mockImplementation(mulberry32(seed));
  const nodes = buildReferenceBoard();
  STATE.currentRPS = rps;
  STATE.trafficDistribution = { ...REFERENCE_MIX };
  if (!STATE.services.length) throw new Error("reference board did not build");
  const b = nodes.bottleneck;

  let redFrames = 0;
  let overCapFrames = 0;
  const dt = 1 / 60;
  const total = Math.round(seconds / dt);
  for (let i = 0; i < total; i++) {
    frame(dt);
    const hex = b.loadRing.material.color.getHex();
    if (hex === RED) redFrames++;
    if (b.smoothedLoad > CAPACITY) overCapFrames++;
  }
  const failures = Object.values(STATE.failures || {}).reduce(
    (a, n) => a + (typeof n === "number" ? n : 0),
    0
  );
  vi.restoreAllMocks();
  return { redFrames, overCapFrames, failures, peakSmoothed: b.smoothedLoad };
}

function alertFiresAt(load, seconds = 8) {
  resetWorld({ gameMode: "survival" });
  resetMetrics();
  STATE.intervention.warnings = [];
  place("monitor");
  const svc = place("compute");
  Object.defineProperty(svc, "totalLoad", {
    get: () => load,
    configurable: true,
  });
  const dt = 1 / 60;
  for (let i = 0; i < seconds / dt; i++) {
    svc.update(dt);
    STATE.elapsedGameTime += dt;
    metricsTick(dt);
    if (STATE.intervention.warnings.some((w) => w.message.includes("High load"))) {
      return (i + 1) * dt;
    }
  }
  return null;
}

function panelTintsAt(load, oneFrameSpike = false) {
  resetWorld({ gameMode: "survival" });
  resetMetrics();
  place("monitor");
  const svc = place("compute");
  let raw = oneFrameSpike ? CAPACITY / 5 : load;
  Object.defineProperty(svc, "totalLoad", {
    get: () => raw,
    configurable: true,
  });
  const Proto =
    globalThis.HTMLCanvasElement?.prototype ||
    globalThis.window?.HTMLCanvasElement?.prototype;
  const orig = Proto.getContext;
  let fillRects = 0;
  Proto.getContext = function () {
    return {
      clearRect() {},
      fillRect() {
        fillRects++;
      },
      beginPath() {},
      moveTo() {},
      lineTo() {},
      stroke() {},
      set fillStyle(_v) {},
      set strokeStyle(_v) {},
      set lineWidth(_v) {},
    };
  };
  try {
    const dt = 1 / 60;
    for (let i = 0; i < 8 / dt; i++) {
      svc.update(dt);
      STATE.elapsedGameTime += dt;
      metricsTick(dt);
      renderMetricsPanel();
    }
    if (oneFrameSpike) {
      raw = load;
      svc.update(dt);
      STATE.elapsedGameTime += 0.5;
      metricsTick(0.5);
      fillRects = 0;
      renderMetricsPanel();
    }
  } finally {
    Proto.getContext = orig;
  }
  return fillRects > 0;
}

afterEach(() => {
  vi.restoreAllMocks();
});

describe("ordering invariant: alert < red <= capacity, red not deep in collapse", () => {
  function discoverRedOnset() {
    let onset = null;
    for (let v = 0; v <= 1.0; v += 0.005) {
      const load = +v.toFixed(3);
      if (ringColorAt(load) === RED) {
        onset = load;
        break;
      }
    }
    return onset;
  }
  function discoverAlertOnset() {
    let onset = null;
    for (let v = 0; v <= 1.0; v += 0.005) {
      const load = +v.toFixed(3);
      if (alertFiresAt(load) !== null) {
        onset = load;
        break;
      }
    }
    return onset;
  }

  it("the failure curve is unchanged ground truth: no drops at or below capacity", () => {
    expect(calculateFailChanceBasedOnLoad(CAPACITY)).toBe(0);
    expect(calculateFailChanceBasedOnLoad(CAPACITY - 0.01)).toBe(0);
    expect(calculateFailChanceBasedOnLoad(CAPACITY + 0.05)).toBeGreaterThan(0);
  });

  it("ring red lights by the capacity point, not only deep in collapse", () => {
    const redOnset = discoverRedOnset();
    expect(redOnset).not.toBeNull();
    const EPS = 0.03;
    expect(redOnset).toBeLessThanOrEqual(CAPACITY + EPS);
  });

  it("the alert fires at a lighter load than the one that turns the ring red", () => {
    const redOnset = discoverRedOnset();
    const alertOnset = discoverAlertOnset();
    expect(alertOnset).not.toBeNull();
    expect(redOnset).not.toBeNull();
    expect(alertOnset).toBeLessThanOrEqual(redOnset);
  });
});

describe("ring calibrated to capacity", () => {
  it("a node just past capacity reads red", () => {
    expect(ringColorAt(CAPACITY + 0.03)).toBe(RED);
  });

  it("a comfortably-under-capacity node does not read red", () => {
    expect(ringColorAt(CAPACITY / 2)).not.toBe(RED);
  });

  it("a lightly loaded node reads calm (green), not a warning colour", () => {
    expect(ringColorAt(CAPACITY / 5)).toBe(GREEN);
  });

  it("the colour bands are monotonic in load: green < yellow < orange < red", () => {
    const firstSeen = new Map();
    for (let v = 0; v <= 0.6; v += 0.005) {
      const load = +v.toFixed(3);
      const hex = ringColorAt(load);
      if (!firstSeen.has(hex)) firstSeen.set(hex, load);
    }
    for (const hex of [YELLOW, ORANGE, RED]) {
      expect(firstSeen.has(hex)).toBe(true);
    }
    expect(firstSeen.get(YELLOW)).toBeLessThan(firstSeen.get(ORANGE));
    expect(firstSeen.get(ORANGE)).toBeLessThan(firstSeen.get(RED));
    if (firstSeen.has(GREEN)) {
      expect(firstSeen.get(GREEN)).toBeLessThan(firstSeen.get(YELLOW));
    }
  });
});

describe("ring does not strobe on a single spike frame", () => {
  it("one over-capacity frame does not change a settled-calm ring", () => {
    resetWorld({ gameMode: "survival" });
    const s = place("compute");
    let raw = CAPACITY / 5;
    Object.defineProperty(s, "totalLoad", {
      get: () => raw,
      configurable: true,
    });
    for (let i = 0; i < 180; i++) s.update(1 / 60);
    const settled = s.loadRing.material.color.getHex();
    expect(settled).toBe(GREEN);
    raw = 3.0;
    s.update(1 / 60);
    const afterSpike = s.loadRing.material.color.getHex();
    expect(afterSpike).toBe(settled);
  });
});

describe("sampled utilization series follows sustained load", () => {
  it("the latest sample stays calm through a spike and rises on a sustained load", () => {
    resetWorld({ gameMode: "survival" });
    resetMetrics();
    const svc = place("compute");
    let instantaneous = 0.1;
    Object.defineProperty(svc, "totalLoad", {
      get: () => instantaneous,
      configurable: true,
    });
    for (let i = 0; i < 180; i++) {
      svc.update(1 / 60);
      STATE.elapsedGameTime += 1 / 60;
      metricsTick(1 / 60);
    }
    instantaneous = 3;
    svc.update(1 / 60);
    STATE.elapsedGameTime += 0.5;
    metricsTick(0.5);
    const spikeSample = getServiceMetrics(svc.id).util.at(-1);
    instantaneous = 0.4;
    for (let i = 0; i < 600; i++) {
      svc.update(1 / 60);
      STATE.elapsedGameTime += 1 / 60;
      metricsTick(1 / 60);
    }
    const sustainedSample = getServiceMetrics(svc.id).util.at(-1);
    expect(spikeSample, "one-frame spike changed the utilization history").toBeLessThan(0.3);
    expect(sustainedSample, "sustained load did not raise utilization history").toBeGreaterThan(spikeSample);
    expect(sustainedSample, "history understates a sustained near-capacity load").toBeGreaterThan(0.3);
    expect(sustainedSample, "history overstates a load below capacity").toBeLessThan(0.9);
  });
});

describe("alert precedes the first dropped request", () => {
  it("on a rising load, the alert fires before failures begin", () => {
    resetWorld({ gameMode: "survival" });
    resetMetrics();
    STATE.intervention.warnings = [];
    place("monitor");
    const alb = place("alb");
    const compute = place("compute");
    const db = place("db");
    connect("internet", alb);
    connect(alb, compute);
    connect(compute, db);

    let alertAt = null;
    let firstFailAt = null;
    let raw = 0;
    Object.defineProperty(compute, "totalLoad", {
      get: () => raw,
      configurable: true,
    });
    const dt = 1 / 60;
    for (let v = 0.0; v <= 0.7; v += 0.01) {
      const load = +v.toFixed(2);
      raw = load;
      for (let i = 0; i < 30; i++) {
        compute.update(dt);
        STATE.elapsedGameTime += dt;
        metricsTick(dt);
      }
      if (
        alertAt === null &&
        STATE.intervention.warnings.some((w) => w.message.includes("High load"))
      ) {
        alertAt = load;
      }
      if (firstFailAt === null && calculateFailChanceBasedOnLoad(load) > 0) {
        firstFailAt = load;
      }
    }
    expect(alertAt).not.toBeNull();
    expect(firstFailAt).not.toBeNull();
    expect(alertAt).toBeLessThan(firstFailAt);
  });

  it("the real update and sample sequence warns during a gradual rise", () => {
    resetWorld({ gameMode: "survival" });
    resetMetrics();
    STATE.intervention.warnings = [];
    place("monitor");
    const svc = place("compute");
    let raw = 0;
    Object.defineProperty(svc, "totalLoad", {
      get: () => raw,
      configurable: true,
    });
    let warningAt = null;
    let failureRiskAt = null;
    const dt = 1 / 60;
    for (let frameIndex = 0; frameIndex < 45 * 60; frameIndex++) {
      raw = (frameIndex / (45 * 60)) * 0.7;
      svc.update(dt);
      STATE.elapsedGameTime += dt;
      metricsTick(dt);
      if (warningAt === null && STATE.intervention.warnings.some((w) => w.message.includes("High load"))) {
        warningAt = frameIndex;
      }
      if (failureRiskAt === null && calculateFailChanceBasedOnLoad(raw) > 0) {
        failureRiskAt = frameIndex;
      }
    }
    expect(warningAt).not.toBeNull();
    expect(failureRiskAt).not.toBeNull();
    expect(warningAt).toBeLessThan(failureRiskAt);
  });
});

describe("alert follows sustained load", () => {
  it("a one-frame spike stays quiet, then a sustained hold alerts", () => {
    resetWorld({ gameMode: "survival" });
    resetMetrics();
    STATE.intervention.warnings = [];
    place("monitor");
    const svc = place("compute");
    let raw = CAPACITY / 5;
    Object.defineProperty(svc, "totalLoad", {
      get: () => raw,
      configurable: true,
    });
    for (let i = 0; i < 180; i++) svc.update(1 / 60);
    raw = 3;
    svc.update(1 / 60);
    STATE.elapsedGameTime += 0.5;
    metricsTick(0.5);
    expect(STATE.intervention.warnings.some((w) => w.message.includes("High load"))).toBe(false);

    const samples = alertFiresAt(CAPACITY);
    expect(samples).not.toBeNull();
  });
});

describe("panel tint agrees with the alert rule", () => {
  it("the panel tints above the alert's firing load and stays clean below it", () => {
    let alertOnset = null;
    for (let v = 0; v <= 0.6; v += 0.01) {
      const load = +v.toFixed(2);
      if (alertFiresAt(load) !== null) {
        alertOnset = load;
        break;
      }
    }
    expect(alertOnset).not.toBeNull();
    let redOnset = null;
    for (let v = 0; v <= 0.6; v += 0.005) {
      const load = +v.toFixed(3);
      if (ringColorAt(load) === RED) { redOnset = load; break; }
    }
    expect(redOnset).not.toBeNull();
    expect(panelTintsAt(redOnset + 0.01)).toBe(true);
    expect(panelTintsAt(Math.max(0, alertOnset - 0.15))).toBe(false);
  });

  it("a single raw spike does not flash the hot tint", () => {
    expect(panelTintsAt(3, true)).toBe(false);
  });
});

describe("red is meaningful on the real board", () => {
  it("a healthy board shows no red ring and drops nothing", () => {
    for (const seed of SEEDS) {
      const r = runBoard(3, seed, 40);
      expect(r.failures).toBe(0);
      expect(r.redFrames).toBe(0);
    }
  });

  it("a drowning board lights red for most of the time it is over capacity", () => {
    for (const seed of SEEDS) {
      const r = runBoard(8, seed, 40);
      expect(r.overCapFrames).toBeGreaterThan(0);
      const coverage = r.redFrames / r.overCapFrames;
      expect(coverage).toBeGreaterThan(0.8);
    }
  });
});

describe("campaign simulation is unaffected (display-only guard)", () => {
  let CampaignController;
  beforeEach(async () => {
    resetWorld({ gameMode: "campaign" });
    ({ CampaignController } = await import("../../src/campaign/campaign.js"));
    globalThis.localStorage.removeItem("serverSurvivalCampaignProgress");
  });

  it("fresh progress, round-trip, and corrupt-store recovery are intact", () => {
    const c = new CampaignController();
    expect(c.loadProgress()).toEqual({
      version: 1,
      completed: {},
      highestUnlocked: 1,
    });
    const p = {
      version: 1,
      completed: { 1: { stars: 3, bestTimeSec: 42, lastPlayed: 5 } },
      highestUnlocked: 2,
    };
    c.saveProgress(p);
    expect(c.loadProgress()).toEqual(p);
    globalThis.localStorage.setItem("serverSurvivalCampaignProgress", "{not json");
    expect(c.loadProgress()).toEqual({
      version: 1,
      completed: {},
      highestUnlocked: 1,
    });
  });

  it("a win requires a completed request and unlocks the next level", () => {
    const c = new CampaignController();
    expect(c.loadLevel(1)).toBe(true);
    for (const o of STATE.campaign.level.objectives.primary) {
      STATE.campaign.objectiveResults[o.id] = true;
    }
    c._checkEndConditions();
    expect(STATE.campaign.ended).toBe(false);
    c.onRequestCompleted({ type: "READ" }, "db");
    c._checkEndConditions();
    expect(STATE.campaign.ended).toBe(true);
    expect(STATE.campaign.outcome).toBe("win");
    expect(c.loadProgress().highestUnlocked).toBe(2);
  });

  it("campaign and survival requests retain the load failure decision around capacity", () => {
    for (const gameMode of ["campaign", "survival"]) {
      for (const [load, roll, shouldFail] of [
        [CAPACITY, 0, false],
        [0.55, 0.09, true],
        [0.55, 0.11, false],
        [0.75, 0.49, true],
        [0.75, 0.51, false],
      ]) {
        resetWorld({ gameMode });
        const db = place("db");
        const req = new Request("READ");
        STATE.requests.push(req);
        db.queue.push(req);
        pinLoad(db, load);
        vi.spyOn(Math, "random").mockReturnValue(roll);
        db.update(0.5);
        expect(STATE.failures.READ > 0).toBe(shouldFail);
        expect(STATE.requestsProcessed > 0).toBe(!shouldFail);
        vi.restoreAllMocks();
      }
    }
  });
});
