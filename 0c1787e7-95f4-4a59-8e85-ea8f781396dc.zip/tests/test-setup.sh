#!/usr/bin/env bash
# Environment bootstrap for the verifier. Sourced (not exec'd) so env vars set
# here stay live for the verifier subprocess. Runs in the verifier phase with the
# network up, but the image already bakes the full dependency closure at the base
# commit (npm ci) and the canonical /opt/tooling venv (Python 3.12, which has
# tomllib built in — js.py reads verify.toml through VERIFIER_PYTHON), so nothing
# here needs the network.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/server-survival}"
export REPO_DIR
cd "$REPO_DIR"

# vitest must be resolvable from the repo root; a miss means a corrupted
# node_modules from the image build. Fail loudly rather than later with a
# confusing "command not found". Do not install here because runtime network
# access is unavailable; the image must already carry node_modules.
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest binary missing from node_modules/.bin -- the baked node_modules is absent or was scrubbed; fix the image, not this script." >&2
    exit 1
fi

# Widen the sim project's include glob so the verifier file is discovered.
#
# js.py only globs verify*.test.{ts,tsx,js} (never .mjs), so the verifier must
# be a .js file; but the repo's sim project includes only tests/sim/*.test.mjs
# at the base commit. Vitest treats the positional path js.py passes as a filter
# against each project's include glob, so an un-widened config matches zero
# projects for a .js file (0 suites -> runner failure). Add tests/sim/*.test.js
# to the sim include. Idempotent: a no-op if the repo already matches .js (e.g.
# a solution that widened it itself). Touches only the display/test harness, not
# any game module, so it cannot affect a solution's behavior.
if ! grep -q "tests/sim/\*\.test\.js" vitest.config.mjs; then
    node -e '
const fs = require("fs");
const p = "vitest.config.mjs";
let src = fs.readFileSync(p, "utf8");
const needle = "\"tests/sim/*.test.mjs\"";
if (!src.includes(needle)) {
  console.error("test-setup.sh: could not find the sim include glob in vitest.config.mjs to widen; the config shape changed.");
  process.exit(1);
}
src = src.replace(needle, needle + ", \"tests/sim/*.test.js\"");
fs.writeFileSync(p, src);
'
    echo "test-setup.sh: widened sim include to also match tests/sim/*.test.js"
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
