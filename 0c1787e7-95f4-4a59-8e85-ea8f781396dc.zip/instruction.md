## Task

In survival mode, the on-screen load warnings can mislead players during busy runs with failed requests.

## General instructions

- Work in /repo/server-survival.
- This container has no network access. Use the installed toolchain, dependencies, and populated package caches for builds and tests; downloads will fail. Some usual local development operations may be unavailable here.
- Work independently through the engineering task until the changes are ready to merge.
- Investigate beyond source reading when needed, including the codebase, available technology information, running services, and logs.
