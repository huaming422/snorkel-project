## Task

During survival runs, the colored rings on service nodes can stay green or yellow even as requests begin to fail. They turn red only after the run has deteriorated. The paid Monitoring node can also raise its high load alert after failures have started, leaving players no useful warning. Make these visible signals reflect how near a node is to capacity, with the alert arriving before requests start dropping. Campaign levels should continue to play out as they do now.

## General instructions

- Work in /repo/server-survival.
- This container has no network access. Use the installed toolchain, dependencies, and populated package caches for builds and tests; downloads will fail. Some usual local development operations may be unavailable here.
- Work independently through the engineering task until the changes are ready to merge.
- Investigate beyond source reading when needed, including the codebase, available technology information, running services, and logs.
