"""Test harness for mcap-feat-remote-scan-opt-in.

This task uses the subprocess driver: each story shells out to the prebuilt
`mcap` CLI binary and asserts on exit code + combined stdout/stderr, so there is
no shared Python state to speak of. This module exists to hold the two pieces of
test infrastructure every remote story needs:

  * the path to the built `mcap` binary and the staged-fixture root, and
  * a local HTTP server that honours byte-range requests, so a story can serve a
    real (or crafted) `.mcap` blob at a `http://127.0.0.1:<port>/...` URL and
    drive the CLI's remote-input path against it.

The HTTP server is a pure test fixture: the CLI reads it, nothing in the
solution defines or depends on its shape, so the harness owns it outright. It
advertises `Accept-Ranges: bytes`, answers a `Range: bytes=a-b` request with a
`206 Partial Content` + `Content-Range: bytes a-b/total`, and answers a
range-less request with a `200 OK` full body — the contract the CLI's range
reader probes for (a `bytes=0-0` probe returns `206` + the total size).

Stories import `MCAP_BIN`, `FIXTURES_ROOT`, `fixture_path`, `merged_env`, and
`serve_dir` from here. The opt-in flag's spelling is NOT defined here: it is the
submitted solution's choice, so each story binds it from the submitted patch
(see validation_spec.toml's instructions).
"""

from __future__ import annotations

import contextlib
import http.server
import os
import re
import threading
import urllib.parse
from typing import Iterator


# The prebuilt mcap binary that validation-setup.sh (re)builds from the agent's
# edits. The crate's target dir is redirected to /opt/cache/cargo-target by the
# image, with a fallback to the in-tree target/ path.
def _resolve_mcap_bin() -> str:
    candidates = [
        "/opt/cache/cargo-target/debug/mcap",
        "/repo/mcap/rust/target/debug/mcap",
        "/repo/mcap/rust/cli/target/debug/mcap",
    ]
    for c in candidates:
        if os.path.isfile(c) and os.access(c, os.X_OK):
            return c
    # Fall back to the first candidate; validation-setup.sh guarantees it
    # exists, and a clear FileNotFound at subprocess time beats a silent "".
    return candidates[0]


MCAP_BIN: str = _resolve_mcap_bin()

# Root of staged fixtures (real repo fixtures + crafted blobs). Created by
# validation-setup.sh.
FIXTURES_ROOT: str = "/tmp/mcap_fixtures"


def fixture_path(name: str) -> str:
    """Absolute path to a staged fixture file under FIXTURES_ROOT."""
    return os.path.join(FIXTURES_ROOT, name)


def merged_env() -> dict:
    """os.environ with the image's Rust toolchain paths defaulted in.

    The binary itself needs no special env, but defaulting the toolchain paths
    keeps a story robust if it ever shells out to cargo for a sanity check.
    """
    env = {**os.environ}
    env.setdefault("CARGO_HOME", "/opt/cargo")
    env.setdefault("RUSTUP_HOME", "/opt/rustup")
    env["PATH"] = f"{env['CARGO_HOME']}/bin:" + env.get("PATH", "")
    return env


class _RangeRequestHandler(http.server.BaseHTTPRequestHandler):
    """Serve files from ``self.server.root`` with HTTP byte-range support."""

    # Silence per-request logging so story stdout stays clean.
    def log_message(self, *args) -> None:  # noqa: D401, ANN002
        return

    def _resolve(self) -> str | None:
        parsed = urllib.parse.urlparse(self.path)
        rel = urllib.parse.unquote(parsed.path).lstrip("/")
        root = os.path.abspath(self.server.root)  # type: ignore[attr-defined]
        full = os.path.abspath(os.path.join(root, rel))
        if not (full == root or full.startswith(root + os.sep)):
            return None
        return full if os.path.isfile(full) else None

    def do_GET(self) -> None:  # noqa: N802
        path = self._resolve()
        if path is None:
            self.send_error(404, "not found")
            return
        total = os.path.getsize(path)

        rng = self.headers.get("Range")
        if rng:
            m = re.match(r"\s*bytes=(\d+)-(\d*)\s*$", rng)
            if m:
                start = int(m.group(1))
                end = int(m.group(2)) if m.group(2) else total - 1
                if end > total - 1:
                    end = total - 1
                if start > end or start >= total:
                    self.send_response(416)
                    self.send_header("Content-Range", f"bytes */{total}")
                    self.send_header("Connection", "close")
                    self.end_headers()
                    return
                length = end - start + 1
                # Read only the requested window so a large (possibly sparse)
                # fixture never has to be slurped whole into memory.
                with open(path, "rb") as fh:
                    fh.seek(start)
                    chunk = fh.read(length)
                self.send_response(206)
                self.send_header("Content-Type", "application/octet-stream")
                self.send_header("Accept-Ranges", "bytes")
                self.send_header("Content-Range", f"bytes {start}-{end}/{total}")
                self.send_header("Content-Length", str(len(chunk)))
                self.send_header("Connection", "close")
                self.end_headers()
                self.wfile.write(chunk)
                return

        # Range-less request: full body, but still advertise range support.
        with open(path, "rb") as fh:
            data = fh.read()
        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(total))
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(data)


@contextlib.contextmanager
def serve_dir(root: str = FIXTURES_ROOT) -> Iterator[str]:
    """Serve ``root`` over a range-capable HTTP server on 127.0.0.1.

    Yields the base URL (``http://127.0.0.1:<port>``). Build a per-file URL as
    ``f"{base}/{name}"`` and optionally append a ``?query`` string. The server
    runs on a background daemon thread and is shut down on context exit.
    """
    server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), _RangeRequestHandler)
    server.root = os.path.abspath(root)  # type: ignore[attr-defined]
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        host, port = server.server_address[0], server.server_address[1]
        yield f"http://{host}:{port}"
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)
