#!/usr/bin/env bash
# Validation setup: runs after the agent applies its edits. Two jobs:
#   1. Rebuild the `mcap` CLI binary from the agent's edits (incremental — the
#      image baked a pre-fix build, so only touched code recompiles + relinks).
#   2. Stage the fixtures the stories drive under /tmp/mcap_fixtures/.
# Idempotent: re-running re-stages the fixtures; the cargo cache survives.
set -euo pipefail

# Re-export the toolchain paths the image set (each phase starts a fresh shell,
# so Dockerfile ENV from RUN lines is not inherited).
export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
export RUSTUP_TOOLCHAIN="${RUSTUP_TOOLCHAIN:-1.99.0}"
export PATH="$CARGO_HOME/bin:$PATH"

REPO=/repo/mcap
RUST_DIR="$REPO/rust"
DATA_DIR="$RUST_DIR/mcap/tests/data"
FIXTURES=/tmp/mcap_fixtures

echo "validation-setup: rustc=$(rustc --version 2>&1 | head -1)"
echo "validation-setup: cargo=$(cargo --version 2>&1 | head -1)"

# Step 1: Rebuild the mcap binary with the agent's edits (incremental).
echo "validation-setup: building mcap-cli (incremental)..."
( cd "$RUST_DIR" && cargo build -p mcap-cli > /tmp/mcap-cli-validate-build.log 2>&1 ) || {
    echo "ERROR: cargo build -p mcap-cli failed" >&2
    tail -120 /tmp/mcap-cli-validate-build.log >&2
    exit 1
}

# Locate the produced binary (target dir is redirected by the image, with an
# in-tree fallback).
MCAP_BIN="$CARGO_TARGET_DIR/debug/mcap"
if [ ! -x "$MCAP_BIN" ]; then
    MCAP_BIN="$RUST_DIR/target/debug/mcap"
fi
if [ ! -x "$MCAP_BIN" ]; then
    echo "ERROR: built mcap binary not found (looked in $CARGO_TARGET_DIR/debug and $RUST_DIR/target/debug)" >&2
    exit 1
fi
"$MCAP_BIN" --help >/dev/null 2>&1 || {
    echo "ERROR: built mcap binary is not runnable at $MCAP_BIN" >&2
    exit 1
}
echo "validation-setup: mcap built at $MCAP_BIN"

# Step 2: Stage fixtures.
rm -rf "$FIXTURES"
mkdir -p "$FIXTURES"

# Real, chunked MCAP with a normal summary/index (drives the free-tier summary
# read, the chunked-cat gate, and both merge inputs).
test -f "$DATA_DIR/uncompressed.mcap" || {
    echo "ERROR: expected repo fixture $DATA_DIR/uncompressed.mcap (git-lfs not pulled?)" >&2
    exit 1
}
cp "$DATA_DIR/uncompressed.mcap" "$FIXTURES/local.mcap"
cp "$DATA_DIR/uncompressed.mcap" "$FIXTURES/local2.mcap"

# A real MCAP whose footer has no summary section (summary_start == 0). This repo
# fixture ships summaryless, so it drives the summaryless gate directly.
test -f "$DATA_DIR/zstd_chunk_with_padding.mcap" || {
    echo "ERROR: expected repo fixture $DATA_DIR/zstd_chunk_with_padding.mcap" >&2
    exit 1
}
cp "$DATA_DIR/zstd_chunk_with_padding.mcap" "$FIXTURES/summaryless.mcap"

# Pick an interpreter for the two byte-crafted fixtures. The isolated tooling
# venv is always present in the image; fall back to the system python3.
PYBIN=/opt/tooling/venv/bin/python
if [ ! -x "$PYBIN" ]; then PYBIN="$(command -v python3)"; fi
test -n "$PYBIN" || { echo "ERROR: no python interpreter available to craft fixtures" >&2; exit 1; }

# Craft the two fixtures that cannot be lifted from the repo. Both exploit the
# fact that the gated read paths inspect only the trailing footer + (bounded)
# summary region, so a minimal, valid trailer is all that is needed — the gate
# fires before any body parse.
"$PYBIN" - "$FIXTURES" <<'PY'
import struct, sys, os

out_dir = sys.argv[1]
MAGIC = bytes([0x89, 0x4D, 0x43, 0x41, 0x50, 0x30, 0x0D, 0x0A])  # \x89 M C A P 0 \r \n
OP_FOOTER = 0x02
FOOTER_TAIL_LEN = 37  # op(1) + reclen(8) + body(20) + trailing MAGIC(8)

def footer_tail(summary_start):
    # Footer record body: summary_start(u64) summary_offset_start(u64) summary_crc(u32)
    body = struct.pack("<QQI", summary_start, 0, 0)
    assert len(body) == 20
    return bytes([OP_FOOTER]) + struct.pack("<Q", 20) + body + MAGIC

# (a) A file with a summary section but no message chunks: leading MAGIC, then a
#     footer placed immediately after it, with summary_start pointing at the
#     footer position -> an empty summary section -> parsed summary has no chunk
#     indexes. This drives the "remote file has no chunk index" cat gate.
nochunks = bytearray()
nochunks += MAGIC
footer_start = len(nochunks)            # 8
nochunks += footer_tail(footer_start)   # summary_start == footer_start -> empty summary
with open(os.path.join(out_dir, "nochunks.mcap"), "wb") as f:
    f.write(nochunks)

# (b) A file whose implied summary section is far larger than any reasonable
#     bounded-read budget. A well-formed footer whose summary_start is the first
#     byte past the leading MAGIC means the implied summary length is almost the
#     whole file. Sized at 128 MiB so it sits comfortably ABOVE any sane cap a
#     solution might pick (the reference uses 16 MiB for the summary and 64 MiB
#     for metadata; an alternative that chose a larger-but-sane cap must still
#     reject this). Written sparse: only MAGIC and the trailing footer carry
#     data, the middle is a hole — the budget gate rejects before the summary
#     body is ever read, so the body bytes are never transferred or inspected.
LARGE = 128 * 1024 * 1024
total = LARGE + FOOTER_TAIL_LEN + len(MAGIC)
path = os.path.join(out_dir, "oversized_summary.mcap")
with open(path, "wb") as f:
    f.write(MAGIC)
    f.truncate(total - FOOTER_TAIL_LEN)   # sparse hole up to the footer
    f.seek(total - FOOTER_TAIL_LEN)
    f.write(footer_tail(len(MAGIC)))       # summary_start = 8
assert os.path.getsize(path) == total, os.path.getsize(path)

print("crafted nochunks.mcap (%d B) and oversized_summary.mcap (%d B)" %
      (len(nochunks), total))
PY

# A dummy non-MCAP input with a recognised extension, used only to drive the
# convert command. The whole-object gate fires on the URL before this content is
# ever fetched, so its bytes are irrelevant on the rejection path.
printf 'not a real rosbag' > "$FIXTURES/demo.bag"

# Step 3: Loud smoke guard — the binary must read a real local fixture, and the
# crafted fixtures must be the sizes the stories rely on.
"$MCAP_BIN" info "$FIXTURES/local.mcap" >/dev/null 2>&1 || {
    echo "ERROR: mcap info failed on staged local fixture" >&2
    exit 1
}
nochunks_sz=$(stat -c%s "$FIXTURES/nochunks.mcap")
oversized_sz=$(stat -c%s "$FIXTURES/oversized_summary.mcap")
test "$nochunks_sz" -eq 45 || { echo "ERROR: nochunks.mcap wrong size ($nochunks_sz, expected 45)" >&2; exit 1; }
test "$oversized_sz" -gt "$((100*1024*1024))" || { echo "ERROR: oversized_summary.mcap too small ($oversized_sz)" >&2; exit 1; }

echo "validation-setup: done. Fixtures staged under $FIXTURES:"
ls -l "$FIXTURES"
