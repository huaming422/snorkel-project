## Task

we want the mcap CLI to stop treating remote inputs like local files. when you point a command at a remote URL today, it reads whatever it needs with no ceremony, so a command that only wants the small summary or index at the end of the file stays cheap, but one that has to download or scan the whole object will quietly pull a large amount of data over the wire.

add an explicit opt-in that a user has to pass before the tool will download or scan large remote data. the cheap, bounded index and summary reads shouldn't need it. make the opt-in a single global flag that applies to every subcommand.

it's a policy change in the CLI; you shouldn't need to touch the MCAP format or the core library to do it.

## User stories / requirements

- Given the global opt-in flag, when a user passes it either before or after the subcommand name, the flag is accepted in both positions and an otherwise-normal command runs exactly as it would without it.
- Given a remote input and a command that must download or scan the whole object to do its work, when the user has not opted in, the command is rejected before any large download happens and the rejection points the user at the opt-in flag. When the user has opted in, the command proceeds.
- Given a remote input, when a user tries to read its message payloads without opting in, the command is rejected both when the remote file carries no message index and when serving the request would mean fetching message chunks. When the user has opted in, the read proceeds.
- Given a remote input that has no summary section, when a user tries to read it without opting in, the command is rejected, because serving it means scanning the file.
- Given a remote input whose summary or index is larger than a conservative size budget, when a user tries to read it without opting in, the command is rejected, because a supposedly bounded read would otherwise balloon into a near-whole-file download.
- Given a merge across more than one remote input, when the user has not opted in, the command is rejected; each remote input is gated by the opt-in, and with it the merge proceeds.
- Given a remote operation rejected for lack of the opt-in, when the error is shown, its text does not reveal sensitive parts of the URL such as query-string credentials.
