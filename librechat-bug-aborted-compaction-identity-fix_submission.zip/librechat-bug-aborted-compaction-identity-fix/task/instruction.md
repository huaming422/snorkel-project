## Task

noticed something off with manual compaction when you stop it partway. if you kick off a compaction on a conversation and then hit stop before it's done summarizing, the turn it leaves behind ends up with the wrong hover and rerun controls. on a branch whose last message is a user message it keeps offering "Regenerate", and clicking that just answers the user's message again instead of redoing the compaction.

it's sticky too: reload the conversation and the cancelled compaction is still sitting there with those same wrong controls.

worse, stopping a compaction can corrupt the message it was anchored to. an existing user message can lose its text, or an assistant message gets replaced by an empty user row.

this is only the stopped path. compactions that run all the way to completion are fine, and stopping a normal (non-compaction) generation is fine too; those behave correctly and should stay that way.

should be fixable on the backend, no schema change needed. can you dig in and sort it out?
