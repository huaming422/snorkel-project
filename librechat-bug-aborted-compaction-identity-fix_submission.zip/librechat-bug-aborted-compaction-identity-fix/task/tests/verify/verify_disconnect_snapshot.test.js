/**
 * The disconnect snapshot writes a provisional row while the run may still be
 * live. Unlike the terminal stop, it must NOT invent a failure that has not
 * happened yet — the completing run may still overwrite it with a real result.
 *
 * So for a compaction the snapshot stamps the compaction identity onto whatever
 * streamed, but: a partial summary is marked as the compaction's own WITHOUT a
 * failed flag, and a snapshot that carries no outcome gets NO typed failure part
 * synthesized. An ordinary (non-compaction) snapshot is unchanged. This is what
 * distinguishes the snapshot (no synthesized failure) from the terminal stop
 * (which does synthesize one — covered elsewhere).
 *
 * The scenario drives the real request controller: `req.body.compact` is recorded
 * by the controller onto the job, and the controller's disconnect handler
 * (fired when all subscribers leave) builds the snapshot row from the job's
 * recorded compaction tag. The job manager is stubbed only to hand back the
 * disconnect handler and a resume state; the row shape is observed through a
 * `saveMessage` spy. No assertion touches how the implementation stores the tag.
 */
const { ContentTypes } = require('librechat-data-provider');

const mockSaveMessage = jest.fn(async () => ({ _id: 'saved' }));

const mockGenerationJobManager = {
  createJob: jest.fn(),
  emitError: jest.fn().mockResolvedValue(undefined),
  completeJob: jest.fn().mockResolvedValue(undefined),
  beginProviderExecution: jest.fn().mockResolvedValue(true),
  markProviderExecutionDrained: jest.fn().mockResolvedValue(true),
  getResumeState: jest.fn(),
  getJobStore: jest.fn(),
  updateMetadata: jest.fn().mockResolvedValue(undefined),
  setContentParts: jest.fn(),
  claimGeneration: jest.fn().mockResolvedValue({ claimed: true }),
  releaseGeneration: jest.fn().mockResolvedValue(undefined),
  hasJob: jest.fn().mockResolvedValue(true),
  steering: {
    closeAndDrain: jest.fn().mockResolvedValue([]),
    park: jest.fn().mockResolvedValue(undefined),
  },
};

jest.mock('@librechat/data-schemas', () => {
  const actual = jest.requireActual('@librechat/data-schemas');
  return {
    ...actual,
    logger: { debug: jest.fn(), info: jest.fn(), warn: jest.fn(), error: jest.fn() },
  };
});

jest.mock('@librechat/api', () => {
  const actual = jest.requireActual('@librechat/api');
  return {
    ...actual,
    GenerationJobManager: mockGenerationJobManager,
    checkAndIncrementPendingRequest: jest.fn().mockResolvedValue({ allowed: true }),
    decrementPendingRequest: jest.fn(),
  };
});

jest.mock('~/models', () => {
  const actual = jest.requireActual('~/models');
  return {
    ...actual,
    initializeMessageBudget: jest.fn(),
    saveMessage: (...args) => mockSaveMessage(...args),
    saveConvo: jest.fn().mockResolvedValue({}),
    getConvo: jest.fn().mockResolvedValue({ createdAt: '2026-07-31T00:00:00.000Z' }),
    getMessages: jest.fn().mockResolvedValue([]),
    isAgentTriggerPrincipalActive: jest.fn().mockReturnValue(true),
    isSubagentOwnerAdmissible: jest.fn().mockReturnValue(true),
  };
});

jest.mock('~/server/cleanup', () => ({ disposeClient: jest.fn() }));
jest.mock('~/server/services/MCPRequestContext', () => ({
  getMCPRequestContext: jest.fn().mockResolvedValue(null),
  cleanupMCPRequestContextForReq: jest.fn(),
}));

const ResumableAgentController = require('~/server/controllers/agents/request');
const { isUsableSummaryPart } = require('@librechat/api');

function makeRes() {
  return {
    headersSent: true,
    statusCode: 200,
    status: jest.fn(function (c) {
      this.statusCode = c;
      return this;
    }),
    json: jest.fn(function () {
      return this;
    }),
    end: jest.fn(function () {
      return this;
    }),
    write: jest.fn(() => true),
    setHeader: jest.fn(),
    flushHeaders: jest.fn(),
    on: jest.fn(),
    removeListener: jest.fn(),
  };
}

/**
 * Start a generation, capture the disconnect (allSubscribersLeft) handler the
 * controller registers, then fire it with the content the run had aggregated.
 * Returns the row handed to saveMessage by the snapshot.
 */
async function snapshotOnDisconnect({ compact, aggregatedContent }) {
  mockSaveMessage.mockClear();
  const conversationId = '11111111-1111-4111-8111-111111111111';
  let handler;
  mockGenerationJobManager.getJobStore.mockReturnValue({
    getJob: jest.fn().mockResolvedValue({ createdAt: 1000 }),
  });
  mockGenerationJobManager.createJob.mockResolvedValue({
    createdAt: 1000,
    metadata: { providerExecutionId: 'seg-1', providerDrained: true },
    readyPromise: Promise.resolve(),
    abortController: new AbortController(),
    emitter: {
      on: jest.fn((event, h) => {
        if (event === 'allSubscribersLeft') {
          handler = h;
        }
      }),
    },
  });
  mockGenerationJobManager.getResumeState.mockResolvedValue({
    conversationId,
    responseMessageId: 'response-message',
    userMessage: { messageId: 'user-message' },
  });
  const req = {
    user: { id: 'u-ok' },
    body: {
      text: '',
      ...(compact ? { compact: true } : {}),
      messageId: 'user-message',
      parentMessageId: '22222222-2222-4222-8222-222222222222',
      conversationId,
      endpointOption: { endpoint: 'agents', modelOptions: { model: 'gpt-4.1' } },
    },
    config: { summarization: { enabled: true } },
    on: jest.fn(),
    app: { locals: {} },
  };
  const initializeClient = jest.fn().mockRejectedValue(new Error('stop after setup'));
  await ResumableAgentController(req, makeRes(), jest.fn(), initializeClient, null);
  if (typeof handler !== 'function') {
    throw new Error('disconnect handler was not registered');
  }
  await handler(aggregatedContent);
  return mockSaveMessage.mock.calls[0] && mockSaveMessage.mock.calls[0][1];
}

describe('disconnect snapshot — provisional row, no invented failure', () => {
  // A compaction snapshot carrying a partial summary stamps the compaction
  // identity but — because the run may still complete and overwrite this
  // provisional row — synthesizes NO failure. The snapshot-specific invariants
  // are: identity is present, and nothing is invented as a terminal failure.
  // Whether the implementation keeps the truncated prefix or drops it is a free
  // display choice and is not pinned.
  it('marks a compaction partial summary as the compaction turn, without synthesizing a failure', async () => {
    const saved = await snapshotOnDisconnect({
      compact: true,
      aggregatedContent: [
        { type: ContentTypes.SUMMARY, content: [{ type: ContentTypes.TEXT, text: 'Half a summary' }], summarizing: true },
      ],
    });

    expect(saved).toBeDefined();
    // identity: the provisional row is owned by the user-initiated compaction.
    expect(saved.content.some((p) => p.initiatedBy === 'user')).toBe(true);
    // no invented failure: the snapshot must NOT synthesize a typed-failure part,
    // and must NOT flag a surviving partial summary failed — the still-live run
    // may yet overwrite this row with a real result.
    expect(saved.content.some((p) => p.type === ContentTypes.ERROR)).toBe(false);
    for (const p of saved.content) {
      if (p.type === ContentTypes.SUMMARY) {
        expect(p.failed).toBeUndefined();
      }
    }
    // no usable checkpoint is presented from the truncated prefix.
    expect(saved.content.every((p) => !isUsableSummaryPart(p))).toBe(true);
  });

  // A compaction snapshot with no outcome part does not get a typed failure
  // invented (that only happens at the terminal stop).
  it('does not synthesize a failure for a compaction snapshot with no outcome', async () => {
    const thinking = { type: 'think', think: 'Picking what to summarize' };
    const saved = await snapshotOnDisconnect({
      compact: true,
      aggregatedContent: [thinking],
    });

    expect(saved).toBeDefined();
    expect(saved.content.some((p) => p.type === ContentTypes.ERROR)).toBe(false);
    expect(saved.content).toContainEqual(thinking);
  });

  // An ordinary snapshot is unchanged.
  it('leaves an ordinary (non-compaction) snapshot unchanged', async () => {
    const partial = { type: ContentTypes.TEXT, text: 'Partial response' };
    const saved = await snapshotOnDisconnect({
      compact: false,
      aggregatedContent: [partial],
    });

    expect(saved).toBeDefined();
    expect(saved.content).toEqual([partial]);
    expect(saved.content[0]).not.toHaveProperty('initiatedBy');
    expect(saved.content.some((p) => p.type === ContentTypes.ERROR)).toBe(false);
  });
});
