/**
 * Terminal stop of a manual compaction: what content the abort path persists.
 *
 * The scenario is driven end to end from the public request surface. A real
 * agent generation is started through the request controller (which records the
 * compaction tag off `req.body.compact`), and while that job is live a real HTTP
 * POST to the abort route stops it. The turn the stop persists is observed
 * through a `saveMessage` spy — the test inspects the response row's content, not
 * how or where the implementation decides to stamp it. Marking the content
 * inside the job-manager library and marking it in the route's abort-content hook
 * are both observable here, because either one flows into the row the route
 * writes.
 *
 * The HTTP body carries the flag that tags a turn as a compaction; the agent
 * request controller records that onto the running job, and the stop path later
 * reads it back off the (reloaded) job to settle the cancelled turn. Nothing here
 * reaches into how the controller stores that fact — the test only sets the
 * request input and inspects the persisted content.
 */
const express = require('express');
const request = require('supertest');
const { ContentTypes } = require('librechat-data-provider');

const mockSaveMessage = jest.fn(async (_ctx, m) => m);

jest.mock('@librechat/data-schemas', () => {
  const actual = jest.requireActual('@librechat/data-schemas');
  return {
    ...actual,
    logger: { debug: jest.fn(), info: jest.fn(), warn: jest.fn(), error: jest.fn() },
  };
});

jest.mock('@librechat/api', () => {
  const actual = jest.requireActual('@librechat/api');
  return {
    ...actual,
    isEnabled: jest.fn().mockReturnValue(false),
    isAgentTriggerRequest: jest.fn(() => false),
    captureScheduleFireContext: jest.fn((req) => {
      req._isScheduledFire = false;
      req._isManualScheduledFire = false;
    }),
    checkAndIncrementPendingRequest: jest.fn().mockResolvedValue({ allowed: true }),
    decrementPendingRequest: jest.fn(),
  };
});

jest.mock('~/models', () => {
  const actual = jest.requireActual('~/models');
  return {
    ...actual,
    initializeMessageBudget: jest.fn(),
    saveMessage: (...args) => mockSaveMessage(...args),
    getPersistedPrivateTextId: jest.fn().mockResolvedValue(null),
    getPrivateMessageTexts: jest.fn().mockResolvedValue([]),
    saveConvo: jest.fn().mockResolvedValue({}),
    getConvo: jest.fn().mockResolvedValue(null),
    getMessages: jest.fn().mockResolvedValue([]),
    isAgentTriggerPrincipalActive: jest.fn().mockReturnValue(true),
    isSubagentOwnerAdmissible: jest.fn().mockReturnValue(true),
  };
});

jest.mock('~/server/cleanup', () => ({ disposeClient: jest.fn() }));
jest.mock('~/server/services/MCPRequestContext', () => ({
  getMCPRequestContext: jest.fn().mockResolvedValue(null),
  cleanupMCPRequestContextForReq: jest.fn(),
}));
jest.mock('~/server/services/Schedules', () => ({
  recordScheduleOutcome: jest.fn().mockResolvedValue(true),
  beginScheduledStop: jest.fn().mockResolvedValue(true),
  acknowledgeScheduledStopPersistence: jest.fn().mockResolvedValue(undefined),
  isScheduleLive: jest.fn().mockReturnValue(false),
}));
jest.mock('~/server/middleware', () => ({
  uaParser: (q, s, n) => n(),
  checkBan: (q, s, n) => n(),
  requireJwtAuth: (q, s, n) => {
    q.user = { id: 'u-ok' };
    n();
  },
  moderateText: (q, s, n) => n(),
  agentEventUserLimiter: (q, s, n) => n(),
  messageIpLimiter: (q, s, n) => n(),
  configMiddleware: (q, s, n) => n(),
  messageUserLimiter: (q, s, n) => n(),
}));
jest.mock('~/server/routes/agents/chat', () => require('express').Router());
jest.mock('~/server/routes/agents/v1', () => ({ v1: require('express').Router() }));
jest.mock('~/server/routes/agents/management', () => require('express').Router());

const {
  GenerationJobManager,
  InMemoryJobStore,
  InMemoryEventTransport,
  isUsableSummaryPart,
} = require('@librechat/api');
const ResumableAgentController = require('~/server/controllers/agents/request');
const agentRoutes = require('~/server/routes/agents/index');

function makeRes() {
  return {
    headersSent: false,
    statusCode: 200,
    status: jest.fn(function (c) {
      this.statusCode = c;
      return this;
    }),
    json: jest.fn(function () {
      return this;
    }),
    end: jest.fn(function () {
      return this;
    }),
    write: jest.fn(() => true),
    setHeader: jest.fn(),
    flushHeaders: jest.fn(),
    on: jest.fn(),
    removeListener: jest.fn(),
  };
}

/**
 * Start a real generation through the controller and, while it is live, stop it
 * with a real POST to the abort route. Returns the abort response plus the
 * persisted response row (the unfinished assistant row the route writes), read
 * off the `saveMessage` spy.
 * @returns {Promise<{resp: object, responseRow: object|undefined}>}
 */
async function stopAndCapture({ app, compact, content, conversationId, parentMessageId }) {
  let abortResp;
  const req = {
    body: {
      text: '',
      ...(compact ? { compact: true } : {}),
      conversationId,
      parentMessageId,
      endpointOption: { endpoint: 'agents', modelOptions: { model: 'gpt-4.1' } },
    },
    config: { summarization: { enabled: true } },
    user: { id: 'u-ok' },
    on: jest.fn(),
    app: { locals: {} },
  };
  const initializeClient = async () => {
    GenerationJobManager.setContentParts(conversationId, content);
    abortResp = await request(app)
      .post('/api/agents/chat/abort')
      .set('X-LibreChat-Generation-Protocol', '2')
      .send({ conversationId, generationProtocolVersion: 2 });
    const stop = new Error('__stop__');
    stop.__stop = true;
    throw stop;
  };
  try {
    await ResumableAgentController(req, makeRes(), jest.fn(), initializeClient, jest.fn());
  } catch (e) {
    if (!e.__stop) {
      throw e;
    }
  }
  const saved = mockSaveMessage.mock.calls.map((c) => c[1]);
  const responseRow = saved.find((m) => m.isCreatedByUser === false);
  return { resp: abortResp, responseRow };
}

describe('stopped compaction — persisted turn content', () => {
  let app;
  beforeAll(() => {
    app = express();
    app.use(express.json());
    app.use('/api/agents', agentRoutes);
  });
  beforeEach(() => {
    mockSaveMessage.mockClear();
    GenerationJobManager.configure({
      jobStore: new InMemoryJobStore(),
      eventTransport: new InMemoryEventTransport(),
      isRedis: false,
      cleanupOnComplete: false,
    });
    GenerationJobManager.initialize();
  });
  afterEach(async () => {
    await GenerationJobManager.destroy();
  });

  // A partial (unfinished) summary that never bounded any history settles the
  // stopped turn as the compaction's own, with no part left presentable as a
  // finished checkpoint. Two decompositions satisfy that behaviour and both are
  // accepted: keep the truncated summary stamped not-successful, OR drop the
  // unusable prefix and let the typed compaction-failure stand as the outcome.
  // The pinned-down property is the behaviour of the persisted row, not the
  // author's chosen display shape, and the row is read off the persistence
  // surface so an implementation may stamp it in the library or in the route.
  it('settles a partial summary as the compaction turn with no usable checkpoint', async () => {
    const partialSummary = {
      type: ContentTypes.SUMMARY,
      content: [{ type: ContentTypes.TEXT, text: 'Half a summary' }],
      summarizing: true,
    };
    const { resp, responseRow } = await stopAndCapture({
      app,
      compact: true,
      content: [partialSummary],
      conversationId: '11111111-1111-4111-8111-111111111111',
      parentMessageId: '22222222-2222-4222-8222-222222222222',
    });

    expect(resp.status).toBe(200);
    expect(responseRow).toBeDefined();
    // identity: the persisted row is owned by the user-initiated compaction, not
    // an answer to the parent — some content part carries the marker.
    expect(responseRow.content.some((p) => p.initiatedBy === 'user')).toBe(true);
    // no usable checkpoint: nothing in the row reads as a finished summary the UI
    // could offer as the history boundary — true both when a kept partial is
    // flagged not-successful and when the prefix is dropped for a typed failure.
    expect(responseRow.content.every((p) => !isUsableSummaryPart(p))).toBe(true);
  });

  // No usable outcome (an empty placeholder summary that never streamed text)
  // still settles the turn as the compaction's own with no usable checkpoint, so
  // a persistable, identifiable row exists instead of one that reads as an answer
  // to its parent. Whether the placeholder is dropped for a typed failure or kept
  // stamped not-successful is an implementation choice; the behaviour is the pin.
  it('settles an empty placeholder as the compaction turn with no usable checkpoint', async () => {
    const { resp, responseRow } = await stopAndCapture({
      app,
      compact: true,
      content: [{ type: ContentTypes.SUMMARY, content: [], summarizing: true }],
      conversationId: '33333333-3333-4333-8333-333333333333',
      parentMessageId: '44444444-4444-4444-8444-444444444444',
    });

    expect(resp.status).toBe(200);
    expect(responseRow).toBeDefined();
    expect(responseRow.content.some((p) => p.initiatedBy === 'user')).toBe(true);
    expect(responseRow.content.every((p) => !isUsableSummaryPart(p))).toBe(true);
  });

  // A non-outcome part streamed (e.g. a reasoning/think part) but no summary and
  // no error: the turn still has to settle as the compaction's own, so a
  // persistable identifiable row exists with no part usable as a checkpoint. The
  // non-outcome part may be kept (implementation choice) or dropped, and the
  // outcome may be a typed failure or an empty owned summary — the pin is the
  // behaviour, identity present and no usable checkpoint, not the shape.
  it('settles a run that streamed no outcome as the compaction turn with no usable checkpoint', async () => {
    const thinking = { type: 'think', think: 'planning what to summarize' };
    const { resp, responseRow } = await stopAndCapture({
      app,
      compact: true,
      content: [thinking],
      conversationId: '55555555-5555-4555-8555-555555555555',
      parentMessageId: '66666666-6666-4666-8666-666666666666',
    });

    expect(resp.status).toBe(200);
    expect(responseRow).toBeDefined();
    // identity: the persisted row is owned by the user-initiated compaction —
    // some content part carries the marker.
    expect(responseRow.content.some((p) => p.initiatedBy === 'user')).toBe(true);
    // no usable checkpoint: nothing in the row reads as a finished summary the UI
    // could offer as the history boundary.
    expect(responseRow.content.every((p) => !isUsableSummaryPart(p))).toBe(true);
  });

  // A usable (finished) summary is the real checkpoint: owned by the compaction
  // AND still presentable as a finished summary (the finish-just-before-stop race
  // is not a failure). Distinguishes a correct fix from one that blanket-fails
  // every stopped summary — a fix that flags this summary failed would make it
  // unusable and trip the second assertion.
  it('keeps a finished summary as a real checkpoint', async () => {
    const usableSummary = {
      type: ContentTypes.SUMMARY,
      content: [{ type: ContentTypes.TEXT, text: 'A complete and usable summary.' }],
      boundary: { messageId: 'step_summary', contentIndex: 0 },
    };
    const { resp, responseRow } = await stopAndCapture({
      app,
      compact: true,
      content: [usableSummary],
      conversationId: '77777777-7777-4777-8777-777777777777',
      parentMessageId: '88888888-8888-4888-8888-888888888888',
    });

    expect(resp.status).toBe(200);
    expect(responseRow).toBeDefined();
    // identity present and the finished summary is still a usable checkpoint.
    expect(responseRow.content.some((p) => p.initiatedBy === 'user')).toBe(true);
    expect(responseRow.content.some((p) => isUsableSummaryPart(p))).toBe(true);
  });

  // An ordinary (non-compaction) stop is unchanged: no identity marker, no
  // synthesized failure, content persisted exactly as streamed.
  it('leaves an ordinary stopped generation unchanged', async () => {
    const partialText = { type: ContentTypes.TEXT, text: 'Partial answer' };
    const { resp, responseRow } = await stopAndCapture({
      app,
      compact: false,
      content: [partialText],
      conversationId: '99999999-9999-4999-8999-999999999999',
      parentMessageId: 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',
    });

    expect(resp.status).toBe(200);
    expect(responseRow).toBeDefined();
    expect(responseRow.content).toEqual([partialText]);
    expect(responseRow.content.every((p) => p.initiatedBy == null)).toBe(true);
    expect(responseRow.content.some((p) => p.type === ContentTypes.ERROR)).toBe(false);
  });
});
