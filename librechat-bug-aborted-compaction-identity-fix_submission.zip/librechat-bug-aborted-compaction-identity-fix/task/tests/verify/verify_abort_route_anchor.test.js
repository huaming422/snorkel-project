/**
 * The abort route's persistence of a stopped compaction must not re-write the
 * turn's anchor.
 *
 * For a compaction the recorded anchor is an already-persisted leaf that is only
 * referenced for identity; re-writing it is what erases a user message's text or
 * leaves an empty user row. So when the route persists a stopped compaction it
 * must write ONLY the aborted response row (parented onto the anchor id) and skip
 * the anchor prerequisite write. An ordinary aborted turn still performs the
 * anchor prerequisite write.
 *
 * The whole flow is driven from the public surfaces: a real agent generation is
 * started through the request controller (which records the compaction tag off
 * `req.body.compact`), and while that job is live a real HTTP POST to the abort
 * route stops it. Persistence is observed through a `saveMessage` spy — the test
 * asserts how many rows are written and their parent/identity shape, never how the
 * implementation stores its compaction marker.
 *
 * NOTE: the route imports `@librechat/api` from its built dist, so test-setup.sh
 * rebuilds the workspace before this runs; otherwise the route would exercise the
 * pre-fix behaviour.
 */
const express = require('express');
const request = require('supertest');
const { ContentTypes } = require('librechat-data-provider');

const mockSaveMessage = jest.fn(async (_ctx, m) => m);

jest.mock('@librechat/data-schemas', () => {
  const actual = jest.requireActual('@librechat/data-schemas');
  return {
    ...actual,
    logger: { debug: jest.fn(), info: jest.fn(), warn: jest.fn(), error: jest.fn() },
  };
});

jest.mock('@librechat/api', () => {
  const actual = jest.requireActual('@librechat/api');
  return {
    ...actual,
    isEnabled: jest.fn().mockReturnValue(false),
    isAgentTriggerRequest: jest.fn(() => false),
    captureScheduleFireContext: jest.fn((req) => {
      req._isScheduledFire = false;
      req._isManualScheduledFire = false;
    }),
    checkAndIncrementPendingRequest: jest.fn().mockResolvedValue({ allowed: true }),
    decrementPendingRequest: jest.fn(),
  };
});

jest.mock('~/models', () => {
  const actual = jest.requireActual('~/models');
  return {
    ...actual,
    initializeMessageBudget: jest.fn(),
    saveMessage: (...args) => mockSaveMessage(...args),
    getPersistedPrivateTextId: jest.fn().mockResolvedValue(null),
    getPrivateMessageTexts: jest.fn().mockResolvedValue([]),
    saveConvo: jest.fn().mockResolvedValue({}),
    getConvo: jest.fn().mockResolvedValue(null),
    getMessages: jest.fn().mockResolvedValue([]),
    isAgentTriggerPrincipalActive: jest.fn().mockReturnValue(true),
    isSubagentOwnerAdmissible: jest.fn().mockReturnValue(true),
  };
});

jest.mock('~/server/cleanup', () => ({ disposeClient: jest.fn() }));
jest.mock('~/server/services/MCPRequestContext', () => ({
  getMCPRequestContext: jest.fn().mockResolvedValue(null),
  cleanupMCPRequestContextForReq: jest.fn(),
}));
jest.mock('~/server/services/Schedules', () => ({
  recordScheduleOutcome: jest.fn().mockResolvedValue(true),
  beginScheduledStop: jest.fn().mockResolvedValue(true),
  acknowledgeScheduledStopPersistence: jest.fn().mockResolvedValue(undefined),
  isScheduleLive: jest.fn().mockReturnValue(false),
}));
jest.mock('~/server/middleware', () => ({
  uaParser: (q, s, n) => n(),
  checkBan: (q, s, n) => n(),
  requireJwtAuth: (q, s, n) => {
    q.user = { id: 'u-ok' };
    n();
  },
  moderateText: (q, s, n) => n(),
  agentEventUserLimiter: (q, s, n) => n(),
  messageIpLimiter: (q, s, n) => n(),
  configMiddleware: (q, s, n) => n(),
  messageUserLimiter: (q, s, n) => n(),
}));
jest.mock('~/server/routes/agents/chat', () => require('express').Router());
jest.mock('~/server/routes/agents/v1', () => ({ v1: require('express').Router() }));
jest.mock('~/server/routes/agents/management', () => require('express').Router());

const {
  GenerationJobManager,
  InMemoryJobStore,
  InMemoryEventTransport,
} = require('@librechat/api');
const ResumableAgentController = require('~/server/controllers/agents/request');
const agentRoutes = require('~/server/routes/agents/index');

function makeRes() {
  return {
    headersSent: false,
    statusCode: 200,
    status: jest.fn(function (c) {
      this.statusCode = c;
      return this;
    }),
    json: jest.fn(function () {
      return this;
    }),
    end: jest.fn(function () {
      return this;
    }),
    write: jest.fn(() => true),
    setHeader: jest.fn(),
    flushHeaders: jest.fn(),
    on: jest.fn(),
    removeListener: jest.fn(),
  };
}

/**
 * Start a real generation through the controller and, while it is live, stop it
 * with a real POST to the abort route. Returns the abort route's HTTP response.
 */
async function stopDuringGeneration({ app, compact, content, conversationId, parentMessageId }) {
  let abortResp;
  const req = {
    body: {
      text: '',
      ...(compact ? { compact: true } : {}),
      conversationId,
      parentMessageId,
      endpointOption: { endpoint: 'agents', modelOptions: { model: 'gpt-4.1' } },
    },
    config: { summarization: { enabled: true } },
    user: { id: 'u-ok' },
    on: jest.fn(),
    app: { locals: {} },
  };
  const initializeClient = async () => {
    GenerationJobManager.setContentParts(conversationId, content);
    abortResp = await request(app)
      .post('/api/agents/chat/abort')
      .set('X-LibreChat-Generation-Protocol', '2')
      .send({ conversationId, generationProtocolVersion: 2 });
    const stop = new Error('__stop__');
    stop.__stop = true;
    throw stop;
  };
  try {
    await ResumableAgentController(req, makeRes(), jest.fn(), initializeClient, jest.fn());
  } catch (e) {
    if (!e.__stop) {
      throw e;
    }
  }
  return abortResp;
}

describe('abort route — anchor handling for a stopped compaction', () => {
  let app;
  beforeAll(() => {
    app = express();
    app.use(express.json());
    app.use('/api/agents', agentRoutes);
  });
  beforeEach(() => {
    mockSaveMessage.mockClear();
    GenerationJobManager.configure({
      jobStore: new InMemoryJobStore(),
      eventTransport: new InMemoryEventTransport(),
      isRedis: false,
      cleanupOnComplete: false,
    });
    GenerationJobManager.initialize();
  });
  afterEach(async () => {
    await GenerationJobManager.destroy();
  });

  // A stopped compaction writes only the response row, parented onto the anchor
  // id; the anchor prerequisite write is skipped.
  it('persists only the response row and skips the anchor write', async () => {
    const parentMessageId = '22222222-2222-4222-8222-222222222222';
    const resp = await stopDuringGeneration({
      app,
      compact: true,
      content: [
        { type: ContentTypes.SUMMARY, content: [{ type: ContentTypes.TEXT, text: 'Half' }], summarizing: true },
      ],
      conversationId: '11111111-1111-4111-8111-111111111111',
      parentMessageId,
    });

    expect(resp.status).toBe(200);
    expect(mockSaveMessage).toHaveBeenCalledTimes(1);
    const saved = mockSaveMessage.mock.calls.map((c) => c[1]);
    // the single write is the response row, not a user anchor, parented onto the anchor id
    const responseRow = saved[0];
    expect(responseRow.isCreatedByUser).toBe(false);
    expect(responseRow.parentMessageId).toBe(parentMessageId);
    // no write re-creates/overwrites the user anchor
    expect(saved.some((m) => m.isCreatedByUser === true)).toBe(false);
  });

  // An ordinary aborted turn still writes the anchor prerequisite plus the
  // response row.
  it('still writes the anchor prerequisite for an ordinary aborted turn', async () => {
    const parentMessageId = '44444444-4444-4444-8444-444444444444';
    const resp = await stopDuringGeneration({
      app,
      compact: false,
      content: [{ type: ContentTypes.TEXT, text: 'Partial answer' }],
      conversationId: '33333333-3333-4333-8333-333333333333',
      parentMessageId,
    });

    expect(resp.status).toBe(200);
    expect(mockSaveMessage).toHaveBeenCalledTimes(2);
    const saved = mockSaveMessage.mock.calls.map((c) => c[1]);
    // the anchor prerequisite (a user row) is written
    const anchor = saved.find((m) => m.isCreatedByUser === true);
    expect(anchor).toBeDefined();
    // and the response row is parented onto that anchor
    const response = saved.find((m) => m.isCreatedByUser === false);
    expect(response).toBeDefined();
    expect(response.parentMessageId).toBe(anchor.messageId);
  });
});
