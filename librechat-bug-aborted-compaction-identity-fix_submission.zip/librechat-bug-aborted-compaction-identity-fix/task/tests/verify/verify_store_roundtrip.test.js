/**
 * The compaction identity must survive a round trip through the job store.
 *
 * The abort paths that settle a stopped turn read the job back from the store
 * (a reloaded job, not the in-process object). On a real deployment that reload
 * goes through the Redis hash serialize/deserialize. If the identity is set on
 * the live job but not carried across that round trip, the reloaded job looks
 * ordinary and the stopped turn is never stamped.
 *
 * This drives the same real-controller + real-abort-route stop as the content
 * test, but over a job store whose every reload is forced through the store's OWN
 * serialize → deserialize (the exact seam a Redis deployment uses). The abort
 * path reads the reloaded job to decide whether the turn is a compaction, so a
 * fix that sets the flag on the live job but never serializes it leaves the
 * reloaded job ordinary and the persisted content unmarked. The assertion is
 * purely observable — the persisted stopped row still carries the compaction
 * identity after the reload — so it isolates the round trip without reading any
 * stored field by name, and accepts an implementation that stamps the row either
 * in the library or in the route.
 */
const express = require('express');
const request = require('supertest');
const { ContentTypes } = require('librechat-data-provider');

const mockSaveMessage = jest.fn(async (_ctx, m) => m);

jest.mock('@librechat/data-schemas', () => {
  const actual = jest.requireActual('@librechat/data-schemas');
  return {
    ...actual,
    logger: { debug: jest.fn(), info: jest.fn(), warn: jest.fn(), error: jest.fn() },
  };
});

jest.mock('@librechat/api', () => {
  const actual = jest.requireActual('@librechat/api');
  return {
    ...actual,
    isEnabled: jest.fn().mockReturnValue(false),
    isAgentTriggerRequest: jest.fn(() => false),
    captureScheduleFireContext: jest.fn((req) => {
      req._isScheduledFire = false;
      req._isManualScheduledFire = false;
    }),
    checkAndIncrementPendingRequest: jest.fn().mockResolvedValue({ allowed: true }),
    decrementPendingRequest: jest.fn(),
  };
});

jest.mock('~/models', () => {
  const actual = jest.requireActual('~/models');
  return {
    ...actual,
    initializeMessageBudget: jest.fn(),
    saveMessage: (...args) => mockSaveMessage(...args),
    getPersistedPrivateTextId: jest.fn().mockResolvedValue(null),
    getPrivateMessageTexts: jest.fn().mockResolvedValue([]),
    saveConvo: jest.fn().mockResolvedValue({}),
    getConvo: jest.fn().mockResolvedValue(null),
    getMessages: jest.fn().mockResolvedValue([]),
    isAgentTriggerPrincipalActive: jest.fn().mockReturnValue(true),
    isSubagentOwnerAdmissible: jest.fn().mockReturnValue(true),
  };
});

jest.mock('~/server/cleanup', () => ({ disposeClient: jest.fn() }));
jest.mock('~/server/services/MCPRequestContext', () => ({
  getMCPRequestContext: jest.fn().mockResolvedValue(null),
  cleanupMCPRequestContextForReq: jest.fn(),
}));
jest.mock('~/server/services/Schedules', () => ({
  recordScheduleOutcome: jest.fn().mockResolvedValue(true),
  beginScheduledStop: jest.fn().mockResolvedValue(true),
  acknowledgeScheduledStopPersistence: jest.fn().mockResolvedValue(undefined),
  isScheduleLive: jest.fn().mockReturnValue(false),
}));
jest.mock('~/server/middleware', () => ({
  uaParser: (q, s, n) => n(),
  checkBan: (q, s, n) => n(),
  requireJwtAuth: (q, s, n) => {
    q.user = { id: 'u-ok' };
    n();
  },
  moderateText: (q, s, n) => n(),
  agentEventUserLimiter: (q, s, n) => n(),
  messageIpLimiter: (q, s, n) => n(),
  configMiddleware: (q, s, n) => n(),
  messageUserLimiter: (q, s, n) => n(),
}));
jest.mock('~/server/routes/agents/chat', () => require('express').Router());
jest.mock('~/server/routes/agents/v1', () => ({ v1: require('express').Router() }));
jest.mock('~/server/routes/agents/management', () => require('express').Router());

const {
  GenerationJobManager,
  InMemoryJobStore,
  InMemoryEventTransport,
  RedisJobStore,
  isUsableSummaryPart,
} = require('@librechat/api');
const ResumableAgentController = require('~/server/controllers/agents/request');
const agentRoutes = require('~/server/routes/agents/index');

/**
 * A job store that persists in memory but forces every reload through the real
 * Redis store's serialize/deserialize — the round trip a live Redis deployment
 * performs. We use the store's own (de)serialization rather than a hand-rolled
 * copy so the test tracks whatever fields the store actually carries across.
 */
function makeRoundTripStore() {
  const base = new InMemoryJobStore();
  let redis;
  try {
    redis = new RedisJobStore({ isCluster: false });
  } catch (e) {
    redis = null;
  }
  const origGetJob = base.getJob.bind(base);
  base.getJob = async (streamId) => {
    const job = await origGetJob(streamId);
    if (!job || !redis) {
      return job;
    }
    const serialized = redis['serializeJob'](job);
    // The reloaded job is purely what deserialize reconstructs from the wire
    // form — nothing from the live object leaks back, so the round trip is the
    // only thing under test.
    return redis['deserializeJob'](serialized);
  };
  return base;
}

function makeRes() {
  return {
    headersSent: false,
    statusCode: 200,
    status: jest.fn(function (c) {
      this.statusCode = c;
      return this;
    }),
    json: jest.fn(function () {
      return this;
    }),
    end: jest.fn(function () {
      return this;
    }),
    write: jest.fn(() => true),
    setHeader: jest.fn(),
    flushHeaders: jest.fn(),
    on: jest.fn(),
    removeListener: jest.fn(),
  };
}

/**
 * Start a real compaction generation and, while it is live, stop it with a real
 * POST to the abort route. The job store is the round-trip store, so the abort
 * path reads the reloaded job. Returns the persisted response row off the
 * `saveMessage` spy.
 */
async function stopAndCapture({ app, content, conversationId, parentMessageId }) {
  let abortResp;
  const req = {
    body: {
      text: '',
      compact: true,
      conversationId,
      parentMessageId,
      endpointOption: { endpoint: 'agents', modelOptions: { model: 'gpt-4.1' } },
    },
    config: { summarization: { enabled: true } },
    user: { id: 'u-ok' },
    on: jest.fn(),
    app: { locals: {} },
  };
  const initializeClient = async () => {
    GenerationJobManager.setContentParts(conversationId, content);
    abortResp = await request(app)
      .post('/api/agents/chat/abort')
      .set('X-LibreChat-Generation-Protocol', '2')
      .send({ conversationId, generationProtocolVersion: 2 });
    const stop = new Error('__stop__');
    stop.__stop = true;
    throw stop;
  };
  try {
    await ResumableAgentController(req, makeRes(), jest.fn(), initializeClient, jest.fn());
  } catch (e) {
    if (!e.__stop) {
      throw e;
    }
  }
  const saved = mockSaveMessage.mock.calls.map((c) => c[1]);
  const responseRow = saved.find((m) => m.isCreatedByUser === false);
  return { resp: abortResp, responseRow };
}

describe('compaction identity survives a job-store round trip', () => {
  let app;
  let store;
  beforeAll(() => {
    app = express();
    app.use(express.json());
    app.use('/api/agents', agentRoutes);
  });
  beforeEach(() => {
    mockSaveMessage.mockClear();
    store = makeRoundTripStore();
    GenerationJobManager.configure({
      jobStore: store,
      eventTransport: new InMemoryEventTransport(),
      isRedis: false,
      cleanupOnComplete: false,
    });
    GenerationJobManager.initialize();
  });
  afterEach(async () => {
    await GenerationJobManager.destroy();
  });

  // After the job is reloaded through the store's own serialize/deserialize, the
  // stopped compaction's turn still carries the identity and still presents no
  // usable checkpoint. A fix that never serializes the identity leaves the
  // reloaded job ordinary and the persisted content unmarked here — regardless of
  // whether the implementation keeps the truncated partial or drops it for a typed
  // failure (both are accepted; this test isolates the round trip).
  it('still stamps the stopped turn after the job reloads through the store', async () => {
    const partialSummary = {
      type: ContentTypes.SUMMARY,
      content: [{ type: ContentTypes.TEXT, text: 'Half a summary' }],
      summarizing: true,
    };
    const { resp, responseRow } = await stopAndCapture({
      app,
      conversationId: '11111111-1111-4111-8111-111111111111',
      parentMessageId: '22222222-2222-4222-8222-222222222222',
      content: [partialSummary],
    });

    expect(resp.status).toBe(200);
    expect(responseRow).toBeDefined();
    // identity survives the round trip: some content part carries the marker.
    expect(responseRow.content.some((p) => p.initiatedBy === 'user')).toBe(true);
    // no usable checkpoint survives: the truncated prefix is never offered as a
    // finished summary after the reload.
    expect(responseRow.content.every((p) => !isUsableSummaryPart(p))).toBe(true);
  });
});
