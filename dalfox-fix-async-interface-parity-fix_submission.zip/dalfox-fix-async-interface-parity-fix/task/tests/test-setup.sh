#!/usr/bin/env bash
# Test-setup for dalfox-fix-async-interface-parity.
#
# Sourced by tests/test.sh before every verifier (inherits set -euo pipefail).
# The image baked the full Cargo dependency closure at the base commit and
# pre-built `cargo build --locked --tests`, so the registry cache under
# $CARGO_HOME and the compiled target dir are already warm. The oracle
# introduces no new crates (no Cargo.toml/Cargo.lock change), so nothing needs
# to be resolved or fetched at grade time — the verifier build is offline-ready
# out of the image.
#
# No services to start, no data to seed: the behavioral verifier stands up its
# own in-process mock targets, blind-XSS callback sink, and launches
# `dalfox server` / `dalfox mcp` itself.

set -euo pipefail

cd /repo/dalfox

echo "[test-setup] Rust version:   $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:  $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Workspace root: /repo/dalfox"
echo "[test-setup] Setup complete."
