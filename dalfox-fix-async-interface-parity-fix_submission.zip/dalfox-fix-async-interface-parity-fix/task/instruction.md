## Task

we drive dalfox through its http api server and its mcp tool interface, and both have drifted away from the cli, which we trust. the behavior you get is wrong in ways that depend on the front-end.

the api and mcp accept targets that aren't real http(s) urls (bare hostnames, other schemes) and kick off scans that go nowhere, instead of rejecting them up front. a genuinely unreachable target comes back as a clean "done, no findings" rather than an error, so we can't tell a clean target from one we never reached. blind-xss scans launched over mcp never fire the out-of-band callback even when we pass a callback url, though the cli fires it fine. while a scan runs, the live progress counter stays stuck at zero, then jumps to the total only once the scan has finished. a numeric scan option passed as text (a worker count, a delay, a timeout) gets swallowed without a word, the scan running on defaults rather than the request being refused up front. and every so often two scans submitted close together land on the same scan id, clobbering one another.

none of this happens on the cli, which gets it all right. bring the server and mcp paths in line with it.
