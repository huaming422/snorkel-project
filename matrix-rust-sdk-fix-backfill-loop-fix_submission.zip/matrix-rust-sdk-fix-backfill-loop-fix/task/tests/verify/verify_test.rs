//! Behavioral tests for the latest-event / history-trimming interaction.
//!
//! Everything here drives the PUBLIC, pre-existing surface that the crate's own
//! `tests/integration/latest_event.rs` uses:
//!
//!   * `Client::latest_events()` →
//!     `LatestEvents::listen_and_subscribe_to_room(room_id)` →
//!     a `Subscriber<LatestEventValue>`;
//!   * a `MemoryStore`-backed event cache seeded directly with chunks via
//!     `EventCacheStore::handle_linked_chunk_updates` (same technique as the
//!     crate's integration + unit tests);
//!   * `MatrixMockServer`, whose underlying wiremock server records every
//!     `/messages` request, so a scheduled background history fetch is
//!     observable as a request count — no reference to any internal symbol.
//!
//! None of the tests import or name anything the reference change introduces
//! (no parameter, no outcome variant, no module constant). They observe only
//! behaviour: whether a history fetch is scheduled, and which value resolves.
//!
//! Decoupling / fairness rationale for the primary test
//! (`test_no_history_fetch_when_candidate_search_is_bounded`):
//!   * It asserts that after the in-memory slice holds no displayable
//!     candidate, and the search would otherwise have to walk a long run of
//!     stored chunks before any gap, NO `/messages` request is scheduled. A
//!     correct solution bounds that walk and concludes "nothing more to pull";
//!     the buggy behaviour walks to the far gap and schedules a fetch (which,
//!     because the room keeps being trimmed, repeats).
//!   * The far gap is placed FAR deeper (50 chunks) than any plausible small
//!     bound, so the test does not assume a specific bound value: whether the
//!     search is limited to 5, 10, or 20 stored chunks, it still stops before
//!     the gap and schedules nothing. A solution that expresses the limit as a
//!     constant, an associated const, a configurable field, with or without a
//!     dedicated outcome value, all pass — the test only reads the observable
//!     consequence (no request), never the mechanism.
//!   * It asserts the count is zero rather than inspecting any value shape, so
//!     a solution is free to resolve the value however it likes.

use assert_matches::assert_matches;
use matrix_sdk::{
    cross_process_lock::CrossProcessLockConfig,
    latest_events::LatestEventValue,
    linked_chunk::{ChunkIdentifier, LinkedChunkId, Position, Update},
    store::StoreConfig,
    test_utils::mocks::{MatrixMockServer, RoomMessagesResponseTemplate},
    Client,
};
use matrix_sdk_base::event_cache::{
    store::{EventCacheStore, MemoryStore},
    Gap,
};
use matrix_sdk_test::{async_test, event_factory::EventFactory};
use ruma::{event_id, owned_room_id, room_id, user_id};
use tokio::time::{sleep, timeout, Duration};

/// Build a client with automatic background history fetching enabled, on top of
/// a pre-seeded in-memory event-cache store. Mirrors the setup used by the
/// crate's own latest-event integration test, plus the builder switch that
/// turns on background history fetching (off by default).
async fn client_with_store(server: &MatrixMockServer, store: MemoryStore) -> Client {
    server
        .client_builder()
        .on_builder(|builder| {
            builder.with_enable_automatic_back_pagination(true).store_config(
                StoreConfig::new(CrossProcessLockConfig::MultiProcess {
                    holder_name: "test".to_owned(),
                })
                .event_cache_store(store),
            )
        })
        .build()
        .await
}

/// Count the `/messages` (history fetch) requests the server has seen so far,
/// optionally restricted to those paginating from a particular token (the
/// `from=` query parameter). Restricting by token isolates the fetch triggered
/// by one specific gap from any unrelated background pagination.
async fn history_fetch_count(server: &MatrixMockServer, from_token: Option<&str>) -> usize {
    server
        .server()
        .received_requests()
        .await
        .unwrap_or_default()
        .iter()
        .filter(|r| r.url.path().ends_with("/messages"))
        .filter(|r| match from_token {
            None => true,
            Some(token) => {
                r.url.query_pairs().any(|(k, v)| k == "from" && v == token)
            }
        })
        .count()
}

/// After the in-memory slice holds no displayable candidate and the only gap
/// sits far deeper than any sane search bound, recomputing the latest event
/// must NOT schedule a background history fetch. The buggy behaviour walks all
/// the way to that far gap, concludes "need more history", and schedules a
/// fetch — which, because the room keeps being trimmed, never settles.
#[async_test]
async fn test_no_history_fetch_when_candidate_search_is_bounded() {
    let room_id = owned_room_id!("!r0");
    let sender = user_id!("@bob:example.org");
    let f = EventFactory::new().room(&room_id).sender(sender);

    // Store layout (oldest -> newest):
    //   [gap] <- [reaction] <- [reaction] <- ... (50 of them) ... <- [reaction]
    // Only the newest chunk is reloaded in memory; it holds a reaction, which
    // is not a displayable candidate. No candidate exists anywhere, and the
    // single gap is 50 stored chunks back — deeper than any small search bound.
    const DEEP_CHUNKS: u64 = 50;

    let store = MemoryStore::new();
    let mut updates = vec![Update::NewGapChunk {
        previous: None,
        new: ChunkIdentifier::new(0),
        next: None,
        gap: Gap { token: "deep".to_owned() },
    }];
    for i in 1..=DEEP_CHUNKS {
        updates.push(Update::NewItemsChunk {
            previous: Some(ChunkIdentifier::new(i - 1)),
            new: ChunkIdentifier::new(i),
            next: None,
        });
        updates.push(Update::PushItems {
            at: Position::new(ChunkIdentifier::new(i), 0),
            items: vec![f
                .reaction(event_id!("$target"), "+1")
                .event_id(&ruma::EventId::parse(format!("$r{i}")).unwrap())
                .into_event()],
        });
    }
    store.handle_linked_chunk_updates(LinkedChunkId::Room(&room_id), updates).await.unwrap();

    let server = MatrixMockServer::new().await;
    let client = client_with_store(&server, store).await;

    // Bring the room into existence without seeding any timeline events or
    // read receipts (which could trigger an unrelated history fetch).
    let _room = server.sync_joined_room(&client, &room_id).await;

    // Subscribing with a restored `None` value triggers a recomputation from
    // the event cache (the natural update that would otherwise schedule a
    // fetch). No displayable candidate exists, so the value stays `None`.
    let mut stream = client
        .latest_events()
        .await
        .unwrap()
        .listen_and_subscribe_to_room(&room_id)
        .await
        .unwrap()
        .unwrap();

    assert_matches!(stream.next_now().await, LatestEventValue::None);

    // Give the background machinery time to run the computation and, if it were
    // going to, enqueue and fire a history fetch.
    sleep(Duration::from_millis(500)).await;

    assert_eq!(
        history_fetch_count(&server, Some("deep")).await,
        0,
        "a background history fetch was scheduled even though the candidate \
         search should have stopped before the far gap"
    );
}

/// A room whose only chunk is a gap, with a displayable event waiting behind
/// it, must still fetch history and resolve to that event. Guards against a
/// solution that stops the runaway fetching by disabling background history
/// fetching altogether. (Mirrors the pre-existing
/// `test_update_with_event_cache_backfills_for_a_candidate`.)
#[async_test]
async fn test_genuine_gap_still_fetches_history() {
    let room_id = room_id!("!r0");
    let sender = user_id!("@bob:example.org");
    let f = EventFactory::new().room(room_id).sender(sender);

    // A single gap: nothing in memory to show, but a token to fetch from.
    let store = MemoryStore::new();
    store
        .handle_linked_chunk_updates(
            LinkedChunkId::Room(room_id),
            vec![Update::NewGapChunk {
                previous: None,
                new: ChunkIdentifier::new(0),
                next: None,
                gap: Gap { token: "prev_batch".to_owned() },
            }],
        )
        .await
        .unwrap();

    let server = MatrixMockServer::new().await;
    let client = client_with_store(&server, store).await;

    // A displayable message lives behind the gap.
    server
        .mock_room_messages()
        .match_from("prev_batch")
        .ok(RoomMessagesResponseTemplate::default()
            .events(vec![f.text_msg("hello").event_id(event_id!("$1"))]))
        .mock_once()
        .mount()
        .await;

    let _room = server.sync_joined_room(&client, room_id).await;

    let mut stream = client
        .latest_events()
        .await
        .unwrap()
        .listen_and_subscribe_to_room(room_id)
        .await
        .unwrap()
        .unwrap();

    // The history fetch surfaces the message in the background; the latest
    // event eventually resolves to it. Poll the current value to a deadline so
    // a solution that never resolves fails fast instead of hanging.
    let resolved = timeout(Duration::from_secs(10), async {
        loop {
            if let LatestEventValue::Remote(event) = stream.next_now().await {
                assert_eq!(event.event_id().as_deref(), Some(event_id!("$1")));
                return;
            }
            sleep(Duration::from_millis(25)).await;
        }
    })
    .await;
    assert!(
        resolved.is_ok(),
        "the latest event never resolved to the event behind the genuine gap"
    );
}

/// A displayable candidate that lives in a stored (not-in-memory) chunk a short
/// way back is used as-is, with no history fetch. (Mirrors the pre-existing
/// `test_update_with_event_cache_uses_a_stored_candidate_without_backfilling`.)
#[async_test]
async fn test_stored_candidate_used_without_fetch() {
    let room_id = owned_room_id!("!r0");
    let sender = user_id!("@bob:example.org");
    let f = EventFactory::new().room(&room_id).sender(sender);

    // Older chunk: a displayable candidate. Newest (in-memory) chunk: only a
    // reaction, which is not displayable.
    let store = MemoryStore::new();
    store
        .handle_linked_chunk_updates(
            LinkedChunkId::Room(&room_id),
            vec![
                Update::NewItemsChunk { previous: None, new: ChunkIdentifier::new(0), next: None },
                Update::PushItems {
                    at: Position::new(ChunkIdentifier::new(0), 0),
                    items: vec![f.text_msg("hello").event_id(event_id!("$1")).into_event()],
                },
                Update::NewItemsChunk {
                    previous: Some(ChunkIdentifier::new(0)),
                    new: ChunkIdentifier::new(1),
                    next: None,
                },
                Update::PushItems {
                    at: Position::new(ChunkIdentifier::new(1), 0),
                    items: vec![f
                        .reaction(event_id!("$1"), "+1")
                        .event_id(event_id!("$2"))
                        .into_event()],
                },
            ],
        )
        .await
        .unwrap();

    let server = MatrixMockServer::new().await;
    let client = client_with_store(&server, store).await;

    let _room = server.sync_joined_room(&client, &room_id).await;

    let mut stream = client
        .latest_events()
        .await
        .unwrap()
        .listen_and_subscribe_to_room(&room_id)
        .await
        .unwrap()
        .unwrap();

    // The latest event resolves to the stored candidate. Poll the current value
    // to a deadline so a solution that never resolves fails fast instead of
    // hanging (the candidate is served from the store without any background
    // fetch, so it may already be set by the time we first look).
    let resolved = timeout(Duration::from_secs(10), async {
        loop {
            if let LatestEventValue::Remote(event) = stream.next_now().await {
                assert_eq!(event.event_id().as_deref(), Some(event_id!("$1")));
                return;
            }
            sleep(Duration::from_millis(25)).await;
        }
    })
    .await;
    assert!(resolved.is_ok(), "the latest event never resolved to the stored candidate");

    // Allow any (wrongly) scheduled history fetch to fire, then confirm none
    // did: the stored candidate was used directly.
    sleep(Duration::from_millis(300)).await;
    assert_eq!(
        history_fetch_count(&server, None).await,
        0,
        "a history fetch was scheduled despite a usable stored candidate"
    );
}
