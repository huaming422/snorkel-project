## Task

on some accounts the client gets stuck hammering the server for room history in
the background. for certain rooms it keeps firing off back-pagination requests
one after another in a tight loop, and nothing useful ever comes back. the rooms
it does this to already have a perfectly good recent message to show in the room
list, so there's no reason to be reaching further back at all.

it seems to kick in after a room's history has been sitting in memory for a while
and then gets trimmed down. before that the room behaves fine.

dig into why these rooms fall into a runaway back-pagination loop and stop it. a
room that genuinely needs older history still has to be able to page back for it.
