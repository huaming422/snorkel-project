## Task

Heads up: the event object our Menu, Combobox, and Autocomplete hand to the `onItemHighlighted` callback is useless whenever the highlight moves by keyboard or pointer. After arrow-keying through the list, the event has no key on it, and calling the usual keyboard-event method on it throws, so a handler can't tell which key moved the highlight or read modifier state. It's meant to be the real interaction event matching the reported reason, a keyboard event for a `'keyboard'` highlight and a pointer/mouse event for a `'pointer'` one, but it's a throwaway placeholder instead.

This isn't only arrow keys: type-to-match, hovering, and the menu's filterable and submenu paths all go through the same broken spot. Dig into why the callback receives a placeholder, and make every interactive highlight report the actual native event that caused it, matching the reason it reports.
