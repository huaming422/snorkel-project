// Behavioral verifier for the item-highlight notification's originating event.
//
// Every assertion here goes through the public `onItemHighlighted(value,
// details)` callback exposed by Menu, Combobox, and Autocomplete. The callback,
// its `details.reason` string union ('keyboard' | 'pointer' | 'imperative-action'
// | 'none'), and `details.event` are the documented public contract; this file
// touches no internal store method, helper, ref, or module. Reason values are
// written as plain string literals on purpose — the public surface speaks those
// strings, so the verifier stays stable across any internal threading choice a
// solution makes.
//
// Rendering uses the repo's own `createRenderer()` harness (the same one every
// sibling *.test.tsx uses), which returns a `user` event driver and runs under
// jsdom (VITEST_ENV=jsdom, set by tests/test-setup.sh).

import { expect, vi, describe, it } from 'vitest';
import * as React from 'react';
import { act, fireEvent, screen, waitFor } from '@mui/internal-test-utils';
import { createRenderer } from '#test-utils';
import { Menu } from '@base-ui/react/menu';
import { Combobox } from '@base-ui/react/combobox';
import { Autocomplete } from '@base-ui/react/autocomplete';

describe('onItemHighlighted originating event', () => {
  const { render } = createRenderer();

  // A small Menu with two plain items plus a submenu trigger, covering the
  // keyboard, typeahead, item-hover, and submenu-hover entry points.
  function HighlightMenu(props: {
    onItemHighlighted: Menu.Root.Props['onItemHighlighted'];
  }) {
    return (
      <Menu.Root onItemHighlighted={props.onItemHighlighted}>
        <Menu.Trigger>Toggle</Menu.Trigger>
        <Menu.Portal>
          <Menu.Positioner>
            <Menu.Popup>
              <Menu.Item>One</Menu.Item>
              <Menu.Item>Two</Menu.Item>
              <Menu.SubmenuRoot>
                <Menu.SubmenuTrigger>Three</Menu.SubmenuTrigger>
                <Menu.Portal>
                  <Menu.Positioner>
                    <Menu.Popup>
                      <Menu.Item>Nested</Menu.Item>
                    </Menu.Popup>
                  </Menu.Positioner>
                </Menu.Portal>
              </Menu.SubmenuRoot>
            </Menu.Popup>
          </Menu.Positioner>
        </Menu.Portal>
      </Menu.Root>
    );
  }

  it('keyboard_event_real', async () => {
    const onItemHighlighted = vi.fn();
    const { user } = await render(
      <HighlightMenu onItemHighlighted={onItemHighlighted} />,
    );

    const trigger = screen.getByRole('button', { name: 'Toggle' });
    await act(async () => {
      trigger.focus();
    });
    await user.keyboard('[Enter]');
    await waitFor(() => {
      expect(screen.getByRole('menuitem', { name: 'One' })).toHaveFocus();
    });

    await user.keyboard('{ArrowDown}');
    await waitFor(() => {
      expect(screen.getByRole('menuitem', { name: 'Two' })).toHaveFocus();
    });

    const details = onItemHighlighted.mock.lastCall?.[1];
    expect(details.reason).toBe('keyboard');
    // The real native keydown must be threaded through, not a placeholder:
    // a placeholder is not a KeyboardEvent and exposes no `key`.
    expect(details.event).toBeInstanceOf(KeyboardEvent);
    expect(details.event.key).toBe('ArrowDown');
  });

  it('typeahead_event_real', async () => {
    const onItemHighlighted = vi.fn();
    const { user } = await render(
      <HighlightMenu onItemHighlighted={onItemHighlighted} />,
    );

    const trigger = screen.getByRole('button', { name: 'Toggle' });
    await act(async () => {
      trigger.focus();
    });
    await user.keyboard('[Enter]');
    await waitFor(() => {
      expect(screen.getByRole('menuitem', { name: 'One' })).toHaveFocus();
    });

    // Type-to-match is a distinct highlight entry point from arrow navigation;
    // a fix that threads only arrow keys misses this call site.
    await user.keyboard('t');
    await waitFor(() => {
      expect(screen.getByRole('menuitem', { name: 'Two' })).toHaveFocus();
    });

    const details = onItemHighlighted.mock.lastCall?.[1];
    expect(details.reason).toBe('keyboard');
    expect(details.event).toBeInstanceOf(KeyboardEvent);
    expect(details.event.key).toBe('t');
  });

  it('pointer_event_real', async () => {
    const onItemHighlighted = vi.fn();
    await render(<HighlightMenu onItemHighlighted={onItemHighlighted} />);

    fireEvent.click(screen.getByRole('button', { name: 'Toggle' }));
    const item = await screen.findByRole('menuitem', { name: 'Two' });

    // Hovering an item supplies a native MouseEvent — the exact dispatched
    // object must be reported, and it must NOT be coerced to a PointerEvent.
    const hoverEvent = new MouseEvent('mousemove', { bubbles: true });
    fireEvent(item, hoverEvent);
    await waitFor(() => {
      expect(onItemHighlighted).toHaveBeenLastCalledWith(item, expect.anything());
    });

    let details = onItemHighlighted.mock.lastCall?.[1];
    expect(details.reason).toBe('pointer');
    expect(details.event).toBeInstanceOf(MouseEvent);
    expect(details.event).toBe(hoverEvent);
    expect(details.event).not.toBeInstanceOf(PointerEvent);

    // Leaving an item supplies a native PointerEvent — the 'pointer' reason's
    // public event type must accept both a MouseEvent and a PointerEvent.
    // (Leaving also moves the highlight off the item, so assert on the
    // originating event of the latest notification rather than its value.)
    const leaveEvent = new PointerEvent('pointerout', {
      bubbles: true,
      pointerType: 'mouse',
    });
    fireEvent(item, leaveEvent);
    await waitFor(() => {
      expect(onItemHighlighted.mock.lastCall?.[1]?.event).toBe(leaveEvent);
    });
    details = onItemHighlighted.mock.lastCall?.[1];
    expect(details.reason).toBe('pointer');
    expect(details.event).toBeInstanceOf(PointerEvent);
  });

  it('combobox_autocomplete_event_real', async () => {
    // Combobox and Autocomplete route highlights through a different root than
    // Menu and previously used an input-mode heuristic; a Menu-only fix leaves
    // these on the placeholder. Both must carry the real keydown.
    const comboboxHighlighted = vi.fn();
    const combobox = await render(
      <Combobox.Root items={['a', 'b', 'c']} onItemHighlighted={comboboxHighlighted}>
        <Combobox.Input data-testid="combobox-input" />
        <Combobox.Portal>
          <Combobox.Positioner>
            <Combobox.Popup>
              <Combobox.List>
                {(item: string) => (
                  <Combobox.Item key={item} value={item}>
                    {item}
                  </Combobox.Item>
                )}
              </Combobox.List>
            </Combobox.Popup>
          </Combobox.Positioner>
        </Combobox.Portal>
      </Combobox.Root>,
    );

    await combobox.user.click(screen.getByTestId('combobox-input'));
    await waitFor(() => expect(screen.getByRole('listbox')).not.toBe(null));
    await combobox.user.keyboard('{ArrowDown}');
    await waitFor(() => {
      expect(comboboxHighlighted.mock.calls.length).toBeGreaterThan(0);
    });

    const [comboboxValue, comboboxDetails] = comboboxHighlighted.mock.lastCall ?? [];
    expect(comboboxValue).toBe('a');
    expect(comboboxDetails.reason).toBe('keyboard');
    expect(comboboxDetails.event).toBeInstanceOf(KeyboardEvent);
    expect(comboboxDetails.event.key).toBe('ArrowDown');

    combobox.unmount();

    const autocompleteHighlighted = vi.fn();
    const autocomplete = await render(
      <Autocomplete.Root
        items={['alpha', 'beta', 'gamma']}
        onItemHighlighted={autocompleteHighlighted}
      >
        <Autocomplete.Input data-testid="autocomplete-input" />
        <Autocomplete.Portal>
          <Autocomplete.Positioner>
            <Autocomplete.Popup>
              <Autocomplete.List>
                {(item: string) => (
                  <Autocomplete.Item key={item} value={item}>
                    {item}
                  </Autocomplete.Item>
                )}
              </Autocomplete.List>
            </Autocomplete.Popup>
          </Autocomplete.Positioner>
        </Autocomplete.Portal>
      </Autocomplete.Root>,
    );

    const autocompleteInput =
      screen.getByTestId<HTMLInputElement>('autocomplete-input');
    // Focus the input, then open + navigate with ArrowDown so the highlight is
    // keyboard-driven (no pointer event involved).
    await act(async () => {
      autocompleteInput.focus();
    });
    // First ArrowDown opens the popup; a follow-up ArrowDown drives an
    // unambiguous keyboard highlight, so a highlight notification is emitted
    // and its originating event must be the real keydown.
    await autocomplete.user.keyboard('{ArrowDown}');
    await screen.findByRole('option', { name: 'alpha' });
    await autocomplete.user.keyboard('{ArrowDown}');
    await waitFor(() => {
      expect(autocompleteHighlighted.mock.calls.length).toBeGreaterThan(0);
    });

    const autocompleteDetails = autocompleteHighlighted.mock.lastCall?.[1];
    expect(autocompleteDetails.reason).toBe('keyboard');
    expect(autocompleteDetails.event).toBeInstanceOf(KeyboardEvent);
    expect(autocompleteDetails.event.key).toBe('ArrowDown');
  });

  it('noninteractive_reason_none', async () => {
    // A highlight with no originating interaction (the popup auto-highlighting
    // on open) must report 'none' and must NOT fabricate a keyboard/pointer
    // event. This holds both before and after the fix — the non-interactive
    // path already reported 'none'; the fix must not break it by synthesizing
    // an event for every highlight.
    const onItemHighlighted = vi.fn();
    const { user } = await render(
      <Autocomplete.Root
        items={['alpha', 'alpine', 'beta']}
        autoHighlight
        onItemHighlighted={onItemHighlighted}
      >
        <Autocomplete.Input data-testid="input" />
        <Autocomplete.Portal>
          <Autocomplete.Positioner>
            <Autocomplete.Popup>
              <Autocomplete.List>
                {(item: string) => (
                  <Autocomplete.Item key={item} value={item}>
                    {item}
                  </Autocomplete.Item>
                )}
              </Autocomplete.List>
            </Autocomplete.Popup>
          </Autocomplete.Positioner>
        </Autocomplete.Portal>
      </Autocomplete.Root>,
    );

    const input = screen.getByTestId<HTMLInputElement>('input');
    await user.type(input, 'a');

    await screen.findByRole('option', { name: 'alpha' });
    await waitFor(() => {
      expect(onItemHighlighted.mock.calls.length).toBeGreaterThan(0);
    });

    const [value, details] = onItemHighlighted.mock.lastCall ?? [];
    expect(value).toBe('alpha');
    expect(details.reason).toBe('none');
  });

  it('filterable_menu_keyboard_event_real', async () => {
    // The filterable menu's own input keydown is a separate highlight entry
    // point (its own key handler), distinct from the plain Menu's list
    // navigation. A fix that threads the plain paths but misses the filter
    // input leaves this one on the placeholder. Drive it through the public
    // Menu.Input of an open filterable menu.
    const onItemHighlighted = vi.fn();
    const { user } = await render(
      <Menu.FilterProvider>
        <Menu.Root open onItemHighlighted={onItemHighlighted}>
          <Menu.Portal>
            <Menu.Positioner>
              <Menu.Popup>
                <Menu.Input aria-label="Filter actions" />
                <Menu.List>
                  <Menu.Item>Rename</Menu.Item>
                  <Menu.Item>Delete</Menu.Item>
                </Menu.List>
              </Menu.Popup>
            </Menu.Positioner>
          </Menu.Portal>
        </Menu.Root>
      </Menu.FilterProvider>,
    );

    const input = screen.getByRole('searchbox', { name: 'Filter actions' });
    await act(async () => {
      input.focus();
    });
    await user.keyboard('[ArrowDown]');

    await waitFor(() => {
      expect(onItemHighlighted).toHaveBeenLastCalledWith(
        screen.getByRole('menuitem', { name: 'Rename' }),
        expect.anything(),
      );
    });

    const details = onItemHighlighted.mock.lastCall?.[1];
    expect(details.reason).toBe('keyboard');
    expect(details.event).toBeInstanceOf(KeyboardEvent);
    expect(details.event.key).toBe('ArrowDown');
  });

  // A small Combobox whose items all contain 'a', so typing 'a' after a
  // keyboard highlight clears the active item without emptying the list.
  function ClearableCombobox(props: {
    onItemHighlighted: Combobox.Root.Props<string>['onItemHighlighted'];
  }) {
    return (
      <Combobox.Root
        items={['apple', 'apricot', 'banana']}
        onItemHighlighted={props.onItemHighlighted}
      >
        <Combobox.Input data-testid="input" />
        <Combobox.Portal>
          <Combobox.Positioner>
            <Combobox.Popup>
              <Combobox.List>
                {(item: string) => (
                  <Combobox.Item key={item} value={item}>
                    {item}
                  </Combobox.Item>
                )}
              </Combobox.List>
            </Combobox.Popup>
          </Combobox.Positioner>
        </Combobox.Portal>
      </Combobox.Root>
    );
  }

  it('clear_highlight_event_not_placeholder', async () => {
    // Clearing a keyboard highlight by typing is another interactive highlight
    // change, routed through a separate call site from list navigation. It must
    // carry the real originating event, never the throwaway placeholder — and
    // whatever reason it reports, the event must match that reason. This stays
    // agnostic about WHICH reason a solution assigns to the type-to-clear
    // transition: it accepts a real keyboard event under a 'keyboard' reason, or
    // a non-interactive 'none'. What it rejects is the broken placeholder — a
    // 'keyboard' reason whose event is not a real KeyboardEvent.
    const onItemHighlighted = vi.fn();
    const { user } = await render(
      <ClearableCombobox onItemHighlighted={onItemHighlighted} />,
    );

    await user.click(screen.getByTestId('input'));
    await user.keyboard('{ArrowDown}');
    await waitFor(() => {
      expect(onItemHighlighted).toHaveBeenLastCalledWith('apple', expect.anything());
    });

    await user.keyboard('a');
    await waitFor(() => {
      expect(onItemHighlighted).toHaveBeenLastCalledWith(undefined, expect.anything());
    });

    const details = onItemHighlighted.mock.lastCall?.[1];
    if (details.reason === 'keyboard') {
      // If it claims a keyboard reason, it must carry the real keydown, with a
      // readable `key` — not the placeholder whose `key` is undefined.
      expect(details.event).toBeInstanceOf(KeyboardEvent);
      expect(typeof details.event.key).toBe('string');
    } else {
      // Otherwise the only contract-consistent classification is 'none'
      // (typing is neither list navigation nor a pointer interaction).
      expect(details.reason).toBe('none');
    }
  });

  it('submenu_hover_pointer', async () => {
    // Hovering a submenu trigger is a distinct pointer entry point from plain
    // item hover; it must report 'pointer' with a real MouseEvent.
    const onItemHighlighted = vi.fn();
    await render(<HighlightMenu onItemHighlighted={onItemHighlighted} />);

    fireEvent.click(screen.getByRole('button', { name: 'Toggle' }));
    const submenuTrigger = await screen.findByRole('menuitem', { name: 'Three' });
    fireEvent.mouseEnter(submenuTrigger);
    await waitFor(() => {
      expect(onItemHighlighted).toHaveBeenLastCalledWith(
        submenuTrigger,
        expect.anything(),
      );
    });

    const details = onItemHighlighted.mock.lastCall?.[1];
    expect(details.reason).toBe('pointer');
    expect(details.event).toBeInstanceOf(MouseEvent);
  });
});
