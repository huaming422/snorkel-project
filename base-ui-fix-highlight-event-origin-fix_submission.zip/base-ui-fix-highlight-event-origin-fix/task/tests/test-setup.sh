#!/usr/bin/env bash
# Environment bootstrap for the verifier. Sourced (not exec'd) by the harbor
# runner so env vars set here stay live for the verifier subprocess.
#
# The agent phase is offline and the image already carries the full dependency
# closure at the base commit (node_modules + warm pnpm store), so nothing here
# needs the network on the happy path. The one fallback (a corrupted
# node_modules from an agent edit) is offline-first with a logged online retry.
#
# The harbor JS runner reads verify.toml with tomllib, which ships with the
# canonical /opt/tooling verifier venv (Python 3.11+) that executes the runner,
# so no tomli install is needed here.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/base-ui}"
export REPO_DIR
cd "$REPO_DIR"

# The verifier runs under jsdom (no real browser); the shared vitest config
# branches on VITEST_ENV and only enables the jsdom environment for this value.
export VITEST_ENV=jsdom
export TZ=UTC

# vitest must be resolvable from the workspace root; a miss means a corrupted
# node_modules from an agent edit. Reinstall from the warm store (offline-first,
# no network on the happy path) rather than failing later with "command not
# found". Fall back to an online install only if the offline store is missing a
# package, and log loudly on hard failure.
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest binary missing from node_modules/.bin/." \
         "The checkout looks corrupt — re-installing from the warm pnpm store." >&2
    if pnpm install --offline --frozen-lockfile --ignore-scripts > /tmp/reinstall.log 2>&1; then
        echo "test-setup.sh: offline reinstall succeeded." >&2
    else
        echo "test-setup.sh: offline reinstall failed; retrying online." >&2
        pnpm install --frozen-lockfile --ignore-scripts > /tmp/reinstall.log 2>&1 \
            || { tail -40 /tmp/reinstall.log >&2; exit 1; }
    fi
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR node=$(node --version) pnpm=$(pnpm --version) vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
