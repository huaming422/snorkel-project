## Task

The executor's mutating admission webhook only runs our built-in secret injection. Deployments that need other pod or node mutations still run a second, separately maintained webhook next to it, and we'd like this webhook to take those mutations over so the old one can be retired.

Several clusters can share one secret backend, and the API key eager tasks use to call back into the platform is provisioned once per cluster.

Secret injection itself should behave exactly as it does today. Don't add new dependencies.

## User stories / requirements

- Deployments can hand the webhook their own pod and node mutations at setup. Each gets a separate endpoint and object selector, applies its changes, and touches only the objects it targets. Secret injection keeps its existing endpoint. Setup fails if two mutations would share an endpoint, and the timeout setting applies to every entry.
- At startup the webhook reuses its stored TLS certificate while it can still serve with it, and replaces a missing, unservable or expiring one. Replicas starting together, even one replacing an old certificate as another stores a fresh one, end up serving the same stored certificate, which is what gets written to local disk.
- Secret reads the webhook makes while admitting pods keep being served from a watch, but the watch only covers the namespaces those reads go to, and when nothing in the configuration reads secrets no watch is started at all.
- A webhook configured for a cluster reads that cluster's copy of a per-cluster secret, falling back to the shared copy only when it is missing, under the requested key. With no cluster configured it reads only the shared copy. Other read errors surface, and clearing the cache picks up a changed copy.
