## Task

The executor's mutating admission webhook only runs our built-in secret injection. Deployments that need other pod or node mutations still run a second, separately maintained webhook next to it, and we'd like this webhook to take those mutations over so the old one can be retired.

Several clusters can share one secret backend, and the API key eager tasks use to call back into the platform is provisioned once per cluster.

Secret injection itself should behave exactly as it does today. Don't add new dependencies.

## User stories / requirements

- Deployments can pass their own pod and node mutations to the webhook while setting it up. Every one of them gets a separate endpoint and object selector, so it is only called for, and only modifies, the objects it targets. Secret injection keeps answering on the endpoint existing webhook configurations point to. Setup fails straight away if two mutations would share an endpoint, and the configured timeout is set on every webhook entry, built-in or not.
- On startup the webhook looks at the TLS certificate already stored for it and keeps using it unchanged if it can still serve with it. If nothing is stored, or the stored certificate can't be served for this service or expires soon, it issues a new one. Replicas that come up together, including one replacing an old certificate at the moment another stores a fresh one, all end up serving the same stored certificate instead of overwriting each other's, and any copy written to local disk matches it.
- Secret reads the webhook makes while admitting pods keep being served from a watch, but the watch only covers the namespaces those reads go to, and when nothing in the configuration reads secrets no watch is started at all.
- A webhook configured for a particular cluster reads that cluster's own copy of a per-cluster secret when it exists and uses the shared copy only when it is missing; either way the task receives the secret under the key it requested. With no cluster configured, it goes straight to the shared copy. A missing cluster copy is the only thing that triggers the fallback, so any other error reading it is returned to the caller, and clearing the cached secret makes the next pod see the cluster copy's current value.
