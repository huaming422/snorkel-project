#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
# The behavioral layer is a Go test in package service, CGO-linked against the
# prebuilt rag_tokenizer_c_api static lib + the office_oxide FFI lib. Everything
# it needs is baked into the image at the base commit (§1.5): the Go module +
# build caches are warm, the C++ static lib is on disk under
# internal/cpp/cmake-build-release/, and the CGO env (CGO_CFLAGS/CGO_LDFLAGS/
# LD_LIBRARY_PATH) is set image-wide. No external services are needed — the
# behavioral tests run against an in-memory pure-Go SQLite DB with a nil doc
# engine and nil metadata service.
cd /repo/ragflow

# Offline switch right after cd so a module-cache miss fails fast instead of
# reaching for a registry. The agent phase is offline; the verifier phase keeps
# these so grading matches the agent's environment. (go env -w already wrote
# these at image build; re-exporting is belt-and-suspenders for a fresh shell.)
export GOFLAGS=-mod=mod
export GOPROXY=off

# Re-assert the CGO env in case tests/test.sh runs under a login shell that did
# not inherit the image ENV. These mirror the image's ENV block exactly.
export CGO_ENABLED=1
export CGO_CFLAGS="-I/root/.office_oxide/include/office_oxide_c"
export CGO_LDFLAGS="-L/root/.office_oxide/lib -loffice_oxide -Wl,-rpath,/root/.office_oxide/lib"
export LD_LIBRARY_PATH="/usr/lib64:/root/.office_oxide/lib"
export PATH="/usr/local/go/bin:${PATH}"

# Dependencies: offline-first against the image bake, logged online fallback.
if GOFLAGS=-mod=mod GOPROXY=off go mod download > /tmp/test-setup-gomod.log 2>&1; then
    echo "[offline-first] go modules satisfied from image cache"
elif go mod download >> /tmp/test-setup-gomod.log 2>&1; then
    echo "[test-setup] go modules downloaded online (image bake was stale)"
else
    tail -40 /tmp/test-setup-gomod.log >&2; exit 1
fi

# Confirm the prebuilt CGO C++ static lib survived into the image. If it is
# missing the service package cannot link; fail loudly here rather than deep in
# a verifier's go test output.
if [ ! -f internal/cpp/cmake-build-release/librag_tokenizer_c_api.a ]; then
    echo "[test-setup] FATAL: prebuilt librag_tokenizer_c_api.a missing from image" >&2
    exit 1
fi
echo "[test-setup] CGO C++ static lib present"

# No background services, no data seeding: the behavioral tests build their own
# in-memory SQLite fixtures. Assertion logic lives in the verifier, not here.
