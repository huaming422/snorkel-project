## Task

The Go API can create and read dataset documents, but it has no way to edit an existing one. The product already offers that capability in Python. Bring the Go backend up to the same public behavior.

Add partial document editing at `PATCH /api/v1/datasets/:dataset_id/documents/:document_id`. Preserve omitted values, honor explicitly supplied values (including zero and empty values), and return the updated document in the existing JSON API shape.

Work in `/repo/ragflow`. This is an offline environment with the module cache, build dependencies, and CGO setup already available; `go build ./internal/...` compiles.

## User stories / requirements

- Authenticate the request and restrict edits to documents in datasets owned by the caller. Refuse an update from a caller who does not own the dataset without changing the document.
- Treat chunk, token, and progress values as system maintained. Accept a supplied value when it matches the stored value or is zero, and refuse any other change. Zero is accepted without overwriting a stored nonzero count. Refuse a chunking method that the document type does not support. Metadata values may be scalars or lists of scalars, but not nested objects.
- Check a proposed document name before changing either record. Reject an empty name, one over the allowed length, an extension change, or a name already used by another document in the dataset. For a valid rename, update both the document and its linked file.
- When the parsing or chunking plan changes, queue the document for processing again, reset its parse progress, and clear its derived counts, including the dataset totals that contain them. If multiple plan fields arrive together, apply only the highest priority field: `pipeline_id` before `parser_id` before `chunk_method`.
- Merge supplied parser settings into the document's current `parser_config`, retaining unrelated settings and adding new ones. Handle RAPTOR specially: remove its block if the supplied configuration leaves it out, and retain it if the supplied configuration includes it.
- Make the document status reflect `enabled` in both directions. Switching it off reads as disabled; switching it back on reads as enabled.
