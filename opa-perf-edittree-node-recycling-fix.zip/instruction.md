## Task

OPA's `json.patch` builtin is producing excessive heap allocations when a document goes through many add, remove, and replace operations. We see the same pressure around `json.remove` and `json.filter`. Workloads that repeatedly edit Rego AST or data documents can use much more memory than the edits warrant, with GC pressure becoming especially costly on larger runs.

Please reduce the allocation and memory overhead of this JSON builtin path under heavy editing churn. Keep the results of all three builtins exactly as they are today. CPU time is not the target here; unchanged wall clock time is fine.
