// Copyright 2026 The OPA Authors.  All rights reserved.
// Use of this source code is governed by an Apache2
// license that can be found in the LICENSE file.

// Allocation-pressure gate for the JSON-patch built-in path.
//
// This file is injected into v1/topdown/ at grade time by the Go runner
// (src/python/ssb_lib/runners/go.py) and compiles as part of `package topdown`,
// so it drives the unexported built-in entry point builtinJSONPatch directly —
// a pre-existing, stable, same-package interface. It never references any symbol
// a solution introduces (no pool, no reclaim helper, no Delete return value):
// the only thing measured is how many heap allocations the built-in performs for
// a fixed churn workload, which is observable for ANY implementation strategy.
//
// All identifiers carry a `vrfAlloc` prefix so this file composes cleanly with
// the package's own test files (which define e.g. runJSONPatchBenchmarkTest).
//
// Workload: build a JSON-patch operation list of N nested-composite "add"s
// followed by N "remove"s against an initially-empty object, then run the
// built-in under testing.Benchmark with ReportAllocs and read AllocsPerOp().
// On the pre-change code every discarded nested node becomes GC garbage, so the
// workload allocated about 20019 objects/op in the author measurement. A solution that actually
// reuses the intermediate tree structures on the delete/replace path drops this
// to ~12050. The gate asserts the result is comfortably below the baseline.
//
// allocs/op is the right signal here: it is an integer measurement in this pinned image,
// and it is exactly the quantity the task targets. Wall-clock (ns/op) is NOT
// used — it is noisy and can legitimately rise slightly as the cost of lower
// allocation/GC pressure, so a time gate would be both flaky and wrong-headed.
//
// A correctness guard rides along in the same run: before measuring, the patch
// list is applied once and the built-in's rendered result is checked to be the
// empty object (every key added is later removed). This closes a cheese where a
// solution slashes allocations by corrupting or short-circuiting the result —
// such a solution would clear the allocation bar but produce the wrong value,
// and is rejected here rather than passing the gate.

package topdown

import (
	"context"
	"strconv"
	"testing"

	"github.com/open-policy-agent/opa/v1/ast"
)

// vrfAllocThreshold is the maximum allocs/op the churn workload may perform.
//
// Provenance: the pre-change implementation is measured (author-validated in the
// built image, go1.26.3) at about 20019 allocs/op for this workload; a
// solution that reuses the discarded tree structures reaches ~12050. 16000 sits
// well below the baseline and comfortably above the reference result. It
// requires a substantial reduction on this workload without prescribing a
// particular reuse strategy. Smaller wins can still miss this pass line.
const vrfAllocThreshold = 16000

// vrfAllocChurn is the number of add-then-remove pairs in the workload. 2000
// nested-composite inserts followed by 2000 removes is large enough that the
// per-node garbage dominates the allocation profile and the baseline/fixed gap
// is unambiguous, while staying fast enough to measure many iterations.
const vrfAllocChurn = 2000

// vrfAllocBuildChurnPatches returns a json.patch operation array that adds
// vrfAllocChurn nested-composite values under distinct keys, then removes all of
// them in reverse order — the in-place "churn" pattern the task targets.
func vrfAllocBuildChurnPatches(m int) *ast.Array {
	out := make([]*ast.Term, 0, 2*m)
	for i := 0; i < m; i++ {
		path := ast.StringTerm("/k" + strconv.Itoa(i))
		val := ast.ObjectTerm([2]*ast.Term{
			ast.StringTerm("inner"),
			ast.ArrayTerm(ast.InternedTerm(i), ast.InternedTerm(i+1)),
		})
		out = append(out, vrfAllocPatchOp("add", path, val))
	}
	for i := m - 1; i >= 0; i-- {
		out = append(out, vrfAllocPatchOp("remove", ast.StringTerm("/k"+strconv.Itoa(i)), nil))
	}
	return ast.NewArray(out...)
}

// vrfAllocPatchOp builds one json.patch operation object {op, path[, value]}.
func vrfAllocPatchOp(op string, path, value *ast.Term) *ast.Term {
	pairs := [][2]*ast.Term{
		{ast.InternedTerm("op"), ast.InternedTerm(op)},
		{ast.InternedTerm("path"), path},
	}
	if value != nil {
		pairs = append(pairs, [2]*ast.Term{ast.InternedTerm("value"), value})
	}
	return ast.NewTerm(ast.NewObject(pairs...))
}

// vrfAllocCapture invokes builtinJSONPatch once and returns the patched term it
// yields through its iter callback (or a fatal error if the built-in fails).
func vrfAllocCapture(t *testing.T, operands []*ast.Term) *ast.Term {
	t.Helper()
	var got *ast.Term
	iter := func(res *ast.Term) error {
		got = res
		return nil
	}
	if err := builtinJSONPatch(BuiltinContext{Context: context.Background()}, operands, iter); err != nil {
		t.Fatalf("builtinJSONPatch returned error: %v", err)
	}
	if got == nil {
		t.Fatal("builtinJSONPatch did not yield a result term")
	}
	return got
}

// TestVerifyJSONPatchChurnAllocations is the fail_to_pass allocation gate.
func TestVerifyJSONPatchChurnAllocations(t *testing.T) {
	source := ast.NewObject()
	patches := vrfAllocBuildChurnPatches(vrfAllocChurn)
	operands := []*ast.Term{ast.NewTerm(source), ast.NewTerm(patches)}

	// Correctness guard: adding then removing every key must round-trip back to
	// the empty object. A solution that wins on allocations by producing a wrong
	// or truncated result fails here instead of passing the gate.
	got := vrfAllocCapture(t, operands)
	want := ast.NewObject()
	if got.Value.Compare(want) != 0 {
		t.Fatalf("churn workload produced wrong result: got %v, want %v", got, want)
	}

	// Measure allocations/op for the built-in over the churn workload.
	res := testing.Benchmark(func(b *testing.B) {
		b.ReportAllocs()
		iter := func(*ast.Term) error { return nil }
		for b.Loop() {
			if err := builtinJSONPatch(BuiltinContext{Context: context.Background()}, operands, iter); err != nil {
				b.Fatalf("builtinJSONPatch returned error: %v", err)
			}
		}
	})

	allocs := res.AllocsPerOp()
	t.Logf("json.patch churn workload: %d allocs/op, %d B/op (threshold %d allocs/op)",
		allocs, res.AllocedBytesPerOp(), vrfAllocThreshold)

	if res.N == 0 {
		t.Fatal("benchmark did not run any iterations")
	}
	if allocs > vrfAllocThreshold {
		t.Fatalf("json.patch churn workload allocates too much: %d allocs/op exceeds threshold %d", allocs, vrfAllocThreshold)
	}
}
