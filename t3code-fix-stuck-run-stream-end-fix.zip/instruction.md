## Task

A delegated provider run has remained in `running` for hours after its session stopped producing events. The run never reached a finished or failed state, and the provider thread stayed busy instead of returning to idle.

Repair the server's run lifecycle so a provider event stream that ends before a real run terminal causes the run to fail and finalize, with its provider thread returned to idle. A run that has already settled while another provider turn is being prepared must not receive that turn.

Preserve the other ways a run can end. When normal server shutdown tears down a session, leave its run for restart recovery without force-failing it. A run that reaches a genuine terminal should continue to settle normally.

Trace how run orchestration handles the provider stream and completes the run, then make the necessary fix.
