// @ts-nocheck
//
// Behavioral verifier for the stuck-run lifecycle defect.
//
// Tests drive the pre-existing stable service entry only:
//   RunExecutionService.layer + startRootRun(input)
// exercised through a faithful reconstruction of the repo's own
// captureRootRunTermination harness (the same pattern the server suite
// uses for RunExecutionService lifecycle scenarios). The harness drives a
// real RunExecutionService.layer with mocked collaborators (EventSink,
// CheckpointService, McpAppModelContext, ProviderEventIngestor,
// RunFinalizationObserver) and observes the run-settlement surface:
//   - observed: ordered "run:<status>" + "pull-requests-refreshed" strings
//     derived from emitted run.updated domain events + the finalization
//     observer.
//   - written: turn-item payloads actually committed.
//   - finalEvents: the full ordered domain-event stream (used to read the
//     provider thread's final status).
//
// Assertions target the observable settlement sequence ONLY — never a
// release-helper name, a private cause string, or an ownership-check call
// site. Any correct localization of the lifecycle defect settles the run
// the same observable way, so structurally-divergent fixes all pass.

import { assert, it } from "@effect/vitest";
import {
  CheckpointScopeId,
  CommandId,
  EnvironmentId,
  MessageId,
  NodeId,
  type OrchestrationV2AppThread,
  type OrchestrationV2CheckpointScope,
  type OrchestrationV2DomainEvent,
  type OrchestrationV2ExecutionNode,
  type OrchestrationV2ProviderThread,
  type OrchestrationV2Run,
  type OrchestrationV2RunAttempt,
  type OrchestrationV2Subagent,
  type OrchestrationV2TurnItem,
  ProviderDriverKind,
  ProviderInstanceId,
  ProviderSessionId,
  ProviderThreadId,
  ProviderTurnId,
  RunAttemptId,
  RunId,
  ThreadId,
  TurnItemId,
} from "@t3tools/contracts";
import * as Cause from "effect/Cause";
import * as DateTime from "effect/DateTime";
import * as Deferred from "effect/Deferred";
import * as Effect from "effect/Effect";
import * as Exit from "effect/Exit";
import * as Fiber from "effect/Fiber";
import * as Layer from "effect/Layer";
import * as Queue from "effect/Queue";
import * as Ref from "effect/Ref";
import * as Stream from "effect/Stream";
import { HttpServer } from "effect/http";
import * as NetAddress from "effect/net/NetAddress";
import * as NodeServices from "@effect/platform-node/NodeServices";

import type { PendingOrchestrationEffectV2 } from "./EffectOutbox.ts";
import { CodexProviderCapabilitiesV2 } from "./Adapters/CodexAdapterV2.ts";
import * as CheckpointService from "./CheckpointService.ts";
import * as EventSink from "./EventSink.ts";
import * as EventStore from "./EventStore.ts";
import * as IdAllocator from "@t3tools/provider-core/server/IdAllocator";
import * as McpProviderSessions from "@t3tools/provider-core/server/McpProviderSessions";
import * as McpSessionRegistry from "../mcp/McpSessionRegistry.ts";
import * as ProviderAdapter from "@t3tools/provider-core/server/ProviderAdapter";
import * as ProjectionStore from "./ProjectionStore.ts";
import * as ProviderAdapterRegistry from "./ProviderAdapterRegistry.ts";
import * as ProviderEventIngestor from "./ProviderEventIngestor.ts";
import * as ProviderSessionManager from "./ProviderSessionManager.ts";
import * as McpAppModelContext from "../mcpApps/McpAppModelContext.ts";
import * as RunExecutionService from "./RunExecutionService.ts";
import * as RunFinalizationService from "./RunFinalizationService.ts";
import * as ServerEnvironment from "../environment/ServerEnvironment.ts";
import * as ServerSettings from "../serverSettings.ts";
import * as SqlitePersistence from "../persistence/Sqlite.ts";
import * as ThreadCommandExecutor from "./ThreadCommandExecutor.ts";

const driver = ProviderDriverKind.make("codex");

interface BackgroundScenarioIds {
  readonly threadId: ThreadId;
  readonly childThreadId: ThreadId;
  readonly runId: RunId;
  readonly attemptId: RunAttemptId;
  readonly providerThreadId: ProviderThreadId;
  readonly rootProviderTurnId: ProviderTurnId;
  readonly rootNodeId: NodeId;
  readonly itemId: TurnItemId;
  readonly childItemId: TurnItemId;
  readonly subagentNodeId: NodeId;
}

function backgroundScenarioIds(key: string): BackgroundScenarioIds {
  return {
    threadId: ThreadId.make(`thread:${key}`),
    childThreadId: ThreadId.make(`thread:${key}:child`),
    runId: RunId.make(`run:${key}`),
    attemptId: RunAttemptId.make(`attempt:${key}`),
    providerThreadId: ProviderThreadId.make(`provider-thread:${key}`),
    rootProviderTurnId: ProviderTurnId.make(`provider-turn:${key}`),
    rootNodeId: NodeId.make(`node:${key}`),
    itemId: TurnItemId.make(`turn-item:${key}`),
    childItemId: TurnItemId.make(`turn-item:${key}:child`),
    subagentNodeId: NodeId.make(`node:${key}:subagent`),
  };
}

function makeRunOwnedSubagentFixture(input: {
  readonly ids: BackgroundScenarioIds;
  readonly providerInstanceId: ProviderInstanceId;
  readonly childThreadId: ThreadId;
  readonly driver: typeof driver;
  readonly status: "running" | "interrupted";
}): OrchestrationV2Subagent {
  const now = DateTime.makeUnsafe("2026-07-21T12:00:00.000Z");
  return {
    id: input.ids.subagentNodeId,
    threadId: input.ids.threadId,
    runId: input.ids.runId,
    parentNodeId: input.ids.rootNodeId,
    origin: "provider_native",
    createdBy: "agent",
    driver: input.driver,
    providerInstanceId: input.providerInstanceId,
    providerThreadId: null,
    childThreadId: input.childThreadId,
    nativeTaskRef: {
      driver: input.driver,
      nativeId: `task:${input.ids.subagentNodeId}`,
      strength: "strong",
    },
    prompt: "hold",
    title: "Live-test subagent hold",
    model: null,
    status: input.status,
    result: null,
    startedAt: now,
    completedAt: null,
    updatedAt: now,
  };
}

function makeRunOwnedSubagentTurnItemFixture(input: {
  readonly ids: BackgroundScenarioIds;
  readonly providerInstanceId: ProviderInstanceId;
  readonly childThreadId: ThreadId;
  readonly driver: typeof driver;
  readonly status: "running" | "interrupted";
}): Extract<OrchestrationV2TurnItem, { type: "subagent" }> {
  const now = DateTime.makeUnsafe("2026-07-21T12:00:00.000Z");
  return {
    id: input.ids.itemId,
    threadId: input.ids.threadId,
    runId: input.ids.runId,
    nodeId: input.ids.subagentNodeId,
    providerThreadId: input.ids.providerThreadId,
    providerTurnId: input.ids.rootProviderTurnId,
    nativeItemRef: {
      driver: input.driver,
      nativeId: `task:${input.ids.subagentNodeId}`,
      strength: "strong",
    },
    parentItemId: null,
    ordinal: 3,
    status: input.status,
    title: "Live-test subagent hold",
    startedAt: now,
    completedAt: null,
    updatedAt: now,
    type: "subagent",
    subagentId: input.ids.subagentNodeId,
    origin: "provider_native",
    driver: input.driver,
    providerInstanceId: input.providerInstanceId,
    childThreadId: input.childThreadId,
    prompt: "hold",
    result: null,
  };
}

function makeRunOwnedSubagentNodeFixture(input: {
  readonly ids: BackgroundScenarioIds;
  readonly status: "running" | "interrupted";
}): OrchestrationV2ExecutionNode {
  const now = DateTime.makeUnsafe("2026-07-21T12:00:00.000Z");
  return {
    id: input.ids.subagentNodeId,
    threadId: input.ids.threadId,
    runId: input.ids.runId,
    parentNodeId: input.ids.rootNodeId,
    rootNodeId: input.ids.rootNodeId,
    kind: "subagent",
    status: input.status,
    countsForRun: false,
    providerThreadId: input.ids.providerThreadId,
    providerTurnId: input.ids.rootProviderTurnId,
    nativeItemRef: {
      driver,
      nativeId: `task:${input.ids.subagentNodeId}`,
      strength: "strong",
    },
    runtimeRequestId: null,
    checkpointScopeId: null,
    startedAt: now,
    completedAt: null,
  };
}

function rootTerminalEvent(
  ids: BackgroundScenarioIds,
  status: "completed" | "interrupted" | "cancelled" | "failed",
): ProviderAdapter.ProviderAdapterV2Event {
  const common = {
    type: "turn.terminal" as const,
    driver,
    providerThreadId: ids.providerThreadId,
    providerTurnId: ids.rootProviderTurnId,
    runOrdinal: 1,
    threadDisposition: "reusable" as const,
  };
  return status === "failed"
    ? {
        ...common,
        status,
        failureItemOrdinal: 101,
        failure: {
          class: "provider_error",
          message: "Provider failed",
          code: null,
          retryable: null,
        },
      }
    : { ...common, status, failure: null };
}

// Faithful reconstruction of the server suite's lifecycle harness, extended
// with an overridable provider-turn ownership predicate, an awaitable
// app-context read, and a captured ordered domain-event stream so the final
// provider-thread status is observable.
function captureRootRunTermination(input: {
  readonly key: string;
  readonly shouldFinalizeRun: () => Effect.Effect<boolean, ProjectionStore.ProjectionStoreV2Error>;
  readonly rejectTerminalWrite?: boolean;
  readonly hasUnpairedRunInterruptRequest?: () => Effect.Effect<boolean, never>;
  readonly seedOpenSubagent?: boolean;
  readonly events?: (
    ids: BackgroundScenarioIds,
  ) => Stream.Stream<
    ProviderAdapter.ProviderAdapterV2Event,
    ProviderAdapter.ProviderAdapterV2Error
  >;
  readonly startTurn?: ProviderAdapter.ProviderAdapterV2SessionRuntime["startTurn"];
  readonly refreshAfterTurn?: Effect.Effect<void>;
  readonly shouldStartProviderTurn?: RunExecutionService.RunExecutionServiceV2StartRootRunInput["shouldStartProviderTurn"];
  readonly appContext?: ReturnType<McpAppModelContext.McpAppModelContext["Service"]["forThread"]>;
}) {
  return Effect.gen(function* () {
    const ids = backgroundScenarioIds(input.key);
    const providerInstanceId = ProviderInstanceId.make("codex");
    const runningSubagent = makeRunOwnedSubagentFixture({
      ids,
      providerInstanceId,
      childThreadId: ids.childThreadId,
      driver,
      status: "running",
    });
    const writtenItems = yield* Ref.make<ReadonlyArray<OrchestrationV2TurnItem>>([]);
    const finalEvents = yield* Ref.make<ReadonlyArray<OrchestrationV2DomainEvent>>([]);
    const observed = yield* Ref.make<ReadonlyArray<string>>([]);
    const submittedEffects = yield* Ref.make<ReadonlyArray<PendingOrchestrationEffectV2>>([]);
    const committedEffects = yield* Ref.make<ReadonlyArray<PendingOrchestrationEffectV2>>([]);
    const ingestionDone = yield* Deferred.make<void>();
    const captureTurnItem = (payload: OrchestrationV2TurnItem) =>
      Ref.update(writtenItems, (current) => [...current, payload]);
    const captureFinalEvents = (events: ReadonlyArray<OrchestrationV2DomainEvent>) =>
      Effect.gen(function* () {
        yield* Ref.update(finalEvents, (current) => [...current, ...events]);
        for (const event of events) {
          if (event.type === "turn-item.updated") {
            yield* captureTurnItem(event.payload);
          }
          if (event.type === "run.updated") {
            yield* Ref.update(observed, (current) => [...current, `run:${event.payload.status}`]);
          }
        }
      });
    const layerTest = RunExecutionService.layer.pipe(
      Layer.provide(
        Layer.mergeAll(
          Layer.mock(McpAppModelContext.McpAppModelContext)({
            forThread: () => input.appContext ?? Effect.succeed([]),
          }),
          Layer.mock(CheckpointService.CheckpointServiceV2)({ captureBaseline: () => Effect.void }),
          Layer.mock(EventSink.EventSinkV2)({
            write: (payload) =>
              Effect.gen(function* () {
                for (const event of payload.events) {
                  if (event.type === "turn-item.updated") {
                    yield* captureTurnItem(event.payload);
                  }
                }
                return [];
              }),
            writeWithEffects: (payload) =>
              Effect.gen(function* () {
                yield* Ref.update(submittedEffects, (current) => [...current, ...payload.effects]);
                yield* Ref.update(committedEffects, (current) => [...current, ...payload.effects]);
                yield* captureFinalEvents(payload.events);
                return [];
              }),
            writeIfRunCurrent: (payload) =>
              Effect.gen(function* () {
                const effects = payload.effects ?? [];
                yield* Ref.update(submittedEffects, (current) => [...current, ...effects]);
                if (input.rejectTerminalWrite === true) {
                  return { committed: false, storedEvents: [] };
                }
                yield* Ref.update(committedEffects, (current) => [...current, ...effects]);
                yield* captureFinalEvents(payload.events);
                return { committed: true, storedEvents: [] };
              }),
          }),
          IdAllocator.layer,
          Layer.mock(ProviderEventIngestor.ProviderEventIngestorV2)({
            ingestNormalized: () => Effect.succeed([]),
          }),
          ServerSettings.layerTest(),
          Layer.succeed(RunFinalizationService.RunFinalizationObserver, {
            refresh: () => Effect.void,
            refreshAfterTurn: () =>
              Ref.update(observed, (current) => [...current, "pull-requests-refreshed"]).pipe(
                Effect.andThen(input.refreshAfterTurn ?? Effect.void),
              ),
          }),
        ),
      ),
    );

    yield* Effect.gen(function* () {
      const runExecution = yield* RunExecutionService.RunExecutionServiceV2;
      yield* runExecution.startRootRun({
        commandId: CommandId.make(`command:${input.key}`),
        appThread: { id: ids.threadId } as OrchestrationV2AppThread,
        providerSessionId: ProviderSessionId.make(`session:${input.key}`),
        session: {
          events: Stream.empty,
          subscribeEvents: Effect.succeed({
            events:
              input.events?.(ids) ??
              Stream.fromIterable([
                ...(input.seedOpenSubagent
                  ? [
                      { type: "subagent.updated", driver, subagent: runningSubagent } as const,
                      {
                        type: "node.updated",
                        driver,
                        node: makeRunOwnedSubagentNodeFixture({ ids, status: "running" }),
                      } as const,
                      {
                        type: "turn_item.updated",
                        driver,
                        turnItem: makeRunOwnedSubagentTurnItemFixture({
                          ids,
                          providerInstanceId,
                          childThreadId: ids.childThreadId,
                          driver,
                          status: "running",
                        }),
                      } as const,
                    ]
                  : []),
                rootTerminalEvent(ids, "interrupted"),
              ] satisfies ReadonlyArray<ProviderAdapter.ProviderAdapterV2Event>),
            close: Deferred.succeed(ingestionDone, undefined),
          }),
          startTurn: input.startTurn ?? (() => Effect.void),
        } as unknown as ProviderAdapter.ProviderAdapterV2SessionRuntime,
        run: {
          id: ids.runId,
          threadId: ids.threadId,
          ordinal: 1,
          providerInstanceId,
        } as OrchestrationV2Run,
        rootNode: {
          id: ids.rootNodeId,
          providerTurnId: ids.rootProviderTurnId,
        } as OrchestrationV2ExecutionNode,
        checkpointScope: {
          id: CheckpointScopeId.make(`checkpoint-scope:${input.key}`),
        } as OrchestrationV2CheckpointScope,
        providerThread: {
          id: ids.providerThreadId,
          driver,
        } as OrchestrationV2ProviderThread,
        attempt: {
          id: ids.attemptId,
          providerTurnId: ids.rootProviderTurnId,
        } as OrchestrationV2RunAttempt,
        attemptId: ids.attemptId,
        providerTurnOrdinal: 1,
        shouldFinalizeRun: input.shouldFinalizeRun,
        ...(input.shouldStartProviderTurn === undefined
          ? {}
          : { shouldStartProviderTurn: input.shouldStartProviderTurn }),
        ...(input.hasUnpairedRunInterruptRequest === undefined
          ? {}
          : {
              hasUnpairedRunInterruptRequest: input.hasUnpairedRunInterruptRequest,
            }),
        message: {
          messageId: MessageId.make(`message:${input.key}`),
          text: "interrupt projection",
          attachments: [],
          createdBy: "user",
          creationSource: "web",
        },
        modelSelection: { instanceId: providerInstanceId, model: "gpt-5.4" },
        runtimePolicy: {
          runtimeMode: "full-access",
          interactionMode: "default",
          cwd: process.cwd(),
          approvalPolicy: "never",
          sandboxPolicy: {
            type: "readOnly",
            access: { type: "fullAccess" },
            networkAccess: false,
          },
        },
      });
    }).pipe(Effect.provide(layerTest), Effect.timeoutOption("10 seconds"));

    // A correctly-settling run resolves the subscription close in milliseconds.
    // Bound the awaits (mirroring the server suite's own ingestion-done waits)
    // so a run that never settles surfaces as empty observables and a clean
    // assertion failure instead of stalling the whole suite on its timeout.
    // These bounds are real-wall-clock escapes: the scenario that needs them to
    // fire (a startup read that blocks on a settlement that never arrives) runs
    // under the live clock so the elapse is genuine rather than a simulated-time
    // no-op; the fast paths resolve long before the bound and never reach it.
    yield* Deferred.await(ingestionDone).pipe(Effect.timeoutOption("10 seconds"));
    return {
      written: yield* Ref.get(writtenItems),
      finalEvents: yield* Ref.get(finalEvents),
      observed: yield* Ref.get(observed),
      submittedEffects: yield* Ref.get(submittedEffects),
      committedEffects: yield* Ref.get(committedEffects),
    };
  });
}

// C1 (fail_to_pass, basic): a provider event stream that ends cleanly with no
// root terminal must FAIL and finalize the run and idle the provider thread,
// instead of returning silently and leaving the run stuck in running. Pre-fix:
// observed == [] (the run never settles).
it.effect("fails the run when its event stream ends without a root terminal", () =>
  Effect.gen(function* () {
    const { observed, finalEvents } = yield* captureRootRunTermination({
      key: "stream-end-without-terminal",
      shouldFinalizeRun: () => Effect.succeed(true),
      events: () => Stream.empty,
    });
    assert.deepEqual(observed, ["run:failed", "pull-requests-refreshed"]);
    assert.equal(
      finalEvents.find((event) => event.type === "provider-thread.updated")?.payload.status,
      "idle",
    );
  }),
);

// C2 (fail_to_pass, basic): a stream torn down by an interrupt-only cause
// (graceful shutdown) must LEAVE the run untouched so restart recovery owns it
// — no finalization, no failure write. A naive fix that fails the run on any
// non-terminal end would wrongly settle it here.
it.effect("leaves the run to restart recovery when shutdown interrupts its event stream", () =>
  Effect.gen(function* () {
    const { written, observed } = yield* captureRootRunTermination({
      key: "stream-end:shutdown",
      shouldFinalizeRun: () => Effect.succeed(true),
      events: () => Stream.failCause(Cause.interrupt()),
    });
    assert.deepEqual(written, []);
    assert.deepEqual(observed, []);
  }),
);

// C3 (fail_to_pass): when the run settles during the awaited app-context read
// at startup, no provider turn may be dispatched into the already-settled run.
// Deferreds interleave the context read and the run's failure settlement; the
// provider-turn-start count must stay 0. Pre-fix the ownership check runs
// before the read, so a turn is dispatched into a settled run.
//
// Runs on the live clock: the regressed path blocks the startup read on a
// settlement that is never produced, so the harness's wall-clock escape must
// actually elapse to surface that as an empty-observable failure. Under the
// simulated clock the escape would never advance and the scenario would hang.
it.live("does not start a turn whose run settled during the app context read", () =>
  Effect.gen(function* () {
    const contextReadStarted = yield* Deferred.make<void>();
    const runFailed = yield* Deferred.make<void>();
    const current = yield* Ref.make(true);
    const providerCalls = yield* Ref.make(0);
    const { observed } = yield* captureRootRunTermination({
      key: "stream-end:context-read",
      shouldStartProviderTurn: () => Ref.get(current),
      shouldFinalizeRun: () => Ref.get(current),
      events: () => Stream.unwrap(Deferred.await(contextReadStarted).pipe(Effect.as(Stream.empty))),
      appContext: Deferred.succeed(contextReadStarted, undefined).pipe(
        Effect.andThen(Deferred.await(runFailed)),
        Effect.as([]),
      ),
      refreshAfterTurn: Ref.set(current, false).pipe(
        Effect.andThen(Deferred.succeed(runFailed, undefined)),
      ),
      startTurn: () => Ref.update(providerCalls, (count) => count + 1),
    });
    assert.deepEqual(observed, ["run:failed", "pull-requests-refreshed"]);
    assert.equal(yield* Ref.get(providerCalls), 0);
  }),
);

// C4 (pass_to_pass, basic): a stream that DOES end with a real root terminal
// still settles the run normally. Auxiliary/stale terminals are ignored and a
// real appended root terminal yields run:cancelled + a single refresh. Guards
// against the clean-end-fails change over-firing on legitimate terminals.
it.effect("settles the run on a real root terminal despite auxiliary or stale terminals", () =>
  Effect.gen(function* () {
    const { observed } = yield* captureRootRunTermination({
      key: "pull-request-refresh:auxiliary-with-root",
      shouldFinalizeRun: () => Effect.succeed(true),
      events: (ids) =>
        Stream.fromIterable([
          rootTerminalEvent(
            { ...ids, rootProviderTurnId: ProviderTurnId.make("turn:child") },
            "completed",
          ),
          rootTerminalEvent(
            { ...ids, rootProviderTurnId: ProviderTurnId.make("turn:previous") },
            "interrupted",
          ),
          rootTerminalEvent(ids, "cancelled"),
        ]),
    });
    assert.deepEqual(observed, ["run:cancelled", "pull-requests-refreshed"]);
  }),
);

// ── C5 end-to-end shutdown-safety harness ───────────────────────────────────
//
// C1–C4 drive the consumer (RunExecutionService.startRootRun) with a hand-made
// event stream, so they verify the consumer half of shutdown-safety given an
// already-interrupted stream. They say nothing about how a REAL graceful
// server shutdown presents to that consumer. C5 closes that gap: it drives the
// real ProviderSessionManager's `shutdown` against a live session the real
// consumer is subscribed to, and asserts the run is left alone end-to-end.
//
// This gates the producer half of the fix (the session manager must tear a
// shutdown subscription down so the consumer observes a graceful teardown, not
// a clean end) as a reward-bearing behavior: a fix that touches only the
// consumer — leaving the manager ending shutdown subscriptions cleanly — would
// make the consumer force-fail every run on a real shutdown and fails here,
// even though it passes C1–C4. The assertion is on the observable settlement
// surface only (no run write, no settlement event), so any mechanism that
// makes a real shutdown leave the run alone passes regardless of how the
// manager signals it.

const shutdownDriver = ProviderDriverKind.make("codex");
const shutdownModelSelection = {
  instanceId: ProviderInstanceId.make("codex"),
  model: "gpt-5.4",
};
const shutdownRuntimePolicy = {
  runtimeMode: "full-access",
  interactionMode: "default",
  cwd: process.cwd(),
};

function makeShutdownProviderSession(
  providerSessionId: ProviderSessionId,
  now: DateTime.Utc,
): OrchestrationV2ProviderSession {
  return {
    id: providerSessionId,
    driver: shutdownDriver,
    providerInstanceId: shutdownModelSelection.instanceId,
    status: "ready",
    cwd: process.cwd(),
    model: "gpt-5.4",
    capabilities: CodexProviderCapabilitiesV2,
    createdAt: now,
    updatedAt: now,
    lastError: null,
  } as OrchestrationV2ProviderSession;
}

function makeShutdownThreadCreatedEvent(input: {
  readonly idAllocator: IdAllocator.IdAllocatorV2["Service"];
  readonly threadId: ThreadId;
  readonly now: DateTime.Utc;
}) {
  return Effect.gen(function* () {
    const projectId = yield* input.idAllocator.allocate.project({
      fixtureName: "stream-end-shutdown",
    });
    const providerThreadId = input.idAllocator.derive.providerThread({
      driver: shutdownDriver,
      nativeThreadId: "native-thread",
    });
    const thread: OrchestrationV2AppThread = {
      createdBy: "user",
      creationSource: "web",
      id: input.threadId,
      projectId,
      title: "stream-end shutdown",
      providerInstanceId: shutdownModelSelection.instanceId,
      modelSelection: shutdownModelSelection,
      runtimeMode: "full-access",
      interactionMode: "default",
      branch: null,
      worktreePath: null,
      activeProviderThreadId: providerThreadId,
      lineage: {
        parentThreadId: null,
        relationshipToParent: null,
        rootThreadId: input.threadId,
      },
      forkedFrom: null,
      createdAt: input.now,
      updatedAt: input.now,
      archivedAt: null,
      settledOverride: null,
      settledAt: null,
      lastVisitedAt: null,
      deletedAt: null,
    } as OrchestrationV2AppThread;
    return {
      id: yield* input.idAllocator.allocate.event({ threadId: input.threadId }),
      type: "thread.created" as const,
      threadId: input.threadId,
      occurredAt: input.now,
      payload: thread,
    };
  });
}

function shutdownUnimplemented(detail: string) {
  return Effect.fail(
    new ProviderAdapter.ProviderAdapterProtocolError({ driver: shutdownDriver, detail }),
  );
}

// A minimal real provider adapter whose event stream is a queue that is never
// fed: the session is a quiet, in-flight run until the manager tears it down.
const makeShutdownAdapter = Effect.gen(function* () {
  const mcpSessions = yield* McpProviderSessions.McpProviderSessions;
  return ProviderAdapter.ProviderAdapterV2.of({
    instanceId: ProviderInstanceId.make("codex"),
    driver: shutdownDriver,
    getCapabilities: () => Effect.succeed(CodexProviderCapabilitiesV2),
    planSelectionTransition: () => Effect.succeed({ type: "apply_on_next_turn" }),
    openSession: (input) =>
      Effect.gen(function* () {
        yield* mcpSessions.read(input.threadId);
        const now = yield* DateTime.now;
        const events = yield* Queue.unbounded<
          ProviderAdapter.ProviderAdapterV2Event,
          Cause.Done
        >();
        return {
          instanceId: ProviderInstanceId.make("codex"),
          driver: shutdownDriver,
          providerSessionId: input.providerSessionId,
          providerSession: makeShutdownProviderSession(input.providerSessionId, now),
          events: Stream.fromQueue(events),
          backgroundTasksEndWithProcess: true as const,
          ensureThread: () => shutdownUnimplemented("ensureThread unused"),
          resumeThread: (t) => Effect.succeed(t.providerThread),
          startTurn: () => Effect.void,
          steerTurn: () => Effect.void,
          interruptTurn: () => Effect.void,
          unloadThread: () => Effect.void,
          respondToRuntimeRequest: () => Effect.void,
          readThreadSnapshot: () => shutdownUnimplemented("readThreadSnapshot unused"),
          rollbackThread: () => shutdownUnimplemented("rollbackThread unused"),
          forkThread: () => shutdownUnimplemented("forkThread unused"),
        } as unknown as ProviderAdapter.ProviderAdapterV2SessionRuntime;
      }),
  });
});

const shutdownFakeHttpServer = HttpServer.HttpServer.of({
  address: NetAddress.inetAddressFromIpStringUnsafe("127.0.0.1", 43123),
  serve: (() => Effect.void) as HttpServer.HttpServer["Service"]["serve"],
});
const shutdownFakeEnvironment = ServerEnvironment.ServerEnvironment.of({
  getEnvironmentId: Effect.succeed(EnvironmentId.make("environment-stream-end-shutdown")),
  getDescriptor: Effect.die("unused"),
});
const shutdownMcpRegistryLayer = Layer.effect(
  McpSessionRegistry.McpSessionRegistry,
  McpSessionRegistry.__testing.make(),
).pipe(
  Layer.provide(Layer.succeed(HttpServer.HttpServer, shutdownFakeHttpServer)),
  Layer.provide(Layer.succeed(ServerEnvironment.ServerEnvironment, shutdownFakeEnvironment)),
  Layer.provide(NodeServices.layer),
);

// The real ProviderSessionManager wired with real stores + the quiet adapter.
function shutdownManagerLayer() {
  const layerDatabase = SqlitePersistence.layerMemory;
  const layerStores = Layer.merge(EventStore.layer, ProjectionStore.layer).pipe(
    Layer.provide(layerDatabase),
  );
  const layerEventSink = EventSink.layer.pipe(
    Layer.provide(Layer.mergeAll(layerStores, layerDatabase)),
  );
  const layerRegistry = Layer.unwrap(
    makeShutdownAdapter.pipe(Effect.map(ProviderAdapterRegistry.layerSingle)),
  );
  const layerIngestor = ProviderEventIngestor.layer.pipe(
    Layer.provide(
      Layer.mergeAll(layerEventSink, IdAllocator.layer, layerStores, ThreadCommandExecutor.layer),
    ),
  );
  return Layer.mergeAll(
    layerStores,
    layerEventSink,
    IdAllocator.layer,
    shutdownMcpRegistryLayer,
    McpProviderSessions.layer,
    ProviderSessionManager.layerWithOptions({ idleTimeoutMs: 600_000 }).pipe(
      Layer.provide(
        Layer.mergeAll(
          layerRegistry.pipe(Layer.provideMerge(McpProviderSessions.layer)),
          layerEventSink,
          IdAllocator.layer,
          layerIngestor,
          shutdownMcpRegistryLayer,
          layerStores,
        ),
      ),
    ),
  ).pipe(Layer.provide(NodeServices.layer));
}

// C5 (fail_to_pass): a REAL graceful server shutdown must leave an in-flight run
// alone end-to-end. Opens a live session on the real ProviderSessionManager,
// subscribes the real RunExecutionService consumer to it, then drives the
// manager's real `shutdown`. The run must not be written or settled — restart
// recovery owns it. Pre-fix (and for a consumer-only fix that leaves the manager
// ending shutdown subscriptions cleanly) the consumer sees a clean stream-end on
// shutdown and force-fails the run, which this rejects.
//
// Runs on the live clock: the real manager's shutdown time-boxes its session
// releases and the consumer settles asynchronously, so the settle window must
// elapse in real wall-clock time rather than under the simulated clock.
it.live("leaves the run alone when a real server shutdown tears its session down", () =>
  Effect.gen(function* () {
    const written = yield* Ref.make<ReadonlyArray<OrchestrationV2TurnItem>>([]);
    const observed = yield* Ref.make<ReadonlyArray<string>>([]);
    // Resolved by the consumer's app-context read, which runs only once it has
    // subscribed to the live session — a deterministic barrier so shutdown is
    // never triggered before the consumer is listening.
    const consumerSubscribed = yield* Deferred.make<void>();

    const threadId = ThreadId.make("thread:stream-end:shutdown-e2e");
    const runId = RunId.make("run:stream-end:shutdown-e2e");
    const attemptId = RunAttemptId.make("attempt:stream-end:shutdown-e2e");
    const providerThreadId = ProviderThreadId.make("provider-thread:stream-end:shutdown-e2e");
    const rootProviderTurnId = ProviderTurnId.make("provider-turn:stream-end:shutdown-e2e");
    const rootNodeId = NodeId.make("node:stream-end:shutdown-e2e");

    const captureFinalEvents = (events: ReadonlyArray<OrchestrationV2DomainEvent>) =>
      Effect.gen(function* () {
        for (const event of events) {
          if (event.type === "turn-item.updated") {
            yield* Ref.update(written, (current) => [...current, event.payload]);
          }
          if (event.type === "run.updated") {
            yield* Ref.update(observed, (current) => [...current, `run:${event.payload.status}`]);
          }
        }
      });

    const consumerLayer = RunExecutionService.layer.pipe(
      Layer.provide(
        Layer.mergeAll(
          Layer.mock(McpAppModelContext.McpAppModelContext)({
            forThread: () =>
              Deferred.succeed(consumerSubscribed, undefined).pipe(Effect.as([])),
          }),
          Layer.mock(CheckpointService.CheckpointServiceV2)({ captureBaseline: () => Effect.void }),
          Layer.mock(EventSink.EventSinkV2)({
            write: (payload) =>
              Effect.gen(function* () {
                for (const event of payload.events) {
                  if (event.type === "turn-item.updated") {
                    yield* Ref.update(written, (current) => [...current, event.payload]);
                  }
                }
                return [];
              }),
            writeWithEffects: (payload) =>
              captureFinalEvents(payload.events).pipe(Effect.as([])),
            writeIfRunCurrent: (payload) =>
              captureFinalEvents(payload.events).pipe(
                Effect.as({ committed: true, storedEvents: [] }),
              ),
          }),
          IdAllocator.layer,
          Layer.mock(ProviderEventIngestor.ProviderEventIngestorV2)({
            ingestNormalized: () => Effect.succeed([]),
          }),
          ServerSettings.layerTest(),
          Layer.succeed(RunFinalizationService.RunFinalizationObserver, {
            refresh: () => Effect.void,
            refreshAfterTurn: () =>
              Ref.update(observed, (current) => [...current, "pull-requests-refreshed"]),
          }),
        ),
      ),
    );

    yield* Effect.gen(function* () {
      const eventSink = yield* EventSink.EventSinkV2;
      const idAllocator = yield* IdAllocator.IdAllocatorV2;
      const manager = yield* ProviderSessionManager.ProviderSessionManagerV2;
      const now = yield* DateTime.now;
      const providerSessionId = yield* idAllocator.allocate.providerSession({
        providerInstanceId: shutdownModelSelection.instanceId,
        threadId,
      });
      yield* eventSink.write({
        events: [yield* makeShutdownThreadCreatedEvent({ idAllocator, threadId, now })],
      });
      const runtime = yield* manager.open({
        threadId,
        providerSessionId,
        modelSelection: shutdownModelSelection,
        runtimePolicy: shutdownRuntimePolicy,
      });

      // Build the consumer into the test scope so its backgrounded ingestion
      // fiber survives after startRootRun returns: a shutdown settles (or must
      // not settle) the run asynchronously, after the start call returns.
      const consumerContext = yield* Layer.build(consumerLayer);
      const startRun = Effect.gen(function* () {
        const consumer = yield* RunExecutionService.RunExecutionServiceV2;
        return yield* consumer.startRootRun({
          commandId: CommandId.make("command:stream-end:shutdown-e2e"),
          appThread: { id: threadId } as OrchestrationV2AppThread,
          providerSessionId,
          session: runtime,
          run: {
            id: runId,
            threadId,
            ordinal: 1,
            providerInstanceId: shutdownModelSelection.instanceId,
          } as OrchestrationV2Run,
          rootNode: {
            id: rootNodeId,
            providerTurnId: rootProviderTurnId,
          } as OrchestrationV2ExecutionNode,
          checkpointScope: {
            id: CheckpointScopeId.make("checkpoint-scope:stream-end:shutdown-e2e"),
          } as OrchestrationV2CheckpointScope,
          providerThread: {
            id: providerThreadId,
            driver: shutdownDriver,
          } as OrchestrationV2ProviderThread,
          attempt: {
            id: attemptId,
            providerTurnId: rootProviderTurnId,
          } as OrchestrationV2RunAttempt,
          attemptId,
          providerTurnOrdinal: 1,
          shouldFinalizeRun: () => Effect.succeed(true),
          message: {
            messageId: MessageId.make("message:stream-end:shutdown-e2e"),
            text: "go",
            attachments: [],
            createdBy: "user",
            creationSource: "web",
          },
          modelSelection: {
            instanceId: shutdownModelSelection.instanceId,
            model: "gpt-5.4",
          },
          runtimePolicy: {
            runtimeMode: "full-access",
            interactionMode: "default",
            cwd: process.cwd(),
            approvalPolicy: "never",
            sandboxPolicy: {
              type: "readOnly",
              access: { type: "fullAccess" },
              networkAccess: false,
            },
          },
        });
      });
      const runFiber = yield* startRun.pipe(Effect.provide(consumerContext), Effect.forkChild);

      // Wait until the consumer has subscribed (its app-context read resolves
      // this), let the start call return, then drive a real server shutdown.
      yield* Deferred.await(consumerSubscribed);
      yield* Fiber.join(runFiber).pipe(Effect.timeoutOption("5 seconds"), Effect.ignore);
      yield* manager.shutdown;
      // Let the backgrounded ingestion fiber observe the torn-down stream and
      // settle (or leave) the run before the scope closes.
      yield* Effect.sleep("300 millis");
    }).pipe(Effect.scoped, Effect.provide(shutdownManagerLayer()), Effect.timeoutOption("20 seconds"));

    assert.deepEqual(
      yield* Ref.get(written),
      [],
      "a real graceful shutdown must not write a failure turn item for the run",
    );
    assert.deepEqual(
      yield* Ref.get(observed),
      [],
      "a real graceful shutdown must leave the run unsettled for restart recovery",
    );
  }),
);
