#!/usr/bin/env bash
# Environment bootstrap for the verifier phase. Sourced (not exec'd) so env vars
# set here stay live for the verifier subprocess.
#
# Offline-first: the image bakes the full pnpm dependency closure at the base
# commit (node_modules + warm store), so nothing here should need the network.
# The smoke gate runs this script inside `docker run --network none`; any fetch
# would fail the offline fold. Reinstalls are a guarded last resort that should
# never fire on a correctly-built image.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/t3code}"
export REPO_DIR
cd "$REPO_DIR"

# Keep git hooks and interactive postinstall behavior out of the verifier run.
export HUSKY=0
export CI=1

# The server package (`t3`) runs its suite through the vite-plus toolchain,
# whose CLI binary installs as `vp` in node_modules/.bin (there is no bare
# `vitest` entry — the suite is driven by `vp test`). The binary must be
# resolvable from the workspace root; a miss means the baked node_modules is
# corrupt. Reinstall defensively (frozen lockfile, no scripts) rather than
# failing later with a confusing "command not found". On a correctly-built
# image this branch is dead code.
if ! [ -x node_modules/.bin/vp ]; then
    echo "test-setup.sh: vp binary missing from node_modules/.bin/." \
         "The image build is corrupt — re-running pnpm install (offline store)." >&2
    pnpm install --frozen-lockfile --ignore-scripts --offline \
        || pnpm install --frozen-lockfile --ignore-scripts
fi

# The shared grading harness launches the suite with `npx vitest run <file>
# --reporter=json --outputFile=...`. This workspace exposes that runner only
# under the `vp test` subcommand, so provide a thin `vitest` entry on the local
# bin PATH that forwards verbatim to `vp test`. `vp test` passes every option
# straight through to the underlying Vitest-compatible runner, so the harness's
# JSON reporter + timeout flags are honored unchanged. Written into the local
# bin dir so `npx` resolves it ahead of any global lookup; a plain shell exec
# keeps argument quoting intact.
#
# `--version`/`-v` are intercepted and routed to `vp --version` directly: these
# are capability probes (e.g. the offline fold's `npx vitest --version`), and
# forwarding them through `vp test` would spin up the entire 1822-file suite —
# which exhausts inotify watches (EMFILE) and reaches for the npm registry.
if [ -x node_modules/.bin/vp ] && ! [ -e node_modules/.bin/vitest ]; then
    cat > node_modules/.bin/vitest <<'SHIM'
#!/bin/sh
case "$1" in
  --version|-v) exec "$(dirname "$0")/vp" --version ;;
  *) exec "$(dirname "$0")/vp" test "$@" ;;
esac
SHIM
    chmod +x node_modules/.bin/vitest
fi

# The server's orchestration-v2 tests import source files directly via relative
# TypeScript imports resolved by vite, so the agent's edits are visible without a
# dist/ rebuild. No `turbo build` is required (and running one here would be slow
# and risks touching the network). If a future verifier needs built workspace
# deps, add a targeted, offline `pnpm --filter t3 build` here.

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR" \
     "node=$(node --version 2>/dev/null || echo unknown)" \
     "pnpm=$(pnpm --version 2>/dev/null || echo unknown)"
