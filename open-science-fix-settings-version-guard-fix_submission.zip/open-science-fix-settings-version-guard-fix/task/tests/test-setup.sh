#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
#
# The image baked the full dependency closure at the base commit (`npm ci` in
# the clone layer), and vitest transforms TypeScript directly, so there is NO
# install or build step at grade time — this script only asserts readiness and
# exports an offline switch so any accidental resolve fails fast instead of
# hanging on the cut network. It MUST succeed with the network cut (the smoke
# gate's offline fold sources it inside `docker run --network none`).

REPO_DIR="${REPO_DIR:-/repo/open-science}"
export REPO_DIR
cd "$REPO_DIR"

# Fail fast on any accidental cache miss rather than reaching for a dead network.
export npm_config_offline=true
export npm_config_audit=false
export npm_config_fund=false

# The baked dependency tree must already carry vitest. A missing binary means a
# corrupted/absent node_modules — bail loudly now rather than hit a confusing
# "vitest: not found" inside the runner.
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest binary missing from node_modules/.bin/ in ${REPO_DIR}." >&2
    echo "test-setup.sh: the baked dependency closure is incomplete; rebuild the image." >&2
    exit 1
fi

echo "[test-setup] baked node_modules present; vitest resolvable; no online step needed"
