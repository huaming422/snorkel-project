## Task

We're getting reports that people's settings get silently wiped after they
run an older build of the app against a profile a newer build already touched.
Someone downgrades, opens the app, changes one unrelated preference, and
afterwards a chunk of their settings are just gone, reset to defaults as if the
newer version never saved them. A couple of reports say it happened without them
changing anything obvious. We've also seen settings disappear after a crash or
an interrupted update: the app comes back up on the older build and the newer
settings are lost entirely instead of being left intact for a later upgrade to
recover. The old build shouldn't be clobbering settings it doesn't understand;
anything it can't interpret should be left untouched rather than silently
rewritten or deleted. This all lives in how settings get persisted on the main
side, not in the UI, IPC, a database, or any new setting. Dig in and fix it.
