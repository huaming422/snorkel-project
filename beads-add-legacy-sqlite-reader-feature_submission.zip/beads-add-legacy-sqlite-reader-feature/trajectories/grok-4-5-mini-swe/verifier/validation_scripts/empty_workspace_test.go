package atomicfile_test

import (
	"bytes"
	"database/sql"
	"encoding/json"
	"path/filepath"
	"strconv"
	"testing"

	_ "github.com/mattn/go-sqlite3"
	"github.com/steveyegge/beads/internal/legacysqlite"
	"github.com/steveyegge/beads/internal/types"
	"github.com/stretchr/testify/require"
)

func authenticDDL_ew() []string {
	return []string{
		`CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL)`,
		`CREATE TABLE issues (id TEXT PRIMARY KEY, content_hash TEXT, title TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', design TEXT NOT NULL DEFAULT '', acceptance_criteria TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'open', priority INTEGER NOT NULL DEFAULT 2, issue_type TEXT NOT NULL DEFAULT 'task', assignee TEXT, estimated_minutes INTEGER, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, created_by TEXT DEFAULT '', owner TEXT DEFAULT '', updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, closed_at DATETIME, closed_by_session TEXT DEFAULT '', external_ref TEXT, spec_id TEXT, compaction_level INTEGER DEFAULT 0, compacted_at DATETIME, compacted_at_commit TEXT, original_size INTEGER, deleted_at DATETIME, deleted_by TEXT DEFAULT '', delete_reason TEXT DEFAULT '', original_type TEXT DEFAULT '', sender TEXT DEFAULT '', ephemeral INTEGER DEFAULT 0, wisp_type TEXT DEFAULT '', pinned INTEGER DEFAULT 0, is_template INTEGER DEFAULT 0, crystallizes INTEGER DEFAULT 0, mol_type TEXT DEFAULT '', work_type TEXT DEFAULT 'mutex', quality_score REAL, source_system TEXT DEFAULT '', metadata TEXT NOT NULL DEFAULT '{}', event_kind TEXT DEFAULT '', actor TEXT DEFAULT '', target TEXT DEFAULT '', payload TEXT DEFAULT '', source_repo TEXT DEFAULT '.', close_reason TEXT DEFAULT '', await_type TEXT, await_id TEXT, timeout_ns INTEGER, waiters TEXT, hook_bead TEXT DEFAULT '', role_bead TEXT DEFAULT '', agent_state TEXT DEFAULT '', last_activity DATETIME, role_type TEXT DEFAULT '', rig TEXT DEFAULT '', due_at DATETIME, defer_until DATETIME)`,
		`CREATE TABLE dependencies (issue_id TEXT NOT NULL, depends_on_id TEXT NOT NULL, type TEXT NOT NULL DEFAULT 'blocks', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, created_by TEXT NOT NULL, metadata TEXT, thread_id TEXT, PRIMARY KEY(issue_id,depends_on_id,type), FOREIGN KEY(issue_id) REFERENCES issues(id) ON DELETE CASCADE)`,
		`CREATE TABLE labels (issue_id TEXT NOT NULL, label TEXT NOT NULL, PRIMARY KEY(issue_id,label), FOREIGN KEY(issue_id) REFERENCES issues(id) ON DELETE CASCADE)`,
		`CREATE TABLE comments (id INTEGER PRIMARY KEY, issue_id TEXT NOT NULL, author TEXT NOT NULL, text TEXT NOT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(issue_id) REFERENCES issues(id) ON DELETE CASCADE)`,
	}
}

func legacyFixture_ew(t *testing.T, release string, issueIDs ...string) string {
	t.Helper()
	path := filepath.Join(t.TempDir(), "beads.db")
	db, err := sql.Open("sqlite3", path)
	require.NoError(t, err)
	for _, ddl := range authenticDDL_ew() {
		_, err := db.Exec(ddl)
		require.NoError(t, err)
	}
	_, err = db.Exec(`INSERT INTO metadata VALUES ('bd_version', ?)`, release)
	require.NoError(t, err)
	for _, id := range issueIDs {
		_, err := db.Exec(`INSERT INTO issues (id,title,status,priority,issue_type,created_at,updated_at,metadata) VALUES (?,?,'open',2,'task','2026-01-02T03:04:05Z','2026-01-02T03:04:05Z','{}')`, id, id)
		require.NoError(t, err)
	}
	require.NoError(t, db.Close())
	return path
}

func TestEmptyWorkspaceValidation(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			release := tc.Inputs["release"].(string)

			// Build authenticated workspace with NO issues
			src := legacyFixture_ew(t, release)

			var out bytes.Buffer
			convErr := legacysqlite.ConvertFile(src, &out)

			outcome := "converted"
			if convErr != nil {
				outcome = "refused"
			}

			var issues []types.Issue
			if convErr == nil {
				for _, line := range bytes.Split(bytes.TrimSpace(out.Bytes()), []byte{'\n'}) {
					if len(line) == 0 {
						continue
					}
					var issue types.Issue
					require.NoError(t, json.Unmarshal(line, &issue))
					issues = append(issues, issue)
				}
			}

			issueCount := strconv.Itoa(len(issues))

			require.Equal(t, tc.Expected["outcome"], outcome, "outcome mismatch for release %s", release)
			require.Equal(t, tc.Expected["issue_count"], issueCount, "issue_count mismatch for release %s", release)
		})
	}
}
