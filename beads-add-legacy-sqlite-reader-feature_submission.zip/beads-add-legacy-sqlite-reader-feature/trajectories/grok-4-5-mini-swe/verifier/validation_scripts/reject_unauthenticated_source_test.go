package atomicfile_test

import (
	"bytes"
	"database/sql"
	"path/filepath"
	"strings"
	"testing"

	_ "github.com/mattn/go-sqlite3"
	"github.com/steveyegge/beads/internal/legacysqlite"
	"github.com/steveyegge/beads/internal/types"
	"github.com/stretchr/testify/require"
)

func authenticDDL_rus() []string {
	return []string{
		`CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL)`,
		`CREATE TABLE issues (id TEXT PRIMARY KEY, content_hash TEXT, title TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', design TEXT NOT NULL DEFAULT '', acceptance_criteria TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'open', priority INTEGER NOT NULL DEFAULT 2, issue_type TEXT NOT NULL DEFAULT 'task', assignee TEXT, estimated_minutes INTEGER, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, created_by TEXT DEFAULT '', owner TEXT DEFAULT '', updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, closed_at DATETIME, closed_by_session TEXT DEFAULT '', external_ref TEXT, spec_id TEXT, compaction_level INTEGER DEFAULT 0, compacted_at DATETIME, compacted_at_commit TEXT, original_size INTEGER, deleted_at DATETIME, deleted_by TEXT DEFAULT '', delete_reason TEXT DEFAULT '', original_type TEXT DEFAULT '', sender TEXT DEFAULT '', ephemeral INTEGER DEFAULT 0, wisp_type TEXT DEFAULT '', pinned INTEGER DEFAULT 0, is_template INTEGER DEFAULT 0, crystallizes INTEGER DEFAULT 0, mol_type TEXT DEFAULT '', work_type TEXT DEFAULT 'mutex', quality_score REAL, source_system TEXT DEFAULT '', metadata TEXT NOT NULL DEFAULT '{}', event_kind TEXT DEFAULT '', actor TEXT DEFAULT '', target TEXT DEFAULT '', payload TEXT DEFAULT '', source_repo TEXT DEFAULT '.', close_reason TEXT DEFAULT '', await_type TEXT, await_id TEXT, timeout_ns INTEGER, waiters TEXT, hook_bead TEXT DEFAULT '', role_bead TEXT DEFAULT '', agent_state TEXT DEFAULT '', last_activity DATETIME, role_type TEXT DEFAULT '', rig TEXT DEFAULT '', due_at DATETIME, defer_until DATETIME)`,
		`CREATE TABLE dependencies (issue_id TEXT NOT NULL, depends_on_id TEXT NOT NULL, type TEXT NOT NULL DEFAULT 'blocks', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, created_by TEXT NOT NULL, metadata TEXT, thread_id TEXT, PRIMARY KEY(issue_id,depends_on_id,type), FOREIGN KEY(issue_id) REFERENCES issues(id) ON DELETE CASCADE)`,
		`CREATE TABLE labels (issue_id TEXT NOT NULL, label TEXT NOT NULL, PRIMARY KEY(issue_id,label), FOREIGN KEY(issue_id) REFERENCES issues(id) ON DELETE CASCADE)`,
		`CREATE TABLE comments (id INTEGER PRIMARY KEY, issue_id TEXT NOT NULL, author TEXT NOT NULL, text TEXT NOT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(issue_id) REFERENCES issues(id) ON DELETE CASCADE)`,
	}
}

func legacyFixture_rus(t *testing.T, release string, issueIDs ...string) string {
	t.Helper()
	path := filepath.Join(t.TempDir(), "beads.db")
	db, err := sql.Open("sqlite3", path)
	require.NoError(t, err)
	for _, ddl := range authenticDDL_rus() {
		_, err := db.Exec(ddl)
		require.NoError(t, err)
	}
	_, err = db.Exec(`INSERT INTO metadata VALUES ('bd_version', ?)`, release)
	require.NoError(t, err)
	for _, id := range issueIDs {
		_, err := db.Exec(`INSERT INTO issues (id,title,status,priority,issue_type,created_at,updated_at,metadata) VALUES (?,?,'open',2,'task','2026-01-02T03:04:05Z','2026-01-02T03:04:05Z','{}')`, id, id)
		require.NoError(t, err)
	}
	require.NoError(t, db.Close())
	return path
}

func mustExec_rus(t *testing.T, path, query string, args ...any) {
	t.Helper()
	db, err := sql.Open("sqlite3", path)
	require.NoError(t, err)
	defer db.Close()
	_, err = db.Exec(query, args...)
	require.NoError(t, err)
}

func TestRejectUnauthenticatedSourceValidation(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			mutation := tc.Inputs["mutation"].(string)

			src := legacyFixture_rus(t, "0.50.3", "old-1", "old-2")

			switch mutation {
			case "unknown-release":
				badRelease := tc.Inputs["bad_release"].(string)
				mustExec_rus(t, src, `UPDATE metadata SET value=? WHERE key='bd_version'`, badRelease)
			case "missing-release":
				mustExec_rus(t, src, `DELETE FROM metadata WHERE key='bd_version'`)
			case "schema-drift":
				mustExec_rus(t, src, `ALTER TABLE issues ADD COLUMN surprise TEXT`)
			case "fk-drift":
				mustExec_rus(t, src, `DROP TABLE labels`)
				mustExec_rus(t, src, `CREATE TABLE labels (issue_id TEXT NOT NULL, label TEXT NOT NULL, PRIMARY KEY(issue_id,label))`)
			case "overflow-field":
				mustExec_rus(t, src, `UPDATE issues SET assignee=? WHERE id='old-1'`, strings.Repeat("é", types.MaxFieldLen+1))
			case "dedup-comments":
				// Both rows carry the same canonical UTC instant: '2026-01-02T03:04:05Z'
				// and '2026-01-02T04:04:05+01:00' both resolve to 2026-01-02 03:04:05 UTC —
				// i.e. they collide after timezone normalization, which should trigger a
				// refusal. Two separate INSERTs are used because SQLite does not support
				// multi-value INSERT in all versions, but the effect is identical to a
				// single multi-row statement.
				mustExec_rus(t, src, `INSERT INTO comments VALUES (1,'old-1','old','same comment','2026-01-02T03:04:05Z')`)
				mustExec_rus(t, src, `INSERT INTO comments VALUES (2,'old-1','old','same comment','2026-01-02T04:04:05+01:00')`)
			case "non-string-waiters":
				mustExec_rus(t, src, `UPDATE issues SET waiters='["a",1]' WHERE id='old-1'`)
			}

			// Use a buffer to capture output; ConvertFile is fail-closed (writes nothing on error)
			var buf bytes.Buffer
			convErr := legacysqlite.ConvertFile(src, &buf)

			outcome := "converted"
			if convErr != nil {
				outcome = "refused"
			}

			// output_published: "yes" if any bytes were written to the buffer, "no" otherwise.
			// Since ConvertFile is fail-closed, a refusal must not write anything.
			outputPublished := "no"
			if buf.Len() > 0 {
				outputPublished = "yes"
			}

			require.Equal(t, tc.Expected["outcome"], outcome, "outcome mismatch for mutation %s", mutation)
			require.Equal(t, tc.Expected["output_published"], outputPublished, "output_published mismatch for mutation %s", mutation)
		})
	}
}
