package atomicfile_test

import (
	"bytes"
	"database/sql"
	"encoding/json"
	"os"
	"path/filepath"
	"strconv"
	"testing"
	"time"

	_ "github.com/mattn/go-sqlite3"
	"github.com/steveyegge/beads/internal/legacysqlite"
	"github.com/steveyegge/beads/internal/types"
	"github.com/stretchr/testify/require"
)

// authenticDDL_saw returns the DDL statements for the authentic legacy SQLite workspace.
func authenticDDL_saw() []string {
	return []string{
		`CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL)`,
		`CREATE TABLE issues (id TEXT PRIMARY KEY, content_hash TEXT, title TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', design TEXT NOT NULL DEFAULT '', acceptance_criteria TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'open', priority INTEGER NOT NULL DEFAULT 2, issue_type TEXT NOT NULL DEFAULT 'task', assignee TEXT, estimated_minutes INTEGER, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, created_by TEXT DEFAULT '', owner TEXT DEFAULT '', updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, closed_at DATETIME, closed_by_session TEXT DEFAULT '', external_ref TEXT, spec_id TEXT, compaction_level INTEGER DEFAULT 0, compacted_at DATETIME, compacted_at_commit TEXT, original_size INTEGER, deleted_at DATETIME, deleted_by TEXT DEFAULT '', delete_reason TEXT DEFAULT '', original_type TEXT DEFAULT '', sender TEXT DEFAULT '', ephemeral INTEGER DEFAULT 0, wisp_type TEXT DEFAULT '', pinned INTEGER DEFAULT 0, is_template INTEGER DEFAULT 0, crystallizes INTEGER DEFAULT 0, mol_type TEXT DEFAULT '', work_type TEXT DEFAULT 'mutex', quality_score REAL, source_system TEXT DEFAULT '', metadata TEXT NOT NULL DEFAULT '{}', event_kind TEXT DEFAULT '', actor TEXT DEFAULT '', target TEXT DEFAULT '', payload TEXT DEFAULT '', source_repo TEXT DEFAULT '.', close_reason TEXT DEFAULT '', await_type TEXT, await_id TEXT, timeout_ns INTEGER, waiters TEXT, hook_bead TEXT DEFAULT '', role_bead TEXT DEFAULT '', agent_state TEXT DEFAULT '', last_activity DATETIME, role_type TEXT DEFAULT '', rig TEXT DEFAULT '', due_at DATETIME, defer_until DATETIME)`,
		`CREATE TABLE dependencies (issue_id TEXT NOT NULL, depends_on_id TEXT NOT NULL, type TEXT NOT NULL DEFAULT 'blocks', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, created_by TEXT NOT NULL, metadata TEXT, thread_id TEXT, PRIMARY KEY(issue_id,depends_on_id,type), FOREIGN KEY(issue_id) REFERENCES issues(id) ON DELETE CASCADE)`,
		`CREATE TABLE labels (issue_id TEXT NOT NULL, label TEXT NOT NULL, PRIMARY KEY(issue_id,label), FOREIGN KEY(issue_id) REFERENCES issues(id) ON DELETE CASCADE)`,
		`CREATE TABLE comments (id INTEGER PRIMARY KEY, issue_id TEXT NOT NULL, author TEXT NOT NULL, text TEXT NOT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(issue_id) REFERENCES issues(id) ON DELETE CASCADE)`,
	}
}

func legacyFixture_saw(t *testing.T, release string, issueIDs ...string) string {
	t.Helper()
	path := filepath.Join(t.TempDir(), "beads.db")
	db, err := sql.Open("sqlite3", path)
	require.NoError(t, err)
	for _, ddl := range authenticDDL_saw() {
		_, err := db.Exec(ddl)
		require.NoError(t, err)
	}
	_, err = db.Exec(`INSERT INTO metadata VALUES ('bd_version', ?)`, release)
	require.NoError(t, err)
	for _, id := range issueIDs {
		_, err := db.Exec(`INSERT INTO issues (id,title,status,priority,issue_type,created_at,updated_at,metadata) VALUES (?,?,'open',2,'task','2026-01-02T03:04:05Z','2026-01-02T03:04:05Z','{}')`, id, id)
		require.NoError(t, err)
	}
	require.NoError(t, db.Close())
	return path
}

func mustExec_saw(t *testing.T, path, query string, args ...any) {
	t.Helper()
	db, err := sql.Open("sqlite3", path)
	require.NoError(t, err)
	defer db.Close()
	_, err = db.Exec(query, args...)
	require.NoError(t, err)
}

func TestConvertAuthenticWorkspaceValidation(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			release := tc.Inputs["release"].(string)

			src := legacyFixture_saw(t, release, "old-1", "old-2")
			mustExec_saw(t, src, `INSERT INTO labels VALUES ('old-1','legacy')`)
			mustExec_saw(t, src, `INSERT INTO dependencies VALUES ('old-1','old-2','blocks','2026-01-02T03:04:05Z','old',NULL,NULL)`)
			mustExec_saw(t, src, `INSERT INTO comments VALUES (1,'old-1','old','preserve me','2026-01-02T03:04:05Z')`)
			mustExec_saw(t, src, `UPDATE issues SET status='closed', closed_at='2026-03-04T05:06:07Z', due_at='2026-03-05T06:07:08Z' WHERE id='old-1'`)

			// Read source bytes before conversion
			beforeBytes, err := os.ReadFile(src)
			require.NoError(t, err)

			// Run conversion
			var out bytes.Buffer
			convErr := legacysqlite.ConvertFile(src, &out)

			// Read source bytes after conversion
			afterBytes, err := os.ReadFile(src)
			require.NoError(t, err)

			// Record outcome
			outcome := "converted"
			if convErr != nil {
				outcome = "refused"
			}

			// Decode issues
			var issues []types.Issue
			if convErr == nil {
				for _, line := range bytes.Split(bytes.TrimSpace(out.Bytes()), []byte{'\n'}) {
					if len(line) == 0 {
						continue
					}
					var issue types.Issue
					require.NoError(t, json.Unmarshal(line, &issue))
					issues = append(issues, issue)
				}
			}

			issueCount := strconv.Itoa(len(issues))

			firstID := ""
			firstLabelCount := "0"
			firstDepCount := "0"
			firstCommentCount := "0"
			allImportSafe := "yes"
			firstClosedAt := ""
			firstDueAt := ""

			if len(issues) > 0 {
				// Find old-1 by id
				var old1 *types.Issue
				for i := range issues {
					if issues[i].ID == "old-1" {
						old1 = &issues[i]
						break
					}
				}
				// Only set firstID if old1 was actually found; if it's nil, firstID
				// remains "" so the assertion fails correctly rather than passing spuriously.
				if old1 != nil {
					firstID = "old-1"
					firstLabelCount = strconv.Itoa(len(old1.Labels))
					firstDepCount = strconv.Itoa(len(old1.Dependencies))
					firstCommentCount = strconv.Itoa(len(old1.Comments))
					if old1.ClosedAt != nil {
						firstClosedAt = old1.ClosedAt.UTC().Format(time.RFC3339)
					}
					if old1.DueAt != nil {
						firstDueAt = old1.DueAt.UTC().Format(time.RFC3339)
					}
				}

				// Check all import safe
				for i := range issues {
					if err := issues[i].Validate(); err != nil {
						allImportSafe = "no"
						break
					}
				}
			}

			sourceUnchanged := "yes"
			if !bytes.Equal(beforeBytes, afterBytes) {
				sourceUnchanged = "no"
			}

			require.Equal(t, tc.Expected["outcome"], outcome, "outcome mismatch")
			require.Equal(t, tc.Expected["issue_count"], issueCount, "issue_count mismatch")
			require.Equal(t, tc.Expected["first_id"], firstID, "first_id mismatch")
			require.Equal(t, tc.Expected["first_label_count"], firstLabelCount, "first_label_count mismatch")
			require.Equal(t, tc.Expected["first_dependency_count"], firstDepCount, "first_dependency_count mismatch")
			require.Equal(t, tc.Expected["first_comment_count"], firstCommentCount, "first_comment_count mismatch")
			require.Equal(t, tc.Expected["all_import_safe"], allImportSafe, "all_import_safe mismatch")
			require.Equal(t, tc.Expected["source_unchanged"], sourceUnchanged, "source_unchanged mismatch")
			require.Equal(t, tc.Expected["first_closed_at"], firstClosedAt, "first_closed_at mismatch")
			require.Equal(t, tc.Expected["first_due_at"], firstDueAt, "first_due_at mismatch")
		})
	}
}
