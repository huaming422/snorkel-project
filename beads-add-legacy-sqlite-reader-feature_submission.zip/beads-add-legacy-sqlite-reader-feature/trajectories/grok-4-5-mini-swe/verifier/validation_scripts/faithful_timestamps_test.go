package atomicfile_test

import (
	"bytes"
	"database/sql"
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
	"time"

	_ "github.com/mattn/go-sqlite3"
	"github.com/steveyegge/beads/internal/legacysqlite"
	"github.com/steveyegge/beads/internal/types"
	"github.com/stretchr/testify/require"
)

func authenticDDL_ft() []string {
	return []string{
		`CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL)`,
		`CREATE TABLE issues (id TEXT PRIMARY KEY, content_hash TEXT, title TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', design TEXT NOT NULL DEFAULT '', acceptance_criteria TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'open', priority INTEGER NOT NULL DEFAULT 2, issue_type TEXT NOT NULL DEFAULT 'task', assignee TEXT, estimated_minutes INTEGER, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, created_by TEXT DEFAULT '', owner TEXT DEFAULT '', updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, closed_at DATETIME, closed_by_session TEXT DEFAULT '', external_ref TEXT, spec_id TEXT, compaction_level INTEGER DEFAULT 0, compacted_at DATETIME, compacted_at_commit TEXT, original_size INTEGER, deleted_at DATETIME, deleted_by TEXT DEFAULT '', delete_reason TEXT DEFAULT '', original_type TEXT DEFAULT '', sender TEXT DEFAULT '', ephemeral INTEGER DEFAULT 0, wisp_type TEXT DEFAULT '', pinned INTEGER DEFAULT 0, is_template INTEGER DEFAULT 0, crystallizes INTEGER DEFAULT 0, mol_type TEXT DEFAULT '', work_type TEXT DEFAULT 'mutex', quality_score REAL, source_system TEXT DEFAULT '', metadata TEXT NOT NULL DEFAULT '{}', event_kind TEXT DEFAULT '', actor TEXT DEFAULT '', target TEXT DEFAULT '', payload TEXT DEFAULT '', source_repo TEXT DEFAULT '.', close_reason TEXT DEFAULT '', await_type TEXT, await_id TEXT, timeout_ns INTEGER, waiters TEXT, hook_bead TEXT DEFAULT '', role_bead TEXT DEFAULT '', agent_state TEXT DEFAULT '', last_activity DATETIME, role_type TEXT DEFAULT '', rig TEXT DEFAULT '', due_at DATETIME, defer_until DATETIME)`,
		`CREATE TABLE dependencies (issue_id TEXT NOT NULL, depends_on_id TEXT NOT NULL, type TEXT NOT NULL DEFAULT 'blocks', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, created_by TEXT NOT NULL, metadata TEXT, thread_id TEXT, PRIMARY KEY(issue_id,depends_on_id,type), FOREIGN KEY(issue_id) REFERENCES issues(id) ON DELETE CASCADE)`,
		`CREATE TABLE labels (issue_id TEXT NOT NULL, label TEXT NOT NULL, PRIMARY KEY(issue_id,label), FOREIGN KEY(issue_id) REFERENCES issues(id) ON DELETE CASCADE)`,
		`CREATE TABLE comments (id INTEGER PRIMARY KEY, issue_id TEXT NOT NULL, author TEXT NOT NULL, text TEXT NOT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(issue_id) REFERENCES issues(id) ON DELETE CASCADE)`,
	}
}

func legacyFixture_ft(t *testing.T, release string, issueIDs ...string) string {
	t.Helper()
	path := filepath.Join(t.TempDir(), "beads.db")
	db, err := sql.Open("sqlite3", path)
	require.NoError(t, err)
	for _, ddl := range authenticDDL_ft() {
		_, err := db.Exec(ddl)
		require.NoError(t, err)
	}
	_, err = db.Exec(`INSERT INTO metadata VALUES ('bd_version', ?)`, release)
	require.NoError(t, err)
	for _, id := range issueIDs {
		_, err := db.Exec(`INSERT INTO issues (id,title,status,priority,issue_type,created_at,updated_at,metadata) VALUES (?,?,'open',2,'task','2026-01-02T03:04:05Z','2026-01-02T03:04:05Z','{}')`, id, id)
		require.NoError(t, err)
	}
	require.NoError(t, db.Close())
	return path
}

func mustExec_ft(t *testing.T, path, query string, args ...any) {
	t.Helper()
	db, err := sql.Open("sqlite3", path)
	require.NoError(t, err)
	defer db.Close()
	_, err = db.Exec(query, args...)
	require.NoError(t, err)
}

const skipSentinel = "__skip__"

func TestFaithfulTimestampsValidation(t *testing.T) {
	cases := GetValidationTestCases(t)
	for _, tc := range cases {
		tc := tc
		t.Run(tc.Name, func(t *testing.T) {
			mode := tc.Inputs["mode"].(string)

			switch mode {
			case "canonicalize":
				src := legacyFixture_ft(t, "0.50.3", "old-1", "old-2")
				mustExec_ft(t, src, `UPDATE issues SET status='closed',
				    created_at='2026-01-02T03:04:05.987654321-02:00',
				    updated_at='2026-01-02T03:04:06.876543210Z',
				    closed_at='2026-01-02 03:04:07.765432100',
				    compacted_at='2026-01-03T04:05:06.5Z',
				    due_at='2026-01-04 05:06:07.123456789',
				    defer_until='2026-01-05T07:08:09.999999999+02:00' WHERE id='old-1'`)
				mustExec_ft(t, src, `INSERT INTO dependencies VALUES ('old-1','old-2','blocks','2026-01-06T10:11:12.555555555-03:00','old',NULL,NULL)`)
				mustExec_ft(t, src, `INSERT INTO comments VALUES (1,'old-1','old','fractional','2026-01-07 11:12:13.444444444')`)

				var out bytes.Buffer
				convErr := legacysqlite.ConvertFile(src, &out)

				outcome := "converted"
				if convErr != nil {
					outcome = "refused"
				}

				// Decode issues
				var issues []types.Issue
				if convErr == nil {
					for _, line := range bytes.Split(bytes.TrimSpace(out.Bytes()), []byte{'\n'}) {
						if len(line) == 0 {
							continue
						}
						var issue types.Issue
						require.NoError(t, json.Unmarshal(line, &issue))
						issues = append(issues, issue)
					}
				}

				// Find old-1
				var old1 *types.Issue
				for i := range issues {
					if issues[i].ID == "old-1" {
						old1 = &issues[i]
						break
					}
				}

				createdAt := ""
				updatedAt := ""
				closedAt := ""
				compactedAt := ""
				dueAt := ""
				deferUntil := ""
				depCreatedAt := ""
				commentCreatedAt := ""

				if old1 != nil {
					createdAt = old1.CreatedAt.UTC().Format(time.RFC3339)
					updatedAt = old1.UpdatedAt.UTC().Format(time.RFC3339)
					if old1.ClosedAt != nil {
						closedAt = old1.ClosedAt.UTC().Format(time.RFC3339)
					}
					if old1.CompactedAt != nil {
						compactedAt = old1.CompactedAt.UTC().Format(time.RFC3339)
					}
					if old1.DueAt != nil {
						dueAt = old1.DueAt.UTC().Format(time.RFC3339)
					}
					if old1.DeferUntil != nil {
						deferUntil = old1.DeferUntil.UTC().Format(time.RFC3339)
					}
					if len(old1.Dependencies) > 0 {
						depCreatedAt = old1.Dependencies[0].CreatedAt.UTC().Format(time.RFC3339)
					}
					if len(old1.Comments) > 0 {
						commentCreatedAt = old1.Comments[0].CreatedAt.UTC().Format(time.RFC3339)
					}
				}

				// Assert all expected keys.
				// output_published uses skipSentinel for the canonicalize mode — the spec
				// does not pin this value for the canonicalize branch, so we just read and
				// discard the sentinel to confirm the key is present without asserting it.
				expOutcome := tc.Expected["outcome"].(string)
				require.Equal(t, expOutcome, outcome, "outcome mismatch")

				// output_published: spec uses __skip__ for canonicalize; read key to confirm presence.
				_ = tc.Expected["output_published"].(string)

				if v := tc.Expected["created_at"].(string); v != skipSentinel {
					require.Equal(t, v, createdAt, "created_at mismatch")
				}
				if v := tc.Expected["updated_at"].(string); v != skipSentinel {
					require.Equal(t, v, updatedAt, "updated_at mismatch")
				}
				if v := tc.Expected["closed_at"].(string); v != skipSentinel {
					require.Equal(t, v, closedAt, "closed_at mismatch")
				}
				if v := tc.Expected["compacted_at"].(string); v != skipSentinel {
					require.Equal(t, v, compactedAt, "compacted_at mismatch")
				}
				if v := tc.Expected["due_at"].(string); v != skipSentinel {
					require.Equal(t, v, dueAt, "due_at mismatch")
				}
				if v := tc.Expected["defer_until"].(string); v != skipSentinel {
					require.Equal(t, v, deferUntil, "defer_until mismatch")
				}
				if v := tc.Expected["dep_created_at"].(string); v != skipSentinel {
					require.Equal(t, v, depCreatedAt, "dep_created_at mismatch")
				}
				if v := tc.Expected["comment_created_at"].(string); v != skipSentinel {
					require.Equal(t, v, commentCreatedAt, "comment_created_at mismatch")
				}

			case "reject-out-of-range":
				mutation := tc.Inputs["mutation"].(string)
				src := legacyFixture_ft(t, "0.50.3", "old-1", "old-2")
				mustExec_ft(t, src, mutation)

				outPath := filepath.Join(t.TempDir(), "out.jsonl")

				// ConvertFile writes to io.Writer; capture to buffer
				var buf bytes.Buffer
				convErr := legacysqlite.ConvertFile(src, &buf)

				outcome := "converted"
				if convErr != nil {
					outcome = "refused"
				}

				outputPublished := "no"
				if buf.Len() > 0 {
					outputPublished = "yes"
				}
				// Also check file (it shouldn't exist since we don't write it here,
				// but if a different implementation writes to outPath, check it)
				if info, err := os.Stat(outPath); err == nil && info.Size() > 0 {
					outputPublished = "yes"
				}

				expOutcome := tc.Expected["outcome"].(string)
				require.Equal(t, expOutcome, outcome, "outcome mismatch")

				// output_published is asserted unconditionally — the spec always pins this
				// value for the reject-out-of-range branch (never skipSentinel here).
				expOutputPublished := tc.Expected["output_published"].(string)
				require.Equal(t, expOutputPublished, outputPublished, "output_published mismatch")

				// All timestamp keys are __skip__ for reject-out-of-range, so no assertions needed
				// but we still read them as the procedure requires asserting ALL expected keys
				// (the skipSentinel guard prevents spurious failures for these).
				if v := tc.Expected["created_at"].(string); v != skipSentinel {
					require.Equal(t, v, "", "created_at mismatch")
				}
				if v := tc.Expected["updated_at"].(string); v != skipSentinel {
					require.Equal(t, v, "", "updated_at mismatch")
				}
				if v := tc.Expected["closed_at"].(string); v != skipSentinel {
					require.Equal(t, v, "", "closed_at mismatch")
				}
				if v := tc.Expected["compacted_at"].(string); v != skipSentinel {
					require.Equal(t, v, "", "compacted_at mismatch")
				}
				if v := tc.Expected["due_at"].(string); v != skipSentinel {
					require.Equal(t, v, "", "due_at mismatch")
				}
				if v := tc.Expected["defer_until"].(string); v != skipSentinel {
					require.Equal(t, v, "", "defer_until mismatch")
				}
				if v := tc.Expected["dep_created_at"].(string); v != skipSentinel {
					require.Equal(t, v, "", "dep_created_at mismatch")
				}
				if v := tc.Expected["comment_created_at"].(string); v != skipSentinel {
					require.Equal(t, v, "", "comment_created_at mismatch")
				}
			}
		})
	}
}
