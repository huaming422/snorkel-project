#!/usr/bin/env bash
# Regression guard: the command binary and the whole internal tree still compile
# with the C sqlite driver OFF.
#
# The new conversion needs the C sqlite driver, which only links under CGO. The
# product still has to build without CGO (static, cross, minimal builds), so the
# driver-dependent code must sit behind a build-tag split and the no-CGO build must
# stay green. This step builds the command and internal trees with CGO_ENABLED=0.
#
# This is a compilation check only. It names nothing the work introduces: whatever
# the submission called its package, its entry point, its command token or its
# flags, a no-CGO build of the command and internal trees must still succeed. The
# message a no-CGO build reports at runtime is a solution-chosen string, exercised
# by a validation story, not asserted here.
#
# On a tree that has not added the feature yet this is a no-op pass (the pre-change
# code has no C-driver dependency), so it is a pure regression gate on the split.
set -euo pipefail

export GOFLAGS="${GOFLAGS:--mod=mod}"
export GOTOOLCHAIN="${GOTOOLCHAIN:-local}"
export CGO_ENABLED=0

cd /repo/beads

echo "== build (cgo off): ./cmd/... ./internal/... =="
go build ./cmd/... ./internal/...

echo "OK: command and internal trees compile with CGO disabled"
