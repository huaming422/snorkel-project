#!/usr/bin/env bash
# Sourced by tests/test.sh before every verifier (set -euo pipefail inherited).
# Go task, offline agent phase: the image baked the full module+build cache at
# the base commit (incl. github.com/mattn/go-sqlite3 v1.14.8, the version the
# curated oracle pins). The reader is CGO (go-sqlite3), so CGO must stay enabled
# and the toolchain pinned. No services to start; no data to seed.
cd /repo/beads

# Go offline switches, exported right after cd so a cache miss fails fast
# instead of reaching a module proxy. Must run with the network cut (smoke
# gate's offline fold sources this inside `docker run --network none`).
export GOFLAGS="-mod=mod"
export GOPROXY=off
export GOTOOLCHAIN=local
export CGO_ENABLED=1
export GOMODCACHE="${GOMODCACHE:-/opt/cache/go}"
export GOCACHE="${GOCACHE:-/opt/cache/go-build}"

# Dependencies: offline-first against the image bake, logged online fallback.
if GOPROXY=off go mod download > /tmp/test-setup-install.log 2>&1; then
    echo "[offline-first] go modules satisfied from image"
elif go mod download >> /tmp/test-setup-install.log 2>&1; then
    echo "[test-setup] go modules downloaded online (image bake was stale)"
else
    tail -40 /tmp/test-setup-install.log >&2; exit 1
fi
