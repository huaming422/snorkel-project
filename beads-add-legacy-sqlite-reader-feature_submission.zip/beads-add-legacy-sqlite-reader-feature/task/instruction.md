## Task

We still get people upgrading from an old release who have a legacy SQLite workspace sitting on disk, and right now the only way to pull that data into the current binary is to keep an ancient build around to open it. We want the current binary to read one of those legacy SQLite workspaces directly and write it out as current-format canonical JSONL, with no historical release binary anywhere in the loop.

Expose it as a new subcommand under the existing migrate command group. It takes the path to a source database and an output destination, either a file or stdout.

Only the two authenticated historical SQLite schema releases, v0.49.6 and v0.50.3, are in scope. The older Dolt-based workspaces and any other on-disk format are not in scope.

The hard part is fidelity, so make it fail closed: convert the workspace faithfully or refuse it. A legacy workspace is more than its issue rows, so carry across everything attached to them too. Timestamps need the same care: the current format keeps times in UTC at whole-second resolution, so carry each legacy time across as UTC rounded to the nearest second, and if that rounded value lands outside what the current format can hold, treat it as something you cannot convert faithfully and refuse the workspace rather than quietly nudging it into range.

## User stories / requirements

- Pointing the command at an authenticated legacy SQLite workspace whose issues carry labels, dependencies, and comments produces current-format canonical JSONL. Importing that output into a fresh current workspace brings every issue and all of its labels, dependencies, and comments across intact.
- A source that cannot be converted faithfully is refused outright, and nothing is written to the output. That holds whether its release marker, table definitions, or foreign-key shape is not a supported authenticated schema, or it carries a value the current importer would silently drop, default, truncate, or deduplicate.
- Legacy timestamps are carried into the current format's time contract exactly. A value that cannot be represented there without loss causes the conversion to be refused rather than quietly rounded or adjusted.
- An authenticated source that happens to contain zero issues still converts successfully, producing well-formed, empty current-format output rather than an error or nothing at all.
