## Task

we're getting reports that changing a dashboard's theme in edit mode breaks saving and reloads everything. put a custom theme on a dashboard, then in edit mode open the styling properties, switch to a different theme (or clear it), and apply. two things break at once: every chart reloads and flickers instead of just recoloring, and the Save button immediately goes disabled as if there were nothing to save, so the theme change and any other pending edits can't be saved.

switching or removing a theme should recolor without reloading charts and leave pending edits intact, so the change can be saved through the UI.

this is all in the frontend. the symptom has more than one contributing cause, so make sure the fix covers both the reloading and the lost edits, not just one side. dashboards with no custom theme, and the existing theme-apply flow, should behave as they do today.

everything's offline and deps are installed, so use the frontend's existing test tooling to reproduce and check your work. dig in and fix it.
