/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
//
// Behavioral checks for the dashboard theme provider when the applied theme
// changes.
//
// WHAT IS TESTED, AND THROUGH WHICH INTERFACE
// -------------------------------------------
// Both checks drive the pre-existing, stable `CrudThemeProvider` component
// through React Testing Library and observe only its public contract: the
// `theme` prop, the children it renders, and the applied theme those children
// see through the public `useTheme()` hook.
//
// The no-remount property is observed directly, not inferred from spy calls: a
// child increments a module-level counter on mount. A theme switch that keeps
// the provider identity stable (updates the theme in place) leaves the counter
// unchanged; a switch that rebuilds the provider remounts the subtree and bumps
// the counter. Nothing asserts HOW the instance is stabilized (ref, lazy state,
// empty-dependency memo), where the base-theme merge is computed, or which hook
// applies the update — any mechanism that keeps the subtree mounted while the
// applied theme changes passes.
//
import { type ReactNode, useEffect } from 'react';
import { render, screen } from 'spec/helpers/testing-library';
import { logging } from '@apache-superset/core/utils';
import { Theme, useTheme } from '@apache-superset/core/theme';
import getBootstrapData from 'src/utils/getBootstrapData';
import CrudThemeProvider from 'src/components/CrudThemeProvider';

jest.mock('src/utils/getBootstrapData', () => ({
  __esModule: true,
  default: jest.fn(() => ({
    common: { theme: { default: {}, dark: {} } },
  })),
}));

const mockGetBootstrapData = getBootstrapData as jest.MockedFunction<
  typeof getBootstrapData
>;

let mountCount = 0;
function MountProbe() {
  const theme = useTheme() as Record<string, unknown>;
  useEffect(() => {
    mountCount += 1;
  }, []);
  return <span data-test="primary">{String(theme.colorPrimary ?? '')}</span>;
}

function themeProp(id: number, name: string, config: unknown) {
  return { id, theme_name: name, json_data: JSON.stringify(config) };
}

beforeEach(() => {
  jest.restoreAllMocks();
  mountCount = 0;
  mockGetBootstrapData.mockReturnValue({
    common: { theme: { default: {}, dark: {} } },
  } as unknown as ReturnType<typeof getBootstrapData>);
});

describe('dashboard theme provider on theme change', () => {
  it('does not remount the dashboard subtree when the applied theme changes', () => {
    const { rerender } = render(
      <CrudThemeProvider
        theme={themeProp(1, 'A', { token: { colorPrimary: '#aaaaaa' } })}
      >
        <MountProbe />
      </CrudThemeProvider>,
    );
    const baselineMounts = mountCount;
    expect(screen.getByTestId('primary').textContent).toBe('#aaaaaa');

    rerender(
      <CrudThemeProvider
        theme={themeProp(2, 'B', { token: { colorPrimary: '#bbbbbb' } })}
      >
        <MountProbe />
      </CrudThemeProvider>,
    );

    // The applied theme actually changed ...
    expect(screen.getByTestId('primary').textContent).toBe('#bbbbbb');
    // ... and the dashboard subtree was updated in place rather than remounted,
    // so charts recolor without reloading.
    expect(mountCount).toBe(baselineMounts);
  });

  it('warns and keeps rendering when applying a theme fails', () => {
    // Make theme construction fail. A defensive provider contains the failure:
    // it logs a warning and still renders its children instead of crashing the
    // dashboard. This is observed through the component, not the internal
    // error-handling code, so any containment approach passes.
    jest.spyOn(Theme, 'fromConfig').mockImplementation(() => {
      throw new Error('theme construction failed');
    });
    jest.spyOn(logging, 'warn').mockImplementation();

    render(
      <CrudThemeProvider
        theme={themeProp(1, 'Custom Theme', {
          token: { colorPrimary: '#ff0000' },
        })}
      >
        <div>Dashboard Content</div>
      </CrudThemeProvider>,
    );

    expect(logging.warn).toHaveBeenCalled();
    expect(screen.getByText('Dashboard Content')).toBeInTheDocument();
  });
});
