/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
//
// Behavioral checks for what the applied dashboard theme carries after the
// theme is switched in place over a base theme.
//
// WHAT IS TESTED, AND THROUGH WHICH INTERFACE
// -------------------------------------------
// Everything is observed at the user-facing boundary: the dashboard theme
// provider (`CrudThemeProvider`) is rendered with React Testing Library, and a
// child reads the APPLIED theme through the public `useTheme()` hook (the
// resolved tokens and ECharts overrides every dashboard component actually
// sees). The `Theme` factory and `setConfig` are NOT spied, NOT called
// directly, and their signatures are never asserted. A child also records its
// own mount count, so each check drives a real theme SWITCH and reads the
// resolved outcome after it.
//
// Why a switch (not a single render): on the pre-fix code a fresh theme object
// is built for every applied theme, so the base theme's values are preserved on
// any single render regardless of the bug. The data-loss only shows up when the
// SAME applied theme instance is updated in place across a switch. These checks
// therefore switch the theme and confirm the subtree was not remounted (the
// same instance was reused) before asserting what the resolved theme carries,
// which is exactly what makes the base-token / ECharts-preservation outcome
// meaningful rather than a tautology.
//
// Any design that keeps the resolved theme carrying the config's new tokens AND
// the base theme's untouched tokens and ECharts overrides after an in-place
// switch passes, no matter where or how the merge is computed (inside the
// `Theme` class, in the provider before applying, in a helper, etc.).
//
import { type ReactNode, useEffect } from 'react';
import { render, screen } from 'spec/helpers/testing-library';
import { useTheme } from '@apache-superset/core/theme';
import getBootstrapData from 'src/utils/getBootstrapData';
import CrudThemeProvider from 'src/components/CrudThemeProvider';

jest.mock('src/utils/getBootstrapData', () => ({
  __esModule: true,
  default: jest.fn(() => ({
    common: { theme: { default: {}, dark: {} } },
  })),
}));

const mockGetBootstrapData = getBootstrapData as jest.MockedFunction<
  typeof getBootstrapData
>;

// A child that reads the applied theme and counts its own mounts. If the
// subtree is remounted on a theme switch, `mountCount` increments; if the theme
// is updated in place, it stays put — so a passing assertion on the resolved
// values is anchored to a genuine in-place update.
let mountCount = 0;
function ThemeProbe() {
  const theme = useTheme() as Record<string, unknown>;
  useEffect(() => {
    mountCount += 1;
  }, []);
  return (
    <div>
      <span data-test="primary">{String(theme.colorPrimary ?? '')}</span>
      <span data-test="error">{String(theme.colorError ?? '')}</span>
      <span data-test="link">{String(theme.colorLink ?? '')}</span>
      <span data-test="echarts">
        {JSON.stringify(theme.echartsOptionsOverrides ?? null)}
      </span>
      <span data-test="echarts-by-type">
        {JSON.stringify(theme.echartsOptionsOverridesByChartType ?? null)}
      </span>
    </div>
  );
}

function themeProp(id: number, name: string, config: unknown) {
  return { id, theme_name: name, json_data: JSON.stringify(config) };
}

beforeEach(() => {
  jest.restoreAllMocks();
  mountCount = 0;
});

describe('applied dashboard theme after an in-place theme switch', () => {
  it('keeps config tokens and fills untouched tokens from the base theme', () => {
    const baseTheme = {
      token: { colorPrimary: '#111111', colorError: '#ff0000' },
    };
    mockGetBootstrapData.mockReturnValue({
      common: { theme: { default: baseTheme, dark: {} } },
    } as unknown as ReturnType<typeof getBootstrapData>);

    const { rerender } = render(
      <CrudThemeProvider
        theme={themeProp(1, 'A', { token: { colorPrimary: '#aaaaaa' } })}
      >
        <ThemeProbe />
      </CrudThemeProvider>,
    );
    const baselineMounts = mountCount;

    // Switch to a config that only overrides the primary color.
    rerender(
      <CrudThemeProvider
        theme={themeProp(2, 'B', { token: { colorPrimary: '#0000ff' } })}
      >
        <ThemeProbe />
      </CrudThemeProvider>,
    );

    // The switch updated the theme in place (no remount) ...
    expect(mountCount).toBe(baselineMounts);
    // ... the config wins for the token it sets ...
    expect(screen.getByTestId('primary').textContent).toBe('#0000ff');
    // ... and the base theme fills the token the config leaves untouched.
    expect(screen.getByTestId('error').textContent).toBe('#ff0000');
  });

  it('keeps the base theme ECharts overrides when the new config sets none', () => {
    const baseTheme = {
      token: { colorPrimary: '#111111' },
      echartsOptionsOverrides: { backgroundColor: '#123456' },
      echartsOptionsOverridesByChartType: {
        pie: { itemStyle: { borderWidth: 2 } },
      },
    };
    mockGetBootstrapData.mockReturnValue({
      common: { theme: { default: baseTheme, dark: {} } },
    } as unknown as ReturnType<typeof getBootstrapData>);

    const { rerender } = render(
      <CrudThemeProvider
        theme={themeProp(1, 'A', { token: { colorPrimary: '#aaaaaa' } })}
      >
        <ThemeProbe />
      </CrudThemeProvider>,
    );
    const baselineMounts = mountCount;

    // The incoming config carries no ECharts overrides. After switching in
    // place, the base theme's chart customizations must survive the update, the
    // same way its untouched tokens do.
    rerender(
      <CrudThemeProvider
        theme={themeProp(2, 'B', { token: { colorPrimary: '#0000ff' } })}
      >
        <ThemeProbe />
      </CrudThemeProvider>,
    );

    expect(mountCount).toBe(baselineMounts);
    expect(screen.getByTestId('echarts').textContent).toBe(
      JSON.stringify({ backgroundColor: '#123456' }),
    );
    expect(screen.getByTestId('echarts-by-type').textContent).toBe(
      JSON.stringify({ pie: { itemStyle: { borderWidth: 2 } } }),
    );
  });

  it('aligns colorLink to the new primary when the config sets no colorLink', () => {
    const baseTheme = {
      token: {
        colorPrimary: '#111111',
        colorError: '#ff0000',
        colorLink: '#999999',
      },
    };
    mockGetBootstrapData.mockReturnValue({
      common: { theme: { default: baseTheme, dark: {} } },
    } as unknown as ReturnType<typeof getBootstrapData>);

    const { rerender } = render(
      <CrudThemeProvider
        theme={themeProp(1, 'A', { token: { colorPrimary: '#aaaaaa' } })}
      >
        <ThemeProbe />
      </CrudThemeProvider>,
    );
    const baselineMounts = mountCount;

    rerender(
      <CrudThemeProvider
        theme={themeProp(2, 'B', { token: { colorPrimary: '#0000ff' } })}
      >
        <ThemeProbe />
      </CrudThemeProvider>,
    );

    // Links follow the brand/primary color: a config that overrides colorPrimary
    // without colorLink leaves the applied theme's colorLink matching the new
    // primary, not the base theme's old link color.
    expect(mountCount).toBe(baselineMounts);
    expect(screen.getByTestId('link').textContent).toBe('#0000ff');
  });
});
