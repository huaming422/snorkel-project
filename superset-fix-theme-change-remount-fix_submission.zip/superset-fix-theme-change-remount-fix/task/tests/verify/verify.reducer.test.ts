/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
//
// Behavioral check for the dashboard-state reducer's refresh-frequency branch.
//
// WHAT IS TESTED, AND THROUGH WHICH INTERFACE
// -------------------------------------------
// This drives the pre-existing default-exported reducer with the pre-existing
// exported `SET_REFRESH_FREQUENCY` action-type constant, and reads the public
// state shape it returns. The assertions are order-independent on the resulting
// boolean, so any logically-equivalent rewrite of the branch passes.
//
import dashboardStateReducer from 'src/dashboard/reducers/dashboardState';
import { SET_REFRESH_FREQUENCY } from 'src/dashboard/actions/dashboardState';
import { DashboardState } from 'src/dashboard/types';

// The reducer is authored in JS; type it so the cases read clearly.
type DashboardStateReducer = (
  state: Partial<DashboardState> | undefined,
  action: any,
) => Partial<DashboardState>;
const reducer = dashboardStateReducer as DashboardStateReducer;

describe('refresh-frequency reducer and unsaved changes', () => {
  it('may add unsaved changes but never clears existing ones', () => {
    // A persistent update records the new frequency and marks the dashboard
    // dirty.
    expect(
      reducer({} as Partial<DashboardState>, {
        type: SET_REFRESH_FREQUENCY,
        refreshFrequency: 30,
        isPersistent: true,
      }),
    ).toEqual(
      expect.objectContaining({
        refreshFrequency: 30,
        shouldPersistRefreshFrequency: true,
        hasUnsavedChanges: true,
      }),
    );

    // A non-persistent update (e.g. a header's unmount cleanup) must preserve,
    // not clear, a pending dirty flag.
    expect(
      reducer({ hasUnsavedChanges: true } as Partial<DashboardState>, {
        type: SET_REFRESH_FREQUENCY,
        refreshFrequency: 0,
        isPersistent: false,
      }),
    ).toEqual(
      expect.objectContaining({
        refreshFrequency: 0,
        shouldPersistRefreshFrequency: false,
        hasUnsavedChanges: true,
      }),
    );

    // With nothing pending, a non-persistent update does not spuriously mark the
    // dashboard dirty.
    expect(
      reducer({ hasUnsavedChanges: false } as Partial<DashboardState>, {
        type: SET_REFRESH_FREQUENCY,
        refreshFrequency: 0,
        isPersistent: false,
      }).hasUnsavedChanges,
    ).toBe(false);
  });
});
