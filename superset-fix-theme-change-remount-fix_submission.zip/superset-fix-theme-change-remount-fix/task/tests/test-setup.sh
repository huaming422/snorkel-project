#!/usr/bin/env bash
# Environment bootstrap for the verifier. Sourced (not exec'd) by the harbor
# runner, so any env vars set here stay live for the verifier subprocess.
#
# This is a frontend (TypeScript/React) task. Jest runs the repo's TypeScript
# sources directly via babel-jest — there is NO build/dist step to regenerate,
# so the agent's edits under superset-frontend/{src,packages}/ are visible to
# the verifier immediately. All this script does is guarantee the dependency
# closure is intact so `npx jest` can run.
#
# The closure is already baked into the image at the base commit (see
# image/Dockerfile: `npm ci` runs during the build), so the install below is
# normally an offline no-op. It stays offline-first because the agent phase —
# and the offline fold of the gate — runs with the network cut.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/superset}"
export REPO_DIR
FRONTEND_DIR="$REPO_DIR/superset-frontend"
cd "$FRONTEND_DIR"

# Keep npm strictly offline: the closure is baked, so a cache miss is a real
# error we want to see, not a silent online fetch. npm_config_cache is already
# exported by the image to the warm build-time cache path.
export npm_config_offline=true
export npm_config_audit=false
export npm_config_fund=false

# Fast path: if node_modules already has the Jest binary resolvable, the baked
# closure is intact and we skip the install entirely.
if [ -x node_modules/.bin/jest ]; then
    echo "test-setup.sh: baked node_modules intact (jest present); skipping install."
else
    echo "test-setup.sh: node_modules incomplete — reinstalling from offline cache..."
    npm ci --offline --no-audit --no-fund > /tmp/ssb-npm-ci.log 2>&1 \
        || { echo "test-setup.sh: offline npm ci failed; tail:" >&2; tail -80 /tmp/ssb-npm-ci.log >&2; exit 1; }
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR node=$(node --version 2>/dev/null || echo unknown) jest=$(node_modules/.bin/jest --version 2>/dev/null || echo unknown)"
