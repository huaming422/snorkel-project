## Task

Masonry already has overlay widgets like tooltips and overlay boxes, but there's
no drop-down selector yet. We want a first-class one an app can drop straight
into a layout: a compact control that shows the option currently chosen and,
when the user activates it, lets them switch to one of the others.

Beyond the picking itself, the control needs to be reachable by assistive
technology, as a combo-box-style control whose menu rows are exposed as
selectable items.

This is new capability to build, not a malfunction to track down. Pixel output
is out of scope; what counts is the behavior, which is observable without a
display.

## User stories / requirements

- When the user activates the selector, it opens a floating menu that presents every available option as its own selectable entry. The menu sits above the surrounding UI, so each option stays reachable even though the menu overlaps whatever is behind it.
- When the user picks an option from the open menu, the selector reports that new choice back to the application, naming both the chosen option's text and its position in the list of options. The choice is reported once per pick.
- After the user picks an option, the selector now shows that newly chosen option as its current value, and the open menu closes on its own.
- When the user dismisses the menu without choosing, by clicking away from it or cancelling, the current choice is left exactly as it was and no new choice is reported. Clicking away or cancelling is never treated as a selection.
