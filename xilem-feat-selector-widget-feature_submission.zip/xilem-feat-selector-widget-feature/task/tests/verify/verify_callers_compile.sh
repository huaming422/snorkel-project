#!/usr/bin/env bash
#
# Structural verifier — confirms the whole workspace still compiles after the
# agent's change.
#
# The feature requires a second mutate-pass entry point that addresses a widget
# by identity (the floating menu lives in a different subtree from the control
# it must drive, so it has no typed handle back to it). Adding that second
# capability alongside the pre-existing by-handle one is where callers break: if
# the split renames or re-signs the existing by-handle method, every existing
# call site must be updated to match. A half-done split leaves the workspace
# uncompilable — and this check is what catches it. It names no
# submission-chosen symbol; it only asserts the whole workspace builds.
#
# `--all-features` is required: the mutate-pass API and its callers live behind
# feature-gated code paths across the workspace crates, and the default feature
# set would not compile every caller. The image pre-warms
# `cargo test --locked --workspace --all-features --no-run` into the default
# debug profile, so a `cargo check --workspace --all-features` here is a
# warm-cache subset (lib/bin targets only) and runs in well under a minute. A
# cold check from a clean target/ takes a few minutes; the timeout covers both.
#
# The by-identity capability itself is exercised behaviorally by the validation
# stories (a pick routes a menu-row click through it into the control to report
# the choice), so this structural check is the compile-integration half only.
#
# The runner cwd is {repo_dir} (/repo/xilem); the workspace root is the repo
# root. Resolution is offline against the warm cargo cache.
#
# Exit codes:
#   0        — the workspace checks cleanly
#   non-zero — propagates the cargo failure

set -euo pipefail

export RUSTUP_HOME="${RUSTUP_HOME:-/usr/local/rustup}"
export CARGO_HOME="${CARGO_HOME:-/usr/local/cargo}"
export PATH="$CARGO_HOME/bin:$PATH"
export CARGO_NET_OFFLINE=true

cd /repo/xilem

cargo check --workspace --all-features
