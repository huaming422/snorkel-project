#!/usr/bin/env bash
# Validation setup: runs after the agent applies its edits, before the stories.
# Three jobs:
#   1. Give the `masonry` crate's integration-test build the two small JSON
#      crates its generated parameter helper relies on. That helper (injected
#      into masonry/tests/ by the cargo-test runner) uses `#[derive(Deserialize)]`
#      and `serde_json::Value` to read each case's inputs/expected, but masonry
#      itself ships neither crate in its dev-dependencies. Both versions are
#      already pinned in the workspace Cargo.lock and warm in the image's cargo
#      cache, so this resolves fully offline.
#   2. Drop a small SHARED helper module into masonry/tests/common/mod.rs. It
#      factors the generic, submission-neutral test plumbing (walking the
#      accessibility tree by role, reading a row's accessible text, a node's
#      centre point, and the control's displayed text from the widget tree) out
#      of every story file. It names nothing the submission introduces — only
#      Masonry's stable, pre-existing headless test surface — so each story file
#      stays short and focuses on the part it must discover from the patch (the
#      control's constructor, the action it emits, how a pick is performed).
#   3. Warm the masonry test build incrementally, so each per-story
#      `cargo test --test ...` is a fast relink rather than a cold compile.
# Idempotent: re-running neither duplicates the dependency lines, re-fetches, nor
# leaves a stale helper (the helper file is rewritten wholesale each run).
set -euo pipefail

REPO=/repo/xilem
MANIFEST="$REPO/masonry/Cargo.toml"
TESTS_DIR="$REPO/masonry/tests"

export RUSTUP_HOME="${RUSTUP_HOME:-/usr/local/rustup}"
export CARGO_HOME="${CARGO_HOME:-/usr/local/cargo}"
export PATH="$CARGO_HOME/bin:$PATH"
# The verifier phase has gateway-only network. Force every cargo resolution to
# use the warm cache so a stray lookup fails fast instead of hanging.
export CARGO_NET_OFFLINE=true

echo "validation-setup: rustc=$(rustc --version 2>&1 | head -1)"
echo "validation-setup: cargo=$(cargo --version 2>&1 | head -1)"
echo "validation-setup: manifest=$MANIFEST"

test -f "$MANIFEST" || {
    echo "ERROR: masonry manifest missing at $MANIFEST" >&2
    exit 1
}

# Step 1: Add the JSON-reading crates to masonry's [dev-dependencies] exactly
# once. Pinned to the versions already present in the workspace lockfile.
if grep -qE '^serde_json[[:space:]]*=' "$MANIFEST"; then
    echo "validation-setup: JSON crates already present in masonry dev-dependencies; skipping injection."
else
    echo "validation-setup: adding serde + serde_json to masonry [dev-dependencies]..."
    # The grading container is a minimal Ubuntu + Rust image with no general
    # Python on PATH, so do the one-time manifest edit with awk (present in the
    # base image). Insert the two JSON crates immediately after the first
    # [dev-dependencies] header line, pinned to the lockfile versions. Guard that
    # the header exists; bail loudly if the manifest layout ever changes.
    grep -qE '^\[dev-dependencies\]' "$MANIFEST" || {
        echo "ERROR: no [dev-dependencies] table in masonry Cargo.toml" >&2
        exit 1
    }
    awk '
        { print }
        /^\[dev-dependencies\]/ && !injected {
            print "serde = { version = \"1.0.228\", features = [\"derive\"] }"
            print "serde_json = \"1.0.149\""
            injected = 1
        }
    ' "$MANIFEST" > "$MANIFEST.tmp" && mv "$MANIFEST.tmp" "$MANIFEST"
fi

# Smoke guard: the injection MUST be visible now, or every story would fail to
# compile its parameter helper with the same opaque error.
grep -qE '^serde_json[[:space:]]*=' "$MANIFEST" || {
    echo "ERROR: serde_json still absent from $MANIFEST after injection" >&2
    exit 1
}
grep -qE '^serde[[:space:]]*=' "$MANIFEST" || {
    echo "ERROR: serde still absent from $MANIFEST after injection" >&2
    exit 1
}
echo "validation-setup: dev-dependency injection confirmed."

# Step 2: Write the shared helper module. A tests/<name>/mod.rs subdirectory is
# NOT itself compiled as an integration-test binary by cargo; it is only built
# when a top-level tests/*.rs file declares `mod common;`. So this adds no extra
# test target — it is a library each story file pulls in. Everything here speaks
# only to Masonry's stable test surface (accesskit tree + widget tree + Label,
# the framework's text-bearing widget); it names nothing the submission defines.
mkdir -p "$TESTS_DIR/common"
cat > "$TESTS_DIR/common/mod.rs" <<'RUST_HELPER_EOF'
// Shared, submission-neutral test plumbing for the selector validation stories.
//
// Each helper speaks ONLY to Masonry's stable, pre-existing headless test
// surface: the accessibility tree (roles, labels/values, bounding boxes) and the
// widget tree (descendant widgets and their state). None of it names the control
// type, the action type, or the modules the submission introduces — the story
// files discover those from the patch. These functions just remove the generic
// tree-walking boilerplate every story would otherwise repeat verbatim.
#![allow(dead_code)]

use masonry::accesskit::{NodeId, Role};
use masonry::core::{NewWidget, PointerButton, Widget, WidgetId};
use masonry::kurbo::Point;
use masonry::theme::default_property_set;
use masonry::widgets::{Flex, Label};
use masonry_testing::TestHarness;

/// Build a test harness whose root places the already-built, already-tagged
/// `control` at the TOP of a vertical layout with flexible empty space below it,
/// then render once so the harness is ready to query. Returns the harness; fetch
/// the control back with `harness.get_widget(tag)` using the tag you created it
/// with.
///
/// The surrounding empty space is deliberate and is why every story builds the
/// control this way. The floating menu opens downward from the control into that
/// space, so each row lands INSIDE the 400x400 window and is collectible; and the
/// leftover area is window that is neither the control nor a menu row — the point
/// `click_away_from_menu` needs for a dismissal that is not a re-activation. A
/// control created as the bare root would instead fill the whole window, leaving
/// no "away" to click and pushing the menu's downward origin to the window edge.
///
/// `control` is taken already-constructed and already-tagged, so this names
/// nothing the submission defines — only Masonry's stable layout container.
pub fn harness_with_control(control: NewWidget<impl Widget + ?Sized>) -> TestHarness<Flex> {
    let root = Flex::column().with_fixed(control).with_spacer(1.0);
    let mut harness = TestHarness::create(default_property_set(), NewWidget::new(root));
    harness.render();
    harness
}

/// The accesskit role of one node, formatted as its `{:?}` name (e.g.
/// `"ComboBox"`, `"MenuItem"`); empty string if the node is absent. Compare it
/// against the expected role name from the case. For a widget you hold a
/// `WidgetId` for, pass `widget_id.into()`.
pub fn node_role_name(harness: &TestHarness<impl Widget>, id: NodeId) -> String {
    let state = harness.access_tree().state();
    state
        .node_by_id(id)
        .map(|n| format!("{:?}", n.role()))
        .unwrap_or_default()
}

/// The accessible text of every menu-row node, in tree order — the option
/// labels the open menu presents. Empty when the menu is closed.
pub fn menu_option_texts(harness: &TestHarness<impl Widget>) -> Vec<String> {
    collect_menu_rows(harness)
        .into_iter()
        .map(|id| node_text(harness, id))
        .collect()
}

/// Whether `role` is a role a drop-down/combo-box popup uses for one of its
/// selectable rows. Two conventions are both recognized and neither is pinned:
/// the accesskit menu pattern (`Role::MenuItem`) and the ARIA combobox+listbox
/// pattern (`Role::ListBoxOption`). A submission is free to expose its rows as
/// either; the spec does not fix which.
pub fn is_menu_row_role(role: Role) -> bool {
    matches!(role, Role::MenuItem | Role::ListBoxOption)
}

/// Every open menu-row node, in tree (BFS) order: the a11y nodes whose role is a
/// recognized selectable-row role (see `is_menu_row_role`). Use this — not
/// `collect_by_role(_, Role::MenuItem)` — to collect the option rows, so a
/// submission that exposes its rows as `ListBoxOption` is collected identically
/// to one that uses `MenuItem`. `.len()` gives the row count; index it for a
/// specific row. Empty when the menu is closed.
pub fn collect_menu_rows(harness: &TestHarness<impl Widget>) -> Vec<NodeId> {
    let state = harness.access_tree().state();
    let mut queue = std::collections::VecDeque::new();
    queue.push_back(state.root().id());
    let mut out = Vec::new();
    while let Some(id) = queue.pop_front() {
        if let Some(node) = state.node_by_id(id) {
            if is_menu_row_role(node.role()) {
                out.push(id);
            }
            let children: Vec<_> = node.child_ids().collect();
            drop(node);
            for c in children {
                queue.push_back(c);
            }
        }
    }
    out
}

/// Whether `node_id` is a STRICT descendant of `ancestor_id` in the
/// accessibility tree — i.e. reachable by walking down from the ancestor's own
/// children (the ancestor itself does not count). Use it to prove a floating
/// menu's rows live on their own overlay subtree rather than nested inside the
/// control: a layer-based menu is a child of the overlay stack (a separate
/// subtree from the control), so its rows are NOT descendants of the control
/// node; a menu built as a clipped child widget of the control nests its rows
/// under the control node, so they ARE. Speaks only to the stable a11y tree;
/// names nothing the submission defines.
pub fn node_is_descendant_of(
    harness: &TestHarness<impl Widget>,
    ancestor_id: NodeId,
    node_id: NodeId,
) -> bool {
    let state = harness.access_tree().state();
    let Some(ancestor) = state.node_by_id(ancestor_id) else {
        return false;
    };
    let mut queue: std::collections::VecDeque<NodeId> = ancestor.child_ids().collect();
    drop(ancestor);
    while let Some(id) = queue.pop_front() {
        if id == node_id {
            return true;
        }
        if let Some(node) = state.node_by_id(id) {
            let kids: Vec<_> = node.child_ids().collect();
            drop(node);
            for k in kids {
                queue.push_back(k);
            }
        }
    }
    false
}

/// Every node in the accessibility tree whose role is `role`, in tree (BFS)
/// order. Use it to locate the control (combo-box role). For the menu rows use
/// `collect_menu_rows` instead, which accepts either recognized row role.
pub fn collect_by_role(harness: &TestHarness<impl Widget>, role: Role) -> Vec<NodeId> {
    let state = harness.access_tree().state();
    let mut queue = std::collections::VecDeque::new();
    queue.push_back(state.root().id());
    let mut out = Vec::new();
    while let Some(id) = queue.pop_front() {
        if let Some(node) = state.node_by_id(id) {
            if node.role() == role {
                out.push(id);
            }
            let children: Vec<_> = node.child_ids().collect();
            drop(node);
            for c in children {
                queue.push_back(c);
            }
        }
    }
    out
}

/// The accessible text of one node: its own `label()` if non-empty, else the
/// first non-empty `value()`/`label()` found among its children/grandchildren
/// (so a row whose text lives in a descendant text node is still read).
pub fn node_text(harness: &TestHarness<impl Widget>, id: NodeId) -> String {
    let state = harness.access_tree().state();
    let Some(node) = state.node_by_id(id) else {
        return String::new();
    };
    if let Some(t) = node.label() {
        if !t.is_empty() {
            return t;
        }
    }
    let children: Vec<_> = node.child_ids().collect();
    drop(node);
    for cid in children {
        if let Some(child) = state.node_by_id(cid) {
            if let Some(t) = child.value() {
                if !t.is_empty() {
                    return t;
                }
            }
            if let Some(t) = child.label() {
                if !t.is_empty() {
                    return t;
                }
            }
            let grand: Vec<_> = child.child_ids().collect();
            drop(child);
            for gid in grand {
                if let Some(g) = state.node_by_id(gid) {
                    if let Some(t) = g.value() {
                        if !t.is_empty() {
                            return t;
                        }
                    }
                }
            }
        }
    }
    String::new()
}

/// Window-space centre of a node's bounding box — the point to send raw
/// coordinate pointer events to when clicking a floating menu row (which lives
/// on its own layer, not the base layer `mouse_click_on` targets).
pub fn node_center(harness: &TestHarness<impl Widget>, id: NodeId) -> Point {
    let state = harness.access_tree().state();
    let bbox = state
        .node_by_id(id)
        .and_then(|n| n.bounding_box())
        .unwrap_or_else(|| panic!("node {id:?} has no bounding box"));
    Point::new((bbox.x0 + bbox.x1) / 2.0, (bbox.y0 + bbox.y1) / 2.0)
}

/// Dismiss the open menu by clicking at a window point that lies OUTSIDE every
/// menu row AND outside the control itself (so the click neither picks a row nor
/// re-activates the control), then inside the 400x400 test window. Scans a grid
/// of window points and clicks the first one that misses the union of the menu
/// rows' bounding boxes and the control's own bounding box (each padded by a
/// small margin so the chosen point sits clearly away from every edge).
///
/// This is pulled into the shared helper on purpose: hand-written point-picking
/// in each story file is both verbose and fragile. A full-window grid scan finds
/// empty space wherever the surrounding layout leaves it, so the caller only has
/// to ensure the control does not occupy the entire window (place it in a layout
/// that leaves some empty area). Panics only if no point in the whole window is
/// free, which means the control was built to fill the window and there is no
/// "away" to click — build the selector with empty space around it.
pub fn click_away_from_menu(harness: &mut TestHarness<impl Widget>, control_id: WidgetId) {
    const W: f64 = 400.0;
    const H: f64 = 400.0;
    const STEP: f64 = 20.0;
    const EDGE: f64 = 4.0;
    const PAD: f64 = 6.0;
    let point = {
        let state = harness.access_tree().state();
        // Collect obstacle boxes as plain (x0, y0, x1, y1) tuples read from the
        // node bounding boxes' fields, so this never has to name the a11y crate's
        // Rect type. The menu rows are collapsed into their single UNION box, not
        // kept as separate per-row boxes: the gaps between rows and the menu's own
        // padding are still part of the open menu, and a click there would land on
        // the menu container rather than clear of it. Treating the whole menu span
        // as one obstacle keeps the chosen point outside the menu entirely. The
        // control's own box is the second obstacle.
        let mut obstacles: Vec<(f64, f64, f64, f64)> = Vec::new();
        let mut menu: Option<(f64, f64, f64, f64)> = None;
        let mut queue = std::collections::VecDeque::new();
        queue.push_back(state.root().id());
        while let Some(id) = queue.pop_front() {
            if let Some(node) = state.node_by_id(id) {
                if is_menu_row_role(node.role()) {
                    if let Some(b) = node.bounding_box() {
                        menu = Some(match menu {
                            None => (b.x0, b.y0, b.x1, b.y1),
                            Some(m) => (m.0.min(b.x0), m.1.min(b.y0), m.2.max(b.x1), m.3.max(b.y1)),
                        });
                    }
                }
                let kids: Vec<_> = node.child_ids().collect();
                drop(node);
                for k in kids {
                    queue.push_back(k);
                }
            }
        }
        if let Some(m) = menu {
            obstacles.push(m);
        }
        if let Some(b) = state
            .node_by_id(control_id.into())
            .and_then(|n| n.bounding_box())
        {
            obstacles.push((b.x0, b.y0, b.x1, b.y1));
        }
        // A point counts as blocked if it is within PAD of any obstacle box, so
        // the chosen click lands clearly away from every edge.
        let hits = |p: Point, b: &(f64, f64, f64, f64)| {
            p.x >= b.0 - PAD && p.x <= b.2 + PAD && p.y >= b.1 - PAD && p.y <= b.3 + PAD
        };
        let mut found: Option<Point> = None;
        let mut y = EDGE;
        while y <= H - EDGE && found.is_none() {
            let mut x = EDGE;
            while x <= W - EDGE {
                let p = Point::new(x, y);
                if !obstacles.iter().any(|b| hits(p, &b)) {
                    found = Some(p);
                    break;
                }
                x += STEP;
            }
            y += STEP;
        }
        found.unwrap_or_else(|| {
            panic!("no window point is free of the menu and the control; build the selector so it does not fill the whole test window")
        })
    };
    harness.mouse_move(point);
    harness.mouse_button_press(PointerButton::Primary);
    harness.mouse_button_release(PointerButton::Primary);
}

/// The text the control currently displays, read from the WIDGET tree: the text
/// of the first descendant `Label` (Masonry's text-bearing widget) under
/// `widget_id`. `None` if the subtree has no Label. The accessibility node of a
/// combo-box-style control does not expose its current value as node text, so
/// read the shown value this way rather than from the a11y tree.
pub fn displayed_text(harness: &TestHarness<impl Widget>, widget_id: WidgetId) -> Option<String> {
    let root = harness.get_widget_with_id(widget_id);
    if let Some(l) = root.downcast::<Label>() {
        return Some(l.text().to_string());
    }
    for child in root.children() {
        if let Some(l) = child.downcast::<Label>() {
            return Some(l.text().to_string());
        }
        for gc in child.children() {
            if let Some(l) = gc.downcast::<Label>() {
                return Some(l.text().to_string());
            }
        }
    }
    None
}
RUST_HELPER_EOF

test -f "$TESTS_DIR/common/mod.rs" || {
    echo "ERROR: shared helper module not written to $TESTS_DIR/common/mod.rs" >&2
    exit 1
}
echo "validation-setup: shared helper module written to masonry/tests/common/mod.rs."

# Step 3: Warm the masonry test build with the agent's edits applied. This is a
# best-effort speedup, NOT a gate: if the submission does not compile, we let
# the per-story cargo invocations surface that as the story outcome rather than
# aborting setup here. Resolution is offline against the warm cache.
echo "validation-setup: warming masonry test build (incremental)..."
# Warm with the SAME feature set each per-story run uses (the crate's default
# features), so this is a warm relink for the build the stories actually do rather
# than compiling a different feature fingerprint that the stories cannot reuse.
if ( cd "$REPO" && cargo test -p masonry --no-run --offline > /tmp/masonry_warm.log 2>&1 ); then
    echo "validation-setup: masonry test build warmed."
else
    echo "validation-setup: warm build did not complete cleanly (last lines):"
    tail -40 /tmp/masonry_warm.log || true
    echo "validation-setup: continuing; per-story runs will report compile outcomes."
fi

# Final guard: cargo must at least be runnable in the workspace, or every story
# would fail identically with an environment error rather than a real outcome.
( cd "$REPO" && cargo --version >/dev/null )

echo "validation-setup: done."
