#!/usr/bin/env bash
# No services to start, no data to seed: the image pre-warms the full cargo
# cache (deps fetched + workspace test binaries built at the base commit) and
# the verifier is self-contained. The agent phase is offline (agent_offline),
# so every dependency the focused tests need is already in the image.
set -euo pipefail

# The verifier phase has network (model gateway only); the agent phase does
# not. Make any stray cargo resolution fail fast against the warm cache rather
# than hang on a dead network. Scoped to this shell's cargo invocations.
export CARGO_NET_OFFLINE=true

echo "[test-setup] Rust version:    $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:   $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Workspace root:  /repo/xilem"
echo "[test-setup] Setup complete."
