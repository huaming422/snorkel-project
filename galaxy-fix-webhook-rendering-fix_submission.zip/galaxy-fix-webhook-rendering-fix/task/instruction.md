## Task

the webhook plugin panels on the tool and workflow pages stopped working. the container still mounts, but it sits empty where the content used to be: no header, no image, no body. nothing errors out visibly either, so at a glance the page looks fine, it's just blank where a webhook should be.

it's not every panel. at least one example webhook still renders normally, which makes it look like a few specific plugins are the problem rather than the whole framework. the plugin files themselves weren't touched. this started after a recent round of client-side cleanup that changed which third-party helpers get exposed as globals. that cleanup was deliberate and should stay — don't bring the dropped globals back; the webhooks that broke need to work against what the client still exposes.

dig in and get the webhook panels rendering their content again. keep it narrow: the plugins already rely on specific element ids and css, and the fix shouldn't require touching those.
