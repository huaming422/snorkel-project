#!/usr/bin/env bash
# tests/test-setup.sh — Ensure the galaxy client workspace can run vitest so
# the behavioural verifier executes. Idempotent.
#
# The image pre-installs the client's pnpm dependency closure at the base
# commit with `pnpm install --frozen-lockfile` (image block 10) against a warm
# pnpm store, so the install below is an offline no-op in normal operation. It
# only re-materialises node_modules if an agent edit wiped it. No new
# dependency is ever fetched (this task introduces none), so this stays
# offline-first.

set -euo pipefail

cd /repo/galaxy/client

# pnpm install (offline replay against the pre-fetched store). Try the
# offline path first; fall back to a plain frozen install with a logged notice
# only if the offline replay cannot satisfy the lockfile from the warm store.
if [ ! -d node_modules/.pnpm ]; then
    pnpm install --frozen-lockfile --offline 2>&1 | tail -10 \
        || { echo "[test-setup] offline replay incomplete; retrying frozen install"; \
             pnpm install --frozen-lockfile 2>&1 | tail -10; }
fi

# Sanity: vitest is reachable from the client workspace.
( node --version && pnpm exec vitest --version ) \
    || echo "[test-setup] WARN: vitest --version failed; tests may not run"

echo "[test-setup] galaxy client vitest env ready"
