// @ts-nocheck
//
// Behavioural + structural verifier for galaxy-fix-webhook-rendering.
//
// Runs under the galaxy client vitest workspace (happy-dom). It gates the two
// offline-reproducible layers of the empty-webhook-panel regression through
// pre-existing, stable client interfaces — never importing any symbol the fix
// introduces, so any equivalent solution passes regardless of HOW the panels
// are made to render again.
//
// Interfaces under test (both pre-date the fix):
//   1. The Webhook.vue component's mounted lifecycle and the `appendScriptStyle`
//      injection seam (client/src/utils/utils.ts). The component sets its mount
//      point id and then injects the plugin script; the injected script targets
//      `#<id>` the instant it runs, so that element must already be in the DOM.
//      We mount the component with the two pre-existing util modules
//      (`@/utils/webhooks`, `@/utils/utils`) replaced by stand-ins that record
//      whether the mount point exists at injection time.
//   2. The served plugin `script.js` files (test/functional/webhooks/{phdcomics,
//      xkcd}/script.js) — static text the framework injects verbatim into the
//      page and runs in global scope. Observable two ways: (a) the executable
//      text uses no helper the client stopped exposing as a global; (b) running
//      the script body in a page that exposes the globals the client still ships
//      (jQuery) but none of the removed ones (Backbone, underscore), with its
//      mount point present, throws nothing, fills the container, and fetches its
//      comic data from the same-origin Galaxy backend rather than a third-party
//      origin directly.
//
// Retained vs removed globals. The client cleanup removed ONLY Backbone and
// underscore from the global bundle (client/src/entry/libs.js). jQuery is still
// exposed as window.$ / window.jQuery there, so a script that uses jQuery keeps
// working on the real page. The scope T3 runs the script in mirrors that: jQuery
// is present, Backbone and underscore are absent. A served script is therefore
// free to use any retained global; it fails only if it reaches for a removed one.
//
// Every test is fail_to_pass — each distinguishes a correct fix from the
// pre-fix tree:
//   T1  mount-timing (the primary signal): the mount point exists when the
//       script is injected. Pre-fix injects in the same tick it sets the id,
//       before the v-if div flushes -> recorded absent -> fails.
//   T2  structural: neither served script's executable code references a helper
//       removed from the client globals (Backbone / underscore).
//   T3  behavioural: each served script, run in a page exposing the retained
//       globals but not the removed ones with its mount point present, throws
//       nothing, populates its container, and requests its comic data from the
//       same-origin Galaxy endpoint (not a third-party origin directly).
//
// The mount-timing wait is deliberately mechanism-agnostic: it settles both
// microtask-based deferrals (an awaited tick, a post-flush watcher) and
// macrotask-based ones (a frame callback), so every equivalent way of injecting
// after the mount point renders is accepted.

import { existsSync, readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

import { getLocalVue } from "@tests/vitest/helpers";
import { mount } from "@vue/test-utils";
import flushPromises from "flush-promises";
import jQuery from "jquery";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import Webhook from "./Webhook.vue";

// ---------------------------------------------------------------------------
// Mount-point-at-injection recorder (mirrors the recorder the component's own
// unit test used). The stand-in `appendScriptStyle` captures, at the exact
// moment the component would inject the plugin script, whether the mount point
// element the script will target is already present in the document.
// ---------------------------------------------------------------------------
const { WEBHOOK, mountPointPresentAtInjection } = vi.hoisted(() => ({
    // A realistic webhook model as config.yml describes one (active webhooks
    // carry `activate: true`). Keeping the flag here means a solution that
    // filters webhooks on `activate` — a defensible reading of the config —
    // still sees this fixture, so the mount-timing signal measures the timing
    // fix rather than the filter.
    WEBHOOK: { id: "phdcomics", type: ["tool"], activate: true, weight: 1, script: "/* placeholder */", styles: "" },
    mountPointPresentAtInjection: vi.fn(),
}));

vi.mock("@/utils/webhooks", () => ({
    loadWebhooks: vi.fn().mockResolvedValue([WEBHOOK]),
    pickWebhook: vi.fn().mockReturnValue(WEBHOOK),
}));

vi.mock("@/utils/utils", () => ({
    appendScriptStyle: (data: { id?: string }) => {
        mountPointPresentAtInjection(Boolean(data.id && document.getElementById(data.id)));
    },
}));

const localVue = getLocalVue();

// Settle every deferral style a correct fix might use. flushPromises drains
// microtasks (an awaited tick, a post-flush watcher); the real-timer step lets
// a frame-callback / timer deferral fire; looping until the injection is
// recorded (bounded) keeps the test fast for the common case and tolerant of
// the slower ones. No mechanism name is assumed.
async function waitForInjection(maxMs = 1500) {
    const start = Date.now();
    // Always drain microtasks first.
    await flushPromises();
    while (mountPointPresentAtInjection.mock.calls.length === 0 && Date.now() - start < maxMs) {
        await new Promise((r) => setTimeout(r, 10));
        await flushPromises();
    }
}

// ---------------------------------------------------------------------------
// Served-script helpers.
// ---------------------------------------------------------------------------

// The served plugin scripts live under <repo>/test/functional/webhooks/. The
// verifier runs from <repo>/client (config_dir) and this file is copied beside
// Webhook.vue (test_parent=client/src/components/Common). Resolve the repo root from
// either anchor so the read is robust to how the file is invoked.
function repoRoot(): string {
    const here = dirname(fileURLToPath(import.meta.url)); // .../client/src/components/Common
    const candidates = [
        resolve(process.cwd(), ".."), // cwd is .../client -> repo root
        process.cwd(), // cwd already repo root
        resolve(here, "..", "..", "..", ".."), // up from the copied-beside location
    ];
    for (const root of candidates) {
        if (existsSync(resolve(root, "test/functional/webhooks"))) {
            return root;
        }
    }
    // Fall back to the cwd-parent guess; the read below surfaces a clear error.
    return resolve(process.cwd(), "..");
}

function readServedScript(name: string): string {
    const path = resolve(repoRoot(), "test/functional/webhooks", name, "script.js");
    return readFileSync(path, "utf8");
}

// Strip line and block comments so the structural check judges executable code,
// not prose — a ported script that mentions a removed helper in a comment
// ("// replaces the old Backbone view") is self-contained and must pass.
function stripComments(source: string): string {
    return source
        .replace(/\/\*[\s\S]*?\*\//g, " ") // block comments
        .replace(/(^|[^:])\/\/[^\n]*/g, "$1 "); // line comments (keep http:// intact)
}

// The helpers the client cleanup actually removed from the page globals. A
// served script that still calls into either throws the instant it runs.
// jQuery is intentionally NOT here: it is a retained global (libs.js still sets
// window.$ / window.jQuery), so a jQuery-based script keeps working on the page.
// Patterns match usage, not passing mentions.
const REMOVED_GLOBAL_PATTERNS = [/Backbone\./, /_\.(template|each|map|extend|isEmpty)\(/];

// Globals the ported scripts must NOT depend on — the ones the cleanup removed.
// We force them undefined while a served script runs so a script that reaches
// for one throws here, exactly as it would on the real page, then restore
// whatever was there. jQuery is deliberately left in place (see RETAINED_GLOBALS).
const WITHHELD_GLOBALS = ["Backbone", "_"];

// Globals the client still exposes on the real page (libs.js). We provide them
// while a served script runs so a script using a retained global behaves exactly
// as it would in production, instead of throwing a spurious ReferenceError.
function installRetainedGlobals(): () => void {
    const saved: Record<string, unknown> = {};
    const had: Record<string, boolean> = {};
    const keys = ["$", "jQuery"];
    for (const key of keys) {
        had[key] = key in (globalThis as any);
        saved[key] = (globalThis as any)[key];
        (globalThis as any)[key] = jQuery;
    }
    return () => {
        for (const key of keys) {
            if (had[key]) {
                (globalThis as any)[key] = saved[key];
            } else {
                try {
                    delete (globalThis as any)[key];
                } catch {
                    (globalThis as any)[key] = undefined;
                }
            }
        }
    };
}

function runServedScriptInBareGlobalScope(scriptText: string): { threw: boolean; error: unknown } {
    const saved: Record<string, unknown> = {};
    const had: Record<string, boolean> = {};
    for (const key of WITHHELD_GLOBALS) {
        had[key] = key in (globalThis as any);
        saved[key] = (globalThis as any)[key];
        try {
            delete (globalThis as any)[key];
        } catch {
            (globalThis as any)[key] = undefined;
        }
    }
    try {
        // Execute exactly as the framework does: the script body wrapped in an
        // IIFE and evaluated in global scope (so bare identifiers resolve to the
        // page globals and the withheld ones are genuinely absent).
        // eslint-disable-next-line no-new-func
        const run = new Function(`(function(){\n${scriptText}\n})();`);
        run();
        return { threw: false, error: undefined };
    } catch (error) {
        return { threw: true, error };
    } finally {
        for (const key of WITHHELD_GLOBALS) {
            if (had[key]) {
                (globalThis as any)[key] = saved[key];
            } else {
                try {
                    delete (globalThis as any)[key];
                } catch {
                    (globalThis as any)[key] = undefined;
                }
            }
        }
    }
}

// A URL is third-party if it resolves to an origin other than the page's. The
// webhook comic data must be fetched from the Galaxy backend (same-origin
// relative path), never from a third-party host directly — that cross-origin
// call is exactly what breaks on an HTTPS Galaxy (no CORS headers / mixed
// content). Relative and same-origin absolute URLs resolve to the page origin.
function isThirdPartyUrl(url: string): boolean {
    try {
        const resolved = new URL(url, document.location.href);
        return resolved.origin !== document.location.origin;
    } catch {
        // Unparseable against the page URL -> treat as same-origin (a relative
        // path with unusual shape), not a third-party call.
        return false;
    }
}

describe("Webhook.vue", () => {
    beforeEach(() => {
        mountPointPresentAtInjection.mockClear();
    });

    it("injects the plugin script only after its mount point has rendered", async () => {
        mount(Webhook as object, {
            localVue,
            propsData: { type: "tool", toolId: "cat1", toolVersion: "1.0" },
            attachTo: document.body,
        });

        await waitForInjection();

        // The script is injected exactly once...
        expect(mountPointPresentAtInjection).toHaveBeenCalledTimes(1);
        // ...and the `#<id>` element the injected script targets is already in
        // the document at that moment. Injecting in the same tick the id is set
        // (before the v-if mount-point div flushes) records `false` here.
        expect(mountPointPresentAtInjection).toHaveBeenCalledWith(true);
    });
});

// The two example plugins that regressed, keyed by their own mount-point id
// (the plugin directory name == the webhook id the framework mounts under).
const SERVED_PLUGINS = [{ name: "phdcomics" }, { name: "xkcd" }];

describe("served webhook plugin scripts", () => {
    // A comic payload that satisfies either plugin's success branch (phdcomics
    // reads `src`, xkcd reads `comic.*`), so the async image load resolves
    // cleanly instead of hitting a console-logged error path.
    const comicPayload = {
        success: true,
        src: "http://example.invalid/comic.png",
        comic: { img: "http://example.invalid/comic.png", alt: "alt text", title: "comic title" },
    };

    // Every URL the served script requests its comic data from, captured across
    // both transports a script might use: `fetch` (vanilla) and XMLHttpRequest
    // (jQuery's `$.getJSON`). The mount-point render assertion is transport- and
    // library-agnostic; this lets the same-origin check be too.
    let requestedUrls: string[] = [];

    let savedFetch: unknown;
    let hadFetch: boolean;
    let RealXHR: unknown;
    let restoreRetainedGlobals: () => void;
    let errorSpy: ReturnType<typeof vi.spyOn>;
    let warnSpy: ReturnType<typeof vi.spyOn>;

    beforeEach(() => {
        requestedUrls = [];

        // The ported scripts fetch their comic through the Galaxy backend; stub
        // both transports (any url) so the async branch settles without a real
        // request while recording the url so the same-origin check can read it.
        hadFetch = "fetch" in (globalThis as any);
        savedFetch = (globalThis as any).fetch;
        (globalThis as any).fetch = vi.fn().mockImplementation((url: unknown) => {
            requestedUrls.push(String(url));
            return Promise.resolve({ json: () => Promise.resolve(comicPayload) });
        });

        // jQuery's `$.getJSON` goes through XMLHttpRequest. Replace it with a
        // minimal mock that records the url and resolves with the comic payload,
        // so a jQuery-based port behaves like a successful same-origin request.
        RealXHR = (globalThis as any).XMLHttpRequest;
        const payloadText = JSON.stringify(comicPayload);
        class MockXHR {
            constructor() {
                this.readyState = 0;
                this.status = 0;
                this.responseText = "";
                this.response = "";
                this._listeners = {};
                this.onreadystatechange = null;
                this.onload = null;
            }
            open(method: string, url: string) {
                this._url = url;
                requestedUrls.push(String(url));
                this.readyState = 1;
            }
            setRequestHeader() {}
            overrideMimeType() {}
            getAllResponseHeaders() {
                return "content-type: application/json\r\n";
            }
            getResponseHeader() {
                return "application/json";
            }
            abort() {}
            addEventListener(type: string, cb: (ev: Event) => void) {
                (this._listeners[type] = this._listeners[type] || []).push(cb);
            }
            removeEventListener() {}
            send() {
                setTimeout(() => {
                    this.readyState = 4;
                    this.status = 200;
                    this.responseText = payloadText;
                    this.response = payloadText;
                    if (typeof this.onreadystatechange === "function") {
                        this.onreadystatechange();
                    }
                    (this._listeners["readystatechange"] || []).forEach((cb) => cb.call(this, new Event("readystatechange")));
                    (this._listeners["load"] || []).forEach((cb) => cb.call(this, new Event("load")));
                    if (typeof this.onload === "function") {
                        this.onload();
                    }
                }, 0);
            }
        }
        (globalThis as any).XMLHttpRequest = MockXHR;

        // Expose the globals the client still ships (jQuery) so a script using a
        // retained global runs as it would on the real page.
        restoreRetainedGlobals = installRetainedGlobals();

        // Neutralise the workspace's fail-on-console hook for these tests: a
        // script's own async logging is not what we are gating here (we gate the
        // synchronous scaffold + no synchronous throw). A real throw is caught
        // and asserted directly, not via console.
        errorSpy = vi.spyOn(console, "error").mockImplementation(() => {});
        warnSpy = vi.spyOn(console, "warn").mockImplementation(() => {});
        document.body.innerHTML = "";
    });

    afterEach(() => {
        errorSpy.mockRestore();
        warnSpy.mockRestore();
        restoreRetainedGlobals();
        if (hadFetch) {
            (globalThis as any).fetch = savedFetch;
        } else {
            delete (globalThis as any).fetch;
        }
        (globalThis as any).XMLHttpRequest = RealXHR;
        document.body.innerHTML = "";
    });

    describe.each(SERVED_PLUGINS)("$name", ({ name }) => {
        it("references none of the helpers removed from the client globals", () => {
            const code = stripComments(readServedScript(name));
            for (const pattern of REMOVED_GLOBAL_PATTERNS) {
                expect(pattern.test(code), `${name} script still uses a removed global matching ${pattern}`).toBe(
                    false,
                );
            }
        });

        it("renders its container and fetches its comic from the same-origin backend", async () => {
            const scriptText = readServedScript(name);

            // Provide the mount point the injected script expects to find (the
            // plugin's own id, which styles.css also targets and base.md says to
            // preserve).
            const mountPoint = document.createElement("div");
            mountPoint.id = name;
            document.body.appendChild(mountPoint);

            const { threw, error } = runServedScriptInBareGlobalScope(scriptText);

            // It must not throw (e.g. a ReferenceError for a removed global).
            expect(threw, `script threw: ${error}`).toBe(false);

            // The container must be populated with DOM — the script wrote its
            // scaffold rather than dying before touching the page. Name-agnostic
            // about the internal structure the port chooses.
            expect(mountPoint.children.length).toBeGreaterThan(0);

            // Let the stubbed async comic request settle.
            await flushPromises();
            await new Promise((r) => setTimeout(r, 0));
            await flushPromises();

            // The comic data must be requested from the Galaxy backend
            // (same-origin), not fetched from a third-party host directly — the
            // direct cross-origin call is exactly the mixed-content/CORS failure
            // the fix resolves. The script must make such a request (it has to
            // fetch a comic to render one).
            expect(
                requestedUrls.length,
                `${name} script requested no comic data; it must fetch its comic from the Galaxy backend`,
            ).toBeGreaterThan(0);
            for (const url of requestedUrls) {
                expect(
                    isThirdPartyUrl(url),
                    `${name} script requested comic data from a third-party origin directly (${url}); ` +
                        `it must go through the same-origin Galaxy backend`,
                ).toBe(false);
            }
        });
    });
});
