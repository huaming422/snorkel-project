#!/usr/bin/env bash
# Verifier-side setup: runs before the verifier, WITH network available.
# The task image already installed the Rust toolchain, warmed the cargo registry
# with the base commit's --locked closure, and pre-built the full workspace
# (--locked --tests --workspace). This script only re-exports the toolchain onto
# PATH (each grade-phase shell starts fresh, so Dockerfile ENV lines are not
# inherited) and sanity-checks that the pre-baked toolchain + verifier venv are
# present. It installs nothing on the happy path; the offline agent phase relies
# on the image already carrying the full dependency closure.
set -euo pipefail

# Rust toolchain — paths match the task image (see image/Dockerfile).
export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
export PATH="$CARGO_HOME/bin:$PATH"

# Grade cargo invocations offline: the registry + target cache are warm from the
# base commit and the oracle introduces no new dependencies.
export CARGO_NET_OFFLINE="${CARGO_NET_OFFLINE:-true}"

# Canonical verifier interpreter (isolated /opt/tooling venv, off PATH).
export VERIFIER_PYTHON="${VERIFIER_PYTHON:-/opt/tooling/venv/bin/python}"

rustc --version >/dev/null 2>&1 || {
    echo "ERROR: rustc not found on PATH (CARGO_HOME=$CARGO_HOME)" >&2
    exit 1
}
cargo --version >/dev/null 2>&1 || {
    echo "ERROR: cargo not found on PATH" >&2
    exit 1
}
"$VERIFIER_PYTHON" -c "import pytest, unidiff" >/dev/null 2>&1 || {
    echo "ERROR: verifier venv missing expected packages at $VERIFIER_PYTHON" >&2
    exit 1
}

echo "test-setup: rustc=$(rustc --version), cargo=$(cargo --version | head -1), verifier=$("$VERIFIER_PYTHON" --version 2>&1)"
