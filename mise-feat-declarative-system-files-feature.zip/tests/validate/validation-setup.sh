#!/usr/bin/env bash
# Validation setup: runs after the agent's edits are applied, before any story.
# One job: relink the `mise` CLI from the edited sources so every story drives
# the agent's binary. Fixtures are not staged here -- each scenario builds its
# own throwaway config tree in a private HOME (see test_harness.py), because
# this feature is stateful and every case needs a clean world.
#
# Incremental: the image baked a built target at the base commit, so only the
# touched crates recompile and relink. Idempotent: re-running just rebuilds.
set -euo pipefail

REPO=/repo/mise

# Toolchain + offline cargo, matching the image. Default if unset so this is
# runnable in isolation; the change adds no dependencies, so --locked offline
# resolves entirely from the baked registry closure.
export RUSTUP_HOME="${RUSTUP_HOME:-/opt/rustup}"
export CARGO_HOME="${CARGO_HOME:-/opt/cargo}"
export CARGO_TARGET_DIR="${CARGO_TARGET_DIR:-/opt/cache/cargo-target}"
export CARGO_NET_OFFLINE="${CARGO_NET_OFFLINE:-true}"
export PATH="$CARGO_HOME/bin:$PATH"

MISE_BIN="$CARGO_TARGET_DIR/debug/mise"

echo "validation-setup: rustc=$(rustc --version 2>&1 | head -1)"
echo "validation-setup: cargo=$(cargo --version 2>&1 | head -1)"

# Step 1: relink the binary with the agent's edits (incremental).
echo "validation-setup: building mise (incremental, offline, locked)..."
( cd "$REPO" && cargo build --locked -p mise 2>&1 | tail -8 )

# Step 2: the binary must exist and run, or every story fails with the same
# opaque error -- surface it here loudly instead.
test -x "$MISE_BIN" || {
    echo "ERROR: mise binary missing at $MISE_BIN after cargo build" >&2
    exit 1
}
"$MISE_BIN" --version >/dev/null || {
    echo "ERROR: mise binary at $MISE_BIN does not run" >&2
    exit 1
}
echo "validation-setup: mise built at $MISE_BIN ($("$MISE_BIN" --version 2>&1 | head -1))"
echo "validation-setup: done."
