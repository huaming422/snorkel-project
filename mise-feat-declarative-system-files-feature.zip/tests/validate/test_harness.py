"""Shared plumbing for the mise-feat-declarative-system-files validation suite.

Every story drives the prebuilt `mise` binary against a throwaway config tree
in a private HOME. The feature is stateful (apply, mutate a source, re-apply,
inspect drift), so each case must run in its own clean world rather than a
shared read-only fixture. This module builds that world and runs the binary;
the story procedures decide what config to write and what to assert.

The isolation here mirrors the repository's own end-to-end harness
(`e2e/run_test` -> `within_isolated_env`): a private HOME under a temp root,
all of mise's data/cache/config/state/system dirs redirected beneath it, the
temp root marked trusted, experimental features on, and non-interactive mode
forced. No variables leak in from the surrounding process, so a stray setting
in the grading container cannot perturb a run.
"""

from __future__ import annotations

import os
import subprocess
import tempfile

# The build step relinks the binary under the workspace's cargo target dir.
# Default matches the image; honor an override if the environment sets one.
_TARGET_DIR = os.environ.get("CARGO_TARGET_DIR", "/opt/cache/cargo-target")
BIN_DIR = os.path.join(_TARGET_DIR, "debug")
MISE_BIN = os.path.join(BIN_DIR, "mise")

# PATH kept deliberately small and explicit: the built binary first, then the
# toolchain and the standard system locations (git, coreutils, a shell for
# template rendering). Nothing is inherited from the caller.
_PATH = ":".join(
    [
        BIN_DIR,
        "/opt/cargo/bin",
        "/usr/local/sbin",
        "/usr/local/bin",
        "/usr/sbin",
        "/usr/bin",
        "/sbin",
        "/bin",
    ]
)


def new_world() -> tuple[str, dict[str, str]]:
    """Create a fresh isolated environment for one scenario.

    Returns ``(workdir, env)``. ``workdir`` is where the config file and its
    source tree should be written and is the cwd the binary should run in;
    ``env`` is a clean environment dict that points mise at the private HOME,
    marks the tree trusted, and runs non-interactively. Each call is fully
    independent of every other.
    """
    root = tempfile.mkdtemp(prefix="mise_sysfiles.")
    home = os.path.join(root, "home")
    workdir = os.path.join(home, "workdir")
    tmp = os.path.join(root, "tmp")

    data = os.path.join(home, ".local", "share", "mise")
    cache = os.path.join(home, ".cache", "mise")
    config = os.path.join(home, ".config", "mise")
    state = os.path.join(home, ".local", "state", "mise")
    system = os.path.join(root, "etc", "mise")

    for d in (workdir, tmp, data, cache, config, state, system):
        os.makedirs(d, exist_ok=True)

    env = {
        "HOME": home,
        "PATH": _PATH,
        "LANG": "C.UTF-8",
        "LC_ALL": "C.UTF-8",
        "TERM": "dumb",
        # Private home for all of mise's bookkeeping dirs.
        "MISE_DATA_DIR": data,
        "MISE_CACHE_DIR": cache,
        "MISE_CONFIG_DIR": config,
        "MISE_STATE_DIR": state,
        "MISE_SYSTEM_DIR": system,
        "MISE_TMP_DIR": tmp,
        # The whole tree is trusted so the config under test is honored, the
        # experimental surface is enabled, and confirmation prompts are
        # answered yes automatically.
        "MISE_TRUSTED_CONFIG_PATHS": root,
        "MISE_EXPERIMENTAL": "1",
        "MISE_YES": "1",
        # Stay fully offline and quiet; no version-host lookups.
        "MISE_USE_VERSIONS_HOST": "0",
        "MISE_CACHE_PRUNE_AGE": "0",
        # Git identity so any internal commit/init has what it needs.
        "GIT_AUTHOR_NAME": "validate",
        "GIT_AUTHOR_EMAIL": "validate@example.com",
        "GIT_COMMITTER_NAME": "validate",
        "GIT_COMMITTER_EMAIL": "validate@example.com",
    }
    return workdir, env


def write(workdir: str, relpath: str, content: str, mode: int | None = None) -> str:
    """Write ``content`` to ``workdir/relpath``, creating parents.

    Returns the absolute path. Pass ``mode`` (e.g. ``0o600``) to set explicit
    permissions on the written file.
    """
    path = os.path.join(workdir, relpath)
    os.makedirs(os.path.dirname(path) or workdir, exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(content)
    if mode is not None:
        os.chmod(path, mode)
    return path


def home_path(env: dict[str, str], relpath: str) -> str:
    """Resolve a path under the world's private HOME (``~`` targets land here)."""
    return os.path.join(env["HOME"], relpath)


def run(
    args: list[str],
    workdir: str,
    env: dict[str, str],
    timeout: int = 120,
) -> subprocess.CompletedProcess:
    """Run the built binary with ``args`` in ``workdir`` under ``env``.

    ``args`` is the argument list after the program name, e.g.
    ``["system", "status"]``. Output is captured as text; a non-zero exit is
    returned, not raised, so procedures can assert on ``returncode``.
    """
    return subprocess.run(
        [MISE_BIN, *args],
        cwd=workdir,
        env=env,
        capture_output=True,
        text=True,
        timeout=timeout,
        check=False,
    )


def combined(result: subprocess.CompletedProcess) -> str:
    """Combined stdout+stderr, for substring checks on user-facing output."""
    return (result.stdout or "") + (result.stderr or "")
