## Task

Extend `mise system` so a trusted, experimental config can declare dotfiles alongside the OS packages and defaults it already manages. The new `[system.files]` table maps each destination on the machine to a source in the declaring config and a handling mode. `mise system install` should bring those destinations into line with the declaration on every run, doing nothing when they already match; `mise system status` should show their current state. Integrate both operations into the existing system commands, keep `[tools]` behavior intact, and apply the same trust and experimental rules used by other `[system]` settings.

## User stories / requirements

- Support four handling modes. `symlink` is the default and links the source file or directory as one target. `symlink-each` links files individually within a target directory that may contain unmanaged files. `copy` writes source content, recursively and additively for directories. `template` renders with mise's template engine and writes the output with the source file's permissions. Reapplying must also correct permission drift when the source permissions change.
- For every entry, `mise system status` shows `applied`, `missing`, `differs (reason)`, or `source missing`. Provide a status check that exits non-zero if any entry is out of its declared state, plus machine-readable output for scripts.
- An apply run must protect conflicting existing targets, including a real file blocking a requested link or directory and a target of the wrong type. Report the conflicting paths and fail without replacing them; an override flag allows replacement. Normal `copy` and `template` content changes apply without an override. If a `copy` target becomes a dangling symlink, reapplying replaces it with the declared file rather than leaving the entry broken.
- A dry run previews the apply operation without changing the filesystem or triggering template side effects.
- Warn and skip entries with unknown modes or relative target paths while continuing the run. Show a missing source in status and report it as an apply error. If several entries have different problems, report them in the same apply run.
