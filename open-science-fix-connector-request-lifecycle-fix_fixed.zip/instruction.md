## Task

Our connectors to the public bio APIs (Rfam, NCBI, PubChem and the rest) hold up badly under load, and it isn't one connector's fault.

Calls run far past their total time limit. A tool that makes several requests, or keeps retrying an upstream that's down, just keeps going, and one whose own code never returns never gets stopped at all. The limit should cover the whole call, every request, retry and wait included. I've also seen calls that already failed back to the caller keep hitting the upstream, and calls that are done still hang on to their resources until the time limit is up.

Rfam sequence searches are the one place this needs care. They poll for up to 300 seconds by default, and that should still work, including the search's own "not finished" error when a job never completes. Someone who passed max_wait_s 1200 also sat on a single search for the full twenty minutes, way past its time limit.

Upstreams that answer 429 or 503 with a Retry-After keep throttling us, because we come back before it's up. We should wait as long as they ask. When that wait won't fit in what's left of the call's limit, I'd rather the call fail right away and say what the server answered and how long it asked us to wait, than retry early or sit there until the clock runs out.

Memory also climbs under sustained error traffic. Response bodies we don't read to the end, from error statuses, aborted requests or oversized responses, never seem to get released. And a call that's cancelled or times out while the upstream has stopped sending mid-response can hang instead of ending.
