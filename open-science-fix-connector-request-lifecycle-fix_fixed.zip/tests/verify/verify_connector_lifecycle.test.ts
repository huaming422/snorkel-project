// @ts-nocheck
// Behavioral checks for the shared connector request executor.
//
// Everything here drives the public boundaries the module already exposes:
// `ParserEngine.call()` (with an injected `fetchImpl` and vitest fake timers,
// exactly as the module's own suites do) and the real `search_sequence`
// descriptor from `RNA_TOOLS`. No internal/private symbol is imported: error
// identity is asserted by its `name`, and timing is asserted by the fake clock.
import { afterEach, beforeEach, describe, it, expect, vi } from 'vitest'
import { ParserEngine } from './engine'
import { RNA_TOOLS } from './descriptors/rna'

// A call that never settles should fail its own case quickly instead of
// holding the whole run until the runner-wide timeout.
vi.setConfig({ testTimeout: 30_000 })

// Back AbortSignal.timeout with the global setTimeout (faked or real,
// whichever is installed when it is called) so every timer the module can
// create follows the one clock these cases control.
beforeEach(() => {
  vi.spyOn(AbortSignal, 'timeout').mockImplementation((ms) => {
    const controller = new AbortController()
    setTimeout(
      () => controller.abort(new DOMException('The operation timed out.', 'TimeoutError')),
      ms
    )
    return controller.signal
  })
})

afterEach(() => {
  vi.useRealTimers()
  vi.restoreAllMocks()
})

const tool = (id) => RNA_TOOLS.find((t) => t.id === id)

// A declarative descriptor whose body is a stream we control, used to observe
// how the executor treats response bodies on the non-success paths.
const streamDescriptor = {
  id: 'lifecycle',
  connector: 'test',
  description: '',
  input: {},
  url: () => 'https://x.test/data',
  parse: (raw) => raw,
  format: 'text'
}

describe('shared whole-call deadline', () => {
  it('bounds sequential requests made by one run() descriptor', async () => {
    vi.useFakeTimers()
    try {
      const fetchImpl = vi.fn(async (_url, init) => {
        await new Promise((resolve, reject) => {
          const timer = setTimeout(resolve, 20)
          init?.signal?.addEventListener(
            'abort',
            () => {
              clearTimeout(timer)
              reject(init.signal?.reason)
            },
            { once: true }
          )
        })
        return new Response('ok')
      })
      const engine = new ParserEngine({ fetchImpl, totalTimeoutMs: 30 })
      const result = engine
        .call(
          {
            ...streamDescriptor,
            run: async (ctx) => {
              await ctx.fetchText('https://x.test/one')
              return ctx.fetchText('https://x.test/two')
            }
          },
          {},
          {}
        )
        .catch((error) => error)
      await vi.advanceTimersByTimeAsync(40)
      // Two ~20ms requests cannot both finish inside a single 30ms budget that
      // spans the whole call; the second request is already in flight when the
      // shared clock fires.
      expect(await result).toMatchObject({ name: 'ConnectorRequestTimeoutError' })
      expect(fetchImpl).toHaveBeenCalledTimes(2)
    } finally {
      vi.useRealTimers()
    }
  })

  it('counts retry backoff against the call budget', async () => {
    vi.useFakeTimers()
    try {
      const fetchImpl = vi.fn(async () => new Response(null, { status: 503 }))
      const engine = new ParserEngine({ fetchImpl, totalTimeoutMs: 30, retryBackoffMs: 40 })
      const result = engine.call(streamDescriptor, {}, {}).catch((error) => error)
      await vi.advanceTimersByTimeAsync(30)
      // The 40ms backoff wait would push past the 30ms call budget, so the call
      // ends at 30ms after a single request. Only the whole-call clock can fire
      // at 30ms here (the per-attempt idle timer defaults to 30s).
      expect(await Promise.race([result, Promise.resolve('still pending')])).toMatchObject({
        name: 'ConnectorRequestTimeoutError'
      })
      expect(fetchImpl).toHaveBeenCalledOnce()
      // Once the call has ended, nothing from it is left armed, and its pending
      // backoff must not wake up and send another request.
      expect(vi.getTimerCount()).toBe(0)
      await vi.runAllTimersAsync()
      await result
      expect(fetchImpl).toHaveBeenCalledOnce()
      expect(vi.getTimerCount()).toBe(0)
    } finally {
      vi.useRealTimers()
    }
  })
})

describe('cancellation handling', () => {
  it('stops a run() descriptor that never settles at the deadline', async () => {
    vi.useFakeTimers()
    try {
      const result = new ParserEngine({ totalTimeoutMs: 30 })
        .call(
          {
            ...streamDescriptor,
            run: async () => new Promise(() => {})
          },
          {},
          {}
        )
        .catch((error) => error)
      await vi.advanceTimersByTimeAsync(30)
      expect(await Promise.race([result, Promise.resolve('still pending')])).toMatchObject({
        name: 'ConnectorRequestTimeoutError'
      })
      expect(vi.getTimerCount()).toBe(0)
    } finally {
      vi.useRealTimers()
    }
  })

  it('stops sibling requests when a run() descriptor fails partway', async () => {
    vi.useFakeTimers()
    try {
      const fetchImpl = vi.fn(async (url) =>
        String(url).endsWith('/bad')
          ? new Response(null, { status: 400 })
          : new Response(null, { status: 503 })
      )
      const engine = new ParserEngine({ fetchImpl, retries: 5, retryBackoffMs: 100 })
      const result = engine
        .call(
          {
            ...streamDescriptor,
            run: async (ctx) =>
              Promise.all([ctx.fetchText('https://x.test/bad'), ctx.fetchText('https://x.test/busy')])
          },
          {},
          {}
        )
        .catch((error) => error)
      await vi.advanceTimersByTimeAsync(0)
      const settled = await Promise.race([result, Promise.resolve('still pending')])
      expect(settled).toBeInstanceOf(Error)
      expect(settled.message).toMatch(/HTTP 400/)
      expect(fetchImpl).toHaveBeenCalledTimes(2)
      // The call has failed, so the retrying sibling must not send anything
      // more, and nothing from the call is left armed.
      expect(vi.getTimerCount()).toBe(0)
      await vi.runAllTimersAsync()
      expect(fetchImpl).toHaveBeenCalledTimes(2)
      expect(vi.getTimerCount()).toBe(0)
    } finally {
      vi.useRealTimers()
    }
  })

  it('propagates caller cancellation through the run-style context signal', async () => {
    const engine = new ParserEngine({ fetchImpl: vi.fn() })
    const cancellation = new AbortController()
    let observed
    const desc = {
      id: 't',
      connector: 'c',
      description: '',
      input: {},
      run: async (ctx) => {
        observed = ctx.signal
        return new Promise((_, reject) => {
          ctx.signal?.addEventListener('abort', () => reject(ctx.signal?.reason), { once: true })
        })
      }
    }
    const result = engine.call(desc, {}, {}, cancellation.signal)
    expect(observed).toBeInstanceOf(AbortSignal)
    expect(observed?.aborted).toBe(false)
    const reason = new Error('user cancelled')
    cancellation.abort(reason)
    await expect(result).rejects.toBe(reason)
    expect(observed?.reason).toBe(reason)
  })
})

describe('Retry-After handling', () => {
  const T0 = Date.parse('2026-09-05T00:00:00Z')
  // The header in either of its two forms: delay seconds or an HTTP-date.
  const header = (form, waitS) =>
    form === 'seconds' ? String(waitS) : new Date(Date.now() + waitS * 1_000).toUTCString()

  it.each([
    [429, 'seconds', 60, undefined],
    [503, 'seconds', 60, undefined],
    [429, 'date', 60, undefined],
    [503, 'date', 60, undefined],
    [429, 'seconds', 90, undefined],
    [503, 'date', 90, undefined],
    [429, 'date', 900, 1_800_000],
    [503, 'seconds', 900, 1_800_000]
  ])(
    'waits the full server-requested delay before retrying (HTTP %i, %s form, %is, limit %s)',
    async (status, form, waitS, totalTimeoutMs) => {
      vi.useFakeTimers()
      vi.setSystemTime(T0)
      try {
        const fetchImpl = vi
          .fn()
          .mockResolvedValueOnce(
            new Response(null, { status, headers: { 'Retry-After': header(form, waitS) } })
          )
          .mockResolvedValueOnce(new Response('ok'))
        const result = new ParserEngine({ fetchImpl, totalTimeoutMs }).call(
          streamDescriptor,
          {},
          {}
        )
        await vi.advanceTimersByTimeAsync(waitS * 1_000 - 1)
        expect(fetchImpl).toHaveBeenCalledOnce()
        // Never earlier than the server asked; a few seconds of extra margin
        // on top of its wait is fine.
        await vi.advanceTimersByTimeAsync(5_001)
        await expect(result).resolves.toBe('ok')
        expect(fetchImpl).toHaveBeenCalledTimes(2)
      } finally {
        vi.useRealTimers()
      }
    }
  )

  // [status, form, earlier wait that fits, requested wait, call limit]
  it.each([
    [429, 'seconds', null, 60, 30_000],
    [503, 'seconds', null, 60, 30_000],
    [429, 'date', null, 60, 30_000],
    [503, 'date', null, 60, 30_000],
    [429, 'seconds', null, 3_600, undefined],
    [503, 'date', null, 3_600, undefined],
    [429, 'seconds', 80, 60, undefined],
    [503, 'seconds', 80, 60, undefined],
    [429, 'date', 80, 60, undefined],
    [503, 'date', 80, 60, undefined]
  ])(
    'fails right away when the wait cannot fit the time left (HTTP %i, %s form, earlier wait %s, asked %is, limit %s)',
    async (status, form, earlierS, waitS, totalTimeoutMs) => {
      vi.useFakeTimers()
      vi.setSystemTime(0)
      try {
        const requestTimes = []
        const fetchImpl = vi.fn(async () => {
          requestTimes.push(Date.now())
          const asked = earlierS !== null && requestTimes.length === 1 ? earlierS : waitS
          return new Response(null, { status, headers: { 'Retry-After': header(form, asked) } })
        })
        const outcome = new ParserEngine({ fetchImpl, totalTimeoutMs })
          .call(streamDescriptor, {}, {})
          .catch((error) => error)
        let settledAt
        outcome.then(() => {
          settledAt = Date.now()
        })
        // Past any earlier wait plus a few seconds of margin, the call must
        // already have ended.
        await vi.advanceTimersByTimeAsync((earlierS ?? 0) * 1_000 + 6_000)
        const settled = await Promise.race([outcome, Promise.resolve('still pending')])
        // When the server's wait no longer fits what is left of the call's
        // limit, the call fails at that response instead of retrying early or
        // sitting out the clock. The error carries the upstream status and the
        // requested wait, in seconds or as the server's own date; the rest of
        // the wording is free.
        const lastRequestAt = requestTimes.at(-1)
        expect(lastRequestAt).toBeGreaterThanOrEqual((earlierS ?? 0) * 1_000)
        expect(settledAt - lastRequestAt).toBeLessThan(1_000)
        expect(settled).toBeInstanceOf(Error)
        expect(settled.name).not.toBe('ConnectorRequestTimeoutError')
        expect(settled.message).toMatch(new RegExp(`\\b${status}\\b`))
        const asDate = new Date(lastRequestAt + waitS * 1_000).toISOString().slice(11, 19)
        expect(settled.message).toMatch(new RegExp(form === 'seconds' ? `${waitS}` : `${waitS}|${asDate}`))
        expect(fetchImpl).toHaveBeenCalledTimes(earlierS === null ? 1 : 2)
        expect(vi.getTimerCount()).toBe(0)
      } finally {
        vi.useRealTimers()
      }
    }
  )

  it.each([
    [429, 'seconds'],
    [503, 'seconds'],
    [429, 'date'],
    [503, 'date']
  ])(
    'counts time a run() tool already spent when the wait cannot fit (HTTP %i, %s form)',
    async (status, form) => {
      vi.useFakeTimers()
      vi.setSystemTime(0)
      try {
        let requestedAt
        const fetchImpl = vi.fn(async () => {
          requestedAt = Date.now()
          return new Response(null, { status, headers: { 'Retry-After': header(form, 60) } })
        })
        const outcome = new ParserEngine({ fetchImpl })
          .call(
            {
              ...streamDescriptor,
              run: async (ctx) => {
                // The tool's own work uses 80 of the call's 120 seconds before
                // its first request, so a 60 second wait no longer fits.
                await new Promise((resolve) => setTimeout(resolve, 80_000))
                return ctx.fetchText('https://x.test/data')
              }
            },
            {},
            {}
          )
          .catch((error) => error)
        let settledAt
        outcome.then(() => {
          settledAt = Date.now()
        })
        await vi.advanceTimersByTimeAsync(81_000)
        const settled = await Promise.race([outcome, Promise.resolve('still pending')])
        expect(requestedAt).toBe(80_000)
        expect(settledAt - requestedAt).toBeLessThan(1_000)
        expect(settled).toBeInstanceOf(Error)
        expect(settled.name).not.toBe('ConnectorRequestTimeoutError')
        expect(settled.message).toMatch(new RegExp(`\\b${status}\\b`))
        expect(settled.message).toMatch(form === 'seconds' ? /60/ : /60|00:02:20/)
        expect(fetchImpl).toHaveBeenCalledOnce()
        expect(vi.getTimerCount()).toBe(0)
      } finally {
        vi.useRealTimers()
      }
    }
  )
})

// A stream cancel hook that settles at once, rejects, or never settles.
const cancelHook = (mode) =>
  vi.fn(() =>
    mode === 'reject'
      ? Promise.reject(new Error('cancel failed'))
      : mode === 'pending'
        ? new Promise(() => {})
        : undefined
  )

describe('response body release', () => {
  it.each([400, 429, 503])('cancels every unfinished HTTP %i body', async (status) => {
    const cancellations = []
    const fetchImpl = vi.fn(async () => {
      const cancel = vi.fn()
      cancellations.push(cancel)
      return new Response(
        new ReadableStream({
          start(controller) {
            controller.enqueue(new Uint8Array(1024 * 1024))
          },
          cancel
        }),
        { status }
      )
    })
    const engine = new ParserEngine({ fetchImpl, retryBackoffMs: 0 })
    await expect(engine.call(streamDescriptor, {}, {})).rejects.toThrow(`HTTP ${status}`)
    expect(fetchImpl).toHaveBeenCalledTimes(status === 400 ? 1 : 3)
    for (const cancel of cancellations) expect(cancel).toHaveBeenCalledOnce()
  })

  it.each(['reject', 'pending'])(
    'keeps the HTTP failure when cancellation is %s',
    async (mode) => {
      const cancel = vi.fn(() =>
        mode === 'reject' ? Promise.reject(new Error('cancel failed')) : new Promise(() => {})
      )
      const response = new Response(new ReadableStream({ cancel }), { status: 400 })
      const engine = new ParserEngine({ fetchImpl: vi.fn().mockResolvedValue(response) })
      await expect(engine.call(streamDescriptor, {}, {})).rejects.toThrow('HTTP 400')
      expect(cancel).toHaveBeenCalledOnce()
    }
  )

  it.each(['settles', 'reject', 'pending'])(
    'cancels the remainder of an oversized successful body (cancel %s)',
    async (cancelMode) => {
      const cancel = cancelHook(cancelMode)
      const response = new Response(
        new ReadableStream({
          start(controller) {
            controller.enqueue(new Uint8Array(10))
          },
          cancel
        })
      )
      const engine = new ParserEngine({
        fetchImpl: vi.fn().mockResolvedValue(response),
        maxResponseBytes: 5
      })
      const result = engine.call(streamDescriptor, {}, {}).catch((error) => error)
      const settled = await Promise.race([
        result,
        new Promise((resolve) => setTimeout(() => resolve('still pending'), 2_000))
      ])
      expect(settled).toMatchObject({ name: 'ConnectorResponseTooLargeError' })
      expect(cancel).toHaveBeenCalledOnce()
      expect(response.body?.locked).toBe(false)
    }
  )

  it('releases the body after a read fails without hiding the error', async () => {
    const error = new Error('stream read failed')
    const response = new Response(
      new ReadableStream({
        pull(controller) {
          controller.error(error)
        }
      })
    )
    const engine = new ParserEngine({ fetchImpl: vi.fn().mockResolvedValue(response), retries: 0 })
    await expect(engine.call(streamDescriptor, {}, {})).rejects.toBe(error)
    expect(response.body?.locked).toBe(false)
  })

  it.each([
    ['user', 'settles'],
    ['idle', 'settles'],
    ['total', 'settles'],
    ['user', 'reject'],
    ['idle', 'reject'],
    ['total', 'reject'],
    ['user', 'pending'],
    ['idle', 'pending'],
    ['total', 'pending']
  ])('cancels a stalled body on %s cancellation (cancel %s)', async (mode, cancelMode) => {
    vi.useFakeTimers()
    try {
      const cancel = cancelHook(cancelMode)
      const response = new Response(new ReadableStream({ cancel }))
      const caller = new AbortController()
      const engine = new ParserEngine({
        fetchImpl: vi.fn().mockResolvedValue(response),
        timeoutMs: mode === 'idle' ? 10 : 100,
        totalTimeoutMs: mode === 'total' ? 10 : 100
      })
      const result = engine.call(streamDescriptor, {}, {}, caller.signal).catch((error) => error)
      await vi.advanceTimersByTimeAsync(0)
      if (mode === 'user') caller.abort()
      await vi.advanceTimersByTimeAsync(10)
      expect(await Promise.race([result, Promise.resolve('still pending')])).toMatchObject({
        name: mode === 'user' ? 'AbortError' : 'ConnectorRequestTimeoutError'
      })
      expect(cancel).toHaveBeenCalledOnce()
      expect(response.body?.locked).toBe(false)
      expect(vi.getTimerCount()).toBe(0)
    } finally {
      vi.useRealTimers()
    }
  })
})

describe('Rfam search_sequence whole-call window', () => {
  it.each([150_000, 295_000])(
    'preserves the default polling window for a job ready after %ims',
    async (readyAfterMs) => {
      vi.useFakeTimers()
      vi.setSystemTime(0)
      try {
        const submissionMs = 20_000
        const fetchImpl = vi.fn(async (_url, init) => {
          if (init?.method === 'POST') {
            await new Promise((resolve) => setTimeout(resolve, submissionMs))
            return Response.json({ jobId: 'job-1', resultURL: 'https://rfam.test/result/1' })
          }
          return Response.json(
            Date.now() >= submissionMs + readyAfterMs
              ? { hits: {}, searchSequence: 'GGUUCC' }
              : { status: 'PEND' }
          )
        })
        const result = new ParserEngine({ fetchImpl })
          .call(tool('search_sequence'), { sequence: 'GGUUCC' }, {})
          .then(
            (value) => ({ value, finishedAt: Date.now() }),
            (error) => ({ error, finishedAt: Date.now() })
          )
        await vi.advanceTimersByTimeAsync(submissionMs + readyAfterMs)
        expect(await result).toMatchObject({
          value: { job_id: 'job-1', num_hits: 0, search_sequence: 'GGUUCC' },
          finishedAt: submissionMs + readyAfterMs
        })
        expect(vi.getTimerCount()).toBe(0)
      } finally {
        vi.useRealTimers()
      }
    }
  )

  it('still stops an unfinished job at its default polling deadline', async () => {
    vi.useFakeTimers()
    vi.setSystemTime(0)
    try {
      const fetchImpl = vi.fn(async (_url, init) =>
        Response.json(
          init?.method === 'POST'
            ? { jobId: 'job-1', resultURL: 'https://rfam.test/result/1' }
            : { status: 'PEND' }
        )
      )
      const result = new ParserEngine({ fetchImpl })
        .call(tool('search_sequence'), { sequence: 'GGUUCC' }, {})
        .catch((error) => ({ error, finishedAt: Date.now() }))
      await vi.advanceTimersByTimeAsync(300_000)
      expect(await result).toMatchObject({
        error: { message: expect.stringContaining('Rfam sequence search not finished after 300s') },
        finishedAt: 300_000
      })
      expect(vi.getTimerCount()).toBe(0)
    } finally {
      vi.useRealTimers()
    }
  })

  it('keeps a hard whole-call cap for longer custom polling waits', async () => {
    vi.useFakeTimers()
    vi.setSystemTime(0)
    try {
      const customWaitMs = 1_200_000
      const requestTimes = []
      const fetchImpl = vi.fn(async (_url, init) => {
        requestTimes.push(Date.now())
        return Response.json(
          init?.method === 'POST'
            ? { jobId: 'job-1', resultURL: 'https://rfam.test/result/1' }
            : { status: 'PEND' }
        )
      })
      const outcome = new ParserEngine({ fetchImpl })
        .call(
          tool('search_sequence'),
          { sequence: 'GGUUCC', max_wait_s: 1200, poll_interval_s: 30 },
          {}
        )
        .catch((error) => ({ error, finishedAt: Date.now() }))
      // Advance across the full requested wait so the call settles even if it
      // is never cut off. A search asked to wait 1200s must still be cut off
      // by its own whole-call limit before that wait is over, ending with the
      // connector timeout rather than the poll loop's "not finished" result,
      // and the poll loop must stop polling once the call has ended.
      await vi.advanceTimersByTimeAsync(customWaitMs)
      const settled = await outcome
      expect(settled.error).toMatchObject({ name: 'ConnectorRequestTimeoutError' })
      expect(settled.finishedAt).toBeGreaterThan(300_000)
      expect(settled.finishedAt).toBeLessThan(customWaitMs)
      expect(Math.max(...requestTimes)).toBeLessThanOrEqual(settled.finishedAt)
      expect(vi.getTimerCount()).toBe(0)
    } finally {
      vi.useRealTimers()
    }
  })
})

describe('existing executor behavior preserved', () => {
  const jsonResponse = (body) =>
    ({
      ok: true,
      status: 200,
      json: async () => body,
      text: async () => JSON.stringify(body)
    })

  it('builds the url, fetches json, and runs parse', async () => {
    const fetchImpl = vi.fn().mockResolvedValue(jsonResponse({ value: 42 }))
    const engine = new ParserEngine({ fetchImpl })
    const desc = {
      id: 't',
      connector: 'c',
      description: '',
      input: {},
      url: (a) => `https://example.test/${a.id}`,
      parse: (raw) => raw.value
    }
    const out = await engine.call(desc, { id: 7 }, {})
    expect(fetchImpl).toHaveBeenCalledWith('https://example.test/7', expect.any(Object))
    expect(out).toBe(42)
  })

  it('retries transient 5xx and gives up after the configured retries', async () => {
    const fetchImpl = vi.fn().mockResolvedValue({ ok: false, status: 503 })
    const engine = new ParserEngine({ fetchImpl, retries: 2, retryBackoffMs: 0 })
    const desc = {
      id: 't',
      connector: 'c',
      description: '',
      input: {},
      url: () => 'https://x.test',
      parse: (r) => r
    }
    await expect(engine.call(desc, {}, {})).rejects.toThrow(/HTTP 503/)
    expect(fetchImpl).toHaveBeenCalledTimes(3)
  })

  it('retries a transient 5xx then succeeds', async () => {
    const fetchImpl = vi
      .fn()
      .mockResolvedValueOnce({ ok: false, status: 503 })
      .mockResolvedValueOnce(jsonResponse({ value: 1 }))
    const engine = new ParserEngine({ fetchImpl, retries: 2, retryBackoffMs: 0 })
    const desc = {
      id: 't',
      connector: 'c',
      description: '',
      input: {},
      url: () => 'https://x.test',
      parse: (r) => r.value
    }
    await expect(engine.call(desc, {}, {})).resolves.toBe(1)
    expect(fetchImpl).toHaveBeenCalledTimes(2)
  })

  it('retries an immediate network error then succeeds', async () => {
    const fetchImpl = vi
      .fn()
      .mockRejectedValueOnce(new Error('ECONNRESET'))
      .mockResolvedValueOnce(jsonResponse({ value: 5 }))
    const engine = new ParserEngine({ fetchImpl, retryBackoffMs: 0 })
    const desc = {
      id: 't',
      connector: 'c',
      description: '',
      input: {},
      url: () => 'https://x.test',
      parse: (r) => r.value
    }
    await expect(engine.call(desc, {}, {})).resolves.toBe(5)
    expect(fetchImpl).toHaveBeenCalledTimes(2)
  })

  it('resets the idle timeout while response body chunks keep arriving', async () => {
    vi.useFakeTimers()
    try {
      const encoder = new TextEncoder()
      const fetchImpl = vi.fn().mockResolvedValue(
        new Response(
          new ReadableStream({
            start(controller) {
              setTimeout(() => controller.enqueue(encoder.encode('{"value":')), 10)
              setTimeout(() => controller.enqueue(encoder.encode('9}')), 20)
              setTimeout(() => controller.close(), 40)
            }
          })
        )
      )
      const engine = new ParserEngine({ fetchImpl, timeoutMs: 30, retries: 2, retryBackoffMs: 0 })
      const desc = {
        id: 't',
        connector: 'c',
        description: '',
        input: {},
        url: () => 'https://x.test/data',
        parse: (raw) => raw.value
      }
      const result = engine.call(desc, {}, {}).catch((error) => error)
      await vi.advanceTimersByTimeAsync(10)
      await vi.advanceTimersByTimeAsync(10)
      await vi.advanceTimersByTimeAsync(20)
      expect(await result).toBe(9)
      expect(fetchImpl).toHaveBeenCalledOnce()
    } finally {
      vi.useRealTimers()
    }
  })

  it('does not retry a client error other than 429', async () => {
    const fetchImpl = vi.fn().mockResolvedValue({ ok: false, status: 400 })
    const engine = new ParserEngine({ fetchImpl, retries: 2, retryBackoffMs: 0 })
    const desc = {
      id: 't',
      connector: 'c',
      description: '',
      input: {},
      url: () => 'https://x.test',
      parse: (r) => r
    }
    await expect(engine.call(desc, {}, {})).rejects.toThrow(/HTTP 400/)
    expect(fetchImpl).toHaveBeenCalledOnce()
  })
})
