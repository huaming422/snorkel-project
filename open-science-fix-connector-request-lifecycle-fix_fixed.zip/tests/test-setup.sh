#!/usr/bin/env bash
# Environment bootstrap for the verifier.
#
# Sourced (not exec'd) by tests/test.sh under `set -euo pipefail`, so env vars
# set here stay live for the verifier subprocess. No assertion logic here.
#
# The image already baked the full dependency closure at the base commit
# (`npm ci` in the environment Dockerfile), so node_modules is present and
# warm. Source changes are TypeScript, which vitest transpiles on the fly, so
# no reinstall is needed on the happy path. Crucially, this file is
# sourced inside `docker run --network none`: a blanket `npm ci` here would
# first delete the baked node_modules and then fail to repopulate it from the
# runtime npm cache, so the install is a guarded fallback only.

REPO_DIR="${REPO_DIR:-/repo/open-science}"
export REPO_DIR
cd "$REPO_DIR"

# Keep the package manager off the network so a cache miss fails fast and loud
# here rather than silently reaching a registry.
export npm_config_offline=true
export npm_config_audit=false
export npm_config_fund=false

# Trust the image bake. Only reinstall if the vitest binary is missing, which
# means the baked node_modules is corrupt or absent. Point npm at the warm
# build-time cache so an offline reconcile can actually resolve packages; fall
# back to the user cache, then to an online install as a last resort.
if [ -x node_modules/.bin/vitest ]; then
    echo "[offline-first] node deps satisfied from image bake"
else
    echo "test-setup.sh: vitest missing from node_modules/.bin/; reinstalling from the image cache" >&2
    install_cache="${npm_config_cache:-}"
    if [ -d /opt/cache/npm ]; then install_cache=/opt/cache/npm; fi
    if npm ci --offline --cache "${install_cache:-/opt/cache/npm}" > /tmp/test-setup-install.log 2>&1; then
        echo "[test-setup] node deps restored offline from the image cache"
    elif npm ci >> /tmp/test-setup-install.log 2>&1; then
        echo "[test-setup] node deps installed online (image bake was stale)"
    else
        echo "[test-setup] npm ci failed:" >&2
        tail -60 /tmp/test-setup-install.log >&2
        exit 1
    fi
fi

# Sanity check: vitest must be resolvable from the repo root. A failure here
# points at a corrupted node_modules and saves a confusing "vitest not found"
# later.
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest binary missing from node_modules/.bin/" >&2
    exit 1
fi

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR node=$(node --version) vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
