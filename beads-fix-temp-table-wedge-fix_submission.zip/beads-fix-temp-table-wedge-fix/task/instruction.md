## Task

one of our heavily-used shared beads hubs wedged itself twice in the same day, both times right after a routine open. once it happens, older clients that open the same store start refusing writes, and `bd dolt pull` starts failing too. the store's working set shows as permanently dirty: there's phantom table-rename junk sitting in it that reopening and retrying never clears, and the only way we've gotten it back so far is a manual repair.

dig into why opening the store wedges it like this and fix it so a normal open stops stranding the store. the goal is to keep new stores from getting wedged on open; repairing stores that older clients already damaged is out of scope.
