//go:build cgo

package embeddeddolt_test

import (
	"database/sql"
	"strings"
	"testing"

	"github.com/steveyegge/beads/internal/storage/schema"
)

// TestEmbeddedTempRebuildIntermediatesNeverReachHistory exercises the shared-hub
// contract through schema.MigrateUp against a real in-process engine.
//
// The ignored-series table rebuilds stage their work through __temp__<table>
// intermediates (ignored/0001, ignored/0002) that are renamed onto the final
// dolt_ignored clone-local names. The final names are ignore-matched, but when
// the intermediates carry no ignore pattern, a @@dolt_transaction_commit=1
// server auto-commits each CREATE __temp__X as a real table at HEAD; the later
// RENAME onto an ignored name then strands an unstageable "__temp__X -> X" half
// in dolt_status that no working-set shuffle can clear, wedging every later open
// behind the dirty-table guard until a manual repair.
//
// The store is shaped like the field clone: its dolt_ignore was seeded by
// binaries that predate the intermediate-covering pattern. A fresh-box
// MigrateUp must therefore assert that pattern itself, in the same pass, before
// the ignored series runs — so no __temp__ intermediate ever lands in committed
// history and the pass ends with a clean working set.
func TestEmbeddedTempRebuildIntermediatesNeverReachHistory(t *testing.T) {
	requireEmbedded(t)
	ctx := t.Context()

	dir := seedMainSchemaAt(t, ctx, schema.LatestVersion())
	conn, closeConn := openPinnedConn(t, ctx, dir)
	defer closeConn()
	if _, err := schema.MigrateUp(ctx, conn); err != nil {
		t.Fatalf("seed MigrateUp: %v", err)
	}

	// Shape the store the way a real clone arrives (the Door B dance from
	// TestEmbeddedIgnoredSeriesConvergesWithFreshInitShape): committed history
	// holds the main tables and the at-latest main cursor; the clone-local
	// tables and the ignored cursor are working-set state a clone never
	// receives.
	for _, table := range []string{
		"wisp_dependencies", "wisp_events", "wisp_comments", "wisp_labels",
		"wisp_child_counters", "wisps", "events", "leases", "repo_mtimes",
		"local_metadata", "bd_events_journal", "bd_events_seq",
		"ignored_schema_migrations",
	} {
		execFrozenGuard(t, ctx, conn, "DROP TABLE IF EXISTS "+table)
	}
	execFrozenGuard(t, ctx, conn,
		"DELETE FROM dolt_ignore WHERE pattern IN ('leases', 'bd_events_journal', 'bd_events_seq')")
	// The field stores were seeded by binaries that predate the intermediate-
	// covering pattern; strip it from the baseline so the pass under test has to
	// assert it itself, before the ignored series runs.
	execFrozenGuard(t, ctx, conn, "DELETE FROM dolt_ignore WHERE pattern = '__temp__%'")
	mustDrain(t, ctx, conn, "CALL DOLT_ADD('-A')")
	mustDrain(t, ctx, conn, "CALL DOLT_COMMIT('-m', 'test: clone-shaped baseline', '--skip-empty')")

	// The hub that hit this twice runs @@dolt_transaction_commit=1: every
	// transaction commit becomes a dolt commit of every non-ignored delta, the
	// mechanism that materialized the intermediates as tracked tables.
	if _, err := conn.ExecContext(ctx, "SET @@dolt_transaction_commit = 1"); err != nil {
		t.Fatalf("enable dolt_transaction_commit: %v", err)
	}

	// The fresh-box open.
	if _, err := schema.MigrateUp(ctx, conn); err != nil {
		t.Fatalf("fresh-box MigrateUp: %v", err)
	}

	// No rebuild intermediate may appear in ANY commit's history.
	rows, err := conn.QueryContext(ctx, "SELECT DISTINCT table_name FROM dolt_diff")
	if err != nil {
		t.Fatalf("read dolt_diff table names: %v", err)
	}
	defer rows.Close()
	var leaked []string
	for rows.Next() {
		var name string
		if err := rows.Scan(&name); err != nil {
			t.Fatalf("scan dolt_diff table name: %v", err)
		}
		if strings.HasPrefix(name, "__temp__") {
			leaked = append(leaked, name)
		}
	}
	if err := rows.Err(); err != nil {
		t.Fatalf("iterate dolt_diff table names: %v", err)
	}
	if len(leaked) > 0 {
		t.Errorf("rebuild intermediates reached committed history: %v", leaked)
	}

	// And the pass must end clean — the incident's other half was the
	// permanently-dirty status that wedged older binaries' opens.
	dirty, err := statusTables(ctx, conn)
	if err != nil {
		t.Fatalf("read dolt_status: %v", err)
	}
	if len(dirty) > 0 {
		t.Errorf("working set dirty after the fresh-box pass: %v", dirty)
	}
}

// TestEmbeddedUntrackScratchSweepStillLandsUnderMatchedPattern is the
// second-order interaction, driven end to end through schema.MigrateUp.
//
// Once the intermediate-covering pattern ships, it ALSO matches the pre-existing
// #4356 untrack scratch table (__temp__ignored_schema_migrations_untrack). That
// table's own cleanup sweep, which must take it back out of HEAD when a writer
// left it committed there, used to stage with an unforced DOLT_ADD. An unforced
// stage classifies purely by ignore pattern and never consults HEAD, so it now
// drops the scratch name silently; a --skip-empty commit then reports success
// having committed nothing, the delete delta survives uncommitted, and the pull
// wedge the sweep exists to clear lives forever.
//
// The fixture forces the scratch to HEAD (only a real commit removes it again),
// asserts that precondition so a future staging change cannot quietly turn this
// into a test of the ordinary untracked path, runs the resume heal via a
// writable open, then asserts the scratch is no longer at HEAD and the working
// set is clean. This fails on a fix that adds the pattern but leaves the sweep
// on unforced staging.
func TestEmbeddedUntrackScratchSweepStillLandsUnderMatchedPattern(t *testing.T) {
	requireEmbedded(t)
	ctx := t.Context()
	f := newLegacyTrackedFixture(t, "sweeplands")

	f.withRawConn(t, func(conn *sql.Conn) {
		untrackCursorInPlace(t, ctx, conn)
		mustExecOn(t, ctx, conn, "REPLACE INTO dolt_ignore VALUES ('ignored_schema_migrations', false)")
		// Force the scratch into HEAD, then assert it: the '-Am' blanket commit
		// below cannot sweep it in once the scratch's name is ignore-matched
		// (a blanket commit's ignore filter is hardcoded on, with no forced
		// form), so without this explicit forced add the sweep's forced branch
		// would never be exercised and the weaker working-set assertion would
		// pass on the local DROP alone.
		mustExecOn(t, ctx, conn, "CALL DOLT_ADD('-f', ?)", untrackScratchTable)
		mustExecOn(t, ctx, conn, "CALL DOLT_COMMIT('-Am', 'operator: version the cursor table on purpose')")
		if !trackedAtHead(t, ctx, conn, untrackScratchTable) {
			t.Fatalf("%s is not committed at HEAD after the blanket commit; the tracked-scratch sweep would not be exercised", untrackScratchTable)
		}
	})

	f.reopenAndClose(t)

	f.withRawConn(t, func(conn *sql.Conn) {
		if tablePresent(t, ctx, conn, untrackScratchTable) {
			t.Errorf("%s survived the resume; the cleanup must always remove it", untrackScratchTable)
		}
		// Positive proof the sweep's COMMIT landed, not just the local DROP:
		// nothing but a commit takes the table back out of HEAD. An unforced
		// stage makes the sweep a silent no-op that --skip-empty reports as
		// success, leaving the table at HEAD and a permanent delete delta that
		// wedges every later pull.
		if trackedAtHead(t, ctx, conn, untrackScratchTable) {
			t.Errorf("%s is still committed at HEAD; the sweep staged nothing and committed nothing", untrackScratchTable)
		}
		if dirty := dirtyTableNames(t, ctx, conn); len(dirty) > 0 {
			t.Errorf("working set is dirty after the resume: %v", dirty)
		}
		if got := len(cursorRows(t, ctx, conn)); got != len(f.cursorRows) {
			t.Errorf("cursor rows = %d, want %d", got, len(f.cursorRows))
		}
	})
}
