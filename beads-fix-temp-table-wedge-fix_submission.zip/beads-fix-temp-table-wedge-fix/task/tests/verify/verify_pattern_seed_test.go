package schema

import (
	"context"
	"regexp"
	"testing"

	"github.com/DATA-DOG/go-sqlmock"
)

// verifyDoltIgnoreWildcardMatch reports whether name is matched by pattern under
// dolt's dolt_ignore matcher semantics: `?` matches exactly one character, `%`
// and `*` each match any run of characters (including none), and every other
// byte — underscores included — is literal. The match is anchored to the whole
// name, the way dolt resolves a dolt_ignore row. Table names are ASCII, so a
// byte-wise two-pointer scan is exact.
func verifyDoltIgnoreWildcardMatch(pattern, name string) bool {
	p, n := 0, 0
	star, mark := -1, 0
	for n < len(name) {
		switch {
		case p < len(pattern) && (pattern[p] == '?' || pattern[p] == name[n]):
			p++
			n++
		case p < len(pattern) && (pattern[p] == '%' || pattern[p] == '*'):
			star, mark = p, n
			p++
		case star != -1:
			p = star + 1
			mark++
			n = mark
		default:
			return false
		}
	}
	for p < len(pattern) && (pattern[p] == '%' || pattern[p] == '*') {
		p++
	}
	return p == len(pattern)
}

// TestVerifyCanonicalPatternSetCoversRebuildIntermediates covers the
// `pattern_covers_intermediates` criterion (structural).
//
// The ignored-series table rebuilds stage every clone-local table through a
// __temp__<table> intermediate before renaming it onto the final dolt_ignored
// name. For those intermediates to be born ignored — never auto-committing as
// tracked tables on a @@dolt_transaction_commit=1 server — the canonical seeded
// pattern set must carry a dolt-matcher-legal pattern that covers the __temp__
// prefix.
//
// The check is intentionally string-agnostic about HOW the prefix is expressed:
// dolt's matcher supports `?`, `*`, and `%` (underscores are literal), so both
// `__temp__%` and `__temp__*` are legal spellings of the same cover and either
// is accepted. It asserts that some canonical pattern matches both the
// pre-existing #4356 untrack scratch name and a generic rebuild intermediate,
// while NOT matching ordinary tracked tables — so a blanket pattern that hides
// real versioned tables does not satisfy it.
func TestVerifyCanonicalPatternSetCoversRebuildIntermediates(t *testing.T) {
	const (
		scratchIntermediate = "__temp__ignored_schema_migrations_untrack"
		genericIntermediate = "__temp__wisps"
	)
	mustStayVisible := []string{
		"ignored_schema_migrations",
		"schema_migrations",
		"issues",
		"wisps",
	}

	var covering []string
	for _, pattern := range doltIgnorePatterns {
		if !verifyDoltIgnoreWildcardMatch(pattern, scratchIntermediate) {
			continue
		}
		if !verifyDoltIgnoreWildcardMatch(pattern, genericIntermediate) {
			continue
		}
		overBroad := false
		for _, keep := range mustStayVisible {
			if verifyDoltIgnoreWildcardMatch(pattern, keep) {
				overBroad = true
				break
			}
		}
		if !overBroad {
			covering = append(covering, pattern)
		}
	}

	if len(covering) == 0 {
		t.Fatalf("no canonical dolt_ignore pattern covers the __temp__ rebuild intermediates "+
			"(e.g. %q / %q) without also matching ordinary tracked tables; "+
			"the rebuild intermediates would auto-commit as tracked tables on "+
			"@@dolt_transaction_commit=1 servers. doltIgnorePatterns = %v",
			scratchIntermediate, genericIntermediate, doltIgnorePatterns)
	}
}

// TestVerifySeedCommitToleratesEmptyStagedDiff covers the
// `seed_commit_skip_empty` criterion (pass_to_pass).
//
// On an out-of-band-materialized database the open-time pass re-asserts the
// canonical dolt_ignore set and must commit that heal itself, scoped and
// labeled, because no migration pass follows to carry it. On a
// @@dolt_transaction_commit=1 server the seeded rows were already committed at
// their own transaction boundaries, so the scoped seed commit meets an empty
// staged diff: it must tolerate that (the `--skip-empty` form) rather than
// aborting the whole pass with "nothing to commit".
//
// This reproduces the no-work-short-circuit path through MigrateUp over the
// pre-existing go-sqlmock seam. A seed commit that is NOT empty-tolerant emits
// the bare labeled commit, the mocked seam does not match it, and MigrateUp
// fails — which is exactly the regression this guards.
func TestVerifySeedCommitToleratesEmptyStagedDiff(t *testing.T) {
	failOnSwallowedAdvisory(t)
	db, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("create sql mock: %v", err)
	}
	defer db.Close()

	expectIgnorePatternSeed(mock, LatestVersion())
	// The open-time untrack reconcile runs right after the seed and before the
	// no-work short-circuit; on a healthy database it is two reads and no writes.
	expectIgnoredCursorHealNoop(mock)
	// migrationWorkNeeded: both cursors at latest, both content_hash columns
	// present, no custom backfill pending -> no work, MigrateUp short-circuits.
	expectCursorProbe(mock, "schema_migrations", true)
	expectScalar(mock, "SELECT COALESCE(MAX(version), 0) FROM schema_migrations", "version", LatestVersion())
	expectCursorProbe(mock, "ignored_schema_migrations", true)
	expectScalar(mock, "SELECT COALESCE(MAX(version), 0) FROM ignored_schema_migrations", "version", LatestIgnoredVersion())
	expectIgnoredSentinelProbes(mock, true)
	expectContentHashColumnExists(mock)
	expectContentHashColumnExists(mock)
	expectScalar(mock, "SELECT COUNT(*) FROM custom_types", "count", 1)
	expectScalar(mock, "SELECT COUNT(*) FROM custom_statuses", "count", 1)
	// The seed inserted rows and no migration pass follows to commit them, so
	// MigrateUp commits the heal itself, scoped and labeled — and empty-tolerant,
	// because the rows may already be committed on a transaction-commit server.
	mock.ExpectQuery(regexp.QuoteMeta("CALL DOLT_ADD('dolt_ignore')")).
		WillReturnRows(sqlmock.NewRows([]string{"status"}))
	mock.ExpectQuery(regexp.QuoteMeta("CALL DOLT_COMMIT('-m', 'schema: seed dolt_ignore patterns', '--skip-empty')")).
		WillReturnRows(sqlmock.NewRows([]string{"hash"}))

	applied, err := MigrateUp(context.Background(), db)
	if err != nil {
		t.Fatalf("MigrateUp() error = %v", err)
	}
	if applied != 0 {
		t.Fatalf("MigrateUp() applied = %d, want 0", applied)
	}
	if err := mock.ExpectationsWereMet(); err != nil {
		t.Fatalf("unmet SQL expectations (the scoped seed commit must tolerate an "+
			"empty staged diff on transaction-commit servers): %v", err)
	}
}
