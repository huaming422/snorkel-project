/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.trino.verify;

import io.trino.Session;
import io.trino.spi.type.LongTimestampWithTimeZone;
import io.trino.spi.type.Type;
import io.trino.sql.query.QueryAssertions;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import java.util.Optional;

import static io.trino.spi.StandardErrorCode.NUMERIC_VALUE_OUT_OF_RANGE;
import static io.trino.spi.function.OperatorType.ADD;
import static io.trino.spi.function.OperatorType.SUBTRACT;
import static io.trino.spi.type.TimeZoneKey.UTC_KEY;
import static io.trino.spi.type.TimestampWithTimeZoneType.createTimestampWithTimeZoneType;
import static io.trino.spi.type.Timestamps.PICOSECONDS_PER_MILLISECOND;
import static io.trino.testing.TestingSession.DEFAULT_TIME_ZONE_KEY;
import static io.trino.testing.TestingSession.testSessionBuilder;
import static io.trino.testing.assertions.TrinoExceptionAssert.assertTrinoExceptionThrownBy;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.TestInstance.Lifecycle.PER_CLASS;

/**
 * Behavioral verifier for the "timestamp arithmetic silently overflows near the
 * representable range" bug. Exercises only Trino's pre-existing, stable SQL
 * scalar/operator layer via {@link QueryAssertions} and the public
 * {@code Type.getPreviousValue}/{@code getNextValue} SPI, never any
 * implementation-internal symbol the fix may introduce.
 *
 * One @Test method per task.toml behavioral criterion (indices 0..6). The
 * Python wrapper (verify.py) maps each method's surefire result onto its
 * criterion. The task passes only when every method passes.
 */
@TestInstance(PER_CLASS)
public class VerifyTimestampOverflow
{
    private QueryAssertions assertions;

    @BeforeAll
    public void init()
    {
        // Same session timezone the repo's own TestTimestamp uses, so the plain-
        // timestamp expected literals below reproduce exactly.
        Session session = testSessionBuilder()
                .setTimeZoneKey(DEFAULT_TIME_ZONE_KEY)
                .build();
        assertions = new QueryAssertions(session);
    }

    @AfterAll
    public void teardown()
    {
        assertions.close();
        assertions = null;
    }

    /**
     * Criterion 0 (date_add_overflow, fail_to_pass): date_add on a timestamp
     * returns the correct value when the shifted result is representable and
     * raises NUMERIC_VALUE_OUT_OF_RANGE when it leaves the range, at ordinary
     * (<=6) and sub-microsecond (>=7) precision.
     */
    @Test
    public void test0DateAddOverflow()
    {
        // representable result at the boundary still returns the correct timestamp
        assertThat(assertions.expression("date_add('millisecond', 9223372036854775, TIMESTAMP '1970-01-01 00:00:00.000807')"))
                .matches("TIMESTAMP '294247-01-10 04:00:54.775807'");

        // one microsecond past the top of the range overflows the scale-back add
        assertTrinoExceptionThrownBy(assertions.expression("date_add('millisecond', 9223372036854775, TIMESTAMP '1970-01-01 00:00:00.000808')")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);

        // month unit, ordinary precision
        assertTrinoExceptionThrownBy(assertions.expression("date_add('month', 1, TIMESTAMP '294246-12-10 04:00:54.775999')")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);

        // month unit, sub-microsecond precision (>=7 LongTimestamp path)
        assertTrinoExceptionThrownBy(assertions.expression("date_add('month', 1, TIMESTAMP '294246-12-10 04:00:54.775999999999')")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);

        // a very large day/week/month/year shift overflows the final timestamp value
        String value = Long.toString(30L * 24 * 60 * 60 * 1000);
        assertTrinoExceptionThrownBy(assertions.expression("date_add('day', " + value + ", TIMESTAMP '0001-01-01 00:00:00')")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
        assertTrinoExceptionThrownBy(assertions.expression("date_add('day', " + value + ", TIMESTAMP '0001-01-01 00:00:00.000000000000')")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
        assertTrinoExceptionThrownBy(assertions.expression("date_add('year', " + value + ", TIMESTAMP '0001-01-01 00:00:00')")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
    }

    /**
     * Criterion 1 (interval_add_overflow, fail_to_pass): timestamp +/- INTERVAL
     * (DAY TO SECOND and YEAR TO MONTH, both short and high-precision timestamps)
     * returns the correct value for representable results and raises
     * NUMERIC_VALUE_OUT_OF_RANGE on overflow.
     */
    @Test
    public void test1IntervalAddOverflow()
    {
        // YEAR TO MONTH: representable result unchanged
        assertThat(assertions.operator(ADD, "TIMESTAMP '294246-12-10 04:00:54.775807'", "INTERVAL '1' month"))
                .matches("TIMESTAMP '294247-01-10 04:00:54.775807'");
        // one microsecond over -> overflow (short + high-precision + both operand orders)
        assertTrinoExceptionThrownBy(assertions.operator(ADD, "TIMESTAMP '294246-12-10 04:00:54.775808'", "INTERVAL '1' month")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
        assertTrinoExceptionThrownBy(assertions.operator(ADD, "TIMESTAMP '294246-12-10 04:00:54.775808000000'", "INTERVAL '1' month")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
        assertTrinoExceptionThrownBy(assertions.operator(ADD, "INTERVAL '1' month", "TIMESTAMP '294246-12-10 04:00:54.775808'")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);

        // DAY TO SECOND: representable result unchanged, then overflow
        assertThat(assertions.operator(ADD, "TIMESTAMP '294247-01-10 04:00:53.775807'", "INTERVAL '1' second"))
                .matches("TIMESTAMP '294247-01-10 04:00:54.775807'");
        assertTrinoExceptionThrownBy(assertions.operator(ADD, "TIMESTAMP '294247-01-10 04:00:54.775807'", "INTERVAL '1' second")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
        assertTrinoExceptionThrownBy(assertions.operator(ADD, "INTERVAL '1' second", "TIMESTAMP '294247-01-10 04:00:54.775807000000'")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);

        // a large interval reachable via multiplication overflows the micros rescale
        assertTrinoExceptionThrownBy(assertions.expression("a + b")
                .binding("a", "TIMESTAMP '2020-05-01 12:34:56'")
                .binding("b", "INTERVAL '1' SECOND * 9223372036854775")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
        assertTrinoExceptionThrownBy(assertions.expression("a - b")
                .binding("a", "TIMESTAMP '2020-05-01 12:34:56'")
                .binding("b", "INTERVAL '1' SECOND * 9223372036854775")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);

        // subtracting from the smallest representable timestamp underflows
        String minTimestamp = "date_add('millisecond', -9223372036854775, TIMESTAMP '1970-01-01 00:00:00.000000')";
        assertTrinoExceptionThrownBy(assertions.operator(SUBTRACT, minTimestamp, "INTERVAL '1' month")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
        assertTrinoExceptionThrownBy(assertions.operator(SUBTRACT, minTimestamp, "INTERVAL '1' second")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
    }

    /**
     * Criterion 2 (ts_minus_ts_representable, fail_to_pass): timestamp - timestamp
     * returns the correct DAY TO SECOND interval even when the naive microsecond
     * difference would overflow but the correct interval is representable.
     */
    @Test
    public void test2TimestampMinusTimestampRepresentable()
    {
        assertThat(assertions.operator(SUBTRACT, "TIMESTAMP '294247-01-10 04:00:54.775807'", "TIMESTAMP '1970-01-01 00:00:00.000000'"))
                .matches("INTERVAL '106751991 04:00:54.776' DAY TO SECOND");
        assertThat(assertions.operator(SUBTRACT, "TIMESTAMP '1970-01-01 00:00:00.000000'", "TIMESTAMP '294247-01-10 04:00:54.775807'"))
                .matches("INTERVAL '-106751991 04:00:54.776' DAY TO SECOND");
        // high-precision operands, same representable difference
        assertThat(assertions.operator(SUBTRACT, "TIMESTAMP '294247-01-10 04:00:54.775807000000'", "TIMESTAMP '1970-01-01 00:00:00.000000000000'"))
                .matches("INTERVAL '106751991 04:00:54.776' DAY TO SECOND");
    }

    /**
     * Criterion 3 (ts_minus_ts_picos_tiebreak, fail_to_pass, basic=false): an exact
     * half-millisecond difference rounds using the picosecond remainder as the
     * tie-breaker; at ordinary precision a half rounds away from zero.
     */
    @Test
    public void test3PicosTiebreak()
    {
        // half a millisecond rounds away from zero in either direction
        assertThat(assertions.operator(SUBTRACT, "TIMESTAMP '1970-01-01 00:00:00.000500'", "TIMESTAMP '1970-01-01 00:00:00.000000'"))
                .matches("INTERVAL '0 00:00:00.001' DAY TO SECOND");
        assertThat(assertions.operator(SUBTRACT, "TIMESTAMP '1970-01-01 00:00:00.000499'", "TIMESTAMP '1970-01-01 00:00:00.000000'"))
                .matches("INTERVAL '0 00:00:00.000' DAY TO SECOND");
        assertThat(assertions.operator(SUBTRACT, "TIMESTAMP '1970-01-01 00:00:00.000000'", "TIMESTAMP '1970-01-01 00:00:00.000500'"))
                .matches("INTERVAL '0 00:00:00.000' DAY TO SECOND");
        assertThat(assertions.operator(SUBTRACT, "TIMESTAMP '1970-01-01 00:00:00.000000'", "TIMESTAMP '1970-01-01 00:00:00.000501'"))
                .matches("INTERVAL '-0 00:00:00.001' DAY TO SECOND");

        // a picosecond on either side of the tie decides which way it rounds (precision >=7)
        assertThat(assertions.operator(SUBTRACT, "TIMESTAMP '1970-01-01 00:00:00.000500000000'", "TIMESTAMP '1970-01-01 00:00:00.000000000000'"))
                .matches("INTERVAL '0 00:00:00.001' DAY TO SECOND");
        assertThat(assertions.operator(SUBTRACT, "TIMESTAMP '1970-01-01 00:00:00.000500000000'", "TIMESTAMP '1970-01-01 00:00:00.000000000001'"))
                .matches("INTERVAL '0 00:00:00.000' DAY TO SECOND");
        assertThat(assertions.operator(SUBTRACT, "TIMESTAMP '1970-01-01 00:00:00.000000000000'", "TIMESTAMP '1970-01-01 00:00:00.000500000000'"))
                .matches("INTERVAL '0 00:00:00.000' DAY TO SECOND");
        assertThat(assertions.operator(SUBTRACT, "TIMESTAMP '1970-01-01 00:00:00.000000000000'", "TIMESTAMP '1970-01-01 00:00:00.000500000001'"))
                .matches("INTERVAL '-0 00:00:00.001' DAY TO SECOND");
    }

    /**
     * Criterion 4 (tstz_add_overflow, fail_to_pass): timestamp with time zone +/-
     * INTERVAL raises NUMERIC_VALUE_OUT_OF_RANGE when the result leaves the
     * storable range, at every precision including >=4 where the zone-packing
     * makes an operator-only check insufficient (pre-fix the failure escaped from
     * type write-out as a generic error).
     */
    @Test
    public void test4TimestampTzIntervalOverflow()
    {
        assertTrinoExceptionThrownBy(assertions.operator(ADD, "TIMESTAMP '73326-09-11 20:14:45.247 UTC'", "INTERVAL '1' second")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
        // precision 7 (>=4): zone packing means the operator check alone is insufficient pre-fix
        assertTrinoExceptionThrownBy(assertions.operator(ADD, "TIMESTAMP '73326-09-11 20:14:45.2470000 UTC'", "INTERVAL '1' second")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
        assertTrinoExceptionThrownBy(assertions.operator(ADD, "TIMESTAMP '73326-09-11 20:14:45.247 UTC'", "INTERVAL '1' month")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
        assertTrinoExceptionThrownBy(assertions.operator(ADD, "TIMESTAMP '73326-09-11 20:14:45.2470000 UTC'", "INTERVAL '1' month")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
        assertTrinoExceptionThrownBy(assertions.operator(ADD, "INTERVAL '1' second", "TIMESTAMP '73326-09-11 20:14:45.2470000 UTC'")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
        assertTrinoExceptionThrownBy(assertions.operator(ADD, "INTERVAL '1' month", "TIMESTAMP '73326-09-11 20:14:45.2470000 UTC'")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);

        // subtracting a negative interval runs past the largest representable value
        assertTrinoExceptionThrownBy(assertions.operator(SUBTRACT, "TIMESTAMP '73326-09-11 20:14:45.247 UTC'", "INTERVAL '-1' second")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
        assertTrinoExceptionThrownBy(assertions.operator(SUBTRACT, "TIMESTAMP '73326-09-11 20:14:45.2470000 UTC'", "INTERVAL '-1' month")::evaluate)
                .hasErrorCode(NUMERIC_VALUE_OUT_OF_RANGE);
    }

    /**
     * Criterion 5 (tstz_range_endpoints, fail_to_pass, basic=false): the
     * timestamp-with-time-zone type's getPreviousValue/getNextValue never return a
     * value outside the storable signed-52-bit epoch-millis domain; at the domain
     * endpoints they return empty. Observed via the pre-existing public Type API.
     */
    @Test
    public void test5TimestampTzRangeEndpoints()
    {
        long minEpochMillis = -(1L << 51);
        long maxEpochMillis = (1L << 51) - 1;

        // precision 6 (TIMESTAMP_TZ_MICROS): step is 1_000_000 picoseconds
        Type typeMicros = createTimestampWithTimeZoneType(6);
        LongTimestampWithTimeZone minValue = LongTimestampWithTimeZone.fromEpochMillisAndFraction(minEpochMillis, 0, UTC_KEY);
        LongTimestampWithTimeZone nextToMinValue = LongTimestampWithTimeZone.fromEpochMillisAndFraction(minEpochMillis, 1_000_000, UTC_KEY);
        LongTimestampWithTimeZone previousToMaxValue = LongTimestampWithTimeZone.fromEpochMillisAndFraction(maxEpochMillis, 998_000_000, UTC_KEY);
        LongTimestampWithTimeZone maxValue = LongTimestampWithTimeZone.fromEpochMillisAndFraction(maxEpochMillis, 999_000_000, UTC_KEY);

        // no value before the minimum / after the maximum of the storable domain
        assertThat(typeMicros.getPreviousValue(minValue)).isEqualTo(Optional.empty());
        assertThat(typeMicros.getNextValue(maxValue)).isEqualTo(Optional.empty());
        // interior values step by exactly one unit, staying inside the domain
        assertThat(typeMicros.getPreviousValue(nextToMinValue)).isEqualTo(Optional.of(minValue));
        assertThat(typeMicros.getNextValue(previousToMaxValue)).isEqualTo(Optional.of(maxValue));

        // a higher precision uses the same 52-bit domain endpoints
        int step = 1_000; // picoseconds per unit at precision 9
        Type typeNanos = createTimestampWithTimeZoneType(9);
        assertThat(typeNanos.getPreviousValue(LongTimestampWithTimeZone.fromEpochMillisAndFraction(minEpochMillis, 0, UTC_KEY)))
                .isEqualTo(Optional.empty());
        assertThat(typeNanos.getNextValue(LongTimestampWithTimeZone.fromEpochMillisAndFraction(maxEpochMillis, (int) (PICOSECONDS_PER_MILLISECOND - step), UTC_KEY)))
                .isEqualTo(Optional.empty());
        assertThat(typeNanos.getPreviousValue(LongTimestampWithTimeZone.fromEpochMillisAndFraction(minEpochMillis, step, UTC_KEY)))
                .isEqualTo(Optional.of(LongTimestampWithTimeZone.fromEpochMillisAndFraction(minEpochMillis, 0, UTC_KEY)));
        assertThat(typeNanos.getNextValue(LongTimestampWithTimeZone.fromEpochMillisAndFraction(maxEpochMillis, (int) (PICOSECONDS_PER_MILLISECOND - 2 * step), UTC_KEY)))
                .isEqualTo(Optional.of(LongTimestampWithTimeZone.fromEpochMillisAndFraction(maxEpochMillis, (int) (PICOSECONDS_PER_MILLISECOND - step), UTC_KEY)));
    }

    /**
     * Criterion 6 (in_range_regression, pass_to_pass): in-range timestamp
     * arithmetic that already worked keeps returning the same results. The fix must
     * narrow only the boundary behavior, not change ordinary arithmetic.
     */
    @Test
    public void test6InRangeRegression()
    {
        // ordinary date_add
        assertThat(assertions.expression("date_add('millisecond', 1, TIMESTAMP '2020-05-10 12:34:56.111')"))
                .matches("TIMESTAMP '2020-05-10 12:34:56.112'");
        assertThat(assertions.expression("date_add('day', 1, TIMESTAMP '2020-05-10 12:34:56')"))
                .matches("TIMESTAMP '2020-05-11 12:34:56'");
        assertThat(assertions.expression("date_add('month', 1, TIMESTAMP '2020-05-10 12:34:56')"))
                .matches("TIMESTAMP '2020-06-10 12:34:56'");

        // ordinary interval add / subtract
        assertThat(assertions.operator(ADD, "INTERVAL '3' year", "TIMESTAMP '2001-1-22 03:04:05.321'"))
                .matches("TIMESTAMP '2004-01-22 03:04:05.321'");
        assertThat(assertions.operator(SUBTRACT, "TIMESTAMP '2001-1-22 03:04:05.321'", "INTERVAL '3' month"))
                .matches("TIMESTAMP '2000-10-22 03:04:05.321'");

        // ordinary timestamp - timestamp (low and high precision)
        assertThat(assertions.operator(SUBTRACT, "TIMESTAMP '2016-03-29 03:04:05.321'", "TIMESTAMP '2017-03-30 14:15:16.432'"))
                .matches("INTERVAL '-366 11:11:11.111' DAY TO SECOND");

        // ordinary timestamp with time zone interval arithmetic
        assertThat(assertions.operator(ADD, "INTERVAL '3' month", "TIMESTAMP '2001-1-22 03:04:05.321 +05:09'"))
                .matches("TIMESTAMP '2001-04-22 03:04:05.321 +05:09'");
    }
}
