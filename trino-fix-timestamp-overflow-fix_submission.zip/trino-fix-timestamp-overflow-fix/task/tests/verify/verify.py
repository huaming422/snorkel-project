"""Behavioral verifier for trino-fix-timestamp-overflow.

The behavior under test is timestamp arithmetic at the extreme ends of the
representable range, observable only through Trino's SQL scalar/operator layer.
There is no native Java/JUnit runner in the grading harness, so this Python
verifier wraps the repo's own in-process test infrastructure: it injects a
JUnit 5 test class (``VerifyTimestampOverflow.java``, shipped alongside this
file) into trino-main's test source tree, runs it through the repo's own
Maven/surefire config, and maps each ``@Test`` method's result onto one
task.toml behavioral criterion.

Why inject our own test class instead of running the repo's stock tests: the
base commit's own timestamp tests assert the OLD pre-fix behavior (error
message ``"long overflow"``); the fix changes that wording, so the stock tests
go red once the fix is applied and would tell us nothing either way. Our
injected class carries the corrected expectations.

Why the build runs in TWO Maven steps instead of one reactor spanning both
modules: a valid fix may place the range check in the SPI type (trino-spi)
rather than in the operators (trino-main). The agent's trino-spi changes must
be compiled and used instead of resolving the stale installed jar. A single
``-pl core/trino-spi,core/trino-main test`` reactor cannot do this: the parent
POM hardcodes ``failIfNoTests`` so the ``-Dtest=`` filter matching nothing in
trino-spi bans the whole reactor ("No tests were executed!") before trino-main
ever runs. Instead we (1) ``install`` the possibly-agent-modified trino-spi
with ``-DskipTests`` so its fresh jar is in the local repo, then (2) run the
injected test in trino-main, which now compiles and links against that jar.

This file imports no repository Python (there is none); it uses only the
standard library plus a ``mvn`` subprocess, so it runs correctly under the
shared verifier interpreter with no ``[pytest] command`` override.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# Layout / configuration
# ---------------------------------------------------------------------------

REPO_NAME = os.environ.get("REPO_NAME", "trino")
REPO_DIR = Path(f"/repo/{REPO_NAME}")
if not REPO_DIR.is_dir():
    REPO_DIR = Path("/repo/trino")

# The JUnit test class ships next to this file and is copied into trino-main's
# test tree under a fresh package that cannot collide with existing tests.
JAVA_SRC = Path(__file__).resolve().parent / "VerifyTimestampOverflow.java"
TEST_FQN = "io.trino.verify.VerifyTimestampOverflow"
TEST_PKG_DIR = Path("core/trino-main/src/test/java/io/trino/verify")
TEST_CLASS_FILE = TEST_PKG_DIR / "VerifyTimestampOverflow.java"
SUREFIRE_REPORT = Path(
    "core/trino-main/target/surefire-reports/TEST-io.trino.verify.VerifyTimestampOverflow.xml"
)

LOGS_DIR = Path("/logs/verifier")
MVN_LOG = LOGS_DIR / "verify_mvn.log"

# Leave headroom under task.toml [verifier] timeout_sec = 2400 and the pytest
# timeout in verify.toml (2300). The runner kills at pytest-timeout + 30.
MVN_TIMEOUT_SEC = 2100

# Criterion index -> (JUnit method name, human description). The method names
# match @Test methods in VerifyTimestampOverflow.java exactly.
CRITERIA = [
    ("test0DateAddOverflow", "date_add overflow raises, representable returns correct value"),
    ("test1IntervalAddOverflow", "timestamp +/- INTERVAL overflow raises, representable correct"),
    ("test2TimestampMinusTimestampRepresentable", "timestamp - timestamp representable difference correct"),
    ("test3PicosTiebreak", "half-millisecond difference tie broken by picosecond remainder"),
    ("test4TimestampTzIntervalOverflow", "timestamp with time zone +/- INTERVAL overflow raises at every precision"),
    ("test5TimestampTzRangeEndpoints", "tstz getPreviousValue/getNextValue respect the 52-bit domain"),
    ("test6InRangeRegression", "in-range arithmetic unchanged (pass_to_pass regression guard)"),
]


# ---------------------------------------------------------------------------
# One Maven run, shared across every criterion test
# ---------------------------------------------------------------------------


def _run_maven_once() -> dict[str, tuple[bool, str]]:
    """Inject the JUnit test, run it offline through the repo's surefire, and
    return ``{method_name: (passed, detail)}``.

    On any failure to produce a surefire report (compile error in the agent's
    patch, Maven failure, timeout) every criterion is reported as failed with
    the Maven tail as detail — a broken patch is a wrong answer (correctness 0),
    never a silently-skipped criterion.
    """
    LOGS_DIR.mkdir(parents=True, exist_ok=True)
    abs_pkg_dir = REPO_DIR / TEST_PKG_DIR
    abs_class_file = REPO_DIR / TEST_CLASS_FILE
    abs_report = REPO_DIR / SUREFIRE_REPORT

    def _all_failed(detail: str) -> dict[str, tuple[bool, str]]:
        return {name: (False, detail[:200]) for name, _ in CRITERIA}

    if not JAVA_SRC.is_file():
        return _all_failed(f"missing injected test source: {JAVA_SRC}")

    try:
        # Fresh package dir; remove any stale report for a clean parse.
        abs_pkg_dir.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(JAVA_SRC, abs_class_file)
        if abs_report.exists():
            abs_report.unlink()

        # Step 1: install the (possibly agent-modified) SPI module so trino-main
        # compiles against the fresh jar. -DskipTests avoids the empty-module
        # surefire trap; the install itself fails loudly on a broken SPI patch.
        install_cmd = [
            "mvn", "-o", "-B",
            "-pl", "core/trino-spi",
            "install",
            "-DskipTests",
            "-Dair.check.skip-all=true",
        ]
        # Step 2: run the injected test in trino-main only.
        test_cmd = [
            "mvn", "-o", "-B",
            "-pl", "core/trino-main",
            "test",
            f"-Dtest={TEST_FQN}",
            "-DfailIfNoTests=false",
            "-Dair.check.skip-all=true",
        ]

        import time

        deadline = time.monotonic() + MVN_TIMEOUT_SEC
        log_parts: list[str] = []

        def _run(cmd: list[str], label: str) -> subprocess.CompletedProcess | None:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return None
            proc = subprocess.run(
                cmd,
                cwd=str(REPO_DIR),
                capture_output=True,
                text=True,
                timeout=remaining,
                check=False,
            )
            combined = (proc.stdout or "") + "\n" + (proc.stderr or "")
            log_parts.append(f"===== {label}: {' '.join(cmd)} =====\n{combined}")
            return proc

        try:
            install_proc = _run(install_cmd, "install trino-spi")
            if install_proc is None:
                MVN_LOG.write_text("\n".join(log_parts))
                return _all_failed(f"mvn install timed out after {MVN_TIMEOUT_SEC}s")
            if install_proc.returncode != 0:
                MVN_LOG.write_text("\n".join(log_parts))
                tail = "\n".join("\n".join(log_parts).splitlines()[-40:])
                return _all_failed(
                    f"trino-spi install failed (exit {install_proc.returncode}); tail:\n{tail}"
                )

            test_proc = _run(test_cmd, "test trino-main")
            if test_proc is None:
                MVN_LOG.write_text("\n".join(log_parts))
                return _all_failed(f"mvn test timed out after {MVN_TIMEOUT_SEC}s")
        except subprocess.TimeoutExpired:
            MVN_LOG.write_text("\n".join(log_parts))
            return _all_failed(f"mvn timed out after {MVN_TIMEOUT_SEC}s")

        combined_all = "\n".join(log_parts)
        MVN_LOG.write_text(combined_all)
        mvn_tail = "\n".join(combined_all.splitlines()[-40:])

        if not abs_report.exists():
            return _all_failed(
                f"no surefire report (mvn exit {test_proc.returncode}); tail:\n{mvn_tail}"
            )

        return _parse_report(abs_report, mvn_tail)
    finally:
        # Always remove the injected test so the repo is left untouched.
        shutil.rmtree(abs_pkg_dir, ignore_errors=True)


def _parse_report(report_path: Path, mvn_tail: str) -> dict[str, tuple[bool, str]]:
    """Parse the surefire XML into ``{method_name: (passed, detail)}``."""
    results: dict[str, tuple[bool, str]] = {}
    try:
        root = ET.parse(str(report_path)).getroot()  # noqa: S314
    except ET.ParseError as exc:
        return {name: (False, f"unparseable surefire report: {exc}") for name, _ in CRITERIA}

    for tc in root.findall("testcase"):
        name = tc.get("name", "")
        failure = tc.find("failure")
        error = tc.find("error")
        skipped = tc.find("skipped")
        if failure is not None:
            detail = (failure.get("message") or failure.text or "assertion failed") or ""
            results[name] = (False, detail[:200])
        elif error is not None:
            detail = (error.get("message") or error.text or "errored") or ""
            results[name] = (False, detail[:200])
        elif skipped is not None:
            results[name] = (False, "test was skipped")
        else:
            results[name] = (True, "")

    # Any expected method absent from the report counts as failed.
    for name, _ in CRITERIA:
        if name not in results:
            results[name] = (False, f"method not found in surefire report; mvn tail:\n{mvn_tail}"[:200])
    return results


@pytest.fixture(scope="module")
def maven_results() -> dict[str, tuple[bool, str]]:
    return _run_maven_once()


# ---------------------------------------------------------------------------
# One pytest test per behavioral criterion (binary all-pass contract)
# ---------------------------------------------------------------------------


def _check(maven_results: dict[str, tuple[bool, str]], method: str) -> None:
    passed, detail = maven_results.get(method, (False, "no result"))
    assert passed, f"{method} failed: {detail}"


def test_0_date_add_overflow(maven_results):
    """fail_to_pass: date_add on a timestamp returns the correct value when the
    shifted result is representable and raises NUMERIC_VALUE_OUT_OF_RANGE when it
    leaves the range, at ordinary and sub-microsecond precision."""
    _check(maven_results, "test0DateAddOverflow")


def test_1_interval_add_overflow(maven_results):
    """fail_to_pass: timestamp +/- INTERVAL (DAY TO SECOND and YEAR TO MONTH,
    short and high-precision) returns the correct value for representable results
    and raises NUMERIC_VALUE_OUT_OF_RANGE on overflow."""
    _check(maven_results, "test1IntervalAddOverflow")


def test_2_timestamp_minus_timestamp_representable(maven_results):
    """fail_to_pass: timestamp - timestamp returns the correct DAY TO SECOND
    interval even when the naive microsecond difference would overflow but the
    correct interval is representable."""
    _check(maven_results, "test2TimestampMinusTimestampRepresentable")


def test_3_picos_tiebreak(maven_results):
    """fail_to_pass: an exact half-millisecond difference rounds using the
    picosecond remainder as the tie-breaker."""
    _check(maven_results, "test3PicosTiebreak")


def test_4_timestamp_tz_interval_overflow(maven_results):
    """fail_to_pass: timestamp with time zone +/- INTERVAL raises
    NUMERIC_VALUE_OUT_OF_RANGE when the result leaves the storable range, at every
    precision including >=4 where the zone-packing makes an operator-only check
    insufficient."""
    _check(maven_results, "test4TimestampTzIntervalOverflow")


def test_5_timestamp_tz_range_endpoints(maven_results):
    """fail_to_pass: the timestamp-with-time-zone type's getPreviousValue/
    getNextValue never return a value outside the storable signed-52-bit
    epoch-millis domain and return empty at the endpoints."""
    _check(maven_results, "test5TimestampTzRangeEndpoints")


def test_6_in_range_regression(maven_results):
    """pass_to_pass: in-range timestamp arithmetic that already worked keeps
    returning the same results (the fix narrows only the boundary behavior)."""
    _check(maven_results, "test6InRangeRegression")
