#!/usr/bin/env bash
# Sourced before verify.py runs. The image already carries the full Maven
# dependency closure for core/trino-spi + core/trino-main (warmed with
# `mvn -am install` at build time, then proven with an offline `mvn -o test`
# run — see image/Dockerfile), plus the Temurin JDK 25 and Apache Maven 3.9.16
# toolchain. So there is nothing to download here; the verifier recompiles the
# two in-scope modules and runs a focused surefire test OFFLINE against the
# baked ~/.m2. This script just pins the toolchain onto PATH, forces Maven into
# offline mode, and sanity-checks that the offline closure resolves.
set -euo pipefail

REPO_DIR="/repo/trino"
cd "$REPO_DIR"

# Toolchain baked at /opt (see image/Dockerfile). Re-export in case the
# verifier is invoked with a clean env.
export JAVA_HOME="${JAVA_HOME:-/opt/java}"
export MAVEN_HOME="${MAVEN_HOME:-/opt/maven}"
export PATH="${JAVA_HOME}/bin:${MAVEN_HOME}/bin:${PATH}"

# The verifier phase is network-restricted (allowlist = model gateway only).
# Force Maven offline so a stray transitive fetch fails loudly here instead of
# hanging the grade. The closure for the two in-scope modules is already local.
export MAVEN_OPTS="${MAVEN_OPTS:-} -Dmaven.wagon.http.retryHandler.count=0"
export MAVEN_ARGS="${MAVEN_ARGS:-} -o -B -Dair.check.skip-all=true"

# Keep any uv-managed verifier tooling offline too (its wheels are baked into
# /opt/tooling/venv at image build; nothing to fetch at grade time).
export UV_OFFLINE="${UV_OFFLINE:-1}"
export UV_NO_SYNC="${UV_NO_SYNC:-1}"

# Sanity: toolchain present and the offline Maven closure resolves for the two
# in-scope modules. `validate -o` touches no source but forces dependency
# resolution against the local repo only; if the closure is incomplete it fails
# now with a clear message rather than mid-test.
java -version
mvn -version
mvn -o -q -B -pl core/trino-spi,core/trino-main -am validate -Dair.check.skip-all=true \
  > /tmp/test-setup-validate.log 2>&1 \
  || { echo "[test-setup] offline Maven closure incomplete:"; tail -60 /tmp/test-setup-validate.log; exit 1; }

echo "[test-setup] trino-fix-timestamp-overflow verifier env ready (offline Maven closure OK)"
