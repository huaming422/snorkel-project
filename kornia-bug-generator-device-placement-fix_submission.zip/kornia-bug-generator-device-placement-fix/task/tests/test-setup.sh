#!/usr/bin/env bash
# test-setup.sh — environment bootstrap for the verifier.
# Sourced by the verifier runner so exported env vars stay alive for pytest.
#
# The image already bakes the full dependency closure at the base commit into
# /opt/venv (uv sync --frozen --all-extras) plus pytest-xdist under /opt/xdist,
# so the agent phase runs fully offline. This script is an idempotent guard: it
# re-syncs the project venv offline-first, falling back to a logged online sync
# only if the offline resolve is incomplete (e.g. an agent mutated the venv).

set -euo pipefail

REPO_DIR="${REPO_DIR:-/repo/kornia}"
cd "$REPO_DIR"

export VIRTUAL_ENV=/opt/venv
export UV_PROJECT_ENVIRONMENT=/opt/venv

# Offline-first: the baked venv already matches the lockfile, so this is a
# no-op in the normal case. Log and retry online only if it fails.
if UV_OFFLINE=1 uv sync --frozen --all-extras > /tmp/test-setup-sync.log 2>&1; then
    echo "[test-setup] offline uv sync ok"
else
    echo "[test-setup] offline sync incomplete; retrying with network" >&2
    tail -20 /tmp/test-setup-sync.log >&2 || true
    uv sync --frozen --all-extras > /tmp/test-setup-sync-online.log 2>&1 \
        || { tail -50 /tmp/test-setup-sync-online.log >&2; exit 1; }
fi

echo "[test-setup] ready: $REPO_DIR (python=$(/opt/venv/bin/python --version 2>&1))"
