# LICENSE HEADER MANAGED BY add-license-header
#
# Copyright 2018 Kornia Team
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
"""Behavioral verifier for kornia-bug-generator-device-placement.

The defect: Kornia's augmentation parameter generators build their small
numeric constants (affine centers, perspective corners, crop corners, shear
bounds, illumination gradients, box coordinates) with ``torch.tensor([...])``
and indexed scalar writes. Every such literal is *lifted* into the FX graph as
a frozen CPU buffer; under ``torch.compile`` + CUDA the generated kernel
dereferences that CPU pointer on the GPU and crashes
(pytorch/pytorch#196969). A cluster of orthogonal device/dtype bugs rides the
same parameter-generation path: samplers do not follow a module ``.to()`` move
cleanly (a dtype-only move silently resets the device, and vice versa), shear
and illumination samplers land on the wrong device/dtype, the linear
illumination directions sampler must stay ``float32`` even under a ``float16``
move, and ``center_crop_generator3d`` returns CPU ``float32`` tensors for an
empty batch instead of ``long`` tensors on the requested device.

The fix is CPU-verifiable even though the crash needs a GPU. ``make_fx`` over a
generator call reveals whether the graph lifts fresh tensor constants
(``aten.lift_fresh_copy.default``) or references geometry constants via a
``get_attr`` node; device/dtype placement is observable on the ``meta`` device
and on CPU. These tests encode exactly those CPU/meta proxies.

Interface discipline: the tests drive the PUBLIC
``kornia.augmentation.random_generator`` constructors (and
``kornia.augmentation`` modules) plus ``make_fx`` and ``.to()``. They never
import the fix's internal helper by name — any correct construction that lifts
no fresh constants and preserves the observable values/placement passes,
regardless of how the fix factors it.

Self-containment: this file is collected from ``/tests/verify/``, OUTSIDE the
repo tree, so the repo's ``tests/conftest.py`` fixtures (``device``, ``dtype``,
``torch_optimizer``) and ``testing.base.BaseTester`` are NOT in scope. Grading
is CPU-only, so the fixtures are defined locally as CPU/float32 and
``torch.testing.assert_close`` is used directly.
"""

from __future__ import annotations

from functools import partial

import numpy as np
import pytest
import torch
from torch.fx.experimental.proxy_tensor import make_fx

import kornia.augmentation as K
from kornia.augmentation import random_generator as rg


# --------------------------------------------------------------------------- #
# Local fixtures (conftest is out of scope; grading runs CPU-only).
# --------------------------------------------------------------------------- #
@pytest.fixture
def device() -> torch.device:
    return torch.device("cpu")


@pytest.fixture
def dtype() -> torch.dtype:
    return torch.float32


def assert_close(actual, expected, *, rtol=None, atol=None) -> None:
    if rtol is None and atol is None:
        torch.testing.assert_close(actual, expected)
    else:
        torch.testing.assert_close(actual, expected, rtol=rtol, atol=atol)


# --------------------------------------------------------------------------- #
# Generator roster — mirrors upstream tests/augmentation/test_parameter_
# constants.py::GENERATORS. Built through public constructors only.
# --------------------------------------------------------------------------- #
GENERATORS = [
    pytest.param(lambda: rg.AffineGenerator(30.0), (4, 3, 16, 19), id="affine"),
    pytest.param(lambda: rg.PerspectiveGenerator(0.5), (4, 3, 16, 19), id="perspective"),
    pytest.param(lambda: rg.ShearGenerator((-10.0, 10.0)), (4, 3, 16, 19), id="shear"),
    pytest.param(
        lambda: rg.RectangleEraseGenerator((0.1, 0.2), (0.8, 1.2), 0.5), (4, 3, 16, 19), id="erasing"
    ),
    pytest.param(lambda: rg.CropGenerator((8, 9)), (4, 3, 16, 19), id="crop"),
    pytest.param(lambda: rg.CropGenerator((8, 9), resize_to=(6, 7)), (4, 3, 16, 19), id="crop-resize"),
    pytest.param(
        lambda: rg.ResizedCropGenerator((8, 9), (0.5, 1.0), (0.8, 1.2)), (4, 3, 16, 19), id="resized-crop"
    ),
    pytest.param(lambda: partial(rg.center_crop_generator, size=(8, 9)), (4, 16, 19), id="center-crop"),
    pytest.param(lambda: rg.ResizeGenerator((8, 9)), (4, 3, 16, 19), id="resize"),
    pytest.param(lambda: rg.AffineGenerator3D(30.0), (4, 3, 12, 16, 19), id="affine3d"),
    pytest.param(lambda: rg.PerspectiveGenerator3D(0.5), (4, 3, 12, 16, 19), id="perspective3d"),
    pytest.param(lambda: rg.CropGenerator3D((6, 8, 9)), (4, 3, 12, 16, 19), id="crop3d"),
    pytest.param(
        lambda: rg.CropGenerator3D((6, 8, 9), resize_to=(4, 6, 7)), (4, 3, 12, 16, 19), id="crop3d-resize"
    ),
    pytest.param(
        lambda: partial(rg.center_crop_generator3d, size=(6, 8, 9)), (4, 12, 16, 19), id="center-crop3d"
    ),
    pytest.param(lambda: K.RandomThinPlateSpline(p=1.0).generate_parameters, (4, 3, 16, 19), id="tps"),
    pytest.param(lambda: rg.MosaicGenerator((8, 9)), (4, 3, 16, 19), id="mosaic"),
    pytest.param(rg.CutmixGenerator, (4, 3, 16, 19), id="cutmix"),
    pytest.param(
        lambda: rg.LinearIlluminationGenerator((0.1, 0.2), (0.1, 0.2)), (4, 3, 16, 19), id="linear"
    ),
    pytest.param(
        lambda: rg.LinearCornerIlluminationGenerator((0.1, 0.2), (0.1, 0.2)), (4, 3, 16, 19), id="linear-corner"
    ),
    pytest.param(
        lambda: rg.GaussianIlluminationGenerator((0.1, 0.2), (0.1, 0.2), (0.1, 0.2), (0.1, 0.2)),
        (4, 3, 16, 19),
        id="gaussian",
    ),
]


def _generate(generator, shape):
    """Call a roster entry: ``partial`` factories take unpacked dims, modules take the shape."""
    return generator(*shape) if isinstance(generator, partial) else generator(shape)


# =========================================================================== #
# Criterion 1 (F2P): no lifted constants across the generator family.
# Primary behavioral check for the CUDA compile-time crash, observed on CPU.
# =========================================================================== #
@pytest.mark.parametrize("make_generator,shape", GENERATORS)
def test_no_lifted_constants(make_generator, shape):
    generator = make_generator()
    # Trace directly rather than through Dynamo: every tracer, not only
    # torch.compile, must see constants built by factories rather than lifted.
    graph = make_fx(lambda: _generate(generator, shape), _error_on_data_dependent_ops=False)().graph
    lifted = [n for n in graph.nodes if n.target == torch.ops.aten.lift_fresh_copy.default]
    assert not lifted, f"Forward lifted fresh tensor constants: {lifted}"


# =========================================================================== #
# Criterion 1 (F2P, geometry sub-case): the affine `center` / perspective
# `start_points` reach the graph output without a `get_attr` node (lifted
# geometry constant). Mirrors test_geometric_parameter_device.py.
# =========================================================================== #
@pytest.mark.parametrize(
    "make_aug,key",
    [
        pytest.param(lambda: K.RandomAffine(30.0, translate=(0.1, 0.1), scale=(0.8, 1.2), p=1.0), "center", id="affine"),
        pytest.param(lambda: K.RandomPerspective(0.5, p=1.0), "start_points", id="perspective"),
        pytest.param(
            lambda: K.RandomPerspective(0.5, p=1.0, sampling_method="area_preserving"),
            "start_points",
            id="perspective-area-preserving",
        ),
    ],
)
def test_geometry_constants_constructed_in_graph(make_aug, key):
    generator = make_aug()._param_generator
    graph = make_fx(lambda: generator((4, 3, 16, 19))[key].to(torch.float64))().graph
    assert all(n.target != torch.ops.aten.lift_fresh_copy.default for n in graph.nodes)
    output = next(n for n in graph.nodes if n.op == "output")
    pending = list(output.all_input_nodes)
    visited = set()
    while pending:
        node = pending.pop()
        if node in visited:
            continue
        visited.add(node)
        assert node.op != "get_attr", f"Lifted geometry constant: {node.target}"
        pending.extend(node.all_input_nodes)


# =========================================================================== #
# Criterion 2 (P2P): in-graph constant construction preserves value semantics.
#
# The fix must not change the parameters generators produce. We assert the
# observable output values of a deterministic generator (center_crop_generator3d
# builds integer-coordinate corner constants with NO randomness) against the
# exact corner coordinates the pre-existing geometry dictates. These coordinates
# are pure geometry (derived from the input dims, unchanged by any correct fix),
# so this guard stays green on any value-preserving construction (reference
# example, a differently-named helper, or a dict builder) and only fails a fix
# that corrupts the constant values, shape, dtype, or device.
#
# Hand-derived for center_crop_generator3d(batch, 12, 16, 19, (6, 8, 9)):
#   start=(x=5, y=4, z=3), end=(x=13, y=11, z=8); dst box (9x8x6) -> (8,7,5).
# =========================================================================== #
_EXPECTED_SRC = [
    [5, 4, 3], [13, 4, 3], [13, 11, 3], [5, 11, 3],
    [5, 4, 8], [13, 4, 8], [13, 11, 8], [5, 11, 8],
]
_EXPECTED_DST = [
    [0, 0, 0], [8, 0, 0], [8, 7, 0], [0, 7, 0],
    [0, 0, 5], [8, 0, 5], [8, 7, 5], [0, 7, 5],
]


def test_constant_values_preserved_integer_coordinates(device):
    """Deterministic integer-coordinate constants keep their exact values/dtype."""
    params = rg.center_crop_generator3d(2, 12, 16, 19, (6, 8, 9), device=device)
    src, dst = params["src"], params["dst"]
    assert src.dtype == torch.long and dst.dtype == torch.long
    assert src.device == device and dst.device == device
    assert src.shape == (2, 8, 3) and dst.shape == (2, 8, 3)
    expected_src = torch.tensor(_EXPECTED_SRC, device=device, dtype=torch.long)
    expected_dst = torch.tensor(_EXPECTED_DST, device=device, dtype=torch.long)
    for b in range(2):
        assert_close(src[b], expected_src, rtol=0, atol=0)
        assert_close(dst[b], expected_dst, rtol=0, atol=0)


def test_constant_construction_is_not_lifted(device):
    """The value-preserving construction is the non-lifting kind.

    Trace the deterministic integer-coordinate generator and assert no fresh
    constant lift, tying the value preservation above to the graph-safe
    construction (a naive torch.tensor path would lift here).
    """
    graph = make_fx(
        lambda: rg.center_crop_generator3d(1, 12, 16, 19, (6, 8, 9), device=device)["src"],
        _error_on_data_dependent_ops=False,
    )().graph
    assert all(n.target != torch.ops.aten.lift_fresh_copy.default for n in graph.nodes)


def test_resized_crop_numpy_scale_matches_tuple(device, dtype):
    """numpy-array scale ranges produce the same parameters as tuple ranges.

    Exercises the ``torch.as_tensor`` array-like fallback in the construction
    path (value semantics preserved for numpy inputs). pass_to_pass.
    """
    tuple_gen = rg.ResizedCropGenerator((8, 9), (0.5, 1.0), (0.8, 1.2)).to(device=device, dtype=dtype)
    numpy_gen = rg.ResizedCropGenerator((8, 9), np.array([0.5, 1.0]), (0.8, 1.2)).to(device=device, dtype=dtype)
    torch.manual_seed(0)
    expected = tuple_gen((4, 3, 16, 19))
    torch.manual_seed(0)
    actual = numpy_gen((4, 3, 16, 19))
    for name, value in expected.items():
        assert_close(actual[name], value, rtol=0, atol=0)


# =========================================================================== #
# Criterion 3 (F2P): samplers follow a module .to() move, including dtype-only
# and device-only moves that must preserve the other axis, and moves that reach
# the generator only by recursing through ``_apply`` (a parent ``nn.Module``
# container or a convenience ``.double()``/``.half()``).
#
# The ``meta`` device makes placement observable without an accelerator. The
# separating moves exploit the pre-fix generator's behavior:
#   * pre-fix ``RandomGeneratorBase`` overrides ``.to()`` but NOT ``_apply``, so
#     a parent-container move never reaches the samplers (they stay on CPU);
#   * the pre-fix ``.to()`` override re-derives BOTH axes from a single parse,
#     so a dtype-only move silently resets the device (and a device-only move
#     resets the dtype).
# AffineGenerator(30.0) has no shear here, so make_samplers runs on ``meta``
# without the data-dependent range check.
# =========================================================================== #
def test_generator_dtype_only_move_preserves_device():
    gen = rg.AffineGenerator(30.0)
    gen.to(device="meta", dtype=torch.float32)
    gen.to(dtype=torch.float64)
    assert gen.device == torch.device("meta")
    assert gen.dtype == torch.float64
    assert gen.degree_sampler.low.device.type == "meta"
    assert gen.degree_sampler.low.dtype == torch.float64


def test_generator_device_only_move_preserves_dtype():
    gen = rg.AffineGenerator(30.0)
    gen.to(dtype=torch.float64)
    gen.to(device="meta")
    assert gen.device == torch.device("meta")
    assert gen.dtype == torch.float64
    assert gen.degree_sampler.low.device.type == "meta"
    assert gen.degree_sampler.low.dtype == torch.float64


def test_generator_container_move_reaches_samplers():
    # A parent nn.Module move recurses through _apply only; pre-fix the generator
    # has no _apply override, so the samplers never leave CPU.
    gen = rg.AffineGenerator(30.0)
    torch.nn.Sequential(gen).to(device="meta", dtype=torch.float64)
    assert gen.device == torch.device("meta")
    assert gen.dtype == torch.float64
    assert gen.degree_sampler.low.device.type == "meta"
    assert gen.degree_sampler.low.dtype == torch.float64


# =========================================================================== #
# Criterion 4 (F2P): shear samplers honor the moved device/dtype for scalar,
# 2-element, and 4-element shear ranges, and sampling after the move does not
# raise. Observed on CPU with a float64 dtype move (the data-dependent range
# check forbids the meta device). Pre-fix: a scalar / 2-element shear builds the
# x-range at the default float32 and the y-range at the requested dtype, so the
# internal torch.stack raises on the dtype mismatch; a 4-element shear builds
# both ranges at float32, leaving the samplers at the wrong dtype.
# =========================================================================== #
@pytest.mark.parametrize("make_generator", [rg.ShearGenerator, partial(rg.AffineGenerator, 30.0)])
@pytest.mark.parametrize("shear", [10.0, (-10.0, 10.0), (-10.0, 10.0, -5.0, 5.0)])
def test_shear_sampler_placement(make_generator, shear):
    gen = make_generator(shear=shear).to(device=torch.device("cpu"), dtype=torch.float64)
    for sampler in (gen.shear_x_sampler, gen.shear_y_sampler):
        assert sampler.low.device == torch.device("cpu")
        assert sampler.low.dtype == torch.float64
    # Sampling must not raise after the move (device/dtype-mismatch regression).
    gen((4, 3, 16, 19))


# =========================================================================== #
# Criterion 5 (F2P): linear-illumination `gradient` follows a real device/dtype
# move, and the directions sampler stays float32 even after a float16 move
# (half-precision rand can return exactly 1.0 -> invalid direction 4).
# =========================================================================== #
@pytest.mark.parametrize(
    "make_generator",
    [
        pytest.param(lambda: rg.LinearIlluminationGenerator((0.1, 0.2), (-1.0, 1.0)), id="linear"),
        pytest.param(lambda: rg.LinearCornerIlluminationGenerator((0.1, 0.2), (-1.0, 1.0)), id="linear-corner"),
        pytest.param(
            lambda: rg.GaussianIlluminationGenerator((0.1, 0.2), (0.1, 0.2), (0.1, 0.2), (-1.0, 1.0)), id="gaussian"
        ),
    ],
)
def test_illumination_gradient_follows_move(make_generator):
    gen = make_generator().to(device=torch.device("cpu"), dtype=torch.float64)
    params = gen((4, 3, 16, 19))
    assert params["gradient"].device == torch.device("cpu")
    assert params["gradient"].dtype == torch.float64


@pytest.mark.parametrize(
    "generator_class", [rg.LinearIlluminationGenerator, rg.LinearCornerIlluminationGenerator]
)
def test_illumination_directions_sampler_stays_float32(generator_class):
    gen = generator_class((0.1, 0.2), (-1.0, 1.0)).to(device="meta", dtype=torch.float16)
    assert gen.directions_sampler.low.device.type == "meta"
    assert gen.directions_sampler.high.device.type == "meta"
    assert gen.directions_sampler.low.dtype == torch.float32


# =========================================================================== #
# Criterion 7 (F2P): the augmentation-level constant sites (reached only through
# the public ``kornia.augmentation`` module forward paths, NOT the generator
# roster) also build their constants in-graph. A fix that migrates only the 20
# ``random_generator`` constructors still lifts these:
#   * ``RandomMotionBlur.generate_parameters`` — the empty-batch ``idx`` constant
#     (``motion_blur.py``);
#   * a mix augmentation's forward — the ``dtype`` constant (``mix/base.py``);
#   * ``_BasicAugmentationBase.forward_parameters`` — the ``forward_input_shape``
#     constant (``base.py``), exercised on a representative ``K.Random*``.
# Observed on CPU via ``make_fx``, the same no-lift proxy the rest of this file
# uses. The modules are driven through their public constructors / call paths;
# no fix-internal symbol is referenced by name.
# =========================================================================== #
def _lift_nodes(graph):
    return [n for n in graph.nodes if n.target == torch.ops.aten.lift_fresh_copy.default]


def test_motion_blur_idx_constant_not_lifted():
    """The empty-batch ``idx`` constant builds in-graph (motion_blur.py)."""
    aug = K.RandomMotionBlur(3, 35.0, 0.5, p=1.0)
    graph = make_fx(
        lambda: aug.generate_parameters(torch.Size([0, 3, 64, 64]))["idx"],
        _error_on_data_dependent_ops=False,
    )().graph
    assert not _lift_nodes(graph), "RandomMotionBlur lifted the idx constant"


@pytest.mark.parametrize(
    "make_aug",
    [
        pytest.param(lambda: K.RandomMixUpV2(p=1.0), id="mixup"),
        pytest.param(lambda: K.RandomCutMixV2(p=1.0), id="cutmix"),
    ],
)
def test_mix_dtype_constant_not_lifted(make_aug):
    """A mix augmentation's forward builds its ``dtype`` constant in-graph (mix/base.py)."""
    aug = make_aug()
    graph = make_fx(lambda x: aug(x), _error_on_data_dependent_ops=False)(torch.rand(2, 3, 16, 16)).graph
    assert not _lift_nodes(graph), "mix augmentation lifted the dtype constant"


@pytest.mark.parametrize(
    "make_aug",
    [
        pytest.param(lambda: K.RandomAffine(degrees=(-30.0, 30.0), p=1.0), id="affine"),
        pytest.param(lambda: K.RandomPerspective(0.5, p=1.0), id="perspective"),
    ],
)
def test_forward_parameters_input_shape_not_lifted(make_aug):
    """The augmentation-level ``forward_input_shape`` constant builds in-graph (base.py)."""
    aug = make_aug()
    graph = make_fx(
        lambda: aug.forward_parameters(torch.Size([2, 3, 64, 64]))["forward_input_shape"],
        _error_on_data_dependent_ops=False,
    )().graph
    assert not _lift_nodes(graph), "forward_parameters lifted the forward_input_shape constant"


# =========================================================================== #
# Criterion 6 (F2P): center_crop_generator3d empty-batch params match the
# non-empty path's dtype (long) and device, not CPU float32.
# =========================================================================== #
def test_centercrop3d_empty_batch_matches_batched(device):
    empty = rg.center_crop_generator3d(0, 12, 16, 19, (6, 8, 9), device=device)
    batched = rg.center_crop_generator3d(1, 12, 16, 19, (6, 8, 9), device=device)
    assert set(empty) == set(batched)
    for name, value in batched.items():
        assert empty[name].shape == (0, *value.shape[1:]), name
        assert empty[name].device == value.device, name
        assert empty[name].dtype == value.dtype, name
