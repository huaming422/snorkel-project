## Task

we've been getting reports that kornia's image augmentations fall apart the moment you leave plain CPU eager mode, with two related symptoms.

first: wrap an augmentation pipeline in `torch.compile` and run it on a GPU, and it crashes hard at runtime. the same pipeline runs clean in eager mode and on CPU, so it only shows up once things are compiled on an accelerator.

second: move an augmentation onto a non-CPU device, or switch its working dtype, and the next call either throws a device-mismatch error or quietly hands back parameters at the wrong precision. a double-precision pipeline can silently come back single-precision, with an extra cross-device copy on every call.

the trouble is somewhere in the augmentation parameter-generation path. dig in, work out what's going wrong, and fix it so augmentations stay correct both under compilation and after a device or dtype move. eager-mode results and the public API need to stay exactly as they are now, and the whole thing has to be verifiable on a CPU-only machine.
