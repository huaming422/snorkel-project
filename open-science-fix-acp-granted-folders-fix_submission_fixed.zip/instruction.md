## Task

A user granted the agent read/write access to a folder outside the project, and the session shows the folder with that access. When the agent then reads or writes a file in that folder, the request fails with an error saying the path is outside the active workspace.

The agent should be able to read and write in a granted folder at the access level the user gave it. A link inside the folder that points elsewhere mustn't let the agent read or write outside it.
