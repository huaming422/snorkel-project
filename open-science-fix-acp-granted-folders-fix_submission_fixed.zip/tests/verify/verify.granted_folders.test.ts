// @ts-nocheck
//
// Behavioural check for granted-folder native file access through the public
// ACP runtime surface.
//
// Every case drives a real prompt: a fake ACP agent process is wired to the
// pre-existing `AcpRuntime` (via `./runtime.test-utils`) and, inside its prompt
// handler, issues `fs/read_text_file` / `fs/write_text_file` requests exactly as
// a live agent would. The runtime is configured through its pre-existing
// `grantedRoots` option and, where relevant, `additionalProtectedReadRoots`.
// Assertions are limited to observable outcomes: the content handed back to the
// agent, the bytes on disk, whether a file outside the granted folder was
// created, and whether a request was rejected.
//
// Each grant case pairs an operation that must be refused with a legitimate one
// on the same grant in the same run, so a runtime that refuses everything fails
// the legitimate half and one that lets a link carry access outside the folder
// fails the refused half. The last two cases keep ordinary workspace access and
// protected application directories behaving as before.

import * as acp from '@agentclientprotocol/sdk'
import { EventEmitter } from 'node:events'
import { mkdir, mkdtemp, readFile, realpath, rm, symlink, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { basename, join } from 'node:path'
import { PassThrough, Readable, Writable } from 'node:stream'
import { describe, expect, it, vi } from 'vitest'

// The main process imports electron; stub the two members the runtime touches.
vi.mock('electron', () => ({ app: { getPath: () => tmpdir(), isPackaged: true } }))

import { AcpRuntime } from './runtime.test-utils'

const SESSION_ID = 'granted-folder-session'
const readMethod = acp.methods.client.fs.readTextFile
const writeMethod = acp.methods.client.fs.writeTextFile

// Minimal child-process stand-in exposing the streams the runtime expects.
class FakeAgentProcess extends EventEmitter {
  stdin = new PassThrough()
  stdout = new PassThrough()
  stderr = new PassThrough()
  killed = false
  pid: number | undefined = undefined

  kill(): boolean {
    this.killed = true
    this.emit('exit', 0, null)
    return true
  }
}

const asAgentProcess = (process: FakeAgentProcess) =>
  process as unknown as ChildProcessWithoutNullStreams

// Builds an ACP agent whose prompt handler runs `scenario(ctx, sessionId)`,
// constructs the runtime around it, drives one prompt, and returns the runtime
// so the caller can disconnect in its finally block. The scenario swallows its
// own request errors into outer variables (a live agent likewise does not abort
// the turn on a filesystem rejection), so assertions run after the prompt.
const drivePrompt = async ({
  workspaceRoot,
  grantedRoots,
  additionalProtectedReadRoots,
  scenario
}): Promise<AcpRuntime> => {
  const process = new FakeAgentProcess()
  acp
    .agent({ name: 'granted-folder-agent' })
    .onRequest(acp.methods.agent.initialize, () => ({
      protocolVersion: acp.PROTOCOL_VERSION,
      agentCapabilities: {
        loadSession: false,
        sessionCapabilities: { close: {} }
      },
      authMethods: []
    }))
    .onRequest(acp.methods.agent.session.new, () => ({ sessionId: SESSION_ID }))
    .onRequest(acp.methods.agent.session.prompt, async (ctx) => {
      await scenario(ctx, SESSION_ID)
      return { stopReason: 'end_turn' }
    })
    .connect(
      acp.ndJsonStream(
        Writable.toWeb(process.stdout) as WritableStream<Uint8Array>,
        Readable.toWeb(process.stdin) as ReadableStream<Uint8Array>
      )
    )

  const runtime = new AcpRuntime({
    appVersion: '0.1.0',
    defaultCwd: workspaceRoot,
    spawnAgent: () => asAgentProcess(process),
    ...(additionalProtectedReadRoots ? { additionalProtectedReadRoots } : {}),
    grantedRoots
  })
  const session = await runtime.createSession({ cwd: workspaceRoot })
  await runtime.sendPrompt({ sessionId: session.sessionId, text: 'process the granted folder' })
  return runtime
}

// The grant record carries `resolveRoot` (single-root lookup) and the list of
// grants. Any other accessor name read off it returns that same list, so the
// list is reachable whatever the runtime calls its enumeration method. Promise,
// serialisation and matcher probes are answered as absent so the object is never
// mistaken for a thenable or a matcher.
const NON_ACCESSOR_KEYS = new Set([
  'then',
  'catch',
  'finally',
  'toJSON',
  'constructor',
  'toString',
  'valueOf',
  'asymmetricMatch',
  '$$typeof',
  'nodeType',
  'tagName'
])

const grantProvider = (roots) => {
  const records = roots.map((root) => ({ name: basename(root.path), ...root }))
  const list = async () => records
  const resolveRoot = async (rootId) => records.find((root) => root.id === rootId)
  return new Proxy(
    { list, resolveRoot },
    {
      get: (_target, key) => {
        if (key === 'resolveRoot') return resolveRoot
        if (typeof key !== 'string' || NON_ACCESSOR_KEYS.has(key)) return undefined
        return list
      },
      has: (_target, key) => typeof key === 'string' && !NON_ACCESSOR_KEYS.has(key)
    }
  )
}

describe('ACP native file access honours folder grants', () => {
  it('reads and writes inside a folder granted read-write during a real prompt', async () => {
    const workspaceRoot = await realpath(await mkdtemp(join(tmpdir(), 'acp-ws-')))
    const grantedRoot = await realpath(await mkdtemp(join(tmpdir(), 'acp-grant-')))
    const inputPath = join(grantedRoot, 'progress.txt')
    const outputPath = join(grantedRoot, 'result.txt')
    let readContent
    let fsError
    let runtime

    try {
      await writeFile(inputPath, 'authorized progress', 'utf8')
      runtime = await drivePrompt({
        workspaceRoot,
        grantedRoots: grantProvider([{ id: 'g1', path: grantedRoot, access: 'rw' }]),
        scenario: async (ctx, sessionId) => {
          try {
            const input = await ctx.client.request(readMethod, { sessionId, path: inputPath })
            readContent = input.content
            await ctx.client.request(writeMethod, {
              sessionId,
              path: outputPath,
              content: `${input.content} (processed)`
            })
          } catch (error) {
            fsError = error
          }
        }
      })

      expect(fsError).toBeUndefined()
      expect(readContent).toBe('authorized progress')
      await expect(readFile(outputPath, 'utf8')).resolves.toBe('authorized progress (processed)')
    } finally {
      if (runtime) await runtime.disconnect()
      await rm(workspaceRoot, { recursive: true, force: true })
      await rm(grantedRoot, { recursive: true, force: true })
    }
  })

  it('enforces a read-only grant: the read succeeds but the write is rejected and creates no file', async () => {
    const workspaceRoot = await realpath(await mkdtemp(join(tmpdir(), 'acp-ws-')))
    const grantedRoot = await realpath(await mkdtemp(join(tmpdir(), 'acp-grant-ro-')))
    const readablePath = join(grantedRoot, 'notes.txt')
    const writeTarget = join(grantedRoot, 'forbidden.txt')
    let readContent
    let readError
    let writeRejected = false
    let runtime

    try {
      await writeFile(readablePath, 'read only content', 'utf8')
      runtime = await drivePrompt({
        workspaceRoot,
        grantedRoots: grantProvider([{ id: 'g1', path: grantedRoot, access: 'ro' }]),
        scenario: async (ctx, sessionId) => {
          try {
            const input = await ctx.client.request(readMethod, { sessionId, path: readablePath })
            readContent = input.content
          } catch (error) {
            readError = error
          }
          try {
            await ctx.client.request(writeMethod, {
              sessionId,
              path: writeTarget,
              content: 'should not be written'
            })
          } catch {
            writeRejected = true
          }
        }
      })

      // Positive control: a read-only grant still allows reads.
      expect(readError).toBeUndefined()
      expect(readContent).toBe('read only content')
      // The write through the same read-only grant is refused and lands nothing.
      expect(writeRejected).toBe(true)
      await expect(readFile(writeTarget, 'utf8')).rejects.toMatchObject({ code: 'ENOENT' })
    } finally {
      if (runtime) await runtime.disconnect()
      await rm(workspaceRoot, { recursive: true, force: true })
      await rm(grantedRoot, { recursive: true, force: true })
    }
  })

  it.skipIf(process.platform === 'win32')(
    'rejects a write through a dangling symlink inside a granted folder while a normal write succeeds',
    async () => {
      const workspaceRoot = await realpath(await mkdtemp(join(tmpdir(), 'acp-ws-')))
      const grantedRoot = await realpath(await mkdtemp(join(tmpdir(), 'acp-grant-link-')))
      const externalDir = await realpath(await mkdtemp(join(tmpdir(), 'acp-external-')))
      const externalTarget = join(externalDir, 'escaped.txt') // does not exist yet
      const danglingPath = join(grantedRoot, 'linked.txt')
      const normalPath = join(grantedRoot, 'normal.txt')
      let normalWritten = false
      let normalError
      let danglingRejected = false
      let runtime

      try {
        await symlink(externalTarget, danglingPath, 'file')
        runtime = await drivePrompt({
          workspaceRoot,
          grantedRoots: grantProvider([{ id: 'g1', path: grantedRoot, access: 'rw' }]),
          scenario: async (ctx, sessionId) => {
            try {
              await ctx.client.request(writeMethod, {
                sessionId,
                path: normalPath,
                content: 'normal write'
              })
              normalWritten = true
            } catch (error) {
              normalError = error
            }
            try {
              await ctx.client.request(writeMethod, {
                sessionId,
                path: danglingPath,
                content: 'escaping write'
              })
            } catch {
              danglingRejected = true
            }
          }
        })

        // Positive control: a plain path in the granted folder is writable.
        expect(normalError).toBeUndefined()
        expect(normalWritten).toBe(true)
        await expect(readFile(normalPath, 'utf8')).resolves.toBe('normal write')
        // The dangling-link write is refused and the external target stays absent.
        expect(danglingRejected).toBe(true)
        await expect(readFile(externalTarget, 'utf8')).rejects.toMatchObject({ code: 'ENOENT' })
      } finally {
        if (runtime) await runtime.disconnect()
        await rm(workspaceRoot, { recursive: true, force: true })
        await rm(grantedRoot, { recursive: true, force: true })
        await rm(externalDir, { recursive: true, force: true })
      }
    }
  )

  it.skipIf(process.platform === 'win32')(
    'refuses to follow links inside a granted folder to files and directories outside it',
    async () => {
      const workspaceRoot = await realpath(await mkdtemp(join(tmpdir(), 'acp-ws-')))
      const grantedRoot = await realpath(await mkdtemp(join(tmpdir(), 'acp-grant-escape-')))
      const outsideRoot = await realpath(await mkdtemp(join(tmpdir(), 'acp-outside-')))
      const normalFile = join(grantedRoot, 'ok.txt')
      const outsideSecret = join(outsideRoot, 'secret.txt')
      const linkedFile = join(grantedRoot, 'secret-link.txt')
      const linkedDir = join(grantedRoot, 'shared')
      const writeThroughLinkedDir = join(linkedDir, 'dropped.txt')
      const outsideDropped = join(outsideRoot, 'dropped.txt')
      let normalContent
      let normalError
      let linkedContent
      let linkedReadRejected = false
      let linkedWriteRejected = false
      let runtime

      try {
        await writeFile(normalFile, 'granted content', 'utf8')
        await writeFile(outsideSecret, 'outside secret', 'utf8')
        await symlink(outsideSecret, linkedFile, 'file')
        await symlink(outsideRoot, linkedDir, 'dir')

        runtime = await drivePrompt({
          workspaceRoot,
          grantedRoots: grantProvider([{ id: 'g1', path: grantedRoot, access: 'rw' }]),
          scenario: async (ctx, sessionId) => {
            try {
              const input = await ctx.client.request(readMethod, { sessionId, path: normalFile })
              normalContent = input.content
            } catch (error) {
              normalError = error
            }
            try {
              const input = await ctx.client.request(readMethod, { sessionId, path: linkedFile })
              linkedContent = input.content
            } catch {
              linkedReadRejected = true
            }
            try {
              await ctx.client.request(writeMethod, {
                sessionId,
                path: writeThroughLinkedDir,
                content: 'escaping write'
              })
            } catch {
              linkedWriteRejected = true
            }
          }
        })

        // Positive control: a plain file in the granted folder is readable.
        expect(normalError).toBeUndefined()
        expect(normalContent).toBe('granted content')
        // A file link pointing outside the folder does not hand back the outside file.
        expect(linkedReadRejected).toBe(true)
        expect(linkedContent).toBeUndefined()
        // A write through a directory link pointing outside is refused and lands nothing there.
        expect(linkedWriteRejected).toBe(true)
        await expect(readFile(outsideDropped, 'utf8')).rejects.toMatchObject({ code: 'ENOENT' })
      } finally {
        if (runtime) await runtime.disconnect()
        await rm(workspaceRoot, { recursive: true, force: true })
        await rm(grantedRoot, { recursive: true, force: true })
        await rm(outsideRoot, { recursive: true, force: true })
      }
    }
  )

  it('keeps ordinary workspace-internal reads and writes working', async () => {
    const workspaceRoot = await realpath(await mkdtemp(join(tmpdir(), 'acp-ws-')))
    const inputPath = join(workspaceRoot, 'input.txt')
    const outputPath = join(workspaceRoot, 'nested', 'output.txt')
    let readContent
    let fsError
    let runtime

    try {
      await writeFile(inputPath, 'workspace content', 'utf8')
      runtime = await drivePrompt({
        workspaceRoot,
        grantedRoots: grantProvider([]),
        scenario: async (ctx, sessionId) => {
          try {
            const input = await ctx.client.request(readMethod, { sessionId, path: inputPath })
            readContent = input.content
            await ctx.client.request(writeMethod, {
              sessionId,
              path: outputPath,
              content: `${input.content} saved`
            })
          } catch (error) {
            fsError = error
          }
        }
      })

      expect(fsError).toBeUndefined()
      expect(readContent).toBe('workspace content')
      await expect(readFile(outputPath, 'utf8')).resolves.toBe('workspace content saved')
    } finally {
      if (runtime) await runtime.disconnect()
      await rm(workspaceRoot, { recursive: true, force: true })
    }
  })

  it('keeps application-owned protected directories unreadable', async () => {
    const workspaceRoot = await realpath(await mkdtemp(join(tmpdir(), 'acp-ws-')))
    const protectedDir = join(workspaceRoot, 'app-config')
    const secretPath = join(protectedDir, 'credentials.json')
    let protectedContent
    let protectedRejected = false
    let runtime

    try {
      await mkdir(protectedDir, { recursive: true })
      await writeFile(secretPath, 'app secret', 'utf8')
      runtime = await drivePrompt({
        workspaceRoot,
        additionalProtectedReadRoots: [protectedDir],
        grantedRoots: grantProvider([]),
        scenario: async (ctx, sessionId) => {
          try {
            const input = await ctx.client.request(readMethod, { sessionId, path: secretPath })
            protectedContent = input.content
          } catch {
            protectedRejected = true
          }
        }
      })

      expect(protectedRejected).toBe(true)
      expect(protectedContent).toBeUndefined()
    } finally {
      if (runtime) await runtime.disconnect()
      await rm(workspaceRoot, { recursive: true, force: true })
    }
  })
})
