## Task

On some accounts the client keeps sending /messages back-pagination requests for a few rooms in the background, over and over, and never settles. The rooms we've seen it on have a long recent run of reactions with no actual message in it, so there's nothing for the room list to show as their latest event. It comes back every time the app is reopened.

Find out why the client keeps going back for history on those rooms and stop it. It shouldn't be pulling their history from the server in the background at all.
