#!/usr/bin/env bash
# Test-setup for matrix-rust-sdk-fix-backfill-loop.
#
# The image bakes the full dependency closure at the base commit: the cargo
# registry/git caches live under CARGO_HOME (/opt/cache/cargo) and the whole
# unit suite's test binaries are pre-compiled into CARGO_TARGET_DIR
# (/opt/cache/cargo-target). No dependency is added by the reference change, so
# nothing is installed here. No services to start, no data to seed.
#
# Make an offline cache miss fail fast instead of stalling against the (dead)
# network during the agent phase; the image already carries everything the
# build needs, so a miss is a real error, not a fetch to retry. Scoped to this
# task's own cargo invocations (an export), never baked image-wide, so harbor's
# `uv tool install` of the agent harness at trial prep still sees a live network.
set -euo pipefail

export CARGO_NET_OFFLINE=true

echo "[test-setup] rustc:           $(rustc --version 2>&1 | head -1)"
echo "[test-setup] cargo:           $(cargo --version 2>&1 | head -1)"
echo "[test-setup] CARGO_HOME:      ${CARGO_HOME:-unset}"
echo "[test-setup] CARGO_TARGET_DIR:${CARGO_TARGET_DIR:-unset}"
echo "[test-setup] workspace root:  /repo/matrix-rust-sdk"
echo "[test-setup] CARGO_NET_OFFLINE=${CARGO_NET_OFFLINE}"
echo "[test-setup] Setup complete."
