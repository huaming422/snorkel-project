//! Latest-event behaviour for rooms whose newest stored history is long and
//! holds nothing to show in the room list.
//!
//! Everything here goes through the public surface the crate's own
//! `tests/integration/latest_event.rs` uses: `Client::latest_events()` and
//! `LatestEvents::listen_and_subscribe_to_room(room_id)`, a `MemoryStore`
//! event cache seeded with chunks via
//! `EventCacheStore::handle_linked_chunk_updates`, and `MatrixMockServer`,
//! whose wiremock server records every `/messages` request so a background
//! history fetch shows up as a request count.

use assert_matches::assert_matches;
use matrix_sdk::{
    cross_process_lock::CrossProcessLockConfig,
    latest_events::LatestEventValue,
    linked_chunk::{ChunkIdentifier, LinkedChunkId, Position, Update},
    store::StoreConfig,
    test_utils::mocks::{MatrixMockServer, RoomMessagesResponseTemplate},
    Client,
};
use matrix_sdk_base::event_cache::{
    store::{EventCacheStore, MemoryStore},
    Gap,
};
use matrix_sdk_test::{async_test, event_factory::EventFactory};
use ruma::{event_id, owned_room_id, room_id, user_id};
use tokio::time::{sleep, timeout, Duration};

/// Build a client with automatic background history fetching enabled, on top of
/// a pre-seeded in-memory event-cache store. Mirrors the setup used by the
/// crate's own latest-event integration test, plus the builder switch that
/// turns on background history fetching (off by default).
async fn client_with_store(server: &MatrixMockServer, store: MemoryStore) -> Client {
    server
        .client_builder()
        .on_builder(|builder| {
            builder.with_enable_automatic_back_pagination(true).store_config(
                StoreConfig::new(CrossProcessLockConfig::MultiProcess {
                    holder_name: "test".to_owned(),
                })
                .event_cache_store(store),
            )
        })
        .build()
        .await
}

/// Count the `/messages` (history fetch) requests the server has seen so far,
/// optionally restricted to those paginating from a particular token (the
/// `from=` query parameter). Restricting by token isolates the fetch triggered
/// by one specific gap from any unrelated background pagination.
async fn history_fetch_count(server: &MatrixMockServer, from_token: Option<&str>) -> usize {
    server
        .server()
        .received_requests()
        .await
        .unwrap_or_default()
        .iter()
        .filter(|r| r.url.path().ends_with("/messages"))
        .filter(|r| match from_token {
            None => true,
            Some(token) => {
                r.url.query_pairs().any(|(k, v)| k == "from" && v == token)
            }
        })
        .count()
}

/// A room whose newest 50 stored chunks hold 20 reactions each (1,000 events,
/// none of them displayable) and whose only gap sits behind all of them. The
/// room list has nothing to show for it, and the client must not go to the
/// server through that far gap to look for something.
#[async_test]
async fn test_no_history_fetch_through_a_far_gap_behind_undisplayable_history() {
    let room_id = owned_room_id!("!r0");
    let sender = user_id!("@bob:example.org");
    let f = EventFactory::new().room(&room_id).sender(sender);

    // Store layout (oldest -> newest):
    //   [gap "deep"] <- [20 reactions] <- ... (50 chunks) ... <- [20 reactions]
    // Only the newest chunk is loaded in memory.
    const DEEP_CHUNKS: u64 = 50;
    const REACTIONS_PER_CHUNK: u64 = 20;

    let store = MemoryStore::new();
    let mut updates = vec![Update::NewGapChunk {
        previous: None,
        new: ChunkIdentifier::new(0),
        next: None,
        gap: Gap { token: "deep".to_owned() },
    }];
    for i in 1..=DEEP_CHUNKS {
        updates.push(Update::NewItemsChunk {
            previous: Some(ChunkIdentifier::new(i - 1)),
            new: ChunkIdentifier::new(i),
            next: None,
        });
        updates.push(Update::PushItems {
            at: Position::new(ChunkIdentifier::new(i), 0),
            items: (0..REACTIONS_PER_CHUNK)
                .map(|j| {
                    f.reaction(event_id!("$target"), "+1")
                        .event_id(&ruma::EventId::parse(format!("$r{i}_{j}")).unwrap())
                        .into_event()
                })
                .collect(),
        });
    }
    store.handle_linked_chunk_updates(LinkedChunkId::Room(&room_id), updates).await.unwrap();

    let server = MatrixMockServer::new().await;
    let client = client_with_store(&server, store).await;

    // Bring the room into existence without seeding any timeline events or
    // read receipts (which could trigger an unrelated history fetch).
    let _room = server.sync_joined_room(&client, &room_id).await;

    // Subscribing computes the latest event from the event cache. Nothing
    // displayable exists, so the value stays `None`.
    let mut stream = client
        .latest_events()
        .await
        .unwrap()
        .listen_and_subscribe_to_room(&room_id)
        .await
        .unwrap()
        .unwrap();

    assert_matches!(stream.next_now().await, LatestEventValue::None);

    // Leave the background work plenty of time to reach the server if it is
    // going to.
    sleep(Duration::from_secs(2)).await;

    assert_eq!(
        history_fetch_count(&server, Some("deep")).await,
        0,
        "history was fetched from the server through a gap 50 stored chunks \
         (1,000 undisplayable events) back"
    );
}

/// A room whose two newest stored chunks hold only reactions, with a gap right
/// behind them and a displayable message behind that gap, still fetches history
/// and resolves to that message.
#[async_test]
async fn test_near_stored_gap_still_fetches_history() {
    let room_id = owned_room_id!("!r0");
    let sender = user_id!("@bob:example.org");
    let f = EventFactory::new().room(&room_id).sender(sender);

    // Store layout (oldest -> newest):
    //   [gap "near"] <- [reaction] <- [reaction]
    // Only the newest chunk is loaded in memory.
    let store = MemoryStore::new();
    store
        .handle_linked_chunk_updates(
            LinkedChunkId::Room(&room_id),
            vec![
                Update::NewGapChunk {
                    previous: None,
                    new: ChunkIdentifier::new(0),
                    next: None,
                    gap: Gap { token: "near".to_owned() },
                },
                Update::NewItemsChunk {
                    previous: Some(ChunkIdentifier::new(0)),
                    new: ChunkIdentifier::new(1),
                    next: None,
                },
                Update::PushItems {
                    at: Position::new(ChunkIdentifier::new(1), 0),
                    items: vec![f
                        .reaction(event_id!("$target"), "+1")
                        .event_id(event_id!("$r1"))
                        .into_event()],
                },
                Update::NewItemsChunk {
                    previous: Some(ChunkIdentifier::new(1)),
                    new: ChunkIdentifier::new(2),
                    next: None,
                },
                Update::PushItems {
                    at: Position::new(ChunkIdentifier::new(2), 0),
                    items: vec![f
                        .reaction(event_id!("$target"), "+1")
                        .event_id(event_id!("$r2"))
                        .into_event()],
                },
            ],
        )
        .await
        .unwrap();

    let server = MatrixMockServer::new().await;
    let client = client_with_store(&server, store).await;

    // A displayable message lives behind the gap.
    server
        .mock_room_messages()
        .match_from("near")
        .ok(RoomMessagesResponseTemplate::default()
            .events(vec![f.text_msg("hello").event_id(event_id!("$1"))]))
        .mount()
        .await;

    let _room = server.sync_joined_room(&client, &room_id).await;

    let mut stream = client
        .latest_events()
        .await
        .unwrap()
        .listen_and_subscribe_to_room(&room_id)
        .await
        .unwrap()
        .unwrap();

    let resolved = timeout(Duration::from_secs(10), async {
        loop {
            if let LatestEventValue::Remote(event) = stream.next_now().await {
                assert_eq!(event.event_id().as_deref(), Some(event_id!("$1")));
                return;
            }
            sleep(Duration::from_millis(25)).await;
        }
    })
    .await;
    assert!(
        resolved.is_ok(),
        "the latest event never resolved to the message behind the gap two stored chunks back"
    );
}

/// A room whose only chunk is a gap, with a displayable event waiting behind
/// it, fetches history and resolves to that event. (Same scenario as the
/// crate's `test_update_with_event_cache_backfills_for_a_candidate`.)
#[async_test]
async fn test_genuine_gap_still_fetches_history() {
    let room_id = room_id!("!r0");
    let sender = user_id!("@bob:example.org");
    let f = EventFactory::new().room(room_id).sender(sender);

    // A single gap: nothing in memory to show, but a token to fetch from.
    let store = MemoryStore::new();
    store
        .handle_linked_chunk_updates(
            LinkedChunkId::Room(room_id),
            vec![Update::NewGapChunk {
                previous: None,
                new: ChunkIdentifier::new(0),
                next: None,
                gap: Gap { token: "prev_batch".to_owned() },
            }],
        )
        .await
        .unwrap();

    let server = MatrixMockServer::new().await;
    let client = client_with_store(&server, store).await;

    // A displayable message lives behind the gap.
    server
        .mock_room_messages()
        .match_from("prev_batch")
        .ok(RoomMessagesResponseTemplate::default()
            .events(vec![f.text_msg("hello").event_id(event_id!("$1"))]))
        .mock_once()
        .mount()
        .await;

    let _room = server.sync_joined_room(&client, room_id).await;

    let mut stream = client
        .latest_events()
        .await
        .unwrap()
        .listen_and_subscribe_to_room(room_id)
        .await
        .unwrap()
        .unwrap();

    // The history fetch surfaces the message in the background; the latest
    // event eventually resolves to it. Poll the current value to a deadline.
    let resolved = timeout(Duration::from_secs(10), async {
        loop {
            if let LatestEventValue::Remote(event) = stream.next_now().await {
                assert_eq!(event.event_id().as_deref(), Some(event_id!("$1")));
                return;
            }
            sleep(Duration::from_millis(25)).await;
        }
    })
    .await;
    assert!(
        resolved.is_ok(),
        "the latest event never resolved to the event behind the genuine gap"
    );
}

/// A displayable candidate that lives in a stored (not-in-memory) chunk a short
/// way back is used as-is, with no history fetch. (Same scenario as the crate's
/// `test_update_with_event_cache_uses_a_stored_candidate_without_backfilling`.)
#[async_test]
async fn test_stored_candidate_used_without_fetch() {
    let room_id = owned_room_id!("!r0");
    let sender = user_id!("@bob:example.org");
    let f = EventFactory::new().room(&room_id).sender(sender);

    // Older chunk: a displayable candidate. Newest (in-memory) chunk: only a
    // reaction, which is not displayable.
    let store = MemoryStore::new();
    store
        .handle_linked_chunk_updates(
            LinkedChunkId::Room(&room_id),
            vec![
                Update::NewItemsChunk { previous: None, new: ChunkIdentifier::new(0), next: None },
                Update::PushItems {
                    at: Position::new(ChunkIdentifier::new(0), 0),
                    items: vec![f.text_msg("hello").event_id(event_id!("$1")).into_event()],
                },
                Update::NewItemsChunk {
                    previous: Some(ChunkIdentifier::new(0)),
                    new: ChunkIdentifier::new(1),
                    next: None,
                },
                Update::PushItems {
                    at: Position::new(ChunkIdentifier::new(1), 0),
                    items: vec![f
                        .reaction(event_id!("$1"), "+1")
                        .event_id(event_id!("$2"))
                        .into_event()],
                },
            ],
        )
        .await
        .unwrap();

    let server = MatrixMockServer::new().await;
    let client = client_with_store(&server, store).await;

    let _room = server.sync_joined_room(&client, &room_id).await;

    let mut stream = client
        .latest_events()
        .await
        .unwrap()
        .listen_and_subscribe_to_room(&room_id)
        .await
        .unwrap()
        .unwrap();

    // The latest event resolves to the stored message. Poll the current value
    // to a deadline (it may already be set by the time we first look).
    let resolved = timeout(Duration::from_secs(10), async {
        loop {
            if let LatestEventValue::Remote(event) = stream.next_now().await {
                assert_eq!(event.event_id().as_deref(), Some(event_id!("$1")));
                return;
            }
            sleep(Duration::from_millis(25)).await;
        }
    })
    .await;
    assert!(resolved.is_ok(), "the latest event never resolved to the stored candidate");

    // Give any history fetch time to fire, then confirm none did: the stored
    // message was used directly.
    sleep(Duration::from_millis(300)).await;
    assert_eq!(
        history_fetch_count(&server, None).await,
        0,
        "a history fetch was scheduled despite a usable stored candidate"
    );
}
