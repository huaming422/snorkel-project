## Task

our document pipeline pulls text out of uploaded PDFs, including scanned ones that go through OCR, and feeds it into indexing. we've had reports that on some documents the extracted text comes out mangled: characters go missing, characters show up twice, and on pages with heavy indentation (tables of contents, pages with footnotes, anything with staggered lines) the text lands in the wrong order. it's worst on the scanned OCR pages and the indent-heavy ones.

these documents used to extract cleanly, and the output is supposed to match our reference extractor, so something has regressed. the parser doesn't throw, it just hands back corrupted text.

dig into why the text is getting mangled and fix it at the source. we want the parsing itself reading the characters and their order correctly, not a cleanup pass bolted onto the final string. and whatever turns out to be behind it, the documents that already come out right need to keep coming out right.
