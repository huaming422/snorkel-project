#!/usr/bin/env bash
# Verifier setup for ragflow-fix-ocr-char-gaps.
#
# The Go toolchain, the full module cache, and a warm build cache for the
# deepdoc PDF parser subtree are all baked into the image at the base commit
# (see image/Dockerfile). Nothing is fetched here. We only pin Go into
# fully-offline mode so a stray cache miss fails fast instead of hanging on a
# dead network during the air-gapped verifier phase.
set -euo pipefail

export CGO_ENABLED=0
export GOFLAGS=-mod=mod
export GOPROXY=off

# Persist the offline switches for any `go` invocation the verifier makes.
go env -w GOFLAGS=-mod=mod GOPROXY=off CGO_ENABLED=0 2>/dev/null || true

echo "[test-setup] ragflow-fix-ocr-char-gaps: Go offline mode set; deps baked in image."
