// Staff-Bench behavioral verifier (package pdf) — covered-left-fragment drop.
//
// Tests the covered-left-fragment behavior THROUGH the pre-existing, stable
// `(*Parser).buildTextBoxes` method — the OCR-fallback assembly stage that
// decides whether a char-less detect box is OCR-filled or left empty (and then
// dropped by the trailing empty-text filter). It does NOT name any
// fix-introduced helper, so it compiles on both the pre- and post-fix trees
// and separates them purely on the observable output: the number of text boxes
// returned and which box survives.
//
// Why through buildTextBoxes and not a predicate call: the fix is free to
// implement the covered-fragment decision inline at the call site OR as an
// extracted named predicate (both are valid per the task's alternative-
// implementation contract). Asserting a specific helper name would reject the
// inlined variant — a false negative. The box-count behavior is identical for
// both variants, so this is the correct interface to test at.
//
// Observable behavior (empirically confirmed on both trees):
//   pre-fix  : the char-less left fragment is sent to OCR, filled with the
//              same-line neighbor's glyph, and SURVIVES -> len == 2 (duplicate).
//   post-fix : the fragment is recognized as covered by its right neighbor,
//              skipped, and dropped by the trailing filter -> len == 1.
//
// NO cgo build tag: buildTextBoxes, ocrDetectBox and the whole OCR-merge path
// live in parser_ocr.go / parser_concurrency.go, which carry no build
// constraint, so this runs under CGO_ENABLED=0 with no native pdfium/pdfoxide
// bridge. The analyzer is a tiny in-file stub; nothing renders a real PDF.
//
// Geometry transcribed verbatim from the reference covered-left-fragment
// fixture (narrow left box 220.7..239.3 overhanging the real text box
// 234.7..456.3 on the same TOC line).

package pdf

import (
	"context"
	"image"
	"testing"

	pdftype "ragflow/internal/deepdoc/parser/pdf/type"
)

// fragStubAnalyzer is a healthy DocAnalyzer whose OCRRecognize always returns a
// single glyph. It lets buildTextBoxes' OCR fallback run end-to-end offline: a
// char-less box routed to OCR comes back carrying "妨", so a tree that fails to
// recognize the box as a covered fragment produces a visible duplicate box.
// Only Health + OCRRecognize are exercised; the other four methods satisfy the
// interface and return empty.
type fragStubAnalyzer struct{}

func (fragStubAnalyzer) DLA(context.Context, image.Image) ([]pdftype.DLARegion, error) {
	return nil, nil
}
func (fragStubAnalyzer) TSR(context.Context, image.Image) ([]pdftype.TSRCell, error) {
	return nil, nil
}
func (fragStubAnalyzer) OCRDetect(context.Context, image.Image) ([]pdftype.OCRBox, error) {
	return nil, nil
}
func (fragStubAnalyzer) OCRRecognize(context.Context, image.Image) ([]pdftype.OCRText, error) {
	return []pdftype.OCRText{{Text: "妨", Confidence: 0.99}}, nil
}
func (fragStubAnalyzer) Health() bool { return true }

// newFragStubImage returns a page image large enough to crop every fixture box
// (scale 3.0 -> max pixel ~1369x8478).
func newFragStubImage() image.Image { return image.NewRGBA(image.Rect(0, 0, 2000, 9000)) }

// TestCoveredLeftFragment_DroppedByBuildTextBoxes — fail_to_pass (+ two
// over-correction guards that ride the same f2p function).
//
// The OCR detector over-segments a single line into a narrow LEFT box plus the
// real text box; the char layer assigns the glyphs to the real box, leaving the
// left box char-less. OCR-filling that left box re-reads the overlapping glyph
// and duplicates it (刑法's 妨妨). Such a char-less left box must be detected as
// covered by its same-line right neighbor and left empty (dropped by the
// trailing filter) instead of OCR-filled.
func TestCoveredLeftFragment_DroppedByBuildTextBoxes(t *testing.T) {
	ctx := context.Background()
	doc := fragStubAnalyzer{}

	frag := ocrDetectBox{
		box: pdftype.TextBox{X0: 220.7, X1: 239.3, Top: 2814.7, Bottom: 2825.0},
		x0:  220.7, y0: 2814.7, x1: 239.3, y1: 2825.0, srcIdx: 0,
	}
	cont := ocrDetectBox{
		box: pdftype.TextBox{X0: 234.7, X1: 456.3, Top: 2813.7, Bottom: 2826.0},
		x0:  234.7, y0: 2813.7, x1: 456.3, y1: 2826.0, srcIdx: 1,
	}

	// fail_to_pass: the covered left fragment must be dropped. Pre-fix it is
	// OCR-filled and both boxes survive (len == 2); post-fix only the container
	// survives (len == 1).
	t.Run("covered left fragment is dropped", func(t *testing.T) {
		p := &Parser{}
		boxes := []ocrDetectBox{frag, cont}
		// frag char-less (its stray glyph was deferred-then-dropped by the
		// height gate upstream); cont carries the real glyph via the char layer.
		boxChars := [][]pdftype.TextChar{
			{},
			{{Text: "妨", X0: 237.5, X1: 253.5, Top: 2814.0, Bottom: 2826.0}},
		}
		got := p.buildTextBoxes(ctx, newFragStubImage(), boxes, boxChars, doc, 3.0, 1)
		if len(got) != 1 {
			t.Fatalf("covered left fragment must be dropped: expected 1 text box, got %d (%+v)", len(got), got)
		}
		// The surviving box is the real container, not the narrow fragment.
		if got[0].X0 != cont.box.X0 || got[0].X1 != cont.box.X1 {
			t.Errorf("surviving box must be the right-hand container [%.1f,%.1f], got [%.1f,%.1f]",
				cont.box.X0, cont.box.X1, got[0].X0, got[0].X1)
		}
	})

	// over-correction guard (holds on both trees): a lone char-less box with NO
	// same-line right neighbor is a legitimate OCR target (e.g. a font-encoded
	// caption) and must STILL be OCR-filled, not dropped. A fix that drops any
	// char-less box would return 0 boxes here.
	t.Run("char-less box with no right neighbor is still OCR-filled", func(t *testing.T) {
		p := &Parser{}
		alone := ocrDetectBox{
			box: pdftype.TextBox{X0: 100, X1: 300, Top: 500, Bottom: 520},
			x0:  100, y0: 500, x1: 300, y1: 520, srcIdx: 0,
		}
		boxes := []ocrDetectBox{alone}
		boxChars := [][]pdftype.TextChar{{}}
		got := p.buildTextBoxes(ctx, newFragStubImage(), boxes, boxChars, doc, 3.0, 1)
		if len(got) != 1 {
			t.Fatalf("lone char-less box without a right neighbor must be OCR-filled: expected 1 box, got %d (%+v)", len(got), got)
		}
		if got[0].Text == "" {
			t.Errorf("OCR-filled box must carry recognized text, got empty")
		}
	})

	// over-correction guard (holds on both trees): a char-bearing right neighbor
	// on a DIFFERENT line (low Y-overlap) does not cover the fragment, so the
	// char-less box must STILL be OCR-filled -> both boxes survive (len == 2). A
	// fix that ignores the same-line requirement would drop the fragment here.
	t.Run("different-line right neighbor does not cover the fragment", func(t *testing.T) {
		p := &Parser{}
		otherLine := ocrDetectBox{
			box: pdftype.TextBox{X0: 234.7, X1: 456.3, Top: 2900, Bottom: 2920},
			x0:  234.7, y0: 2900, x1: 456.3, y1: 2920, srcIdx: 1,
		}
		boxes := []ocrDetectBox{frag, otherLine}
		boxChars := [][]pdftype.TextChar{
			{},
			{{Text: "妨", X0: 237.5, X1: 253.5, Top: 2905, Bottom: 2918}},
		}
		got := p.buildTextBoxes(ctx, newFragStubImage(), boxes, boxChars, doc, 3.0, 1)
		if len(got) != 2 {
			t.Fatalf("char-less box with only a different-line neighbor must be OCR-filled: expected 2 boxes, got %d (%+v)", len(got), got)
		}
	})
}
