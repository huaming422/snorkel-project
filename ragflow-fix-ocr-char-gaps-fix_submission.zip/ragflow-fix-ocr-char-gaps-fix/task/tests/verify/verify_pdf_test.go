// Staff-Bench behavioral verifier (package pdf) — char->box matching.
//
// Runs in-package so it can call the unexported matchCharsToBoxes directly (the
// glyph->detect-box assignment that decides whether a small inline glyph is
// kept or dropped). Both tests reference ONLY pre-existing symbols, so this
// file compiles on the pre-fix tree too — that is what lets the pass_to_pass
// guard below demonstrably hold on the no-op.
//
// NO cgo build tag: matchCharsToBoxes and ocrDetectBox live in parser_ocr.go,
// which carries no build constraint, so the file compiles and runs under
// CGO_ENABLED=0 with no native pdfium/pdfoxide bridge. Fixtures are hand-built
// structs; nothing renders a PDF.
//
// The covered-left-fragment drop is tested in a separate file
// (verify_fragment_test.go) through the pre-existing buildTextBoxes assembly
// stage — it keeps that file's OCR-fallback stub and image fixtures apart from
// this file's pure matchCharsToBoxes unit assertions.

package pdf

import (
	"testing"

	pdftype "ragflow/internal/deepdoc/parser/pdf/type"
)

// TestMatchCharsToBoxes_FullyContainedSmallOvershoot — fail_to_pass.
//
// A small glyph (h=8.1) whose top rises ~0.65pt above a tall box's edge has an
// overlap ratio of ~0.92 (NOT >= 0.95). It is still an inline glyph of that box
// (sub-point detection noise), so the deferred inline-glyph path must absorb
// it. Pre-fix the acceptance bound is 0.95, so the glyph is rejected and its
// character goes missing from the extracted text; post-fix (bound relaxed into
// the ~0.88..0.95 range) it is kept.
func TestMatchCharsToBoxes_FullyContainedSmallOvershoot(t *testing.T) {
	box := ocrDetectBox{
		box: pdftype.TextBox{X0: 70, X1: 763, Top: 494, Bottom: 528.7},
		x0:  70, y0: 494, x1: 763, y1: 528.7,
	}
	boxes := []ocrDetectBox{box}
	chars := []pdftype.TextChar{
		{Text: "在", X0: 100, X1: 112, Top: 500, Bottom: 512},       // normal, h=12
		{Text: "①", X0: 100, X1: 108, Top: 493.35, Bottom: 501.45}, // h=8.1, top 0.65pt above box -> overlap ~0.92
	}
	got := matchCharsToBoxes(boxes, chars)
	if len(got) != 1 {
		t.Fatalf("expected 1 box group, got %d", len(got))
	}
	found := false
	for _, c := range got[0] {
		if c.Text == "①" {
			found = true
		}
	}
	if !found {
		t.Errorf("small glyph with 0.92 overlap (0.6pt top overshoot) must be kept as inline content, got %+v", got[0])
	}
}

// TestMatchCharsToBoxes_PartialOverlapHeightFiltered — pass_to_pass guard.
//
// The dual of the case above: a char that only PARTIALLY overlaps its assigned
// box (overlap ~0.6, well below both 0.95 and any sane relaxed bound) and whose
// height differs from the box by >=70% is an adjacent-line glyph poking in, not
// inline content — it must STILL be dropped by the height gate. This holds pre-
// and post-fix; it proves a relaxed acceptance bound did not swallow genuine
// partial-overlap intruders (the cheap over-correction of just lowering the
// bound toward 0 is rejected here). Geometry transcribed verbatim from the
// repo's own TestMatchCharsToBoxes_PartialOverlapHeightFiltered.
func TestMatchCharsToBoxes_PartialOverlapHeightFiltered(t *testing.T) {
	box := ocrDetectBox{
		box: pdftype.TextBox{X0: 0, X1: 90, Top: 0, Bottom: 40},
		x0:  0, y0: 0, x1: 90, y1: 40,
	}
	boxes := []ocrDetectBox{box}
	// h=5 vs bh=40 -> ratio 0.875 >= 0.7; the char spans top=-2..3, so only
	// 3 of its 5pt vertically overlap the box (top 0..3) -> overlap 0.6, i.e.
	// NOT fully contained -> deferred path must not absorb it.
	chars := []pdftype.TextChar{
		{X0: 5, X1: 12, Top: -2, Bottom: 3, Text: "x"},
	}
	got := matchCharsToBoxes(boxes, chars)
	if len(got) != 1 {
		t.Fatalf("expected 1 box group, got %d", len(got))
	}
	if len(got[0]) != 0 {
		t.Errorf("partial-overlap height-mismatched glyph must be dropped by the height gate, got %+v", got[0])
	}
}
