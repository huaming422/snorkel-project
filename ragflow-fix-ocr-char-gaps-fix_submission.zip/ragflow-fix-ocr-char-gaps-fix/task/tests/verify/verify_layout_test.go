// Staff-Bench behavioral verifier (package layout).
//
// Runs in-package against the two exported layout-stage functions the change
// touches: AssignColumn (document-wide column-majority assignment) and
// DedupSubstringOverlaps (the substring-collapse pass, now column-aware and with
// a tightened top-overshoot containment test). Both are pure geometry over
// []pdf.TextBox and carry no build constraint, so this file compiles and runs
// under CGO_ENABLED=0. Every symbol referenced here (AssignColumn,
// DedupSubstringOverlaps, pdf.TextBox) pre-exists on both trees, so the file
// compiles on the no-op too; fail_to_pass separation here is by ASSERTION,
// not by compile.
//
// Fixtures and assertions for the AssignColumn / cross-column dedup tests are
// transcribed verbatim from the reference tests the change shipped with. The two
// top-overshoot containment tests at the end are authored here to cover the
// boxInsideTolerant height-match branch, which the PR exercised only through the
// (absent) parity-golden fixtures — see AP6 note in the reward summary.

package layout

import (
	"testing"

	pdf "ragflow/internal/deepdoc/parser/pdf/type"
)

// xingfaPage1Boxes reproduces an indent-heavy single-column page whose
// staggered x0 (footnote 80, body 111-119, indents 144/176/270) trips the
// per-page gap detector into 2 columns.
var xingfaPage1Boxes = [][4]float64{ // x0, top, x1, bottom
	{111.7, 955.0, 490.0, 1348.0},
	{113.3, 985.0, 489.0, 997.3},
	{119.7, 1012.0, 489.0, 1027.0},
	{113.3, 1043.0, 487.3, 1055.0},
	{113.3, 1071.0, 490.0, 1085.7},
	{115.3, 1100.7, 488.0, 1113.0},
	{112.7, 1128.7, 490.0, 1143.7},
	{111.7, 1156.0, 489.0, 1171.0},
	{113.3, 1187.7, 488.0, 1200.0},
	{112.7, 1216.7, 487.3, 1228.7},
	{111.7, 1243.7, 489.0, 1258.7},
	{119.7, 1273.7, 488.0, 1288.3},
	{113.3, 1302.3, 489.0, 1317.3},
	{111.7, 1329.7, 341.7, 1348.0},
	{270.3, 1389.3, 334.0, 1405.0},
	{113.3, 1418.3, 205.7, 1433.0},
	{144.3, 1447.3, 441.3, 1462.0},
	{144.3, 1476.0, 236.7, 1491.0},
	{176.3, 1505.0, 347.3, 1520.0},
	{79.7, 1547.3, 521.0, 1583.0},
	{80.7, 1568.3, 324.3, 1583.0},
}

func makeBoxes(coords [][4]float64, page int) []pdf.TextBox {
	out := make([]pdf.TextBox, len(coords))
	for i, r := range coords {
		out[i] = pdf.TextBox{
			X0: r[0], Top: r[1], X1: r[2], Bottom: r[3],
			PageNumber: page, LayoutType: pdf.LayoutTypeText,
		}
	}
	return out
}

// TestAssignColumnSingleColumnMajority — fail_to_pass.
//
// Locks the document-wide column-majority rule: when most pages read as a
// single column, EVERY page is assigned ColID 0 — even an indent-heavy page
// whose staggered x0 would trip the per-page gap detector into 2 columns.
// Pre-fix the per-page detector tags that page as multi-column and the reading
// order scrambles.
func TestAssignColumnSingleColumnMajority(t *testing.T) {
	var boxes []pdf.TextBox
	boxes = append(boxes, makeBoxes(xingfaPage1Boxes, 0)...) // indent page -> per-page k>=2
	for pg := 1; pg <= 2; pg++ {
		for i := 0; i < 8; i++ {
			boxes = append(boxes, pdf.TextBox{
				X0: 100, Top: float64(50 + 14*i), X1: 400, Bottom: float64(62 + 14*i),
				PageNumber: pg, LayoutType: pdf.LayoutTypeText,
			})
		}
	}
	out := AssignColumn(boxes)
	for i, b := range out {
		if b.ColID != 0 {
			t.Fatalf("box %d (page %d) ColID=%d, want 0 (single-column majority)", i, b.PageNumber, b.ColID)
		}
	}
}

// TestAssignColumnTieFirstPageWins — pass_to_pass guard.
//
// Locks the majority tie-break: with one two-column page and one single-column
// page the count ties, and the first-seen column count wins (the two-column
// page appears first) — so the two-column split is kept. Guards against an
// over-correction that collapses to single-column whenever any single-column
// page exists.
func TestAssignColumnTieFirstPageWins(t *testing.T) {
	var boxes []pdf.TextBox
	// page 0: genuine two columns
	for i := 0; i < 4; i++ {
		top := float64(50 + 30*i)
		boxes = append(boxes,
			pdf.TextBox{X0: 50, Top: top, X1: 250, Bottom: top + 20, PageNumber: 0, LayoutType: pdf.LayoutTypeText},
			pdf.TextBox{X0: 300, Top: top, X1: 500, Bottom: top + 20, PageNumber: 0, LayoutType: pdf.LayoutTypeText},
		)
	}
	// page 1: single column
	for i := 0; i < 4; i++ {
		top := float64(50 + 14*i)
		boxes = append(boxes, pdf.TextBox{X0: 100, Top: top, X1: 400, Bottom: top + 12, PageNumber: 1, LayoutType: pdf.LayoutTypeText})
	}
	out := AssignColumn(boxes)
	colSeen := map[int]bool{}
	for _, b := range out {
		if b.PageNumber == 0 {
			colSeen[b.ColID] = true
		}
	}
	if len(colSeen) < 2 {
		t.Fatalf("tie must keep the first-seen two-column split, got page0 ColIDs %v", colSeen)
	}
}

// TestAssignColumnMultiColumnMajorityKeepsSplit — pass_to_pass guard.
//
// Locks that a document whose majority of pages are genuinely two-column keeps
// the per-page split: the majority rule must NOT collapse a real multi-column
// document to one. Guards against the bluntest over-correction (force every
// document to single-column).
func TestAssignColumnMultiColumnMajorityKeepsSplit(t *testing.T) {
	// Genuine two-column pages: left column x0=50, right column x0=300.
	var boxes []pdf.TextBox
	for pg := 0; pg < 3; pg++ {
		for i := 0; i < 5; i++ {
			top := float64(50 + 30*i)
			boxes = append(boxes,
				pdf.TextBox{X0: 50, Top: top, X1: 250, Bottom: top + 20, PageNumber: pg, LayoutType: pdf.LayoutTypeText},
				pdf.TextBox{X0: 300, Top: top, X1: 500, Bottom: top + 20, PageNumber: pg, LayoutType: pdf.LayoutTypeText},
			)
		}
	}
	out := AssignColumn(boxes)
	colSeen := map[int]bool{}
	for _, b := range out {
		colSeen[b.ColID] = true
	}
	if len(colSeen) < 2 {
		t.Fatalf("multi-column majority document must keep two columns, got ColIDs %v", colSeen)
	}
}

// TestDedupSubstringOverlaps_CrossColumnKept — fail_to_pass.
//
// A substring box in a DIFFERENT column from the containing box is kept even
// when its geometry is fully inside the container. On a two-column page the OCR
// detector often draws a wide right-column paragraph box whose X span reaches
// across the gutter into the left column, so a left-column short line whose
// text happens to be a substring of that paragraph is geometrically "inside"
// it. It is independent document text, not an OCR duplicate. Pre-fix the
// column guard is absent and the left-column line is collapsed (content lost).
func TestDedupSubstringOverlaps_CrossColumnKept(t *testing.T) {
	rightCol := pdf.TextBox{
		Text:       "出血，尤其是心脏病患者，术中应密切监测血氧饱和度并备好抢救药物如沙丁胺醇",
		PageNumber: 0, Top: 100, Bottom: 400, X0: 40, X1: 600, ColID: 1, IsOCR: true, // wide OCR box spanning both columns
	}
	leftLine := pdf.TextBox{
		Text:       "出血，尤其是心脏病患者",                                                    // left-column short line, IS a substring of rightCol text
		PageNumber: 0, Top: 150, Bottom: 165, X0: 50, X1: 280, ColID: 0, IsOCR: true, // inside rightCol geometry
	}
	got := DedupSubstringOverlaps([]pdf.TextBox{rightCol, leftLine})
	if len(got) != 2 {
		t.Fatalf("cross-column substring must be kept (different ColID), got %d boxes", len(got))
	}
}

// TestDedupSubstringOverlaps_SameColumnStillCollapses — pass_to_pass guard.
//
// Moving the column guard must NOT weaken same-column dedup: two boxes in the
// SAME column (identical ColID) with substring text and containment geometry
// are still collapsed. This is the real OCR double-detection case. Guards
// against an over-correction that disables substring dedup wholesale.
func TestDedupSubstringOverlaps_SameColumnStillCollapses(t *testing.T) {
	outer := pdf.TextBox{
		Text:       "用Python生成的分词1为：文章中提到了哪些健康服务体系?",
		PageNumber: 0, Top: 100, Bottom: 400, X0: 60, X1: 520, ColID: 1, IsOCR: true,
	}
	inner := pdf.TextBox{
		Text:       "文章中提到了哪些健康服务体系", // substring, same column
		PageNumber: 0, Top: 150, Bottom: 165, X0: 60, X1: 520, ColID: 1, IsOCR: true,
	}
	got := DedupSubstringOverlaps([]pdf.TextBox{outer, inner})
	if len(got) != 1 {
		t.Fatalf("same-column substring must still collapse, got %d boxes", len(got))
	}
	if got[0].Text != outer.Text {
		t.Fatalf("outer must be kept, got %q", got[0].Text)
	}
}

// NOTE on the production pipeline reorder (parser.go buildLayout: AssignColumn
// moved BEFORE dedup) and criterion #4 ("the fixes compose"): the reorder IS
// observable offline, but NOT at this per-stage seam. These layout tests call
// AssignColumn / DedupSubstringOverlaps directly and set ColID explicitly, so
// they cannot see whether an agent ran column assignment before or after dedup
// in the real pipeline. The reference PR's
// TestDedupSubstringOverlaps_AssignColumnFirst was deliberately NOT transcribed
// here: at the fabricated-struct seam with hand-set ColID, AssignColumn assigns
// the gutter-spanning wide box the SAME ColID as the left lines, so the
// cross-column guard never engages and that test passes identically on the
// no-op and the fixed tree (verified by hand): a fail_to_pass that would not
// separate the two trees. The reorder is instead covered by a dedicated
// compose verifier, TestBuildLayout_CrossColumnComposeSurvives in
// verify_compose_test.go, which
// drives the REAL (*Parser).buildLayout pipeline (pure Go, runs offline under
// CGO_ENABLED=0 — the cgo pdfium/pdf_oxide bridges are only the char/engine
// front-end, not buildLayout). That test fails unless BOTH the cross-column
// guard exists AND column assignment precedes dedup (verified: guard-present
// but assign-after-dedup still drops the line). The per-stage column-guard
// logic itself is additionally covered by TestDedupSubstringOverlaps_CrossColumnKept
// (f2p) + _SameColumnStillCollapses (p2p) above.

// TestDedupSubstringOverlaps_TopOvershootDifferentHeightKept — fail_to_pass.
//
// Covers the tightened top-overshoot containment test (boxInsideTolerant). A
// substring box whose TOP pokes a sub-tolerance amount (2pt) above the
// container but whose HEIGHT differs sharply (14 vs 40) is an ADJACENT line
// that merely overlaps the container's Y band, not a same-line double-detection
// fragment — it must be KEPT. Pre-fix boxInsideTolerant tolerates any top
// overshoot within dedupYTolerancePt regardless of height, so this independent
// line is wrongly collapsed (content lost). Post-fix the top-overshoot branch
// additionally requires the two heights to match within tolerance, so the
// mismatched line survives. Same ColID (default 0) isolates this from the
// cross-column guard.
func TestDedupSubstringOverlaps_TopOvershootDifferentHeightKept(t *testing.T) {
	container := pdf.TextBox{
		Text:       "第四节麻醉管理要点与注意事项", // height 40
		PageNumber: 0, Top: 100, Bottom: 140, X0: 60, X1: 520, IsOCR: true,
	}
	adjacentLine := pdf.TextBox{
		Text:       "麻醉管理", // substring of container; height 14, top overshoot 2pt
		PageNumber: 0, Top: 98, Bottom: 112, X0: 70, X1: 300, IsOCR: true,
	}
	got := DedupSubstringOverlaps([]pdf.TextBox{container, adjacentLine})
	if len(got) != 2 {
		t.Fatalf("top-overshoot line with mismatched height must be kept (adjacent line, not a fragment), got %d boxes", len(got))
	}
}

// TestDedupSubstringOverlaps_TopOvershootSameHeightCollapsed — pass_to_pass guard.
//
// The dual of the case above: a substring box whose top overshoots the
// container by a sub-tolerance amount (2pt) AND whose height matches the
// container within tolerance (41 vs 40) IS a same-line OCR double-detection
// fragment and must STILL collapse — on both trees. Guards against an
// over-correction that rejects every top overshoot unconditionally (which would
// re-leak the Rag Flow Usage / 三国人物 duplicate text the tolerance exists to
// absorb). Same ColID (default 0) keeps this out of the cross-column guard.
func TestDedupSubstringOverlaps_TopOvershootSameHeightCollapsed(t *testing.T) {
	container := pdf.TextBox{
		Text:       "三国人物关系总览表格", // height 40
		PageNumber: 0, Top: 100, Bottom: 140, X0: 60, X1: 520, IsOCR: true,
	}
	fragment := pdf.TextBox{
		Text:       "三国人物", // substring; height 41, top overshoot 2pt, same line
		PageNumber: 0, Top: 98, Bottom: 139, X0: 70, X1: 300, IsOCR: true,
	}
	got := DedupSubstringOverlaps([]pdf.TextBox{container, fragment})
	if len(got) != 1 {
		t.Fatalf("same-line top-overshoot fragment with matching height must still collapse, got %d boxes", len(got))
	}
	if got[0].Text != container.Text {
		t.Fatalf("container must be kept, got %q", got[0].Text)
	}
}
