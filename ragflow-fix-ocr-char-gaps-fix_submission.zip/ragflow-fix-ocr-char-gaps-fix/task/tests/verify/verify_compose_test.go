// Staff-Bench behavioral verifier (package pdf) — compose: column + dedup order.
//
// This is the "the fixes COMPOSE" fail_to_pass. It exercises the REAL layout
// pipeline entry point `(*Parser).buildLayout`, which runs the global
// text-assembly sequence (column assignment, substring-overlap dedup, text
// merge, reading-order merge, sections) in the order the implementation
// chooses. Testing through it — rather than calling the individual stage
// functions with hand-set ColID — is what makes this verifier sensitive to the
// STAGE ORDERING, not just to the per-stage logic.
//
// Why ordering matters (the fourth, interaction root cause): the cross-column
// dedup guard keys on a box's column id. If column assignment runs AFTER dedup,
// every box still carries the zero-value column id when dedup compares them, so
// the "different column -> keep" guard can never fire and a legitimate
// different-column line is still collapsed into a wide cross-gutter OCR box that
// merely contains its text as a substring. An agent who adds the column guard
// but leaves column assignment after dedup therefore still drops the line — and
// this verifier still fails for them. Only when BOTH the guard exists AND column
// assignment precedes dedup does the line survive. (Verified on both trees: the
// line survives only with guard-present AND assign-before-dedup; guard-present
// but assign-after-dedup still drops it.)
//
// Fixture: a two-column page. The left column has six lines; the right column
// has six lines, one of which ("ABC") is geometrically covered by a full-width
// cross-gutter OCR box whose text ("xxABCyy") contains "ABC" as a substring. The
// wide box falls in the LEFT column; the covered line is in the RIGHT column.
//   pre-fix : the right-column line is collapsed into the wide box -> "ABC"
//             appears once in the emitted text (inside the wide box only).
//   post-fix: column-before-dedup + same-column guard spare the right-column
//             line -> "ABC" appears twice (its own line + inside the wide box).
//
// No fix-introduced symbol is named; buildLayout, and every stage it drives,
// pre-exist on both trees. NO cgo build tag: the whole layout/table pipeline is
// pure Go, so this runs under CGO_ENABLED=0 (no pdfium/pdf_oxide bridge). The
// assertion is an observable text-occurrence count, so any valid fix shape (a
// different column-resolution data flow, a differently named guard) passes as
// long as the two columns resolve and the guard spares the cross-column line.

package pdf

import (
	"context"
	"strings"
	"testing"

	pdftype "ragflow/internal/deepdoc/parser/pdf/type"
)

// composeCrossColumnBoxes builds the two-column fixture described above.
func composeCrossColumnBoxes() []pdftype.TextBox {
	var b []pdftype.TextBox
	y := 100.0
	for i := 0; i < 6; i++ {
		// Left column (x0 ~60).
		b = append(b, pdftype.TextBox{X0: 60, X1: 280, Top: y, Bottom: y + 12, Text: "leftx", PageNumber: 1, IsOCR: true})
		// Right column (x0 ~410); one line is the covered "ABC".
		rt := "rite"
		if i == 2 {
			rt = "ABC"
		}
		b = append(b, pdftype.TextBox{X0: 410, X1: 640, Top: y, Bottom: y + 12, Text: rt, PageNumber: 1, IsOCR: true})
		y += 20
	}
	// Full-width cross-gutter OCR box over the "ABC" line's Y band; its text
	// contains "ABC" and it geometrically covers the right-column line. Its x0
	// lands in the LEFT column, so after column assignment it differs in column
	// from the right-column "ABC" line.
	b = append(b, pdftype.TextBox{X0: 58, X1: 650, Top: 138, Bottom: 154, Text: "xxABCyy", PageNumber: 1, IsOCR: true})
	return b
}

// TestBuildLayout_CrossColumnComposeSurvives — fail_to_pass (compose).
//
// A different-column line whose text is a substring of a wide cross-gutter OCR
// box must survive the layout pipeline. It only survives when column assignment
// runs before substring-overlap dedup AND dedup is guarded on same-column
// containment — i.e. when the matching/dedup/column fixes compose. Pre-fix the
// line is dropped (one "ABC"); post-fix it is kept (two "ABC").
func TestBuildLayout_CrossColumnComposeSurvives(t *testing.T) {
	p := &Parser{}
	res := &pdftype.ParseResult{
		PageHeight: map[int]float64{1: 1000},
		PageWidth:  map[int]float64{1: 700},
	}
	medianHeights := map[int]float64{1: 12}
	medianWidths := map[int]float64{1: 200}

	err := p.buildLayout(context.Background(), res, composeCrossColumnBoxes(), nil,
		medianHeights, medianWidths, map[int]bool{1: false})
	if err != nil {
		t.Fatalf("buildLayout returned error: %v", err)
	}

	var sb strings.Builder
	for _, s := range res.Sections {
		sb.WriteString(s.Text)
		sb.WriteString("\n")
	}
	got := strings.Count(sb.String(), "ABC")

	// Pre-fix: the cross-column line is collapsed into the wide box -> 1.
	// Post-fix: column-before-dedup + same-column guard keep it -> 2.
	if got < 2 {
		t.Errorf("cross-column line covered by a wide same-text OCR box must survive the layout pipeline: "+
			"expected \"ABC\" to appear at least twice (its own line + the wide box), got %d occurrence(s).\n"+
			"emitted sections:\n%s", got, sb.String())
	}
}
