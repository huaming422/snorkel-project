## Task

We want to standardize when Lexical notifies selection changes. Today `SELECTION_CHANGE_COMMAND` is driven off the browser's native `selectionchange` events, which get coalesced or suppressed, so genuine changes are sometimes missed. Drive it off the pending editor state instead: one notification per genuine selection change, dispatched before the DOM is reconciled, the same for native, programmatic, and non-range selections.

Since the command would now run before reconciliation, the DOM a listener sees may still reflect the previous state: layout and the DOM selection stale, a newly inserted node not yet having an element. DOM-dependent work in a listener should defer with `$onUpdate` and read the settled result back through `editor.read(...)`.

The `@lexical/table` plugin reads DOM and observer state while handling this command, so that work needs to move to after reconciliation.

Scope is the update and commit pipeline, native event handling, the command contract, and per-editor state in `packages/lexical/src`, plus selection helpers and plugin registration in `packages/lexical-table/src`. Leave the playground and other consumers alone, and keep dependency versions as they are. Exercised by the jsdom unit project (`pnpm run test-unit`).

## User stories / requirements

- When a programmatic selection change happens without any native selection event arriving (such as deleting inside a text node), the selection command still fires exactly once, before the DOM is reconciled. Inside the listener `$getSelection()` reflects the pending selection and `$getPreviousSelection()` the last committed one.
- Re-applying the same selection, or running a batched update whose net selection does not change, fires no extra selection notification. Native dirty-selection notifications are still delivered as before.
- When a listener reacts to a selection change by editing nodes, those edits and their transforms land in the same commit as the triggering update, reconciled together in one pass, while the previously committed state still reads the old content.
- When a selection listener keeps changing the selection so it never settles, the editor still converges: the user's pending edit is committed and the runaway condition is surfaced through the editor's warn hook rather than rolling the edit back.
- While the editor is headless or its root is detached, automatic range and null selection notifications are skipped, and a change made during that time is not replayed once the root reconnects. Non-range selection changes still notify.
- A table and its cells created and selected in the same update highlight correctly as a table selection, with the DOM-dependent sync running after reconciliation. The selection-command handler holds a stable priority across root detach and re-attach and is cleaned up when the root is removed.
- When a real browser selection change arrives (the native `selectionchange` event that used to drive the command), a genuine selection move still notifies exactly once. Firing that same native event again while the selection has not actually moved does not notify a second time.
