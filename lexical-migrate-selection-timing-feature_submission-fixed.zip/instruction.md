## Task

We hooked SELECTION_CHANGE_COMMAND in the toolbar and it misses updates when deleting text, and the notifications that do arrive come at different moments.

The command's documentation should tell listener authors when it fires, what the current and previous selection reads return while a listener runs, and how to read the updated DOM afterward; playground changes aren't needed.

Touch selection in tables already works and should stay as it is: a drag across cells produces a table selection once the finger leaves the first cell, and a drag that stays inside one cell stays a range selection.

## User stories / requirements

- When code changes the selection, for example when selected text is deleted, listeners are notified exactly once, before the DOM shows the change. While they run, $getSelection() already returns the new selection and $getPreviousSelection() still returns the old one.
- Moving the selection twice in one batch of updates notifies once, with the final selection. Moving it away and back in one batch does not notify, and applying the same selection again does not notify either.
- If a listener edits the document when the selection changes, that edit and the node transforms it sets off are applied together with the selection change: update listeners run once and the DOM shows the final text, while the editor state from before the change still holds the old text.
- When a listener moves the selection on every notification, the editor's warn hook gets a warning during an edit, and even if that hook throws, the edit is applied and shown and the error hook is not called. Once that listener is removed, the next selection change notifies once, with no new warning.
- In a headless editor, or one whose root is missing or not in the page, setting, moving or clearing a range selection notifies no listener, then or after a root in the page is set. Setting a node selection there notifies, with $getPreviousSelection() returning the old selection, and dispatching the command directly reaches listeners.
- Creating a table and selecting across its cells in one update gives a table selection, with those cells shown as selected after the update, and selection listeners the app registers see it; this still holds after the root is unset and set again. With no root, the selection across cells stays a range selection.
- When the browser reports a selection move through its native selectionchange event, listeners are notified once and see the moved selection, even if the same event arrives again before the selection moves further.
