#!/usr/bin/env bash
# test-setup.sh — environment bootstrap for the verifier.
# Sourced (not exec'd) by the harbor verifier runner so env vars and
# anything else stay alive for vitest.
#
# Idempotent. The Dockerfile already runs `pnpm install --frozen-lockfile`
# at the base commit, so node_modules is present and the pnpm store is warm.
# Lexical's vitest config resolves monorepo imports to TypeScript source via
# tsconfig.test.json `paths` (no per-package dist build is required for the
# unit project), so the only guard needed here is re-materializing deps if an
# agent erased node_modules.

set -e

REPO_DIR="${REPO_DIR:-/repo/lexical}"
cd "$REPO_DIR"

node --version
pnpm --version
pnpm config set store-dir /opt/cache/pnpm

# Re-install workspace deps only if an agent erased them. Offline-first using
# the warm store baked into the image; fall back to the network (verifier phase
# has it) if the store is cold.
if [ ! -d "node_modules/.pnpm" ]; then
    echo "[test-setup] node_modules missing; reinstalling (offline-first)..."
    if ! pnpm install --frozen-lockfile --offline > /tmp/pnpm-install.log 2>&1; then
        echo "[test-setup] offline install failed; retrying online..." >&2
        pnpm install --frozen-lockfile > /tmp/pnpm-install.log 2>&1 || { tail -80 /tmp/pnpm-install.log; exit 1; }
    fi
fi

export PATH="$REPO_DIR/node_modules/.bin:$PATH"

echo "[test-setup] ready: $REPO_DIR (node=$(node --version), pnpm=$(pnpm --version))"
