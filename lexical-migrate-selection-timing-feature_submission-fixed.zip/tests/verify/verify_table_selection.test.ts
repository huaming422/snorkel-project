/**
 * Table selection checks.
 *
 * A table created and selected across cells in one update ends up as a table
 * selection, with exactly the selected cells carrying the theme's
 * selected-cell class in the DOM once the update is done.
 *
 * A touch drag across cells produces a table selection once the finger leaves
 * the first cell, and a drag that stays inside one cell stays a range
 * selection. The gestures mirror the
 * repo's own LexicalTableMobileSelection unit tests: jsdom has no layout, so
 * elementsFromPoint is stubbed, and the caret a touch device moves is
 * simulated with a selection update plus the command the browser path would
 * deliver.
 */
import {buildEditorFromExtensions} from '@lexical/extension';
import {
  $computeTableMapSkipCellCheck,
  $createTableNodeWithDimensions,
  $isTableRowNode,
  $isTableSelection,
  TableExtension,
} from '@lexical/table';
import {
  $createRangeSelection,
  $getNodeByKey,
  $getRoot,
  $getSelection,
  $isRangeSelection,
  $setSelection,
  defineExtension,
  type ElementNode,
  SELECTION_CHANGE_COMMAND,
} from 'lexical';
import {afterEach, beforeEach, describe, expect, test} from 'vitest';

const SELECTED_CELL_CLASS = 'verify-selected-cell';

function buildTableEditor(name: string) {
  return buildEditorFromExtensions(
    defineExtension({
      dependencies: [TableExtension],
      name,
      theme: {
        tableCellSelected: SELECTED_CELL_CLASS,
        tableScrollableWrapper: '',
      },
    }),
  );
}

describe('table created and selected in one update', () => {
  type Cell = [row: number, column: number];

  /**
   * Creates a rows x columns table and selects from the anchor cell to the
   * focus cell in the same discrete update, then reports the model selection
   * and which cells (as "row,column") carry the selected-cell class.
   */
  function createAndSelect(
    rows: number,
    columns: number,
    anchorCell: Cell,
    focusCell: Cell,
  ) {
    const editor = buildTableEditor('verify-same-update-table');
    const root = document.createElement('div');
    root.contentEditable = 'true';
    document.body.appendChild(root);
    editor.setRootElement(root);
    const keys = {anchor: '', focus: ''};
    const positionByKey = new Map<string, string>();
    let error = 'none';
    try {
      editor.update(
        () => {
          const table = $createTableNodeWithDimensions(rows, columns, false);
          $getRoot().clear().append(table);
          const [map] = $computeTableMapSkipCellCheck(table, null, null);
          map.forEach((row, r) =>
            row.forEach((value, c) =>
              positionByKey.set(value.cell.getKey(), `${r},${c}`),
            ),
          );
          keys.anchor = map[anchorCell[0]][anchorCell[1]].cell.getKey();
          keys.focus = map[focusCell[0]][focusCell[1]].cell.getKey();
          const selection = $createRangeSelection();
          selection.anchor.set(keys.anchor, 0, 'element');
          selection.focus.set(keys.focus, 0, 'element');
          $setSelection(selection);
        },
        {discrete: true},
      );
    } catch (e) {
      error = e instanceof Error ? e.message : String(e);
    }
    const result = editor.read(() => {
      const selection = $getSelection();
      return {
        anchor: $isTableSelection(selection) ? selection.anchor.key : null,
        error,
        focus: $isTableSelection(selection) ? selection.focus.key : null,
        isTableSelection: $isTableSelection(selection),
      };
    });
    const highlighted: string[] = [];
    for (const [key, position] of positionByKey) {
      const element = editor.getElementByKey(key);
      if (element !== null && element.classList.contains(SELECTED_CELL_CLASS)) {
        highlighted.push(position);
      }
    }
    editor.dispose();
    root.remove();
    return {highlighted: highlighted.sort(), keys, result};
  }

  test('verify_same_update_one_by_two_table_highlights_both_cells', () => {
    const {highlighted, keys, result} = createAndSelect(1, 2, [0, 0], [0, 1]);
    expect(result).toEqual({
      anchor: keys.anchor,
      error: 'none',
      focus: keys.focus,
      isTableSelection: true,
    });
    expect(highlighted).toEqual(['0,0', '0,1']);
  });

  test('verify_same_update_two_by_three_table_highlights_only_selected_cells', () => {
    const {highlighted, keys, result} = createAndSelect(2, 3, [0, 0], [0, 1]);
    expect(result).toEqual({
      anchor: keys.anchor,
      error: 'none',
      focus: keys.focus,
      isTableSelection: true,
    });
    expect(highlighted).toEqual(['0,0', '0,1']);
  });

  test('verify_same_update_reversed_two_by_two_block_highlights_four_cells', () => {
    const {highlighted, keys, result} = createAndSelect(3, 3, [1, 1], [0, 0]);
    expect(result).toEqual({
      anchor: keys.anchor,
      error: 'none',
      focus: keys.focus,
      isTableSelection: true,
    });
    expect(highlighted).toEqual(['0,0', '0,1', '1,0', '1,1']);
  });
});

describe('touch selection in tables keeps working', () => {
  const COLUMNS = 3;
  const ROWS = 3;
  const CELL_WIDTH = 100;
  const CELL_HEIGHT = 40;
  const DRAG_DISTANCE = 50;

  const hadElementsFromPoint = 'elementsFromPoint' in document;
  const originalElementsFromPoint = document.elementsFromPoint;

  let editor: ReturnType<typeof buildTableEditor>;
  let container: HTMLDivElement;
  let cells: HTMLTableCellElement[];
  let keys: string[];
  let cellUnderPointer: Element | null;

  beforeEach(() => {
    container = document.createElement('div');
    document.body.appendChild(container);
    editor = buildTableEditor('verify-touch-table');
    editor.setRootElement(container);
    keys = [];
    editor.update(
      () => {
        const tableNode = $createTableNodeWithDimensions(ROWS, COLUMNS, false);
        $getRoot().clear().append(tableNode);
        for (const rowNode of tableNode.getChildren()) {
          if ($isTableRowNode(rowNode)) {
            for (const cellNode of rowNode.getChildren()) {
              keys.push(cellNode.getKey());
            }
          }
        }
      },
      {discrete: true},
    );
    cells = Array.from(container.querySelectorAll('td'));
    expect(cells).toHaveLength(ROWS * COLUMNS);
    cellUnderPointer = null;
    document.elementsFromPoint = () =>
      cellUnderPointer === null ? [] : [cellUnderPointer];
  });

  afterEach(() => {
    editor.dispose();
    container.remove();
    if (hadElementsFromPoint) {
      document.elementsFromPoint = originalElementsFromPoint;
    } else {
      delete (document as Partial<Document>).elementsFromPoint;
    }
  });

  function centerOf(index: number) {
    return {
      clientX: (index % COLUMNS) * CELL_WIDTH + CELL_WIDTH / 2,
      clientY: Math.floor(index / COLUMNS) * CELL_HEIGHT + CELL_HEIGHT / 2,
    };
  }

  function dispatchPointerEvent(
    cell: Element,
    type: string,
    options: PointerEventInit,
  ) {
    cell.dispatchEvent(
      new PointerEvent(type, {
        bubbles: true,
        button: 0,
        buttons: 1,
        cancelable: true,
        pointerId: 1,
        pointerType: 'touch',
        ...options,
      }),
    );
  }

  function touchDown(index: number) {
    cellUnderPointer = cells[index];
    dispatchPointerEvent(cells[index], 'pointerdown', centerOf(index));
  }

  function touchMove(fromIndex: number, overIndex: number, dx: number) {
    cellUnderPointer = cells[overIndex];
    const from = centerOf(fromIndex);
    dispatchPointerEvent(cells[overIndex], 'pointermove', {
      clientX: from.clientX + dx,
      clientY: from.clientY,
    });
  }

  function touchUp(index: number) {
    dispatchPointerEvent(cells[index], 'pointerup', {
      buttons: 0,
      ...centerOf(index),
    });
  }

  function moveCaretTo(index: number) {
    editor.update(
      () => {
        const cellNode = $getNodeByKey<ElementNode>(keys[index]);
        expect(cellNode).not.toBe(null);
        cellNode!.selectStart();
        editor.dispatchCommand(SELECTION_CHANGE_COMMAND, undefined);
      },
      {discrete: true},
    );
  }

  function selectionSummary() {
    return editor.read(() => {
      const selection = $getSelection();
      return $isTableSelection(selection)
        ? {
            anchor: keys.indexOf(selection.anchor.getNode().getKey()),
            focus: keys.indexOf(selection.focus.getNode().getKey()),
            kind: 'table',
          }
        : {kind: $isRangeSelection(selection) ? 'range' : 'other'};
    });
  }

  test('verify_touch_drag_across_cells_selects_cells', () => {
    touchDown(0);
    touchMove(0, 1, DRAG_DISTANCE);
    touchUp(1);
    expect(selectionSummary()).toEqual({anchor: 0, focus: 1, kind: 'table'});
  });

  test('verify_touch_drag_inside_one_cell_does_not_select_cells', () => {
    moveCaretTo(0);
    touchDown(4);
    touchMove(4, 4, DRAG_DISTANCE);
    moveCaretTo(4);
    touchUp(4);
    expect(selectionSummary()).toEqual({kind: 'range'});
  });

  test('verify_touch_drag_leaving_its_cell_with_moving_caret_selects_cells', () => {
    moveCaretTo(0);
    touchDown(0);
    touchMove(0, 1, DRAG_DISTANCE);
    moveCaretTo(1);
    expect(selectionSummary().kind).toBe('table');
  });
});
