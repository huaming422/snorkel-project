#!/usr/bin/env bash
# validation-setup.sh — environment bootstrap for the validation story
# scripts. Idempotent guard against agent edits that erased node_modules.
#
# Lexical's vitest `unit` project resolves monorepo imports to TypeScript
# source via tsconfig.test.json `paths` + the workspace `dev-source` resolve
# condition (active when vitest runs from the repo root), so NO per-package
# dist build is required for the unit project. The only guard needed here is
# re-materializing deps if an agent erased node_modules.

set -e

REPO_DIR="${REPO_DIR:-/repo/lexical}"
cd "$REPO_DIR"

# Sanity: Node + pnpm + vitest are reachable (loud failure if not).
node --version
pnpm --version
pnpm config set store-dir /opt/cache/pnpm
npx vitest --version

# Re-install workspace deps only if an agent erased them. Offline-first using
# the warm store baked into the image; fall back to the network (validation
# phase has it) if the store is cold.
if [ ! -d "node_modules/.pnpm" ]; then
    echo "[validation-setup] node_modules missing; reinstalling (offline-first)..."
    if ! pnpm install --frozen-lockfile --offline > /tmp/pnpm-install.log 2>&1; then
        echo "[validation-setup] offline install failed; retrying online..." >&2
        pnpm install --frozen-lockfile > /tmp/pnpm-install.log 2>&1 || { tail -80 /tmp/pnpm-install.log; exit 1; }
    fi
fi

export PATH="$REPO_DIR/node_modules/.bin:$PATH"

# Loud smoke guard: confirm the vitest `unit` project exists and that the
# TypeScript sources the stories import are present (resolved via dev-source /
# tsconfig paths, so the .ts files themselves must be on disk — no dist).
node -e '
const fs = require("fs");
const path = require("path");
const repoDir = process.env.REPO_DIR || "/repo/lexical";
const required = [
  "packages/lexical/src/index.ts",
  "packages/lexical-extension/src/index.ts",
  "packages/lexical-table/src/index.ts",
  "packages/lexical/src/__tests__/unit",
  "packages/lexical-table/src/__tests__/unit",
  "tsconfig.test.json",
];
const missing = required.filter((p) => !fs.existsSync(path.join(repoDir, p)));
if (missing.length > 0) {
  console.error("[validation-setup] Missing required sources:", missing.join(", "));
  process.exit(1);
}
console.log("[validation-setup] source tree OK (lexical, extension, table, unit projects)");
'

echo "[validation-setup] ready: $REPO_DIR (node=$(node --version), pnpm=$(pnpm --version))"
