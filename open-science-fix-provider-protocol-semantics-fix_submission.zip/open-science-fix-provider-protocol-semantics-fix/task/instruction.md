## Task

Lots of reports lately about the provider compatibility bridges, the local adapters that translate requests and responses between the LLM vendor API dialects. This used to work; several distinct things in that layer started misbehaving recently.

What people are seeing:

- Images in a tool result never reach the model; they arrive as text or vanish.
- Replies the vendor cut short, by a limit or a filter, come back looking like they finished normally.
- Usage accounting is off: cached input is undercounted, and usage sometimes goes missing from a streamed response that asked for it.
- When the model fires several tool calls at once, their order and identity get scrambled, and malformed arguments get quietly swapped for empty ones instead of raising an error.
- Streaming tool-call events spanning multiple lines lose track of which tool they belong to, and some good requests get altered on the way out, legitimate fields stripped.

It all reproduces locally against a stubbed upstream, no network needed. Find the root causes and fix them together, without disabling any conversion path.
