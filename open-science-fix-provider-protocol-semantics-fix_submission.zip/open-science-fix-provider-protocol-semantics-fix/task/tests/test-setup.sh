#!/usr/bin/env bash
# Environment bootstrap for the verifier. Sourced (not exec'd) so env
# vars set here stay live for the verifier subprocess.

set -e
set -o pipefail

REPO_DIR="${REPO_DIR:-/repo/open-science}"
export REPO_DIR
cd "$REPO_DIR"

# js.py reads verify.toml via tomllib (Python 3.11+) or tomli (3.10). The
# verifier runs under VERIFIER_PYTHON (/opt/tooling/venv, 3.12) which has
# tomllib, but if an older system python is ever selected, verify.toml would be
# silently dropped and the runner would fall back to its jest default (which
# fails on a vitest repo). Install tomli defensively — this runs with network.
if ! python3 -c "import tomllib" >/dev/null 2>&1 && \
   ! python3 -c "import tomli"   >/dev/null 2>&1; then
    {
        python3 -m pip install --quiet "tomli==2.0.1" \
            || python3 -m pip install --break-system-packages --quiet "tomli==2.0.1" \
            || true
    } >/dev/null 2>&1
fi

# vitest must be resolvable from the workspace root; a miss means a corrupted
# node_modules. The image bakes the full dependency closure at the base commit
# (npm ci), so this should already be present. Reinstall only as a fallback
# instead of failing later with a confusing "command not found".
if ! [ -x node_modules/.bin/vitest ]; then
    echo "test-setup.sh: vitest binary missing from node_modules/.bin/. " \
         "The image build is corrupt — reinstalling from the lockfile." >&2
    # Offline-first: the image bakes the npm cache at the base commit, so an
    # offline install succeeds; fall back to a networked install only if needed.
    npm ci --offline || npm ci
fi

# No build step: the repo runs tests straight from TypeScript source via vitest's
# on-the-fly transform, and the verifier imports the provider-bridge modules by
# relative path, so the agent's source edits are visible immediately without a
# dist/ regen.

echo "test-setup.sh: ready. REPO_DIR=$REPO_DIR vitest=$(node_modules/.bin/vitest --version 2>/dev/null || echo unknown)"
