#!/usr/bin/env bash
# Verifier-phase setup for mise-feat-project-daemons.
#
# All runtime dependencies are baked into the image at the base commit: the
# Rust toolchain, the full cargo dependency closure, and the pre-warmed target
# cache (the image builds `cargo build --locked --tests --workspace`). The
# daemon-management surface under test is exercised offline — upstream mocks the
# external `pitchfork` supervisor with a tiny shell script under mise's offline
# mode — so this setup installs nothing over the network; it only reports the
# toolchain and confirms the workspace is present.
set -euo pipefail

echo "[test-setup] Rust version:    $(rustc --version 2>&1 | head -1)"
echo "[test-setup] Cargo version:   $(cargo --version 2>&1 | head -1)"
echo "[test-setup] Workspace root:  /repo/mise"
echo "[test-setup] CARGO_TARGET_DIR: ${CARGO_TARGET_DIR:-<unset>}"

if [ ! -f /repo/mise/Cargo.toml ]; then
  echo "[test-setup] ERROR: /repo/mise/Cargo.toml not found" >&2
  exit 1
fi

echo "[test-setup] Setup complete."
