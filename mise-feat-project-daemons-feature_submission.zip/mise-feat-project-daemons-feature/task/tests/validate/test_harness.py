"""Shared plumbing for the project-daemons validation stories.

Every story drives the prebuilt CLI binary as a subprocess inside a throwaway
isolated environment. This module only provides that plumbing — a fresh fake
HOME with the tool's private data/state/config/cache dirs, a tiny stand-in for
the external process supervisor that records every invocation to a log, and a
couple of helpers for reading that log and flattening JSON output. It encodes
no behaviour of the capability under test; the stories assert that.

The isolated-env layout and variable set mirror the repository's own end-to-end
harness so the binary sees exactly the environment it is tested under upstream.
"""

from __future__ import annotations

import json
import os
import subprocess
import tempfile
from collections import namedtuple

# The prebuilt binary that validation-setup.sh (re)builds. The build cache dir
# is fixed by the image; fall back to its known location if the var is unset.
_TARGET_DIR = os.environ.get("CARGO_TARGET_DIR", "/opt/cache/cargo-target")
MISE_BIN: str = os.path.join(_TARGET_DIR, "debug", "mise")

# Stand-in for the external supervisor. It logs every call (cwd + args) and
# answers the read-only capability probe: by default it reports support for
# external configuration files; with the OLD_PITCHFORK switch it reports an
# older, unsupported shape. status/supervisor/project are inert read-only
# answers so list/inspection paths have something to read.
PITCHFORK_MOCK: str = r"""#!/usr/bin/env bash
printf 'cwd=%s args=%s\n' "$PWD" "$*" >> "$DAEMON_LOG"
case "$1" in
  usage)
    if [[ ${OLD_PITCHFORK:-0} == 1 ]]; then echo 'cmd start {}'; else echo 'cmd config help="External files" {'; fi
    ;;
  status) exit 1 ;;
  supervisor) printf '{"status":"%s"}\n' "${SUPERVISOR_STATUS:-down}" ;;
  project) echo '[]' ;;
esac
"""

# Sub-commands the stand-in answers that are pure read-only inspection. Anything
# else recorded in the log means the binary drove a real lifecycle action.
_READONLY_SUBCOMMANDS = {"usage", "status", "supervisor", "project"}

Project = namedtuple("Project", ["cwd", "env", "log_path"])


def setup_project(inputs: dict) -> Project:
    """Create a fresh isolated project from a story case's ``inputs`` dict.

    Recognised ``inputs`` keys:
      - ``mise_toml``  (str)  : config file contents written into the project.
      - ``experimental`` (bool, default True) : enable the experimental gate.
      - ``safe``        (bool, default False) : enable safe mode.
      - ``old_pitchfork`` (bool, default False) : make the supervisor report
        no external-config support.
      - ``supervisor_status`` (str, default "down").
    """
    root = tempfile.mkdtemp(prefix="daemons-validate-")
    home = os.path.join(root, "home")
    workdir = os.path.join(home, "workdir")
    tmpdir = os.path.join(root, "tmp")
    data_dir = os.path.join(home, ".local", "share", "mise")
    state_dir = os.path.join(home, ".local", "state", "mise")
    cache_dir = os.path.join(home, ".cache", "mise")
    config_dir = os.path.join(home, ".config", "mise")
    system_dir = os.path.join(root, "etc", "mise")
    for d in (os.path.join(home, "bin"), workdir, tmpdir, data_dir,
              state_dir, cache_dir, config_dir, system_dir):
        os.makedirs(d, exist_ok=True)

    log_path = os.path.join(workdir, "supervisor.log")
    open(log_path, "w").close()

    mock = os.path.join(home, "bin", "pitchfork")
    with open(mock, "w") as f:
        f.write(PITCHFORK_MOCK)
    os.chmod(mock, 0o755)

    with open(os.path.join(workdir, "mise.toml"), "w") as f:
        f.write(inputs.get("mise_toml", ""))

    base = {k: v for k, v in os.environ.items()
            if not k.startswith(("MISE_", "PITCHFORK_"))
            and k not in ("DAEMON_LOG", "OLD_PITCHFORK", "SUPERVISOR_STATUS")}
    env = dict(base)
    env["HOME"] = home
    env["PATH"] = os.path.join(home, "bin") + ":" + base.get(
        "PATH", "/usr/local/bin:/usr/bin:/bin")
    env["TMPDIR"] = tmpdir
    env["MISE_TMP_DIR"] = tmpdir
    env["MISE_DATA_DIR"] = data_dir
    env["MISE_STATE_DIR"] = state_dir
    env["MISE_CACHE_DIR"] = cache_dir
    env["MISE_CONFIG_DIR"] = config_dir
    env["MISE_SYSTEM_DIR"] = system_dir
    env["MISE_YES"] = "1"
    env["MISE_OFFLINE"] = "1"
    env["MISE_USE_VERSIONS_HOST"] = "0"
    env["MISE_TRUSTED_CONFIG_PATHS"] = workdir
    env["MISE_EXPERIMENTAL"] = "1" if inputs.get("experimental", True) else "0"
    env["DAEMON_LOG"] = log_path
    env["SUPERVISOR_STATUS"] = str(inputs.get("supervisor_status", "down"))
    if inputs.get("old_pitchfork", False):
        env["OLD_PITCHFORK"] = "1"
    if inputs.get("safe", False):
        env["MISE_SAFE"] = "1"

    return Project(cwd=workdir, env=env, log_path=log_path)


def run(project: Project, *args: str, extra_env: dict | None = None,
        timeout: int = 120) -> subprocess.CompletedProcess:
    """Invoke the binary under test inside ``project`` and capture output."""
    env = dict(project.env)
    if extra_env:
        env.update(extra_env)
    return subprocess.run(
        [MISE_BIN, *args], cwd=project.cwd, env=env,
        capture_output=True, text=True, timeout=timeout, check=False)


def log_lines(project: Project) -> list:
    """Return the non-empty lines the supervisor stand-in recorded."""
    try:
        with open(project.log_path) as f:
            return [ln.rstrip("\n") for ln in f if ln.strip()]
    except FileNotFoundError:
        return []


def log_empty(project: Project) -> bool:
    """True when the supervisor stand-in was never invoked at all."""
    return len(log_lines(project)) == 0


def _args_of(line: str) -> str:
    i = line.find("args=")
    return line[i + 5:] if i >= 0 else ""


def dispatched_beyond_probe(project: Project) -> bool:
    """True when the binary issued a supervisor call that is not a read-only probe.

    Read-only probes (capability/status/inspection) do not count; a real
    lifecycle action (registering/starting/stopping) does.
    """
    for ln in log_lines(project):
        toks = _args_of(ln).split()
        if toks and toks[0] not in _READONLY_SUBCOMMANDS:
            return True
    return False


def json_string_values(text: str) -> list:
    """Flatten every string (dict keys and all values) from a JSON document.

    Returns an empty list when ``text`` is not valid JSON. Lets a story assert
    that a value appears somewhere in the output without pinning the exact
    field names the implementation chose for its JSON shape.
    """
    try:
        data = json.loads(text)
    except Exception:
        return []
    out: list = []

    def walk(x):
        if isinstance(x, str):
            out.append(x)
        elif isinstance(x, dict):
            for k, v in x.items():
                out.append(k)
                walk(v)
        elif isinstance(x, list):
            for v in x:
                walk(v)

    walk(data)
    return out
