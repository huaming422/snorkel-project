## Task

We want to add project daemons to mise: let a project declare the long-running background processes it needs, including local databases, in its `mise.toml`, and manage them through a new `mise daemons` command.

A daemon is either a custom process, where you supply the command to run, or a shorthand selecting a built-in database preset, PostgreSQL or Redis. A preset is batteries-included: picking one brings a real local database into the project's managed setup, not just a bare background process. Keep the presets aimed at local Unix development; this isn't a general-purpose supervisor.

Don't reimplement supervision. Delegate it to pitchfork, the external supervisor, a binary on PATH. pitchfork must be recent enough to accept external configuration files; if the one on PATH is too old, say so clearly rather than failing obscurely later.

Daemon declarations merge down the `mise.toml` hierarchy like the rest of mise config, so a child directory refines its parent. Daemon names get reused as persistent-data directory names, URI components, and SQL identifiers, so validate them strictly. Keep the capability behind mise's experimental mode.

## User stories / requirements

- A project declares its daemons in mise.toml, freely mixing preset shorthands such as `postgres = "18"` with custom `[daemons.NAME]` blocks that carry a `run` command. `mise daemons ls` then reports the declared daemons, and offers a `--json` form for tooling to consume.
- When a daemon selects a database preset, that database's tool becomes one of the project's managed tools: it shows up in `mise ls` and is pinned in the lockfile like the project's other tools. A tool that a `[daemons]` entry declares cannot be dropped with `mise unuse`.
- A database-preset daemon contributes the connection environment variables a client needs to reach it, including a port and a connection URL, and those show up in `mise env` for the project.
- `mise daemons start`, `stop`, and `restart` validate the request and then hand the real work to pitchfork, while `mise daemons ls` stays read-only and never drives a daemon. These lifecycle commands turn down a `--group` flag, since grouping is pitchfork's own concern, and they reject an unknown daemon name before taking any action.
