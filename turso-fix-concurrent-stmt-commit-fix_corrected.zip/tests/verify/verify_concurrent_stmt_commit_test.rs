// Two statements in flight on one connection, one of them ending while the
// other is still open.
//
// Runs as its own `core_tester` integration-test target
// (`cargo test --test verify_concurrent_stmt_commit_test`), so it sees only
// turso_core's public API: every helper below is inlined, and each case works
// through Database / Connection / Statement and reads the result back,
// reopening the database where durability matters.
//
// Cases:
//   * an interrupted DROP TABLE followed by a read, then reopen;
//   * an interrupted DROP TABLE, UPDATE or DELETE followed by a read, an
//     INSERT, or an INSERT OR FAIL that hits a UNIQUE conflict, then reopen;
//   * an open INSERT ... RETURNING next to a statement that fails (overflow,
//     UNIQUE, foreign key, deferred foreign key), read to the end afterwards,
//     with and without mvcc;
//   * a COMMIT dropped while it waits on IO, with and without mvcc;
//   * single statements: a plain INSERT, and constraint errors under the
//     default ABORT and under OR FAIL.

use std::collections::HashSet;
use std::sync::{Arc, Mutex};

use turso_core::io::{FileId, FileSyncType};
use turso_core::mvcc::yield_points::{YieldInjector, YieldPoint};
use turso_core::{
    Buffer, Clock, Completion, Connection, Database, File, LimboError, MemoryIO,
    MonotonicInstant, OpenFlags, StepResult, Value, WallClockInstant, IO,
};

// ---------------------------------------------------------------------------
// Yield injector (interrupt a statement at a safe cursor boundary)
// ---------------------------------------------------------------------------
//
// The MVCC cursor state machine consults an installed `YieldInjector` at each
// safe boundary. Returning `true` makes the current statement yield a
// synthetic `StepResult::IO` there, which lets a test abandon the statement
// mid-flight. `YieldPoint` is a public descriptor `{ ordinal, point_count }`;
// the first cursor boundary is ordinal 0 of the 9-point cursor family. We
// match that descriptor directly instead of naming the crate-private point
// enum, so the test does not depend on any non-public item.
const CURSOR_FAMILY_POINT_COUNT: u8 = 9;
const CURSOR_NEXT_START_ORDINAL: u8 = 0;

#[derive(Debug)]
struct FixedYieldInjector {
    remaining: Mutex<HashSet<YieldPoint>>,
}

impl FixedYieldInjector {
    fn new(points: impl IntoIterator<Item = YieldPoint>) -> Arc<Self> {
        Arc::new(Self {
            remaining: Mutex::new(points.into_iter().collect()),
        })
    }
}

impl YieldInjector for FixedYieldInjector {
    fn should_yield(&self, _instance_id: u64, _selection_key: u64, point: YieldPoint) -> bool {
        self.remaining.lock().unwrap().remove(&point)
    }
}

fn cursor_next_start_point() -> YieldPoint {
    YieldPoint {
        ordinal: CURSOR_NEXT_START_ORDINAL,
        point_count: CURSOR_FAMILY_POINT_COUNT,
    }
}

// ---------------------------------------------------------------------------
// Row reader (public Statement API; pumps IO internally)
// ---------------------------------------------------------------------------

fn get_rows(conn: &Arc<Connection>, sql: &str) -> Vec<Vec<Value>> {
    let mut stmt = conn.prepare(sql).unwrap();
    let mut rows = Vec::new();
    stmt.run_with_row_callback(|row| {
        rows.push(row.get_values().cloned().collect::<Vec<_>>());
        Ok(())
    })
    .unwrap();
    rows
}

/// Read a single-column i64 result set through the public typed row getter.
fn get_i64_column(conn: &Arc<Connection>, sql: &str) -> Vec<i64> {
    let mut stmt = conn.prepare(sql).unwrap();
    let mut values = Vec::new();
    stmt.run_with_row_callback(|row| {
        values.push(row.get::<i64>(0)?);
        Ok(())
    })
    .unwrap();
    values
}

fn step_blocking(stmt: &mut turso_core::Statement) -> turso_core::Result<StepResult> {
    loop {
        match stmt.step()? {
            StepResult::IO => stmt._io().step()?,
            other => return Ok(other),
        }
    }
}

fn mode_name(mvcc: bool) -> &'static str {
    if mvcc {
        "mvcc"
    } else {
        "default journal mode"
    }
}

// ---------------------------------------------------------------------------
// Case 1:
// An interrupted DROP TABLE, abandoned, followed by an ordinary read on the
// SAME connection must not make the DROP's partial schema delete durable. The
// table and its index must still be present after the database is reopened.
// ---------------------------------------------------------------------------
#[test]
fn interrupted_drop_table_schema_survives_reopen() {
    let io = Arc::new(MemoryIO::new());
    let path = ":memory:verify-interrupted-drop-table-schema-rollback";

    let db = Database::open_file(io.clone(), path).unwrap();
    let conn = db.connect().unwrap();

    conn.execute("PRAGMA journal_mode = 'mvcc'").unwrap();
    conn.execute("CREATE TABLE repro_target(c0 INTEGER, c1 REAL)")
        .unwrap();
    conn.execute(
        "CREATE UNIQUE INDEX IF NOT EXISTS idx_repro_target_c0 \
         ON repro_target (c0) WHERE c1 IS NULL",
    )
    .unwrap();
    conn.execute("PRAGMA wal_checkpoint(TRUNCATE)").unwrap();

    let before = get_rows(
        &conn,
        "SELECT type, name FROM sqlite_schema \
         WHERE tbl_name = 'repro_target' ORDER BY rowid",
    );
    assert_eq!(before.len(), 2, "precondition: table + index present");
    assert_eq!(before[0][0].to_string(), "table");
    assert_eq!(before[0][1].to_string(), "repro_target");
    assert_eq!(before[1][0].to_string(), "index");
    assert_eq!(before[1][1].to_string(), "idx_repro_target_c0");

    // Interrupt the DROP at the first cursor boundary and abandon it.
    conn.set_yield_injector(Some(FixedYieldInjector::new([cursor_next_start_point()])));
    let mut drop_stmt = conn.prepare("DROP TABLE repro_target").unwrap();
    match drop_stmt.step().unwrap() {
        StepResult::IO => {}
        other => panic!("expected injected IO yield while dropping repro_target; got {other:?}"),
    }
    conn.set_yield_injector(None);

    // An ordinary read finishes on the same connection.
    let read = get_rows(&conn, "SELECT 1");
    assert_eq!(read.len(), 1);
    assert_eq!(read[0][0].to_string(), "1");

    drop(drop_stmt);
    drop(conn);
    drop(db);

    // Reopen: the interrupted DROP must not have been committed by the read.
    let db = Database::open_file(io, path).unwrap();
    let conn = db.connect().unwrap();
    let after = get_rows(
        &conn,
        "SELECT type, name FROM sqlite_schema \
         WHERE tbl_name = 'repro_target' ORDER BY rowid",
    );
    assert_eq!(
        after.len(),
        2,
        "table and index must survive reopen (interrupted DROP must not persist)"
    );
    assert_eq!(after[0][0].to_string(), "table");
    assert_eq!(after[0][1].to_string(), "repro_target");
    assert_eq!(after[1][0].to_string(), "index");
    assert_eq!(after[1][1].to_string(), "idx_repro_target_c0");
}

// ---------------------------------------------------------------------------
// Case 2:
// Under mvcc, a DROP TABLE, an UPDATE or a DELETE interrupted at its first
// cursor boundary and abandoned, while another statement on the same
// connection runs to its end: a read, an INSERT into another table, or an
// INSERT OR FAIL that stops on a UNIQUE conflict after writing a row. After
// the interrupted statement is dropped and the database reopened, its table
// must be exactly as it was before. What the second statement itself left
// behind is not checked.
// ---------------------------------------------------------------------------
#[test]
fn interrupted_statement_not_persisted_by_next_statement() {
    let owners = [
        "DROP TABLE target",
        "UPDATE target SET v = v + 1",
        "DELETE FROM target",
    ];
    let finishers = [
        "SELECT 1",
        "INSERT INTO other VALUES (1)",
        "INSERT OR FAIL INTO uniq VALUES (7), (1)",
    ];
    let expected_rows: Vec<Vec<i64>> = (1..=5).map(|id| vec![id, 10]).collect();

    for (oi, owner_sql) in owners.iter().enumerate() {
        for (fi, finisher_sql) in finishers.iter().enumerate() {
            let what = format!("{owner_sql:?} interrupted, then {finisher_sql:?}");
            let io = Arc::new(MemoryIO::new());
            let path = format!(":memory:verify-interrupted-{oi}-{fi}");

            let db = Database::open_file(io.clone(), &path).unwrap();
            let conn = db.connect().unwrap();
            conn.execute("PRAGMA journal_mode = 'mvcc'").unwrap();
            conn.execute("CREATE TABLE target (id INTEGER PRIMARY KEY, v INTEGER)")
                .unwrap();
            conn.execute("INSERT INTO target VALUES (1, 10), (2, 10), (3, 10), (4, 10), (5, 10)")
                .unwrap();
            conn.execute("CREATE INDEX idx_target_v ON target (v)").unwrap();
            conn.execute("CREATE TABLE other (x INTEGER)").unwrap();
            conn.execute("CREATE TABLE uniq (k INTEGER UNIQUE)").unwrap();
            conn.execute("INSERT INTO uniq VALUES (1)").unwrap();
            conn.execute("PRAGMA wal_checkpoint(TRUNCATE)").unwrap();

            conn.set_yield_injector(Some(FixedYieldInjector::new([cursor_next_start_point()])));
            let mut owner = conn.prepare(*owner_sql).unwrap();
            match owner.step().unwrap() {
                StepResult::IO => {}
                other => panic!("{what}: expected injected IO yield; got {other:?}"),
            }
            conn.set_yield_injector(None);

            if finisher_sql.starts_with("INSERT OR FAIL") {
                let err = conn
                    .execute(*finisher_sql)
                    .expect_err("the second VALUES row hits the UNIQUE index");
                assert!(matches!(err, LimboError::Constraint(_)), "{what}: {err:?}");
            } else {
                conn.execute(*finisher_sql).unwrap();
            }

            drop(owner);
            drop(conn);
            drop(db);

            let db = Database::open_file(io, &path)
                .unwrap_or_else(|e| panic!("{what}: reopen failed: {e:?}"));
            let conn = db.connect().unwrap();
            let schema = get_rows(
                &conn,
                "SELECT type, name FROM sqlite_schema \
                 WHERE tbl_name = 'target' ORDER BY rowid",
            );
            let schema: Vec<(String, String)> = schema
                .iter()
                .map(|r| (r[0].to_string(), r[1].to_string()))
                .collect();
            assert_eq!(
                schema,
                vec![
                    ("table".to_string(), "target".to_string()),
                    ("index".to_string(), "idx_target_v".to_string()),
                ],
                "{what}: schema after reopen"
            );
            let mut stmt = conn.prepare("SELECT id, v FROM target ORDER BY id").unwrap();
            let mut rows = Vec::new();
            stmt.run_with_row_callback(|row| {
                rows.push(vec![row.get::<i64>(0)?, row.get::<i64>(1)?]);
                Ok(())
            })
            .unwrap();
            assert_eq!(rows, expected_rows, "{what}: target rows after reopen");
        }
    }
}

// ---------------------------------------------------------------------------
// Case 3:
// An INSERT ... RETURNING has handed back its first row and is still open
// when another statement on the same connection fails: an integer overflow,
// a UNIQUE violation on its second row, an immediate foreign key violation,
// or a deferred foreign key violation that a later INSERT satisfies. The
// RETURNING statement is then read to the end. Its rows must be there, on the
// same connection and after reopen, and a failed INSERT must have undone its
// own rows. Runs with and without mvcc.
// ---------------------------------------------------------------------------
#[test]
fn unrelated_failure_does_not_roll_back_open_returning_statement() {
    let peers: [(&str, &[&str]); 4] = [
        ("overflow", &["SELECT sum(x) FROM overflow"]),
        ("unique", &["INSERT INTO uniq VALUES (5), (1)"]),
        ("foreign key", &["INSERT INTO child VALUES (99)"]),
        (
            "deferred foreign key",
            &["INSERT INTO dchild VALUES (42)", "INSERT INTO parent VALUES (42)"],
        ),
    ];

    for mvcc in [false, true] {
        for (pi, (peer_name, peer_sql)) in peers.iter().enumerate() {
            let what = format!("{} peer in {}", peer_name, mode_name(mvcc));
            let io = Arc::new(MemoryIO::new());
            let path = format!(":memory:verify-open-returning-{mvcc}-{pi}");

            let db = Database::open_file(io.clone(), &path).unwrap();
            let conn = db.connect().unwrap();
            if mvcc {
                conn.execute("PRAGMA journal_mode = 'mvcc'").unwrap();
            }
            conn.execute("PRAGMA foreign_keys = ON").unwrap();
            for sql in [
                "CREATE TABLE pending (id INTEGER PRIMARY KEY, v TEXT)",
                "CREATE TABLE overflow (x INTEGER)",
                "INSERT INTO overflow VALUES (9223372036854775807), (1)",
                "CREATE TABLE uniq (k INTEGER UNIQUE)",
                "INSERT INTO uniq VALUES (1)",
                "CREATE TABLE parent (id INTEGER PRIMARY KEY)",
                "INSERT INTO parent VALUES (1)",
                "CREATE TABLE child (pid INTEGER REFERENCES parent(id))",
                "CREATE TABLE dchild (pid INTEGER REFERENCES parent(id) \
                 DEFERRABLE INITIALLY DEFERRED)",
            ] {
                conn.execute(sql).unwrap();
            }

            let mut owner = conn
                .prepare("INSERT INTO pending VALUES (1, 'a'), (2, 'b') RETURNING id")
                .unwrap();
            let first = step_blocking(&mut owner).unwrap();
            assert!(matches!(first, StepResult::Row), "{what}: expected Row, got {first:?}");

            match *peer_name {
                "deferred foreign key" => {
                    // The first INSERT leaves a deferred violation (its result is
                    // not checked); the second satisfies it.
                    let _ = conn.execute(peer_sql[0]);
                    conn.execute(peer_sql[1]).unwrap();
                }
                _ => {
                    let err = conn
                        .execute(peer_sql[0])
                        .expect_err("the unrelated statement fails");
                    let kind_ok = match *peer_name {
                        "overflow" => matches!(err, LimboError::IntegerOverflow),
                        "unique" => matches!(err, LimboError::Constraint(_)),
                        _ => matches!(err, LimboError::ForeignKeyConstraint(_)),
                    };
                    assert!(kind_ok, "{what}: unexpected error {err:?}");
                }
            }

            // Read the RETURNING statement to its end.
            let mut returned = vec![first];
            loop {
                match step_blocking(&mut owner).unwrap() {
                    StepResult::Done => break,
                    other => returned.push(other),
                }
            }
            assert_eq!(returned.len(), 2, "{what}: RETURNING rows read: {returned:?}");
            drop(owner);

            let ids = get_i64_column(&conn, "SELECT id FROM pending ORDER BY id");
            assert_eq!(ids, vec![1, 2], "{what}: RETURNING insert rows");
            if *peer_name == "unique" {
                let keys = get_i64_column(&conn, "SELECT k FROM uniq ORDER BY k");
                assert_eq!(keys, vec![1], "{what}: the failed INSERT's own row");
            }
            if *peer_name == "foreign key" {
                let pids = get_i64_column(&conn, "SELECT pid FROM child");
                assert!(pids.is_empty(), "{what}: the failed INSERT's own row: {pids:?}");
            }

            drop(conn);
            drop(db);
            let db = Database::open_file(io, &path)
                .unwrap_or_else(|e| panic!("{what}: reopen failed: {e:?}"));
            let conn = db.connect().unwrap();
            let ids = get_i64_column(&conn, "SELECT id FROM pending ORDER BY id");
            assert_eq!(ids, vec![1, 2], "{what}: RETURNING insert rows after reopen");
        }
    }
}

// ---------------------------------------------------------------------------
// Case 4:
// An explicit COMMIT suspended on IO and then abandoned must roll back its
// transaction. A subsequent INSERT + read on the same connection must see
// only the post-rollback row, never the pre-COMMIT one. Runs with and
// without mvcc.
// ---------------------------------------------------------------------------
#[test]
fn dropping_explicit_commit_waiting_on_io_rolls_back_transaction() {
    for mvcc in [false, true] {
        let io = Arc::new(QueuedIo::new());
        let path = format!("verify-queued-explicit-commit-drop-{mvcc}.db");
        let db = Database::open_file(io, &path).unwrap();
        let conn = db.connect().unwrap();
        if mvcc {
            conn.execute("PRAGMA journal_mode = 'mvcc'").unwrap();
        }

        conn.execute("CREATE TABLE t(x INTEGER)").unwrap();
        conn.execute("BEGIN").unwrap();
        conn.execute("INSERT INTO t VALUES (1)").unwrap();

        {
            let mut commit = conn.prepare("COMMIT").unwrap();
            assert!(
                matches!(commit.step().unwrap(), StepResult::IO),
                "{}: COMMIT should suspend on queued IO",
                mode_name(mvcc)
            );
            // Abandon the suspended COMMIT.
        }

        conn.execute("INSERT INTO t VALUES (2)").unwrap();

        let values = get_i64_column(&conn, "SELECT x FROM t ORDER BY x");
        assert_eq!(
            values,
            vec![2],
            "{}: abandoned COMMIT must roll back; only the post-rollback row is visible",
            mode_name(mvcc)
        );
    }
}

// ---------------------------------------------------------------------------
// Case 5:
// The ordinary single-statement autocommit path must keep committing. With
// only one statement ever in flight, a plain INSERT run to completion is
// durable across reopen.
// ---------------------------------------------------------------------------
#[test]
fn single_statement_autocommit_commit_preserved() {
    let io = Arc::new(MemoryIO::new());
    let path = ":memory:verify-single-statement-autocommit";

    let db = Database::open_file(io.clone(), path).unwrap();
    let conn = db.connect().unwrap();

    conn.execute("PRAGMA journal_mode = 'mvcc'").unwrap();
    conn.execute("CREATE TABLE t (id INTEGER PRIMARY KEY, v TEXT)")
        .unwrap();
    conn.execute("INSERT INTO t VALUES (1, 'a'), (2, 'b'), (3, 'c')")
        .unwrap();
    conn.execute("PRAGMA wal_checkpoint(TRUNCATE)").unwrap();

    let rows = get_rows(&conn, "SELECT id FROM t ORDER BY id");
    assert_eq!(rows.len(), 3, "all three rows committed before reopen");

    drop(conn);
    drop(db);

    let db = Database::open_file(io, path).unwrap();
    let conn = db.connect().unwrap();
    let ids = get_i64_column(&conn, "SELECT id FROM t ORDER BY id");
    assert_eq!(
        ids,
        vec![1, 2, 3],
        "ordinary single-statement autocommit must stay durable across reopen"
    );
}

// ---------------------------------------------------------------------------
// Case 6:
// With one statement at a time, a multi-row INSERT that hits a UNIQUE
// conflict on its second row keeps nothing under the default ABORT and keeps
// its first row under OR FAIL, across reopen. Runs with and without mvcc.
// ---------------------------------------------------------------------------
#[test]
fn single_statement_constraint_errors_unchanged() {
    for mvcc in [false, true] {
        let io = Arc::new(MemoryIO::new());
        let path = format!(":memory:verify-single-statement-constraint-{mvcc}");

        let db = Database::open_file(io.clone(), &path).unwrap();
        let conn = db.connect().unwrap();
        if mvcc {
            conn.execute("PRAGMA journal_mode = 'mvcc'").unwrap();
        }
        conn.execute("CREATE TABLE uniq (k INTEGER UNIQUE)").unwrap();
        conn.execute("INSERT INTO uniq VALUES (1)").unwrap();

        let err = conn
            .execute("INSERT INTO uniq VALUES (5), (1)")
            .expect_err("second row conflicts");
        assert!(matches!(err, LimboError::Constraint(_)), "{err:?}");
        let err = conn
            .execute("INSERT OR FAIL INTO uniq VALUES (7), (1)")
            .expect_err("second row conflicts");
        assert!(matches!(err, LimboError::Constraint(_)), "{err:?}");

        drop(conn);
        drop(db);
        let db = Database::open_file(io, &path).unwrap();
        let conn = db.connect().unwrap();
        let keys = get_i64_column(&conn, "SELECT k FROM uniq ORDER BY k");
        assert_eq!(keys, vec![1, 7], "{}: rows after reopen", mode_name(mvcc));
    }
}

// ---------------------------------------------------------------------------
// QueuedIo: a deterministic IO shim that defers every file operation onto an
// internal queue, so a statement that needs IO (here, an explicit COMMIT's
// durability write) suspends at `StepResult::IO` until the queue is pumped.
// Built entirely on turso_core's public IO/File/Clock traits. Mirrors the
// repo's own integration-test helper; inlined because integration-test
// targets cannot import the test crate's private modules.
// ---------------------------------------------------------------------------
struct QueuedIoOp {
    action: Box<dyn FnOnce() -> turso_core::Result<()> + Send>,
}

struct QueuedIoState {
    pending: Mutex<std::collections::VecDeque<QueuedIoOp>>,
}

struct QueuedIo {
    inner: Arc<dyn IO>,
    state: Arc<QueuedIoState>,
}

impl QueuedIo {
    fn new() -> Self {
        Self {
            inner: Arc::new(MemoryIO::new()),
            state: Arc::new(QueuedIoState {
                pending: Mutex::new(std::collections::VecDeque::new()),
            }),
        }
    }

    fn step_one(&self) -> turso_core::Result<bool> {
        let Some(op) = self.state.pending.lock().unwrap().pop_front() else {
            return Ok(false);
        };
        (op.action)()?;
        Ok(true)
    }
}

impl Clock for QueuedIo {
    fn current_time_monotonic(&self) -> MonotonicInstant {
        self.inner.current_time_monotonic()
    }

    fn current_time_wall_clock(&self) -> WallClockInstant {
        self.inner.current_time_wall_clock()
    }
}

impl IO for QueuedIo {
    fn open_file(
        &self,
        path: &str,
        flags: OpenFlags,
        direct: bool,
    ) -> turso_core::Result<Arc<dyn File>> {
        let inner = self.inner.open_file(path, flags, direct)?;
        Ok(Arc::new(QueuedFile {
            inner,
            state: self.state.clone(),
        }))
    }

    fn remove_file(&self, path: &str) -> turso_core::Result<()> {
        self.inner.remove_file(path)
    }

    fn step(&self) -> turso_core::Result<()> {
        self.step_one().map(|_| ())
    }

    fn drain_completions(&self, completions: &[Completion]) -> turso_core::Result<()> {
        while completions.iter().any(|c| !c.finished()) {
            if !self.step_one()? {
                break;
            }
        }
        Ok(())
    }

    fn cancel(&self, completions: &[Completion]) -> turso_core::Result<()> {
        for completion in completions {
            completion.abort();
        }
        Ok(())
    }

    fn file_id(&self, path: &str) -> turso_core::Result<FileId> {
        self.inner.file_id(path)
    }

    fn fill_bytes(&self, dest: &mut [u8]) {
        self.inner.fill_bytes(dest);
    }

    fn generate_random_number(&self) -> i64 {
        self.inner.generate_random_number()
    }
}

struct QueuedFile {
    inner: Arc<dyn File>,
    state: Arc<QueuedIoState>,
}

impl QueuedFile {
    fn enqueue(
        &self,
        completion: Completion,
        action: impl FnOnce() -> turso_core::Result<()> + Send + 'static,
    ) -> turso_core::Result<Completion> {
        self.state
            .pending
            .lock()
            .unwrap()
            .push_back(QueuedIoOp {
                action: Box::new(action),
            });
        Ok(completion)
    }
}

impl File for QueuedFile {
    fn lock_file(&self, exclusive: bool) -> turso_core::Result<()> {
        self.inner.lock_file(exclusive)
    }

    fn unlock_file(&self) -> turso_core::Result<()> {
        self.inner.unlock_file()
    }

    fn pread(&self, pos: u64, completion: Completion) -> turso_core::Result<Completion> {
        let inner = self.inner.clone();
        let c = completion.clone();
        self.enqueue(completion, move || {
            drop(inner.pread(pos, c)?);
            Ok(())
        })
    }

    fn pwrite(
        &self,
        pos: u64,
        buffer: Arc<Buffer>,
        completion: Completion,
    ) -> turso_core::Result<Completion> {
        let inner = self.inner.clone();
        let c = completion.clone();
        self.enqueue(completion, move || {
            drop(inner.pwrite(pos, buffer, c)?);
            Ok(())
        })
    }

    fn sync(&self, completion: Completion, sync_type: FileSyncType) -> turso_core::Result<Completion> {
        let inner = self.inner.clone();
        let c = completion.clone();
        self.enqueue(completion, move || {
            drop(inner.sync(c, sync_type)?);
            Ok(())
        })
    }

    fn pwritev(
        &self,
        pos: u64,
        buffers: Vec<Arc<Buffer>>,
        completion: Completion,
    ) -> turso_core::Result<Completion> {
        let inner = self.inner.clone();
        let c = completion.clone();
        self.enqueue(completion, move || {
            drop(inner.pwritev(pos, buffers, c)?);
            Ok(())
        })
    }

    fn size(&self) -> turso_core::Result<u64> {
        self.inner.size()
    }

    fn truncate(&self, len: u64, completion: Completion) -> turso_core::Result<Completion> {
        let inner = self.inner.clone();
        let c = completion.clone();
        self.enqueue(completion, move || {
            drop(inner.truncate(len, c)?);
            Ok(())
        })
    }
}
