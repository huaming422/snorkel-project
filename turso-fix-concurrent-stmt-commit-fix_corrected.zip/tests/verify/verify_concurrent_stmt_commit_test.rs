// Two statements in flight on one connection, one of them ending while the
// other is still open.
//
// Runs as its own `core_tester` integration-test target
// (`cargo test --test verify_concurrent_stmt_commit_test`), so it sees only
// turso_core's public API: every helper below is inlined, and each case works
// through Database / Connection / Statement and reads the result back,
// reopening the database where durability matters.
//
// Cases:
//   * an interrupted DROP TABLE followed by a read, then reopen;
//   * an open INSERT ... RETURNING next to a statement that fails;
//   * a COMMIT dropped while it waits on IO;
//   * a plain single-statement INSERT, which keeps working.

use std::collections::HashSet;
use std::sync::{Arc, Mutex};

use turso_core::io::{FileId, FileSyncType};
use turso_core::mvcc::yield_points::{YieldInjector, YieldPoint};
use turso_core::{
    Buffer, Clock, Completion, Database, File, LimboError, MemoryIO, MonotonicInstant, OpenFlags,
    StepResult, Value, WallClockInstant, IO,
};

// ---------------------------------------------------------------------------
// Yield injector (interrupt a statement at a safe cursor boundary)
// ---------------------------------------------------------------------------
//
// The MVCC cursor state machine consults an installed `YieldInjector` at each
// safe boundary. Returning `true` makes the current statement yield a
// synthetic `StepResult::IO` there, which lets a test abandon the statement
// mid-flight. `YieldPoint` is a public descriptor `{ ordinal, point_count }`;
// the first cursor boundary (the one the interrupted-DROP-TABLE repro needs)
// is ordinal 0 of the 9-point cursor family. We match that descriptor
// directly instead of naming the crate-private point enum, so the test does
// not depend on any non-public item.
const CURSOR_FAMILY_POINT_COUNT: u8 = 9;
const CURSOR_NEXT_START_ORDINAL: u8 = 0;

#[derive(Debug)]
struct FixedYieldInjector {
    remaining: Mutex<HashSet<YieldPoint>>,
}

impl FixedYieldInjector {
    fn new(points: impl IntoIterator<Item = YieldPoint>) -> Arc<Self> {
        Arc::new(Self {
            remaining: Mutex::new(points.into_iter().collect()),
        })
    }
}

impl YieldInjector for FixedYieldInjector {
    fn should_yield(&self, _instance_id: u64, _selection_key: u64, point: YieldPoint) -> bool {
        self.remaining.lock().unwrap().remove(&point)
    }
}

fn cursor_next_start_point() -> YieldPoint {
    YieldPoint {
        ordinal: CURSOR_NEXT_START_ORDINAL,
        point_count: CURSOR_FAMILY_POINT_COUNT,
    }
}

// ---------------------------------------------------------------------------
// Row reader (public Statement API; pumps IO internally)
// ---------------------------------------------------------------------------

fn get_rows(conn: &Arc<turso_core::Connection>, sql: &str) -> Vec<Vec<Value>> {
    let mut stmt = conn.prepare(sql).unwrap();
    let mut rows = Vec::new();
    stmt.run_with_row_callback(|row| {
        rows.push(row.get_values().cloned().collect::<Vec<_>>());
        Ok(())
    })
    .unwrap();
    rows
}

/// Read a single-column i64 result set through the public typed row getter.
fn get_i64_column(conn: &Arc<turso_core::Connection>, sql: &str) -> Vec<i64> {
    let mut stmt = conn.prepare(sql).unwrap();
    let mut values = Vec::new();
    stmt.run_with_row_callback(|row| {
        values.push(row.get::<i64>(0)?);
        Ok(())
    })
    .unwrap();
    values
}

fn step_blocking(stmt: &mut turso_core::Statement) -> turso_core::Result<StepResult> {
    loop {
        match stmt.step()? {
            StepResult::IO => stmt._io().step()?,
            other => return Ok(other),
        }
    }
}

// ---------------------------------------------------------------------------
// Case 1:
// An interrupted DROP TABLE, abandoned, followed by an ordinary read on the
// SAME connection must not make the DROP's partial schema delete durable. The
// table and its index must still be present after the database is reopened.
// ---------------------------------------------------------------------------
#[test]
fn interrupted_drop_table_schema_survives_reopen() {
    let io = Arc::new(MemoryIO::new());
    let path = ":memory:verify-interrupted-drop-table-schema-rollback";

    let db = Database::open_file(io.clone(), path).unwrap();
    let conn = db.connect().unwrap();

    conn.execute("PRAGMA journal_mode = 'mvcc'").unwrap();
    conn.execute("CREATE TABLE repro_target(c0 INTEGER, c1 REAL)")
        .unwrap();
    conn.execute(
        "CREATE UNIQUE INDEX IF NOT EXISTS idx_repro_target_c0 \
         ON repro_target (c0) WHERE c1 IS NULL",
    )
    .unwrap();
    conn.execute("PRAGMA wal_checkpoint(TRUNCATE)").unwrap();

    let before = get_rows(
        &conn,
        "SELECT type, name FROM sqlite_schema \
         WHERE tbl_name = 'repro_target' ORDER BY rowid",
    );
    assert_eq!(before.len(), 2, "precondition: table + index present");
    assert_eq!(before[0][0].to_string(), "table");
    assert_eq!(before[0][1].to_string(), "repro_target");
    assert_eq!(before[1][0].to_string(), "index");
    assert_eq!(before[1][1].to_string(), "idx_repro_target_c0");

    // Interrupt the DROP at the first cursor boundary and abandon it.
    conn.set_yield_injector(Some(FixedYieldInjector::new([cursor_next_start_point()])));
    let mut drop_stmt = conn.prepare("DROP TABLE repro_target").unwrap();
    match drop_stmt.step().unwrap() {
        StepResult::IO => {}
        other => panic!("expected injected IO yield while dropping repro_target; got {other:?}"),
    }
    conn.set_yield_injector(None);

    // An ordinary read finishes on the same connection.
    let read = get_rows(&conn, "SELECT 1");
    assert_eq!(read.len(), 1);
    assert_eq!(read[0][0].to_string(), "1");

    drop(drop_stmt);
    drop(conn);
    drop(db);

    // Reopen: the interrupted DROP must not have been committed by the read.
    let db = Database::open_file(io, path).unwrap();
    let conn = db.connect().unwrap();
    let after = get_rows(
        &conn,
        "SELECT type, name FROM sqlite_schema \
         WHERE tbl_name = 'repro_target' ORDER BY rowid",
    );
    assert_eq!(
        after.len(),
        2,
        "table and index must survive reopen (interrupted DROP must not persist)"
    );
    assert_eq!(after[0][0].to_string(), "table");
    assert_eq!(after[0][1].to_string(), "repro_target");
    assert_eq!(after[1][0].to_string(), "index");
    assert_eq!(after[1][1].to_string(), "idx_repro_target_c0");
}

// ---------------------------------------------------------------------------
// Case 2:
// A runtime error in an UNRELATED statement must not roll back an in-flight
// INSERT ... RETURNING that is still open on the same connection. Its rows
// must remain after it is drained.
// ---------------------------------------------------------------------------
#[test]
fn unrelated_runtime_error_does_not_rollback_open_returning_statement() {
    let io = Arc::new(MemoryIO::new());
    let db = Database::open_file(io, ":memory:verify-unrelated-error-open-returning").unwrap();
    let conn = db.connect().unwrap();

    // No MVCC pragma: this case and the next one show up in the default
    // journal mode too.
    conn.execute("CREATE TABLE pending (id INTEGER PRIMARY KEY, v TEXT)")
        .unwrap();
    conn.execute("CREATE TABLE overflow (x INTEGER)").unwrap();
    conn.execute("INSERT INTO overflow VALUES (9223372036854775807), (1)")
        .unwrap();

    {
        let mut owner = conn
            .prepare("INSERT INTO pending VALUES (1, 'a'), (2, 'b') RETURNING id")
            .unwrap();
        let result = step_blocking(&mut owner).unwrap();
        assert!(matches!(result, StepResult::Row), "expected Row, got {result:?}");

        // Unrelated statement fails with a runtime overflow while `owner`
        // is still open.
        let err = conn
            .execute("SELECT sum(x) FROM overflow")
            .expect_err("sum overflow should fail");
        assert!(matches!(err, LimboError::IntegerOverflow), "{err:?}");
    }

    let ids = get_i64_column(&conn, "SELECT id FROM pending ORDER BY id");
    assert_eq!(
        ids,
        vec![1, 2],
        "the open RETURNING insert must not be rolled back by an unrelated error"
    );
}

// ---------------------------------------------------------------------------
// Case 3:
// An explicit COMMIT suspended on IO and then abandoned must roll back its
// transaction. A subsequent INSERT + read on the same connection must see
// only the post-rollback row, never the pre-COMMIT one.
// ---------------------------------------------------------------------------
#[test]
fn dropping_explicit_commit_waiting_on_io_rolls_back_transaction() {
    let io = Arc::new(QueuedIo::new());
    let db = Database::open_file(io, "verify-queued-explicit-commit-drop.db").unwrap();
    let conn = db.connect().unwrap();

    conn.execute("CREATE TABLE t(x INTEGER)").unwrap();
    conn.execute("BEGIN").unwrap();
    conn.execute("INSERT INTO t VALUES (1)").unwrap();

    {
        let mut commit = conn.prepare("COMMIT").unwrap();
        assert!(
            matches!(commit.step().unwrap(), StepResult::IO),
            "COMMIT should suspend on queued IO"
        );
        // Abandon the suspended COMMIT.
    }

    conn.execute("INSERT INTO t VALUES (2)").unwrap();

    let values = get_i64_column(&conn, "SELECT x FROM t ORDER BY x");
    assert_eq!(
        values,
        vec![2],
        "abandoned COMMIT must roll back; only the post-rollback row is visible"
    );
}

// ---------------------------------------------------------------------------
// Case 4:
// The ordinary single-statement autocommit path must keep committing. With
// only one statement ever in flight, a plain INSERT run to completion is
// durable across reopen.
// ---------------------------------------------------------------------------
#[test]
fn single_statement_autocommit_commit_preserved() {
    let io = Arc::new(MemoryIO::new());
    let path = ":memory:verify-single-statement-autocommit";

    let db = Database::open_file(io.clone(), path).unwrap();
    let conn = db.connect().unwrap();

    conn.execute("PRAGMA journal_mode = 'mvcc'").unwrap();
    conn.execute("CREATE TABLE t (id INTEGER PRIMARY KEY, v TEXT)")
        .unwrap();
    conn.execute("INSERT INTO t VALUES (1, 'a'), (2, 'b'), (3, 'c')")
        .unwrap();
    conn.execute("PRAGMA wal_checkpoint(TRUNCATE)").unwrap();

    let rows = get_rows(&conn, "SELECT id FROM t ORDER BY id");
    assert_eq!(rows.len(), 3, "all three rows committed before reopen");

    drop(conn);
    drop(db);

    let db = Database::open_file(io, path).unwrap();
    let conn = db.connect().unwrap();
    let ids = get_i64_column(&conn, "SELECT id FROM t ORDER BY id");
    assert_eq!(
        ids,
        vec![1, 2, 3],
        "ordinary single-statement autocommit must stay durable across reopen"
    );
}

// ---------------------------------------------------------------------------
// QueuedIo: a deterministic IO shim that defers every file operation onto an
// internal queue, so a statement that needs IO (here, an explicit COMMIT's
// durability write) suspends at `StepResult::IO` until the queue is pumped.
// Built entirely on turso_core's public IO/File/Clock traits. Mirrors the
// repo's own integration-test helper; inlined because integration-test
// targets cannot import the test crate's private modules.
// ---------------------------------------------------------------------------
struct QueuedIoOp {
    action: Box<dyn FnOnce() -> turso_core::Result<()> + Send>,
}

struct QueuedIoState {
    pending: Mutex<std::collections::VecDeque<QueuedIoOp>>,
}

struct QueuedIo {
    inner: Arc<dyn IO>,
    state: Arc<QueuedIoState>,
}

impl QueuedIo {
    fn new() -> Self {
        Self {
            inner: Arc::new(MemoryIO::new()),
            state: Arc::new(QueuedIoState {
                pending: Mutex::new(std::collections::VecDeque::new()),
            }),
        }
    }

    fn step_one(&self) -> turso_core::Result<bool> {
        let Some(op) = self.state.pending.lock().unwrap().pop_front() else {
            return Ok(false);
        };
        (op.action)()?;
        Ok(true)
    }
}

impl Clock for QueuedIo {
    fn current_time_monotonic(&self) -> MonotonicInstant {
        self.inner.current_time_monotonic()
    }

    fn current_time_wall_clock(&self) -> WallClockInstant {
        self.inner.current_time_wall_clock()
    }
}

impl IO for QueuedIo {
    fn open_file(
        &self,
        path: &str,
        flags: OpenFlags,
        direct: bool,
    ) -> turso_core::Result<Arc<dyn File>> {
        let inner = self.inner.open_file(path, flags, direct)?;
        Ok(Arc::new(QueuedFile {
            inner,
            state: self.state.clone(),
        }))
    }

    fn remove_file(&self, path: &str) -> turso_core::Result<()> {
        self.inner.remove_file(path)
    }

    fn step(&self) -> turso_core::Result<()> {
        self.step_one().map(|_| ())
    }

    fn drain_completions(&self, completions: &[Completion]) -> turso_core::Result<()> {
        while completions.iter().any(|c| !c.finished()) {
            if !self.step_one()? {
                break;
            }
        }
        Ok(())
    }

    fn cancel(&self, completions: &[Completion]) -> turso_core::Result<()> {
        for completion in completions {
            completion.abort();
        }
        Ok(())
    }

    fn file_id(&self, path: &str) -> turso_core::Result<FileId> {
        self.inner.file_id(path)
    }

    fn fill_bytes(&self, dest: &mut [u8]) {
        self.inner.fill_bytes(dest);
    }

    fn generate_random_number(&self) -> i64 {
        self.inner.generate_random_number()
    }
}

struct QueuedFile {
    inner: Arc<dyn File>,
    state: Arc<QueuedIoState>,
}

impl QueuedFile {
    fn enqueue(
        &self,
        completion: Completion,
        action: impl FnOnce() -> turso_core::Result<()> + Send + 'static,
    ) -> turso_core::Result<Completion> {
        self.state
            .pending
            .lock()
            .unwrap()
            .push_back(QueuedIoOp {
                action: Box::new(action),
            });
        Ok(completion)
    }
}

impl File for QueuedFile {
    fn lock_file(&self, exclusive: bool) -> turso_core::Result<()> {
        self.inner.lock_file(exclusive)
    }

    fn unlock_file(&self) -> turso_core::Result<()> {
        self.inner.unlock_file()
    }

    fn pread(&self, pos: u64, completion: Completion) -> turso_core::Result<Completion> {
        let inner = self.inner.clone();
        let c = completion.clone();
        self.enqueue(completion, move || {
            drop(inner.pread(pos, c)?);
            Ok(())
        })
    }

    fn pwrite(
        &self,
        pos: u64,
        buffer: Arc<Buffer>,
        completion: Completion,
    ) -> turso_core::Result<Completion> {
        let inner = self.inner.clone();
        let c = completion.clone();
        self.enqueue(completion, move || {
            drop(inner.pwrite(pos, buffer, c)?);
            Ok(())
        })
    }

    fn sync(&self, completion: Completion, sync_type: FileSyncType) -> turso_core::Result<Completion> {
        let inner = self.inner.clone();
        let c = completion.clone();
        self.enqueue(completion, move || {
            drop(inner.sync(c, sync_type)?);
            Ok(())
        })
    }

    fn pwritev(
        &self,
        pos: u64,
        buffers: Vec<Arc<Buffer>>,
        completion: Completion,
    ) -> turso_core::Result<Completion> {
        let inner = self.inner.clone();
        let c = completion.clone();
        self.enqueue(completion, move || {
            drop(inner.pwritev(pos, buffers, c)?);
            Ok(())
        })
    }

    fn size(&self) -> turso_core::Result<u64> {
        self.inner.size()
    }

    fn truncate(&self, len: u64, completion: Completion) -> turso_core::Result<Completion> {
        let inner = self.inner.clone();
        let c = completion.clone();
        self.enqueue(completion, move || {
            drop(inner.truncate(len, c)?);
            Ok(())
        })
    }
}
