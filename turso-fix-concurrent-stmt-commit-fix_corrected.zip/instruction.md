## Task

With `PRAGMA journal_mode = 'mvcc'` I keep getting databases that come back damaged once the connection closes: schema entries or rows gone, and once the file wouldn't open at all. Every time, one statement on the connection got interrupted partway (step returned IO and I dropped it) and then another statement on the same connection ran to the end. These are the ones I can reproduce, and the last two show up without mvcc as well:

```
DROP TABLE on a table with an index, interrupted and dropped, then SELECT 1, close  -> reopening fails with Corrupt("sqlite_schema contains index for missing table ...")
INSERT ... RETURNING with one row read and the statement left open, then an unrelated SELECT sum(x) fails on integer overflow  -> the rows that INSERT wrote are gone
BEGIN, INSERT a row, COMMIT returns IO and I drop it, then INSERT another row  -> the first row is there too; I'd expect a dropped COMMIT to throw its transaction away
```

With a single statement in flight at a time none of this happens. Can you find the root cause and fix it?
