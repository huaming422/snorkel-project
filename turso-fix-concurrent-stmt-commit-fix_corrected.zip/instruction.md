## Task

With `PRAGMA journal_mode = 'mvcc'` I keep getting databases that come back damaged once the connection closes: schema entries or rows gone or half changed, and once the file wouldn't open at all. In every case two statements were in flight on one connection and one of them was left unfinished:

```
DROP TABLE on an indexed table (or an UPDATE, a DELETE) gets IO from step and I drop it, then SELECT 1, an INSERT, or an INSERT OR FAIL that hits UNIQUE runs, close  -> reopening fails with Corrupt("sqlite_schema contains index for missing table ..."), or the UPDATE/DELETE shows up half done
INSERT ... RETURNING with one row read and left open, another statement fails (sum overflow, UNIQUE, foreign key), then I read the INSERT to its end  -> its rows are gone, with or without mvcc
BEGIN, INSERT a row, COMMIT returns IO and I drop it, then INSERT another row, no mvcc  -> the first row is there too; I'd expect a dropped COMMIT to throw its transaction away
```

A plain INSERT that fails on its own keeps none of its rows, and I'd expect the same when it fails next to an open statement, with the open one's rows left alone. With a single statement in flight at a time none of this happens. Can you find the root cause and fix it?
