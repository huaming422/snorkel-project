# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

"""Behavioral verifier for superset-fix-guest-token-scoping.

Every check goes through Superset's real HTTP routes with the Flask test client,
as an embedded-dashboard guest holding a real guest token, against rows in an
in-memory metadata database and a small SQLite dataset. Where a fix sits is not
asserted, only what the guest gets back:

* ``POST /api/v1/chart/data`` for chart requests, filter value lookups, Drill
  By and Drill to Detail, plus ``POST /datasource/samples`` for the Drill to
  Detail table. A tampered request passes when the response carries none of
  the data it reached for, whatever status a fix answers with (a crash, HTTP
  5xx, does not pass). A legitimate request passes on HTTP 200 with its rows.
* ``GET /embedded/<uuid>``, the page served before any guest token exists: its
  body must not carry the dashboard's title or description.

The dataset has a ``secret`` column. The aggregated charts never show it, and
one chart's saved samples query shows it for the EMEA region only. There are two
native annotation layers: one saved on a shared chart, one saved on no chart.
"""

from __future__ import annotations

import os
import sqlite3
import tempfile
from datetime import datetime
from typing import Any
from unittest.mock import patch

import pytest

from superset.extensions import appbuilder, db
from superset.security.manager import SupersetSecurityManager
from superset.utils import json

DATA_DB = os.path.join(tempfile.mkdtemp(prefix="guest_scope_verify_"), "orders.db")

# Values only the dataset's unshown column holds.
SECRET = "SECRET-"
# Text of the annotation on the layer a shared chart is saved with, and on the
# layer no chart is saved with.
SHARED_NOTE = "NOTE-SHARED-INCIDENT"
UNSHARED_NOTE = "NOTE-UNSHARED-PAYROLL"

DASH_TITLE = "Quarterly Revenue Confidential Board Report"
DASH_DESCRIPTION = "internal-only dashboard description"

REGIONS = {"EMEA", "AMER", "APAC"}


# ---------------------------------------------------------------------------
# App, metadata database and a small SQLite dataset.
# ---------------------------------------------------------------------------
@pytest.fixture(scope="module", autouse=True)
def app():
    from flask_appbuilder import Model
    from sqlalchemy.pool import StaticPool

    from superset.app import SupersetApp
    from superset.initialization import SupersetAppInitializer

    con = sqlite3.connect(DATA_DB)
    con.execute("CREATE TABLE orders (region TEXT, secret TEXT, cnt INTEGER)")
    con.executemany(
        "INSERT INTO orders VALUES (?, ?, ?)",
        [
            ("EMEA", f"{SECRET}emea", 3),
            ("AMER", f"{SECRET}amer", 5),
            ("APAC", f"{SECRET}apac", 7),
        ],
    )
    con.commit()
    con.close()

    # ``superset.app`` as the import name, as the real factory does, so the
    # embedded page finds its templates.
    app = SupersetApp("superset.app")
    app.config.from_object("superset.config")
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite://"
    # One shared connection, so tables created below are visible to every query.
    app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
        "poolclass": StaticPool,
        "connect_args": {"check_same_thread": False},
    }
    app.config["WTF_CSRF_ENABLED"] = False
    app.config["TESTING"] = True
    app.config["RATELIMIT_ENABLED"] = False
    app.config["CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    app.config["DATA_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    app.config["FILTER_STATE_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    app.config["EXPLORE_FORM_DATA_CACHE_CONFIG"] = {"CACHE_TYPE": "NullCache"}
    app.config["GLOBAL_ASYNC_QUERIES_REDIS_CONFIG"] = None
    app.config["TALISMAN_ENABLED"] = False
    app.config["PREVENT_UNSAFE_DB_CONNECTIONS"] = False
    app.config["GUEST_TOKEN_JWT_SECRET"] = "verify-guest-token-secret-" + "x" * 32
    app.config["FEATURE_FLAGS"] = {
        **app.config.get("FEATURE_FLAGS", {}),
        "EMBEDDED_SUPERSET": True,
    }
    appbuilder.baseviews = []
    SupersetAppInitializer(app).init_app()
    with app.app_context():
        import superset.connectors.sqla.models  # noqa: F401
        import superset.models.annotations  # noqa: F401
        import superset.models.core  # noqa: F401
        import superset.models.dashboard  # noqa: F401
        import superset.models.embedded_dashboard  # noqa: F401
        import superset.models.slice  # noqa: F401
        import superset.subjects.models  # noqa: F401

        Model.metadata.create_all(db.engine)
        sm = appbuilder.sm
        appbuilder.add_permissions(update_perms=True)
        sm.sync_role_definitions()
        # The guest role may read annotations, as it must for embedded charts
        # to show the layers they are saved with.
        guest_role = sm.find_role(app.config["GUEST_ROLE_NAME"]) or sm.add_role(
            app.config["GUEST_ROLE_NAME"]
        )
        sm.add_permission_role(
            guest_role, sm.add_permission_view_menu("can_read", "Annotation")
        )
        yield app


# ---------------------------------------------------------------------------
# One embedded dashboard over ``orders``: an aggregated chart, the same chart
# with an annotation layer, a chart saved with two queries, and a native
# filter on ``region``. Only ``region`` is drillable.
# ---------------------------------------------------------------------------
@pytest.fixture(scope="module")
def world(app):
    from superset.connectors.sqla.models import SqlaTable, SqlMetric, TableColumn
    from superset.models.annotations import Annotation, AnnotationLayer
    from superset.models.core import Database
    from superset.models.dashboard import Dashboard
    from superset.models.embedded_dashboard import EmbeddedDashboard
    from superset.models.slice import Slice

    database = Database(
        database_name="orders_db", sqlalchemy_uri=f"sqlite:///{DATA_DB}"
    )
    table = SqlaTable(
        table_name="orders",
        database=database,
        columns=[
            TableColumn(column_name="region", groupby=True, filterable=True),
            TableColumn(column_name="secret", groupby=False, filterable=False),
            TableColumn(column_name="cnt", groupby=False, filterable=False),
        ],
        metrics=[SqlMetric(metric_name="count", expression="COUNT(*)")],
    )
    db.session.add_all([database, table])
    db.session.commit()

    layers = {}
    for name, note in (("Incidents", SHARED_NOTE), ("Payroll", UNSHARED_NOTE)):
        layer = AnnotationLayer(name=name)
        db.session.add(layer)
        db.session.commit()
        db.session.add(
            Annotation(
                layer_id=layer.id,
                short_descr=note,
                long_descr=note,
                start_dttm=datetime(2024, 1, 1),
                end_dttm=datetime(2024, 1, 2),
            )
        )
        db.session.commit()
        layers[name] = layer

    def native_layer(layer, **extra: Any) -> dict[str, Any]:
        return {
            "annotationType": "EVENT",
            "sourceType": "NATIVE",
            "value": layer.id,
            "name": layer.name,
            "show": True,
            "showLabel": False,
            "showMarkers": False,
            "hideLine": False,
            "style": "solid",
            "width": 1,
            "overrides": {},
            **extra,
        }

    shared_layer = native_layer(layers["Incidents"])
    base_params = {"viz_type": "table", "metrics": ["count"], "groupby": ["region"]}
    query = {"metrics": ["count"], "columns": ["region"], "row_limit": 100}

    def chart(name: str, extra_params: dict[str, Any], queries: list[dict]) -> Slice:
        params = {**base_params, **extra_params}
        slc = Slice(
            slice_name=name,
            viz_type="table",
            datasource_type="table",
            datasource_id=table.id,
            params=json.dumps(params),
        )
        db.session.add(slc)
        db.session.commit()
        slc.query_context = json.dumps(
            {
                "datasource": {"id": table.id, "type": "table"},
                "force": False,
                "queries": queries,
                "form_data": {**params, "slice_id": slc.id},
                "result_format": "json",
                "result_type": "full",
            }
        )
        db.session.commit()
        return slc

    charts = {
        "agg": chart("agg", {}, [query]),
        "annotated": chart(
            "annotated",
            {"annotation_layers": [shared_layer]},
            [{**query, "annotation_layers": [shared_layer]}],
        ),
        # Saved with a second query that asks for samples of the EMEA rows.
        "two_queries": chart(
            "two_queries",
            {},
            [
                query,
                {
                    **query,
                    "result_type": "samples",
                    "filters": [{"col": "region", "op": "==", "val": "EMEA"}],
                },
            ],
        ),
    }

    native_filter_id = "NATIVE_FILTER-region"
    dash = Dashboard(
        dashboard_title=DASH_TITLE,
        description=DASH_DESCRIPTION,
        slug="embedded-orders",
        published=True,
        json_metadata=json.dumps(
            {
                "native_filter_configuration": [
                    {
                        "id": native_filter_id,
                        "filterType": "filter_select",
                        "targets": [
                            {"datasetId": table.id, "column": {"name": "region"}}
                        ],
                        "controlValues": {},
                    }
                ]
            }
        ),
    )
    dash.slices = list(charts.values())
    db.session.add(dash)
    db.session.commit()
    embedding = EmbeddedDashboard(dashboard_id=dash.id)
    db.session.add(embedding)
    db.session.commit()
    return {
        "table": table,
        "layers": layers,
        "native_layer": native_layer,
        "shared_layer": shared_layer,
        "base_params": base_params,
        "query": query,
        "charts": charts,
        "dashboard": dash,
        "embedding": embedding,
        "native_filter_id": native_filter_id,
    }


def _clear_login_cache() -> None:
    """The module keeps one app context open and Flask reuses it for test
    requests, so Flask-Login's per-context user cache is cleared per request."""
    from flask import g

    for attr in ("_login_user", "user"):
        g.pop(attr, None)


def _guest_headers(app, world) -> dict[str, str]:
    token = appbuilder.sm.create_guest_access_token(
        {"username": "embed_viewer", "first_name": "Embed", "last_name": "Viewer"},
        [{"type": "dashboard", "id": str(world["embedding"].uuid)}],
        [],
    )
    if isinstance(token, bytes):
        token = token.decode()
    return {app.config["GUEST_TOKEN_HEADER_NAME"]: token}


def _guest_post(app, world, path: str, **kwargs: Any):
    """A guest request. Only the route permission lookup is stubbed, so the
    request reaches the data-access logic under test."""
    _clear_login_cache()
    headers = _guest_headers(app, world)
    with patch.object(SupersetSecurityManager, "has_access", return_value=True):
        return app.test_client().post(path, headers=headers, **kwargs)


def _chart_body(
    world,
    chart: str | None,
    queries: list[dict[str, Any]],
    *,
    form_data: dict[str, Any] | None = None,
    result_type: str = "full",
) -> dict[str, Any]:
    table = world["table"]
    if form_data is None:
        form_data = {
            **world["base_params"],
            "slice_id": world["charts"][chart].id,
            "dashboardId": world["dashboard"].id,
            "datasource": f"{table.id}__table",
        }
    return {
        "datasource": {"id": table.id, "type": "table"},
        "force": True,
        "queries": queries,
        "form_data": form_data,
        "result_format": "json",
        "result_type": result_type,
    }


def _chart_data(app, world, body):
    return _guest_post(app, world, "/api/v1/chart/data", json=body)


def _rows(response) -> list[dict[str, Any]]:
    payload = response.get_json(silent=True) or {}
    rows: list[dict[str, Any]] = []
    for result in payload.get("result") or []:
        if isinstance(result, dict):
            rows.extend(result.get("data") or [])
    return rows


def _assert_withheld(response, markers: str | tuple[str, ...], what: str) -> None:
    assert response.status_code < 500, (
        f"{what}: the request crashed (HTTP {response.status_code})"
    )
    for marker in (markers,) if isinstance(markers, str) else markers:
        assert marker.encode() not in response.data, (
            f"{what}: the guest received data this request isn't for "
            f"(HTTP {response.status_code})"
        )


def _assert_served(response, what: str) -> list[dict[str, Any]]:
    assert response.status_code == 200, (
        f"{what}: expected HTTP 200, got {response.status_code}: "
        f"{response.data[:400]!r}"
    )
    rows = _rows(response)
    assert rows, f"{what}: the response carried no rows"
    return rows


def _drill_by_form_data(world) -> dict[str, Any]:
    return {
        "slice_id": 0,
        "chart_id": world["charts"]["agg"].id,
        "dashboardId": world["dashboard"].id,
        "groupby": ["region"],
        "viz_type": "table",
    }


def _native_filter_form_data(world) -> dict[str, Any]:
    return {
        "type": "NATIVE_FILTER",
        "native_filter_id": world["native_filter_id"],
        "dashboardId": world["dashboard"].id,
    }


# ---------------------------------------------------------------------------
# Annotation layers: only the layers a shared chart is saved with.
# ---------------------------------------------------------------------------
def test_annotation_layer_not_on_the_chart_is_withheld(app, world) -> None:
    """A layer no shared chart is saved with, added to a chart that has none."""
    layer = world["native_layer"](world["layers"]["Payroll"])
    body = _chart_body(world, "agg", [{**world["query"], "annotation_layers": [layer]}])
    body["form_data"]["annotation_layers"] = [layer]
    _assert_withheld(_chart_data(app, world, body), UNSHARED_NOTE, "injected layer")


def test_annotation_layer_swapped_under_the_saved_name_is_withheld(
    app, world
) -> None:
    """The chart's own layer entry, kept under its saved name but pointed at a
    layer the chart isn't saved with."""
    swapped = {**world["shared_layer"], "value": world["layers"]["Payroll"].id}
    body = _chart_body(
        world, "annotated", [{**world["query"], "annotation_layers": [swapped]}]
    )
    body["form_data"]["annotation_layers"] = [swapped]
    _assert_withheld(_chart_data(app, world, body), UNSHARED_NOTE, "swapped layer")


def test_annotation_layer_saved_on_the_chart_is_served(app, world) -> None:
    """Replaying the chart's own layer still returns its annotations."""
    layer = world["shared_layer"]
    body = _chart_body(
        world, "annotated", [{**world["query"], "annotation_layers": [layer]}]
    )
    body["form_data"]["annotation_layers"] = [layer]
    response = _chart_data(app, world, body)
    _assert_served(response, "saved layer replay")
    assert SHARED_NOTE.encode() in response.data, (
        "the chart's own annotation layer was not returned"
    )


# ---------------------------------------------------------------------------
# Raw rows: a chart request returns what the chart shows, a filter value lookup
# returns the filter's values and Drill By returns the drilled breakdown, never
# the dataset's raw rows.
# ---------------------------------------------------------------------------
RAW_ROW_REQUESTS = {
    "request_samples": ("samples", None),
    "request_drill_detail": ("drill_detail", None),
    "query_samples": ("full", "samples"),
    "query_drill_detail": ("full", "drill_detail"),
}


@pytest.mark.parametrize("case", list(RAW_ROW_REQUESTS))
def test_chart_request_for_raw_rows_is_withheld(app, world, case) -> None:
    """The aggregated chart asked for raw rows, on the request or on its query."""
    request_type, query_type = RAW_ROW_REQUESTS[case]
    query = dict(world["query"])
    if query_type:
        query["result_type"] = query_type
    body = _chart_body(world, "agg", [query], result_type=request_type)
    _assert_withheld(_chart_data(app, world, body), SECRET, case)


def test_raw_rows_moved_to_another_query_of_the_chart_are_withheld(
    app, world
) -> None:
    """A chart saved with EMEA samples on its second query: samples of every
    region asked for on its first query, the one the chart renders aggregated.
    Rows outside EMEA are no part of anything the chart returns."""
    query = world["query"]
    body = _chart_body(
        world,
        "two_queries",
        [{**query, "result_type": "samples"}, {**query, "result_type": "full"}],
    )
    _assert_withheld(
        _chart_data(app, world, body),
        (f"{SECRET}amer", f"{SECRET}apac"),
        "samples on query 0",
    )


@pytest.mark.parametrize("result_type", ["samples", "drill_detail"])
def test_filter_value_lookup_for_raw_rows_is_withheld(
    app, world, result_type
) -> None:
    """A native filter's value lookup on its own column, asking for raw rows."""
    body = _chart_body(
        world,
        None,
        [{"columns": ["region"], "metrics": [], "row_limit": 100}],
        form_data=_native_filter_form_data(world),
        result_type=result_type,
    )
    _assert_withheld(_chart_data(app, world, body), SECRET, f"filter {result_type}")


@pytest.mark.parametrize("result_type", ["samples", "drill_detail"])
def test_drill_by_for_raw_rows_is_withheld(app, world, result_type) -> None:
    """A Drill By on the chart's drillable column, asking for raw rows."""
    body = _chart_body(
        world,
        None,
        [{"columns": ["region"], "metrics": ["count"], "row_limit": 100}],
        form_data=_drill_by_form_data(world),
        result_type=result_type,
    )
    _assert_withheld(_chart_data(app, world, body), SECRET, f"Drill By {result_type}")


# ---------------------------------------------------------------------------
# Guest views that must keep working.
# ---------------------------------------------------------------------------
def _legit_request(world, case: str) -> tuple[str, dict[str, Any]]:
    query = world["query"]
    table = world["table"]
    dashboard_id = world["dashboard"].id
    if case == "chart":
        return "/api/v1/chart/data", {"json": _chart_body(world, "agg", [query])}
    if case == "chart_results":
        body = _chart_body(world, "agg", [query], result_type="results")
        return "/api/v1/chart/data", {"json": body}
    if case == "filter_value_lookup":
        body = _chart_body(
            world,
            None,
            [{"columns": ["region"], "metrics": [], "row_limit": 100}],
            form_data=_native_filter_form_data(world),
        )
        return "/api/v1/chart/data", {"json": body}
    if case == "drill_by":
        body = _chart_body(
            world,
            None,
            [{"columns": ["region"], "metrics": ["count"], "row_limit": 100}],
            form_data=_drill_by_form_data(world),
        )
        return "/api/v1/chart/data", {"json": body}
    if case == "drill_to_detail_download":
        body = _chart_body(
            world,
            None,
            [{"columns": [], "metrics": [], "orderby": [], "row_limit": 100}],
            form_data={"dashboardId": dashboard_id},
            result_type="drill_detail",
        )
        return "/api/v1/chart/data", {"json": body}
    if case == "drill_to_detail_table":
        path = (
            f"/datasource/samples?datasource_type=table&datasource_id={table.id}"
            f"&dashboard_id={dashboard_id}&force=false&per_page=50&page=1"
        )
        return path, {"json": {}}
    raise AssertionError(case)


@pytest.mark.parametrize(
    "case",
    [
        "chart",
        "chart_results",
        "filter_value_lookup",
        "drill_by",
        "drill_to_detail_download",
        "drill_to_detail_table",
    ],
)
def test_guest_views_still_work(app, world, case) -> None:
    """Chart data (also as plain results), filter value lookups, Drill By, and Drill to Detail (its table and
    its download), since that one is meant to show the dataset's rows."""
    path, kwargs = _legit_request(world, case)
    response = _guest_post(app, world, path, **kwargs)
    if case == "drill_to_detail_table":
        assert response.status_code == 200, (
            f"Drill to Detail table: expected HTTP 200, got {response.status_code}: "
            f"{response.data[:400]!r}"
        )
        result = (response.get_json(silent=True) or {}).get("result") or {}
        assert result.get("data"), "Drill to Detail table: no rows"
        return
    rows = _assert_served(response, case)
    if case.startswith("drill_to_detail"):
        return
    assert {row.get("region") for row in rows} == REGIONS, (
        f"{case}: unexpected rows {rows}"
    )
    assert SECRET.encode() not in response.data, f"{case}: raw rows leaked"


# ---------------------------------------------------------------------------
# The page served before any guest token is presented.
# ---------------------------------------------------------------------------
def test_embedded_page_has_no_dashboard_metadata(app, world) -> None:
    _clear_login_cache()
    response = app.test_client().get(f"/embedded/{world['embedding'].uuid}")
    assert response.status_code == 200, (
        f"embedded page did not render (HTTP {response.status_code})"
    )
    assert DASH_TITLE.encode() not in response.data, (
        "the embedded page shows the dashboard title"
    )
    assert DASH_DESCRIPTION.encode() not in response.data, (
        "the embedded page shows the dashboard description"
    )
